/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.c
*
*  @brief   :
*
*  @author  :
*
*  @date    : 2017.11.27
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "Apache.h"
#include "System.h"

#include "./Test/sim.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define SRAM1_TEST                      1
#define SRAM2_TEST                      1
#define DDR_TEST                        1


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


unsigned char nChar[256];
unsigned short nShort[256];
unsigned int nInt[256];


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void APACHE_TEST_APP_DisplayClock(void)
{
    DEBUGMSG(MSGINFO, STR_CLEAR_SCREEN);
    DEBUGMSG(MSGINFO, "\n============================================================\n");
    DEBUGMSG(MSGINFO, "   Test APP Version: [v%d.%d.%d]    [%s, %s]\n",
                      TEST_APP_VER_MAJOR, TEST_APP_VER_MINOR1, TEST_APP_VER_MINOR2, TEST_APP_BUILD_DATE, TEST_APP_BUILD_TIME);
    DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");

    APACHE_SYS_DisplayClock();
}


void APACHE_TEST_APP_InitDebugPort(UINT32 nDbgZone_APP, UINT32 nDbgZone_SDK)
{
    // Open Debug Port (Used UART Interface)
    ncLib_DEBUG_Open();

    // Init Debug Port
    ncLib_DEBUG_Control(GCMD_DBG_INIT, UART_CH0, UT_BAUDRATE_115200, CMD_END);

    // APP Debug Zone - On/Off
    ncLib_DEBUG_Control(GCMD_DBG_APP_LOG_ZONE, nDbgZone_APP, ON, CMD_END);

    // SDK Debug Zone - On/Off
    ncLib_DEBUG_Control(GCMD_DBG_SDK_LOG_ZONE, nDbgZone_SDK, ON, CMD_END);
}


void APACHE_TEST_APP_InitInterface(void)
{
    ncLib_SCU_Open();
    //ncLib_INTC_Open();

    APACHE_TEST_APP_InitDebugPort(MSGFULL, MSGFULL);
    APACHE_TEST_APP_DisplayClock();
}


int main(void)
{
	unsigned int nTestStep = 0;
	int i;
	unsigned int ctemp, stemp, itemp;

#if SRAM2_TEST
	unsigned char  *ncSRAMtest = (unsigned char  *)0x02000000;
	unsigned short *nsSRAMtest = (unsigned short *)0x02001000;
	unsigned int   *niSRAMtest = (unsigned int   *)0x02002000;
#endif
#if DDR_TEST
	unsigned char  *ncDDRtest =  (unsigned char  *)0x80000000;
	unsigned short *nsDDRtest =  (unsigned short *)0x80001000;
	unsigned int   *niDDRtest =  (unsigned int   *)0x80002000;
#endif

	nTestStep = 0;
	REGRW32(0x08000000, 0x1000) = nTestStep;
	REGRW32(0x08000000, 0x1004) = nTestStep;	// sram_1 area result
	REGRW32(0x08000000, 0x1008) = nTestStep;	// sram_2 area result
	REGRW32(0x08000000, 0x100C) = nTestStep;	// ddr area result

	/* -----------------------------------------------------------------------------------------------
	 * 1. chart, short, int address access test
	 * write 0 ~ 255
	 * */

	for(i = 0; i < 256; i++)
	{
		nChar[i] = i;
	}

	nTestStep = 1;
	REGRW32(0x08000000, 0x1000) = nTestStep;

	for(i = 0; i < 256; i++)
	{
		nShort[i] = (i<<8) | i;
	}

	nTestStep = 2;
	REGRW32(0x08000000, 0x1000) = nTestStep;

	for(i = 0; i < 256; i++)
	{
		nInt[i] = (i<<24) | (i<<16) | (i<<8) | i;
	}

	nTestStep = 3;
	REGRW32(0x08000000, 0x1000) = nTestStep;

	/*
	 * 1. chart, short, int address access test
	 * compare 0 ~ 255
	 * */

	for(i = 0; i < 256; i++)
	{
		ctemp = i;
		if(nChar[i] != ctemp)
		{
			REGRW32(0x08000000, 0x1004) = nTestStep;
			REGRW32(0x08000000, 0x1010) = i;
			break;
		}
	}

	nTestStep = 4;
	REGRW32(0x08000000, 0x1000) = nTestStep;

	for(i = 0; i < 256; i++)
	{
		stemp = (i<<8) | i;
		if(nShort[i] != stemp)
		{
			REGRW32(0x08000000, 0x1004) = nTestStep;
			REGRW32(0x08000000, 0x1010) = (i<<8) | i;
			break;
		}
	}

	nTestStep = 5;
	REGRW32(0x08000000, 0x1000) = nTestStep;

	for(i = 0; i < 256; i++)
	{
		itemp = (i<<24) | (i<<16) | (i<<8) | i;
		if(nInt[i] != itemp)
		{
			REGRW32(0x08000000, 0x1004) = nTestStep;
			REGRW32(0x08000000, 0x1010) = (i<<24) | (i<<16) | (i<<8) | i;
			break;
		}
	}

	nTestStep = 0x10;
	REGRW32(0x08000000, 0x1000) = nTestStep;

    {
#if SRAM2_TEST
	    /* -----------------------------------------------------------------------------------------------
		 * 2. SRAM chart, short, int address access test
		 * write 0 ~ 255
		 * */

		for(i = 0; i < 256; i++)
		{
			ncSRAMtest[i] = i;
		}

		nTestStep = 0x11;
		REGRW32(0x08000000, 0x1000) = nTestStep;

		for(i = 0; i < 256; i++)
		{
			nsSRAMtest[i] = (i<<8) | i;
		}

		nTestStep = 0x12;
		REGRW32(0x08000000, 0x1000) = nTestStep;

		for(i = 0; i < 256; i++)
		{
			niSRAMtest[i] = (i<<24) | (i<<16) | (i<<8) | i;
		}

		nTestStep = 0x13;
		REGRW32(0x08000000, 0x1000) = nTestStep;

		/*
		 * 2. SRAM chart, short, int address access test
		 * compare 0 ~ 255
		 * */


		for(i = 0; i < 256; i++)
		{
			ctemp = i;
			if(ncSRAMtest[i] != ctemp)
			{
				REGRW32(0x08000000, 0x1008) = nTestStep;
				REGRW32(0x08000000, 0x1010) = i;
				break;
			}
		}

		nTestStep = 0x14;
		REGRW32(0x08000000, 0x1000) = nTestStep;

		for(i = 0; i < 256; i++)
		{
			stemp = (i<<8) | i;
			if(nsSRAMtest[i] != stemp)
			{
				REGRW32(0x08000000, 0x1008) = nTestStep;
				REGRW32(0x08000000, 0x1010) = (i<<8) | i;
				break;
			}
		}

		nTestStep = 0x15;
		REGRW32(0x08000000, 0x1000) = nTestStep;

		for(i = 0; i < 256; i++)
		{
			itemp = (i<<24) | (i<<16) | (i<<8) | i;
			if(niSRAMtest[i] != itemp)
			{
				REGRW32(0x08000000, 0x1008) = nTestStep;
				REGRW32(0x08000000, 0x1010) = (i<<24) | (i<<16) | (i<<8) | i;
				break;
			}
		}

		nTestStep = 0x20;
		REGRW32(0x08000000, 0x1000) = nTestStep;
#endif

#if DDR_TEST
		/* -----------------------------------------------------------------------------------------------
		 * 3. DDR chart, short, int address access test
		 * write 0 ~ 255
		 * */

		for(i = 0; i < 256; i++)
		{
			ncDDRtest[i] = i;
		}

		nTestStep = 0x21;
		REGRW32(0x08000000, 0x1000) = nTestStep;

		for(i = 0; i < 256; i++)
		{
			nsDDRtest[i] = (i<<8) | i;
		}

		nTestStep = 0x22;
		REGRW32(0x08000000, 0x1000) = nTestStep;

		for(i = 0; i < 256; i++)
		{
			niDDRtest[i] = (i<<24) | (i<<16) | (i<<8) | i;
		}

		nTestStep = 0x23;
		REGRW32(0x08000000, 0x1000) = nTestStep;

		/*
		 * 2. SRAM chart, short, int address access test
		 * compare 0 ~ 255
		 * */


		for(i = 0; i < 256; i++)
		{
			ctemp = i;
			if(ncDDRtest[i] != ctemp)
			{
				REGRW32(0x08000000, 0x100C) = nTestStep;
				REGRW32(0x08000000, 0x1010) = i;
				break;
			}
		}

		nTestStep = 0x24;
		REGRW32(0x08000000, 0x1000) = nTestStep;

		for(i = 0; i < 256; i++)
		{
			stemp = (i<<8) | i;
			if(nsDDRtest[i] != stemp)
			{
				REGRW32(0x08000000, 0x100C) = nTestStep;
				REGRW32(0x08000000, 0x1010) = (i<<8) | i;
				break;
			}
		}

		nTestStep = 0x25;
		REGRW32(0x08000000, 0x1000) = nTestStep;

		for(i = 0; i < 256; i++)
		{
			itemp = (i<<24) | (i<<16) | (i<<8) | i;
			if(niDDRtest[i] != itemp)
			{
				REGRW32(0x08000000, 0x100C) = nTestStep;
				REGRW32(0x08000000, 0x1010) = (i<<24) | (i<<16) | (i<<8) | i;
				break;
			}
		}

		nTestStep = 0x30;
		REGRW32(0x08000000, 0x1000) = nTestStep;
#endif
    }

    APACHE_TEST_APP_InitInterface();

    while(1)
    {
        for(i = 0; i < 10000; i++)
        {
            //DEBUGMSG(MSGINFO, ".\n");
            REGRW32(0x08000000, 0x1000) = i;

            nc_mdelay(1000);
        }
    }

	nTestStep = 0xFFFFFFFF;
	REGRW32(0x08000000, 0x1000) = nTestStep;

    return 0;
}


/* End Of File */
