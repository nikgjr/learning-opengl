/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.c
*
*  @brief   :
*
*  @author  :
*
*  @date    : 2017.11.27
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "App.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

extern void APACHE_APP_InitISP2M(void);


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void APACHE_APP_InitDebugPort(UINT32 nDbgZone_APP, UINT32 nDbgZone_SDK)
{
    // Open Debug Port (Used UART_0 Interface)
    ncLib_DEBUG_Open();

    // Init Debug Port
    ncLib_DEBUG_Control(GCMD_DBG_INIT, UART_CH0, UT_BAUDRATE_115200, CMD_END);

    // APP Debug Zone - On/Off
    ncLib_DEBUG_Control(GCMD_DBG_APP_LOG_ZONE, nDbgZone_APP, ON, CMD_END);

    // SDK Debug Zone - On/Off
    ncLib_DEBUG_Control(GCMD_DBG_SDK_LOG_ZONE, nDbgZone_SDK, ON, CMD_END);

    DEBUGMSG(MSGINFO, STR_CLEAR_SCREEN);
    DEBUGMSG(MSGINFO, "\n============================================================\n");
    DEBUGMSG(MSGINFO, "   Test APP Version: [v%d.%d.%d]   [%s, %s]\n",
                      APP_VER_MAJOR, APP_VER_MINOR1, APP_VER_MINOR2, APP_BUILD_DATE, APP_BUILD_TIME);
    DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");

    APACHE_SYS_DisplayClock();
}


void APACHE_APP_InitUartJigPort(void)
{
    // Open Jig Port (Used UART_1 Interface)
    ncLib_JIG_Open();

    // Init Jig Port
    ncLib_JIG_Control(GCMD_JIG_INIT, UART_CH1, UT_BAUDRATE_57600, CMD_END);
    //ncLib_JIG_Control(GCMD_JIG_INIT, UART_CH1, UT_BAUDRATE_38400, CMD_END);
}


void APACHE_APP_InitInterface(void)
{
    ncLib_SCU_Open();
    ncLib_INTC_Open();

    APACHE_APP_InitDebugPort(MSGFULL, MSGFULL);

    APACHE_APP_InitUartJigPort();

    APACHE_APP_InitISP2M();
}


int main(void)
{
    APACHE_APP_InitInterface();

    while(1)
    {
        ncLib_JIG_Control(GCMD_JIG_DO_COMMAND, CMD_END);

        nc_mdelay(10);
    }

    return 0;
}


/* End Of File */
