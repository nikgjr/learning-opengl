/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    :
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version :
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __RE_LIB_H__
#define __RE_LIB_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

/*
********************************************************************************
*               DEFINES
********************************************************************************
*/



/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum
{
    /*
    * Generic Commands
    */
    GCMD_RE_INIT = 0,
	GCMD_RE_DEINIT,
    GCMD_RE_RUN,
	GCMD_RE_STOP,
	GCMD_RE_SCALER_INIT,
    GCMD_RE_VDPD_INIT,
	GCMD_RE_VDPD_DEINIT,
    GCMD_RE_VDPD_RUN,
	GCMD_RE_VDPD_STOP,
    GCMD_RE_MOD_INIT,
	GCMD_RE_MOD_DEINIT,
    GCMD_RE_MOD_RUN,
	GCMD_RE_MOD_STOP,
    GCMD_RE_LD_INIT,
	GCMD_RE_LD_DEINIT,
    GCMD_RE_LD_RUN,
	GCMD_RE_LD_STOP,
    GCMD_RE_CE_INIT,
	GCMD_RE_CE_DEINIT,
    GCMD_RE_CE_RUN,
	GCMD_RE_CE_STOP,
    GCMD_RE_MAX

} eRE_CMD;


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

extern INT32 ncLib_RE_Open(void);
extern INT32 ncLib_RE_Close(void);
extern INT32 ncLib_RE_Read(void);
extern INT32 ncLib_RE_Write(void);
extern INT32 ncLib_RE_Control(eRE_CMD Cmd, ...);

#endif  /* __RE_LIB_H__ */


/* End Of File */
