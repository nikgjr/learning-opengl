/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __PWM_LIB_H__
#define __PWM_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define PMW_DUTY_MIN    1
#define PWM_DUTY_MAX    99

#define PWM_FREQ_MIN    (100)










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* PWM GENERIC & SPECIFIC COMMANDS
*/

typedef enum _PWM_CMD
{
    /*
    * Generic Commands
    */

    GCMD_PWM_INIT_CH = 0,
    GCMD_PWM_DEINIT_CH, 
    GCMD_PWM_START,
    GCMD_PWM_STOP,
    GCMD_PWM_SET_FREQUENCY,
    GCMD_PWM_GET_INT_STS,

    GCMD_PWM_MAX

} ePWM_CMD;

typedef enum
{
    PWM_CH0,
    PWM_CH1,
    PWM_CH2,
    PWM_CH3,
    
    MAX_OF_PWM_CH
} ePWM_CH;

typedef enum
{
    PWM_OP_DIS = (0<<0),    
    PWM_OP_EN  = (1<<0)
} ePWM_OP;

typedef enum
{
    PWM_ISR_DIS = (0<<1),    
    PWM_ISR_EN  = (1<<1)
} ePWM_ISR;

typedef enum
{
    PWM_OUT_DIS = (0<<2),    
    PWM_OUT_EN  = (1<<2)
} ePWM_OUT;

typedef enum
{
    PWM_LEVEL_LOW  = (0<<3),
    PWM_LEVEL_HIGH = (1<<3)
} ePWM_INIT_LEVEL;

typedef enum
{
    PWM_SCALE_1X    = (0<<4),
    PWM_SCALE_1_2X  = (1<<4),
    PWM_SCALE_1_3X  = (2<<4),
    PWM_SCALE_1_4X  = (3<<4),
    PWM_SCALE_1_5X  = (4<<4),  
} ePWM_SCALE;

typedef enum
{
    PWM_MODE_ONE_SHOT = (0<<8),
    PWM_MODE_AUTO_RELOAD = (1<<8)
} ePWM_MODE;










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    ePWM_ISR        mIsrEn;
    ePWM_OUT        mOutEn;
    ePWM_INIT_LEVEL mLevel;
    ePWM_SCALE      mScale;
    ePWM_MODE       mMode;

    UINT32          mFrequency;
    UINT32          mDutyCycle;
} tPWM_PARAM, *ptPWM_PARAM;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_PWM_Open(void);
extern INT32 ncLib_PWM_Close(void);
extern INT32 ncLib_PWM_Read(void);
extern INT32 ncLib_PWM_Write(void);
extern INT32 ncLib_PWM_Control(ePWM_CMD Cmd, ...);


#endif /* __PWM_LIB_H__ */


/* End Of File */

