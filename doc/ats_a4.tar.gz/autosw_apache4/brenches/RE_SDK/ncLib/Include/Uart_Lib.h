/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __UART_LIB_H__
#define __UART_LIB_H__


/*
********************************************************************************
*               INCLUDE                                    
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define BACKSP_KEY          0x08
#define RETURN_KEY          0x0D
#define DELETE_KEY          0x7F
#define BELL                0x07
#define ESCAPE_KEY          0x1B
 










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* UART GENERIC & SPECIFIC COMMANDS
*/

typedef enum
{
    /*
    * Generic Commands
    */

    GCMD_UT_INIT_CH = 0,
    GCMD_UT_DEINIT_CH,
    
    GCMD_UT_SET_BAUDRATE,
    GCMD_UT_GET_INT_STS,
    GCMD_UT_GET_FIFO_CNT,
    
    GCMD_UT_GET_CHAR,
    GCMD_UT_PUT_CHAR,
    GCMD_UT_PUT_STR,
  
    GCMD_UT_MAX
} eUART_CMD;


typedef enum
{
    UART_CH0 = 0,
    UART_CH1,

    MAX_OF_UART_CH
} eUART_CH;

typedef enum
{
    UT_SPS_DIS = (0<<5),
    UT_SPS_ENA = (1<<5),

    MAX_OF_UART_SPS
} eUART_SPS;

typedef enum
{
    UT_DATA_5BIT = (0<<0),
    UT_DATA_6BIT = (1<<0),
    UT_DATA_7BIT = (2<<0),
    UT_DATA_8BIT = (3<<0),

    MAX_OF_UART_DATA_WLEN_BIT
} eUART_DATA_WLEN;

typedef enum
{
    UT_STOP_1BIT = (0<<2),
    UT_STOP_2BIT = (1<<2),

    MAX_OF_UART_STOP_BIT
} eUART_STOP_BIT;

typedef enum
{
    UT_EPS_DIS = (0<<4),    // odd
    UT_EPS_ENA = (1<<4),    // even

    MAX_OF_UART_EPS
} eUART_EPS;

typedef enum
{
    UT_PARITY_DIS = (0<<3),
    UT_PARITY_ENA = (1<<3),

    MAX_OF_UART_PARITY
} eUART_PARITY;

typedef enum
{
    UT_BRK_DIS = (0<<6),
    UT_BRK_ENA = (1<<6),

    MAX_OF_UART_BRK
} eUART_BRK;


typedef enum
{
    UT_BAUDRATE_300     = 300,
    UT_BAUDRATE_600     = 600,
    UT_BAUDRATE_1200    = 1200,
    UT_BAUDRATE_2400    = 2400,
    UT_BAUDRATE_4800    = 4800,
    UT_BAUDRATE_9600    = 9600,
    UT_BAUDRATE_19200   = 19200,
    UT_BAUDRATE_38400   = 38400,
    UT_BAUDRATE_57600   = 57600,
    UT_BAUDRATE_115200  = 115200,
    UT_BAUDRATE_230400  = 230400,
    UT_BAUDRATE_460800  = 460800,
    UT_BAUDRATE_921600  = 921600
} eUART_BAUDRATE;











/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    BOOL            mIntEn;     // Interrupt On or Off  
    UINT32          mBaudRate;  // UART baudrate

    eUART_SPS       mSPS;       // Stick parity select
    eUART_DATA_WLEN mLEN;       // Word length
    eUART_STOP_BIT  mSTP;       // Two stop bits select
    eUART_EPS       mEPS;       // Even parity select
    eUART_PARITY    mPEN;       // Parity enable
    eUART_BRK       mBRK;       // Send break
} tUART_PARAM, *ptUART_PARAM;











/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_UART_Open(void);
extern INT32 ncLib_UART_Close(void);
extern INT32 ncLib_UART_Read(void);
extern INT32 ncLib_UART_Write(void);
extern INT32 ncLib_UART_Control(eUART_CMD Cmd, ...);


#endif /* __UART_LIB_H__ */


/* End Of File */

