/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __APACHE_H__
#define __APACHE_H__


/*
********************************************************************************
*               INCLUDE                                    
********************************************************************************
*/

#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

#include "Type.h"

/* Peripheral Libraries */
#include "Debug_Lib.h"
#include "DMA_Lib.h"
#include "GPIO_Lib.h"
#include "I2C_Lib.h"
#include "INTC_Lib.h"
#include "PWM_Lib.h"
#include "QSPI_Lib.h"
#include "SCU_Lib.h"
#include "SSP_Lib.h"
#include "sFlash_Lib.h"
#include "SysTime_Lib.h"
#include "Timer_Lib.h"
#include "Uart_Lib.h"

/* ISP Libraries */
//#include "ISP_Lib.h"


/* RE Libraries */
#include "RE_Lib.h"


/* JIG Libraries */
#include "JIG_Lib.h"










/*
********************************************************************************
*               MEMORY MAP FOR APACHE                             
********************************************************************************
*/

/* Storage Memory Map */

#define APACHE_IROM_BASE                0x00000000
#define APACHE_IRAM_BASE                0x02000000
#define APACHE_NAND_BASE                0x70000000
#define APACHE_DRAM_BASE                0x80000000


/* Peripheral Memory Map */

#define APACHE_SYSCON_BASE              0x08000000
#define APACHE_ICU_BASE                 0x08100000
#define APACHE_GPIO_BASE                0x08101000

#define APACHE_INTC_BASE                0x10000000
#define APACHE_DMAC_BASE                0x10100000
#define APACHE_TIMER0_BASE              0x10300000
#define APACHE_TIMER1_BASE              0x10480000
#define APACHE_PWM_BASE                 0x10500000
#define APACHE_I2C_0_BASE               0x10600000
#define APACHE_I2C_1_BASE               0x10700000
#define APACHE_UART_0_BASE              0x10800000
#define APACHE_UART_1_BASE              0x10900000
#define APACHE_SPI_0_BASE               0x10A00000
#define APACHE_SPI_1_BASE               0x10B00000
#define APACHE_QSPI_BASE                0x10C00000
#define APACHE_FMC_BASE                 0x12300000
#define APACHE_SDC_BASE                 0x12400000
#define APACHE_DSP_BASE                 0x13000000
#define APACHE_ISP_BASE                 0x14800000


#if 0
#define APACHE_EI_BASE                  0x80000000
#define APACHE_FT_BASE                  0x80100000
#define APACHE_DDRC_BASE                0x90400000
#define APACHE_CAN_BASE                 0x90C00000
#define APACHE_ATOP_BASE                0x90F00000
#define APACEH_ADAS_BASE                0x93000000
#define APACHE_SE_BASE                  0xA0000000
#define APACHE_ISP_SM_BASE              0xA1000000
#define APACHE_RE_SM_BASE               0xA2000000
#endif











/*
*******************************************************************************
*               DEFINITION FOR ARM ASM CODE SECTION                      
*******************************************************************************
*/

extern void __CORE_INT_EN(void);
extern void __CORE_INT_DIS(void);

//extern void __ENTER_CRITICAL_SECTION(void);
//extern void __EXIT_CRITICAL_SECTION(void);










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

#ifdef __MAIN_C__
#define GLOBAL
#else
#define GLOBAL extern
#endif

// Set Value : ncLib_SCU_Open() Function Call.
GLOBAL UINT32 SYS_TICK_CLK;










/*
*******************************************************************************
*               INLINE FUNCTION FOR APACHE
*******************************************************************************
*/

static __inline UINT32 nc_get_tick(UINT32 cls)
{
    if(cls)
    {
        // Clear : Count == 0
        REGRW32(APACHE_SYSCON_BASE, 0x3000) = 0x0;
    }

    return REGRW32(APACHE_SYSCON_BASE, 0x3000);
}


static __inline void nc_wait_tick(UINT32 ticks)
{
    UINT32 sTicks = nc_get_tick(1);

    while ((nc_get_tick(0) - sTicks) < ticks);
}


static __inline void nc_delay(UINT32 s)
{
    // limit 10-sec
    if(s > 10) s = 10;

    nc_wait_tick(SYS_TICK_CLK * s);
}


static __inline void nc_mdelay(UINT32 ms)
{
    // limit 10-sec
    if(ms > 10000) ms = 10000;

    nc_wait_tick((SYS_TICK_CLK / MSEC) * ms);
}


static __inline void nc_udelay(UINT32 us)
{
    // limit 10-sec
    if(us > 10000000) us = 10000000;

    nc_wait_tick((SYS_TICK_CLK / USEC) * us);
}


static __inline unsigned int nc_get_msec(UINT32 cls)
{
    UINT32 curr_tick = nc_get_tick(cls);

    if(curr_tick)
        curr_tick = curr_tick / (SYS_TICK_CLK / MSEC);

    return curr_tick;
}


static __inline unsigned int nc_get_usec(UINT32 cls)
{
    UINT32 curr_tick = nc_get_tick(cls);

    if(curr_tick)
        curr_tick = curr_tick / (SYS_TICK_CLK / USEC);

    return curr_tick;
}


static __inline UINT32 nc_get_tick_auto_cls(void)
{
    // It is initialized to '0' when reading the register.
    return REGRW32(APACHE_SYSCON_BASE, 0x3004);
}


static __inline UINT32 nc_get_msec_auto_cls(void)
{
    UINT32 curr_tick = nc_get_tick_auto_cls();

    if(curr_tick)
        curr_tick = curr_tick / (SYS_TICK_CLK / MSEC);

    return curr_tick;
}


static __inline UINT32 nc_get_usec_auto_cls(void)
{
    UINT32 curr_tick = nc_get_tick_auto_cls();

    if(curr_tick)
        curr_tick = curr_tick / (SYS_TICK_CLK / USEC);

    return curr_tick;
}


#endif	/* __APACHE_H__ */


/* End Of File */

