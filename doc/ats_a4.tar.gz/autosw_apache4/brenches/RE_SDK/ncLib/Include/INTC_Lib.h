/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : INTC_Lib.h
*
*  @brief   :
*
*  @author  :
*
*  @date    : 2018.01.15
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __INTC_LIB_H__
#define __INTC_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

//#define DEF_INTC_TRIGGER_LEVEL      TRIG_HIGH_LEVEL
#define DEF_INTC_PRIORITY_LEVEL     240










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* INTC GENERIC & SPECIFIC COMMANDS
*/

typedef enum
{
	GCMD_INTC_REGISTER_INT = 0,
	GCMD_INTC_UNREGISTER_INT,
	GCMD_INTC_SGI_TRIGGER,

	GCMD_INTC_ENABLE_INT,
	GCMD_INTC_DISABLE_INT,
    GCMD_INTC_SET_PRIORITY_LEVEL,
	GCMD_INTC_ONOFF_RAISED_INT,      // for Debug
	GCMD_INTC_CHK_RAISED_INT,        // for Debug
	GCMD_INTC_CLR_RAISED_INT,        // for Debug

	GCMD_INTC_MAX
} eINTC_CMD;

#if 0
typedef enum
{
	TRIG_LEVEL_HIGH = 0,
	TRIG_LEVEL_LOW,
	TRIG_EDGE_HIGH,
	TRIG_EDGE_LOW,
	TRIG_EDGE_BOTH
} eTRIG_MODE;
#endif

typedef enum
{
    IRQ_NUM_NULL = 0,

    IRQ_NUM_SGI_0 = IRQ_NUM_NULL,
    IRQ_NUM_SGI_1,
    IRQ_NUM_SGI_2,   
    IRQ_NUM_SGI_3,
    IRQ_NUM_SGI_MAX,

    // A = 0 group
    IRQ_NUM_TIMER0 = 32,    // (A+ 0)
    IRQ_NUM_TIMER1,         // (A+ 1)
    IRQ_NUM_TIMER2,         // (A+ 2)
    IRQ_NUM_TIMER3,         // (A+ 3)
    IRQ_NUM_TIMER4,         // (A+ 4)
    IRQ_NUM_TIMER5,         // (A+ 5)
    IRQ_NUM_TIMER6,         // (A+ 6)
    IRQ_NUM_TIMER7,         // (A+ 7)
    IRQ_NUM_UART0,          // (A+ 8)
    IRQ_NUM_UART1,          // (A+ 9)
    IRQ_NUM_I2C0,           // (A+10)
    IRQ_NUM_I2C1,           // (A+11)
    IRQ_NUM_SPI0,           // (A+12) - EDGE
    IRQ_NUM_SPI1,           // (A+13) - EDGE
    IRQ_NUM_QSPI,           // (A+14)
    IRQ_NUM_DMA_CHANNEL0,   // (A+15)
    IRQ_NUM_DMA_CHANNEL1,   // (A+16)
    IRQ_NUM_DMA_CHANNEL2,   // (A+17)
    IRQ_NUM_DMA_CHANNEL3,   // (A+18)
    IRQ_NUM_PWM0,           // (A+19) - EDGE
    IRQ_NUM_PWM1,           // (A+20) - EDGE
    IRQ_NUM_PWM3,           // (A+21) - EDGE
    IRQ_NUM_PWM4,           // (A+22) - EDGE
    IRQ_NUM_CAN,            // (A+23)
    IRQ_NUM_GPIO0,          // (A+24)
    IRQ_NUM_GPIO1,          // (A+25)
    IRQ_NUM_GPIO2,          // (A+26)
    IRQ_NUM_FMC,            // (A+27)
    IRQ_NUM_SDC,            // (A+28)
    IRQ_NUM_REV29,          // (A+29)
    IRQ_NUM_REV30,          // (A+30)
    IRQ_NUM_REV31,          // (A+31)

    // B = 32 group
    IRQ_NUM_ISP0 = 64,      // (A+32) - EDGE
    IRQ_NUM_ISP1,           // (A+33) - EDGE
    IRQ_NUM_ISP2,           // (A+34) - EDGE
    IRQ_NUM_ISP3,           // (A+35) - EDGE
    IRQ_NUM_ISP4,           // (A+36) - EDGE
    IRQ_NUM_ISP5,           // (A+37) - EDGE
    IRQ_NUM_ISP6,           // (A+38) - EDGE
    IRQ_NUM_ISP7,           // (A+39) - EDGE
    IRQ_NUM_ISP8,           // (A+40) - EDGE
    IRQ_NUM_ISP9,           // (A+41) - EDGE
    IRQ_NUM_VDUMP,          // (A+42) - EDGE
    IRQ_NUM_REV43,          // (A+43)
    IRQ_NUM_REV44,          // (A+44)
    IRQ_NUM_REV45,          // (A+45)
    IRQ_NUM_REV46,          // (A+46)
    IRQ_NUM_REV47,          // (A+47)
    IRQ_NUM_RE_VDPD,        // (A+48)
    IRQ_NUM_RE_SCALER,      // (A+49)
    IRQ_NUM_RE_MOD,         // (A+50)
    IRQ_NUM_RE_CE,          // (A+51)
    IRQ_NUM_RE_LD,          // (A+52)
    IRQ_NUM_REV53,          // (A+53)
    IRQ_NUM_REV54,          // (A+54)
    IRQ_NUM_REV55,          // (A+55)
    IRQ_NUM_NOC0,           // (A+56) - EDGE
    IRQ_NUM_NOC1,           // (A+57) - EDGE
    IRQ_NUM_NOC2,           // (A+58) - EDGE
    IRQ_NUM_NOC3,           // (A+59) - EDGE
    IRQ_NUM_NOC4,           // (A+60) - EDGE
    IRQ_NUM_NOC5,           // (A+61) - EDGE
    IRQ_NUM_REV62,          // (A+62)
    IRQ_NUM_FAULT,          // (A+63) - EDGE

    MAX_IRQ_NUM,

    FIQ_NUM_NULL = MAX_IRQ_NUM,

    MAX_FIQ_NUM
} eINT_NUM;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32  ncLib_INTC_Open(void);
extern INT32  ncLib_INTC_Close(void);
extern INT32  ncLib_INTC_Read(void);
extern INT32  ncLib_INTC_Write(void);
extern INT32  ncLib_INTC_Control(eINTC_CMD Cmd, ...);

extern void   ncLib_INTC_IrqHandler(void);
extern void   ncLib_INTC_FiqHandler(void);


#endif /* __INTC_LIB_H__ */


/* End Of File */

