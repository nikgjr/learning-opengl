/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SSP_LIB_H__
#define __SSP_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* SSP GENERIC & SPECIFIC COMMANDS
*/

typedef enum _SSP_CMD
{
    /*
    * Generic SSP Commands
    */
    GCMD_SSP_INIT_CH = 0,
    GCMD_SSP_DEINIT_CH,
    GCMD_SSP_CS_ENABLE_CH,
    GCMD_SSP_CS_DISABLE_CH,
    GCMD_SSP_SET_BITRATE_CH,
    GCMD_SSP_SET_DMA_MODE,    
    GCMD_SSP_GET_INT_STS,	
    GCMD_SSP_MAX,

    /*
    * Specific Commands
    */
    SCMD_SSP_PAD_CTRL_GET = 100,
    SCMD_SSP_PAD_CTRL_FREE,	 
    SCMD_SSP_MAX
} eSSP_CMD;


typedef enum _SSP_CH
{
    SSP_CH0 = 0,
    SSP_CH1,
    MAX_OF_SSP_CH
} eSSP_CH;


typedef enum _SSP_MODE
{
    SSP_MODE_MASTER = 0,    // Master Mode
    SSP_MODE_SLAVE          // Slave Mode
} eSSP_MODE;


typedef enum _SSP_ORDER
{
    SSP_MSB_FIRST = 0,
    SSP_LSB_FIRST
} eSSP_ORDER;


typedef enum _SSP_SPH       // Clock Phase 
{
    SSP_SPH_LOW = 0,        // Catch data at falling edge
    SSP_SPH_HIGH            // Catch data at rising edge
} eSSP_SPH;


typedef enum _SSP_SPO       // Clock Polarity
{
    SSP_SPO_LOW = 0,        // Clock will remain low when SSP is in the idle state
    SSP_SPO_HIGH            // Clock will remain high when SSP is in the idle state
} eSSP_SPO;


// Data width
typedef enum _SSP_DS
{
    SSP_DS_4BIT = 3,
    SSP_DS_5BIT,
    SSP_DS_6BIT,
    SSP_DS_7BIT,
    SSP_DS_8BIT,
    SSP_DS_9BIT,
    SSP_DS_10BIT,
    SSP_DS_11BIT,
    SSP_DS_12BIT,
    SSP_DS_13BIT,
    SSP_DS_14BIT,
    SSP_DS_15BIT,
    SSP_DS_16BIT,
} eSSP_DS;










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tSSP_PARAM
{
    BOOL            mIntEn;   
    UINT32          mBitRate;  
    
    eSSP_MODE       mMode;
    eSSP_DS         mDataWidth;
    eSSP_SPO        mSPO;
    eSSP_SPH        mSPH;
    eSSP_ORDER      mOrder;
} tSSP_PARAM, *ptSSP_PARAM;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_SSP_Open(void);
extern INT32 ncLib_SSP_Close(void);
extern INT32 ncLib_SSP_Read(eSSP_CH Ch, UINT8 *pBuf, UINT32 Length);
extern INT32 ncLib_SSP_Write(eSSP_CH Ch, UINT8 *pBuf, UINT32 Length);
extern INT32 ncLib_SSP_Control(eSSP_CMD Cmd, ...);


#endif /* __SSP_LIB_H__ */


/* End Of File */

