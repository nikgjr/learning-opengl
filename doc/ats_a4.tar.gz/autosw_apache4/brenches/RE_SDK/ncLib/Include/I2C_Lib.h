/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __I2C_LIB_H__
#define __I2C_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define APACHE_I2C_SLAVE_REG_00               0x40
#define APACHE_I2C_SLAVE_REG_01               0x41
#define APACHE_I2C_SLAVE_REG_02               0x42
#define APACHE_I2C_SLAVE_REG_03               0x43










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* I2C GENERIC & SPECIFIC COMMANDS
*/

typedef enum _I2C_CMD
{
    /*
    * Generic Commands
    */

    GCMD_I2C_INIT_CH = 0,
    GCMD_I2C_DEINIT_CH,
    GCMD_I2C_SET_BITRATE,
    GCMD_I2C_SET_DEV_ADDR,
    GCMD_I2C_SET_LENGTH_TYPE,
    GCMD_I2C_GET_INT_STS,
    GCMD_I2C_SET_INT_CLS,

    GCMD_I2C_SET_ACK_VALUE,     // Only Slave Mode

    GCMD_I2C_MAX

} eI2C_CMD;


typedef enum
{
    I2C_CH0,
    I2C_CH1,
    MAX_OF_I2C_CH
} eI2C_CH;


typedef enum
{
    I2C_OP_MODE_MASTER,
    I2C_OP_MODE_SLAVE,
    MAX_OF_I2C_MODE
} eI2C_OP_MODE;


typedef enum
{
    I2C_ADDR_8_DATA_8,
    I2C_ADDR_8_DATA_16,
    I2C_ADDR_16_DATA_8,
    I2C_ADDR_16_DATA_16,
    MAX_OF_I2C_LENGTH_TYPE
} eI2C_LENGTH_TYPE;


typedef enum 
{
    I2C_DEV_7BIT,
    I2C_DEV_10BIT,
} eI2C_DEV_BIT_TYPE;










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    BOOL              mIntEn;           // Interrupt On/Off            : Enable or DISABLE    
    eI2C_OP_MODE      mOpMode;          // Operation Mode              : Master/Slave
    eI2C_LENGTH_TYPE  mLengthType;      // Device RegAddr, Data Length : 8_8/ 8_16/ 16_8/ 16_16
    eI2C_DEV_BIT_TYPE mDevBit;          // Slave Device Addressing     : 7-bit, 10-bit
    UINT16            mDevAddr;         // Slave Address               : Master Mode(Target Addr), Slave Mode(My Addr)
    UINT32            mHz;              // I2C Target Hz               : 1KHz~400KHz
} tI2C_PARAM, *ptI2C_PARAM;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_I2C_Open(void);
extern INT32 ncLib_I2C_Close(void);
extern INT32 ncLib_I2C_Read(eI2C_CH Ch, UINT16 RegAddr, void *pBuff, UINT32 UnitCnt);
extern INT32 ncLib_I2C_Write(eI2C_CH Ch, UINT16 RegAddr, void *pBuff, UINT32 UnitCnt);
extern INT32 ncLib_I2C_Control(eI2C_CMD Cmd, ...);


#endif  /* __I2C_LIB_H__ */


/* End Of File */

