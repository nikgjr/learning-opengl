/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    :
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version :
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "../../SWC_RE/Service/RE_Svc.h"
#include "Apache.h"

/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile int gbREOpen = 0;

/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncLib_RE_Open(void)
{
    INT32 Ret = NC_SUCCESS;

    gbREOpen = 1;

    return Ret;
}


INT32 ncLib_RE_Close(void)
{
    INT32 Ret = NC_SUCCESS;

    gbREOpen = 0;

    return Ret;
}


INT32 ncLib_RE_Write(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_RE_Read(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_RE_Control(eRE_CMD Cmd,  ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;


    if(gbREOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
            	case GCMD_RE_INIT:
            	{
            	    ncSvc_RE_Register_Init();
            	}
            	break;

            	case GCMD_RE_RUN:
            	{
            		//Adas_draw_main();
            	}
            	break;

            	case GCMD_RE_SCALER_INIT:
				{
					//ncSvc_RE_Scaler_Init();
					A4_RecgScaler_Init();
					//ncSvc_RE_SetDisplayMode();
					ncDrv_AR_SetDisplayMode();
				}
				break;

                case GCMD_RE_VDPD_INIT:
                {
                	//A4_RecgEng_Init();
                    //ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_RE_VDPD, (PrVoid)ncSvc_RE_VDPD_Handler, CMD_END);
                }
                break;

                case GCMD_RE_VDPD_DEINIT:
                {

                }
                break;

                case GCMD_RE_MOD_INIT:
			    {
			    	//A4_Mod_Init();
			    }
			    break;

                case GCMD_RE_LD_INIT:
				{
					//RE_LD_Init();
					A4_LD_Init();
				}
				break;

                case GCMD_RE_CE_INIT:
				{
					//RE_Ce_Init();
					A4_HsvOp_Init();
				}
				break;
                default:
                    Ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


/* End Of File */

