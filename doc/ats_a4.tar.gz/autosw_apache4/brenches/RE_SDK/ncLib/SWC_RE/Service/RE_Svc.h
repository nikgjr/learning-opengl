/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    :
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version :
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __RE_SVC_H__
#define __RE_SVC_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/
#include "Apache.h"

#include "RE_MemoryMap.h"

#include "RE_StatusRegister.h"
#include "RE_ScalerRegister.h"
#include "RE_VdpdRegister.h"
#include "RE_CeRegister.h"
#include "RE_ModRegister.h"
#include "RE_LdRegister.h"
#include "RE_PreRegister.h"
#include "RE_PostRegister.h"
#include "RE_PostTgRegister.h"

#include "./PRE/PRE_Svc.h"
#include "./SCALER/SCALER_Svc.h"
#include "./VDPD/VDPD_Svc.h"
#include "./CE/CE_Svc.h"
#include "./LD/LD_Svc.h"
#include "./MOD/MOD_Svc.h"
#include "./POST/POST_Svc.h"

#include "./_Old/common.h"
#include "./_Old/A4_AdasIp.h"

// ld




/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/



/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
int ncSvc_RE_Register_Init(void);
void ncSvc_RE_AdasIp_Init(void);
void RE_Size_int(unsigned int type);
void ncSvc_RE_SetDisplayMode(void);

extern volatile RE_STATUS_REGISTER   	sReStatusReg;
extern volatile RE_SCALER_REGISTER   	*sReScalerReg;
extern volatile RE_VDPD_REGISTER   		*sReVdpdReg;
extern volatile RE_CE_REGISTER   		*sReCeReg;
extern volatile RE_MOD_REGISTER   		*sReModReg;
extern volatile RE_LD_REGISTER   		*sReLdReg;
extern volatile RE_PRE_REGISTER   		*sRePreReg;
extern volatile RE_POST_REGISTER   		*sRePostReg;
extern volatile RE_POST_TG_REGISTER   	*sRePostTgReg;

#endif  /* __RE_SVC_H__ */


/* End Of File */

