#include "RECG_DataAssociation.h"
#include "RECG_Hungarian.h"
#include "../common.h"

//extern "C"
//{

void data_Association(BOX_INFO *Track_Box, BOX_INFO *Det_Box)
{
#if 0

#endif

#if 1	// ���� ����
	DA da;
	int i,j;

	float cost_matrix[MAX_TRACK][MAX_TRACK];
	int data_matrix[MAX_TRACK][MAX_TRACK];

	da.nTrack = Track_Box->BoxNumMax;
	da.nDetect = Det_Box->BoxNumMax;

	similarity_calculate_Box_Static(&da,Track_Box,Det_Box,0,cost_matrix);

	Hungarian_algorithm_Static(da.nTrack, da.nDetect, cost_matrix, data_matrix);


	for( i = 0; i < da.nTrack; i++)
	{
		Track_Box->BaxXYWH[i].IsAssociation = FALSE;
		Track_Box->BaxXYWH[i].ID = -1;
	}

	for( j = 0; j < da.nDetect; j++)
	{
		Det_Box->BaxXYWH[j].IsAssociation = FALSE;
		Det_Box->BaxXYWH[j].ID = -1;
	}


	for( i = 0; i < da.nTrack; i++)
	{
		for( j = 0; j < da.nDetect; j++)
		{
			//float rate0 = (float)Track_Box->BaxXYWH[i].Width / Det_Box->BaxXYWH[j].Width;
			//float rate1 = (float)Det_Box->BaxXYWH[j].Width / Track_Box->BaxXYWH[i].Width;

			//rate0 = rate0 > rate1 ? rate0 : rate1;


			if (data_matrix[i][j] == 1 && cost_matrix[i][j]<MATCH_THRESHOLD) //  && rate0<1.8
			{
				Track_Box->BaxXYWH[i].IsAssociation = TRUE;
				Track_Box->BaxXYWH[i].ID = j;
				Det_Box->BaxXYWH[j].IsAssociation = TRUE;
				Det_Box->BaxXYWH[j].ID = i;
				Track_Box->BaxXYWH[i].costValue = cost_matrix[i][j];
			
				//printf("%d %d %f\n",j,i,cost_matrix[i][j]);
			}
			else
				Track_Box->BaxXYWH[i].costValue = 1;
		}

	}


#endif
}

float** similarity_calculate(DA *da)
{
	/*int nMapping = da->nMapping;
	int nDetect = da->nDetect;
	

	float** cost_matrix = new float*[nMapping];
	for( i = 0; i < nMapping; i++)
		cost_matrix[i] = new float[nDetect];

	for( i = 0; i < nMapping; i++)
		for( j = 0; j < nDetect; j++)
			cost_matrix[i][j] = 1 - rectOverlapRatio(track[da->mapping[i]].f_predROI, detect[j].detectROI, 0);

	return cost_matrix;*/
}

float similarity_calculate_Box(DA *da, BOX_INFO *a, BOX_INFO *b, int type, float **cost_matrix)
{
	int nTrack = da->nTrack;
	int nDetect = da->nDetect;
	int i,j;

/*
	printf("nTrack : %d , nDetect : %d\n",nTrack,nDetect);

	printf("Tracking ROI\n");
	for( i=0; i<nTrack; i++)
		printf("%f %f %f %f\n",a->BaxXYWH[i].StX,a->BaxXYWH[i].StY,a->BaxXYWH[i].Width,a->BaxXYWH[i].Height);

	printf("Detect ROI\n");
	for( i=0; i<nDetect; i++)
		printf("%f %f %f %f\n",b->BaxXYWH[i].StX,b->BaxXYWH[i].StY,b->BaxXYWH[i].Width,b->BaxXYWH[i].Height);
*/

	for( i = 0; i < nTrack; i++)
	{
		for( j = 0; j < nDetect; j++)
		{
			//overlap is invalid in the beginning
			float o = -1;

			float aPointX1 = a->BaxXYWH[i].StX;
			float aPointY1 = a->BaxXYWH[i].StY;
			float aPointX2 = a->BaxXYWH[i].StX + a->BaxXYWH[i].Width - 1;
			float aPointY2 = a->BaxXYWH[i].StY + a->BaxXYWH[i].Height - 1;

			float bPointX1 = b->BaxXYWH[j].StX;
			float bPointY1 = b->BaxXYWH[j].StY;
			float bPointX2 = b->BaxXYWH[j].StX + b->BaxXYWH[j].Width - 1;
			float bPointY2 = b->BaxXYWH[j].StY + b->BaxXYWH[j].Height - 1;

			//get overlapping area
			float x1 = aPointX1 > bPointX1 ? aPointX1 : bPointX1;
			float y1 = aPointY1 > bPointY1 ? aPointY1 : bPointY1;
			float x2 = aPointX2 < bPointX2 ? aPointX2 : bPointX2;
			float y2 = aPointY2 < bPointY2 ? aPointY2 : bPointY2;

			//compute width and height of overlapping area
			float w = x2 - x1;
			float h = y2 - y1;

			//set invalid entries to 0 overlap
			if (w <= 0 || h <= 0)
			{
				o = 0;
			}

			else
			{
				//get overlapping areas
				float inter = w*h;
				float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
				float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);

				//intersection over union overlap depending on users choice
				if (type == 0)
				{
					o = inter / (a_area + b_area - inter);
				}
				else
				{
					o = (a_area > b_area) ? inter / b_area : inter / a_area;
				}
			}
/*			printf("%d %d , Overlap = %f\n",i,j,o);*/

			cost_matrix[i][j] = 1 - o;
		}
	}


	//overlap
	return 0;
}

float similarity_calculate_Box_Static(DA *da, BOX_INFO *a, BOX_INFO *b, int type, float cost_matrix[][MAX_TRACK])
{
	int nTrack = da->nTrack;
	int nDetect = da->nDetect;
	int i,j;
/*
	printf("nTrack : %d , nDetect : %d\n",nTrack,nDetect);

	printf("Tracking ROI\n");
	for( i=0; i<nTrack; i++)
		printf("%f %f %f %f\n",a->BaxXYWH[i].StX,a->BaxXYWH[i].StY,a->BaxXYWH[i].Width,a->BaxXYWH[i].Height);

	printf("Detect ROI\n");
	for( i=0; i<nDetect; i++)
		printf("%f %f %f %f\n",b->BaxXYWH[i].StX,b->BaxXYWH[i].StY,b->BaxXYWH[i].Width,b->BaxXYWH[i].Height);
*/

	for( i = 0; i < nTrack; i++)
	{
		for( j = 0; j < nDetect; j++)
		{
			//overlap is invalid in the beginning
			float o = -1;

			float aPointX1 = a->BaxXYWH[i].StX;
			float aPointY1 = a->BaxXYWH[i].StY;
			float aPointX2 = a->BaxXYWH[i].StX + a->BaxXYWH[i].Width - 1;
			float aPointY2 = a->BaxXYWH[i].StY + a->BaxXYWH[i].Height - 1;

			float bPointX1 = b->BaxXYWH[j].StX;
			float bPointY1 = b->BaxXYWH[j].StY;
			float bPointX2 = b->BaxXYWH[j].StX + b->BaxXYWH[j].Width - 1;
			float bPointY2 = b->BaxXYWH[j].StY + b->BaxXYWH[j].Height - 1;

			//get overlapping area
			float x1 = aPointX1 > bPointX1 ? aPointX1 : bPointX1;
			float y1 = aPointY1 > bPointY1 ? aPointY1 : bPointY1;
			float x2 = aPointX2 < bPointX2 ? aPointX2 : bPointX2;
			float y2 = aPointY2 < bPointY2 ? aPointY2 : bPointY2;

			//compute width and height of overlapping area
			float w = x2 - x1;
			float h = y2 - y1;

			//set invalid entries to 0 overlap
			if (w <= 0 || h <= 0)
			{
				o = 0;
			}

			else
			{
				//get overlapping areas
				float inter = w*h;
				float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
				float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);

				//intersection over union overlap depending on users choice
				if (type == 0)
				{
					o = inter / (a_area + b_area - inter);
				}
				else
				{
					o = (a_area > b_area) ? inter / b_area : inter / a_area;
				}
			}
/*			printf("%d %d , Overlap = %f\n",i,j,o);*/

			cost_matrix[i][j] = 1 - o;
		}
	}


	//overlap
	return 0;
}

void pile_box_exception(BOX_INFO *a, BOX_INFO *b)
{
	int cnt = 0;
	int i,j;

	BOX_INFO out;

	for( i = 0; i < a->BoxNumMax; i++)
	{
		float max_overay = 0.0;

		for( j = 0; j < a->BoxNumMax; j++)
		{
			if(i!=j)
			{
				float o = -1;

				float aPointX1 = a->BaxXYWH[i].StX;
				float aPointY1 = a->BaxXYWH[i].StY;
				float aPointX2 = a->BaxXYWH[i].StX + a->BaxXYWH[i].Width - 1;
				float aPointY2 = a->BaxXYWH[i].StY + a->BaxXYWH[i].Height - 1;

				float bPointX1 = a->BaxXYWH[j].StX;
				float bPointY1 = a->BaxXYWH[j].StY;
				float bPointX2 = a->BaxXYWH[j].StX + b->BaxXYWH[j].Width - 1;
				float bPointY2 = a->BaxXYWH[j].StY + b->BaxXYWH[j].Height - 1;

				//get overlapping area
				float x1 = aPointX1 > bPointX1 ? aPointX1 : bPointX1;
				float y1 = aPointY1 > bPointY1 ? aPointY1 : bPointY1;
				float x2 = aPointX2 < bPointX2 ? aPointX2 : bPointX2;
				float y2 = aPointY2 < bPointY2 ? aPointY2 : bPointY2;

				//compute width and height of overlapping area
				float w = x2 - x1;
				float h = y2 - y1;

				//set invalid entries to 0 overlap
				if (w <= 0 || h <= 0)
				{
					o = 0;
				}

				else
				{
					//get overlapping areas
					float inter = w*h;
					float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
					float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);

					//intersection over union overlap depending on users choice

					o = inter / a_area;

				}
				/*			printf("%d %d , Overlap = %f\n",i,j,o);*/

				if(o>max_overay)
					max_overay = o;
			
			}
			//overlap is invalid in the beginning
			
		}

		if(max_overay < 0.25)
		{
			int x = a->BaxXYWH[i].StX;
			int y = a->BaxXYWH[i].StY;
			int w = a->BaxXYWH[i].Width;
			int h = a->BaxXYWH[i].Height;

			if(y+h/2>360*0.35)
			{
				out.BaxXYWH[cnt] = a->BaxXYWH[i];
				cnt++;
			}


			
		}
		

	}

	out.BoxNumMax = cnt;
	*a = out;


}

double calc_overay(BOX_XYWH_DATA *a , BOX_XYWH_DATA *b)
{
	double overay;

	float o = -1;

	float aPointX1 = a->StX;
	float aPointY1 = a->StY;
	float aPointX2 = a->StX + a->Width - 1;
	float aPointY2 = a->StY + a->Height - 1;

	float bPointX1 = b->StX;
	float bPointY1 = b->StY;
	float bPointX2 = b->StX + b->Width - 1;
	float bPointY2 = b->StY + b->Height - 1;

	//get overlapping area
	float x1 = aPointX1 > bPointX1 ? aPointX1 : bPointX1;
	float y1 = aPointY1 > bPointY1 ? aPointY1 : bPointY1;
	float x2 = aPointX2 < bPointX2 ? aPointX2 : bPointX2;
	float y2 = aPointY2 < bPointY2 ? aPointY2 : bPointY2;

	//compute width and height of overlapping area
	float w = x2 - x1;
	float h = y2 - y1;

	if(!a->Width || !a->Height)
		return 0;

	//set invalid entries to 0 overlap
	if (w <= 0 || h <= 0)
	{
		o = 0;
	}

	else
	{
		float a_width = aPointX2 - aPointX1;
		float a_height = aPointY2 - aPointY1;
		float b_width = bPointX2 - bPointX1;
		float b_height = bPointY2 - bPointY1;


		//get overlapping areas
		float inter = w*h;

		//float min_area = min((a_width*a_height), (b_width*b_height));
		float min_area = b_width*b_height;

		//printf("%f %f %f\n",(a_width*a_height), (b_width*b_height) , min_area);


		float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
		float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);

		//intersection over union overlap depending on users choice

		o = inter / (a_area + b_area - inter);

		overay = o;

	}
	/*			printf("%d %d , Overlap = %f\n",i,j,o);*/


	return overay;
}

double calc_min_overay(BOX_XYWH_DATA *a , BOX_XYWH_DATA*b, double *out)
{
	double min_overay;

	float o = -1;

	float aPointX1 = a->StX;
	float aPointY1 = a->StY;
	float aPointX2 = a->StX + a->Width - 1;
	float aPointY2 = a->StY + a->Height - 1;

	float bPointX1 = b->StX;
	float bPointY1 = b->StY;
	float bPointX2 = b->StX + b->Width - 1;
	float bPointY2 = b->StY + b->Height - 1;


	//JIGMSG("%d %d %d %d\n",(int)aPointX1 , (int)aPointY1, (int)aPointX2, (int)aPointY2);
	//JIGMSG("%d %d %d %d\n",(int)bPointX1 , (int)bPointY1, (int)bPointX2, (int)bPointY2);


	//get overlapping area
	float x1 = aPointX1 > bPointX1 ? aPointX1 : bPointX1;
	float y1 = aPointY1 > bPointY1 ? aPointY1 : bPointY1;
	float x2 = aPointX2 < bPointX2 ? aPointX2 : bPointX2;
	float y2 = aPointY2 < bPointY2 ? aPointY2 : bPointY2;

	//compute width and height of overlapping area
	float w = x2 - x1;
	float h = y2 - y1;

	//set invalid entries to 0 overlap
	if (w <= 0 || h <= 0)
	{
		min_overay = 0;
	}

	else
	{
		float a_width = aPointX2 - aPointX1;
		float a_height = aPointY2 - aPointY1;
		float b_width = bPointX2 - bPointX1;
		float b_height = bPointY2 - bPointY1;


		//get overlapping areas
		float inter = w*h;

		//float min_area = min((a_width*a_height), (b_width*b_height));
		float min_area = b_width*b_height;

		//printf("%f %f %f\n",(a_width*a_height), (b_width*b_height) , min_area);


		float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
		float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);

		//intersection over union overlap depending on users choice

		o = inter / min_area;

		min_overay = o;

	}


	//JIGMSG("%d\n",(int)(min_overay*1000));
	/*			printf("%d %d , Overlap = %f\n",i,j,o);*/


	*out = min_overay;

	return min_overay;
}
//}

