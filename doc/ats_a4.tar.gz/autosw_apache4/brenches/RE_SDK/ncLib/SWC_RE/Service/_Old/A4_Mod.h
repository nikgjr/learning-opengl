#include "common.h"
#ifndef	_A4_MOD_H_
#define	_A4_MOD_H_

#define	META_MOD_CNT_MAX			2560

typedef struct {
	unsigned int ModX;
	unsigned int ModY;
	int 		 ModU;
	int 		 ModV;
	float		 NCC;
}MOD_LINE;

extern volatile MODValue 		ModLine;
extern volatile unsigned int	DetCntMod[2];

extern void A4_Mod_Init(void);
extern unsigned int A4_MOD_Result(void);
extern unsigned int A4_MOD_Result_test(void);

void ncDrv_MOD_IRQ_Handler(void *param);
void ncDrv_MOD_ISR_Handler(void);

#endif
