#ifndef __RE_CE_REGISTER_H__
#define __RE_CE_REGISTER_H__

/*=============================================================================
	Definitions for Register Start Address, End Address, Size
=============================================================================*/

#define	RE_CE_REGISTER_SIZE	0x700
typedef union
{
	unsigned int Data32[2];
	struct
	{
		unsigned int RESULT_P_CNT:		16;
		unsigned int RESULT_Y_MAX:		9;
		unsigned int REV_1:				7;

		unsigned int RESULT_X_MAX:		10;
		unsigned int RESULT_Y_MIN:		9;
		unsigned int RESULT_X_MIN:		10;
		unsigned int REV_0:				3;
	}Reg;
}RESULT_HSV_OP;


typedef union
{
	unsigned int Data[RE_CE_REGISTER_SIZE/4];
	struct
	{
		/*	0x0000	[00]	*/	unsigned int	HSV_CH0_OP_EN	:	1	;
		/*	0x0000	[02]	*/	unsigned int	Rev0000_02	:	6	;
		/*	0x0000	[08]	*/	unsigned int	HSV_CH1_OP_EN	:	1	;
		/*	0x0000	[09]	*/	unsigned int	Rev0000_09	:	7	;
		/*	0x0000	[16]	*/	unsigned int	HSV_CBCR_SWAP	:	1	;
		/*	0x0000	[17]	*/	unsigned int	Rev0000_17	:	15	;

		/*	0x0004	[00]	*/	unsigned int	CH0_R_H_BOUND_0	:	10	;
		/*	0x0004	[10]	*/	unsigned int	Rev0004_10	:	6	;
		/*	0x0004	[16]	*/	unsigned int	CH0_R_H_BOUND_1	:	10	;
		/*	0x0004	[26]	*/	unsigned int	Rev0004_26	:	6	;

		/*	0x0008	[00]	*/	unsigned int	CH0_R_S_BOUND	:	8	;
		/*	0x0008	[08]	*/	unsigned int	Rev0008_08	:	8	;
		/*	0x0008	[16]	*/	unsigned int	CH0_R_V_BOUND	:	8	;
		/*	0x0008	[24]	*/	unsigned int	Rev0008_24	:	8	;

		/*	0x000C	[00]	*/	unsigned int	CH0_B_H_BOUND_0	:	10	;
		/*	0x000C	[10]	*/	unsigned int	Rev000C_10	:	6	;
		/*	0x000C	[16]	*/	unsigned int	CH0_B_H_BOUND_1	:	10	;
		/*	0x000C	[26]	*/	unsigned int	Rev000C_26	:	6	;

		/*	0x0010	[00]	*/	unsigned int	CH0_B_S_BOUND	:	8	;
		/*	0x0010	[08]	*/	unsigned int	Rev0010_08	:	8	;
		/*	0x0010	[16]	*/	unsigned int	CH0_B_V_BOUND	:	8	;
		/*	0x0010	[24]	*/	unsigned int	Rev0010_24	:	8	;

		/*	0x0014	[00]	*/	unsigned int	CH1_R_H_BOUND_0	:	10	;
		/*	0x0014	[10]	*/	unsigned int	Rev0014_10	:	6	;
		/*	0x0014	[16]	*/	unsigned int	CH1_R_H_BOUND_1	:	10	;
		/*	0x0014	[26]	*/	unsigned int	Rev0014_26	:	6	;

		/*	0x0018	[00]	*/	unsigned int	CH1_R_S_BOUND	:	8	;
		/*	0x0018	[08]	*/	unsigned int	Rev0018_08	:	8	;
		/*	0x0018	[16]	*/	unsigned int	CH1_R_V_BOUND	:	8	;
		/*	0x0018	[24]	*/	unsigned int	Rev0018_24	:	8	;

		/*	0x001C	[00]	*/	unsigned int	CH1_B_H_BOUND_0	:	10	;
		/*	0x001C	[10]	*/	unsigned int	Rev001C_10	:	6	;
		/*	0x001C	[16]	*/	unsigned int	CH1_B_H_BOUND_1	:	10	;
		/*	0x001C	[26]	*/	unsigned int	Rev001C_26	:	6	;

		/*	0x0020	[00]	*/	unsigned int	CH1_B_S_BOUND	:	8	;
		/*	0x0020	[08]	*/	unsigned int	Rev0020_08	:	8	;
		/*	0x0020	[16]	*/	unsigned int	CH1_B_V_BOUND	:	8	;
		/*	0x0020	[24]	*/	unsigned int	Rev0020_24	:	8	;

		/*	0x0024	[00]	*/	unsigned int	HSV_H_ACT	:	10	;
		/*	0x0024	[10]	*/	unsigned int	Rev0024_10	:	22	;

		/*	0x0028	[00]	*/	unsigned int	CH0_MIN_THRESHOLD	:	16	;
		/*	0x0028	[16]	*/	unsigned int	CH0_MAX_THRESHOLD	:	16	;

		/*	0x002C	[00]	*/	unsigned int	CH1_MIN_THRESHOLD	:	16	;
		/*	0x002C	[16]	*/	unsigned int	CH1_MAX_THRESHOLD	:	16	;

		/*	0x0030	[00]	*/	unsigned int	CH0_RESULT_CNT	:	8	;
		/*	0x0030	[08]	*/	unsigned int	Rev0030_08	:	8	;
		/*	0x0030	[24]	*/	unsigned int	Rev0030_24	:	8	;
		/*	0x0030	[16]	*/	unsigned int	CH1_RESULT_CNT	:	8	;

		/*	0x0034	[00]	*/	unsigned int	CH0_SEL	:	1	;
		/*	0x0034	[01]	*/	unsigned int	Rev0034_01	:	15	;
		/*	0x0034	[16]	*/	unsigned int	CH1_SEL	:	1	;
		/*	0x0034	[17]	*/	unsigned int	Rev0034_17	:	15	;

		/*	0x0038	[00]	*/	unsigned int	Rev0038_00	:	32	;

		/*	0x003C	[00]	*/	unsigned int	Rev003C_00	:	32	;

		/* 0x0040[00] */ RESULT_HSV_OP	CH0_Result_Hsv_op[100]		;	// 0x0040 ~ 0x035C
		/* 0x0360[00] */ RESULT_HSV_OP	CH1_Result_Hsv_op[100]		;	// 0x0360 ~ 0x067C

		/*	0x0680	[00]	*/	unsigned int	END_INT_CLR	:	1	;
		/*	0x0680	[01]	*/	unsigned int	START_INT_CLR	:	1	;
		/*	0x0680	[02]	*/	unsigned int	Rev0680_02	:	30	;

		/*	0x0684	[00]	*/	unsigned int	END_INT_EN	:	1	;
		/*	0x0684	[01]	*/	unsigned int	START_INT_EN	:	1	;
		/*	0x0684	[02]	*/	unsigned int	Rev0684_02	:	14	;
		/*	0x0684	[16]	*/	unsigned int	INT_PULSE_EN	:	1	;
		/*	0x0684	[17]	*/	unsigned int	Rev0684_17	:	15	;

		/*	0x0688	[00]	*/	unsigned int	END	:	1	;
		/*	0x0688	[01]	*/	unsigned int	START	:	1	;
		/*	0x0688	[02]	*/	unsigned int	Rev0688_02	:	6	;
		/*	0x0688	[08]	*/	unsigned int	END_INT	:	1	;
		/*	0x0688	[09]	*/	unsigned int	START_INT	:	1	;
		/*	0x0688	[10]	*/	unsigned int	Rev0688_10	:	22	;

		/*	0x068C	[00]	*/	unsigned int	FRAME_TOT_PIX_CNT	:	32	;

		/*	0x0690	[00]	*/	unsigned int	R_FRAME_TOT_PIX_CNT	:	32	;


		/* 0x0694	[00] 	*/ unsigned int	Rev0364_00[(0x0700-0x0694)/4];

	}Reg;
}RE_CE_REGISTER;

#endif


