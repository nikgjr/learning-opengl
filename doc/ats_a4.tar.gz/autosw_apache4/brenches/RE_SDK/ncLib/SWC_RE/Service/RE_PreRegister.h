#ifndef __RE_PRE_REGISTER_H__
#define __RE_PRE_REGISTER_H__

/*=============================================================================
	Definitions for Register Start Address, End Address, Size
=============================================================================*/
#define	RE_PRE_REGISTER_SIZE	0x200

typedef union
{
	UINT32 Data[RE_PRE_REGISTER_SIZE/4];
	struct
	{
		/*	0x0000	[00]	*/	unsigned int	FR_SKIP_CNT	:	3	;
		/*	0x0000	[03]	*/	unsigned int	Rev0000_03	:	5	;
		/*	0x0000	[08]	*/	unsigned int	YUV_SWAP	:	1	;
		/*	0x0000	[09]	*/	unsigned int	Rev0000_09	:	7	;
		/*	0x0000	[16]	*/	unsigned int	VSYNC_R_CHANGE_EN	:	1	;
		/*	0x0000	[17]	*/	unsigned int	Rev0000_17	:	15	;

		/*	0x0004	[00]	*/	unsigned int	VSYNC_R_SHIFT_CNT	:	32	;

		/*	0x0008	[00]	*/	unsigned int	DOWN_CROP_EN	:	1	;
		/*	0x0008	[01]	*/	unsigned int	Rev0008_01	:	7	;
		/*	0x0008	[08]	*/	unsigned int	DOWN_CROP_REG_UPD	:	1	;
		/*	0x0008	[09]	*/	unsigned int	Rev0008_09	:	23	;

		/*	0x000C	[00]	*/	unsigned int	DOWN_CROP_H_POS	:	16	;
		/*	0x000C	[16]	*/	unsigned int	DOWN_CROP_V_POS	:	16	;

		/*	0x0010	[00]	*/	unsigned int	DOWN_CROP_H_SIZE	:	16	;
		/*	0x0010	[16]	*/	unsigned int	DOWN_CROP_V_SIZE	:	16	;

		/*	0x0014	[00]	*/	unsigned int	DOWN_CROP_H_ACT	:	16	;
		/*	0x0014	[16]	*/	unsigned int	DOWN_CROP_V_ACT	:	16	;

		/*	0x0018	[00]	*/	unsigned int	CROP_EN	:	1	;
		/*	0x0018	[01]	*/	unsigned int	Rev0018_01	:	3	;
		/*	0x0018	[04]	*/	unsigned int	CROP_SWAP	:	1	;
		/*	0x0018	[05]	*/	unsigned int	Rev0018_05	:	3	;
		/*	0x0018	[08]	*/	unsigned int	CROP_REG_UPD	:	1	;
		/*	0x0018	[09]	*/	unsigned int	Rev0018_09	:	23	;

		/*	0x001C	[00]	*/	unsigned int	CROP_H_POS	:	16	;
		/*	0x001C	[16]	*/	unsigned int	CROP_V_POS	:	16	;

		/*	0x0020	[00]	*/	unsigned int	CROP_H_SIZE	:	16	;
		/*	0x0020	[16]	*/	unsigned int	CROP_V_SIZE	:	16	;

		/*	0x0024	[00]	*/	unsigned int	CROP_H_ACT	:	16	;
		/*	0x0024	[16]	*/	unsigned int	CROP_V_ACT	:	16	;

		/*	0x0028	[00]	*/	unsigned int	WIDE_CROP_EN	:	1	;
		/*	0x0028	[01]	*/	unsigned int	Rev0028_01	:	3	;
		/*	0x0028	[04]	*/	unsigned int	WIDE_CROP_SWAP	:	1	;
		/*	0x0028	[05]	*/	unsigned int	Rev0028_05	:	3	;
		/*	0x0028	[08]	*/	unsigned int	WIDE_CROP_REG_UPD	:	1	;
		/*	0x0028	[09]	*/	unsigned int	Rev0028_09	:	23	;

		/*	0x002C	[00]	*/	unsigned int	WIDE_CROP_H_POS	:	16	;
		/*	0x002C	[16]	*/	unsigned int	WIDE_CROP_V_POS	:	16	;

		/*	0x0030	[00]	*/	unsigned int	WIDE_CROP_H_SIZE	:	16	;
		/*	0x0030	[16]	*/	unsigned int	WIDE_CROP_V_SIZE	:	16	;

		/*	0x0034	[00]	*/	unsigned int	WIDE_CROP_H_ACT	:	16	;
		/*	0x0034	[16]	*/	unsigned int	WIDE_CROP_V_ACT	:	16	;

		/*	0x0038	[00]	*/	unsigned int	DS_EN	:	1	;
		/*	0x0038	[01]	*/	unsigned int	Rev0038_01	:	7	;
		/*	0x0038	[08]	*/	unsigned int	DS_REG_UPD	:	1	;
		/*	0x0038	[09]	*/	unsigned int	Rev0038_09	:	7	;
		/*	0x0038	[16]	*/	unsigned int	DS_USE_HSYNC	:	1	;
		/*	0x0038	[17]	*/	unsigned int	DS_OUT_HSYNC	:	1	;
		/*	0x0038	[18]	*/	unsigned int	Rev0038_18	:	6	;
		/*	0x0038	[24]	*/	unsigned int	DS_OUT_UV_SWAP	:	1	;
		/*	0x0038	[25]	*/	unsigned int	Rev0038_25	:	7	;

		/*	0x003C	[00]	*/	unsigned int	DS_IN_HACT_SIZE	:	13	;
		/*	0x003C	[13]	*/	unsigned int	Rev003C_13	:	3	;
		/*	0x003C	[16]	*/	unsigned int	DS_IN_HBLK_SIZE	:	13	;
		/*	0x003C	[29]	*/	unsigned int	Rev003C_29	:	3	;

		/*	0x0040	[00]	*/	unsigned int	DS_IN_VACT_SIZE	:	13	;
		/*	0x0040	[13]	*/	unsigned int	Rev0040_13	:	19	;

		/*	0x0044	[00]	*/	unsigned int	DS_METHOD_Y	:	1	;
		/*	0x0044	[01]	*/	unsigned int	DS_METHOD_C	:	1	;
		/*	0x0044	[02]	*/	unsigned int	Rev0044_02	:	6	;
		/*	0x0044	[08]	*/	unsigned int	DS_TABLE_SEL_Y	:	2	;
		/*	0x0044	[10]	*/	unsigned int	DS_TABLE_SEL_C	:	2	;
		/*	0x0044	[12]	*/	unsigned int	Rev0044_12	:	20	;

		/*	0x0048	[00]	*/	unsigned int	DS_H_DTO	:	16	;
		/*	0x0048	[16]	*/	unsigned int	DS_V_DTO	:	16	;

		/*	0x004C	[00]	*/	unsigned int	DS_OUT_HACT_SIZE	:	12	;
		/*	0x004C	[12]	*/	unsigned int	Rev004C_12	:	4	;
		/*	0x004C	[16]	*/	unsigned int	DS_OUT_VACT_SIZE	:	13	;
		/*	0x004C	[29]	*/	unsigned int	Rev004C_29	:	3	;

		/*	0x0050	[00]	*/	unsigned int	HUS_IN_H_SIZE	:	12	;
		/*	0x0050	[12]	*/	unsigned int	Rev0050_12	:	4	;
		/*	0x0050	[16]	*/	unsigned int	HUS_IN_USE_HSYNC	:	1	;
		/*	0x0050	[17]	*/	unsigned int	Rev0050_17	:	15	;

		/*	0x0054	[00]	*/	unsigned int	HUS_TG_H_ACT_EN	:	1	;
		/*	0x0054	[01]	*/	unsigned int	Rev0054_01	:	7	;
		/*	0x0054	[08]	*/	unsigned int	HUS_TG_HACT_EN	:	1	;
		/*	0x0054	[09]	*/	unsigned int	Rev0054_09	:	7	;
		/*	0x0054	[16]	*/	unsigned int	HUS_TG_HSYN_EN	:	1	;
		/*	0x0054	[19]	*/	unsigned int	Rev0054_19	:	5	;
		/*	0x0054	[24]	*/	unsigned int	HUS_TG_VSYN_EN	:	1	;
		/*	0x0054	[25]	*/	unsigned int	Rev0054_25	:	7	;

		/*	0x0058	[00]	*/	unsigned int	HUS_TG_H_ACT	:	13	;
		/*	0x0058	[13]	*/	unsigned int	Rev0058_13	:	3	;
		/*	0x0058	[16]	*/	unsigned int	HUS_TG_H_DLY	:	13	;
		/*	0x0058	[29]	*/	unsigned int	Rev0058_29	:	3	;

		/*	0x005C	[00]	*/	unsigned int	HUS_TG_V_RDLY	:	13	;
		/*	0x005C	[13]	*/	unsigned int	Rev005C_13	:	3	;
		/*	0x005C	[16]	*/	unsigned int	HUS_TG_V_FDLY	:	13	;
		/*	0x005C	[29]	*/	unsigned int	Rev005C_29	:	3	;

		/*	0x0060	[00]	*/	unsigned int	HUS_UP_EN	:	1	;
		/*	0x0060	[01]	*/	unsigned int	Rev0060_01	:	15	;
		/*	0x0060	[16]	*/	unsigned int	HUS_UP_USE_HSYNC	:	1	;
		/*	0x0060	[17]	*/	unsigned int	Rev0060_17	:	15	;

		/*	0x0064	[00]	*/	unsigned int	HUS_UP_H_DTO	:	15	;
		/*	0x0064	[15]	*/	unsigned int	Rev0064_15	:	1	;
		/*	0x0064	[16]	*/	unsigned int	HUS_UP_H_DISP	:	13	;
		/*	0x0064	[29]	*/	unsigned int	Rev0064_29	:	3	;

		/*	0x0068	[00]	*/	unsigned int	HUS_METHOD_Y	:	1	;
		/*	0x0068	[01]	*/	unsigned int	HUS_METHOD_C	:	1	;
		/*	0x0068	[02]	*/	unsigned int	Rev0068_02	:	6	;
		/*	0x0068	[08]	*/	unsigned int	HUS_TABLE_SEL_Y	:	2	;
		/*	0x0068	[10]	*/	unsigned int	HUS_TABLE_SEL_C	:	2	;
		/*	0x0068	[12]	*/	unsigned int	Rev0068_12	:	20	;

		/*	0x006C	[00]	*/	unsigned int	HUS_IN_ERR_CTRL_CLEAR	:	1	;
		/*	0x006C	[01]	*/	unsigned int	Rev006C_01	:	7	;
		/*	0x006C	[08]	*/	unsigned int	HUS_FIFO_ERR_CTRL_CLEAR	:	4	;
		/*	0x006C	[12]	*/	unsigned int	Rev006C_12	:	4	;
		/*	0x006C	[16]	*/	unsigned int	HUS_UP_ERR_CTRL_CLEAR	:	1	;
		/*	0x006C	[17]	*/	unsigned int	Rev006C_17	:	15	;

		/*	0x0070	[00]	*/	unsigned int	HUS_IN_ERR_OVERFLOW	:	1	;
		/*	0x0070	[01]	*/	unsigned int	HUS_FIFO_ERR_WSKIP	:	1	;
		/*	0x0070	[02]	*/	unsigned int	HUS_FIFO_ERR_RSKIP	:	1	;
		/*	0x0070	[03]	*/	unsigned int	HUS_FIFO_ERR_OVERFLOW	:	1	;
		/*	0x0070	[04]	*/	unsigned int	HUS_FIFO_ERR_UNDERFLOW	:	1	;
		/*	0x0070	[05]	*/	unsigned int	HUS_UP_ERR_OVERFLOW	:	1	;
		/*	0x0070	[16]	*/	unsigned int	Rev0070_16	:	16	;

		/*	0x0074	[00]	*/	unsigned int	Rev0074_00	:	32	;

		/*	0x0078	[00]	*/	unsigned int	Rev0078_00	:	32	;

		/*	0x007C	[00]	*/	unsigned int	Rev007C_00	:	32	;

		/*	0x0080	[00]	*/	unsigned int	Rev0080_00	:	32	;

		/*	0x0084	[00]	*/	unsigned int	VSCD_FRAME_SKIP	:	3	;
		/*	0x0084	[03]	*/	unsigned int	Rev0084_03	:	5	;
		/*	0x0084	[08]	*/	unsigned int	VSCD_INV_VS_TOGGLE	:	1	;
		/*	0x0084	[09]	*/	unsigned int	Rev0084_09	:	7	;
		/*	0x0084	[16]	*/	unsigned int	VSCD_CD_SEL	:	2	;
		/*	0x0084	[18]	*/	unsigned int	Rev0084_18	:	14	;

		/* 0x0088[00] */ UINT32	Rev0088[(0x200-0x088)/4];
	}Reg;
}RE_PRE_REGISTER;

#endif


