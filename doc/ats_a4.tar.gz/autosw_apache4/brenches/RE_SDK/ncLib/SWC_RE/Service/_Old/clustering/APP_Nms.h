
#ifdef PC
#include "common.h"
#else
#include "../common.h"
#include "../RECG_typedef.h"
#endif


extern void ADAS_nms(BOX_INFO *in_Box , BOX_INFO *out_Box);
extern int remain_select(int *b_sel, int size);
extern void rect_overap(BOX_INFO *in_Box, int max_idx, int idx, ST_OVERLAP *overlap_ratio);
extern float max_func(float a, float b);
extern float min_func(float a, float b);

