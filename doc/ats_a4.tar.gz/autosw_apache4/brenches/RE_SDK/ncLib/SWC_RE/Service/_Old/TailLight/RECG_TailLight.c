#include "../common.h"
#include "../Tracking/RECG_NCFlow.h"
#include "../Tracking/RECG_DataAssociation.h"
#include "../A4_AdasIp.h"
#include "../Tracking/RECG_NCFlow.h"
#include <math.h>

#if 0
		Label BoxLabel;
		int candidate_pair[NUM_MAX_LABEL][30];
		float score[NUM_MAX_LABEL][30];
		unsigned char pair_cnt[NUM_MAX_LABEL] = {0, };

		unsigned char roi_Tail_cnt = 0;
		NCRectf roi_Tail[256];
#endif

void copy_one_label(Label *inLabel , Label *outLabel , int in_idx , int out_idx)
{
	outLabel->area[out_idx] = inLabel->area[in_idx];
	outLabel->top[out_idx] = inLabel->top[in_idx];
	outLabel->left[out_idx] = inLabel->left[in_idx];
	outLabel->width[out_idx] = inLabel->width[in_idx];
	outLabel->height[out_idx] = inLabel->height[in_idx];
	outLabel->label_number[out_idx] = inLabel->label_number[in_idx];
	outLabel->paring_number[out_idx] = inLabel->paring_number[in_idx];

	outLabel->centroid[out_idx].x = inLabel->centroid[in_idx].x;
	outLabel->centroid[out_idx].y = inLabel->centroid[in_idx].y;

}


void find_label_in_Box(Label *inLabel , Label *OutLabel , BOX_XYWH_DATA *Box)
{
	int i;

	int num = 0;
	NCSize s;
	NCPointf p0;
	NCPointf p1;

	NCPointf centroid;
	NCSize l_size;

	s.width = Box->Width;
	s.height = Box->Height;
	p0.x = Box->StX - s.width*0.1;
	p0.y = Box->StY - s.height*0.1;
	p1.x=Box->StX+Box->Width*1.2;
	p1.y=Box->StY+Box->Height*1.2;

	OutLabel->num_label = 0;

	for(i=0; i<inLabel->num_label; i++)
	{
		centroid.x = inLabel->centroid[i].x;
		centroid.y= inLabel->centroid[i].y;

		//JIGMSG("%d %d\n",(int)centroid.x , (int)centroid.y);


		l_size.width = inLabel->width[i];
		l_size.height =  inLabel->height[i];

		if(centroid.x >= p0.x && centroid.x<= p1.x && centroid.y>= p0.y  && centroid.y<= p1.y )
		{
			copy_one_label(inLabel,OutLabel,i,num);
			num++;
		}
	}

	OutLabel->num_label = num;
}


void Detect_TailLight_using_Box(unsigned int y_addr , Label *label , NCRectf *roi, int *ROICnt ,BOX_INFO *Box, BOX_INFO *Tail)
{
	int box,i,j,k;

	unsigned char p1[PATCH_SIZE][PATCH_SIZE],p2[PATCH_SIZE][PATCH_SIZE];

	unsigned char * gray = (unsigned char *)y_addr;

	unsigned char roi_cnt = 0;

	unsigned int osilo;

	BOX_INFO temp_Tail;

	Label BoxLabel;
	int candidate_pair[OPERATE_MAX_LABEL][10];
	int invalid_pair[OPERATE_MAX_LABEL] = {0, };

	float score[OPERATE_MAX_LABEL][10];
	unsigned char pair_cnt[OPERATE_MAX_LABEL] = {0, };

	NCRectf roi_Tail[OPERATE_MAX_LABEL];

	unsigned int roi_Tail_cnt = 0;

	NCSize BoxSize;

	unsigned char score_cnt = 0;
	int idx0[OPERATE_MAX_LABEL] , idx1[OPERATE_MAX_LABEL];
	float total_score[OPERATE_MAX_LABEL];

	float cy_dif;
	float cx_dif;
	float area_rate;
	float height_rate;
	float width_rate;
	float avg_width;

	double rgb_ncc_score = 0;
	int idx = candidate_pair[i][j];
	float ares;

	int tmp0,tmp1;
	int ftmp;

	NCSize s;

	NCSize ImageSize;

	NCPointf c1 , c2;

	int left0;
	int left1;
	int top0;
	int top1;
	int width0;
	int width1;
	int height0;
	int height1;

	int x0;
	int y0;

	int x1;
	int y1;

	int dif_width;

	NCRectf r;

	float max_overay = 0;
	int max_idx = 0;

	float overay;
	BOX_XYWH_DATA BOX;

	Tail->BoxNumMax = 0;



	temp_Tail.BoxNumMax = 0;

	//JIGMSG("\n Box : %d\n",Box->BoxNumMax);



	for(box=0; box<Box->BoxNumMax; box++)
	{

		memset(invalid_pair , 0, sizeof(int)*OPERATE_MAX_LABEL);
		memset(pair_cnt , 0 , sizeof(char)*OPERATE_MAX_LABEL);

		roi_Tail_cnt = 0;
		score_cnt = 0;

		BoxSize.width = Box->BaxXYWH[box].Width;
		BoxSize.height= Box->BaxXYWH[box].Height;

		find_label_in_Box(label, &BoxLabel, &Box->BaxXYWH[box]);	// function


		for(i=0; i<BoxLabel.num_label-1; i++)
		{
			for(j=i+1; j<BoxLabel.num_label; j++)
			{
				 cy_dif = fabs(BoxLabel.centroid[i].y - BoxLabel.centroid[j].y);
				 cx_dif = fabs(BoxLabel.centroid[i].x - BoxLabel.centroid[j].x);
				 area_rate = (float)BoxLabel.area[i] / BoxLabel.area[j];
				 height_rate = (float)BoxLabel.height[i] / BoxLabel.height[j];
				 width_rate = (float)BoxLabel.width[i] / BoxLabel.width[j];
				 avg_width = (float)(BoxLabel.width[i] + BoxLabel.width[j])/2;

				//JIGMSG("%d %d %d %d\n",i,j,(int)cy_dif,(int)cx_dif);

				if((i!=j) && cy_dif < (BoxSize.height*0.15) && (area_rate<=3 && area_rate>=0.33) && (width_rate<=3 && width_rate>=0.33) && cx_dif>avg_width  && (height_rate<=3 && height_rate>=0.33) )	//
				{
					candidate_pair[i][pair_cnt[i]] = j;
					pair_cnt[i]++;

					//JIGMSG("Pair!\n");

					if(pair_cnt[i] == 30)
						break;
				}
			}
			if(pair_cnt[i] == 30)
				break;
		}


		for(i=0; i<BoxLabel.num_label; i++)
		{
			//JIGMSG("%d %d\n",i,pair_cnt[i]);
			for(j=0; j<pair_cnt[i]; j++)
			{

				rgb_ncc_score = 0;

				s.width=PATCH_SIZE;
				s.height=PATCH_SIZE;
				ImageSize.width=640;
				ImageSize.height=360;

				c1.x = BoxLabel.centroid[i].x;
				c1.y = (BoxLabel.centroid[i].y+BoxLabel.centroid[idx].y)/2;

				c2.x= BoxLabel.centroid[idx].x;
				c2.y= (BoxLabel.centroid[i].y+BoxLabel.centroid[idx].y)/2;

				s.width=(BoxLabel.width[i] + BoxLabel.width[idx])/2;
				s.height=(BoxLabel.height[i] + BoxLabel.height[idx])/2;

				s.width = s.width> PATCH_SIZE ? PATCH_SIZE : s.width;
				s.height = s.height> PATCH_SIZE ? PATCH_SIZE : s.height;

				//JIGMSG("%d %d %d %d\n",(int)c1.x, (int)c2.x , (int)c1.y, (int)c2.y);
				ares = Cal_NCC(gray ,gray , ImageSize , s , c1, c2, CALC_NCC_FLIP);
				//float ares = 0;

				//JIGMSG("%d %d %d\n",i,candidate_pair[i][j],(int)(ares*1000));

				score[i][j] = ares;

				if(ares>0.2)
				{
					//JIGMSG("%d %d\n",box,(int)(ares*10000));

					idx0[score_cnt] = i;
					idx1[score_cnt] = idx;
					total_score[score_cnt] = ares;
					score_cnt++;
				}
			}
		}

#if 1
		if(score_cnt)
		{
			for(i=0; i<score_cnt-1; i++)
			{
				for(j=i+1; j<score_cnt; j++)
				{


					if(total_score[i]<total_score[j])
					{
						tmp0 = idx0[i];
						tmp1 = idx1[i];
						ftmp = total_score[i];

						total_score[i] = total_score[j];
						idx0[i] = idx0[j];
						idx1[i] = idx1[j];

						total_score[j] = ftmp;
						idx0[j] = tmp0;
						idx1[j] = tmp1;

					}

				}
			}
		}


		for(i=0; i<score_cnt; i++)
		{
			//printf("%d %d %f\n",idx0[i],idx1[i],total_score[i]);
			if(!invalid_pair[idx0[i]] && !invalid_pair[idx1[i]])
			{
				 left0 = BoxLabel.left[idx0[i]];
				 left1 = BoxLabel.left[idx1[i]];
				 top0 = BoxLabel.top[idx0[i]];
				 top1 = BoxLabel.top[idx1[i]];
				 width0 = BoxLabel.width[idx0[i]];
				 width1 = BoxLabel.width[idx1[i]];
				 height0 = BoxLabel.height[idx0[i]];
				 height1 = BoxLabel.height[idx1[i]];

				 x0 = left0 < left1 ? left0 : left1;
				 y0 = top0 < top1 ? top0 : top1;

				 x1 = left0+width0 > left1+width1 ? left0+width0 : left1+width1;
				 y1 = top0+height0 > top1+height1 ? top0+height0 : top1+height1;

				 dif_width = abs((x1-x0) - BoxSize.width);

				//JIGMSG("%d %d\n",(int)(BoxSize.width*0.2), dif_width);


				if(dif_width < BoxSize.width*0.3)		//&& y1-y0 > BoxSize.height*0.125
				{
					//JIGMSG("%d %d %d %d %d\n",x0 ,y0, x1, y1, dif_width);


					invalid_pair[idx0[i]] = 1;
					invalid_pair[idx1[i]] = 1;



					r.x = x0;
					r.y = y0;
					r.width = x1-x0;
					r.height = y1-y0;

					//JIGMSG("%d %d %d %d\n",(int)r.x ,(int)r.y, (int)r.width, (int)r.height);


					roi_Tail[roi_Tail_cnt] = r;

					roi_Tail_cnt = roi_Tail_cnt  +1;
				}
			}
		}


		/*if(!Tail->BoxNumMax)
		{
			if(roi_Tail_cnt)
			{
				//JIGMSG("%d %d\n",Tail->BoxNumMax, roi_Tail_cnt);
				//JIGMSG("%d %d %d %d\n",(int)roi_Tail[0].x ,(int)roi_Tail[0].y, (int)roi_Tail[0].width, (int)roi_Tail[0].height);

				roi[roi_cnt] = roi_Tail[0];
				roi_cnt = roi_cnt+1;


				temp_Tail.BaxXYWH[box].StX = roi_Tail[0].x;
				temp_Tail.BaxXYWH[box].StY = roi_Tail[0].y;
				temp_Tail.BaxXYWH[box].Width = roi_Tail[0].width;
				temp_Tail.BaxXYWH[box].Height = roi_Tail[0].height;
				temp_Tail.BaxXYWH[box].InvalidCount = 0;

			}
		}*/




#if 0
#ifdef	_DIS_G08_ON
	osilo = ab_asi_io_read(0x90d01040);
	osilo |= 1<<8;
	ab_asi_io_write(osilo, 0x90d01040); // high
#endif
#endif

		if(!Tail->BoxNumMax)
		{
			if(roi_Tail_cnt)
			{
				roi[roi_cnt] = roi_Tail[0];
				roi_cnt++;
				temp_Tail.BaxXYWH[box].StX = roi_Tail[0].x;
				temp_Tail.BaxXYWH[box].StY = roi_Tail[0].y;
				temp_Tail.BaxXYWH[box].Width = roi_Tail[0].width;
				temp_Tail.BaxXYWH[box].Height = roi_Tail[0].height;
				temp_Tail.BaxXYWH[box].InvalidCount = 0;
			}
			else
			{
				temp_Tail.BaxXYWH[box].StX = 0;
				temp_Tail.BaxXYWH[box].StY = 0;
				temp_Tail.BaxXYWH[box].Width = 0;
				temp_Tail.BaxXYWH[box].Height = 0;
				temp_Tail.BaxXYWH[box].InvalidCount = 1;
			}

		}

		else
		{
			if(!roi_Tail_cnt)
			{
				temp_Tail.BaxXYWH[box].StX = 0;
				temp_Tail.BaxXYWH[box].StY = 0;
				temp_Tail.BaxXYWH[box].Width = 0;
				temp_Tail.BaxXYWH[box].Height = 0;
				temp_Tail.BaxXYWH[box].InvalidCount = 1;
			}
			else if(roi_Tail_cnt == 1)
			{
				roi[roi_cnt] = roi_Tail[0];
				roi_cnt++;
				temp_Tail.BaxXYWH[box].StX = roi_Tail[0].x;
				temp_Tail.BaxXYWH[box].StY = roi_Tail[0].y;
				temp_Tail.BaxXYWH[box].Width = roi_Tail[0].width;
				temp_Tail.BaxXYWH[box].Height = roi_Tail[0].height;
				temp_Tail.BaxXYWH[box].InvalidCount = 0;
			}
			else if(roi_Tail_cnt > 1)
			{
				max_overay = 0;
				max_idx = 0;

				for(k=0; k<roi_Tail_cnt; k++)
				{
					BOX.StX = roi_Tail[k].x;	//04989ab,
					BOX.StY = roi_Tail[k].y;
					BOX.Width = roi_Tail[k].width;
					BOX.Height = roi_Tail[k].height;

					overay = calc_overay(&Tail->BaxXYWH[box], &BOX);

					if(overay>max_overay)
					{
						max_overay = overay;
						max_idx = k;
					}

				}

				roi[roi_cnt] = roi_Tail[max_idx];
				roi_cnt++;
				temp_Tail.BaxXYWH[box].StX = roi_Tail[max_idx].x;
				temp_Tail.BaxXYWH[box].StY = roi_Tail[max_idx].y;
				temp_Tail.BaxXYWH[box].Width = roi_Tail[max_idx].width;
				temp_Tail.BaxXYWH[box].Height = roi_Tail[max_idx].height;
				temp_Tail.BaxXYWH[box].InvalidCount = 0;

			}

		}

#if 0
#ifdef	_DIS_G08_ON
	osilo = ab_asi_io_read(0x90d01040);
	osilo &= ~(1<<8);
	ab_asi_io_write(osilo, 0x90d01040); // low
#endif
#endif



		if(roi_Tail_cnt)
		{

			Box->BaxXYWH[box].StX = temp_Tail.BaxXYWH[box].StX;
			Box->BaxXYWH[box].Width = temp_Tail.BaxXYWH[box].Width;

			//JIGMSG("%d\n",(int)Box->BaxXYWH[box].Width);

			//float rate =Box->BaxXYWH[box].Height/Box->BaxXYWH[box].Width;

			Box->BaxXYWH[box].StY -= (temp_Tail.BaxXYWH[box].Width - Box->BaxXYWH[box].Height)/2;
			Box->BaxXYWH[box].Height = (temp_Tail.BaxXYWH[box].Width);

			/*if(Box->BaxXYWH[box].TrackCount)
				Box->BaxXYWH[box].TrackCount--;

			if(Box->BaxXYWH[box].InvalidCount)
				Box->BaxXYWH[box].InvalidCount = 0;*/
		}


#endif

	}


	*ROICnt = roi_cnt;

	/*if(roi_cnt)
	{
		JIGMSG("Num ROI = %d\n",roi_cnt);
		for(i=0; i<roi_cnt; i++)
			JIGMSG("%d %d %d %d\n",(int)roi[i].x,(int)roi[i].y,(int)roi[i].width,(int)roi[i].height);
		JIGMSG("\n");
	}*/

	//for(i=0; i<)

	temp_Tail.BoxNumMax = Box->BoxNumMax;

	*Tail = temp_Tail;
}

