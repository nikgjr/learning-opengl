#include "../RECG_typedef.h"

#define DETECT_SCORE_THRESHOLD			0.5
#define MIN_SIMILARITY					0.1
#define MATCH_THRESHOLD					0.8

typedef struct{
	int nMapping;
	int nDetect;
	int nTrack;

	int mapping[MAX_TRACK];
}DA;


void data_Association(BOX_INFO *Track_Box, BOX_INFO *Det_Box);

float** similarity_calculate(DA *da);

float rectOverlapRatio(NCRectf a, NCRectf b, int type);

float similarity_calculate_Box(DA *da, BOX_INFO *a, BOX_INFO *b, int type, float **cost_matrix);

float similarity_calculate_Box_Static(DA *da, BOX_INFO *a, BOX_INFO *b, int type, float cost_matrix[][MAX_TRACK]);

void pile_box_exception(BOX_INFO *a, BOX_INFO *b);

double calc_overay(BOX_XYWH_DATA *a , BOX_XYWH_DATA *b);

double calc_min_overay(BOX_XYWH_DATA *a , BOX_XYWH_DATA*b, double *out);
