#include <math.h>
#include "../common.h"
#include "RECG_NCFlow.h"
#include "Sqrt_LUT.h"
//#include "AR_AdasIp.h"

//extern "C"
//{

#define MAX_BOX_MOD 15

void MedianFlow(unsigned char *pre, unsigned char *cur, NCSize ImageSize , MODValue *Mod,BOX_INFO *inBox, BOX_INFO *outBox, int mode)
{
	int i,j;
	NCPointf  di[MAX_BOX_MOD];
	char filter_status[MAX_BOX_MOD];
	int true_cnt = 0;
	NCRectf TrueMODRect[MAX_BOX_MOD];
	NCPointf mDisplacement;
	NCRectf newRect;
	double displacements[MAX_BOX_MOD];

	double dis;
	double displace;
	int max_dis;

	outBox->BoxNumMax = inBox->BoxNumMax;

	for( i=0; i<inBox->BoxNumMax; i++)
	{
		BOOL BoolMedianFlow = TRUE;

		MODValue ModOut, ModOut2;

		//printf("1\n");


		Find_Points_ROI(&inBox->BaxXYWH[i] , Mod , &ModOut,mode);

		for( j=0; j<ModOut.size; j++)
		{
			di[j].x = ModOut.ModVal[j].width;
			di[j].y = ModOut.ModVal[j].height;
			filter_status[j] = TRUE;
		}

		//	printf("2\n");



		Check_NCC(pre,cur,ImageSize,&ModOut,filter_status);


		//	printf("3\n");
		true_cnt = 0;
		for( j=0; j<ModOut.size; j++)
		{
			if(filter_status[j])
			{
				TrueMODRect[true_cnt] = ModOut.ModVal[j];
				true_cnt++;

				if(true_cnt == MAX_BOX_MOD)
					break;
			}

		}



		ModOut2.size = true_cnt;

		for( j=0; j<true_cnt; j++)
		{
			ModOut2.ModVal[j] = TrueMODRect[j];
		}

	//		printf("4\n");


		newRect = Vote_MOD(&inBox->BaxXYWH[i], &ModOut2, &mDisplacement);


		//	printf("5\n");

		for( j=0; j<ModOut.size; j++)
		{
			di[j].x -= mDisplacement.x;
			di[j].y -= mDisplacement.y;

			displacements[j] = sqrt(di[j].x * di[j].x + di[j].y*di[j].y);	// sqrt
		}
		dis = GetMedian(displacements,ModOut.size);


		//	printf("6\n");


		if(mode == RUN_VD)
		{
			displace = HK_DISPLACE_VD * newRect.width / 48.0;
			max_dis = HK_DISPLACE_VD;
		}
		else if(mode == RUN_PD)
		{
			displace = HK_DISPLACE_PD * newRect.width / 30.0;
			max_dis = HK_DISPLACE_PD;
		}



		if(mode == RUN_VD)
			displace = displace < 1 ? 1 : (displace > max_dis ? max_dis : displace);

		else if(mode == RUN_PD)
			displace = displace < 1 ? 1 : (displace > max_dis ? max_dis : displace);

		//


		if(dis > displace)
			BoolMedianFlow = FALSE;

		if(BoolMedianFlow)
		{
			outBox->BaxXYWH[i] = inBox->BaxXYWH[i];
			outBox->BaxXYWH[i].StX = newRect.x;
			outBox->BaxXYWH[i].StY = newRect.y;
			outBox->BaxXYWH[i].Width = newRect.width;
			outBox->BaxXYWH[i].Height = newRect.height;
			outBox->BaxXYWH[i].TrueTracking = TRUE;
		}
		else
		{
			outBox->BaxXYWH[i] = inBox->BaxXYWH[i];
			outBox->BaxXYWH[i].StX = newRect.x;
			outBox->BaxXYWH[i].StY = newRect.y;
			outBox->BaxXYWH[i].Width = newRect.width;
			outBox->BaxXYWH[i].Height = newRect.height;
			outBox->BaxXYWH[i].TrueTracking = FALSE;
		}
		
		//outBox->BoxNumMax = inBox->BoxNumMax;

		//if(mode == RUN_VD && ModOut.size < 5)
			//outBox->BaxXYWH[i].TrueTracking = 2;


		//	printf("7\n");

		//free(ModOut.ModVal);
		//free(ModOut2.ModVal);
		//delete [] filter_status;


		//delete [] ModOut.ModVal;
	}



/*
	*v0 << tmp;

	imshow("Feature",tmp);*/

}

void NCC_MedianFlow(NCSize ImageSize , MODValue *Mod,BOX_INFO *inBox, BOX_INFO *outBox, int mode)
{

	int i,j;
	NCPointf  di[MAX_BOX_MOD];
	NCRectf TrueMODRect[MAX_BOX_MOD];

	NCPointf mDisplacement;
	NCRectf newRect;

	char filter_status[MAX_BOX_MOD];
	int true_cnt;

	double displacements[MAX_BOX_MOD];
	double dis;

	double displace;
	int max_dis;

	outBox->BoxNumMax = inBox->BoxNumMax;


	for( i=0; i<inBox->BoxNumMax; i++)
	{
		BOOL BoolMedianFlow = TRUE;

		MODValue ModOut, ModOut2;

		//printf("1\n");


		Find_Points_ROI(&inBox->BaxXYWH[i] , Mod , &ModOut,mode);

		//JIGMSG("%d\n",ModOut.size);

		for( j=0; j<ModOut.size; j++)
		{
			di[j].x = ModOut.ModVal[j].width;
			di[j].y = ModOut.ModVal[j].height;

			//JIGMSG("%d %d\n",(int)(di[j].x*1000) , (int)(di[j].y*1000));

			filter_status[j] = TRUE;
		}


		Check_NCC2(ImageSize,&ModOut,filter_status);

		true_cnt = 0;

		for( j=0; j<ModOut.size; j++)
		{
			if(filter_status[j])
			{
				TrueMODRect[true_cnt] = ModOut.ModVal[j];
				true_cnt++;

				if(true_cnt == MAX_BOX_MOD)
					break;
			}

		}



		ModOut2.size = true_cnt;

		for( j=0; j<true_cnt; j++)
		{
			ModOut2.ModVal[j] = TrueMODRect[j];
		}

	//		printf("4\n");

		newRect = Vote_MOD(&inBox->BaxXYWH[i], &ModOut2, &mDisplacement);


		//	printf("5\n");



		for( j=0; j<ModOut.size; j++)
		{
			//JIGMSG("%d - ",(int)(di[j].y*1000));

			di[j].x -= mDisplacement.x;
			di[j].y -= mDisplacement.y;

			displacements[j] = (di[j].x * di[j].x + di[j].y*di[j].y);	// sqrt

			//displacements[j] = di[j].x * di[j].x + di[j].y*di[j].y;	// no sqrt

			//JIGMSG("%d^2 + %d^2 = %d\n",(int)(di[j].x*1000) ,(int)(di[j].y*1000),(int)(displacements[j]*1000) );
		}
		//JIGMSG("\n");

		dis = GetMedian(displacements,ModOut.size);
		//JIGMSG("%d %d\n",ModOut.size, (int)(dis*1000));



		if(mode == RUN_VD)
		{
			displace = HK_DISPLACE_VD * newRect.width / 48.0;
			max_dis = HK_DISPLACE_VD;
		}
		else if(mode == RUN_PD)
		{
			displace = HK_DISPLACE_PD * newRect.width / 30.0;
			max_dis = HK_DISPLACE_PD;
		}



		if(mode == RUN_VD)
			displace = displace < 9 ? 9 : (displace > max_dis ? max_dis : displace);

		else if(mode == RUN_PD)
			displace = displace < 9 ? 9 : (displace > max_dis ? max_dis : displace);

		//JIGMSG("%d %f %f\n",i,dis displace);

		//JIGMSG("%d %d %d\n",i,(int)(dis*1000), (int)(displace*1000));


		if(dis > displace)
		{
			BoolMedianFlow = FALSE;
			//JIGMSG("%d ",BoolMedianFlow);
		}

		outBox->BaxXYWH[i] = inBox->BaxXYWH[i];

		if(BoolMedianFlow)
		{
			outBox->BaxXYWH[i].StX = newRect.x;
			outBox->BaxXYWH[i].StY = newRect.y;
			outBox->BaxXYWH[i].Width = newRect.width;
			outBox->BaxXYWH[i].Height = newRect.height;
			outBox->BaxXYWH[i].TrueTracking = TRUE;
		}
		else
		{
			outBox->BaxXYWH[i].StX = newRect.x;
			outBox->BaxXYWH[i].StY = newRect.y;
			outBox->BaxXYWH[i].Width = newRect.width;
			outBox->BaxXYWH[i].Height = newRect.height;
			outBox->BaxXYWH[i].TrueTracking = TRUE;
			outBox->BaxXYWH[i].TrueTracking = FALSE;
		}

	}

	//JIGMSG("\n");
}

NCRectf Vote_MOD(BOX_XYWH_DATA *inBox, MODValue *modBox, NCPointf *md)
{

	NCRectf newRect;
	NCPointf newCenter;

	int n = modBox->size;
	int b_size = n*(n-1)/2;
	double buf[(MAX_BOX_MOD*MAX_BOX_MOD-1)/2];
	int i,j,k,ctr;

	double xshift=0,yshift=0;
	double nd,od;

	double max_od = 0, max_nd = 0;
	double scale;

	newCenter.x = inBox->StX + inBox->Width/2;
	newCenter.y = inBox->StY + inBox->Height/2;



	i=0; j=0; k=0; ctr=0;

	if(n>MAX_BOX_MOD)
		n = MAX_BOX_MOD;

	if(!n)
	{
		md->x = 0;
		md->y = 0;

		newRect.x = inBox->StX;
		newRect.y = inBox->StY;
		newRect.width = inBox->Width;
		newRect.height = inBox->Height;
		return newRect;

	}
	else if(n == 1)
	{
		md->x = modBox->ModVal[0].width;
		md->y = modBox->ModVal[0].height;

		newRect.x = inBox->StX + modBox->ModVal[0].width;
		newRect.y = inBox->StY + modBox->ModVal[0].height;
		newRect.width = inBox->Width;
		newRect.height = inBox->Height;
		return newRect;
	}
	else
	{
		//printf("1\n");


		xshift=0,yshift=0;
		for( j=0;j<n;j++)
		{ 
			buf[j]=modBox->ModVal[j].width; 
		}


		//xshift=HK_GetWeightMedian(buf,n,inBox->Width);
		xshift=GetMedian(buf,n);
		newCenter.x+=xshift;

		for( j=0;j<n;j++)
		{  
			buf[j]=modBox->ModVal[j].height; 
			//JIGMSG("%d\n" , (int)(buf[j]));
		}


		//yshift=HK_GetWeightMedian(buf,n,inBox->Width);
		yshift=GetMedian(buf,n);

		//JIGMSG("%d\n", (int)yshift);

		newCenter.y+=yshift;

		md->x = xshift;
		md->y = yshift;

		max_od = 0, max_nd = 0;

#if 1
		for( j=0,ctr=0;j<n;j++)
		{
			for( k=0;k<j;k++)
			{

				NCPointf P[4];
				double dx, dy;

				P[0].x = modBox->ModVal[j].x + modBox->ModVal[j].width;
				P[0].y = modBox->ModVal[j].y + modBox->ModVal[j].height;

				P[1].x = modBox->ModVal[k].x + modBox->ModVal[k].width;
				P[1].y = modBox->ModVal[k].y + modBox->ModVal[k].height;

				P[2].x = modBox->ModVal[j].x;
				P[2].y = modBox->ModVal[j].y;

				P[3].x = modBox->ModVal[k].x;
				P[3].y = modBox->ModVal[k].y;


				dx = (int)(P[0].x-P[1].x);
				dy = (int)(P[0].y-P[1].y);

				nd = (dx*dx + dy*dy);

				dx = (int)(P[2].x-P[3].x);
				dy = (int)(P[2].y-P[3].y);

				od = (dx*dx + dy*dy);

				if(nd>1 && od>1)
				{
					nd = NC_sqrt(nd);
					od = NC_sqrt(od);

					buf[ctr]=(od==0.0 )? 1.0:(nd/od);
				}
				else
					buf[ctr] = 1.0;



				ctr++;

				// cause 1.sqrt , 2.divde

				/*nd=L2Distance(P[0] , P[1]);
								od=L2Distance(P[2] , P[3]);*/
			}
		}

#endif
		scale = GetMedian(buf,b_size);

		//JIGMSG("%f\n",scale);

		//printf("5\n");

		if(scale>0)
		{
			newRect.x=newCenter.x-(scale*inBox->Width/2.0);
			newRect.y=newCenter.y-(scale*inBox->Height/2.0);
			newRect.width=scale*inBox->Width;
			newRect.height=scale*inBox->Height;
		}
		else
		{

			newRect.x=newCenter.x - inBox->Width/2.0;
			newRect.y=newCenter.y - inBox->Height/2.0;
			newRect.width=inBox->Width;
			newRect.height=inBox->Height;
		}

		//printf("%f %f %f\n",md->x, md->y,scale);
		//printf("%f %f %f %f\n",newRect.x, newRect.y, newRect.width, newRect.height);



		return newRect;
	}
}

double L2Distance(NCPointf p1, NCPointf p2)
{
	double dx=p1.x-p2.x, dy=p1.y-p2.y;
	return sqrt(dx*dx+dy*dy);	//sqrt
}

void Find_Points_ROI(BOX_XYWH_DATA *ROI, MODValue *MOD, MODValue *outMOD, int mode)
{

	int x0 ,y0 , x1, y1; 
	int x2, y2 , x3, y3;

	int i,j;

	float NCC_Value[MAX_BOX_MOD];
	NCRectf Rectf[MAX_BOX_MOD];

	float weight = 0.2;
	int cnt = 0;


	if(mode == RUN_VD)
	{
		x0 = ROI->StX;
		y0 = ROI->StY;
		x1 = x0 + ROI->Width;
		y1 = y0 + ROI->Height;

		x2 = 0;
		y2 = 0;
		x3 = 0;
		y3 = 0; 

		/*x0 = ROI->StX + ROI->Width*(weight);
		y0 = ROI->StY + ROI->Height*weight;
		x1 = ROI->StX + ROI->Width - ROI->Width*weight;
		y1 = ROI->StY + ROI->Height - ROI->Height*weight;*/
	}
	else if(mode == RUN_PD)
	{

		x0 = ROI->StX + ROI->Width*(weight/2);
		y0 = ROI->StY + ROI->Height*weight;
		x1 = ROI->StX + ROI->Width - ROI->Width*weight;
		y1 = ROI->StY + ROI->Height - ROI->Height*0.4;

		x2 = ROI->StX + ROI->Width*0.3;
		y2 = ROI->StY + ROI->Height*0.1;
		x3 = ROI->StX + ROI->Width*0.7;
		y3 = ROI->StY + ROI->Height*0.2;

		/*
		x0 = ROI->StX;
				y0 = ROI->StY;
				x1 = x0 + ROI->Width;
				y1 = y0 + ROI->Height;

				x2 = 0;
				y2 = 0;
				x3 = 0;
				y3 = 0;
		 */
	}


	for( i=0; i<MOD->size; i++)
	{
		int x = MOD->ModVal[i].x;
		int y = MOD->ModVal[i].y;

		if(x >= x0 && x <= x1 && y >= y0 && y <= y1)
		{
			Rectf[cnt].x =  x;
			Rectf[cnt].y =  y;
			Rectf[cnt].width =  MOD->ModVal[i].width;
			Rectf[cnt].height =  MOD->ModVal[i].height;
			//NCC_Value[cnt] = MOD->ModNcc[i];
			cnt++;
			
			if(cnt == MAX_BOX_MOD)
				break;
		}
		else if(x >= x2 && x <= x3 && y >= y2 && y <= y3)
		{
			Rectf[cnt].x =  x;
			Rectf[cnt].y =  y;
			Rectf[cnt].width =  MOD->ModVal[i].width;
			Rectf[cnt].height =  MOD->ModVal[i].height;
			//NCC_Value[cnt] = MOD->ModNcc[i];
			cnt++;

			if(cnt == MAX_BOX_MOD)
				break;
		}
	}

	outMOD->size = cnt;

	//outMOD->ModVal = (NCRectf*) malloc(sizeof(NCRectf)*cnt);

	for( i=0; i<cnt; i++)
	{
		outMOD->ModVal[i] = Rectf[i];
		outMOD->ModNcc[i] = NCC_Value[i];
	}

}




void Check_NCC(unsigned char *pre , unsigned char *cur, NCSize ImageSize, MODValue *ModVal, char *status)
{
	//int NCC[MAX_BOX_MOD];
	double NomalCC[MAX_BOX_MOD];

	NCSize patch_size;// = NCSize(PATCH_SIZE,PATCH_SIZE64);

	unsigned char p1[PATCH_SIZE][PATCH_SIZE];
	unsigned char p2[PATCH_SIZE][PATCH_SIZE];

	int i,j;

	patch_size.width = PATCH_SIZE;
	patch_size.height = PATCH_SIZE;




	for( i=0; i<ModVal->size; i++)
	{
/*
		NCPointf op;
		op.x=ModVal->ModVal[i].x;
		op.y=ModVal->ModVal[i].y;
		NCPointf np;
		np.x = op.x + ModVal->ModVal[i].width;
		np.y = op.y + ModVal->ModVal[i].height;


		//printf("2-1\n");
		Read_Patch_Image_Static(pre,ImageSize,patch_size,op,p1);
		//printf("2-2\n");
		Read_Patch_Image_Static(cur,ImageSize,patch_size,np,p2);
		//printf("2-3\n");


		const int N = 49;

		double s1 = _2Array_Sum_Static(p1,patch_size);
		double s2 = _2Array_Sum_Static(p2,patch_size);

		double n1=0 , n2=0;


		/// L2-Norm
		n1 = _2Array_DotMatrix_Static(p1,p1,patch_size);
		n2 = _2Array_DotMatrix_Static(p2,p2,patch_size);
		n1 = sqrt(n1);
		n2 = sqrt(n2);
d
		/// p1 dot p2
		double prod = 0;
		prod = _2Array_DotMatrix_Static(p1,p2,patch_size);

		double sq1=sqrt(n1*n1-s1*s1/N);
		double sq2=sqrt(n2*n2-s2*s2/N);
		double ares=(sq2==0) ? sq1/abs(sq1) : (prod-s1*s2/N)/sq1/sq2;

		NomalCC[i] = ares;
*/

		NomalCC[i] = ModVal->ModNcc[i];
/*
		if(i<3)
			printf("%f %f\n",ModVal->ModNcc[i] , ares);*/
	}


//	double median = GetMedian(&NomalCC[0] , ModVal->size);


	for( i = 0; i < ModVal->size; i++)
	{
//		status[i] = status[i] && (NomalCC[i]>median);
		status[i] = status[i] && (NomalCC[i]>0.9);

		//printf("%lf > %lf = %d\n",NCC[i],median,status[i]);
		//getch();
	}


}

void Check_NCC2(NCSize ImageSize, MODValue *ModVal, char *status)
{

	int i;

	for( i = 0; i < ModVal->size; i++)
	{
		status[i] = status[i] && (ModVal->ModNcc[i]>0.9);
	}
}


float Cal_NCC(unsigned char *img0 , unsigned char *img1, NCSize ImageSize , NCSize PatchSize , NCPointf p0, NCPointf p1 , int mode)
{
	int i,j;
	int PN = PatchSize.width * PatchSize.height;

	unsigned char pat0[PATCH_SIZE][PATCH_SIZE];
	unsigned char pat1[PATCH_SIZE][PATCH_SIZE];

	double s1;
	double s2;

	double n1 , n2;
	//unsigned char pp2[2][2] = { {10 , 20} , {25 , 15} };

	double prod = 0;
	double sq1;
	double sq2;

	double ares;

	Read_Patch_Image_Static(img0,ImageSize,PatchSize,p0,pat0);

	if(mode == CALC_NCC_BASIC)
		Read_Patch_Image_Static(img1,ImageSize,PatchSize,p1,pat1);
	else if(mode == CALC_NCC_FLIP)
		Read_FLIP_Patch_Image_Static(img1,ImageSize,PatchSize,p1,pat1);



	/*for(i=0; i<5; i++)
	{
		JIGMSG("%03d ",pat0[0][i]);
	}
	JIGMSG("\n");

	for(i=0; i<5; i++)
		{
			JIGMSG("%03d ",pat1[0][i]);
		}
	JIGMSG("\n");*/



	s1 = _2Array_Sum_Static(pat0,PatchSize);
	s2 = _2Array_Sum_Static(pat1,PatchSize);





	/// L2-Norm
	n1 = _2Array_DotMatrix_Static(pat0,pat0,PatchSize);
	n2 = _2Array_DotMatrix_Static(pat1,pat1,PatchSize);

	n1 = NC_sqrt(n1);
	n2 = NC_sqrt(n2);

	prod = 0;
	prod = _2Array_DotMatrix_Static(pat0,pat1,PatchSize);

	//JIGMSG("sq1 = %d\n" , (int)((n1*n1-s1*s1/PN)) );
	sq1=NC_sqrt(n1*n1-s1*s1/PN);
	//JIGMSG("sq2 = %d\n" , (int)((n2*n2-s2*s2/PN)) );
	sq2=NC_sqrt(n2*n2-s2*s2/PN);

	//JIGMSG("Cal End\n");

#if 1

	if(sq1 == 0)
		return 0;

	ares=(sq2==0) ? sq1/abs(sq1) : (prod-s1*s2/PN)/sq1/sq2;

	//JIGMSG("%d\n\n",(int)(ares*1000));

	return ares;

#endif

	//return 0;

}

double GetMedian(double *values, int size)
{
	double val[(MAX_BOX_MOD*MAX_BOX_MOD-1)/2];
	int i;

	if(!size)
		return 0;

	for( i=0; i<size; i++)
		val[i] = values[i];

	NCSort(&values[0], val, size);

	if(size%2==0 && size>1)
	{
		return (val[size/2-1]+val[size/2])/(2.0);
	}
	else
	{
		return val[(size-1)/2];
	}


}

double GetWeightMedian(double *values,int size, int width)
{

	double val[MAX_BOX_MOD];
	int i;
	float stand_width;
	float width_weight;

	if(!size)
		return 0;



	for( i=0; i<size; i++)
		val[i] = values[i];

	NCSort(values, val, size);

	stand_width = STAND_WIDTH;
	width_weight = (float) width / stand_width < 2 ? 2 : (width / stand_width > 3 ? 3: width / stand_width);


	if(size%2==0){
		return (val[(int)(size/width_weight) -1 ]+val[ (int)(size/width_weight) ])/(2.0);
	}else{
		return val[((int)(size/width_weight)-1)];
	}

}

void NCSort(double *inval, double *outval, int size)
{
	int i,j;

	for( i=0; i<size; i++)
		outval[i] = inval[i];

	for( i=0; i<size-1; i++)
	{
		for( j=i; j<size; j++)
		{
			if(outval[i] < outval[j])
			{
				double temp = outval[i];
				outval[i] = outval[j];
				outval[j] = temp;
			}
		}
	}
	/*for( i=1; i<size; i++)
	{
		double temp = inval[i];
		for( j=i; j>0; j--)
		{
			if(inval[j-1]<temp)
			{
				outval[j] = outval[j-1];
				if(j==1)
				{
					outval[j-1] = temp;
					break;
				}
			}
			else
			{
				outval[j] = temp;
				break;
			}
		}
	}*/
}

BOOL Read_Patch_Image(unsigned char *img, NCSize ImageSize , NCSize size, NCPointf p ,unsigned char **out)
{
	BOOL status = 1;

	const int width = ImageSize.width;
	const int height = ImageSize.height;

	float a11, a12, a21, a22, b1, b2;
	float a,b;

	int i,j;

	NCPointf Center;
	NCPoint ip;

	Center.x = p.x - (size.width-1)*0.5;
	Center.y = p.y - (size.height-1)*0.5;


	ip.x = (int)Center.x;
	ip.y = (int)Center.y;

	a = Center.x - ip.x;
	b = Center.y - ip.y;

	a11 = (1-a)*(1-b);
	a12 = (a*(1-b));
	a21 = (b*(1-a));
	a22 = a*b;

	b1 = 1-b;
	b2 = b;

	/*if( 0 <= ip.x && ip.x < ImageSize.width - size.width && 0 <= ip.y && ip.y < ImageSize.height - size.height)
	{
		for(i=0; i<size.height; i++)
		{
			for(j=0; j<size.width-2; j+=2)
			{
				int idx = i*width + j;
				
				float s0 = img[idx]*a11 + img[idx+1]*a12 + img[idx+width]*a21 + img[idx+width+1]*a22;
				float s1 = img[idx+1]*a11 + img[idx+1+1]*a12 + img[idx+width+1]*a21 + img[idx+width+1+1]*a22;
				out[i][j] = s0+0.5;
				out[i][j+1] = s1+0.5;

			}
			for( ; j < size.width; j++ )
			{
				int idx = i*width + j;

				float s0 = img[j]*a11 + img[j+1]*a12 + img[j+width]*a21 + img[j+width+1]*a22;
				out[i][j] = s0+0.5;
			}
		}
	}
	else
	{
		return FALSE;
	}*/

	for( i = 0; i < size.height; i++)
	{
		for( j = 0; j < size.width; j ++ )
		{
			int x , y;

			x = ip.x + j;
			y = ip.y + i;

			if(x < 0)
			{
				x = 0;
				y = y<0 ? 0 : (y>=width ? width-1 : y);

				out[i][j] = img[y*width + x];
			}
			else if(x >= width)
			{
				x = width-1;
				y = y<0 ? 0 : (y>=width ? width-1 : y);

				out[i][j] = img[y*width + x];
			}
			else if(y < 0)
			{
				y = 0;

				out[i][j] = img[y*width + x];
			}
			else if(y >= height)
			{
				y = height-1;
				out[i][j] = img[y*width + x];
			}
			else
			{

				int idx = (y) * ImageSize.width + x;

				double s0 = img[idx]*a11 + img[idx+1]*a12 + img[idx+width]*a21 + img[idx+width+1]*a22;

				out[i][j] = s0+0.5;
			}
		}

	}

	/*for( i=-px; i<=size.height/2; i++)
	{
		for( j=-py; j<=size.width/2; j++)
		{

			int x;
			int y;
			if(p.x+j < 0)
			{
				x = 0;
				y = p.y + i;
				y = y<0 ? 0 : (y>=width ? width-1 : y);

				out[i+px][j+py] = img[y*width + x];
			}
			else if(p.x+j >= width)
			{
				x = width-1;
				y = p.y + i;
				y = y<0 ? 0 : (y>=width ? width-1 : y);

				out[i+px][j+py] = img[y*width + x];
			}
			else if(p.y+i < 0)
			{
				x = p.x + j;
				y = 0;

				out[i+px][j+py] = img[y*width + x];
			}
			else if(p.y+i >= height)
			{
				x = p.x + j;
				y = height-1;

				out[i+px][j+py] = img[y*width + x];
			}
			else
			{
				x = p.x + j;
				y = p.y + i;

				float val = img[y*width + x]*a11 + img[y*width + x+1]*a12 + img[(y+1)*width + x]*a21 + img[(y+1)*width + (x+1)]*a22;

				out[i+px][j+py] = val;
			}
			
		}*/


	// �̹��� ��ȯ ���� //
/*
	Mat im = Mat::zeros(30,30,CV_8UC1);

	for( i=0; i<30; i++)
	for( j=0; j<30; j++)
	im.at<uchar>(i,j) = out[i][j];

	imshow("2",im);
	waitKey(0);*/


	return status;
}

BOOL Read_Patch_Image_Static(unsigned char *img, NCSize ImageSize , NCSize size, NCPointf p ,unsigned char out[][PATCH_SIZE])
{
	BOOL status = 1;

	const int width = ImageSize.width;
	const int height = ImageSize.height;

	float a11, a12, a21, a22, b1, b2;
	float a,b;

	int i,j;

	NCPointf Center;

	int istart = PATCH_SIZE/2 - size.height/2;
	int jstart = PATCH_SIZE/2 - size.width/2;


	Center.x = p.x - (size.width-1)*0.5;
	Center.y = p.y - (size.height-1)*0.5;
	//NCPoint ip;



	/*if( 0 <= ip.x && ip.x < ImageSize.width - size.width && 0 <= ip.y && ip.y < ImageSize.height - size.height)
	{
		for(i=0; i<size.height; i++)
		{
			for(j=0; j<size.width-2; j+=2)
			{
				int idx = i*width + j;
				
				float s0 = img[idx]*a11 + img[idx+1]*a12 + img[idx+width]*a21 + img[idx+width+1]*a22;
				float s1 = img[idx+1]*a11 + img[idx+1+1]*a12 + img[idx+width+1]*a21 + img[idx+width+1+1]*a22;
				out[i][j] = s0+0.5;
				out[i][j+1] = s1+0.5;

			}
			for( ; j < size.width; j++ )
			{
				int idx = i*width + j;

				float s0 = img[j]*a11 + img[j+1]*a12 + img[j+width]*a21 + img[j+width+1]*a22;
				out[i][j] = s0+0.5;
			}
		}
	}
	else
	{
		return FALSE;
	}*/

	for( i = istart; i < size.height; i++)
	{
		for( j = jstart; j < size.width; j ++ )
		{
			int x , y;

			x = Center.x + j;
			y = Center.y + i;

			//printf("1\n");

			if(x < 0)
			{
				//printf("2-1\n");

				x = 0;
				y = y<0 ? 0 : (y>=height ? height-1 : y);

				out[i][j] = img[y*width + x];
			}
			else if(x >= width)
			{
				//printf("2-2\n");

				x = width-1;
				y = y<0 ? 0 : (y>=width ? width-1 : y);

				out[i][j] = img[y*width + x];
			}
			else if(y < 0)
			{
				//printf("2-3\n");
				y = 0;

				out[i][j] = img[y*width + x];
			}
			else if(y >= height)
			{
				//printf("2-4\n");
				y = height-1;
				out[i][j] = img[y*width + x];
			}
			else
			{
				//printf("2-5\n");
				int idx = (y) * ImageSize.width + x;

				//double s0 = img[idx]*a11 + img[idx+1]*a12 + img[idx+width]*a21 + img[idx+width+1]*a22;



				out[i][j] = img[y*width + x];
			}
		}
		//printf("3-1\n");
	}

	return status;
}

BOOL Read_FLIP_Patch_Image_Static(unsigned char *img, NCSize ImageSize , NCSize size, NCPointf p ,unsigned char out[][PATCH_SIZE])
{
	BOOL status = 1;

	const int width = ImageSize.width;
	const int height = ImageSize.height;

	float a11, a12, a21, a22, b1, b2;
	float a,b;

	int i,j;

	NCPointf Center;
	NCPoint ip;

	int istart = PATCH_SIZE/2 - size.height/2;
	int jstart = PATCH_SIZE/2 - size.width/2;

	Center.x = p.x - (size.width-1)*0.5;
	Center.y = p.y - (size.height-1)*0.5;


	ip.x = (int)Center.x;
	ip.y = (int)Center.y;

	a = Center.x - ip.x;
	b = Center.y - ip.y;

	a11 = (1-a)*(1-b);
	a12 = (a*(1-b));
	a21 = (b*(1-a));
	a22 = a*b;

	b1 = 1-b;
	b2 = b;



	/*if( 0 <= ip.x && ip.x < ImageSize.width - size.width && 0 <= ip.y && ip.y < ImageSize.height - size.height)
	{
		for(i=0; i<size.height; i++)
		{
			for(j=0; j<size.width-2; j+=2)
			{
				int idx = i*width + j;

				float s0 = img[idx]*a11 + img[idx+1]*a12 + img[idx+width]*a21 + img[idx+width+1]*a22;
				float s1 = img[idx+1]*a11 + img[idx+1+1]*a12 + img[idx+width+1]*a21 + img[idx+width+1+1]*a22;
				out[i][j] = s0+0.5;
				out[i][j+1] = s1+0.5;

			}
			for( ; j < size.width; j++ )
			{
				int idx = i*width + j;

				float s0 = img[j]*a11 + img[j+1]*a12 + img[j+width]*a21 + img[j+width+1]*a22;
				out[i][j] = s0+0.5;
			}
		}
	}
	else
	{
		return FALSE;
	}*/

	for( i = istart; i < size.height; i++)
	{
		for( j = jstart; j < size.width; j ++ )
		{
			int x , y;

			x = ip.x + (size.width-1) - j;
			y = ip.y + i;

			//printf("1\n");

			if(x < 0)
			{
				//printf("2-1\n");

				x = 0;
				y = y<0 ? 0 : (y>=height ? height-1 : y);

				out[i][j] = img[y*width + x];
			}
			else if(x >= width)
			{
				//printf("2-2\n");

				x = width-1;
				y = y<0 ? 0 : (y>=width ? width-1 : y);

				out[i][j] = img[y*width + x];
			}
			else if(y < 0)
			{
				//printf("2-3\n");
				y = 0;

				out[i][j] = img[y*width + x];
			}
			else if(y >= height)
			{
				//printf("2-4\n");
				y = height-1;
				out[i][j] = img[y*width + x];
			}
			else
			{
				//printf("2-5\n");
				int idx = (y) * ImageSize.width + x;

				//double s0 = img[idx]*a11 + img[idx+1]*a12 + img[idx+width]*a21 + img[idx+width+1]*a22;

				out[i][j] = img[y*width + x];
			}
		}
		//printf("3-1\n");
	}

	return status;
}


double _2Array_Sum(unsigned char **img, NCSize ImageSize)
{
	const int width = ImageSize.width;
	const int height = ImageSize.height;

	int sum = 0;

	int i,j;

	for( i=0; i<height; i++)
		for( j=0; j<width; j++)
			sum += img[i][j];


	return sum;
	
}

double _2Array_DotMatrix(unsigned char **p1, unsigned char **p2, NCSize size)
{
	double sum = 0;

	int i,j;

	for( i=0; i<size.height; i++)
	{
		for( j=0; j<size.width; j++)
		{
			sum += p1[i][j] * p2[i][j];
		}
	}

	return sum;
}


double _2Array_Sum_Static(unsigned char img[][PATCH_SIZE], NCSize ImageSize)
{
	const int width = ImageSize.width;
	const int height = ImageSize.height;

	int sum = 0;

	int i,j;

	int istart = PATCH_SIZE/2 - ImageSize.height/2;
	int jstart = PATCH_SIZE/2 - ImageSize.width/2;

	for( i=istart; i<height; i++)
		for( j=jstart; j<width; j++)
			sum += img[i][j];


	return sum;

}

double _2Array_DotMatrix_Static(unsigned char p1[][PATCH_SIZE], unsigned char p2[][PATCH_SIZE] , NCSize size)
{
	double sum = 0;

	int i,j;

	int istart = PATCH_SIZE/2 - size.height/2;
	int jstart = PATCH_SIZE/2 - size.width/2;

	for( i=istart; i<size.height; i++)
	{
		for( j=jstart; j<size.width; j++)
		{
			sum += p1[i][j] * p2[i][j];
			//JIGMSG("%d %d %d\n",p1[i][j] , p2[i][j], (int)sum);
		}
		//JIGMSG("\n");
	}
	//JIGMSG("\n");

	return sum;
}

double _2Array_DotMatrix_Static_1(unsigned char p1[][PATCH_SIZE], unsigned char p2[][PATCH_SIZE] , NCSize size)
{
	double sum = 0;

	int i,j;

	for( i=0; i<size.height; i++)
	{
		for( j=0; j<size.width; j++)
		{
			sum += p1[i][j] * p2[i][j];
			//JIGMSG("%d ",(int)sum);
		}
		//JIGMSG("\n");
	}
	//JIGMSG("\n");

	return 1304682;
}

double _2Array_DotMatrix_Static_2(unsigned char p1[][PATCH_SIZE], unsigned char p2[][PATCH_SIZE] , NCSize size)
{
	double sum = 0;

	int i,j;

	for( i=0; i<size.height; i++)
	{
		for( j=0; j<size.width; j++)
		{
			sum += p1[i][j] * p2[i][j];
			//JIGMSG("%d ",(int)sum);
		}
		//JIGMSG("\n");
	}
	//JIGMSG("\n");

	return 974030;
}

double NC_sqrt(double val)
{
	int i;
	int idx , idx2, cnt = 0;
	float step = 10.0;

	double ret ,ret2;
	double alpha;

	while(1)
	{
		int temp;

		temp = val/step;
		if( temp < 1)
		{
			idx2 = (int)(val*100/step)%10;
			break;
		}

		idx = temp;
		step *= 10.0;
		cnt++;
	}

	if(!idx && !idx2)
	{
		ret = SQRT_LUT[idx];
	}
	else
	{
		ret2 = idx*step/10 + idx2*step/100;

		alpha = (val - ret2)*100 / step;

		idx = 90*cnt + (idx-1)*10 + idx2;


		ret = SQRT_LUT[idx]*(1-alpha) + SQRT_LUT[idx+1]*alpha;
	}


	//ret = SQRT_LUT[idx];
	//ret2 = SQRT_LUT[idx+1];

	//JIGMSG("%d %d %d\n",(int)SQRT_LUT[idx] , (int)SQRT_LUT[idx+1], (int)ret);

	//JIGMSG("%d %d %d %d\n",(int)val , (int)ret2, (int)alpha , (int)step);

	//JIGMSG("%d %d %d %d\n",(int)val , idx ,idx2 , cnt);



	return ret;
}
