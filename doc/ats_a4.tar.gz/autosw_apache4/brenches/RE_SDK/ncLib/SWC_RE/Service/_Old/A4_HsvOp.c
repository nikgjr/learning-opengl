/*#---------------------------------------------------------------------
#
# Copyright Processor Group, 2006-2016, All rights reserved.
# Processor Group, System-on-Chip Research Department
# Electronics and Telecommunications Research Institute (ETRI)
#
# THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE
# WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS
# TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE
# REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL
# SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE,
# IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE
# COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
#
#
#------------------------------------------------------------------------*/
#include "common.h"
#include "A4_HsvOp.h"
#include "A4_AdasIp.h"
#include "RECG_typedef.h"


Label	HsvOpResult0[2];
Label	HsvOpResult1[2];
unsigned int	HsvOpResultCnt0[2] = {0,0};
unsigned int	HsvOpResultCnt1[2] = {0,0};
unsigned int	HsvOpIntOn = 0;
/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
******************************************************************************** 
*/

//--------------------------------------------------------------------------------------------------------------
void A4_HsvOpEndInt_Callback(void)
{
	unsigned int i;

	if(sReCeReg->Reg.CH0_RESULT_CNT >= HSV_OP_CNT_MAX | sReCeReg->Reg.CH1_RESULT_CNT >= HSV_OP_CNT_MAX)
	{
		JIGMSG( "@E: CH0_HsvOp Result Cnt=%d\n", sReCeReg->Reg.CH0_RESULT_CNT);
		JIGMSG( "@E: CH1_HsvOp Result Cnt=%d\n", sReCeReg->Reg.CH1_RESULT_CNT);
	}

	if(HsvOpIntOn == 1)
	{
		JIGMSG( "@E: HsvOp Result Write\n");
	}
	else
	{
		for(i=0; i<sReCeReg->Reg.CH0_RESULT_CNT; i++)
		{
			HsvOpResult0[AdasStatus.Reg.WrBufSelHsv].left[i] 	= (int)(sReCeReg->Reg.CH0_Result_Hsv_op[i].Reg.RESULT_X_MIN);
			HsvOpResult0[AdasStatus.Reg.WrBufSelHsv].top[i] 	= (int)(sReCeReg->Reg.CH0_Result_Hsv_op[i].Reg.RESULT_Y_MIN);
			HsvOpResult0[AdasStatus.Reg.WrBufSelHsv].width[i] 	= (int)(sReCeReg->Reg.CH0_Result_Hsv_op[i].Reg.RESULT_X_MAX - sReCeReg->Reg.CH0_Result_Hsv_op[i].Reg.RESULT_X_MIN);
			HsvOpResult0[AdasStatus.Reg.WrBufSelHsv].height[i] 	= (int)(sReCeReg->Reg.CH0_Result_Hsv_op[i].Reg.RESULT_Y_MAX - sReCeReg->Reg.CH0_Result_Hsv_op[i].Reg.RESULT_Y_MIN);
			HsvOpResult0[AdasStatus.Reg.WrBufSelHsv].area[i]	= (int)(sReCeReg->Reg.CH0_Result_Hsv_op[i].Reg.RESULT_P_CNT);

			HsvOpResult0[AdasStatus.Reg.WrBufSelHsv].centroid[i].x 	= HsvOpResult0[AdasStatus.Reg.WrBufSelHsv].left[i] + HsvOpResult0[AdasStatus.Reg.WrBufSelHsv].width[i]/2;
			HsvOpResult0[AdasStatus.Reg.WrBufSelHsv].centroid[i].y 	= HsvOpResult0[AdasStatus.Reg.WrBufSelHsv].top[i] + HsvOpResult0[AdasStatus.Reg.WrBufSelHsv].height[i]/2;
		}
		HsvOpResultCnt0[AdasStatus.Reg.WrBufSelHsv] = sReCeReg->Reg.CH0_RESULT_CNT;

		for(i=0; i<sReCeReg->Reg.CH1_RESULT_CNT; i++)
		{
			HsvOpResult1[AdasStatus.Reg.WrBufSelHsv].left[i] 	= (int)(sReCeReg->Reg.CH1_Result_Hsv_op[i].Reg.RESULT_X_MIN);
			HsvOpResult1[AdasStatus.Reg.WrBufSelHsv].top[i] 	= (int)(sReCeReg->Reg.CH1_Result_Hsv_op[i].Reg.RESULT_Y_MIN);
			HsvOpResult1[AdasStatus.Reg.WrBufSelHsv].width[i] 	= (int)(sReCeReg->Reg.CH1_Result_Hsv_op[i].Reg.RESULT_X_MAX - sReCeReg->Reg.CH0_Result_Hsv_op[i].Reg.RESULT_X_MIN);
			HsvOpResult1[AdasStatus.Reg.WrBufSelHsv].height[i] 	= (int)(sReCeReg->Reg.CH1_Result_Hsv_op[i].Reg.RESULT_Y_MAX - sReCeReg->Reg.CH0_Result_Hsv_op[i].Reg.RESULT_Y_MIN);

			HsvOpResult1[AdasStatus.Reg.WrBufSelHsv].area[i]	= (int)(sReCeReg->Reg.CH1_Result_Hsv_op[i].Reg.RESULT_P_CNT);

			HsvOpResult1[AdasStatus.Reg.WrBufSelHsv].centroid[i].x 	= HsvOpResult1[AdasStatus.Reg.WrBufSelHsv].left[i] + HsvOpResult1[AdasStatus.Reg.WrBufSelHsv].width[i]/2;
			HsvOpResult1[AdasStatus.Reg.WrBufSelHsv].centroid[i].y 	= HsvOpResult1[AdasStatus.Reg.WrBufSelHsv].top[i] + HsvOpResult1[AdasStatus.Reg.WrBufSelHsv].height[i]/2;
		}
		HsvOpResultCnt1[AdasStatus.Reg.WrBufSelHsv] = sReCeReg->Reg.CH1_RESULT_CNT;
		//HsvBuffSel = (~HsvBuffSel) & 0x01;


		HsvOpIntOn = 1;



	}
}

//--------------------------------------------------------------------------------------------------------------
void A4_HsvOp_ISR_Handler(void)
{
	int tmp;
	static int hsvtest=0;
	if(sReCeReg->Reg.START_INT)
	{
		sReCeReg->Reg.START_INT_CLR = 1;
		sReCeReg->Reg.START_INT_CLR = 0;


		Gpio_Set(8,GPIO_HIGH);

	}
	//--------------------------------------------------------------------------------------------------------
	if(sReCeReg->Reg.END_INT)
	{

		sReCeReg->Reg.END_INT_CLR = 1;
		sReCeReg->Reg.END_INT_CLR = 0;

		Gpio_Set(8,GPIO_LOW);
		if(hsvtest)
		{
			hsvtest = 0;

		}
		else
		{
			hsvtest = 1;
		}

		A4_HsvOpEndInt_Callback();
		//JIGMSG( "HE\n");


	}
    //Clear IFR of IRQ1 (INTC's IFR turn-off)
    //abbd_intc_core_ifr_off(HSV_OP_CORE_IRQ);
}

//---------------------------------------------------------------------------------------------------------------------
void A4_HsvOp_Init(void)
{
	sReCeReg->Reg.HSV_CH0_OP_EN = 1;
	sReCeReg->Reg.HSV_CH1_OP_EN = 1;
	sReCeReg->Reg.CH0_SEL = 0;
	sReCeReg->Reg.CH1_SEL = 0;
	sReCeReg->Reg.FRAME_TOT_PIX_CNT =adas_size.total_size_height * adas_size.total_size_width - 2; // 1650 X 750 - 2
	sReCeReg->Reg.START_INT_EN 	= 1;
	sReCeReg->Reg.END_INT_EN 	= 1;
	sReCeReg->Reg.HSV_H_ACT = adas_size.width_0;

#ifdef	_HSV_OP_INT_EN
    if( ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_RE_CE, (PrVoid)A4_HsvOp_ISR_Handler, CMD_END) != NC_SUCCESS )
    {
    	DEBUGMSG_SDK(MSGERR, "CE_INI ERROR\n");
    }
#endif

	JIGMSG("@@ HSV OP Init. done \n");

}

