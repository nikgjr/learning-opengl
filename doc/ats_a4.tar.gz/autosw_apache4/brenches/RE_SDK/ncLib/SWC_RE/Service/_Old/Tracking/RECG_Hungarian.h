#include "../RECG_typedef.h"
#include "../common.h"

#define MAXVALUE 0xFFFFFFFF

//#include "debug.h"
//#define HUNGARIAN_DEBUG

void Hungarian_algorithm(int nRow, int nCol, float **c_mat, int **l_mat);
void Hungarian_algorithm_Static(int nRow, int nCol, float c_mat[][MAX_TRACK], int l_mat[][MAX_TRACK]);
void hungarian_processing(float **CostMat, int nR, int mC, int **DA_Mat);
void hungarian_processing_Static(float CostMat[][MAX_TRACK], int nR, int mC, int DA_Mat[][MAX_TRACK]);

void PrintArray_f(float *C, int nRow, int nCol);
void PrintArray_i(int *C, int nRow, int nCol);
void PrintVector_i(int *V, int nDim);
int step_one(float *C, int nRow, int nCol);
int step_two(float *C, int nRow, int nCol, int *C_cov, int *R_cov, int *M);
int step_three(float *C, int nRow, int nCol, int *C_cov, int *R_cov, int *M);
int step_four(float *C, int nRow, int nCol, int *C_cov, int *R_cov, int *M, int *Z0_r, int *Z0_c);
void find_a_zero(float *C, int nRow, int nCol, int *C_cov, int *R_cov, int *row, int *col);
char _find_star_in_row(int *M, int nCol, int *row, int *col);
int step_five(int nRow, int nCol, int *C_cov, int *R_cov, int *M, int *Z0_r, int *Z0_c);
void find_star_in_col(int *M, int nRow, int nCol, int c, int *r);
void find_prime_in_row(int *M, int nRow, int nCol, int r, int *c);
//void convert_path(int *M, int nCol, int count, int **path);
void convert_path(int *M, int nCol, int count, int path[][2]);
void clear_covers(int nRow, int nCol, int *C_cov, int *R_cov);
void erase_primes(int *M, int nRow, int nCol);
int step_six(float *C, int nRow, int nCol, int *C_cov, int *R_cov);
void find_smallest(float *C, int nRow, int nCol, int *C_cov, int *R_cov, float *minval);
