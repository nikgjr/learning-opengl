/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    :
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version :
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "RE_Svc.h"

/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile RE_STATUS_REGISTER   	sReStatusReg;

volatile RE_SCALER_REGISTER		*sReScalerReg;
volatile RE_VDPD_REGISTER		*sReVdpdReg;
volatile RE_CE_REGISTER			*sReCeReg;
volatile RE_MOD_REGISTER			*sReModReg;
volatile RE_LD_REGISTER			*sReLdReg;
volatile RE_PRE_REGISTER			*sRePreReg;
volatile RE_POST_REGISTER		*sRePostReg;
volatile RE_POST_TG_REGISTER		*sRePostTgReg;


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

int ncSvc_RE_Register_Init(void)
{
	int iTmp;

	REGRW32(0x08001040, 0) = 1<<4 | 1<<5 | 1<<6;		// GPIO_SEN_CLK_ON[4], SEN_CLK_INV[5], OUT_CLK_INV[6]

	REGRW32(0x08100008, 0) = 0x22222222;
	REGRW32(0x0810000c, 0) = 0x22222222;
	REGRW32(0x08100010, 0) = 0x22222222;
	REGRW32(0x08100014, 0) = 0x22222222;
	REGRW32(0x08100018, 0) = 0x22222222;
	REGRW32(0x0810001c, 0) = 0x22222222;


	sReScalerReg 	= (RE_SCALER_REGISTER*)(RE_SCALER_ADDR);
	sReVdpdReg 		= (RE_VDPD_REGISTER*)(RE_VDPD_ADDR);
	sReCeReg 		= (RE_CE_REGISTER*)(RE_CE_ADDR);
	sReModReg		= (RE_MOD_REGISTER*)(RE_MOD_ADDR);
	sReLdReg		= (RE_LD_REGISTER *)(RE_LD_ADDR);

	sRePreReg		= (RE_PRE_REGISTER*)(RE_PRE_ADDR);
	sRePostReg	 	= (RE_POST_REGISTER*)(RE_POST_ADDR);
	sRePostTgReg	= (RE_POST_TG_REGISTER*)(RE_POST_TG_ADDR);

	REGRW32(0x08000020, 0) &= ~(1<<26); 			// [26]APB_ON : 0-ON, 1-OFF

	sRePostReg->Reg.O_SEL_ST296_POL = 2;	// H_ACT_INV[1], V_ACT_INV[0]


	AdasStatus.Reg.DrawFrameNum = 3;
	sReStatusReg.Reg.start_status = INPUT_IMG_SIZE ;
	sReStatusReg.Reg.FilterCompareMode7  = 0;
	sReStatusReg.Reg.FilterCompareMode6  = 0;
	sReStatusReg.Reg.FilterCompareMode5  = 0;
	sReStatusReg.Reg.FilterCompareMode4  = 0;
	sReStatusReg.Reg.FilterCompareMode3  = 0;
	sReStatusReg.Reg.FilterCompareMode2  = 1;
	sReStatusReg.Reg.FilterCompareMode1  = 1;
	sReStatusReg.Reg.FilterCompareMode0  = 1;
	sReStatusReg.Reg.DisModeSel = 1;
	sReStatusReg.Reg.status_flag13 = 0 ;
	sReStatusReg.Reg.status_flag12 = 0 ;
	sReStatusReg.Reg.status_flag11 = 0 ;
	sReStatusReg.Reg.status_flag10 = 0 ;
	sReStatusReg.Reg.status_flag09 = 0 ;
	sReStatusReg.Reg.status_flag08 = 0 ;
	sReStatusReg.Reg.status_flag07 = 0 ;
	sReStatusReg.Reg.status_flag06 = 0 ;
	sReStatusReg.Reg.status_flag05 = 0 ;
	sReStatusReg.Reg.status_flag04 = 0 ;
	sReStatusReg.Reg.status_flag03 = 0 ;
	sReStatusReg.Reg.status_flag02 = 0 ;
	sReStatusReg.Reg.status_flag01 = 0 ;
	sReStatusReg.Reg.status_flag00 = 0 ;
	sReStatusReg.Reg.Frame_skip = 3;
	sReStatusReg.Reg.ClusteringBoxDisOn = 0;

	RE_Size_int(sReStatusReg.Reg.start_status);

	//- old data -------------------------------------------------------------
	//A4_AdasIp_Init();

	REGRW32(0x08000020, 0) &= ~(1<<3); 	// [3]AXI_ON : 0-ON, 1-OFF

	#ifdef	_RECG_TABLE_WR_EN
		#ifdef	_RECG_F00_ON
			ncDrv_A4_WriteRecgTable_FX(0);	// Set recg_eng Table
		#endif
			/*
		#ifdef	_RECG_F01_ON
			ncDrv_A4_WriteRecgTable_FX(1);	// Set recg_eng Table
		#endif
		#ifdef	_RECG_F10_ON
			ncDrv_A4_WriteRecgTable_FX(2);	// Set recg_eng Table
		#endif
		#ifdef	_RECG_F11_ON
			ncDrv_A4_WriteRecgTable_FX(3);	// Set recg_eng Table
		#endif

		#ifdef	_RECG_F100_ON
			ncDrv_A4_WriteRecgTable_FX(4);	// Set recg_eng Table
		#endif
		#ifdef	_RECG_F101_ON
			ncDrv_A4_WriteRecgTable_FX(5);	// Set recg_eng Table
		#endif
		#ifdef	_RECG_F110_ON
			ncDrv_A4_WriteRecgTable_FX(6);	// Set recg_eng Table
		#endif
		#ifdef	_RECG_F111_ON
			ncDrv_A4_WriteRecgTable_FX(7);	// Set recg_eng Table
		#endif
*/
		ncDrv_A4_ReadRecgTable_FX();	// Read & compare recg_eng Table
	#endif

	//A4_AdasIP_Interrupt_Init();


	//#ifdef	_DEBUG_MODE_0
		JIGMSG("@@ RE Init OK!!\n");
	//#endif

	return 	NC_SUCCESS;
}



void RE_Size_int(unsigned int type)
{
	if(type == 0)
	{
		adas_size.width_0  = 640;
		adas_size.width_2  = 512;
		adas_size.width_4  = 412;
		adas_size.width_6  = (unsigned int)(adas_size.width_0 / 2);
		adas_size.width_c  = (unsigned int)(adas_size.width_0 / 4);
		adas_size.width_e  = (unsigned int)(adas_size.width_2 / 4);
		adas_size.width_10 = (unsigned int)(adas_size.width_4 / 4 + 1);
		adas_size.width_12 = (unsigned int)(adas_size.width_0 / 8);

		adas_size.height_0  = 360;
		adas_size.height_2  = 288;
		adas_size.height_4  = 230;
		adas_size.height_6  = (unsigned int)(adas_size.height_0 / 2);
		adas_size.height_c  = (unsigned int)(adas_size.height_0 / 4);
		adas_size.height_e  = (unsigned int)(adas_size.height_2 / 4);
		adas_size.height_10 = (unsigned int)(adas_size.height_4 / 4);
		adas_size.height_12 = (unsigned int)(adas_size.height_0 / 8);

		adas_size.wide_width_0  = 1280;
		adas_size.wide_width_2  = 1024;
		adas_size.wide_width_4  = 820;

		adas_size.wide_height_0  = 360;
		adas_size.wide_height_2  = 288;
		adas_size.wide_height_4  = 230;

		adas_size.total_size_width  = 1650;
		adas_size.total_size_height = 750;

		adas_size.input_size_width  = 1280;
		adas_size.input_size_height = 720;
		adas_size.DTO = 0x2000;
		adas_size.DLY = 645;


/*
		sRePreReg->Reg.HUS_TG_H_DLY = 645;
		sRePreReg->Reg.HUS_TG_V_FDLY = 645;
		sRePreReg->Reg.HUS_TG_V_RDLY = 645;*/
	}
	else if(type ==1)
	{
		adas_size.width_0  = 640;
		adas_size.width_2  = 512;
		adas_size.width_4  = 412;
		adas_size.width_6  = (unsigned int)( adas_size.width_0 / 2);
		adas_size.width_c  = (unsigned int)( adas_size.width_0 / 4);
		adas_size.width_e  = (unsigned int)( adas_size.width_2 / 4);
		adas_size.width_10 = (unsigned int)( adas_size.width_4 / 4 + 1);
		adas_size.width_12 = (unsigned int)( adas_size.width_0 / 8);

		adas_size.height_0  = 360;
		adas_size.height_2  = 288;
		adas_size.height_4  = 230;
		adas_size.height_6  = (unsigned int)(adas_size.height_0 / 2);
		adas_size.height_c  = (unsigned int)(adas_size.height_0 / 4);
		adas_size.height_e  = (unsigned int)(adas_size.height_2 / 4);
		adas_size.height_10 = (unsigned int)(adas_size.height_4 / 4);
		adas_size.height_12 = (unsigned int)(adas_size.height_0 / 8);

		adas_size.wide_width_0  = 1920;
		adas_size.wide_width_2  = 1536;
		adas_size.wide_width_4  = 1228;

		adas_size.wide_height_0  = 480;
		adas_size.wide_height_2  = 384;
		adas_size.wide_height_4  = 307;

		adas_size.total_size_width  = 2200;
		adas_size.total_size_height = 1125;

		adas_size.input_size_width  = 1920;
		adas_size.input_size_height = 1080;
		adas_size.DTO = 0x3000;
		adas_size.DLY = 1285;
/*
		sRePreReg->Reg.HUS_TG_H_DLY = 1285;
		sRePreReg->Reg.HUS_TG_V_FDLY = 1285;
		sRePreReg->Reg.HUS_TG_V_RDLY = 1285;*/
	}
	else
	{
		adas_size.width_0  = 768;
		adas_size.width_2  = 616;
		adas_size.width_4  = 496;
		adas_size.width_6  = 384;
		adas_size.width_c  = 192;
		adas_size.width_e  = 144;
		adas_size.width_10 = 128;
		adas_size.width_12 = 96;

		adas_size.height_0  = 432;
		adas_size.height_2  = 345;
		adas_size.height_4  = 276;
		adas_size.height_6  = 216;
		adas_size.height_c  = 108;
		adas_size.height_e  = 88;
		adas_size.height_10 = 70;
		adas_size.height_12 = 54;

		adas_size.wide_width_0  = 3072;
		adas_size.wide_width_2  = 2458;
		adas_size.wide_width_4  = 1967;

		adas_size.wide_height_0  = 480;   //
		adas_size.wide_height_2  = 384;   //
		adas_size.wide_height_4  = 307;   //

		adas_size.total_size_width  = 3375;
		adas_size.total_size_height = 1760;

		adas_size.input_size_width  = 3072;
		adas_size.input_size_height = 1728;

		adas_size.DTO = 0x4000;
		adas_size.DLY = 2432;
	}
}
void ncSvc_RE_SetDisplayMode(void)
{
	UINT32	rest;
	UINT32	i;
	static UINT32 tCnt=0;

	const unsigned int preISP_size_H = 1280;
	const unsigned int preISP_size_V = 720 ;

	const unsigned int total_pixel_size_H = 1650;
	const unsigned int total_pixel_size_V = 750 ;

	const unsigned int output_W = 1280;
	const unsigned int output_H = 720;
	const unsigned int output_tot_W = 1650;
	const unsigned int output_tot_H = 750;
	tCnt++;
	if(tCnt == 9) tCnt = 1;

	sReStatusReg.Reg.FrameBufCnt = 4;


	JIGMSG("ncSvc_RE_SetDisplayMode start \n");
	//sReStatusReg.Reg.DisModeSel = 1;

	//sRePostReg->Reg.RD_BUF_SEL = 1;		// display recg_scaling Image
	//sRePreReg->Reg.FM_YC_EN_MODE = 3; // enable pre Y,C Saving

	/*
	i = ab_asi_io_read(0x93010400);	JIGMSG( "1.post_isp=%08x\n", i);
	i = ab_asi_io_read(0x93010600);	JIGMSG( "2.post_tg=%08x\n", i);
	i = ab_asi_io_read(0x93010800);	JIGMSG( "3.pre_isp=%08x\n", i);
	i = ab_asi_io_read(0x93010A00);	JIGMSG( "4.scaler=%08x\n", i);
	i = ab_asi_io_read(0x93020000);	JIGMSG( "5.recg_eng=%08x\n", i);
	i = ab_asi_io_read(0x93050000);	JIGMSG( "6.mod=%08x\n", i);
	*/

	////sRePreReg->Reg.IN_TEST_MODE_TYPE = 7;
	////sRePreReg->Reg.FM_HSIZE = preISP_size_H;
	////sRePreReg->Reg.FM_VSIZE = preISP_size_V;

	//JIGMSG( "h-size=%d\n", sRePreReg->Reg.FM_HSIZE);
	JIGMSG("%d",sReStatusReg.Reg.Frame_skip);
	sRePreReg->Reg.FR_SKIP_CNT =3;//_SC_FR_SKIP;
	////sRePreReg->Reg.FR_SKIP_CNT0 = 0;
#if 1
	sRePostTgReg->Reg.DSP_OUT_SKIP_CNT = sRePreReg->Reg.FR_SKIP_CNT;

	sRePostTgReg->Reg.DSP_OUT_FL_H_ACT = output_W;
	sRePostTgReg->Reg.DSP_OUT_FL_H_TOTAL =adas_size.total_size_height *
			adas_size.total_size_width *(sRePreReg->Reg.FR_SKIP_CNT + 1) / output_tot_H;;

	sRePostTgReg->Reg.DSP_OUT_FL_V_ACT = output_H;
	sRePostTgReg->Reg.DSP_OUT_FL_V_TOTAL = output_tot_H;
	sRePostTgReg->Reg.DSP_OUT_FL_V_BLK1 = output_tot_H - output_H;

	sRePostReg->Reg.RD_BASE_ADDR = FM0_START_ADDR;

	sRePostReg->Reg.RD_BUF_MODE = 3;


	sRePreReg->Reg.DOWN_CROP_H_SIZE = adas_size.input_size_width;
	sRePreReg->Reg.DOWN_CROP_V_SIZE = adas_size.input_size_height;
	sRePreReg->Reg.DOWN_CROP_H_ACT  = adas_size.input_size_width;
	sRePreReg->Reg.DOWN_CROP_V_ACT  = adas_size.input_size_height;
	sRePreReg->Reg.DS_IN_HACT_SIZE  = adas_size.input_size_width;
	sRePreReg->Reg.DS_IN_HBLK_SIZE  = adas_size.total_size_width - adas_size.input_size_width;
	sRePreReg->Reg.DS_IN_VACT_SIZE  = adas_size.input_size_height;
	sRePreReg->Reg.DS_H_DTO = adas_size.DTO;
	sRePreReg->Reg.DS_V_DTO = adas_size.DTO;
	sRePreReg->Reg.DS_OUT_HACT_SIZE = adas_size.width_0;
    sRePreReg->Reg.DS_OUT_VACT_SIZE = adas_size.height_0;
    sRePreReg->Reg.HUS_IN_H_SIZE = adas_size.width_0;

    sRePreReg->Reg.WIDE_CROP_H_ACT  = adas_size.input_size_width;
    sRePreReg->Reg.WIDE_CROP_V_ACT  = adas_size.input_size_height;
    sRePreReg->Reg.WIDE_CROP_H_POS  = 0;
    if(sReStatusReg.Reg.start_status == 0)
    	sRePreReg->Reg.WIDE_CROP_V_POS  = 180;
    else if(sReStatusReg.Reg.start_status == 1)
    	sRePreReg->Reg.WIDE_CROP_V_POS  = adas_size.input_size_height / 2;
    else
    	sRePreReg->Reg.WIDE_CROP_V_POS  = adas_size.input_size_height / 2;
    sRePreReg->Reg.WIDE_CROP_H_SIZE = adas_size.wide_width_0;
    sRePreReg->Reg.WIDE_CROP_V_SIZE = adas_size.wide_height_0;

    sRePreReg->Reg.HUS_TG_H_ACT   = adas_size.width_0 ;
    sRePreReg->Reg.HUS_TG_H_DLY   = adas_size.DLY ;
    sRePreReg->Reg.HUS_TG_V_RDLY  = adas_size.DLY ;
    sRePreReg->Reg.HUS_TG_V_FDLY  = adas_size.DLY ;
    sRePreReg->Reg.HUS_UP_H_DISP  = adas_size.width_0;
	JIGMSG( "AR Start 1_2 \n");


	sReScalerReg->Reg.FRAME_TOT_PIX_CNT = adas_size.total_size_height * adas_size.total_size_width - 2;
#else
	sRePostTgReg->Reg.DSP_OUT_SKIP_CNT = sRePreReg->Reg.FR_SKIP_CNT;

	sRePostTgReg->Reg.DSP_OUT_FL_H_ACT = 1280;
	sRePostTgReg->Reg.DSP_OUT_FL_H_TOTAL =1650 *(sRePreReg->Reg.FR_SKIP_CNT + 1);;

	sRePostTgReg->Reg.DSP_OUT_FL_V_ACT = 720;
	sRePostTgReg->Reg.DSP_OUT_FL_V_TOTAL = 750;
	sRePostTgReg->Reg.DSP_OUT_FL_V_BLK1 = 30;

	sRePostReg->Reg.RD_BASE_ADDR = FM0_START_ADDR;

	sRePostReg->Reg.RD_BUF_MODE = 3;


	JIGMSG( "AR Start 1_2 \n");


	sReScalerReg->Reg.FRAME_TOT_PIX_CNT = 1650 * 750 - 2;
#endif
	sRePostReg->Reg.RD_PASS_SEL = 1;

	sRePostTgReg->Reg.DSP_OUT_TG_MODE = 1;	// 0 - bypass, 1 - frame lock, 2 - free run
	sRePostTgReg->Reg.DSP_OUT_BP_VS_MODE = 1;





	if(sReStatusReg.Reg.DisModeSel > 0)
	{
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = sReStatusReg.Reg.DisModeSel - 1;
	}

	if( sReStatusReg.Reg.DisModeSel == 1 )
	{
		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FM0_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FM0_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FM0_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM0_H_SIZE;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM0_V_SIZE;

		JIGMSG( "scaler_fm0_hsize = %d \n", sReScalerReg->Reg.RES_FM0_H_SIZE);
		JIGMSG( "post_fm0_hsize = %d \n", sRePostReg->Reg.RD_HSIZE);

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FM0_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 0;
		//sReScalerReg->Reg.RES_FM0_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM0_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 2 )
	{
		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FM2_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FM2_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FM2_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM2_H_SIZE;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM2_V_SIZE;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FM2_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 2;
		//sReScalerReg->Reg.RES_FM2_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM2_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 3 )
	{

		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FM4_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FM4_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FM4_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM4_H_SIZE;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM4_V_SIZE;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FM4_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 4;
		//sReScalerReg->Reg.RES_FM4_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM4_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 4 )
	{
		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FM6_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FM6_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FM6_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM0_H_SIZE / 2;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM0_V_SIZE / 2;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FM6_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 6;
		//sReScalerReg->Reg.RES_FM6_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM6_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 5 )
	{
		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FMc_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FMc_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FMc_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM0_H_SIZE / 4;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM0_V_SIZE / 4;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FMc_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 7;
		//sReScalerReg->Reg.RES_FMc_Y_EN = 1;
		//sReScalerReg->Reg.RES_FMc_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 6 )
	{
	   //// sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FM12_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FM12_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FM12_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM0_H_SIZE / 8;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM0_V_SIZE / 8;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FM12_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 8;
		//sReScalerReg->Reg.RES_FM12_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM12_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 7 )
	{
		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FMe_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FMe_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FMe_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM2_H_SIZE / 4;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM2_V_SIZE / 4;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FMe_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 3;
		//sReScalerReg->Reg.RES_FM12_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM12_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 8 )
	{
		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FM10_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FM10_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FM10_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM4_H_SIZE / 4 + 1;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM4_V_SIZE / 4;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FM10_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 5;
		//sReScalerReg->Reg.RES_FM12_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM12_C_EN = 1;
	}
}

void ncSvc_RE_AdasIp_Init(void)
{
	unsigned int Tmp;
	JIGMSG("@@ ADAS IP Init Start0\n");

	sReModReg->Reg.MOD_EN_0 = 0;  // fp
	sReModReg->Reg.MOD_EN_1 = 0;  // of





	//ncSvc_RE_Scaler_Init();

#ifdef _LD_INIT
	A4_LD_Init();
#endif
	//ncDrv_AR_SetDisplayMode();
	//A4_Mod_Init();
	//A4_RecgEng_Init();
 	// mod image start address
	//A4_HsvOp_Init();

	AdasStatus.Data32 = 0;

	JIGMSG("@@ ADAS IP Init Done\n");
}

/* End Of File */

