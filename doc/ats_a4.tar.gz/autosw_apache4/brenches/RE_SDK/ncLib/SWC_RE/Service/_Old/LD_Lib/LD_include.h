#ifndef __LD_INCLUDE_H__
#define __LD_INCLUDE_H__

//#define _RUN_MFC
#define	_USE_UV
//#define _MAKE_FILE

#include <string.h>
#include <stdio.h>
#include <math.h>

#ifdef _RUN_MFC
#include <Windows.h>
#include <cv.h>
#include <highgui.h>

#else


#endif // _RUN_MFC


#endif
