#ifndef __RE_LD_REGISTER_H__
#define __RE_LD_REGISTER_H__

/*=============================================================================
	Definitions for Register Start Address, End Address, Size
=============================================================================*/
typedef union
{
	UINT32 Data32[2];
	struct
	{
		UINT32 height:						5;	//7
		UINT32 cen_x:						5;	//0
		UINT32 cen_y:						5;	//0
		UINT32 Y_Sum:						16;	//0
		UINT32 Rev_0:						1;	//0

		UINT32 color:						2;	//0
		UINT32 width:						5;	//2
		UINT32 U_Sum:						12;	//1
		UINT32 V_Sum:						12;	//1
		UINT32 Rev_1:						1;	//0
	}Reg;

	struct
	{
		UINT32 Data0:						8;
		UINT32 Data1:						8;
		UINT32 Data2:						8;
		UINT32 Data3:						8;

		UINT32 Data4:						8;
		UINT32 Data5:						8;
		UINT32 Data6:						8;
		UINT32 Data7:						8;
	}D8;

}REC_LD_RESULT;


#define	RE_LD_REGISTER_SIZE	0x005C

typedef union
{
	unsigned int Data[RE_LD_REGISTER_SIZE/4];
	struct
	{
		/*	0x0000	[00]	*/	unsigned int	LANE_DETECTION_EN	:	1	;
		/*	0x0000	[01]	*/	unsigned int	Rev0000_01	:	7	;
		/*	0x0000	[08]	*/	unsigned int	LD_FRAME_SKIP	:	8	;
		/*	0x0000	[16]	*/	unsigned int	Rev0000_16	:	16	;

		/*	0x0004	[00]	*/	unsigned int	LD_IMG_WIDTH	:	10	;
		/*	0x0004	[10]	*/	unsigned int	Rev0004_10	:	6	;
		/*	0x0004	[16]	*/	unsigned int	LD_IMG_HEIGHT	:	9	;
		/*	0x0004	[25]	*/	unsigned int	Rev0004_25	:	7	;

		/*	0x0008	[00]	*/	unsigned int	VP_X	:	10	;
		/*	0x0008	[10]	*/	unsigned int	Rev0008_10	:	6	;
		/*	0x0008	[16]	*/	unsigned int	VP_Y	:	9	;
		/*	0x0008	[25]	*/	unsigned int	Rev0008_25	:	7	;
		/*	0x000C	[00]	*/	unsigned int	TV_RATIO_W	:	8	;
		/*	0x000C	[08]	*/	unsigned int	Rev000C_08	:	24	;

		/*	0x0010	[00]	*/	unsigned int	CANDI1_GAP	:	8	;
		/*	0x0010	[08]	*/	unsigned int	CANDI1_Y_TH	:	8	;
		/*	0x0010	[16]	*/	unsigned int	CANDI1_Y_DIFF_TH	:	8	;
		/*	0x0010	[24]	*/	unsigned int	CANDI1_U_TH	:	8	;

		/*	0x0014	[00]	*/	unsigned int	CANDI1_U_LEVEL_TH	:	8	;
		/*	0x0014	[08]	*/	unsigned int	CANDI1_V_TH	:	8	;
		/*	0x0014	[16]	*/	unsigned int	CANDI1_V_LEVEL_TH	:	8	;
		/*	0x0014	[24]	*/	unsigned int	CANDI1_MODE	:	1	;
		/*	0x0014	[25]	*/	unsigned int	Rev0014_25	:	7	;

		/*	0x0018	[00]	*/	unsigned int	CANDI2_GAP	:	8	;
		/*	0x0018	[08]	*/	unsigned int	Rev0018_08	:	24	;
		/*	0x001C	[00]	*/	unsigned int	BLOCK_WIDTH	:	8	;
		/*	0x001C	[08]	*/	unsigned int	BLOCK_HEIGHT	:	8	;
		/*	0x001C	[16]	*/	unsigned int	X_BLOCK_TOT	:	8	;
		/*	0x001C	[24]	*/	unsigned int	Y_BLOCK_TOT	:	8	;

		/*	0x0020	[00]	*/	unsigned int	LAST_Y	:	9	;
		/*	0x0020	[09]	*/	unsigned int	Rev0020_09	:	7	;
		/*	0x0020	[16]	*/	unsigned int	BLOCK_OVERLAP	:	8	;
		/*	0x0020	[24]	*/	unsigned int	TEST_MODE	:	1	;
		/*	0x0020	[25]	*/	unsigned int	Rev0020_25	:	7	;

		/*	0x0024	[00]	*/	unsigned int	LD_INT_PULSE_EN	:	1	;
		/*	0x0024	[01]	*/	unsigned int	LD_INT_EN_FRAME_START	:	1	;
		/*	0x0024	[02]	*/	unsigned int	LD_INT_EN_AXI_FINISH	:	1	;
		/*	0x0024	[03]	*/	unsigned int	LD_INT_EN_INIT_FINISH	:	1	;
		/*	0x0024	[04]	*/	unsigned int	LD_INT_EN_PSEUDO_AXI_FINISH	:	1	;
		/*	0x0024	[05]	*/	unsigned int	LD_INT_EN_PSEUDO_INIT_FINISH	:	1	;
		/*	0x0024	[06]	*/	unsigned int	LD_INT_EN_FINISH_ERROR	:	1	;
		/*	0x0024	[07]	*/	unsigned int	Rev0024_07	:	25	;

		/*	0x0028	[00]	*/	unsigned int	LD_INT_CLR_FRAME_START	:	1	;
		/*	0x0028	[01]	*/	unsigned int	LD_INT_CLR_AXI_FINISH	:	1	;
		/*	0x0028	[02]	*/	unsigned int	LD_INT_CLR_INIT_FINISH	:	1	;
		/*	0x0028	[03]	*/	unsigned int	LD_INT_CLR_PSEUDO_AXI_FINISH	:	1	;
		/*	0x0028	[04]	*/	unsigned int	LD_INT_CLR_PSEUDO_INIT_FINISH	:	1	;
		/*	0x0028	[05]	*/	unsigned int	LD_INT_CLR_FINISH_ERROR	:	1	;
		/*	0x0028	[06]	*/	unsigned int	Rev0028_06	:	26	;

		/*	0x002C	[00]	*/	unsigned int	LD_BASE_ADDR0	:	32	;

		/*	0x0030	[00]	*/	unsigned int	LD_BASE_ADDR1	:	32	;

		/*	0x0034	[00]	*/	unsigned int	COEF00	:	3	;
		/*	0x0034	[03]	*/	unsigned int	COEF01	:	3	;
		/*	0x0034	[06]	*/	unsigned int	COEF02	:	3	;
		/*	0x0034	[09]	*/	unsigned int	COEF10	:	3	;
		/*	0x0034	[12]	*/	unsigned int	COEF11	:	3	;
		/*	0x0034	[15]	*/	unsigned int	COEF12	:	3	;
		/*	0x0034	[18]	*/	unsigned int	COEF20	:	3	;
		/*	0x0034	[21]	*/	unsigned int	COEF21	:	3	;
		/*	0x0034	[24]	*/	unsigned int	COEF22	:	3	;
		/*	0x0034	[27]	*/	unsigned int	SH_BIT	:	4	;
		/*	0x0034	[31]	*/	unsigned int	Rev0034_31	:	1	;

		/*	0x0038	[00]	*/	unsigned int	TEST_CODE	:	32                       ;

		/*	0x003C	[00]	*/	unsigned int	VSYNC_DELAY					:	32	;

		/*	0x0040	[00]	*/	unsigned int	PSEUDO_LENGTH				:	16	;
		/*	0x0040	[16]	*/	unsigned int	Rev0040_16					:	16	;


		/* 0x0044	[00] 	*/ unsigned int	Rev0068_00[(0x005C-0x0044)/4];

		/*	0x005C	[00]	*/	unsigned int	LD_AXI_MEM_SEL	:	1	;
		/*	0x005C	[01]	*/	unsigned int	Rev005C_01	:	31	;

		/*	0x0060	[00]	*/	unsigned int	LD_FRAME_START_FLAG	:	1	;
		/*	0x0060	[01]	*/	unsigned int	LD_AXI_FINISH_FLAG	:	1	;
		/*	0x0060	[02]	*/	unsigned int	LD_INIT_FINISH_FLAG	:	1	;
		/*	0x0060	[03]	*/	unsigned int	LD_PSEUDO_AXI_FINISH_FLAG	:	1	;
		/*	0x0060	[04]	*/	unsigned int	LD_PSEUDO_INIT_FINISH_FLAG	:	1	;
		/*	0x0060	[05]	*/	unsigned int	LD_FINISH_ERROR_FLAG	:	1	;
		/*	0x0060	[06]	*/	unsigned int	Rev0060_06	:	26	;

		/*	0x0064	[00]	*/	unsigned int	dma_wptr	:	13	;
		/*	0x0064	[13]	*/	unsigned int	Rev0064_13	:	3	;
		/*	0x0064	[16]	*/	unsigned int	dma_rptr	:	13	;
		/*	0x0064	[29]	*/	unsigned int	Rev0064_29	:	3	;

		/*	0x0068	[00]	*/	unsigned int	I_AWREADY	:	1	;
		/*	0x0068	[01]	*/	unsigned int	O_AWVALID	:	1	;
		/*	0x0068	[02]	*/	unsigned int	I_WREADY	:	1	;
		/*	0x0068	[03]	*/	unsigned int	O_WVALID	:	1	;
		/*	0x0068	[04]	*/	unsigned int	O_WLAST	:	1	;
		/*	0x0068	[05]	*/	unsigned int	I_BVALID	:	1	;
		/*	0x0068	[06]	*/	unsigned int	O_BREADY	:	1	;
		/*	0x0068	[07]	*/	unsigned int	Rev0068_07	:	25	;

	}Reg;
}RE_LD_REGISTER;

#endif


