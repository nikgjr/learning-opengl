#include "common.h"

#include "./clustering/APP_Nms.h"
#define GROUP_THRESHOLD 1
#define MIN_OVERLAP_THRESH 0.7
#define UNION_OVERLAP_THRESH 0.4


void ADAS_nms(BOX_INFO *in_Box , BOX_INFO *out_Box);
int remain_select(int *b_sel, int size);
void rect_overap(BOX_INFO *in_Box, int max_idx, int idx, ST_OVERLAP *overlap_ratio);
float max_func(float a, float b);
float min_func(float a, float b);

void ADAS_nms(BOX_INFO *in_Box , BOX_INFO *out_Box)
{
	int 	n_min_group = GROUP_THRESHOLD;
	float 	eps1 = MIN_OVERLAP_THRESH;
	float 	eps2 = UNION_OVERLAP_THRESH;
	int 	i, j ;
	int 	n_rect;
	int 	b_select[128];
	int 	cnt_rect;
	int 	index_max_rect;
	float 	max_score;
	int 	idx , while_break_cnt;

	ST_OVERLAP overlap_ratio;

	if(in_Box->BoxNumMax)
	{
		if(n_min_group<=0 || !in_Box->BoxNumMax)
			return;

		n_rect = (int)in_Box->BoxNumMax;


		//int *b_select = new int[n_rect];
		for(i=0; i<n_rect; i++)
			b_select[i] = 0;
		//	b_select = 0;

		out_Box->BoxNumMax = 0;

		overlap_ratio.min_overlap = 0;
		overlap_ratio.union_overlap = 0;

		while(remain_select(b_select, n_rect))
		{
			index_max_rect = 0;
			max_score = -1000;

			for(i = 0; i < n_rect; i++)
			{
				if(b_select[i] == 0)
				{
					if(in_Box->BaxXYWH[i].score > max_score)
					{
						max_score = in_Box->BaxXYWH[i].score;
						index_max_rect = i;
					}
				}
			}

			b_select[index_max_rect] = 1;
			cnt_rect = 1;

			for(i = 0; i < n_rect; i++)
			{
				if(b_select[i] == 0)
				{
					rect_overap(in_Box, index_max_rect, i, &overlap_ratio);
					if(overlap_ratio.min_overlap >= eps1)	// 0.7
					{
						b_select[i] = 1;
					}

					if(overlap_ratio.union_overlap >= eps2)		//0.4
					{
						b_select[i] = 1;
					}
				}

			}

			if(cnt_rect >= n_min_group)
			{
				idx = out_Box->BoxNumMax;
				out_Box->BaxXYWH[idx] = in_Box->BaxXYWH[index_max_rect];
				out_Box->BoxNumMax++;
			}
		}
	}
	else
	{
		out_Box->BoxNumMax = 0;
	}
}



int remain_select(int *b_sel, int size)
{
	int i;
	for(i = 0; i < size; i++)
		if(!b_sel[i])
			return 1;

	return 0;
}

void rect_overap(BOX_INFO *in_Box, int max_idx, int idx ,ST_OVERLAP *overlap_ratio)
{
	//overlap is invalid in the beginning
	float aPointX1 = in_Box->BaxXYWH[max_idx].StX;
	float aPointY1 = in_Box->BaxXYWH[max_idx].StY;
	float aPointX2 = in_Box->BaxXYWH[max_idx].StX + in_Box->BaxXYWH[max_idx].Width;
	float aPointY2 = in_Box->BaxXYWH[max_idx].StY + in_Box->BaxXYWH[max_idx].Height;

	float bPointX1 = in_Box->BaxXYWH[idx].StX;
	float bPointY1 = in_Box->BaxXYWH[idx].StY;
	float bPointX2 = in_Box->BaxXYWH[idx].StX + in_Box->BaxXYWH[idx].Width;
	float bPointY2 = in_Box->BaxXYWH[idx].StY + in_Box->BaxXYWH[idx].Height;

	float max_w = in_Box->BaxXYWH[max_idx].Width;
	float max_h = in_Box->BaxXYWH[max_idx].Height;
	float org_w = in_Box->BaxXYWH[idx].Width;
	float org_h = in_Box->BaxXYWH[idx].Height;

	//get overlapping area
	float x1 = max_func(aPointX1, bPointX1);
	float y1 = max_func(aPointY1, bPointY1);
	float x2 = min_func(aPointX2, bPointX2);
	float y2 = min_func(aPointY2, bPointY2);

	//compute width and height of overlapping area
	float w = x2-x1;
	float h = y2-y1;

	float inter;
	float min_area;

	float a_area;
	float b_area;

	//set invalid entries to 0 overlap
	if(w<=0 || h<=0)
	{
		overlap_ratio->min_overlap = 0;
		overlap_ratio->union_overlap = 0;
	}
	else
	{
		//get overlapping areas
		inter = w*h;
		min_area = min_func((max_w*max_h), (org_w*org_h));

		a_area = (aPointX2-aPointX1) * (aPointY2-aPointY1);
		b_area = (bPointX2-bPointX1) * (bPointY2-bPointY1);

		//intersection over union overlap depending on users choice
		if(min_area > 0)
		{
			overlap_ratio->min_overlap = inter / min_area;
		}
		else
		{
			overlap_ratio->min_overlap = inter ;
		}
		if(a_area+b_area-inter > 0)
		{
			overlap_ratio->union_overlap = inter / (a_area+b_area-inter);
		}
		else
		{
			overlap_ratio->union_overlap = inter;
		}
	}
}

float max_func(float a, float b)
{
	return a>b? a : b;
}

float min_func(float a, float b)
{
	return a>b? b:a;
}

