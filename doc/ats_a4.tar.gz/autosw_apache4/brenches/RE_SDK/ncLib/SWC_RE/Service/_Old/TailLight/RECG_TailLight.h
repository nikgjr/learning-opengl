#include "RECG_typedef.h"


extern void Detect_TailLight_using_Box(unsigned int y_addr , Label *label , NCRectf *roi, int *ROICnt ,BOX_INFO *Box, BOX_INFO *Tail);
extern void find_label_in_Box(Label *inLabel , Label *OutLabel , BOX_XYWH_DATA *Box);
extern void copy_one_label(Label *inLabel , Label *outLabel , int in_idx , int out_idx);
