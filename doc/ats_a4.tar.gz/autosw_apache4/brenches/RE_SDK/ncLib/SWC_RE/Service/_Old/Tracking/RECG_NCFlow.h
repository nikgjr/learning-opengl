#include "../RECG_typedef.h"
#include "../common.h"

#define CALC_NCC_BASIC	0
#define CALC_NCC_FLIP	1

void MedianFlow(unsigned char *pre, unsigned char *cur, NCSize ImageSize , MODValue *ModVal,BOX_INFO *inBox, BOX_INFO *outBox, int mode);

void NCC_MedianFlow(NCSize ImageSize , MODValue *Mod,BOX_INFO *inBox, BOX_INFO *outBox, int mode);

void Find_Points_ROI(BOX_XYWH_DATA *ROI, MODValue *MOD, MODValue *outMOD, int mode);

void Check_NCC(unsigned char *pre , unsigned char *cur, NCSize ImageSize, MODValue *ModVal, char *filter_status);
void Check_NCC2(NCSize ImageSize, MODValue *ModVal, char *status);

BOOL Read_Patch_Image(unsigned char *img, NCSize ImageSize, NCSize size, NCPointf p , unsigned char **out);
BOOL Read_Patch_Image_Static(unsigned char *img, NCSize ImageSize , NCSize size, NCPointf p ,unsigned char out[][PATCH_SIZE]);
BOOL Read_FLIP_Patch_Image_Static(unsigned char *img, NCSize ImageSize , NCSize size, NCPointf p ,unsigned char out[][PATCH_SIZE]);

double _2Array_Sum(unsigned char **img, NCSize ImageSize);
double _2Array_Sum_Static(unsigned char img[][PATCH_SIZE], NCSize ImageSize);
double _2Array_DotMatrix(unsigned char **p1, unsigned char **p2, NCSize size);

double _2Array_DotMatrix_Static(unsigned char p1[][PATCH_SIZE], unsigned char p2[][PATCH_SIZE] , NCSize size);
double _2Array_DotMatrix_Static_1(unsigned char p1[][PATCH_SIZE], unsigned char p2[][PATCH_SIZE] , NCSize size);
double _2Array_DotMatrix_Static_2(unsigned char p1[][PATCH_SIZE], unsigned char p2[][PATCH_SIZE] , NCSize size);

double GetMedian(double *values,int size);

double GetWeightMedian(double *values,int size, int width);

void NCSort(double *inval, double *outval, int size);

double L2Distance(NCPointf p1, NCPointf p2);

NCRectf Vote_MOD(BOX_XYWH_DATA *inBox, MODValue *modBox, NCPointf *md);

extern float Cal_NCC(unsigned char *img0 , unsigned char *img1, NCSize ImageSize , NCSize PatchSize , NCPointf p0, NCPointf p1 , int mode);

extern double NC_sqrt(double val);
