/*#---------------------------------------------------------------------
#
# Copyright Processor Group, 2006-2016, All rights reserved.
# Processor Group, System-on-Chip Research Department
# Electronics and Telecommunications Research Institute (ETRI)
#
# THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE
# WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS
# TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE
# REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL
# SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE,
# IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE
# COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
#
#
#------------------------------------------------------------------------*/
#include "common.h"
#include "A4_AdasIp.h"

//volatile unsigned int ScalerStartOn = 0;

volatile unsigned int VomBuffChCnt=0;
unsigned char A4_RecgScaler_Test(void)
{
	volatile static unsigned char cnt=0;
	char item;

	//item = ab_uart_get_data(puart);	// UART 1
	//item = read_user_input();			// UART 0
	item = 0;
	if (('0' <= item) && (item <= '9'))
	{
		//	640 x 480 image start address
		//	512 x 384 image start address
		//	412 x 308 image start address
		//	320 x 240 image start address
		//	160 x 120 image start address
		//	80	x 60  image start address
		//	128 x 96  image start address
		//	104 x 57  image start address
		if (item == '1')
		{
			if(cnt<32)	cnt++;
		}
		else if (item == '2')
		{
			if(cnt>0)	cnt--;
		}
		else if (item == '0')
		{
			cnt=0;
		}

		//ab_uart_putc(puart, Hex2Ascii(((unsigned char)cnt&0xF0)>>4));
		//ab_uart_putc(puart, Hex2Ascii((unsigned char)cnt&0x0F));
		//ab_uart_putc(puart, '\n');
/*
		if(cnt==0)	vc_config();
		if(cnt==1)	vc_config_nc(FM0_START_ADDR+(ADAS_WIDTH_0 * ADAS_HEIGHT_0 * 0), ADAS_WIDTH_0, ADAS_HEIGHT_0);
		if(cnt==2)	vc_config_nc(FM0_START_ADDR+(ADAS_WIDTH_0 * ADAS_HEIGHT_0 * 1), ADAS_WIDTH_0, ADAS_HEIGHT_0);
		if(cnt==3)	vc_config_nc(FM0_START_ADDR+(ADAS_WIDTH_0 * ADAS_HEIGHT_0 * 2), ADAS_WIDTH_0, ADAS_HEIGHT_0);
		if(cnt==4)	vc_config_nc(FM0_START_ADDR+(ADAS_WIDTH_0 * ADAS_HEIGHT_0 * 3), ADAS_WIDTH_0, ADAS_HEIGHT_0);

		if(cnt==5)	vc_config_nc(FM2_START_ADDR+(ADAS_WIDTH_2 * ADAS_HEIGHT_2 * 0), ADAS_WIDTH_2, ADAS_HEIGHT_2);
		if(cnt==6)	vc_config_nc(FM2_START_ADDR+(ADAS_WIDTH_2 * ADAS_HEIGHT_2 * 1), ADAS_WIDTH_2, ADAS_HEIGHT_2);
		if(cnt==7)	vc_config_nc(FM2_START_ADDR+(ADAS_WIDTH_2 * ADAS_HEIGHT_2 * 2), ADAS_WIDTH_2, ADAS_HEIGHT_2);
		if(cnt==8)	vc_config_nc(FM2_START_ADDR+(ADAS_WIDTH_2 * ADAS_HEIGHT_2 * 3), ADAS_WIDTH_2, ADAS_HEIGHT_2);

		if(cnt==9)	vc_config_nc(FM4_START_ADDR+(ADAS_WIDTH_4 * ADAS_HEIGHT_4 * 0), ADAS_WIDTH_4, ADAS_HEIGHT_4);
		if(cnt==10) vc_config_nc(FM4_START_ADDR+(ADAS_WIDTH_4 * ADAS_HEIGHT_4 * 1), ADAS_WIDTH_4, ADAS_HEIGHT_4);
		if(cnt==11) vc_config_nc(FM4_START_ADDR+(ADAS_WIDTH_4 * ADAS_HEIGHT_4 * 2), ADAS_WIDTH_4, ADAS_HEIGHT_4);
		if(cnt==12) vc_config_nc(FM4_START_ADDR+(ADAS_WIDTH_4 * ADAS_HEIGHT_4 * 3), ADAS_WIDTH_4, ADAS_HEIGHT_4);

		if(cnt==13) vc_config_nc(FM6_START_ADDR+(ADAS_WIDTH_6 * ADAS_HEIGHT_6 * 0), ADAS_WIDTH_6, ADAS_HEIGHT_6);
		if(cnt==14) vc_config_nc(FM6_START_ADDR+(ADAS_WIDTH_6 * ADAS_HEIGHT_6 * 1), ADAS_WIDTH_6, ADAS_HEIGHT_6);
		if(cnt==15) vc_config_nc(FM6_START_ADDR+(ADAS_WIDTH_6 * ADAS_HEIGHT_6 * 2), ADAS_WIDTH_6, ADAS_HEIGHT_6);
		if(cnt==16) vc_config_nc(FM6_START_ADDR+(ADAS_WIDTH_6 * ADAS_HEIGHT_6 * 3), ADAS_WIDTH_6, ADAS_HEIGHT_6);

		if(cnt==17) vc_config_nc(FMc_START_ADDR+(ADAS_WIDTH_c * ADAS_HEIGHT_c * 0), ADAS_WIDTH_c, ADAS_HEIGHT_c);
		if(cnt==18) vc_config_nc(FMc_START_ADDR+(ADAS_WIDTH_c * ADAS_HEIGHT_c * 1), ADAS_WIDTH_c, ADAS_HEIGHT_c);
		if(cnt==19) vc_config_nc(FMc_START_ADDR+(ADAS_WIDTH_c * ADAS_HEIGHT_c * 2), ADAS_WIDTH_c, ADAS_HEIGHT_c);
		if(cnt==20) vc_config_nc(FMc_START_ADDR+(ADAS_WIDTH_c * ADAS_HEIGHT_c * 3), ADAS_WIDTH_c, ADAS_HEIGHT_c);

		if(cnt==21) vc_config_nc(FM12_START_ADDR+(ADAS_WIDTH_12 * ADAS_HEIGHT_12 * 0), ADAS_WIDTH_12, ADAS_HEIGHT_12);
		if(cnt==22) vc_config_nc(FM12_START_ADDR+(ADAS_WIDTH_12 * ADAS_HEIGHT_12 * 1), ADAS_WIDTH_12, ADAS_HEIGHT_12);
		if(cnt==23) vc_config_nc(FM12_START_ADDR+(ADAS_WIDTH_12 * ADAS_HEIGHT_12 * 2), ADAS_WIDTH_12, ADAS_HEIGHT_12);
		if(cnt==24) vc_config_nc(FM12_START_ADDR+(ADAS_WIDTH_12 * ADAS_HEIGHT_12 * 3), ADAS_WIDTH_12, ADAS_HEIGHT_12);

		if(cnt==25) vc_config_nc(FMe_START_ADDR+(ADAS_WIDTH_e * ADAS_HEIGHT_e * 0), ADAS_WIDTH_e, ADAS_HEIGHT_e);
		if(cnt==26) vc_config_nc(FMe_START_ADDR+(ADAS_WIDTH_e * ADAS_HEIGHT_e * 1), ADAS_WIDTH_e, ADAS_HEIGHT_e);
		if(cnt==27) vc_config_nc(FMe_START_ADDR+(ADAS_WIDTH_e * ADAS_HEIGHT_e * 2), ADAS_WIDTH_e, ADAS_HEIGHT_e);
		if(cnt==28) vc_config_nc(FMe_START_ADDR+(ADAS_WIDTH_e * ADAS_HEIGHT_e * 3), ADAS_WIDTH_e, ADAS_HEIGHT_e);

		if(cnt==29) vc_config_nc(FM10_START_ADDR+(ADAS_WIDTH_10 * ADAS_HEIGHT_10 * 0), ADAS_WIDTH_10, ADAS_HEIGHT_10);
		if(cnt==30) vc_config_nc(FM10_START_ADDR+(ADAS_WIDTH_10 * ADAS_HEIGHT_10 * 1), ADAS_WIDTH_10, ADAS_HEIGHT_10);
		if(cnt==31) vc_config_nc(FM10_START_ADDR+(ADAS_WIDTH_10 * ADAS_HEIGHT_10 * 2), ADAS_WIDTH_10, ADAS_HEIGHT_10);
		if(cnt==32) vc_config_nc(FM10_START_ADDR+(ADAS_WIDTH_10 * ADAS_HEIGHT_10 * 3), ADAS_WIDTH_10, ADAS_HEIGHT_10);
*/
	}
	return cnt;
}

volatile unsigned int ScalerIntOn = 0;
void A4_RECG_SCALER_ISR_Handler(void)
{
	volatile static unsigned int ScalerStartOn = 0;



	if(sReScalerReg->Reg.RES_START_INT)
	{
		sReScalerReg->Reg.RES_START_INT_CLR = 1;
		sReScalerReg->Reg.RES_START_INT_CLR = 0;

		ScalerStartOn = 1;
		ScalerIntOn = 1;
#ifdef	_DIS_G11_ON
		Gpio_Set(11,GPIO_HIGH);
#endif

	}
	else if(sReScalerReg->Reg.RES_ERROR_INT)
	{
		sReScalerReg->Reg.RES_ERROR_INT_CLR = 1;
		sReScalerReg->Reg.RES_ERROR_INT_CLR = 0;
		//JIGMSG("RES_ERROR\n");

	}
	else if(sReScalerReg->Reg.RES_END_INT)
	{
		sReScalerReg->Reg.RES_END_INT_CLR = 1;
		sReScalerReg->Reg.RES_END_INT_CLR = 0;

		VomBuffChCnt = (sReScalerReg->Reg.FM0_WBUF_CNT - 2) & 0x00000003;
		//JIGMSG("sReScalerReg->Reg.FM0_WBUF_CNT = %d \n",sReScalerReg->Reg.FM0_WBUF_CNT);

		AdasStatus.Reg.RdBufSelHsv = AdasStatus.Reg.WrBufSelHsv;
		//AdasStatus.Reg.WrBufSelHsv = ~ AdasStatus.Reg.WrBufSelHsv;

#ifdef	_DIS_G11_ON
		Gpio_Set(11,GPIO_LOW);
#endif
		if(ScalerStartOn)
		{
			ScalerStartOn = 0;
			ScalerIntOn = 0;
		}
	}
	else if(sReScalerReg->Reg.RES_PSEUDO_END_INT)
	{
		sReScalerReg->Reg.RES_PSEUDO_END_INT_CLR = 1;
		sReScalerReg->Reg.RES_PSEUDO_END_INT_CLR = 0;
		JIGMSG("RES_SUDO\n");
		if(ScalerStartOn)
		{
			ScalerStartOn = 0;
			ScalerIntOn = 0;
		}
	}




    //abbd_intc_core_ifr_off(RECG_SCALER_IRQ);
}

//----------------------------------
void A4_RecgScaler_Init (void)
{
	JIGMSG("@@ RECG Scaler Init. start\n");
	sReScalerReg->Reg.RES_FM0_Y_EN 	 	 = 1;
	sReScalerReg->Reg.RES_FM2_Y_EN		 = 0;
	sReScalerReg->Reg.RES_FM4_Y_EN		 = 0;
	sReScalerReg->Reg.RES_FM6_Y_EN		 = 0;
	sReScalerReg->Reg.RES_FMc_Y_EN		 = 0;
	sReScalerReg->Reg.RES_FMe_Y_EN		 = 0;
	sReScalerReg->Reg.RES_FM10_Y_EN	 	= 0;
	sReScalerReg->Reg.RES_FM12_Y_EN	 	= 0;
	sReScalerReg->Reg.RES_WIDE_FM0_Y_EN = 0;
	sReScalerReg->Reg.RES_WIDE_FM2_Y_EN = 0;
	sReScalerReg->Reg.RES_WIDE_FM4_Y_EN = 0;

	sReScalerReg->Reg.RES_FM0_C_EN		 = 1;
	sReScalerReg->Reg.RES_FM2_C_EN		 = 0;
	sReScalerReg->Reg.RES_FM4_C_EN		 = 0;
	sReScalerReg->Reg.RES_FM6_C_EN		 = 0;//
	sReScalerReg->Reg.RES_FMc_C_EN		 = 0;
	sReScalerReg->Reg.RES_FMe_C_EN		 = 0;
	sReScalerReg->Reg.RES_FM10_C_EN	 = 0;
	sReScalerReg->Reg.RES_FM12_C_EN	 = 0;//
	sReScalerReg->Reg.RES_WIDE_FM0_C_EN = 0;
	sReScalerReg->Reg.RES_WIDE_FM2_C_EN = 0;
	sReScalerReg->Reg.RES_WIDE_FM4_C_EN = 0;
	// recg_scaler image start address
	sReScalerReg->Reg.RES_FM0_BASE_ADDR  = FM0_START_ADDR	;    	//  640 x 480 image start address
	sReScalerReg->Reg.RES_FM2_BASE_ADDR  = FM2_START_ADDR	;    	//  512 x 384 image start address
	sReScalerReg->Reg.RES_FM4_BASE_ADDR  = FM4_START_ADDR	;    	//  412 x 308 image start address
	sReScalerReg->Reg.RES_FM6_BASE_ADDR  = FM6_START_ADDR	;    	//  320 x 240 image start address
	sReScalerReg->Reg.RES_FMc_BASE_ADDR  = FMc_START_ADDR	;    	//  160 x 120 image start address
	sReScalerReg->Reg.RES_FM12_BASE_ADDR = FM12_START_ADDR	;   	//  80  x 60  image start address
	sReScalerReg->Reg.RES_FMe_BASE_ADDR  = FMe_START_ADDR	;    	//  128 x 96  image start address
	sReScalerReg->Reg.RES_FM10_BASE_ADDR = FM10_START_ADDR	;	//  104 x 57  image start address

	sReScalerReg->Reg.RES_WIDE_FM0_BASE_ADDR = FM18_START_ADDR;
	sReScalerReg->Reg.RES_WIDE_FM2_BASE_ADDR = FM1a_START_ADDR;
	sReScalerReg->Reg.RES_WIDE_FM4_BASE_ADDR = FM1c_START_ADDR;


	sReScalerReg->Reg.RES_FM0_H_SIZE = adas_size.width_0;
	sReScalerReg->Reg.RES_FM0_V_SIZE = adas_size.height_0;     	// FM00 H_V_SIZE 640 X 360
	sReScalerReg->Reg.RES_FM2_H_SIZE = adas_size.width_2;
	sReScalerReg->Reg.RES_FM2_V_SIZE = adas_size.height_2;		// FM02 H_V_SIZE 512 X 288
	sReScalerReg->Reg.RES_FM4_H_SIZE = adas_size.width_4;
	sReScalerReg->Reg.RES_FM4_V_SIZE = adas_size.height_4;		// FM04 H_V_SIZE 412 X 230

	sReScalerReg->Reg.RES_WIDE_FM0_H_SIZE = adas_size.wide_width_0	;
	sReScalerReg->Reg.RES_WIDE_FM0_V_SIZE = adas_size.wide_height_0;
	sReScalerReg->Reg.RES_WIDE_FM2_H_SIZE = adas_size.wide_width_2	;
	sReScalerReg->Reg.RES_WIDE_FM2_V_SIZE = adas_size.wide_height_2;
	sReScalerReg->Reg.RES_WIDE_FM4_H_SIZE = adas_size.wide_width_4	;
	sReScalerReg->Reg.RES_WIDE_FM4_V_SIZE = adas_size.wide_height_4;

	sReVdpdReg->Reg.REC_FMc_H_SIZE  = sReScalerReg->Reg.RES_FM0_H_SIZE/4;
	sReVdpdReg->Reg.REC_FMc_V_SIZE  = sReScalerReg->Reg.RES_FM0_V_SIZE/4;
	sReVdpdReg->Reg.REC_FMe_H_SIZE  = sReScalerReg->Reg.RES_FM2_H_SIZE/4;
	sReVdpdReg->Reg.REC_FMe_V_SIZE  = sReScalerReg->Reg.RES_FM2_V_SIZE/4;
	sReVdpdReg->Reg.REC_FM10_H_SIZE = sReScalerReg->Reg.RES_FM4_H_SIZE/4;
	sReVdpdReg->Reg.REC_FM10_V_SIZE = sReScalerReg->Reg.RES_FM4_V_SIZE/4;
#ifdef BUFF_SIMPLE
	// this sReScalerReg->Reg.RES_FM0_FRC_MODE  is already define in A4_AdasIp.c
	sReScalerReg->Reg.RES_FM0_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM2_FRC_MODE  = 1;
	sReScalerReg->Reg.RES_FM4_FRC_MODE  = 1;
	sReScalerReg->Reg.RES_FM6_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FMc_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM12_FRC_MODE = 3;
	sReScalerReg->Reg.RES_FMe_FRC_MODE  = 1;
	sReScalerReg->Reg.RES_FM10_FRC_MODE = 1;

	sReScalerReg->Reg.RES_WIDE_FM0_FRC_MODE = 1;
	sReScalerReg->Reg.RES_WIDE_FM2_FRC_MODE = 1;
	sReScalerReg->Reg.RES_WIDE_FM4_FRC_MODE = 1;
#else
	sReScalerReg->Reg.RES_FM0_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM2_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM4_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM6_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FMc_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM12_FRC_MODE = 3;
	sReScalerReg->Reg.RES_FMe_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM10_FRC_MODE = 3;
#endif


	sReScalerReg->Reg.FRAME_SKIP_CNT = 0;

	sReScalerReg->Reg.RES_START_INT_CLR = 0;
	sReScalerReg->Reg.RES_END_INT_CLR = 0;
	sReScalerReg->Reg.RES_PSEUDO_END_INT_CLR = 0;
	sReScalerReg->Reg.RES_ERROR_INT_CLR = 0;

	sReScalerReg->Reg.RES_START_INT_EN 	= 1;
	sReScalerReg->Reg.RES_END_INT_EN 		= 1;
	sReScalerReg->Reg.RES_PSEUDO_END_INT_EN 	= 0;
	sReScalerReg->Reg.RES_ERROR_INT_EN 	= 0;

	#ifdef	_INT_PULSE_ON
		sReScalerReg->Reg.INT_PULSE_EN = 1;
	#else
		sReScalerReg->Reg.INT_PULSE_EN = 0;
	#endif

	///////////////////////////////////////////////////////////
#if 1
	//sReScalerReg->Reg.FRAME_TOT_PIX_CNT = 0x00;//0x00447FF0;

	sReScalerReg->Reg.PSEUDO_END_CNT = 0xFA;//0x00447FF0;


/*
 *
 * change by checksum * checksum is added in this address.
 *
 *
	sReScalerReg->Reg.IN_HACT_INV = 0;
	sReScalerReg->Reg.IN_VSYNC_INV = 1;
	sReScalerReg->Reg.IN_DATA_SHUFFLE0 = 0;
	sReScalerReg->Reg.IN_DATA_SHUFFLE1 = 0;

	sReScalerReg->Reg.VS_MODE = 0;
	sReScalerReg->Reg.H_TOTAL = 1716;//5912;

	sReScalerReg->Reg.H_ACT = ADAS_WIDTH_0*2;
	sReScalerReg->Reg.V_ACT = ADAS_HEIGHT_0;
*/
	//WRITE(RECG_SCALER_OFFSET + 0x0A8, 1<<16 | 5913<<0);	// // VS_MODE[16]=0, H_TOTAL[12:0]=5913
	//WRITE(RECG_SCALER_OFFSET + 0x0AC, 480<<16 | 640<<0);	// // V_ACT[26:16]=360, H_ACT[10:0]=640
#endif

	#ifdef	_SCALER_INT_EN
	//ncLib_INTC_Control(GCMD_INTC_SET_TRIG_MODE, IRQ_NUM_RE_SCALER, TRIG_EDGE_HIGH, CMD_END);
	if( ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_RE_SCALER, (PrVoid)A4_RECG_SCALER_ISR_Handler, CMD_END) != NC_SUCCESS )
	{
		DEBUGMSG_SDK(MSGERR, "SCALER_INIT ERROR\n");
	}
	#endif

	JIGMSG("@@ RECG Scaler Init. done\n");

}

