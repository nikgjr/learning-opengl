#ifndef __RE_POST_TG_REGISTER_H__
#define __RE_POST_TG_REGISTER_H__

/*=============================================================================
	Definitions for Register Start Address, End Address, Size
=============================================================================*/
#define	RE_POST_TG_REGISTER_SIZE	0x200

typedef union
{
	UINT32 Data[RE_POST_TG_REGISTER_SIZE/4];
	struct
	{
        /* 0x0000[00] */ UINT32	DSP_OUT_TG_MODE:		2;
        /* 0x0000[02] */ UINT32	Rev0000_02:				14;
        /* 0x0000[16] */ UINT32	DSP_OUT_TG_EN:			1;
        /* 0x0000[17] */ UINT32	Rev0000_17:				15;

        /* 0x0004[00] */ UINT32	DSP_OUT_BP_H_ACT:		16;
        /* 0x0004[16] */ UINT32	DSP_OUT_BP_H_TOTAL:		16;

        /* 0x0008[00] */ UINT32	DSP_OUT_BP_V_ACT:		16;
        /* 0x0008[16] */ UINT32	DSP_OUT_BP_VS_MODE:		1;
        /* 0x0008[17] */ UINT32	Rev0008_17:				3;
        /* 0x0008[20] */ UINT32	DSP_OUT_SKIP_CNT:		3;
        /* 0x0008[23] */ UINT32	Rev0008_23:				1;
        /* 0x0008[24] */ UINT32	DSP_OUT_FL_VS_SEL:		2;	// 0-recg_scale, 1-recg_engine, 2-pre_ddr
        /* 0x0008[26] */ UINT32	Rev0008_26:				6;

        /* 0x000C[00] */ UINT32	DSP_OUT_FL_VS_V_S_PNT:	16;
        /* 0x000C[16] */ UINT32	DSP_OUT_FL_VS_H_S_PNT:	16;

        /* 0x0010[00] */ UINT32	DSP_OUT_FL_H_ACT:		16;
        /* 0x0010[16] */ UINT32	DSP_OUT_FL_H_TOTAL:		16;

        /* 0x0014[00] */ UINT32	DSP_OUT_FL_V_ACT:		16;
        /* 0x0014[16] */ UINT32	DSP_OUT_FL_V_TOTAL:		16;

        /* 0x0018[00] */ UINT32	DSP_OUT_FL_V_BLK2:		16;
        /* 0x0018[16] */ UINT32	DSP_OUT_FL_V_BLK1:		16;

        /* 0x001C[00] */ UINT32	DSP_OUT_FR_H_ACT:		16;
        /* 0x001C[16] */ UINT32	DSP_OUT_FR_H_TOTAL:		16;

        /* 0x0020[00] */ UINT32	DSP_OUT_FR_V_ACT:		16;
        /* 0x0020[16] */ UINT32	DSP_OUT_FR_V_TOTAL:		16;

        /* 0x0024[00] */ UINT32	DSP_OUT_FR_V_BLK2:		16;
        /* 0x0024[16] */ UINT32	DSP_OUT_FR_V_BLK1:		16;

		/* 0x0028[00] */ UINT32	Rev0028_00[(0x200-0x028)/4];
	}Reg;
}RE_POST_TG_REGISTER;

#endif


