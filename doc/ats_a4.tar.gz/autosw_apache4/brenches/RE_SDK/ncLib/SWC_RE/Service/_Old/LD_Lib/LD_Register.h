#ifndef _LD_REGISTER_H_
#define _LD_REGISTER_H_


typedef union{
	unsigned int DATA32[0x100 / 4];

	struct{
		/*0x0000 00*/	unsigned int InitOn;

		/*0x0004 00*/	unsigned int YuvMode;

		/*0x0010 00*/	unsigned int VpX;
		/*0x0010 10*/	unsigned int VpY;
		/*0x0010 20*/	unsigned int EndY;
		/*0x0010 30*/	unsigned int ViewVStrEnd;

		/*0x0014 00*/	unsigned int CamH;
		/*0x0014 00*/	unsigned int CamF;
		/*0x0014 00*/	unsigned int SenC;

		/*0x0018 00*/	unsigned int LdImgWidth;
		/*0x0018 00*/	unsigned int LdImgHeight;

		/*0x001C 00*/	unsigned int TvImgWidth;
		/*0x001C 00*/	unsigned int TvImgHeight;

		/*0x0020 00*/	unsigned int DiffTh;
		/*0x0020 00*/	unsigned int YTh;
		/*0x0020 00*/	unsigned int CbTh;
		/*0x0020 00*/	unsigned int CrTh;

		/*0x0024 00*/	unsigned int UTh;
		/*0x0024 00*/	unsigned int VTh;
		/*0x0024 00*/	unsigned int LaneDiff;


		/*0x0050 00*/	unsigned int Rev_0050[(0x0100-0x0050) / 4];

	}REG;

}LD_REGISTER;


#endif // !_LD_REGISTER_H_


