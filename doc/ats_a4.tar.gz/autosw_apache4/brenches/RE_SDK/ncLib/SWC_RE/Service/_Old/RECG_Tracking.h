#include "common.h"
#include "RECG_typedef.h"

#define TAIL_TRACKING 0
//#define MAX_TRACK_NUM 30

//typedef struct
//{
//	int CurPoint;
//	char UseNumber[MAX_TRACK_NUM];
//}IDNumber;


extern void initial_Box(BOX_INFO *Box, IDNumber *ID);
extern void box_scale_convert(BOX_INFO *in , BOX_INFO *out, int mode);

extern void HK_Tracking(BOX_INFO *PreTrack, BOX_INFO *Track , BOX_INFO *Det, BOX_INFO *Out, IDNumber *ID , int mode);
extern void Tracking_Tail(BOX_INFO *PreTrack, BOX_INFO *Track , BOX_INFO *Det, BOX_INFO *Out, BOX_INFO *Tail, IDNumber *ID, int mode);
extern void initial_ID(IDNumber *ID);

extern void Remove_Invalid_Box(BOX_INFO *in , BOX_INFO *out);

extern void Tracking_DetTrue_TrackingTrue(BOX_XYWH_DATA *Track , BOX_XYWH_DATA *Det, BOX_XYWH_DATA *Pre, BOX_XYWH_DATA *Out, BOX_INFO *Tail,int index ,unsigned int *BoxNum, int mode);
extern void Tracking_DetNon_TrackingTrue(BOX_XYWH_DATA *Track , BOX_XYWH_DATA *Pre, BOX_XYWH_DATA *Out, BOX_INFO *Tail,int index, unsigned int *BoxNum, int mode);
extern void Tracking_DetNon_TrackingFail(BOX_XYWH_DATA *Track , BOX_XYWH_DATA *Pre, BOX_XYWH_DATA *Out, BOX_INFO *Tail,int index,unsigned int *BoxNum, int mode);
extern void Tracking_DetTrue_TrackingFail(BOX_XYWH_DATA *Track , BOX_XYWH_DATA *Det, BOX_XYWH_DATA *Pre, BOX_XYWH_DATA *Out, BOX_INFO *Tail,int index, unsigned int *BoxNum, int mode);

