#ifndef _NCLD_REGISTER_H_
#define _NCLD_REGISTER_H_

typedef struct{
	int x;
	int y;
}POINT_XY;

typedef struct{
	POINT_XY	Lane[20];
	int 		LaneCnt;
}NCLD_LANE_REGISTER;

typedef union{
	unsigned int DATA32[0x100 / 4];

	struct{
		/*0x0000 00*/	unsigned int VpX:			10;
		/*0x0000 10*/	unsigned int VpY:			10;
		/*0x0000 20*/	unsigned int EndY:			10;
		/*0x0000 30*/	unsigned int ViewVStrEnd:	1;
		/*0x0000 31*/	unsigned int Rev_0000_31:	1;

		/*0x0004 00*/	unsigned int BoxOverlap:	2;
		/*0x0004 02*/	unsigned int Rev_0004_2:	30;

		/*0x0008 00*/	unsigned int Rev_0008[(0x0100-0x0008) / 4];
	}REG;

}NCLD_REGISTER;


#endif // !_NCLD_REGISTER_H_


