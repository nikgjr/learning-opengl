#ifndef __RE_STATUS_REGISTER_H__
#define __RE_STATUS_REGISTER_H__

/*=============================================================================
	Definitions for Register Start Address, End Address, Size
=============================================================================*/
#define RE_STATUS_REGISTER_SIZE 			0x200


/*=============================================================================

=============================================================================*/

typedef struct
{
	unsigned char	EndY;
	unsigned char	StartY;
}RECG_DETECTION_AREA;

typedef union
{
	unsigned int Data[2];
	struct
	{
		 unsigned int	FxAcfRejectTh:  		16;
		 unsigned int	FxAcfTh:  				16;

		 unsigned int	FxAcfRejectWeakCnt:		16;
		 unsigned int	FxAcfWeakCnt:			16;
	}Reg;
}Fx_ACF_VALUE;
/*=============================================================================

=============================================================================*/

typedef union
{
	unsigned int Data[RE_STATUS_REGISTER_SIZE/4];
	struct
	{
	  	  /* 0x0000[00] */ unsigned int DisModeSel:    4;
		  /* 0x0000[04] */ unsigned int ClusteringBoxDisOn:  1;
		  /* 0x0000[05] */ unsigned int FrameBufCnt:   3;
		  /* 0x0000[08] */ unsigned int ResolutionSel:   4;
		  /* 0x0000[12] */ unsigned int Frame_skip:    3;
		  /* 0x0000[15] */ unsigned int Rev0000_12:    16;
		  /* 0x0000[31] */ unsigned int RecgDisMax64On:   1;//


		  /* 0x0004 [00] */ unsigned int FilterCompareMode0 : 1 ;
		  /* 0x0004 [01] */ unsigned int FilterCompareMode1 : 1 ;
		  /* 0x0004 [02] */ unsigned int FilterCompareMode2 : 1 ;
		  /* 0x0004 [03] */ unsigned int FilterCompareMode3 : 1 ;
		  /* 0x0004 [04] */ unsigned int FilterCompareMode4 : 1 ;
		  /* 0x0004 [05] */ unsigned int FilterCompareMode5 : 1 ;
		  /* 0x0004 [06] */ unsigned int FilterCompareMode6 : 1 ;
		  /* 0x0004 [07] */ unsigned int FilterCompareMode7 : 1 ;
		  /* 0x0004[08] */ unsigned int Rev0004_08:      24;

		  /* 0x0008[00] */ Fx_ACF_VALUE	FxAcfValue[8]			; //0x0008~0x0047

		  /* 0x0048 [00] */ unsigned int status_flag00 : 1 ;
		  /* 0x0048 [01] */ unsigned int status_flag01 : 1 ;
		  /* 0x0048 [02] */ unsigned int status_flag02 : 1 ;
		  /* 0x0048 [03] */ unsigned int status_flag03 : 1 ;
		  /* 0x0048 [04] */ unsigned int status_flag04 : 1 ;
		  /* 0x0048 [05] */ unsigned int status_flag05 : 1 ;
		  /* 0x0048 [06] */ unsigned int status_flag06 : 1 ;
		  /* 0x0048 [07] */ unsigned int status_flag07 : 1 ;
		  /* 0x0048 [08] */ unsigned int status_flag08 : 1 ;
		  /* 0x0048 [09] */ unsigned int status_flag09 : 1 ;
		  /* 0x0048 [10] */ unsigned int status_flag10 : 1 ;
		  /* 0x0048 [11] */ unsigned int status_flag11 : 1 ;
		  /* 0x0048 [12] */ unsigned int status_flag12 : 1 ;
		  /* 0x0048 [13] */ unsigned int status_flag13 : 1 ;
		  /* 0x0048 [14] */ unsigned int start_status:   2;
		  /* 0x0048 [16] */ unsigned int Rev0048_16 : 16 ;


		/* 0x01F8[00] */ unsigned int	Rev01F4_00[(0x200-0x04C)/4];
	}Reg;
}RE_STATUS_REGISTER;

#endif


