#ifndef __RE_POST_REGISTER_H__
#define __RE_POST_REGISTER_H__

/*=============================================================================
	Definitions for Register Start Address, End Address, Size
=============================================================================*/
#define	RE_POST_REGISTER_SIZE	0x200

typedef union
{
	UINT32 Data[RE_POST_REGISTER_SIZE/4];
	struct
	{
        /* 0x0000[00] */ UINT32	H_MIRROR:				1;
        /* 0x0000[01] */ UINT32	Rev0000_01:				31;

        /* 0x0004[00] */ UINT32	RD_BUFF_M_EN:			1;
        /* 0x0004[01] */ UINT32	Rev0004_01:				15;
        /* 0x0004[16] */ UINT32	RD_BUFF_M_CNT:			2;
        /* 0x0004[18] */ UINT32	Rev0004_18:				14;

        /* 0x0008[00] */ UINT32	RD_YC_EN_MODE:			3;
        /* 0x0008[03] */ UINT32	Rev0008_03:				5;
        /* 0x0008[08] */ UINT32	RD_PASS_SEL:			2;
        /* 0x0008[10] */ UINT32	Rev0008_10:				2;
        /* 0x0008[12] */ UINT32	RD_BUF_SEL:				1;
        /* 0x0008[13] */ UINT32	Rev0008_13:				3;
        /* 0x0008[16] */ UINT32	RD_BL:					5;
        /* 0x0008[21] */ UINT32	Rev0008_21:				3;
        /* 0x0008[24] */ UINT32	RD_FRC_MODE:			2;
        /* 0x0008[26] */ UINT32	RD_BUF_MODE:			2;
		/* 0x0008[28] */ UINT32	Rev0008_28:				3;
		/* 0x0008[31] */ UINT32	O_PATH_SEL:				1;


        /* 0x000C[00] */ UINT32	RD_HSIZE:				11;
        /* 0x000C[11] */ UINT32	Rev000C_11:				5;
        /* 0x000C[16] */ UINT32	RD_VSIZE:				11;
        /* 0x000C[27] */ UINT32	Rev000C_27:				5;

        /* 0x0010[00] */ UINT32	RD_BASE_ADDR:			32;

        /* 0x0014[00] */ UINT32	O_SEL_CROP:				1;
        /* 0x0014[01] */ UINT32	O_CROP_SYNC_EN:			1;
        /* 0x0014[02] */ UINT32	Rev0014_02:				30;

        /* 0x0018[00] */ UINT32	O_CROP_VPOS:			11;
        /* 0x0018[11] */ UINT32	Rev0018_11:				5;
        /* 0x0018[16] */ UINT32	O_CROP_VSIZE:			11;
        /* 0x0018[27] */ UINT32	Rev0018_27:				5;

        /* 0x001C[00] */ UINT32	O_CROP_HPOS:			11;
        /* 0x001C[11] */ UINT32	Rev001C_11:				5;
        /* 0x001C[16] */ UINT32	O_CROP_HSIZE:			11;
        /* 0x001C[27] */ UINT32	Rev001C_27:				5;

        /* 0x0020[00] */ UINT32	O_CROP_HACTSIZE:		11;
        /* 0x0020[11] */ UINT32	Rev0020_11:				5;
        /* 0x0020[16] */ UINT32	O_CROP_VACTSIZE:		11;
        /* 0x0020[27] */ UINT32	Rev0020_27:				5;

        /* 0x0024[00] */ UINT32	O_SEL_CRIP:				2;
        /* 0x0024[02] */ UINT32	O_SEL_CSWAP:			1;
        /* 0x0024[03] */ UINT32	O_SEL_BGROUND:			1;
        /* 0x0024[04] */ UINT32	Rev0024_04:				28;

        /* 0x0028[00] */ UINT32	O_BG_Y:					8;
        /* 0x0028[08] */ UINT32	O_BG_CB:				8;
        /* 0x0028[16] */ UINT32	O_BG_CR:				8;
        /* 0x0028[24] */ UINT32	Rev0028_24:				8;

        /* 0x002C[00] */ UINT32	O_SEL_FREERUN_HSYNC:	2;
        /* 0x002C[02] */ UINT32	O_SEL_FREERUN_HACT:		2;
        /* 0x002C[04] */ UINT32	Rev002C_04:				28;

        /* 0x0030[00] */ UINT32	O_FR_HBLKSIZE:			11;
        /* 0x0030[11] */ UINT32	Rev0030_11:				5;
        /* 0x0030[16] */ UINT32	O_FR_VBLKSIZE:			11;
        /* 0x0030[27] */ UINT32	Rev0030_27:				5;

        /* 0x0034[00] */ UINT32	O_FR_HFPORCH:			11;
        /* 0x0034[11] */ UINT32	Rev0034_11:				5;
        /* 0x0034[16] */ UINT32	O_FR_HBPORCH:			11;
        /* 0x0034[27] */ UINT32	Rev0034_27:				5;

        /* 0x0038[00] */ UINT32	O_FR_HSYNCSIZE:			11;
        /* 0x0038[11] */ UINT32	Rev0038_11:				21;

        /* 0x003C[00] */ UINT32	O_SEL_BT601_POL                   :			3;
        /* 0x003C[03] */ UINT32	O_SEL_BT601_YCSWAP                :			1;
        /* 0x003C[04] */ UINT32	O_SEL_BT601_HSYNC_LOCK            :			1;
        /* 0x003C[05] */ UINT32	O_SEL_BT601_HSYNC_LOCK_CEA861VSYNC:			1;
        /* 0x003C[06] */ UINT32	O_SEL_BT601_HACT_LOCK             :			1;
        /* 0x003C[07] */ UINT32	O_SEL_BT601_HACT_LOCK_CEA861VSYNC :			1;
        /* 0x003C[08] */ UINT32	O_SEL_BT601_LOCK_VSYNCPOL         :			1;
        /* 0x003C[09] */ UINT32	O_SEL_BT601_HSYNC2HACT            :			1;
        /* 0x003C[10] */ UINT32	Rev003C_10:									22;

        /* 0x0040[00] */ UINT32	O_601_CEA861_EN:		3;
        /* 0x0040[03] */ UINT32	Rev0040_03:				29;

        /* 0x0044[00] */ UINT32	O_601_CEA861_HSYNC_FP:	11;
        /* 0x0044[11] */ UINT32	Rev0044_11:				5;
        /* 0x0044[16] */ UINT32	O_601_CEA861_HSYNC_BLK:	11;
        /* 0x0044[27] */ UINT32	Rev0044_27:				5;

        /* 0x0048[00] */ UINT32	O_601_CEA861_VSYNC0_HDELAY:	11;
        /* 0x0048[11] */ UINT32	Rev0048_11:					5;
        /* 0x0048[16] */ UINT32	O_601_CEA861_VSYNC0_FP:		11;
        /* 0x0048[27] */ UINT32	Rev0048_27:					5;

        /* 0x004C[00] */ UINT32	O_601_CEA861_VSYNC0_BLK:	11;
        /* 0x004C[11] */ UINT32	O_601_CEA861_VSYNC0_STOPT:	1;
        /* 0x004C[12] */ UINT32	Rev004C_12:					20;

        /* 0x0050[00] */ UINT32	O_601_CEA861_VSYNC1_HDELAY:	11;
        /* 0x0050[11] */ UINT32	Rev0050_11:					5;
        /* 0x0050[16] */ UINT32	O_601_CEA861_VSYNC1_FP:		11;
        /* 0x0050[27] */ UINT32	Rev0050_27:					5;

        /* 0x0054[00] */ UINT32	O_601_CEA861_VSYNC1_BLK:	11;
        /* 0x0054[11] */ UINT32	O_601_CEA861_VSYNC1_STOPT:	1;
        /* 0x0054[12] */ UINT32	Rev0054_12:					20;

		/* 0x0058[00] */ UINT32	O_601_YBIT0_MAP:			4;
		/* 0x0058[04] */ UINT32	O_601_YBIT1_MAP:			4;
		/* 0x0058[08] */ UINT32	O_601_YBIT2_MAP:			4;
		/* 0x0058[12] */ UINT32	O_601_YBIT3_MAP:			4;
		/* 0x0058[16] */ UINT32	O_601_YBIT4_MAP:			4;
		/* 0x0058[20] */ UINT32	O_601_YBIT5_MAP:			4;
		/* 0x0058[24] */ UINT32	O_601_YBIT6_MAP:			4;
		/* 0x0058[28] */ UINT32	O_601_YBIT7_MAP:			4;

		/* 0x005C[00] */ UINT32	O_601_CBIT0_MAP:			4;
		/* 0x005C[04] */ UINT32	O_601_CBIT1_MAP:			4;
		/* 0x005C[08] */ UINT32	O_601_CBIT2_MAP:			4;
		/* 0x005C[12] */ UINT32	O_601_CBIT3_MAP:			4;
		/* 0x005C[16] */ UINT32	O_601_CBIT4_MAP:			4;
		/* 0x005C[20] */ UINT32	O_601_CBIT5_MAP:			4;
		/* 0x005C[24] */ UINT32	O_601_CBIT6_MAP:			4;
		/* 0x005C[28] */ UINT32	O_601_CBIT7_MAP:			4;

        /* 0x0060[00] */ UINT32 O_601_SEL_REF_SYNC       :	1;
        /* 0x0060[01] */ UINT32 Rev0060_01               :	7;
        /* 0x0060[08] */ UINT32 O_SEL_BT656_USINGHSYNC   :	1;
        /* 0x0060[09] */ UINT32 O_SEL_BT656_POL          :	2;
        /* 0x0060[11] */ UINT32 O_SEL_BT656_YCSWAP       :	1;
        /* 0x0060[12] */ UINT32 O_SEL_BT656_LOCK         :	1;
        /* 0x0060[13] */ UINT32 O_SEL_BT656_LOCK_VSYNCPOL:	1;
        /* 0x0060[14] */ UINT32 Rev0060_14               :	2;
        /* 0x0060[16] */ UINT32 O_656_HSYNC_ACTSIZE      :	12;
        /* 0x0060[28] */ UINT32 O_656_HSYNC_GEN          :	1;
        /* 0x0060[29] */ UINT32 Rev0060_29               :	3;

		/* 0x0064[00] */ UINT32	O_656_BIT0_MAP:				4;
		/* 0x0064[04] */ UINT32	O_656_BIT1_MAP:				4;
		/* 0x0064[08] */ UINT32	O_656_BIT2_MAP:				4;
		/* 0x0064[12] */ UINT32	O_656_BIT3_MAP:				4;
		/* 0x0064[16] */ UINT32	O_656_BIT4_MAP:				4;
		/* 0x0064[20] */ UINT32	O_656_BIT5_MAP:				4;
		/* 0x0064[24] */ UINT32	O_656_BIT6_MAP:				4;
		/* 0x0064[28] */ UINT32	O_656_BIT7_MAP:				4;

        /* 0x0068[00] */ UINT32 O_656_SEL_REF_SYNC    :		1;
        /* 0x0068[01] */ UINT32 O_656_SEL_TRC_EN      :		1;
		/* 0x0068[02] */ UINT32 Rev0068_02            :		6;
        /* 0x0068[08] */ UINT32 O_SEL_ST292_USINGHSYNC:		1;
        /* 0x0068[09] */ UINT32 O_SEL_ST292_YCSWAP    :		1;
		/* 0x0068[10] */ UINT32 Rev0068_10            :		22;

        /* 0x006C[00] */ UINT32	O_292_INSERT_STNUM:			11;
        /* 0x006C[11] */ UINT32	Rev006C_11:					5;
        /* 0x006C[16] */ UINT32	O_292_INSERT_TOTALNUM:		11;
        /* 0x006C[27] */ UINT32	Rev006C_27:					5;

		/* 0x0070[00] */ UINT32	O_292_YBIT0_MAP:			4;
		/* 0x0070[04] */ UINT32	O_292_YBIT1_MAP:			4;
		/* 0x0070[08] */ UINT32	O_292_YBIT2_MAP:			4;
		/* 0x0070[12] */ UINT32	O_292_YBIT3_MAP:			4;
		/* 0x0070[16] */ UINT32	O_292_YBIT4_MAP:			4;
		/* 0x0070[20] */ UINT32	O_292_YBIT5_MAP:			4;
		/* 0x0070[24] */ UINT32	O_292_YBIT6_MAP:			4;
		/* 0x0070[28] */ UINT32	O_292_YBIT7_MAP:			4;

		/* 0x0074[00] */ UINT32	O_292_YBIT8_MAP:			4;
		/* 0x0074[04] */ UINT32	O_292_YBIT9_MAP:			4;
		/* 0x0074[08] */ UINT32	Rev0074_08:					24;

		/* 0x0078[00] */ UINT32	O_292_CBIT0_MAP:			4;
		/* 0x0078[04] */ UINT32	O_292_CBIT1_MAP:			4;
		/* 0x0078[08] */ UINT32	O_292_CBIT2_MAP:			4;
		/* 0x0078[12] */ UINT32	O_292_CBIT3_MAP:			4;
		/* 0x0078[16] */ UINT32	O_292_CBIT4_MAP:			4;
		/* 0x0078[20] */ UINT32	O_292_CBIT5_MAP:			4;
		/* 0x0078[24] */ UINT32	O_292_CBIT6_MAP:			4;
		/* 0x0078[28] */ UINT32	O_292_CBIT7_MAP:			4;

		/* 0x007C[00] */ UINT32	O_292_CBIT8_MAP:			4;
		/* 0x007C[04] */ UINT32	O_292_CBIT9_MAP:			4;
		/* 0x007C[08] */ UINT32	O_292_SEL_TRC_EN:			1;
		/* 0x007C[08] */ UINT32	Rev007C_08:					23;


        /* 0x0080[00] */ UINT32	O_SEL_ST296_USINGHSYNC   :  1;
        /* 0x0080[01] */ UINT32	O_SEL_ST296_POL          :  2;
        /* 0x0080[03] */ UINT32	O_SEL_ST296_YCSWAP       :  1;
        /* 0x0080[04] */ UINT32	O_SEL_ST296_LOCK         :  1;
        /* 0x0080[05] */ UINT32	O_SEL_ST296_LOCK_VSYNCPOL:  1;
        /* 0x0080[06] */ UINT32	O_296_SEL_REF_SYNC       :  1;
        /* 0x0080[07] */ UINT32	O_296_SEL_TRC_EN         :  1;
        /* 0x0080[08] */ UINT32	Rev0080_08				 :	24;

		/* 0x0084[00] */ UINT32	O_296_YBIT0_MAP:			4;
		/* 0x0084[04] */ UINT32	O_296_YBIT1_MAP:			4;
		/* 0x0084[08] */ UINT32	O_296_YBIT2_MAP:			4;
		/* 0x0084[12] */ UINT32	O_296_YBIT3_MAP:			4;
		/* 0x0084[16] */ UINT32	O_296_YBIT4_MAP:			4;
		/* 0x0084[20] */ UINT32	O_296_YBIT5_MAP:			4;
		/* 0x0084[24] */ UINT32	O_296_YBIT6_MAP:			4;
		/* 0x0084[28] */ UINT32	O_296_YBIT7_MAP:			4;

		/* 0x0088[00] */ UINT32	O_296_CBIT0_MAP:			4;
		/* 0x0088[04] */ UINT32	O_296_CBIT1_MAP:			4;
		/* 0x0088[08] */ UINT32	O_296_CBIT2_MAP:			4;
		/* 0x0088[12] */ UINT32	O_296_CBIT3_MAP:			4;
		/* 0x0088[16] */ UINT32	O_296_CBIT4_MAP:			4;
		/* 0x0088[20] */ UINT32	O_296_CBIT5_MAP:			4;
		/* 0x0088[24] */ UINT32	O_296_CBIT6_MAP:			4;
		/* 0x0088[28] */ UINT32	O_296_CBIT7_MAP:			4;

        /* 0x008C[00] */ UINT32	O_OTP_EN           :        1;
        /* 0x008C[01] */ UINT32	O_OTP_SYNCGEN_EN   :        1;
        /* 0x008C[02] */ UINT32	O_OTP_SYNCGEN_HLOCK:        1;
        /* 0x008C[03] */ UINT32	O_OTP_TST_PAT      :        2;
        /* 0x008C[05] */ UINT32	Rev008C_05:					3;
        /* 0x008C[08] */ UINT32	O_OTP_RAMP         :        2;
        /* 0x008C[10] */ UINT32	Rev008C_10:					6;
        /* 0x008C[16] */ UINT32	O_OTP_CHOICE_IW    :        2;
        /* 0x008C[18] */ UINT32	O_OTP_CHOICE_QB    :        1;
        /* 0x008C[19] */ UINT32	O_OTP_CHOICE_BAR   :        1;
        /* 0x008C[20] */ UINT32	O_OTP_CSWAP        :        1;
        /* 0x008C[21] */ UINT32	Rev008C_21:					11;

        /* 0x0090[00] */ UINT32	O_OTP_V_BLK_FP:				11;
        /* 0x0090[11] */ UINT32	Rev0090_11:					5;
        /* 0x0090[16] */ UINT32	O_OTP_V_BLK_SY:				11;
        /* 0x0090[27] */ UINT32	Rev0090_27:					5;

        /* 0x0094[00] */ UINT32	O_OTP_V_BLK_BP:				11;
        /* 0x0094[11] */ UINT32	Rev0094_11:					5;
        /* 0x0094[16] */ UINT32	O_OTP_V_ACT_SIZE:			11;
        /* 0x0094[27] */ UINT32	Rev0094_27:					5;

        /* 0x0098[00] */ UINT32	O_OTP_H_BLK_FP:				11;
        /* 0x0098[11] */ UINT32	Rev0098_11:					5;
        /* 0x0098[16] */ UINT32	O_OTP_H_BLK_SY:				11;
        /* 0x0098[27] */ UINT32	Rev0098_27:					5;

        /* 0x009C[00] */ UINT32	O_OTP_H_BLK_BP:				11;
        /* 0x009C[11] */ UINT32	Rev009C_11:					5;
        /* 0x009C[16] */ UINT32	O_OTP_H_ACT_SIZE:			11;
        /* 0x009C[27] */ UINT32	Rev009C_27:					5;



        /* 0x00A0[00] */ UINT32	H_MIRROR_1:				1;
        /* 0x00A0[01] */ UINT32	Rev00A0_01:				31;

        /* 0x00A4[00] */ UINT32	RD_BUFF_M_EN_1:			1;
        /* 0x00A4[01] */ UINT32	Rev00A4_01:				15;
        /* 0x00A4[16] */ UINT32	RD_BUFF_M_CNT_1:			2;
        /* 0x00A4[18] */ UINT32	Rev00A4_18:				14;

        /* 0x00A8[00] */ UINT32	RD_YC_EN_MODE_1:			3;
        /* 0x00A8[03] */ UINT32	Rev00A8_03:				5;
        /* 0x00A8[08] */ UINT32	RD_PASS_SEL_1:			2;
        /* 0x00A8[10] */ UINT32	Rev00A8_10:				2;
        /* 0x00A8[12] */ UINT32	RD_BUF_SEL_1:				1;
        /* 0x00A8[13] */ UINT32	Rev00A8_13:				3;
        /* 0x00A8[16] */ UINT32	RD_BL_1:					5;
        /* 0x00A8[21] */ UINT32	Rev00A8_21:				3;
        /* 0x00A8[24] */ UINT32	RD_FRC_MODE_1:			2;
        /* 0x00A8[26] */ UINT32	RD_BUF_MODE_1:			2;
		/* 0x00A8[28] */ UINT32	Rev00A8_28:				4;

        /* 0x00AC[00] */ UINT32	RD_HSIZE_1:				11;
        /* 0x00AC[11] */ UINT32	Rev00AC_11:				5;
        /* 0x00AC[16] */ UINT32	RD_VSIZE_1:				11;
        /* 0x00AC[27] */ UINT32	Rev00AC_27:				5;

        /* 0x00B0[00] */ UINT32	RD_BASE_ADDR_1:			32;

		/* 0x00B4[00] */ UINT32	Rev00B4_00[(0x0C0-0x0B4)/4];

        /* 0x00C0[00] */ UINT32	AXI_RD_EN:				1;
        /* 0x00C0[01] */ UINT32	Rev00C0_01:				7;
        /* 0x00C0[08] */ UINT32	AXI_RD_DONE:			1;
        /* 0x00C0[09] */ UINT32	Rev00C0_09:				7;
        /* 0x00C0[16] */ UINT32	AXI_WR_EN:				1;
        /* 0x00C0[17] */ UINT32	Rev00C0_17:				7;
        /* 0x00C0[24] */ UINT32	AXI_WR_DONE:			1;
        /* 0x00C0[25] */ UINT32	Rev00C0_25:				7;

        /* 0x00C4[00] */ UINT32	AXI_RW_ADDR:			32;
        /* 0x00C8[00] */ UINT32	AXI_RW_DATA[8];					// 0x00C8 ~ 0x00E4

		/* 0x00E8[00] */ UINT32	Rev00E8_00[(0x200-0x0E8)/4];
	}Reg;
}RE_POST_REGISTER;

#endif


