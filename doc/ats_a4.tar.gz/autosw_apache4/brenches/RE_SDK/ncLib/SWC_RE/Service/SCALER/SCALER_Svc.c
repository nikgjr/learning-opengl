/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    :
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version :
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "../RE_Svc.h"

/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/
volatile unsigned int REScalerIntOn = 0;


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
void ncSvc_RE_SCALER_ISR_Handler(void)
{
	volatile static unsigned int ScalerStartOn = 0;

	JIGMSG("scaler_intertup\n");


	if(sReScalerReg->Reg.RES_START_INT)
	{
		sReScalerReg->Reg.RES_START_INT_CLR = 1;
		sReScalerReg->Reg.RES_START_INT_CLR = 0;
		JIGMSG("scaler_start\n");

		ScalerStartOn = 1;
		REScalerIntOn = 1;
#ifdef	_DIS_G11_ON
		Gpio_Set(11,GPIO_HIGH);
#endif

	}
	else if(sReScalerReg->Reg.RES_ERROR_INT)
	{
		sReScalerReg->Reg.RES_ERROR_INT_CLR = 1;
		sReScalerReg->Reg.RES_ERROR_INT_CLR = 0;
		//JIGMSG("RES_ERROR\n");

	}
	else if(sReScalerReg->Reg.RES_END_INT)
	{
		sReScalerReg->Reg.RES_END_INT_CLR = 1;
		sReScalerReg->Reg.RES_END_INT_CLR = 0;

		VomBuffChCnt = (sReScalerReg->Reg.FM0_WBUF_CNT - 2) & 0x00000003;
		//JIGMSG("sReScalerReg->Reg.FM0_WBUF_CNT = %d \n",sReScalerReg->Reg.FM0_WBUF_CNT);

		AdasStatus.Reg.RdBufSelHsv = AdasStatus.Reg.WrBufSelHsv;
		//AdasStatus.Reg.WrBufSelHsv = ~ AdasStatus.Reg.WrBufSelHsv;

#ifdef	_DIS_G11_ON
		Gpio_Set(11,GPIO_LOW);
#endif
		if(ScalerStartOn)
		{
			ScalerStartOn = 0;
			REScalerIntOn = 0;
		}
	}
	else if(sReScalerReg->Reg.RES_PSEUDO_END_INT)
	{
		sReScalerReg->Reg.RES_PSEUDO_END_INT_CLR = 1;
		sReScalerReg->Reg.RES_PSEUDO_END_INT_CLR = 0;
		JIGMSG("RES_SUDO\n");
		if(ScalerStartOn)
		{
			ScalerStartOn = 0;
			REScalerIntOn = 0;
		}
	}
    //abbd_intc_core_ifr_off(RECG_SCALER_IRQ); //aldebaran
}

//----------------------------------
void ncSvc_RE_Scaler_Init (void)
{
	JIGMSG("@@ ncSvc RE Init. start\n");
	sReScalerReg->Reg.RES_FM0_Y_EN 	 	 = 1;
	sReScalerReg->Reg.RES_FM2_Y_EN		 = 0;
	sReScalerReg->Reg.RES_FM4_Y_EN		 = 0;
	sReScalerReg->Reg.RES_FM6_Y_EN		 = 0;
	sReScalerReg->Reg.RES_FMc_Y_EN		 = 0;
	sReScalerReg->Reg.RES_FMe_Y_EN		 = 0;
	sReScalerReg->Reg.RES_FM10_Y_EN	 = 0;
	sReScalerReg->Reg.RES_FM12_Y_EN	 = 0;
	sReScalerReg->Reg.RES_WIDE_FM0_Y_EN = 0;
	sReScalerReg->Reg.RES_WIDE_FM2_Y_EN = 0;
	sReScalerReg->Reg.RES_WIDE_FM4_Y_EN = 0;

	sReScalerReg->Reg.RES_FM0_C_EN		 = 1;
	sReScalerReg->Reg.RES_FM2_C_EN		 = 0;
	sReScalerReg->Reg.RES_FM4_C_EN		 = 0;
	sReScalerReg->Reg.RES_FM6_C_EN		 = 0;//
	sReScalerReg->Reg.RES_FMc_C_EN		 = 0;
	sReScalerReg->Reg.RES_FMe_C_EN		 = 0;
	sReScalerReg->Reg.RES_FM10_C_EN	 = 0;
	sReScalerReg->Reg.RES_FM12_C_EN	 = 0;//
	sReScalerReg->Reg.RES_WIDE_FM0_C_EN = 0;
	sReScalerReg->Reg.RES_WIDE_FM2_C_EN = 0;
	sReScalerReg->Reg.RES_WIDE_FM4_C_EN = 0;
	// recg_scaler image start address
	sReScalerReg->Reg.RES_FM0_BASE_ADDR  = FM0_START_ADDR	;    	//  640 x 480 image start address
	sReScalerReg->Reg.RES_FM2_BASE_ADDR  = FM2_START_ADDR	;    	//  512 x 384 image start address
	sReScalerReg->Reg.RES_FM4_BASE_ADDR  = FM4_START_ADDR	;    	//  412 x 308 image start address
	sReScalerReg->Reg.RES_FM6_BASE_ADDR  = FM6_START_ADDR	;    	//  320 x 240 image start address
	sReScalerReg->Reg.RES_FMc_BASE_ADDR  = FMc_START_ADDR	;    	//  160 x 120 image start address
	sReScalerReg->Reg.RES_FM12_BASE_ADDR = FM12_START_ADDR	;   	//  80  x 60  image start address
	sReScalerReg->Reg.RES_FMe_BASE_ADDR  = FMe_START_ADDR	;    	//  128 x 96  image start address
	sReScalerReg->Reg.RES_FM10_BASE_ADDR = FM10_START_ADDR	;	//  104 x 57  image start address

	sReScalerReg->Reg.RES_WIDE_FM0_BASE_ADDR = FM18_START_ADDR;
	sReScalerReg->Reg.RES_WIDE_FM2_BASE_ADDR = FM1a_START_ADDR;
	sReScalerReg->Reg.RES_WIDE_FM4_BASE_ADDR = FM1c_START_ADDR;


	sReScalerReg->Reg.RES_FM0_H_SIZE = adas_size.width_0;
	sReScalerReg->Reg.RES_FM0_V_SIZE = adas_size.height_0;     	// FM00 H_V_SIZE 640 X 360
	sReScalerReg->Reg.RES_FM2_H_SIZE = adas_size.width_2;
	sReScalerReg->Reg.RES_FM2_V_SIZE = adas_size.height_2;		// FM02 H_V_SIZE 512 X 288
	sReScalerReg->Reg.RES_FM4_H_SIZE = adas_size.width_4;
	sReScalerReg->Reg.RES_FM4_V_SIZE = adas_size.height_4;		// FM04 H_V_SIZE 412 X 230

	sReScalerReg->Reg.RES_WIDE_FM0_H_SIZE = adas_size.wide_width_0	;
	sReScalerReg->Reg.RES_WIDE_FM0_V_SIZE = adas_size.wide_height_0;
	sReScalerReg->Reg.RES_WIDE_FM2_H_SIZE = adas_size.wide_width_2	;
	sReScalerReg->Reg.RES_WIDE_FM2_V_SIZE = adas_size.wide_height_2;
	sReScalerReg->Reg.RES_WIDE_FM4_H_SIZE = adas_size.wide_width_4	;
	sReScalerReg->Reg.RES_WIDE_FM4_V_SIZE = adas_size.wide_height_4;

	sReVdpdReg->Reg.REC_FMc_H_SIZE  = sReScalerReg->Reg.RES_FM0_H_SIZE/4;
	sReVdpdReg->Reg.REC_FMc_V_SIZE  = sReScalerReg->Reg.RES_FM0_V_SIZE/4;
	sReVdpdReg->Reg.REC_FMe_H_SIZE  = sReScalerReg->Reg.RES_FM2_H_SIZE/4;
	sReVdpdReg->Reg.REC_FMe_V_SIZE  = sReScalerReg->Reg.RES_FM2_V_SIZE/4;
	sReVdpdReg->Reg.REC_FM10_H_SIZE = sReScalerReg->Reg.RES_FM4_H_SIZE/4;
	sReVdpdReg->Reg.REC_FM10_V_SIZE = sReScalerReg->Reg.RES_FM4_V_SIZE/4;
#ifdef BUFF_SIMPLE
	// this sReScalerReg->Reg.RES_FM0_FRC_MODE  is already define in A4_AdasIp.c
	sReScalerReg->Reg.RES_FM0_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM2_FRC_MODE  = 1;
	sReScalerReg->Reg.RES_FM4_FRC_MODE  = 1;
	sReScalerReg->Reg.RES_FM6_FRC_MODE  = 2;
	sReScalerReg->Reg.RES_FMc_FRC_MODE  = 2;
	sReScalerReg->Reg.RES_FM12_FRC_MODE = 2;
	sReScalerReg->Reg.RES_FMe_FRC_MODE  = 1;
	sReScalerReg->Reg.RES_FM10_FRC_MODE = 1;

	sReScalerReg->Reg.RES_WIDE_FM0_FRC_MODE = 1;
	sReScalerReg->Reg.RES_WIDE_FM2_FRC_MODE = 1;
	sReScalerReg->Reg.RES_WIDE_FM4_FRC_MODE = 1;
#else
	sReScalerReg->Reg.RES_FM0_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM2_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM4_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM6_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FMc_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM12_FRC_MODE = 3;
	sReScalerReg->Reg.RES_FMe_FRC_MODE  = 3;
	sReScalerReg->Reg.RES_FM10_FRC_MODE = 3;
#endif


	sReScalerReg->Reg.FRAME_SKIP_CNT = 0;

	sReScalerReg->Reg.RES_START_INT_CLR = 0;
	sReScalerReg->Reg.RES_END_INT_CLR = 0;
	sReScalerReg->Reg.RES_PSEUDO_END_INT_CLR = 0;
	sReScalerReg->Reg.RES_ERROR_INT_CLR = 0;

	sReScalerReg->Reg.RES_START_INT_EN 	= 1;
	sReScalerReg->Reg.RES_END_INT_EN 		= 1;
	sReScalerReg->Reg.RES_PSEUDO_END_INT_EN 	= 0;
	sReScalerReg->Reg.RES_ERROR_INT_EN 	= 0;

	#ifdef	_INT_PULSE_ON
		sReScalerReg->Reg.INT_PULSE_EN = 1;
	#else
		sReScalerReg->Reg.INT_PULSE_EN = 0;
	#endif

#if 1

	sReScalerReg->Reg.PSEUDO_END_CNT = 0xFA;//0x00447FF0;


#endif

	#ifdef	_SCALER_INT_EN
	//ncLib_INTC_Control(GCMD_INTC_SET_TRIG_MODE, IRQ_NUM_RE_SCALER, TRIG_EDGE_HIGH, CMD_END);
	if( ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_RE_SCALER, (PrVoid)ncSvc_RE_SCALER_ISR_Handler, CMD_END) != NC_SUCCESS )
	{
		DEBUGMSG_SDK(MSGERR, "SCALER_INIT ERROR\n");
	}
	#endif

	JIGMSG("@@ RECG Scaler Init. done\n");

}



/* End Of File */

