#ifndef __RE_VDPD_REGISTER_H__
#define __RE_VDPD_REGISTER_H__

/*=============================================================================
	Definitions for Register Start Address, End Address, Size
=============================================================================*/
typedef struct
{
	unsigned int B0_16:	16;
	unsigned int B1_16:	16;
}BIT16x2;

typedef struct
{
	unsigned int B0_4:	4;
	unsigned int B1_4:	4;
	unsigned int B2_4:	4;
	unsigned int B3_4:	4;
	unsigned int B4_4:	4;
	unsigned int B5_4:	4;
	unsigned int B6_4:	4;
	unsigned int B7_4:	4;
}BIT4x8;


typedef union
{
	unsigned int Data32;
	struct
	{
		unsigned int RESULT_FMx_S_H_OFFSET:	8;
		unsigned int RESULT_FMx_E_H_OFFSET:	8;
		unsigned int RESULT_FMx_S_V_OFFSET:	7;
		unsigned int REV0:					1;
		unsigned int RESULT_FMx_E_V_OFFSET: 7;
		unsigned int REV1:					1;
	}Reg;
}RESULT_FMX_OFFSET;

typedef union
{
	unsigned int Result[2];
	struct
	{


		unsigned int ACF_VALUE:				11;
		unsigned int REV_1:					21;

		unsigned int V_PNT:					8;
		unsigned int H_PNT:					11;
		unsigned int FM_X:					6;
		unsigned int CR_DN:					1;
		unsigned int REV_0:					6;


	}Reg;
}ACF_RESULT;

typedef union
{
	UINT32 Data32[1];
	struct
	{
		UINT32 Fx_VD_PD_FMx_H_PADDING_ENABLE:	1;
		UINT32 REV1:							3;
		UINT32 Fx_VD_PD_FMx_V_PADDING_ENABLE:	1;
		UINT32 REV2:							3;
		UINT32 Fx_VD_PD_FMx_H_STRIDE1_ENABLE:	1;
		UINT32 REV3:							3;
		UINT32 Fx_VD_PD_FMx_V_STRIDE1_ENABLE:	1;
		UINT32 REV4:							19;
	}Reg;
}H_V_PADDING_STRIDE;


typedef union
{
	UINT32 Data32;
	struct
	{
		UINT32 FXX_REC_RESULT_CNT:			16;
		UINT32 REV1:						16;
	}Reg;
}REC_RESULT_CNT;


typedef union
{
	UINT32 Data32;
	struct
	{
		UINT32 FXX_REC_RESULT_UP_CNT:		16;
		UINT32 FXX_REC_REDULT_BUF_CNT:		1;
		UINT32 REV1:						15;
	}Reg;
}REC_RESULT_UP_CNT;

#define	RE_VDPD_REGISTER_SIZE	0x0DF0

typedef union
{
	unsigned int Data[RE_VDPD_REGISTER_SIZE/4];
	struct
	{
		/*	0x0000	[00]	*/	unsigned int	REC_VD_PD_EN	:	1	;
		/*	0x0000	[01]	*/	unsigned int	Rev0000_01	:	3	;
		/*	0x0000	[04]	*/	unsigned int	REC_VD_PD_C_EN	:	1	;
		/*	0x0000	[05]	*/	unsigned int	Rev0000_05	:	3	;
		/*	0x0000	[08]	*/	unsigned int	REC_FR_SKIP_CNT	:	8	;
		/*	0x0000	[16]	*/	unsigned int	REC_CR_DN_INV	:	1	;
		/*	0x0000	[17]	*/	unsigned int	REC_CR_DN_FR_SKIP_EN	:	1	;
		/*	0x0000	[18]	*/	unsigned int	Rev0000_18	:	6	;
		/*	0x0000	[24]	*/	unsigned int	REC_START_MODE	:	2	;
		/*	0x0000	[26]	*/	unsigned int	Rev0000_26	:	2	;
		/*	0x0000	[28]	*/	unsigned int	REC_MANUAL_START_CMD	:	1	;
		/*	0x0000	[29]	*/	unsigned int	Rev0000_29	:	3	;

		/*	0x0004	[00]	*/	unsigned int	REC_FM0_EN	:	1	;
		/*	0x0004	[01]	*/	unsigned int	REC_FM1_EN	:	1	;
		/*	0x0004	[02]	*/	unsigned int	REC_FM2_EN	:	1	;
		/*	0x0004	[03]	*/	unsigned int	REC_FM3_EN	:	1	;
		/*	0x0004	[04]	*/	unsigned int	REC_FM4_EN	:	1	;
		/*	0x0004	[05]	*/	unsigned int	REC_FM5_EN	:	1	;
		/*	0x0004	[06]	*/	unsigned int	REC_FM6_EN	:	1	;
		/*	0x0004	[07]	*/	unsigned int	REC_FM7_EN	:	1	;
		/*	0x0004	[08]	*/	unsigned int	REC_FM8_EN	:	1	;
		/*	0x0004	[09]	*/	unsigned int	REC_FM9_EN	:	1	;
		/*	0x0004	[10]	*/	unsigned int	REC_FMa_EN	:	1	;
		/*	0x0004	[11]	*/	unsigned int	REC_FMb_EN	:	1	;
		/*	0x0004	[12]	*/	unsigned int	REC_FMc_EN	:	1	;
		/*	0x0004	[13]	*/	unsigned int	REC_FMd_EN	:	1	;
		/*	0x0004	[14]	*/	unsigned int	REC_FMe_EN	:	1	;
		/*	0x0004	[15]	*/	unsigned int	REC_FMf_EN	:	1	;
		/*	0x0004	[16]	*/	unsigned int	REC_FM10_EN	:	1	;
		/*	0x0004	[17]	*/	unsigned int	REC_FM11_EN	:	1	;
		/*	0x0004	[18]	*/	unsigned int	REC_FM12_EN	:	1	;
		/*	0x0004	[19]	*/	unsigned int	REC_FM13_EN	:	1	;
		/*	0x0004	[20]	*/	unsigned int	REC_FM14_EN	:	1	;
		/*	0x0004	[21]	*/	unsigned int	REC_FM15_EN	:	1	;
		/*	0x0004	[22]	*/	unsigned int	REC_FM16_EN	:	1	;
		/*	0x0004	[23]	*/	unsigned int	REC_FM17_EN	:	1	;
		/*	0x0004	[24]	*/	unsigned int	Rev0004_24	:	8	;

		/*	0x0008	[00]	*/	unsigned int	REC_FM0_H_SIZE	:	10	;
		/*	0x0008	[10]	*/	unsigned int	Rev0008_10	:	2	;
		/*	0x0008	[12]	*/	unsigned int	REC_FM0_V_SIZE	:	9	;
		/*	0x0008	[21]	*/	unsigned int	Rev0008_21	:	3	;
		/*	0x0008	[24]	*/	unsigned int	REC_FM0_RD_FRC_MODE	:	3	;
		/*	0x0008	[27]	*/	unsigned int	Rev0008_27	:	1	;
		/*	0x0008	[28]	*/	unsigned int	REC_FM0_RD_BUF_M_CNT	:	3	;
		/*	0x0008	[31]	*/	unsigned int	REC_FM0_RD_BUF_M_EN	:	1	;

		/*	0x000C	[00]	*/	unsigned int	REC_FM0_BASE_ADDR	:	32	;

		/*	0x0010	[00]	*/	unsigned int	REC_FM2_H_SIZE	:	10	;
		/*	0x0010	[10]	*/	unsigned int	Rev0010_10	:	2	;
		/*	0x0010	[12]	*/	unsigned int	REC_FM2_V_SIZE	:	9	;
		/*	0x0010	[21]	*/	unsigned int	Rev0010_21	:	3	;
		/*	0x0010	[24]	*/	unsigned int	REC_FM2_RD_FRC_MODE	:	3	;
		/*	0x0010	[27]	*/	unsigned int	Rev0010_27	:	1	;
		/*	0x0010	[28]	*/	unsigned int	REC_FM2_RD_BUF_M_CNT	:	3	;
		/*	0x0010	[31]	*/	unsigned int	REC_FM2_RD_BUF_M_EN	:	1	;

		/*	0x0014	[00]	*/	unsigned int	REC_FM2_BASE_ADDR	:	32	;

		/*	0x0018	[00]	*/	unsigned int	REC_FM4_H_SIZE	:	10	;
		/*	0x0018	[10]	*/	unsigned int	Rev0018_10	:	2	;
		/*	0x0018	[12]	*/	unsigned int	REC_FM4_V_SIZE	:	9	;
		/*	0x0018	[21]	*/	unsigned int	Rev0018_21	:	3	;
		/*	0x0018	[24]	*/	unsigned int	REC_FM4_RD_FRC_MODE	:	3	;
		/*	0x0018	[27]	*/	unsigned int	Rev0018_27	:	1	;
		/*	0x0018	[28]	*/	unsigned int	REC_FM4_RD_BUF_M_CNT	:	3	;
		/*	0x0018	[31]	*/	unsigned int	REC_FM4_RD_BUF_M_EN	:	1	;

		/*	0x001C	[00]	*/	unsigned int	REC_FM4_BASE_ADDR	:	32	;

		/*	0x0020	[00]	*/	unsigned int	REC_FMc_H_SIZE	:	10	;
		/*	0x0020	[10]	*/	unsigned int	Rev0020_10	:	2	;
		/*	0x0020	[12]	*/	unsigned int	REC_FMc_V_SIZE	:	9	;
		/*	0x0020	[21]	*/	unsigned int	Rev0020_21	:	3	;
		/*	0x0020	[24]	*/	unsigned int	REC_FMc_RD_FRC_MODE	:	3	;
		/*	0x0020	[27]	*/	unsigned int	Rev0020_27	:	1	;
		/*	0x0020	[28]	*/	unsigned int	REC_FMc_RD_BUF_M_CNT	:	3	;
		/*	0x0020	[31]	*/	unsigned int	REC_FMc_RD_BUF_M_EN	:	1	;

		/*	0x0024	[00]	*/	unsigned int	REC_FMc_BASE_ADDR	:	32	;

		/*	0x0028	[00]	*/	unsigned int	REC_FMe_H_SIZE	:	10	;
		/*	0x0028	[10]	*/	unsigned int	Rev0028_10	:	2	;
		/*	0x0028	[12]	*/	unsigned int	REC_FMe_V_SIZE	:	9	;
		/*	0x0028	[21]	*/	unsigned int	Rev0028_21	:	3	;
		/*	0x0028	[24]	*/	unsigned int	REC_FMe_RD_FRC_MODE	:	3	;
		/*	0x0028	[27]	*/	unsigned int	Rev0028_27	:	1	;
		/*	0x0028	[28]	*/	unsigned int	REC_FMe_RD_BUF_M_CNT	:	3	;
		/*	0x0028	[31]	*/	unsigned int	REC_FMe_RD_BUF_M_EN	:	1	;

		/*	0x002C	[00]	*/	unsigned int	REC_FMe_BASE_ADDR	:	32	;

		/*	0x0030	[00]	*/	unsigned int	REC_FM10_H_SIZE	:	10	;
		/*	0x0030	[10]	*/	unsigned int	Rev0030_10	:	2	;
		/*	0x0030	[12]	*/	unsigned int	REC_FM10_V_SIZE	:	9	;
		/*	0x0030	[21]	*/	unsigned int	Rev0030_21	:	3	;
		/*	0x0030	[24]	*/	unsigned int	REC_FM10_RD_FRC_MODE	:	3	;
		/*	0x0030	[27]	*/	unsigned int	Rev0030_27	:	1	;
		/*	0x0030	[28]	*/	unsigned int	REC_FM10_RD_BUF_M_CNT	:	3	;
		/*	0x0030	[31]	*/	unsigned int	REC_FM10_RD_BUF_M_EN	:	1	;

		/*	0x0034	[00]	*/	unsigned int	REC_FM10_BASE_ADDR	:	32	;

		/*	0x0038	[00]	*/	unsigned int	REC_FM0_RD_BUF_CNT	:	3	;
		/*	0x0038	[03]	*/	unsigned int	Rev0038_03	:	1	;
		/*	0x0038	[04]	*/	unsigned int	REC_FM2_RD_BUF_CNT	:	3	;
		/*	0x0038	[07]	*/	unsigned int	Rev0038_07	:	1	;
		/*	0x0038	[08]	*/	unsigned int	REC_FM4_RD_BUF_CNT	:	3	;
		/*	0x0038	[11]	*/	unsigned int	Rev0038_11	:	1	;
		/*	0x0038	[12]	*/	unsigned int	REC_FMc_RD_BUF_CNT	:	3	;
		/*	0x0038	[15]	*/	unsigned int	Rev0038_15	:	1	;
		/*	0x0038	[16]	*/	unsigned int	REC_FMe_RD_BUF_CNT	:	3	;
		/*	0x0038	[19]	*/	unsigned int	Rev0038_19	:	1	;
		/*	0x0038	[20]	*/	unsigned int	REC_FM10_RD_BUF_CNT	:	3	;
		/*	0x0038	[23]	*/	unsigned int	Rev0038_23	:	9	;

		/*	0x003C	[00]	*/	unsigned int	Rev003C_00	:	32	;

		/*	0x0040	[00]	*/	unsigned int	REC_FM0_S_H_OFFSET	:	8	;
		/*	0x0040	[08]	*/	unsigned int	REC_FM0_E_H_OFFSET	:	8	;
		/*	0x0040	[16]	*/	unsigned int	REC_FM0_S_V_OFFSET	:	7	;
		/*	0x0040	[23]	*/	unsigned int	Rev0040_23	:	1	;
		/*	0x0040	[24]	*/	unsigned int	REC_FM0_E_V_OFFSET	:	7	;
		/*	0x0040	[31]	*/	unsigned int	Rev0040_31	:	1	;

		/*	0x0044	[00]	*/	unsigned int	REC_FM2_S_H_OFFSET	:	8	;
		/*	0x0044	[08]	*/	unsigned int	REC_FM2_E_H_OFFSET	:	8	;
		/*	0x0044	[16]	*/	unsigned int	REC_FM2_S_V_OFFSET	:	7	;
		/*	0x0044	[23]	*/	unsigned int	Rev0044_23	:	1	;
		/*	0x0044	[24]	*/	unsigned int	REC_FM2_E_V_OFFSET	:	7	;
		/*	0x0044	[31]	*/	unsigned int	Rev0044_31	:	1	;

		/*	0x0048	[00]	*/	unsigned int	REC_FM4_S_H_OFFSET	:	8	;
		/*	0x0048	[08]	*/	unsigned int	REC_FM4_E_H_OFFSET	:	8	;
		/*	0x0048	[16]	*/	unsigned int	REC_FM4_S_V_OFFSET	:	7	;
		/*	0x0048	[23]	*/	unsigned int	Rev0048_23	:	1	;
		/*	0x0048	[24]	*/	unsigned int	REC_FM4_E_V_OFFSET	:	7	;
		/*	0x0048	[31]	*/	unsigned int	Rev0048_31	:	1	;

		/*	0x004C	[00]	*/	unsigned int	REC_FM6_S_H_OFFSET	:	7	;
		/*	0x004C	[07]	*/	unsigned int	Rev004C_07	:	1	;
		/*	0x004C	[08]	*/	unsigned int	REC_FM6_E_H_OFFSET	:	7	;
		/*	0x004C	[15]	*/	unsigned int	Rev004C_15	:	1	;
		/*	0x004C	[16]	*/	unsigned int	REC_FM6_S_V_OFFSET	:	6	;
		/*	0x004C	[22]	*/	unsigned int	Rev004C_22	:	2	;
		/*	0x004C	[24]	*/	unsigned int	REC_FM6_E_V_OFFSET	:	6	;
		/*	0x004C	[30]	*/	unsigned int	Rev004C_30	:	2	;

		/*	0x0050	[00]	*/	unsigned int	REC_FM8_S_H_OFFSET	:	7	;
		/*	0x0050	[07]	*/	unsigned int	Rev0050_07	:	1	;
		/*	0x0050	[08]	*/	unsigned int	REC_FM8_E_H_OFFSET	:	7	;
		/*	0x0050	[15]	*/	unsigned int	Rev0050_15	:	1	;
		/*	0x0050	[16]	*/	unsigned int	REC_FM8_S_V_OFFSET	:	6	;
		/*	0x0050	[22]	*/	unsigned int	Rev0050_22	:	2	;
		/*	0x0050	[24]	*/	unsigned int	REC_FM8_E_V_OFFSET	:	6	;
		/*	0x0050	[30]	*/	unsigned int	Rev0050_30	:	2	;

		/*	0x0054	[00]	*/	unsigned int	REC_FMa_S_H_OFFSET	:	7	;
		/*	0x0054	[07]	*/	unsigned int	Rev0054_07	:	1	;
		/*	0x0054	[08]	*/	unsigned int	REC_FMa_E_H_OFFSET	:	7	;
		/*	0x0054	[15]	*/	unsigned int	Rev0054_15	:	1	;
		/*	0x0054	[16]	*/	unsigned int	REC_FMa_S_V_OFFSET	:	6	;
		/*	0x0054	[22]	*/	unsigned int	Rev0054_22	:	2	;
		/*	0x0054	[24]	*/	unsigned int	REC_FMa_E_V_OFFSET	:	6	;
		/*	0x0054	[30]	*/	unsigned int	Rev0054_30	:	2	;

		/*	0x0058	[00]	*/	unsigned int	REC_FMc_S_H_OFFSET	:	6	;
		/*	0x0058	[06]	*/	unsigned int	Rev0058_06	:	2	;
		/*	0x0058	[08]	*/	unsigned int	REC_FMc_E_H_OFFSET	:	6	;
		/*	0x0058	[14]	*/	unsigned int	Rev0058_14	:	2	;
		/*	0x0058	[16]	*/	unsigned int	REC_FMc_S_V_OFFSET	:	5	;
		/*	0x0058	[21]	*/	unsigned int	Rev0058_21	:	3	;
		/*	0x0058	[24]	*/	unsigned int	REC_FMc_E_V_OFFSET	:	5	;
		/*	0x0058	[29]	*/	unsigned int	Rev0058_29	:	3	;

		/*	0x005C	[00]	*/	unsigned int	REC_FMe_S_H_OFFSET	:	6	;
		/*	0x005C	[06]	*/	unsigned int	Rev005C_06	:	2	;
		/*	0x005C	[08]	*/	unsigned int	REC_FMe_E_H_OFFSET	:	6	;
		/*	0x005C	[14]	*/	unsigned int	Rev005C_14	:	2	;
		/*	0x005C	[16]	*/	unsigned int	REC_FMe_S_V_OFFSET	:	5	;
		/*	0x005C	[21]	*/	unsigned int	Rev005C_21	:	3	;
		/*	0x005C	[24]	*/	unsigned int	REC_FMe_E_V_OFFSET	:	5	;
		/*	0x005C	[29]	*/	unsigned int	Rev005C_29	:	3	;

		/*	0x0060	[00]	*/	unsigned int	REC_FM10_S_H_OFFSET	:	6	;
		/*	0x0060	[06]	*/	unsigned int	Rev0060_06	:	2	;
		/*	0x0060	[08]	*/	unsigned int	REC_FM10_E_H_OFFSET	:	6	;
		/*	0x0060	[14]	*/	unsigned int	Rev0060_14	:	2	;
		/*	0x0060	[16]	*/	unsigned int	REC_FM10_S_V_OFFSET	:	5	;
		/*	0x0060	[21]	*/	unsigned int	Rev0060_21	:	3	;
		/*	0x0060	[24]	*/	unsigned int	REC_FM10_E_V_OFFSET	:	5	;
		/*	0x0060	[29]	*/	unsigned int	Rev0060_29	:	3	;

		/*	0x0064	[00]	*/	unsigned int	REC_FM12_S_H_OFFSET	:	5	;
		/*	0x0064	[05]	*/	unsigned int	Rev0064_05	:	3	;
		/*	0x0064	[08]	*/	unsigned int	REC_FM12_E_H_OFFSET	:	5	;
		/*	0x0064	[13]	*/	unsigned int	Rev0064_13	:	3	;
		/*	0x0064	[16]	*/	unsigned int	REC_FM12_S_V_OFFSET	:	4	;
		/*	0x0064	[20]	*/	unsigned int	Rev0064_20	:	4	;
		/*	0x0064	[24]	*/	unsigned int	REC_FM12_E_V_OFFSET	:	4	;
		/*	0x0064	[28]	*/	unsigned int	Rev0064_28	:	4	;

		/*	0x0068	[00]	*/	unsigned int	REC_FM14_S_H_OFFSET	:	5	;
		/*	0x0068	[05]	*/	unsigned int	Rev0068_05	:	3	;
		/*	0x0068	[08]	*/	unsigned int	REC_FM14_E_H_OFFSET	:	5	;
		/*	0x0068	[13]	*/	unsigned int	Rev0068_13	:	3	;
		/*	0x0068	[16]	*/	unsigned int	REC_FM14_S_V_OFFSET	:	4	;
		/*	0x0068	[20]	*/	unsigned int	Rev0068_20	:	4	;
		/*	0x0068	[24]	*/	unsigned int	REC_FM14_E_V_OFFSET	:	4	;
		/*	0x0068	[28]	*/	unsigned int	Rev0068_28	:	4	;

		/*	0x006C	[00]	*/	unsigned int	REC_FM16_S_H_OFFSET	:	5	;
		/*	0x006C	[05]	*/	unsigned int	Rev006C_05	:	3	;
		/*	0x006C	[08]	*/	unsigned int	REC_FM16_E_H_OFFSET	:	5	;
		/*	0x006C	[13]	*/	unsigned int	Rev006C_13	:	3	;
		/*	0x006C	[16]	*/	unsigned int	REC_FM16_S_V_OFFSET	:	4	;
		/*	0x006C	[20]	*/	unsigned int	Rev006C_20	:	4	;
		/*	0x006C	[24]	*/	unsigned int	REC_FM16_E_V_OFFSET	:	4	;
		/*	0x006C	[28]	*/	unsigned int	Rev006C_28	:	4	;

		/*	0x0070	[00]	*/	unsigned int	REC_FM18_EN	:	1	;
		/*	0x0070	[01]	*/	unsigned int	REC_FM19_EN	:	1	;
		/*	0x0070	[02]	*/	unsigned int	REC_FM1a_EN	:	1	;
		/*	0x0070	[03]	*/	unsigned int	REC_FM1b_EN	:	1	;
		/*	0x0070	[04]	*/	unsigned int	REC_FM1c_EN	:	1	;
		/*	0x0070	[05]	*/	unsigned int	REC_FM1d_EN	:	1	;
		/*	0x0070	[06]	*/	unsigned int	REC_FM1e_EN	:	1	;
		/*	0x0070	[07]	*/	unsigned int	REC_FM1f_EN	:	1	;
		/*	0x0070	[08]	*/	unsigned int	REC_FM20_EN	:	1	;
		/*	0x0070	[09]	*/	unsigned int	REC_FM21_EN	:	1	;
		/*	0x0070	[10]	*/	unsigned int	REC_FM22_EN	:	1	;
		/*	0x0070	[11]	*/	unsigned int	REC_FM23_EN	:	1	;
		/*	0x0070	[12]	*/	unsigned int	Rev0070_12	:	20	;

		/*	0x0074	[00]	*/	unsigned int	REC_FM18_H_SIZE	:	12	;
		/*	0x0074	[12]	*/	unsigned int	REC_FM18_V_SIZE	:	9	;
		/*	0x0074	[21]	*/	unsigned int	Rev0074_21	:	3	;
		/*	0x0074	[24]	*/	unsigned int	REC_FM18_RD_FRC_MODE	:	3	;
		/*	0x0074	[27]	*/	unsigned int	Rev0074_27	:	1	;
		/*	0x0074	[28]	*/	unsigned int	REC_FM18_RD_BUF_M_CNT	:	3	;
		/*	0x0074	[31]	*/	unsigned int	REC_FM18_RD_BUF_M_EN	:	1	;

		/*	0x0078	[00]	*/	unsigned int	REC_FM18_BASE_ADDR	:	32	;

		/*	0x007C	[00]	*/	unsigned int	REC_FM1a_H_SIZE	:	12	;
		/*	0x007C	[12]	*/	unsigned int	REC_FM1a_V_SIZE	:	9	;
		/*	0x007C	[21]	*/	unsigned int	Rev007C_21	:	3	;
		/*	0x007C	[24]	*/	unsigned int	REC_FM1a_RD_FRC_MODE	:	3	;
		/*	0x007C	[27]	*/	unsigned int	Rev007C_27	:	1	;
		/*	0x007C	[28]	*/	unsigned int	REC_FM1a_RD_BUF_M_CNT	:	3	;
		/*	0x007C	[31]	*/	unsigned int	REC_FM1a_RD_BUF_M_EN	:	1	;

		/*	0x0080	[00]	*/	unsigned int	REC_FM1a_BASE_ADDR	:	32	;

		/*	0x0084	[00]	*/	unsigned int	REC_FM1c_H_SIZE	:	12	;
		/*	0x0084	[12]	*/	unsigned int	REC_FM1c_V_SIZE	:	9	;
		/*	0x0084	[21]	*/	unsigned int	Rev0084_21	:	3	;
		/*	0x0084	[24]	*/	unsigned int	REC_FM1c_RD_FRC_MODE	:	3	;
		/*	0x0084	[27]	*/	unsigned int	Rev0084_27	:	1	;
		/*	0x0084	[28]	*/	unsigned int	REC_FM1c_RD_BUF_M_CNT	:	3	;
		/*	0x0084	[31]	*/	unsigned int	REC_FM1c_RD_BUF_M_EN	:	1	;

		/*	0x0088	[00]	*/	unsigned int	REC_FM1c_BASE_ADDR	:	32	;

		/*	0x008C	[00]	*/	unsigned int	REC_FM18_RD_BUF_CNT	:	3	;
		/*	0x008C	[03]	*/	unsigned int	Rev008C_03	:	5	;
		/*	0x008C	[08]	*/	unsigned int	REC_FM1a_RD_BUF_CNT	:	3	;
		/*	0x008C	[11]	*/	unsigned int	Rev008C_11	:	5	;
		/*	0x008C	[16]	*/	unsigned int	REC_FM1c_RD_BUF_CNT	:	3	;
		/*	0x008C	[19]	*/	unsigned int	Rev008C_19	:	13	;

		/*	0x0090	[00]	*/	unsigned int	REC_FM18_S_H_OFFSET	:	8	;
		/*	0x0090	[08]	*/	unsigned int	REC_FM18_E_H_OFFSET	:	8	;
		/*	0x0090	[16]	*/	unsigned int	REC_FM18_S_V_OFFSET	:	7	;
		/*	0x0090	[23]	*/	unsigned int	Rev0090_23	:	1	;
		/*	0x0090	[24]	*/	unsigned int	REC_FM18_E_V_OFFSET	:	7	;
		/*	0x0090	[31]	*/	unsigned int	Rev0090_31	:	1	;

		/*	0x0094	[00]	*/	unsigned int	REC_FM1a_S_H_OFFSET	:	8	;
		/*	0x0094	[08]	*/	unsigned int	REC_FM1a_E_H_OFFSET	:	8	;
		/*	0x0094	[16]	*/	unsigned int	REC_FM1a_S_V_OFFSET	:	7	;
		/*	0x0094	[23]	*/	unsigned int	Rev0094_23	:	1	;
		/*	0x0094	[24]	*/	unsigned int	REC_FM1a_E_V_OFFSET	:	7	;
		/*	0x0094	[31]	*/	unsigned int	Rev0094_31	:	1	;

		/*	0x0098	[00]	*/	unsigned int	REC_FM1c_S_H_OFFSET	:	8	;
		/*	0x0098	[08]	*/	unsigned int	REC_FM1c_E_H_OFFSET	:	8	;
		/*	0x0098	[16]	*/	unsigned int	REC_FM1c_S_V_OFFSET	:	7	;
		/*	0x0098	[23]	*/	unsigned int	Rev0098_23	:	1	;
		/*	0x0098	[24]	*/	unsigned int	REC_FM1c_E_V_OFFSET	:	7	;
		/*	0x0098	[31]	*/	unsigned int	Rev0098_31	:	1	;

		/*	0x009C	[00]	*/	unsigned int	REC_FM1e_S_H_OFFSET	:	8	;
		/*	0x009C	[08]	*/	unsigned int	REC_FM1e_E_H_OFFSET	:	8	;
		/*	0x009C	[16]	*/	unsigned int	REC_FM1e_S_V_OFFSET	:	7	;
		/*	0x009C	[23]	*/	unsigned int	Rev009C_23	:	1	;
		/*	0x009C	[24]	*/	unsigned int	REC_FM1e_E_V_OFFSET	:	7	;
		/*	0x009C	[31]	*/	unsigned int	Rev009C_31	:	1	;

		/*	0x00A0	[00]	*/	unsigned int	REC_FM20_S_H_OFFSET	:	8	;
		/*	0x00A0	[08]	*/	unsigned int	REC_FM20_E_H_OFFSET	:	8	;
		/*	0x00A0	[16]	*/	unsigned int	REC_FM20_S_V_OFFSET	:	7	;
		/*	0x00A0	[23]	*/	unsigned int	Rev00A0_23	:	1	;
		/*	0x00A0	[24]	*/	unsigned int	REC_FM20_E_V_OFFSET	:	7	;
		/*	0x00A0	[31]	*/	unsigned int	Rev00A0_31	:	1	;

		/*	0x00A4	[00]	*/	unsigned int	REC_FM22_S_H_OFFSET	:	8	;
		/*	0x00A4	[08]	*/	unsigned int	REC_FM22_E_H_OFFSET	:	8	;
		/*	0x00A4	[16]	*/	unsigned int	REC_FM22_S_V_OFFSET	:	7	;
		/*	0x00A4	[23]	*/	unsigned int	Rev00A4_23	:	1	;
		/*	0x00A4	[24]	*/	unsigned int	REC_FM22_E_V_OFFSET	:	7	;
		/*	0x00A4	[31]	*/	unsigned int	Rev00A4_31	:	1	;

		/*	0x00A8	[00]	*/	unsigned int	Rev00A8_00	:	8	;
		/*	0x00A8	[08]	*/	unsigned int	REC_VD_PD_F6_V_MASK_SIZE_FIX	:	7	;
		/*	0x00A8	[15]	*/	unsigned int	Rev00A8_15	:	9	;
		/*	0x00A8	[24]	*/	unsigned int	REC_VD_PD_F7_V_MASK_SIZE_FIX	:	7	;
		/*	0x00A8	[31]	*/	unsigned int	Rev00A8_31	:	1	;

		/*	0x00AC	[00]	*/	unsigned int	Rev00AC_00	:	8	;
		/*	0x00AC	[08]	*/	unsigned int	REC_VD_PD_F6_V_MASK_SIZE	:	7	;
		/*	0x00AC	[15]	*/	unsigned int	Rev00AC_15	:	9	;
		/*	0x00AC	[24]	*/	unsigned int	REC_VD_PD_F7_V_MASK_SIZE	:	7	;
		/*	0x00AC	[31]	*/	unsigned int	Rev00AC_31	:	1	;

		/*	0x00B0	[00]	*/	unsigned int	Rev00B0_00	:	8	;
		/*	0x00B0	[08]	*/	unsigned int	REC_VD_PD_F4_V_MASK_SIZE_FIX	:	7	;
		/*	0x00B0	[15]	*/	unsigned int	Rev00B0_15	:	9	;
		/*	0x00B0	[24]	*/	unsigned int	REC_VD_PD_F5_V_MASK_SIZE_FIX	:	7	;
		/*	0x00B0	[31]	*/	unsigned int	Rev00B0_31	:	1	;

		/*	0x00B4	[00]	*/	unsigned int	Rev00B4_00	:	8	;
		/*	0x00B4	[08]	*/	unsigned int	REC_VD_PD_F4_V_MASK_SIZE	:	7	;
		/*	0x00B4	[15]	*/	unsigned int	Rev00B4_15	:	9	;
		/*	0x00B4	[24]	*/	unsigned int	REC_VD_PD_F5_V_MASK_SIZE	:	7	;
		/*	0x00B4	[31]	*/	unsigned int	Rev00B4_31	:	1	;

		/*	0x00B8	[00]	*/	unsigned int	Rev00B8_00	:	8	;
		/*	0x00B8	[08]	*/	unsigned int	REC_VD_PD_F2_V_MASK_SIZE_FIX	:	7	;
		/*	0x00B8	[15]	*/	unsigned int	Rev00B8_15	:	9	;
		/*	0x00B8	[24]	*/	unsigned int	REC_VD_PD_F3_V_MASK_SIZE_FIX	:	7	;
		/*	0x00B8	[31]	*/	unsigned int	Rev00B8_31	:	1	;

		/*	0x00BC	[00]	*/	unsigned int	Rev00BC_00	:	8	;
		/*	0x00BC	[08]	*/	unsigned int	REC_VD_PD_F2_V_MASK_SIZE	:	7	;
		/*	0x00BC	[15]	*/	unsigned int	Rev00BC_15	:	9	;
		/*	0x00BC	[24]	*/	unsigned int	REC_VD_PD_F3_V_MASK_SIZE	:	7	;
		/*	0x00BC	[31]	*/	unsigned int	Rev00BC_31	:	1	;

		/*	0x00C0	[00]	*/	unsigned int	REC_VD_PD_H_MASK_SIZE_FIX	:	6	;
		/*	0x00C0	[06]	*/	unsigned int	Rev00C0_06	:	2	;
		/*	0x00C0	[08]	*/	unsigned int	REC_VD_PD_F0_V_MASK_SIZE_FIX	:	7	;
		/*	0x00C0	[15]	*/	unsigned int	Rev00C0_15	:	9	;
		/*	0x00C0	[24]	*/	unsigned int	REC_VD_PD_F1_V_MASK_SIZE_FIX	:	7	;
		/*	0x00C0	[31]	*/	unsigned int	Rev00C0_31	:	1	;

		/*	0x00C4	[00]	*/	unsigned int	REC_VD_PD_H_MASK_SIZE	:	6	;
		/*	0x00C4	[06]	*/	unsigned int	Rev00C4_06	:	2	;
		/*	0x00C4	[08]	*/	unsigned int	REC_VD_PD_F0_V_MASK_SIZE	:	7	;
		/*	0x00C4	[15]	*/	unsigned int	Rev00C4_15	:	9	;
		/*	0x00C4	[24]	*/	unsigned int	REC_VD_PD_F1_V_MASK_SIZE	:	7	;
		/*	0x00C4	[31]	*/	unsigned int	Rev00C4_31	:	1	;

		/*	0x00C8	[00]	*/	unsigned int	VDPD_RECG_END_R_INT_CLR	:	1	;
		/*	0x00C8	[01]	*/	unsigned int	VDPD_RECG_UP_END_R_INT_CLR	:	1	;
		/*	0x00C8	[02]	*/	unsigned int	Rev00C8_02	:	2	;
		/*	0x00C8	[04]	*/	unsigned int	VDPD_RECG_END_ERR_INT_CLR	:	1	;
		/*	0x00C8	[05]	*/	unsigned int	Rev00C8_05	:	1	;
		/*	0x00C8	[06]	*/	unsigned int	VDPD_RECG_SRT_INT_CLR	:	1	;
		/*	0x00C8	[07]	*/	unsigned int	Rev00C8_07	:	1	;
		/*	0x00C8	[08]	*/	unsigned int	PSEUDO_RECG_END_INT_CLR	:	1	;
		/*	0x00C8	[09]	*/	unsigned int	Rev00C8_09	:	23	;

		/*	0x00CC	[00]	*/	unsigned int	VDPD_RECG_END_R_INT_EN	:	1	;
		/*	0x00CC	[01]	*/	unsigned int	VDPD_RECG_UP_END_R_INT_EN	:	1	;
		/*	0x00CC	[02]	*/	unsigned int	Rev00CC_02	:	2	;
		/*	0x00CC	[04]	*/	unsigned int	VDPD_RECG_END_ERR_INT_EN	:	1	;
		/*	0x00CC	[05]	*/	unsigned int	Rev00CC_05	:	1	;
		/*	0x00CC	[06]	*/	unsigned int	VDPD_RECG_SRT_INT_EN	:	1	;
		/*	0x00CC	[07]	*/	unsigned int	Rev00CC_07	:	1	;
		/*	0x00CC	[08]	*/	unsigned int	PSEUDO_RECG_END_INT_EN	:	1	;
		/*	0x00CC	[09]	*/	unsigned int	Rev00CC_09	:	7	;
		/*	0x00CC	[16]	*/	unsigned int	INT_PULSE_EN	:	1	;
		/*	0x00CC	[17]	*/	unsigned int	Rev00CC_17	:	15	;

		/*	0x00D0	[00]	*/	unsigned int	VDPD_RECG_END	:	1	;
		/*	0x00D0	[01]	*/	unsigned int	VDPD_RECG_UP_END	:	1	;
		/*	0x00D0	[02]	*/	unsigned int	Rev00D0_02	:	2	;
		/*	0x00D0	[04]	*/	unsigned int	VDPD_RECG_ERR	:	1	;
		/*	0x00D0	[05]	*/	unsigned int	Rev00D0_05	:	1	;
		/*	0x00D0	[06]	*/	unsigned int	VDPD_RECG_SRT	:	1	;
		/*	0x00D0	[07]	*/	unsigned int	Rev00D0_07	:	1	;
		/*	0x00D0	[08]	*/	unsigned int	VDPD_RECG_END_R_INT	:	1	;
		/*	0x00D0	[09]	*/	unsigned int	VDPD_RECG_UP_END_R_INT	:	1	;
		/*	0x00D0	[10]	*/	unsigned int	Rev00D0_10	:	2	;
		/*	0x00D0	[12]	*/	unsigned int	VDPD_RECG_END_ERR_INT	:	1	;
		/*	0x00D0	[13]	*/	unsigned int	Rev00D0_13	:	1	;
		/*	0x00D0	[14]	*/	unsigned int	VDPD_RECG_SRT_INT	:	1	;
		/*	0x00D0	[15]	*/	unsigned int	Rev00D0_15	:	1	;
		/*	0x00D0	[16]	*/	unsigned int	PSEUDO_RECG_END_INT	:	1	;
		/*	0x00D0	[17]	*/	unsigned int	Rev00D0_17	:	15	;

		/*	0x00D4	[00]	*/	unsigned int	F0_REC_EN	:	1	;
		/*	0x00D4	[01]	*/	unsigned int	Rev00D4_01	:	1	;
		/*	0x00D4	[02]	*/	unsigned int	F1_REC_EN	:	1	;
		/*	0x00D4	[03]	*/	unsigned int	Rev00D4_03	:	1	;
		/*	0x00D4	[04]	*/	unsigned int	F2_REC_EN	:	1	;
		/*	0x00D4	[05]	*/	unsigned int	Rev00D4_05	:	1	;
		/*	0x00D4	[06]	*/	unsigned int	F3_REC_EN	:	1	;
		/*	0x00D4	[07]	*/	unsigned int	Rev00D4_07	:	1	;
		/*	0x00D4	[08]	*/	unsigned int	F4_REC_EN	:	1	;
		/*	0x00D4	[09]	*/	unsigned int	Rev00D4_09	:	1	;
		/*	0x00D4	[10]	*/	unsigned int	F5_REC_EN	:	1	;
		/*	0x00D4	[11]	*/	unsigned int	Rev00D4_11	:	1	;
		/*	0x00D4	[12]	*/	unsigned int	F6_REC_EN	:	1	;
		/*	0x00D4	[13]	*/	unsigned int	Rev00D4_13	:	1	;
		/*	0x00D4	[14]	*/	unsigned int	F7_REC_EN	:	1	;
		/*	0x00D4	[15]	*/	unsigned int	Rev00D4_15	:	2	;
		/*	0x00D4	[17]	*/	unsigned int	ACF_C_EN	:	1	;
		/*	0x00D4	[18]	*/	unsigned int	ACF_Y_PENALTY_EN	:	1	;
		/*	0x00D4	[19]	*/	unsigned int	ACF_YC_MERGE_EN	:	1	;
		/*	0x00D4	[20]	*/	unsigned int	Rev00D4_20	:	12	;
		/*	0x00D8	[00]	*/	unsigned int	RESULT_Q_BUFF_SIZE	:	8	;
		/*	0x00D8	[08]	*/	unsigned int	Rev00D8_08	:	24	;
		/*	0x00DC	[00]	*/	unsigned int	ACF_NORM_FACTOR	:	7	;
		/*	0x00DC	[07]	*/	unsigned int	Rev00DC_07	:	25	;

		/*  0x00E0	[00]	*/ unsigned int		Rev00E0_00[(0x00F8-0x00E0)/4];

		/*	0x00F8	[00]	*/	unsigned int	PARAM_MANUAL_INIT	:	1	;
		/*	0x00F8	[01]	*/	unsigned int	Rev00F8_01	:	31	;

		/*	0x00FC	[00]	*/	unsigned int	Fx_WR_SEL	:	3	;
		/*	0x00FC	[03]	*/	unsigned int	Rev00FC_03	:	29	;

		/*  0x0100	[00] 	*/ unsigned int		Fx_ACF_PARAM[4]				;	// 0x0100 ~ 0x010C

		/*	0x0110	[00]	*/	unsigned int	Rev0110_00	:	32	;

		/*	0x0114	[00]	*/	unsigned int	Rev0114_00	:	32	;

		/*	0x0118	[00]	*/	unsigned int	Fx_ACF_PARAM_ADDR	:	32	;

		/*	0x011C	[00]	*/	unsigned int	Fx_ACF_PARAM_WEN	:	1	;
		/*	0x011C	[01]	*/	unsigned int	Rev011C_01	:	15	;
		/*	0x011C	[16]	*/	unsigned int	Fx_ACF_PARAM_CEN	:	1	;
		/*	0x011C	[17]	*/	unsigned int	Rev011C_17	:	15	;

		/*	0x0120	[00]	*/	unsigned int	Fx_ACF_REJECT_THRESHOLD	:	16	;
		/*	0x0120	[16]	*/	unsigned int	Fx_ACF_THRESHOLD	:	16	;

		/*	0x0124	[00]	*/	unsigned int	Fx_ACF_REJECT_WEAK_CNT	:	16	;
		/*	0x0124	[16]	*/	unsigned int	Fx_ACF_WEAK_CNT	:	16	;

		/*	0x0128	[00]	*/	unsigned int	Rev0128_00	:	32	;

		/*	0x012C	[00]	*/	unsigned int	Fx_ALL_ACF_PARAM_CHECKSUM_SRT	:	1	;
		/*	0x012C	[01]	*/	unsigned int	Rev012C_01	:	7	;
		/*	0x012C	[08]	*/	unsigned int	Fx_ALL_ACF_PARAM_CHECKSUM_END	:	1	;
		/*	0x012C	[09]	*/	unsigned int	Rev012C_09	:	7	;
		/*	0x012C	[16]	*/	unsigned int	Fx_ALL_ACF_PARAM_CHECKSUM_CLR	:	1	;
		/*	0x012C	[17]	*/	unsigned int	Rev012C_17	:	15	;


		/*	0x0130	[00] 	*/	 unsigned int	Fx_ACF_PARAM_CHECKSUM[8];		// 0x0130 ~ 0x014C
		/* 	0x0150	[00] 	*/	 unsigned int 	Rev0150;						// 0x0150
		/* 	0x0154	[00]	*/	 H_V_PADDING_STRIDE	HV_PADDING_STRIDE1[18];		// 0x0154 ~ 0x0198

		//===========================================================
		/* 	0x019C	[00] 	*/ 	unsigned int	Rev01B0_00[(0x0200-0x019C)/4];

		/*	0x0200	[00] 	*/ 	unsigned int	REC_Fx_RESULT_BASE_ADDR[8][2];
		/* 	0x0240	[00] 	*/ 	unsigned int	R_REC_Fx_RESULT_BASE_ADDR[8][2];

		/* 	0x0280	[00] 	*/ 	REC_RESULT_CNT	FXX_SW_OP_REC_RESULT_CNT[8]; //0x0280 ~ 0x028F

		/* 	0x02A0	[00] 	*/ 	REC_RESULT_UP_CNT FXX_REC_RESULT_UP_CNT[8];

		/* 	0x02C0	[00] 	*/	unsigned int	Rev02C0_00[(0x03E4-0x02C0)/4];

		/*	0x03E4	[00]	*/	unsigned int	PSEUDO_END_CNT	:	32	;

		/*	0x03E8	[00]	*/	unsigned int	VD_PD_RESULT_CNT_MAX_IS_OVER_64	:	1	;
		/*	0x03E8	[01]	*/	unsigned int	Rev03E8_01	:	15	;
		/*	0x03E8	[16]	*/	unsigned int	VD_PD_RESULT_CROP_DOWN_INV	:	1	;
		/*	0x03E8	[17]	*/	unsigned int	Rev03E8_17	:	15	;

		/* 0x03EC[00] */ unsigned int	Rev03F0_00[(0x0DF0-0x03EC)/4];
	}Reg;
}RE_VDPD_REGISTER;

#endif


