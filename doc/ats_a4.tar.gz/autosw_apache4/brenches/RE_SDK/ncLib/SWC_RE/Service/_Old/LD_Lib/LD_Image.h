#ifndef _LD_IMAGE_H_
#define _LD_IMAGE_H_
#include "LD_Searching.h"
#include "LD_Register.h"

typedef union{
	unsigned int	Data32[2];
	struct{
		unsigned int posY:			16;
		unsigned int cntY:			16;

		unsigned int posX1:			10;
		unsigned int posX2:			10;
		unsigned int Rev_0:			12;
	}REG;
}TABLE_ORG2TV;

typedef union{
	unsigned int	Data32;
	struct{
		unsigned int posY: 16;
		unsigned int Rev_0: 16;
	}REG;
}TABLE_TV2ORG;

#define LD_IMG_WIDTH	640
#define LD_IMG_HEIGHT	360

#define TV_IMG_WIDTH	640
#define TV_IMG_HEIGHT	360

#define CAM_H			1140
#define CAM_F			8.0
#define SEN_C			0.0042

#define TV_RATIO_W		8
#define TV_RATIO_H2		2

extern TABLE_ORG2TV	TableOrg2TV[LD_IMG_HEIGHT];
extern LD_REGISTER	LdReg;

extern int svp_x, AddDiffY[2];


#ifdef _RUN_MFC
extern void LD_Init_Register(int pp_x, int vp_y, int vp_x, int end_y,
							 int DiffTh, int YTh, int CbTh, int CrTh, int UTh, int VTh, int LaneDiff
							 );//(LD_REGISTER InitReg)
#else
extern void LD_Init_Register(NCLD_REGISTER *sLdStatusReg);
#endif

extern void LD_Img_Make_TopView_Table(void);
extern void LD_Img_Make_TopView_YUV_H_From_Org(unsigned char *src_y, unsigned char *src_u, unsigned char *src_v, unsigned char *dest);
extern void LD_Img_Candi1_In_TopView_YUV_H(unsigned char *src, unsigned char *dest);
extern void LD_Img_Candi2_In_TopView_YUV_H(unsigned char *src, unsigned char *dest);

extern POINT_XY LD_Image_Make_OrgXY_Point_From_TopView(POINT_XY tvLane);
extern POINT_XY LD_Image_Draw_OrgXY_From_TopView(POINT_XY tvLane);
extern void Calculate_Point(int *pointX, int x1, int y1, int x2, int y2);

#ifdef _RUN_MFC
	extern void LD_Image_Overlay_TopView_To_Org(unsigned char *src_y, unsigned char *dest);
#else
	extern void LD_Image_Overlay_TopView_To_Org(unsigned char *src_y, unsigned char *destY, unsigned char *destU, unsigned char *destV);
#endif

#if 1//def _RUN_MFC
	extern void Draw_Box(unsigned char *src, int width, int sx, int sy, int ex, int ey, unsigned char c);
#else
	extern void Draw_Box(unsigned char *srcY, unsigned char *srcU, unsigned char *srcV, int width, int sx, int sy, int ex, int ey, unsigned char c);
#endif


#ifdef _RUN_MFC
extern void LD_Image_Draw_Lane_On_Org(unsigned char *dest, NCLD_LANE_REGISTER *sLaneReg);
#else
extern void LD_Image_Draw_Lane_On_Org(NCLD_LANE_REGISTER *sLaneReg);
#endif

extern void Draw_Line(unsigned char *ptr, int w, int x1, int y1, int x2, int y2, unsigned char c);
extern void Draw_Line_Color(unsigned char *ImageY, unsigned char *ImageU, unsigned char *ImageV, int x1, int y1, int x2, int y2, unsigned char C);
//extern void Draw_Text(unsigned char* pCurDatabuf, char *ChString, unsigned int StX, unsigned int StY);

#endif // !_LD_IMAGE_H_

