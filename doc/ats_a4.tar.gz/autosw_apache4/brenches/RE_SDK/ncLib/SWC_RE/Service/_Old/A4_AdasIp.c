#include "common.h"
#include "A4_AdasIp.h"
#include "A4_RecgScaler.h"
#include "A4_RecgEng.h"
#include "A4_HsvOp.h"
#include "A4_Mod.h"
#include "A4_LD.h"
#include "./Tracking/RECG_NCFlow.h"

#include "RECG_Tracking.h"
#include "./clustering/APP_Nms.h"

#include "./LD_Lib/LD_Lib.h"
extern char EngFont_14[];

NCLD_REGISTER		sLdStatusReg[1];
NCLD_LANE_REGISTER	sLaneReg[4];

enum{
	R_1280x960 = 0,
	R_1280x720
}RESOLUTION_SELECTION;

volatile ADAS_STATUS AdasStatus;


volatile ADAS_SIZE 					adas_size;

volatile unsigned int 				*scaler64_checksum;
volatile unsigned int 				engdraw=0;
tAR_RECGINT 	sRecgInt;
tAR_MODINT 		sModInt;
tAR_IMAGE_SIZE	sImageSize;

	//To use NCC
	IDNumber ID[2];
//----------------------------------------------------------------------------------------------

void test_apb(void)
{


	sReModReg->Reg.MOD_BASE_ADDR_LV0 = FM12_START_ADDR;	//	80  x 60 image start address
	sReModReg->Reg.MOD_RD_IRQ_BOUNDARY = 63;	// [24]IRQ_BOUNDARY = 8-1

	while(1);
}


//----------------------------------------------------------------------------------------------
void A4_AdasIP_Interrupt_Init(void)
{
	int i, j, grid_x_num, grid_y_num;

	JIGMSG("@@ ADAS IP Enable Init Start0\n");

	sReScalerReg->Reg.RES_FM0_Y_EN 	 	 = 1;
	sReScalerReg->Reg.RES_FM2_Y_EN		 = 1;
	sReScalerReg->Reg.RES_FM4_Y_EN		 = 1;
	sReScalerReg->Reg.RES_FM6_Y_EN		 = 1;
	sReScalerReg->Reg.RES_FMc_Y_EN		 = 1;
	sReScalerReg->Reg.RES_FMe_Y_EN		 = 1;
	sReScalerReg->Reg.RES_FM10_Y_EN	 = 1;
	sReScalerReg->Reg.RES_FM12_Y_EN	 = 1;
	sReScalerReg->Reg.RES_WIDE_FM0_Y_EN = 1;
	sReScalerReg->Reg.RES_WIDE_FM2_Y_EN = 1;
	sReScalerReg->Reg.RES_WIDE_FM4_Y_EN = 1;

	sReScalerReg->Reg.RES_FM0_C_EN		 = 1;
	sReScalerReg->Reg.RES_FM2_C_EN		 = 1;
	sReScalerReg->Reg.RES_FM4_C_EN		 = 1;
	sReScalerReg->Reg.RES_FM6_C_EN		 = 0;//
	sReScalerReg->Reg.RES_FMc_C_EN		 = 1;
	sReScalerReg->Reg.RES_FMe_C_EN		 = 1;
	sReScalerReg->Reg.RES_FM10_C_EN	 = 1;
	sReScalerReg->Reg.RES_FM12_C_EN	 = 0;//
	sReScalerReg->Reg.RES_WIDE_FM0_C_EN = 1;
	sReScalerReg->Reg.RES_WIDE_FM2_C_EN = 1;
	sReScalerReg->Reg.RES_WIDE_FM4_C_EN = 1;



#ifdef	_SCALER_INT_EN
	sReScalerReg->Reg.RES_START_INT_EN = 1;
	sReScalerReg->Reg.RES_END_INT_EN = 1;
	sReScalerReg->Reg.RES_PSEUDO_END_INT_EN = 1;
	sReScalerReg->Reg.RES_ERROR_INT_EN = 1;
#endif

#ifdef _LD_INIT
	sReLdReg->Reg.LANE_DETECTION_EN		= 1      ;
#else
	sReLdReg->Reg.LANE_DETECTION_EN		= 0      ;
#endif

#ifdef	HSV_OP_TEST
	sReCeReg->Reg.HSV_CH0_OP_EN = 1;
	sReCeReg->Reg.HSV_CH1_OP_EN = 1;
#else
	sReCeReg->Reg.HSV_CH0_OP_EN = 0;
	sReCeReg->Reg.HSV_CH1_OP_EN = 0;
#endif
	#ifdef	_MOD_ON
	JIGMSG("MOD is on!!\n");

		sReModReg->Reg.MOD_EN_0 = 1;
		sReModReg->Reg.MOD_EN_1 = 1;
		sReModReg->Reg.MOD_NCC_EN = 1;
		sReModReg->Reg.MOD_INT_EN_OF_START 	= 1;
		sReModReg->Reg.MOD_INT_EN_OF_BUFFER_F = 0;
		sReModReg->Reg.MOD_INT_EN_OF_END_R 	= 1;
		sReModReg->Reg.MOD_INT_EN_PSEUDO_END_R = 1;
	#else
		sReModReg->Reg.MOD_EN_0 = 0;  // fp
		sReModReg->Reg.MOD_EN_1 = 0;  // of
	#endif


	#ifdef	_RECG_ON
		sReVdpdReg->Reg.REC_VD_PD_EN 	= 1;
		sReVdpdReg->Reg.REC_VD_PD_C_EN = 1;
	#else
		sReVdpdReg->Reg.REC_VD_PD_EN = 0;
		sReVdpdReg->Reg.REC_VD_PD_C_EN = 0;
	#endif


	sReModReg->Reg.MOD_GRID_MODE =0;

#ifdef	_MOD_ON
#if 0
	sReModReg->Reg.MOD_GRID_MAX = 32;
	sReModReg->Reg.MOD_GRID_ADDR = 0;
	grid_x_num = 16;
	grid_y_num = 2;

	for(i = 0 ; i < grid_y_num ; i++)
		{

		for(j = 0 ; j < grid_x_num ; j++)
		{

			sReModReg->Reg.MOD_GRID_X = (unsigned int)(320 / (grid_x_num) * (j) + 160 / grid_x_num );
			sReModReg->Reg.MOD_GRID_Y = (unsigned int)(180 / (grid_y_num) * (i) + 90  / grid_y_num );
			//sReModReg->Reg.MOD_GRID_WEN = 1 ;
			sReModReg->Reg.MOD_GRID_WEN = 1;
			sReModReg->Reg.MOD_GRID_WEN = 0;
			sReModReg->Reg.MOD_GRID_ADDR += 1;
		}
	}
	sReModReg->Reg.MOD_GRID_MODE =1;
#else

	grid_x_num = 20	;
	grid_y_num = 10;
	sReModReg->Reg.MOD_GRID_MAX = grid_x_num * grid_y_num;
	sReModReg->Reg.MOD_GRID_ADDR = 0;
#if 1
	for(i = 0 ; i < grid_y_num ; i++)
	{
		for(j = 0 ; j < grid_x_num ; j++)
		{

			sReModReg->Reg.MOD_GRID_X = (unsigned int)(adas_size.width_6 / (grid_x_num) * (j) + adas_size.width_6/ 2 / grid_x_num );
			sReModReg->Reg.MOD_GRID_Y = (unsigned int)(adas_size.height_6 / (grid_y_num) * (i) + adas_size.height_6 / 2 / grid_y_num );
			//sReModReg->Reg.MOD_GRID_WEN = 1 ;
			sReModReg->Reg.MOD_GRID_WEN = 1;
			sReModReg->Reg.MOD_GRID_WEN = 0;
			sReModReg->Reg.MOD_GRID_ADDR += 1;
		}
	}
	sReModReg->Reg.MOD_GRID_MODE = 0	;
#else

	for(i = 0 ; i < grid_y_num ; i++)
		{
			for(j = 0 ; j < grid_x_num ; j++)
			{

				sReModReg->Reg.MOD_GRID_X = 0x44;
				sReModReg->Reg.MOD_GRID_Y = 0x88;
				sReModReg->Reg.MOD_GRID_WEN = 1;
				sReModReg->Reg.MOD_GRID_WEN = 0;
				sReModReg->Reg.MOD_GRID_ADDR += 1;
			}
		}
		sReModReg->Reg.MOD_GRID_MODE =1;
#endif
#endif
#endif


	JIGMSG("@@ ADAS IP Enable Init End\n");
}


void Adas_Size_int(unsigned int type)
{
	if(type == 0)
	{
		adas_size.width_0  = 640;
		adas_size.width_2  = 512;
		adas_size.width_4  = 412;
		adas_size.width_6  = (unsigned int)(adas_size.width_0 / 2);
		adas_size.width_c  = (unsigned int)(adas_size.width_0 / 4);
		adas_size.width_e  = (unsigned int)(adas_size.width_2 / 4);
		adas_size.width_10 = (unsigned int)(adas_size.width_4 / 4 + 1);
		adas_size.width_12 = (unsigned int)(adas_size.width_0 / 8);

		adas_size.height_0  = 360;
		adas_size.height_2  = 288;
		adas_size.height_4  = 230;
		adas_size.height_6  = (unsigned int)(adas_size.height_0 / 2);
		adas_size.height_c  = (unsigned int)(adas_size.height_0 / 4);
		adas_size.height_e  = (unsigned int)(adas_size.height_2 / 4);
		adas_size.height_10 = (unsigned int)(adas_size.height_4 / 4);
		adas_size.height_12 = (unsigned int)(adas_size.height_0 / 8);

		adas_size.wide_width_0  = 1280;
		adas_size.wide_width_2  = 1024;
		adas_size.wide_width_4  = 820;

		adas_size.wide_height_0  = 360;
		adas_size.wide_height_2  = 288;
		adas_size.wide_height_4  = 230;

		adas_size.total_size_width  = 1650;
		adas_size.total_size_height = 750;

		adas_size.input_size_width  = 1280;
		adas_size.input_size_height = 720;
		adas_size.DTO = 0x2000;
		adas_size.DLY = 645;


/*
		sRePreReg->Reg.HUS_TG_H_DLY = 645;
		sRePreReg->Reg.HUS_TG_V_FDLY = 645;
		sRePreReg->Reg.HUS_TG_V_RDLY = 645;*/
	}
	else if(type ==1)
	{
		adas_size.width_0  = 640;
		adas_size.width_2  = 512;
		adas_size.width_4  = 412;
		adas_size.width_6  = (unsigned int)( adas_size.width_0 / 2);
		adas_size.width_c  = (unsigned int)( adas_size.width_0 / 4);
		adas_size.width_e  = (unsigned int)( adas_size.width_2 / 4);
		adas_size.width_10 = (unsigned int)( adas_size.width_4 / 4 + 1);
		adas_size.width_12 = (unsigned int)( adas_size.width_0 / 8);

		adas_size.height_0  = 360;
		adas_size.height_2  = 288;
		adas_size.height_4  = 230;
		adas_size.height_6  = (unsigned int)(adas_size.height_0 / 2);
		adas_size.height_c  = (unsigned int)(adas_size.height_0 / 4);
		adas_size.height_e  = (unsigned int)(adas_size.height_2 / 4);
		adas_size.height_10 = (unsigned int)(adas_size.height_4 / 4);
		adas_size.height_12 = (unsigned int)(adas_size.height_0 / 8);

		adas_size.wide_width_0  = 1920;
		adas_size.wide_width_2  = 1536;
		adas_size.wide_width_4  = 1228;

		adas_size.wide_height_0  = 480;
		adas_size.wide_height_2  = 384;
		adas_size.wide_height_4  = 307;

		adas_size.total_size_width  = 2200;
		adas_size.total_size_height = 1125;

		adas_size.input_size_width  = 1920;
		adas_size.input_size_height = 1080;
		adas_size.DTO = 0x3000;
		adas_size.DLY = 1285;
/*
		sRePreReg->Reg.HUS_TG_H_DLY = 1285;
		sRePreReg->Reg.HUS_TG_V_FDLY = 1285;
		sRePreReg->Reg.HUS_TG_V_RDLY = 1285;*/
	}
	else
	{
		adas_size.width_0  = 768;
		adas_size.width_2  = 616;
		adas_size.width_4  = 496;
		adas_size.width_6  = 384;
		adas_size.width_c  = 192;
		adas_size.width_e  = 144;
		adas_size.width_10 = 128;
		adas_size.width_12 = 96;

		adas_size.height_0  = 432;
		adas_size.height_2  = 345;
		adas_size.height_4  = 276;
		adas_size.height_6  = 216;
		adas_size.height_c  = 108;
		adas_size.height_e  = 88;
		adas_size.height_10 = 70;
		adas_size.height_12 = 54;

		adas_size.wide_width_0  = 3072;
		adas_size.wide_width_2  = 2458;
		adas_size.wide_width_4  = 1967;

		adas_size.wide_height_0  = 480;   //
		adas_size.wide_height_2  = 384;   //
		adas_size.wide_height_4  = 307;   //

		adas_size.total_size_width  = 3375;
		adas_size.total_size_height = 1760;

		adas_size.input_size_width  = 3072;
		adas_size.input_size_height = 1728;

		adas_size.DTO = 0x4000;
		adas_size.DLY = 2432;
	}
}



void acf_th_reset(int FilterSel)
{//
	sReVdpdReg->Reg.Fx_WR_SEL = FilterSel & 0x07;

	sReVdpdReg->Reg.Fx_ACF_REJECT_THRESHOLD = sReStatusReg.Reg.FxAcfValue[FilterSel].Reg.FxAcfRejectTh 		;
	sReVdpdReg->Reg.Fx_ACF_THRESHOLD 		 = sReStatusReg.Reg.FxAcfValue[FilterSel].Reg.FxAcfTh				;
	sReVdpdReg->Reg.Fx_ACF_REJECT_WEAK_CNT  = sReStatusReg.Reg.FxAcfValue[FilterSel].Reg.FxAcfRejectWeakCnt   ;
	sReVdpdReg->Reg.Fx_ACF_WEAK_CNT 		 = sReStatusReg.Reg.FxAcfValue[FilterSel].Reg.FxAcfWeakCnt		    ;

}


//------------------------------------------------------------------------------------------------------------------------
void ncDrv_AR_SetDisplayMode(void)
{
	UINT32	rest;
	UINT32	i;
	static UINT32 tCnt=0;

	const unsigned int preISP_size_H = 1280;
	const unsigned int preISP_size_V = 720 ;

	const unsigned int total_pixel_size_H = 1650;
	const unsigned int total_pixel_size_V = 750 ;

	const unsigned int output_W = 1280;
	const unsigned int output_H = 720;
	const unsigned int output_tot_W = 1650;
	const unsigned int output_tot_H = 750;
	tCnt++;
	if(tCnt == 9) tCnt = 1;

	sReStatusReg.Reg.FrameBufCnt = 4;

JIGMSG("ncDrv_AR_SetDisplayMode start \n");
	//sReStatusReg.Reg.DisModeSel = 1;

	//sRePostReg->Reg.RD_BUF_SEL = 1;		// display recg_scaling Image
	//sRePreReg->Reg.FM_YC_EN_MODE = 3; // enable pre Y,C Saving

	/*
	i = ab_asi_io_read(0x93010400);	JIGMSG( "1.post_isp=%08x\n", i);
	i = ab_asi_io_read(0x93010600);	JIGMSG( "2.post_tg=%08x\n", i);
	i = ab_asi_io_read(0x93010800);	JIGMSG( "3.pre_isp=%08x\n", i);
	i = ab_asi_io_read(0x93010A00);	JIGMSG( "4.scaler=%08x\n", i);
	i = ab_asi_io_read(0x93020000);	JIGMSG( "5.recg_eng=%08x\n", i);
	i = ab_asi_io_read(0x93050000);	JIGMSG( "6.mod=%08x\n", i);
	*/

	////sRePreReg->Reg.IN_TEST_MODE_TYPE = 7;
	////sRePreReg->Reg.FM_HSIZE = preISP_size_H;
	////sRePreReg->Reg.FM_VSIZE = preISP_size_V;

	//JIGMSG( "h-size=%d\n", sRePreReg->Reg.FM_HSIZE);
	JIGMSG("%d",sReStatusReg.Reg.Frame_skip);
	sRePreReg->Reg.FR_SKIP_CNT =3;//_SC_FR_SKIP;
	////sRePreReg->Reg.FR_SKIP_CNT0 = 0;
#if 1
	sRePostTgReg->Reg.DSP_OUT_SKIP_CNT = sRePreReg->Reg.FR_SKIP_CNT;

	sRePostTgReg->Reg.DSP_OUT_FL_H_ACT = output_W;
	sRePostTgReg->Reg.DSP_OUT_FL_H_TOTAL =adas_size.total_size_height *
			adas_size.total_size_width *(sRePreReg->Reg.FR_SKIP_CNT + 1) / output_tot_H;;

	sRePostTgReg->Reg.DSP_OUT_FL_V_ACT = output_H;
	sRePostTgReg->Reg.DSP_OUT_FL_V_TOTAL = output_tot_H;
	sRePostTgReg->Reg.DSP_OUT_FL_V_BLK1 = output_tot_H - output_H;

	sRePostReg->Reg.RD_BASE_ADDR = FM0_START_ADDR;

	sRePostReg->Reg.RD_BUF_MODE = 3;


	sRePreReg->Reg.DOWN_CROP_H_SIZE = adas_size.input_size_width;
	sRePreReg->Reg.DOWN_CROP_V_SIZE = adas_size.input_size_height;
	sRePreReg->Reg.DOWN_CROP_H_ACT  = adas_size.input_size_width;
	sRePreReg->Reg.DOWN_CROP_V_ACT  = adas_size.input_size_height;
	sRePreReg->Reg.DS_IN_HACT_SIZE  = adas_size.input_size_width;
	sRePreReg->Reg.DS_IN_HBLK_SIZE  = adas_size.total_size_width - adas_size.input_size_width;
	sRePreReg->Reg.DS_IN_VACT_SIZE  = adas_size.input_size_height;
	sRePreReg->Reg.DS_H_DTO = adas_size.DTO;
	sRePreReg->Reg.DS_V_DTO = adas_size.DTO;
	sRePreReg->Reg.DS_OUT_HACT_SIZE = adas_size.width_0;
    sRePreReg->Reg.DS_OUT_VACT_SIZE = adas_size.height_0;
    sRePreReg->Reg.HUS_IN_H_SIZE = adas_size.width_0;

    sRePreReg->Reg.WIDE_CROP_H_ACT  = adas_size.input_size_width;
    sRePreReg->Reg.WIDE_CROP_V_ACT  = adas_size.input_size_height;
    sRePreReg->Reg.WIDE_CROP_H_POS  = 0;
    if(sReStatusReg.Reg.start_status == 0)
    	sRePreReg->Reg.WIDE_CROP_V_POS  = 180;
    else if(sReStatusReg.Reg.start_status == 1)
    	sRePreReg->Reg.WIDE_CROP_V_POS  = adas_size.input_size_height / 2;
    else
    	sRePreReg->Reg.WIDE_CROP_V_POS  = adas_size.input_size_height / 2;
    sRePreReg->Reg.WIDE_CROP_H_SIZE = adas_size.wide_width_0;
    sRePreReg->Reg.WIDE_CROP_V_SIZE = adas_size.wide_height_0;

    sRePreReg->Reg.HUS_TG_H_ACT   = adas_size.width_0 ;
    sRePreReg->Reg.HUS_TG_H_DLY   = adas_size.DLY ;
    sRePreReg->Reg.HUS_TG_V_RDLY  = adas_size.DLY ;
    sRePreReg->Reg.HUS_TG_V_FDLY  = adas_size.DLY ;
    sRePreReg->Reg.HUS_UP_H_DISP  = adas_size.width_0;
	JIGMSG( "AR Start 1_2 \n");


	sReScalerReg->Reg.FRAME_TOT_PIX_CNT = adas_size.total_size_height * adas_size.total_size_width - 2;
#else
	sRePostTgReg->Reg.DSP_OUT_SKIP_CNT = sRePreReg->Reg.FR_SKIP_CNT;

	sRePostTgReg->Reg.DSP_OUT_FL_H_ACT = 1280;
	sRePostTgReg->Reg.DSP_OUT_FL_H_TOTAL =1650 *(sRePreReg->Reg.FR_SKIP_CNT + 1);;

	sRePostTgReg->Reg.DSP_OUT_FL_V_ACT = 720;
	sRePostTgReg->Reg.DSP_OUT_FL_V_TOTAL = 750;
	sRePostTgReg->Reg.DSP_OUT_FL_V_BLK1 = 30;

	sRePostReg->Reg.RD_BASE_ADDR = FM0_START_ADDR;

	sRePostReg->Reg.RD_BUF_MODE = 3;


	JIGMSG( "AR Start 1_2 \n");


	sReScalerReg->Reg.FRAME_TOT_PIX_CNT = 1650 * 750 - 2;
#endif
	sRePostReg->Reg.RD_PASS_SEL = 1;

	sRePostTgReg->Reg.DSP_OUT_TG_MODE = 1;	// 0 - bypass, 1 - frame lock, 2 - free run
	sRePostTgReg->Reg.DSP_OUT_BP_VS_MODE = 1;





	if(sReStatusReg.Reg.DisModeSel > 0)
	{
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = sReStatusReg.Reg.DisModeSel - 1;
	}

	if( sReStatusReg.Reg.DisModeSel == 1 )
	{
		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FM0_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FM0_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FM0_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM0_H_SIZE;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM0_V_SIZE;

		JIGMSG( "scaler_fm0_hsize = %d \n", sReScalerReg->Reg.RES_FM0_H_SIZE);
		JIGMSG( "post_fm0_hsize = %d \n", sRePostReg->Reg.RD_HSIZE);

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FM0_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 0;
		//sReScalerReg->Reg.RES_FM0_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM0_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 2 )
	{
		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FM2_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FM2_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FM2_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM2_H_SIZE;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM2_V_SIZE;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FM2_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 2;
		//sReScalerReg->Reg.RES_FM2_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM2_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 3 )
	{

		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FM4_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FM4_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FM4_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM4_H_SIZE;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM4_V_SIZE;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FM4_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 4;
		//sReScalerReg->Reg.RES_FM4_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM4_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 4 )
	{
		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FM6_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FM6_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FM6_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM0_H_SIZE / 2;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM0_V_SIZE / 2;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FM6_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 6;
		//sReScalerReg->Reg.RES_FM6_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM6_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 5 )
	{
		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FMc_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FMc_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FMc_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM0_H_SIZE / 4;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM0_V_SIZE / 4;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FMc_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 7;
		//sReScalerReg->Reg.RES_FMc_Y_EN = 1;
		//sReScalerReg->Reg.RES_FMc_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 6 )
	{
	   //// sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FM12_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FM12_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FM12_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM0_H_SIZE / 8;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM0_V_SIZE / 8;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FM12_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 8;
		//sReScalerReg->Reg.RES_FM12_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM12_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 7 )
	{
		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FMe_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FMe_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FMe_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM2_H_SIZE / 4;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM2_V_SIZE / 4;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FMe_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 3;
		//sReScalerReg->Reg.RES_FM12_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM12_C_EN = 1;
	}
	else if( sReStatusReg.Reg.DisModeSel == 8 )
	{
		////sRePreReg->Reg.FM_FRC_MODE    = sReScalerReg->Reg.RES_FM10_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE   = sReScalerReg->Reg.RES_FM10_FRC_MODE ;
		sRePostReg->Reg.RD_FRC_MODE_1 = sReScalerReg->Reg.RES_FM10_FRC_MODE ;

		sRePostReg->Reg.RD_HSIZE = sReScalerReg->Reg.RES_FM4_H_SIZE / 4 + 1;
		sRePostReg->Reg.RD_VSIZE = sReScalerReg->Reg.RES_FM4_V_SIZE / 4;

		sRePostReg->Reg.RD_BASE_ADDR = sReScalerReg->Reg.RES_FM10_BASE_ADDR;
		sReScalerReg->Reg.RES_W_BUFF_MODE_POST = 5;
		//sReScalerReg->Reg.RES_FM12_Y_EN = 1;
		//sReScalerReg->Reg.RES_FM12_C_EN = 1;
	}
}


void A4_AdasIp_Init(void)
{
	unsigned int Tmp;
	JIGMSG("@@ ADAS IP Init Start0\n");

	sReModReg->Reg.MOD_EN_0 = 0;  // fp
	sReModReg->Reg.MOD_EN_1 = 0;  // of
	AdasStatus.Reg.DrawFrameNum = 3;
	sReStatusReg.Reg.start_status = INPUT_IMG_SIZE ;

//#ifdef ACF_4TO8
	sReStatusReg.Reg.FilterCompareMode7  = 0;
	sReStatusReg.Reg.FilterCompareMode6  = 0;
	sReStatusReg.Reg.FilterCompareMode5  = 0;
	sReStatusReg.Reg.FilterCompareMode4  = 0;
	sReStatusReg.Reg.FilterCompareMode3  = 0;
	sReStatusReg.Reg.FilterCompareMode2  = 1;
	sReStatusReg.Reg.FilterCompareMode1  = 1;
	sReStatusReg.Reg.FilterCompareMode0  = 1;
	sReStatusReg.Reg.DisModeSel = 1;
	sReStatusReg.Reg.status_flag13 = 0 ;
	sReStatusReg.Reg.status_flag12 = 0 ;
	sReStatusReg.Reg.status_flag11 = 0 ;
	sReStatusReg.Reg.status_flag10 = 0 ;
	sReStatusReg.Reg.status_flag09 = 0 ;
	sReStatusReg.Reg.status_flag08 = 0 ;
	sReStatusReg.Reg.status_flag07 = 0 ;
	sReStatusReg.Reg.status_flag06 = 0 ;
	sReStatusReg.Reg.status_flag05 = 0 ;
	sReStatusReg.Reg.status_flag04 = 0 ;
	sReStatusReg.Reg.status_flag03 = 0 ;
	sReStatusReg.Reg.status_flag02 = 0 ;
	sReStatusReg.Reg.status_flag01 = 0 ;
	sReStatusReg.Reg.status_flag00 = 0 ;
	sReStatusReg.Reg.Frame_skip = 3;

	Adas_Size_int(sReStatusReg.Reg.start_status);



	A4_RecgScaler_Init();
	sReStatusReg.Reg.ClusteringBoxDisOn = 0;

#ifdef _LD_INIT
	A4_LD_Init();
#endif
	ncDrv_AR_SetDisplayMode();
	A4_Mod_Init();
	A4_RecgEng_Init();
 	// mod image start address
	A4_HsvOp_Init();

	AdasStatus.Data32 = 0;

	//JIGMSG("@@ ADAS IP Init Done\n", Tmp);
	JIGMSG("@@ ADAS IP Init Done\n");
}



void Gpio_Set(int gpio_num , int state)
{
	unsigned int tmp;

	tmp = REGRW32(0x08001040, 0);

	if(state == 1)
	{
		tmp |= 1<<gpio_num;
		REGRW32(0x08001040, 0) = tmp;
	}
	else
	{
		tmp &= ~(1<<gpio_num);
		REGRW32(0x08001040, 0) = tmp;
	}

}

const unsigned char ColorBarTable[8][3]={
		{235, 128, 128},	// 0 white
		{210,  16, 146},	// 1 Yellow
		{170, 166,  16},	// 2 Cyan
		{145,  54,  34},	// 3 Green
		{107, 202, 222},	// 4 Magenta
		{82,   90, 240},	// 5 Red
		{41,  240, 110},	// 6 Blue
		{16,  128, 128}		// 7 black
};


void Adas_frame_cnt()
{
	unsigned char *pYbuf;
	unsigned char *pCbbuf;
	int p,q;

	unsigned int sum = 0;
	int white_num ;
	int idx;

	if(VomBuffChCnt==0)			pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 0));
	else if(VomBuffChCnt==1)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 1));
	else if(VomBuffChCnt==2)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 2));
	else if(VomBuffChCnt==3)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 3));

	if(sReStatusReg.Reg.status_flag01 ==  1)
		return;

#if 1
	for(p=31; p>=0; p--)
	{
		white_num = 0;
		for(q=0; q<5; q++)
		{
			idx = p*5 + q;
			if(pYbuf[idx] > 200)
				white_num++;
		}

		if(white_num > 3)
		{
			int num = 1<<(31-p);
			sum = sum + num;
			//JIGMSG("%d %d %u\n",num ,p, sum);
		}
	}
#endif
	JIGMSG("%d\n",sum);

}
void Adas_draw_buff_cnt()
{
	unsigned int x, y, j, k;
	unsigned char *pYbuf;
	unsigned char *pCbbuf;

	unsigned int img_width, img_height;

	img_width = adas_size.width_0;
	img_height = adas_size.height_0;

	if(VomBuffChCnt==0)			pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 0));
	else if(VomBuffChCnt==1)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 1));
	else if(VomBuffChCnt==2)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 2));
	else if(VomBuffChCnt==3)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 3));

	if(VomBuffChCnt==0)			pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 0));
	else if(VomBuffChCnt==1)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 1));
	else if(VomBuffChCnt==2)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 2));
	else if(VomBuffChCnt==3)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 3));
	for( j = 0; j<4; j++)
		{
			if(j == VomBuffChCnt)
				x=0;
			else
				x=7;

			for(y= 0 ; y<15;y++)
			{
				k = img_width * img_height - j * 15 - y - 1 ;
				pYbuf[k] = ColorBarTable[x][0];
				if((k %2) ==0)
				{
					pCbbuf[k] = ColorBarTable[x][1];
					pCbbuf[k + 1] = ColorBarTable[x][1];
				}
				else
				{
					pCbbuf[k] = ColorBarTable[x][1];
					pCbbuf[k - 1] = ColorBarTable[x][1];
				}
			}
		}
}
void Adas_draw_box(int ch, BOX_INFO* square)
{
	int x, y, j,i, Sx, Ex, Sy, Ey, k;
	unsigned char *pYbuf;
	unsigned char *pCbbuf;
	unsigned int  AdasWidth = adas_size.width_0 * _DRAW_SCALE;
	int  StX   ;
	int  StY   ;
	unsigned int  Width ;
	unsigned int  Height;
	int color ;
	unsigned int img_width, img_height;

	img_width = adas_size.width_0;
	img_height = adas_size.height_0;
	if(VomBuffChCnt==0)			pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 0));
	else if(VomBuffChCnt==1)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 1));
	else if(VomBuffChCnt==2)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 2));
	else if(VomBuffChCnt==3)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 3));

	if(VomBuffChCnt==0)			pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 0));
	else if(VomBuffChCnt==1)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 1));
	else if(VomBuffChCnt==2)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 2));
	else if(VomBuffChCnt==3)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 3));

	for(i = 0 ; i < square->BoxNumMax;i++)
	{

		if(square->BaxXYWH[i].FrameNum > 24){
			color = COLOR_WHITE;
			//JIGMSG("w_c\n");
		}
		else
			color = ch;
		StX 	= ((int)square->BaxXYWH[i].StX		) * _DRAW_SCALE;
		StY 	= ((int)square->BaxXYWH[i].StY		) * _DRAW_SCALE;
		Width 	= ((unsigned int)square->BaxXYWH[i].Width	) * _DRAW_SCALE;
		Height 	= ((unsigned int)square->BaxXYWH[i].Height	) * _DRAW_SCALE;


		StX = StX < 0? 0 : StX;
		StY = StY < 0? 0 : StY;

		if(StX + Width > img_width-1)
			Width = img_width - StX -1;

		if(StY + Height > img_height-1)
			Height = img_height - StY -1;

		/*if((StX + Width) == ADAS_WIDTH_0)
		{
			Width--;
		}
		else if((StY + Height) == ADAS_HEIGHT_0)
		{
			Height--;
		}

		if((StX + Width) >= ADAS_WIDTH_0)
		{

			JIGMSG("W_Err:x:%03d, w:%03d  %3d\n", StX, Width, ch);
			continue;
		}
		else if((StY + Height) >= ADAS_HEIGHT_0)
		{
			JIGMSG("H_Err:y:%03d, h:%03d  %3d\n", StY, Height, ch);
					continue;
		}*/

		for(j=0; j<4; j++)
		{
			if(j == 0)		{ Sy = StY;				Ey = StY;			Sx = StX;			Ex = StX + Width;   }
			else if(j == 1)	{ Sy = StY + Height;	Ey = StY + Height;	Sx = StX;			Ex = StX + Width;   }
			else if(j == 2)	{ Sy = StY;				Ey = StY + Height;	Sx = StX;			Ex = StX; }
			else			{ Sy = StY;				Ey = StY + Height;	Sx = StX + Width;	Ex = StX + Width;   }

			for(y=Sy; y<=Ey; y++)
			{
				for(x=Sx; x<=Ex; x++)
				{
					k = y * AdasWidth + x;

						pYbuf[k] = ColorBarTable[color][0]; // Y

						//k = y/2 * AdasWidth/2 + x/2;
						if((k%2) == 0)
						{
							pCbbuf[k]   = ColorBarTable[color][1]; // Cb
							pCbbuf[k+1] = ColorBarTable[color][2]; // Cr
						}
						else
						{
							pCbbuf[k-1] = ColorBarTable[color][1]; // Cb
							pCbbuf[k] 	= ColorBarTable[color][2]; // Cr
						}
				}
			}
		}
	}
}

void Adas_draw_label(int ch, Label* square)
{
	unsigned int x, y, j,i, Sx, Ex, Sy, Ey, k;
	unsigned char *pYbuf;
	unsigned char *pCbbuf;
	unsigned int  AdasWidth = adas_size.width_0 * _DRAW_SCALE;
	unsigned int  StX   ;
	unsigned int  StY   ;
	unsigned int  Width ;
	unsigned int  Height;

	unsigned int img_width, img_height;

	img_width = adas_size.width_0;
	img_height = adas_size.height_0;


	if(VomBuffChCnt==0)			pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 0));
	else if(VomBuffChCnt==1)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 1));
	else if(VomBuffChCnt==2)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 2));
	else if(VomBuffChCnt==3)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 3));

	if(VomBuffChCnt==0)			pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 0));
	else if(VomBuffChCnt==1)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 1));
	else if(VomBuffChCnt==2)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 2));
	else if(VomBuffChCnt==3)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 3));
	for(i = 0 ; i < square->num_label;i++)
	{
		StX 	= ((unsigned int)square->left[i]	) * _DRAW_SCALE;
		StY 	= ((unsigned int)square->top[i]		) * _DRAW_SCALE;
		Width 	= ((unsigned int)square->width[i]	) * _DRAW_SCALE;
		Height 	= ((unsigned int)square->height[i]	) * _DRAW_SCALE;

		if((StX + Width) == img_width)
		{
			Width--;
		}
		else if((StY + Height) == img_height)
		{
			Height--;
		}

		if((StX + Width) >= img_width)
		{

			JIGMSG("W_Err:x:%03d, w:%03d  %3d\n", StX, Width, ch);
			return;
		}
		else if((StY + Height) >= img_height)
		{
			JIGMSG("H_Err:y:%03d, h:%03d  %3d\n", StY, Height, ch);
					return;
		}

		for(j=0; j<4; j++)
		{
			if(j == 0)		{ Sy = StY;				Ey = StY;			Sx = StX;			Ex = StX + Width;   }
			else if(j == 1)	{ Sy = StY + Height;	Ey = StY + Height;	Sx = StX;			Ex = StX + Width;   }
			else if(j == 2)	{ Sy = StY;				Ey = StY + Height;	Sx = StX;			Ex = StX; }
			else			{ Sy = StY;				Ey = StY + Height;	Sx = StX + Width;	Ex = StX + Width;   }

			for(y=Sy; y<=Ey; y++)
			{
				for(x=Sx; x<=Ex; x++)
				{
					k = y * AdasWidth + x;

						pYbuf[k] = ColorBarTable[ch][0]; // Y

						//k = y/2 * AdasWidth/2 + x/2;
						if((k%2) == 0)
						{
							pCbbuf[k]   = ColorBarTable[ch][1]; // Cb
							pCbbuf[k+1] = ColorBarTable[ch][2]; // Cr
						}
						else
						{
							pCbbuf[k-1] = ColorBarTable[ch][1]; // Cb
							pCbbuf[k] 	= ColorBarTable[ch][2]; // Cr
						}
				}
			}
		}
	}
}

//------------------------------------------------------------------------------------------------
volatile unsigned int StatusDL0=0, StatusDL1=0, StatusDL2=0;
void Adas_draw_line(MODValue *in_mod)
{
	unsigned int i=0;
	int cnt=0;
	unsigned char *pYbuf = 0;
	unsigned char *pCbbuf;
	unsigned int x, y, k, m, vector, Color = COLOR_MAX, absU, absV, ui_tmp;
	int ModV,ModU;
	unsigned int ModX,ModY;
	unsigned int img_width, img_height;

	StatusDL0 = 0;
	StatusDL1 = 0;
	StatusDL2 = 0;

	img_width = adas_size.width_0;
	img_height = adas_size.height_0;

	if(VomBuffChCnt==0)			pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 0));
	else if(VomBuffChCnt==1)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 1));
	else if(VomBuffChCnt==2)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 2));
	else if(VomBuffChCnt==3)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 3));

	if(VomBuffChCnt==0)			pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 0));
	else if(VomBuffChCnt==1)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 1));
	else if(VomBuffChCnt==2)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 2));
	else if(VomBuffChCnt==3)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 3));

	for(cnt = 0; cnt <in_mod->size; cnt++)
	{
		//pYbuf = canvas + (ModX + ModY * ADAS_WIDTH_0);

		ModX = (unsigned int)in_mod->ModVal[cnt].x       ;
		ModY = (unsigned int)in_mod->ModVal[cnt].y       ;
		ModU = (int)in_mod->ModVal[cnt].width   ;
		ModV = (int)in_mod->ModVal[cnt].height  ;

		if(ModV < 0)	absV = -ModV;
		else			absV = ModV;
		if(ModU < 0)	absU = -ModU;
		else			absU = ModU;
	/*
		COLOR_BLUE  = �쇊履쎌뿉�꽌 �삤瑜몄そ�쑝濡�
		COLOR_WHITE = �쐞履쎌뿉�꽌 �븘�옒履쎌쑝濡�
		COLOR_RED   = �삤瑜몄そ�뿉�꽌 �쇊履쎌쑝濡�
		COLOR_BLACK = �븘�옒履쎌뿉�꽌 �쐞履쎌쑝濡�


	*/


		if(absV == 0)
		{
			if(ModU > 0)		Color = COLOR_BLUE;
			else if(ModU < 0)	Color = COLOR_RED;
			else				Color = COLOR_MAX;
		}
		else if(absU == 0)
		{

			if(ModV > 0)		Color = COLOR_WHITE;
			else if(ModV < 0)	Color = COLOR_BLACK;
			else				Color = COLOR_MAX;
		}
		else
		{
			if((absU / absV) >= 2)
			{
				if(ModU > 0) 	Color = COLOR_BLUE;
				else			Color = COLOR_RED;
			}
			else if(((absU / absV) < 2) && ((absV / absU) < 2))
			{
				if((ModU > 0) &&  (ModV > 0))		Color = COLOR_CYAN;
				else if((ModU > 0) &&  (ModV < 0))	Color = COLOR_MAGENTA;
				else if((ModU < 0) &&  (ModV > 0))	Color = COLOR_GREEN;
				else if((ModU < 0) &&  (ModV < 0))	Color = COLOR_YELLOW;
			}
			else if((absV / absU) >= 2)
			{
				if(ModV > 0) 	Color = COLOR_WHITE;
				else			Color = COLOR_BLACK;
			}
			else
			{
				JIGMSG("Vector Error ");
			}
		}

		//Color = COLOR_MAX;

		StatusDL0 = ModX<<16 | ModY;
		StatusDL1 = absU<<16 | absV;
		StatusDL2 = Color;

		if(ModX >= img_width)
		{
			JIGMSG("X");
			return;
		}
		else if(ModY >= img_height)
		{
			JIGMSG("Y");
			return;
		}

		y = ModY;
		x = ModX;
;
		if(Color == COLOR_BLUE)
		{
			if((ModX+absU) >= img_width) absU = img_width - ModX - 1;

			for(x=ModX; x <= ModX+absU; x++)
			{
				k = y * img_width + x;
				pYbuf[k] = ColorBarTable[Color][0];

				if((k%2) == 0)
				{
					pCbbuf[k] = ColorBarTable[Color][1];
					pCbbuf[k+1] = ColorBarTable[Color][2];
				}
				else
				{
					pCbbuf[k-1] = ColorBarTable[Color][1]; // Cb
					pCbbuf[k] 	= ColorBarTable[Color][2]; // Cr
				}
			}
		}
		else if(Color == COLOR_RED)
		{
			if(ModX < absU) absU = ModX;

			for(x=ModX-absU; x <=ModX ; x++)
			{
				k = y * img_width + x;
				pYbuf[k] = ColorBarTable[Color][0];

				if((k%2) == 0)
				{
					pCbbuf[k] = ColorBarTable[Color][1];
					pCbbuf[k+1] = ColorBarTable[Color][2];
				}
				else
				{
					pCbbuf[k-1] = ColorBarTable[Color][1]; // Cb
					pCbbuf[k] 	= ColorBarTable[Color][2]; // Cr
				}
			}
		}
		else if(Color == COLOR_MAX)
		{
			Color = COLOR_YELLOW;


			x=ModX;
			k = y * img_width + x;
			pYbuf[k] = ColorBarTable[Color][0];

			if((k%2) == 0)
			{
				pCbbuf[k] = ColorBarTable[Color][1];
				pCbbuf[k+1] = ColorBarTable[Color][2];
			}
			else
			{
				pCbbuf[k-1] = ColorBarTable[Color][1]; // Cb
				pCbbuf[k] 	= ColorBarTable[Color][2]; // Cr
			}
		}
		else if(Color == COLOR_WHITE)
		{
			//Color = COLOR_RED;

			if(ModY < absV) absV = ModY;

			for(y=ModY-absV; y <=ModY ; y++)
			{
				k = y * img_width + x;
				pYbuf[k] = ColorBarTable[Color][0];

				if((k%2) == 0)
				{
					pCbbuf[k] = ColorBarTable[Color][1];
					pCbbuf[k+1] = ColorBarTable[Color][2];
				}
				else
				{
					pCbbuf[k-1] = ColorBarTable[Color][1]; // Cb
					pCbbuf[k] 	= ColorBarTable[Color][2]; // Cr
				}
			}
		}
		else if(Color == COLOR_BLACK)
		{
			//Color = COLOR_RED;

			if((ModY+absV) >= img_height) absV = img_height - ModY - 1;

			for(y=ModY; y <=ModY+absV ; y++)
			{
				k = y * img_width + x;
				pYbuf[k] = ColorBarTable[Color][0];

				if((k%2) == 0)
				{
					pCbbuf[k] = ColorBarTable[Color][1];
					pCbbuf[k+1] = ColorBarTable[Color][2];
				}
				else
				{
					pCbbuf[k-1] = ColorBarTable[Color][1]; // Cb
					pCbbuf[k] 	= ColorBarTable[Color][2]; // Cr
				}
			}
		}
		else if(Color == COLOR_MAGENTA)
		{
			Color = COLOR_BLUE;

			if((ModX+absU) >= img_width) absU = img_width - ModX - 1;
			if(ModY < absV) absV = ModY;

			i = 0;
			for(x=ModX; x <= ModX+absU; x++)
			{
				ui_tmp = absV * i / absU;
				if(ModY > ui_tmp)	y = ModY - ui_tmp;
				else				y = 0;
				i++;

				k = y * img_width + x;
				pYbuf[k] = ColorBarTable[Color][0];

				if((k%2) == 0)
				{
					pCbbuf[k] = ColorBarTable[Color][1];
					pCbbuf[k+1] = ColorBarTable[Color][2];
				}
				else
				{
					pCbbuf[k-1] = ColorBarTable[Color][1]; // Cb
					pCbbuf[k] 	= ColorBarTable[Color][2]; // Cr
				}
			}
		}
		else if(Color == COLOR_YELLOW)
		{
			Color = COLOR_RED;

			if(ModX < absU) absU = ModX;
			if(ModY < absV) absV = ModY;
			i = absU;
			for(x=ModX-absU; x <=ModX ; x++)
			{
				if(absU == 0)
					ui_tmp = absV * i;
				else
					ui_tmp = absV * i / absU;

				if(ModY > ui_tmp)	y = ModY - ui_tmp;
				else				y = 0;
				i--;

				k = y * img_width + x;
				pYbuf[k] = ColorBarTable[Color][0];

				if((k%2) == 0)
				{
					pCbbuf[k] = ColorBarTable[Color][1];
					pCbbuf[k+1] = ColorBarTable[Color][2];
				}
				else
				{
					pCbbuf[k-1] = ColorBarTable[Color][1]; // Cb
					pCbbuf[k] 	= ColorBarTable[Color][2]; // Cr
				}
			}
		}
		else if(Color == COLOR_GREEN)
		{
			Color = COLOR_RED;

			if(ModX < absU) absU = ModX;
			if((ModY+absV) >= img_height) absV = img_height - ModY - 1;

			i = absU;
			for(x=ModX-absU; x <=ModX ; x++)
			{
				if(absU == 0)
					y = ModY + absV * i ;
				else
					y = ModY + absV * i / absU;
				if(y >= img_height) y = img_height - 1;

				i--;

				k = y * img_width + x;
				pYbuf[k] = ColorBarTable[Color][0];

				if((k%2) == 0)
				{
					pCbbuf[k] = ColorBarTable[Color][1];
					pCbbuf[k+1] = ColorBarTable[Color][2];
				}
				else
				{
					pCbbuf[k-1] = ColorBarTable[Color][1]; // Cb
					pCbbuf[k] 	= ColorBarTable[Color][2]; // Cr
				}
			}
		}
		else if(Color == COLOR_CYAN)
		{
			Color = COLOR_BLUE;

			if((ModX+absU) >= img_width) absU = img_width - ModX - 1;
			if((ModY+absV) >= img_height) absV = img_height - ModY - 1;

			i = 0;
			for(x=ModX; x <=ModX+absU ; x++)
			{
				if(absU == 0)
					y = ModY + absV * i ;
				else
					y = ModY + absV * i / absU;
				if(y >= img_height) y = img_height - 1;
				i++;

				k = y * img_width + x;
				pYbuf[k] = ColorBarTable[Color][0];

				if((k%2) == 0)
				{
					pCbbuf[k] = ColorBarTable[Color][1];
					pCbbuf[k+1] = ColorBarTable[Color][2];
				}
				else
				{
					pCbbuf[k-1] = ColorBarTable[Color][1]; // Cb
					pCbbuf[k] 	= ColorBarTable[Color][2]; // Cr
				}
			}
		}
		else
		{
			//Color = COLOR_BLACK;
			//Color = COLOR_RED;
			Color = COLOR_YELLOW;

			x=ModX;
			k = y * img_width + x;
			pYbuf[k] = ColorBarTable[Color][0];

			if((k%2) == 0)
			{
				pCbbuf[k] = ColorBarTable[Color][1];
				pCbbuf[k+1] = ColorBarTable[Color][2];
			}
			else
			{
				pCbbuf[k-1] = ColorBarTable[Color][1]; // Cb
				pCbbuf[k] 	= ColorBarTable[Color][2]; // Cr
			}
		}
	}
}
//----------------------------------------------------------------------------------------------------

void Draw_Text(char *ChString, unsigned int StX, unsigned int StY) // OutSel Bit0
{
	unsigned long x, y, k, z, i;

	unsigned char *pSrc, *pSrcAddr;
	unsigned char ReturnValue[100];
	unsigned char rdpix;
	unsigned char *pYbuf;


	if(VomBuffChCnt==0)			pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 0));
	else if(VomBuffChCnt==1)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 1));
	else if(VomBuffChCnt==2)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 2));
	else if(VomBuffChCnt==3)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 3));


	i = 0;
	while(*ChString != '\0')
	{
		if(*ChString == 0x20)								ReturnValue[i] = 0;	// space
		else if(*ChString <= 0x39)							ReturnValue[i] = *ChString - 0x2F;	// number
		else if((*ChString >= 0x41) & (*ChString <= 0x5A))	ReturnValue[i] = *ChString - 0x36;	// capital alphabet
		else if((*ChString >= 0x61) & (*ChString <= 0x7A))	ReturnValue[i] = *ChString - 0x56;	// alphabet
		else												ReturnValue[i] = 47;	// black
		ChString++;
		i++;
	}
	ReturnValue[i] = 0xFF;	// blank;

	pSrc = (unsigned char*)EngFont_14;

	z = 0;
	while(ReturnValue[z] != 0xFF)
	{
		pSrcAddr = pSrc + (14 * 14) * ReturnValue[z++];
		for(y=StY; y < StY+14; y++)
		{
			for(x=StX; x < StX+14; x++)
			{
				rdpix = *pSrcAddr;
				pSrcAddr+=1;
				if(rdpix > 0)
				{
					rdpix = 255;
					k = y * LD_IMG_WIDTH + x;
					//pCurDatabuf[k] = rdpix;
					pYbuf[k] = 255;
				}
			}
		}
		StX = StX + 14;
	}
}


//----------------------------------------------------------------------------------------------------

void Draw_Lane(int x1, int y1, int x2, int y2, unsigned char C)
{
	int x, y, m, k;
	unsigned char *pYbuf = 0;
	unsigned char *pCbbuf;

	unsigned int img_width, img_height;

	img_width = adas_size.width_0;
	img_height = adas_size.height_0;

	if((x1 <= 0) || (x1 >= LD_IMG_WIDTH))		return;
	if((x2 <= 0) || (x2 >= LD_IMG_WIDTH))		return;
	if((y1 <= 0) || (y1 >= LD_IMG_HEIGHT))		return;
	if((y2 <= 0) || (y2 >= LD_IMG_HEIGHT))		return;

	if(VomBuffChCnt==0)			pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 0));
	else if(VomBuffChCnt==1)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 1));
	else if(VomBuffChCnt==2)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 2));
	else if(VomBuffChCnt==3)	pYbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 3));

	if(VomBuffChCnt==0)			pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 0));
	else if(VomBuffChCnt==1)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 1));
	else if(VomBuffChCnt==2)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 2));
	else if(VomBuffChCnt==3)	pCbbuf = (unsigned char *)(FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0 * 4)+(adas_size.width_0 * adas_size.height_0 * 3));

	if (y1 > y2)
	{
		m = y1;
		y1 = y2;
		y2 = m;

		m = x1;
		x1 = x2;
		x2 = m;
	}

	//-------------------------------------------------------------------------
	// ?占쎌쭅?占쎌씤 寃쎌슦
	//-------------------------------------------------------------------------
	if (x1 == x2)
	{
		x = x1;
		for (y = y1; y <= y2; y++)
		{
			k = y * img_width + x;
			pYbuf[k] = ColorBarTable[C][0];

			if((k%2) == 0)
			{
				pCbbuf[k] = ColorBarTable[C][1];
				pCbbuf[k+1] = ColorBarTable[C][2];
			}
			else
			{
				pCbbuf[k-1] = ColorBarTable[C][1]; // Cb
				pCbbuf[k] 	= ColorBarTable[C][2]; // Cr
			}
		}
		return;
	}

	//-------------------------------------------------------------------------
	// (x1, y1) ?占쎌꽌 (x2, y2)源뚳옙? 吏곸꽑 洹몃━占�?
	//-------------------------------------------------------------------------
	if((y2 - y1) > 0)
	{
		for (y = y1; y <= y2; y++)
		{
			x = x1 + (x2 - x1) * (y - y1) / (y2 - y1);

			k = y * img_width + x;
			pYbuf[k] = ColorBarTable[C][0];

			if((k%2) == 0)
			{
				pCbbuf[k] = ColorBarTable[C][1];
				pCbbuf[k+1] = ColorBarTable[C][2];
			}
			else
			{
				pCbbuf[k-1] = ColorBarTable[C][1]; // Cb
				pCbbuf[k] 	= ColorBarTable[C][2]; // Cr
			}
		}
	}
	else
	{
		if (x1 > x2)
		{
			m = x1;
			x1 = x2;
			x2 = m;

			m = y1;
			y1 = y2;
			y2 = m;
		}

		for (x = x1; x <= x2; x++)
		{
			k = y * img_width + x;
			pYbuf[k] = ColorBarTable[C][0];

			if((k%2) == 0)
			{
				pCbbuf[k] = ColorBarTable[C][1];
				pCbbuf[k+1] = ColorBarTable[C][2];
			}
			else
			{
				pCbbuf[k-1] = ColorBarTable[C][1]; // Cb
				pCbbuf[k] 	= ColorBarTable[C][2]; // Cr
			}
		}
	}
}

//-----------------------------------------------------------------------------------------------------
extern volatile unsigned int ScalerIntOn;
extern volatile unsigned int LDIntOn;
extern volatile unsigned int ModIntOn;
extern volatile unsigned int RecgIntOn;
extern volatile unsigned int LDdatadown;
extern volatile unsigned int TailIntOn;


unsigned int frame_cnt = 0;
volatile unsigned int Mod_Cnt = 0;
unsigned int ModIntTestCnt=0;

unsigned char vd_tracking_on[4] = {0,};
unsigned char pd_tracking_on[3] = {0,};
unsigned char vd_side_tracking_on[3] = {0,};

void Adas_draw_main()
{
	static int start = 0;
	static int test_start = 0;

		// To use Ncc
		BOX_INFO		BoxTrackingOutInfoVD, BoxNMSOutInfoVD;
		BOX_INFO		BoxTrackingOutInfoVDSide, BoxNMSOutInfoVDSide;
		BOX_INFO		BoxTrackingOutInfoPD, BoxNMSOutInfoPD;
		BOX_INFO 		Tail;
		static BOX_INFO BoxOutInfoVD , BoxOutInfoVDSide, BoxOutInfoPD;
		static BOX_INFO PreBoxVD, PreBoxVDSide, PreBoxPD;


	unsigned int	i, tmp, k, cnt;
	figure 			BoxInfo;
	unsigned int	Sx, Sy, Ex, Ey;
	unsigned int 	draw0_cnt,draw2_cnt,draw1_cnt;
	volatile static unsigned int TmpCnt0 = 0, TmpCnt1 = 0, OldModCnt=0;


	if(LDdatadown ==1)
	{
		if(sReStatusReg.Reg.status_flag00 ==  1)
		{
			LD_DATA_Read();
		}
		if(sReLdReg->Reg.TEST_MODE)
		{
			LD_DATA_Read_test();
		}
		LDdatadown = 0;
	}

	if(RecgIntOn)	//if(AdasStatus.Reg.RecgStartOn)
	{
	//	JIGMSG("R");
		engdraw =1;
#ifdef	_DIS_G08_ON
		Gpio_Set(0,GPIO_HIGH);
#endif

		Adas_frame_cnt();
		A4_VDPDUpEndInt_Callback();



		Adas_draw_buff_cnt();
		RecgIntOn = 0; //AdasStatus.Reg.RecgStartOn = 0;
		vd_tracking_on[0] = 1;
		//return;

		if(1)//if(sReStatusReg.Reg.ClusteringBoxDisOn  ==  1)
		{
//VD clustering
			initial_Box(&DetBoxF00, &ID[RUN_VD]);

			box_scale_convert(&DetBoxF00, &DetBoxF00, RUN_VD);

			ADAS_nms(&DetBoxF00, &BoxNMSOutInfoVD);

			//Adas_draw_box(COLOR_GREEN , &BoxNMSOutInfoVD);

//VDSIDE clustering
			initial_Box(&DetBoxF01, &ID[RUN_VD_SIDE]);
			box_scale_convert(&DetBoxF01, &DetBoxF01, RUN_VD_SIDE);
			ADAS_nms(&DetBoxF01, &BoxNMSOutInfoVDSide);
//pd clustering

			initial_Box(&DetBoxF10, &ID[RUN_PD]);
			box_scale_convert(&DetBoxF10, &DetBoxF10, RUN_PD);
			ADAS_nms(&DetBoxF10, &BoxNMSOutInfoPD);
		}
		//JIGMSG("%d  %d  %d  %d  %d  %d  %d  %d\n",draw0_cnt ,DetCntFxx[k][1],draw2_cnt
		//		,DetCntFxx[k][3],DetCntFxx[k][4],DetCntFxx[k][5],DetCntFxx[k][6],DetCntFxx[k][7]);
/*

		#ifdef	_ACF_DRAW_ON
			#ifdef	_RECG_F00_ON
				Adas_draw_box(COLOR_YELLOW, &DetBoxF00);
			#endif

			#ifdef	_RECG_F01_ON
				Adas_draw_box(COLOR_CYAN, &DetBoxF01);
			#endif

			#ifdef	_RECG_F10_ON
				Adas_draw_box(COLOR_GREEN, &DetBoxF10);
			#endif

			#ifdef	_RECG_F11_ON
				Adas_draw_box(COLOR_MAGENTA, &DetBoxF11);
			#endif

			#ifdef	_RECG_F100_ON
				Adas_draw_box(COLOR_YELLOW, &DetBoxF100);
			#endif


			#ifdef	_RECG_F101_ON
				Adas_draw_box(COLOR_CYAN, &DetBoxF101);
			#endif

			#ifdef	_RECG_F110_ON
				Adas_draw_box(COLOR_GREEN, &DetBoxF110);
			#endif

			#ifdef	_RECG_F111_ON
				Adas_draw_box(COLOR_MAGENTA, &DetBoxF111);
			#endif
		#endif
*/
#ifdef	_DIS_G08_ON
		Gpio_Set(0,GPIO_LOW);
#endif

	}

	if(HsvOpIntOn)
	{

	//	JIGMSG("h");
#ifdef	_DIS_G08_ON
		Gpio_Set(0,GPIO_HIGH);
#endif
		vd_tracking_on[2] = 1;	// HSV

		HsvOpResult0[AdasStatus.Reg.RdBufSelHsv].num_label = HsvOpResultCnt0[AdasStatus.Reg.RdBufSelHsv];
		HsvOpResult1[AdasStatus.Reg.RdBufSelHsv].num_label = HsvOpResultCnt1[AdasStatus.Reg.RdBufSelHsv];
		Adas_draw_label(COLOR_RED, &HsvOpResult0[AdasStatus.Reg.RdBufSelHsv]);
		Adas_draw_label(COLOR_BLUE, &HsvOpResult1[AdasStatus.Reg.RdBufSelHsv]);

		HsvOpIntOn = 0;

#ifdef	_DIS_G08_ON
		Gpio_Set(0,GPIO_LOW);
#endif
	}

	if(ModIntOn ) //if(AdasStatus.Reg.ModStartOn)
	{
#ifdef	_DIS_G08_ON
		Gpio_Set(0,GPIO_HIGH);
#endif
//JIGMSG("m");
		Mod_Cnt = A4_MOD_Result();
		ModIntOn = 0; //AdasStatus.Reg.ModStartOn = 0;
		vd_tracking_on[1] = 1;

		#ifdef	_MOD_DRAW_ON

			k = AdasStatus.Reg.RdBufSelMod;
			//JIGMSG("ST0\n");

			ModIntTestCnt++;

			if(DetCntMod[k] == 1279)
			{
				JIGMSG("MOD_%d=%d\n", ModIntTestCnt, DetCntMod[k]);
				DetCntMod[k] = OldModCnt;
				ModIntTestCnt = 0;
			}
			else
			{
				OldModCnt = DetCntMod[k];
			}
			ModLine.size = (int)Mod_Cnt;

			//Adas_draw_line(ModLine[k][i].ModV, ModLine[k][i].ModU, ModLine[k][i].ModY, ModLine[k][i].ModX);
			Adas_draw_line(&ModLine);


		#endif

#ifdef	_DIS_G08_ON
			Gpio_Set(0,GPIO_LOW);
#endif

	}

#ifdef TRACKING
	// Tracking

	// Tracking
	if(vd_tracking_on[0] && vd_tracking_on[1] && vd_tracking_on[2] )
	{

#ifdef	_DIS_G08_ON
		Gpio_Set(0,GPIO_HIGH);
	#endif
		if(!start)
		{
			start = 1;
			PreBoxVD = BoxNMSOutInfoVD;
			Tail.BoxNumMax=0;
		}
		else
		{
			NCSize s;
			//IDNumber ID;
			s.width = 640; s.height=180;
			NCC_MedianFlow(s,&ModLine,&PreBoxVD, &BoxTrackingOutInfoVD,VD_MODE);
			//JIGMSG("1");
			NCRectf roi[NUM_MAX_LABEL];

			int p,q;
			int num_roi = 0;
			int yaddr = 0;
			unsigned char *yimage;

			if(VomBuffChCnt==0)			yaddr = FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 0);
			else if(VomBuffChCnt==1)	yaddr = FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 1);
			else if(VomBuffChCnt==2)	yaddr = FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 2);
			else if(VomBuffChCnt==3)	yaddr = FM0_START_ADDR+(adas_size.width_0 * adas_size.height_0  * 3);

			Detect_TailLight_using_Box((unsigned int) yaddr , &HsvOpResult0[AdasStatus.Reg.RdBufSelHsv] , roi, &num_roi, &BoxTrackingOutInfoVD, &Tail);
			//JIGMSG("2");
			//JIGMSG("%d %d\n",(int)BoxTrackingOutInfoVD.BaxXYWH[0].Width, (int)Tail.BaxXYWH[0].Width);

			//Adas_draw_box(COLOR_YELLOW, &BoxTrackingOutInfoVD);

			Tracking_Tail(&PreBoxVD , &BoxTrackingOutInfoVD, &BoxNMSOutInfoVD, &BoxOutInfoVD, &Tail, &ID[VD_MODE], VD_MODE);
			//JIGMSG("3");
			pile_box_exception(&BoxOutInfoVD, &BoxOutInfoVD, VD_MODE);
			//JIGMSG("4");
			Remove_Invalid_Box(&BoxOutInfoVD,&BoxOutInfoVD);
			//JIGMSG("5");

			PreBoxVD = BoxOutInfoVD;

		}

		//Adas_draw_box(COLOR_GREEN, &BoxNMSOutInfoVD);
		Adas_draw_box(COLOR_YELLOW, &BoxOutInfoVD);
		Adas_draw_box(COLOR_RED, &Tail);

		vd_tracking_on[0] = 0;		// Detection Engine
		vd_tracking_on[1] = 0;		// MOD Engine
		vd_tracking_on[2] = 0;		// HSV Engine
		vd_tracking_on[3] = 0;		// Tail Light Algorithm


	#ifdef	_DIS_G08_ON
		Gpio_Set(0,GPIO_LOW);
	#endif

	}
#endif

#ifdef _LD_ON
	if(LDIntOn)
		{

	#ifdef	_DIS_G08_ON
		for(i=0; i<100; i++)
		{
			Gpio_Set(0,GPIO_HIGH);
		}
	#endif

			//JIGMSG("ld_draw!!\n");
			LDIntOn=0;


			LD_Task(sLaneReg, sLdStatusReg);

			//ld_test_f();
	/*
			if(sLaneReg[1].LaneCnt > 0)
			{
				JIGMSG("(1=%03d %03d) ", sLaneReg[1].Lane[0].x, sLaneReg[1].Lane[0].y);
				JIGMSG("(%03d %03d) \n", sLaneReg[1].Lane[sLaneReg[1].LaneCnt-1].x, sLaneReg[1].Lane[sLaneReg[1].LaneCnt-1].y);
			}

			if(sLaneReg[2].LaneCnt > 0)
			{
				JIGMSG("(2=%03d %03d) ", sLaneReg[2].Lane[0].x, sLaneReg[2].Lane[0].y);
				JIGMSG("(%03d %03d) \n", sLaneReg[2].Lane[sLaneReg[2].LaneCnt-1].x, sLaneReg[2].Lane[sLaneReg[2].LaneCnt-1].y);
			}
	*/

	/*
			printf("\n--------------------\n");
			printf("@ lane 0 count = %d \n", sLaneReg[0].LaneCnt);
			for(i=0; i<sLaneReg[0].LaneCnt; i++)
				printf("x=%03d, y=%03d \n", sLaneReg[0].Lane[i].x, sLaneReg[0].Lane[i].y);

			printf("\n@ lane 1 count = %d \n", sLaneReg[1].LaneCnt);
			for(i=0; i<sLaneReg[1].LaneCnt; i++)
				printf("x=%03d, y=%03d \n", sLaneReg[1].Lane[i].x, sLaneReg[1].Lane[i].y);

			printf("\n@ lane 2 count = %d \n", sLaneReg[2].LaneCnt);
			for(i=0; i<sLaneReg[2].LaneCnt; i++)
				printf("x=%03d, y=%03d \n", sLaneReg[2].Lane[i].x, sLaneReg[2].Lane[i].y);

			printf("\n@ lane 3 count = %d \n", sLaneReg[3].LaneCnt);
			for(i=0; i<sLaneReg[3].LaneCnt; i++)
				printf("x=%03d, y=%03d \n", sLaneReg[3].Lane[i].x, sLaneReg[3].Lane[i].y);
	*/
			#if 0
				// draw lane
				for(i=1; i<=2; i++)
				{
					for(k=1; k<sLaneReg[i].LaneCnt; k++)
					{
						Draw_Lane(sLaneReg[i].Lane[k-1].x, sLaneReg[i].Lane[k-1].y, sLaneReg[i].Lane[k].x, sLaneReg[i].Lane[k].y, 5);
					}
				}
			#endif

	#ifdef	_DIS_G08_ON
		for(i=0; i<100; i++)
		{
			Gpio_Set(0,GPIO_LOW);
		}
	#endif

		JIGMSG("%d\n", start++);

		}
#endif
}



