/*
 * A4_LD.c
 *
 *  Created on: Dec 20, 2017
 *      Author: thcho
 */

#include "common.h"
#include "A4_AdasIp.h"
#include "A4_LD.h"

volatile LD_DATASET 		Ld_data[2][META_LD_CNT_MAX];
volatile unsigned int WrBufSelLd;
volatile unsigned int ReBufSelLd;
volatile unsigned int LD_addr = 0x29030000;
volatile unsigned int LDdatadown = 0;
void A4_LD_ISR_Handler(void)
{
	int i;
	unsigned int tmp;
	volatile static unsigned int LDStartIntOn = 0; //異붽��빐�빞�븿

	if(sReLdReg->Reg.LD_FRAME_START_FLAG)
	{
		//sReLdReg->Reg.LD_INT_CLR_FRAME_START  = 1;
		//sReLdReg->Reg.LD_INT_CLR_FRAME_START  = 0;
		//draw error code
		//JIGMSG("\n1");

		tmp = REGRW32(0x14050028,0);
		tmp = tmp | 1<<0;
		REGRW32(0x14050028,0) = tmp;
		tmp = tmp & ~(1<<0);
		REGRW32(0x14050028,0) = tmp;

		//interrupt error code
		if(LDStartIntOn == 1){}
			//JIGMSG("LD_end_interrrupt error!! \n");
		else
			LDStartIntOn = 1;

#ifdef	_DIS_G10_ON
		Gpio_Set(9,GPIO_HIGH);
#endif

	}

	if(sReLdReg->Reg.LD_AXI_FINISH_FLAG)
	{
		//sReLdReg->Reg.LD_INT_CLR_AXI_FINISH  = 1;
		//sReLdReg->Reg.LD_INT_CLR_AXI_FINISH  = 0;
		//axi bus data download

		tmp = REGRW32(0x14050028,0);
		tmp = tmp | 1<<1;
		REGRW32(0x14050028,0) = tmp;
		tmp = tmp & ~(1<<1);
		REGRW32(0x14050028,0) = tmp;
		LDdatadown =1;

#ifdef	_DIS_G10_ON
		Gpio_Set(9,GPIO_LOW);
#endif

		WrBufSelLd = sReLdReg->Reg.LD_AXI_MEM_SEL;
		if(WrBufSelLd)
		{
			LD_addr = sReLdReg->Reg.LD_BASE_ADDR0;
		}
		else
		{
			LD_addr = sReLdReg->Reg.LD_BASE_ADDR1;
		}

		//interrupt error code
		//confirm start end intrrupt pare
		if(LDStartIntOn == 0)
			JIGMSG("LD_start_interrupt error!! \n");
		else
			LDStartIntOn = 0;

		//axi bus data download
		//LDdatadown = 1;

		//JIGMSG("2");


	}
	if(sReLdReg->Reg.LD_INIT_FINISH_FLAG)
	{
		sReLdReg->Reg.LD_INT_CLR_INIT_FINISH  = 1;
		sReLdReg->Reg.LD_INT_CLR_INIT_FINISH  = 0;

		//JIGMSG("3");
	}
	if(sReLdReg->Reg.LD_PSEUDO_AXI_FINISH_FLAG)	// X
	{
		sReLdReg->Reg.LD_INT_CLR_PSEUDO_AXI_FINISH  = 1;
		sReLdReg->Reg.LD_INT_CLR_PSEUDO_AXI_FINISH  = 0;
		JIGMSG("LDA_SUDO\n");

	}
	if(sReLdReg->Reg.LD_PSEUDO_INIT_FINISH_FLAG)	// X
	{
		sReLdReg->Reg.LD_INT_CLR_PSEUDO_INIT_FINISH  = 1;
		sReLdReg->Reg.LD_INT_CLR_PSEUDO_INIT_FINISH  = 0;
		JIGMSG("LDI_SUDO\n");

		//JIGMSG("5");
	}
	if(sReLdReg->Reg.LD_FINISH_ERROR_FLAG)	// X
	{
		sReLdReg->Reg.LD_INT_CLR_FINISH_ERROR  = 1;
		sReLdReg->Reg.LD_INT_CLR_FINISH_ERROR  = 0;
		JIGMSG("LD_ERROR\n");
		//JIGMSG("6");
	}

	//abbd_intc_core_ifr_off(LD_CORE_IRQ);
}

void LD_DATA_Read_test(void)
{
/*
	int i, k, temp;
		REC_LD_RESULT0 *p_LD_RESULT0;
		REC_LD_RESULT1 *p_LD_RESULT1;

		REC_LD_RESULT0 tmp_LD_RESULT0;
		REC_LD_RESULT1 tmp_LD_RESULT1;
		REC_LD_RESULT0 LD_RESULT0;
		REC_LD_RESULT1 LD_RESULT1;

		p_LD_RESULT0 = LD_addr;
		p_LD_RESULT1 = LD_addr + 0x04;
	for(i = 0; i < 1152 ; i++)//1152
		{
			LD_RESULT0.Data32 = 0;
			LD_RESULT1.Data32 = 0;

			tmp_LD_RESULT0.Data32 = p_LD_RESULT0->Data32;
			LD_RESULT0.D8.Data0 = tmp_LD_RESULT0.D8.Data3;
			LD_RESULT0.D8.Data1 = tmp_LD_RESULT0.D8.Data2;
			LD_RESULT0.D8.Data2 = tmp_LD_RESULT0.D8.Data1;
			LD_RESULT0.D8.Data3 = tmp_LD_RESULT0.D8.Data0;

			tmp_LD_RESULT1.Data32 = p_LD_RESULT1->Data32;
			LD_RESULT1.D8.Data0 = tmp_LD_RESULT1.D8.Data3;
			LD_RESULT1.D8.Data1 = tmp_LD_RESULT1.D8.Data2;
			LD_RESULT1.D8.Data2 = tmp_LD_RESULT1.D8.Data1;
			LD_RESULT1.D8.Data3 = tmp_LD_RESULT1.D8.Data0;

			if(LD_RESULT0.Data32 != sReLdReg->Reg.TEST_CODE)
			{
				JIGMSG("0 error 4k ld %d  %x\n",i,LD_RESULT0.Data32 );
				return;
			}
			if(LD_RESULT1.Data32 != sReLdReg->Reg.TEST_CODE)
			{
				JIGMSG("1 error 4k ld %d  %x\n",i,LD_RESULT1.Data32 );
				return;
			}
			p_LD_RESULT0 += 2;
			p_LD_RESULT1 += 2;
		}
*/
}

void LD_DATA_Read(void)
{
	int i, k, temp;

	REC_LD_RESULT *p_LD_RESULT;
	REC_LD_RESULT LD_RESULT;

	p_LD_RESULT = (REC_LD_RESULT *)LD_addr;
	for(i = 0; i < 2304 ; i++)//1152
	{
		LD_RESULT.Data32[0] = p_LD_RESULT->Data32[0];
		LD_RESULT.Data32[1] = p_LD_RESULT->Data32[1];

		if(i ==1174)
			JIGMSG("%8x  , %8x,%8x  , %8x , %8x ",LD_RESULT.Reg.cen_y,LD_RESULT.Reg.cen_x,LD_RESULT.Reg.height,LD_RESULT.Reg.width,LD_RESULT.Reg.color);
		p_LD_RESULT += 1;
	}

	//JIGMSG("LD data test end\n");
}

void A4_LD_Init(void)
{
	int tmp;
	sReLdReg->Reg.LD_FRAME_SKIP			= 0;//sA4StatusRegister.Reg.Frame_skip      ;

	sReLdReg->Reg.LD_IMG_HEIGHT			= 360;//rA4RecgScalerRegister->Reg.RES_FM0_H_SIZE      ;
	sReLdReg->Reg.LD_IMG_WIDTH				= 640;//rA4RecgScalerRegister->Reg.RES_FM0_V_SIZE      ;

	sReLdReg->Reg.VP_X						= 320      ;
	sReLdReg->Reg.VP_Y						= 150      ;

	sReLdReg->Reg.TV_RATIO_W		        = 8      ;

	sReLdReg->Reg.CANDI1_Y_DIFF_TH		    = 10      ;//
	sReLdReg->Reg.CANDI1_U_TH				= 30      ;//
	sReLdReg->Reg.CANDI1_Y_TH				= 25      ;//
	sReLdReg->Reg.CANDI1_GAP				= 8       ;

	sReLdReg->Reg.CANDI1_MODE				= 0       ;
	sReLdReg->Reg.CANDI1_V_LEVEL_TH		= 140      ;//
	sReLdReg->Reg.CANDI1_V_TH				= 25      ;//
	sReLdReg->Reg.CANDI1_U_LEVEL_TH		= 140      ;
	sReLdReg->Reg.CANDI2_GAP		        = 6      ;


	sReLdReg->Reg.BLOCK_HEIGHT			    = 10      ;
	sReLdReg->Reg.BLOCK_WIDTH				= 10      ;

	sReLdReg->Reg.Y_BLOCK_TOT				= 36;//22;////(rA4RecgScalerRegister->Reg.RES_FM0_H_SIZE  /  sReLdReg->Reg.BLOCK_HEIGHT)	+ 1 ;
	sReLdReg->Reg.X_BLOCK_TOT				= 64;//38;////(rA4RecgScalerRegister->Reg.RES_FM0_V_SIZE  /  sReLdReg->Reg.BLOCK_WIDTH)	+ 1 ;

	sReLdReg->Reg.LAST_Y					= 340;//

	sReLdReg->Reg.LD_INT_EN_FINISH_ERROR			= 0		 ;
	sReLdReg->Reg.LD_INT_EN_PSEUDO_INIT_FINISH		= 0      ;
	sReLdReg->Reg.LD_PSEUDO_AXI_FINISH_FLAG			= 0      ;
	sReLdReg->Reg.LD_INT_EN_INIT_FINISH				= 0     ;
	sReLdReg->Reg.LD_INT_EN_AXI_FINISH				= 1      ;
	sReLdReg->Reg.LD_INT_EN_FRAME_START				= 1      ;

	sReLdReg->Reg.PSEUDO_LENGTH	= 100;
	sReLdReg->Reg.VSYNC_DELAY		= 1280;

	sReLdReg->Reg.TEST_MODE				= 0      ;
	sReLdReg->Reg.BLOCK_OVERLAP			= 2		 ;

#ifdef	_INT_PULSE_ON
	sReLdReg->Reg.LD_INT_PULSE_EN		    = 1      ;
#else
	sReLdReg->Reg.LD_INT_PULSE_EN		    = 0      ;
#endif

	sReLdReg->Reg.LD_BASE_ADDR0		    = 0x89030000      ;
	sReLdReg->Reg.LD_BASE_ADDR1			= 0x89040000      ;

	sReLdReg->Reg.LANE_DETECTION_EN		= 1      ;
	#ifdef	_LD_INT_EN
	//ncLib_INTC_Control(GCMD_INTC_SET_TRIG_MODE, IRQ_NUM_RE_LD, TRIG_EDGE_HIGH, CMD_END);
    if( ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_RE_LD, (PrVoid)A4_LD_ISR_Handler, CMD_END) != NC_SUCCESS )
    {
    	DEBUGMSG_SDK(MSGERR, "LD_INIT ERROR\n");
    }
	#endif
    JIGMSG("@@ LD_int_en\n");
}
