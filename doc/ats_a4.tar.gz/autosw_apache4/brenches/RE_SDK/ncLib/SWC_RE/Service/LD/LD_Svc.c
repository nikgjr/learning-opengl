/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    :
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version :
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "../RE_Svc.h"

/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile unsigned int LdWrBufSelLd;
volatile unsigned int LdReBufSelLd;
volatile unsigned int RE_LD_addr = 0x29030000;

/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void RE_LD_ISR_Handler(void)
{
	int i;
	unsigned int tmp;
	volatile static unsigned int LDStartIntOn = 0;

	if(sReLdReg->Reg.LD_FRAME_START_FLAG)
	{
		sReLdReg->Reg.LD_INT_CLR_FRAME_START  = 1;
		sReLdReg->Reg.LD_INT_CLR_FRAME_START  = 0;
		//draw error code
		//JIGMSG("\n1");

		//interrupt error code
		if(LDStartIntOn == 1){}
			//JIGMSG("LD_end_interrrupt error!! \n");
		else
			LDStartIntOn = 1;

		#ifdef	_DIS_G10_ON
				Gpio_Set(9,GPIO_HIGH);
		#endif

	}

	if(sReLdReg->Reg.LD_AXI_FINISH_FLAG)
	{
		sReLdReg->Reg.LD_INT_CLR_AXI_FINISH  = 1;
		sReLdReg->Reg.LD_INT_CLR_AXI_FINISH  = 0;
		//axi bus data download

		#ifdef	_DIS_G10_ON
			Gpio_Set(9,GPIO_LOW);
		#endif

		LdWrBufSelLd = sReLdReg->Reg.LD_AXI_MEM_SEL;
		if(LdWrBufSelLd)
		{
			RE_LD_addr = sReLdReg->Reg.LD_BASE_ADDR0;
		}
		else
		{
			RE_LD_addr = sReLdReg->Reg.LD_BASE_ADDR1;
		}

		//interrupt error code
		//confirm start end intrrupt pare
		if(LDStartIntOn == 0)
			JIGMSG("LD_start_interrupt error!! \n");
		else
			LDStartIntOn = 0;

		//axi bus data download
		//LDdatadown = 1;

		//JIGMSG("2");


	}
	if(sReLdReg->Reg.LD_INIT_FINISH_FLAG)
	{
		sReLdReg->Reg.LD_INT_CLR_INIT_FINISH  = 1;
		sReLdReg->Reg.LD_INT_CLR_INIT_FINISH  = 0;

		//JIGMSG("3");
	}
	if(sReLdReg->Reg.LD_PSEUDO_AXI_FINISH_FLAG)	// X
	{
		sReLdReg->Reg.LD_INT_CLR_PSEUDO_AXI_FINISH  = 1;
		sReLdReg->Reg.LD_INT_CLR_PSEUDO_AXI_FINISH  = 0;
		JIGMSG("LDA_SUDO\n");

	}
	if(sReLdReg->Reg.LD_PSEUDO_INIT_FINISH_FLAG)	// X
	{
		sReLdReg->Reg.LD_INT_CLR_PSEUDO_INIT_FINISH  = 1;
		sReLdReg->Reg.LD_INT_CLR_PSEUDO_INIT_FINISH  = 0;
		JIGMSG("LDI_SUDO\n");

		//JIGMSG("5");
	}
	if(sReLdReg->Reg.LD_FINISH_ERROR_FLAG)	// X
	{
		sReLdReg->Reg.LD_INT_CLR_FINISH_ERROR  = 1;
		sReLdReg->Reg.LD_INT_CLR_FINISH_ERROR  = 0;
		JIGMSG("LD_ERROR\n");
		//JIGMSG("6");
	}
}
void RE_LD_Init(void)
{
	sReLdReg->Reg.LD_FRAME_SKIP			= 0;//sA4StatusRegister.Reg.Frame_skip      ;

	sReLdReg->Reg.LD_IMG_HEIGHT			= 360;//rA4RecgScalerRegister->Reg.RES_FM0_H_SIZE      ;
	sReLdReg->Reg.LD_IMG_WIDTH				= 640;//rA4RecgScalerRegister->Reg.RES_FM0_V_SIZE      ;

	sReLdReg->Reg.VP_X						= 320      ;
	sReLdReg->Reg.VP_Y						= 150      ;

	sReLdReg->Reg.TV_RATIO_W		        = 8      ;

	sReLdReg->Reg.CANDI1_Y_DIFF_TH		    = 10      ;//
	sReLdReg->Reg.CANDI1_U_TH				= 30      ;//
	sReLdReg->Reg.CANDI1_Y_TH				= 25      ;//
	sReLdReg->Reg.CANDI1_GAP				= 8       ;

	sReLdReg->Reg.CANDI1_MODE				= 0       ;
	sReLdReg->Reg.CANDI1_V_LEVEL_TH		= 140      ;//
	sReLdReg->Reg.CANDI1_V_TH				= 25      ;//
	sReLdReg->Reg.CANDI1_U_LEVEL_TH		= 140      ;
	sReLdReg->Reg.CANDI2_GAP		        = 6      ;


	sReLdReg->Reg.BLOCK_HEIGHT			    = 10      ;
	sReLdReg->Reg.BLOCK_WIDTH				= 10      ;

	sReLdReg->Reg.Y_BLOCK_TOT				= 36;//22;////(rA4RecgScalerRegister->Reg.RES_FM0_H_SIZE  /  sReLdReg->Reg.BLOCK_HEIGHT)	+ 1 ;
	sReLdReg->Reg.X_BLOCK_TOT				= 64;//38;////(rA4RecgScalerRegister->Reg.RES_FM0_V_SIZE  /  sReLdReg->Reg.BLOCK_WIDTH)	+ 1 ;

	sReLdReg->Reg.LAST_Y					= 340;//

	sReLdReg->Reg.LD_INT_EN_FINISH_ERROR			= 0		 ;
	sReLdReg->Reg.LD_INT_EN_PSEUDO_INIT_FINISH		= 0      ;
	sReLdReg->Reg.LD_PSEUDO_AXI_FINISH_FLAG			= 0      ;
	sReLdReg->Reg.LD_INT_EN_INIT_FINISH				= 0     ;
	sReLdReg->Reg.LD_INT_EN_AXI_FINISH				= 1      ;
	sReLdReg->Reg.LD_INT_EN_FRAME_START				= 1      ;

	sReLdReg->Reg.PSEUDO_LENGTH	= 100;
	sReLdReg->Reg.VSYNC_DELAY		= 1280;

	sReLdReg->Reg.TEST_MODE				= 0      ;
	sReLdReg->Reg.BLOCK_OVERLAP			= 2		 ;

#ifdef	_INT_PULSE_ON
	sReLdReg->Reg.LD_INT_PULSE_EN		    = 1      ;
#else
	sReLdReg->Reg.LD_INT_PULSE_EN		    = 0      ;
#endif

	sReLdReg->Reg.LD_BASE_ADDR0		    = 0x89030000      ;
	sReLdReg->Reg.LD_BASE_ADDR1			= 0x89040000      ;

	sReLdReg->Reg.LANE_DETECTION_EN		= 0      ;
	#ifdef	_LD_INT_EN
	//ncLib_INTC_Control(GCMD_INTC_SET_TRIG_MODE, IRQ_NUM_RE_LD, TRIG_EDGE_HIGH, CMD_END);
    if( ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_RE_LD, (PrVoid)RE_LD_ISR_Handler, CMD_END) != NC_SUCCESS )
    {
    	DEBUGMSG_SDK(MSGERR, "LD_INIT ERROR\n");
    }
	#endif
    JIGMSG("@@ LD_int_en\n");
}



/* End Of File */

