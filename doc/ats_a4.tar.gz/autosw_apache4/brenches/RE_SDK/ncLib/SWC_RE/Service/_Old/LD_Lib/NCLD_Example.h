#ifndef _NCLD_EXAMPLE_H_
#define _NCLD_EXAMPLE_H_

#include "NCLD_Register.h"

extern void NCLD_Example(unsigned char *src_y, unsigned char *src_u, unsigned char *src_v);

#endif // !_NCLD_EXAMPLE_H_



