#ifndef	_A4_HSV_OP_H_
#define	_A4_HSV_OP_H_

#include "common.h"

#include "RECG_typedef.h"
#define	HSV_OP_CNT_MAX	100

extern Label	HsvOpResult0[2];
extern Label	HsvOpResult1[2];
extern unsigned int		HsvOpResultCnt0[2];
extern unsigned int		HsvOpResultCnt1[2];

extern unsigned int	HsvOpIntOn ;
#endif
 
