#include "libNCL_LD.h"
#include "NCLD_Register.h"

NCLD_REGISTER		sLdStatusReg[1];
NCLD_LANE_REGISTER	sLaneReg[4];

extern void LD_FRAMEWORK(unsigned char *src_y, unsigned char *src_u, unsigned char *src_v, NCLD_LANE_REGISTER *sLaneReg, NCLD_REGISTER *sLdStatusReg);

void NCLD_Example(unsigned char *src_y, unsigned char *src_u, unsigned char *src_v)
{
	int i;

	// setting status register
	sLdStatusReg[0].REG.VpX = 320;			// vanishing point x
	sLdStatusReg[0].REG.VpY = 150;			// vanishing point y
	sLdStatusReg[0].REG.EndY = 340;			// end of searching y
	sLdStatusReg[0].REG.ViewVStrEnd = 1;	// view on / off for "vanishing point y", "end of searching y"

	// call LD Framework
	LD_FRAMEWORK(src_y, src_u, src_v, sLaneReg, sLdStatusReg);

	// print Lane Detection Result
	printf("\n--------------------\n");
	printf("@ lane 0 count = %d \n", sLaneReg[0].LaneCnt);
	for(i=0; i<sLaneReg[0].LaneCnt; i++)
		printf("x=%03d, y=%03d \n", sLaneReg[0].Lane[i].x, sLaneReg[0].Lane[i].y);

	printf("\n@ lane 1 count = %d \n", sLaneReg[1].LaneCnt);
	for(i=0; i<sLaneReg[1].LaneCnt; i++)
		printf("x=%03d, y=%03d \n", sLaneReg[1].Lane[i].x, sLaneReg[1].Lane[i].y);

	printf("\n@ lane 2 count = %d \n", sLaneReg[2].LaneCnt);
	for(i=0; i<sLaneReg[2].LaneCnt; i++)
		printf("x=%03d, y=%03d \n", sLaneReg[2].Lane[i].x, sLaneReg[2].Lane[i].y);

	printf("\n@ lane 3 count = %d \n", sLaneReg[3].LaneCnt);
	for(i=0; i<sLaneReg[3].LaneCnt; i++)
		printf("x=%03d, y=%03d \n", sLaneReg[3].Lane[i].x, sLaneReg[3].Lane[i].y);

}
