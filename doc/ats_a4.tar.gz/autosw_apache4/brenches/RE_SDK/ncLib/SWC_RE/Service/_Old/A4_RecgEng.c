/*#---------------------------------------------------------------------
#
# Copyright Processor Group, 2006-2016, All rights reserved.
# Processor Group, System-on-Chip Research Department
# Electronics and Telecommunications Research Institute (ETRI)
#
# THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE
# WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS
# TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE
# REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL
# SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE,
# IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE
# COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
#
#
#------------------------------------------------------------------------*/
#include "common.h"
#include "A4_AdasIp.h"
#include "A4_RecgEng.h"
#include "Fx_ACF_TABLE.h"

/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/
#define	BOX_CNT_MAX			128
#define	FRAME_CNT_MAX		13

#define	DISPLAY_X_MAX		640
#define	DISPLAY_Y_MAX		480

#define	NVS3320_REG_CNT_MAX		64
#define	META_DATA_BOX_DIS_ON	0

#define	VDPD_RESULT_BUF_MAX	64
#define	TSR_RESULT_BUF_MAX	32

volatile unsigned int 	HWCntFxx[2][8] = {{0, 0, 0, 0, 0, 0, 0, 0},{0, 0, 0, 0, 0, 0, 0, 0}};
volatile unsigned int 	buf_num_Fxx[2][8] = {{0, 0, 0, 0, 0, 0, 0, 0},{0, 0, 0, 0, 0, 0, 0, 0}};

volatile unsigned int	DetCntFxx[2][8]={{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0}};


//--------------------------------------------------------------------------------------------------
BOX_INFO DetBoxF00;
BOX_INFO DetBoxF01;
BOX_INFO DetBoxF10;
BOX_INFO DetBoxF11;
BOX_INFO DetBoxF100;
BOX_INFO DetBoxF101;
BOX_INFO DetBoxF110;
BOX_INFO DetBoxF111;

//	A			B			C			D			E			F
//  100%    	A x 8/9   	A x 4/5		C x 8/9		C x 4/5		E x 8/9
unsigned long 	ExchangeRateX[]  = {1000*1, 	1000*1, 	1250*1, 	1250*1, 	1562*1, 	1562*1,
									1000*2, 	1000*2, 	1250*2, 	1250*2, 	1562*2, 	1562*2,
									1000*4, 	1000*4, 	1250*4, 	1250*4, 	1562*4, 	1562*4,
									1000*8, 	1000*8, 	1250*8, 	1250*8, 	1562*8, 	1562*8};

	//	A		B			C			D			E			F
	//  100%   	A x 8/9   	A x 4/5		C x 8/9		C x 4/5		E x 8/9
unsigned long 	ExchangeRateYWH[] = {1000*1, 	1125*1, 	1250*1, 	1406*1, 	1562*1, 	1757*1,
									 1000*2, 	1125*2, 	1250*2, 	1406*2, 	1562*2, 	1757*2,
									 1000*4, 	1125*4, 	1250*4, 	1406*4, 	1562*4, 	1757*4,
									 1000*8, 	1125*8, 	1250*8, 	1406*8, 	1562*8, 	1757*8};



#define	_TABLE_MAX	2048

volatile char	*pYbuf;


//---------------------------------------------------------------------------------------------------------------
void ncDrv_A4_WriteRecgTable_FX(unsigned int FilterSel)	// F1
{
	unsigned int 	j;

	sReVdpdReg->Reg.Fx_WR_SEL = FilterSel & 0x07;

	//= HAAR Y =============================================
	sReVdpdReg->Reg.Fx_ACF_PARAM_WEN = 1;
	sReVdpdReg->Reg.Fx_ACF_PARAM_CEN = 0;

	for(j=0; j<_TABLE_MAX; j++)
	{
		sReVdpdReg->Reg.Fx_ACF_PARAM_ADDR = j;
		sReVdpdReg->Reg.Fx_ACF_PARAM[0] = ACF_TABLE[FilterSel][2048*0 + j];
		sReVdpdReg->Reg.Fx_ACF_PARAM[1] = ACF_TABLE[FilterSel][2048*1 + j];
		sReVdpdReg->Reg.Fx_ACF_PARAM[2] = ACF_TABLE[FilterSel][2048*2 + j];
		sReVdpdReg->Reg.Fx_ACF_PARAM[3] = ACF_TABLE[FilterSel][2048*3 + j];

		sReVdpdReg->Reg.Fx_ACF_PARAM_CEN = 1;
		sReVdpdReg->Reg.Fx_ACF_PARAM_CEN = 0;
	}

	sReVdpdReg->Reg.Fx_ACF_REJECT_THRESHOLD = sReStatusReg.Reg.FxAcfValue[FilterSel].Reg.FxAcfRejectTh 		;
	sReVdpdReg->Reg.Fx_ACF_THRESHOLD 		 = sReStatusReg.Reg.FxAcfValue[FilterSel].Reg.FxAcfTh				;
	sReVdpdReg->Reg.Fx_ACF_REJECT_WEAK_CNT  = sReStatusReg.Reg.FxAcfValue[FilterSel].Reg.FxAcfRejectWeakCnt   ;
	sReVdpdReg->Reg.Fx_ACF_WEAK_CNT 		 = sReStatusReg.Reg.FxAcfValue[FilterSel].Reg.FxAcfWeakCnt		    ;


	sReVdpdReg->Reg.VD_PD_RESULT_CNT_MAX_IS_OVER_64 = 1;




	sReVdpdReg->Reg.Fx_ACF_PARAM_WEN = 0;
	sReVdpdReg->Reg.Fx_ACF_PARAM_CEN = 0;

	JIGMSG( "End Write ACF F%d\n", FilterSel);
}

//---------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------
void ncDrv_A4_ReadRecgTable_FX(void)
{
	unsigned int tmp, i;

	//return;

	//sReVdpdReg->Reg.F00_REC_EN = 0;
	//sReVdpdReg->Reg.F01_REC_EN = 0;

	//sReVdpdReg->Reg.F10_REC_EN = 0;
	//sReVdpdReg->Reg.F11_REC_EN = 0;

	JIGMSG( "Start Compare \n");

	//= ACF =============================================
	sReVdpdReg->Reg.Fx_ALL_ACF_PARAM_CHECKSUM_CLR = 0;
	sReVdpdReg->Reg.Fx_ALL_ACF_PARAM_CHECKSUM_CLR = 1;
	sReVdpdReg->Reg.Fx_ALL_ACF_PARAM_CHECKSUM_CLR = 0;

	sReVdpdReg->Reg.Fx_ALL_ACF_PARAM_CHECKSUM_SRT = 0;
	sReVdpdReg->Reg.Fx_ALL_ACF_PARAM_CHECKSUM_SRT = 1;
	sReVdpdReg->Reg.Fx_ALL_ACF_PARAM_CHECKSUM_SRT = 0;
	//while(sReVdpdReg->Reg.Fx_ALL_ACF_PARAM_CHECKSUM_END == 0);

	for(i=0; i<8; i++)
	{
		if(sReVdpdReg->Reg.Fx_ACF_PARAM_CHECKSUM[i] != ACF_TABLE_CS[i])
		{
			JIGMSG("ERROR : Compare F%d_CS \n", i);
		}
		else
		{
			JIGMSG("OK : Compare F%d_CS \n", i);
		}
	}

	//sReVdpdReg->Reg.F00_REC_EN = 1;
	//sReVdpdReg->Reg.F01_REC_EN = 1;

	//sReVdpdReg->Reg.F10_REC_EN = 1;
	//sReVdpdReg->Reg.F11_REC_EN = 1;

	JIGMSG( "End Compare ACF \n");
}

//--------------------------------------------------------------------------------------------------
void A4_VDPDUpEndInt_Callback(void)
{
	unsigned int	ExchangeY, ExchangeH;
	unsigned int	i, ResultFrame, RcgCntTmp, Fnum, MetaMaxCnt, MaskH;
	unsigned int 	StX, EnX, StY, EnY, Width, Height, CenterX, AcfValue, Fmx, CrDn;
	unsigned int 	Mod;
	unsigned int	Overflow;
	unsigned int	temp = 0 ;
	unsigned int 	tmp, SaveCntFxx,OpCntFxx;
	int j,k;
	ACF_RESULT		AcfResult;
	ACF_RESULT		*temp_AcfResult;
	BOX_INFO 		*DetBox;

	unsigned int img_width, img_height;

	img_width = adas_size.width_0;
	img_height = adas_size.height_0;

	for(Fnum=0; Fnum<8; Fnum++)
	{
		if(Fnum == 0) //vd
		{
			if(sReStatusReg.Reg.FilterCompareMode0 == 1)
			{
				MetaMaxCnt 	= META_F00_CNT_MAX - 1;
				MaskH 		= F00_MASK_H;
				DetBox 		= &DetBoxF00;
			}
			else
			{
				DetBox 		= &DetBoxF00;
				DetBox->BoxNumMax = 0;
				continue;
			}
		}
		else if(Fnum == 1) //vd side changyu's opinion
		{
			if(sReStatusReg.Reg.FilterCompareMode1 == 1)
			{
				MetaMaxCnt 	= META_F01_CNT_MAX - 1;
				MaskH 		= F01_MASK_H;
				DetBox 		= &DetBoxF01;
			}
			else
			{
				DetBox 		= &DetBoxF01;
				DetBox->BoxNumMax = 0;
				continue;
			}
		}
		else if(Fnum == 2) //pd
		{
			if(sReStatusReg.Reg.FilterCompareMode2 == 1)
			{
				MetaMaxCnt 	= META_F10_CNT_MAX - 1;
				MaskH 		= F10_MASK_H;
				DetBox 		= &DetBoxF10;
			}
			else
			{
				DetBox 		= &DetBoxF10;
				DetBox->BoxNumMax = 0;
				continue;
			}
		}

		else if(Fnum == 3)
		{
			if(sReStatusReg.Reg.FilterCompareMode3 == 1)
			{
				MetaMaxCnt 	= META_F11_CNT_MAX - 1;
				MaskH 		= F11_MASK_H;
				DetBox 		= &DetBoxF11;
			}
			else
			{
				DetBox 		= &DetBoxF11;
				DetBox->BoxNumMax = 0;
				continue;
			}
		}

		else if(Fnum == 4) //vd
		{
			if(sReStatusReg.Reg.FilterCompareMode4 == 1)
			{
				MetaMaxCnt 	= META_F00_CNT_MAX - 1;
				MaskH 		= F00_MASK_H;
				DetBox 		= &DetBoxF100;
			}
			else
			{
				DetBox 		= &DetBoxF100;
				DetBox->BoxNumMax = 0;
				continue;
			}
		}
		else if(Fnum == 5) //vd side changyu's opinion
		{
			if(sReStatusReg.Reg.FilterCompareMode5 == 1)
			{
				MetaMaxCnt 	= META_F01_CNT_MAX - 1;
				MaskH 		= F01_MASK_H;
				DetBox 		= &DetBoxF101;
			}
			else
			{
				DetBox 		= &DetBoxF101;
				DetBox->BoxNumMax = 0;
				continue;
			}
		}
		else if(Fnum == 6) //pd
		{
			if(sReStatusReg.Reg.FilterCompareMode6 == 1)
			{
				MetaMaxCnt 	= META_F10_CNT_MAX - 1;
				MaskH 		= F10_MASK_H;
				DetBox 		= &DetBoxF110;
			}
			else
			{
				DetBox 		= &DetBoxF110;
				DetBox->BoxNumMax = 0;
				continue;
			}
		}
		else if(Fnum == 7)
		{
			if(sReStatusReg.Reg.FilterCompareMode7 == 1)
			{
				MetaMaxCnt 	= META_F11_CNT_MAX - 1;
				MaskH 		= F11_MASK_H;
				DetBox 		= &DetBoxF111;
			}
			else
			{
				DetBox 		= &DetBoxF111;
				DetBox->BoxNumMax = 0;
				continue;
			}
		}
		else
		{
			continue;
		}
		DetBox->BoxNumMax = 0;
		OpCntFxx = 0;
		SaveCntFxx = 0;
		temp_AcfResult = (ACF_RESULT *)(sReVdpdReg->Reg.R_REC_Fx_RESULT_BASE_ADDR[Fnum][buf_num_Fxx[AdasStatus.Reg.RdBufSelACF][Fnum]]);

		while((OpCntFxx < HWCntFxx[AdasStatus.Reg.RdBufSelACF][Fnum]) & (SaveCntFxx < MetaMaxCnt))
		{
			AcfResult.Result[0] = 0;
			AcfResult.Result[1] = 0;
			for(j = 0; j < 2 ; j++)
			{
				temp = 0;
				for(k = 0; k < 4; k++)
				{

					temp = temp_AcfResult->Result[j] & 0x00FF;
					AcfResult.Result[j] = AcfResult.Result[j] | temp;
					if(k == 3)
						break;
					AcfResult.Result[j] = AcfResult.Result[j] << 8;
					AcfResult.Result[j] = AcfResult.Result[j] & 0xFFFFFF00;
					temp_AcfResult->Result[j] = temp_AcfResult->Result[j] >> 8;
				}
			}

			StX 	 = AcfResult.Reg.H_PNT;
			StY 	 = AcfResult.Reg.V_PNT;
			Fmx 	 = AcfResult.Reg.FM_X;

			CrDn 	 = AcfResult.Reg.CR_DN;
			AcfValue = AcfResult.Reg.ACF_VALUE;

			Overflow = 0;
			if(Fmx>35)	Overflow = Overflow + 0x01;
			if(Fmx<24)
			{
				if(StX > FXX_MASK_W/2)	StX = ExchangeRateX[Fmx] * 2 * (StX - FXX_MASK_W/2) / 1000;
				else					StX = 0;

				if(StY > MaskH/2)	StY = ExchangeRateYWH[Fmx] * 2 * (StY - MaskH/2) / 1000;
				else					StY = 0;

				EnX = StX + FXX_MASK_W * ExchangeRateYWH[Fmx] / 1000 - 1;
				EnY = StY + MaskH * ExchangeRateYWH[Fmx] / 1000 - 1;
			}

			else if(Fmx<36)
			{
				if(sReStatusReg.Reg.start_status == 0)
				{
					Fmx = Fmx - 24;
					if(StX > FXX_MASK_W/2)	StX = ExchangeRateX[Fmx] * 2 * (StX - FXX_MASK_W/2) / 2000;
					else					StX = 0;

					if(StY > MaskH/2)	StY = ExchangeRateYWH[Fmx] * 2 * (StY - MaskH/2) / 2000 + 90 ;
					else					StY = 0;

					EnX = StX + FXX_MASK_W * ExchangeRateYWH[Fmx] / 2000 - 1;
					EnY = StY + MaskH * ExchangeRateYWH[Fmx] / 2000 - 1;
					Fmx = Fmx + 24;
				}
				else if(sReStatusReg.Reg.start_status == 1)
				{
					Fmx = Fmx - 24;

					if(StX > FXX_MASK_W/2)	StX = ExchangeRateX[Fmx] * 2 * (StX - FXX_MASK_W/2) / 3000;
					else					StX = 0;

					if(StY > MaskH/2)	StY = ExchangeRateYWH[Fmx] * 2 * (StY - MaskH/2) / 3000 + sRePreReg->Reg.WIDE_CROP_V_POS / 3 ;
					else					StY = 0;

					EnX = StX + FXX_MASK_W * ExchangeRateYWH[Fmx] / 3000 - 1;
					EnY = StY + MaskH * ExchangeRateYWH[Fmx] / 3000 - 1;
					Fmx = Fmx + 24;
				}
				else
				{
					Fmx = Fmx - 24;
					if(StX > FXX_MASK_W/2)	StX = ExchangeRateX[Fmx] * 2 * (StX - FXX_MASK_W/2) * 5 / (24000);
					else					StX = 0;

					if(StY > MaskH/2)	StY = ExchangeRateYWH[Fmx] * 2 * (StY - MaskH/2) * 5 / (24000) + sRePreReg->Reg.WIDE_CROP_V_POS / 4 ;
					else					StY = 0;

					EnX = StX + FXX_MASK_W * ExchangeRateYWH[Fmx] * 5 / (24000) - 1;
					EnY = StY + MaskH * ExchangeRateYWH[Fmx] * 5 / (24000) - 1;
					Fmx = Fmx + 24;
				}

			}
			if(EnX >= img_width)	EnX = img_width - 1;
			if(EnY >= img_height)	EnY = img_height - 1;


			if(EnX >= img_width)	EnX = img_width - 1;
			if(EnY >= img_height)	EnY = img_height - 1;

			if(Overflow == 0)
			{
				DetBox->BaxXYWH[SaveCntFxx].StX		 = 	(float)(StX		);
				DetBox->BaxXYWH[SaveCntFxx].StY		 = 	(float)(StY		);
				DetBox->BaxXYWH[SaveCntFxx].Width	 = 	(float)(EnX - StX	);
				DetBox->BaxXYWH[SaveCntFxx].Height	 = 	(float)(EnY - StY	);
				DetBox->BaxXYWH[SaveCntFxx].score	 = 	(float)(AcfValue	);
				DetBox->BaxXYWH[SaveCntFxx].FrameNum =  (float)(Fmx		);
				SaveCntFxx++;
			}
			OpCntFxx++;

			temp_AcfResult += 1;
		}
		DetBox->BoxNumMax = SaveCntFxx;
	}




}

//--------------------------------------------------------------------------------------------------------------
void A4_VDPDStartInt_Callback(void)
{
	volatile static unsigned int VsyncSign=0;
	unsigned int cnt, tmp, i;

	AdasStatus.Reg.RdBufSelACF = AdasStatus.Reg.WrBufSelACF;
	AdasStatus.Reg.WrBufSelACF = ~AdasStatus.Reg.WrBufSelACF;

	AdasStatus.Reg.RecgStartOn = 1;
	//JIGMSG("sReVdpdReg->Reg.REC_FM0_RD_BUF_CNT = %d \n",sReVdpdReg->Reg.REC_FM0_RD_BUF_CNT);
}

//--------------------------------------------------------------------------------------------------
unsigned int recg_int_test=0, recg_cnt=0;
volatile unsigned int RecgIntOn = 0;
volatile unsigned int TailIntOn = 0;
volatile unsigned int LDIntOn = 0;

void A4_RECG_ENG_ISR_Handler(void)
{
	unsigned int tmp;
	volatile static unsigned int RecgStartIntOn = 0;
	int i;

#ifdef	_DIS_G09_ON
		Gpio_Set(8,GPIO_HIGH);
#endif
	if(sReVdpdReg->Reg.VDPD_RECG_SRT_INT)
	{

		/*
	if(LDIntOn == 1){}
				//JIGMSG("LD_draw error!!!/n");
	else
		LDIntOn = 1;*/

		sReVdpdReg->Reg.VDPD_RECG_SRT_INT_CLR = 1;
		sReVdpdReg->Reg.VDPD_RECG_SRT_INT_CLR = 0;

		tmp = REGRW32(0x140600c8,0);
		tmp = tmp | 1<<6;
		REGRW32(0x140600c8,0) = tmp;
		tmp = tmp & ~(1<<6);
		REGRW32(0x140600c8,0) = tmp;

		RecgStartIntOn = 1;

		A4_VDPDStartInt_Callback();

#ifdef	_DIS_G09_ON
		Gpio_Set(8,GPIO_LOW);
#endif

	   // JIGMSG("RS");
		//if(RecgIntOn)	JIGMSG("RS");
		RecgIntOn = 1;
	}
	if(sReVdpdReg->Reg.VDPD_RECG_END_ERR_INT)
	{
		sReVdpdReg->Reg.VDPD_RECG_END_ERR_INT_CLR = 1;
		sReVdpdReg->Reg.VDPD_RECG_END_ERR_INT_CLR = 0;
		JIGMSG("RE_ERROR\n");
	}
	if(sReVdpdReg->Reg.VDPD_RECG_END_R_INT)
	{
		sReVdpdReg->Reg.VDPD_RECG_END_R_INT_CLR = 1;
		sReVdpdReg->Reg.VDPD_RECG_END_R_INT_CLR = 0;
		//JIGMSG("RE_END\n");
	}
	if(sReVdpdReg->Reg.VDPD_RECG_UP_END_R_INT)
	{
		sReVdpdReg->Reg.VDPD_RECG_UP_END_R_INT_CLR = 1;
		sReVdpdReg->Reg.VDPD_RECG_UP_END_R_INT_CLR = 0;

		tmp = REGRW32(0x140600c8,0);
		tmp = tmp | 1<<1;
		REGRW32(0x140600c8,0) = tmp;
		tmp = tmp & ~(1<<1);
		REGRW32(0x140600c8,0) = tmp;



		for(i = 0; i < 8 ;i ++)
		{
			HWCntFxx[AdasStatus.Reg.WrBufSelACF][i] 	= sReVdpdReg->Reg.FXX_SW_OP_REC_RESULT_CNT[i].Reg.FXX_REC_RESULT_CNT;
			buf_num_Fxx[AdasStatus.Reg.WrBufSelACF][i]  = sReVdpdReg->Reg.FXX_REC_RESULT_UP_CNT[i].Reg.FXX_REC_REDULT_BUF_CNT;
		}

		if(RecgStartIntOn)
		{
			RecgStartIntOn = 0;
		}

	}
	if(sReVdpdReg->Reg.PSEUDO_RECG_END_INT)
	{
		sReVdpdReg->Reg.PSEUDO_RECG_END_INT_CLR = 1;
		sReVdpdReg->Reg.PSEUDO_RECG_END_INT_CLR = 0;
		//JIGMSG("RE_SUDO\n");

	}

	//else
	//{
	//	sReVdpdReg->Data[0x00C0/4] = 0xffffffff;
	//	sReVdpdReg->Data[0x00C0/4] = 0x00000000;
	//}

    //Clear IFR of IRQ1 (INTC's IFR turn-off)
    //abbd_intc_core_ifr_off(RECG_CORE_IRQ);
}

//--------------------------------------------------------------------------------------------------
void A4_RecgEng_Init(void)
{
	int i, j;

    sReVdpdReg->Reg.REC_VD_PD_EN = 0;
    sReVdpdReg->Reg.REC_VD_PD_C_EN = 0;
    // recg_eng image start address
    sReVdpdReg->Reg.REC_FM0_BASE_ADDR  = sReScalerReg->Reg.RES_FM0_BASE_ADDR ;
    sReVdpdReg->Reg.REC_FM2_BASE_ADDR  = sReScalerReg->Reg.RES_FM2_BASE_ADDR ;
    sReVdpdReg->Reg.REC_FM4_BASE_ADDR  = sReScalerReg->Reg.RES_FM4_BASE_ADDR ;
    sReVdpdReg->Reg.REC_FMc_BASE_ADDR  = sReScalerReg->Reg.RES_FMc_BASE_ADDR ;
    sReVdpdReg->Reg.REC_FMe_BASE_ADDR  = sReScalerReg->Reg.RES_FMe_BASE_ADDR ;
    sReVdpdReg->Reg.REC_FM10_BASE_ADDR = sReScalerReg->Reg.RES_FM10_BASE_ADDR;

    sReVdpdReg->Reg.REC_FM18_BASE_ADDR = sReScalerReg->Reg.RES_WIDE_FM0_BASE_ADDR ;
    sReVdpdReg->Reg.REC_FM1a_BASE_ADDR = sReScalerReg->Reg.RES_WIDE_FM2_BASE_ADDR ;
    sReVdpdReg->Reg.REC_FM1c_BASE_ADDR = sReScalerReg->Reg.RES_WIDE_FM4_BASE_ADDR ;

    sReVdpdReg->Reg.PSEUDO_END_CNT = 0xFA;


	sReVdpdReg->Reg.REC_START_MODE = 0;
	sReVdpdReg->Reg.REC_FR_SKIP_CNT = 0;

	sReVdpdReg->Reg.REC_FM0_EN = 1;
	sReVdpdReg->Reg.REC_FM1_EN = 0;
	sReVdpdReg->Reg.REC_FM2_EN = 0;
	sReVdpdReg->Reg.REC_FM3_EN = 0;
	sReVdpdReg->Reg.REC_FM4_EN = 0;
	sReVdpdReg->Reg.REC_FM5_EN = 0;
	sReVdpdReg->Reg.REC_FM6_EN = 0;
	sReVdpdReg->Reg.REC_FM7_EN = 0;
	sReVdpdReg->Reg.REC_FM8_EN = 0;
	sReVdpdReg->Reg.REC_FM9_EN = 0;
	sReVdpdReg->Reg.REC_FMa_EN = 0;
	sReVdpdReg->Reg.REC_FMb_EN = 0;
	sReVdpdReg->Reg.REC_FMc_EN = 0;
	sReVdpdReg->Reg.REC_FMd_EN = 0;
	sReVdpdReg->Reg.REC_FMe_EN = 0;
	sReVdpdReg->Reg.REC_FMf_EN = 0;
	sReVdpdReg->Reg.REC_FM10_EN = 0;
	sReVdpdReg->Reg.REC_FM11_EN = 0;
	sReVdpdReg->Reg.REC_FM12_EN = 0;
	sReVdpdReg->Reg.REC_FM13_EN = 0;
	sReVdpdReg->Reg.REC_FM14_EN = 0;
	sReVdpdReg->Reg.REC_FM15_EN = 0;
	sReVdpdReg->Reg.REC_FM16_EN = 0;
	sReVdpdReg->Reg.REC_FM17_EN = 0;

	sReVdpdReg->Reg.REC_FM18_EN = 0;
	sReVdpdReg->Reg.REC_FM19_EN = 0;
	sReVdpdReg->Reg.REC_FM1a_EN = 0;
	sReVdpdReg->Reg.REC_FM1b_EN = 0;
	sReVdpdReg->Reg.REC_FM1c_EN = 0;
	sReVdpdReg->Reg.REC_FM1d_EN = 0;
	sReVdpdReg->Reg.REC_FM1e_EN = 0;
	sReVdpdReg->Reg.REC_FM1f_EN = 0;
	sReVdpdReg->Reg.REC_FM20_EN = 0;
	sReVdpdReg->Reg.REC_FM21_EN = 0;
	sReVdpdReg->Reg.REC_FM22_EN = 0;
	sReVdpdReg->Reg.REC_FM23_EN = 0;


	sReVdpdReg->Reg.REC_FM0_H_SIZE  = adas_size.width_0;
	sReVdpdReg->Reg.REC_FM0_V_SIZE  = adas_size.height_0	  ;		//  640 x 480 image start address
	sReVdpdReg->Reg.REC_FM2_H_SIZE  = adas_size.width_2;
	sReVdpdReg->Reg.REC_FM2_V_SIZE  = adas_size.height_2	  ;		//  512 x 384 image start address
	sReVdpdReg->Reg.REC_FM4_H_SIZE  = adas_size.width_4;
	sReVdpdReg->Reg.REC_FM4_V_SIZE  = adas_size.height_4	  ;		//  412 x 308 image start address
	sReVdpdReg->Reg.REC_FMc_H_SIZE  = adas_size.width_c;
	sReVdpdReg->Reg.REC_FMc_V_SIZE  = adas_size.height_c	  ;		//  160 x 120 image start address
	sReVdpdReg->Reg.REC_FMe_H_SIZE  = adas_size.width_e;
	sReVdpdReg->Reg.REC_FMe_V_SIZE  = adas_size.height_e	  ;		//  128 x 96  image start address
	sReVdpdReg->Reg.REC_FM10_H_SIZE = adas_size.width_10	  ;
	sReVdpdReg->Reg.REC_FM10_V_SIZE = adas_size.height_10 ;	//  104 x 77  image start address

	sReVdpdReg->Reg.REC_FM18_H_SIZE  = adas_size.wide_width_0	;
	sReVdpdReg->Reg.REC_FM18_V_SIZE  = adas_size.wide_height_0 	;
	sReVdpdReg->Reg.REC_FM1a_H_SIZE  = adas_size.wide_width_2	;
	sReVdpdReg->Reg.REC_FM1a_V_SIZE  = adas_size.wide_height_2 	;
	sReVdpdReg->Reg.REC_FM1c_H_SIZE  = adas_size.wide_width_4	;
	sReVdpdReg->Reg.REC_FM1c_V_SIZE  = adas_size.wide_height_4 	;
	// REC_FM00 H_V_SIZE 640 X 360, [25:24]FRC_MODE=3, [26]RD_BUF_M_EN=1, [29:28]RD_BUF_M_CNT=0
	// REC_FM02 H_V_SIZE 512 X 288, [25:24]FRC_MODE=3, [26]RD_BUF_M_EN=1, [29:28]RD_BUF_M_CNT=0
	// REC_FM04 H_V_SIZE 412 X 230, [25:24]FRC_MODE=3, [26]RD_BUF_M_EN=1, [29:28]RD_BUF_M_CNT=0
	// REC_FM0c H_V_SIZE 160 X 90, [25:24]FRC_MODE=3, [26]RD_BUF_M_EN=1, [29:28]RD_BUF_M_CNT=0
	// REC_FM0e H_V_SIZE 128 X 72,  [25:24]FRC_MODE=3, [26]RD_BUF_M_EN=1, [29:28]RD_BUF_M_CNT=0
	// REC_FM10 H_V_SIZE 104 X 57,  [25:24]FRC_MODE=3, [26]RD_BUF_M_EN=1, [29:28]RD_BUF_M_CNT=0
	sReVdpdReg->Reg.REC_FM0_RD_FRC_MODE  = sReScalerReg->Reg.RES_FM0_FRC_MODE;
	sReVdpdReg->Reg.REC_FM2_RD_FRC_MODE  = sReScalerReg->Reg.RES_FM2_FRC_MODE;
	sReVdpdReg->Reg.REC_FM4_RD_FRC_MODE  = sReScalerReg->Reg.RES_FM4_FRC_MODE;
	sReVdpdReg->Reg.REC_FMc_RD_FRC_MODE  = sReScalerReg->Reg.RES_FMc_FRC_MODE;
	sReVdpdReg->Reg.REC_FMe_RD_FRC_MODE  = sReScalerReg->Reg.RES_FMe_FRC_MODE;
	sReVdpdReg->Reg.REC_FM10_RD_FRC_MODE = sReScalerReg->Reg.RES_FM10_FRC_MODE;

	sReVdpdReg->Reg.REC_FM18_RD_FRC_MODE = sReScalerReg->Reg.RES_WIDE_FM0_FRC_MODE;
	sReVdpdReg->Reg.REC_FM1a_RD_FRC_MODE = sReScalerReg->Reg.RES_WIDE_FM2_FRC_MODE;
	sReVdpdReg->Reg.REC_FM1c_RD_FRC_MODE = sReScalerReg->Reg.RES_WIDE_FM4_FRC_MODE;

	sReVdpdReg->Reg.REC_FM0_RD_BUF_M_EN  = 0;
	sReVdpdReg->Reg.REC_FM2_RD_BUF_M_EN  = 0;
	sReVdpdReg->Reg.REC_FM4_RD_BUF_M_EN  = 0;
	sReVdpdReg->Reg.REC_FMc_RD_BUF_M_EN  = 0;
	sReVdpdReg->Reg.REC_FMe_RD_BUF_M_EN  = 0;
	sReVdpdReg->Reg.REC_FM10_RD_BUF_M_EN = 0;

	sReVdpdReg->Reg.REC_FM18_RD_BUF_M_EN = 0;
	sReVdpdReg->Reg.REC_FM1a_RD_BUF_M_EN = 0;
	sReVdpdReg->Reg.REC_FM1c_RD_BUF_M_EN = 0;


	sReVdpdReg->Reg.RESULT_Q_BUFF_SIZE = 16;
	sReVdpdReg->Reg.VD_PD_RESULT_CNT_MAX_IS_OVER_64 = 1;

	for(i = 0 ; i < 8; i ++)
	{
		for(j = 0 ; j < 2 ; j ++)
		{
			sReVdpdReg->Reg.REC_Fx_RESULT_BASE_ADDR[i][j] = VDPD_RESULTQ_BASE + ( 2 * i + j) * 8 * 512;
		}
	}

    // 16 : int_pulse_en
    // 8  : pseudo_end_int_en
    // 6  : recg_stat_int_en
    // 4  : recg_end_err_int_en
    // 2  : recg_buff_full_int_en
    // 0  : recg_end_r_int_en


	#ifdef	_INT_PULSE_ON
    	sReVdpdReg->Reg.INT_PULSE_EN = 1;
	#else
    	sReVdpdReg->Reg.INT_PULSE_EN = 0;
	#endif

    REGRW32(RE_VDPD_ADDR, 0x000000C0) = 0xFFFFFFFF;        // CLR ALL INT
    REGRW32(RE_VDPD_ADDR, 0x000000C0) = 0x00000000;

#if 1


	sReStatusReg.Reg.FxAcfValue[0].Reg.FxAcfRejectTh 		= 0xFFF6;
	sReStatusReg.Reg.FxAcfValue[0].Reg.FxAcfRejectWeakCnt  = 32;
	sReStatusReg.Reg.FxAcfValue[0].Reg.FxAcfTh				= 0;
	sReStatusReg.Reg.FxAcfValue[0].Reg.FxAcfWeakCnt		= 2048;

	sReStatusReg.Reg.FxAcfValue[1].Reg.FxAcfRejectTh 		= 0xFFF6;
	sReStatusReg.Reg.FxAcfValue[1].Reg.FxAcfRejectWeakCnt  = 32;
	sReStatusReg.Reg.FxAcfValue[1].Reg.FxAcfTh				= 0;
	sReStatusReg.Reg.FxAcfValue[1].Reg.FxAcfWeakCnt		= 2048;

	sReStatusReg.Reg.FxAcfValue[2].Reg.FxAcfRejectTh 		= 0xFFF6;
	sReStatusReg.Reg.FxAcfValue[2].Reg.FxAcfRejectWeakCnt  = 32;
	sReStatusReg.Reg.FxAcfValue[2].Reg.FxAcfTh				= 0;
	sReStatusReg.Reg.FxAcfValue[2].Reg.FxAcfWeakCnt		= 2048;

	sReStatusReg.Reg.FxAcfValue[3].Reg.FxAcfRejectTh 		= 0xFFF6;
	sReStatusReg.Reg.FxAcfValue[3].Reg.FxAcfRejectWeakCnt  = 32;
	sReStatusReg.Reg.FxAcfValue[3].Reg.FxAcfTh				= 0;
	sReStatusReg.Reg.FxAcfValue[3].Reg.FxAcfWeakCnt		= 2048;

	sReStatusReg.Reg.FxAcfValue[4].Reg.FxAcfRejectTh 		= 0xFFF6;
	sReStatusReg.Reg.FxAcfValue[4].Reg.FxAcfRejectWeakCnt  = 32;
	sReStatusReg.Reg.FxAcfValue[4].Reg.FxAcfTh				= 0;
	sReStatusReg.Reg.FxAcfValue[4].Reg.FxAcfWeakCnt		= 2048;

	sReStatusReg.Reg.FxAcfValue[5].Reg.FxAcfRejectTh 		= 0xFFF6;
	sReStatusReg.Reg.FxAcfValue[5].Reg.FxAcfRejectWeakCnt  = 32;
	sReStatusReg.Reg.FxAcfValue[5].Reg.FxAcfTh				= 0;
	sReStatusReg.Reg.FxAcfValue[5].Reg.FxAcfWeakCnt		= 2048;

	sReStatusReg.Reg.FxAcfValue[6].Reg.FxAcfRejectTh 		= 0xFFF6;
	sReStatusReg.Reg.FxAcfValue[6].Reg.FxAcfRejectWeakCnt  = 32;
	sReStatusReg.Reg.FxAcfValue[6].Reg.FxAcfTh				= 0;
	sReStatusReg.Reg.FxAcfValue[6].Reg.FxAcfWeakCnt		= 2048;

	sReStatusReg.Reg.FxAcfValue[7].Reg.FxAcfRejectTh 		= 0xFFF6;
	sReStatusReg.Reg.FxAcfValue[7].Reg.FxAcfRejectWeakCnt  = 32;
	sReStatusReg.Reg.FxAcfValue[7].Reg.FxAcfTh				= 0;
	sReStatusReg.Reg.FxAcfValue[7].Reg.FxAcfWeakCnt		= 2048;
	// PADDING ENABLE
	for(j=0; j<8; j++)
	{
		sReVdpdReg->Reg.Fx_WR_SEL = j;
		for(i=0; i<18; i++)
		{
			sReVdpdReg->Reg.HV_PADDING_STRIDE1[i].Reg.Fx_VD_PD_FMx_H_PADDING_ENABLE = 0;
			sReVdpdReg->Reg.HV_PADDING_STRIDE1[i].Reg.Fx_VD_PD_FMx_V_PADDING_ENABLE = 0;

			sReVdpdReg->Reg.HV_PADDING_STRIDE1[i].Reg.Fx_VD_PD_FMx_H_STRIDE1_ENABLE = 0;
			sReVdpdReg->Reg.HV_PADDING_STRIDE1[i].Reg.Fx_VD_PD_FMx_V_STRIDE1_ENABLE = 0;
		}
	}

    sRecgInt.VdpdEndPosFlag = 0;			// pos
    sRecgInt.VdpdPseudoFlag = 0;			// neg
    sRecgInt.VdpdStartFlag = 0;				// start
    sRecgInt.VdpdBufFullFlag = 0;			// buffer full
#endif

	sReVdpdReg->Reg.F0_REC_EN = 1;
	sReVdpdReg->Reg.F1_REC_EN = 1;
	sReVdpdReg->Reg.F2_REC_EN = 1;
	sReVdpdReg->Reg.F3_REC_EN = 1;
	sReVdpdReg->Reg.F4_REC_EN = 1;
	sReVdpdReg->Reg.F5_REC_EN = 1;
	sReVdpdReg->Reg.F6_REC_EN = 1;
	sReVdpdReg->Reg.F7_REC_EN = 1;

	sReVdpdReg->Reg.ACF_C_EN = 1;
	sReVdpdReg->Reg.ACF_Y_PENALTY_EN = 1;
	sReVdpdReg->Reg.ACF_YC_MERGE_EN = 1;

	//acf valude set [move from fuction(ncDrv_A4_WriteRecgTable_FX) to set just one time]
	sReVdpdReg->Reg.REC_VD_PD_H_MASK_SIZE    = FXX_MASK_W;

	sReVdpdReg->Reg.REC_VD_PD_F0_V_MASK_SIZE = F00_MASK_H;
	sReVdpdReg->Reg.REC_VD_PD_F1_V_MASK_SIZE = F01_MASK_H;
	sReVdpdReg->Reg.REC_VD_PD_F2_V_MASK_SIZE = F10_MASK_H;
	sReVdpdReg->Reg.REC_VD_PD_F3_V_MASK_SIZE = F11_MASK_H;

	sReVdpdReg->Reg.REC_VD_PD_F4_V_MASK_SIZE = F100_MASK_H;
	sReVdpdReg->Reg.REC_VD_PD_F5_V_MASK_SIZE = F101_MASK_H;
	sReVdpdReg->Reg.REC_VD_PD_F6_V_MASK_SIZE = F110_MASK_H;
	sReVdpdReg->Reg.REC_VD_PD_F7_V_MASK_SIZE = F111_MASK_H;

    sReVdpdReg->Reg.VDPD_RECG_END_R_INT_EN = 0;
    sReVdpdReg->Reg.VDPD_RECG_END_ERR_INT_EN = 0;
    sReVdpdReg->Reg.VDPD_RECG_SRT_INT_EN = 1;
    sReVdpdReg->Reg.PSEUDO_RECG_END_INT_EN = 0;
    sReVdpdReg->Reg.VDPD_RECG_UP_END_R_INT_EN = 1;

    sReVdpdReg->Reg.REC_VD_PD_EN = 0;
    sReVdpdReg->Reg.REC_VD_PD_C_EN = 0;

	#ifdef	_RECG_INT_EN
	if( ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_RE_VDPD, (PrVoid)A4_RECG_ENG_ISR_Handler, CMD_END) != NC_SUCCESS )
	{
		DEBUGMSG_SDK(MSGERR, "VDPD_INIT ERROR\n");
	}
	#endif
    JIGMSG("@@ recg_int_en\n");
}
