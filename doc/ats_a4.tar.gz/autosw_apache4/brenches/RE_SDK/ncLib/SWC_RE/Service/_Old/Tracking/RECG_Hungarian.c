#include "RECG_Hungarian.h"
#include "../common.h"

#define BOOL char
//extern "C"
//{


void Hungarian_algorithm(int nRow, int nCol, float **c_mat, int **l_mat)
{
	/*int i, j;
	if (nRow > nCol) //transpose占쏙옙占쏙옙占� 占쏙옙
	{
		//printf("nR\n");

		float **trans_c_mat = new float *[nCol];
		int **trans_l_mat = new int *[nCol];

		//transpose cost matrix and link matrix
		for( i = 0; i < nCol; i++)
		{
			trans_c_mat[i] = new float[nRow];
			trans_l_mat[i] = new int[nRow];
			for( j = 0; j < nRow; j++)
			{
				trans_c_mat[i][j] = c_mat[j][i];
				trans_l_mat[i][j] = l_mat[j][i];
			}
		}


		hungarian_processing(trans_c_mat, nCol, nRow, trans_l_mat);

		//transpose transposed link matrix
		for( i = 0; i < nRow; i++)
		{
			for( j = 0; j < nCol; j++)
			{
				l_mat[i][j] = trans_l_mat[j][i];
			}
		}

		for( i = 0; i < nCol; i++)
		{
			delete[] trans_c_mat[i];
			delete[] trans_l_mat[i];
		}
		delete[] trans_c_mat;
		delete[] trans_l_mat;

	}
	else //占쏙옙占쏙옙占쏙옙占쏙옙 占쏙옙占쏙옙
	{
		//printf("nC\n");
		hungarian_processing(c_mat, nRow, nCol, l_mat);
	}*/
}

void Hungarian_algorithm_Static(int nRow, int nCol, float c_mat[][MAX_TRACK], int l_mat[][MAX_TRACK])
{
	int i, j;
	if (nRow > nCol) //transpose占쏙옙占쏙옙占� 占쏙옙
	{

		float trans_c_mat[MAX_TRACK][MAX_TRACK];
		int trans_l_mat[MAX_TRACK][MAX_TRACK];

		//transpose cost matrix and link matrix
		for( i = 0; i < nCol; i++)
		{
			for( j = 0; j < nRow; j++)
			{
				trans_c_mat[i][j] = c_mat[j][i];
				trans_l_mat[i][j] = l_mat[j][i];
			}
		}


		hungarian_processing_Static(trans_c_mat, nCol, nRow, trans_l_mat);

		//transpose transposed link matrix
		for( i = 0; i < nRow; i++)
		{
			for( j = 0; j < nCol; j++)
			{
				l_mat[i][j] = trans_l_mat[j][i];
			}
		}


	}
	else //占쏙옙占쏙옙占쏙옙占쏙옙 占쏙옙占쏙옙
	{
		hungarian_processing_Static(c_mat, nRow, nCol, l_mat);
	}
}

void hungarian_processing(float **CostMat, int nR, int mC, int **DA_Mat)
{
	/*
	int i, j;
	//hungarian占쏙옙占쏙옙 占쏙옙占쏙옙 占쏙옙占쏙옙
	int* _M = new int[nR*mC]; //_M = 1 => star, _M = 2 => prime
	int* _C_cov = new int[mC]; //column cover vector
	int* _R_cov = new int[nR]; //Row cover vector
	int stepnum = 1;
	int Z0_r, Z0_c; //Z0占쏙옙 row占쏙옙 col 占쏙옙치
	BOOL done = FALSE;
	float *_C = new float[nR*mC];



	//2占쏙옙占쏙옙 占썼열占쏙옙 1占쏙옙占쏙옙 占썼열占쏙옙 占쏙옙환
	for( i = 0; i < nR; i++)
		for( j = 0; j < mC; j++)
		{
			_C[i*mC + j] = CostMat[i][j];
		}
#ifdef HUNGARIAN_DEBUG
	//printf("***********Cost Matrix***********\n");
	PrintArray_f(_C, nR, mC);
#endif

	////printf("%d %d\n",nR,mC);

	//hungarian algorithm start

	while (!done)
	{
		////printf("%d\n",stepnum);
		switch (stepnum)
		{
		case 1:
			stepnum = step_one(_C, nR, mC);
			break;
		case 2:
			stepnum = step_two(_C, nR, mC, _C_cov, _R_cov, _M);
			break;
		case 3:
			stepnum = step_three(_C, nR, mC, _C_cov, _R_cov, _M);
			break;
		case 4:
			stepnum = step_four(_C, nR, mC, _C_cov, _R_cov, _M, &Z0_r, &Z0_c);
			break;
		case 5:
			stepnum = step_five(nR, mC, _C_cov, _R_cov, _M, &Z0_r, &Z0_c);
			break;
		case 6:
			stepnum = step_six(_C, nR, mC, _C_cov, _R_cov);
			break;
		default:
			done = TRUE;
			break;
		}
	}

	for( i = 0; i < nR; i++)
		for( j = 0; j < mC; j++)
		{
			DA_Mat[i][j] = _M[i*mC + j];
		}
#ifdef HUNGARIAN_DEBUG
	//printf("***********Data Association Matrix***********\n");
	PrintArray_i(_M, nR, mC);
#endif


	delete[] _C;
	delete[] _M;
	delete[] _C_cov;
	delete[] _R_cov;

*/
}

void hungarian_processing_Static(float CostMat[][MAX_TRACK], int nR, int mC, int DA_Mat[][MAX_TRACK])
{
	int i, j;
	//hungarian占쏙옙占쏙옙 占쏙옙占쏙옙 占쏙옙占쏙옙
	int stepnum = 1;
	int Z0_r, Z0_c; //Z0占쏙옙 row占쏙옙 col 占쏙옙치
	BOOL done = FALSE;

	int _M[MAX_TRACK * MAX_TRACK]; //_M = 1 => star, _M = 2 => prime
	int _C_cov[MAX_TRACK]; //column cover vector
	int _R_cov[MAX_TRACK]; //Row cover vector
	float _C [MAX_TRACK*MAX_TRACK];


	//2占쏙옙占쏙옙 占썼열占쏙옙 1占쏙옙占쏙옙 占썼열占쏙옙 占쏙옙환
	for( i = 0; i < nR; i++)
		for( j = 0; j < mC; j++)
		{
			_C[i*mC + j] = CostMat[i][j];
		}
#ifdef HUNGARIAN_DEBUG
		//printf("***********Cost Matrix***********\n");
		PrintArray_f(_C, nR, mC);
#endif

		////printf("%d %d\n",nR,mC);

		//hungarian algorithm start

		while (!done)
		{
			////printf("%d\n",stepnum);
			switch (stepnum)
			{
			case 1:
				stepnum = step_one(_C, nR, mC);
				break;
			case 2:
				stepnum = step_two(_C, nR, mC, _C_cov, _R_cov, _M);
				break;
			case 3:
				stepnum = step_three(_C, nR, mC, _C_cov, _R_cov, _M);
				break;
			case 4:
				stepnum = step_four(_C, nR, mC, _C_cov, _R_cov, _M, &Z0_r, &Z0_c);
				break;
			case 5:
				stepnum = step_five(nR, mC, _C_cov, _R_cov, _M, &Z0_r, &Z0_c);
				break;
			case 6:
				stepnum = step_six(_C, nR, mC, _C_cov, _R_cov);
				break;
			default:
				done = TRUE;
				break;
			}
		}

		for( i = 0; i < nR; i++)
			for( j = 0; j < mC; j++)
			{
				DA_Mat[i][j] = _M[i*mC + j];
			}
#ifdef HUNGARIAN_DEBUG
			//printf("***********Data Association Matrix***********\n");
			PrintArray_i(_M, nR, mC);
#endif

}

void PrintArray_f(float *C, int nRow, int nCol)
{
	int i, j;
	for( i = 0; i < nRow; i++)
	{
		for( j = 0; j < nCol; j++)
		{
			//printf(" %f ", C[i*nCol + j]);
		}
		//printf("\n");
	}
}

void PrintArray_i(int *C, int nRow, int nCol)
{
	int i, j;
	for( i = 0; i < nRow; i++)
	{
		for( j = 0; j < nCol; j++)
		{
			//printf(" %d ", C[i*nCol + j]);
		}
		//printf("\n");
	}
}

void PrintVector_i(int *V, int nDim)
{
	int j;
	for( j = 0; j < nDim; j++)
	{
		//printf(" %d ", V[j]);
	}
	//printf("\n");
}

//////////////////////////STEP 1占쏙옙占쏙옙/////////////////////////
///row占쏙옙占쏙옙 占쌍소곤옙占쏙옙 찾占싣쇽옙 占쏙옙 row占쏙옙占쏙옙 占쌍소곤옙占쏙옙 占쏙옙占쌔댐옙///////
int step_one(float *C, int nRow, int nCol)
{
	int i, j;
	float minval;
	for( i = 0; i < nRow; i++)
	{
		//占쌍소곤옙占쏙옙 찾占쏙옙 占쏙옙占쏙옙
		minval = C[i*nCol + 0];
		for( j = 1; j < nCol; j++)
		{
			if (minval > C[i*nCol + j])
			{
				minval = C[i*nCol + j];
			}
		}
		//占쌍소곤옙占쏙옙 占쏙옙 占쌍댐옙 占쏙옙占쏙옙
		for( j = 0; j < nCol; j++)
		{
			C[i*nCol + j] = C[i*nCol + j] - minval;
		}
	}
#ifdef HUNGARIAN_DEBUG
	//printf("*********step 1***************\n");
	PrintArray_f(C, nRow, nCol);
#endif
	return 2;
}

//////////////////////////STEP 2占쏙옙占쏙옙/////////////////////////
///0占쏙옙 찾占싣쇽옙 star 표占쏙옙(M[] =1)占쏙옙 占쏙옙占쌔댐옙///////
int step_two(float *C, int nRow, int nCol, int *C_cov, int *R_cov, int *M)
{
	int i, j;
	//占십깍옙화
	for( i = 0; i < nRow; i++)
	{
		R_cov[i] = 0;
		for( j = 0; j < nCol; j++)
		{
			M[i*nCol + j] = 0;
			if (i == 0)
			{
				C_cov[j] = 0;
			}
		}
	}

	for( i = 0; i < nRow; i++)
	{
		for( j = 0; j < nCol; j++)
		{
			//0占쏙옙 찾占쏙옙, star표占쏙옙占싹곤옙, cover占싹댐옙 占쏙옙占쏙옙
			if ((C[i*nCol + j] == 0) && (C_cov[j] == 0) && (R_cov[i] == 0))
			{
				M[i*nCol + j] = 1;
				//占쏙옙 占쏙옙 mask占쏙옙 0占쏙옙 占쏙옙占쏙옙占쏙옙 占쌔댐옙풔占� row占쏙옙 column占쏙옙 disable占쏙옙킨占쏙옙.
				C_cov[j] = 1;
				R_cov[i] = 1;
			}
		}
	}
	//cover占쏙옙 占쏙옙占� row占쏙옙 column 占십깍옙화占싼댐옙.
	for( i = 0; i < nRow; i++) R_cov[i] = 0;
	for( j = 0; j < nCol; j++) C_cov[j] = 0;

#ifdef HUNGARIAN_DEBUG
	//printf("*********step 2***************\n");
	PrintArray_i(M, nRow, nCol);
#endif

	return 3;
}

//////////////////////////STEP 3占쏙옙占쏙옙/////////////////////////
//star占쏙옙 占쌍댐옙 column占쏙옙 cover占쏙옙占쌍곤옙, 占쏙옙占쏙옙占쏙옙 占쏙옙占쏙옙臼占�, column 占쏙옙占쏙옙占쏙옙占쏙옙 占쏙옙占쏙옙占쏙옙 占쏙옙占쏙옙占�./////////////
int step_three(float *C, int nRow, int nCol, int *C_cov, int *R_cov, int *M)
{
	int count = 0;
	int step;
	int i, j;

	for( i = 0; i < nRow; i++)
	{
		for( j = 0; j < nCol; j++)
		{
			//star占쏙옙 占쌍댐옙 column占쏙옙 cover占싼댐옙.
			if (M[i*nCol + j] == 1)
			{
				C_cov[j] = 1;
			}
		}
	}

	for( j = 0; j < nCol; j++) count += C_cov[j];

	if (count >= nRow) step = 7; //row占쏙옙 占쏙옙占쌘곤옙 占쏙옙占쏙옙 占쏙옙占쏙옙占쏙옙
	else step = 4;
#ifdef HUNGARIAN_DEBUG
	//printf("*********step 3***************\n");
	//printf("count = %d\n", count);
	PrintVector_i(C_cov, nCol);
#endif

	return step;
}

//////////////////////////STEP 4占쏙옙占쏙옙/////////////////////////

int step_four(float *C, int nRow, int nCol, int *C_cov, int *R_cov, int *M, int *Z0_r, int *Z0_c)
{
	BOOL done = FALSE;
	int row, col;
	int step;

	while (!done)
	{
		//cover 占쏙옙占쏙옙占쏙옙占쏙옙 0占쏙옙 찾占싣쇽옙, row占쏙옙 column占쏙옙占쏙옙 占싯뤄옙占쌔댐옙.
		find_a_zero(C, nRow, nCol, C_cov, R_cov, &row, &col);
		if (row == -1) //cover 占쏙옙占쏙옙 占십댐옙 0占쏙옙 占쏙옙占쏙옙 占쏙옙占�
		{
			done = TRUE;
			step = 6;
		}
		else //cover占쏙옙占쏙옙占쏙옙占쏙옙 0占쏙옙 占쌍댐옙 占쏙옙占�
		{
			M[row*nCol + col] = 2; //占쏙옙 占쌘몌옙占쏙옙 占쏙옙占쏙옙占쏙옙 표占쏙옙(M[]=2)占쏙옙 占싼댐옙.
			if (_find_star_in_row(M, nCol, &row, &col)) //占쌔댐옙풔占� row占쏙옙 star占쏙옙 占쏙옙占쏙옙占쏙옙, column占쏙옙치占쏙옙 占싯뤄옙占쌔댐옙.
			{
				R_cov[row] = 1;
				C_cov[col] = 0;
			}
			else //占쌔댐옙풔占� row占쏙옙 star占쏙옙 占쏙옙占쏙옙占쏙옙
			{
				done = TRUE;
				step = 5;
				*Z0_r = row;
				*Z0_c = col;
			}
		}
	}
#ifdef HUNGARIAN_DEBUG
	//printf("*********step 4***************\n");
	//printf("Star&Prime 표占쏙옙\n");
	PrintArray_i(M, nRow, nCol);
#endif

	return step;
}

void find_a_zero(float *C, int nRow, int nCol, int *C_cov, int *R_cov, int *row, int *col)
{
	int i =0, j;
	BOOL done = FALSE;
	*row = -1;
	*col = -1;

	while (!done)
	{
		for( i = 0; i < nRow; i++)
		{
			for( j = 0; j < nCol; j++)
			{
				//cover 占쏙옙占쏙옙 占십댐옙 0占쏙옙 占쏙옙占쏙옙占싹몌옙
				if ((C[i*nCol + j] == 0) && (R_cov[i] == 0) && (C_cov[j] == 0))
				{
					*row = i;
					*col = j;
					done = TRUE;
					break;
				}
			}
			if (done) break;
		}
		done = TRUE;
	}
	return;
}

//占쏙옙占쏙옙 占쏙옙 占쌉쇽옙占쏙옙 占쏙옙친占쏙옙.
char _find_star_in_row(int *M, int nCol, int *row, int *col)
{
	int j;
	BOOL tbool = FALSE;

	for( j = 0; j < nCol; j++)
	{
		if (M[*row*nCol + j] == 1)
		{
			tbool = TRUE;
			*col = j;
			break;
		}
	}
	return tbool;
}

//////////////////////////STEP 5占쏙옙占쏙옙/////////////////////////
int step_five(int nRow, int nCol, int *C_cov, int *R_cov, int *M, int *Z0_r, int *Z0_c)
{
	int i;
	int count;
	BOOL done;
	int r, c;
	int path[MAX_TRACK * MAX_TRACK][2];

	/*int **path = new int *[nCol*nRow];
	for( i = 0; i < (nCol*nRow); i++)
		path[i] = new int[2];*/

	count = 0;
	//step 4占쏙옙占쏙옙 찾占쏙옙 占쏙옙占쏙옙 占쏙옙占쏙옙占쏙옙占쏙옙 row, column 占쏙옙占쏙옙
	path[count][0] = *Z0_r;
	path[count][1] = *Z0_c;
	done = FALSE;


	while (!done)
	{
		//占쏙옙占쏙옙占쏙옙占쏙옙 占쌍댐옙 column占쏙옙 star占쏙옙 占쌍댐옙占쏙옙 찾占승댐옙.
		find_star_in_col(M, nRow, nCol, path[count][1], &r);
		if (r >= 0) //star占쏙옙 占쏙옙占쏙옙占쏙옙
		{
			++count;
			//star占쏙옙 占쏙옙치 占쏙옙占쏙옙
			path[count][0] = r;
			path[count][1] = path[count - 1][1]; //column占쏙옙 占쏙옙占쏙옙占쌈곤옙 占쏙옙占쏙옙占싹깍옙 占쏙옙占쏙옙占쏙옙
		}
		else //star占쏙옙 占쏙옙占쏙옙占쏙옙
		{
			done = TRUE;
		}

		if (!done)
		{
			//star占쏙옙 占쌍댐옙 row占쏙옙 占쏙옙占쏙옙占쏙옙(占쏙옙占쏙옙占쏙옙 占싹놂옙 占쏙옙占쏙옙)占쏙옙 占쏙옙치占쏙옙 찾占승댐옙.
			find_prime_in_row(M, nRow, nCol, path[count][0], &c);
			++count;
			//占쏙옙占쏙옙占쏙옙占쏙옙 占쏙옙치 占쏙옙占쏙옙
			path[count][0] = path[count - 1][0]; //row占쏙옙 占쏙옙타占쏙옙 占쏙옙占쏙옙占싹깍옙 占쏙옙占쏙옙占쏙옙
			path[count][1] = c;
		}
	}

	++count; //占쏙옙占쏙옙 占쏙옙占쏙옙占쏙옙 占싼곤옙占쏙옙森홱占�.
	//star占쏙옙 占쏙옙占쌍곤옙, prime占쏙옙 star占쏙옙 占쏙옙환占쏙옙占쌔댐옙.
	convert_path(M, nCol, count, path);
	//占쏙옙占쏙옙占쌍댐옙 cover占쏙옙占쏙옙 占쏙옙占� 占쏙옙占쏙옙占싼댐옙.
	clear_covers(nRow, nCol, C_cov, R_cov);
	//占쏙옙占쏙옙占쌍댐옙 prime占쏙옙占쏙옙 占쏙옙占쏙옙占싼댐옙.
	erase_primes(M, nRow, nCol);



	/// ex
/*
	for( i = 0; i < (nCol*nRow); i++)
		delete path[i];*/
	//delete path;


	return 3;
}

void find_star_in_col(int *M, int nRow, int nCol, int c, int *r)
{
	int i;
	*r = -1;
	for( i = 0; i < nRow; i++)
	{
		if (M[i*nCol + c] == 1)
		{
			*r = i;
			break;
		}
	}
}

void find_prime_in_row(int *M, int nRow, int nCol, int r, int *c)
{
	int j;
	for( j = 0; j < nCol; j++)
	{
		if (M[r*nCol + j] == 2)
		{
			*c = j;
			break;
		}
	}
}

void convert_path(int *M, int nCol, int count, int path[][2])
//void convert_path(int *M, int nCol, int count, int **path)
{
	int i;
	for( i = 0; i < count; i++)
	{
		if (M[(path[i][0] * nCol + path[i][1])] == 1)
		{
			M[(path[i][0] * nCol + path[i][1])] = 0;
		}
		else
		{
			M[(path[i][0] * nCol + path[i][1])] = 1;
		}
	}
}

void clear_covers(int nRow, int nCol, int *C_cov, int *R_cov)
{
	int i, j;
	for( i = 0; i < nRow; i++) R_cov[i] = 0;
	for( j = 0; j < nCol; j++) C_cov[j] = 0;
}

void erase_primes(int *M, int nRow, int nCol)
{
	int i, j;
	for( i = 0; i < nRow; i++)
	{
		for( j = 0; j < nCol; j++)
		{
			//占쏙옙占쏙옙占쏙옙占쏙옙 占쌍댐옙 占쏙옙占쏙옙 占쏙옙占쏙옙占쏙옙 占쏙옙占쏙옙占�.
			if (M[i*nCol + j] == 2) M[i*nCol + j] = 0;
		}
	}
}

//////////////////////////STEP 6占쏙옙占쏙옙/////////////////////////
int step_six(float *C, int nRow, int nCol, int *C_cov, int *R_cov)
{
	int i, j;
	float minval = (float)MAXVALUE;

	find_smallest(C, nRow, nCol, C_cov, R_cov, &minval);

	for( i = 0; i < nRow; i++)
	{
		for( j = 0; j < nCol; j++)
		{
			if (R_cov[i] == 1)
			{
				C[i*nCol + j] = C[i*nCol + j] + minval;
			}
			if (C_cov[j] == 0)
			{
				C[i*nCol + j] = C[i*nCol + j] - minval;
			}
		}
	}
#ifdef HUNGARIAN_DEBUG
	//printf("*********step 6***************\n");
	PrintArray_f(C, nRow, nCol);
#endif
	return 4;
}

void find_smallest(float *C, int nRow, int nCol, int *C_cov, int *R_cov, float *minval)
{
	int i, j;

	for( i = 0; i < nRow; i++)
		for( j = 0; j < nCol; j++)
		{
			if ((R_cov[i] == 0) && (C_cov[j] == 0))
			{
				if (*minval > C[i*nCol + j]) *minval = C[i*nCol + j];
			}
		}
}


//}

