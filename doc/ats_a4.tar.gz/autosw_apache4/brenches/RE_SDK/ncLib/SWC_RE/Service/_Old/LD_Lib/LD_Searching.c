#include "common.h"
#include "A4_AdasIp.h"
#include "A4_RecgScaler.h"
#include "A4_RecgEng.h"
#include "A4_HsvOp.h"
#include "A4_Mod.h"
#include "A4_LD.h"

#include "LD_Lib.h"
#include <math.h>

#include "TanTable.h"


#define	DAX_0_MIN	(0+4)
#define	DAX_0_MAX	(DAX_0_MIN+12)

#define	DAX_3_MAX	(63-4)
#define	DAX_3_MIN	(DAX_3_MAX-10)

#define	DAX_1_MIN	(DAX_0_MAX-1)
#define	DAX_2_MAX	(DAX_3_MIN+1)

#define	DAX_1_MAX	32
#define	DAX_2_MIN	31


#define DAX_0_STR	((DAX_0_MIN + DAX_0_MAX) / 2)
#define DAX_1_STR	((DAX_1_MIN + DAX_1_MAX) / 2)
#define DAX_2_STR	((DAX_2_MIN + DAX_2_MAX) / 2)
#define DAX_3_STR	((DAX_3_MIN + DAX_3_MAX) / 2)


SEARCH_BOX_REGISTER		sSBoxReg;
PRE_BOX_REGISTER		sPreSBoxReg[2];
SEARCHING_LANE_REGISTER	sSLaneReg[SEARCHING_LANE_NUM][2];

TRACKING_LANE_REGISTER	sTrLaneReg[4];

ORG_LANE_REGISTER	sOrgLaneReg[4];
ORG_LANE_REGISTER	sOldOrgLaneReg[4];

ORG_LANE_REGISTER	sOldTvLaneReg[4];
ORG_LANE_REGISTER	sTmpLaneReg, sTmpLaneReg1;

TRACKING_LANE_REGISTER	*sTrSelReg[5];

int Det0Max=DAX_0_MAX, Det1Min=DAX_1_MIN, Det2Max=DAX_2_MAX, Det3Min=DAX_3_MIN;
int Det1Max=DAX_1_MAX, Det2Min=DAX_2_MIN;

unsigned int averageY[2]={0, }, averageYold[2]={0, };
unsigned int avergageCnt[2]={0, };

extern void Draw_Lane(int x1, int y1, int x2, int y2, unsigned char C);
extern void Draw_Text(char *ChString, unsigned int StX, unsigned int StY);

//-----------------------------------------------------------------------------------------------------
void CubicBSpline(POINT_XY *pDest, int destCnt, POINT_XY *pSrc, int srcCnt)
{
	double m = (double)(srcCnt - 1) / (destCnt - 1);
	int i, j;
	double jt;
	double t, tt, ttt;
	double b0, b1, b2, b3;
	int j_m1, j_p0, j_p1, j_p2;

	for (i = 0; i < destCnt; ++i)
	{
		jt = i*m;
		j = (int)jt;

		t = jt - j;
		tt = t*t;
		ttt = tt * t;

		b0 = (-1 * ttt + 3 * tt - 3 * t + 1) / 6.;
		b1 = (3 * ttt - 6 * tt + 0 * t + 4) / 6.;
		b2 = (-3 * ttt + 3 * tt + 3 * t + 1) / 6.;
		b3 = (1 * ttt + 0 * tt + 0 * t + 0) / 6.;

		j_m1 = (j - 1 < 0) ? 0 : j - 1;
		j_p0 = (j + 0 > srcCnt - 1) ? srcCnt - 1 : j + 0;
		j_p1 = (j + 1 > srcCnt - 1) ? srcCnt - 1 : j + 1;
		j_p2 = (j + 2 > srcCnt - 1) ? srcCnt - 1 : j + 2;

		pDest[i].x = b0 * pSrc[j_m1].x + b1 * pSrc[j_p0].x + b2 * pSrc[j_p1].x + b3 * pSrc[j_p2].x;
		pDest[i].y = b0 * pSrc[j_m1].y + b1 * pSrc[j_p0].y + b2 * pSrc[j_p1].y + b3 * pSrc[j_p2].y;
	}
}


//----------------------------------------------------------------------------------------------------
SEARCH_BOX_INFO LD_Search_Lane_In_Box(unsigned char *src, unsigned char *src1, int StrX, int EndX, int StrY, int EndY)
{
	int x, y, iTmp;
	int HoCntMax;

	int sumY=0, sumCb=0, sumCr=0, sumCnt=0;

	SEARCH_BOX_INFO HpReturn;

	POINT_XY minX, minY, maxX, maxY;

	HpReturn.REG.CenterX = 0;
	HpReturn.REG.CenterY = 0;

	HpReturn.REG.StrX = 0x3FF;
	HpReturn.REG.StrY = 0x3FF;
	HpReturn.REG.EndX = 0;
	HpReturn.REG.EndY = 0;

	minX.x = 0xFFFF;
	minY.y = 0xFFFF;
	maxX.x = 0;
	maxY.y = 0;

	HoCntMax = 0;
	for (y =StrY; y <= EndY; y++)
	{
		for (x = StrX; x <= EndX; x++)
		{
			if (src[y * LD_IMG_WIDTH + x] > 0)//== threshold)
			{
				HoCntMax++;
				if(minX.x > x) {minX.x = x;	minX.y = y;}
				if(maxX.x < x) {maxX.x = x; maxX.y = y;}

				if(minY.y > y) {minY.y = y; minY.x = x;}
				if(maxY.y < y) {maxY.y = y; maxY.x = x;}
			}

			if((y <= EndY-2) && (x <= EndX-2))
			{
				iTmp = src1[LD_IMG_WIDTH*LD_IMG_HEIGHT * 0 + y * LD_IMG_WIDTH + x];
				//if(iTmp < LdReg.REG.YTh)
				{
					sumY  += iTmp;
					sumCb += src1[LD_IMG_WIDTH*LD_IMG_HEIGHT * 1 + y * LD_IMG_WIDTH + x];
					sumCr += src1[LD_IMG_WIDTH*LD_IMG_HEIGHT * 2 + y * LD_IMG_WIDTH + x];
					sumCnt++;
				}
			}
		}
	}

	if(sumCnt > 0)
	{
		sumY /= sumCnt;
		sumCb /= sumCnt;
		sumCr /= sumCnt;
	}

	HpReturn.REG.avgY = (sumY > 255)?   255 : sumY;
	HpReturn.REG.avgCb = (sumCb > 255)? 255 : sumCb;
	HpReturn.REG.avgCr = (sumCb > 255)? 255 : sumCr;

	HpReturn.REG.StrX = minX.x;
	HpReturn.REG.EndX = maxX.x;

	HpReturn.REG.StrY = minY.y;
	HpReturn.REG.EndY = maxY.y;

	HpReturn.REG.Width = HpReturn.REG.EndX - HpReturn.REG.StrX + 1;
	HpReturn.REG.Height = HpReturn.REG.EndY - HpReturn.REG.StrY + 1;



	if((HoCntMax >= 2) && ((HpReturn.REG.Width>=2) || (HpReturn.REG.Height>=2)))
	{

		HpReturn.REG.CenterX = ((int)HpReturn.REG.EndX + (int)HpReturn.REG.StrX) / 2;
		HpReturn.REG.CenterY = ((int)HpReturn.REG.EndY + (int)HpReturn.REG.StrY) / 2;
	}

	return HpReturn;
}

//----------------------------------------------------------------------------------------
void LD_Test_Box(void)
{
	/*
	static int InitOn = 1;
	int m, n, k, l, StrBoxNum, iTmp, iTmp1, addValue;
	unsigned int BoxAddr, BoxStrY;
	SEARCH_BOX_INFO	uHoPoint = {0, };
	int VanishingPointY=0, SearchingEndY=0, SearchingStrY=0;

	unsigned int p_LD_RESULT0;
	REC_LD_RESULT0 tmp_LD_RESULT0, LD_RESULT0;

	POINT_XY tvPnt;
	POINT_XY orgPnt;

	//- Init uHoResult Register ---------------------------------------------------------------------
	if((InitOn > 0) || (VanishingPointY != LdReg.REG.VpY) || (SearchingEndY != LdReg.REG.EndY))
	{
		VanishingPointY = LdReg.REG.VpY;
		SearchingEndY = LdReg.REG.EndY;
		SearchingStrY = VanishingPointY + 20;

		InitOn = 0;
		addValue = 1;

		for(m=0; m<SEARCH_BOX_NUM_V; m++)
		{
			for(n=0; n<SEARCH_BOX_NUM_H; n++)
			{
				BoxAddr = m * SEARCH_BOX_NUM_H + n;

				for(iTmp=0; iTmp<13; iTmp++)
					sSBoxReg.SBoxInfo[BoxAddr].Data32[iTmp] = 0;

				if((SearchingStrY / SEARCH_BOX_HEIGHT) == m)
				{
					sSBoxReg.SBoxInfo[BoxAddr].REG.StrX = SEARCH_BOX_WIDTH * n;
					sSBoxReg.SBoxInfo[BoxAddr].REG.EndX = ((SEARCH_BOX_WIDTH * (n+1) + addValue) < LD_IMG_WIDTH)? SEARCH_BOX_WIDTH * (n+1) + addValue : LD_IMG_WIDTH-1;

					sSBoxReg.SBoxInfo[BoxAddr].REG.StrY = SEARCH_BOX_HEIGHT * m + (SearchingStrY % SEARCH_BOX_HEIGHT);
					sSBoxReg.SBoxInfo[BoxAddr].REG.EndY = ((SEARCH_BOX_HEIGHT * (m+1) + addValue) < LD_IMG_HEIGHT)? SEARCH_BOX_HEIGHT * (m+1) + addValue : LD_IMG_HEIGHT-1;
				}
				else if((SearchingEndY / SEARCH_BOX_HEIGHT) == m)
				{
					sSBoxReg.SBoxInfo[BoxAddr].REG.StrX = SEARCH_BOX_WIDTH * n;
					sSBoxReg.SBoxInfo[BoxAddr].REG.EndX = ((SEARCH_BOX_WIDTH * (n+1) + addValue) < LD_IMG_WIDTH)? SEARCH_BOX_WIDTH * (n+1) + addValue : LD_IMG_WIDTH-1;

					sSBoxReg.SBoxInfo[BoxAddr].REG.StrY = SEARCH_BOX_HEIGHT * m;
					sSBoxReg.SBoxInfo[BoxAddr].REG.EndY = SEARCH_BOX_HEIGHT * m + SearchingEndY % SEARCH_BOX_HEIGHT + addValue;
				}
				else
				{
					sSBoxReg.SBoxInfo[BoxAddr].REG.StrX = SEARCH_BOX_WIDTH * n;
					sSBoxReg.SBoxInfo[BoxAddr].REG.EndX = ((SEARCH_BOX_WIDTH * (n+1) + addValue) < LD_IMG_WIDTH)? SEARCH_BOX_WIDTH * (n+1) + addValue : LD_IMG_WIDTH-1;

					sSBoxReg.SBoxInfo[BoxAddr].REG.StrY = SEARCH_BOX_HEIGHT * m;
					sSBoxReg.SBoxInfo[BoxAddr].REG.EndY = ((SEARCH_BOX_HEIGHT * (m+1) + addValue) < LD_IMG_HEIGHT)? SEARCH_BOX_HEIGHT * (m+1) + addValue : LD_IMG_HEIGHT-1;
				}
			}
		}
	}

	//----------------------------------------------------------------------
	for(m=0; m<SEARCH_BOX_NUM_V; m++)
	{
		if(m < SearchingStrY / SEARCH_BOX_HEIGHT)
			continue;
		else if(m > (SearchingEndY / SEARCH_BOX_HEIGHT))
			break;

		for(n=0; n<SEARCH_BOX_NUM_H; n++)
		{
			BoxAddr = m * SEARCH_BOX_NUM_H + n;
			BoxStrY = sSBoxReg.SBoxInfo[BoxAddr].REG.StrY;

			//------------------------------------------------------------------
			if(rA4LdRegister->Reg.LD_AXI_MEM_SEL)
			{
				LD_addr = rA4LdRegister->Reg.LD_BASE_ADDR1;
			}
			else
			{
				LD_addr = rA4LdRegister->Reg.LD_BASE_ADDR0;
			}
			p_LD_RESULT0 = LD_addr + (BoxAddr * 4);
			tmp_LD_RESULT0.Data32 = ab_asi_io_read(p_LD_RESULT0);
			//tmp_LD_RESULT0.Data32 = p_LD_RESULT0->Data32;
			LD_RESULT0.D8.Data0 = tmp_LD_RESULT0.D8.Data3;
			LD_RESULT0.D8.Data1 = tmp_LD_RESULT0.D8.Data2;
			LD_RESULT0.D8.Data2 = tmp_LD_RESULT0.D8.Data1;
			LD_RESULT0.D8.Data3 = tmp_LD_RESULT0.D8.Data0;

			//------------------------------------------------------------------
			uHoPoint.REG.CenterX = sSBoxReg.SBoxInfo[BoxAddr].REG.StrX + LD_RESULT0.Reg.cen_x;
			uHoPoint.REG.CenterY = sSBoxReg.SBoxInfo[BoxAddr].REG.StrY + LD_RESULT0.Reg.cen_y;

			uHoPoint.REG.Width = LD_RESULT0.Reg.width;
			uHoPoint.REG.Height = LD_RESULT0.Reg.height;

			tvPnt.x = sSBoxReg.SBoxInfo[BoxAddr].REG.CenterX;
			tvPnt.y = sSBoxReg.SBoxInfo[BoxAddr].REG.CenterY;
			orgPnt = LD_Image_Draw_OrgXY_From_TopView(tvPnt);

			Draw_Lane(orgPnt.x-1, orgPnt.y-1, orgPnt.x-1, orgPnt.y-1, 5);
			Draw_Lane(orgPnt.x-0, orgPnt.y-0, orgPnt.x-0, orgPnt.y-0, 5);
			Draw_Lane(orgPnt.x+1, orgPnt.y+1, orgPnt.x+1, orgPnt.y+1, 5);
		}
	}
	*/
}

//------------------------------------------------------------------------------------
int LdHwRdAddr = 0;
void LD_PreRead_Box(void)
{
	static int InitOn = 1;
	int m, n, k, l, StrBoxNum, iTmp, iTmp1, BoxAddr, BoxStrY, addValue;
	SEARCH_BOX_INFO	uHoPoint = {0, };
	static int VanishingPointY=0, SearchingEndY=0, SearchingStrY=0;

	unsigned int uiTmp;
	unsigned int p_LD_RESULT0;

	REC_LD_RESULT LD_RESULT0;

	POINT_XY tvPnt;
	POINT_XY orgPnt;

	char	DisString[100] = {0, };
	int		DmCnt = 0;

	//- Init uHoResult Register ---------------------------------------------------------------------
	for(m=0; m<SEARCH_BOX_NUM_V; m++)
	{
		for(n=0; n<SEARCH_BOX_NUM_H; n++)
		{
			BoxAddr = m * SEARCH_BOX_NUM_H + n;

			for(iTmp=0; iTmp<7; iTmp++)
			{
				sPreSBoxReg[LdHwRdAddr].SBoxInfo[BoxAddr].Data32[iTmp] = 0;
			}
		}
	}

	//- Init uHoResult Register ---------------------------------------------------------------------
	if((VanishingPointY != LdReg.REG.VpY) || (SearchingEndY != LdReg.REG.EndY))
	{
		VanishingPointY = LdReg.REG.VpY;
		SearchingEndY = LdReg.REG.EndY;
		SearchingStrY = VanishingPointY + 20;
	}

	//-----------------------------------------------------------------------------------------------------------
	for(m=0; m<SEARCH_BOX_NUM_V; m++)
	{
		if(m < SearchingStrY / SEARCH_BOX_HEIGHT)
			continue;
		else if(m > (SearchingEndY / SEARCH_BOX_HEIGHT))
			break;

		for(n=0; n<SEARCH_BOX_NUM_H; n++)
		{
			BoxAddr = m * SEARCH_BOX_NUM_H + n;

			//------------------------------------------------------------------
			p_LD_RESULT0 = LD_addr + (BoxAddr * 8);
			LD_RESULT0.Data32[0] = REGRW32(p_LD_RESULT0, 0);
			LD_RESULT0.Data32[1] = REGRW32(p_LD_RESULT0+4, 0);

			//LD_RESULT0.Reg.Y_Sum = (int)tmp_LD_RESULT0.Reg.Y_Sum0 + ((int)tmp_LD_RESULT0.Reg.Y_Sum1)<<10;

			//------------------------------------------------------------------
			sPreSBoxReg[LdHwRdAddr].SBoxInfo[BoxAddr].REG.CenterX = LD_RESULT0.Reg.cen_x;
			sPreSBoxReg[LdHwRdAddr].SBoxInfo[BoxAddr].REG.CenterY = LD_RESULT0.Reg.cen_y;

			sPreSBoxReg[LdHwRdAddr].SBoxInfo[BoxAddr].REG.Width = LD_RESULT0.Reg.width;
			sPreSBoxReg[LdHwRdAddr].SBoxInfo[BoxAddr].REG.Height = LD_RESULT0.Reg.height;

			sPreSBoxReg[LdHwRdAddr].SBoxInfo[BoxAddr].REG.avgY = 0x80;
			sPreSBoxReg[LdHwRdAddr].SBoxInfo[BoxAddr].REG.avgCb = 0x80;
			sPreSBoxReg[LdHwRdAddr].SBoxInfo[BoxAddr].REG.avgCr = 0x80;
		}
	}
	if(LdHwRdAddr == 0)	LdHwRdAddr = 1;
	else                LdHwRdAddr = 0;
}

//------------------------------------------------------------------------------------
void LD_Read_Box(void)
{
	static int InitOn = 1;
	int m, n, k, l, StrBoxNum, iTmp, iTmp1, BoxAddr, BoxStrY, addValue;
	SEARCH_BOX_INFO	uHoPoint = {0, };	
	static int VanishingPointY=0, SearchingEndY=0, SearchingStrY=0;

	unsigned int uiTmp;
	unsigned int p_LD_RESULT0;
	//REC_LD_RESULT0 tmp_LD_RESULT0, LD_RESULT0;

	POINT_XY tvPnt;
	POINT_XY orgPnt;

	char	DisString[100] = {0, };
	int		DmCnt = 0;

	int		LdPreRdAddr = (LdHwRdAddr == 0)? 0 : 1;

	//- Init uHoResult Register ---------------------------------------------------------------------
	if((InitOn > 0) || (VanishingPointY != LdReg.REG.VpY) || (SearchingEndY != LdReg.REG.EndY))
	{
		VanishingPointY = LdReg.REG.VpY;
		SearchingEndY = LdReg.REG.EndY;
		SearchingStrY = VanishingPointY + 20;

		InitOn = 0;
		addValue = 2;

		for(m=0; m<SEARCH_BOX_NUM_V; m++)
		{
			for(n=0; n<SEARCH_BOX_NUM_H; n++)
			{
				BoxAddr = m * SEARCH_BOX_NUM_H + n;

				for(iTmp=0; iTmp<13; iTmp++)
					sSBoxReg.SBoxInfo[BoxAddr].Data32[iTmp] = 0;

				if((SearchingStrY / SEARCH_BOX_HEIGHT) == m)
				{
					sSBoxReg.SBoxInfo[BoxAddr].REG.StrX = (SEARCH_BOX_WIDTH * n) & 0x000003FF;
					uiTmp = (SEARCH_BOX_WIDTH * (n+1) + addValue);
					sSBoxReg.SBoxInfo[BoxAddr].REG.EndX = ((uiTmp < LD_IMG_WIDTH)? uiTmp : LD_IMG_WIDTH-1) & 0x000003FF;

					sSBoxReg.SBoxInfo[BoxAddr].REG.StrY = (SEARCH_BOX_HEIGHT * m + (SearchingStrY % SEARCH_BOX_HEIGHT)) & 0x000003FF;
					uiTmp = (SEARCH_BOX_HEIGHT * (m+1) + addValue);
					sSBoxReg.SBoxInfo[BoxAddr].REG.EndY = ((uiTmp < LD_IMG_HEIGHT)? uiTmp : LD_IMG_HEIGHT-1) & 0x000003FF;
				}
				else if((SearchingEndY / SEARCH_BOX_HEIGHT) == m)
				{
					sSBoxReg.SBoxInfo[BoxAddr].REG.StrX = (SEARCH_BOX_WIDTH * n) & 0x000003FF;
					uiTmp = (SEARCH_BOX_WIDTH * (n+1) + addValue);
					sSBoxReg.SBoxInfo[BoxAddr].REG.EndX = ((uiTmp < LD_IMG_WIDTH)? uiTmp : LD_IMG_WIDTH-1) & 0x000003FF;

					sSBoxReg.SBoxInfo[BoxAddr].REG.StrY = (SEARCH_BOX_HEIGHT * m) & 0x000003FF;
					uiTmp = SEARCH_BOX_HEIGHT * m + SearchingEndY % SEARCH_BOX_HEIGHT + addValue;
					sSBoxReg.SBoxInfo[BoxAddr].REG.EndY = (uiTmp) & 0x000003FF;
				}
				else
				{
					sSBoxReg.SBoxInfo[BoxAddr].REG.StrX = (SEARCH_BOX_WIDTH * n) & 0x000003FF;
					uiTmp = (SEARCH_BOX_WIDTH * (n+1) + addValue);
					sSBoxReg.SBoxInfo[BoxAddr].REG.EndX = ((uiTmp < LD_IMG_WIDTH)? uiTmp : LD_IMG_WIDTH-1) & 0x000003FF;

					sSBoxReg.SBoxInfo[BoxAddr].REG.StrY = (SEARCH_BOX_HEIGHT * m) & 0x000003FF;
					uiTmp = (SEARCH_BOX_HEIGHT * (m+1) + addValue);
					sSBoxReg.SBoxInfo[BoxAddr].REG.EndY = ((uiTmp < LD_IMG_HEIGHT)? uiTmp : LD_IMG_HEIGHT-1) & 0x000003FF;
				}
			}
		}
	}

	//----------------------------------------------------------------------
	for(m=0; m<SEARCH_BOX_NUM_H; m++)
	{
		sSBoxReg.DBoxInfoV[m].REG.VerticalMax = 0;
	}

	for(m=0; m<SEARCH_BOX_NUM_V; m++)
	{
		for(iTmp=0; iTmp<4; iTmp++)
			sSBoxReg.DBoxInfoH[m].Data32[iTmp] = 0;
	}


	for(m=0; m<SEARCH_BOX_NUM_V; m++)
	{
		if(m < SearchingStrY / SEARCH_BOX_HEIGHT)
			continue;
		else if(m > (SearchingEndY / SEARCH_BOX_HEIGHT))
			break;

		for(n=0; n<SEARCH_BOX_NUM_H; n++)
		{
			BoxAddr = m * SEARCH_BOX_NUM_H + n;
			BoxStrY = (int)sSBoxReg.SBoxInfo[BoxAddr].REG.StrY;
			if((sSBoxReg.SBoxInfo[BoxAddr].REG.StrX >= TableOrg2TV[BoxStrY].REG.posX1) && (sSBoxReg.SBoxInfo[BoxAddr].REG.EndX <= TableOrg2TV[BoxStrY].REG.posX2))
			{
				sSBoxReg.DBoxInfoV[n].REG.VerticalMax = m;

				uHoPoint.REG.avgY = 0x80;
				uHoPoint.REG.avgCb = 0x80;
				uHoPoint.REG.avgCr = 0x80;

				uHoPoint.REG.CenterX = sPreSBoxReg[LdPreRdAddr].SBoxInfo[BoxAddr].REG.CenterX;
				uHoPoint.REG.CenterY = sPreSBoxReg[LdPreRdAddr].SBoxInfo[BoxAddr].REG.CenterY;

				uHoPoint.REG.Width  = sPreSBoxReg[LdPreRdAddr].SBoxInfo[BoxAddr].REG.Width;
				uHoPoint.REG.Height = sPreSBoxReg[LdPreRdAddr].SBoxInfo[BoxAddr].REG.Height;

				sSBoxReg.SBoxInfo[BoxAddr].REG.avgY = uHoPoint.REG.avgY;
				sSBoxReg.SBoxInfo[BoxAddr].REG.avgCb = uHoPoint.REG.avgCb;
				sSBoxReg.SBoxInfo[BoxAddr].REG.avgCr = uHoPoint.REG.avgCr;

				sSBoxReg.SBoxInfo[BoxAddr].REG.DcntArea = 0;

				sSBoxReg.SBoxInfo[BoxAddr].REG.CenterX = sSBoxReg.SBoxInfo[BoxAddr].REG.StrX + uHoPoint.REG.CenterX;
				sSBoxReg.SBoxInfo[BoxAddr].REG.CenterY = sSBoxReg.SBoxInfo[BoxAddr].REG.StrY + uHoPoint.REG.CenterY;
				sSBoxReg.SBoxInfo[BoxAddr].REG.Width = uHoPoint.REG.Width;
				sSBoxReg.SBoxInfo[BoxAddr].REG.Height = uHoPoint.REG.Height;

				if((uHoPoint.REG.CenterX > 0) && (uHoPoint.REG.CenterY > 0))
				{
					sSBoxReg.SBoxInfo[BoxAddr].REG.ScoreTime = SCORE_TIME_MAX;//++;

#if 1
					tvPnt.x = (int)sSBoxReg.SBoxInfo[BoxAddr].REG.CenterX;
					tvPnt.y = (int)sSBoxReg.SBoxInfo[BoxAddr].REG.CenterY;
					orgPnt = LD_Image_Draw_OrgXY_From_TopView(tvPnt);

					Draw_Lane(orgPnt.x-1, orgPnt.y-1, orgPnt.x-1, orgPnt.y-1, 5);
					Draw_Lane(orgPnt.x-0, orgPnt.y-0, orgPnt.x-0, orgPnt.y-0, 5);
					Draw_Lane(orgPnt.x+1, orgPnt.y+1, orgPnt.x+1, orgPnt.y+1, 5);
#endif
				}
				else
				{
					sSBoxReg.SBoxInfo[BoxAddr].REG.ScoreTime = 0;//--;
				}
			}
		}
	}
}

//------------------------------------------------------------------------------------
int LdDrawAddr = 0, LdCopyAddr = 1;
void LD_Draw_Box(void)
{
	static int InitOn = 1;
	int m, n, k, l, StrBoxNum, iTmp, iTmp1, addValue;
	unsigned int BoxAddr, BoxStrY;
	int VanishingPointY=0, SearchingEndY=0, SearchingStrY=0;

	unsigned int uiTmp;
	unsigned int p_LD_RESULT0;

	POINT_XY tvPnt;
	POINT_XY orgPnt;

	char	DisString[100] = {0, };
	int		DmCnt = 0;

	VanishingPointY = LdReg.REG.VpY;
	SearchingEndY = LdReg.REG.EndY;
	SearchingStrY = VanishingPointY + 20;

	for(m=0; m<SEARCH_BOX_NUM_V; m++)
	{
		if(m < SearchingStrY / SEARCH_BOX_HEIGHT)
			continue;
		else if(m > (SearchingEndY / SEARCH_BOX_HEIGHT))
			break;

		for(n=0; n<=SEARCH_BOX_NUM_H; n++)
		{
			BoxAddr = m * SEARCH_BOX_NUM_H + n;

			if(sSBoxReg.SBoxInfo[BoxAddr].REG.ScoreTime > 0)
			{
				if((sSBoxReg.SBoxInfo[BoxAddr].REG.CenterX > 0) && (sSBoxReg.SBoxInfo[BoxAddr].REG.CenterY > 0))
				{
					tvPnt.x = sSBoxReg.SBoxInfo[BoxAddr].REG.CenterX;
					tvPnt.y = sSBoxReg.SBoxInfo[BoxAddr].REG.CenterY;
					orgPnt = LD_Image_Draw_OrgXY_From_TopView(tvPnt);

					Draw_Lane(orgPnt.x-1, orgPnt.y-1, orgPnt.x-1, orgPnt.y-1, 5);
					Draw_Lane(orgPnt.x-0, orgPnt.y-0, orgPnt.x-0, orgPnt.y-0, 5);
					Draw_Lane(orgPnt.x+1, orgPnt.y+1, orgPnt.x+1, orgPnt.y+1, 5);

					//sprintf( DisString, "%05d", BoxAddr);
					//Draw_Text(DisString, 100, 10+(DmCnt++)*20);
				}
			}
		}
	}
	if(LdDrawAddr == 0)
	{
		LdCopyAddr = 0;
		LdDrawAddr = 1;
	}
	else
	{
		LdCopyAddr = 1;
		LdDrawAddr = 0;
	}
}


//------------------------------------------------------------------------------------
void LD_Calculate_meanY(unsigned char* dest)
{
	static int InitOn = 1;

	int m, n, k, l, BoxAddr, iTmp, CenterN, BoxStrY;
	int VanishingPointY=0, SearchingEndY=0, SearchingStrY=0;

	#ifdef _RUN_MFC
		char	DisString[100] = {0, };
	#endif

	//- Init uHoResult Register ---------------------------------------------------------------------
	if((InitOn > 0) || (VanishingPointY != LdReg.REG.VpY) || (SearchingEndY != LdReg.REG.EndY))
	{
		VanishingPointY = LdReg.REG.VpY;
		SearchingEndY = LdReg.REG.EndY;
		SearchingStrY = VanishingPointY + 20;

		InitOn = 0;

	}

	averageY[0] = 0;
	averageY[1] = 0;
	avergageCnt[0] = 0;
	avergageCnt[1] = 0;

	for(m=0; m<SEARCH_BOX_NUM_V; m++)
	{
		if(m < SearchingStrY / SEARCH_BOX_HEIGHT)
			continue;
		else if(m > (SearchingEndY / SEARCH_BOX_HEIGHT))
			break;

		for(n=0; n<SEARCH_BOX_NUM_H; n++)
		{
			CenterN = (LdReg.REG.VpX + svp_x) / SEARCH_BOX_WIDTH;
			BoxAddr = m * SEARCH_BOX_NUM_H + n;

			BoxAddr = m * SEARCH_BOX_NUM_H + n;
			BoxStrY = sSBoxReg.SBoxInfo[BoxAddr].REG.StrY;
			if((sSBoxReg.SBoxInfo[BoxAddr].REG.StrX > TableOrg2TV[BoxStrY].REG.posX1) && (sSBoxReg.SBoxInfo[BoxAddr].REG.EndX < TableOrg2TV[BoxStrY].REG.posX2))
			{
				if(sSBoxReg.SBoxInfo[BoxAddr].REG.avgY > 10)
				{
					if((m >= 25) && (n >= CenterN-12) && (n < CenterN-2))
					{
						averageY[0] += sSBoxReg.SBoxInfo[BoxAddr].REG.avgY;
						avergageCnt[0]++;
					}
					else if((m >= 25) && (n > CenterN+2) && (n <= CenterN+12))
					{
						averageY[1] += sSBoxReg.SBoxInfo[BoxAddr].REG.avgY;
						avergageCnt[1]++;
					}
				}
			#ifdef _RUN_MFC
				for(k=sSBoxReg.SBoxInfo[BoxAddr].REG.StrY; k<=sSBoxReg.SBoxInfo[BoxAddr].REG.EndY-2; k++)
				{
					for(l=sSBoxReg.SBoxInfo[BoxAddr].REG.StrX; l<=sSBoxReg.SBoxInfo[BoxAddr].REG.EndX-2; l++)
					{
						dest[k * LD_IMG_WIDTH + l] = sSBoxReg.SBoxInfo[BoxAddr].REG.avgY;
					}
				}
			#endif
			}
		}
	}

	//-----------
	if(avergageCnt[0] > 0)	averageYold[0] = averageY[0] / avergageCnt[0];
	else                    averageYold[0] = averageY[0];

	averageYold[0] = (averageYold[0] > 255)? 255 : averageYold[0];

	//-----------
	if(avergageCnt[1] > 0)	averageYold[1] = averageY[1] / avergageCnt[1];
	else                    averageYold[1] = averageY[1];

	averageYold[1] = (averageYold[1] > 255)? 255 : averageYold[1];

	iTmp = averageYold[0] - 100;
	if(iTmp < 0)	iTmp = 0;
	else            iTmp = iTmp / 10;
	AddDiffY[0] = iTmp;

	iTmp = averageYold[1] - 100;
	if(iTmp < 0)	iTmp = 0;
	else            iTmp = iTmp / 10;
	AddDiffY[1] = iTmp;

	#ifdef _RUN_MFC
		sprintf( DisString, "%03d %03d %02d %02d", averageYold[0], averageYold[1], AddDiffY[0], AddDiffY[1]);
		Draw_Text(dest, DisString, 10, 10+5*20);

		sprintf( DisString, "%03d %03d", avergageCnt[0], avergageCnt[1]);
		Draw_Text(dest, DisString, 10, 10+6*20);
	#endif

}

//------------------------------------------------------------------------------------
void LD_Erasing_Box_0(void)
{
	static int InitOn = 1;
	int m, n, k, StrBoxNum, iTmp, iTmp1, BoxAddr, BoxStrY, addValue, BoxOnBit;
	int i, Min, Max;
	SEARCH_BOX_INFO	uHoPoint = {0, };	
	int VanishingPointY=0, SearchingEndY=0, SearchingStrY=0;

#ifdef _RUN_MFC
	char	DisString[100] = {0, };
	
	/*
	for(m=0; m<LD_IMG_WIDTH*LD_IMG_HEIGHT; m++)
	{
		dest1[m] = 0;
	}
	for(m=0; m<LD_IMG_WIDTH*LD_IMG_HEIGHT/2; m++)
	{
		dest1[LD_IMG_WIDTH*LD_IMG_HEIGHT+m] = 0x80;
	}
	*/
	
#endif 

	//- Init uHoResult Register ---------------------------------------------------------------------
	if((InitOn > 0) || (VanishingPointY != LdReg.REG.VpY) || (SearchingEndY != LdReg.REG.EndY))
	{
		VanishingPointY = LdReg.REG.VpY;
		SearchingEndY = LdReg.REG.EndY;
		SearchingStrY = VanishingPointY + 20;

		InitOn = 0;

	}

	// searching left to right ---------------------------------------------------------------------
	for(m=0; m<SEARCH_BOX_NUM_V; m++)
	{
		if(m < SearchingStrY / SEARCH_BOX_HEIGHT)
			continue;
		else if(m >= ((SearchingEndY / SEARCH_BOX_HEIGHT) - 1)) // because of last lane
			break;

		BoxOnBit = 0;
		for(n=0; n<SEARCH_BOX_NUM_H; n++)
		{
			BoxAddr = m * SEARCH_BOX_NUM_H + n;
			BoxStrY = sSBoxReg.SBoxInfo[BoxAddr].REG.StrY;
			if((sSBoxReg.SBoxInfo[BoxAddr].REG.StrX > TableOrg2TV[BoxStrY].REG.posX1) && (sSBoxReg.SBoxInfo[BoxAddr].REG.EndX < TableOrg2TV[BoxStrY].REG.posX2))
			{
				if(sSBoxReg.SBoxInfo[BoxAddr - SEARCH_BOX_NUM_H].REG.ScoreTime > 0)
				{
					iTmp = sSBoxReg.SBoxInfo[BoxAddr].REG.avgY;
					if( ((n <  SEARCH_BOX_NUM_H/2) && ((averageYold[0]*0.6 > iTmp))) ||
						((n >= SEARCH_BOX_NUM_H/2) && ((averageYold[1]*0.6 > iTmp))) )
					{
						sSBoxReg.SBoxInfo[BoxAddr - SEARCH_BOX_NUM_H].REG.ScoreTime = 0;
					#ifdef _RUN_MFC
						Draw_Box(dest1,LD_IMG_WIDTH, 
							sSBoxReg.SBoxInfo[BoxAddr - SEARCH_BOX_NUM_H].REG.StrX, 
							sSBoxReg.SBoxInfo[BoxAddr - SEARCH_BOX_NUM_H].REG.StrY, 
							sSBoxReg.SBoxInfo[BoxAddr - SEARCH_BOX_NUM_H].REG.EndX, 
							sSBoxReg.SBoxInfo[BoxAddr - SEARCH_BOX_NUM_H].REG.EndY, 2);
					#endif
					}
				}

				if(sSBoxReg.SBoxInfo[BoxAddr].REG.ScoreTime > 0)
				{
					//------------------------------------------------
					iTmp = sSBoxReg.SBoxInfo[BoxAddr-1].REG.avgY;
					iTmp1 = sSBoxReg.SBoxInfo[BoxAddr+1].REG.avgY;

					if( ((n < SEARCH_BOX_NUM_H/2)  && ((averageYold[0]*0.6 > iTmp) && (averageYold[0]*0.6 > iTmp1))) ||
						((n >= SEARCH_BOX_NUM_H/2) && ((averageYold[1]*0.6 > iTmp) && (averageYold[1]*0.6 > iTmp1))) )
					{
						sSBoxReg.SBoxInfo[BoxAddr].REG.ScoreTime = 0;
						#ifdef _RUN_MFC
						Draw_Box(dest1,LD_IMG_WIDTH, 
							sSBoxReg.SBoxInfo[BoxAddr].REG.StrX, 
							sSBoxReg.SBoxInfo[BoxAddr].REG.StrY, 
							sSBoxReg.SBoxInfo[BoxAddr].REG.EndX, 
							sSBoxReg.SBoxInfo[BoxAddr].REG.EndY, 2);
						#endif
					}

					//------------------------------------------------
					iTmp = sSBoxReg.SBoxInfo[BoxAddr].REG.avgY;
					if( ((n <  SEARCH_BOX_NUM_H/2) && (averageYold[0]*0.6 > iTmp)) ||
						((n >= SEARCH_BOX_NUM_H/2) && (averageYold[1]*0.6 > iTmp)) )
					{
						sSBoxReg.SBoxInfo[BoxAddr].REG.ScoreTime = 0;
						#ifdef _RUN_MFC
							Draw_Box(dest1,LD_IMG_WIDTH, 
								sSBoxReg.SBoxInfo[BoxAddr].REG.StrX, 
								sSBoxReg.SBoxInfo[BoxAddr].REG.StrY, 
								sSBoxReg.SBoxInfo[BoxAddr].REG.EndX, 
								sSBoxReg.SBoxInfo[BoxAddr].REG.EndY, 2);
						#endif
					}
				}
			}
		}
	}

}


//------------------------------------------------------------------------------------
void LD_Erasing_Box_1(void)
{
	static int InitOn = 1;
	int m, n, k, StrBoxNum, iTmp, iTmp1, BoxAddr, BoxStrY, addValue, BoxOnBit;
	int i, Min, Max;
	SEARCH_BOX_INFO	uHoPoint = {0, };	
	int VanishingPointY=0, SearchingEndY=0, SearchingStrY=0;

	//- Init uHoResult Register ---------------------------------------------------------------------
	if((InitOn > 0) || (VanishingPointY != LdReg.REG.VpY) || (SearchingEndY != LdReg.REG.EndY))
	{
		VanishingPointY = (int)LdReg.REG.VpY;
		SearchingEndY = (int)LdReg.REG.EndY;
		SearchingStrY = VanishingPointY + 20;

		InitOn = 0;
	}

	// searching left to right ---------------------------------------------------------------------
	for(m=0; m<SEARCH_BOX_NUM_V; m++)
	{
		if(m < SearchingStrY / SEARCH_BOX_HEIGHT)
			continue;
		else if(m > (SearchingEndY / SEARCH_BOX_HEIGHT))
			break;

		BoxOnBit = 0;
		for(n=0; n<SEARCH_BOX_NUM_H; n++)
		{
			BoxAddr = m * SEARCH_BOX_NUM_H + n;
			BoxStrY = (int)sSBoxReg.SBoxInfo[BoxAddr].REG.StrY;
			if((sSBoxReg.SBoxInfo[BoxAddr].REG.StrX >= TableOrg2TV[BoxStrY].REG.posX1) && (sSBoxReg.SBoxInfo[BoxAddr].REG.EndX <= TableOrg2TV[BoxStrY].REG.posX2))
			{
				if(sSBoxReg.SBoxInfo[BoxAddr].REG.ScoreTime > 0)
				{
					if(n >= DAX_0_MIN)
					{
						if(n < SEARCH_BOX_NUM_H*1/4)		{if(BoxOnBit>=2)	(unsigned int)sSBoxReg.DBoxInfoH[m].REG.DcntArea0++;}
						else if(n < SEARCH_BOX_NUM_H*2/4)	{if(BoxOnBit>=2)	(unsigned int)sSBoxReg.DBoxInfoH[m].REG.DcntArea1++;}
						else if(n < SEARCH_BOX_NUM_H*3/4)	{if(BoxOnBit>=2)	(unsigned int)sSBoxReg.DBoxInfoH[m].REG.DcntArea2++;}
						else if(n < DAX_3_MAX)				{if(BoxOnBit>=2)	(unsigned int)sSBoxReg.DBoxInfoH[m].REG.DcntArea3++;}
					}
					BoxOnBit++;
				}
				else if(BoxOnBit > 0)	BoxOnBit--;
				else					BoxOnBit = 0;
			}
			else	BoxOnBit = 0;
		}
	}
	return;

	// searching right to left ---------------------------------------------------------------------
	for(m=0; m<SEARCH_BOX_NUM_V; m++)
	{
		if(m < SearchingStrY / SEARCH_BOX_HEIGHT)
			continue;
		else if(m > (SearchingEndY / SEARCH_BOX_HEIGHT))
			break;

		BoxOnBit = 0;
		for(n=SEARCH_BOX_NUM_H-1; n>=0; n--)
		{
			BoxAddr = m * SEARCH_BOX_NUM_H + n;
			BoxStrY = (int)sSBoxReg.SBoxInfo[BoxAddr].REG.StrY;
			if((sSBoxReg.SBoxInfo[BoxAddr].REG.StrX >= TableOrg2TV[BoxStrY].REG.posX1) && (sSBoxReg.SBoxInfo[BoxAddr].REG.EndX <= TableOrg2TV[BoxStrY].REG.posX2))
			{
				if(sSBoxReg.SBoxInfo[BoxAddr].REG.ScoreTime > 0)
				{
					if(n <= DAX_3_MAX)
					{
						if(n > SEARCH_BOX_NUM_H*3/4)		{if(BoxOnBit>=2)	(unsigned int)sSBoxReg.DBoxInfoH[m].REG.DcntArea3++;}
						else if(n > SEARCH_BOX_NUM_H*2/4)	{if(BoxOnBit>=2)	(unsigned int)sSBoxReg.DBoxInfoH[m].REG.DcntArea2++;}
						else if(n > SEARCH_BOX_NUM_H*1/4)	{if(BoxOnBit>=2)	(unsigned int)sSBoxReg.DBoxInfoH[m].REG.DcntArea1++;}
						else if(n > DAX_1_MIN)				{if(BoxOnBit>=2)	(unsigned int)sSBoxReg.DBoxInfoH[m].REG.DcntArea0++;}
					}
					BoxOnBit++;
				}
				else if(BoxOnBit > 0)	BoxOnBit--;
				else					BoxOnBit = 0;
			}
			else	BoxOnBit = 0;
		}
	}

	//----------------------------------------------------------------------
	for(m=1; m<SEARCH_BOX_NUM_V-1; m++)
	{
		if(m < SearchingStrY / SEARCH_BOX_HEIGHT)
			continue;
		else if(m > (SearchingEndY / SEARCH_BOX_HEIGHT))
			break;

		for(i=0; i<4; i++)
		{
			Min = 1; Max = 0;
			if((i == 0) && ((unsigned int)sSBoxReg.DBoxInfoH[m].REG.DcntArea0 >= 3))		{Min = DAX_0_MIN;			 Max = SEARCH_BOX_NUM_H*1/4;}
			else if((i == 1) && ((unsigned int)sSBoxReg.DBoxInfoH[m].REG.DcntArea1 >= 3))	{Min = SEARCH_BOX_NUM_H*1/4; Max = SEARCH_BOX_NUM_H*2/4;}
			else if((i == 2) && ((unsigned int)sSBoxReg.DBoxInfoH[m].REG.DcntArea2 >= 3))	{Min = SEARCH_BOX_NUM_H*2/4; Max = SEARCH_BOX_NUM_H*3/4;}
			else if((i == 3) && ((unsigned int)sSBoxReg.DBoxInfoH[m].REG.DcntArea3 >= 3))	{Min = SEARCH_BOX_NUM_H*3/4; Max = DAX_3_MAX;}

			for(n=Min; n<Max; n++)
			{
				for(k=-1; k<2; k++)
				{
					BoxAddr = (m+k) * SEARCH_BOX_NUM_H + n;
					if(sSBoxReg.SBoxInfo[BoxAddr].REG.ScoreTime > 0)
					{
						sSBoxReg.SBoxInfo[BoxAddr].REG.DcntArea = 1;

						#ifdef _RUN_MFC
							Draw_Box(dest1,LD_IMG_WIDTH, 
								sSBoxReg.SBoxInfo[BoxAddr].REG.StrX, 
								sSBoxReg.SBoxInfo[BoxAddr].REG.StrY, 
								sSBoxReg.SBoxInfo[BoxAddr].REG.EndX, 
								sSBoxReg.SBoxInfo[BoxAddr].REG.EndY, 3);
						#endif	// _RUN_MFC
					}
				}
			}
		}
	}
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------
int Calculate_Angle(int StrPntX, int StrPntY, int EndPntX, int EndPntY)
{
	int i, iTmp, DetCnt, errCnt = 0;
	int iAngle=90, oldAngle=90, iLengthX, iLengthY;
	POINT_XY tvPnt;
	POINT_XY orgPnt0, orgPnt1;

	//tvPnt.x = StrPntX;
	//tvPnt.y = StrPntY;
	//orgPnt0 = LD_Image_Draw_OrgXY_From_TopView(tvPnt);
	orgPnt0.x = StrPntX;
	orgPnt0.y = StrPntY;

	//tvPnt.x = EndPntX;
	//tvPnt.y = EndPntY;
	//orgPnt1 = LD_Image_Draw_OrgXY_From_TopView(tvPnt);
	orgPnt1.x = EndPntX;
	orgPnt1.y = EndPntY;

	// lane angle calculation 
	iLengthX = abs(orgPnt0.x - orgPnt1.x);
	iLengthY = abs(orgPnt0.y - orgPnt1.y);

	// angle is under 45 degree (x / y) --> angle is over 45 degree if (y > x)
	if(iLengthX == 0)				iAngle = 90;
	else if(iLengthX == iLengthY) 	iAngle = 45;
	else if(iLengthX < iLengthY)
	{
		iTmp = iLengthX*100 / iLengthY;
		if(iTmp >= 100)	iTmp = 100;
		iAngle = 90 - TAN_TABLE[iTmp];
	}
	else if(iLengthX > iLengthY)
	{
		iTmp = iLengthY*100 / iLengthX;
		if(iTmp >= 100)	iTmp = 100;
		iAngle = TAN_TABLE[iTmp];
	}

	if(StrPntX > EndPntX)	
		iAngle = 180 - iAngle;

	return iAngle;
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------
int Researching_Lane(SEARCHING_LANE_REGISTER *sSLaneTemp, int TDir)
{
	int i, iTmp, DetCnt, errCnt = 0;
	int iAngle, oldAngle=90, iLengthX, iLengthY;
	POINT_XY tvPnt;
	POINT_XY orgPnt0, orgPnt1;

	DetCnt = sSLaneTemp->SLaneInfo.REG.DetCnt;
	//iAngle = sSLaneTemp->SLaneInfo.REG.Angle;

	for(i=0; i<DetCnt-1; i++)
	{
		tvPnt.x = sSLaneTemp->SLanePnt[i].REG.CenterX;
		tvPnt.y = sSLaneTemp->SLanePnt[i].REG.CenterY;
		orgPnt0 = LD_Image_Draw_OrgXY_From_TopView(tvPnt);

		tvPnt.x = sSLaneTemp->SLanePnt[i+1].REG.CenterX;
		tvPnt.y = sSLaneTemp->SLanePnt[i+1].REG.CenterY;
		orgPnt1 = LD_Image_Draw_OrgXY_From_TopView(tvPnt);

		// lane angle calculation 
		iLengthX = abs(orgPnt0.x - orgPnt1.x);
		iLengthY = abs(orgPnt0.y - orgPnt1.y);

		// angle is under 45 degree (x / y) --> angle is over 45 degree if (y > x)
		if(iLengthX == 0)				iAngle = 90;
		else if(iLengthX == iLengthY) 	iAngle = 45;
		else if(iLengthX < iLengthY)
		{
			iTmp = iLengthX*100 / iLengthY;
			if(iTmp >= 100)	iTmp = 100;
			iAngle = 90 - TAN_TABLE[iTmp];
		}
		else if(iLengthX > iLengthY)
		{
			iTmp = iLengthY*100 / iLengthX;
			if(iTmp >= 100)	iTmp = 100;
			iAngle = TAN_TABLE[iTmp];
		}

		if(sSLaneTemp->SLanePnt[i].REG.CenterX > sSLaneTemp->SLanePnt[i+1].REG.CenterX)	
			iAngle = 180 - iAngle;

		//----------------------------------------------------------------------------------------------------------
		if(i > 0)
		{
			if(sSLaneTemp->SLanePnt[i+1].REG.ResultOn < 2)
			{
				if(TDir == 0)
				{
					if(abs(iAngle - oldAngle > 50) && ((iAngle - oldAngle) < 20))
					{
						errCnt++;
					}	
				}
				else if(TDir == 1)
				{
					if(abs(iAngle - oldAngle > 50) && ((oldAngle - iAngle) < 20))
					{
						errCnt++;
					}	
				}
				oldAngle = iAngle;
			}
		}
		else
			oldAngle = iAngle;
	}
	return errCnt;
}


//-------------------------------------------------------------------------------------------------------------------------------------------------------
typedef union
{
	unsigned int DATA32;

	struct{
		unsigned int ResultAddr:	16;
		unsigned int Result:		8;
		unsigned int ResultOn:		2;
		unsigned int Rev0_0:		6;
	}REG;
}PRE_SEARCHING_RESULT;

void LD_Searching_Lane(void)
{
	static int InitOn = 1;
	int BoxCnt = 0, DetCnt;
	SEARCH_BOX_INFO	uHoPoint = {0, };	
	int TDir, m, n=0, k, i, EndBoxNum;
	int TAddr, CandiAddr, CandiAddrSave, CandiOn, BreakCnt, tmpAddr;
	static int oldMove=0, oldMove1=0;
	int iTmp, iTmp1, diffX;
	int vp_y;
	PRE_SEARCHING_RESULT PreSearchingResult[5];
	int iLengthX, iLengthY, iAngle;
	int preAngle, curAngle, OldAndNewMatch=0;
	int DmCnt=0;

	POINT_XY tvPnt;
	POINT_XY orgPnt;

#ifdef _RUN_MFC
	char	DisString[100] = {0, };
#else
	char	DisString[100] = {0, };
#endif

	vp_y = LdReg.REG.VpY;

	#ifdef _RUN_MFC
		/*
		for(m=0; m<LD_IMG_WIDTH*LD_IMG_HEIGHT; m++)		dest[m] = 0;
		for(m=0; m<LD_IMG_WIDTH*LD_IMG_HEIGHT/2; m++)	dest[LD_IMG_WIDTH*LD_IMG_HEIGHT+m] = 0x80;
		*/
		for(m=0; m<LD_IMG_WIDTH*LD_IMG_HEIGHT; m++)		dest1[m] = 0;
		for(m=0; m<LD_IMG_WIDTH*LD_IMG_HEIGHT/2; m++)	dest1[LD_IMG_WIDTH*LD_IMG_HEIGHT+m] = 0x80;
	#endif // !_RUN_MFC
	
	//- Init uHoResult Register ---------------------------------------------------------------------
	if(InitOn > 0)
	{
		InitOn = 0;

		for(m=0; m<SEARCHING_LANE_NUM; m++)
		{
			for(TDir=0; TDir<2; TDir++)
			{
				sSLaneReg[m][TDir].SLaneInfo.REG.DetCnt = 0;
			}
		}
	}

	//----------------------------------------------------------------------
	k=0;
	EndBoxNum = (vp_y+20) / SEARCH_BOX_HEIGHT * SEARCH_BOX_NUM_H;

	//#ifdef _RUN_MFC
	//	sprintf( DisString, "%03d", EndBoxNum);
	//	Draw_Text(dest, DisString, 10, 10+0*20);
	//#endif

	//---------------------------------------

	for(m=0; m<SEARCHING_LANE_NUM; m++)
	{
		for(TDir=0; TDir<2; TDir++)
		{
			TAddr = (sSBoxReg.DBoxInfoV[m].REG.VerticalMax)*SEARCH_BOX_NUM_H + m;
			sSLaneReg[m][TDir].SLaneInfo.REG.DetCnt = 0;

			// search lane
			DetCnt = 0;
			diffX = 0;
			if((sSBoxReg.SBoxInfo[TAddr].REG.ScoreTime == SCORE_TIME_MAX) && (sSBoxReg.SBoxInfo[TAddr].REG.DcntArea == 0))
			{
				sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.BoxAddr = TAddr;
				sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.CenterX = sSBoxReg.SBoxInfo[TAddr].REG.CenterX;
				sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.CenterY = sSBoxReg.SBoxInfo[TAddr].REG.EndY;//sSBoxReg.SBoxInfo[TAddr].REG.CenterY;

				sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.Width = sSBoxReg.SBoxInfo[TAddr].REG.Width;
				sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.Height = sSBoxReg.SBoxInfo[TAddr].REG.Height;

				//sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.EndY = sSBoxReg.SBoxInfo[TAddr].REG.EndY;
				sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.ScoreTime = sSBoxReg.SBoxInfo[TAddr].REG.ScoreTime;
			}
			else
			{
				sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.BoxAddr = TAddr;
				sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.CenterX = sSBoxReg.SBoxInfo[TAddr].REG.StrX + SEARCH_BOX_WIDTH/2;
				sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.CenterY = sSBoxReg.SBoxInfo[TAddr].REG.EndY;

				sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.Width = 1;
				sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.Height = 1;

				//sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.EndY = sSBoxReg.SBoxInfo[TAddr].REG.EndY;
				sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.ScoreTime = 0;
			}

			DetCnt = 1;

			BreakCnt = 0;
			OldAndNewMatch = 0;
			for(TAddr; TAddr > EndBoxNum;)//ScoreAddr-=SEARCH_BOX_NUM_H)
			{
				CandiOn = 0;
				for(n=0; n<4; n++)
				{
					if(DetCnt == 1)
					{
						CandiAddr = TAddr-SEARCH_BOX_NUM_H;
					}
					else
					{
						if(TDir == 0)
						{
							if(diffX < 2*2)
							{
								if(n==0)		CandiAddr = TAddr-SEARCH_BOX_NUM_H;
								else if(n==1)	CandiAddr = TAddr+1-SEARCH_BOX_NUM_H;
								else if(n==2)	CandiAddr = TAddr+2-SEARCH_BOX_NUM_H;
								else if(n==3)	CandiAddr = TAddr+1;
								//else if(n==4)	CandiAddr = TAddr-1-SEARCH_BOX_NUM_H;
							}
							else
							{
								if(n==0)							CandiAddr = TAddr+1-SEARCH_BOX_NUM_H;
								else if(n==1)						CandiAddr = TAddr+2-SEARCH_BOX_NUM_H;
								else if((n==2) && (diffX < 4*2))	CandiAddr = TAddr-SEARCH_BOX_NUM_H;
								else if(n==3)						CandiAddr = TAddr+1;
								//else if(n==3)						CandiAddr = TAddr+1-SEARCH_BOX_NUM_H;
							}
						}
						else
						{
							if(diffX < 2*2)
							{
								if(n==0)		CandiAddr = TAddr-SEARCH_BOX_NUM_H;
								else if(n==1)	CandiAddr = TAddr-1-SEARCH_BOX_NUM_H;
								else if(n==2)	CandiAddr = TAddr-2-SEARCH_BOX_NUM_H;
								else if(n==3)	CandiAddr = TAddr-1;
								//else if(n==4)	CandiAddr = TAddr+1-SEARCH_BOX_NUM_H;
							}
							else
							{
								if(n==0)							CandiAddr = TAddr-1-SEARCH_BOX_NUM_H;
								else if(n==1)						CandiAddr = TAddr-2-SEARCH_BOX_NUM_H;
								else if((n==2) && (diffX < 4*2))	CandiAddr = TAddr-SEARCH_BOX_NUM_H;
								else if(n==3)						CandiAddr = TAddr-1;
								//else if(n==4)						CandiAddr = TAddr-1-SEARCH_BOX_NUM_H;
							}
						}
					}

					PreSearchingResult[n].REG.Result = 0;
					PreSearchingResult[n].REG.ResultAddr = CandiAddr;
					if((sSBoxReg.SBoxInfo[CandiAddr].REG.ScoreTime == SCORE_TIME_MAX) && (sSBoxReg.SBoxInfo[TAddr].REG.DcntArea == 0))
					{
						PreSearchingResult[n].REG.Result = 2;
					}
					else if((sSBoxReg.SBoxInfo[CandiAddr].REG.ScoreTime == SCORE_TIME_MAX) && (sSBoxReg.SBoxInfo[TAddr].REG.DcntArea == 0))
					{
						PreSearchingResult[n].REG.Result = 1;
						iTmp = abs(sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterX - sSBoxReg.SBoxInfo[CandiAddr].REG.CenterX);
						iTmp = iTmp - (sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.Width + sSBoxReg.SBoxInfo[CandiAddr].REG.Width)/2;

						iTmp1 = abs(sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterY - sSBoxReg.SBoxInfo[CandiAddr].REG.CenterY);
						iTmp1 = iTmp1 - (sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.Height + sSBoxReg.SBoxInfo[CandiAddr].REG.Height)/2;

						if((iTmp <= 0) && (iTmp1 <= 0))
						{
							PreSearchingResult[n].REG.Result = 2;
						}

						//------------------------------------------------------------------------------------------------------------
						if(DetCnt <= 3)
						{
							iTmp = abs(sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.CenterX - sSBoxReg.SBoxInfo[CandiAddr].REG.CenterX);
							iTmp = iTmp - (sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.Width + sSBoxReg.SBoxInfo[CandiAddr].REG.Width)/2;

							iTmp1 = abs(sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.CenterY - sSBoxReg.SBoxInfo[CandiAddr].REG.CenterY);
							iTmp1 = iTmp1 - (sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.Height + sSBoxReg.SBoxInfo[CandiAddr].REG.Height)/2;

							if((iTmp <= 1) && (iTmp1 <= 1))
							{
								PreSearchingResult[n].REG.Result = 2;
							}
						}						
					}
				}

				PreSearchingResult[4].REG.ResultOn = 0;
				for(n=0; n<4; n++)
				{
					if(PreSearchingResult[n].REG.Result == 2)
					{
						CandiAddr = PreSearchingResult[n].REG.ResultAddr;
						PreSearchingResult[4].REG.ResultOn = 2;
						OldAndNewMatch++;
						break;
					}
				}
				if(PreSearchingResult[4].REG.ResultOn == 0)
				{
					for(n=0; n<4; n++)
					{
						if(PreSearchingResult[n].REG.Result == 1)
						{
							CandiAddr = PreSearchingResult[n].REG.ResultAddr;

							if(DetCnt > 2)
							{
								if(sSLaneReg[m][TDir].SLanePnt[0].REG.ScoreTime == SCORE_TIME_MAX)
								{
									preAngle = Calculate_Angle(	sSLaneReg[m][TDir].SLanePnt[0].REG.CenterX,
										sSLaneReg[m][TDir].SLanePnt[0].REG.CenterY,
										sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterX,
										sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterY);

									curAngle = Calculate_Angle(	sSLaneReg[m][TDir].SLanePnt[0].REG.CenterX,
										sSLaneReg[m][TDir].SLanePnt[0].REG.CenterY,
										sSBoxReg.SBoxInfo[CandiAddr].REG.CenterX,
										sSBoxReg.SBoxInfo[CandiAddr].REG.CenterY);
								}
								else
								{
									preAngle = Calculate_Angle(	sSLaneReg[m][TDir].SLanePnt[1].REG.CenterX,
										sSLaneReg[m][TDir].SLanePnt[1].REG.CenterY,
										sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterX,
										sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterY);

									curAngle = Calculate_Angle(	sSLaneReg[m][TDir].SLanePnt[1].REG.CenterX,
										sSLaneReg[m][TDir].SLanePnt[1].REG.CenterY,
										sSBoxReg.SBoxInfo[CandiAddr].REG.CenterX,
										sSBoxReg.SBoxInfo[CandiAddr].REG.CenterY);
								}

								if((abs(preAngle - 90) < 10) && (abs(curAngle - 90) < 10))
								{
									PreSearchingResult[4].REG.ResultOn = 1;
									//break;
								}
								else if((preAngle < 90) && (preAngle+2 > curAngle) && (preAngle < curAngle+30))
								{
									PreSearchingResult[4].REG.ResultOn = 1;
									//break;
								}
								else if((preAngle > 90) && (preAngle-2 < curAngle) && (preAngle+30 > curAngle))
								{
									PreSearchingResult[4].REG.ResultOn = 1;
									//break;
								}


								if(PreSearchingResult[4].REG.ResultOn > 0)
								{
									if((DetCnt == 3) && (sSLaneReg[m][TDir].SLanePnt[0].REG.ScoreTime == SCORE_TIME_MAX))
									{
										preAngle = Calculate_Angle(	sSLaneReg[m][TDir].SLanePnt[0].REG.CenterX,
											sSLaneReg[m][TDir].SLanePnt[0].REG.CenterY,
											sSLaneReg[m][TDir].SLanePnt[1].REG.CenterX,
											sSLaneReg[m][TDir].SLanePnt[1].REG.CenterY);

										curAngle = Calculate_Angle(	sSLaneReg[m][TDir].SLanePnt[1].REG.CenterX,
											sSLaneReg[m][TDir].SLanePnt[1].REG.CenterY,
											sSBoxReg.SBoxInfo[CandiAddr].REG.CenterX,
											sSBoxReg.SBoxInfo[CandiAddr].REG.CenterY);
									}
									else
									{
										preAngle = Calculate_Angle(	sSLaneReg[m][TDir].SLanePnt[DetCnt-3].REG.CenterX,
											sSLaneReg[m][TDir].SLanePnt[DetCnt-3].REG.CenterY,
											sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterX,
											sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterY);

										curAngle = Calculate_Angle(	sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterX,
											sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterY,
											sSBoxReg.SBoxInfo[CandiAddr].REG.CenterX,
											sSBoxReg.SBoxInfo[CandiAddr].REG.CenterY);
									}

									if((abs(preAngle - 90) < 10) && (abs(curAngle - 90) < 10))
									{
										PreSearchingResult[4].REG.ResultOn = 1;
										break;
									}
									else if((preAngle < 90) && (preAngle+2 > curAngle) && (preAngle < curAngle+30))
									{
										PreSearchingResult[4].REG.ResultOn = 1;
										break;
									}
									else if((preAngle > 90) && (preAngle-2 < curAngle) && (preAngle+30 > curAngle))
									{
										PreSearchingResult[4].REG.ResultOn = 1;
										break;
									}
									else
									{
										PreSearchingResult[4].REG.ResultOn = 0;
									}
								}

							}
							else						
							{
								PreSearchingResult[4].REG.ResultOn = 1;
								break;
							}
						}
					}
				}


				if(PreSearchingResult[4].REG.ResultOn > 0)
				{
					//if(sSBoxReg.SBoxInfo[CandiAddr].REG.ScoreTime >= SCORE_TIME_MAX)
					//{
						/*
						if((DetCnt != 1) || 
						   ((DetCnt == 1) && (sSBoxReg.SBoxInfo[CandiAddr - 1 + SEARCH_BOX_NUM_H].REG.ScoreTime != SCORE_TIME_MAX) && 
						    (sSBoxReg.SBoxInfo[CandiAddr + 1 + SEARCH_BOX_NUM_H].REG.ScoreTime != SCORE_TIME_MAX)))
							*/ // 李⑥꽑??寃뱀퀜?????????????寃쎌슦 臾몄젣媛� ????.

						//-------------------------------------------------------------------------
						iTmp = sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.BoxAddr % SEARCH_BOX_NUM_H;
						iTmp1 = CandiAddr % SEARCH_BOX_NUM_H;

						// if move to up side
						if(iTmp == iTmp1)
						{
							for(i=0; i<4; i++)
							{
								if(i==0)		tmpAddr = CandiAddr - 1 + SEARCH_BOX_NUM_H;
								else if(i==1)	tmpAddr = CandiAddr - 1;
								else if(i==2)	tmpAddr = CandiAddr + 1;
								else if(i==3)	tmpAddr = CandiAddr + 1 + SEARCH_BOX_NUM_H;

								iTmp = abs(sSBoxReg.SBoxInfo[tmpAddr].REG.CenterX - sSBoxReg.SBoxInfo[CandiAddr].REG.CenterX);
								iTmp = iTmp - (sSBoxReg.SBoxInfo[tmpAddr].REG.Width + sSBoxReg.SBoxInfo[CandiAddr].REG.Width)/2;

								iTmp1 = abs(sSBoxReg.SBoxInfo[tmpAddr].REG.CenterY - sSBoxReg.SBoxInfo[CandiAddr].REG.CenterY);
								iTmp1 = iTmp1 - (sSBoxReg.SBoxInfo[tmpAddr].REG.Height + sSBoxReg.SBoxInfo[CandiAddr].REG.Height)/2;

								if((iTmp <= 1) && (iTmp1 <= 1) &&
									(sSBoxReg.SBoxInfo[tmpAddr].REG.CenterY > sSBoxReg.SBoxInfo[CandiAddr].REG.CenterY) &&
									((sSBoxReg.SBoxInfo[tmpAddr].REG.Width + sSBoxReg.SBoxInfo[CandiAddr].REG.Width) >= 10)	)
								{
									CandiOn = 0;
									break;
								}
								else
									CandiOn = 1;
							}
						}
						else
							CandiOn = 1;

						if(CandiOn > 0)
						{
							if(sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterY > sSBoxReg.SBoxInfo[CandiAddr].REG.CenterY+1)
							{
								sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.ScoreTime = sSBoxReg.SBoxInfo[CandiAddr].REG.ScoreTime;
								sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.BoxAddr = CandiAddr;
								sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.CenterX = sSBoxReg.SBoxInfo[CandiAddr].REG.CenterX;
								sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.CenterY = sSBoxReg.SBoxInfo[CandiAddr].REG.CenterY;
								sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.Width = sSBoxReg.SBoxInfo[CandiAddr].REG.Width;
								sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.Height = sSBoxReg.SBoxInfo[CandiAddr].REG.Height;
								sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.ResultOn = PreSearchingResult[4].REG.ResultOn;

								CandiAddrSave = CandiAddr;
							}
							else
								CandiOn = 0;
						}
					//}
				} // for(n=0; n<9; n++)

				if(CandiOn)
				{
					iTmp = sSLaneReg[m][TDir].SLanePnt[0].REG.BoxAddr % SEARCH_BOX_NUM_H;
					diffX = abs(iTmp - (int)(CandiAddrSave % SEARCH_BOX_NUM_H));
					// it is not the lane if horizontal length is over "SEARCH_BOX_NUM_H/3"
					if(diffX < 6*2)
					{
						TAddr = sSLaneReg[m][TDir].SLanePnt[DetCnt].REG.BoxAddr;
						DetCnt++;

						if(SEARCH_BOX_CNT_MAX <= DetCnt)
							TAddr = 0;	// 

						#ifdef _RUN_MFC
							Draw_Box(dest,LD_IMG_WIDTH, 
								sSBoxReg.SBoxInfo[TAddr].REG.StrX, 
								sSBoxReg.SBoxInfo[TAddr].REG.StrY, 
								sSBoxReg.SBoxInfo[TAddr].REG.EndX, 
								sSBoxReg.SBoxInfo[TAddr].REG.EndY, 1);	// Cyan				
						#endif
					}
					else
					{
						TAddr = 0;
					}
				}
				else
				{
					BreakCnt++;
					//if((DetCnt > 2) && (BreakCnt > 5))	TAddr = 0;
					//else
					//{
					//	TAddr = TAddr - SEARCH_BOX_NUM_H;
					//}
					if(diffX < 4*2)	TAddr = TAddr - SEARCH_BOX_NUM_H;
					else
					{
						if(TDir == 0)		TAddr = TAddr + 1 - SEARCH_BOX_NUM_H;
						else if(TDir == 1)	TAddr = TAddr - 1 - SEARCH_BOX_NUM_H;
					}
				}
			}

			if( (DetCnt >= (((sSBoxReg.DBoxInfoV[m].REG.VerticalMax - (EndBoxNum / SEARCH_BOX_NUM_H)) > 7)? 4 : 3)) &&
				(OldAndNewMatch >= 3) )
			{
				if(sSLaneReg[m][TDir].SLanePnt[0].REG.ScoreTime == 0)
				{
					sSLaneReg[m][TDir].SLanePnt[0].REG.CenterX = sSLaneReg[m][TDir].SLanePnt[1].REG.CenterX;
				}

				// lane angle calculation 
				iLengthX = abs(sSLaneReg[m][TDir].SLanePnt[1].REG.CenterX - sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterX);
				iLengthY = abs(sSLaneReg[m][TDir].SLanePnt[1].REG.CenterY - sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterY);

				// angle is under 45 degree (x / y) --> angle is over 45 degree if (y > x)
				if(iLengthX == 0)				iAngle = 90;
				else if(iLengthX == iLengthY) 	iAngle = 45;
				else if(iLengthX < iLengthY)
				{
					iTmp = iLengthX*100 / iLengthY;
					if(iTmp >= 100)	iTmp = 100;
					iAngle = 90 - TAN_TABLE[iTmp];
				}
				else if(iLengthX > iLengthY)
				{
					iTmp = iLengthY*100 / iLengthX;
					if(iTmp >= 100)	iTmp = 100;
					iAngle = TAN_TABLE[iTmp];
				}

				if(sSLaneReg[m][TDir].SLanePnt[0].REG.CenterX > sSLaneReg[m][TDir].SLanePnt[DetCnt-1].REG.CenterX)	
					iAngle = 180 - iAngle;

				//----------------------------------------------------------------------------------------------------------
				if((iAngle > 30) && (iAngle < (180 - 30)))	// tan(30) = 0.577
				{
					sSLaneReg[m][TDir].SLaneInfo.REG.DetCnt = DetCnt;
					sSLaneReg[m][TDir].SLaneInfo.REG.CurLaneAngle = iAngle;

					if(Researching_Lane(&sSLaneReg[m][TDir], TDir) >= 2)
					{
						sSLaneReg[m][TDir].SLaneInfo.REG.DetCnt = 0;
						sSLaneReg[m][TDir].SLaneInfo.REG.CurLaneAngle = 90;
					}
					else
					{
#if 1 // drawing searching result
						for(k=1; k<DetCnt; k++)
						{
							tvPnt.x = sSLaneReg[m][TDir].SLanePnt[k].REG.CenterX;
							tvPnt.y = sSLaneReg[m][TDir].SLanePnt[k].REG.CenterY;
							orgPnt = LD_Image_Draw_OrgXY_From_TopView(tvPnt);

							//if(tvPnt.x < 320)

							{
								Draw_Lane(orgPnt.x-1, orgPnt.y-1, orgPnt.x-1, orgPnt.y-1, 3);
								Draw_Lane(orgPnt.x-0, orgPnt.y-0, orgPnt.x-0, orgPnt.y-0, 3);
								Draw_Lane(orgPnt.x+1, orgPnt.y+1, orgPnt.x+1, orgPnt.y+1, 3);
							}

						}
#endif

						//if(tvPnt.x < 320)
						//{
						//	sprintf( DisString, "%03d", (unsigned char)m);
						//	Draw_Text(DisString, 10, 10+(DmCnt++)*20);
						//}

						#ifdef _RUN_MFC
							for(k=0; k<DetCnt; k++)
							{
								Draw_Box(dest1,LD_IMG_WIDTH, 
									sSLaneReg[m][TDir].SLanePnt[k].REG.CenterX - sSLaneReg[m][TDir].SLanePnt[k].REG.Width/2, 
									sSLaneReg[m][TDir].SLanePnt[k].REG.CenterY - sSLaneReg[m][TDir].SLanePnt[k].REG.Height/2, 
									sSLaneReg[m][TDir].SLanePnt[k].REG.CenterX + sSLaneReg[m][TDir].SLanePnt[k].REG.Width/2, 
									sSLaneReg[m][TDir].SLanePnt[k].REG.CenterY + sSLaneReg[m][TDir].SLanePnt[k].REG.Height/2, 3+m%4);
							}
						#endif
					}
				}
				else
				{
					sSLaneReg[m][TDir].SLaneInfo.REG.DetCnt = 0;
					sSLaneReg[m][TDir].SLaneInfo.REG.CurLaneAngle = 90;
				}
			}
			else
			{
				sSLaneReg[m][TDir].SLaneInfo.REG.DetCnt = 0;
				sSLaneReg[m][TDir].SLaneInfo.REG.CurLaneAngle = 90;
			}

		} // for(i=0; i<2; i++)
	}

	#ifdef _RUN_MFC
		iTmp = DAX_0_MIN * SEARCH_BOX_WIDTH;
		Draw_Box(dest,LD_IMG_WIDTH, iTmp, vp_y+30, iTmp, LD_IMG_HEIGHT-21, 0);

		iTmp = Det0Max * SEARCH_BOX_WIDTH;
		Draw_Box(dest,LD_IMG_WIDTH, iTmp, vp_y+30, iTmp, LD_IMG_HEIGHT-21, 0);

		iTmp = Det1Max * SEARCH_BOX_WIDTH;
		Draw_Box(dest,LD_IMG_WIDTH, iTmp, vp_y+30, iTmp, LD_IMG_HEIGHT-21, 0);

		iTmp = Det2Min * SEARCH_BOX_WIDTH;
		Draw_Box(dest,LD_IMG_WIDTH, iTmp, vp_y, iTmp, LD_IMG_HEIGHT-21, 0);

		iTmp = Det2Max * SEARCH_BOX_WIDTH;
		Draw_Box(dest,LD_IMG_WIDTH, iTmp, vp_y, iTmp, LD_IMG_HEIGHT-21, 0);

		iTmp = (DAX_3_MAX+1) * SEARCH_BOX_WIDTH;
		Draw_Box(dest,LD_IMG_WIDTH, iTmp, vp_y, iTmp, LD_IMG_HEIGHT-21, 0);

	#endif
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------
#define DIR_GAP	60
void Detection_Lane(int *curStrBx, int *curI, int mMin, int mMax)
{
	int k, i, k1, DetCnt, iTmp;
	int CompareCnt[4];

	//----------------------------------------------------------------------------------------
	for(i=0; i<4; i++)
		CompareCnt[i] = 0;

	for(k=mMin; k<=mMax; k++)
	{
		for(i=0; i<2; i++)
		{
			DetCnt = sSLaneReg[k][i].SLaneInfo.REG.DetCnt;
			iTmp = sSLaneReg[k][i].SLanePnt[0].REG.BoxAddr % SEARCH_BOX_NUM_H;
			if((DetCnt >= 4) && (iTmp == k))
			{
				for(k1=0; k1<4; k1++)
				{
					if(DetCnt > CompareCnt[k1])
					{
						CompareCnt[k1] = DetCnt;
						curStrBx[k1]   = k;
						curI[k1]       = i;
						break;
					}
				}
			}
		}
	}
}

//-------------------------------------------------------------------------------------------------------------------------------------------------------
#define _TRACKING_STEP_0	0
#define _TRACKING_STEP_1	1
#define _TRACKING_STEP_2	2
#define _TRACKING_STEP_3	3
#define _TRACKING_STEP_4	4
#define _TRACKING_STEP_5	5
#define _TRACKING_STEP_6	6
#define _TRACKING_STEP_7	7
#define _TRACKING_STEP_8	8

#ifdef _RUN_MFC
void LD_Searching_Tracking_Lane(unsigned char* dest, unsigned char* dest1)
#else
void LD_Searching_Tracking_Lane(void)
#endif
{
	int TrackingStep = _TRACKING_STEP_0;
	int iLengthX, iLengthY, iAngle;
	int DetCnt, iTmp, iTmp1, ChangeMode=0;
	int curStrBx[4][4] = {{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
	int curI[4][4] = {{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
	int i, m, k, mMinT, mMaxT, iCnt;
	int mMin[4] = {0,0,0,0};
	int mMax[4] = {0,0,0,0};
	int ReSearchCnt[4] = {0,0,0,0};

	static int LaneChangeCnt[4] = {0,0,0,0};

	static int cntDelay[4] = {0,0,0,0};
	static int oldCenterY[4] = {0,0,0,0};
	static int initOn = 1;
	static int mAddT[4] = {0,0,0,0};
	static int WaitCnt=0;

	SEARCHING_LANE_REGISTER	*sClReg;

	static int disDelay = 10;

#ifdef _RUN_MFC
	unsigned char *dest_y = dest1;
	unsigned char *dest_u = dest1+LD_IMG_WIDTH*LD_IMG_HEIGHT*1;
	unsigned char *dest_v = dest1+LD_IMG_WIDTH*LD_IMG_HEIGHT*4/5;
#endif

	POINT_XY tvPnt;
	POINT_XY orgPnt;

	int y1, x1, y2, x2, y3;
	int vp_y = LdReg.REG.VpY;

	char	DisString[100] = {0, };
	
#ifdef _RUN_MFC
/*
	for(m=0; m<LD_IMG_WIDTH*LD_IMG_HEIGHT; m++)		dest[m] = 0;
	for(m=0; m<LD_IMG_WIDTH*LD_IMG_HEIGHT/2; m++)	dest[LD_IMG_WIDTH*LD_IMG_HEIGHT+m] = 0x80;
*/
	for(m=0; m<LD_IMG_WIDTH*LD_IMG_HEIGHT; m++)		dest1[m] = 0;
	for(m=0; m<LD_IMG_WIDTH*LD_IMG_HEIGHT/2; m++)	dest1[LD_IMG_WIDTH*LD_IMG_HEIGHT+m] = 0x80;
#endif

	if(initOn > 0)
	{
		initOn = 0;

		sTrLaneReg[0].TLaneInfo.REG.orgNum = 0;
		sTrLaneReg[1].TLaneInfo.REG.orgNum = 1;
		sTrLaneReg[2].TLaneInfo.REG.orgNum = 2;
		sTrLaneReg[3].TLaneInfo.REG.orgNum = 3;

		sTrSelReg[0] = &sTrLaneReg[0];
		sTrSelReg[1] = &sTrLaneReg[1];
		sTrSelReg[2] = &sTrLaneReg[2];
		sTrSelReg[3] = &sTrLaneReg[3];
		sTrSelReg[4] = &sTrLaneReg[3];

		for(i=0; i<4; i++)
		{
			sTrSelReg[i]->TLaneInfo.REG.detOn = 0;
			sTrSelReg[i]->TLaneInfo.REG.displayOn = 0;
			sTrSelReg[i]->TLaneInfo.REG.WaitDrawingCnt = 0;

			sTrSelReg[i]->TLaneInfo.REG.OldLaneAngle = 0;
			sTrSelReg[i]->TLaneInfo.REG.CurLaneAngle = 0;
			sTrSelReg[i]->TLaneInfo.REG.NewLaneAngle = 0;

			sTrSelReg[i]->TLaneInfo.REG.KindsOfLane = 0;
			sTrSelReg[i]->TLaneInfo.REG.CurLanePos = 0;
			sTrSelReg[i]->TLaneInfo.REG.NewLanePos = 0;

			sTrSelReg[i]->TLaneInfo.REG.NewLaneCnt = 0;
			sTrSelReg[i]->TLaneInfo.REG.NoLaneCnt = 0;

			sOldTvLaneReg[i].laneCnt = 0;

			sOrgLaneReg[i].laneCnt = 0;
			sOldOrgLaneReg[i].laneCnt = 0;
			LaneChangeCnt[i] = 0;
		}

		sTrSelReg[0]->TLaneInfo.REG.saveStrBx = DAX_0_STR;
		sTrSelReg[1]->TLaneInfo.REG.saveStrBx = DAX_1_STR;
		sTrSelReg[2]->TLaneInfo.REG.saveStrBx = DAX_2_STR;
		sTrSelReg[3]->TLaneInfo.REG.saveStrBx = DAX_3_STR;

		for(i=0; i<360; i++)
		{
			sTrSelReg[0]->TrackingPointX[i] = 0;
			sTrSelReg[1]->TrackingPointX[i] = 0;
			sTrSelReg[2]->TrackingPointX[i] = 0;
			sTrSelReg[3]->TrackingPointX[i] = 0;
		}
	}

	// step 1 set searching area  ------------------------------------------------------------------------------------
	if( (sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt > 5) && 
		(LaneChangeCnt[1] == 0) &&
		(sTrSelReg[1]->TLaneInfo.REG.saveStrBx >= DAX_1_MAX) )
	{
		LaneChangeCnt[1] = 30;

		sTrSelReg[4] = sTrSelReg[3];	// dummy

		sTrSelReg[3] = sTrSelReg[2];
		sTrSelReg[2] = sTrSelReg[1];
		sTrSelReg[1] = sTrSelReg[0];	// new 
		sTrSelReg[0] = sTrSelReg[4];	// new 

		for(iTmp=0; iTmp<15; iTmp++)
			sTrSelReg[0]->TLaneInfo.Data32[iTmp] = 0;

		sTrSelReg[0]->TLaneInfo.REG.saveStrBx = DAX_0_STR;
		sTrSelReg[0]->TLaneInfo.REG.OldLaneAngle = 90;

		for(i=0; i<360; i++)
		{
			sTrSelReg[1]->TrackingPointX[i] = 0;
			sTrSelReg[2]->TrackingPointX[i] = 0;
			sTrSelReg[3]->TrackingPointX[i] = 0;
		}
		sOldTvLaneReg[1].laneCnt = 0;
		sOldTvLaneReg[2].laneCnt = 0;
		sOldTvLaneReg[3].laneCnt = 0;
		oldCenterY[1] = 0;
		oldCenterY[2] = 0;
		oldCenterY[3] = 0;

		sTrSelReg[0]->TLaneInfo.REG.detOn = 0;

		ChangeMode = 1;
	}
	else if( (sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt > 10) &&
			 (LaneChangeCnt[0] == 0) &&
			 (sTrSelReg[1]->TLaneInfo.REG.saveStrBx <= DAX_1_MIN) )
	{
		LaneChangeCnt[0] = 30;

		sTrSelReg[4] = sTrSelReg[0];	// dummy

		sTrSelReg[0] = sTrSelReg[1];
		sTrSelReg[1] = sTrSelReg[4];	// new 

		for(iTmp=0; iTmp<15; iTmp++)
			sTrSelReg[1]->TLaneInfo.Data32[iTmp] = 0;

		sTrSelReg[1]->TLaneInfo.REG.saveStrBx = DAX_1_STR;
		sTrSelReg[1]->TLaneInfo.REG.OldLaneAngle = 90;

		for(i=0; i<360; i++)
		{
			sTrSelReg[0]->TrackingPointX[i] = 0;
			sTrSelReg[1]->TrackingPointX[i] = 0;
		}
		sOldTvLaneReg[0].laneCnt = 0;
		oldCenterY[0] = 0;
		sOldTvLaneReg[1].laneCnt = 0;
		oldCenterY[1] = 0;
		sTrSelReg[1]->TLaneInfo.REG.detOn = 0;

		ChangeMode = 2;
	}
	else if( (sTrSelReg[0]->TLaneInfo.REG.WaitDrawingCnt > 5) && 
			 (sTrSelReg[1]->TLaneInfo.REG.KindsOfLane < 10)	  && 
			 (sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt < 10) &&
			 (LaneChangeCnt[0] == 0) &&
			 (sTrSelReg[0]->TLaneInfo.REG.saveStrBx >= Det0Max) )
	{
		LaneChangeCnt[0] = 30;

		sTrSelReg[4] = sTrSelReg[1];	// dummy

		sTrSelReg[1] = sTrSelReg[0];
		sTrSelReg[0] = sTrSelReg[4];	// new 

		for(iTmp=0; iTmp<15; iTmp++)
			sTrSelReg[0]->TLaneInfo.Data32[iTmp] = 0;

		sTrSelReg[0]->TLaneInfo.REG.saveStrBx = DAX_0_STR;
		sTrSelReg[0]->TLaneInfo.REG.OldLaneAngle = 90;

		for(i=0; i<360; i++)
		{
			sTrSelReg[0]->TrackingPointX[i] = 0;
			sTrSelReg[1]->TrackingPointX[i] = 0;
		}
		sOldTvLaneReg[0].laneCnt = 0;
		oldCenterY[0] = 0;
		sOldTvLaneReg[1].laneCnt = 0;
		oldCenterY[1] = 0;

		sTrSelReg[0]->TLaneInfo.REG.detOn = 0;
		sTrSelReg[1]->TLaneInfo.REG.detOn = 1;

		ChangeMode = 3;
	}
	else if( (sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt > 5) &&
			 (LaneChangeCnt[1] == 0) &&
			 (sTrSelReg[2]->TLaneInfo.REG.saveStrBx <= DAX_2_MIN) )
	{
		LaneChangeCnt[1] = 30;

		sTrSelReg[4] = sTrSelReg[0];	// dummy

		sTrSelReg[0] = sTrSelReg[1];
		sTrSelReg[1] = sTrSelReg[2];
		sTrSelReg[2] = sTrSelReg[3];
		sTrSelReg[3] = sTrSelReg[4];

		for(iTmp=0; iTmp<15; iTmp++)
			sTrSelReg[3]->TLaneInfo.Data32[iTmp] = 0;

		sTrSelReg[3]->TLaneInfo.REG.saveStrBx = DAX_3_STR;
		sTrSelReg[3]->TLaneInfo.REG.OldLaneAngle = 90;
		
		for(i=0; i<360; i++)
		{
			sTrSelReg[0]->TrackingPointX[i] = 0;
			sTrSelReg[1]->TrackingPointX[i] = 0;
			sTrSelReg[2]->TrackingPointX[i] = 0;
		}
		sOldTvLaneReg[0].laneCnt = 0;
		sOldTvLaneReg[1].laneCnt = 0;
		sOldTvLaneReg[2].laneCnt = 0;
		oldCenterY[0] = 0;
		oldCenterY[1] = 0;
		oldCenterY[2] = 0;

		sTrSelReg[3]->TLaneInfo.REG.detOn = 0;

		ChangeMode = 4;
	}
	else if( (sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt > 10) &&
			 (LaneChangeCnt[3] == 0) && 
			 (sTrSelReg[2]->TLaneInfo.REG.saveStrBx >= DAX_2_MAX) )
	{
		LaneChangeCnt[3] = 30;

		sTrSelReg[4] = sTrSelReg[3];	// dummy

		sTrSelReg[3] = sTrSelReg[2];
		sTrSelReg[2] = sTrSelReg[4];

		for(iTmp=0; iTmp<15; iTmp++)
			sTrSelReg[2]->TLaneInfo.Data32[iTmp] = 0;

		sTrSelReg[2]->TLaneInfo.REG.saveStrBx = DAX_2_STR;
		sTrSelReg[2]->TLaneInfo.REG.OldLaneAngle = 90;

		for(i=0; i<360; i++)
		{
			sTrSelReg[2]->TrackingPointX[i] = 0;
			sTrSelReg[3]->TrackingPointX[i] = 0;
		}
		sOldTvLaneReg[2].laneCnt = 0;
		oldCenterY[2] = 0;
		sOldTvLaneReg[3].laneCnt = 0;
		oldCenterY[3] = 0;

		sTrSelReg[2]->TLaneInfo.REG.detOn = 0;

		ChangeMode = 5;
	}
	else if( (sTrSelReg[3]->TLaneInfo.REG.WaitDrawingCnt > 5) &&
			 (sTrSelReg[2]->TLaneInfo.REG.KindsOfLane < 10)    &&  
			 (sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt < 10) &&
			 (LaneChangeCnt[3] == 0) && 
			 (sTrSelReg[3]->TLaneInfo.REG.saveStrBx <= Det3Min) )
	{
		LaneChangeCnt[3] = 30;

		sTrSelReg[4] = sTrSelReg[2];	// dummy

		sTrSelReg[2] = sTrSelReg[3];
		sTrSelReg[3] = sTrSelReg[4];

		for(iTmp=0; iTmp<15; iTmp++)
			sTrSelReg[3]->TLaneInfo.Data32[iTmp] = 0;

		sTrSelReg[3]->TLaneInfo.REG.saveStrBx = DAX_3_STR;
		sTrSelReg[3]->TLaneInfo.REG.OldLaneAngle = 90;

		for(i=0; i<360; i++)
		{
			sTrSelReg[2]->TrackingPointX[i] = 0;
			sTrSelReg[3]->TrackingPointX[i] = 0;
		}
		sOldTvLaneReg[2].laneCnt = 0;
		oldCenterY[2] = 0;

		sOldTvLaneReg[3].laneCnt = 0;
		oldCenterY[3] = 0;

		sTrSelReg[3]->TLaneInfo.REG.detOn = 0;

		ChangeMode = 6;
	}
	
	//-------------------------------------------------------------------------------------------------
	for(m=0; m<4; m++)
	{
		if(LaneChangeCnt[m] > 0)	LaneChangeCnt[m]--;

		if(sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt <= 3)
		{
			mMin[m] = (int)sTrSelReg[m]->TLaneInfo.REG.saveStrBx - 1;
			mMax[m] = (int)sTrSelReg[m]->TLaneInfo.REG.saveStrBx + 1;
		}
		else
		{
			/*
			if(svp_x < 0)
			{
				mMin[m] = (int)sTrSelReg[m]->TLaneInfo.REG.saveStrBx - sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt/2;
				mMax[m] = (int)sTrSelReg[m]->TLaneInfo.REG.saveStrBx + sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt;
			}
			else if(svp_x > 0)
			{
				mMin[m] = (int)sTrSelReg[m]->TLaneInfo.REG.saveStrBx - sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt;
				mMax[m] = (int)sTrSelReg[m]->TLaneInfo.REG.saveStrBx + sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt/2;
			}
			else
			{
				mMin[m] = (int)sTrSelReg[m]->TLaneInfo.REG.saveStrBx - sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt;
				mMax[m] = (int)sTrSelReg[m]->TLaneInfo.REG.saveStrBx + sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt;
			}
			*/
			mMin[m] = (int)sTrSelReg[m]->TLaneInfo.REG.saveStrBx - (sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt-2);
			mMax[m] = (int)sTrSelReg[m]->TLaneInfo.REG.saveStrBx + (sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt-2);

		}
	}

	//-------------------------------------------------------------
	if((sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt > 0) && (sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt == 0))
	{
		Det1Max = sTrSelReg[1]->TLaneInfo.REG.saveStrBx + 8;	
		Det2Min = Det1Max;
		//Det2Max = Det2Min+8;
	}
	else if((sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt == 0) && (sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt > 0))
	{
		Det2Min = sTrSelReg[2]->TLaneInfo.REG.saveStrBx - 8;	
		Det1Max = Det2Min;
		//Det1Min = Det1Max-8;
	}
	else if((sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt > 0) && (sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt > 0))
	{
		Det1Max = (sTrSelReg[1]->TLaneInfo.REG.saveStrBx + sTrSelReg[2]->TLaneInfo.REG.saveStrBx)/2 + 1;	
		Det2Min = (sTrSelReg[1]->TLaneInfo.REG.saveStrBx + sTrSelReg[2]->TLaneInfo.REG.saveStrBx)/2 - 1;	
		//Det1Min = Det1Max-8;
		//Det2Max = Det2Min+8;
	}
	else
	{
		Det1Max = (int)DAX_1_MAX;
		Det2Min = (int)DAX_2_MIN;
		//Det1Min = DAX_1_MIN;
		//Det2Max = DAX_2_MAX;
	}

	if(sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt > 0)	
	{
		Det1Min = sTrSelReg[1]->TLaneInfo.REG.saveStrBx - 4;	
		Det0Max = Det1Min + 1;
	}
	else                                        
	{ 
		if(Det0Max > (int)DAX_0_MAX) Det0Max--;
		else if(Det0Max < (int)DAX_0_MAX) Det0Max++;
		Det1Min = Det0Max-1;
	}
	
	if(sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt > 0)	
	{
		Det2Max = sTrSelReg[2]->TLaneInfo.REG.saveStrBx + 4;	
		Det3Min = Det2Max - 1;
	}
	else
	{
		if(Det3Min > (int)DAX_3_MIN) Det3Min--;
		else if(Det3Min < (int)DAX_3_MIN) Det3Min++;
		Det2Max = Det3Min-1;
	}

	//-------------------------------------------------------------
	if(mMin[0] < (int)DAX_0_MIN)	mMin[0] = (int)DAX_0_MIN;
	if(mMax[0] > Det0Max)	mMax[0] = Det0Max;

	if(mMin[1] < Det1Min)	mMin[1] = Det1Min;
	if(mMax[1] > Det1Max)	mMax[1] = Det1Max;

	if(mMin[2] < Det2Min)	mMin[2] = Det2Min;
	if(mMax[2] > Det2Max)	mMax[2] = Det2Max;

	if(mMin[3] < Det3Min)	mMin[3] = Det3Min;
	if(mMax[3] > (int)DAX_3_MAX)	mMax[3] = (int)DAX_3_MAX;

	for(m=0; m<4; m++)
	{
		if(sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt > 3)
		{
			if( (sTrSelReg[m]->TLaneInfo.REG.saveStrBx < mMin[m]) || (mMax[m] < sTrSelReg[m]->TLaneInfo.REG.saveStrBx) )
				sTrSelReg[m]->TLaneInfo.REG.saveStrBx = (mMin[m] + mMax[m]) / 2;
		}
	}

	//-----------------------------------------
	/*
	if(sTrSelReg[2]->TLaneInfo.REG.detOn > 0)
	{
		mMax[1] = ((sTrSelReg[2]->TLaneInfo.REG.saveStrBx - 3*2) < mMax[1])? (sTrSelReg[2]->TLaneInfo.REG.saveStrBx - 3*2) : mMax[1];
		if(mMin[1] >= mMax[1])
		{
			mMin[1] = mMax[1] - 2;
			sTrSelReg[1]->TLaneInfo.REG.saveStrBx = mMin[1] + 1;
		}
	}

	if(sTrSelReg[1]->TLaneInfo.REG.detOn > 0)
	{
		mMin[2] = ((sTrSelReg[1]->TLaneInfo.REG.saveStrBx + 3*2) > mMin[2])? (sTrSelReg[1]->TLaneInfo.REG.saveStrBx + 3*2) : mMin[2];
		if(mMin[2] >= mMax[2])
		{
			mMax[2] = mMin[1] + 2;
			sTrSelReg[2]->TLaneInfo.REG.saveStrBx = mMin[2] + 1;
		}
	}
	*/

	//------------------------------------------------------------------------------------------------------------------
	if((sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt > 5) && (sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt > 5))
	{
		iTmp = (sTrSelReg[1]->TLaneInfo.REG.OldLaneAngle + sTrSelReg[2]->TLaneInfo.REG.OldLaneAngle) / 2;
	}
	else if((sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt > 5) && !(sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt > 5))
	{
		if((sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt > 5) && (sTrSelReg[0]->TLaneInfo.REG.WaitDrawingCnt > 5))
			iTmp = (sTrSelReg[1]->TLaneInfo.REG.OldLaneAngle + sTrSelReg[0]->TLaneInfo.REG.OldLaneAngle) / 2;
		else
			iTmp = sTrSelReg[1]->TLaneInfo.REG.OldLaneAngle;
	}
	else if(!(sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt > 5) && (sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt > 5))
	{
		if((sTrSelReg[3]->TLaneInfo.REG.WaitDrawingCnt > 5) && (sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt > 5))
			iTmp = (sTrSelReg[3]->TLaneInfo.REG.OldLaneAngle + sTrSelReg[2]->TLaneInfo.REG.OldLaneAngle) / 2;
		else
			iTmp = sTrSelReg[2]->TLaneInfo.REG.OldLaneAngle;
	}
	else
	{
		if((sTrSelReg[0]->TLaneInfo.REG.WaitDrawingCnt > 5) && (sTrSelReg[3]->TLaneInfo.REG.WaitDrawingCnt > 5))
			iTmp = (sTrSelReg[0]->TLaneInfo.REG.OldLaneAngle + sTrSelReg[3]->TLaneInfo.REG.OldLaneAngle) / 2;
		else
			iTmp = 90;
	}

	if(iTmp > 95)
	{
		if(svp_x > -40)
		{
			if(svp_x > -20)			svp_x -= 1;
			else if(svp_x > -30)	svp_x -= 2;
			else			        svp_x -= 2;
		}
	}
	else if(iTmp < 85)
	{
		if(svp_x < 40)
		{
			if(svp_x < 20)		svp_x += 1;
			else if(svp_x < 30)	svp_x += 2;
			else			    svp_x += 2;
		}
	}
	else
	{
		if(svp_x > 0)
		{
			if(svp_x > 30)		svp_x -= 2;
			else if(svp_x > 20)	svp_x -= 1;
			else			    svp_x -= 1;
		}
		else if(svp_x < 0)
		{
			if(svp_x < -30)		 svp_x += 2;
			else if(svp_x < -20) svp_x += 1;
			else			     svp_x += 1;
		}
	}

	//--------------------------------
	for(iCnt=0; iCnt<4; iCnt++)
	{
		if(iCnt == 0)	m = 1;
		if(iCnt == 1)	m = 2;
		if(iCnt == 2)	m = 0;
		if(iCnt == 3)	m = 3;

		// step 2 searching & decision Lane ------------------------------------------------------------------------------------
		TrackingStep = _TRACKING_STEP_0;
		for(i=0; i<4; i++)
		{
			curStrBx[m][i] = 100;
			curI[m][i] = 0;
		}
		Detection_Lane(curStrBx[m], curI[m], mMin[m], mMax[m]);

		#ifdef _RUN_MFC
			sprintf( DisString, "%03d %03d", curStrBx[m][0], curStrBx[m][1]);
			Draw_Text(dest, DisString, 10+15*12, 10+m*20);
		#endif

		if( (curStrBx[m][0] == 100) ||
			((m==1) && (sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt > 8) && (sTrSelReg[2]->TLaneInfo.REG.NoLaneCnt == 0) && (abs(sTrSelReg[2]->TLaneInfo.REG.saveStrBx - curStrBx[m][0]) < 8)) ||
			((m==2) && (sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt > 8) && (sTrSelReg[1]->TLaneInfo.REG.NoLaneCnt == 0) && (abs(sTrSelReg[1]->TLaneInfo.REG.CurLanePos - curStrBx[m][0]) < 8)) ||
			((m==0) && (sTrSelReg[1]->TLaneInfo.REG.WaitDrawingCnt > 8) && (sTrSelReg[1]->TLaneInfo.REG.NoLaneCnt == 0) && (abs(sTrSelReg[1]->TLaneInfo.REG.CurLanePos - curStrBx[m][0]) < 8)) ||
			((m==3) && (sTrSelReg[2]->TLaneInfo.REG.WaitDrawingCnt > 8) && (sTrSelReg[2]->TLaneInfo.REG.NoLaneCnt == 0) && (abs(sTrSelReg[2]->TLaneInfo.REG.CurLanePos - curStrBx[m][0]) < 8)) )
		{
			if(sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt < 10)	sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt++;
			else                                            sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt = 10;

			if(curStrBx[m][0] != 100)
			{
				sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt = 0;
				sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt = 0;
				curStrBx[m][0] = 100;
			}
			
			TrackingStep = _TRACKING_STEP_7;
		}
		else
		{
			sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt = 0;
			TrackingStep = _TRACKING_STEP_3;
		}
	
		// step 3 compare old & cur angle / Start Position ------------------------------------------------------------------------------------
		if(TrackingStep == _TRACKING_STEP_3)
		{
			iTmp = curStrBx[m][0];
			iTmp1 = curI[m][0];
			sClReg = &sSLaneReg[iTmp][iTmp1];

			sTrSelReg[m]->TLaneInfo.REG.CurLanePos		= curStrBx[m][0];
			sTrSelReg[m]->TLaneInfo.REG.CurBoxI			= curI[m][0];
			sTrSelReg[m]->TLaneInfo.REG.CurLaneAngle	= sClReg->SLaneInfo.REG.CurLaneAngle;

			if(abs(sTrSelReg[m]->TLaneInfo.REG.OldLaneAngle - sTrSelReg[m]->TLaneInfo.REG.CurLaneAngle) < 30)
			{
				sTrSelReg[m]->TLaneInfo.REG.OldLaneAngle = sTrSelReg[m]->TLaneInfo.REG.CurLaneAngle;
				if(abs(sTrSelReg[m]->TLaneInfo.REG.saveStrBx - curStrBx[m][0]) <= 2)
				{
					sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt = 0;
					TrackingStep = _TRACKING_STEP_5;
				}
				else
				{
					TrackingStep = _TRACKING_STEP_4;
				}
			}
			else if(abs(sTrSelReg[m]->TLaneInfo.REG.saveStrBx - sTrSelReg[m]->TLaneInfo.REG.CurLanePos) > 2)
			{
				sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt = 0;
				//sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt = 0;
				TrackingStep = _TRACKING_STEP_4;
			}
			else
			{
				TrackingStep = _TRACKING_STEP_4;
			}
		}

		// step 4 searching New Lane ------------------------------------------------------------------------------------
		if(TrackingStep == _TRACKING_STEP_4)
		{
			if(sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt == 0)
			{
				sTrSelReg[m]->TLaneInfo.REG.NewLanePos	 = sTrSelReg[m]->TLaneInfo.REG.CurLanePos;
				sTrSelReg[m]->TLaneInfo.REG.NewLaneAngle = sTrSelReg[m]->TLaneInfo.REG.CurLaneAngle;
				sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt++;
			}
			else
			{
				if(abs(sTrSelReg[m]->TLaneInfo.REG.NewLanePos - sTrSelReg[m]->TLaneInfo.REG.CurLanePos) <= 2)
				{
					if(abs(sTrSelReg[m]->TLaneInfo.REG.NewLaneAngle - sTrSelReg[m]->TLaneInfo.REG.CurLaneAngle) < 30)
					{
						sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt++;
					}
					else
					{
						sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt = 0;
					}
				}
				else
				{
					sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt = 0;
				}
				sTrSelReg[m]->TLaneInfo.REG.NewLanePos = sTrSelReg[m]->TLaneInfo.REG.CurLanePos;
				sTrSelReg[m]->TLaneInfo.REG.NewLaneAngle = sTrSelReg[m]->TLaneInfo.REG.CurLaneAngle;
			}
			sTrSelReg[m]->TLaneInfo.REG.saveStrBx = sTrSelReg[m]->TLaneInfo.REG.CurLanePos;

			TrackingStep = _TRACKING_STEP_6;
		}

		// step 5 Update Lane when Lane detection success ------------------------------------------------------------------------------------
		if(TrackingStep == _TRACKING_STEP_5)
		{
			iTmp  = sTrSelReg[m]->TLaneInfo.REG.CurLanePos;
			iTmp1 = sTrSelReg[m]->TLaneInfo.REG.CurBoxI;
			sClReg = &sSLaneReg[iTmp][iTmp1];

			sTrSelReg[m]->TLaneInfo.REG.DetCnt = sClReg->SLaneInfo.REG.DetCnt;
			DetCnt = sTrSelReg[m]->TLaneInfo.REG.DetCnt;
			for(k=0; k<DetCnt; k++)
			{
				sTrSelReg[m]->SLanePnt[k].REG.ScoreTime = sClReg->SLanePnt[k].REG.ScoreTime;
				sTrSelReg[m]->SLanePnt[k].REG.BoxAddr   = sClReg->SLanePnt[k].REG.BoxAddr;
				sTrSelReg[m]->SLanePnt[k].REG.CenterX	= sClReg->SLanePnt[k].REG.CenterX;
				sTrSelReg[m]->SLanePnt[k].REG.CenterY	= sClReg->SLanePnt[k].REG.CenterY;
				sTrSelReg[m]->SLanePnt[k].REG.Width		= sClReg->SLanePnt[k].REG.Width;
				sTrSelReg[m]->SLanePnt[k].REG.Height	= sClReg->SLanePnt[k].REG.Height;
			}
			//sTrSelReg[m]->TLaneInfo.REG.saveStrBx = sTrSelReg[m]->TLaneInfo.REG.CurLanePos;

			iTmp = sTrSelReg[m]->SLanePnt[0].REG.BoxAddr / SEARCH_BOX_NUM_H;
			iTmp1 = sTrSelReg[m]->SLanePnt[1].REG.BoxAddr / SEARCH_BOX_NUM_H;
			if((iTmp - iTmp1) < 8)
			{
				if(sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt < 20)	sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt++;
				else												sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt = 20;
			}

			//----------------------------------------------------------------------------------------
			if( (((m==1) || (m==2)) && (DetCnt > 10)) || 
				(((m==0) || (m==3)) && (DetCnt >  3))    ) 
			{
				if(sTrSelReg[m]->TLaneInfo.REG.KindsOfLane < 20)	sTrSelReg[m]->TLaneInfo.REG.KindsOfLane++;
				else												sTrSelReg[m]->TLaneInfo.REG.KindsOfLane = 20;
			}
			else
			{
				if(sTrSelReg[m]->TLaneInfo.REG.KindsOfLane > 0)		sTrSelReg[m]->TLaneInfo.REG.KindsOfLane--;
				else												sTrSelReg[m]->TLaneInfo.REG.KindsOfLane = 0;
			}

			if( (((m==1) || (m==2)) && (sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt >= 10)) ||
				(((m==0) || (m==3)) && (sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt >= 12))   )
			{
				sTrSelReg[m]->TLaneInfo.REG.detOn = 1;
				sTrSelReg[m]->TLaneInfo.REG.displayOn = 1;
			}
			else
			{
				sTrSelReg[m]->TLaneInfo.REG.detOn = 0;
				sTrSelReg[m]->TLaneInfo.REG.displayOn = 0;
			}
			sTrSelReg[m]->TLaneInfo.REG.saveStrBx = sTrSelReg[m]->TLaneInfo.REG.CurLanePos;
			TrackingStep = _TRACKING_STEP_8;
		}

		// step 6 Update Lane when New Lane detection  ------------------------------------------------------------------------------------
		if(TrackingStep == _TRACKING_STEP_6)
		{
			if(sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt >= 10)
			{
				sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt = sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt;
				sTrSelReg[m]->TLaneInfo.REG.OldLaneAngle = sTrSelReg[m]->TLaneInfo.REG.NewLaneAngle;
				sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt = 0;
				sTrSelReg[m]->TLaneInfo.REG.detOn = 1;

				iTmp  = sTrSelReg[m]->TLaneInfo.REG.CurLanePos;
				iTmp1 = sTrSelReg[m]->TLaneInfo.REG.CurBoxI;
				sClReg = &sSLaneReg[iTmp][iTmp1];

				sTrSelReg[m]->TLaneInfo.REG.DetCnt = sClReg->SLaneInfo.REG.DetCnt;
				DetCnt = sTrSelReg[m]->TLaneInfo.REG.DetCnt;
				for(k=0; k<DetCnt; k++)
				{
					sTrSelReg[m]->SLanePnt[k].REG.ScoreTime = sClReg->SLanePnt[k].REG.ScoreTime;
					sTrSelReg[m]->SLanePnt[k].REG.BoxAddr   = sClReg->SLanePnt[k].REG.BoxAddr;
					sTrSelReg[m]->SLanePnt[k].REG.CenterX	= sClReg->SLanePnt[k].REG.CenterX;
					sTrSelReg[m]->SLanePnt[k].REG.CenterY	= sClReg->SLanePnt[k].REG.CenterY;
					sTrSelReg[m]->SLanePnt[k].REG.Width		= sClReg->SLanePnt[k].REG.Width;
					sTrSelReg[m]->SLanePnt[k].REG.Height	= sClReg->SLanePnt[k].REG.Height;
				}
				//sTrSelReg[m]->TLaneInfo.REG.saveStrBx = sTrSelReg[m]->TLaneInfo.REG.CurLanePos;
			}
			else
			{
				iTmp  = sTrSelReg[m]->TLaneInfo.REG.CurLanePos;
				iTmp1 = sTrSelReg[m]->TLaneInfo.REG.CurBoxI;
				sClReg = &sSLaneReg[iTmp][iTmp1];

				iTmp = sClReg->SLanePnt[0].REG.BoxAddr / SEARCH_BOX_NUM_H;
				iTmp1 = sClReg->SLanePnt[1].REG.BoxAddr / SEARCH_BOX_NUM_H;
				if((iTmp - iTmp1) > 8)
				{
					if(sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt > 0)	sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt--;
					else											sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt = 0;
				}

				if(sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt > 0)	sTrSelReg[m]->TLaneInfo.REG.detOn = 1;
				else											sTrSelReg[m]->TLaneInfo.REG.detOn = 0;

				if(sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt >= 8)	sTrSelReg[m]->TLaneInfo.REG.displayOn = 1;
				else												sTrSelReg[m]->TLaneInfo.REG.displayOn = 0;
			}

			TrackingStep = _TRACKING_STEP_8;
		}

		// step 7 Update Lane when Lane detection fail ------------------------------------------------------------------------------------
		if(TrackingStep == _TRACKING_STEP_7)
		{
			if(sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt > 0)	sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt--;
			else												sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt = 0;

			sTrSelReg[m]->TLaneInfo.REG.detOn = 0;
			if( (((m==1) || (m==2)) && (sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt >= 8)) ||
				(((m==0) || (m==3)) && (sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt >= 10))   )
			{
				sTrSelReg[m]->TLaneInfo.REG.displayOn = 1;
			}
			else
			{
				sTrSelReg[m]->TLaneInfo.REG.displayOn = 0;
			}

			if(sTrSelReg[m]->TLaneInfo.REG.KindsOfLane > 0)	sTrSelReg[m]->TLaneInfo.REG.KindsOfLane--;
			else                                            sTrSelReg[m]->TLaneInfo.REG.KindsOfLane = 0;

			TrackingStep = _TRACKING_STEP_8;
		}

		//TrackingStep = _TRACKING_STEP_8+1;
		// step 8 Drawing Lane  ------------------------------------------------------------------------------------
		if(TrackingStep == _TRACKING_STEP_8)
		{
			if(sTrSelReg[m]->TLaneInfo.REG.detOn > 0)
			{
				//sTrSelReg[m]->TLaneInfo.REG.detOn = 0;

				DetCnt = sTrSelReg[m]->TLaneInfo.REG.DetCnt;
				//- re-calculate X-point for last Y-point -----------------------------------
				y1 = sTrSelReg[m]->SLanePnt[DetCnt-2].REG.CenterY;
				y2 = sTrSelReg[m]->SLanePnt[DetCnt-3].REG.CenterY;

				x1 = sTrSelReg[m]->SLanePnt[DetCnt-2].REG.CenterX;
				x2 = sTrSelReg[m]->SLanePnt[DetCnt-3].REG.CenterX;

				y3 = sTrSelReg[m]->SLanePnt[DetCnt-1].REG.CenterY;
				tvPnt.y = y3;

				if((y1 < y2) && (y3 < y1))
				{
					iTmp = ((y3-y1) * (x2-x1) * 1000 / (y2-y1));
					iTmp = iTmp * 120 / 100;
					tvPnt.x = iTmp / 1000 + x1;

					if(tvPnt.x < 0)						tvPnt.x = 0;
					else if(tvPnt.x >= LD_IMG_WIDTH)	tvPnt.x = LD_IMG_WIDTH-1;

					sTrSelReg[m]->SLanePnt[DetCnt-1].REG.CenterX = tvPnt.x;
					sTrSelReg[m]->SLanePnt[DetCnt-1].REG.CenterY = tvPnt.y;
				}

				//- calculate X-point for last+1 Y-point -----------------------------------
				y1 = sTrSelReg[m]->SLanePnt[DetCnt-1].REG.CenterY;
				y2 = sTrSelReg[m]->SLanePnt[DetCnt-2].REG.CenterY;

				x1 = sTrSelReg[m]->SLanePnt[DetCnt-1].REG.CenterX;
				x2 = sTrSelReg[m]->SLanePnt[DetCnt-2].REG.CenterX;

				if((oldCenterY[m] != 0) && (oldCenterY[m] < LD_IMG_HEIGHT) && (y1 > oldCenterY[m]))
				{
					y3 = (y1 * 10 + oldCenterY[m] * 90) / 100;

					if((y1 < y2) && (y3 < y1))
					{
						oldCenterY[m] = y3; 
						tvPnt.y = y3;

						iTmp = ((y3-y1) * (x2-x1) * 1000 / (y2-y1));
						iTmp = iTmp * 120 / 100;
						tvPnt.x = iTmp / 1000 + x1;

						if(tvPnt.x < 0)						tvPnt.x = 0;
						else if(tvPnt.x >= LD_IMG_WIDTH)	tvPnt.x = LD_IMG_WIDTH-1;

						sTrSelReg[m]->SLanePnt[DetCnt].REG.CenterX = tvPnt.x;
						sTrSelReg[m]->SLanePnt[DetCnt].REG.CenterY = tvPnt.y;
						sTrSelReg[m]->TLaneInfo.REG.DetCnt++;
					}
					else
						oldCenterY[m] = y1; 
				}
				else
					oldCenterY[m] = y1; 

				//- calculate X-point for last+2 Y-point(y3 = LdReg.REG.VpY+20) -----------------------------------
				DetCnt = sTrSelReg[m]->TLaneInfo.REG.DetCnt;

				y1 = sTrSelReg[m]->SLanePnt[DetCnt-1].REG.CenterY;
				y2 = sTrSelReg[m]->SLanePnt[DetCnt-2].REG.CenterY;

				x1 = sTrSelReg[m]->SLanePnt[DetCnt-1].REG.CenterX;
				x2 = sTrSelReg[m]->SLanePnt[DetCnt-2].REG.CenterX;

				y3 = LdReg.REG.VpY+20;
				tvPnt.y = y3;

				if((y1 < y2) && (y3 < y1))
				{
					iTmp = ((y3-y1) * (x2-x1) * 1000 / (y2-y1));
					iTmp = iTmp * 120 / 100;
					tvPnt.x = iTmp / 1000 + x1;

					if(tvPnt.x < 0)						tvPnt.x = 0;
					else if(tvPnt.x >= LD_IMG_WIDTH)	tvPnt.x = LD_IMG_WIDTH-1;

					sTrSelReg[m]->SLanePnt[DetCnt].REG.CenterX = tvPnt.x;
					sTrSelReg[m]->SLanePnt[DetCnt].REG.CenterY = tvPnt.y;
				}				
				else
				{
					sTrSelReg[m]->SLanePnt[DetCnt].REG.CenterX = x1;
					sTrSelReg[m]->SLanePnt[DetCnt].REG.CenterY = y3;
				}

				// Update Old Lane -----------------------------------------------------
				iTmp = sTrSelReg[m]->SLanePnt[0].REG.CenterY;
				if(sTrSelReg[m]->TrackingPointX[iTmp] > 0)
				{
					iTmp1 = abs(sTrSelReg[m]->TrackingPointX[iTmp] - sTrSelReg[m]->SLanePnt[0].REG.CenterX) / 10;

					if(iTmp1 < 5)		iTmp1 = 30;
					else				iTmp1 = 100;
				}
				else
					iTmp1 = 0;

#if 0 // STEP3
				for(k=0; k<DetCnt; k++)
				{
					iTmp = sTrSelReg[m]->SLanePnt[k].REG.CenterY;
					if(sTrSelReg[m]->TrackingPointX[iTmp] > 0)
					{
						//iTmp1 = 30;
						sTrSelReg[m]->SLanePnt[k].REG.CenterX = ((sTrSelReg[m]->SLanePnt[k].REG.CenterX * iTmp1 + sTrSelReg[m]->TrackingPointX[iTmp] * (100-iTmp1)) + 50) / 100;
					}
				}

				for(k=0; k<=DetCnt; k++)
				{
					sOldTvLaneReg[m].orgLane[k].x = sTrSelReg[m]->SLanePnt[k].REG.CenterX;
					sOldTvLaneReg[m].orgLane[k].y = sTrSelReg[m]->SLanePnt[k].REG.CenterY;
				}
#endif
				sOldTvLaneReg[m].laneCnt = DetCnt;
			}	// if(sTrSelReg[m]->TLaneInfo.REG.detOn > 0)
			else
			{
#if 0 // STEP2
				if(sOldTvLaneReg[m].laneCnt > 0)
				{
					sTrSelReg[m]->TLaneInfo.REG.DetCnt = sOldTvLaneReg[m].laneCnt;
					DetCnt = sTrSelReg[m]->TLaneInfo.REG.DetCnt;
					for(k=0; k<=DetCnt; k++)
					{
						sTrSelReg[m]->SLanePnt[k].REG.CenterX = sOldTvLaneReg[m].orgLane[k].x;
						sTrSelReg[m]->SLanePnt[k].REG.CenterY = sOldTvLaneReg[m].orgLane[k].y;
					}
				}
#endif
			}

			//---------------------------------------------------------------------------------------------
			//if(((m == 1) || (m == 2)) && (sTrSelReg[m]->TLaneInfo.REG.displayOn > 0))
			if( ((m == 0) && (sTrSelReg[1]->TLaneInfo.REG.KindsOfLane < 10) && (sTrSelReg[m]->TLaneInfo.REG.displayOn > 0)) || 
				((m == 3) && (sTrSelReg[2]->TLaneInfo.REG.KindsOfLane < 10) && (sTrSelReg[m]->TLaneInfo.REG.displayOn > 0)) ||
				((m == 1) && (sTrSelReg[m]->TLaneInfo.REG.displayOn > 0)) ||
				((m == 2) && (sTrSelReg[m]->TLaneInfo.REG.displayOn > 0))														)
			{
				//sTrSelReg[m]->TLaneInfo.REG.displayOn = 0;

				//----------------------------------------------------------------------
				#ifdef _RUN_MFC
					for(i=0; i<360; i++)
					{
						if(sTrSelReg[m]->TrackingPointX[i] > 0)
						{
							Draw_Box(dest, LD_IMG_WIDTH, sTrSelReg[m]->TrackingPointX[i], i, sTrSelReg[m]->TrackingPointX[i], i, 3+m%2);
						}
					}

					DetCnt = sTrSelReg[m]->TLaneInfo.REG.DetCnt;
					if(DetCnt > 0)
					{
						for(k=0; k<DetCnt; k++)
						{
							iTmp = sTrSelReg[m]->SLanePnt[k].REG.BoxAddr;
							Draw_Box(dest, LD_IMG_WIDTH, 
								sSBoxReg.SBoxInfo[iTmp].REG.StrX, 
								sSBoxReg.SBoxInfo[iTmp].REG.StrY, 
								sSBoxReg.SBoxInfo[iTmp].REG.EndX, 
								sSBoxReg.SBoxInfo[iTmp].REG.EndY, 3+m);
						}
					}
				#endif

				//----------------------------------------------------------------------
				for(i=0; i<360; i++)
					sTrSelReg[m]->TrackingPointX[i] = 0;

#if 0 // STEP1
				DetCnt = sTrSelReg[m]->TLaneInfo.REG.DetCnt;
				for(k=0; k<DetCnt; k++)
				{
					Calculate_Point(sTrSelReg[m]->TrackingPointX, 
						sTrSelReg[m]->SLanePnt[k].REG.CenterX,
						sTrSelReg[m]->SLanePnt[k].REG.CenterY,
						sTrSelReg[m]->SLanePnt[k+1].REG.CenterX,
						sTrSelReg[m]->SLanePnt[k+1].REG.CenterY);
				}

				// until 360 (LD_IMG_HEIGHT)
				Calculate_Point(sTrSelReg[m]->TrackingPointX, 
					sTrSelReg[m]->SLanePnt[0].REG.CenterX,
					LD_IMG_HEIGHT-1,
					sTrSelReg[m]->SLanePnt[0].REG.CenterX,
					sTrSelReg[m]->SLanePnt[0].REG.CenterY);
#endif

				//----------------------------------------------------------------------
				for(k=0; k<DetCnt; k++)
				{
					tvPnt.x = sTrSelReg[m]->SLanePnt[k].REG.CenterX;
					tvPnt.y = sTrSelReg[m]->SLanePnt[k].REG.CenterY;

#if 0 // STEP0
					Draw_Lane(tvPnt.x-1, tvPnt.y-1, tvPnt.x-1, tvPnt.y-1, 3);
					Draw_Lane(tvPnt.x-0, tvPnt.y-0, tvPnt.x-0, tvPnt.y-0, 3);
					Draw_Lane(tvPnt.x+1, tvPnt.y+1, tvPnt.x+1, tvPnt.y+1, 3);
#endif

					//if((k==0) || (k==DetCnt-1))
					//	JIGMSG("(%d %d=%03d %03d) \n", m, k, sTrSelReg[m]->SLanePnt[k].REG.CenterX, sTrSelReg[m]->SLanePnt[k].REG.CenterY);

					orgPnt = LD_Image_Draw_OrgXY_From_TopView(tvPnt);

					sTmpLaneReg.orgLane[k].x = orgPnt.x;
					sTmpLaneReg.orgLane[k].y = orgPnt.y;
				}
				sTmpLaneReg.laneCnt = DetCnt;

				#if 1 // STEP4
				// draw lane
					for(k=1; k<sTmpLaneReg.laneCnt; k++)
					{
						Draw_Lane(sTmpLaneReg.orgLane[k-1].x, sTmpLaneReg.orgLane[k-1].y, sTmpLaneReg.orgLane[k].x, sTmpLaneReg.orgLane[k].y, 4);
					}
				#endif


				//----------------------------------------------------------------------
#if 1 // STEP5
				CubicBSpline(&sOrgLaneReg[m].orgLane[0], 7, &sTmpLaneReg.orgLane[0], sTmpLaneReg.laneCnt);
				sOrgLaneReg[m].laneCnt = 7;
#endif

				//KalmanFiltering(sOrgLaneReg, 7, m);
			}
			else
			{
				for(i=0; i<360; i++)
					sTrSelReg[m]->TrackingPointX[i] = 0;

				for(i=0; i<SEARCH_BOX_CNT_MAX; i++)
				{
					sOldTvLaneReg[m].orgLane[i].x = 0;
					sOldTvLaneReg[m].orgLane[i].y = 0;
				}
				sOldTvLaneReg[m].laneCnt = 0;
				oldCenterY[m] = 0;

				sTmpLaneReg.laneCnt = 0;
				sOrgLaneReg[m].laneCnt = 0;
			}
		} // if(TrackingStep == _TRACKING_STEP_8)
	}

	//svp_x = 0;
	//JIGMSG("%03d \n", svp_x);

	if(disDelay > 0)
		disDelay--;
	else
	{
		for(m=0; m<4; m++)
		{
			sprintf( DisString, "%02d %02d %02d %02d", sTrSelReg[m]->TLaneInfo.REG.saveStrBx, mMin[m], mMax[m], sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt);
			Draw_Text(DisString, 10, 10+m*20);

			sprintf( DisString, "%d %03d %03d %02d %02d %03d %03d %03d",
				m, sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt, sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt, sTrSelReg[m]->TLaneInfo.REG.KindsOfLane, ChangeMode, LaneChangeCnt[m], sTrSelReg[m]->TLaneInfo.REG.OldLaneAngle, (unsigned char)svp_x);
			Draw_Text(DisString, 10, 10+(m+5)*20);
		}
	}

//	JIGMSG("(%03d %03d) ", sOrgLaneReg[1].orgLane[0].x, sOrgLaneReg[1].orgLane[0].y);
//	JIGMSG("(%03d %03d) \n", sOrgLaneReg[1].orgLane[6].x, sOrgLaneReg[1].orgLane[6].y);

//	JIGMSG("(%03d %03d) ", sOrgLaneReg[1].orgLane[0].x, sOrgLaneReg[1].orgLane[0].y);
//	JIGMSG("(%03d %03d)\n", sOrgLaneReg[2].orgLane[0].x, sOrgLaneReg[2].orgLane[0].y);

#ifdef _RUN_MFC
	for(m=0; m<4; m++)
	{
		sprintf( DisString, "%02d %02d %02d %02d", sTrSelReg[m]->TLaneInfo.REG.saveStrBx, mMin[m], mMax[m], sTrSelReg[m]->TLaneInfo.REG.NoLaneCnt);
		Draw_Text(dest, DisString, 10, 10+m*20);

		sprintf( DisString, "%d %03d %03d %02d %02d %03d %03d %03d", 
			m, sTrSelReg[m]->TLaneInfo.REG.WaitDrawingCnt, sTrSelReg[m]->TLaneInfo.REG.NewLaneCnt, sTrSelReg[m]->TLaneInfo.REG.KindsOfLane, ChangeMode, LaneChangeCnt[m], sTrSelReg[m]->TLaneInfo.REG.OldLaneAngle, svp_x);
		Draw_Text(dest1, DisString, 10, 10+(m)*20);
	}
#endif	

}
