#ifndef _LD_SEARCHING_H_
#define _LD_SEARCHING_H_

#define LD_IMG_WIDTH		640
#define LD_IMG_HEIGHT		360

#define SEARCH_BOX_WIDTH	17
#define SEARCH_BOX_HEIGHT	17
#define SCORE_TIME_MAX		3
#define SEARCH_ANGLE_MAX	40

#define SEARCH_BOX_CNT_MAX	50

#define SEARCH_BOX_NUM_H	38//(LD_IMG_WIDTH / SEARCH_BOX_WIDTH)
#define SEARCH_BOX_NUM_V	22//(LD_IMG_HEIGHT / SEARCH_BOX_HEIGHT)
#define SEARCH_BOX_NUM		(SEARCH_BOX_NUM_H*SEARCH_BOX_NUM_V)


/*
typedef struct 
{
	int x;
	int y;
}POINT_XY;
*/


typedef union{
	unsigned int Data32[7];
	struct{
		unsigned int Width;
		unsigned int Height;

		unsigned int CenterX;
		unsigned int CenterY;

		unsigned int avgY;		// cut-1bit
		unsigned int avgCb;		// cut-4bit
		unsigned int avgCr;		// cut-4bit
	}REG;
}PRE_BOX_INFO;

typedef union{
	unsigned int Data32[13];
	struct{
		unsigned int ScoreTime;
		unsigned int Width;
		unsigned int Height;
		unsigned int DcntArea;
		//unsigned int Rev0_0:		7;

		unsigned int StrX;//16;
		unsigned int EndX;//16;

		unsigned int StrY;
		unsigned int EndY;

		unsigned int CenterX;//16;
		unsigned int CenterY;

		unsigned int avgY;
		unsigned int avgCb;
		unsigned int avgCr;
	}REG;

}SEARCH_BOX_INFO;

typedef union{
	unsigned int Data32;
	struct{
		unsigned int VerticalMax;
	}REG;
}DET_BOX_INFO_V;

typedef union{
	unsigned int Data32[4];
	struct{
		unsigned int DcntArea0;
		unsigned int DcntArea1;
		unsigned int DcntArea2;
		unsigned int DcntArea3;
	}REG;
}DET_BOX_INFO_H;

typedef struct{
	DET_BOX_INFO_V      DBoxInfoV[SEARCH_BOX_NUM_H];
	DET_BOX_INFO_H      DBoxInfoH[SEARCH_BOX_NUM_V];
	SEARCH_BOX_INFO		SBoxInfo[SEARCH_BOX_NUM];
}SEARCH_BOX_REGISTER;

typedef struct{
	PRE_BOX_INFO		SBoxInfo[SEARCH_BOX_NUM];
}PRE_BOX_REGISTER;


#define SEARCHING_LANE_NUM		(LD_IMG_WIDTH / SEARCH_BOX_WIDTH)
typedef union{
	unsigned int Data32[2];
	struct{
		unsigned int DetCnt;
		unsigned int CurLaneAngle;
	}REG;
}SEARCHING_LANE_INFO;

typedef union{
	unsigned int Data32[7];
	struct{
		unsigned int BoxAddr;
		unsigned int CenterX;
		unsigned int CenterY;

		unsigned int ScoreTime;
		unsigned int Width;
		unsigned int Height;
		unsigned int ResultOn;
	}REG;
}SEARCHING_LANE_POINT_INFO;

typedef struct{
	SEARCHING_LANE_POINT_INFO	SLanePnt[SEARCH_BOX_CNT_MAX];
	SEARCHING_LANE_INFO			SLaneInfo;
}SEARCHING_LANE_REGISTER;


typedef union{
	unsigned int Data32[15];
	struct{
		//-- 0
		unsigned int saveStrBx;
		unsigned int WaitDrawingCnt;

		unsigned int orgNum;
		unsigned int CurBoxI;
		unsigned int detOn;
		unsigned int displayOn;
		unsigned int DetCnt;
		unsigned int KindsOfLane;
		unsigned int CurLanePos;
		unsigned int NewLanePos;
		unsigned int NewLaneCnt;

		//-- 2
		unsigned int OldLaneAngle;
		unsigned int CurLaneAngle;
		unsigned int NewLaneAngle;
		unsigned int NoLaneCnt;
	}REG;
}TRACKING_LANE_INFO;

typedef struct{
	SEARCHING_LANE_POINT_INFO	SLanePnt[SEARCH_BOX_CNT_MAX];
	TRACKING_LANE_INFO			TLaneInfo;

	//int sArea;
	int TrackingPointX[360];

}TRACKING_LANE_REGISTER;

typedef struct{
	POINT_XY	orgLane[SEARCH_BOX_CNT_MAX];
	int laneCnt;
}ORG_LANE_REGISTER;

extern ORG_LANE_REGISTER	sOrgLaneReg[4];

//extern void LD_Searching_Box(unsigned char* src, unsigned char* src1, unsigned char* dest, unsigned char* dest1);
extern void LD_Read_Box(void);
extern void LD_Draw_Box(void);

extern void LD_Calculate_meanY(unsigned char* dest);
extern void LD_Erasing_Box_0(void);
extern void LD_Erasing_Box_1(void);
//extern void LD_Erasing_Box_V01(unsigned char* dest1);

#ifdef	_RUN_MFC
	extern void LD_Searching_Tracking_Lane(unsigned char* dest, unsigned char* dest1);
	extern void LD_Searching_Lane(unsigned char* dest, unsigned char* dest1);
#else
	extern void LD_Searching_Tracking_Lane(void);
	extern void LD_Searching_Lane(void);
#endif

extern void CubicBSpline(POINT_XY *pDest, int destCnt, POINT_XY *pSrc, int srcCnt);

#endif // #ifndef _LD_SEARCHING_H_
