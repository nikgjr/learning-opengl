/*
 * A4_LD.h
 *
 *  Created on: Dec 20, 2017
 *      Author: thcho
 */
#include "common.h"
#ifndef APP_ADAS_IP_A4_LD_H_
#define APP_ADAS_IP_A4_LD_H_

#define	META_LD_CNT_MAX			2304

typedef struct {
	unsigned int Ld_Sen_x;
	unsigned int Ld_Sen_y;
	unsigned int Ld_Sen_w;
	unsigned int Ld_Sen_h;
	unsigned int Ld_color;
}LD_DATASET;
extern volatile LD_DATASET 		Ld_data[2][META_LD_CNT_MAX];
extern void A4_LD_Init(void);

void LD_DATA_Read_test(void);
void LD_DATA_Read(void);
#endif /* APP_ADAS_IP_A4_LD_H_ */
