#ifndef _LIBNCL_LD_H_
#define _LIBNCL_LD_H_
#include "NCLD_Register.h"

// unsigned char *src_y : pointer Y start address (640x360 size)
// unsigned char *src_u : pointer U start address (320x360 size)
// unsigned char *src_v : pointer V start address (320x360 size)
extern void LD_FRAMEWORK(unsigned char *src_y, unsigned char *src_u, unsigned char *src_v, NCLD_LANE_REGISTER *sLaneReg, NCLD_REGISTER *sLdStatusReg);

#endif // !_LIBNCL_LD_H_



