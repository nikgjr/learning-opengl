
#include "RECG_Tracking.h"
#include "common.h"

#define WEIGHT_THRESHOLD	0.6			// Median Flow


#define 	PRE_TRACKING	0
#define 	GRADUAL_WEIGHT	1
#define 	PRE_WEIGHT		0

void initial_Box(BOX_INFO *Box, IDNumber *ID)
{
	int i;
	static int start = 0;

	for(i=0; i<Box->BoxNumMax; i++)
	{
		Box->BaxXYWH[i].IsAssociation = 0;
		Box->BaxXYWH[i].TrueTracking = 0;
		Box->BaxXYWH[i].ID = 0;

		Box->BaxXYWH[i].InvalidCount = 0;
		Box->BaxXYWH[i].TrackCount = 0;
		Box->BaxXYWH[i].DetCount = 0;

		/*if(start< && Box->BoxNumMax)
		{
			Box->BaxXYWH[i].NumberID = i;
			ID->UseNumber[ID->CurPoint] = 1;
			ID->CurPoint++;
		}*/
	}

}

void box_scale_convert(BOX_INFO *in , BOX_INFO *out, int mode)
{
	int i,j;
	BOX_INFO temp;

	double scale[24] = {1,  9/8.0,   5/4.0 ,  45/32.0,   25/16.0,  225/128.0,
						2, 18/8.0,  10/4.0 ,  90/32.0,   50/16.0,  450/128.0,
						4, 36/8.0,  20/4.0 , 180/32.0,  100/16.0,  900/128.0,
						8, 72/8.0,  40/4.0 , 360/32.0,  200/16.0, 1800/128.0};


	temp = *in;

	if(mode == RUN_VD)
	{
		for(i=0; i< temp.BoxNumMax; i++)
		{
			temp.BaxXYWH[i].StX += (4 * scale[temp.BaxXYWH[i].FrameNum]);
			temp.BaxXYWH[i].StY += (5 * scale[temp.BaxXYWH[i].FrameNum]);
			temp.BaxXYWH[i].Width = 24 * scale[temp.BaxXYWH[i].FrameNum];
			temp.BaxXYWH[i].Height = 22 * scale[temp.BaxXYWH[i].FrameNum];
		}
	}
	else if(mode == RUN_PD)
	{
		for(i=0; i<temp.BoxNumMax; i++)
		{
			temp.BaxXYWH[i].StX += (5.5 * scale[temp.BaxXYWH[i].FrameNum]);
			temp.BaxXYWH[i].StY += (7 * scale[temp.BaxXYWH[i].FrameNum]);
			temp.BaxXYWH[i].Width = 20.5 * scale[temp.BaxXYWH[i].FrameNum];
			temp.BaxXYWH[i].Height = 50 * scale[temp.BaxXYWH[i].FrameNum];
		}
	}
	else if(mode == RUN_VD_SIDE)
	{
		for(i=0; i<temp.BoxNumMax; i++)
		{
			temp.BaxXYWH[i].StX += (3 * scale[temp.BaxXYWH[i].FrameNum]);
			temp.BaxXYWH[i].StY += (2 * scale[temp.BaxXYWH[i].FrameNum]);
			temp.BaxXYWH[i].Width = 26 * scale[temp.BaxXYWH[i].FrameNum];
			temp.BaxXYWH[i].Height = 12 * scale[temp.BaxXYWH[i].FrameNum];
		}
	}

	*out = temp;
}

void Tracking_Tail(BOX_INFO*PreTrack, BOX_INFO *Track , BOX_INFO *Det, BOX_INFO *Out, BOX_INFO *Tail,IDNumber *ID, int mode)
{
	int i;
	unsigned int tnum = 0;
	float weight_filter = 0.9;
	BOX_INFO newBox;
	int idx;
	int max_idx = -1;
	int t;
	double max_overay = 0;

	data_Association(Track,Det);


#if ON_KALMAN_TRACKING
	t_KI.num_kalman = 0;
#endif

	for(i=0; i<Track->BoxNumMax; i++)
	{
		if(tnum == MAX_TRACK_NUM)
			break;

		idx = Track->BaxXYWH[i].ID;

		Tracking_DetTrue_TrackingTrue(&Track->BaxXYWH[i],&Det->BaxXYWH[idx],&PreTrack->BaxXYWH[i],&newBox.BaxXYWH[tnum], Tail, i,&tnum, mode);

		Tracking_DetNon_TrackingTrue(&Track->BaxXYWH[i], &PreTrack->BaxXYWH[i], &newBox.BaxXYWH[tnum], Tail, i,&tnum, mode);

		Tracking_DetNon_TrackingFail(&Track->BaxXYWH[i], &PreTrack->BaxXYWH[i], &newBox.BaxXYWH[tnum], Tail, i,&tnum, mode);

		Tracking_DetTrue_TrackingFail(&Track->BaxXYWH[i],&Det->BaxXYWH[idx],&PreTrack->BaxXYWH[i],&newBox.BaxXYWH[tnum], Tail, i,&tnum, mode);

#if 1


		//printf("%.0f %.0f %.0f %.0f\n",newBox.StX, newBox.StY, newBox.Width, newBox.Height);


		max_idx = -1;
		max_overay = 0;

		for(t=0; t<Tail->BoxNumMax; t++)
		{
			double overay;

			calc_min_overay(&newBox.BaxXYWH[i], &Tail->BaxXYWH[t],&overay);
			//JIGMSG("%d %d %d %d\n",(int)newBox.BaxXYWH[i].StX,(int)newBox.BaxXYWH[i].Width, (int)Tail->BaxXYWH[i].StX, (int)Tail->BaxXYWH[i].Width);
			//JIGMSG("%d\n",(int)(overay*1000));
			if(overay > max_overay)
			{
				max_idx = t;
				max_overay = overay;
				//JIGMSG("%d\n",(int)(max_overay*1000));
			}
		}

		if(max_overay>0)
		{
			float width_rate = newBox.BaxXYWH[i].Width/Tail->BaxXYWH[max_idx].Width;
			float x_distance = newBox.BaxXYWH[i].StX-Tail->BaxXYWH[max_idx].StX;
			float x_thresh = newBox.BaxXYWH[i].Width*0.2;


			x_distance = x_distance < 0 ? -x_distance : x_distance;

			//JIGMSG("%d %d %d %d %d\n",max_idx, (int)(max_overay*1000) ,(int)(width_rate*1000) ,(int)(x_distance*1000) ,(int)(x_thresh*1000));

			if(max_idx>=0 && max_overay>0.8 && width_rate> 0.7 && width_rate< 1.3 && (x_distance<x_thresh && x_distance>-x_thresh))
			{
				//JIGMSG("Hi %d\n",i);

				newBox.BaxXYWH[i].TrackCount = 0;
				newBox.BaxXYWH[i].TrackCount = newBox.BaxXYWH[i].TrackCount < 0 ? 0 : newBox.BaxXYWH[i].TrackCount;
				newBox.BaxXYWH[i].InvalidCount = 0;
			}
		}




#endif
	}
#if ON_KALMAN_TRACKING
	KI = t_KI;
#endif


	for(i=0; i<Det->BoxNumMax; i++)
	{
		if(tnum == MAX_TRACK_NUM)
			break;

		if(!Det->BaxXYWH[i].IsAssociation)
		{

			newBox.BaxXYWH[tnum] = Det->BaxXYWH[i];

			newBox.BaxXYWH[tnum].DetCount = 1;
			newBox.BaxXYWH[tnum].TrackCount = 0;
			newBox.BaxXYWH[tnum].InvalidCount = 0;
			newBox.BaxXYWH[tnum].weightValue = 0.7;

#if ON_KALMAN_TRACKING
			init_statematrix(&KI.KT[tnum].pos_x);
			init_statematrix(&KI.KT[tnum].pos_y);
			init_statematrix(&KI.KT[tnum].width);
			init_statematrix(&KI.KT[tnum].height);

			initial_kalman(&KI.KT[tnum].pos_x,&newBox,0,i);
			initial_kalman(&KI.KT[tnum].pos_y,&newBox,1,i);
			initial_kalman(&KI.KT[tnum].width,&newBox,2,i);
			initial_kalman(&KI.KT[tnum].height,&newBox,3,i);
#endif

/*
#if TAIL_TRACKING == 1
			for(int t=0; t<Tail->BoxNumMax; t++)
			{
				double overay;

				overay = calc_min_overay(&newBox.BaxXYWH[tnum], &Tail->BaxXYWH[t]);
				//printf("%.0f %.0f %.0f %.0f\n",newBox.BaxXYWH[tnum].StX,newBox.BaxXYWH[i].Width, Tail->BaxXYWH[i].StX, Tail->BaxXYWH[i].Width);

				if(abs(1-overay) < max_overay)
				{
					max_idx = t;
					max_overay = 1-overay;
				}
			}

			if(abs(max_overay)<0.2 && Det->BaxXYWH[i].Width/Tail->BaxXYWH[max_idx].Width> 0.8 && Det->BaxXYWH[i].Width/Tail->BaxXYWH[max_idx].Width< 1.2 && abs(Det->BaxXYWH[i].StX-Tail->BaxXYWH[max_idx].StX)<Det->BaxXYWH[i].Width*0.2)
			{
				newBox.BaxXYWH[tnum].StX = Tail->BaxXYWH[max_idx].StX;
				newBox.BaxXYWH[tnum].Width = Tail->BaxXYWH[max_idx].Width;
			}
#endif*/


			tnum++;
		}
	}

#if ON_KALMAN_TRACKING
	KI.num_kalman = tnum;
#endif
	newBox.BoxNumMax = tnum;

#if TAIL_TRACKING == 1

/*
	if(mode == VD_MODE)
	{
		for(int i=0; i<newBox.BoxNumMax; i++)
		{
			int max_idx;
			double max_overay = 10000.0;

			for(int t=0; t<Tail->BoxNumMax; t++)
			{
				double overay;

				overay = calc_min_overay(&newBox.BaxXYWH[i], &Tail->BaxXYWH[t]);
				//printf("%.0f %.0f %.0f %.0f\n",newBox.BaxXYWH[tnum].StX,newBox.BaxXYWH[i].Width, Tail->BaxXYWH[i].StX, Tail->BaxXYWH[i].Width);

				if(abs(1-overay) < max_overay)
				{
					max_idx = t;
					max_overay = 1-overay;
				}
			}

			if(abs(max_overay)<0.2 && newBox.BaxXYWH[i].Width/Tail->BaxXYWH[max_idx].Width> 0.8 && newBox.BaxXYWH[i].Width/Tail->BaxXYWH[max_idx].Width< 1.2 && abs(newBox.BaxXYWH[i].StX-Tail->BaxXYWH[max_idx].StX)<newBox.BaxXYWH[i].Width*0.2)
			{
				newBox.BaxXYWH[i].StX = Tail->BaxXYWH[max_idx].StX;
				newBox.BaxXYWH[i].Width = Tail->BaxXYWH[max_idx].Width;
			}


		}
	}*/
#endif

	*Out = newBox;

}

void Tracking_DetTrue_TrackingTrue(BOX_XYWH_DATA *Track , BOX_XYWH_DATA *Det, BOX_XYWH_DATA *Pre, BOX_XYWH_DATA *Out, BOX_INFO *Tail,int index ,unsigned int *BoxNum, int mode)
{
	float weight_filter = 0.7;
	float box_weight = 0.9;
	float x_weight = 0.5;

	BOX_XYWH_DATA newBox;

	int idx;

	float pcx;
	float pcy;

	float cx;
	float cy;

	float dcx;
	float dcy;

	float dw;
	float dh;

	float pre_weight;

	if(Track->TrueTracking)
	{
		if(Track->IsAssociation)	// Track, Det µÑŽÙ
		{
			//JIGMSG("TTTT\n");
			newBox = *Track;

			if(newBox.DetCount<30)
				newBox.DetCount++;
			if(newBox.TrackCount > 0)
				newBox.TrackCount--;
			if(newBox.InvalidCount > 0)
				newBox.InvalidCount--;

			idx = Track->ID;

			pcx = Pre->StX + Pre->Width/2;
			pcy = Pre->StY + Pre->Height;

			cx = Track->StX + Track->Width/2;
			cy = Track->StY + Track->Height;

			dcx = Det->StX + Det->Width/2;
			dcy = Det->StY + Det->Height;

			dw = Det->Width;
			dh = Det->Height;

			newBox.weightValue = Pre->weightValue;

			//weight_filter = 0.9 - ( Track->BaxXYWH[i].costValue/ (MATCH_THRESHOLD*3));

			if(Track->costValue > WEIGHT_THRESHOLD)
			{
				if(mode == PD_MODE)
				{
					weight_filter = 0.6;
					box_weight = 0.9;
				}
				else if(mode == VD_MODE)
				{
					weight_filter = 0.6;
					box_weight = 0.8;
				}

			}
			else
			{
				if(mode == PD_MODE)
				{

					weight_filter = 0.8;
					box_weight = 0.95;
				}
				else if(mode == VD_MODE)
				{

#if GRADUAL_WEIGHT == 0

					box_weight = 0.95;
#if PRE_TRACKING
					weight_filter = 0.6;

					if(Track->costValue < 0.3)
					{
						weight_filter = 0.95;
					}
#else
					weight_filter = 0.8;

					if(Track->costValue < 0.2)
					{
						weight_filter = 0.95;
					}
#endif


					box_weight = 0.9;
				}
			}
#else

				}
			}

			newBox.weightValue += (0.25 - newBox.costValue)*0.1;
			newBox.weightValue = newBox.weightValue > 0.8 ? 0.8 : newBox.weightValue;
			newBox.weightValue = newBox.weightValue < 0.4 ? 0.4 : newBox.weightValue;
			weight_filter = newBox.weightValue;
#endif
			//printf("%d %f %f\n",index,newBox.weightValue,newBox.costValue);
			//newBox.StY = cy*weight_filter + dcy*(1-weight_filter);

#if PRE_TRACKING
			newBox.StX = (cx*weight_filter + dcx*(1-weight_filter))*1.0; // + pcx*0.3;
			newBox.StY = pcy*0.7 + (cy*weight_filter + dcy*(1-weight_filter)) *0.3;		// (Pre->StY+Pre->Height/2)*0.3 +
			newBox.Width = Pre->Width*0.7 + (Track->Width*box_weight + Det->Width*(1-box_weight))*0.3;
			newBox.Height= (Track->Height*box_weight + Det->Height*(1-box_weight))*0.3	+  Pre->Height*0.7;
#else



			if(Tail->BaxXYWH[index].InvalidCount)
			{


				newBox.StX = (cx*weight_filter + dcx*(1-weight_filter))*1.0; // + pcx*0.3;
				newBox.StY = (cy*weight_filter + dcy*(1-weight_filter)) *1.0;		// (Pre->StY+Pre->Height/2)*0.3 +

				newBox.Width = Pre->Width*0.5 + (Track->Width*box_weight + Det->Width*(1-box_weight))*0.5;
				newBox.Height= (Track->Height*box_weight + Det->Height*(1-box_weight))*0.5	+  Pre->Height*0.5;
			}
			else
			{
				//box_weight = 0.7;
				//weight_filter = 0.5;

				newBox.StX = (cx*weight_filter + dcx*(1-weight_filter))*1.0; // + pcx*0.3;
				newBox.StY = (cy*weight_filter + dcy*(1-weight_filter)) *1.0;		// (Pre->StY+Pre->Height/2)*0.3 +

				newBox.Width = (Track->Width*box_weight + Det->Width*(1-box_weight));
				newBox.Height= (Track->Height*box_weight + Det->Height*(1-box_weight));
			}


#if PRE_WEIGHT
			pre_weight = 0.2 + ( abs(newBox.StY - (Pre->StY+Pre->Height)) / 8) ;
			pre_weight = pre_weight > 0.8 ? 0.8 : pre_weight;

			//printf("%d %f %f \n", index, pre_weight , abs(newBox.StY - Pre->StY - Pre->Height) / newBox.Width);

			newBox.StY = newBox.StY * (1 - pre_weight) + pre_weight*(Pre->StY + Pre->Height);

			pre_weight = 1 - abs(newBox.StX - (Pre->StX+Pre->Width/2))/8.0;
			pre_weight = pre_weight<0 ? 0 : pre_weight;
			newBox.StX = newBox.StX * (1 - pre_weight) + pre_weight*(Pre->StX + Pre->Width/2);

			pre_weight = 0.3 + (abs(newBox.Width - Pre->Width))/8.0;
			pre_weight = pre_weight > 0.8 ? 0.8 : pre_weight;
			newBox.Width = newBox.Width*(1 - pre_weight) + pre_weight * Pre->Width;

#if 0
			pre_weight = 0.3 + (abs(newBox.Width - Pre->Width))/8.0;
			pre_weight = pre_weight > 0.8 ? 0.8 : pre_weight;
			newBox.Width = newBox.Width*(1 - pre_weight) + pre_weight * Pre->Width;

			pre_weight = 0.3 + (abs(newBox.Height - Pre->Height))/8.0;
			pre_weight = pre_weight > 0.8 ? 0.8 : pre_weight;
			newBox.Height = newBox.Height*(1 - pre_weight) + pre_weight * Pre->Height;
#endif

#endif



#endif
			/*newBox.Width = (Track->Width*box_weight + Det->Width*(1-box_weight));
			newBox.Height= (Track->Height*box_weight + Det->Height*(1-box_weight));*/

			newBox.StX -= newBox.Width/2;
			newBox.StY -= newBox.Height;

			if(newBox.StX+newBox.Width/2 >0 && newBox.StX+newBox.Width/2 <640 && newBox.StY+newBox.Height/2 >0 && newBox.StY+newBox.Height/2 < 480)
			{

				if(mode == VD_MODE)
				{
#if TAIL_TRACKING == 1
					int max_idx;
					double max_overay = 10000.0;

					//printf("%.0f %.0f %.0f %.0f\n",newBox.StX, newBox.StY, newBox.Width, newBox.Height);

					for(int t=0; t<Tail->BoxNumMax; t++)
					{
						double overay;

						overay = calc_min_overay(&newBox, &Tail->BaxXYWH[t]);
						//printf("%.0f %.0f %.0f %.0f\n",newBox.BaxXYWH[tnum].StX,newBox.BaxXYWH[i].Width, Tail->BaxXYWH[i].StX, Tail->BaxXYWH[i].Width);

						if(abs(1-overay) < max_overay)
						{
							max_idx = t;
							max_overay = 1-overay;
						}
					}

					if(abs(max_overay)<0.2 && newBox.Width/Tail->BaxXYWH[max_idx].Width> 0.8 && newBox.Width/Tail->BaxXYWH[max_idx].Width< 1.2 && abs(newBox.StX-Tail->BaxXYWH[max_idx].StX)<newBox.Width*0.2)
					{
						float rate = newBox.Height/newBox.Width;

						newBox.StX = Tail->BaxXYWH[max_idx].StX;
						newBox.Width = Tail->BaxXYWH[max_idx].Width;


						newBox.StY -= (rate * Tail->BaxXYWH[max_idx].Width - newBox.Height)/2;
						newBox.Height = rate * Tail->BaxXYWH[max_idx].Width;
					}
#endif
				}

				*Out = newBox;
				Tail->BaxXYWH[*BoxNum] = Tail->BaxXYWH[index];

				// Tail->BaxXYWH[index] = Tail->BaxXYWH[*BoxNum];

				//copy_one_Box(&newBox , Out);
				//if(Tail->BoxNumMax)
				//copy_one_Box(&Tail->BaxXYWH[index],&Tail->BaxXYWH[*BoxNum]);

#if ON_KALMAN_TRACKING
				int idx = Det->ID;
				float temp;

				float cx = newBox.StX + newBox.Width/2;
				float dx = 0; //cx - (Pre->StX + Pre->Width/2);
				float uy = newBox.StY + newBox.Height;
				float dy = 0; //uy - (Pre->StY + Pre->Height);

				input_observe(&KI.KT[idx].pos_x, cx, dx);
				input_observe(&KI.KT[idx].pos_y, uy, dy);
				input_observe(&KI.KT[idx].width,newBox.Width, 0);
				input_observe(&KI.KT[idx].height,newBox.Height, 0);

				kalman_filter(&KI.KT[idx].pos_x);
				kalman_filter(&KI.KT[idx].pos_y);
				kalman_filter(&KI.KT[idx].width);
				kalman_filter(&KI.KT[idx].height);

				copy_Kalman(&KI.KT[idx].pos_x, &t_KI.KT[*BoxNum].pos_x);
				copy_Kalman(&KI.KT[idx].pos_y, &t_KI.KT[*BoxNum].pos_y);
				copy_Kalman(&KI.KT[idx].width, &t_KI.KT[*BoxNum].width);
				copy_Kalman(&KI.KT[idx].height, &t_KI.KT[*BoxNum].height);

				//printf("%f %f\n",t_KI.KT[*BoxNum].pos_x.x[0] , newBox.StX);

				Out->StX = t_KI.KT[*BoxNum].pos_x.x[0] - t_KI.KT[*BoxNum].width.x[0]/2;
				Out->StY = t_KI.KT[*BoxNum].pos_y.x[0] - t_KI.KT[*BoxNum].height.x[0];
				Out->Width =  t_KI.KT[*BoxNum].width.x[0];
				Out->Height =  t_KI.KT[*BoxNum].height.x[0];


#endif

				*BoxNum = *BoxNum + 1 ;

				//printf("%d %d\n",preBoxNUm,*BoxNum);
			}




		}
	}
}

void Tracking_DetNon_TrackingTrue(BOX_XYWH_DATA *Track , BOX_XYWH_DATA *Pre, BOX_XYWH_DATA *Out, BOX_INFO *Tail,int index, unsigned int *BoxNum, int mode)
{
	if(Track->TrueTracking)
	{
		if(!Track->IsAssociation)	// Track, Det µÑŽÙ
		{
			//JIGMSG("TT\n");

			BOX_XYWH_DATA newBox;

			int x = Track->StX;
			int y = Track->StY;

			int w = Track->Width;
			int h = Track->Height;

			//Track->Width = Pre->Width;
			//Track->Height = Pre->Height;

			Track->StX = Track->StX*1.0;// + Pre->StX*0.5;
			Track->StY = Track->StY*1.0;// + Pre->StY*0.5;

			if(Track->DetCount >= Track->TrackCount)	//
			{
				if(Track->TrackCount <= 30)
					Track->TrackCount ++;

				if(x+w/2 >0 && x+w/2 <640 && y+h/2 >0 && y+h/2 <480)
				{
#if PRE_WEIGHT
					float pre_weight;

					pre_weight = 0.2 + ( abs(Track->StY+ Track->Height - (Pre->StY+Pre->Height)) / 8);
					pre_weight = pre_weight > 0.8 ? 0.8 : pre_weight;

					Track->StY = (Track->StY+Track->Height) * (1 - pre_weight) + pre_weight*(Pre->StY+Pre->Height);
					Track->StY -= Track->Height;

					pre_weight = 1 - abs(Track->StX+ Track->Width/2 - (Pre->StX+Pre->Width/2))/4.0;
					pre_weight = pre_weight<0 ? 0 : pre_weight;
					Track->StX = (Track->StX+Track->Width/2) * (1 - pre_weight) + pre_weight*(Pre->StX+Pre->Width/2);
					Track->StX -= Track->Width/2;
#endif

					*Out = *Track;
					//copy_one_Box(Track , Out);

					Tail->BaxXYWH[*BoxNum] = Tail->BaxXYWH[index];
					//copy_one_Box(&Tail->BaxXYWH[index],&Tail->BaxXYWH[*BoxNum]);

#if ON_KALMAN_TRACKING
					float temp;

					float cx = Out->StX + Out->Width/2;
					float dx = 0; //cx - (Pre->StX + Pre->Width/2);
					float uy = Out->StY + Out->Height;
					float dy = 0; //uy - (Pre->StY + Pre->Height);

					input_observe(&KI.KT[index].pos_x, cx, dx);
					input_observe(&KI.KT[index].pos_y, uy, dy);
					input_observe(&KI.KT[index].width, Out->Width, 0); //Out->Width - Pre->Width);
					input_observe(&KI.KT[index].height,Out->Height, 0); //Out->Height - Pre->Height);

					kalman_filter(&KI.KT[index].pos_x);
					kalman_filter(&KI.KT[index].pos_y);
					kalman_filter(&KI.KT[index].width);
					kalman_filter(&KI.KT[index].height);

					copy_Kalman(&KI.KT[index].pos_x, &t_KI.KT[*BoxNum].pos_x);
					copy_Kalman(&KI.KT[index].pos_y, &t_KI.KT[*BoxNum].pos_y);
					copy_Kalman(&KI.KT[index].width, &t_KI.KT[*BoxNum].width);
					copy_Kalman(&KI.KT[index].height, &t_KI.KT[*BoxNum].height);

					//printf("%f %f\n",t_KI.KT[*BoxNum].pos_x.x[0] , newBox.StX);

					Out->StX = t_KI.KT[*BoxNum].pos_x.x[0] - t_KI.KT[*BoxNum].width.x[0]/2;
					Out->StY = t_KI.KT[*BoxNum].pos_y.x[0] - t_KI.KT[*BoxNum].height.x[0];
					Out->Width =  t_KI.KT[*BoxNum].width.x[0];
					Out->Height =  t_KI.KT[*BoxNum].height.x[0];
#endif

					*BoxNum = *BoxNum + 1;
				}

			}
			else
			{
				if(x+w/2 >0 && x+w/2 <640 && y+h/2 >0 && y+h/2 <480)
				{
					Track->InvalidCount = 1;

					*Out = *Track;
					//copy_one_Box(Track , Out);
					//if(Tail->BoxNumMax)


					Tail->BaxXYWH[*BoxNum] = Tail->BaxXYWH[index];
						//copy_one_Box(&Tail->BaxXYWH[index],&Tail->BaxXYWH[*BoxNum]);
					*BoxNum = *BoxNum + 1;

				}
			}
		}
	}


}

void Tracking_DetNon_TrackingFail(BOX_XYWH_DATA *Track , BOX_XYWH_DATA *Pre, BOX_XYWH_DATA *Out, BOX_INFO *Tail,int index, unsigned int *BoxNum, int mode)
{
	int x, y, w, h;

	if(!Track->TrueTracking)
	{
		if(!Track->IsAssociation)	// Track, Det µÑŽÙ
		{
				//JIGMSG("FT\n");
				if(Track->TrackCount <= 30)
					Track->TrackCount = Track->DetCount - 1;

				x = Track->StX;
				y = Track->StY;
				w = Track->Width;
				h = Track->Height;

				if(x+w/2 >0 && x+w/2 <640 && y+h/2 >0 && y+h/2 <480)
				{
					Track->InvalidCount = 1;

					*Out = *Track;
					//copy_one_Box(Track , Out);

					Tail->BaxXYWH[*BoxNum] = Tail->BaxXYWH[index];
					//copy_one_Box(&Tail->BaxXYWH[index],&Tail->BaxXYWH[*BoxNum]);

#if ON_KALMAN_TRACKING
					float temp;

					float cx = Out->StX + Out->Width/2;
					float dx = 0; //cx - (Pre->StX + Pre->Width/2);
					float uy = Out->StY + Out->Height;
					float dy = 0; //uy - (Pre->StY + Pre->Height);

					input_observe(&KI.KT[index].pos_x, cx, dx);
					input_observe(&KI.KT[index].pos_y, uy, dy);
					input_observe(&KI.KT[index].width,Out->Width, 0); //Out->Width - Pre->Width);
					input_observe(&KI.KT[index].height,Out->Height, 0); //Out->Height - Pre->Height);

					kalman_filter(&KI.KT[index].pos_x);
					kalman_filter(&KI.KT[index].pos_y);
					kalman_filter(&KI.KT[index].width);
					kalman_filter(&KI.KT[index].height);

					copy_Kalman(&KI.KT[index].pos_x, &t_KI.KT[*BoxNum].pos_x);
					copy_Kalman(&KI.KT[index].pos_y, &t_KI.KT[*BoxNum].pos_y);
					copy_Kalman(&KI.KT[index].width, &t_KI.KT[*BoxNum].width);
					copy_Kalman(&KI.KT[index].height, &t_KI.KT[*BoxNum].height);

					//printf("%f %f\n",t_KI.KT[*BoxNum].pos_x.x[0] , newBox.StX);

					Out->StX = t_KI.KT[*BoxNum].pos_x.x[0] - t_KI.KT[*BoxNum].width.x[0]/2;
					Out->StY = t_KI.KT[*BoxNum].pos_y.x[0] - t_KI.KT[*BoxNum].height.x[0];
					Out->Width =  t_KI.KT[*BoxNum].width.x[0];
					Out->Height =  t_KI.KT[*BoxNum].height.x[0];
#endif
					*BoxNum = *BoxNum + 1;
				}

		}
	}



}

void Tracking_DetTrue_TrackingFail(BOX_XYWH_DATA *Track , BOX_XYWH_DATA *Det, BOX_XYWH_DATA *Pre, BOX_XYWH_DATA *Out, BOX_INFO *Tail,int index, unsigned int *BoxNum, int mode)
{
	int idx;

	float dcx;
	float dcy;

	float dw;
	float dh;

	if(!Track->TrueTracking)
	{
		if(Track->IsAssociation)	// Track, Det µÑŽÙ
		{
			//JIGMSG("TTT\n");
			BOX_XYWH_DATA newBox;
			float weight_filter = 0.2;
			float box_weight = 0.8;

			//copy_one_Box(Track,&newBox);

			newBox = *Track;

			if(newBox.DetCount<30)
				newBox.DetCount++;

			idx = Track->ID;

			dcx = Det->StX + Det->Width/2;
			dcy = Det->StY + Det->Height;

			dw = Det->Width;
			dh = Det->Height;

#if GRADUAL_WEIGHT == 0
			weight_filter = 0.3;
#else
			newBox.weightValue -= 0.1;
			newBox.weightValue = newBox.weightValue > 0.8 ? 0.8 : newBox.weightValue;
			newBox.weightValue = newBox.weightValue < 0.4 ? 0.4 : newBox.weightValue;
			weight_filter = newBox.weightValue;
#endif

			newBox.Width = Pre->Width*box_weight + dw*(1-box_weight);
			newBox.Height = Pre->Height*box_weight + dh*(1-box_weight);


			newBox.StX = (Track->StX+Track->Width/2)*weight_filter + dcx*(1-weight_filter);
			//newBox.StY = (Pre->StY+Pre->Height/2)*0.3 + (Track->StY*weight_filter + dcy*(1-weight_filter))*0.7;
			newBox.StY = (Track->StY+Track->Height)*weight_filter + dcy*(1-weight_filter);




#if PRE_WEIGHT
			float pre_weight;

			pre_weight = 0.2 + ( abs(newBox.StY - (Pre->StY+Pre->Height)) / 8);
			pre_weight = pre_weight > 0.5 ? 0.5 : pre_weight;

			//printf("%d %f %f \n", index, pre_weight , abs(newBox.StY - Pre->StY - Pre->Height) / newBox.Width);

			newBox.StY = newBox.StY * (1 - pre_weight) + pre_weight*(Pre->StY + Pre->Height);

			pre_weight = 1 - abs(newBox.StX - (Pre->StX+Pre->Width/2))/4.0;
			pre_weight = pre_weight<0 ? 0 : pre_weight;
			newBox.StX = newBox.StX * (1 - pre_weight) + pre_weight*(Pre->StX + Pre->Width/2);
#endif
			newBox.StX -= newBox.Width/2;
			newBox.StY -= newBox.Height;


#if TAIL_TRACKING == 1

			if(mode == VD_MODE)
			{
				int max_idx;
				double max_overay = 10000.0;

				printf("%.0f %.0f %.0f %.0f\n",newBox.StX, newBox.StY, newBox.Width, newBox.Height);

				for(int t=0; t<Tail->BoxNumMax; t++)
				{
					double overay;

					overay = calc_min_overay(&newBox, &Tail->BaxXYWH[t]);
					//printf("%.0f %.0f %.0f %.0f\n",newBox.BaxXYWH[tnum].StX,newBox.BaxXYWH[i].Width, Tail->BaxXYWH[i].StX, Tail->BaxXYWH[i].Width);

					if(abs(1-overay) < max_overay)
					{
						max_idx = t;
						max_overay = 1-overay;
					}
				}

				if(abs(max_overay)<0.2 && newBox.Width/Tail->BaxXYWH[max_idx].Width> 0.8 && newBox.Width/Tail->BaxXYWH[max_idx].Width< 1.2 && abs(newBox.StX-Tail->BaxXYWH[max_idx].StX)<newBox.Width*0.2)
				{
					float rate = newBox.Height/newBox.Width;

					newBox.StX = Tail->BaxXYWH[max_idx].StX;
					newBox.Width = Tail->BaxXYWH[max_idx].Width;
					newBox.StY -= (rate * Tail->BaxXYWH[max_idx].Width - newBox.Height)/2;
					newBox.Height = rate * Tail->BaxXYWH[max_idx].Width;
				}
			}

#endif

			*Out = newBox;
			//copy_one_Box(&newBox, Out);

			Tail->BaxXYWH[*BoxNum] = Tail->BaxXYWH[index];
			//copy_one_Box(&Tail->BaxXYWH[index],&Tail->BaxXYWH[*BoxNum]);

#if ON_KALMAN_TRACKING
			Det->ID;
			float temp;

			float cx = newBox.StX + newBox.Width/2;
			float dx = 0; //cx - (Pre->StX + Pre->Width/2);
			float uy = newBox.StY + newBox.Height;
			float dy = 0; //uy - (Pre->StY + Pre->Height);
			float ddw = 0; // newBox.Width - Pre->Width;
			float ddh = 0; // newBox.Height - Pre->Height;

			input_observe(&KI.KT[idx].pos_x, cx, dx);
			input_observe(&KI.KT[idx].pos_y, uy, dy);
			input_observe(&KI.KT[idx].width,newBox.Width, ddw); //newBox.Width - Pre->Width);
			input_observe(&KI.KT[idx].height,newBox.Height, ddh); //newBox.Height - Pre->Height);

			kalman_filter(&KI.KT[idx].pos_x);
			kalman_filter(&KI.KT[idx].pos_y);
			kalman_filter(&KI.KT[idx].width);
			kalman_filter(&KI.KT[idx].height);

			copy_Kalman(&KI.KT[idx].pos_x, &t_KI.KT[*BoxNum].pos_x);
			copy_Kalman(&KI.KT[idx].pos_y, &t_KI.KT[*BoxNum].pos_y);
			copy_Kalman(&KI.KT[idx].width, &t_KI.KT[*BoxNum].width);
			copy_Kalman(&KI.KT[idx].height, &t_KI.KT[*BoxNum].height);

			//printf("%f %f\n",t_KI.KT[*BoxNum].pos_x.x[0] , newBox.StX);

			Out->StX = t_KI.KT[*BoxNum].pos_x.x[0] - t_KI.KT[*BoxNum].width.x[0]/2;
			Out->StY = t_KI.KT[*BoxNum].pos_y.x[0] - t_KI.KT[*BoxNum].height.x[0];
			Out->Width =  t_KI.KT[*BoxNum].width.x[0];
			Out->Height =  t_KI.KT[*BoxNum].height.x[0];
#endif

			*BoxNum = *BoxNum + 1;
		}

	}


}

void initial_ID(IDNumber *ID)
{
	int i;

	ID->CurPoint = 0;

	for(i=0; i<MAX_TRACK_NUM; i++)
		ID->UseNumber[i] = 0;
}

void Remove_Invalid_Box(BOX_INFO *in , BOX_INFO *out)
{
	BOX_INFO new_Box;
	int cnt = 0;
	int i;

	for(i=0; i<in->BoxNumMax; i++)
	{
		if(!in->BaxXYWH[i].InvalidCount)
		{
			new_Box.BaxXYWH[cnt] = in->BaxXYWH[i];
			//copy_one_Box(&in->BaxXYWH[i], &new_Box.BaxXYWH[cnt]);

#if ON_KALMAN_TRACKING
			copy_Kalman(&KI.KT[i].pos_x, &t_KI.KT[cnt].pos_x);
			copy_Kalman(&KI.KT[i].pos_y, &t_KI.KT[cnt].pos_y);
			copy_Kalman(&KI.KT[i].width, &t_KI.KT[cnt].width);
			copy_Kalman(&KI.KT[i].height, &t_KI.KT[cnt].height);
#endif

			cnt++;
		}
	}

#if ON_KALMAN_TRACKING
	KI = t_KI;
	KI.num_kalman = cnt;
#endif

	new_Box.BoxNumMax = cnt;

	*out = new_Box;
}
//}
