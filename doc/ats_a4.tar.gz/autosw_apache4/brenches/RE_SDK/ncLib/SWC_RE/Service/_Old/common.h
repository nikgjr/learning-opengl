#include "Apache.h"

#ifndef	_COMMON_H_
#define	_COMMON_H_

/*
#define	FM0_START_ADDR	0x28000000
#define	FM2_START_ADDR	(FM0_START_ADDR + (640 * 480 * 2 * 4))
#define	FM4_START_ADDR	(FM2_START_ADDR + (512 * 384 * 2 * 4))
#define	FM6_START_ADDR	(FM4_START_ADDR + (412 * 308 * 2 * 4))

#define	FMc_START_ADDR	(FM6_START_ADDR + (320 * 240 * 2 * 4))
#define	FM12_START_ADDR	(FMc_START_ADDR + (160 * 120 * 2 * 4))

#define	FMe_START_ADDR	(FM12_START_ADDR + (80 * 60 * 2 * 4))
#define	FM10_START_ADDR	(FMe_START_ADDR + (128 * 96 * 2 * 4))
*/

#define VDPD_RESULTQ_BASE 0x88FFA4D0

#define COLOR_WHITE 	0// white
#define COLOR_YELLOW 	1// Yellow
#define COLOR_CYAN 		2// Cyan
#define COLOR_GREEN 	3// Green
#define COLOR_MAGENTA 	4// Magenta
#define COLOR_RED 		5// Red
#define COLOR_BLUE 		6// Blue
#define COLOR_BLACK 	7// black
#define COLOR_MAX 		8

#define BUFF_SIMPLE
#ifdef BUFF_SIMPLE
#define	FM0_START_ADDR	0x88000000
	#define	FM2_START_ADDR	(FM0_START_ADDR +  ( 768 * 432 * 4 * 2 ))
	#define	FM4_START_ADDR	(FM2_START_ADDR +  ( 616 * 345 * 2 * 2 ))
	#define	FM6_START_ADDR	(FM4_START_ADDR +  ( 496 * 276 * 2 * 2 ))
	#define	FMc_START_ADDR	(FM6_START_ADDR +  ( 384 * 216 * 4 * 1 ))
	#define	FMe_START_ADDR	(FMc_START_ADDR +  ( 192 * 108 * 4 * 2 ))
	#define	FM10_START_ADDR	(FMe_START_ADDR +  ( 144 * 88  * 2 * 2 ))
	#define	FM12_START_ADDR	(FM10_START_ADDR + ( 128 * 70  * 2 * 2 ))

	#define	FM18_START_ADDR	(FM12_START_ADDR + ( 96  * 54  * 4 * 1 ))
	#define	FM1a_START_ADDR	(FM18_START_ADDR + ( 3072* 480 * 2 * 2 ))
	#define	FM1c_START_ADDR	(FM1a_START_ADDR + ( 2458* 384 * 2 * 2 ))


#else
	#define	FM0_START_ADDR	0x28000000
	#define	FM2_START_ADDR	(FM0_START_ADDR + (768 * 480 * 2 * 4))   //(640 * 480 * 2 * 4))
	#define	FM4_START_ADDR	(FM2_START_ADDR + (616 * 384 * 2 * 4))   //(512 * 384 * 2 * 4))
	#define	FM6_START_ADDR	(FM4_START_ADDR + 1218176 )//(492 * 309 * 2 * 4))   //(492 * 308 * 2 * 4))

	#define	FMc_START_ADDR	(FM6_START_ADDR + (384 * 240 * 2 * 4))   //(320 * 240 * 2 * 4))
	#define	FMe_START_ADDR	(FMc_START_ADDR + (192 * 120 * 2 * 4))   //(80 * 60 * 2 * 4))
	#define	FM10_START_ADDR	(FMe_START_ADDR + (156 * 96 * 2 * 4))    //(128 * 96 * 2 * 4))
	#define	FM12_START_ADDR	(FM10_START_ADDR + 77824)//(124 * 78 * 2 * 4))   //(160 * 120 * 2 * 4))
#endif


#define	FM0_START_ADDR_1	0
#define	FM2_START_ADDR_1	(FM0_START_ADDR_1 + (640 * 480 * 2 * 4))
#define	FM4_START_ADDR_1	(FM2_START_ADDR_1 + (512 * 384 * 2 * 4))
#define	FM6_START_ADDR_1	(FM4_START_ADDR_1 + (412 * 308 * 2 * 4))

#define	FMc_START_ADDR_1	(FM6_START_ADDR_1 + (320 * 240 * 2 * 4))
#define	FM12_START_ADDR_1	(FMc_START_ADDR_1 + (160 * 120 * 2 * 4))


typedef	union
{
	unsigned int DATA32;
	struct{
		unsigned int Rev_31:		1;
		unsigned int hdmi_rst:		1;
		unsigned int rev_29:		1;
		unsigned int sen_clk_on:	1;
		unsigned int rev_27:		1;
		unsigned int rev_26:		1;
		unsigned int out_clk_inv:	1;
		unsigned int sen_clk_inv:	1;
		unsigned int gpio_23:		1;
		unsigned int gpio_22:		1;
		unsigned int gpio_21:		1;
		unsigned int gpio_20:		1;
		unsigned int Rev_00:		20;
	}Reg;
}GPIO_REG;


// sensor selection ------------------------------------------------
#define	VIM_SET_CIS_IMX291		// SONY --> ISP --> VIM --> VOM
//#define VIM_SET_CIS_MT9P111	// AT   ----------> VIM --> VOM

#ifdef	VIM_SET_CIS_IMX291
	#define	IMG_WIDTH	1280
	#define	IMG_HEIGHT	720

	#define	_BT601
#endif

#ifdef	VIM_SET_CIS_MT9P111
	#define	IMG_WIDTH	640
	#define	IMG_HEIGHT	362

	#define	_BT656
#endif


// adas selection ------------------------------------------------
//#define	RECG_TEST
//#define	MOD_TEST
//#define	HSV_OP_TEST
//#define	LD_TEST
//#define TRACKING	// #Tracking
//#define SEN_VEDIO

#define	_ADAS_HEIGHT_360
#define	_SC_FR_SKIP		3
#define	_DRAW_SCALE		1


#define	_DIS_G08_ON
#define	_DIS_G09_ON
#define	_DIS_G10_ON
#define	_DIS_G11_ON

#define	_SCALER_INT_EN
#define	_SCALER_INT_G11_ON

//#define	_INT_PULSE_ON
#ifdef	LD_TEST
	#define _LD_INT_EN
	#define _LD_INIT
	#define	_LD_ON
#endif



#ifdef	RECG_TEST
	#define	_RECG_ON
	#define	_RECG_INT_EN
	#define	_RECG_INT_G09_ON

	#define _ACF_DRAW_ON
	#define _ACF_DRAW_COLOR_ON

	#define	_RECG_TABLE_WR_EN
	#define	_RECG_F00_ON				// vD
	#define	_RECG_F01_ON				// vD
	#define	_RECG_F10_ON				// pD
	#define	_RECG_F11_ON				// VD

	#ifdef	_ENABLE_VIM_BUF_CHANGE
		#define	_ACF_DRAW_COLOR_ON
	#endif
#endif

#ifdef	MOD_TEST
	#define	_MOD_ON
	#define	_MOD_INT_EN
	#define	_MOD_DRAW_ON		// MOD
	#define	_MOD_NCC_ON
	#define	_MOD_INT_G11_ON

	#ifdef	_ENABLE_VIM_BUF_CHANGE
		#define	_MOD_DRAW_COLOR_ON
	#endif
#endif

#ifdef	HSV_OP_TEST
	#define	_HSV_OP_INT_EN
#endif

#define	_UART1_RX_INT_EN

#define	_PD_TABLE_ON
#define	_VD_TABLE_ON

typedef void (interrupt_handler_t)(void *);

#define STATUS_CHANGE
//#define DB_R750

//#define ACFTEST
#define SENCLK_INV
	#define	_RECG_F100_ON				// vD
	#define	_RECG_F101_ON				// pD
	#define	_RECG_F110_ON				// VD
	#define	_RECG_F111_ON				// VD

	#define	RUN_VD		0
	#define	RUN_PD		1
	#define	RUN_TSR		2
	#define RUN_VD_SIDE	3

	typedef struct
	{
		float min_overlap;
		float union_overlap;

	}ST_OVERLAP;


#define INPUT_IMG_SIZE 0
/*
 * INPUT_IMG_SIZE = 0 1280 * 720
 * INPUT_IMG_SIZE = 1 1920 * 1080
 * INPUT_IMG_SIZE = 2 3072 * 1728
 */
#define GPIO_TOGGLE 2
#define GPIO_HIGH 1
#define GPIO_LOW 0

#endif
