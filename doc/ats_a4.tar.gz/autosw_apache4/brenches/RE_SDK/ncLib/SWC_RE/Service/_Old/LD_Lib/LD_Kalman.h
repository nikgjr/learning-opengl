#ifndef _LD_KALMAN_H_
#define _LD_KALMAN_H_
#include "LD_Searching.h"
#include "LD_Register.h"


extern void KalmanFiltering(ORG_LANE_REGISTER *Left_lane, int Cnt, int m);


#endif // !_LD_KALMAN_H_

