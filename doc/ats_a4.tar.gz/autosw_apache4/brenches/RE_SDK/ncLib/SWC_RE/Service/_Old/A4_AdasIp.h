#ifndef	_ADAS_IP_H_
#define	_ADAS_IP_H_

#include "common.h"
#include "../RE_Svc.h"
#include "RECG_typedef.h"
#include "A4_RecgEng.h"
#include "A4_HsvOp.h"
#include "A4_LD.h"
#include "A4_Mod.h"
#include "A4_RecgScaler.h"

typedef struct
{
	unsigned int x;
	unsigned int y;
	unsigned int width;
	unsigned int height;
	unsigned int color;
	int			 acfValue;
	int			 fmx;
}figure;

typedef union
{
	unsigned int Data32;
	struct{
		unsigned int RecgStartOn:	1;
		unsigned int ModStartOn:	1;
		unsigned int ScalerStartOn:	1;
		unsigned int Reserved_25:	5;

		unsigned int Reserved_18:	5;
		unsigned int DrawFrameNum:	2;
		unsigned int DrawOn: 		1;

		unsigned int Reserved_06:	10;

		unsigned int RdBufSelHsv:	1;
		unsigned int WrBufSelHsv:	1;

		unsigned int RdBufSelMod: 	1;
		unsigned int WrBufSelMod: 	1;

		unsigned int RdBufSelACF: 	1;
		unsigned int WrBufSelACF: 	1;
	}Reg;
}ADAS_STATUS;

typedef struct
{
	unsigned int width_0 ;
	unsigned int width_2 ;
	unsigned int width_4 ;
	unsigned int width_6 ;
	unsigned int width_c ;
	unsigned int width_e ;
	unsigned int width_10;
	unsigned int width_12;

	unsigned int height_0 ;
	unsigned int height_2 ;
	unsigned int height_4 ;
	unsigned int height_6 ;
	unsigned int height_c ;
	unsigned int height_e ;
	unsigned int height_10;
	unsigned int height_12;

	unsigned int wide_width_0 ;
	unsigned int wide_width_2 ;
	unsigned int wide_width_4 ;

	unsigned int wide_height_0 ;
	unsigned int wide_height_2 ;
	unsigned int wide_height_4 ;

	unsigned int input_size_width;
	unsigned int input_size_height;

	unsigned int total_size_width;
	unsigned int total_size_height;

	unsigned int DTO;
	unsigned int DLY;

}ADAS_SIZE;

#define _ADAS_WIDE_HEIGHT_306
#ifdef _ADAS_WIDE_HEIGHT_306
	#define ADAS_WIDE_WIDTH_0	1280
	#define ADAS_WIDE_HEIGHT_0	360

	#define ADAS_WIDE_WIDTH_2	1024
	#define ADAS_WIDE_HEIGHT_2	288

	#define ADAS_WIDE_WIDTH_4	820
	#define ADAS_WIDE_HEIGHT_4	230
#endif


#ifdef _ADAS_HEIGHT_360
	#define	ADAS_WIDTH_0		640	// FM0 H_V_SIZE 640 X 360
	#define	ADAS_HEIGHT_0		360

	#define	ADAS_WIDTH_2		512 // FM2 H_V_SIZE 512 X 288
	#define	ADAS_HEIGHT_2		288

	#define	ADAS_WIDTH_4		412	// FM4 H_V_SIZE 412 X 230
	#define	ADAS_HEIGHT_4		230

	#define	ADAS_WIDTH_6		(unsigned int)(ADAS_WIDTH_0/2)
	#define	ADAS_HEIGHT_6		(unsigned int)(ADAS_HEIGHT_0/2)

	#define	ADAS_WIDTH_12		(unsigned int)(ADAS_WIDTH_0/8)
	#define	ADAS_HEIGHT_12		(unsigned int)(ADAS_HEIGHT_0/8)

	#define	ADAS_WIDTH_c		(unsigned int)(ADAS_WIDTH_0/4)
	#define	ADAS_HEIGHT_c		(unsigned int)(ADAS_HEIGHT_0/4)

	#define	ADAS_WIDTH_e		(unsigned int)(ADAS_WIDTH_2/4)
	#define	ADAS_HEIGHT_e		(unsigned int)(ADAS_HEIGHT_2/4)

	#define	ADAS_WIDTH_10		(unsigned int)(ADAS_WIDTH_4/4+1)
	#define	ADAS_HEIGHT_10		(unsigned int)(ADAS_HEIGHT_4/4)
#else
			//  640 x 480 image start address
			//  512 x 384 image start address
			//  412 x 308 image start address
			//  320 x 240 image start address
			//  160 x 120 image start address
			//  80  x 60  image start address
			//  128 x 96  image start address
			//  104 x 57  image start address

	#define	ADAS_WIDTH_0		640	// FM0 H_V_SIZE 640 X 360
	#define	ADAS_HEIGHT_0		480

	#define	ADAS_WIDTH_2		512 // FM2 H_V_SIZE 512 X 288
	#define	ADAS_HEIGHT_2		384

	#define	ADAS_WIDTH_4		412	// FM4 H_V_SIZE 412 X 230
	#define	ADAS_HEIGHT_4		307

	#define	ADAS_WIDTH_6		(unsigned int)(ADAS_WIDTH_0/2)
	#define	ADAS_HEIGHT_6		(unsigned int)(ADAS_HEIGHT_0/2)

	#define	ADAS_WIDTH_12		(unsigned int)(ADAS_WIDTH_0/8)
	#define	ADAS_HEIGHT_12		(unsigned int)(ADAS_HEIGHT_0/8)

	#define	ADAS_WIDTH_c		(unsigned int)(ADAS_WIDTH_0/4)
	#define	ADAS_HEIGHT_c		(unsigned int)(ADAS_HEIGHT_0/4)

	#define	ADAS_WIDTH_e		(unsigned int)(ADAS_WIDTH_2/4)
	#define	ADAS_HEIGHT_e		(unsigned int)(ADAS_HEIGHT_2/4)

	#define	ADAS_WIDTH_10		(unsigned int)(ADAS_WIDTH_4/4+1)
	#define	ADAS_HEIGHT_10		(unsigned int)(ADAS_HEIGHT_4/4)
#endif

extern volatile ADAS_SIZE 		adas_size;
extern volatile ADAS_STATUS 	AdasStatus;

extern void A4_AdasIp_Init(void);
extern void A4_AdasIP_Interrupt_Init(void);
extern void test_apb (void);
extern void Gpio_Set(int gpio_num , int state);



typedef struct
{
    UCHAR VdpdEndPosFlag;
    UCHAR VdpdPseudoFlag;
    UCHAR VdpdStartFlag;
    UCHAR VdpdBufFullFlag;

    UCHAR ModOfEndPosFlag;
    UCHAR ModOfEndNegFlag;
    UCHAR ModOfStartFlag;

    UCHAR ModFpEndPosFlag;
    UCHAR ModFpEndNegFlag;
    UCHAR ModFpStartFlag;

    UCHAR TsrEndPosFlag;
    UCHAR TsrEndNegFlag;
    UCHAR TsrStartFlag;
    UCHAR TsrBufFullFlag;

    UCHAR VdpdEndPosFlag_HOG;
    UCHAR VdpdEndNegFlag_HOG;
    UCHAR VdpdStartFlag_HOG;
    UCHAR VdpdBufFullFlag_HOG;

    UCHAR TsrEndPosFlag_HOG;
    UCHAR TsrEndNegFlag_HOG;
    UCHAR TsrStartFlag_HOG;
    UCHAR TsrBufFullFlag_HOG;

} tAR_RECGINT;

typedef struct
{
    UCHAR ModFpStartFlag;
    UCHAR ModFpEndPosFlag;
    UCHAR ModFpEndNegFlag;

    UCHAR ModOfStartFlag;
	UCHAR ModOfEndNegFlag;
    UCHAR ModOfEndPosFlag;
} tAR_MODINT;


typedef struct
{
    UINT32 DownSacleStartX;
    UINT32 DownSacleStartY;
} tAR_IMAGE_SIZE;

extern tAR_RECGINT sRecgInt;
extern tAR_MODINT sModInt;
extern tAR_IMAGE_SIZE	sImageSize;

#endif
