/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    :
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version :
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "../RE_Svc.h"

/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
void RE_Ce_ISR_Handler(void)
{
	int tmp;
	static int hsvtest=0;
	if(sReCeReg->Reg.START_INT)
	{
		sReCeReg->Reg.START_INT_CLR = 1;
		sReCeReg->Reg.START_INT_CLR = 0;


		Gpio_Set(8,GPIO_HIGH);

	}
	//--------------------------------------------------------------------------------------------------------
	if(sReCeReg->Reg.END_INT)
	{

		sReCeReg->Reg.END_INT_CLR = 1;
		sReCeReg->Reg.END_INT_CLR = 0;

		Gpio_Set(8,GPIO_LOW);
		if(hsvtest)
		{
			hsvtest = 0;

		}
		else
		{
			hsvtest = 1;
		}

		A4_HsvOpEndInt_Callback();
		//JIGMSG( "HE\n");


	}
    //Clear IFR of IRQ1 (INTC's IFR turn-off)
    //abbd_intc_core_ifr_off(HSV_OP_CORE_IRQ);
}



void RE_Ce_Init(void)
{
	sReCeReg->Reg.HSV_CH0_OP_EN = 0;
	sReCeReg->Reg.HSV_CH1_OP_EN = 0;
	sReCeReg->Reg.CH0_SEL = 0;
	sReCeReg->Reg.CH1_SEL = 0;
	sReCeReg->Reg.FRAME_TOT_PIX_CNT =adas_size.total_size_height * adas_size.total_size_width - 2; // 1650 X 750 - 2
	sReCeReg->Reg.START_INT_EN 	= 1;
	sReCeReg->Reg.END_INT_EN 	= 1;
	sReCeReg->Reg.HSV_H_ACT = adas_size.width_0;

#ifdef	_HSV_OP_INT_EN
    if( ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_RE_CE, (PrVoid)RE_Ce_ISR_Handler, CMD_END) != NC_SUCCESS )
    {
    	DEBUGMSG_SDK(MSGERR, "CE_INI ERROR\n");
    }
#endif

	JIGMSG("@@ HSV OP Init. done \n");

}


/* End Of File */

