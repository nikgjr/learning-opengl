#ifndef __RE_MOD_REGISTER_H__
#define __RE_MOD_REGISTER_H__

/*=============================================================================
	Definitions for Register Start Address, End Address, Size
=============================================================================*/
typedef union
{
	unsigned int Data32;
	struct
	{
		unsigned int f_0:			1;	// 0.125
		unsigned int f_1:			1;	// 0.25
		unsigned int f_2:			1;	// 0.5
		unsigned int int_0:			6;
		unsigned int rev_0:			23;
	}Reg;

}MOD_UV_ORG;

typedef union
{
	unsigned int Data32;
	struct
	{
		unsigned int f_0:			1;	// 0.015626
		unsigned int f_1:			1;	// 0.03125
		unsigned int f_2:			1;	// 0.0625
		unsigned int f_3:			1;	// 0.125
		unsigned int f_4:			1;	// 0.25
		unsigned int f_5:			1;	// 0.5
		unsigned int int_0:			2;
		unsigned int rev_0:			24;
	}Reg;

}MOD_NCC_ORG;


typedef union
{
	unsigned int Data32;
	struct
	{
		int mod_v_int:					6;
		int mod_u_int:					6;
		unsigned int mod_crop:			1;
		unsigned int mod_y:				9;
		unsigned int mod_x:				10;
	}Reg;
	struct
	{
		UINT32 Data0:						8;
		UINT32 Data1:						8;
		UINT32 Data2:						8;
		UINT32 Data3:						8;
	}D8;
}MOD_RESULT_0;

typedef union
{
	unsigned int Data32;
	struct
	{
		unsigned int mod_v_float:		3;


		unsigned int mod_u_float:		3;
		unsigned int mod_ncc:			8;	// [7:6]2bit int, [5:0]6bit float
		unsigned int rev:				18;
	}Reg;
	struct
	{
		UINT32 Data0:						8;
		UINT32 Data1:						8;
		UINT32 Data2:						8;
		UINT32 Data3:						8;
	}D8;
}MOD_RESULT_1;

#define	RE_MOD_REGISTER_SIZE	0x5100

typedef union
{
	unsigned int Data[RE_MOD_REGISTER_SIZE/4];
	struct
	{
		/*	0x0000	[00]	*/	unsigned int	MOD_EN_0	:	1	;
		/*	0x0000	[01]	*/	unsigned int	MOD_EN_1	:	1	;
		/*	0x0000	[02]	*/	unsigned int	MOD_NCC_EN	:	1	;
		/*	0x0000	[03]	*/	unsigned int	Rev0000_03	:	5	;
		/*	0x0000	[08]	*/	unsigned int	MOD_FRAME_SKIP	:	8	;
		/*	0x0000	[16]	*/	unsigned int	MOD_UV_MAX	:	8	;
		/*	0x0000	[24]	*/	unsigned int	MOD_DIV_MAX	:	8	;

		/*	0x0004	[00]	*/	unsigned int	MOD_ROI_MODE_SELECT	:	2	;
		/*	0x0004	[02]	*/	unsigned int	MOD_FP_RESOLUTION	:	1	;
		/*	0x0004	[03]	*/	unsigned int	MOD_VECTOR_LENGTH	:	5	;
		/*	0x0004	[08]	*/	unsigned int	MOD_FP_THRESHOLD	:	16	;
		/*	0x0004	[24]	*/	unsigned int	MOD_RD_IRQ_BOUNDARY	:	8	;

		/*	0x0008	[00]	*/	unsigned int	MOD_ROI0_y0	:	9	;
		/*	0x0008	[09]	*/	unsigned int	Rev0008_09	:	7	;
		/*	0x0008	[16]	*/	unsigned int	MOD_ROI0_x0	:	10	;
		/*	0x0008	[26]	*/	unsigned int	Rev0008_26	:	6	;

		/*	0x000C	[00]	*/	unsigned int	MOD_ROI0_y1	:	9	;
		/*	0x000C	[09]	*/	unsigned int	Rev000C_09	:	7	;
		/*	0x000C	[16]	*/	unsigned int	MOD_ROI0_x1	:	10	;
		/*	0x000C	[26]	*/	unsigned int	Rev000C_26	:	6	;

		/*	0x0010	[00]	*/	unsigned int	MOD_ROI1_y0	:	9	;
		/*	0x0010	[09]	*/	unsigned int	Rev0010_09	:	7	;
		/*	0x0010	[16]	*/	unsigned int	MOD_ROI1_x0	:	10	;
		/*	0x0010	[26]	*/	unsigned int	Rev0010_26	:	6	;

		/*	0x0014	[00]	*/	unsigned int	MOD_ROI1_y1	:	9	;
		/*	0x0014	[09]	*/	unsigned int	Rev0014_09	:	7	;
		/*	0x0014	[16]	*/	unsigned int	MOD_ROI1_x1	:	10	;
		/*	0x0014	[26]	*/	unsigned int	Rev0014_26	:	6	;

		/*	0x0018	[00]	*/	unsigned int	MOD_ROI2_y0	:	9	;
		/*	0x0018	[09]	*/	unsigned int	Rev0018_09	:	7	;
		/*	0x0018	[16]	*/	unsigned int	MOD_ROI2_x0	:	10	;
		/*	0x0018	[26]	*/	unsigned int	Rev0018_26	:	6	;

		/*	0x001C	[00]	*/	unsigned int	MOD_ROI2_y1	:	9	;
		/*	0x001C	[09]	*/	unsigned int	Rev001C_09	:	7	;
		/*	0x001C	[16]	*/	unsigned int	MOD_ROI2_x1	:	10	;
		/*	0x001C	[26]	*/	unsigned int	Rev001C_26	:	6	;

		/*	0x0020	[00]	*/	unsigned int	MOD_ROI3_y0	:	9	;
		/*	0x0020	[09]	*/	unsigned int	Rev0020_09	:	7	;
		/*	0x0020	[16]	*/	unsigned int	MOD_ROI3_x0	:	10	;
		/*	0x0020	[26]	*/	unsigned int	Rev0020_26	:	6	;

		/*	0x0024	[00]	*/	unsigned int	MOD_ROI3_y1	:	9	;
		/*	0x0024	[09]	*/	unsigned int	Rev0024_09	:	7	;
		/*	0x0024	[16]	*/	unsigned int	MOD_ROI3_x1	:	10	;
		/*	0x0024	[26]	*/	unsigned int	Rev0024_26	:	6	;

		/*	0x0028	[00]	*/	unsigned int	MOD_BASE_ADDR_LV0	:	32	;

		/*	0x002C	[00]	*/	unsigned int	MOD_BASE_ADDR_LV1	:	32	;

		/*	0x0030	[00]	*/	unsigned int	MOD_BASE_ADDR_LV2	:	32	;

		/*	0x0034	[00]	*/	unsigned int	MOD_FRC_M_EN_LV0	:	1	;
		/*	0x0034	[01]	*/	unsigned int	MOD_FRC_M_EN_LV1	:	1	;
		/*	0x0034	[02]	*/	unsigned int	MOD_FRC_M_EN_LV2	:	1	;
		/*	0x0034	[03]	*/	unsigned int	MOD_MAX_PYR_LV	:	2	;
		/*	0x0034	[05]	*/	unsigned int	Rev0034_05	:	3	;
		/*	0x0034	[08]	*/	unsigned int	MOD_FP_IMG_HEIGHT	:	9	;
		/*	0x0034	[17]	*/	unsigned int	MOD_FP_IMG_WIDTH	:	10	;
		/*	0x0034	[27]	*/	unsigned int	Rev0034_27	:	5	;

		/*	0x0038	[00]	*/	unsigned int	MOD_IMG_SIZE_LV0	:	20	;
		/*	0x0038	[20]	*/	unsigned int	Rev0038_20	:	12	;

		/*	0x003C	[00]	*/	unsigned int	MOD_IMG_SIZE_LV1	:	20	;
		/*	0x003C	[20]	*/	unsigned int	Rev003C_20	:	12	;

		/*	0x0040	[00]	*/	unsigned int	MOD_IMG_SIZE_LV2	:	20	;
		/*	0x0040	[20]	*/	unsigned int	Rev0040_20	:	12	;

		/*	0x0044	[00]	*/	unsigned int	MOD_BUFFER_M_CNT_LV0_T0	:	2	;
		/*	0x0044	[02]	*/	unsigned int	MOD_BUFFER_M_CNT_LV0_T1	:	2	;
		/*	0x0044	[04]	*/	unsigned int	MOD_BUFFER_CNT_LV0	:	2	;
		/*	0x0044	[06]	*/	unsigned int	MOD_BUFFER_M_CNT_LV1_T0	:	2	;
		/*	0x0044	[08]	*/	unsigned int	MOD_BUFFER_M_CNT_LV1_T1	:	2	;
		/*	0x0044	[10]	*/	unsigned int	MOD_BUFFER_CNT_LV1	:	2	;
		/*	0x0044	[12]	*/	unsigned int	MOD_BUFFER_M_CNT_LV2_T0	:	2	;
		/*	0x0044	[14]	*/	unsigned int	MOD_BUFFER_M_CNT_LV2_T1	:	2	;
		/*	0x0044	[16]	*/	unsigned int	MOD_BUFFER_CNT_LV2	:	2	;
		/*	0x0044	[18]	*/	unsigned int	Rev0044_18	:	14	;

		/*	0x0048	[00]	*/	unsigned int	MOD_INT_EN_FP_START	:	1	;
		/*	0x0048	[01]	*/	unsigned int	MOD_INT_EN_FP_END_R	:	1	;
		/*	0x0048	[02]	*/	unsigned int	MOD_INT_EN_FP_BUFFER_F	:	1	;
		/*	0x0048	[03]	*/	unsigned int	MOD_INT_EN_OF_START	:	1	;
		/*	0x0048	[04]	*/	unsigned int	MOD_INT_EN_OF_END_R	:	1	;
		/*	0x0048	[05]	*/	unsigned int	MOD_INT_EN_OF_BUFFER_F	:	1	;
		/*	0x0048	[06]	*/	unsigned int	MOD_INT_EN_PSEUDO_END_R	:	1	;
		/*	0x0048	[07]	*/	unsigned int	Rev0048_07	:	9	;
		/*	0x0048	[16]	*/	unsigned int	MOD_INT_PULSE_EN	:	1	;
		/*	0x0048	[17]	*/	unsigned int	Rev0048_17	:	15	;

		/*	0x004C	[00]	*/	unsigned int	MOD_INT_CLR_FP_START	:	1	;
		/*	0x004C	[01]	*/	unsigned int	MOD_INT_CLR_FP_END_R	:	1	;
		/*	0x004C	[02]	*/	unsigned int	MOD_INT_CLR_FP_BUFFER_F	:	1	;
		/*	0x004C	[03]	*/	unsigned int	MOD_INT_CLR_OF_START	:	1	;
		/*	0x004C	[04]	*/	unsigned int	MOD_INT_CLR_OF_END_R	:	1	;
		/*	0x004C	[05]	*/	unsigned int	MOD_INT_CLR_OF_BUFFER_F	:	1	;
		/*	0x004C	[06]	*/	unsigned int	MOD_INT_CLR_PSEUDO_END_R	:	1	;
		/*	0x004C	[07]	*/	unsigned int	Rev004C_07	:	25	;

		/*	0x0050	[00]	*/	unsigned int	MOD_OF_IMG_HEIGHT_LV0	:	9	;
		/*	0x0050	[09]	*/	unsigned int	MOD_OF_IMG_WIDTH_LV0	:	10	;
		/*	0x0050	[19]	*/	unsigned int	Rev0050_19	:	13	;

		/*	0x0054	[00]	*/	unsigned int	MOD_OF_IMG_HEIGHT_LV1	:	9	;
		/*	0x0054	[09]	*/	unsigned int	MOD_OF_IMG_WIDTH_LV1	:	10	;
		/*	0x0054	[19]	*/	unsigned int	Rev0054_19	:	13	;

		/*	0x0058	[00]	*/	unsigned int	MOD_OF_IMG_HEIGHT_LV2	:	9	;
		/*	0x0058	[09]	*/	unsigned int	MOD_OF_IMG_WIDTH_LV2	:	10	;
		/*	0x0058	[19]	*/	unsigned int	Rev0058_19	:	13	;

		/*	0x005C	[00]	*/	unsigned int	MOD_MANUAL_FP_XY	:	19	;
		/*	0x005C	[19]	*/	unsigned int	MOD_MANUAL_FP_ADDR	:	11	;
		/*	0x005C	[30]	*/	unsigned int	MOD_MANUAL_FP_WEN	:	1	;
		/*	0x005C	[31]	*/	unsigned int	Rev005C_31	:	1	;

		/*	0x0060	[00]	*/	unsigned int	MOD_MANUAL_START_EN	:	1	;
		/*	0x0060	[01]	*/	unsigned int	MOD_MANUAL_MODE	:	2	;
		/*	0x0060	[03]	*/	unsigned int	MOD_MANUAL_MAX_FP	:	10	;
		/*	0x0060	[14]	*/	unsigned int	Rev0060_14	:	18	;

		/*	0x0064	[00]	*/	unsigned int	MOD_PSEUDO_CNT	:	32	;

		/*	0x0068	[00]	*/	unsigned int	MOD_GRID_ADDR	:	11	;
		/*	0x0068	[11]	*/	unsigned int	Rev0068_11	:	5	;
		/*	0x0068	[16]	*/	unsigned int	MOD_GRID_MAX	:	11	;
		/*	0x0068	[27]	*/	unsigned int	Rev0068_27	:	5	;

		/*	0x006C	[00]	*/	unsigned int	MOD_GRID_Y	:	9	;
		/*	0x006C	[09]	*/	unsigned int	MOD_GRID_X	:	10	;
		/*	0x006C	[19]	*/	unsigned int	Rev006C_19	:	5	;
		/*	0x006C	[24]	*/	unsigned int	MOD_GRID_WEN	:	1	;
		/*	0x006C	[25]	*/	unsigned int	MOD_GRID_MODE	:	1	;
		/*	0x006C	[26]	*/	unsigned int	Rev006C_26	:	6	;

		/*	0x0070	[00]	*/	unsigned int	MOD_AXI_W_BASE_ADDR0	:	32	;

		/*	0x0074	[00]	*/	unsigned int	MOD_AXI_W_BASE_ADDR1	:	32	;

		/*	0x0078	[00]	*/ 	unsigned int	Rev0068_00[(0x00A0-0x0078)/4];

		/*	0x00A0	[00]	*/	unsigned int	MOD_MAX_FP_CNT_T0	:	11	;
		/*	0x00A0	[11]	*/	unsigned int	Rev00A0_11	:	21	;

		/*	0x00A4	[00]	*/	unsigned int	MOD_MAX_FP_CNT_T1	:	11	;
		/*	0x00A4	[11]	*/	unsigned int	Rev00A4_11	:	21	;

		/*	0x00A8	[00]	*/	unsigned int	MOD_INT_FP_START_FLAG	:	1	;
		/*	0x00A8	[01]	*/	unsigned int	MOD_INT_FP_END_R_FLAG	:	1	;
		/*	0x00A8	[02]	*/	unsigned int	MOD_INT_FP_BUFFER_FULL_FLAG	:	1	;
		/*	0x00A8	[03]	*/	unsigned int	MOD_INT_OF_START_FLAG	:	1	;
		/*	0x00A8	[04]	*/	unsigned int	MOD_INT_OF_END_R_FLAG	:	1	;
		/*	0x00A8	[05]	*/	unsigned int	MOD_INT_OF_BUFFER_FULL_FLAG	:	1	;
		/*	0x00A8	[06]	*/	unsigned int	MOD_INT_PSEUDO_END_R_FLAG	:	1	;
		/*	0x00A8	[07]	*/	unsigned int	Rev00A8_07	:	25	;

		/*	0x00AC	[00]	*/	unsigned int	MOD_RESQ_W_ADDR	:	12	;
		/*	0x00AC	[11]	*/	unsigned int	Rev00AC_11	:	5	;
		/*	0x00AC	[16]	*/	unsigned int	MOD_AXI_W_MEM_SEL	:	1	;
		/*	0x00AC	[17]	*/	unsigned int	Rev00AC_17	:	15	;

		/*	0x00B0	[00]	*/	unsigned int	MOD_AXI_W_MAX_CNT	:	12	;
		/*	0x00B0	[12]	*/	unsigned int	Rev00B0_12	:	4	;
		/*	0x00B0	[16]	*/	unsigned int	MOD_AXI_W_END_SIG	:	1	;
		/*	0x00B0	[17]	*/	unsigned int	Rev00B0_17	:	15	;

		/*	0x00B4	[00]	*/	unsigned int	MOD_AXI_W_BASE_ADDR	:	32	;

		//
		/* 0x00B8[00] */ unsigned int	Rev00B8_00[(0x0100-0x00B8)/4];
	}Reg;
}RE_MOD_REGISTER;

#endif


