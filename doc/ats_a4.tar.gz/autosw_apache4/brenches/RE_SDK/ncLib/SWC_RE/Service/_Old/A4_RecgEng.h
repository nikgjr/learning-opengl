#include "common.h"
#ifndef	_A4_RECGENG_
#define _A4_RECGENG_

#define	FXX_MASK_W	32
#ifdef ACFTEST
	#define	F00_MASK_H	32	// vd
	#define	F01_MASK_H	32	// vd side
	#define	F10_MASK_H	32	// pd
	#define	F11_MASK_H	32
#else
	#define	F00_MASK_H	32	// vd
	#define	F01_MASK_H	16	// vd side
	#define	F10_MASK_H	64	// pd
	#define	F11_MASK_H	32
	#define	F100_MASK_H	32	// vd
	#define	F101_MASK_H	16	// vd side
	#define	F110_MASK_H	64	// pd
	#define	F111_MASK_H	32
/*
	#define	F00_MASK_H	32	// vd
	#define	F01_MASK_H	16	// vd side
	#define	F10_MASK_H	64	// pd
	#define	F11_MASK_H	32*/
#endif


//#define RECG_W 	ADAS_WIDTH_0
//#define RECG_H 	ADAS_HEIGHT_0


#define	META_F00_CNT_MAX				128
#define	META_F01_CNT_MAX				128
#define	META_F10_CNT_MAX				128
#define	META_F11_CNT_MAX				128

extern BOX_INFO DetBoxF00;
extern BOX_INFO DetBoxF01;
extern BOX_INFO DetBoxF10;
extern BOX_INFO DetBoxF11;

#define	META_F100_CNT_MAX				128
#define	META_F101_CNT_MAX				128
#define	META_F110_CNT_MAX				128
#define	META_F111_CNT_MAX				128

extern BOX_INFO DetBoxF100;
extern BOX_INFO DetBoxF101;
extern BOX_INFO DetBoxF110;
extern BOX_INFO DetBoxF111;

extern volatile unsigned int	DetCntFxx[2][8];

extern volatile unsigned int 	HWCntFxx[2][8]   ;
extern volatile unsigned int 	buf_num_Fxx[2][8];


extern void A4_RecgEng_Init(void);


extern void A4_VDPDUpEndInt_Callback(void);

extern void ncDrv_A4_WriteRecgTable_FX(unsigned int FilterSel);

extern void ncDrv_A4_ReadRecgTable_FX(void);

#endif

