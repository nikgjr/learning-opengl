#include <stdio.h>

#include "LD_Lib.h"

#define LANE_POINT_CNT 14

static const signed char A_T[16] = { 1, 0, 0, 0,
	0, 1, 0, 0,
	1, 0, 1, 0,
	0, 1, 0, 1 };

double S[4];
double a21;
int r1;
static const signed char A[16] = { 1, 0, 1, 0,
	0, 1, 0, 1,
	0, 0, 1, 0,
	0, 0, 0, 1 };

double a22;
static const signed char H_T[8] = { 1, 0, 0, 1,
	0, 0, 0, 0 };

double B[12];
static const short R[4] = { 10, 0,
	0, 10 };

static const signed char H[8] = { 3, 0, 0, 0,
	0, 3, 0, 0 };


//===============================================================================

void kalmanfilter(const double z[2], double y[2], double x_est[4], double p_est[16])
{
	signed char Q[16];
	int r2;
	double a[16];
	int k;
	double p_prd[16];
	double x_prd[4];
	int i0;
	double b_a[8];


	double b_z[2];
	double klm_gain[8];

	/*    Copyright 2010 The MathWorks, Inc. */
	/*  Initialize state transition matrix */
	/*      % [x  ] */
	/*      % [y  ] */
	/*      % [Vx] */
	/*      % [Vy] */
	/*  Initialize measurement matrix */
	for (r2 = 0; r2 < 16; r2++) {
		Q[r2] = 0;
	}

	/*  Initial state conditions */
	/*  Predicted state and covariance */
	for (k = 0; k < 4; k++) {
		Q[k + 4 * k] = 1;
		x_prd[k] = 0.0;
		for (r2 = 0; r2 < 4; r2++) {
			x_prd[k] += (double)A_T[k + 4 * r2] * x_est[r2];
			a[k + 4 * r2] = 0.0;
			for (i0 = 0; i0 < 4; i0++) {
				a[k + 4 * r2] += (double)A_T[k + 4 * i0] * p_est[i0 + 4 * r2];
			}
		}
	}

	for (r2 = 0; r2 < 4; r2++) {
		for (i0 = 0; i0 < 4; i0++) {
			a21 = 0.0;
			for (r1 = 0; r1 < 4; r1++) {
				a21 += a[r2 + 4 * r1] * (double)A[r1 + 4 * i0];
			}

			p_prd[r2 + 4 * i0] = a21 + (double)Q[r2 + 4 * i0];
		}
	}

	/*  Estimation */
	for (r2 = 0; r2 < 2; r2++) {
		for (i0 = 0; i0 < 4; i0++) {
			b_a[r2 + (i0 << 1)] = 0.0;
			for (r1 = 0; r1 < 4; r1++) {
				b_a[r2 + (i0 << 1)] += (double)H_T[r2 + (r1 << 1)] * p_prd[i0 + 4 * r1];
			}
		}

		for (i0 = 0; i0 < 2; i0++) {
			a21 = 0.0;
			for (r1 = 0; r1 < 4; r1++) {
				a21 += b_a[r2 + (r1 << 1)] * (double)H[r1 + 4 * i0];
			}

			S[r2 + (i0 << 1)] = a21 + (double)R[r2 + (i0 << 1)];
		}

		for (i0 = 0; i0 < 4; i0++) {
			B[r2 + (i0 << 1)] = 0.0;
			for (r1 = 0; r1 < 4; r1++) {
				B[r2 + (i0 << 1)] += (double)H_T[r2 + (r1 << 1)] * p_prd[i0 + 4 * r1];
			}
		}
	}

	if (fabs(S[1]) > fabs(S[0])) {
		r1 = 1;
		r2 = 0;
	}
	else {
		r1 = 0;
		r2 = 1;
	}

	a21 = S[r2] / S[r1];
	a22 = S[2 + r2] - a21 * S[2 + r1];
	for (k = 0; k < 4; k++) {
		b_a[1 + (k << 1)] = (B[r2 + (k << 1)] - B[r1 + (k << 1)] * a21) / a22;
		b_a[k << 1] = (B[r1 + (k << 1)] - b_a[1 + (k << 1)] * S[2 + r1]) / S[r1];
	}

	/*  Estimated state and covariance */
	for (r2 = 0; r2 < 2; r2++) {
		a21 = 0.0;
		for (i0 = 0; i0 < 4; i0++) {
			klm_gain[i0 + 4 * r2] = b_a[r2 + (i0 << 1)];
			a21 += (double)H_T[r2 + (i0 << 1)] * x_prd[i0];
		}

		b_z[r2] = z[r2] - a21;
	}

	for (r2 = 0; r2 < 4; r2++) {
		a21 = 0.0;
		for (i0 = 0; i0 < 2; i0++) {
			a21 += klm_gain[r2 + 4 * i0] * b_z[i0];
		}

		x_est[r2] = x_prd[r2] + a21;
		for (i0 = 0; i0 < 4; i0++) {
			a[r2 + 4 * i0] = 0.0;
			for (r1 = 0; r1 < 2; r1++) {
				a[r2 + 4 * i0] += klm_gain[r2 + 4 * r1] * (double)H_T[r1 + (i0 << 1)];
			}
		}

		for (i0 = 0; i0 < 4; i0++) {
			a21 = 0.0;
			for (r1 = 0; r1 < 4; r1++) {
				a21 += a[r2 + 4 * r1] * p_prd[r1 + 4 * i0];
			}

			p_est[r2 + 4 * i0] = p_prd[r2 + 4 * i0] - a21;
		}
	}

	/*  Compute the estimated measurements */
	for (r2 = 0; r2 < 2; r2++) {
		y[r2] = 0.0;
		for (i0 = 0; i0 < 4; i0++) {
			y[r2] += (double)H_T[r2 + (i0 << 1)] * x_est[i0];
		}
	}
	/*  of the function */
}


//================================================================================================
void KalmanFiltering(ORG_LANE_REGISTER *Left_lane, int Cnt, int m)
{
	int i, j, temp;
	static double x_est_L[7][4] = { 0, };
	static double p_est_L[7][16] = { 0, };
	double Lane_temp[2] = { 0, }, Lane_dest[2] = { 0, };

	temp = 0;
	for (i = 0; i < Cnt; i++)
	{
		//memset(x_est_L[i], 0, sizeof(double) * 4);
		//memset(p_est_L[i], 0, sizeof(double) * 16);

		x_est_L[i][0] = Left_lane[m].orgLane[i].x;
		x_est_L[i][1] = Left_lane[m].orgLane[i].y;
	}

	for (i=0, temp = 0; i < Cnt; i++, temp++)
	{
		Lane_temp[0] = Left_lane[m].orgLane[i].x;
		Lane_temp[1] = Left_lane[m].orgLane[i].y;
		kalmanfilter(Lane_temp, Lane_dest, x_est_L[temp], p_est_L[temp]);
		Left_lane[m].orgLane[i].x = Lane_dest[0];
		Left_lane[m].orgLane[i].y = Lane_dest[1];
	}

	for (i = 1, j = 0; i < 7; i += 2, j += 2)		//20160720
	{
		if (Left_lane[m].orgLane[i].x < 0)							Left_lane[m].orgLane[i].x = 0;
		else if (Left_lane[m].orgLane[i].x > LD_IMG_WIDTH - 1)		Left_lane[m].orgLane[i].x = LD_IMG_WIDTH - 1;

		if (Left_lane[m].orgLane[i].y < 0)							Left_lane[m].orgLane[i].y = 0;
		else if (Left_lane[m].orgLane[i].y > LD_IMG_HEIGHT - 1)		Left_lane[m].orgLane[i].y = LD_IMG_HEIGHT - 1;
	}
}

