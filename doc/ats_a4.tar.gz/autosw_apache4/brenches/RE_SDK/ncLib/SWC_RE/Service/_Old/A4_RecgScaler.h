#include "common.h"
#ifndef	_A4_RECG_SCALER_H_
#define	_A4_RECG_SCALER_H_


//extern volatile unsigned int ScalerStartOn;

extern unsigned char A4_RecgScaler_Test(void);
extern void A4_RecgScaler_Init (void);

extern volatile unsigned int 	VomBuffChCnt;

#endif
