/*#---------------------------------------------------------------------
#
# Copyright Processor Group, 2006-2016, All rights reserved.
# Processor Group, System-on-Chip Research Department
# Electronics and Telecommunications Research Institute (ETRI)
#
# THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE
# WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS
# TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE
# REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL
# SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE,
# IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE
# COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
#
#
#------------------------------------------------------------------------*/
#include "common.h"
#include "A4_AdasIp.h"
#include "A4_Mod.h"

//extern void ab_vim_isr_test(void);
PrVoid ncDrv_MOD_UserHandler = NULL;

volatile MODValue ModLine;

volatile MOD_RESULT_0 ModOut0[2][META_MOD_CNT_MAX];
volatile MOD_RESULT_1 ModOut1[2][META_MOD_CNT_MAX];
volatile unsigned int Mod_baseAddr[2] = {0x2901000,0x2901000};
volatile unsigned int	ModReadCnt = 0, DetCntMod[2] = {0, 0};
/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

//--------------------------------------------------------------------------------------------------------------

unsigned int A4_MOD_Result(void)
{
	MOD_RESULT_0	ModData_0;
	MOD_RESULT_1	ModData_1;
	unsigned int	ModResultQCnt, i, u32Tmp, k,j,temp ,tmp, buffsel;
	MOD_UV_ORG		org_v, org_u;
	MOD_NCC_ORG		org_ncc;
	int 			mod_v, mod_u, mod_ncc, mod_v_temp;
	int 			mod_x, mod_y;
	unsigned int	DisY, Overflow;
	volatile static unsigned int TestCnt=0;
	//unsigned int	BuffSelMod = AdasStatus.Reg.WrBufSelMod;
	unsigned int    TmpDisCntMod = DetCntMod[AdasStatus.Reg.RdBufSelMod];
	unsigned int	SaveCnt=0;
	unsigned int	tmepcnt = 0;
	MOD_RESULT_0	*p_ModData_0;
	MOD_RESULT_1	*p_ModData_1;
	MOD_RESULT_1	temp_ModData_0;
	MOD_RESULT_1	temp_ModData_1;
	int img_width, img_height;

	img_width  = (int)adas_size.width_0;
	img_height = (int)adas_size.height_0;



	buffsel = AdasStatus.Reg.RdBufSelMod;
	if(TmpDisCntMod == 1279)
	{
		TmpDisCntMod = 0;
	}
	p_ModData_0 = (MOD_RESULT_0 *)(Mod_baseAddr[buffsel]);
	p_ModData_1 = (MOD_RESULT_1 *)(Mod_baseAddr[buffsel] + 0x04);
	for(i=0; i<TmpDisCntMod; i++)
	{
		ModData_0.Data32 = 0;
		ModData_1.Data32 = 0;

		temp_ModData_0.Data32 = p_ModData_0->Data32;
		ModData_0.D8.Data0 = temp_ModData_0.D8.Data3;
		ModData_0.D8.Data1 = temp_ModData_0.D8.Data2;
		ModData_0.D8.Data2 = temp_ModData_0.D8.Data1;
		ModData_0.D8.Data3 = temp_ModData_0.D8.Data0;

		temp_ModData_1.Data32 = p_ModData_1->Data32;
		ModData_1.D8.Data0 = temp_ModData_1.D8.Data3;
		ModData_1.D8.Data1 = temp_ModData_1.D8.Data2;
		ModData_1.D8.Data2 = temp_ModData_1.D8.Data1;
		ModData_1.D8.Data3 = temp_ModData_1.D8.Data0;


		mod_y = (int)(ModData_0.Reg.mod_y);
		mod_x = (int)(ModData_0.Reg.mod_x);

		/*
		if(mod_y < 50 || mod_y>150)
		{
			p_ModData_0+=2;
			p_ModData_1+=2;
			continue;
		}*/
		org_v.Reg.int_0 = ModData_0.Reg.mod_v_int;
		org_u.Reg.int_0 = ModData_0.Reg.mod_u_int;

		org_v.Reg.f_2   = ModData_1.Reg.mod_v_float >> 2;
		org_v.Reg.f_1   = ModData_1.Reg.mod_v_float >> 1;
		org_v.Reg.f_0   = ModData_1.Reg.mod_v_float;


		org_u.Reg.f_2   = ModData_1.Reg.mod_u_float >> 2;
		org_u.Reg.f_1   = ModData_1.Reg.mod_u_float >> 1;
		org_u.Reg.f_0   = ModData_1.Reg.mod_u_float;
		//if(org_v.Reg.f_2 !=0 |org_v.Reg.f_1 !=0 |org_v.Reg.f_0 !=0 |org_u.Reg.f_2 !=0 |org_u.Reg.f_1 !=0 |org_u.Reg.f_0 !=0 )
		//JIGMSG("%12x %12x %12x %12x %12x %12x \n",org_v.Reg.f_2,org_v.Reg.f_1,org_v.Reg.f_0,org_u.Reg.f_2,org_u.Reg.f_1,org_u.Reg.f_0);

		org_ncc.Data32 = (int)ModData_1.Reg.mod_ncc;

		if(org_v.Reg.int_0 == 0x0020)	{
			mod_v = 0;

			//JIGMSG("%d    %d V\n",mod_x,mod_y);
		}
		else							mod_v = ModData_0.Reg.mod_v_int;

		/*
		if((ModData_0.Reg.mod_u_int & 0x001F) != 0)
		{
			JIGMSG("U %x\n",ModData_0.Reg.mod_u_int);
		}*/
		if(org_v.Reg.int_0 & 0x0020)
		{
			mod_v = mod_v * 1000 - 500 * org_v.Reg.f_2 - 250 * org_v.Reg.f_1 - 125 * org_v.Reg.f_0;

		}
		else
		{
			mod_v = mod_v * 1000 + 500 * org_v.Reg.f_2 + 250 * org_v.Reg.f_1 + 125 * org_v.Reg.f_0;
		}



		if(org_u.Reg.int_0 == 0x0020)	{
			mod_u = 0;
		}
		else							mod_u = ModData_0.Reg.mod_u_int;

		if(org_u.Reg.int_0 & 0x0020)
		{
			mod_u = 1000 * mod_u - 500 * org_u.Reg.f_2 - 250*org_u.Reg.f_1 - 125*org_u.Reg.f_0;

		}
		else
		{
			mod_u = 1000 * mod_u + 500 * org_u.Reg.f_2 + 250*org_u.Reg.f_1 + 125*org_u.Reg.f_0;
		}

		#ifdef	_MOD_NCC_ON
			mod_ncc = org_ncc.Reg.f_5*500000 + org_ncc.Reg.f_4*250000 + org_ncc.Reg.f_3*125000 +
					org_ncc.Reg.f_2*62500 + org_ncc.Reg.f_1*31250 + org_ncc.Reg.f_0*15625;
			//if(i<4)	printf("%d=%f\n", i, mod_ncc);
		#else
			mod_ncc = 0;
		#endif
		//sprintf( DisString, "%01d %01d %01d %01d %01d %01d", org_v.Reg.f_2, org_v.Reg.f_1, org_v.Reg.f_0, org_u.Reg.f_2, org_u.Reg.f_1, org_u.Reg.f_0);
		//APP_Display_Charactor2(pCurDatabuf, DisString, 5, 10+16*1);


	#if 1	// 320 x 240
			mod_y = mod_y * 2; // 240 --> 480
			mod_x = mod_x * 2; // 320 --> 640
			mod_u = mod_u * 2; // 240 --> 480
			mod_v = mod_v * 2; // 320 --> 640
	#else	// 640 x 480
	#endif

		Overflow = 0;

		if(mod_x >= img_width)
		{
			Overflow = 1;
		}
		else if((mod_u < -31000) || (mod_u > 31000))
		{
			Overflow = 2;
		}
		else if((int)mod_x * 1000 + (int)mod_u >= img_width * 1000)
		{
			mod_u = (img_width - mod_x - 1)*1000;
		}
		else if((int)mod_x*1000 + (int)mod_u < 0)
		{
			if(mod_x > 0)	mod_u = -mod_x * 1000;
			else			mod_u = 0;
		}

		if(mod_y >= img_height)
		{
			Overflow = 3;
		}
		else if((mod_v < -310000) || (mod_v > 310000))
		{
			Overflow = 4;
		}
		else if((int)mod_y * 1000 + (int)mod_v >= img_height * 1000)
		{
			mod_v = (img_height - mod_y - 1)*1000;
		}
		else if((int)mod_y*1000 + (int)mod_v < 0)
		{
			if(mod_y > 0)	mod_v = -mod_y*1000;
			else 			mod_v = 0;
		}

		if(Overflow == 0)
		{

			//if(mod_ncc > 0){
				ModLine.ModVal[SaveCnt].x	  = (float)mod_x;
				ModLine.ModVal[SaveCnt].y	  = (float)mod_y;
				ModLine.ModVal[SaveCnt].width = (float)mod_u/1000.0;
				ModLine.ModVal[SaveCnt].height= (float)mod_v/1000.0;
				ModLine.ModNcc[SaveCnt]		  = (float)mod_ncc/1000000.0;

				//if(sA4StatusRegister.Reg.status_flag01 == 1)
				/*if(SaveCnt >20 && SaveCnt < 30)
				JIGMSG("%d  _%d   =   %d    %d     %d    %d \n",
						rA4RecgScalerRegister->Reg.FM0_WBUF_CNT,SaveCnt,i,mod_x,mod_y,mod_u,mod_v);
*/
				//}

				SaveCnt++;
			//}


		}
		else
		{
			JIGMSG("M_E=%d", Overflow);
		}
		p_ModData_0+=2;
		p_ModData_1+=2;

		tmepcnt++;
	}


	return SaveCnt;
}

#if 0
//--------------------------------------------------------------------------------------------------------------
void A4_MODEndInt_Callback(void)
{
	MOD_RESULT_0	ModData_0;
	MOD_RESULT_1	ModData_1;
	unsigned int	ModResultQCnt, i, u32Tmp;
	float 			mod_v, mod_u;
	int 			mod_x, mod_y;
	unsigned int	DisY, Overflow;
	unsigned int	BuffSelMod = AdasStatus.Reg.WrBufSelMod;

	ModResultQCnt = sReModReg->Reg.MOD_RESQ_W_CNT;
	if(ModResultQCnt > META_MOD_CNT_MAX-1)	ModResultQCnt = META_MOD_CNT_MAX-1;

	for(i=ModReadCnt; i<ModResultQCnt; i++)
	{
		ModOut0[BuffSelMod][i].Data32 = sReModReg->Reg.ModResult_0[i].Data32;
		ModOut1[BuffSelMod][i].Data32 = sReModReg->Reg.ModResult_1[i].Data32;
	}
	ModReadCnt = ModResultQCnt;

	DetCntMod[AdasStatus.Reg.WrBufSelMod] = ModResultQCnt;
}
#endif

void ncDrv_MOD_ISR_Handler(void);
void ncDrv_MOD_IRQ_Handler(void *param)
{
    ncDrv_MOD_ISR_Handler();

    /*
    * User Handler Call Back Function
    */
    if(ncDrv_MOD_UserHandler != NULL)
    {
        ncDrv_MOD_UserHandler();
    }
}

//--------------------------------------------------------------------------------------------------------------
//#define	_MOD_DIS_INT_END
void A4_MODStartInt_Callback(void)
{
	ModReadCnt = 0;

	#ifndef	_MOD_DIS_INT_END
		AdasStatus.Reg.RdBufSelMod = AdasStatus.Reg.WrBufSelMod;
		AdasStatus.Reg.WrBufSelMod = ~AdasStatus.Reg.WrBufSelMod;
		AdasStatus.Reg.ModStartOn = 1;
	#endif
}


//--------------------------------------------------------------------------------------------------------------
int 	mod_int_test;
volatile unsigned int ModIntOn = 0;
extern volatile unsigned int StatusDL0, StatusDL1, StatusDL2;
void ncDrv_MOD_ISR_Handler(void)
{
	int i, tmp;
	volatile static unsigned int ModStartIntOn=0;
	static int state = 0;

	//--------------------------------------------------------------------------------------------------------
	if(sReModReg->Reg.MOD_INT_OF_START_FLAG)
	{
		sReModReg->Reg.MOD_INT_CLR_OF_START = 1;
		sReModReg->Reg.MOD_INT_CLR_OF_START = 0;

		ModStartIntOn = 1;

		A4_MODStartInt_Callback();
#ifdef	_MOD_INT_G11_ON
	Gpio_Set(11, GPIO_HIGH);
#endif

		if(ModIntOn)
		{
			//JIGMSG("x=%04x, y=%04x, u=%x, v=%x, c=%d\n", StatusDL0>>16, StatusDL0&0x0000FFFF, StatusDL1<<16, StatusDL1&0x0000FFFF, StatusDL2);
		}
		ModIntOn = 1;
		//JIGMSG( "OS\n");
	}
	else if(sReModReg->Reg.MOD_INT_OF_BUFFER_FULL_FLAG)
	{
		sReModReg->Reg.MOD_INT_CLR_FP_BUFFER_F = 1;
		sReModReg->Reg.MOD_INT_CLR_FP_BUFFER_F = 0;

//		A4_MODEndInt_Callback();


	//	DetCntMod[AdasStatus.Reg.WrBufSelMod] = sReModReg->Reg.MOD_AXI_W_MAX_CNT;
		/*if(ModStartIntOn)
		{
			ModStartIntOn = 0;
		}*/
		//DetCntMod[AdasStatus.Reg.WrBufSelMod] = ModReadCnt;
		//JIGMSG( "OF\n");
	}
	else if(sReModReg->Reg.MOD_INT_OF_END_R_FLAG)
	{
		sReModReg->Reg.MOD_INT_CLR_OF_END_R = 1;
		sReModReg->Reg.MOD_INT_CLR_OF_END_R = 0;


#ifdef	_MOD_INT_G11_ON
	Gpio_Set(11, GPIO_LOW);
#endif

		//JIGMSG( "END!!!!!\n");
		if(ModStartIntOn)
		{
			ModStartIntOn = 0;
			DetCntMod[AdasStatus.Reg.WrBufSelMod] 	 = sReModReg->Reg.MOD_AXI_W_MAX_CNT;
			Mod_baseAddr[AdasStatus.Reg.WrBufSelMod] = sReModReg->Reg.MOD_AXI_W_BASE_ADDR;
		}


		//JIGMSG( "OE\n");
	}
	else if(sReModReg->Reg.MOD_INT_PSEUDO_END_R_FLAG)
	{
		sReModReg->Reg.MOD_INT_CLR_PSEUDO_END_R = 1;
		sReModReg->Reg.MOD_INT_CLR_PSEUDO_END_R = 0;
		JIGMSG("M_SUDO\n");
		if(ModStartIntOn)
		{
			ModStartIntOn = 0;

			DetCntMod[AdasStatus.Reg.WrBufSelMod] = 	sReModReg->Reg.MOD_AXI_W_MAX_CNT;
			Mod_baseAddr[AdasStatus.Reg.WrBufSelMod] = 	sReModReg->Reg.MOD_AXI_W_BASE_ADDR;

		}
		//JIGMSG( "OP\n");
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	else if(sReModReg->Reg.MOD_INT_FP_START_FLAG)
	{
		sReModReg->Reg.MOD_INT_CLR_FP_START = 1;
		sReModReg->Reg.MOD_INT_CLR_FP_START = 0;


#ifdef	_MOD_INT_G11_ON
	Gpio_Set(11, GPIO_HIGH);
#endif

		ModReadCnt = 0; //	A4_MODStartInt_Callback();

		if(ModIntOn)
		{
			JIGMSG("x=%04x, y=%04x, u=%x, v=%x, c=%d\n", StatusDL0>>16, StatusDL0&0x0000FFFF, StatusDL1<<16, StatusDL1&0x0000FFFF, StatusDL2);
		}
		ModIntOn = 1;
	    //JIGMSG( "FS\n");
	}
	else if(sReModReg->Reg.MOD_INT_FP_BUFFER_FULL_FLAG)
	{
		sReModReg->Reg.MOD_INT_CLR_FP_BUFFER_F = 1;
		sReModReg->Reg.MOD_INT_CLR_FP_BUFFER_F = 0;

		//JIGMSG( "FF\n");
	}
	else if(sReModReg->Reg.MOD_INT_FP_END_R_FLAG)
	{
		sReModReg->Reg.MOD_INT_CLR_FP_END_R = 1;
		sReModReg->Reg.MOD_INT_CLR_FP_END_R = 0;

		DetCntMod[AdasStatus.Reg.WrBufSelMod] = ModReadCnt;


#ifdef	_MOD_INT_G11_ON
	Gpio_Set(11, GPIO_LOW);
#endif
		AdasStatus.Reg.ModStartOn = 1;

		//JIGMSG( "FE\n");
	}

	//sReModReg->Data[0x4C/4] = 0xFFFFFFFF;
	//sReModReg->Data[0x4C/4] = 0x00000000;

    //Clear IFR of IRQ1 (INTC's IFR turn-off)
    //abbd_intc_core_ifr_off(MOD_CORE_IRQ);
}

//---------------------------------------------------------------------------------------------------------------------
void A4_Mod_Init(void)
{
	int i, j, grid_x_num, grid_y_num;
return;
    sReModReg->Reg.MOD_EN_0 = 0;  // fp
	sReModReg->Reg.MOD_EN_1 = 0;  // of
	// mod image start address

	sReModReg->Reg.MOD_INT_EN_FP_START 	= 0;
	sReModReg->Reg.MOD_INT_EN_FP_BUFFER_F 	= 0;
	sReModReg->Reg.MOD_INT_EN_FP_END_R 	= 0;

	sReModReg->Reg.MOD_INT_EN_OF_START 	= 0;
	sReModReg->Reg.MOD_INT_EN_OF_BUFFER_F 	= 0;
	sReModReg->Reg.MOD_INT_EN_OF_END_R 	= 0;
	sReModReg->Reg.MOD_INT_EN_PSEUDO_END_R	= 0;

	sReModReg->Reg.MOD_BASE_ADDR_LV0 = FM12_START_ADDR;	//	80  x 45 image start address
	sReModReg->Reg.MOD_BASE_ADDR_LV1 = FMc_START_ADDR;		//	160 x 90 image start address
	sReModReg->Reg.MOD_BASE_ADDR_LV2 = FM6_START_ADDR;		//	320 x 180 image start address

	sReModReg->Reg.MOD_ROI_MODE_SELECT = 0;    // ROI 0 | ROI 1
	sReModReg->Reg.MOD_FP_RESOLUTION = 1;
	sReModReg->Reg.MOD_VECTOR_LENGTH = 20;
	sReModReg->Reg.MOD_FP_THRESHOLD = 200;
	sReModReg->Reg.MOD_RD_IRQ_BOUNDARY = 63;	// [24]IRQ_BOUNDARY = 8-1

	sReModReg->Reg.MOD_FRC_M_EN_LV0 = 0;
	sReModReg->Reg.MOD_FRC_M_EN_LV1 = 0;
	sReModReg->Reg.MOD_FRC_M_EN_LV2 = 0;
	sReModReg->Reg.MOD_MAX_PYR_LV = 2;

/*
	sReModReg->Reg.MOD_BUFFER_CNT_LV2		= 2;
	sReModReg->Reg.MOD_BUFFER_M_CNT_LV2_T1 = 2;
	sReModReg->Reg.MOD_BUFFER_M_CNT_LV2_T0 = 2;
	sReModReg->Reg.MOD_BUFFER_CNT_LV1		= 2;
	sReModReg->Reg.MOD_BUFFER_M_CNT_LV1_T1 = 2;
	sReModReg->Reg.MOD_BUFFER_M_CNT_LV1_T0 = 2;
	sReModReg->Reg.MOD_BUFFER_CNT_LV0		= 2;
	sReModReg->Reg.MOD_BUFFER_M_CNT_LV0_T1 = 2;
	sReModReg->Reg.MOD_BUFFER_M_CNT_LV0_T0 = 2;*/

	#ifdef	_INT_PULSE_ON
		sReModReg->Reg.MOD_INT_PULSE_EN = 1;
	#else
		sReModReg->Reg.MOD_INT_PULSE_EN = 1;
	#endif

#if 0
	sReModReg->Reg.MOD_FP_IMG_WIDTH = 320;
	sReModReg->Reg.MOD_FP_IMG_HEIGHT = 0;///////�썝�옒 180

	sReModReg->Reg.MOD_IMG_SIZE_LV0 = 3600;	// IMG_SIZE_LV0 = 3600
	sReModReg->Reg.MOD_IMG_SIZE_LV1 = 14400;	// IMG_SIZE_LV1 = 14400
	sReModReg->Reg.MOD_IMG_SIZE_LV2 = 57600;	// IMG_SIZE_LV2 = 57600

	sReModReg->Reg.MOD_IMG_WIDTH_LV0 = 80;
	sReModReg->Reg.MOD_IMG_HEIGHT_LV0 = 45;	// IMG_H_W_LV0 80 x 45

	sReModReg->Reg.MOD_IMG_WIDTH_LV1 = 160;
	sReModReg->Reg.MOD_IMG_HEIGHT_LV1 = 90;	// IMG_H_W_LV1 160 x 90

	sReModReg->Reg.MOD_IMG_WIDTH_LV2 = 320;
	sReModReg->Reg.MOD_IMG_HEIGHT_LV2 = 180;	// IMG_H_W_LV2 320 x 180

#else
	sReModReg->Reg.MOD_FP_IMG_WIDTH = adas_size.width_6;
	sReModReg->Reg.MOD_FP_IMG_HEIGHT =0; //adas_size.height_6;///////�썝�옒 180

	sReModReg->Reg.MOD_IMG_SIZE_LV0 = adas_size.width_12* adas_size.height_12;	// IMG_SIZE_LV0 = 3600
	sReModReg->Reg.MOD_IMG_SIZE_LV1 = adas_size.width_c * adas_size.height_c;	// IMG_SIZE_LV1 = 14400
	sReModReg->Reg.MOD_IMG_SIZE_LV2 = adas_size.width_6 * adas_size.height_6;	// IMG_SIZE_LV2 = 57600

	sReModReg->Reg.MOD_OF_IMG_WIDTH_LV0  = adas_size.width_12;
	sReModReg->Reg.MOD_OF_IMG_HEIGHT_LV0 = adas_size.height_12;	// IMG_H_W_LV0 80 x 45

	sReModReg->Reg.MOD_OF_IMG_WIDTH_LV1  = adas_size.width_c;
	sReModReg->Reg.MOD_OF_IMG_HEIGHT_LV1 = adas_size.height_c;	// IMG_H_W_LV1 160 x 90

	sReModReg->Reg.MOD_OF_IMG_WIDTH_LV2  = adas_size.width_6;
	sReModReg->Reg.MOD_OF_IMG_HEIGHT_LV2 = adas_size.height_6;	// IMG_H_W_LV2 320 x 180
#endif


	sReModReg->Reg.MOD_MANUAL_FP_WEN = 0;

	sReModReg->Reg.MOD_MANUAL_MODE = 0;
	sReModReg->Reg.MOD_MANUAL_START_EN = 0;
	sReModReg->Reg.MOD_MANUAL_MAX_FP = 0;		// [0]M_STR_EN=0, [2:1]M_MODE=0, [13:3]M_MAX_FP=0

	sReModReg->Data[0x004C/4] = 0xFFFFFFFF;
	sReModReg->Data[0x004C/4] = 0x00000000;	// CLR ALL INT

	sReModReg->Reg.MOD_FRAME_SKIP = 0;
	sReModReg->Reg.MOD_UV_MAX = 31;
	sReModReg->Reg.MOD_DIV_MAX = 40;

	sReModReg->Reg.MOD_PSEUDO_CNT = 0xFFFF;

	sReModReg->Reg.MOD_ROI0_x0 = 0;
	sReModReg->Reg.MOD_ROI0_y0 = 0;//56;
	sReModReg->Reg.MOD_ROI0_x1 = 319;
	sReModReg->Reg.MOD_ROI0_y1 = 170;

	sReModReg->Reg.MOD_AXI_W_BASE_ADDR0 = 0x89010000;//0x2900a4d0;
	sReModReg->Reg.MOD_AXI_W_BASE_ADDR1 = 0x89020000;//0x2901a4d0;



	sReModReg->Reg.MOD_EN_0 				= 0;
	sReModReg->Reg.MOD_EN_1 				= 0;
	sReModReg->Reg.MOD_NCC_EN 				= 0;
	sReModReg->Reg.MOD_INT_EN_OF_START 		= 0;
	sReModReg->Reg.MOD_INT_EN_OF_BUFFER_F 	= 0;
	sReModReg->Reg.MOD_INT_EN_OF_END_R 		= 0;
	sReModReg->Reg.MOD_INT_EN_PSEUDO_END_R 	= 0;


	grid_x_num = 20	;
	grid_y_num = 10;
	sReModReg->Reg.MOD_GRID_MAX = grid_x_num * grid_y_num;
	sReModReg->Reg.MOD_GRID_ADDR = 0;

	for(i = 0 ; i < grid_y_num ; i++)
	{
		for(j = 0 ; j < grid_x_num ; j++)
		{

			sReModReg->Reg.MOD_GRID_X = (unsigned int)(adas_size.width_6 / (grid_x_num) * (j) + adas_size.width_6/ 2 / grid_x_num );
			sReModReg->Reg.MOD_GRID_Y = (unsigned int)(adas_size.height_6 / (grid_y_num) * (i) + adas_size.height_6 / 2 / grid_y_num );
			//sReModReg->Reg.MOD_GRID_WEN = 1 ;
			sReModReg->Reg.MOD_GRID_WEN = 1;
			sReModReg->Reg.MOD_GRID_WEN = 0;
			sReModReg->Reg.MOD_GRID_ADDR += 1;
		}
	}
	sReModReg->Reg.MOD_GRID_MODE = 1	;


#ifdef	_MOD_INT_EN
	if( ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_RE_MOD, (PrHandler)ncDrv_MOD_IRQ_Handler, CMD_END) != NC_SUCCESS )
	{
		DEBUGMSG_SDK(MSGERR, "MOD_INIT ERROR\n");
	}
#endif

	JIGMSG("@@ MOD Init. done \n");

}
