#ifndef __RE_SCALER_REGISTER_H__
#define __RE_SCALER_REGISTER_H__

/*=============================================================================
	Definitions for Register Start Address, End Address, Size
=============================================================================*/
#define RE_SCALER_REGISTER_SIZE 			0x148

typedef union
{
	unsigned int Data[RE_SCALER_REGISTER_SIZE/4];
	struct
	{
		/*	0x0000	[00]	*/	unsigned int	RES_FM_BL			:	5	;
		/*	0x0000	[05]	*/	unsigned int	Rev0000_05			:	3	;
		/*	0x0000	[08]	*/	unsigned int	RES_W_BUFF_MODE_POST:	4	;
		/*	0x0000	[12]	*/	unsigned int	Rev0000_12			:	20	;

		/*	0x0004	[00]	*/	unsigned int	RES_FM0_Y_EN	:	1	;
		/*	0x0004	[01]	*/	unsigned int	Rev0004_01		:	3	;
		/*	0x0004	[04]	*/	unsigned int	RES_FM0_C_EN	:	1	;
		/*	0x0004	[05]	*/	unsigned int	Rev0004_05		:	3	;
		/*	0x0004	[08]	*/	unsigned int	RES_FM0_FRC_MODE:	3	;
		/*	0x0004	[11]	*/	unsigned int	Rev0004_11		:	21	;

		/*	0x0008	[00]	*/	unsigned int	RES_FM0_H_SIZE	:	10	;
		/*	0x0008	[10]	*/	unsigned int	Rev0008_10	:	6	;
		/*	0x0008	[16]	*/	unsigned int	RES_FM0_V_SIZE	:	10	;
		/*	0x0008	[26]	*/	unsigned int	Rev0008_26	:	6	;

		/*	0x000C	[00]	*/	unsigned int	RES_FM0_BASE_ADDR	:	32	;

		/*	0x0010	[00]	*/	unsigned int	RES_FM2_Y_EN	:	1	;
		/*	0x0010	[01]	*/	unsigned int	Rev0010_01	:	3	;
		/*	0x0010	[04]	*/	unsigned int	RES_FM2_C_EN	:	1	;
		/*	0x0010	[05]	*/	unsigned int	Rev0010_05	:	3	;
		/*	0x0010	[08]	*/	unsigned int	RES_FM2_FRC_MODE	:	3	;
		/*	0x0010	[11]	*/	unsigned int	Rev0010_11	:	21	;

		/*	0x0014	[00]	*/	unsigned int	RES_FM2_H_SIZE	:	10	;
		/*	0x0014	[10]	*/	unsigned int	Rev0014_10	:	6	;
		/*	0x0014	[16]	*/	unsigned int	RES_FM2_V_SIZE	:	10	;
		/*	0x0014	[26]	*/	unsigned int	Rev0014_26	:	6	;

		/*	0x0018	[00]	*/	unsigned int	RES_FM2_BASE_ADDR	:	32	;

		/*	0x001C	[00]	*/	unsigned int	RES_FM4_Y_EN	:	1	;
		/*	0x001C	[01]	*/	unsigned int	Rev001C_01	:	3	;
		/*	0x001C	[04]	*/	unsigned int	RES_FM4_C_EN	:	1	;
		/*	0x001C	[05]	*/	unsigned int	Rev001C_05	:	3	;
		/*	0x001C	[08]	*/	unsigned int	RES_FM4_FRC_MODE	:	3	;
		/*	0x001C	[11]	*/	unsigned int	Rev001C_11	:	21	;

		/*	0x0020	[00]	*/	unsigned int	RES_FM4_H_SIZE	:	10	;
		/*	0x0020	[10]	*/	unsigned int	Rev0020_10	:	6	;
		/*	0x0020	[16]	*/	unsigned int	RES_FM4_V_SIZE	:	10	;
		/*	0x0020	[26]	*/	unsigned int	Rev0020_26	:	6	;

		/*	0x0024	[00]	*/	unsigned int	RES_FM4_BASE_ADDR	:	32	;

		/*	0x0028	[00]	*/	unsigned int	RES_FM6_Y_EN	:	1	;
		/*	0x0028	[01]	*/	unsigned int	Rev0028_01	:	3	;
		/*	0x0028	[04]	*/	unsigned int	RES_FM6_C_EN	:	1	;
		/*	0x0028	[05]	*/	unsigned int	Rev0028_05	:	3	;
		/*	0x0028	[08]	*/	unsigned int	RES_FM6_FRC_MODE	:	3	;
		/*	0x0028	[11]	*/	unsigned int	Rev0028_11	:	21	;

		/*	0x002C	[00]	*/	unsigned int	RES_FM6_BASE_ADDR	:	32	;

		/*	0x0030	[00]	*/	unsigned int	RES_FMc_Y_EN	:	1	;
		/*	0x0030	[01]	*/	unsigned int	Rev0030_01	:	3	;
		/*	0x0030	[04]	*/	unsigned int	RES_FMc_C_EN	:	1	;
		/*	0x0030	[05]	*/	unsigned int	Rev0030_05	:	3	;
		/*	0x0030	[08]	*/	unsigned int	RES_FMc_FRC_MODE	:	3	;
		/*	0x0030	[11]	*/	unsigned int	Rev0030_11	:	21	;

		/*	0x0034	[00]	*/	unsigned int	RES_FMc_BASE_ADDR	:	32	;

		/*	0x0038	[00]	*/	unsigned int	RES_FMe_Y_EN	:	1	;
		/*	0x0038	[01]	*/	unsigned int	Rev0038_01	:	3	;
		/*	0x0038	[04]	*/	unsigned int	RES_FMe_C_EN	:	1	;
		/*	0x0038	[05]	*/	unsigned int	Rev0038_05	:	3	;
		/*	0x0038	[08]	*/	unsigned int	RES_FMe_FRC_MODE	:	3	;
		/*	0x0038	[11]	*/	unsigned int	Rev0038_11	:	21	;

		/*	0x003C	[00]	*/	unsigned int	RES_FMe_BASE_ADDR	:	32	;

		/*	0x0040	[00]	*/	unsigned int	RES_FM10_Y_EN	:	1	;
		/*	0x0040	[01]	*/	unsigned int	Rev0040_01	:	3	;
		/*	0x0040	[04]	*/	unsigned int	RES_FM10_C_EN	:	1	;
		/*	0x0040	[05]	*/	unsigned int	Rev0040_05	:	3	;
		/*	0x0040	[08]	*/	unsigned int	RES_FM10_FRC_MODE	:	3	;
		/*	0x0040	[11]	*/	unsigned int	Rev0040_11	:	21	;

		/*	0x0044	[00]	*/	unsigned int	RES_FM10_BASE_ADDR	:	32	;

		/*	0x0048	[00]	*/	unsigned int	RES_FM12_Y_EN	:	1	;
		/*	0x0048	[01]	*/	unsigned int	Rev0048_01	:	3	;
		/*	0x0048	[04]	*/	unsigned int	RES_FM12_C_EN	:	1	;
		/*	0x0048	[05]	*/	unsigned int	Rev0048_05	:	3	;
		/*	0x0048	[08]	*/	unsigned int	RES_FM12_FRC_MODE	:	3	;
		/*	0x0048	[11]	*/	unsigned int	Rev0048_11	:	21	;

		/*	0x004C	[00]	*/	unsigned int	RES_FM12_BASE_ADDR	:	32	;

		/*	0x0050	[00]	*/	unsigned int	RES_FM18_Y_EN	:	1	;
		/*	0x0050	[01]	*/	unsigned int	Rev0050_01	:	3	;
		/*	0x0050	[04]	*/	unsigned int	RES_FM18_C_EN	:	1	;
		/*	0x0050	[05]	*/	unsigned int	Rev0050_05	:	3	;
		/*	0x0050	[08]	*/	unsigned int	RES_FM18_FRC_MODE	:	3	;
		/*	0x0050	[11]	*/	unsigned int	Rev0050_11	:	21	;

		/*	0x0054	[00]	*/	unsigned int	RES_FM18_BASE_ADDR	:	32	;

		/*	0x0058	[00]	*/	unsigned int	Rev0058_00	:	32	;

		/*	0x005C	[00]	*/	unsigned int	Rev005C_00	:	32	;

		/*	0x0060	[00]	*/	unsigned int	Rev0060_00	:	32	;

		/*	0x0064	[00]	*/	unsigned int	RES_MOD_IMG_SEL	:	2	;
		/*	0x0064	[02]	*/	unsigned int	Rev0064_02	:	30	;

		/*	0x0068	[00]	*/	unsigned int	RES_START_INT_CLR	:	1	;
		/*	0x0068	[01]	*/	unsigned int	RES_END_INT_CLR	:	1	;
		/*	0x0068	[02]	*/	unsigned int	RES_PSEUDO_END_INT_CLR	:	1	;
		/*	0x0068	[03]	*/	unsigned int	RES_ERROR_INT_CLR	:	1	;
		/*	0x0068	[04]	*/	unsigned int	Rev0068_04	:	28	;

		/*	0x006C	[00]	*/	unsigned int	RES_START_INT_EN	:	1	;
		/*	0x006C	[01]	*/	unsigned int	RES_END_INT_EN	:	1	;
		/*	0x006C	[02]	*/	unsigned int	RES_PSEUDO_END_INT_EN	:	1	;
		/*	0x006C	[03]	*/	unsigned int	RES_ERROR_INT_EN	:	1	;
		/*	0x006C	[04]	*/	unsigned int	Rev006C_04	:	12	;
		/*	0x006C	[16]	*/	unsigned int	INT_PULSE_EN	:	1	;
		/*	0x006C	[17]	*/	unsigned int	Rev006C_17	:	15	;

		/*	0x0070	[00]	*/	unsigned int	RES_START	:	1	;
		/*	0x0070	[01]	*/	unsigned int	RES_END	:	1	;
		/*	0x0070	[02]	*/	unsigned int	Rev0070_02	:	1	;
		/*	0x0070	[03]	*/	unsigned int	RES_ERROR	:	1	;
		/*	0x0070	[04]	*/	unsigned int	Rev0070_04	:	4	;
		/*	0x0070	[08]	*/	unsigned int	RES_START_INT	:	1	;
		/*	0x0070	[09]	*/	unsigned int	RES_END_INT	:	1	;
		/*	0x0070	[10]	*/	unsigned int	RES_PSEUDO_END_INT	:	1	;
		/*	0x0070	[11]	*/	unsigned int	RES_ERROR_INT	:	1	;
		/*	0x0070	[12]	*/	unsigned int	Rev0070_12	:	20	;

		/*	0x0074	[00]	*/	unsigned int	FM0_H_TRUE	:	10	;
		/*	0x0074	[10]	*/	unsigned int	FM2_H_TRUE	:	10	;
		/*	0x0074	[20]	*/	unsigned int	FM4_H_TRUE	:	10	;
		/*	0x0074	[30]	*/	unsigned int	Rev0074_30	:	2	;

		/*	0x0078	[00]	*/	unsigned int	FM6_H_TRUE	:	10	;
		/*	0x0078	[10]	*/	unsigned int	FMc_H_TRUE	:	10	;
		/*	0x0078	[20]	*/	unsigned int	FMe_H_TRUE	:	10	;
		/*	0x0078	[30]	*/	unsigned int	Rev0078_30	:	2	;

		/*	0x007C	[00]	*/	unsigned int	FM10_H_TRUE	:	10	;
		/*	0x007C	[10]	*/	unsigned int	FM12_H_TRUE	:	10	;
		/*	0x007C	[20]	*/	unsigned int	FM18_H_TRUE	:	10	;
		/*	0x007C	[30]	*/	unsigned int	Rev007C_30	:	2	;

		/*	0x0080	[00]	*/	unsigned int	FM0_WBUF_CNT	:	3	;
		/*	0x0080	[03]	*/	unsigned int	Rev0080_03	:	1	;
		/*	0x0080	[04]	*/	unsigned int	FM2_WBUF_CNT	:	3	;
		/*	0x0080	[07]	*/	unsigned int	Rev0080_07	:	1	;
		/*	0x0080	[08]	*/	unsigned int	FM4_WBUF_CNT	:	3	;
		/*	0x0080	[11]	*/	unsigned int	Rev0080_11	:	1	;
		/*	0x0080	[12]	*/	unsigned int	FM6_WBUF_CNT	:	3	;
		/*	0x0080	[15]	*/	unsigned int	Rev0080_15	:	1	;
		/*	0x0080	[16]	*/	unsigned int	FMc_WBUF_CNT	:	3	;
		/*	0x0080	[19]	*/	unsigned int	Rev0080_19	:	1	;
		/*	0x0080	[20]	*/	unsigned int	FMe_WBUF_CNT	:	3	;
		/*	0x0080	[23]	*/	unsigned int	Rev0080_23	:	1	;
		/*	0x0080	[24]	*/	unsigned int	FM10_WBUF_CNT	:	3	;
		/*	0x0080	[27]	*/	unsigned int	Rev0080_27	:	1	;
		/*	0x0080	[28]	*/	unsigned int	FM12_WBUF_CNT	:	3	;
		/*	0x0080	[31]	*/	unsigned int	Rev0080_31	:	1	;

		/*	0x0084	[00]	*/	unsigned int	FM18_WBUF_CNT	:	3	;
		/*	0x0084	[03]	*/	unsigned int	Rev0084_03	:	29	;
		/*	0x0088	[00]	*/	unsigned int	FM0_BUFF_SIZE	:	20	;
		/*	0x0088	[20]	*/	unsigned int	Rev0088_20	:	12	;

		/*	0x008C	[00]	*/	unsigned int	FM6_BUFF_SIZE	:	20	;
		/*	0x008C	[20]	*/	unsigned int	Rev008C_20	:	12	;

		/*	0x0090	[00]	*/	unsigned int	FMc_BUFF_SIZE	:	20	;
		/*	0x0090	[20]	*/	unsigned int	Rev0090_20	:	12	;

		/*	0x0094	[00]	*/	unsigned int	FM12_BUFF_SIZE	:	20	;
		/*	0x0094	[20]	*/	unsigned int	Rev0094_20	:	12	;

		/*	0x0098	[00]	*/	unsigned int	FM18_BUFF_SIZE	:	20	;
		/*	0x0098	[20]	*/	unsigned int	Rev0098_20	:	12	;

		/*	0x009C	[00]	*/	unsigned int	FRAME_TOT_PIX_CNT;

		/*	0x00A0	[00]	*/	unsigned int	R_FRAME_TOT_PIX_CNT	:	24	;
		/*	0x00A0	[24]	*/	unsigned int	Rev00A0_24	:	8	;

		/*	0x00A4	[00]	*/	unsigned int	FRAME_SKIP_CNT	:	8	;
		/*	0x00A4	[08]	*/	unsigned int	Rev00A4_08	:	24	;

		/*	0x00A8	[00]	*/	unsigned int	PSEUDO_END_CNT	:	32	;

		/*	0x00AC	[00]	*/	unsigned int	FM0_Y_CKSUM	:	32	;

		/*	0x00B0	[00]	*/	unsigned int	FM0_C_CKSUM	:	32	;

		/*	0x00B4	[00]	*/	unsigned int	FM2_Y_CKSUM	:	32	;

		/*	0x00B8	[00]	*/	unsigned int	FM2_C_CKSUM	:	32	;

		/*	0x00BC	[00]	*/	unsigned int	FM4_Y_CKSUM	:	32	;

		/*	0x00C0	[00]	*/	unsigned int	FM4_C_CKSUM	:	32	;

		/*	0x00C4	[00]	*/	unsigned int	FM6_Y_CKSUM	:	32	;

		/*	0x00C8	[00]	*/	unsigned int	FM6_C_CKSUM	:	32	;

		/*	0x00CC	[00]	*/	unsigned int	FMc_Y_CKSUM	:	32	;

		/*	0x00D0	[00]	*/	unsigned int	FMc_C_CKSUM	:	32	;

		/*	0x00D4	[00]	*/	unsigned int	FMe_Y_CKSUM	:	32	;

		/*	0x00D8	[00]	*/	unsigned int	FMe_C_CKSUM	:	32	;

		/*	0x00DC	[00]	*/	unsigned int	FM10_Y_CKSUM	:	32	;

		/*	0x00E0	[00]	*/	unsigned int	FM10_C_CKSUM	:	32	;

		/*	0x00E4	[00]	*/	unsigned int	FM12_Y_CKSUM	:	32	;

		/*	0x00E8	[00]	*/	unsigned int	FM12_C_CKSUM	:	32	;

		/*	0x00EC	[00]	*/	unsigned int	FM18_Y_CKSUM	:	32	;


		/*	0x00F0	[00]	*/	unsigned int	FM18_C_CKSUM	:	32	;

		/*	0x00F4	[00]	*/	unsigned int	Rev00F4_00	:	32	;

		/*	0x00F8	[00]	*/	unsigned int	Rev00F8_00	:	32	;

		/*	0x00FC	[00]	*/	unsigned int	Rev00FC_00	:	32	;

		/*	0x0100	[00]	*/	unsigned int	RES_WIDE_FM0_Y_EN	:	1	;
		/*	0x0100	[01]	*/	unsigned int	Rev0100_01	:	3	;
		/*	0x0100	[04]	*/	unsigned int	RES_WIDE_FM0_C_EN	:	1	;
		/*	0x0100	[05]	*/	unsigned int	Rev0100_05	:	3	;
		/*	0x0100	[08]	*/	unsigned int	RES_WIDE_FM0_FRC_MODE	:	3	;
		/*	0x0100	[11]	*/	unsigned int	Rev0100_11	:	21	;

		/*	0x0104	[00]	*/	unsigned int	RES_WIDE_FM0_H_SIZE	:	12	;
		/*	0x0104	[12]	*/	unsigned int	Rev0104_12	:	4	;
		/*	0x0104	[16]	*/	unsigned int	RES_WIDE_FM0_V_SIZE	:	10	;
		/*	0x0104	[26]	*/	unsigned int	Rev0104_26	:	6	;

		/*	0x0108	[00]	*/	unsigned int	RES_WIDE_FM0_BASE_ADDR	:	32	;

		/*	0x010C	[00]	*/	unsigned int	RES_WIDE_FM2_Y_EN	:	1	;
		/*	0x010C	[01]	*/	unsigned int	Rev010C_01	:	3	;
		/*	0x010C	[04]	*/	unsigned int	RES_WIDE_FM2_C_EN	:	1	;
		/*	0x010C	[05]	*/	unsigned int	Rev010C_05	:	3	;
		/*	0x010C	[08]	*/	unsigned int	RES_WIDE_FM2_FRC_MODE	:	3	;
		/*	0x010C	[11]	*/	unsigned int	Rev010C_11	:	21	;

		/*	0x0110	[00]	*/	unsigned int	RES_WIDE_FM2_H_SIZE	:	12	;
		/*	0x0110	[12]	*/	unsigned int	Rev0110_12	:	4	;
		/*	0x0110	[16]	*/	unsigned int	RES_WIDE_FM2_V_SIZE	:	10	;
		/*	0x0110	[26]	*/	unsigned int	Rev0110_26	:	6	;

		/*	0x0114	[00]	*/	unsigned int	RES_WIDE_FM2_BASE_ADDR	:	32	;

		/*	0x0118	[00]	*/	unsigned int	RES_WIDE_FM4_Y_EN	:	1	;
		/*	0x0118	[01]	*/	unsigned int	Rev0118_01	:	3	;
		/*	0x0118	[04]	*/	unsigned int	RES_WIDE_FM4_C_EN	:	1	;
		/*	0x0118	[05]	*/	unsigned int	Rev0118_05	:	3	;
		/*	0x0118	[08]	*/	unsigned int	RES_WIDE_FM4_FRC_MODE	:	3	;
		/*	0x0118	[11]	*/	unsigned int	Rev0118_11	:	21	;

		/*	0x011C	[00]	*/	unsigned int	RES_WIDE_FM4_H_SIZE	:	12	;
		/*	0x011C	[12]	*/	unsigned int	Rev011C_12	:	4	;
		/*	0x011C	[16]	*/	unsigned int	RES_WIDE_FM4_V_SIZE	:	10	;
		/*	0x011C	[26]	*/	unsigned int	Rev011C_26	:	6	;

		/*	0x0120	[00]	*/	unsigned int	RES_WIDE_FM4_BASE_ADDR	:	32	;

		/*	0x0124	[00]	*/	unsigned int	WIDE_FM0_H_TRUE	:	12	;
		/*	0x0124	[12]	*/	unsigned int	Rev0124_12	:	4	;
		/*	0x0124	[16]	*/	unsigned int	WIDE_FM2_H_TRUE	:	12	;
		/*	0x0124	[28]	*/	unsigned int	Rev0124_28	:	4	;

		/*	0x0128	[00]	*/	unsigned int	WIDE_FM4_H_TRUE	:	12	;
		/*	0x0128	[12]	*/	unsigned int	Rev0128_12	:	20	;

		/*	0x012C	[00]	*/	unsigned int	WIDE_FM0_WBUF_CNT	:	3	;
		/*	0x012C	[03]	*/	unsigned int	Rev012C_03	:	1	;
		/*	0x012C	[04]	*/	unsigned int	WIDE_FM2_WBUF_CNT	:	3	;
		/*	0x012C	[07]	*/	unsigned int	Rev012C_07	:	1	;
		/*	0x012C	[08]	*/	unsigned int	WIDE_FM4_WBUF_CNT	:	3	;
		/*	0x012C	[11]	*/	unsigned int	Rev012C_11	:	21	;

		/*	0x0130	[00]	*/	unsigned int	WIDE_FM0_BUFF_SIZE	:	21	;
		/*	0x0130	[21]	*/	unsigned int	Rev0130_21	:	11	;

		/*	0x0134	[00]	*/	unsigned int	WIDE_FM0_Y_CKSUM	:	32	;

		/*	0x0138	[00]	*/	unsigned int	WIDE_FM0_C_CKSUM	:	32	;

		/*	0x013C	[00]	*/	unsigned int	WIDE_FM2_Y_CKSUM	:	32	;

		/*	0x0140	[00]	*/	unsigned int	WIDE_FM2_C_CKSUM	:	32	;

		/*	0x0144	[00]	*/	unsigned int	WIDE_FM4_Y_CKSUM	:	32	;

		/*	0x0148	[00]	*/	unsigned int	WIDE_FM4_C_CKSUM	:	32	;
	}Reg;
}RE_SCALER_REGISTER;

#endif


