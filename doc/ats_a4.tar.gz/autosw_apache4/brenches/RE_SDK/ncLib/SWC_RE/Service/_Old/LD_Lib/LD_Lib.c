#include "common.h"
#include "A4_AdasIp.h"
#include "A4_RecgScaler.h"
#include "A4_RecgEng.h"
#include "A4_HsvOp.h"
#include "A4_Mod.h"
#include "A4_LD.h"

#include "LD_Lib.h"

#ifdef __cplusplus
extern "C" {
#endif

	//unsigned char	Buf_candi[LD_IMG_WIDTH * LD_IMG_HEIGHT * 2];
	//unsigned char	Buf_TvEdge[LD_IMG_WIDTH * LD_IMG_HEIGHT * 2];
	//unsigned char	Buf_cluster[LD_IMG_WIDTH * LD_IMG_HEIGHT * 2];

	//unsigned char	Buf_tv_org[TV_IMG_WIDTH * TV_IMG_HEIGHT * 3];
	//unsigned char	Buf_out[LD_IMG_WIDTH * LD_IMG_HEIGHT * 2];

#ifdef _RUN_MFC
	unsigned char	Buf_tv_test[TV_IMG_WIDTH * TV_IMG_HEIGHT * 3];
#else
	//unsigned char 	LdpYbuf[LD_IMG_WIDTH * LD_IMG_HEIGHT];
	//unsigned char 	LdpCbbuf[LD_IMG_WIDTH * LD_IMG_HEIGHT / 4];
	//unsigned char 	LdpCrbuf[LD_IMG_WIDTH * LD_IMG_HEIGHT / 4];
#endif

#ifdef __cplusplus
}
#endif

void InitMemoryLd(void)
{

}

void ExitMemoryLd(void)
{
	#ifdef _RUN_MFC
		cvDestroyAllWindows();
	#endif
}

void LD_MemInit()
{
	InitMemoryLd();

}

void LD_MemRelease()
{
	ExitMemoryLd();
}


#ifdef _RUN_MFC
int __LD_FRAMEWORK(UINT32 param00, UINT32 param01, UINT32 param02, UINT32 param03,
				   UINT32 param04, UINT32 param05, UINT32 param06, UINT32 param07,
				   UINT8* src, UINT8* HsvSrc, UINT16* Left_lane, UINT16* Right_lane, UINT16* Left_lane1, UINT16* Right_lane1,
				   int PricipleX, int VanisingPointY, int VanisingPointX, int EndY,
				   int DiffTh, int YTh, int CbTh, int CrTh, int UTh, int VTh, int LaneDiff,
				   int test0,
				   unsigned char **LD_ptrArr_)
#else
void LD_Task(NCLD_LANE_REGISTER *sLaneReg, NCLD_REGISTER *sLdStatusReg)
#endif
{
	int i, j, iTmp, iTmp1, sumY;
	char Spline_ret = 0;
	char ret = 0;
	static int strDelayCnt = 15;

	if(strDelayCnt > 0)
	{
		strDelayCnt--;
		return;
	}


	//-------------------------------------------------------------------------
	LD_Init_Register(sLdStatusReg);

	LD_Img_Make_TopView_Table();

	LD_PreRead_Box();
	LD_Read_Box();
#if 1

	//LD_Calculate_meanY(Buf_cluster);
	//LD_Erasing_Box_0();
	//JIGMSG("0");
	//LD_Erasing_Box_1();
	//JIGMSG("1");
	//LD_Searching_Lane();
	//JIGMSG("2");
	//LD_Searching_Tracking_Lane();
	//LD_Draw_Lane();
	//JIGMSG("3");
	//LD_Image_Draw_Lane_On_Org(sLaneReg);
	//JIGMSG("4\n");



#endif


#ifdef _RUN_MFC
	cvWaitKey(20);
#endif

#ifdef _RUN_MFC
	return ret;
#endif
}

void ld_test_f(void)
{
	JIGMSG("0");
	//LD_Erasing_Box_1();
	JIGMSG("1");
	//LD_Searching_Lane();
	JIGMSG("2");
	//LD_Searching_Tracking_Lane();
	JIGMSG("3");
	//LD_Image_Draw_Lane_On_Org(sLaneReg);
	JIGMSG("4\n");
}


