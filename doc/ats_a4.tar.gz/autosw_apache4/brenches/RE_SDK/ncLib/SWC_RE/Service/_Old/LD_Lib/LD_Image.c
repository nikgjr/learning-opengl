#include "common.h"
#include "A4_AdasIp.h"
#include "A4_RecgScaler.h"
#include "A4_RecgEng.h"
#include "A4_HsvOp.h"
#include "A4_Mod.h"
#include "A4_LD.h"

#include <stdio.h>

#include "LD_Lib.h"
#include "EngFont_14.h"

#ifdef _RUN_MFC
unsigned char ColorTable[8][3]={
	{235, 128, 128},	// 0 white  // y, u, v
	{210, 146 ,16},		// 1 Yellow
	{170,  16, 166},	// 2 Cyan
	{145,  34, 54},		// 3 Green
	{107, 202, 202},	// 4 Magenta
	{82,  240, 90},		// 5 Red
	{41,  110, 240},	// 6 Blue
	{100, 128, 128}		// 7 black{16,  128, 128}		// 7 black
};
#else
unsigned char ColorTable[8][3]={
	{235, 128, 128},	// 0 white  // y, u, v
	{210,  16, 146},	// 1 Yellow
	{170, 166,  16},	// 2 Cyan
	{145,  54,  34},	// 3 Green
	{107, 202, 222},	// 4 Magenta
	{82,   90, 240},	// 5 Red
	{41,  240, 110},	// 6 Blue
	{100,  128, 128}		// 7 black{16,  128, 128}		// 7 black
};
#endif


float lengthTable[LD_IMG_HEIGHT];
TABLE_ORG2TV	TableOrg2TV[LD_IMG_HEIGHT];
TABLE_TV2ORG	TableTV2Org[TV_IMG_HEIGHT];

LD_REGISTER	LdReg;

unsigned int TotalTestFrameCnt = 0;
int svp_x = 0, AddDiffY[2] = {0, 0};

#define	COLOR_WHITE		0
#define	COLOR_YELLOW	1
#define	COLOR_CYAN		2
#define	COLOR_GREEN		3
#define	COLOR_MAGENTA	4
#define	COLOR_RED		5
#define	COLOR_BLUE		6
#define	COLOR_BLACK		7
#define	COLOR_MAX		8


#define CANDI_1_DIFF_TH_L		(int)(LdReg.REG.DiffTh+AddDiffY[0])	// 10
#define CANDI_1_DIFF_TH_R		(int)(LdReg.REG.DiffTh+AddDiffY[1])	// 10

#define CANDI_1_Y_TH			(int)LdReg.REG.YTh		// 20
#define CANDI_1_CB_TH			(int)LdReg.REG.CbTh		// 30
#define CANDI_1_CR_TH			(int)LdReg.REG.CrTh		// 25

#define CANDI_1_U_LEVEL_TH		(int)LdReg.REG.UTh		// 140
#define CANDI_1_V_LEVEL_TH		(int)LdReg.REG.VTh		// 140

#define LANE_DIFF_TH			(int)LdReg.REG.LaneDiff	// 10


//---------------------------------------------------------------------------------------------
#ifdef _RUN_MFC
void LD_Init_Register(int pp_x, int vp_y, int vp_x, int end_y,
					  int DiffTh, int YTh, int CbTh, int CrTh, int UTh, int VTh, int LaneDiff)//(LD_REGISTER InitReg)
#else
void LD_Init_Register(NCLD_REGISTER *sLdStatusReg)
#endif
{
#ifdef _RUN_MFC
//	LdReg.REG.PpX = pp_x;
	LdReg.REG.VpX = vp_x; // InitReg.REG.VpX;

	LdReg.REG.VpY = vp_y;//150; //InitReg.REG.VpY;
	LdReg.REG.EndY = end_y;//150; //InitReg.REG.VpY;

	LdReg.REG.YuvMode = 1; // 0 - Y, 1 - YUV420, 2 - YUV422
	LdReg.REG.ViewVStrEnd = 0;

	LdReg.REG.DiffTh = DiffTh;
	LdReg.REG.YTh = YTh;
	LdReg.REG.CbTh = CbTh;
	LdReg.REG.CrTh = CrTh;
	LdReg.REG.UTh = UTh;
	LdReg.REG.VTh = VTh;
	LdReg.REG.LaneDiff = LaneDiff;
#else
//	LdReg.REG.PpX = vp_x;
	sLdStatusReg->REG.VpX = sReLdReg->Reg.VP_X;
	sLdStatusReg->REG.VpY = sReLdReg->Reg.VP_Y;
	sLdStatusReg->REG.EndY = sReLdReg->Reg.LAST_Y;
	sLdStatusReg->REG.ViewVStrEnd = 0;
	sLdStatusReg->REG.BoxOverlap = sReLdReg->Reg.BLOCK_OVERLAP;

	LdReg.REG.VpX = sLdStatusReg->REG.VpX;//;
	LdReg.REG.VpY = sLdStatusReg->REG.VpY; // 150; //InitReg.REG.VpY;
	LdReg.REG.EndY = sLdStatusReg->REG.EndY;//  340; //InitReg.REG.VpY;

	LdReg.REG.YuvMode = 2; // 0 - Y, 1 - YUV420, 2 - YUV422
	LdReg.REG.ViewVStrEnd = sLdStatusReg->REG.ViewVStrEnd;

	LdReg.REG.DiffTh = sReLdReg->Reg.CANDI1_Y_DIFF_TH;
	LdReg.REG.YTh = sReLdReg->Reg.CANDI1_Y_TH;
	LdReg.REG.CbTh = sReLdReg->Reg.CANDI1_U_TH;
	LdReg.REG.CrTh = sReLdReg->Reg.CANDI1_V_TH;
	LdReg.REG.UTh = sReLdReg->Reg.CANDI1_U_LEVEL_TH;
	LdReg.REG.VTh = sReLdReg->Reg.CANDI1_V_LEVEL_TH;
	LdReg.REG.LaneDiff = sReLdReg->Reg.CANDI2_GAP;

#endif

	LdReg.REG.CamH = CAM_H;			//InitReg.REG.CamH;
	LdReg.REG.CamF = CAM_F;			//InitReg.REG.CamF;
	LdReg.REG.SenC = (10000*SEN_C);	// InitReg.REG.SenC;

//	LdReg.REG.LdImgWidth	= sReLdReg->Reg.LD_IMG_WIDTH; //InitReg.REG.LdImgWidth;
//	LdReg.REG.LdImgHeight	= sReLdReg->Reg.LD_IMG_HEIGHT; //InitReg.REG.LdImgHeight;

//	LdReg.REG.TvImgWidth	= sReLdReg->Reg.LD_IMG_WIDTH; //InitReg.REG.TvImgWidth;
//	LdReg.REG.TvImgHeight	= sReLdReg->Reg.LD_IMG_HEIGHT; //InitReg.REG.TvImgHeight;
}

//----------------------------------------------------------------------------------------------------
void Calculate_Point(int *pointX, int x1, int y1, int x2, int y2)
{
	int x, y=0, m;

	if(x1 >= LD_IMG_WIDTH)		return;
	if(x2 >= LD_IMG_WIDTH)		return;
	if(y1 >= LD_IMG_HEIGHT)		return;
	if(y2 >= LD_IMG_HEIGHT)		return;

	if (y1 > y2)
	{
		m = y1;
		y1 = y2;
		y2 = m;

		m = x1;
		x1 = x2;
		x2 = m;
	}

	//-------------------------------------------------------------------------
	if (x1 == x2)
	{
		for (y = y1; y <= y2; y++)
		{
			pointX[y] = x1;
		}
		return;
	}

	//-------------------------------------------------------------------------
	if((y2 - y1) > 0)
	{
		for (y = y1; y <= y2; y++)
		{
			x = x1 + (x2 - x1) * (y - y1) / (y2 - y1);
			pointX[y] = x;
		}
	}
	else
	{
		if (x1 > x2)
		{
			m = x1;
			x1 = x2;
			x2 = m;

			m = y1;
			y1 = y2;
			y2 = m;
		}

		for (x = x1; x <= x2; x++)
		{
			pointX[y] = x;
		}
	}
}

//---------------------------------------------------------------------------------------------
//#define _MAKE_FILE
void LD_Img_Make_TopView_Table(void)
{
	unsigned int uiTmp;
	int k, j, iTmp;

	float cam_h;
	float cam_f;
	float cam_i;
	float cam_pixel;

	float min_d;
	float first_d, second_d;
	float refGap;

	int   vCnt;
	float curGap;

	int NewVpX;

	//static int pp_x=0, vp_x=0, vp_y=0, yDesAddr;
	static int vp_x=0, vp_y=0, yDesAddr;
	static int vp_x_old=0xFFFF, vp_y_old=0xFFFF;
	static int InitCnt=0;

#ifdef _MAKE_FILE
	FILE *file;
	FILE *file1;

	if ((file = fopen("d:\\TableOrg2TV.dat", "w")) == NULL)
	{
		printf(" File Open Error");
		return;
	}

	if ((file1 = fopen("d:\\TableTV2Org.dat", "w")) == NULL)
	{
		printf(" File Open Error");
		return;
	}
#endif

	//if((pp_x != LdReg.REG.PpX) || (vp_x != LdReg.REG.VpX) || (vp_y != LdReg.REG.VpY))
	if(1)//if( (vp_x != LdReg.REG.VpX) || (vp_y != LdReg.REG.VpY) )
	{
		//pp_x = LdReg.REG.PpX;
		vp_x = LdReg.REG.VpX;
		vp_y = LdReg.REG.VpY;
	}

	cam_h = (float)LdReg.REG.CamH;
	cam_f = (float)LdReg.REG.CamF;

	cam_pixel = (float)LdReg.REG.SenC;
	cam_pixel = cam_pixel / 10000;

	cam_i = cam_pixel * (LD_IMG_HEIGHT - vp_y);

	min_d = cam_f * cam_h / cam_i;
	second_d = cam_f * cam_h / (cam_i-cam_pixel);
	refGap = (second_d - min_d);

	//==========================================================================
	// generate topview-line(y) count of each org-line(y)
	vCnt = 0;
	for(k = LD_IMG_HEIGHT-1; k >= vp_y; k--)
	{
		first_d = cam_f * cam_h / (cam_i-cam_pixel*vCnt);
		second_d = cam_f * cam_h / (cam_i-cam_pixel*(vCnt+1));
		curGap = second_d - first_d;

		if(vCnt == 0)
		{
			//lengthTable[vCnt] = 720 - (curGap / refGap)/2;
			lengthTable[vCnt] = TV_IMG_HEIGHT-1;
			TableOrg2TV[k].REG.posY = TV_IMG_HEIGHT-1;
			TableOrg2TV[k].REG.cntY = 1;
		}
		else
		{
			//lengthTable[vCnt] = lengthTable[vCnt-1] + curGap / refGap;
			iTmp = (int)((curGap / refGap)/TV_RATIO_H2 + 0.5);
			if(lengthTable[vCnt-1] > iTmp)
			{
				lengthTable[vCnt] = (int)(lengthTable[vCnt-1] - iTmp);
				TableOrg2TV[k].REG.posY = (int)(TableOrg2TV[k+1].REG.posY - iTmp);
				TableOrg2TV[k].REG.cntY = iTmp;
			}
			else
			{
				lengthTable[vCnt] = 0;
				TableOrg2TV[k].REG.posY = 0;
				TableOrg2TV[k].REG.cntY = 0;
			}
		}
		vCnt++;
	}

	//==========================================================================
	// calculate new vp_x
	sReLdReg->Reg.VP_X = vp_x + svp_x;

	//==========================================================================
	// calculate start-x, end-x of each topview-line(y)
	yDesAddr = TV_IMG_HEIGHT-1;
	vCnt = 0;

	NewVpX = sReLdReg->Reg.VP_X;
	for(k=LD_IMG_HEIGHT-1; k>vp_y; k--)
	{
		//------------------------------------------------------------------------------
		j = 0;
		uiTmp = (NewVpX-j) * (LD_IMG_HEIGHT-vp_y) * 1024 / ((k-vp_y) * TV_RATIO_W/2);
		uiTmp = uiTmp / 1024;

		if(NewVpX > (int)uiTmp)	TableOrg2TV[k].REG.posX1 = NewVpX - uiTmp;
		else					TableOrg2TV[k].REG.posX1 = 0;

		//------------------------------------------------------------------------------
		j = LD_IMG_WIDTH-1;
		uiTmp = (j-NewVpX) * (LD_IMG_HEIGHT-vp_y) * 1024 / ((k-vp_y) * TV_RATIO_W/2);
		uiTmp = uiTmp / 1024;

		if(NewVpX + (int)uiTmp < j)	TableOrg2TV[k].REG.posX2 = NewVpX + uiTmp;
		else						TableOrg2TV[k].REG.posX2 = j;
	}

	// make topview-line(y) to org-line(y) table
	j = TV_IMG_HEIGHT-1;
	for(k=LD_IMG_HEIGHT-1; k>vp_y; k--)
	{

		while(j >= (int)TableOrg2TV[k].REG.posY)
		{
			if(j >= 0)	TableTV2Org[j].REG.posY = k;
			else		break;
			j--;
		}
		if(j == 0) break;
	}

/*
	JIGMSG("NewVpX = %4d, vp_y = %4d \n", NewVpX, vp_y);
	JIGMSG("no_y, tv_y, tv_c, tvX1, tvX2\n");
	//for(k=LD_IMG_HEIGHT-1; k>=vp_y; k--)
	{
		k = LD_IMG_HEIGHT-1;
		JIGMSG("%4d, %4d, %4d, %4d, %4d \n", k, TableOrg2TV[k].REG.posY, TableOrg2TV[k].REG.cntY, TableOrg2TV[k].REG.posX1, TableOrg2TV[k].REG.posX2);
		k = vp_y;
		JIGMSG("%4d, %4d, %4d, %4d, %4d \n", k, TableOrg2TV[k].REG.posY, TableOrg2TV[k].REG.cntY, TableOrg2TV[k].REG.posX1, TableOrg2TV[k].REG.posX2);
	}

	JIGMSG("NewVpX = %4d, vp_y = %4d \n", NewVpX, vp_y);
	JIGMSG("tv_y, or_y\n");
	//for(k=TV_IMG_HEIGHT-1; k>=0; k--)
	{
		k = TV_IMG_HEIGHT-1;
		JIGMSG("%4d, %4d \n", k, TableTV2Org[k].REG.posY);

		k = 0;
		JIGMSG("%4d, %4d \n", k, TableTV2Org[k].REG.posY);
	}
*/
#ifdef _MAKE_FILE
	fprintf(file, "NewVpX = %4d, vp_y = %4d \n", NewVpX, vp_y);
	fprintf(file, "no_y, tv_y, tv_c, tvX1, tvX2\n");
	for(k=LD_IMG_HEIGHT-1; k>=vp_y; k--)
	{
		fprintf(file, "%4d, %4d, %4d, %4d, %4d \n", k, TableOrg2TV[k].REG.posY, TableOrg2TV[k].REG.cntY, TableOrg2TV[k].REG.posX1, TableOrg2TV[k].REG.posX2);
	}

	fprintf(file1, "NewVpX = %4d, vp_y = %4d \n", NewVpX, vp_y);
	fprintf(file1, "tv_y, or_y\n");
	for(k=TV_IMG_HEIGHT-1; k>=0; k--)
	{
		fprintf(file1, "%4d, %4d \n", k, TableTV2Org[k].REG.posY);
	}

	//fwrite(&data_32, sizeof(data_32), 1, file1);
	//fprintf(file, "%d %d \n", TopView_LUT_X[index], TopView_LUT_Y[index]);

	fclose(file);
	fclose(file1);
#endif

}

//---------------------------------------------------------------------------------------------
void LD_Img_Make_TopView_YUV_H_From_Org(unsigned char *src_y, unsigned char *src_u, unsigned char *src_v, unsigned char *dest)
{
	unsigned int uiTmp;
	int i, j, k;
	int ySrcAddr, xSrcAddr;
	int iIdx, iIdx1;
	int NewVpX, vp_y;

	//NewVpX = LdReg.REG.VpX;
	vp_y = LdReg.REG.VpY;

	for(i=0; i<LD_IMG_WIDTH*LD_IMG_HEIGHT*3; i++)
	{
		dest[i] = 0;
	}

	//==========================================================================
	NewVpX = sReLdReg->Reg.VP_X;
	for(k=LD_IMG_HEIGHT-1; k>vp_y; k--)
	{
		i = k;
		ySrcAddr = k;

		for(j = 0; j < LD_IMG_WIDTH; j++)
		{
#if 0
			if(j<NewVpX)			
			{
				uiTmp = (NewVpX-j) * (LD_IMG_HEIGHT-vp_y) * 1024 / ((k-vp_y) * TV_RATIO_W/2);
				uiTmp = uiTmp / 1024;
				if(NewVpX > uiTmp)	xDesAddr = NewVpX - uiTmp;
				else                xDesAddr = 0;
			}
			else if(j==NewVpX)	 xDesAddr = j;
			else				
			{
				uiTmp = (j-NewVpX) * (LD_IMG_HEIGHT-vp_y) * 1024 / ((k-vp_y) * TV_RATIO_W/2);
				uiTmp = uiTmp / 1024;
				if(NewVpX + uiTmp < LD_IMG_WIDTH-1)	xDesAddr = NewVpX + uiTmp;
				else                                xDesAddr = LD_IMG_WIDTH - 1;
			}
#else
			if(j<NewVpX)			
			{
				uiTmp = (NewVpX-j) * (k-vp_y) * 1024 / (LD_IMG_HEIGHT-vp_y) * TV_RATIO_W/2;
				uiTmp = uiTmp / 1024;
				if(NewVpX > (int)uiTmp)
					xSrcAddr = NewVpX - uiTmp;
				else
					xSrcAddr = 0;
			}
			else if(j==NewVpX)	 
				xSrcAddr = j;
			else				
			{
				uiTmp = (j-NewVpX) * (k-vp_y) * 1024 / (LD_IMG_HEIGHT-vp_y) * TV_RATIO_W/2;
				uiTmp = uiTmp / 1024;
				if(NewVpX + uiTmp < (LD_IMG_WIDTH-1))
					xSrcAddr = NewVpX + uiTmp;
				else 
					xSrcAddr = LD_IMG_WIDTH-1;
			}
#endif			

			if(xSrcAddr < 0)				xSrcAddr = 0;
			if(xSrcAddr >= LD_IMG_WIDTH)	xSrcAddr = LD_IMG_WIDTH - 1;

			//iIdx = (ySrcAddr * LD_IMG_WIDTH + j) * 1;
			//iIdx1= (i * LD_IMG_WIDTH + xDesAddr) * 1;

			iIdx = (ySrcAddr * LD_IMG_WIDTH + xSrcAddr) * 1;
			iIdx1= (i * LD_IMG_WIDTH + j) * 1;
			/////////////////////////////////////////////////////////
			if((xSrcAddr >= 0) && (xSrcAddr < LD_IMG_WIDTH))
				dest[iIdx1] = src_y[iIdx];
			//else
			//	dest[iIdx1] = 0;

			/////////////////////////////////////////////////////////
			if(LdReg.REG.YuvMode == 1) // yuv420
			{
				iIdx = (ySrcAddr/2 * LD_IMG_WIDTH/2 + xSrcAddr/2) * 1;
				if((xSrcAddr >= 0) && (xSrcAddr < LD_IMG_WIDTH))
				{
					dest[LD_IMG_WIDTH*LD_IMG_HEIGHT*1 + iIdx1] = src_u[iIdx];
					dest[LD_IMG_WIDTH*LD_IMG_HEIGHT*2 + iIdx1] = src_v[iIdx];
				}
			}
			else if(LdReg.REG.YuvMode == 2) // yuv422
			{
				iIdx = (ySrcAddr * LD_IMG_WIDTH/2 + xSrcAddr/2) * 1;
				if((xSrcAddr >= 0) && (xSrcAddr < LD_IMG_WIDTH))
				{
					dest[LD_IMG_WIDTH*LD_IMG_HEIGHT*1 + iIdx1] = src_u[iIdx];
					dest[LD_IMG_WIDTH*LD_IMG_HEIGHT*2 + iIdx1] = src_v[iIdx];
				}
			}
		}
	}

	for(j = 0; j < LD_IMG_WIDTH; j++)
	{
		dest[vp_y*LD_IMG_WIDTH+j] = 255;
	}

#if 0
	for(i=0; i<LD_IMG_WIDTH*LD_IMG_HEIGHT*1; i++)
	{
		if((dest[LD_IMG_WIDTH*LD_IMG_HEIGHT*1+i] > 128) && (dest[LD_IMG_WIDTH*LD_IMG_HEIGHT*2+i] < 115))
			dest[LD_IMG_WIDTH*LD_IMG_HEIGHT*1+i] = 255;
	}

	for(i=0; i<LD_IMG_WIDTH*LD_IMG_HEIGHT*1; i++)
	{
		if((dest[LD_IMG_WIDTH*LD_IMG_HEIGHT*1+i] < 110) && (dest[LD_IMG_WIDTH*LD_IMG_HEIGHT*2+i] > 128))
			dest[LD_IMG_WIDTH*LD_IMG_HEIGHT*2+i] = 255;
	}
#endif

}


//-------------------------------------------------------------------------------------------------------------------------
void LD_Img_Candi1_In_TopView_YUV_H(unsigned char *src, unsigned char *dest)
{
	int i, j, index, index2, k;
	int val1, val2, val3;
	int Candi1PixelGap;
	int vp_y;
	unsigned char *src_y = src;
	unsigned char *src_u = src+LD_IMG_WIDTH*LD_IMG_HEIGHT*1;
	unsigned char *src_v = src+LD_IMG_WIDTH*LD_IMG_HEIGHT*2;

	vp_y = LdReg.REG.VpY;

	for (i = 0; i < LD_IMG_WIDTH*LD_IMG_HEIGHT; i++)
		dest[i] = 0;

	for (i = LD_IMG_HEIGHT-2; i > vp_y; i--)
	{
		Candi1PixelGap = 8;

		for (j = Candi1PixelGap*2; j < LD_IMG_WIDTH - Candi1PixelGap*2 - 1; j++)
		{

			index = i * LD_IMG_WIDTH + j;

			k=1;
			//for(k=1; k<=2; k++)
			{
				Candi1PixelGap = Candi1PixelGap*k;

				val1 = src_y[index];
				val2 = src_y[index - Candi1PixelGap];
				val3 = src_y[index + Candi1PixelGap];

				val1 += src_y[(i - 1) * LD_IMG_WIDTH + (j)];
				val2 += src_y[(i - 1) * LD_IMG_WIDTH + (j - Candi1PixelGap)];
				val3 += src_y[(i - 1) * LD_IMG_WIDTH + (j + Candi1PixelGap)];

				val1 += src_y[(i + 1) * LD_IMG_WIDTH + (j)];
				val2 += src_y[(i + 1) * LD_IMG_WIDTH + (j - Candi1PixelGap)];
				val3 += src_y[(i + 1) * LD_IMG_WIDTH + (j + Candi1PixelGap)];

				val1 = val1 / 3;
				val2 = val2 / 3;
				val3 = val3 / 3;

				if(j < LdReg.REG.VpX + svp_x)
				{
					if (((2 * val1) - (val2 + val3)) >= CANDI_1_DIFF_TH_L)
					{
						if ((val1 - val2) >= CANDI_1_DIFF_TH_L && (val1 - val3) >= CANDI_1_DIFF_TH_L)
						{
							dest[index+0] |= 255;
						}
					}
				}
				else
				{
					if (((2 * val1) - (val2 + val3)) >= CANDI_1_DIFF_TH_R)
					{
						if ((val1 - val2) >= CANDI_1_DIFF_TH_R && (val1 - val3) >= CANDI_1_DIFF_TH_R)
						{
							dest[index+0] |= 255;
						}
					}
				}

				//-----------------------------------------------------------------------
				index2 = (i >> 0) * (LD_IMG_WIDTH ) + (j >> 0);
				val1 = src_u[index];
				val2 = src_u[index - Candi1PixelGap];
				val3 = src_u[index + Candi1PixelGap];
				if ((val1 < val2) && (val1 < val3))
				{
					if (((val2 - val1) >= CANDI_1_CB_TH) && ((val3 - val1) >= CANDI_1_CB_TH))
					{
						if ((val2 <= CANDI_1_U_LEVEL_TH) && (val3 <= CANDI_1_U_LEVEL_TH))
						{
							dest[index+0] |= 255;
						}
					}
				}

				//-----------------------------------------------------------------------------
				//index2 = (i >> 0) * (LD_IMG_WIDTH >> 1) + (j >> 0);
				val1 = src_v[index];
				val2 = src_v[index - Candi1PixelGap];
				val3 = src_v[index + Candi1PixelGap];
				if ((val1 < val2) && (val1 < val3))
				{
					if ((((val2) - (val1)) >= CANDI_1_CR_TH) && (((val3) - (val1)) >= CANDI_1_CR_TH))
					{
						if ((val2 <= CANDI_1_V_LEVEL_TH) && (val3 <= CANDI_1_V_LEVEL_TH))
						{
							dest[index+0] |= 255;
						}
					}
				}


				/*
				if(LdReg.REG.YuvMode == 1) // yuv420
				{
					//-----------------------------------------------------------------------
					index2 = (i >> 1) * (LD_IMG_WIDTH ) + (j >> 1);
					val1 = src_u[index];
					val2 = src_u[index - Candi1PixelGap];
					val3 = src_u[index + Candi1PixelGap];
					if ((val1 < val2) && (val1 < val3))
					{
						if (((val2 - val1) >= CANDI_1_U_TH) && ((val3 - val1) >= CANDI_1_U_TH))
						{
							if ((val2 <= CANDI_1_U_LEVEL_TH) && (val3 <= CANDI_1_U_LEVEL_TH))
							{
								dest[index+0] |= 255;
							}
						}
					}

					//-----------------------------------------------------------------------------
					//index2 = (i >> 1) * (LD_IMG_WIDTH >> 1) + (j >> 1);
					val1 = src_v[index];
					val2 = src_v[index - Candi1PixelGap];
					val3 = src_v[index + Candi1PixelGap];
					if ((val1 < val2) && (val1 < val3))
					{
						if ((((val2) - (val1)) >= CANDI_1_V_TH) && (((val3) - (val1)) >= CANDI_1_V_TH))
						{
							if ((val2 <= CANDI_1_V_LEVEL_TH) && (val3 <= CANDI_1_V_LEVEL_TH))
							{
								dest[index+0] |= 255;
							}
						}
					}
				}
				else if(LdReg.REG.YuvMode == 2) // yuv422
				{
					//-----------------------------------------------------------------------
					index2 = (i >> 0) * (LD_IMG_WIDTH ) + (j >> 1);
					val1 = src_u[index];
					val2 = src_u[index - Candi1PixelGap];
					val3 = src_u[index + Candi1PixelGap];
					if ((val1 < val2) && (val1 < val3))
					{
						if (((val2 - val1) >= CANDI_1_U_TH) && ((val3 - val1) >= CANDI_1_U_TH))
						{
							if ((val2 <= CANDI_1_U_LEVEL_TH) && (val3 <= CANDI_1_U_LEVEL_TH))
							{
								dest[index+0] |= 255;
							}
						}
					}

					//-----------------------------------------------------------------------------
					//index2 = (i >> 0) * (LD_IMG_WIDTH >> 1) + (j >> 1);
					val1 = src_v[index];
					val2 = src_v[index - Candi1PixelGap];
					val3 = src_v[index + Candi1PixelGap];
					if ((val1 < val2) && (val1 < val3))
					{
						if ((((val2) - (val1)) >= CANDI_1_V_TH) && (((val3) - (val1)) >= CANDI_1_V_TH))
						{
							if ((val2 <= CANDI_1_V_LEVEL_TH) && (val3 <= CANDI_1_V_LEVEL_TH))
							{
								dest[index+0] |= 255;
							}
						}
					}
				}
				*/
			}
		}
	}

	for (i = 0; i < LD_IMG_HEIGHT; i++)
	{
		for (j = 0; j < LD_IMG_WIDTH; j++)
		{
			if((i==0) || (i==LD_IMG_HEIGHT-1) || (j==0) || (j==LD_IMG_WIDTH-1))
				dest[i*LD_IMG_WIDTH+j] = 255;
		}
	}
}


//-------------------------------------------------------------------------------------------------------
void LD_Img_Candi2_In_TopView_YUV_H(unsigned char *src, unsigned char *dest)
{
	int upEdge = 0, validCnt = 0;
	int Left_val, Right_val;
	int i, j, k, index, diff_up, diff_down = 0;
	int AreaMin, AreaMax, Str, End;
	int Candi2PixelGap, itmp;
	int vp_y;

	vp_y = LdReg.REG.VpY;

	Str = vp_y;
	End = LD_IMG_HEIGHT;

	//-----------------------------------------
	for(i=0; i<LD_IMG_WIDTH*LD_IMG_HEIGHT; i++)
		dest[i] = 0;

	//-----------------------------------------
	for (i=Str; i<End; i++)
	{
		Candi2PixelGap = LANE_DIFF_TH;//6;

		AreaMin = Candi2PixelGap-2;
		AreaMax = Candi2PixelGap+3;

		upEdge = 0;
		for (j = 0; j < LD_IMG_WIDTH - 1; j++)
		{
			index = i * LD_IMG_WIDTH + j;

			Left_val = src[index];
			Right_val = src[index + 1];

			//diff_up = Right_val - Left_val;
			if (Right_val > Left_val)//if (diff_up >= LANE_DIFF_TH)
			{
				upEdge = j;
			}

			if (upEdge)
			{
				//diff_up = Left_val - Right_val;
				if(Left_val > Right_val) //if (diff_up >= LANE_DIFF_TH)
				{
					validCnt = j - upEdge;
					if ((validCnt >= AreaMin) && (validCnt <= AreaMax))
					{
						itmp = 1;//Candi2PixelGap/2;
						if(itmp == 0) itmp = 1;

						for(k=index-validCnt/2; k<=index-validCnt/2; k++)
						{
							dest[k-1] = 0xFF;
							dest[k] = 0xFF;
						}
					}
					upEdge = 0;
					validCnt = 0;
				}
			}
		}
	}
}



//----------------------------------------------------------------------------------------------------
#if 1//def _RUN_MFC
	void Draw_Box(unsigned char *src, int width, int sx, int sy, int ex, int ey, unsigned char c)
	{
		int n;

		if(sx > ex)	{n = sx; sx = ex; ex = n;}
		if(sy > ey)	{n = sy; sy = ey; ey = n;}

		for(n=sx; n<=ex; n++)
		{
			src[sy*width + n] = ColorTable[c][0];
			src[ey*width + n] = ColorTable[c][0];

			src[width*LD_IMG_HEIGHT + sy/2*width/2 + n/2] = ColorTable[c][2];
			src[width*LD_IMG_HEIGHT + ey/2*width/2 + n/2] = ColorTable[c][2];

			src[width*LD_IMG_HEIGHT*5/4 + sy/2*width/2 + n/2] = ColorTable[c][1];
			src[width*LD_IMG_HEIGHT*5/4 + ey/2*width/2 + n/2] = ColorTable[c][1];
		}

		for(n=sy; n<=ey; n++)
		{
			src[n*width + sx] = ColorTable[c][0];
			src[n*width + ex] = ColorTable[c][0];

			src[width*LD_IMG_HEIGHT + n/2*width/2 + sx/2] = ColorTable[c][2];
			src[width*LD_IMG_HEIGHT + n/2*width/2 + ex/2] = ColorTable[c][2];

			src[width*LD_IMG_HEIGHT*5/4 + n/2*width/2 + sx/2] = ColorTable[c][1];
			src[width*LD_IMG_HEIGHT*5/4 + n/2*width/2 + ex/2] = ColorTable[c][1];
		}
	}
#else
	void Draw_Box(unsigned char *srcY, unsigned char *srcU, unsigned char *srcV, int width, int sx, int sy, int ex, int ey, unsigned char c)
	{
		int n;

		if(sx > ex)	{n = sx; sx = ex; ex = n;}
		if(sy > ey)	{n = sy; sy = ey; ey = n;}

		for(n=sx; n<=ex; n++)
		{
			srcY[sy*width + n] = ColorTable[c][0];
			srcY[ey*width + n] = ColorTable[c][0];

			srcU[sy/2*width/2 + n/2] = ColorTable[c][2];
			srcU[ey/2*width/2 + n/2] = ColorTable[c][2];

			srcV[sy/2*width/2 + n/2] = ColorTable[c][1];
			srcV[ey/2*width/2 + n/2] = ColorTable[c][1];
		}

		for(n=sy; n<=ey; n++)
		{
			srcY[n*width + sx] = ColorTable[c][0];
			srcY[n*width + ex] = ColorTable[c][0];

			srcU[n/2*width/2 + sx/2] = ColorTable[c][2];
			srcU[n/2*width/2 + ex/2] = ColorTable[c][2];

			srcV[n/2*width/2 + sx/2] = ColorTable[c][1];
			srcV[n/2*width/2 + ex/2] = ColorTable[c][1];
		}
	}
#endif

//----------------------------------------------------------------------------------------------------
void Draw_Line(unsigned char *ptr, int w, int x1, int y1, int x2, int y2, unsigned char c)
{
	int x, y, m;

	if (y1 > y2)
	{
		m = y1;
		y1 = y2;
		y2 = m;

		m = x1;
		x1 = x2;
		x2 = m;
	}

	//-------------------------------------------------------------------------
	// 占쏙옙占쏙옙占쏙옙占쏙옙 占쏙옙占�?
	//-------------------------------------------------------------------------
	if (x1 == x2)
	{
		for (y = y1; y <= y2; y++)
		{
			ptr[y*w + x1] = c;
		}
		return;
	}

	//-------------------------------------------------------------------------
	// (x1, y1) 占쏙옙占쏙옙 (x2, y2)占쏙옙占쏙옙 占쏙옙占쏙옙 占쌓몌옙占쏙옙
	//-------------------------------------------------------------------------

	if ((y2 - y1) / (x2 - x1))
	{
		for (y = y1; y <= y2; y++)
		{
			x = (int)(y - y1)*(x2 - x1) / (y2 - y1) + x1;
			ptr[y*w + x] = c;
		}
	}
	else
	{
		if (x1 > x2)
		{
			m = x1;
			x1 = x2;
			x2 = m;

			m = y1;
			y1 = y2;
			y2 = m;
		}

		for (x = x1; x <= x2; x++)
		{
			ptr[y1*w + x] = c;			
		}
	}
}

//----------------------------------------------------------------------------------------------------
void Draw_Line_Color(unsigned char *ImageY, unsigned char *ImageU, unsigned char *ImageV, int x1, int y1, int x2, int y2, unsigned char C)
{
	int x, y, m;

	if(x1 >= LD_IMG_WIDTH)		return;
	if(x2 >= LD_IMG_WIDTH)		return;
	if(y1 >= LD_IMG_HEIGHT)		return;
	if(y2 >= LD_IMG_HEIGHT)		return;

	if (y1 > y2)
	{
		m = y1;
		y1 = y2;
		y2 = m;

		m = x1;
		x1 = x2;
		x2 = m;
	}

	//-------------------------------------------------------------------------
	// ?占쎌쭅?占쎌씤 寃쎌슦
	//-------------------------------------------------------------------------
	if (x1 == x2)
	{
		for (y = y1; y <= y2; y++)
		{
			ImageY[y * LD_IMG_WIDTH + x1]		= ColorTable[C][0];

			if(LdReg.REG.YuvMode == 1) // yuv420
			{
				ImageU[y/2 * LD_IMG_WIDTH/2 + x1/2] = ColorTable[C][1];
				ImageV[y/2 * LD_IMG_WIDTH/2 + x1/2] = ColorTable[C][2];
			}
			else if(LdReg.REG.YuvMode == 2) // yuv422
			{
				ImageU[y * LD_IMG_WIDTH/2 + x1/2] = ColorTable[C][1];
				ImageV[y * LD_IMG_WIDTH/2 + x1/2] = ColorTable[C][2];
			}
		}
		return;
	}

	//-------------------------------------------------------------------------
	// (x1, y1) ?占쎌꽌 (x2, y2)源뚳옙? 吏곸꽑 洹몃━占�?
	//-------------------------------------------------------------------------
	if((y2 - y1) > 0)
	{
		for (y = y1; y <= y2; y++)
		{
			x = x1 + (x2 - x1) * (y - y1) / (y2 - y1);

			ImageY[y * LD_IMG_WIDTH + x]	   = ColorTable[C][0];

			if(LdReg.REG.YuvMode == 1) // yuv420
			{
				ImageU[y/2 * LD_IMG_WIDTH/2 + x/2] = ColorTable[C][1];
				ImageV[y/2 * LD_IMG_WIDTH/2 + x/2] = ColorTable[C][2];
			}
			else if(LdReg.REG.YuvMode == 2) // yuv422
			{
				ImageU[y * LD_IMG_WIDTH/2 + x/2] = ColorTable[C][1];
				ImageV[y * LD_IMG_WIDTH/2 + x/2] = ColorTable[C][2];
			}
		}
	}
	else
	{
		if (x1 > x2)
		{
			m = x1;
			x1 = x2;
			x2 = m;

			m = y1;
			y1 = y2;
			y2 = m;
		}

		for (x = x1; x <= x2; x++)
		{
			ImageY[y1 * LD_IMG_WIDTH + x]		= ColorTable[C][0];

			if(LdReg.REG.YuvMode == 1) // yuv420
			{
				ImageU[y1/2 * LD_IMG_WIDTH/2 + x/2] = ColorTable[C][1];
				ImageV[y1/2 * LD_IMG_WIDTH/2 + x/2] = ColorTable[C][2];
			}
			else if(LdReg.REG.YuvMode == 2) // yuv422
			{
				ImageU[y1 * LD_IMG_WIDTH/2 + x/2] = ColorTable[C][1];
				ImageV[y1 * LD_IMG_WIDTH/2 + x/2] = ColorTable[C][2];
			}
		}
	}
}

//-----------------------------------------------------------------------------------------------------------------
void DrawLine8_2(unsigned char *ptr, int w, int h, int x1, int y1, int x2, int y2, unsigned char c)
{
	register int x, y, m;

	if (y1 > y2)
	{
		m = y1;
		y1 = y2;
		y2 = m;

		m = x1;
		x1 = x2;
		x2 = m;
	}

	//-------------------------------------------------------------------------
	// 占쏙옙占쏙옙占쏙옙占쏙옙 占쏙옙占�?
	//-------------------------------------------------------------------------
	if (x1 == x2)
	{
		for (y = y1; y <= y2; y++)
			ptr[y*w + x1] = c;

		return;
	}

	//-------------------------------------------------------------------------
	// (x1, y1) 占쏙옙占쏙옙 (x2, y2)占쏙옙占쏙옙 占쏙옙占쏙옙 占쌓몌옙占쏙옙
	//-------------------------------------------------------------------------

	if ((y2 - y1) / (x2 - x1))
	{
		for (y = y1; y <= y2; y++)
		{
			x = (int)(y - y1)*(x2 - x1) / (y2 - y1) + x1;
			ptr[y*w + x] = c;
		}
	}
	else
	{
		if (x1 > x2)
		{
			m = x1;
			x1 = x2;
			x2 = m;

			m = y1;
			y1 = y2;
			y2 = m;
		}

		for (x = x1; x <= x2; x++)
		{
			y = (x - x1)*(y2 - y1) / (x2 - x1) + y1;
			ptr[y*w + x] = c;
		}
	}
}

//---------------------------------------------------------------------------------------------
#ifdef _RUN_MFC
	void LD_Image_Draw_Lane_On_Org(unsigned char *dest, NCLD_LANE_REGISTER *sLaneReg)
#else
	void LD_Image_Draw_Lane_On_Org(NCLD_LANE_REGISTER *sLaneReg)
#endif
{
	int m, k;

#ifdef _RUN_MFC
	unsigned char *destY = dest;
	unsigned char *destU = dest + LD_IMG_WIDTH * LD_IMG_HEIGHT;
	unsigned char *destV = dest + LD_IMG_WIDTH * LD_IMG_HEIGHT * 5 / 4;
#endif

	for(m=0; m<4; m++)
		sLaneReg[m].LaneCnt = 0;
	
	if((sOrgLaneReg[0].laneCnt > 0) && (sOrgLaneReg[1].laneCnt == 0))
	{
		for(k=0; k<sOrgLaneReg[0].laneCnt; k++)
		{
			sOrgLaneReg[1].orgLane[k].x = sOrgLaneReg[0].orgLane[k].x;
			sOrgLaneReg[1].orgLane[k].y = sOrgLaneReg[0].orgLane[k].y;
		}
		sOrgLaneReg[1].laneCnt = sOrgLaneReg[0].laneCnt;
		sOrgLaneReg[0].laneCnt = 0;
	}

	if((sOrgLaneReg[3].laneCnt > 0) && (sOrgLaneReg[2].laneCnt == 0))
	{
		for(k=0; k<sOrgLaneReg[3].laneCnt; k++)
		{
			sOrgLaneReg[2].orgLane[k].x = sOrgLaneReg[3].orgLane[k].x;
			sOrgLaneReg[2].orgLane[k].y = sOrgLaneReg[3].orgLane[k].y;
		}
		sOrgLaneReg[2].laneCnt = sOrgLaneReg[3].laneCnt;
		sOrgLaneReg[3].laneCnt = 0;
	}

	for(m=0; m<4; m++)
	{
		if(sOrgLaneReg[m].laneCnt > 1)
		{

			//KalmanFiltering(sOrgLaneReg, 7, m);

			// copy lane
			for(k=0; k<sOrgLaneReg[m].laneCnt; k++)
			{
				sLaneReg[m].Lane[k].x = sOrgLaneReg[m].orgLane[k].x;
				sLaneReg[m].Lane[k].y = sOrgLaneReg[m].orgLane[k].y;
			}
			sLaneReg[m].LaneCnt = sOrgLaneReg[m].laneCnt;

			// draw lane
			//for(k=1; k<sOrgLaneReg[m].laneCnt; k++)
			//{
			//	Draw_Line_Color(destY, destU, destV, sOrgLaneReg[m].orgLane[k-1].x, sOrgLaneReg[m].orgLane[k-1].y, sOrgLaneReg[m].orgLane[k].x, sOrgLaneReg[m].orgLane[k].y, 5);
			//}
		}
	}

	/*
	for(k=LdReg.REG.VpY+5; k > LdReg.REG.VpY; k--)
	{
		Draw_Line_Color(destY, destU, destV, TableOrg2TV[k].REG.TableNewVpX, k, TableOrg2TV[k].REG.TableNewVpX, k, 5);
	}
	*/
}

//---------------------------------------------------------------------------------------------
#ifdef _RUN_MFC
void LD_Image_Overlay_TopView_To_Org(unsigned char *src_y, unsigned char *dest)
#else
void LD_Image_Overlay_TopView_To_Org(unsigned char *src_y, unsigned char *destY, unsigned char *destU, unsigned char *destV)
#endif
{
	unsigned int uiTmp;
	int i, j, k;
	int ySrcAddr, xSrcAddr;
	int iIdx, iIdx1;
	int NewVpX, vp_y;

	//NewVpX = LdReg.REG.VpX;
	vp_y = LdReg.REG.VpY;

	//==========================================================================
	NewVpX = sReLdReg->Reg.VP_X;
	for(k=LD_IMG_HEIGHT-1; k>vp_y; k--)
	{
		i = k;
		ySrcAddr = k;

		for(j = 0; j < LD_IMG_WIDTH; j++)
		{
#if 0
			if(j<NewVpX)
			{
				uiTmp = (NewVpX-j) * (LD_IMG_HEIGHT-vp_y) * 1024 / ((k-vp_y) * TV_RATIO_W/2);
				uiTmp = uiTmp / 1024;
				if(NewVpX > uiTmp)	xDesAddr = NewVpX - uiTmp;
				else                xDesAddr = 0;
			}
			else if(j==NewVpX)	 xDesAddr = j;
			else				
			{
				uiTmp = (j-NewVpX) * (LD_IMG_HEIGHT-vp_y) * 1024 / ((k-vp_y) * TV_RATIO_W/2);
				uiTmp = uiTmp / 1024;
				if(NewVpX + uiTmp < LD_IMG_WIDTH-1)	xDesAddr = NewVpX + uiTmp;
				else                                xDesAddr = LD_IMG_WIDTH - 1;
			}
#else
			if(j<NewVpX)			
			{
				uiTmp = (NewVpX-j) * (k-vp_y) * 1024 / (LD_IMG_HEIGHT-vp_y) * TV_RATIO_W/2;
				uiTmp = uiTmp / 1024;
				if(NewVpX > (int)uiTmp)
					xSrcAddr = NewVpX - uiTmp;
				else
					xSrcAddr = 0;
			}
			else if(j==NewVpX)	 
				xSrcAddr = j;
			else				
			{
				uiTmp = (j-NewVpX) * (k-vp_y) * 1024 / (LD_IMG_HEIGHT-vp_y) * TV_RATIO_W/2;
				uiTmp = uiTmp / 1024;
				if(NewVpX + uiTmp < (LD_IMG_WIDTH-1))
					xSrcAddr = NewVpX + uiTmp;
				else 
					xSrcAddr = LD_IMG_WIDTH-1;
			}
#endif			

			if(xSrcAddr < 0)				xSrcAddr = 0;
			if(xSrcAddr >= LD_IMG_WIDTH)	xSrcAddr = LD_IMG_WIDTH - 1;

			//iIdx = (ySrcAddr * LD_IMG_WIDTH + j) * 1;
			//iIdx1= (i * LD_IMG_WIDTH + xDesAddr) * 1;

			iIdx = (ySrcAddr * LD_IMG_WIDTH + xSrcAddr) * 1;
			iIdx1= (i * LD_IMG_WIDTH + j) * 1;
			/////////////////////////////////////////////////////////
			if((xSrcAddr >= 0) && (xSrcAddr < LD_IMG_WIDTH))
			{
				if(src_y[iIdx1])
				{
					#ifdef _RUN_MFC
						dest[iIdx] = ColorTable[5][0]; // cyan Y

						if(LdReg.REG.YuvMode == 1) // yuv420
						{
							iIdx = (ySrcAddr/2 * LD_IMG_WIDTH/2 + xSrcAddr/2) + LD_IMG_WIDTH * LD_IMG_HEIGHT;
							//iIdx1= (i/2 * LD_IMG_WIDTH/2 + j/2) * 1 + LD_IMG_WIDTH * LD_IMG_HEIGHT;
							dest[iIdx] = ColorTable[5][2]; // cyan V

							iIdx = (ySrcAddr/2 * LD_IMG_WIDTH/2 + xSrcAddr/2) + LD_IMG_WIDTH * LD_IMG_HEIGHT * 5 / 4;
							//iIdx1= (i/2 * LD_IMG_WIDTH/2 + j/2) * 1 + LD_IMG_WIDTH * LD_IMG_HEIGHT * 5 / 4;
							dest[iIdx] = ColorTable[5][1]; // cyan U
						}
						else if(LdReg.REG.YuvMode == 2) // yuv422
						{
							iIdx = (ySrcAddr * LD_IMG_WIDTH/2 + xSrcAddr/2) + LD_IMG_WIDTH * LD_IMG_HEIGHT;
							//iIdx1= (i * LD_IMG_WIDTH/2 + j/2) * 1 + LD_IMG_WIDTH * LD_IMG_HEIGHT;
							dest[iIdx] = ColorTable[5][2]; // cyan V

							iIdx = (ySrcAddr * LD_IMG_WIDTH/2 + xSrcAddr/2) + LD_IMG_WIDTH * LD_IMG_HEIGHT * 5 / 4;
							//iIdx1= (i * LD_IMG_WIDTH/2 + j/2) * 1 + LD_IMG_WIDTH * LD_IMG_HEIGHT * 5 / 4;
							dest[iIdx] = ColorTable[5][1]; // cyan U
						}
					#else
						destY[iIdx] = ColorTable[2][0]; // cyan Y

						if(LdReg.REG.YuvMode == 1) // yuv420
						{
							iIdx = (ySrcAddr/2 * LD_IMG_WIDTH/2 + xSrcAddr/2);
							//iIdx1= (i/2 * LD_IMG_WIDTH/2 + j/2) * 1 + LD_IMG_WIDTH * LD_IMG_HEIGHT;
							destU[iIdx] = ColorTable[2][1]; // cyan U

							//iIdx = (ySrcAddr/2 * LD_IMG_WIDTH/2 + xSrcAddr/2) + LD_IMG_WIDTH * LD_IMG_HEIGHT * 5 / 4;
							//iIdx1= (i/2 * LD_IMG_WIDTH/2 + j/2) * 1 + LD_IMG_WIDTH * LD_IMG_HEIGHT * 5 / 4;
							destV[iIdx] = ColorTable[2][2]; // cyan V
						}
						else if(LdReg.REG.YuvMode == 2) // yuv422
						{
							iIdx = (ySrcAddr * LD_IMG_WIDTH/2 + xSrcAddr/2);
							//iIdx1= (i * LD_IMG_WIDTH/2 + j/2) * 1 + LD_IMG_WIDTH * LD_IMG_HEIGHT;
							destU[iIdx] = ColorTable[2][1]; // cyan U

							//iIdx = (ySrcAddr * LD_IMG_WIDTH/2 + xSrcAddr/2) + LD_IMG_WIDTH * LD_IMG_HEIGHT * 5 / 4;
							//iIdx1= (i * LD_IMG_WIDTH/2 + j/2) * 1 + LD_IMG_WIDTH * LD_IMG_HEIGHT * 5 / 4;
							destV[iIdx] = ColorTable[2][2]; // cyan V
						}
					#endif
				}
			}
		}
	}
	#ifdef _RUN_MFC
		DrawLine8_2(dest, LD_IMG_WIDTH, LD_IMG_HEIGHT, 0, k, LD_IMG_WIDTH-1, k, 255);	// vp
	#else
		DrawLine8_2(destY, LD_IMG_WIDTH, LD_IMG_HEIGHT, 0, k, LD_IMG_WIDTH-1, k, 255);	// vp
	#endif
}


/*
//---------------------------------------------------------------------------------------------
void LD_Image_Make_TopView_to_Narmal(unsigned char *src, unsigned char *dest)
{
	unsigned int uiTmp;
	int i, j, k;
	int yDesAddr, ySrcAddr, yEnd, xSrcAddr;
	int iIdx, iIdx1, iIdx_uv;

	unsigned char *dest_y = dest;
	unsigned char *dest_v = dest + LD_IMG_WIDTH*LD_IMG_HEIGHT;
	unsigned char *dest_u = dest_v + LD_IMG_WIDTH*LD_IMG_HEIGHT/4;

	int vp_x, vp_y, vCnt;
	
#ifdef _RUN_MFC
	char	DisString[20] = {NULL};
#endif 

	vp_x = LdReg.REG.VpX;
	vp_y = LdReg.REG.VpY;

	//==========================================================================
	yDesAddr = TV_IMG_HEIGHT-1;
	vCnt = 0;
	for(k=LD_IMG_HEIGHT-1; k>=0; k--)
	{
		ySrcAddr = k;

		yEnd = (int)lengthTable[vCnt];
		vCnt++;

		if(yEnd>=0)
		{
			for(i = yDesAddr; i >= yEnd; i--)
			{
				if(i<0) break;

				for(j = 0; j < LD_IMG_WIDTH; j++)
				{
					if(j<vp_x)
					{
						uiTmp = (vp_x-j) * (k-vp_y) * 1024 / (LD_IMG_HEIGHT-vp_y) * TV_RATIO_W/2;
						uiTmp = uiTmp / 1024;

						if(vp_x > (int)uiTmp)	xSrcAddr = vp_x - uiTmp;
						else				    xSrcAddr = 0;
					}
					else if(j==vp_x)	xSrcAddr = j;
					else
					{
						uiTmp = (j-vp_x) * (k-vp_y) * 1024 / (LD_IMG_HEIGHT-vp_y) * TV_RATIO_W/2;
						uiTmp = uiTmp / 1024;

						if(vp_x + uiTmp < LD_IMG_WIDTH-1)	xSrcAddr = vp_x + uiTmp;
						else                                xSrcAddr = LD_IMG_WIDTH-1;
					}

					iIdx = (ySrcAddr * LD_IMG_WIDTH + xSrcAddr) * 1;
					iIdx_uv = (ySrcAddr/2 * LD_IMG_WIDTH/2 + xSrcAddr/2) * 1;
					//iIdx = (i*InImg.width+j)*3;
					iIdx1= (i * LD_IMG_WIDTH + j) * 1;

					/////////////////////////////////////////////////////////

					if((xSrcAddr >= 0) && (xSrcAddr < LD_IMG_WIDTH))
					{
						if(src[iIdx1] > 0)
						{
								dest_y[iIdx]	= ColorTable[2][0];
								dest_u[iIdx_uv] = ColorTable[2][1];
								dest_v[iIdx_uv] = ColorTable[2][2];
						}
					}
				}
			}
			yDesAddr = yEnd-1;
			if(yDesAddr<0) break;
		}
		else 
			break;
	}

	DrawLine8_2(dest, LD_IMG_WIDTH, LD_IMG_HEIGHT, 0, k, LD_IMG_WIDTH-1, k, 255);	// vp

	#ifdef _RUN_MFC
		sprintf( DisString, "%d %d %d %d m", i, (int)min_d/10, (int)refGap, (int)(min_d+refGap*(TV_IMG_HEIGHT-i)));
		Draw_Text(dest, DisString, 10, 10);
	#endif 

}
*/

//---------------------------------------------------------------------------------------------------------------------
/*
void Draw_Text(unsigned char* pCurDatabuf, char *ChString, unsigned int StX, unsigned int StY) // OutSel Bit0
{
	unsigned long x, y, k, z, i;

	unsigned char *pSrc, *pSrcAddr;
	unsigned char ReturnValue[100];
	unsigned char rdpix;

	i = 0;
	while(*ChString != '\0')
	{
		if(*ChString == 0x20)								ReturnValue[i] = 0;	// space
		else if(*ChString <= 0x39)							ReturnValue[i] = *ChString - 0x2F;	// number
		else if((*ChString >= 0x41) & (*ChString <= 0x5A))	ReturnValue[i] = *ChString - 0x36;	// capital alphabet
		else if((*ChString >= 0x61) & (*ChString <= 0x7A))	ReturnValue[i] = *ChString - 0x56;	// alphabet
		else												ReturnValue[i] = 47;	// black
		ChString++;
		i++;
	}
	ReturnValue[i] = 0xFF;	// blank;

	pSrc = (unsigned char*)EngFont_14;

	z = 0;
	while(ReturnValue[z] != 0xFF)
	{
		pSrcAddr = pSrc + (14 * 14) * ReturnValue[z++];
		for(y=StY; y < StY+14; y++)
		{
			for(x=StX; x < StX+14; x++)
			{
				rdpix = *pSrcAddr;
				pSrcAddr+=1;
				if(rdpix > 0)
				{
					rdpix = 255;
					k = y * LD_IMG_WIDTH + x;
					//pCurDatabuf[k] = rdpix;
					if(pCurDatabuf[k] == 0)
					{
						pCurDatabuf[k] = 255;
					}
					else
					{
						pCurDatabuf[k] = 0;
					}

				}
			}
		}
		StX = StX + 14;
	}
}
*/

//---------------------------------------------------------------------------------------------
POINT_XY LD_Image_Draw_OrgXY_From_TopView(POINT_XY tvLane)
{
	unsigned int uiTmp;

	int tvX, tvY;
	int outX, outY;
	int NewVpX, vp_y;

	POINT_XY orgLane;

	vp_y = LdReg.REG.VpY;

	tvX = tvLane.x;
	tvY = tvLane.y;

	//NewVpX = LdReg.REG.VpX;
	NewVpX = sReLdReg->Reg.VP_X;

	/*
	for(yCnt=LD_IMG_HEIGHT-1; yCnt> 0; yCnt--)
	{
		if(tvY >= (int)TableOrg2TV[yCnt].REG.posY)
		{
			outY = yCnt;
			break;
		}
	}
	*/
	outY = tvY;
	
	// add lane drawing offset
	if(tvX < NewVpX)	tvX = tvX + 3;
	else            tvX = tvX + 1;

	if(tvX < NewVpX)
	{
		uiTmp = (NewVpX-tvX) * (outY-vp_y) * 1024 / (LD_IMG_HEIGHT-vp_y) * TV_RATIO_W/2;
		uiTmp = uiTmp / 1024;
		if(NewVpX > (int)uiTmp)	outX = NewVpX - uiTmp;
		else					outX = 0;
	}
	else if(tvX == NewVpX)	outX = tvX;
	else
	{
		uiTmp = (tvX-NewVpX) * (outY-vp_y) * 1024 / (LD_IMG_HEIGHT-vp_y) * TV_RATIO_W/2;
		uiTmp = uiTmp / 1024;
		if(NewVpX + uiTmp < LD_IMG_WIDTH-1)	outX = NewVpX + uiTmp;
		else                                outX = LD_IMG_WIDTH - 1;
	}

	if(outX < 0)				outX = 0;
	if(outX >= LD_IMG_WIDTH)	outX = LD_IMG_WIDTH-1;

	orgLane.x = outX;
	orgLane.y = outY;

	return orgLane;
}


//---------------------------------------------------------------------------------------------
POINT_XY LD_Image_Make_OrgXY_Point_From_TopView(POINT_XY tvLane)
{
	unsigned int uiTmp;

	int tvX, tvY;
	int outX, outY;
	int NewVpX, vp_y;

	POINT_XY orgLane;

	//NewVpX = LdReg.REG.VpX;
	vp_y = LdReg.REG.VpY;

	tvX = tvLane.x;
	tvY = tvLane.y;

	NewVpX = sReLdReg->Reg.VP_X;

	outY = tvY;
	
	if(tvX < NewVpX)
	{
		uiTmp = (NewVpX-tvX) * (outY-vp_y) * 1024 / (LD_IMG_HEIGHT-vp_y) * TV_RATIO_W/2;
		uiTmp = uiTmp / 1024;
		if(NewVpX > (int)uiTmp)	outX = NewVpX - uiTmp;
		else					outX = 0;
	}
	else if(tvX == NewVpX)	outX = tvX;
	else
	{
		uiTmp = (tvX-NewVpX) * (outY-vp_y) * 1024 / (LD_IMG_HEIGHT-vp_y) * TV_RATIO_W/2;
		uiTmp = uiTmp / 1024;
		if(NewVpX + uiTmp < LD_IMG_WIDTH-1)	outX = NewVpX + uiTmp;
		else                                outX = LD_IMG_WIDTH - 1;
	}

	if(outX < 0)				outX = 0;
	if(outX >= LD_IMG_WIDTH)	outX = LD_IMG_WIDTH-1;

	orgLane.x = outX;
	orgLane.y = outY;

	return orgLane;
}

