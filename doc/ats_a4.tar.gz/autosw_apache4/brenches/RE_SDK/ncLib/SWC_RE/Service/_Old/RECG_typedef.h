#ifndef	_HK_TYPEDEF
#define	_HK_TYPEDEF


#define	MAX_TRACK	30
#define MAX_TRACK_NUM MAX_TRACK

#define HK_DISPLACE_VD 25.0
#define HK_DISPLACE_PD 4.0

#define PATCH_SIZE 20
#define STAND_WIDTH 72.0

#define TH_WEIGHT_WIDTH 60
#define MAX_BOX_MOD 100

#define PD_MODE 1
#define VD_MODE 0

typedef struct
{
	float	StX;
	float	StY;

	float	Width;
	float	Height;

	unsigned char FrameNum;

	unsigned char TrueTracking;

	unsigned char IsAssociation;
	char ID;

	char InvalidCount;
	char TrackCount;
	char DetCount;

	char NumberID;

	float score;
	float costValue;
	float weightValue;

	unsigned short	HogLbpValue: 	16;
}BOX_XYWH_DATA;

typedef	struct
{
	unsigned int	BoxNumMax;
	BOX_XYWH_DATA	BaxXYWH[128];
}BOX_INFO;

typedef struct
{
	int x;
	int y;
}NCPoint;

typedef struct
{
	float x;
	float y;
}NCPointf;

typedef struct
{
	int width;
	int height;
}NCSize;

typedef struct
{
	int x;
	int y;
	int width;
	int height;
}NCRect;



typedef struct
{
	float x;
	float y;
	float width;
	float height;
}NCRectf;

typedef struct
{
	NCRectf ModVal[2560];
	float	ModNcc[2560];
	int size;
}MODValue;

typedef struct
{
	int CurPoint;
	char UseNumber[MAX_TRACK_NUM];
}IDNumber;

#define NUM_MAX_LABEL 128

#define OPERATE_MAX_LABEL 10

#define AREA_VALID_UPPER_THRESHOLD 50
#define AREA_VALID_LOWER_THRESHOLD 20000
#define UPPER_RATE 2.7
#define LOWER_RATE 0.25

typedef struct
{
	int num_label;

	int area[NUM_MAX_LABEL];
	int top[NUM_MAX_LABEL];
	int left[NUM_MAX_LABEL];
	int width[NUM_MAX_LABEL];			// right
	int height[NUM_MAX_LABEL];			// bottom
	int label_number[NUM_MAX_LABEL];
	int paring_number[NUM_MAX_LABEL];

	NCPointf centroid[NUM_MAX_LABEL];
}Label;

#endif
