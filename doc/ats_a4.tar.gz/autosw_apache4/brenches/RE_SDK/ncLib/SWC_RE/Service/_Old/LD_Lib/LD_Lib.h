#ifndef _LD_LIB_H_
#define _LD_LIB_H_

#include "LD_include.h"

#include "RE_Svc.h"
#include "NCLD_Register.h"
#include "LD_Register.h"
#include "LD_Image.h"
#include "LD_Searching.h"
#include "LD_Kalman.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef _RUN_MFC
	typedef struct {
		INT32 x1;
		INT32 y1;
	} STRUCT_NC_POINT;
#endif


#ifdef _RUN_MFC
int __LD_FRAMEWORK(UINT32 param00, UINT32 param01, UINT32 param02, UINT32 param03,
				   UINT32 param04, UINT32 param05, UINT32 param06, UINT32 param07,
				   UINT8* src, UINT8* HsvSrc, UINT16* Left_lane, UINT16* Right_lane, UINT16* Left_lane1, UINT16* Right_lane1,
				   int PricipleX, int VanisingPointY, int VanisingPointX, int EndY,
				   int DiffTh, int YTh, int CbTh, int CrTh, int UTh, int VTh, int LaneDiff,
				   int Test0,
				   unsigned char **LD_ptrArr_);
#else
extern void LD_Task(NCLD_LANE_REGISTER *sLaneReg, NCLD_REGISTER *sLdStatusReg);
#endif

extern void ld_test_f(void);

extern void InitMemoryLd(void);
extern void ExitMemoryLd(void);

extern volatile unsigned int LD_addr;
extern NCLD_REGISTER		sLdStatusReg[1];

#ifdef __cplusplus
}
#endif

#endif // !_LD_LIB_H_



