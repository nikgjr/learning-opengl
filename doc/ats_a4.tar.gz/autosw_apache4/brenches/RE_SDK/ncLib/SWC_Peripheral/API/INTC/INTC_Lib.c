/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : INTC_Lib.c
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "INTC_Drv.h"










/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

typedef struct _INTC_PARAM
{
    UINT32      mIntNum;
    UINT32      mDispatchMode;  // TBD
    PrHandler   mHandler1;
    PrHandler3  mHandler2;      // TBD
} tGIC_PARAM, *ptGIC_PARAM;










/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

BOOL gbIntcOpen = FALSE;
tGIC_PARAM gtIntInfo[IRQS_TOTAL];










/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

void ncLib_INTC_IrqHandler(void);
void ncLib_INTC_FiqHandler(void);
void ncLib_INTC_RegisterHandler(UINT32 nIntNum, PrHandler pHandler);
void ncLib_INTC_UnRegisterHandler(UINT32 nIntNum);
void ncLib_INTC_InitIntHandler(void);
void ncLib_INTC_UserHandler(UINT32 nIntNum);











/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncLib_INTC_Open(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbIntcOpen == FALSE)
    {
        gbIntcOpen = TRUE;

        ncLib_INTC_InitIntHandler();
        ncDrv_GIC_Initialize();
    }
    else
    {
        //DEBUGMSG_SDK(MSGERR, "Error, GIC %s\n", LOG_ERR_OPEN);

        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_INTC_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbIntcOpen == TRUE)
    {
        ncLib_INTC_InitIntHandler();
        ncDrv_GIC_Deinitialize();
        gbIntcOpen = FALSE;
    }
    else
    {
        //DEBUGMSG_SDK(MSGERR, "Error, GIC %s\n", LOG_ERR_CLOSE);

        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_INTC_Read(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_INTC_Write(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_INTC_Control(eINTC_CMD Cmd, ...)
{
    UINT32   count;
    UINT32   argData[CMD_MAX];
    eINT_NUM nIntNum;
    va_list  vlist;
    BOOL     bEndCmd = FALSE;
    INT32    ret = NC_SUCCESS;

    if(gbIntcOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vlist, Cmd);

        for(count = 0; count < CMD_MAX; count++)
        {
            argData[count] = va_arg(vlist, UINT32);

            if(argData[count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vlist);

        if(bEndCmd == FALSE)
        {
            ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

            nIntNum = (eINT_NUM)argData[0];

            switch(Cmd)
            {
                case GCMD_INTC_REGISTER_INT:
                    ncLib_INTC_RegisterHandler(nIntNum, (PrHandler)argData[1]);
                    ncDrv_GIC_EnableIrq(nIntNum);
                break;

                case GCMD_INTC_UNREGISTER_INT:
                    ncLib_INTC_UnRegisterHandler(nIntNum);
                    ncDrv_GIC_DisableIrq(nIntNum);
                break;
                
                case GCMD_INTC_SGI_TRIGGER:
                    ncDrv_GIC_SGITrigger(nIntNum);
                break;
#if 0
                case GCMD_INTC_SET_TRIG_MODE:
                    if(argData[1] == TRIG_LEVEL_HIGH || argData[1] == TRIG_LEVEL_LOW)
                    {
                        ncDrv_GIC_SetInterruptConfigration(nIntNum, GIT_N_N_LEVEL);
                    }
                    else
                    {
                        ncDrv_GIC_SetInterruptConfigration(nIntNum, GIT_N_N_EDGE);
                    }
                break;
#endif
                case GCMD_INTC_SET_PRIORITY_LEVEL:
                    ncDrv_GIC_SetPriorityLevel(nIntNum, (argData[1] & 0xFF));
                break;

                case GCMD_INTC_ENABLE_INT:
                    ncDrv_GIC_EnableIrq(nIntNum);
                break;

                case GCMD_INTC_DISABLE_INT:
                    ncDrv_GIC_DisableIrq(nIntNum);
                break;

                case GCMD_INTC_ONOFF_RAISED_INT:         // for Debug
                    ncDrv_GIC_OnOffRaisedIrq((BOOL) argData[1]);
                break;

                case GCMD_INTC_CHK_RAISED_INT:           // for Debug
                    ret = ncDrv_GIC_CheckRaisedIrq(nIntNum);
                break;

                case GCMD_INTC_CLR_RAISED_INT:           // for Debug
                    ncDrv_GIC_ClearAllRaisedIrq();
                break;

                default :
                    ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


void ncLib_INTC_IrqHandler(void)
{
    ncDrv_GIC_IrqHandler();

    return;
}


void ncLib_INTC_FiqHandler(void)
{
    return;
}


void ncLib_INTC_RegisterHandler(UINT32 nIntNum, PrHandler pHandler)
{
    gtIntInfo[nIntNum].mIntNum   = nIntNum;
    gtIntInfo[nIntNum].mHandler1 = pHandler;
}


void ncLib_INTC_UnRegisterHandler(UINT32 nIntNum)
{
    gtIntInfo[nIntNum].mIntNum   = 0;
    gtIntInfo[nIntNum].mHandler1 = 0;
}


void ncLib_INTC_InitIntHandler(void)
{
    UINT32 i;

    /* Initialize interrupt pointer function */

    for(i = 0; i < IRQS_TOTAL; i++)
    {
        gtIntInfo[i].mIntNum       = 0;
        gtIntInfo[i].mHandler1     = 0;
        gtIntInfo[i].mHandler2     = 0;
        gtIntInfo[i].mDispatchMode = 0;
    }
}


void ncLib_INTC_UserHandler(UINT32 nIntNum)
{
    /* Execute interrupt handler */

    if(gtIntInfo[nIntNum].mHandler1)
    {
        gtIntInfo[nIntNum].mHandler1(nIntNum);
    }
}


/* End Of File */

