/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "SCU_Drv.h"










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbSCUOpen = FALSE;










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncLib_SCU_Open(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbSCUOpen == FALSE)
    {
        ncDrv_SCU_Init();
        gbSCUOpen = TRUE;
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_SCU_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbSCUOpen == TRUE)
    {
        ncDrv_SCU_DeInit();
        gbSCUOpen = FALSE;
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_SCU_Read(void)
{
    INT32 ret = NC_SUCCESS;
    
    return ret;
}


INT32 ncLib_SCU_Write(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_SCU_Control(eSCU_CMD Cmd, ...)
{
    INT32       ret = NC_SUCCESS;

    UINT32      count;
    UINT32      argData[CMD_MAX];
    va_list     vlist;
    BOOL        bEndCmd = FALSE;


    if(gbSCUOpen == TRUE)
    {
        /*
         * Parsing Variable Argument
         */
        va_start(vlist, Cmd);
        for(count = 0; count < CMD_MAX; count++)
        {
            argData[count] = va_arg(vlist, UINT32);
            if(argData[count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }
        va_end(vlist);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "%s\n", "No CMD_END");
            ret = NC_FAILURE;
        }
        else
        {
            /*
             * Implement Control Command Function
             */
            switch(Cmd)
            {
                case GCMD_SCU_GET_STRAP_INFO:
                    break;

                case GCMD_SCU_GET_CLK:
                    ret = ncDrv_SCU_GetSystemClock(argData[0]);
                    break;

                case GCMD_SCU_GET_PINMUX:
                    ret = ncDrv_SCU_GetPinMux(argData[0]);
                    break;

                case GCMD_SCU_SET_PINMUX:
                    ret = ncDrv_SCU_SetPinMux(argData[0], argData[1]);
                    break;

                case GCMD_SCU_GET_DATA:
                    ret = ncDrv_SCU_GetData(argData[0]);
                    break;

                case GCMD_SCU_SET_DATA:
                    ret = ncDrv_SCU_SetData(argData[0], argData[1]);
                    break;

                case GCMD_SCU_ENA_CLK:
                    ncDrv_SCU_EnableClk((eSCU_CLK_ID)argData[0]);
                    break;

                case GCMD_SCU_DIS_CLK:
                    ncDrv_SCU_DisableClk((eSCU_CLK_ID)argData[0]);
                    break;
                    
                case SCMD_SCU_DB_NUM:
                    break;

                default :
                    ret = NC_FAILURE;
                    DEBUGMSG_SDK(MSGERR, "%s\n", "Unknown Command");
                    break;
            }
        }
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


/* End Of File */
