/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "DMA_Drv.h"










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbDMAOpen = FALSE;
tDMA_INFO gtDMA[MAX_OF_DMA_CH];










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static INT32 ncLib_DMA_InfoInit(eDMA_CH Ch, ptDMA_PARAM ptDMAParam)
{
    INT32 Ret = NC_FAILURE;
    
    if(ptDMAParam != NULL)
    {
        gtDMA[Ch].mDMA_ChInit = ON;
        gtDMA[Ch].mDMA_ChNum  = Ch;
        gtDMA[Ch].mDMA_Param  = *ptDMAParam;
        
        Ret = NC_SUCCESS;
    }

    return Ret;
}


static void ncLib_DMA_InfoDeInit(eDMA_CH Ch)
{
    gtDMA[Ch].mDMA_ChInit = OFF;    
    gtDMA[Ch].mDMA_ChNum  = MAX_OF_DMA_CH;  
}


static INT32 ncLib_DMA_IsNotAliveCh(void)
{
    INT32 Ret = NC_SUCCESS;
    eDMA_CH Ch;
    
    for(Ch=DMA_CH0; Ch<MAX_OF_DMA_CH; Ch++)
    {
        if(gtDMA[Ch].mDMA_ChInit == ON)
            Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_DMA_Open(void)
{
    INT32 Ret = NC_SUCCESS;
    eDMA_CH Ch;
    
    if(gbDMAOpen == FALSE)
    {
        ncLib_SCU_Control(GCMD_SCU_ENA_CLK, SCU_CLK_ID_DMA, CMD_END);  

        for(Ch=DMA_CH0; Ch<MAX_OF_DMA_CH; Ch++)
            ncLib_DMA_InfoDeInit(Ch); 

        gbDMAOpen = TRUE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_DMA_Close(void)
{
    INT32 Ret;

    Ret = ncLib_DMA_IsNotAliveCh();
    if(Ret == NC_SUCCESS)
    {
        ncLib_SCU_Control(GCMD_SCU_DIS_CLK, SCU_CLK_ID_DMA, CMD_END);   
        gbDMAOpen = FALSE;
    }

    return Ret;
}


INT32 ncLib_DMA_Read(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_DMA_Write(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_DMA_Control(eDMA_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    eDMA_CH Ch;


    if(gbDMAOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */
        
        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, DMA no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Defence Code
            */
            
            Ch = (eDMA_CH)ArgData[0];
            if(   (Ch >= MAX_OF_DMA_CH) 
               || ((Cmd != GCMD_DMA_INIT_CH) && (gtDMA[Ch].mDMA_ChInit == OFF)) )
            {
                Cmd = GCMD_DMA_MAX; 
            }

            
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case GCMD_DMA_INIT_CH:
                {
                    Ret = ncLib_DMA_InfoInit(Ch, (ptDMA_PARAM)ArgData[1]); 
                    if(Ret == NC_SUCCESS)
                        ncDrv_DMA_Initialize(Ch);
                }
                break;


                case GCMD_DMA_DEINIT_CH:
                {
                    ncDrv_DMA_DeInitialize(Ch);
                    ncLib_DMA_InfoDeInit(Ch); 
                }
                break;


                case GCMD_DMA_START:
                {
                    Ret = ncDrv_DMA_Transfer(&gtDMA[Ch], (UINT32)ArgData[1], (UINT32)ArgData[2], (UINT32)ArgData[3]);
                }
                break;


                case GCMD_DMA_DONE:
                {
                    Ret = ncDrv_DMA_CheckComplete(Ch);
                }
                break;
                

                case GCMD_DMA_SET_BURST_LEN:
                {
                    gtDMA[Ch].mDMA_Param.mRxBurstLen = (UINT32)ArgData[1];
                    gtDMA[Ch].mDMA_Param.mTxBurstLen = (UINT32)ArgData[2];
                }
                break;    
   

                case GCMD_DMA_GET_INT_STS:
                {
                    Ret = ncDrv_DMA_GetStatus(Ch);
                }
                break;

                
                case GCMD_DMA_MAX:
                {
                    Ret = NC_FAILURE;
                }   
                break; 

                
                default :
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support DMA command\n");
                    Ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


/* End Of File */

