/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "QSPI_Drv.h"










/*
********************************************************************************
*               TYPEDEFS                                    
********************************************************************************
*/

typedef struct
{
    tPAD_INFO CS0;
    tPAD_INFO CS1;
    tPAD_INFO DQ0;
    tPAD_INFO DQ1;        
    tPAD_INFO DQ2;
    tPAD_INFO DQ3;    
    tPAD_INFO SCK;    
} tQSPI_PAD, *ptQSPI_PAD;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbQSPIOpen = FALSE;

tQSPI_PAD gtQSPI_PAD = 
{
    {PAD_SPI2_CSN0, {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_SPI2_CSN1, {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_SPI2_DQ0,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_SPI2_DQ1,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_SPI2_DQ2,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_SPI2_DQ3,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_SPI2_SCK,  {PAD_FUNC_1, PAD_FUNC_MAX}}
};










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void ncLib_QSPI_PinMuxCtrlGet(void)
{
    //-----------------------------------------------------------------------------------------------------    
    // Back-up Current PinMux
    if(gtQSPI_PAD.CS0.mFunc[1] == PAD_FUNC_MAX)
        gtQSPI_PAD.CS0.mFunc[1] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gtQSPI_PAD.CS0.mId, CMD_END);

    if(gtQSPI_PAD.CS1.mFunc[1] == PAD_FUNC_MAX)
        gtQSPI_PAD.CS1.mFunc[1] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gtQSPI_PAD.CS1.mId, CMD_END);

    if(gtQSPI_PAD.DQ0.mFunc[1] == PAD_FUNC_MAX)
        gtQSPI_PAD.DQ0.mFunc[1] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gtQSPI_PAD.DQ0.mId, CMD_END);
    
    if(gtQSPI_PAD.DQ1.mFunc[1] == PAD_FUNC_MAX)
        gtQSPI_PAD.DQ1.mFunc[1] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gtQSPI_PAD.DQ1.mId, CMD_END);

    if(gtQSPI_PAD.DQ2.mFunc[1] == PAD_FUNC_MAX)
        gtQSPI_PAD.DQ2.mFunc[1] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gtQSPI_PAD.DQ2.mId, CMD_END);
    
    if(gtQSPI_PAD.DQ3.mFunc[1] == PAD_FUNC_MAX)
        gtQSPI_PAD.DQ3.mFunc[1] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gtQSPI_PAD.DQ3.mId, CMD_END);

    if(gtQSPI_PAD.SCK.mFunc[1] == PAD_FUNC_MAX)
        gtQSPI_PAD.SCK.mFunc[1] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gtQSPI_PAD.SCK.mId, CMD_END);


    //-----------------------------------------------------------------------------------------------------  
    // Set PinMux
    ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.CS0.mId,  gtQSPI_PAD.CS0.mFunc[0], CMD_END);
    if(gtQSPI_PAD.CS0.mFunc[0] == PAD_FUNC_4)
    {
        ncLib_GPIO_Control(GCMD_GPIO_SET_DIR,  GPIO_GROUP_PAD, gtQSPI_PAD.CS0.mId, GPIO_DIR_OUT, CMD_END);
        ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_PAD, gtQSPI_PAD.CS0.mId, GPIO_HIGH, CMD_END);
    }

    ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.CS1.mId,  gtQSPI_PAD.CS1.mFunc[0], CMD_END);
    if(gtQSPI_PAD.CS1.mFunc[0] == PAD_FUNC_4)
    {
        ncLib_GPIO_Control(GCMD_GPIO_SET_DIR,  GPIO_GROUP_PAD, gtQSPI_PAD.CS1.mId, GPIO_DIR_OUT, CMD_END);
        ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_PAD, gtQSPI_PAD.CS1.mId, GPIO_HIGH, CMD_END);        
    }
    
    ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.DQ0.mId,  gtQSPI_PAD.DQ0.mFunc[0], CMD_END);
    ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.DQ1.mId,  gtQSPI_PAD.DQ1.mFunc[0], CMD_END);
    ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.DQ2.mId,  gtQSPI_PAD.DQ2.mFunc[0], CMD_END);
    ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.DQ3.mId,  gtQSPI_PAD.DQ3.mFunc[0], CMD_END);
    ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.SCK.mId,  gtQSPI_PAD.SCK.mFunc[0], CMD_END);


    //-----------------------------------------------------------------------------------------------------  
    // Ctrl Chip Select PIN
    if( 0 ) // if((ncLib_SCU_Control(GCMD_SCU_GET_STRAP_INFO, CMD_END) >> 2) & 0x01)
    {
        if(gtQSPI_PAD.CS1.mFunc[0] == PAD_FUNC_4)
            ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_PAD, gtQSPI_PAD.CS1.mId, GPIO_LOW, CMD_END);
        else
            ncDrv_QSPI_IsExternalMemory(TRUE);
    }
    else
    {
        if(gtQSPI_PAD.CS0.mFunc[0] == PAD_FUNC_4)
            ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_PAD, gtQSPI_PAD.CS0.mId, GPIO_LOW, CMD_END);
        else
            ncDrv_QSPI_IsExternalMemory(FALSE);  
    }
}


static void ncLib_QSPI_PinMuxCtrlFree(void)
{
    //-----------------------------------------------------------------------------------------------------
    // if ( Ctrl Chip Select PIN - GPIO)
    if( 0 ) // if((ncLib_SCU_Control(GCMD_SCU_GET_STRAP_INFO, CMD_END) >> 2) & 0x01)
    {
        if(gtQSPI_PAD.CS1.mFunc[0] == PAD_FUNC_4)
            ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_PAD, gtQSPI_PAD.CS1.mId, GPIO_HIGH, CMD_END);
    }
    else
    {
        if(gtQSPI_PAD.CS0.mFunc[0] == PAD_FUNC_4)
            ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_PAD, gtQSPI_PAD.CS0.mId, GPIO_HIGH, CMD_END);
    }


    //------------------------------------------------------------------------------------------------------
    // Rollback PinMux
    if(gtQSPI_PAD.CS0.mFunc[1] != PAD_FUNC_MAX)
    {
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.CS0.mId, gtQSPI_PAD.CS0.mFunc[1], CMD_END);
        gtQSPI_PAD.CS0.mFunc[1] = PAD_FUNC_MAX;
    }    

    if(gtQSPI_PAD.CS1.mFunc[1] != PAD_FUNC_MAX)
    {
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.CS1.mId, gtQSPI_PAD.CS1.mFunc[1], CMD_END);
        gtQSPI_PAD.CS1.mFunc[1] = PAD_FUNC_MAX;
    }    

    if(gtQSPI_PAD.DQ0.mFunc[1] != PAD_FUNC_MAX)
    {
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.DQ0.mId, gtQSPI_PAD.DQ0.mFunc[1], CMD_END);
        gtQSPI_PAD.DQ0.mFunc[1] = PAD_FUNC_MAX;
    }   
    
    if(gtQSPI_PAD.DQ1.mFunc[1] != PAD_FUNC_MAX)
    { 
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.DQ1.mId, gtQSPI_PAD.DQ1.mFunc[1], CMD_END);
        gtQSPI_PAD.DQ1.mFunc[1] = PAD_FUNC_MAX;
    }   

    if(gtQSPI_PAD.DQ2.mFunc[1] != PAD_FUNC_MAX)
    {
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.DQ2.mId, gtQSPI_PAD.DQ2.mFunc[1], CMD_END);
        gtQSPI_PAD.DQ2.mFunc[1] = PAD_FUNC_MAX;
    }   
    
    if(gtQSPI_PAD.DQ3.mFunc[1] != PAD_FUNC_MAX)
    { 
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.DQ3.mId, gtQSPI_PAD.DQ3.mFunc[1], CMD_END);
        gtQSPI_PAD.DQ3.mFunc[1] = PAD_FUNC_MAX;
    }  
    
    if(gtQSPI_PAD.SCK.mFunc[1] != PAD_FUNC_MAX)
    {
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtQSPI_PAD.SCK.mId, gtQSPI_PAD.SCK.mFunc[1], CMD_END);
        gtQSPI_PAD.SCK.mFunc[1] = PAD_FUNC_MAX;
    }   
}


INT32 ncLib_QSPI_Open(void)
{
    INT32 Ret = NC_SUCCESS;

    if(gbQSPIOpen == FALSE)
    {
        ncLib_SCU_Control(GCMD_SCU_ENA_CLK, SCU_CLK_ID_QSPI, CMD_END);  
        gbQSPIOpen = TRUE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_QSPI_Close(void)
{
    INT32 Ret = NC_SUCCESS;
    
    if(gbQSPIOpen == FALSE)
    {
        ncLib_SCU_Control(GCMD_SCU_DIS_CLK, SCU_CLK_ID_QSPI, CMD_END);  
        gbQSPIOpen = FALSE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_QSPI_Read(UINT32 Addr, UINT8 *pBuff, UINT32 nLength)
{
    INT32 Ret = NC_FAILURE;

    if(gbQSPIOpen == TRUE)
    {
        // Set PIN MUX
        ncLib_QSPI_PinMuxCtrlGet();

        // Data Read
        Ret = ncDrv_QSPI_ReadData(ON, Addr, (UINT32)pBuff, nLength);

        // Free PIN MUX
        ncLib_QSPI_PinMuxCtrlFree();
    }

    return Ret;
}


INT32 ncLib_QSPI_Write(UINT32 Addr, UINT8 *pBuff, UINT32 nLength)
{
    INT32 Ret = NC_FAILURE;

    return Ret;
}


INT32 ncLib_QSPI_Control(eQSPI_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    UINT32  QSPI_Clk;
    
    if(gbQSPIOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, QSPI no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */
            switch(Cmd)
            {
                case GCMD_QSPI_INIT:
                {
                    ncLib_QSPI_PinMuxCtrlGet();
                    ncDrv_QSPI_Init();
                }
                break;


                case GCMD_QSPI_DEINIT:
                {
                    ncDrv_QSPI_DeInit();
                    ncLib_QSPI_PinMuxCtrlFree();
                }
                break;


                case GCMD_QSPI_SET_BITRATE:
                {
                    QSPI_Clk = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_QSPI, CMD_END);
                    ncDrv_QSPI_SetBitRate((UINT32)ArgData[0], QSPI_Clk);
                }
                break;


                case GCMD_QSPI_LUT_READ:
                {
                    ncLib_QSPI_PinMuxCtrlGet();
                    Ret = ncDrv_QSPI_ReadData(OFF, ArgData[0], (UINT32)ArgData[1], ArgData[2]);
                    ncLib_QSPI_PinMuxCtrlFree();
                }
                break;


                case GCMD_QSPI_OSG_READ:
                {
                    Ret = ncDrv_QSPI_OSGReadData((eQSPI_OSG)ArgData[0], ArgData[1], ArgData[2], ArgData[3]);
                }
                break;
    
                default :
                {
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support QSPI command\n");
                    Ret = NC_FAILURE;
                }
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


/* End Of File */

