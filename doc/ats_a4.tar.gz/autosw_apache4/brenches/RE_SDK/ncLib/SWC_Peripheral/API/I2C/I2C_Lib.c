/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "I2C_Drv.h"










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    tPAD_INFO SCL;
    tPAD_INFO SDA;     
} tI2C_PAD, *ptI2C_PAD;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbI2COpen = FALSE;

tI2C_INFO gtI2C[MAX_OF_I2C_CH];

tI2C_PAD  gtI2C_PAD[MAX_OF_I2C_CH] = 
{
    {   // I2C-0
        {PAD_I2C0_SCL, {PAD_FUNC_1, PAD_FUNC_MAX}},
        {PAD_I2C0_SDA, {PAD_FUNC_1, PAD_FUNC_MAX}}
    },
    {   // I2C-1
        {PAD_I2C1_SCL, {PAD_FUNC_1, PAD_FUNC_MAX}},
        {PAD_I2C1_SDA, {PAD_FUNC_1, PAD_FUNC_MAX}}
    },
};










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void ncLib_I2C_PinMuxCtrlGet(eI2C_CH Ch)
{
    if(Ch < MAX_OF_I2C_CH)
    {
        // Back-up Current PinMux
        if(gtI2C_PAD[Ch].SCL.mFunc[1] == PAD_FUNC_MAX)
            gtI2C_PAD[Ch].SCL.mFunc[1] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gtI2C_PAD[Ch].SCL.mId, CMD_END);
        
        if(gtI2C_PAD[Ch].SDA.mFunc[1] == PAD_FUNC_MAX)
            gtI2C_PAD[Ch].SDA.mFunc[1] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gtI2C_PAD[Ch].SDA.mId, CMD_END);

        // Set PinMux
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtI2C_PAD[Ch].SCL.mId, gtI2C_PAD[Ch].SCL.mFunc[0], CMD_END);
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtI2C_PAD[Ch].SDA.mId, gtI2C_PAD[Ch].SDA.mFunc[0], CMD_END);
    }
}


static void ncLib_I2C_PinMuxCtrlFree(eI2C_CH Ch)
{
    if(Ch < MAX_OF_I2C_CH)
    {    
        // Rollback PinMux
        if(gtI2C_PAD[Ch].SCL.mFunc[1] != PAD_FUNC_MAX)
        {
            ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtI2C_PAD[Ch].SCL.mId, gtI2C_PAD[Ch].SCL.mFunc[1], CMD_END);
            gtI2C_PAD[Ch].SCL.mFunc[1] = PAD_FUNC_MAX;
        }

        if(gtI2C_PAD[Ch].SDA.mFunc[1] != PAD_FUNC_MAX)
        {
            ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtI2C_PAD[Ch].SDA.mId, gtI2C_PAD[Ch].SDA.mFunc[1], CMD_END); 
            gtI2C_PAD[Ch].SDA.mFunc[1] = PAD_FUNC_MAX;
        }
    }
}


static INT32 ncLib_I2C_InfoInit(eI2C_CH Ch, ptI2C_PARAM ptI2CParam)
{
    INT32 Ret = NC_FAILURE;
    
    if(ptI2CParam != NULL)
    {
        gtI2C[Ch].mI2C_ChInit = ON;
        gtI2C[Ch].mI2C_ChNum  = Ch;
        gtI2C[Ch].mI2C_SrcClk = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_I2C, CMD_END);
        gtI2C[Ch].mI2C_Param  = *ptI2CParam;

        // Set PIN MUX
        ncLib_I2C_PinMuxCtrlGet(Ch);

        Ret = NC_SUCCESS;
    }

    return Ret;
}


static void ncLib_I2C_InfoDeInit(eI2C_CH Ch)
{
    gtI2C[Ch].mI2C_ChInit = OFF;    
    gtI2C[Ch].mI2C_ChNum  = MAX_OF_I2C_CH;  
    gtI2C[Ch].mI2C_SrcClk = 0;    

    // Free PIN MUX
    ncLib_I2C_PinMuxCtrlFree(Ch);   
}


static INT32 ncLib_I2C_IsNotAliveCh(void)
{
    INT32 Ret = NC_SUCCESS;
    eI2C_CH Ch;
    
    for(Ch=I2C_CH0; Ch<MAX_OF_I2C_CH; Ch++)
    {
        if(gtI2C[Ch].mI2C_ChInit == ON)
            Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_I2C_Open(void)
{
    INT32 Ret = NC_SUCCESS;
    eI2C_CH Ch;
    
    if(gbI2COpen == FALSE)
    {
        ncLib_SCU_Control(GCMD_SCU_ENA_CLK, SCU_CLK_ID_I2C, CMD_END);  

        for(Ch=I2C_CH0; Ch<MAX_OF_I2C_CH; Ch++)
            ncLib_I2C_InfoDeInit(Ch); 
        
        gbI2COpen = TRUE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_I2C_Close(void)
{
    INT32 Ret;

    Ret = ncLib_I2C_IsNotAliveCh();
    if(Ret == NC_SUCCESS)
    {
        ncLib_SCU_Control(GCMD_SCU_DIS_CLK, SCU_CLK_ID_I2C, CMD_END);  
        gbI2COpen = FALSE;
    }

    return Ret;
}


INT32 ncLib_I2C_Read(eI2C_CH Ch, UINT16 RegAddr, void *pBuff, UINT32 UnitCnt)
{
    INT32 Ret = NC_FAILURE;

    if((gbI2COpen == TRUE) && (Ch < MAX_OF_I2C_CH) && (gtI2C[Ch].mI2C_ChInit == ON))
    {
        Ret = ncDrv_I2C_ReadData(&gtI2C[Ch], RegAddr, (UINT8*)pBuff, UnitCnt);
    }

    return Ret;
}


INT32 ncLib_I2C_Write(eI2C_CH Ch, UINT16 RegAddr, void *pBuff, UINT32 UnitCnt)
{
    INT32 Ret = NC_FAILURE;

    if((gbI2COpen == TRUE) && (Ch < MAX_OF_I2C_CH) && (gtI2C[Ch].mI2C_ChInit == ON))
    {
        Ret = ncDrv_I2C_WriteData(&gtI2C[Ch], RegAddr, (UINT8*)pBuff, UnitCnt);
    }

    return Ret;
}


INT32 ncLib_I2C_Control(eI2C_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    eI2C_CH Ch;


    if(gbI2COpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, I2C no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Defence Code
            */
            
            Ch = (eI2C_CH)ArgData[0];
            if(   (Ch >= MAX_OF_I2C_CH) 
               || ((Cmd != GCMD_I2C_INIT_CH) && (gtI2C[Ch].mI2C_ChInit == OFF)) )
            {
                Cmd = GCMD_I2C_MAX;
            }

            
            /*
            * Implement Control Command Function
            */
            
            switch(Cmd)
            {
                case GCMD_I2C_INIT_CH:
                {
                    Ret = ncLib_I2C_InfoInit(Ch, (ptI2C_PARAM)ArgData[1]); 
                    if(Ret == NC_SUCCESS)
                        Ret = ncDrv_I2C_Initialize(&gtI2C[Ch]);
                }
                break;


                case GCMD_I2C_DEINIT_CH:
                {
                    Ret = ncDrv_I2C_DeInitialize(&gtI2C[Ch]);
                    ncLib_I2C_InfoDeInit(Ch); 
                }
                break;


                case GCMD_I2C_SET_BITRATE:
                {
                    gtI2C[Ch].mI2C_Param.mHz = (UINT32)ArgData[1];
                    gtI2C[Ch].mI2C_SrcClk = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_I2C, CMD_END);
                    
                    Ret = ncDrv_I2C_SetClock(&gtI2C[Ch]);
                }
                break;


                case GCMD_I2C_SET_DEV_ADDR:
                {
                    gtI2C[Ch].mI2C_Param.mDevAddr = (UINT16)ArgData[1];
                    gtI2C[Ch].mI2C_Param.mDevBit  = (eI2C_DEV_BIT_TYPE)ArgData[2];

                    Ret = ncDrv_I2C_SetDevAddr(&gtI2C[Ch]);
                }
                break;


                case GCMD_I2C_SET_LENGTH_TYPE:
                {
                    gtI2C[Ch].mI2C_Param.mLengthType = (eI2C_LENGTH_TYPE)ArgData[1];
                }
                break;


                case GCMD_I2C_GET_INT_STS:
                {
                    Ret = ncDrv_I2C_GetIntSts(&gtI2C[Ch]);
                }
                break;


                case GCMD_I2C_SET_INT_CLS:
                {
                    ncDrv_I2C_SetIntClear(&gtI2C[Ch]);
                }
                break;


                case GCMD_I2C_SET_ACK_VALUE:
                {
                    ncDrv_I2C_sSetAckValue(Ch, (UINT32)ArgData[1]);
                }
                break;


                default :
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support I2C command\n");
                    Ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


/* End Of File */

