/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "GPIO_Drv.h"










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    eGPIO_GROUP mGroup;
    eGPIO_PORT  mPort;
} tGPIO_PAD, *ptGPIO_PAD;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbGPIOOpen = FALSE;

volatile ePAD_ID   gaGPIOtoPad[GPIO_GROUP_D][32];
volatile ePAD_FUNC gaGPIOtoPadFunc_org[GPIO_GROUP_D][32];

volatile tGPIO_PAD gaPadtoGPIO[PAD_MAX];
volatile ePAD_FUNC gaPadtoGPIOFunc_org[PAD_MAX];










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

INT32 ncLib_GPIO_Open(void)
{
    INT32 ret = NC_SUCCESS;
    ePAD_ID id = PAD_NTRST;
    UINT32 i,j;
    
    if(gbGPIOOpen == FALSE)
    {
        gbGPIOOpen = TRUE;

        // init map table (gpio to padmname)
        for(i=0; i<2; i++)
        {
            for(j=0; j<32; j++)
            {
                gaGPIOtoPad[i][j]         = id;
                gaGPIOtoPadFunc_org[i][j] = PAD_FUNC_MAX;

                gaPadtoGPIO[id].mGroup  = (eGPIO_GROUP)i;
                gaPadtoGPIO[id].mPort   = (eGPIO_PORT)j;
                gaPadtoGPIOFunc_org[id] = PAD_FUNC_MAX;
                
                if(++id >= PAD_MAX) break;
            }
        }
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_GPIO_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbGPIOOpen == TRUE)
    {
        gbGPIOOpen = FALSE;
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_GPIO_Read(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_GPIO_Write(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_GPIO_Control(eGPIO_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    

    if(gbGPIOOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, GPIO no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */
            switch(Cmd)
            {
                case GCMD_GPIO_ENA:
                {
                    switch(ArgData[0])
                    {
                        case GPIO_GROUP_A:
                        case GPIO_GROUP_B:
                        case GPIO_GROUP_C:
                        { 
                            gaGPIOtoPadFunc_org[ArgData[0]][ArgData[1]] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gaGPIOtoPad[ArgData[0]][ArgData[1]], CMD_END);
                            ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gaGPIOtoPad[ArgData[0]][ArgData[1]],  PAD_FUNC_4, CMD_END);
                        }
                        break;
                        
                        case GPIO_GROUP_D:
                        {
                            // Only GPIO Port (PIMMUX is unnecessary)
                        }
                        break;

                        case GPIO_GROUP_PAD:
                        {
                            gaPadtoGPIOFunc_org[ArgData[1]] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, ArgData[1], CMD_END);
                            ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, ArgData[1], PAD_FUNC_4, CMD_END);
                        }
                    } 
                }
                break;

                case GCMD_GPIO_DIS:
                {
                     switch(ArgData[0])
                    {
                        case GPIO_GROUP_A:
                        case GPIO_GROUP_B:
                        case GPIO_GROUP_C:
                        {  
                            ncDrv_GPIO_SetDirection((eGPIO_GROUP)ArgData[0], (eGPIO_PORT)ArgData[1], GPIO_DIR_IN);
                            
                            if(gaGPIOtoPadFunc_org[ArgData[0]][ArgData[1]] != PAD_FUNC_MAX)
                                ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gaGPIOtoPad[ArgData[0]][ArgData[1]],  gaGPIOtoPadFunc_org[ArgData[0]][ArgData[1]], CMD_END);
                            else
                                ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gaGPIOtoPad[ArgData[0]][ArgData[1]],  PAD_FUNC_0, CMD_END);  
                        }
                        break;
                        
                        case GPIO_GROUP_D:
                        {
                            // Only GPIO Port (PIMMUX is unnecessary)
                        }
                        break;

                        case GPIO_GROUP_PAD:
                        {
                            ncDrv_GPIO_SetDirection(gaPadtoGPIO[ArgData[1]].mGroup, gaPadtoGPIO[ArgData[1]].mPort, GPIO_DIR_IN);
                            
                            if(gaPadtoGPIOFunc_org[ArgData[1]] != PAD_FUNC_MAX)
                                ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, ArgData[1],  gaPadtoGPIOFunc_org[ArgData[1]], CMD_END);
                            else
                                ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, ArgData[1],  PAD_FUNC_0, CMD_END);  
                        }
                    } 
                }
                break;

                case GCMD_GPIO_SET_DIR:
                {
                    if(ArgData[0] == GPIO_GROUP_PAD)
                        ncDrv_GPIO_SetDirection(gaPadtoGPIO[ArgData[1]].mGroup, gaPadtoGPIO[ArgData[1]].mPort, (eGPIO_DIR)ArgData[2]);
                    else
                        ncDrv_GPIO_SetDirection((eGPIO_GROUP)ArgData[0], (eGPIO_PORT)ArgData[1], (eGPIO_DIR)ArgData[2]);
                }
                break;

                case GCMD_GPIO_SET_DATA:
                {
                    if(ArgData[0] == GPIO_GROUP_PAD)
                        ncDrv_GPIO_SetData(gaPadtoGPIO[ArgData[1]].mGroup, gaPadtoGPIO[ArgData[1]].mPort, (eGPIO_DATA)ArgData[2]);
                    else
                        ncDrv_GPIO_SetData((eGPIO_GROUP)ArgData[0], (eGPIO_PORT)ArgData[1], (eGPIO_DATA)ArgData[2]);
                }
                break;

                case GCMD_GPIO_GET_DATA:
                {
                    if(ArgData[0] == GPIO_GROUP_PAD)
                        Ret = ncDrv_GPIO_GetData(gaPadtoGPIO[ArgData[1]].mGroup, gaPadtoGPIO[ArgData[1]].mPort);
                    else
                        Ret = ncDrv_GPIO_GetData((eGPIO_GROUP)ArgData[0], (eGPIO_PORT)ArgData[1]);
                }
                break;

                case GCMD_GPIO_SET_INTC:
                {
                    if(ArgData[0] == GPIO_GROUP_PAD)
                        ncDrv_GPIO_SetIntc(gaPadtoGPIO[ArgData[1]].mGroup, gaPadtoGPIO[ArgData[1]].mPort, (eGPIO_INT_CH)ArgData[2], (BOOL)ArgData[3]);
                    else
                        ncDrv_GPIO_SetIntc((eGPIO_GROUP)ArgData[0], (eGPIO_PORT)ArgData[1], (eGPIO_INT_CH)ArgData[2], (BOOL)ArgData[3]);
                }
                break;

                default :
                {
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support GPIO command\n");
                    Ret = NC_FAILURE;
                }
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


/* End Of File */

