/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "Timer_Drv.h"










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbTimerOpen = FALSE;
volatile BOOL gbTimerCH[MAX_OF_TIMER_CH];










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static INT32 ncLib_TIMER_InfoInit(eTIMER_CH Ch, ptTIMER_PARAM ptTIMER)
{
    INT32 Ret = NC_FAILURE;

    if(ptTIMER != NULL)
    {
        gbTimerCH[Ch] = ON;

        Ret = NC_SUCCESS;
    }

    return Ret;
}


static void ncLib_TIMER_InfoDeInit(eTIMER_CH Ch)
{
    gbTimerCH[Ch] = OFF;
}


static INT32 ncLib_TIMER_IsNotAliveCh(void)
{
    INT32 Ret = NC_SUCCESS;
    eTIMER_CH Ch;
    
    for(Ch=TC_CH0; Ch<MAX_OF_TIMER_CH; Ch++)
    {
        if(gbTimerCH[Ch] == ON)
            Ret = NC_FAILURE;
    }

    return Ret;
}

INT32 ncLib_TIMER_Open(void)
{
	INT32 Ret = NC_SUCCESS;
    eTIMER_CH Ch;
	
	if(gbTimerOpen == FALSE)
	{
        ncLib_SCU_Control(GCMD_SCU_ENA_CLK, SCU_CLK_ID_TIMER, CMD_END); 
        
        for(Ch=TC_CH0; Ch<MAX_OF_TIMER_CH; Ch++)
            ncLib_TIMER_InfoDeInit(Ch); 
        
	    gbTimerOpen = TRUE;
	}
    else
    {
        Ret = NC_FAILURE;
    }

	return Ret;
}


INT32 ncLib_TIMER_Close(void)
{
	INT32 Ret = NC_SUCCESS;

    Ret = ncLib_TIMER_IsNotAliveCh();
    if(Ret == NC_SUCCESS)
    {
        ncLib_SCU_Control(GCMD_SCU_DIS_CLK, SCU_CLK_ID_TIMER, CMD_END);  
        gbTimerOpen = FALSE;
    }
    
    return Ret;
}


INT32 ncLib_TIMER_Read(void)
{
	INT32 Ret = NC_SUCCESS;
    
	return Ret;
}


INT32 ncLib_TIMER_Write(void)
{
	INT32 Ret = NC_SUCCESS;

	return Ret;
}


INT32 ncLib_TIMER_Control(eTIMER_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

	eTIMER_CH 	Ch;
    UINT32      TIMER_Clk;


	if(gbTimerOpen == TRUE)
	{
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


		if(bEndCmd == FALSE)
		{
			DEBUGMSG_SDK(MSGERR, "Error, TIMER no CMD_END!\n");
			Ret = NC_FAILURE;
		}
		else
		{
            /*
            * Defence Code
            */
            
            Ch = (eTIMER_CH)ArgData[0];
            if(   (Ch >= MAX_OF_TIMER_CH) 
               || ((Cmd != GCMD_TC_INIT_CH) && (gbTimerCH[Ch] == OFF)) )
            {
                Cmd = SCMD_TC_MAX;
            }

            
            /*
            * Implement Control Command Function
            */
            
			switch(Cmd)
			{
                case GCMD_TC_INIT_CH:
                {
                    Ret = ncLib_TIMER_InfoInit(Ch, (ptTIMER_PARAM)ArgData[1]);
                    if(Ret == NC_SUCCESS)
                    {
                        TIMER_Clk = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_TIMER, CMD_END);
                        Ret = ncDrv_TIMER_Init(Ch, (ptTIMER_PARAM)ArgData[1], TIMER_Clk);
                    }
                }
                break;


                case GCMD_TC_DEINIT_CH:
                {
                    ncLib_TIMER_InfoDeInit(Ch);
                }
                break;


                case GCMD_TC_START:
                {
                    ncDrv_TIMER_Start(Ch);
                }
                break;


                case GCMD_TC_STOP:
                {
                    ncDrv_TIMER_Stop(Ch);
                }
                break;


                case GCMD_TC_GET_INT_STS:
                {
                    Ret = ncDrv_TIMER_GetIntSts(Ch);
                }
                break;


                case SCMD_TC_WDT_REFRESH:
                {
                    ncDrv_TIMER_ReLoad(Ch);
                }
                break;


                case GCMD_TC_MAX:
                {
                    Ret = NC_FAILURE; 
                }
                break;


                default :
                {
                    Ret = NC_FAILURE;
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support TIMER command\n");
                }
                break;
			}
		}
	}
	else
	{
		Ret = NC_FAILURE;
	}

	return Ret;
}


/* End Of File */

