/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __I2C_DRV_H__
#define __I2C_DRV_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define rI2C_0_BASE                 APACHE_I2C_0_BASE
#define rI2C_1_BASE                 APACHE_I2C_1_BASE

#define rI2C_BASE(Ch)               (rI2C_0_BASE + (Ch*0x100000))


// I2C TimeOut - msec
#define I2C_WAIT_TIMEOUT            (1000)


//---------------------------------------------------------------------
//               Master Mode                             
//---------------------------------------------------------------------
// Master Mode - Clock Register
#define rI2C_PRERLO	                0x00
#define rI2C_PRERHI	                0x04


// Master Mode - Core/ISR On/Off Resgiter
#define rI2C_CTR	                0x08
    #define bI2C_CTR_EN 		    (1<<7)
    #define bI2C_CTR_IEN 		    (1<<6)


// Master Mode - Tx egister     
#define rI2C_TXR	                0x0C


// Master Mode - Rx egister  
#define rI2C_RXR	                0x0C


// Master Mode - Command Register 
#define rI2C_CR		                0x10
    #define bI2C_CR_STA 		    (1<<7)
    #define bI2C_CR_STO 		    (1<<6)
    #define bI2C_CR_RD 			    (1<<5)
    #define bI2C_CR_WR 			    (1<<4)
    #define bI2C_CR_NACK 		    (1<<3)
    #define bI2C_CR_ACK 		    (0<<3)
    #define bI2C_CR_INT             (1<<0)


// Master Mode - Status Register 
#define rI2C_SR		                0x10
    #define bI2C_SR_NACK            (1<<7)     // 0: ACK,  1: NACK
    #define bI2C_SR_BUSY            (1<<6)     // Busy
    #define bI2C_SR_LOST            (1<<5)     // Aibtation lost
    #define bI2C_SR_TIP             (1<<1)     // Transfer in progress
    #define bI2C_SR_INT             (1<<0)     // interrupt flag





//---------------------------------------------------------------------
//               Slave Mode                             
//---------------------------------------------------------------------
// Slave Mode - Core/ISR On/Off Resgiter
#define rI2C_SCTR	                0x80
    #define bI2C_SCTR_IEN_E         (1<<12) 
    #define bI2C_SCTR_IEN_S         (1<<11)
    #define bI2C_SCTR_IEN_A_R       (1<<10) 
    #define bI2C_SCTR_IEN_A_W       (1<<9)
    #define bI2C_SCTR_EN_A_CTRL     (1<<8)

    #define bI2C_SCTR_IEN_W 		(1<<2)
    #define bI2C_SCTR_IEN_R 		(1<<1)    
    #define bI2C_SCTR_EN 		    (1<<0)


// Slave Mode - Slave Address Resgiter
#define rI2C_SIDA	                0x84


// Slave Mode - Status Register 
#define rI2C_SST	                0x88
    #define bI2C_SST_INT            (3<<0) 
    #define bI2C_SST_INT_R          (1<<1)
    #define bI2C_SST_INT_W          (1<<0)


// Slave Mode - Rx Register
#define rI2C_SRXR_40	            0x8C
#define rI2C_SRXR_41	            0x90
#define rI2C_SRXR_42	            0x94
#define rI2C_SRXR_43	            0x98


// Slave Mode - Tx Register
#define rI2C_STXR_40	            0x8C
#define rI2C_STXR_41	            0x90
#define rI2C_STXR_42	            0x94
#define rI2C_STXR_43	            0x98

#define rI2C_SLV_ACK_CON            0x9C
#define rI2C_SLV_TX                 0xA0
#define rI2C_SLV_RX                 0xA4










/*
********************************************************************************
               ENUMERATION
********************************************************************************
*/

typedef enum 
{
    I2C_CMD_W,  
    I2C_CMD_R             
} eI2C_CMD_MODE;

typedef enum 
{
    I2C_COND_START = 0,                 // Start   
    I2C_COND_RESTART,                   // ReStart  
    I2C_COND_ACK,                       // ACK
    I2C_COND_NACK,                      // NAC
    I2C_COND_STOP,                      // Stop
    I2C_COND_NONE                       // No Condtion    
} eI2C_COND;










/*
********************************************************************************
               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    BOOL       mI2C_ChInit;
    eI2C_CH    mI2C_ChNum;  
    UINT32     mI2C_SrcClk;
    tI2C_PARAM mI2C_Param;
} tI2C_INFO, *ptI2C_INFO;










/*
********************************************************************************
               FUNCTION DEFINITIONS                              
********************************************************************************
*/

// I2C_SlaveDrv.c
extern void  ncDrv_I2C_sSetAckValue(eI2C_CH Ch, UINT32 Value);
extern void  ncDrv_I2C_sIntClear(eI2C_CH Ch);
extern INT32 ncDrv_I2C_sGetIntSts(eI2C_CH Ch);
extern void  ncDrv_I2C_sSetDevAddr(eI2C_CH Ch, UINT16 DevAddr);
extern INT32 ncDrv_I2C_sSetClock(eI2C_CH Ch, UINT32 RefClk, UINT32 TargetClk);
extern INT32 ncDrv_I2C_sReadData(eI2C_CH Ch, UINT16 RegAddr, UINT8* pBuff, UINT32 UnitCnt);
extern INT32 ncDrv_I2C_sWriteData(eI2C_CH Ch, UINT16 RegAddr, UINT8* pBuff, UINT32 UnitCnt);
extern INT32 ncDrv_I2C_sDeInitialize(eI2C_CH Ch);
extern INT32 ncDrv_I2C_sInitialize(eI2C_CH Ch, BOOL mIntEn, UINT16 DevAddr);


// I2C_MasterDrv.c
extern void  ncDrv_I2C_mIntClear(eI2C_CH Ch);
extern INT32 ncDrv_I2C_mGetIntSts(eI2C_CH Ch);
extern void  ncDrv_I2C_mSetDevAddr(eI2C_CH Ch, UINT16 DevAddr);
extern INT32 ncDrv_I2C_mSetClock(eI2C_CH Ch, UINT32 RefClk, UINT32 TargetClk);
extern INT32 ncDrv_I2C_mReadData(ptI2C_INFO ptI2C, UINT16 RegAddr, UINT8* pBuff, UINT32 UnitCnt);
extern INT32 ncDrv_I2C_mWriteData(ptI2C_INFO ptI2C, UINT16 RegAddr, UINT8* pBuff, UINT32 UnitCnt);
extern INT32 ncDrv_I2C_mDeInitialize(eI2C_CH Ch);
extern INT32 ncDrv_I2C_mInitialize(eI2C_CH Ch, BOOL mIntEn, UINT32 RefClk, UINT32 Hz);


// I2C_Drv.c
extern INT32 ncDrv_I2C_GetIntSts(ptI2C_INFO ptI2C);
extern void  ncDrv_I2C_SetIntClear(ptI2C_INFO ptI2C);
extern INT32 ncDrv_I2C_SetDevAddr(ptI2C_INFO ptI2C);
extern INT32 ncDrv_I2C_SetClock(ptI2C_INFO ptI2C);
extern INT32 ncDrv_I2C_ReadData(ptI2C_INFO ptI2C, UINT16 RegAddr, UINT8* pBuff, UINT32 UnitCnt);
extern INT32 ncDrv_I2C_WriteData(ptI2C_INFO ptI2C, UINT16 RegAddr, UINT8* pBuff, UINT32 UnitCnt);
extern INT32 ncDrv_I2C_DeInitialize(ptI2C_INFO ptI2C);
extern INT32 ncDrv_I2C_Initialize(ptI2C_INFO ptI2C);


#endif  /* __I2C_DRV_H__ */


/* End Of File */

