/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : INTC_Drv.c
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : ARM PrimeCell�� Generic Interrupt Controller (PL390) / Revision: r0p0
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "INTC_Drv.h"










/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

const UINT32 cGicConfig[(MAX_IRQ_NUM-32)*4]=
{
    // IRQ Number,          Type,               Priority,   CPU Target?
    IRQ_NUM_TIMER0,         GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+ 0)
    IRQ_NUM_TIMER1,         GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+ 1)
    IRQ_NUM_TIMER2,         GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+ 2)
    IRQ_NUM_TIMER3,         GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+ 3)
    IRQ_NUM_TIMER4,         GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+ 4)
    IRQ_NUM_TIMER5,         GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+ 5)
    IRQ_NUM_TIMER6,         GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+ 6)
    IRQ_NUM_TIMER7,         GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+ 7)

    IRQ_NUM_UART0,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+ 8)
    IRQ_NUM_UART1,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+ 9)
    IRQ_NUM_I2C0,           GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+10)
    IRQ_NUM_I2C1,           GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+11)
    IRQ_NUM_SPI0,           GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+12)
    IRQ_NUM_SPI1,           GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+13)
    IRQ_NUM_QSPI,           GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+14)

    IRQ_NUM_DMA_CHANNEL0,   GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+15)
    IRQ_NUM_DMA_CHANNEL1,   GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+16)
    IRQ_NUM_DMA_CHANNEL2,   GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+17)
    IRQ_NUM_DMA_CHANNEL3,   GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+18)

    IRQ_NUM_PWM0,           GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+19)
    IRQ_NUM_PWM1,           GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+20)
    IRQ_NUM_PWM3,           GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+21)
    IRQ_NUM_PWM4,           GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+22)

    IRQ_NUM_CAN,            GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+23)

    IRQ_NUM_GPIO0,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+24)
    IRQ_NUM_GPIO1,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+25)
    IRQ_NUM_GPIO2,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+26)
    IRQ_NUM_FMC,            GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+27)
    IRQ_NUM_SDC,            GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+28)
    IRQ_NUM_REV29,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+29)
    IRQ_NUM_REV30,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+30)
    IRQ_NUM_REV31,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+31)

    IRQ_NUM_ISP0,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+32)
    IRQ_NUM_ISP1,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+33)
    IRQ_NUM_ISP2,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+34)
    IRQ_NUM_ISP3,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+35)
    IRQ_NUM_ISP4,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+36)
    IRQ_NUM_ISP5,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+37)
    IRQ_NUM_ISP6,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+38)
    IRQ_NUM_ISP7,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+39)
    IRQ_NUM_ISP8,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+40)
    IRQ_NUM_ISP9,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+41)

    IRQ_NUM_VDUMP,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+42)
    IRQ_NUM_REV43,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+43)
    IRQ_NUM_REV44,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+44)
    IRQ_NUM_REV45,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+45)
    IRQ_NUM_REV46,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+46)
    IRQ_NUM_REV47,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+47)

    IRQ_NUM_RE_VDPD,        GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+48)
    IRQ_NUM_RE_SCALER,      GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+49)
    IRQ_NUM_RE_MOD,         GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+50)
    IRQ_NUM_RE_CE,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+51)
    IRQ_NUM_RE_LD,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+52)
    IRQ_NUM_REV53,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+53)
    IRQ_NUM_REV54,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+54)
    IRQ_NUM_REV55,          GIT_N_N_LEVEL,      240,        (CPU_TARGET_IF0),// (A+55)

    IRQ_NUM_NOC0,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+56)
    IRQ_NUM_NOC1,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+57)
    IRQ_NUM_NOC2,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+58)
    IRQ_NUM_NOC3,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+59)
    IRQ_NUM_NOC4,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+60)
    IRQ_NUM_NOC5,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+61)
    IRQ_NUM_REV62,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+62)

    IRQ_NUM_FAULT,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),// (A+63)
};










/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

typedef struct
{
    UINT32  mIRQnum;
    UINT32  mType;
    UINT32  mPriority;
    UINT32  mCpuTarget;

} stGicConfig;










/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

tGIC_RAISED_IRQ gRaisedIrq[RAISED_IRQS_TOTAL];
stGicConfig gGicConfig;

BOOL gbOnOffRasedIrq = FALSE;










/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

extern void ncLib_INTC_UserHandler(UINT32 nIntNum);










/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

/*
 * Distributor function control
 */
void   iGICDIST_SetInterfaceEnable(void);
void   iGICDIST_SetInterfaceDisable(void);
UINT32 iGICDIST_GetInterruptControllerType(void);
UINT32 iGICDIST_GetImplementerIdentification(void);
UINT32 iGICDIST_GetInterruptSecurity(UINT32 regOffset, UINT32 bitOffset);
void   iGICDIST_SetIrqEnable(UINT32 regOffset, UINT32 bitOffset);
void   iGICDIST_SetIrqDisable(UINT32 regOffset, UINT32 bitOffset);
void   iGICDIST_SetIrqPending(UINT32 regOffset, UINT32 bitOffset);
void   iGICDIST_ClearIrqPending(UINT32 regOffset, UINT32 bitOffset);
UINT32 iGICDIST_GetActiveStatus(UINT32 regOffset, UINT32 bitOffset);
UINT32 iGICDIST_GetPriorityLevel(UINT32 regOffset, UINT32 bitOffset);
void   iGICDIST_SetPriorityLevel(UINT32 regOffset, UINT32 bitOffset, UINT8 level);
UINT32 iGICDIST_GetIrqCpuTarget(UINT32 regOffset, UINT32 bitOffset);
void   iGICDIST_SetIrqCpuTarget(UINT32 regOffset, UINT32 bitOffset, UINT32 target);
UINT32 iGICDIST_GetInterruptConfigration(UINT32 regOffset, UINT32 bitOffset);
void   iGICDIST_SetInterruptConfigration(UINT32 regOffset, UINT32 bitOffset, UINT8 config);
UINT32 iGICDIST_GetPPIStatus(void);
UINT32 iGICDIST_GetSPIStatus(UINT32 regOffset, UINT32 bitOffset);
UINT32 iGICDIST_GetPeripheralIdentification(void);
UINT32 iGICDIST_GetPrimeCellIdentification(void);


/*
 * CPU interface function control
 */
void   iGICCPU_SetInterfaceEnable(void);
void   iGICCPU_SetInterfaceDisable(void);
UINT32 iGICCPU_GetPriorityMask(void);
void   iGICCPU_SetPriorityMask(UINT32 mask);
UINT32 iGICCPU_GetBinaryPoint(void);
void   iGICCPU_SetBinaryPoint(UINT32 point);
UINT32 iGICCPU_GetInterruptAcknowledge(void);
void   iGICCPU_SetEndOfInterrupt(UINT32 eoi);
UINT32 iGICCPU_GetRunningPriority(void);
UINT32 iGICCPU_GetHighestPendingInterrupt(void);
UINT32 iGICCPU_GetAliasedBinaryPoint(void);
void   iGICCPU_SetAliasedBinaryPoint(UINT8 aliase);
UINT32 iGICCPU_GetInterfaceIdentification(void);
UINT32 iGICCPU_GetPeripheralIdentification(void);
UINT32 iGICCPU_GetPrimeCellIdentification(void);










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

/*
 * Distributor function control
 */
void iGICDIST_SetInterfaceEnable(void)
{
    // [31:1] Reserved.
    // [   0] Enable
    //        1 interrupts forwarded, subject to the priority rules.
    //        0 interupts not forwarded.

    REGRW32(rGIC_DIST_BASE, rICDDCR) = 1;
}


void iGICDIST_SetInterfaceDisable(void)
{
    REGRW32(rGIC_DIST_BASE, rICDDCR) = 0;
}


UINT32 iGICDIST_GetInterruptControllerType(void)
{
    // [31:16] Reserved.
    // [15:11] Lockable Shared Peripheral Interrupt that the GIC contains.
    // [   10] number of security states that the GIC supports.
    // [ 9: 8] Reserved.
    // [ 7: 5] number of CPU Interfaces that the GIC provides.
    // [ 4: 0] number of INTIDs, to the nearest 32, that the DIST provides.

    return REGRW32(rGIC_DIST_BASE, rICDICTR) & 0xFFFF;
}


UINT32 iGICDIST_GetImplementerIdentification(void)
{
    // identification information rICDIIDR
    // [31:24] impl_ver Returns the product identifier. For a GIC (PL390) this field returns 0x00.
    // [23:12] rev_num Returns the revision number of the GIC. For revision r0p0, this field returns 0x000.
    // [11: 0] implementer Returns the JEP106 code of the company that implemented the Distributor RTL, that is, ARM.
    // [11: 8] = 0x4, that is, the JEP106 continuation code for ARM
    // [    7] = 0
    // [ 6: 0] = b0111011, that is, the JEP106 code [6:0] for ARM.

    return REGRW32(rGIC_DIST_BASE, rICDIIDR);
}


UINT32 iGICDIST_GetInterruptSecurity(UINT32 regOffset, UINT32 bitOffset)
{
    // 0x0080 [31:16] ppi_security_if<n> Register ~~ Security status for PPI [31~16]
    // 0x0080 [15: 0] sgi_security_if<n> Register ~~ Security status for SGI [15~0]
    // 0x0084 [31: 0] spi_security Registers ~~ Security status for SPI [63~32]
    // ~~
    // 0x00FC [27: 0] spi_security Registers ~~ Security status for SPI [1019~992]

    return (REGRW32(rGIC_DIST_BASE, rICDISR+regOffset) >> bitOffset) & 0x1;
}


void iGICDIST_SetIrqEnable(UINT32 regOffset, UINT32 bitOffset)
{
    // 0x0100 [31:16] ppi_enable_if<n> Register ~~ Set-enable for PPI [31~16]
    // 0x0100 [15: 0]
    // 0x0104 [31: 0] spi_security Registers ~~ Set-enable for SPI [63~32]
    // ~~
    // 0x017C [27: 0] spi_security Registers ~~ Set-enable for SPI [1019~992]

    REGRW32(rGIC_DIST_BASE, rICDISER+regOffset) = (1 << bitOffset);
}


void iGICDIST_SetIrqDisable(UINT32 regOffset, UINT32 bitOffset)
{
    // 0x0180 [31:16] ppi_enable_if<n> Register ~~ Clear-enable for PPI [31~16]
    // 0x0180 [15: 0]
    // 0x0184 [31: 0] spi_security Registers ~~ Clear-enable for SPI [63~32]
    // ~~
    // 0x01FC [27: 0] spi_security Registers ~~ Clear-enable for SPI [1019~992]

    REGRW32(rGIC_DIST_BASE, rICDICER+regOffset) = (1 << bitOffset);
}


void iGICDIST_SetIrqPending(UINT32 regOffset, UINT32 bitOffset)
{
    // 0x0200 [31:16] ppi_pending_if<n> Register ~~ Set-pending for PPI [31~16]
    // 0x0200 [15: 0] sgi_pending_if<n> Register ~~ Set-pending for SGI [15~0]
    // 0x0204 [31: 0] spi_pending Registers ~~ Set-pending for SPI [63~32]
    // ~~
    // 0x027C [27: 0] spi_pending Registers ~~ Set-pending for SPI [1019~992]

    REGRW32(rGIC_DIST_BASE, rICDISPR+regOffset) = (1 << bitOffset);
}


void iGICDIST_ClearIrqPending(UINT32 regOffset, UINT32 bitOffset)
{
    // 0x0280 [31:16] ppi_pending_if<n> Register ~~ Clear-pending for PPI [31~16]
    // 0x0280 [15: 0] sgi_pending_if<n> Register ~~ Clear-pending for SGI [15~0]
    // 0x0284 [31: 0] spi_pending Registers ~~ Clear-pending for SPI [63~32]
    // ~~
    // 0x02FC [27: 0] spi_pending Registers ~~ Clear-pending for SPI [1019~992]

    REGRW32(rGIC_DIST_BASE, rICDICPR+regOffset) = (1 << bitOffset);
}


UINT32 iGICDIST_GetActiveStatus(UINT32 regOffset, UINT32 bitOffset)
{
    // 0x0300 [31:16] ppi_active_if<n> Register ~~ Active status for PPI [31~16]
    // 0x0300 [15: 0] sgi_active_if<n> Register ~~ Active status for SGI [15~0]
    // 0x0304 [31: 0] spi_active Registers ~~ Active status for SPI [63~32]
    // ~~
    // 0x037C [27: 0] spi_active Registers ~~ Active status for SPI [1019~992]

    return REGRW32(rGIC_DIST_BASE, rICDABR+regOffset) & (1 << bitOffset);
}


UINT32 iGICDIST_GetPriorityLevel(UINT32 regOffset, UINT32 bitOffset)
{
    // 0x0400 [31:0] priority_sgi_<INTID>_if<n> Registers ~~ SGI [INTID3~INTID0]
    // 0x0410 [31:0] priority_ppi_<INTID>_if<n> Registers ~~ PPI [INTID19~INTID16]
    // 0x0420 [31:0] priority_spi_<INTID> Registers ~~ SPI [INTID35~INTID32]
    // ~~
    // 0x07F8 [31:0] priority_spi_<INTID> Registers ~~ SPI [INTID1019~INTID1016]

    return (REGRW32(rGIC_DIST_BASE, rICDIPR+regOffset) >> bitOffset) & 0xFF;
}


void iGICDIST_SetPriorityLevel(UINT32 regOffset, UINT32 bitOffset, UINT8 level)
{
    REGRW32(rGIC_DIST_BASE, rICDIPR+regOffset) &= ~(0xFF << bitOffset);
    REGRW32(rGIC_DIST_BASE, rICDIPR+regOffset) |= (level << bitOffset);
}


UINT32 iGICDIST_GetIrqCpuTarget(UINT32 regOffset, UINT32 bitOffset)
{
    // 0x0800 [31:0] [INTID3~INTID0]
    // 0x0810 [31:0] [INTID19~INTID16]
    // 0x0820 [31:0] targets_spi_<INTID> Registers ~~ SPI [INTID35~INTID32]
    // ~~
    // 0x0BF8 [31:0] targets_spi_<INTID> Registers ~~ SPI [INTID1019~INTID1016]

    return (REGRW32(rGIC_DIST_BASE, rICDIPTR+regOffset) >> bitOffset) & 0xFF;
}


void iGICDIST_SetIrqCpuTarget(UINT32 regOffset, UINT32 bitOffset, UINT32 target)
{
    REGRW32(rGIC_DIST_BASE, rICDIPTR+regOffset) &= ~(0xFF << bitOffset);
    REGRW32(rGIC_DIST_BASE, rICDIPTR+regOffset) |= (target << bitOffset);
}


UINT32 iGICDIST_GetInterruptConfigration(UINT32 regOffset, UINT32 bitOffset)
{
    // 0x0C00 [31:0] [INTID15~INTID0]
    // 0x0C04 [31:0] int_config INTID for PPI [INTID31~INTID16]
    // 0x0C08 [31:0] int_config INTID for SPI [INTID47~INTID32]
    // ~~
    // 0x0CFC [31:0] int_config INTID for SPI [INTID1019~INTID1008]

    return (REGRW32(rGIC_DIST_BASE, rICDICR+regOffset) >> bitOffset) & 0x3;
}


void iGICDIST_SetInterruptConfigration(UINT32 regOffset, UINT32 bitOffset, UINT8 config)
{
    REGRW32(rGIC_DIST_BASE, rICDICR+regOffset) &= ~(0x03 << bitOffset);
    REGRW32(rGIC_DIST_BASE, rICDICR+regOffset) |= (config << bitOffset);
}


UINT32 iGICDIST_GetPPIStatus(void)
{
    // Each bit returns the status of the ppi_c<n>
    // [15:0] inputs for CPU Interface<n>.

    return REGRW32(rGIC_DIST_BASE, rICDPPISR) & 0xFFFF;
}


UINT32 iGICDIST_GetSPIStatus(UINT32 regOffset, UINT32 bitOffset)
{
    // Each bit returns the status of an spi[987:0] input
    // 0x0D04 [31:0] spi_status for spi [31~0]
    // ~~
    // 0x0D7C [31:0] spi_status for spi [987~960]

    return (REGRW32(rGIC_DIST_BASE, rICDSPISR+regOffset) >> bitOffset) & 0x01;
}


UINT32 iGICDIST_GetPeripheralIdentification(void)
{
    // identification information rICDPIR, rICDPIR74, rICDPIR30

    return REGRW32(rGIC_DIST_BASE, rICDPIR) & 0xFF;
}


UINT32 iGICDIST_GetPrimeCellIdentification(void)
{
    UINT32 ident = 0;

    // identification information rICDPCIR30

    ident = REGRW32(rGIC_DIST_BASE, rICDPCIR30) & 0xFF;
    ident |= (REGRW32(rGIC_DIST_BASE, rICDPCIR30+0x4) & 0xFF) << 8;
    ident |= (REGRW32(rGIC_DIST_BASE, rICDPCIR30+0x8) & 0xFF) << 16;
    ident |= (REGRW32(rGIC_DIST_BASE, rICDPCIR30+0xC) & 0xFF) << 24;

    return ident;
}


/*
 * CPU interface function control
 */

void iGICCPU_SetInterfaceEnable(void)
{
    // [0] Enable Enable for the signaling of Group 1 interrupts
    //     by the CPU interface to the connected processor.
    //     0 Disable signaling of interrupts
    //     1 Enable signaling of interrupts.

    REGRW32(rGIC_CPU_BASE, rICCICR) = 1;
}


void iGICCPU_SetInterfaceDisable(void)
{
    REGRW32(rGIC_CPU_BASE, rICCICR) = 0;
}


UINT32 iGICCPU_GetPriorityMask(void)
{
    //                                              levels
    // [7:0] 0x00-0xFF (0-255), all values          256
    // [7:1] 0x00-0xFE (0-254), even values only    128
    // [7:2] 0x00-0xFC (0-252), in steps of 4       64
    // [7:3] 0x00-0xF8 (0-248), in steps of 8       32
    // [7:4] 0x00-0xF0 (0-240), in steps of 16      16

    return REGRW32(rGIC_CPU_BASE, rICCPMR) & 0xFF;
}


void iGICCPU_SetPriorityMask(UINT32 mask)
{
    REGRW32(rGIC_CPU_BASE, rICCPMR) = (mask & 0xFF);
}


UINT32 iGICCPU_GetBinaryPoint(void)
{
    // [2:0] Binary point

    return REGRW32(rGIC_CPU_BASE, rICCBPR) & 0x7;
}


void iGICCPU_SetBinaryPoint(UINT32 point)
{
    REGRW32(rGIC_CPU_BASE, rICCBPR) = (point & 0x7);
}


UINT32 iGICCPU_GetInterruptAcknowledge(void)
{
    return REGRW32(rGIC_CPU_BASE, rICCIAR);
}


void iGICCPU_SetEndOfInterrupt(UINT32 eoi)
{
    REGRW32(rGIC_CPU_BASE, rICCEOIR) = (eoi & 0x3FF);
}


UINT32 iGICCPU_GetRunningPriority(void)
{
    return REGRW32(rGIC_CPU_BASE, rICCRPR) & 0xFF;
}


UINT32 iGICCPU_GetHighestPendingInterrupt(void)
{
    return REGRW32(rGIC_CPU_BASE, rICCHPIR);
}


UINT32 iGICCPU_GetAliasedBinaryPoint(void)
{
    return REGRW32(rGIC_CPU_BASE, rICCABPR) & 0x7;
}


void iGICCPU_SetAliasedBinaryPoint(UINT8 aliase)
{
    REGRW32(rGIC_CPU_BASE, rICCABPR) = (aliase & 0x7);
}


UINT32 iGICCPU_GetInterfaceIdentification(void)
{
    // [31:20] 0x390 An IMPLEMENTATION DEFINED product identifier.
    // [19:16] 0x1 The value of this field depends on the GIC architecture version, as follows.
    // [15:12] 0x0 An IMPLEMENTATION DEFINED revision number for the CPU interface.
    // [11:00] 0x43B For an ARM implementation, the value of this field is 0x43B.

    return REGRW32(rGIC_CPU_BASE, rICCIIDR);
}


UINT32 iGICCPU_GetPeripheralIdentification(void)
{
    // identification information rICDPIR, rICCPIR74, rICDPIR30

    return REGRW32(rGIC_CPU_BASE, rICCPIR) & 0xF;
}


UINT32 iGICCPU_GetPrimeCellIdentification(void)
{
    UINT32 ident = 0;

    // identification information rICCPCIR30

    ident = REGRW32(rGIC_CPU_BASE, rICCPCIR30) & 0xFF;
    ident |= (REGRW32(rGIC_CPU_BASE, rICCPCIR30+0x4) & 0xFF) << 8;
    ident |= (REGRW32(rGIC_CPU_BASE, rICCPCIR30+0x8) & 0xFF) << 16;
    ident |= (REGRW32(rGIC_CPU_BASE, rICCPCIR30+0xC) & 0xFF) << 24;

    return ident;
}


/*
 * CPU Driver level control function
 */

void ncDrv_GIC_HaltHandler(void) // Halt_Handler
{
    DEBUGMSG_SDK(MSGINFO, "Halt_Handler()\n");
}


void ncDrv_GIC_IrqHandler(void)  // GIC_IrqHandler
{
    UINT32 nIrqNum;

    /* Ack the IRQ */
    nIrqNum = iGICCPU_GetInterruptAcknowledge();
    
    /* Register IRQ number on the raised irqs structures */
    if(gbOnOffRasedIrq == TRUE)
    {
        ncDrv_GIC_SetRaisedIrq(nIrqNum);
    }

    /* We disable the irq otherwise same irq would reassert since
    the peripheral irq pending register isn't cleared. */
    ncDrv_GIC_DisableIrq(nIrqNum);

    /* Service routine */
    ncLib_INTC_UserHandler(nIrqNum);

    /* Clear IRQ pending */
    ncDrv_GIC_ClearPendingIrq(nIrqNum);

    /* Set the end-of-interrupt for this irq */
    iGICCPU_SetEndOfInterrupt(nIrqNum);

    /* We cleared the peripheral irq, so enable the irq */
    ncDrv_GIC_EnableIrq(nIrqNum);
}


INT32 ncDrv_GIC_Initialize(void)
{
    INT32 i;

    /* Disable Distributor and CPU Interface */
    iGICDIST_SetInterfaceDisable();
    iGICCPU_SetInterfaceDisable();

    // Disable all irqs on all gics
    ncDrv_GIC_DisableAllIrqs();

    /* Configure IRQs */
    for(i = IRQS_START; i < IRQS_TOTAL; i++)
    {

        // Set CPU target for each interrupt
        ncDrv_GIC_SetIrqCPUTarget(i, CPU_TARGET_IF0);
        //ncDrv_GIC_SetIrqCPUTarget(i, CPU_TARGET_IF1);
        //ncDrv_GIC_SetIrqCPUTarget(i, CPU_TARGET_IF2);
        //ncDrv_GIC_SetIrqCPUTarget(i, CPU_TARGET_IF3);


        // Set interrupt type
        // Useless Assignment - This code assigns the variable the same value it already had
        if( 
            ((i >= IRQ_NUM_ISP0) && (i <= IRQ_NUM_VDUMP))
         || ((i >= IRQ_NUM_SPI0) && (i <= IRQ_NUM_SPI1))
         || ((i >= IRQ_NUM_PWM0) && (i <= IRQ_NUM_PWM4))
         || ((i >= IRQ_NUM_NOC0) && (i <= IRQ_NUM_NOC5))
         || (i == IRQ_NUM_FAULT)
         )
        {
            ncDrv_GIC_SetInterruptConfigration(i, GIT_1_N_EDGE);
        }
        else
        {
            ncDrv_GIC_SetInterruptConfigration(i, GIT_N_N_LEVEL);
        }

        // Set priority of interrupt
        ncDrv_GIC_SetPriorityLevel(i, DEF_INTC_PRIORITY_LEVEL);
    }

    /* Enable Distributor and CPU Interface */
    iGICDIST_SetInterfaceEnable();
    iGICCPU_SetInterfaceEnable();

    /* Set priority mask */
    iGICCPU_SetPriorityMask(GPM_LEVEL_256);

    /* Clear all pending IRQs */
    ncDrv_GIC_EnableAllIrqsClearPending();

    ncDrv_GIC_ClearAllRaisedIrq();

    /* Enable global interrupt */
    __CORE_INT_EN();

    return NC_SUCCESS;
}


INT32 ncDrv_GIC_Deinitialize(void)
{
    /* Disable Distributor and CPU interface */
    iGICDIST_SetInterfaceDisable();
    iGICCPU_SetInterfaceDisable();

    /* Disable global interrupt */
    __CORE_INT_DIS();

    return NC_SUCCESS;
}


void ncDrv_GIC_EnableIrq(INT32 irq)    // enable set dist_icdiser
{
    UINT32 regOffset, bitOffset;

    regOffset = (irq / IRQS_PER_REG) << 2;
    bitOffset = irq % IRQS_PER_REG;

    iGICDIST_SetIrqEnable(regOffset, bitOffset);
}


void ncDrv_GIC_DisableIrq(INT32 irq)   // enable clear dist_icdicer
{
    UINT32 regOffset, bitOffset;

    regOffset = (irq / IRQS_PER_REG) << 2;
    bitOffset = irq % IRQS_PER_REG;

    iGICDIST_SetIrqDisable(regOffset, bitOffset);
}


void ncDrv_GIC_EnableAllIrqs(void)  // all enable set dist_icdiser
{
    UINT32 i, regOffset, bitOffset;

    for(i = IRQS_START; i < IRQS_TOTAL; i++)
    {
        regOffset = (i / IRQS_PER_REG) << 2;
        bitOffset = i % IRQS_PER_REG;

        iGICDIST_SetIrqEnable(regOffset, bitOffset);
    }
}


void ncDrv_GIC_DisableAllIrqs(void)  // all enable clear dist_icdicer
{
    UINT32 i, regOffset, bitOffset;

    for(i = IRQS_START; i < IRQS_TOTAL; i++)
    {
        regOffset = (i / IRQS_PER_REG) << 2;
        bitOffset = i % IRQS_PER_REG;

        iGICDIST_SetIrqDisable(regOffset, bitOffset);
    }
}


void ncDrv_GIC_ClearPendingIrq(INT32 irq)
{
    UINT32 regOffset, bitOffset;

    regOffset = (irq / IRQS_PER_REG) << 2;
    bitOffset = irq % IRQS_PER_REG;

    iGICDIST_ClearIrqPending(regOffset, bitOffset);
}


void ncDrv_GIC_EnableAllIrqsClearPending(void)  // all enable pending clear dist_icdicer
{
    UINT32 i, regOffset, bitOffset;

    for(i = IRQS_START; i < IRQS_TOTAL; i++)
    {
        regOffset = (i / IRQS_PER_REG) << 2;
        bitOffset = i % IRQS_PER_REG;

        iGICDIST_ClearIrqPending(regOffset, bitOffset);
    }
}


void ncDrv_GIC_OnOffRaisedIrq(BOOL OnOff)
{
    gbOnOffRasedIrq = OnOff;
}


void ncDrv_GIC_ClearAllRaisedIrq(void)
{
    INT32 i;

    memset(gRaisedIrq, 0, RAISED_IRQS_TOTAL*sizeof(tGIC_RAISED_IRQ));

    for(i = 0; i < RAISED_IRQS_TOTAL; i++)
    {
        gRaisedIrq[i].irqNo = INVALID_IRQ_NO;
    }
}


void ncDrv_GIC_SetRaisedIrq(INT32 irq)
{
    INT32 i;

    for(i = 0; i < RAISED_IRQS_TOTAL; i++)
    {
        if(gRaisedIrq[i].irqNo == INVALID_IRQ_NO)
        {
            gRaisedIrq[i].irqNo = irq;

            return;
        }
    }
}


INT32 ncDrv_GIC_CheckRaisedIrq(INT32 irq)
{
    INT32 i;

    for(i = 0; i < RAISED_IRQS_TOTAL; i++)
    {
        if(irq == gRaisedIrq[i].irqNo)
        {
            gRaisedIrq[i].irqNo = INVALID_IRQ_NO;

            return TRUE;
        }
    }

    return FALSE;
}


INT32 ncDrv_GIC_WaitIrq(INT32 irq, UINT32 timeout)
{
    while(timeout)
    {
        if(ncDrv_GIC_CheckRaisedIrq(irq)) break;
        timeout--;
    }

    if(timeout == 0)
    {
        return NC_FAILURE;
    }

    return NC_SUCCESS;
}


void ncDrv_GIC_SetIrqCPUTarget(UINT32 irq, UINT32 value)
{
    UINT32 regOffset, bitOffset;

    regOffset = (irq / TARGETS_PER_REG) << 2;

    bitOffset = irq % TARGETS_PER_REG;
    bitOffset *= TARGET_FIELD_WIDTH;

    value &= TARGET_FIELD_MASK;

    iGICDIST_SetIrqCpuTarget(regOffset, bitOffset, value);
}


void ncDrv_GIC_SetInterruptConfigration(UINT32 irq, UINT32 value)
{
    UINT32 regOffset, bitOffset;

#if 1 // Only Apache4 (test code)
    // Note that the following code must be enabled after FPGQ_DB_r1609.
    UINT32 regValue;
    UINT32 setValue = 0;
    
    if((value == GIT_1_N_EDGE) || (value == GIT_N_N_EDGE))
        setValue = 1;
    
    if(irq < IRQ_NUM_ISP0)
    {
        regOffset = 0x140;
        bitOffset = irq - IRQ_NUM_TIMER0;
    }
    else
    {
        regOffset = 0x144;        
        bitOffset = irq - IRQ_NUM_ISP0;
    }
    
    regValue = REGRW32(APACHE_SYSCON_BASE, regOffset);
    regValue &= ~(1<<bitOffset);
    if(setValue)
        regValue |= (setValue<<bitOffset);
    REGRW32(APACHE_SYSCON_BASE, regOffset) = regValue;
#endif

    regOffset = (irq / CONFIGS_PER_REG) << 2;

    bitOffset = irq % CONFIGS_PER_REG;
    bitOffset *= CONFIG_FIELD_WIDTH;

    value &= CONFIG_FIELD_MASK;

    iGICDIST_SetInterruptConfigration(regOffset, bitOffset, value);    
}


void ncDrv_GIC_SetPriorityLevel(UINT32 irq, UINT32 value)
{
    UINT32 regOffset;
    UINT32 bitOffset;

    regOffset = (irq / PRIOS_PER_REG) << 2;

    bitOffset = irq % PRIOS_PER_REG;
    bitOffset *= PRIO_FIELD_WIDTH;

    value &= PRIO_FIELD_MASK;

    iGICDIST_SetPriorityLevel(regOffset, bitOffset, value);
}


void ncDrv_GIC_SGITrigger(UINT32 irq)
{
    REGRW32(rGIC_DIST_BASE, rICDSGIR) = (0x2<<24)|(irq<<0);
}


/* End Of File */

