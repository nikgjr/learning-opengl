/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "SCU_Drv.h"










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tSUC_CLK
{
    UINT32      mOSC;    

    UINT32      mCPU;
    UINT32      mAXI;
    UINT32      mAPB;
    UINT32      mDDR;
    UINT32      mQSPI;
} tSCU_CLK, *ptSCU_CLK;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tSCU_CLK tSCUClk = {
                                27*MHZ,     // OSC
                                50*MHZ,     // CPU
                                50*MHZ,     // AXI
                                25*MHZ,     // APB
                                64*MHZ,     // DDR
                                25*MHZ      // QSPI
                            };










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncDrv_SCU_GetPad(UINT32 Offset, UINT32 Pos)
{
    return (REGRW32(rICU_BASE, Offset)>>Pos)&0xf;
}


void ncDrv_SCU_SetPad(UINT32 Func, UINT32 Offset, UINT32 Pos)
{
    UINT32 Reg;

    Reg = REGRW32(rICU_BASE, Offset);
    Reg &= ~(0x7<<Pos);         // Clear
    Reg |= ((Func&0x7)<<Pos);   // Set
    REGRW32(rICU_BASE, Offset) = Reg;
}


void ncDrv_SCU_GenClk(void)
{
    //------------------------------------
    // Do not delete it...
    SYS_TICK_CLK = tSCUClk.mAPB;
    //------------------------------------

    
}


INT32 ncDrv_SCU_GetPinMux(UINT32 Pad)
{
    INT32 ret = NC_SUCCESS;

    UINT32 Offset = 0;
    UINT32 Pos    = 0;
    
    if(Pad < PAD_MAX)
    {
        if(Pad != PAD_NTRST)
        {
            Offset = (Pad / 8)*4;
            Pos    = (Pad % 8)*4;
        }
        
        ret = ncDrv_SCU_GetPad(Offset, Pos);
    }
    else
    {
        DEBUGMSG_SDK(MSGERR, "[SCU_Drv] PIM MUX Set Error (%d)\n", Pad);
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncDrv_SCU_SetPinMux(UINT32 Pad, UINT32 Func)
{
    INT32  ret = NC_SUCCESS;
 
    UINT32 Offset = 0;
    UINT32 Pos    = 0;

    if(Pad < PAD_MAX)
    {
        if(Pad != PAD_NTRST)
        {
            Offset = (Pad / 8)*4;
            Pos    = (Pad % 8)*4;
        }
        
        ncDrv_SCU_SetPad(Func, Offset, Pos);
    }
    else
    {
        DEBUGMSG_SDK(MSGERR, "[SCU_Drv] PIM MUX Set Error (%d)\n", Pad);
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncDrv_SCU_GetSystemClock(UINT32 nClkNum)
{
    INT32 Clock = NC_FAILURE;

    switch(nClkNum)
    {
        case SCU_CLK_ID_CPU:
            Clock = tSCUClk.mCPU;
            break;

        case SCU_CLK_ID_AXI:
        case SCU_CLK_ID_DMA:
            Clock = tSCUClk.mAXI;
            break;

        case SCU_CLK_ID_APB:
        case SCU_CLK_ID_SSPI:
        case SCU_CLK_ID_UART:
        case SCU_CLK_ID_TIMER:
        case SCU_CLK_ID_I2C:
        case SCU_CLK_ID_PWM:
            Clock = tSCUClk.mAPB;
            break;

        case SCU_CLK_ID_QSPI:
            Clock = tSCUClk.mQSPI;
            break;
            
        case SCU_CLK_ID_CAN:
            break;

        case SCU_CLK_ID_DDR:
            Clock = tSCUClk.mDDR;
            break;

        case SCU_CLK_ID_ADC: 
            break;

        case SCU_CLK_ID_TS:
            break;
            
        default:
            break;
    }

    return Clock;
}


INT32 ncDrv_SCU_EnableClk(eSCU_CLK_ID Id)
{
    INT32 ret = NC_SUCCESS;

    switch (Id)
    {
        case SCU_CLK_ID_I2C:
        {
            REGRW32(rSCU_BASE, rSCU_RST_BUS_PULSE) |= 1<<20;
            nc_mdelay(1);
        }
        break;

        case SCU_CLK_ID_SSPI:
        {
            REGRW32(rSCU_BASE, rSCU_RST_BUS_PULSE) |= 1<<27;
            nc_mdelay(1);
        }
        break;

        default:
            ret = NC_FAILURE;
        break;
    }

    return ret;
}


INT32 ncDrv_SCU_DisableClk(eSCU_CLK_ID Id)
{
    INT32 ret = NC_SUCCESS;

    switch (Id)
    {
        case SCU_CLK_ID_I2C:
        break;

        case SCU_CLK_ID_SSPI:
        break;

        default:
            ret = NC_FAILURE;
        break;
    }

    return ret;
}


UINT32 ncDrv_SCU_GetData(UINT32 offset)
{
    return REGRW32(rSCU_BASE, offset);
}


UINT32 ncDrv_SCU_SetData(UINT32 offset, UINT32 data)
{
    REGRW32(rSCU_BASE, offset) = data;
    
    return NC_SUCCESS;
}


INT32 ncDrv_SCU_Init(void)
{
    INT32 ret = NC_SUCCESS;

    ncDrv_SCU_GenClk();

    return ret;
}


INT32 ncDrv_SCU_DeInit(void)
{
    INT32  ret = NC_SUCCESS;

    return ret;
}


/* End Of File */

