/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __DMA_DRV_H__
#define __DMA_DRV_H__


/*
********************************************************************************
*               INCLUDE                                    
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define rDMAC_BASE(ch)              (APACHE_DMAC_BASE + (ch*0x100))



//------------------------------------------------------------------------------
#define rDMAC_SRC                   0x00        // RxTx : Source Addr Register 
                                                //        - [31: 0] : Is start address of read buffer.


//------------------------------------------------------------------------------
#define rDMAC_DEST                  0x04        // RxTx : Destination Addr Register 
                                                //        - [31: 0] : Is start address of write buffer.


//------------------------------------------------------------------------------
#define rDMAC_SIZE                  0x08        // RxTx : Transfer Size Register 
                                                //        - [31:10] : Reserved
    #define bDMAC_SIZE_MASK         (0x3FF)     //        - [ 9: 0] : Size of buffer to transfer. Value is in bytes
    #define bDMAC_SIZE_MAX          (0x200)     //        -           (1023) b'11 1111 1111 => Align => (512) b'10 0000 0000


//------------------------------------------------------------------------------
#define rDMAC_LINK                  0x0C        // RxTx : Next(Link) Addr Register 
                                                //        - [31:02] : Next Address
    #define bDMAC_LINK_END          (1<<1)      //        -     [1] : Data Command Last Flag
    #define bDMAC_LINK_IEN          (1<<0)      //        -     [0] : Interrupt On/Off Flag 


//------------------------------------------------------------------------------
#define rDMAC_CR0                   0x10        // RxTx : Read Ctrl Register 
    #define bDMAC_CR0_INCR          (31)        //        -    [31] : If set the controller will increment the next burst address
    #define bDMAC_CR0_SWAP          (30)        //        -    [30] : 0:Disable 1:Enable (APB Data)
                                                //        - [29:28] : Reserved                                   
    #define bDMAC_CR0_CMD_MAX       (24)        //        - [27:24] : Number of maximum outstanding AXI read Commands
                                                //        - [23:22] : Reserved    
    #define bDMAC_CR0_TOKENS        (16)        //        - [21:16] : Number of AXI read commands to issue before the channel releases the AXI command bus.
                                                //        - [15: 7] : Reserved    
    #define bDMAC_CR0_BURST_MASK    (0x7F)      //        - [ 6: 0] : Maximum number of bytes of an AXI read burst
    #define bDMAC_CR0_BURST         (0)         //                    Possible values: 1, 2, 4, data_width(32)*N (N is an integer 1 ~ 16)


//------------------------------------------------------------------------------
#define rDMAC_CR1                   0x14        // RxTx : Write Ctrl Register 
    #define bDMAC_CR1_INCR          (31)        //        -    [31] : If set the controller will increment the next burst address
    #define bDMAC_CR1_SWAP          (30)        //        -    [30] : 0:Disable 1:Enable (APB Data)
                                                //        - [29:28] : Reserved                                   
    #define bDMAC_CR1_CMD_MAX       (24)        //        - [27:24] : Number of maximum outstanding AXI Write Commands
                                                //        - [23:22] : Reserved    
    #define bDMAC_CR1_TOKENS        (16)        //        - [21:16] : Number of AXI write commands to issue before the channel releases the AXI command bus.
                                                //        - [15: 7] : Reserved    
    #define bDMAC_CR1_BURST_MASK    (0x7F)      //        - [ 6: 0] : Maximum number of bytes of an AXI Write burst
    #define bDMAC_CR1_BURST         (0)         //                    Possible values: 1, 2, 4, data_width*N (N is an integer 1 ~ 16)


//------------------------------------------------------------------------------
#define rDMAC_CR2                   0x18        // RxTx : Write Ctrl Register 
                                                //        - [31:30] : Reserved
    #define bDMAC_CR2_SWAP          (28)        //        - [29:28] : Endianness byte swapping. Notice byte swapping restrictions
                                                //                    0-No swapping. 1-16bit. 2-32bits. 3-64bits
                                                //        - [27:17] : Reserved
    #define bDMAC_CR2_JOINT         (16)        //        -    [16] : If set the channel will work in joint mode
    

//------------------------------------------------------------------------------
#define rDMAC_CR3                   0x1C        //        - [31:00] : Reserved


//------------------------------------------------------------------------------
#define rDMAC_PERI_CR0              0x20        // RxTx : Peripheral Ctrl Register 
                                                //        - [31:27] : Reserved
    #define bDMAC_PERI_WR_DLY       (24)        //        - [26:24] : Number of cycles to wait for the peripheral write request signal to update after issuing the write clear signal
                                                //        - [23:21] : Reserved
    #define bDMAC_PERI_WR_NUM       (16)        //        - [20:16] : Number of peripheral to write to (Set 0 - writes to a memory)
                                                //        - [15:11] : Reserved
    #define bDMAC_PERI_RD_DLY       (8)         //        - [10:08] : Number of cycles to wait for the peripheral read request signal to update after issuing the read clear signal
                                                //        - [07:05] : Reserved
    #define bDMAC_PERI_RD_NUM       (0)         //        - [04:00] : Number of peripheral to read from (Set 0 - read from a memory)


//------------------------------------------------------------------------------    
#define rDMAC_EN                    0x40        // RxTx : DMA Enable Register 
                                                //        - [31:01] : Reserved
    #define bDMAC_CH_EN             (1<<0)      //        -    [00] : Channel enable. Part of the initialization sequence. Also used for pause and resume
    #define bDMAC_CH_DIS            (0<<0)      //        -    [00] : Channel Disable. Part of the initialization sequence. Also used for pause and resume


//------------------------------------------------------------------------------ 
#define rDMAC_START                 0x44        //   Tx : DMA Start Register 
                                                //        - [31:00] : Write any value
    #define bDMAC_CH_START          (1<<0)      //                    DMA Channel Start (only start)


//------------------------------------------------------------------------------   
#define rDMAC_ACTIVE                0x48        // Rx   : DMA Active Status Register 
                                                //        - [31:02] : Reserved
    #define bDMAC_ACTIVE_WR         (1<<1)      //        -    [01] : This value is set if channel is enabled and all write data has been transferred
    #define bDMAC_ACTIVE_RD         (1<<0)      //        -    [00] : This value is set if channel is enabled and all read data has been received


//------------------------------------------------------------------------------   
#define rDMAC_CNT                   0x50        // Rx   : DMA Count Status Register 
                                                //        - [31:20] : Reserved
    #define bDMAC_CNT_INT           (16)        //        - [19:16] : Number of unserviced end interrupts
                                                //        - [15:12] : Reserved
    #define bDMAC_CNT_BUF           (0)         //        - [11:00] : Number of buffers transferred by channel since started



//------------------------------------------------------------------------------   
#define rDMAC_INT_RSTS              0xA0        // RxTx : DMA Interrupt Raw Status Register
#define rDMAC_INT_CLR               0xA4        //   Tx : DMA Interrupt Clear Register 
#define rDMAC_INT_EN                0xA8        // RxTx : DMA Interrupt Enable Register 
#define rDMAC_INT_STS               0xAC        // Rx   : DMA Interrupt Status Register 
    #define bDMAC_INT_MASK          (0x1FFF)    //        - [12:00] : 
    #define bDMAC_INT_WDT           (12)        //        -    [12] : Indicates that the channel is active but did not start a burst for 2048 cycles.
    #define bDMAC_INT_TIMEOUT_AW    (11)        //        -    [11] : Indicates that a write issued by this channel caused a timeout on the AXI write command bus. 
    #define bDMAC_INT_TIMEOUT_W     (10)        //        -    [10] : Indicates that a write issued by this channel caused a timeout on the AXI write data bus.
    #define bDMAC_INT_TIMEOUT_B     (9)         //        -    [09] : Indicates that a write issued by this channel caused a timeout on the AXI write response bus. 
    #define bDMAC_INT_TIMEOUT_AR    (8)         //        -    [08] : Indicates that a read issued by this channel caused a timeout on the AXI read command bus.
    #define bDMAC_INT_TIMEOUT_R     (7)         //        -    [07] : Indicates that a read issued by this channel caused a timeout on the AXI read data bus.   
    #define bDMAC_INT_UNDERFLOW     (6)         //        -    [06] : Indicates that the data FIFO has been underflown, this can only occur when WR_OUTSTANING is set.
    #define bDMAC_INT_OVERFLOW      (5)         //        -    [05] : Indicates that the data FIFO has been overflown, this can only occur when RD_OUTSTANING is set. 
    #define bDMAC_INT_WR_SLVERR     (4)         //        -    [04] : Indicates that a write issued by this channel caused an AXI read slave error.
    #define bDMAC_INT_WR_DECERR     (3)         //        -    [03] : Indicates that a write issued by this channel caused an AXI read decode error.  
    #define bDMAC_INT_RD_SLVERR     (2)         //        -    [02] : Indicates that a read issued by this channel caused an AXI read slave error.
    #define bDMAC_INT_RD_DECERR     (1)         //        -    [01] : Indicates that a read issued by this channel caused an AXI read decode error.
    #define bDMAC_INT_END           (0)         //        -    [00] : Indicates an unserviced channel end interrupt. 


#define rDMAC_SHR_START             0x1048










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    BOOL       mDMA_ChInit;
    eDMA_CH    mDMA_ChNum;  
    tDMA_PARAM mDMA_Param;
} tDMA_INFO, *ptDMA_INFO;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncDrv_DMA_GetStatus(eDMA_CH Ch);
extern INT32 ncDrv_DMA_CheckComplete(eDMA_CH Ch);
extern INT32 ncDrv_DMA_Transfer(ptDMA_INFO ptDMA, UINT32 SrcAddr, UINT32 DestAddr, UINT32 Length);
extern void  ncDrv_DMA_DeInitialize(eDMA_CH Ch);
extern void  ncDrv_DMA_Initialize(eDMA_CH Ch);


#endif  /* __DMA_DRV_H__ */


/* End Of File */

