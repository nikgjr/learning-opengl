/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "GPIO_Drv.h"










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

void ncDrv_GPIO_SetDirection(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_DIR dir)
{
    UINT32 Reg;    

    switch(group)
    {
        case GPIO_GROUP_A:
        case GPIO_GROUP_B:
        case GPIO_GROUP_C:    
        {
            Reg = REGRW32(rGPIO_BASE(group), rGPIO_DIR);
            if(dir == GPIO_DIR_IN)
                Reg &= ~(1<<port);
            else
                Reg |= (1<<port);
            REGRW32(rGPIO_BASE(group), rGPIO_DIR) = Reg;
        }
        break;

        case GPIO_GROUP_D:
        {

        }
        break;
    }
}


INT32 ncDrv_GPIO_GetData(eGPIO_GROUP group, eGPIO_PORT port)
{  
    UINT32 Reg = 0;

    switch(group)
    {
        case GPIO_GROUP_A:
        case GPIO_GROUP_B:
        case GPIO_GROUP_C:    
        {
            Reg = REGRW32(rGPIO_BASE(group), rGPIO_IN_PORT);
            Reg = ((Reg >> port) & 0x01);
        }
        break;   
        
        case GPIO_GROUP_D:
        break;
    }
    
    return Reg;
}


void ncDrv_GPIO_SetData(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_DATA level)
{
    UINT32 Reg;      

    switch(group)
    {
        case GPIO_GROUP_A:
        case GPIO_GROUP_B:
        case GPIO_GROUP_C:    
        {
            Reg = REGRW32(rGPIO_BASE(group), rGPIO_OUT_PORT);
            if(level == GPIO_LOW)
                Reg &= ~(1<<port);
            else
                Reg |= (1<<port);
            REGRW32(rGPIO_BASE(group), rGPIO_OUT_PORT) = Reg;
        }
        break;   
        
        case GPIO_GROUP_D:
        {
            if(port < GPIO_PORT4)
            {
                // Only FPGA TEST Mode
                // - 0x90D01040[08] GPIO_0
                // - 0x90D01040[09] GPIO_1
                // - 0x90D01040[10] GPIO_2
                // - 0x90D01040[11] GPIO_3


                Reg = REGRW32(APACHE_SYSCON_BASE, 0x1040);
                if(level == GPIO_LOW)
                    Reg &= ~(1<<(port+8));
                else
                    Reg |= (1<<(port+8));
                REGRW32(APACHE_SYSCON_BASE, 0x1040) = Reg;
                
            }
        }
        break;
    }
}


void ncDrv_GPIO_SetIntc(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_INT_CH ch, BOOL OnOff)
{
    UINT32 Reg;

    // Set PADID 
    Reg = REGRW32(APACHE_GPIO_BASE, rGPIO_INT_ID);
    Reg &= ~(0xFF<<(ch*8));

    if(OnOff == ON)
        Reg |= (((group*MAX_OF_GPIO_PORT)+port)<<(ch*8));

    REGRW32(APACHE_GPIO_BASE, rGPIO_INT_ID) = Reg;


    // Set INTC Enable
    Reg = REGRW32(APACHE_GPIO_BASE, rGPIO_INT_EN);
    Reg &= ~(1<<(ch*8));

    if(OnOff == ON)
        Reg |= (1<<(ch*8));

    REGRW32(APACHE_GPIO_BASE, rGPIO_INT_EN) = Reg;
}


/* End Of File */

