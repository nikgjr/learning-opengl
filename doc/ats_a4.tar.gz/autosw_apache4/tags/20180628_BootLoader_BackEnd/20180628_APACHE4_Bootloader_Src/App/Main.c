/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    :
*
*  @brief   :
*
*  @author  :
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#define __MAIN_C__

/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "Apache.h"

#include "Main.h"

#if defined(__BL2__) && defined(__FPGA_MODE__)  
#include "DummyData.h"
#endif










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

// Do not delete this variable.
// The current program does not use global variables
// Therefore, a link error occurs when the following options are enabled.
// __BL2_INTC_ENABLE__  (Enable) Need ER_ZI
// So, I made a variable that I do not use.
volatile UINT32 DUMMY_ER_ZI_DATA[4];











/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

extern UINT32 sss_SecureRun(UINT32 Addr, UINT8 UsedCodeKey);











/*
********************************************************************************
*               LOCAL FUNCTION DEFINITIONS
********************************************************************************
*/

static INT32 __compare(UINT8 *pSrc, UINT8* pDes, UINT32 Length)
{
    UINT32 i;
    INT32 Ret = NC_SUCCESS;

    for(i=0; i<Length; i++)
    {
        if(pSrc[i] != pDes[i])
            Ret = NC_FAILURE;
    }

    return Ret;
}


static UINT32 __checksum(UINT32 *pSrc, UINT32 Length)
{
    UINT32 CheckSum = 0;
    UINT32 i;

    for(i=0; i<Length; i++)
    {
        CheckSum += pSrc[i];
    }

    return CheckSum;
}


void ncBL_SE_DebugCoreDump(ptARM_FAULT pFault, const char *msg)
{
#ifdef __UART_ENABLE__
    UINT32 i = 0;

    // Display Current Core Register
    DEBUGMSG(MSGINFO,     "\n------------------------------------------------\n");
    DEBUGMSG(MSGERR,      " [Halt] Core %s Abort \n", msg);
    DEBUGMSG(MSGINFO,     "------------------------------------------------\n"); 
    DEBUGMSG(MSGINFO,     "   SPSR: 0x%08x\n", pFault->mSPSR);  
    DEBUGMSG(MSGINFO,     "   PC  : 0x%08x  r%02d : 0x%08x\n", pFault->mPC, i, pFault->mReg[i]);    
    for(i=1; i<13; i+=2)
        DEBUGMSG(MSGINFO, "   r%02d : 0x%08x  r%02d : 0x%08x\n", i, pFault->mReg[i], i+1, pFault->mReg[i+1]);
#endif
}


void ncBL_SE_FaultTrig(void)
{
    // SE_ENABLE
    REGRW32(APACHE_SE_BASE, 0x000) = ENABLE;

    // SE_SW_FAULT_TRIG_EN
    REGRW32(APACHE_SE_BASE, 0x110) = ENABLE;

    // SE_SW_FAULT_TRIG
    REGRW32(APACHE_SE_BASE, 0x100) = HIGH;

    // Wait (set bit Check)
    while(!(REGRW32(APACHE_SE_BASE, 0x118)&HIGH));
}


void ncBL_SE_Undefined_Handler(ptARM_FAULT pFault)
{
    BOOL IsThumb;
    
    IsThumb = pFault->mSPSR & (1<<5) ;

    if(IsThumb)
        pFault->mPC -= 2;
    else
        pFault->mPC -= 4;
    ncBL_SE_DebugCoreDump(pFault, "Undefined");

    ncBL_SE_FaultTrig();
    
    while(1);
}


void ncBL_SE_Prefetch_Handler(ptARM_FAULT pFault)
{
    pFault->mPC -= 4;    
    ncBL_SE_DebugCoreDump(pFault, "Prefetch");
    
    ncBL_SE_FaultTrig();

    while(1);
}


void ncBL_SE_Abort_Handler(ptARM_FAULT pFault)
{
    pFault->mPC -= 8;      
    ncBL_SE_DebugCoreDump(pFault, "Data");

    ncBL_SE_FaultTrig();

    while(1);
}


void ncBL_DBG_GpioToggle(void)
{
#ifdef __FPGA_MODE__    
    UINT32 Reg;
    UINT32 Port = (BL_NUM-1);

    /*
     *----------------------------
     *  Only FPGA Debug GPIO Port 
     *  0x90D01040 [11:8]
     *      -. PORT0[8]
     *      -. PORT1[9]
     *      -. PORT2[10] 
     *      -. PORT3[11]
     *----------------------------
     */
     
    Reg = REGRW32(APACHE_SCU_BASE, 0x1040);
    if( Reg & (1<<(Port+8)) )
        Reg &= ~(1<<(Port+8));
    else
        Reg |= (1<<(Port+8));
    REGRW32(APACHE_SCU_BASE, 0x1040) = Reg;
#endif
}


void ncBL_DBG_Step(UINT8 Bit)
{
    DBG_STP_REG |= (1U<<Bit);
}


void ncBL_DBG_Result(INT32 Ret)
{
    if(Ret == NC_SUCCESS)
    {
        DBG_RES_REG = ('K'<<8) | ('O'<<0);                          // OK
    }
    else
    {
        DBG_RES_REG = ('L'<<24) | ('I'<<16) | ('A'<<8) | ('F'<<0);  // Fail
        ncBL_SE_FaultTrig();
    }

#ifdef __UART_ENABLE__
    if(Ret == NC_SUCCESS)
    {
        DEBUGMSG(MSGWARN, "\n >>>>> BL_%d Success\n", BL_NUM);
    }
    else
    {
        DEBUGMSG(MSGERR, "\n >>>>> BL_%d Failure\n", BL_NUM);
    }
#endif
}


void ncBL_DBG_RegInit(void)
{
    DBG_VER_REG = ((BL_NUM<<24) | (BL_VER_MAJOR<<16) | (BL_VER_MINOR1<<8) | (BL_VER_MINOR2));
    DBG_STP_REG = 0;    // Debug - FlowStep
    DBG_RES_REG = 0;    // Debug - Result
    DBG_RTY_REG = 0;    // Debug - Retry 
}


void ncBL_UART_Initialize(ptBOOT_INFO ptBootInfo)
{    
#ifdef __UART_ENABLE__    
    ncBL_DBG_Step(DBG_STP_UART_IN);

    
    // Set Pin Mux : Tx Only
    ncDrv_SCU_SetPinMux(PAD_UART0_TX, PAD_FUNC_1);
    ncDrv_UART_Initialize(UT_BAUDRATE_57600, ptBootInfo->tClock.mAPB);


    // Boot Information Display
    DEBUGMSG(MSGINFO, "\n\n");
    DEBUGMSG(MSGINFO, "=======================================================\n");
    DEBUGMSG(MSGINFO, " APACHE4 BL%d Version: [v%d.%d.%d] [%s, %s]\n", BL_NUM, 
                                                                       BL_VER_MAJOR, 
                                                                       BL_VER_MINOR1,
                                                                       BL_VER_MINOR2,
                                                                       (UINT32*)__DATE__,
                                                                       (UINT32*)__TIME__);
    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "  > Boot-Strap Information\n");
    DEBUGMSG(MSGINFO, "    -. %s Boot Mode\n", ptBootInfo->tStrap.mSecureEn?"Secure":"Normal");
    DEBUGMSG(MSGINFO, "    -. sFlash CSN_%d\n", ptBootInfo->tStrap.mFlashCS);
    if(ptBootInfo->tStrap.mPLLConfig == 0)      DEBUGMSG(MSGINFO, "    -. External Clock mode\n");
    else if(ptBootInfo->tStrap.mPLLConfig == 1) DEBUGMSG(MSGINFO, "    -. PLL Min. Clock Mode\n");
    else if(ptBootInfo->tStrap.mPLLConfig == 2) DEBUGMSG(MSGINFO, "    -. PLL Middle Clock Mode\n");
    else if(ptBootInfo->tStrap.mPLLConfig == 3) DEBUGMSG(MSGINFO, "    -. PLL Max. Clock Mode\n");
    else                                        DEBUGMSG(MSGINFO, "    -. FPGA Test Clock Mode\n");
    DEBUGMSG(MSGINFO, "  > Clock Information\n");
    DEBUGMSG(MSGINFO, "    -. CPU : %8d Hz   DDR  : %8d Hz\n", ptBootInfo->tClock.mCPU, ptBootInfo->tClock.mDDR);
    DEBUGMSG(MSGINFO, "    -. APB : %8d Hz   QSPI : %8d Hz\n", ptBootInfo->tClock.mAPB, ptBootInfo->tClock.mQSPI);


    ncBL_DBG_Step(DBG_STP_UART_OUT);
#endif
}


INT32 ncBL_DDR_Initialize(ptBOOT_INFO ptBootInfo)
{
#if defined(__BL2__) && defined(__BL2_DDR_ENABLE__)   
    INT32 Ret = NC_SUCCESS;

    ncBL_DBG_Step(DBG_STP_DDR_IN);
    
    ncDrv_DDRC_Init();

    ncBL_DBG_Step(DBG_STP_DDR_OUT);

    return Ret;
#else
    return NC_SUCCESS;
#endif
}


void ncBL_INTC_Initialize(void)
{
#ifdef __BL2_INTC_ENABLE__    
    ncBL_DBG_Step(DBG_STP_INTC_IN);
    
    ncDrv_INTC_InitIntHandler();
    ncDrv_INTC_Initialize();

    ncBL_DBG_Step(DBG_STP_INTC_OUT);
#endif
}


void ncBL_SCU_Initialize(ptBOOT_INFO ptBootInfo)
{
    UINT32 Reg;
    const tBOOT_CLK Clk_Conf[5] = { 
                                        {BL_OSC_CPU_CLOCK, BL_OSC_DDR_CLOCK, BL_OSC_APB_CLOCK, BL_OSC_QSPI_CLOCK},
                                        {BL_MIN_CPU_CLOCK, BL_MIN_DDR_CLOCK, BL_MIN_APB_CLOCK, BL_MIN_QSPI_CLOCK},
                                        {BL_MID_CPU_CLOCK, BL_MID_DDR_CLOCK, BL_MID_APB_CLOCK, BL_MID_QSPI_CLOCK},
                                        {BL_MAX_CPU_CLOCK, BL_MAX_DDR_CLOCK, BL_MAX_APB_CLOCK, BL_MAX_QSPI_CLOCK}, 
                                        {BL_SIM_CPU_CLOCK, BL_SIM_DDR_CLOCK, BL_SIM_APB_CLOCK, BL_SIM_QSPI_CLOCK}
                                  };
                            

    ncBL_DBG_Step(DBG_STP_SCU_IN);


    /*
     *------------------------------------------------
     * Check Boot Strap
     *------------------------------------------------
     */
    Reg = REGRW32(APACHE_SCU_BASE, rSCU_BOOT_STRAP) & 0x0F;
    ptBootInfo->tStrap.mSecureEn  = (Reg >> 3) & 0x1;
    ptBootInfo->tStrap.mFlashCS   = (Reg >> 2) & 0x1;
    ptBootInfo->tStrap.mPLLConfig = (Reg >> 0) & 0x3;

#ifdef __FPGA_MODE__
    ptBootInfo->tStrap.mPLLConfig = 4;
#endif

    // Image Config Ctrl
    ptBootInfo->tImage.mSecuMode[E_CORE_DLS] = ptBootInfo->tStrap.mSecureEn; 
    ptBootInfo->tImage.mSecuMode[E_CORE_SIG] = ptBootInfo->tStrap.mSecureEn; 
    ptBootInfo->tImage.mSecuMode[E_CORE_DSP] = ptBootInfo->tStrap.mSecureEn; 

    ptBootInfo->tClock.mCPU  = Clk_Conf[ptBootInfo->tStrap.mPLLConfig].mCPU;
    ptBootInfo->tClock.mAPB  = Clk_Conf[ptBootInfo->tStrap.mPLLConfig].mAPB;
    ptBootInfo->tClock.mDDR  = Clk_Conf[ptBootInfo->tStrap.mPLLConfig].mDDR;
    ptBootInfo->tClock.mQSPI = Clk_Conf[ptBootInfo->tStrap.mPLLConfig].mQSPI;

    SYS_APB_CLK     = ptBootInfo->tClock.mAPB;
    SYS_TIMEOUT_CNT = 0;


#ifdef __BL1__
    /*
     * PLL Configuration ...
     *  0 : OSC 27MHz       : PLL0    27MHz
     *  1 : Low speed       : PLL0   297MHz
     *  2 : Middle speed    : PLL0 796.5MHz
     *  3 : Max speed       : PLL0  1593MHz
     * ------------------------------------------------------------------------
     * BLOCK      | CLOCK NAME   | 2'b11     | 2'b10     | 2'b01    | 2'b00   |
     * -----------|--------------|-----------|-----------|----------|---------|
     * ARM_CPU_LS | clk_armls_0  | 796.5     | 398.25    | 148.5    | 13.5    |
     * AXI        | aclk_noc     | 199.125   |  99.5625  |  37.125  |  3.375  |
     * APB        | pclk_noc     | 199.125   |  99.5625  |  37.125  |  3.375  |
     * QSPI       | clk_qspi     |  99.5625  |  49.78125 |  18.5625 |  1.6875 |
     * ------------------------------------------------------------------------
     */

    //-----------------------------------------------------------------------
    // by jjosuba
    //-----------------------------------------------------------------------
//    // Set CPU,AXI Clock
//    Reg = (REGRW32(APACHE_SCU_BASE, rSCU_BOOT_STRAP) & 0x30 ) >> 4;
//    REGRW32(APACHE_SCU_BASE, rSCU_CLK_SEL_ARM_LS_0   ) = Reg;
//    REGRW32(APACHE_SCU_BASE, rSCU_CLK_SEL_RAM        ) = Reg;
//    REGRW32(APACHE_SCU_BASE, rSCU_CLK_SEL_BUS_AXI    ) = Reg;

    // CPU : AXI = 1 : 1
    Reg = REGRW32(APACHE_SCU_BASE, rSCU_CLK_DIV_ARM        ) & 0xFFFCFCFC;
//    if(REGRW32(APACHE_SCU_BASE, rSCU_BOOT_STRAP) & 0x40)
        Reg |= 0x20202;
//    else
//        Reg |= 0x1;
    REGRW32(APACHE_SCU_BASE, rSCU_CLK_DIV_ARM        ) = Reg;

    REGRW32(APACHE_SCU_BASE, rSCU_CLK_DIV_SECURE     ) = 0x203;
    REGRW32(APACHE_SCU_BASE, rSCU_CLK_SEL_SECURE     ) = 0x0;
    //________________________________________________________________________

    // Set RAM Clock
    // CLK_DIV_RAM[1:0] - 0:1/1(27MHz), 1:1/2(148.5MHz), 2:1/4(199.125MHz), 3:1/8(199.125MHz)
    REGRW32(APACHE_SCU_BASE, rSCU_CLK_DIV_RAM) = (ptBootInfo->tStrap.mPLLConfig<<0);

    // Set ROM Clock
    // CLK_SEL_R0M[4]   - 0:1/1, 1:1/2
    REGRW32(APACHE_SCU_BASE, rSCU_CLK_SEL_R0M) = (0<<4);  


    // Set Clock Path 
    // 0 : Used SYS_CK_I_XI(27MHz), 2: Used PLL, 3: Used EXT0_CLK
    if(ptBootInfo->tStrap.mPLLConfig&0x3)
        Reg = 0x2;
    else
        Reg = 0x0;
    REGRW32(APACHE_SCU_BASE, rSCU_PLL0_SEL) = Reg;
    REGRW32(APACHE_SCU_BASE, rSCU_PLL1_SEL) = Reg;
    REGRW32(APACHE_SCU_BASE, rSCU_PLL2_SEL) = Reg;
    REGRW32(APACHE_SCU_BASE, rSCU_PLL3_SEL) = Reg;

    
   
    /*
     *------------------------------------------------
     * Clock Enable
     *------------------------------------------------
     */
     
    // Enable Bus Clock  
    Reg = REGRW32(APACHE_SCU_BASE, rSCU_CLK_BUS);
    Reg |= ( 
             bSCU_CLK_BUS_PCLK_QSPI
           | bSCU_CLK_BUS_PCLK_SPI
           | bSCU_CLK_BUS_PCLK_DMAC
            #ifdef __UART_ENABLE__
                | bSCU_CLK_BUS_PCLK_UART
            #endif
           | bSCU_CLK_BUS_PCLK_ICU
           | bSCU_CLK_BUS_ACLK_RAM
           | bSCU_CLK_BUS_ACLK_DMAC
           | bSCU_CLK_BUS_ACLK_QSPI
           );
    
    if(1) // ptBootInfo->tStrap.mSecureEn == bSCU_BOOT_STRAP_SECURE_MODE)
    {
        Reg |= ( 
                 bSCU_CLK_BUS_PCLK_ATOP
               | bSCU_CLK_BUS_HCLK_SECURE_HS
               | bSCU_CLK_BUS_HCLK_SECURE_IS
               ); 
    } 
    REGRW32(APACHE_SCU_BASE, rSCU_CLK_BUS) = Reg;


    // Enable IP Clock
    Reg = REGRW32(APACHE_SCU_BASE, rSCU_CLK_IP);
    Reg |= ( 
             bSCU_CLK_IP_SAFETY
           | bSCU_CLK_IP_QSPI
           );
    
    if(1) // ptBootInfo->tStrap.mSecureEn == bSCU_BOOT_STRAP_SECURE_MODE)
    {
        Reg |= ( 
                 bSCU_CLK_IP_TNG
               | bSCU_CLK_IP_HMAC
               | bSCU_CLK_IP_PKA
               | bSCU_CLK_IP_AES
               | bSCU_CLK_IP_SECURE
               ); 
    } 
    REGRW32(APACHE_SCU_BASE, rSCU_CLK_IP) = Reg;



    /*
     *------------------------------------------------
     * Device Reset
     *------------------------------------------------
     */
     
    // Reset Bus
    Reg = ( 
             bSCU_RST_BUS_PRST_ICU
            #ifdef __UART_ENABLE__
                | bSCU_RST_BUS_PRST_UART
            #endif
           | bSCU_RST_BUS_HRST_DMAC
           | bSCU_RST_BUS_HRST_QSPI
           );
    
    if(1) // ptBootInfo->tStrap.mSecureEn == bSCU_BOOT_STRAP_SECURE_MODE)
    {
        Reg |= ( 
                 bSCU_CLK_BUS_PCLK_ATOP
               | bSCU_CLK_BUS_HCLK_SECURE_HS
               | bSCU_CLK_BUS_HCLK_SECURE_IS
               ); 
    } 
    REGRW32(APACHE_SCU_BASE, rSCU_RST_BUS) = Reg;
    REGRW32(APACHE_SCU_BASE, rSCU_RST_BUS) = 0;


    // Reset IP
    Reg = bSCU_RST_IP_QSPI;
    
    if(1) // ptBootInfo->tStrap.mSecureEn == bSCU_BOOT_STRAP_SECURE_MODE)
    {
        Reg |= ( 
                 bSCU_RST_IP_TNG
               | bSCU_RST_IP_HMAC
               | bSCU_RST_IP_PKA
               | bSCU_RST_IP_AES
               | bSCU_RST_IP_SECURE
               ); 
    } 
    REGRW32(APACHE_SCU_BASE, rSCU_RST_IP) = Reg;
    REGRW32(APACHE_SCU_BASE, rSCU_RST_IP) = 0;
    
#else   // __BL2__

    #ifdef __BL2_DDR_ENABLE__
        // Enable DDRC Clock  
        Reg = REGRW32(APACHE_SCU_BASE, rSCU_CLK_BUS);
        Reg |= ( 
                 bSCU_CLK_BUS_PCLK_DDRC
               | bSCU_CLK_BUS_ACLK_DDRC
               );
        REGRW32(APACHE_SCU_BASE, rSCU_CLK_BUS) = Reg;

        // Enable DDR Clock  
        Reg = REGRW32(APACHE_SCU_BASE, rSCU_CLK_DDRC);
        Reg |= ( 
                 bSCU_CLK_DDRC_DFI
               | bSCU_CLK_DDRC_MDII
               | bSCU_CLK_DDRC_PHT
               );
        REGRW32(APACHE_SCU_BASE, rSCU_CLK_DDRC) = Reg;
    #endif

#endif

#ifdef __BL1__
    /*
     *------------------------------------------------
     * SRAN Ecc Enable (Only BL1)
     *------------------------------------------------
     */

    // SRAM ECC Enable
    REGRW32(APACHE_SCU_BASE, rSCU_SRAM_ECC) = bSCU_SRAM_ECC_ENABLE;    
#endif


    ncBL_DBG_Step(DBG_STP_SCU_OUT);
}


INT32 ncBL_SF_GetHeader(ptBOOT_INFO ptBootInfo, UINT32 CoreType)
{
    INT32 Ret = NC_FAILURE;
    UINT32 ImgType;


    // Only SPI Mode
    ptBootInfo->tImage.mCtrlMode = SPI_MODE;


    // 0: Orignal, 1:Backup
    for(ImgType=E_IMG_NORMAL; ImgType<=E_IMG_BACKUP; ImgType++)
    {
        if(ptBootInfo->tImage.mFlashAddr[CoreType][ImgType] != 0x0)
        {
            ptBootInfo->tHeader[CoreType][ImgType].mSignature = 0;
            ncSvc_SF_ReadData(ptBootInfo->tStrap.mFlashCS,
                              ptBootInfo->tImage.mCtrlMode,
                              ptBootInfo->tImage.mInstBuff,
                              ptBootInfo->tImage.mFlashAddr[CoreType][ImgType],
                              (UINT8 *)&(ptBootInfo->tHeader[CoreType][ImgType]),
                              BL_IMG_HEADER_SIZE);

            if(ptBootInfo->tHeader[CoreType][ImgType].mSignature == BL_IMG_SIGNATURE_ID)
            {
                Ret = NC_SUCCESS;
            }
        }
    }

    return Ret;
}


INT32 ncBL_SF_CheckQSPIBitRate(ptBOOT_INFO ptBootInfo)
{
    INT32 Ret = NC_FAILURE;
    UINT32 Clk_Div = 0xE;   // Default QSPI Max Clock (0xE, Div_2)
    UINT32 BitRate = SYS_QSPI_CLK;
    UINT32 ImgType;


    ncBL_DBG_Step(DBG_STP_QSPI_IN);
    

    // Set QSPI Mode
    ptBootInfo->tImage.mCtrlMode = QSPI_MODE;


    while(Clk_Div)
    {
        // Set QSPI Default Bitrate
        BitRate = ncDrv_QSPI_SetBitRate(Clk_Div, ptBootInfo->tClock.mQSPI);
        if(BitRate < (100*KHZ))
            break;


        // 0:Orignal, 1:Backup
        for(ImgType=E_IMG_NORMAL; ImgType<=E_IMG_BACKUP; ImgType++)
        {
            // Check Noraml - Finds the header identified by the SPI.
            if(ptBootInfo->tHeader[E_CORE_DLS][ImgType].mSignature == BL_IMG_SIGNATURE_ID)
            {
                ncSvc_SF_ReadData(ptBootInfo->tStrap.mFlashCS,
                                  ptBootInfo->tImage.mCtrlMode,
                                  ptBootInfo->tImage.mInstBuff,
                                  ptBootInfo->tImage.mFlashAddr[E_CORE_DLS][ImgType],
                                  (UINT8 *)(ptBootInfo->tImage.mTempBuff),
                                  BL_IMG_HEADER_SIZE);

                break;
            }  
        }
        
        if(ImgType > E_IMG_BACKUP)
        {
            // This case should not exist.
            break;
        }

   
        // Compare SPI-Read Header vs QSPI-Read Hader 
        Ret = __compare((UINT8 *)&(ptBootInfo->tHeader[E_CORE_DLS][ImgType]), (UINT8 *)(ptBootInfo->tImage.mTempBuff), BL_IMG_HEADER_SIZE);
        if(Ret == NC_SUCCESS)
        {
            break;
        }


        // QSPI-BitRate Down
        Clk_Div -= 1;
        
        
        // Debug - Update Retry Count 
        DBG_RTY_REG += 1;
    }


    // Debug - Update Last QSPI-Clock   
    SYS_QSPI_CLK = BitRate;
    

    ncBL_DBG_Step(DBG_STP_QSPI_OUT);

    return Ret;
}

#ifdef __DMA_ENABLE__
INT32 ncBL_SF_CheckDMASPIBitRate(ptBOOT_INFO ptBootInfo)
{
    INT32 Ret = NC_FAILURE;
    UINT32 ImgType;    
    UINT32 BitRate = SYS_SPI_CLK;


    ncBL_DBG_Step(DBG_STP_DMA_IN);


    // Set DMA Mode
    ptBootInfo->tImage.mCtrlMode = DMA_MODE;


    while(1)
    {
        // 0:Orignal, 1:Backup
        for(ImgType=E_IMG_NORMAL; ImgType<=E_IMG_BACKUP; ImgType++)
        {
            // Check Noraml - Finds the header identified by the SPI.
            if(ptBootInfo->tHeader[E_CORE_DLS][ImgType].mSignature == BL_IMG_SIGNATURE_ID)
            {
                ncSvc_SF_ReadData(ptBootInfo->tStrap.mFlashCS,
                                  ptBootInfo->tImage.mCtrlMode,
                                  ptBootInfo->tImage.mInstBuff,
                                  ptBootInfo->tImage.mFlashAddr[E_CORE_DLS][ImgType],
                                  (UINT8 *)(ptBootInfo->tImage.mTempBuff),
                                  BL_IMG_HEADER_SIZE);

                break;
            }  
        }

        
        if(ImgType > E_IMG_BACKUP)
        {
            // This case should not exist.
            break;
        }

   
        // Compare SPI-Read Header vs QSPI-Read Hader 
        Ret = __compare((UINT8 *)&(ptBootInfo->tHeader[E_CORE_DLS][ImgType]), (UINT8 *)(ptBootInfo->tImage.mTempBuff), BL_IMG_HEADER_SIZE);
        if(Ret == NC_SUCCESS)
        {
            break;
        }


        // SPI-BitRate Down
        if     (BitRate > (20000*KHZ))  BitRate -= (10000*KHZ);
        else if(BitRate > (10000*KHZ))  BitRate =  (10000*KHZ);
        else if(BitRate > ( 5000*KHZ))  BitRate =  ( 5000*KHZ);
        else if(BitRate > ( 1000*KHZ))  BitRate =  ( 1000*KHZ);
        else if(BitRate > (  500*KHZ))  BitRate =  (  500*KHZ);
        else if(BitRate > (  100*KHZ))  BitRate =  (  100*KHZ);
        else                            break;


        // Update BitRate
        ncDrv_SSP_SetBitRate(&BitRate, ptBootInfo->tClock.mAPB);


        // Debug - Update Retry Count 
        DBG_RTY_REG += 1;
    }


    // Debug - Update Last SPI-Clock   
    SYS_SPI_CLK = BitRate;


    ncBL_DBG_Step(DBG_STP_DMA_OUT);


    return Ret;
}
#endif


INT32 ncBL_SF_CheckSPIBitRate(ptBOOT_INFO ptBootInfo)
{
    INT32 Ret = NC_FAILURE;
    UINT32 CoreType; 
    UINT32 BitRate = ptBootInfo->tClock.mAPB/2;


    ncBL_DBG_Step(DBG_STP_SPI_IN);


    CoreType = E_CORE_DLS;
    while(1)
    {
        Ret = ncBL_SF_GetHeader(ptBootInfo, CoreType);
        if(Ret == NC_SUCCESS)
            break;

        // SPI-BitRate Down
        if     (BitRate > (20000*KHZ))  BitRate -= (10000*KHZ);
        else if(BitRate > (10000*KHZ))  BitRate =  (10000*KHZ);
        else if(BitRate > ( 5000*KHZ))  BitRate =  ( 5000*KHZ);
        else if(BitRate > ( 1000*KHZ))  BitRate =  ( 1000*KHZ);
        else if(BitRate > (  500*KHZ))  BitRate =  (  500*KHZ);
        else if(BitRate > (  100*KHZ))  BitRate =  (  100*KHZ);
        else                            break;

        // Update BitRate
        ncDrv_SSP_SetBitRate(&BitRate, ptBootInfo->tClock.mAPB);

        // Debug - Update Retry Count 
        DBG_RTY_REG += 1;
    }


    // Debug - Update Last SPI-Clock   
    SYS_SPI_CLK = BitRate;


    // Single-Core/DSP Application Header Read
    if(Ret == NC_SUCCESS)
    {
        for(CoreType=E_CORE_SIG; CoreType<ptBootInfo->tImage.mTotalCnt; CoreType++)
        {
            ncBL_SF_GetHeader(ptBootInfo, CoreType);
        }
    }

    ncBL_DBG_Step(DBG_STP_SPI_OUT);

    return Ret;
}


INT32 ncBL_SF_CheckHeader(ptBOOT_INFO ptBootInfo, UINT32 CoreType, UINT32 ImgType)
{
    INT32 Ret = NC_SUCCESS;


    if(    (ptBootInfo->tHeader[CoreType][ImgType].mSignature != BL_IMG_SIGNATURE_ID)
        || (ptBootInfo->tHeader[CoreType][ImgType].mLength == 0)
        || (ptBootInfo->tHeader[CoreType][ImgType].mLength > ptBootInfo->tImage.mLimitSize))
    {
        Ret = NC_FAILURE;
    }


#ifdef __UART_ENABLE__
    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n"); 
    DEBUGMSG(MSGINFO, "  > Header Info [%d.%d]\n",       CoreType, ImgType);        
    DEBUGMSG(MSGINFO, "    -. Length    = 0x%08X(%d)\n", ptBootInfo->tHeader[CoreType][ImgType].mLength, ptBootInfo->tHeader[CoreType][ImgType].mLength);
    DEBUGMSG(MSGINFO, "    -. CheckSum  = 0x%08X\n",     ptBootInfo->tHeader[CoreType][ImgType].mCheckSum);
    DEBUGMSG(MSGINFO, "    -. Config    = 0x%08X\n",     ptBootInfo->tHeader[CoreType][ImgType].mConfig);
    DEBUGMSG(MSGINFO, "    -. Signature = 0x%08X\n",     ptBootInfo->tHeader[CoreType][ImgType].mSignature);
    if(Ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "    ==> Image Header Fail %d.%d \n", CoreType, ImgType);    
    }     
#endif


    return Ret;
}


INT32 ncBL_SF_GetImage(ptBOOT_INFO ptBootInfo, UINT32 CoreType, UINT32 ImgType)
{
    INT32  Ret;
    UINT32 TotalLength;
    UINT32 CheckSum = 0;


    // Quad-SPI 64bit(8Byte) Align
    TotalLength = _ALIGN(ptBootInfo->tHeader[CoreType][ImgType].mLength, 8);


    #ifdef __IMG_CONF_ENABLE__ // [0xxxxx_xxx3 => b'xx11]
        if((ptBootInfo->tHeader[CoreType][ImgType].mConfig&0x3) != CTRL_NONE)
        {
            // 1: SPI 2:QSPI 3:DMA Mode 
            ptBootInfo->tImage.mReadMode[CoreType] = (ptBootInfo->tHeader[CoreType][ImgType].mConfig&0x3);
        }
    #endif


    // FW Image Data Read
    Ret = ncSvc_SF_ReadData(ptBootInfo->tStrap.mFlashCS,
                            ptBootInfo->tImage.mReadMode[CoreType],
                            ptBootInfo->tImage.mInstBuff,
                            ptBootInfo->tImage.mFlashAddr[CoreType][ImgType] + BL_IMG_HEADER_SIZE,
                            (UINT8 *)(ptBootInfo->tImage.mDestAddr[CoreType]),
                            TotalLength);


    #ifdef __IMG_CONF_ENABLE__
        if(Ret == NC_SUCCESS)
        {
            // [0xxxxx_xx3x => b'xxx1]
            if(ptBootInfo->tHeader[CoreType][ImgType].mConfig & (1<<4))
            {
                ptBootInfo->tImage.mSecuMode[CoreType] = bSCU_BOOT_STRAP_NORMAL_MODE;
            }

            // [0xxxxx_xx3x => b'xx1x]
            if(ptBootInfo->tHeader[CoreType][ImgType].mConfig & (1<<5))
            {
               ptBootInfo->tImage.mSecuMode[CoreType] = bSCU_BOOT_STRAP_SECURE_MODE; 
            }

            ncBL_DBG_GpioToggle();
        }
    #endif


    // FW Loading Success
    if((Ret == NC_SUCCESS) && (ptBootInfo->tImage.mSecuMode[CoreType] == bSCU_BOOT_STRAP_NORMAL_MODE))
    {
        CheckSum = __checksum((UINT32 *)(ptBootInfo->tImage.mDestAddr[CoreType]), (ptBootInfo->tHeader[CoreType][ImgType].mLength/4));
        if(ptBootInfo->tHeader[CoreType][ImgType].mCheckSum != CheckSum)
        {
            Ret = NC_FAILURE;
        }

        ncBL_DBG_GpioToggle();
    }

#ifdef __UART_ENABLE__
    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");       
    DEBUGMSG(MSGINFO, "  > Image Loading - %08X, [%d.%d.%d]\n",  Ret, ptBootInfo->tImage.mCtrlMode, CoreType, ImgType);   
    DEBUGMSG(MSGINFO, "    -. Header(0x%08X) vs Calc(0x%08X)\n", ptBootInfo->tHeader[CoreType][ImgType].mCheckSum, CheckSum);
#endif

    return Ret;
}


INT32 ncBL_SF_ImageLoading(ptBOOT_INFO ptBootInfo, UINT32* Status)
{
    INT32  Ret = NC_SUCCESS;
    UINT32 CoreType;
    INT32  Result;
    UINT32 ImgType;
    UINT8  UsedCodeKey = 0;

    ncBL_DBG_Step(DBG_STP_IMG_IN);


    ncBL_DBG_GpioToggle();


    // All Image Loading 
    for(CoreType=E_CORE_DLS; CoreType<ptBootInfo->tImage.mTotalCnt; CoreType++)
    {
        ncBL_DBG_Step(DBG_STP_IMG_0_IN + (CoreType*4));


        // Check  - Normal Boot Header
        ImgType = E_IMG_NORMAL;
        Result = ncBL_SF_CheckHeader(ptBootInfo, CoreType, ImgType);


        // Success - Normal Boot image loading
        if(Result == NC_SUCCESS)
        {
            Result = ncBL_SF_GetImage(ptBootInfo, CoreType, ImgType);
        }


        // Fail - Normal Header or Image loading
        if(Result == NC_FAILURE)
        {
            // Check - Backup Boot Header
            ImgType = E_IMG_BACKUP;
            Result = ncBL_SF_CheckHeader(ptBootInfo, CoreType, ImgType);


            // Success - Backup Boot image loading 
            if(Result == NC_SUCCESS)
            {
                Result = ncBL_SF_GetImage(ptBootInfo, CoreType, ImgType);
            }
        }


        // Image Decoding 
        if((Result == NC_SUCCESS) && (ptBootInfo->tImage.mSecuMode[CoreType] == bSCU_BOOT_STRAP_SECURE_MODE))
        {
            ncBL_DBG_Step(DBG_STP_IMG_SECU_0_IN + (CoreType*4));


            #ifdef __IMG_CONF_ENABLE__  // [0xxxxx_x1xx => b'xxx1]
                UsedCodeKey = (ptBootInfo->tHeader[CoreType][ImgType].mConfig>>8)&0x1;
            #endif
            
            #ifdef __UART_ENABLE__
                DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");  
                DEBUGMSG(MSGINFO, "  > SSS In  0x%08X 0x%08X\n", ptBootInfo->tImage.mDestAddr[CoreType], UsedCodeKey);
            #endif

            Result = sss_SecureRun(ptBootInfo->tImage.mDestAddr[CoreType], UsedCodeKey);

            if(Result == NC_SUCCESS)
            {
                ASM_DCACHE_FLUSH(ptBootInfo->tImage.mDestAddr[CoreType], ptBootInfo->tHeader[CoreType][ImgType].mLength);
            }

            ncBL_DBG_GpioToggle();
            #ifdef __UART_ENABLE__
                DEBUGMSG(MSGINFO, "  > SSS Out 0x%08X\n", Result);
            #endif

            
            ncBL_DBG_Step(DBG_STP_IMG_SECU_0_OUT + (CoreType*4));
        }


        // Merge return value
        Ret |= Result;


        // Status Update
        if(Result == NC_SUCCESS)
        {
            // Image Loading Result (Success or Fail)
            *Status |= (1<<CoreType);
        }


        ncBL_DBG_Step(DBG_STP_IMG_0_OUT + (CoreType*4));
    }


    ncBL_DBG_Step(DBG_STP_IMG_OUT);


    return Ret;
}


void ncBL_SF_DeInitialize(ptBOOT_INFO ptBootInfo)
{
    // DeInit sFlash Inferface : Default SPI Mode    
    ncSvc_SF_DeInit(ptBootInfo->tStrap.mFlashCS);    
}


INT32 ncBL_SF_Initialize(ptBOOT_INFO ptBootInfo)
{
    INT32 Ret = NC_FAILURE;
    UINT8 rRDID[3] = {0xA5, 0x5A, 0xC3};        // b'1010_0101, b'0101_1010, b'1100_0011


    ncBL_DBG_Step(DBG_STP_SF_IN);


    // Init sFlash Inferface : Default SPI Mode
    ncSvc_SF_Init(ptBootInfo->tStrap.mFlashCS
                 ,(ptBootInfo->tClock.mAPB/2)
                 ,ptBootInfo->tClock.mAPB);


    // Check SPI-BitRate
    Ret = ncBL_SF_CheckSPIBitRate(ptBootInfo);


    // Select QSPI or DMA Mode  
    if(Ret == NC_SUCCESS)
    {
        // QSPI Support Check and Set QSPI Mode
        Ret = ncSvc_SF_QspiEnable(ptBootInfo->tStrap.mFlashCS, rRDID);


        // Support QSPI Mode  
        if(Ret == NC_SUCCESS)
        {
            // Check QSPI-BitRate
            Ret = ncBL_SF_CheckQSPIBitRate(ptBootInfo);
        }


        #ifdef __DMA_ENABLE__
            // Not Supported QSPI -> Change DMA Mode
            if(Ret == NC_FAILURE)
            {
                // Check DMA-BitRate
                Ret = ncBL_SF_CheckDMASPIBitRate(ptBootInfo);
            }
        #endif


        // Not Supported QSPI/DMA
        if(Ret == NC_FAILURE)
        {
            ptBootInfo->tImage.mCtrlMode = SPI_MODE;
        }
        
    }


    // Image Config Ctrl
    ptBootInfo->tImage.mReadMode[E_CORE_DLS] = ptBootInfo->tImage.mCtrlMode; 
    ptBootInfo->tImage.mReadMode[E_CORE_SIG] = ptBootInfo->tImage.mCtrlMode; 
    ptBootInfo->tImage.mReadMode[E_CORE_DSP] = ptBootInfo->tImage.mCtrlMode; 


#ifdef __UART_ENABLE__
    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n"); 
    DEBUGMSG(MSGINFO, "  > Serial Flash [%d]\n", ptBootInfo->tImage.mCtrlMode);    
    DEBUGMSG(MSGINFO, "    -. SPI  : %8d Hz\n", SYS_SPI_CLK);    
    DEBUGMSG(MSGINFO, "    -. QSPI : %8d Hz\n", SYS_QSPI_CLK);    
    DEBUGMSG(MSGINFO, "    -. INFO : 0x%02X,0x%02X,0x%02X\n", rRDID[0], rRDID[1], rRDID[2]);
#endif

    ncBL_DBG_Step(DBG_STP_SF_OUT);

    return Ret;
}


void ncBL_SYS_Jump(UINT32 Status)
{
#ifdef __BL1__

    PrVoid PC_CountReset = (PrVoid)(APACHE_IRAM_BASE);

    ncBL_DBG_Step(DBG_STP_JUMP);

    PC_CountReset();
    
#else // __BL2__

    PrVoid PC_CountReset = (PrVoid)(0x0);                   
    UINT32 Temp;


    ncBL_DBG_Step(DBG_STP_JUMP);

    
    // 0x0: 64KB, 0x1:128KB, 0x3:256KB, 0x7:512KB, 0xF:1MB ....
    Temp = (APACHE_DRAM_BASE | 0x07);

    // Dual-Core DDR 0x8000_0000 Remap
    REGRW32(APACHE_SCU_BASE, rSCU_REMAP_DLS_S_ADDR_00) = 0x0;
    REGRW32(APACHE_SCU_BASE, rSCU_REMAP_DLS_E_ADDR_00) = Temp;

    REGRW32(APACHE_SCU_BASE, rSCU_REMAP_DLS_S_ADDR_01) = 0x0;
    REGRW32(APACHE_SCU_BASE, rSCU_REMAP_DLS_E_ADDR_01) = Temp;


    if(Status&(1<<E_CORE_SIG))
    {
        Temp |= APACHE_RMAP_SIZE;
        
        // Single-Core DDR 0x8008_0000 Remap
        REGRW32(APACHE_SCU_BASE, rSCU_REMAP_SIG_S_ADDR) = 0x0;
        REGRW32(APACHE_SCU_BASE, rSCU_REMAP_SIG_E_ADDR) = Temp;
    }

    // Remap Enable
    REGRW32(APACHE_SCU_BASE, rSCU_REMAP_EN) = ENABLE;

    while(1)
    {
        // Check Remap Bit 
        Temp = REGRW32(APACHE_SCU_BASE, rSCU_REMAP_EN);
        if(Temp)
        {
            
            if(Status&(1<<E_CORE_SIG))
            {
                // Single Core Run (Reset : HIGH->LOW)
                REGRW32(APACHE_SCU_BASE, rSCU_RST_CPU) &= ~0x00030000;
            }

            // Jump 
            PC_CountReset();

            // Never Done
            break;
        }
    }
#endif
}


INT32 main(void)
{
    INT32 Ret = NC_SUCCESS;
    UINT32 Status = 0;
    tBOOT_INFO tBootInfo;  


    /*
     *------------------------------------------------
     * FPGA Mode
     *  -. Check Booting-Speed
     *  -. Debug GPIO Toggle
     *------------------------------------------------
     */
    ncBL_DBG_GpioToggle();




    /*
     *------------------------------------------------
     * Init Debug Register
     *  -. for RTL Simulation
     *  -. Used when debugging in UART Off state.
     *------------------------------------------------
     */
    ncBL_DBG_RegInit();




    /*
     *------------------------------------------------
     * Init SCU 
     *  -. Check Boot-Strap
     *  -. Clock Enable and IP Reset
     *------------------------------------------------
     */
    ncBL_SCU_Initialize(&tBootInfo);




#ifdef __SIM_FAST_BOOT_MODE__

    // Only DDR Init 
    Ret = ncBL_DDR_Initialize(&tBootInfo);

#else
    /*
     *------------------------------------------------
     * Init UART Interface 
     *  -. Used Control UART-0 (Only Tx)
     *  -. Default BaudRate - 57600
     *------------------------------------------------
     */
    ncBL_UART_Initialize(&tBootInfo);




     /*
     *------------------------------------------------
     * Interrupt Init
     *  -. I will not use it by default
     *  -. However, since I do not know the later work, I applied it.
     *------------------------------------------------
     */  
    ncBL_INTC_Initialize();




     /*
     *------------------------------------------------
     * DDR Init
     *  -. Only BL2
     *------------------------------------------------
     */     
    Ret = ncBL_DDR_Initialize(&tBootInfo);




    /*
     *------------------------------------------------
     * If (DDR Init == SUCCESS) 
     *  -. BL1 : Always Succes
     *  -. BL2 : I hope to succeed
     *------------------------------------------------
     */
    if(Ret == NC_SUCCESS)
    {
        /*
         *------------------------------------------------
         * Boot Image sFlash Address 
         *  -. Set Loading FW Count
         *  -. Set Temp Buffer (Used QSPI or DMA BitRate Check)
         *  -. Set Instuction Buffer (Used DMA Mode)
         *  -. Set Limit Image Size
         *  -. Modify Main.h 
         *------------------------------------------------
         */
        tBootInfo.tImage.mTotalCnt  = BL_IMG_LOADING_CNT;
        tBootInfo.tImage.mTempBuff  = BL_TEMP_BUFF_ADDR;
        tBootInfo.tImage.mInstBuff  = BL_INST_BUFF_ADDR;
        tBootInfo.tImage.mLimitSize = BL_IMG_MAX_SIZE;

        // sFlash Address
        tBootInfo.tImage.mFlashAddr[E_CORE_DLS][E_IMG_NORMAL] = BL_IMG_DLS_SRC_NORMAL_ADDR; 
        tBootInfo.tImage.mFlashAddr[E_CORE_DLS][E_IMG_BACKUP] = BL_IMG_DLS_SRC_BACKUP_ADDR; 
        tBootInfo.tImage.mFlashAddr[E_CORE_SIG][E_IMG_NORMAL] = BL_IMG_SIG_SRC_NORMAL_ADDR; 
        tBootInfo.tImage.mFlashAddr[E_CORE_SIG][E_IMG_BACKUP] = BL_IMG_SIG_SRC_BACKUP_ADDR; 
        tBootInfo.tImage.mFlashAddr[E_CORE_DSP][E_IMG_NORMAL] = BL_IMG_DSP_SRC_NORMAL_ADDR; 
        tBootInfo.tImage.mFlashAddr[E_CORE_DSP][E_IMG_BACKUP] = BL_IMG_DSP_SRC_BACKUP_ADDR; 

        // SRAM or DDR (destination address to copy FW image)
        tBootInfo.tImage.mDestAddr[E_CORE_DLS] = BL_IMG_DLS_DEST_ADDR; 
        tBootInfo.tImage.mDestAddr[E_CORE_SIG] = BL_IMG_SIG_DEST_ADDR; 
        tBootInfo.tImage.mDestAddr[E_CORE_DSP] = BL_IMG_DSP_DEST_ADDR; 




        /*
         *------------------------------------------------
         * Init sFlash Interface 
         *  -. SPI, QSPI or DMA
         *  -. Get Image Header (Used SPI Interface)  
         *------------------------------------------------
         */
        Ret = ncBL_SF_Initialize(&tBootInfo);



     
        /*
         *------------------------------------------------
         * If (SPI Init == Success)
         *  -. Check Header 
         *  -. Loading FW Image (sflash->SRAM or DDR)  
         *------------------------------------------------
         */
        if(Ret == NC_SUCCESS)
        {
            Ret = ncBL_SF_ImageLoading(&tBootInfo, &Status);
        }
    }





    /*
     *------------------------------------------------
     * De-Init sFlash Interface 
     *  -. Debug - loading Fail/Ok Save
     *  -. Free Pin Mux (for Nextune)
     *------------------------------------------------
     */
    ncBL_DBG_Result(Ret);     
    ncBL_SF_DeInitialize(&tBootInfo);
#endif




    /*
     *------------------------------------------------
     * If (FW Loading == Success)
     *  -. Jump SRAM or DDR
     *------------------------------------------------
     */
    if( (Ret == NC_SUCCESS) || (Status&(1<<E_CORE_DLS)) )
    {    
        ncBL_SYS_Jump(Status);
    }




    /*
     *------------------------------------------------
     * If (FW Loading == Failure)
     *  -. Returned from main() 
     *  -. Wait for FW Download (for Nextune)
     *  -. Wait Function [ Loop_Handler(), Startup Code ]
     *------------------------------------------------
     */
    ncBL_DBG_Step(DBG_STP_WAIT);

    // Fake Function (Skip)
    while(DUMMY_ER_ZI_DATA[0]);

    return Ret;
}


#undef __MAIN_C__


/* End Of File */

