/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * \defgroup SSS_ECC		SSS_ECC
 * \ingroup SSS_Library
 * \brief					ECC Core Library
 * \{
 */

/*!
 * \file		sss_lib_ecc_core.h
 * \brief		Header for ECC core function
 * \author		Kiseok Bae (kiseok.bae at samsung.com)
 * \version		V1.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 |V0.01		|2018.03.30	|kiseok		|Beta Version   |
 |V1.00		|2018.04.27	|kiseok		|Final Version  |
 */

#ifndef SSS_LIB_ECC_CORE_H_
#define SSS_LIB_ECC_CORE_H_

/*************** Include Files ************************************************/
#include "sss_lib_pke_a.h"

#ifndef SBOOT_SOL
	#include "sss_api_rng.h"
#endif


/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/
/*! \brief	struct of ECC private key */
typedef struct
{
	/*!	if u32KeyType != 0xFFFFFFFF, u32KeyType means KeyHandle.
		otherwise, private key is inserted directly.
	*/
	u32				u32KeyType;
	/*! id of elliptic curve  */
	u32				u32EllipticCurveID;
	/*! struct of stBIG_NUM to represent of Big Number D  */
	stOCTET_STRING	stBigNum_D;
} stECC_PRIVKEY;

/*! \brief	struct of ECC public key */
typedef struct
{
	/*!	if u32KeyType != 0xFFFFFFFF, u32KeyType means KeyHandle.
		otherwise, private key is inserted directly.
	 */
	u32				u32KeyType;
	/*! id of elliptic curve */
	u32				u32EllipticCurveID;
	/*! struct of stBIG_NUM to represent of Big Number Qx */
	stOCTET_STRING	stBigNum_Qx;
	/*! struct of stBIG_NUM to represent of Big Number Qy */
	stOCTET_STRING	stBigNum_Qy;
} stECC_PUBKEY;


/**
 * \brief	struct of ECC Param
 */
typedef struct
{
	/** < Curve Domain */
	u32 u32CurveID;
	/** < Parameter data word length */
	u32 u32Data_wlen;

} stECC_Param;

/**
 * \brief	struct of ECDSA Sign
 */
typedef struct
{
	/** < object id */
	u32 u32ECDSA_OID;
	/** < ECDSA-r */
	stOCTET_STRING stSign_r;
	/** < ECDSA-s */
	stOCTET_STRING stSign_s;
} stECDSA_SIGN;

/*************** Constants ****************************************************/

/*************** Variable declarations ****************************************/

/*************** Error Message ************************************************/
#define ERROR_ECC_INVALID_LEN_KEY (ERR_KEY|INVALID_LEN|ERROR_ECC)
#define ERROR_ECC_INVALID_VAL_KEY (ERR_KEY|INVALID_VAL|ERROR_ECC)

/*************** Prototypes ***************************************************/
/**
 * \brief		set ecc param data
 * \param[in]	pstDomainParam    	ECC object = select EC parameter(160, 192, 224, 256, 384, 521)
 * \return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 ERROR_INVALID_OID_SIZE

 */
void ECC_PARAM(const stECC_Param *pstDomainParam);

#ifndef SBOOT_SOL
/**
 * \brief		set ecdsa key data
 * \param[in]	pstECCkey			pointer of ECC_KEY structure
 * \param[in]	SEG_ID				target segment id
 * \return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 ERROR_IP_BUSY
 ERROR_INVALID_OID_SIZE

 */
SSS_RV ECC_PRVKEY(const stECC_PRIVKEY *pstECCkey, u32 SEG_ID);
#endif

SSS_RV ECC_PUBKEY(const stECC_PUBKEY *pstECCkey, u32 SEG_ID_X);

void get_ECC256Info(stECC_Param *pstECCParam);

SSS_RV chk_INPUT(u32 SEG_ID);

#ifndef SBOOT_SOL
SSS_RV get_random_scalar256(u32 seg_id);
#endif

/*************** END OF FILE **************************************************/

#endif /* SSS_LIB_ECC_CORE_H_ */

/** \} */
