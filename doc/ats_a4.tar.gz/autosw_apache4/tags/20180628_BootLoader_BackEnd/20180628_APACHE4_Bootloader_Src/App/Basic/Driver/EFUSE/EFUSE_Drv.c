/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

void ncDrv_EFUSE_Enable(void)
{
    REGRW32(APACHE_ATOP_BASE, 0x1000) = 0x1;    // efuse enable
    REGRW32(APACHE_ATOP_BASE, 0x1008) = 2;      // efuse unit time
    ncDrv_EFUSE_Disable();
    // Sense Mode On
    REGRW32(APACHE_ATOP_BASE, 0x1010) = 0x1;    // efuse sense on
    REGRW32(APACHE_ATOP_BASE, 0x1010) = 0x0;    // efuse sense off
    
    while(!REGRW32(APACHE_ATOP_BASE, 0x1014));  // efuse scan done    
}

void ncDrv_EFUSE_Disable(void)
{
    UINT32 i;

    // Clear
    for(i=0; i<16; i++)
    {
        REGRW32(APACHE_ATOP_BASE, 0x1020 + (i << 2)) = 0x0;
    }

    // Scan Mode On
    REGRW32(APACHE_ATOP_BASE , 0x1010) = 0x2;   // efuse scan on
    REGRW32(APACHE_ATOP_BASE , 0x1010) = 0x0;   // efuse sense off
    
    while(!REGRW32(APACHE_ATOP_BASE, 0x1014));  // efuse scan done
}


/* End Of File */

