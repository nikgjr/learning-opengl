/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * \defgroup SSS_HMACSHA		SSS_HMACSHA
 * \ingroup SSS_Driver
 * \brief					HMAC_SHA Driver & Library
 * \{
 */

/**
 * \file		sss_lib_hmac_sha256.c
 * \brief		Source for HMAC_SHA core function
 * \author		Kiseok Bae (kiseok.bae at samsung.com)
 * \version		V1.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 |V0.01		|2018.03.30	|kiseok		|Beta Version   |
 |V1.00		|2018.04.27	|kiseok		|Final Version  |
 */

/*************** Include Files ************************************************/
#include "sss_lib_hmac_sha256.h"
#include "sss_lib_util.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ****************************************************/

/*************** Prototypes ***************************************************/
static SSS_RV HMACKEY(const stSHA_PARAMS *pstHASH_PARAM);

void get_Hash256Info(stSHA_PARAMS *pstHASH_PARAM)
{
	/*! > Get hash parameters using the variable written at HASH_CONTROL */

	/* HASH_CONTROL_SHA2_256
	! 	+ block length : 16 word
	! 	+ hash output length : 8 word */
	pstHASH_PARAM->u32Block_byte_len = 64u;
	pstHASH_PARAM->u32Digest_byte_len = 32u;
}

static SSS_RV HMACKEY(const stSHA_PARAMS *pstHASH_PARAM)
{
	SSS_RV ret = SSSR_SUCCESS;

	sss_SFRclr(HASH_HMAC_KEY_ADDR, (pstHASH_PARAM->u32Block_byte_len / 4u));

	if (pstHASH_PARAM->u32Block_byte_len >=  pstHASH_PARAM->pstMACKey->u32DataByteLen)
	{
		sss_OS_to_SFR(HASH_HMAC_KEY_ADDR, (const stOCTET_STRING *)pstHASH_PARAM->pstMACKey);

		SFR_BIT_SET(HASH_CONTROL, HMAC_EN);
	}
	else
	{
		ret = ERROR_HMAC_SHA2_INVALID_LEN_KEY;
	}

	return ret;
}

SSS_RV HMACSHA_init(const stSHA_PARAMS *pstHASH_PARAM, u32 u32HMAC_Flag)
{
	SSS_RV ret = SSSR_SUCCESS;
	/*! > Sequence */

	/*! Step1. HMAC_SHA SFR Clear & SWAP */
	SFR_SET(HASH_CONTROL, HASH_SW_RESET);
	SFR_SET(HASH_BYTE_SWAP,
			(HASH_BYTESWAP_IV|HASH_BYTESWAP_KEY|HASH_BYTESWAP_DO|HASH_BYTESWAP_DI));

	/*! Step2. Set the message size in bytes */
	SFR_SET(HASH_DATA_SIZE_LOW, pstHASH_PARAM->pstMSG->u32DataByteLen);

	/*! Step3. HMAC Setting if HMAC */
	if (u32HMAC_Flag != 0u)
	{
		ret = HMACKEY(pstHASH_PARAM);
	}

	/*! Step4. Start HMAC_SHA */
	if (SSSR_SUCCESS == ret)
	{
		SFR_BIT_SET(HASH_CONTROL, START_INIT_BIT);
	}

	return ret;
}

void HMACSHA_update(stSHA_PARAMS *pstHASH_PARAM)
{
	stOCTET_STRING stTemp;
	u32 u32ByteLen = pstHASH_PARAM->pstMSG->u32DataByteLen;

	stTemp.pu08Data = pstHASH_PARAM->pstMSG->pu08Data;
	stTemp.u32DataByteLen = pstHASH_PARAM->u32Block_byte_len;

	/*! > Sequence */
	while (u32ByteLen != 0u)
	{

		WAIT_SFR_BIT_SET(HASH_STATUS_ADDR, HASH_BUFFER_READY);


		if(u32ByteLen < pstHASH_PARAM->u32Block_byte_len)
		{
			stTemp.u32DataByteLen = u32ByteLen;
		}
		/*sss_OS_to_SFR((u32*) &HASH_DATA_IN_1, &stTemp);*/
		sss_OS_to_SFR(HASH_DATA_ADDR, &stTemp);
		stTemp.pu08Data += stTemp.u32DataByteLen;
		u32ByteLen -= stTemp.u32DataByteLen;
	}
}

void HMACSHA_final(const stSHA_PARAMS *pstHASH_PARAM, stOCTET_STRING *pstDigest)
{
	u32 u32SrcAddr;

	u32 zu32SHA256_NullDigest[8] =
	{
	0x42c4b0e3u,0x141cfc98u,0xc8f4fb9au,0x24b96f99u,
	0xe441ae27u,0x4c939b64u,0x1b9995a4u,0x55b85278u
	};

	/*!
	 * > Sequence
	 */

	/*!
	 * Step1. Wait for Done
	 */
	if (pstHASH_PARAM->pstMSG->u32DataByteLen != 0u)
	{

		WAIT_SFR_BIT_SET(HASH_STATUS_ADDR, HASH_MSG_DONE);

		SFR_W0i1C(HASH_STATUS, HASH_MSG_DONE);

		u32SrcAddr = HASH_RESULT_ADDR;
	}
	else
	{
		/*!
		 * Step1-1. Zero message
		 */
		u32SrcAddr = (u32)zu32SHA256_NullDigest;
	}

	/*!
	 * Step2. update to Output
	 */
	pstDigest->u32DataByteLen = pstHASH_PARAM->u32Digest_byte_len;
	sss_SFR_to_OS(pstDigest, u32SrcAddr);

}

#ifdef SBOOT_SOL
SSS_RV sss_Hash_Compare(stOCTET_STRING *pstInput, const u08 *pu08Target)
{
	SSS_RV ret;
	stSHA_PARAMS zstHASH_Param;
	stOCTET_STRING zstDigest;
	u08 zu08Temp[32];

	/*! > Step 0. Get Hash param data */
	get_Hash256Info(&zstHASH_Param);
	/* assign message to param */
	zstHASH_Param.pstMSG = (stOCTET_STRING*) pstInput;

	/*! > Step 1. Hash init */
	ret = HMACSHA_init(&zstHASH_Param, HASH_ONLY);
	if (SSSR_SUCCESS == ret)
	{
		/*! > Step 2. Hash update during msg > block */
		if (zstHASH_Param.pstMSG->u32DataByteLen != 0u)
		{
			HMACSHA_update(&zstHASH_Param);
		}
		zstDigest.pu08Data = zu08Temp;

		/*! > Step 3. Hash final */
		HMACSHA_final(&zstHASH_Param, &zstDigest);

		/*! > Step 4. Compare*/
		ret = sss_memcmp_u08(pu08Target, zu08Temp, zstHASH_Param.u32Digest_byte_len );
	}

	return ret;
}

SSS_RV sss_HMAC_Compare(stOCTET_STRING *pstKey,
		stOCTET_STRING *pstInput, const u08 *pu08Target)
{
	SSS_RV ret;
	stSHA_PARAMS zstHASH_Param;
	stOCTET_STRING zstDigest;
	u08 zu08Temp[32];

	if(pstInput->u32DataByteLen == 0x0u)
	{
		ret = ERROR_HMAC_SHA2_INVALID_LEN_MSG;
	}
	else
	{
		zstDigest.pu08Data = zu08Temp;

		/*! > Step 0. Get Hash param data */
		get_Hash256Info(&zstHASH_Param);
		/* assign message to param */
		zstHASH_Param.pstMSG = (stOCTET_STRING*) pstInput;

		/* assign key to param */
		zstHASH_Param.pstMACKey = (stOCTET_STRING*) pstKey;

		/*! > Step 2. HMAC init */
		ret = HMACSHA_init(&zstHASH_Param, HMAC_FLAG);
		if (SSSR_SUCCESS == ret)
		{
			/*! > Step 3. HMAC update during msg > block */
			HMACSHA_update(&zstHASH_Param);

			/*! > Step 4. HMAC final */
			HMACSHA_final(&zstHASH_Param, &zstDigest);

			/*! > Step 4. Compare*/
			ret = sss_memcmp_u08(pu08Target, (const u08*)zstDigest.pu08Data, zstHASH_Param.u32Digest_byte_len);
		}
	}

	return ret;
}
#endif
/*************** END OF FILE **************************************************/

/** \} */
