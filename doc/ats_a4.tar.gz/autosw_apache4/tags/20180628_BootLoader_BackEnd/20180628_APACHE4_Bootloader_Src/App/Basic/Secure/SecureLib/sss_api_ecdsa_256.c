/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * \defgroup SSS_ECDSA256		SSS_ECDSA256
 * \ingroup SSS_API
 * \brief					ECDSA256 Library
 * \{
 */

/*!
 * \file		sss_api_ecdsa_256.c
 * \brief		Sourcefile for ECDSA API
 * \author		Kiseok Bae (kiseok.bae at samsung.com)
 * \version		V1.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 |V0.01		|2018.03.30	|kiseok		|Beta Version   |
 |V1.00		|2018.04.27	|kiseok		|Final Version  |
 */

/*************** Include Files ********************************************/
#include "sss_lib_util.h"
#include "sss_api_ecdsa_256.h"

/*************** Assertions ***********************************************/

/*************** Definitions / Macros *************************************/

/*************** Constants ************************************************/

/*************** Variable declarations ************************************/

/*************** Prototypes ***********************************************/

/*************** Function *************************************************/
SSS_RV sss_ECDSA_Verify_256(const stECC_PUBKEY *pstEcdsaPubKey,
		stOCTET_STRING *pstDigest, const stECDSA_SIGN *pstSIGN)
{
	SSS_RV ret;
	stECC_Param zstECDSAParam;

	/*! > Sequence */
	/*! Step 1. Init */
	/*! - ECC Info */
	get_ECC256Info(&zstECDSAParam);

	/*! - ECDSA Init */
	ret = ECDSA_verify_Init((const stECC_Param*)&zstECDSAParam, pstEcdsaPubKey);
	if (SSSR_SUCCESS == ret)
	{

		/*! Step 2. Update */
		/*! - ECDSA Update with Digest */
		if (0x0u != pstDigest->u32DataByteLen)
		{
			ECDSA_update(pstDigest, zstECDSAParam.u32Data_wlen);
			/*! Step 3. Final */
			/*! - ECDSA Final with Sign */
			ret = ECDSA_verify_final((const stECC_Param*)&zstECDSAParam, pstSIGN);
			/*! - Get result */
		}
		else
		{
			ret = ERROR_ECDSA_INVALID_LEN_MSG;
		}
	}

	return ret;
}

#ifndef SBOOT_SOL
SSS_RV sss_ECDSA_Sign_256(stECC_PRIVKEY *pstEcdsaPrivKey,
		stOCTET_STRING *pstDigest, stECDSA_SIGN *pstSIGN)
{
	SSS_RV ret;
	stECC_Param zstECDSAParam;

	/*! > Sequence */
	/*! Step 1. Init */
	/*! - ECC Info */
	get_ECC256Info(&zstECDSAParam);

	/*! - ECDSA Init */
	ret = ECDSA_sign_Init((const stECC_Param*)&zstECDSAParam, pstEcdsaPrivKey);
	if (SSSR_SUCCESS == ret)
	{

		/*! Step 2. Update */
		/*! - ECDSA Update with Digest */
		if (0x0u != pstDigest->u32DataByteLen)
		{
			ECDSA_update(pstDigest, zstECDSAParam.u32Data_wlen);
			/*! Step 3. Final */
			/*! - ECDSA Final with Sign */
			ret = ECDSA_sign_final((const stECC_Param*)&zstECDSAParam, pstSIGN);

			pstSIGN->u32ECDSA_OID = OID_ECDSA_P256_SHA2_256;
		}
		else
		{
			ret = ERROR_ECDSA_INVALID_LEN_MSG;
		}
	}


	return ret;
}
#endif
/*************** END OF FILE **********************************************/

/** \} */
