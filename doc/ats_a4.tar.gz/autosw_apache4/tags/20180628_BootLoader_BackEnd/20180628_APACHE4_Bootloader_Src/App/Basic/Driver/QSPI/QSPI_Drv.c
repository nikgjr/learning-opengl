/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#include "Apache.h"







/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define QSPI_TIMEOUT_MAX            (1000)     // 1sec










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static BOOL ncDrv_QSPI_WaitBusIsBusy(void)
{
    BOOL Ret = TRUE;
    UINT32 TimeOut = QSPI_TIMEOUT_MAX;

    
    while(REGRW32(APACHE_QSPI_BASE, rQSPI_STS) & bQSPI_BUSY)
    {
        if(ncDrv_SCU_mTimeOut(TimeOut))
        {
            Ret = FALSE;
            break;
        }
    }
    ncDrv_SCU_mTimeOut(0);

    return Ret;
}


static BOOL ncDrv_QSPI_WaitFrameDone(void)
{
    BOOL Ret = TRUE;
    UINT32 TimeOut = QSPI_TIMEOUT_MAX;

    
    while(!(REGRW32(APACHE_QSPI_BASE, rQSPI_STS) & bQSPI_MIFDONE))
    {
        if(ncDrv_SCU_mTimeOut(TimeOut))
        {
            Ret = FALSE;
            break;
        }
    }
    ncDrv_SCU_mTimeOut(0);
    
    return Ret;
}


void ncDrv_QSPI_SetCSN(UINT8 CSN)
{
    //----------------------------------------------
    // if( rQSPI_START_ADDR < rQSPI_EXT_ADDR)
    //    ChipSelect = CSN0   
    // else if( rQSPI_START_ADDR >= rQSPI_EXT_ADDR)
    //    ChipSelect = CSN1
    //----------------------------------------------
    
    if(CSN == 1)
        REGRW32(APACHE_QSPI_BASE, rQSPI_EXT_ADDR) = 0x00;       // Used CSN_1
    else
        REGRW32(APACHE_QSPI_BASE, rQSPI_EXT_ADDR) = 0xFFFFFF;   // Used CSN_0
}


UINT32 ncDrv_QSPI_SetBitRate(UINT32 Div, UINT32 RefClk)
{
                                     // 0x0,  0x1,  0x2,  0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xA, 0xB, 0xC, 0xD, 0xE, 0xF
    const UINT32 DivValue[] = { 4095, 2500, 1250, 1000, 500, 250, 125,  50,  25,  12,  10,   5,   4,   3,   2,   0};  
    UINT32 Reg;

    Reg = REGRW32(APACHE_QSPI_BASE, rQSPI_CTRL) & ~(0xf<<bQSPI_BRATE);
    REGRW32(APACHE_QSPI_BASE, rQSPI_CTRL) = (Reg | (Div<<bQSPI_BRATE));

    return RefClk/DivValue[Div];
}


INT32 ncDrv_QSPI_ReadData(UINT32 Addr, UINT32 BuffAddr, UINT32 Size)
{   
    INT32 Ret = NC_SUCCESS;    
    UINT32 Reg;


    // cache clean and invalidate data
    if(1) // BuffAddr < APACHE_DRAM_BASE)
        ASM_DCACHE_FLUSH(BuffAddr, Size);


    // QSPI Status Clear - Why?? Read Only Register, 
    REGRW32(APACHE_QSPI_BASE, rQSPI_STS) = 0x0;   


    // QSPI Ctrl Register 
    Reg = REGRW32(APACHE_QSPI_BASE, rQSPI_CTRL) & (0xf<<bQSPI_BRATE);
    Reg |= (bQSPI_INT_EN | bQSPI_SCKPOL | bQSPI_EN  | (0xEB<<0));
    REGRW32(APACHE_QSPI_BASE, rQSPI_CTRL) = Reg;


    // OSG Mode Disable
    REGRW32(APACHE_QSPI_BASE, rQSPI_OSG_DN) = bQSPI_OSG_DIS;

    
    // Master Interface Enable    
    REGRW32(APACHE_QSPI_BASE, rQSPI_MICTRL) = (bQSPI_MIEN |bQSPI_MIQSWIP | bQSPI_MIHSWIP);  


    // Master Interface Buffer Address
    REGRW32(APACHE_QSPI_BASE, rQSPI_MIADDR) = BuffAddr;
    // Dummy Address
    REGRW32(APACHE_QSPI_BASE, rQSPI_DUMMY)  = 0x00FF0000; 
    // sFlash End Address
    REGRW32(APACHE_QSPI_BASE, rQSPI_EADDR)  = (Addr+Size-1);
    // sFlash Start Address
    REGRW32(APACHE_QSPI_BASE, rQSPI_SADDR)  = Addr;      


    // Wait Busy
    if(!ncDrv_QSPI_WaitBusIsBusy())
        Ret = NC_FAILURE;


    // Wait Done
    if(!ncDrv_QSPI_WaitFrameDone())
        Ret = NC_FAILURE;


    // Master Interface Disable
    REGRW32(APACHE_QSPI_BASE, rQSPI_MICTRL) = 0x0;

        
    // OSG Mode Disable
    REGRW32(APACHE_QSPI_BASE, rQSPI_OSG_DN) = bQSPI_OSG_DIS;

    return Ret;
}




/* End Of File */

