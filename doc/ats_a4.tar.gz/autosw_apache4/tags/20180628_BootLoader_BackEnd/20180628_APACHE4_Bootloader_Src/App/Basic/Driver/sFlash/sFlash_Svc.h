/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SFLASH_SVC_H__
#define __SFLASH_SVC_H__


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define CMD_sFLASH_WR_EN                        0x06
#define CMD_sFLASH_WR_DS                        0x04
#define CMD_sFLASH_RD_STS                       0x05
#define CMD_sFLASH_RD_STS2                      0x35		// for WINBOND Type
#define CMD_sFLASH_WR_STS                       0x01
#define CMD_sFLASH_RD_DATA                      0x03
#define CMD_sFLASH_RD_IDENTIFICATION            0x9F

#define STS_WIP                                 (0x1<<0)
#define STS_WEL                                 (0x1<<1)

#define FLASH_ID_WINBOND                        (0xEF)
#define FLASH_ID_EON                            (0x1C)
#define FLASH_ID_MXIC                           (0xC2)
#define FLASH_ID_CYPRESS                        (0x01)      // Spansion

#define FLASH_ID_MICRON                         (0x20)
#define FAASH_ID_SST                            (0xBF)
#define FLASH_ID_ATML                           (0x1F)

#define SF_BLOCK_SIZE                           (64*KB)
#define SF_SECTOR_SIZE                          (4*KB)
#define SF_PAGE_SIZE                            (256)

#define SF_DMA_TIME_OUT                         2000        // 2-msec










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum _SF_MODE
{
    CTRL_NONE = 0,
    SPI_MODE,
    QSPI_MODE,
    DMA_MODE
} SF_MODE;











/*
********************************************************************************
*              FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncSvc_SF_ReadData(UINT8 CSN, UINT32 CtrlMode, UINT32 InstBuff, UINT32 Addr, UINT8 *pData, UINT32 Size);
extern INT32 ncSvc_SF_QspiEnable(UINT8 CSN, UINT8* pRDID);
extern void  ncSvc_SF_DeInit(UINT8 CSN);
extern void  ncSvc_SF_Init(UINT8 CSN, UINT32 BitRate, UINT32 RefClk);

#endif /* __SFLASH_SVC_H__ */


/* End Of File */

