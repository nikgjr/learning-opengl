/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * \defgroup SSS_PKE_A		SSS_PKE_A
 * \ingroup SSS_Driver
 * \brief					PKA Driver & Library
 * \{
 */

/*!
 * \file		sss_lib_pke_a.h
 * \brief		Headerfile for pka library
 * \author		kiseok.bae (kiseok.bae at samsung.com)
 * \version		V1.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 |V0.01		|2018.03.30	|kiseok		|Beta Version   |
 |V1.00		|2018.04.27	|kiseok		|Final Version  |
 */

#ifndef SSS_LIB_PKE_A_H_
#define SSS_LIB_PKE_A_H_

/*************** Include Files ************************************************/
#include "sss_lib_common.h"

/*************** Assertions ***********************************************/

/*************** Definitions / Macros *************************************/
/*
 * SFR Defintion for crypt_pke_a_v1.20e
 */
#define PKA_SRAM_OFFSET		(0x1000u)
#define PKA_SFR_0			(*(volatile u32 *)((PKA_REG_BASE) + 0x0000u))
#define PKA_SFR_0_ADDR		((PKA_REG_BASE) + 0x0000u)
	#define SEG_SIZE_036B		(((u32)0u)<<24)		/**< 288b */
	#define SEG_SIZE_068B		(((u32)1u)<<24)		/**< 544b */
#if SSS_UNUSED
	#define SEG_SIZE_132B		(((u32)2u)<<24)		/**< 1056b */
	#define SEG_SIZE_260B		(((u32)3u)<<24)		/**< 2080b */
#endif
	#define PREC_ID(x)			(((u32)(x))<<8)		/**< x = 0..63 (supporting 32*(x+1) bits) */
	#define FUNC_ID_MM			(((u32)0u)<<4)		/**< Modular Multiplication of A & B */
	#define FUNC_ID_M1			(((u32)1u)<<4)		/**< Modular Multiplication of A & 1 */
	#define FUNC_ID_MA			(((u32)2u)<<4)		/**< Modular Addition of A & B */
	#define FUNC_ID_MS			(((u32)3u)<<4)		/**< Modular Subtraction of A & B */
	#define FUNC_ID_ME			(((u32)0x4u)<<8)	/**<N/A on crypt_ke_a_v1.20e */
	#define FUNC_ID_PA			(((u32)0x8u)<<8)    /**<N/A on crypt_ke_a_v1.20e */
	#define FUNC_ID_PD			(((u32)0xAu)<<8)    /**<N/A on crypt_ke_a_v1.20e */
	#define FUNC_ID_SM			(((u32)0xCu)<<8)    /**<N/A on crypt_ke_a_v1.20e */
	#define FUNC_ID_TS			(((u32)0xDu)<<8)    /**<N/A on crypt_ke_a_v1.20e */
	#define EXEC_ON				(((u32)1u)<<0)		/**< Run Execution */
#define PKA_SFR_1           (*(volatile u32 *)((PKA_REG_BASE) + 0x0004u))
	#define SEG_ID_A(x)			(((u32)(x))<<24)		/**<	x = 0..63 (Segment ID for 'A') */
	#define SEG_ID_B(x)			(((u32)(x))<<16)		/**<	x = 0..63 (Segment ID for 'B') */
	#define SEG_ID_M(x)			(((u32)(x))<< 8)		/**<	x = 0..63 (Segment ID for 'M') */
	#define SEG_ID_S(x)			(((u32)(x)))		/**<	x = 0..63 (Segment ID for 'S') */
#define PKA_SFR_2           (*(volatile u32 *)((PKA_REG_BASE) + 0x0008u))
	#define SEG_ID_I(x)			(((u32)(x))<<16u)		/**<	x = 0..63 (Segment ID for 'I') */
#define PKA_SFR_3           (*(volatile u32 *)((PKA_REG_BASE) + 0x000Cu))
		#define IS_NEGATIVE(SegID)	( ((PKA_SFR_3)>>(SegID))&((u32)1u) )
	#define SET_SIGN(SegID)		( (PKA_SFR_3) |= (((u32)1u)<<(SegID)) )
	#define CLEAR_SIGN(SegID)	( (PKA_SFR_3) &= (~(((u32)1u)<<(SegID))) )
#if SSS_UNUSED
	#define PKA_ECC_INT_STAT
	#define PKA_ECC_UNCOORRECT_STAT		(((u32)1u)<<1)		/**< indicate double error bits */
	#define PKA_ECC_SEC_STAT			(((u32)1u)<<0)		/**< single error bit */
	#define PKA_ECC_INT_EN_SET
	#define PKA_ECC_INT_EN_CLR
	#define PKA_ECC_INT_PEND							/**< write 1 clear */
	#define PKA_ECC_INT_ENABLE
	#define PKA_ECC_ENABLE			(((u32)1u)<<0)		/**< ECC enable bit */
	#define PKA_ECC_ERRLOG_CLR
	#define PKA_ERRLOG_DECODER_CLR		(((u32)1u)<<2)		/**< ERR LOG Clear bit */
	#define PKA_ERRLOG_DED_CLR			(((u32)1u)<<1)		/**< ERR LOG Clear bit */
	#define PKA_ERRLOG_SEC_CLR			(((u32)1u)<<0)		/**< ERR LOG Clear bit */
	#define PKA_ECC_SEC_ADDR
	#define PKA_ECC_DED_ADDR
	#define PKA_ECC_ERR_STAT
	#define PKA_ERR_DECODER			(((u32)1u)<<2)		/**< ERR Status bit */
	#define PKA_ERR_DED			(((u32)1u)<<1)		/**< ERR Status bit */
	#define PKA_ERR_SEC			(((u32)1u)<<0)		/**< ERR Status bit */
#endif
/*
 * PKA_SRAM Defintion for crypt_pke_a_v1.20e
 */

#define SEGSZ_ECC256	(9u) /* only for ECC 256 */

#define PKA_SRAM_BASE		(PKA_REG_BASE + PKA_SRAM_OFFSET)
#define ptrPKA_SEG(idx)		((u32*)PKA_SRAM_BASE+((idx)*(SEGSZ_ECC256)))
/*************** New Data Types (Basic Data Types)	***********************/

/*************** New Data Types *******************************************/

/*************** Constants ************************************************/
/*
 * Define Segment ID Number
 */
#define SEG_00		(((u32)0u))
#define SEG_01		(((u32)1u))
#define SEG_02		(((u32)2u))
#define SEG_03		(((u32)3u))
#define SEG_04		(((u32)4u))
#define SEG_05		(((u32)5u))
#define SEG_06		(((u32)6u))
#define SEG_07		(((u32)7u))
#define SEG_08		(((u32)8u))
#define SEG_09		(((u32)9u))
#define SEG_10		(((u32)10u))
#define SEG_11		(((u32)11u))
#define SEG_12		(((u32)12u))
#define SEG_13		(((u32)13u))
#define SEG_14		(((u32)14u))
#define SEG_15		(((u32)15u))
#define SEG_16		(((u32)16u))
#define SEG_17		(((u32)17u))
#define SEG_18		(((u32)18u))
#define SEG_19		(((u32)19u))
#define SEG_20		(((u32)20u))
#define SEG_21		(((u32)21u))
#define SEG_22		(((u32)22u))
#define SEG_23		(((u32)23u))
#define SEG_24		(((u32)24u))
#define SEG_25		(((u32)25u))
#define SEG_26		(((u32)26u))
#define SEG_27		(((u32)27u))
#define SEG_XX		(((u32)0xFFu))	/*	Dummy Segment Name (Un-used)*/

/*
 * Define Segment ID Number for ECC group operation
 */
#define SEG_ID_K			(SEG_02)
#define SEG_ID_Gx			(SEG_03)
#define SEG_ID_Gy			(SEG_04)
#define SEG_ID_P			(SEG_05)
#define SEG_ID_R2p			(SEG_06)
#define SEG_ID_N			(SEG_07)
#define SEG_ID_R2n			(SEG_08)
#define SEG_ID_ECC_Coef_A	(SEG_09)
#define SEG_ID_ECC_Coef_B	(SEG_10)
#define SEG_ID_K2			(SEG_10)
#define SEG_ID_Gx2			(SEG_11)
#define SEG_ID_Gy2			(SEG_12)
#define SEG_ID_Rx			(SEG_13)
#define SEG_ID_Ry			(SEG_14)
#define SEG_ID_Int_00		(SEG_16)
#define SEG_ID_Int_01		(SEG_17)
#define SEG_ID_Int_02		(SEG_18)
#define SEG_ID_Int_03		(SEG_19)
#define SEG_ID_Int_04		(SEG_20)
#define SEG_ID_Int_05		(SEG_21)
#define SEG_ID_Int_06		(SEG_22)
#define SEG_ID_Int_07		(SEG_23)
#define SEG_ID_Int_08		(SEG_24)
#define SEG_ID_Int_09		(SEG_25)
#define SEG_ID_Int_10		(SEG_26)

#define SEG_ID_ECDSA_SignKey	(SEG_01)
#define SEG_ID_ECDSA_Qx			(SEG_11)
#define SEG_ID_ECDSA_Qy			(SEG_12)
#define SEG_ID_ECDSA_HMSG		(SEG_09)
#define SEG_ID_ECC_Gx			(SEG_03)
#define SEG_ID_ECC_Gy			(SEG_04)
#define SEG_ID_ECC_PrimeP		(SEG_05)
#define SEG_ID_ECC_R2p			(SEG_06)
#define SEG_ID_ECC_OrderN		(SEG_07)
#define SEG_ID_ECC_R2n			(SEG_08)
#define SEG_ID_ECDSA_SIGNr		(SEG_01)
#define SEG_ID_ECDSA_SIGNs		(SEG_02)

#define SEG_ID_ECDH_PubQx		(SEG_00)
#define SEG_ID_ECDH_PubQy		(SEG_01)
#define SEG_ID_ECDH_PrivD		(SEG_02)
#define SEG_ID_ECDH_OtherQx		(SEG_03)

/*************** Variable declarations ************************************/

/*************** Prototypes ***********************************************/

/*!
 * \brief 		Initialize PKE
 * \return		N/A
 */
void PKE_A_Init256(void);


/*!
 * \brief 		Clear Sign & PKSRAM for target segment
 * \param[in]	seg_id		target segment id
 * \return		N/A
 *
 */
void PKE_A_1SEG_Clear(u32 seg_id);



/*!
 * \brief 		PKA execution with input segmentations & function ID (with non-fixed segment size)
 * \param[in]	f_id  	PKA function ID = { MM(00), M1(01), MA(02), MS(03)	}
 * \param[in]	Seg_A 	Segment	A_SEG
 * \param[in]	Seg_B 	Segment B_SEG
 * \param[in]	Seg_M 	Segment M_SEG
 * \param[in]	Seg_S 	Segment S_SEG
 * \param[in]	Seg_I 	Segment I_SEG
 * \return		N/A
 *
 */
void PKA_exe(u32 f_id, u32 Seg_A, u32 Seg_B, u32 Seg_M, u32 Seg_S, u32 Seg_I);

/*!
 * \brief		Modular Exponentiation: [Seg_Res] <= [Seg_Base] ^ [Seg_Exp] mod [Seg_Mod]
 * \param		Seg_Base	[in] Segment ID for Base Number
 * \param		Seg_Exp		[in] Segment ID for Exponent Number
 * \param		Seg_Mod		[in] Segment ID for Modulus Number
 * \param		Seg_Res		[in] Segment ID for saving Result of Exponent
 * \param		Seg_Int		[in] Segment ID for Intermediate Values
 * \param		u32ECC_wlen	[in] Word Length of Base Prime Number
 * \return		N/A

 */
/*void Modular_Exp(u32 Seg_Base, u32 Seg_Exp, u32 Seg_Mod, u32 Seg_Res,
		u32 Seg_Int);*/

/*!
 * \brief		Scalar Multiplication
 * \param		u32ECC_wlen	[in] Word Length of Base Prime Number
 * \return		N/A

 */
/*void Scalar_Mul(u32 u32ECC_wlen);*/

/*!
 * \brief		Two-Term Scalar Multiplication
 * \param		u32ECC_wlen	[in] Word Length of Base Prime Number
 * \return		N/A

 */
/*void TwoTerm_Scalar_Mul(u32 u32ECC_wlen);*/

/*************** END OF FILE **********************************************/
#endif /* SSS_LIB_PKE_A_H_ */

/** \} */
