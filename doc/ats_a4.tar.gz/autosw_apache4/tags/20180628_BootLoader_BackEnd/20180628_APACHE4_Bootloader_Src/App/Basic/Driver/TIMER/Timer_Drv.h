/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


#ifndef __TIMER_DRV_H__
#define __TIMER_DRV_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
 * REGISTER STRUCTURE
 */
 
#define rTIMER_CSR                  (0x000)
#define rTIMER_LOAD                 (0x004)
#define rTIMER_PRESCALER            (0x008)
#define rTIMER_OVER                 (0x00C)
#define rTIMER_UNDER                (0x010)
#define rTIMER_CVAL                 (0x014)










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


typedef enum
{
    TC_CH0 = 0,
    TC_CH1,
    TC_CH2,
    TC_CH3,
    
    MAX_OF_TIMER_CH
} eTIMER_CH;


typedef enum _TIMER_MODE
{
    TC_MODE_PERIOD = 0,
    TC_MODE_PWM,                        // Not Used	            
    TC_MODE_ONESHOT,
    TC_MODE_CAPTURE,                    // Not Used	
    TC_MODE_WDT,
    TC_MODE_MAX
} TIMER_MODE;











/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT8  mMode;               // enum _TIMER_MODE
    UINT8  mClockSource;        // Not Used.
    UINT8  mPrescaler;          // 0~0xFFFF
    UINT8  mTrigMode;           // Not Used.
    UINT32 mPeriod1;            // 1'st period (usec)
    UINT32 mPeriod2;            // Not Used.
} tTIMER_PARAM, *ptTIMER_PARAM;











/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncDrv_TIMER_GetIntSts(eTIMER_CH Ch);
extern void  ncDrv_TIMER_ReLoad(eTIMER_CH Ch);
extern void  ncDrv_TIMER_Start(eTIMER_CH Ch);
extern void  ncDrv_TIMER_Stop(eTIMER_CH Ch);
extern INT32 ncDrv_TIMER_Init(eTIMER_CH Ch, ptTIMER_PARAM ptTIMER, UINT32 RefClk);


#endif  /* __TIMER_DRV_H__ */


/* End Of File */

