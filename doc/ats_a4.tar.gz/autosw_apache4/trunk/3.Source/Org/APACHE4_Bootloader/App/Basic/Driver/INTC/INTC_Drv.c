/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : INTC_Drv.c
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#if BL_INTC_ENABLE


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define IRQ_NUM_RESERVED        0x3FF


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

typedef struct
{
    UINT32 mIntNum;
    UINT8  mTrigType;
    UINT8  mPriority;
    UINT8  mCpuTarget;
    UINT8  mIntType;
} stIntrList;


stIntrList gcIntrList[]=
{
    // Int Number,           Trigger Type,       Priority,   CPU Target,         Interrupt Type
    // 32 (gic_irq_type0[0])
    {IRQ_NUM_TIMER0,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_TIMER1,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_TIMER2,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_TIMER3,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_TIMER4,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ},
    {IRQ_NUM_TIMER5,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ},
    {IRQ_NUM_TIMER6,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ},
    {IRQ_NUM_TIMER7,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ},

    // 40 (gic_irq_type0[8])
    {IRQ_NUM_UART0,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_UART1,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_UART2,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_UART3,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_I2C0,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_I2C1,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_SPI0,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_SPI1,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},

    // 48 (gic_irq_type0[16])
    {IRQ_NUM_QSPI,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_DMA_CHANNEL0,   GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_DMA_CHANNEL1,   GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_DMA_CHANNEL2,   GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_DMA_CHANNEL3,   GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_PWM0,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_PWM1,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_PWM3,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},

    // 56 (gic_irq_type0[24])
    {IRQ_NUM_PWM4,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_GPIO0,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_GPIO1,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_GPIO2,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_FMC,            GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_SDC,            GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_MCAN0,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_MCAN1,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},

    // 64 (gic_irq_type1[0])
    {IRQ_NUM_ISP0,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_ISP1,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_ISP2,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_ISP3,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_ISP4,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_ISP5,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_ISP6,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_ISP7,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},

    // 72 (gic_irq_type1[8])
    {IRQ_NUM_ISP8,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_ISP9,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_VDUMP,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_DTRNG,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_AES,            GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_PKA0,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_PKA1,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_PKA2,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},

    // 80 (gic_irq_type1[16])
    {IRQ_NUM_ADAS0,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ},
    {IRQ_NUM_ADAS1,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ},
    {IRQ_NUM_ADAS2,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ},
    {IRQ_NUM_ADAS3,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ},
    {IRQ_NUM_ADAS4,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ},
    {IRQ_NUM_RESERVED,       GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_RESERVED,       GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_FAULT_SCU,      GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},

    // 88 (gic_irq_type1[24])
    {IRQ_NUM_FAULT_APRB,     GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_FAULT_CPRB,     GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_FAULT_LFT,      GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_FAULT_MFT,      GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_FAULT_PLATFORM, GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_FAULT_ISP,      GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_FAULT_RE,       GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_FAULT,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ},

    // 96 (gic_irq_type2[0])
    {IRQ_NUM_IPC0,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_IPC1,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ},
    {IRQ_NUM_IPC2,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF3),   INTR_IRQ},
    {IRQ_NUM_DSP_L,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF3),   INTR_IRQ},
    {IRQ_NUM_DSP_M,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF3),   INTR_IRQ},
    {IRQ_NUM_RESERVED,       GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_ISP_L,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_ISP_M,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},

    // 104 (gic_irq_type2[8])
    {IRQ_NUM_MCU_L,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_MCU_M,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ},
    {IRQ_NUM_RE_L,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ},
    {IRQ_NUM_RE_M,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ},
    {0,                      0,                  0,          (0),                0       }, // (END)
};


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

typedef struct _INTC_PARAM
{
    UINT32      mIntNum;
    PrHandler   mHandler1;
} tINTC_PARAM, *ptINTC_PARAM;


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

tINTC_PARAM gtIntInfo[IRQS_TOTAL];


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

UINT8 ncDrv_INTC_GetCpuTarget(UINT32 IntNum)
{
    UINT8 nCpuTarget;

    nCpuTarget = gcIntrList[IntNum-IRQS_START].mCpuTarget;

    return nCpuTarget;
}


void ncDrv_INTC_RegisterHandler(UINT32 nIntNum, PrHandler pHandler)
{
    gtIntInfo[nIntNum].mIntNum   = nIntNum;
    gtIntInfo[nIntNum].mHandler1 = pHandler;
}


void ncDrv_INTC_UnRegisterHandler(UINT32 nIntNum)
{
    gtIntInfo[nIntNum].mIntNum   = 0;
    gtIntInfo[nIntNum].mHandler1 = 0;
}


void ncDrv_INTC_InitIntHandler(void)
{
    UINT32 i;

    /* Initialize interrupt pointer function */

    for(i = 0; i < IRQS_TOTAL; i++)
    {
        gtIntInfo[i].mIntNum   = 0;
        gtIntInfo[i].mHandler1 = 0;
    }
}


void ncDrv_INTC_UserHandler(UINT32 nIntNum)
{
    /* Execute interrupt handler */

    if(gtIntInfo[nIntNum].mHandler1)
    {
        gtIntInfo[nIntNum].mHandler1(nIntNum);
    }
}


void ncDrv_INTC_HaltHandler(void)
{
    DEBUGMSG(MSGERR, "Halt_Handler ignore\n");
}


void ncDrv_INTC_IrqHandler(void)
{
    UINT32 nIntNum;
    UINT8 nCpuTarget;

    //SPIN_LOCK(SPINLOCK_INTC);

    //DEBUGMSG_SDK(MSGINFO, "I");

    //REGRW32(APACHE_SYSCON_BASE, 0x0150) = (gCPU_ID | 0x80000000);

    /* read group 1 Acknowledge ID */
    nIntNum = ncDrv_GIC_CPUI_GetAliasedIntAcknowledge();

    ncDrv_GIC_DisableIrq(nIntNum);

    if(nIntNum < MAX_IRQ_NUM)
    {
        /* Interrupt Service routine */
        ncDrv_INTC_UserHandler(nIntNum);

        ncDrv_GIC_ClearPendingIrq(nIntNum);

        nCpuTarget = ncDrv_INTC_GetCpuTarget(nIntNum);
        ncDrv_GIC_SetGrp1EndOfIntID(nCpuTarget, nIntNum);
    }
    else
    {
        DEBUGMSG(MSGERR, "IRQ_Handler ignore %d\n", nIntNum);

        //ncDrv_GIC_ClearPendingIrq(nIntNum);
        //ncDrv_GIC_SetGrp1EndOfIntID(CPU_TARGET_IF0, nIntNum);
    }

    ncDrv_GIC_EnableIrq(nIntNum);

    //SPIN_UNLOCK(SPINLOCK_INTC);
}


void ncDrv_INTC_FiqHandler(void)
{
    UINT32 nIntNum;
    UINT8 nCpuTarget;

    //SPIN_LOCK(SPINLOCK_INTC);

    //DEBUGMSG_SDK(MSGINFO, "F");

    //REGRW32(APACHE_SYSCON_BASE, 0x0150) = (gCPU_ID | 0x80000000);

    /* read group 0 Acknowledge ID */
    nIntNum = ncDrv_GIC_CPUI_GetIntAcknowledge();

    ncDrv_GIC_DisableIrq(nIntNum);

    if(nIntNum < MAX_IRQ_NUM)
    {
        /* Interrupt Service routine */
        ncDrv_INTC_UserHandler(nIntNum);

        ncDrv_GIC_ClearPendingIrq(nIntNum);

        nCpuTarget = ncDrv_INTC_GetCpuTarget(nIntNum);
        ncDrv_GIC_SetGrp0EndOfIntID(nCpuTarget, nIntNum);
    }
    else
    {
        DEBUGMSG(MSGERR, "FIQ_Handler ignore\n");

        //ncDrv_GIC_ClearPendingIrq(nIntNum);
        //ncDrv_GIC_SetGrp0EndOfIntID(CPU_TARGET_IF0, nIntNum);
    }

    ncDrv_GIC_EnableIrq(nIntNum);

    //SPIN_UNLOCK(SPINLOCK_INTC);
}


INT32 ncDrv_INTC_Initialize(void)
{
    INT32 i;
    UINT8 nIntNum, nTrigType, nCpuTarget, nIntType; // nPriority

    //SPIN_LOCK(SPINLOCK_INTC);

    //gCPU_ID = nCpuId & 0x7;
    //REGRW32(APACHE_SYSCON_BASE, 0x0150) = (gCPU_ID | 0x80000000);   // enable

    ncDrv_GIC_DistIf_Disable();
    ncDrv_GIC_CpuIf_Disable();

    ncDrv_GIC_AllDisableIrqs();

    for(i = 0; i < IRQS_TOTAL; i++)
    {
        nIntNum = gcIntrList[i].mIntNum;

        if(nIntNum == 0) break;

        if(nIntNum != IRQ_NUM_RESERVED)
        {
            nCpuTarget = gcIntrList[i].mCpuTarget;
            nTrigType  = gcIntrList[i].mTrigType;
            nIntType   = gcIntrList[i].mIntType;
            //nPriority  = gcIntrList[i].mPriority;

            ncDrv_GIC_DisableIrq(nIntNum);
            //ncDrv_GIC_ClearPendingIrq(nIntNum);

            ncDrv_GIC_SetIrqCPUTarget(nIntNum, nCpuTarget);
            ncDrv_GIC_SetIntTrigType(nIntNum, nTrigType);
            ncDrv_GIC_SetIntTypeGroup(nIntNum, nIntType);

            if(nIntType == INTR_FIQ)
            {
                ncDrv_GIC_SetPriorityLevel(nIntNum, INTC_PRIO_HIGH);
            }
            else // INTR_IRQ
            {
                ncDrv_GIC_SetPriorityLevel(nIntNum, INTC_PRIO_MIDDLE);
            }
        }
    }

    ncDrv_GIC_DistIf_Enable();
    ncDrv_GIC_CpuIf_Enable();

    ncDrv_GIC_CPUI_SetIntPriorityMask(GPM_LEVEL_256 & 0xFF);

    ncDrv_GIC_AllClearPendingIrqs();

    __CORE_INT_EN();

    //SPIN_UNLOCK(SPINLOCK_INTC);

    return NC_SUCCESS;
}


INT32 ncDrv_INTC_Deinitialize(void)
{
    ncDrv_GIC_DistIf_Disable();
    ncDrv_GIC_CpuIf_Disable();

    __CORE_INT_DIS();

    return NC_SUCCESS;
}


#else

void ncDrv_INTC_IrqHandler(void)
{
}


void ncDrv_INTC_FiqHandler(void)
{
}

#endif  /* BL_INTC_ENABLE */


/* End Of File */
