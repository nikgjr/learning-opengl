/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncDrv_SCU_GetPad(UINT32 Offset, UINT32 Pos)
{
    return (REGRW32(rICU_BASE, Offset)>>Pos)&0xf;
}


void ncDrv_SCU_SetPad(UINT32 Func, UINT32 Offset, UINT32 Pos)
{
    UINT32 Reg;

    Reg = REGRW32(rICU_BASE, Offset);
    Reg &= ~(0x7<<Pos);         // Clear
    Reg |= ((Func&0x7)<<Pos);   // Set
    REGRW32(rICU_BASE, Offset) = Reg;

    //DEBUGMSG_SDK(MSGINFO, "[SCU_Drv] PIM MUX Set (%d, 0x%02x, %d)\n", Func, Offset, Pos);
}


void ncDrv_SCU_GenClk(void)
{
    //------------------------------------
    // Do not delete it...
    //SYS_TICK_CLK = tSCUClk.mAPB;
    //------------------------------------

    
}


INT32 ncDrv_SCU_GetPinMux(UINT32 Pad)
{
    INT32 ret = NC_SUCCESS;

    UINT32 Offset = 0;
    UINT32 Pos    = 0;
    
    if(Pad < PAD_MAX)
    {
        if(Pad != PAD_NTRST)
        {
            Offset = (Pad / 8)*4;
            Pos    = (Pad % 8)*4;
        }
        
        ret = ncDrv_SCU_GetPad(Offset, Pos);
    }
    else
    {
        //DEBUGMSG(MSGERR, "[SCU_Drv] PIM MUX Set Error (%d)\n", Pad);
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncDrv_SCU_SetPinMux(UINT32 Pad, UINT32 Func)
{
    INT32  ret = NC_SUCCESS;
 
    UINT32 Offset = 0;
    UINT32 Pos    = 0;

    if(Pad < PAD_MAX)
    {
        if(Pad != PAD_NTRST)
        {
            Offset = (Pad / 8)*4;
            Pos    = (Pad % 8)*4;
        }
        
        ncDrv_SCU_SetPad(Func, Offset, Pos);
    }
    else
    {
        //DEBUGMSG(MSGERR, "[SCU_Drv] PIM MUX Set Error (%d)\n", Pad);
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncDrv_SCU_GetSystemClock(UINT32 nClkNum)
{
    INT32 Clock = NC_FAILURE;

    switch(nClkNum)
    {
        case SCU_CLK_ID_CPU:
            Clock = tSCUClk.mCPU;
            break;

        case SCU_CLK_ID_AXI:
        case SCU_CLK_ID_DMA:
            Clock = tSCUClk.mAXI;
            break;

        case SCU_CLK_ID_APB:
        case SCU_CLK_ID_SSPI:
        case SCU_CLK_ID_UART:
        case SCU_CLK_ID_TIMER:
        case SCU_CLK_ID_I2C:
        case SCU_CLK_ID_PWM:
            Clock = tSCUClk.mAPB;
            break;

        case SCU_CLK_ID_QSPI:
            Clock = tSCUClk.mQSPI;
            break;
            
        case SCU_CLK_ID_CAN:
            break;

        case SCU_CLK_ID_DDR:
            Clock = tSCUClk.mDDR;
            break;

        case SCU_CLK_ID_ADC: 
            break;

        case SCU_CLK_ID_TS:
            break;
            
        default:
            break;
    }

    return Clock;
}




/* End Of File */

