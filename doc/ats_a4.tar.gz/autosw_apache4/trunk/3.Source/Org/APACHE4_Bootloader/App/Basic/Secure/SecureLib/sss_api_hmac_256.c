/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_HMAC2_256	SSS_HMAC_256
 * @ingroup SSS_API
 * @brief					HMAC SHA2_256 Library
 * @{
 */


/**
 * @file		sss_api_hmac_256.c
 * @brief		Source for HMAC SHA2 API
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ************************************************/
#include "sss_lib_util.h"

#include "sss_api_hmac_256.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ****************************************************/

/*************** Prototypes ***************************************************/
SSS_RV sss_HMAC_SHA2_256(const stOCTET_STRING *pstHMACKey, const stOCTET_STRING *pstMessage, stOCTET_STRING *pstDigest)
{
	u32 ret = SSSR_FAIL;
	stSHA_PARAMS zstHASH_Param;

	/*! > Step 0. check zero message */
	if(pstMessage->u32DataByteLen == 0x0)
	{
		ret = ERROR_HMAC_SHA2_INVALID_LEN_MSG;
	}
	else
	{
		/*! > Step 0. Get Hash param data */
		get_HashInfo(OID_SHA2_256, &zstHASH_Param);
		/* assign message to param */
		zstHASH_Param.pstMSG = (stOCTET_STRING*) pstMessage;
		/* assign key to param */
		zstHASH_Param.pstMACKey = (stOCTET_STRING*) pstHMACKey;

		/*! > Step 1. HMAC init */
		ret = HMACSHA_init(&zstHASH_Param, HMAC_FLAG);
		if (SSSR_SUCCESS == ret)
		{
			/*! > Step 2. HMAC update during msg > block */
			HMACSHA_update(&zstHASH_Param);

			/*! > Step 3. HMAC final */
			HMACSHA_final(&zstHASH_Param, pstDigest);
		}
	}

	return ret;
}

/*************** END OF FILE **************************************************/

/** @} */
