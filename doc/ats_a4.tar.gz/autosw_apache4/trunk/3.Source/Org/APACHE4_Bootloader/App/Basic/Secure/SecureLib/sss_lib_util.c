/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_COMMON		SSS_COMMON
 * @ingroup SSS_Solution
 * @brief					Common Source (C & Head) File of SSS_Solution
 * @{
 */

/**
 * @file		sss_lib_util.c
 * @brief		Source file for Utility Functions
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ************************************************/
#include "sss_lib_util.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** New Data Types ***********************************************/

/*************** Constants ****************************************************/

/*************** Function Prototypes ******************************************/

/*************** Function *****************************************************/

/*************** Function *****************************************************/

SSS_RV sss_memcmp_u08(const u08* pu08Src1, const u08* pu08Src2,
		u32 u32_byte_size)
{
	u32 i = 0;
	u32 ret = SSSR_FAIL;
	volatile u32 sum = 0;

	for (i = 0; i < u32_byte_size; i++)
	{
		sum += (pu08Src1[i] != pu08Src2[i]);
	}

	if ((0 == sum) && (u32_byte_size == i))
	{
		ret = SSSR_SUCCESS;
	}

	return ret;
}

SSS_RV sss_memcmp_u32(const u32* pu32Src1, const u32* pu32Src2,
		const u32 u32Size)
{
	u32 i = 0;
	u32 ret = SSSR_FAIL;
	volatile u32 sum = 0;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Check the mis-aligned address
	 */
	if ((((u32) pu32Src1) & 3) || (((u32) pu32Src2) & 3))
	{
		ret = sss_memcmp_u08((u08*) pu32Src1, (u08*) pu32Src2, 4 * u32Size);
	}
	else
	{
		/*!
		 * Step 2 : Compare src1 and src2
		 */
		for (i = 0; i < u32Size; i++)
		{
			sum += (pu32Src1[i] != pu32Src2[i]);
		}

		if ((sum == 0) && (i == u32Size))
		{
			ret = SSSR_SUCCESS;
		}
	}

	return ret;
}

void sss_memset_u08(u08* pu08Dst, const u08 u08Val, const u08 u08ByteLen)
{
	u08 u08Size = u08ByteLen;
	u08 *pu08Dest = pu08Dst;

	while (u08Size--)
	{
		*pu08Dest++ = u08Val;
	}
}

void sss_memset_u32(u32* pu32Dst, const u32 u32Val, const u32 u32Size)
{
	u32 i = 0;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Check the mis-aligned address
	 */
	if (((u32) pu32Dst) & 3)
	{
		sss_memset_u08((u08*) pu32Dst, (u08) u32Val, 4 * u32Size);
	}
	else
	{
		/*!
		 * Step 2 : Compare src1 and src2
		 */
		for (i = 0; i < u32Size; i++)
		{
			pu32Dst[i] = u32Val;
		}
	}
}

void sss_memclr_u08(u08* pu08Dst, const u32 u32Size)
{
	u32 i = 0;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Clear data
	 */
	for (i = 0; i < u32Size; i++)
	{
		pu08Dst[i] = 0;
	}
}

void sss_memclr_u32(u32* pu32Dst, const u32 u32Size)
{
	u32 i = 0;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Check the mis-aligned address
	 */
	if (((u32) pu32Dst) & 3)
	{
		sss_memclr_u08((u08*) pu32Dst, 4 * u32Size);
	}
	else
	{
		/*!
		 * Step 2 : Clear data
		 */
		for (i = 0; i < u32Size; i++)
		{
			pu32Dst[i] = 0;
		}
	}
}

void sss_memcpy_u08(u08* pu08Dst, const u08* pu08Src, const u32 u32Size)
{
	u32 i = 0;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Copy data from src to dst
	 */
	for (i = 0; i < u32Size; i++)
	{
		pu08Dst[i] = pu08Src[i];
	}
}

void sss_memcpy_u32(u32* pu32Dst, const u32* pu32Src, const u32 u32Size)
{
	u32 i = 0;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Check the mis-aligned address
	 */
	if ((((u32) pu32Src) & 3) || (((u32) pu32Dst) & 3))
	{
		sss_memcpy_u08((u08*) pu32Dst, (const u08*) pu32Src, 4 * u32Size);
	}
	else
	{
		/*!
		 * Step 2 : Copy data from src to dst
		 */
		for (i = 0; i < u32Size; i++)
		{
			pu32Dst[i] = pu32Src[i];
		}
	}
}

void sss_memxor_u32(u32* pu32Dst, u32* pu32Src1, u32* pu32Src2, u32 u32Wlen)
{
	u32 i = 0;

	for (i = 0; i < u32Wlen; i++)
	{
		pu32Dst[i] = pu32Src1[i] ^ pu32Src2[i];
	}
}

void sss_OS_to_SFR(u32 *pu32SFRAddr, const stOCTET_STRING *pstSrc)
{
	volatile u32 u32Tmp = 0;
	u08 *pu08Src = pstSrc->pu08Data;
	u32 *pu32Dst = pu32SFRAddr;
	s32 Index = (s32) pstSrc->u32DataByteLen;

	/*!
	 * > Sequence
	 */
	/*!
	 * Step 1 : Check Source address is aligned
	 */
	if (((u32) pu08Src & 0x3) == 0x0)
	{
		while (Index >= 4)
		{
			u32Tmp = *((u32*) pu08Src);
			*(pu32Dst++) = u32Tmp;

			pu08Src += 4;
			Index -= 4;
		}
	}
	else
	{
		while (Index >= 4)
		{
			u32Tmp = (((u32) *(pu08Src + 3) << 24)
					| ((u32) *(pu08Src + 2) << 16) | ((u32) *(pu08Src + 1) << 8)
					| (u32) *(pu08Src));
			*(pu32Dst++) = u32Tmp;

			pu08Src += 4;
			Index -= 4;
		}
	}

	/* remainder */
	if (Index != 0)
	{
		/* set default is zero */
		u32Tmp = 0;
		/* define update value */
		if (Index >= 3)
		{
			u32Tmp |= ((u32) *(pu08Src + 2) << 16);
		}
		if (Index >= 2)
		{
			u32Tmp |= ((u32) *(pu08Src + 1) << 8);
		}
		if (Index >= 1)
		{
			u32Tmp |= ((u32) *(pu08Src));
		}
		/* update to destination */
		*(pu32Dst++) = u32Tmp;
	}
}

void sss_SFR_to_OS(stOCTET_STRING *pstDst, u32 *pu32SFRAddr)
{
	volatile u32 u32Tmp;
	u08 *pu08Dst = pstDst->pu08Data;
	u32 *pu32Src = pu32SFRAddr;
	s32 Index = (s32) pstDst->u32DataByteLen;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Check Source address is aligned
	 */
	if (((u32) pu08Dst & 0x3) == 0x0)
	{
		while (Index >= 4)
		{
			u32Tmp = *(pu32Src++);
			*((u32*) pu08Dst) = u32Tmp;

			pu08Dst += 4;
			Index -= 4;
		}
	}
	else
	{
		/* load 32bit data */
		u32Tmp = *(pu32Src++);
		if (Index >= 4)
		{
			*(pu08Dst) = (u08) (u32Tmp);
			*(pu08Dst + 1) = (u08) (u32Tmp >> 8);
			*(pu08Dst + 2) = (u08) (u32Tmp >> 16);
			*(pu08Dst + 3) = (u08) (u32Tmp >> 24);
			pu08Dst += 4;
		}

		Index -= 4;
	}

	/*!
	 * Step 2 : Reminder
	 */
	if(Index != 0)
	{
		/* load 32bit data */
		u32Tmp = *(pu32Src++);
		/* define update value */
		if (Index >= 3)
		{
			*(pu08Dst + 2) = (u08) (u32Tmp >> 16);
		}
		if (Index >= 2)
		{
			*(pu08Dst + 1) = (u08) (u32Tmp >> 8);
		}
		if (Index >= 1)
		{
			*(pu08Dst) = (u08) (u32Tmp);
		}
	}
}

void sss_SFR_to_OS_reversing(stOCTET_STRING *pstDst, u32 *pu32SFR_MSW_Addr)
{
	u32 u32Tmp;
	u08 *pu08Dst = pstDst->pu08Data;
	u32 u32Index = pstDst->u32DataByteLen;
	u32 *pu32SrcTemp = pu32SFR_MSW_Addr;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Convert first multiple of 4 Bytes
	 */
	while (u32Index >= 4)
	{
		u32Tmp = *pu32SrcTemp--;
		*(pu08Dst + 0) = (u08) (u32Tmp >> 24);
		*(pu08Dst + 1) = (u08) (u32Tmp >> 16);
		*(pu08Dst + 2) = (u08) (u32Tmp >> 8);
		*(pu08Dst + 3) = (u08) (u32Tmp);

		pu08Dst += 4;
		u32Index -= 4;
	}

	/*!
	 * Step 2 : Convert last remainder Bytes
	 */
	if(u32Index != 0)
	{
		u32Tmp = *pu32SrcTemp;
		if (u32Index >= 3)
		{
			*(pu08Dst + 2) = (u08) (u32Tmp >> 8);
		}
		if (u32Index >= 2)
		{
			*(pu08Dst + 1) = (u08) (u32Tmp >> 16);
		}
		if (u32Index >= 1)
		{
			*(pu08Dst + 0) = (u08) (u32Tmp >> 24);
		}
	}
}

void sss_OS_to_BN(u32 *pu32Dst, const stOCTET_STRING *pstSrc)
{
	u32 i, u32Tmp = 0;
	u08 *pu08Src = pstSrc->pu08Data;
	u32 u32BLen = pstSrc->u32DataByteLen;
	u32 *pu32Dstptr = pu32Dst;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Check Source address is aligned
	 */
	for (i = u32BLen; i >= 4; i -= 4)
	{
		u32Tmp = (((u32) pu08Src[i - 4]) << 24) | (((u32) pu08Src[i - 3]) << 16)
				| (((u32) pu08Src[i - 2]) << 8) | ((u32) pu08Src[i - 1]);
		*pu32Dstptr++ = u32Tmp;
	}

	/*!
	 * Step 2 : Convert last remainder Bytes
	 */
	if(i != 0)
	{
		u32Tmp = 0;
		if (i >= 3)
		{
			u32Tmp |= (((u32) pu08Src[i - 3]) << 16);
		}
		if (i >= 2)
		{
			u32Tmp |= (((u32) pu08Src[i - 2]) << 8);
		}
		if (i >= 1)
		{
			u32Tmp |= ((u32) pu08Src[i - 1]);
		}
		/* update to destination */
		*pu32Dstptr = u32Tmp;
	}
}

void sss_BN_to_OS(stOCTET_STRING *pstDst, u32 *pu32Src)
{

	u32 i, u32Tmp;
	u08 *pu08Dst = pstDst->pu08Data;
	u32 *pu32Srcptr = pu32Src;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Convert first multiple of 4 Bytes
	 */
	for (i = pstDst->u32DataByteLen; i >= 4; i -= 4)
	{
		u32Tmp = *pu32Srcptr++;
		pu08Dst[i - 4] = (u08) (u32Tmp >> 24);
		pu08Dst[i - 3] = (u08) (u32Tmp >> 16);
		pu08Dst[i - 2] = (u08) (u32Tmp >> 8);
		pu08Dst[i - 1] = (u08) (u32Tmp);
	}

	/*!
	 * Step 2 : Convert last remainder Bytes
	 */
	if(i != 0)
	{
		u32Tmp = *pu32Srcptr++;
		if (i >= 3)
		{
			pu08Dst[i - 3] = (u08) (u32Tmp >> 16);
		}
		if (i >= 2)
		{
			pu08Dst[i - 2] = (u08) (u32Tmp >> 8);
		}
		if (i >= 1)
		{
			pu08Dst[i - 1] = (u08) (u32Tmp);
		}
	}
}
/*************** END OF FILE **************************************************/

/** @} */
