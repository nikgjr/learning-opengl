/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_AES_CTR	SSS_AES_CTR
 * @ingroup SSS_API
 * @brief					AES_CTR Library
 * @{
 */

/**
 * @file		sss_api_aes_ctr.h
 * @brief		Header for AES CTR API
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

#ifndef SSS_API_AES_CTR_H_
#define SSS_API_AES_CTR_H_

/*************** Include Files ************************************************/
#include "sss_lib_aes_s1.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ************************************************/

/*************** Variable declarations ************************************/

/*************** Error Message ********************************************/

/*************** Prototypes ***************************************************/

/**
 * @brief		AES CTR encryption
 * @param[in]	pstAES_Params		pointer of struct for IV Parameter

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |stIV					|structure of IV				|							|
 | - pu08Data			|pointer of octet string		|							|
 | - u32DataByteLen		|byte length of octet string	|16							|
 |u32CntByteLen			|byte length of Counter			|{2, 4, 8, 16}				|


 * @param[in]	pstAES_Key			pointer of struct for AES Key

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |u32KeyType			|Key type						|N/A						|
 |stKey					|structure of AES Key			|							|
 | - pu08Data			|pointer of octet string		|							|
 | - u32DataByteLen		|byte length of octet string	|{16, 24, 32}				|

 * @param[in]	pstAES_Plaintext	pointer of struct for AES plaintext

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |pu08Data				|pointer of octet string		|							|
 |u32DataByteLen		|byte length of octet string	|0< x < variable byte length|

 * @param[out]	pstAES_Ciphertext	pointer of struct for AES ciphertext

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |pu08Data				|pointer of octet string		|							|
 |u32DataByteLen		|byte length of octet string	|0< x < variable byte length|

 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV sss_AES_Enc_CTR(stAES_PARAMS *pstAES_Params, const stAES_KEY *pstAES_Key,
		const stOCTET_STRING *pstAES_Plaintext,
		stOCTET_STRING *pstAES_Ciphertext);

/**
 * @brief		AES CTR decryption
 * @param[in]	pstAES_Params		pointer of struct for IV Parameter

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |stIV					|structure of IV				|							|
 | - pu08Data			|pointer of octet string		|							|
 | - u32DataByteLen		|byte length of octet string	|16							|
 |u32CntByteLen			|byte length of Counter			|{2, 4, 8, 16}				|


 * @param[in]	pstAES_Key			pointer of struct for AES Key

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |u32KeyType			|Key type						|N/A						|
 |stKey					|structure of AES Key			|							|
 | - pu08Data			|pointer of octet string		|							|
 | - u32DataByteLen		|byte length of octet string	|{16, 24, 32}				|

 * @param[in]	pstAES_Ciphertext	pointer of struct for AES ciphertext

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |pu08Data				|pointer of octet string		|							|
 |u32DataByteLen		|byte length of octet string	|0< x < variable byte length|

 * @param[out]	pstAES_Plaintext	pointer of struct for AES plaintext

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |pu08Data				|pointer of octet string		|							|
 |u32DataByteLen		|byte length of octet string	|0< x < variable byte length|


 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV sss_AES_Dec_CTR(stAES_PARAMS *pstAES_Params, const stAES_KEY *pstAES_Key,
		const stOCTET_STRING *pstAES_Ciphertext,
		stOCTET_STRING *pstAES_Plaintext);
/*************** END OF FILE **************************************************/

#endif /* SSS_API_AES_CTR_H_ */

/** @} */
