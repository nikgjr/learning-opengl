/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_ECDSA		SSS_ECDSA
 * @ingroup SSS_Library
 * @brief					ECDSA Library
 * @{
 */

/*!
 * @file		sss_lib_ecdsa.h
 * @brief		Header for ECDSA function
 * @author		kiseok.bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

#ifndef SSS_LIB_ECDSA_H_
#define SSS_LIB_ECDSA_H_

/*************** Include Files ************************************************/
#include "sss_lib_ecc_core.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ****************************************************/

/*************** Variable declarations ****************************************/

/*************** Error Message ************************************************/
#define ERROR_ECDSA_INVALID_LEN_MSG 	(ERR_MSG|INVALID_LEN|ERROR_ECDSA)
#define ERROR_ECDSA_INVALID_LEN_SIGN 	(ERR_SIGN|INVALID_LEN|ERROR_ECDSA)
#define ERROR_ECDSA_INVALID_VAL_SIGN 	(ERR_SIGN|INVALID_VAL|ERROR_ECDSA)

/*************** Prototypes ***************************************************/
/**
 * @brief		set ecdsa key data for verifying
 * @param[in]	pstDomainParam    	pointer of ECC Domain structure
 * @param[in]	pstPubkey			pointer of ECC_KEY structure
 * @return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 Else

 * @author		kiseok.bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV ECDSA_verify_Init(stECC_Param *pstDomainParam, stECC_PUBKEY* pstPubkey);

/**
 * @brief		update ecdsa digest message
 * @param[in]	pstDigest		pointer of digested message
 * @param[in]	u32ECC_wlen		length of ECC data (word)
 * @return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 Else

 * @author		kiseok.bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
void ECDSA_update(stOCTET_STRING* pstDigest, u32 u32ECC_wlen);

/**
 * @brief		run ecdsa verification
 * @param[in]	pstDomainParam    	pointer of ECC Domain structure
 * @param[in]	pstSIGN				pointer of ECDSA_SIGN structure
 * @return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 Else

 * @author		kiseok.bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV ECDSA_verify_final(stECC_Param *pstDomainParam, stECDSA_SIGN* pstSIGN);

/*************** END OF FILE **************************************************/

#endif /* SSS_LIB_ECDSA_H_ */

/** @} */
