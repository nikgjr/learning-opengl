/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#if BL_SPI_ENABLE


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncDrv_SSP_CS_High(UINT32 Ch)
{
    if(Ch == SSP_CH0)
    {
        REGRW32(APACHE_GPIO_BASE, 0x0008) |= (1<<15);   // PAD_SPI2_CSN0 high
    }
    else
    {
        REGRW32(APACHE_GPIO_BASE, 0x0008) |= (1<<16);   // PAD_SPI2_CSN1 high
    }
}


void ncDrv_SSP_CS_Low(UINT32 Ch)
{
    if(Ch == SSP_CH0)
    {
        REGRW32(APACHE_GPIO_BASE, 0x0008) &= ~(1<<15);   // PAD_SPI2_CSN0 low
    }
    else
    {
        REGRW32(APACHE_GPIO_BASE, 0x0008) &= ~(1<<16);   // PAD_SPI2_CSN1 low
    }
}


static BOOL ncDrv_SSP_TimeOut(UINT32 mSec)
{
    BOOL ret = FALSE;       
    static volatile UINT32 sSSP_TimeOutMsec = 0;  

    if(mSec > 0)
    {
        if(sSSP_TimeOutMsec == 0)
        {
            // Set TimeOut : SystemTick(msec) + TargetMsec;
            sSSP_TimeOutMsec = nc_get_msec(1) + mSec;
        }
        else
        {
            // Timeout Check. 
            if( nc_get_msec(0) > sSSP_TimeOutMsec)
            {
                ret = TRUE;
                sSSP_TimeOutMsec = 0;
            }
        }
    }
    else
    {
        sSSP_TimeOutMsec = 0;
    }
    
    return ret;
}


INT32 ncDrv_SSP_WaitBusIsBusy(void)
{
    INT32 Ret = NC_SUCCESS;
    UINT32 TimeOut = SSP_WAIT_TIMEOUT;

    while(REGRW32(APACHE_SPI_0_BASE, rSSP_CR1)&bSSP_CR1_BUSY)
    {
        if(ncDrv_SSP_TimeOut(TimeOut))
        {
            Ret = NC_FAILURE;
            break;
        }
    }
    ncDrv_SSP_TimeOut(0);

    return Ret;
}


void ncDrv_SSP_SetDMAMode(UINT8 rwMode)
{
    UINT32 Reg;

    Reg = REGRW32(APACHE_SPI_0_BASE, rSSP_CR0);
    Reg &= ~(1<<8);
    Reg |= (rwMode<<8);
    REGRW32(APACHE_SPI_0_BASE, rSSP_CR0) = Reg;

}


INT32 ncDrv_SSP_GetIntSts(eSSP_MODE Mode)
{
    INT32 Ret;
    
    if(Mode == SSP_MODE_MASTER)
        Ret = (1<<0);
    else
        Ret = (1<<1);

    return Ret;
}


void ncDrv_SSP_SetBitRate(UINT32 BitRate, UINT32 InClk)
{
    UINT32 Div = 2;
    UINT32 Sampling;

    while(1)
    {
        Sampling = (InClk/Div);
        if(BitRate >= Sampling)
        {
            break;
        }
        else if(BitRate < Sampling)
        {
            Div++;
        }
    }

    // BaudRate = RefClk/Div, 0x02~0xFF
    REGRW32(APACHE_SPI_0_BASE, rSSP_CLK_DIV) = Div - 1;
}


INT32 ncDrv_SSP_mRead(UINT8 *pBuf, UINT32 Length)
{
    INT32  Ret = NC_FAILURE;
    UINT32 i;
    UINT8  DIV = 1;

    // Clear Rx Buffer
    REGRW32(APACHE_SPI_0_BASE, rSSP_RX_CLR) = 1;

    for(i = 0; i < (Length/DIV); i++)
    {  
        // Check Busy
        Ret = ncDrv_SSP_WaitBusIsBusy();


        // Write Dummy data
        REGRW32(APACHE_SPI_0_BASE, rSSP_TX) = 0x00;


        // Wait Transfer Done.
        Ret = ncDrv_SSP_WaitBusIsBusy();


        // Read data
        pBuf[i]   = (UINT8) (REGRW32(APACHE_SPI_0_BASE, rSSP_RX)&0xFF);
    }

    return Ret;
}


INT32 ncDrv_SSP_mWrite(UINT8 *pBuf, UINT32 Length)
{
    INT32  Ret = NC_FAILURE;
    //UINT32 Temp;
    UINT32 i;
    UINT8  DIV = 1;


    for(i=0; i<(Length/DIV); i++)
    {
        // Check Busy
        Ret = ncDrv_SSP_WaitBusIsBusy();


        // Data Write
        REGRW32(APACHE_SPI_0_BASE, rSSP_TX) = pBuf[i];


        // Wait Transfer Done.
        Ret = ncDrv_SSP_WaitBusIsBusy();

        
        // Clear Rx Buffer
        //Temp = REGRW32(APACHE_SPI_0_BASE, rSSP_RX)&0xFFFF;
        REGRW32(APACHE_SPI_0_BASE, rSSP_RX_CLR) = 1;
    }

    return Ret;
}


#endif  /* BL_SPI_ENABLE */


/* End Of File */

