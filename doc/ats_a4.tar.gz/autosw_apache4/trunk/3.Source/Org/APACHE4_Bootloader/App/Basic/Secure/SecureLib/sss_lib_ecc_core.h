/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_ECC		SSS_ECC
 * @ingroup SSS_Library
 * @brief					ECC Core Library
 * @{
 */

/*!
 * @file		sss_lib_ecc_core.h
 * @brief		Header for ECC core function
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

#ifndef SSS_LIB_ECC_CORE_H_
#define SSS_LIB_ECC_CORE_H_

/*************** Include Files ************************************************/
#include "sss_lib_pke_a.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/
/*! @brief	struct of ECC private key */
typedef struct
{
	/*!	if u32KeyType != 0xFFFFFFFF, u32KeyType means KeyHandle.
		otherwise, private key is inserted directly.
	*/
	u32				u32KeyType;
	/*! id of elliptic curve  */
	u32				u32EllipticCurveID;
	/*! struct of stBIG_NUM to represent of Big Number D  */
	stOCTET_STRING	stBigNum_D;
} stECC_PRIVKEY;

/*! @brief	struct of ECC public key */
typedef struct
{
	/*!	if u32KeyType != 0xFFFFFFFF, u32KeyType means KeyHandle.
		otherwise, private key is inserted directly.
	 */
	u32				u32KeyType;
	/*! id of elliptic curve */
	u32				u32EllipticCurveID;
	/*! struct of stBIG_NUM to represent of Big Number Qx */
	stOCTET_STRING	stBigNum_Qx;
	/*! struct of stBIG_NUM to represent of Big Number Qy */
	stOCTET_STRING	stBigNum_Qy;
} stECC_PUBKEY;


/**
 * @brief	struct of ECC Param
 */
typedef struct
{
	/** < Curve Domain */
	const u32 u32CurveID;
	/** < Generator x 	(in M-domain) */
	const u32* pu32Gx;
	/** < Generator y 	(in M-domain) */
	const u32* pu32Gy;
	/** < Prime P			(in I-domain) */
	const u32* pu32PrimeP;
	/** < Order N			(in I-domain) */
	const u32* pu32OrderN;
	/** < Coefficient A 	(in M-domain) */
	const u32* pu32CoeA;
	/** < Coefficient B 	(in M-domain) */
	const u32* pu32CoeB;
	/** < R2 mod p 		(in M-domain) */
	const u32* pu32R2modP;
	/** < R2 mod n 		(in M-domain) */
	const u32* pu32R2modN;

	/** < Parameter data word length */
	const u32 u32Data_wlen;
	/** < Curve key size */
	const u32 u32ECC_bitsize;

	/** < Twister Coefficient Z (in M-domain) */
	const u32* pu32CoefZ;
} stECC_Param;

/**
 * @brief	struct of ECDSA Sign
 */
typedef struct
{
	/** < object id */
	u32 u32ECDSA_OID;
	/** < ECDSA-r */
	stOCTET_STRING stSign_r;
	/** < ECDSA-s */
	stOCTET_STRING stSign_s;
} stECDSA_SIGN;

/*************** Constants ****************************************************/

/*************** Variable declarations ****************************************/

/*************** Error Message ************************************************/
#define ERROR_ECC_INVALID_LEN_KEY (ERR_KEY|INVALID_LEN|ERROR_ECC)

/*************** Prototypes ***************************************************/
/**
 * @brief		set ecc param data
 * @param[in]	pstDomainParam    	ECC object = select EC parameter(160, 192, 224, 256, 384, 521)
 * @return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 ERROR_IP_BUSY
 ERROR_INVALID_OID_SIZE

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
void ECC_PARAM(stECC_Param *pstDomainParam);

/**
 * @brief		set ecdsa key data
 * @param[in]	pstECCkey			pointer of ECC_KEY structure
 * @return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 ERROR_IP_BUSY
 ERROR_INVALID_OID_SIZE

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV ECC_PRVKEY(stECC_PRIVKEY* pstECCkey);

void ECC_PUBKEY(stECC_PUBKEY* pstECCkey);

void get_ECCInfo(u32 u32ECCOID, stECC_Param **pstDomainParams);

SSS_RV chk_INPUT(s32 SEG_ID);

/*************** END OF FILE **************************************************/

#endif /* SSS_LIB_ECC_CORE_H_ */

/** @} */
