/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __QSPI_DRV_H__
#define __QSPI_DRV_H__

/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/











/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

// QSPI Control Register
#define rQSPI_CTRL                      0x0000
    #define bQSPI_EN_POL                (1<<23)         // Read Data Enable Polarity
    #define bQSPI_INT_EN                (1<<22)         // Interrupt Enable
    #define bQSPI_CKPHA                 (1<<21)         // SCK Start PHASE
    #define bQSPI_SCKPOL                (1<<20)         // SCK Polarity
    #define bQSPI_TDIR                  (1<<19)         // Direction select(TX)
    #define bQSPI_MODE                  (1<<18)         // Master/Slave Mode
    #define bQSPI_MANU_EN               (1<<17)         // Maunal Enable
    #define bQSPI_EN                    (1<<16)         // Enable
    #define bQSPI_OEN_CON               (1<<14)         // OEN contorl
    #define bQSPI_RSWAP                 (1<<13)         // Read Data Swap
    #define bQSPI_RDIR                  (1<<12)         // Direcion select(RX)
    #define bQSPI_BRATE                 (8)             // BuadRate
    #define bQSPI_CMD                   (0)             // SPI Command

// QSPI End Address Resiger    
#define rQSPI_EADDR                     0x0004

// QSPI Dummy Address Register
#define rQSPI_DUMMY                     0x0008

// QSPI Start Address Register 
#define rQSPI_SADDR                     0x000C

// QSPI Master Interface Wirte Address Register 
#define rQSPI_MIADDR                    0x0010

// QSPI Master Interface Contorl Register
#define rQSPI_MICTRL                    0x0014
    #define bQSPI_PSWAP                 (8)             // Buffer Data Swap for APB Slave
    #define bQSPI_MIEN                  (1<<7)          // Master Interface Enable
    #define bQSPI_MIQSWIP               (1<<5)          // Master Interface Data Quad Swap
    #define bQSPI_MIHSWIP               (1<<4)          // Master Interface Data Half Swap
    #define bQSPI_MIBUST                (0)             // Master Interface Burst Control

// QSPI Master Interface Status Register
#define rQSPI_STS                       0x0018
    #define bQSPI_MIOVER                (1<<23)         // Master Interface Overflow Read Flag
    #define bQSPI_MIFDONE               (1<<22)         // Master Interface Frame Done ReadFlag
    #define bQSPI_CKERR                 (1<<20)         // Check Sum Error Flag
    #define bQSPI_BUSY                  (1<<16)         // Busy Flag
    #define bQSPI_RxDATA                (0)             // Rx Data

#define rQSPI_INTCLR                    0x001C
#define rQSPI_INTMASK                   0x0020
#define rQSPI_SRBUFF                    0x0024
#define rQSPI_SIGSTS                    0x0028
    #define bQSPI_STS_END               (1<<24)
    #define bQSPI_STS_FULL              (1<<8)
    #define bQSPI_STS_EMPTY             (1<<0)
#define rQSPI_INTSTS                    0x002C
#define rQSPI_OSG_DN                    0x0030
    #define bQSPI_OSG_DIS               (0)
    #define bQSPI_OSG_DIRECT            (1<<0)
    #define bQSPI_OSG_APB               (1<<1)
#define rQSPI_EXT_ADDR                  0x005C











/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern void   ncDrv_QSPI_IsExternalMemory(UINT8 IsExternal);
extern INT32  ncDrv_QSPI_SetBitRate(UINT32 BitRate, UINT32 InClk);
extern INT32  ncDrv_QSPI_ReadData(BOOL DataSwap, UINT32 Addr, UINT32 BuffAddr, UINT32 Size);


#endif  /* __QSPI_DRV_H__ */


/* End Of File */

