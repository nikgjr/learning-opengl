/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/


/**
 * @file		sss_test_release.h
 * @brief		integration test
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ************************************************/
#include "sss_lib_boot.h"
#include "sss_lib_util.h"


/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/
/*
 * to be modifed
 */
#define SIGNEDBL0_SRC_BASE  (0x20010000u)
#define SIGNEDBL0_BYTE_SIZE (0x4f0u)
//#define BL0_DST_BASE        (0x20018000u)
#define BL0_DST_BASE        (0x04000000u)

//#define OTP_VALUE_FOR_CASE1
//#define OTP_VALUE_FOR_CASE2


/*************** Constants ****************************************************/

static const u32 gzu32SBOOT_DECKEY_OTP[8] =
{
    0x136cc226, 0x7c359f6c, 0x4803d0e5, 0x9ad9994e,
    0x1e7f0578, 0x22d1b3bd, 0x90f15e4e, 0xa533b375
};

static const u32 gzu32SBOOT_PUBKEY_DIGEST[8] =
{
    0xa550f18c, 0xc65bc307, 0x072c7ca2, 0x862dbb37,
    0x97fdca7f, 0x47835117, 0xddd0263f, 0x16366143
};

static const u32 gzu32SBOOT_DECKEY_MAC[8] =
{
    0xA0A1A2A3, 0xA4A5A6A7, 0xA8A9AAAB, 0xACADAEAF,
    0xB0B1B2B3, 0xB4B5B6B7, 0xB8B9BABB, 0xBCBDBEBF
};


/*************** Prototypes ***************************************************/
void sss_Swap(u32 *pDst, u32 *pSrc, u32 nSize)
{
    u32 i, temp;

    for(i = 0; i < nSize; i++)
    {
        temp = 0;

        temp |= ((pSrc[i]&0x000000FF)<<24);
        temp |= ((pSrc[i]&0x0000FF00)<<8);
        temp |= ((pSrc[i]&0x00FF0000)>>8);
        temp |= ((pSrc[i]&0xFF000000)>>24);

        pDst[i] = temp;
    }
}

s32 sss_boot_test(void)
{
	s32 ret = SSSR_FAIL;
    u32 *pBuffer_OPT_BASE = (u32 *)SBOOT_OTP_BASE;
    u32 *pBufferDECKEY_OPT = (u32 *)SBOOT_DECKEY_OTP_BASE;
    u32 *pBufferDECKEY_MAC = (u32 *)SBOOT_DECKEY_MAC_BASE;
    u32 *pBufferPUBKEY_DIGEST = (u32 *)SBOOT_PUBKEY_DIGEST_BASE;

    SB_STP_REG = 1;

	/*! > Step 1. Loading Signed Boot Image to SRAM */
	/*
	 *  example)
	 *  memcpy((u08*)BL0_DST_BASE, (u08*)SIGNEDBL0_SRC_BASE, SIGNEDBL0_BYTE_SIZE);
	 */

    sss_Swap(pBufferDECKEY_OPT, (u32 *)&gzu32SBOOT_DECKEY_OTP[0], 8);
    sss_Swap(pBufferPUBKEY_DIGEST, (u32 *)&gzu32SBOOT_PUBKEY_DIGEST[0], 8);
    sss_Swap(pBufferDECKEY_MAC, (u32 *)&gzu32SBOOT_DECKEY_MAC[0], 8);

    pBuffer_OPT_BASE[0] = 0x01; // SBOOT_ENABLE
    pBuffer_OPT_BASE[1] = 0x00; // SBOOT_RBCNT

    SB_STP_REG = 2;

	/*! > Step 2. Start Secure Boot */

	ret = sss_SecureBoot((u08*) BL0_DST_BASE);

	SB_RES_REG = ret;

	if(SSSR_SUCCESS != ret)
	{
		/*
		 * example)
		 * printf("ERROR CODE = %08x\n", ret);
		 */
	}

	return ret;
}

/*************** END OF FILE **************************************************/

