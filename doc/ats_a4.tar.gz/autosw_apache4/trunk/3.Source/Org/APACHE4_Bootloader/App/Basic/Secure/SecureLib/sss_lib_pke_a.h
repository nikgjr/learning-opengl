/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_PKE_A		SSS_PKE_A
 * @ingroup SSS_Driver
 * @brief					PKA Driver & Library
 * @{
 */

/*!
 * @file		sss_lib_pke_a.h
 * @brief		Headerfile for pka library
 * @author		kiseok.bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

#ifndef SSS_LIB_PKE_A_H_
#define SSS_LIB_PKE_A_H_

/*************** Include Files ************************************************/
#include "sss_lib_common.h"

/*************** Assertions ***********************************************/

/*************** Definitions / Macros *************************************/
/*
 * SFR Defintion for crypt_pke_a_v1.20e
 */
#define PKA_SRAM_OFFSET		(0x1000u)
#define PKA_SFR_0			(*(volatile u32 *)((PKA_REG_BASE) + 0x0000u))
	#define SEG_SIZE_036B		(0<<24)		/**< 288b */
	#define SEG_SIZE_068B		(1<<24)		/**< 544b */
#if SSS_UNUSED
	#define SEG_SIZE_132B		(2<<24)		/**< 1056b */
	#define SEG_SIZE_260B		(3<<24)		/**< 2080b */
#endif
	#define PREC_ID(x)			(x<<8)		/**< x = 0..63 (supporting 32*(x+1) bits) */
	#define FUNC_ID_MM			(0<<4)		/**< Modular Multiplication of A & B */
	#define FUNC_ID_M1			(1<<4)		/**< Modular Multiplication of A & 1 */
	#define FUNC_ID_MA			(2<<4)		/**< Modular Addition of A & B */
	#define FUNC_ID_MS			(3<<4)		/**< Modular Subtraction of A & B */
	#define EXEC_ON				(1<<0)		/**< Run Execution */
#define PKA_SFR_1           (*(volatile u32 *)((PKA_REG_BASE) + 0x0004u))
	#define SEG_ID_A(x)			(x<<24)		/**<	x = 0..63 (Segment ID for 'A') */
	#define SEG_ID_B(x)			(x<<16)		/**<	x = 0..63 (Segment ID for 'B') */
	#define SEG_ID_M(x)			(x<< 8)		/**<	x = 0..63 (Segment ID for 'M') */
	#define SEG_ID_S(x)			(x<< 0)		/**<	x = 0..63 (Segment ID for 'S') */
#define PKA_SFR_2           (*(volatile u32 *)((PKA_REG_BASE) + 0x0008u))
	#define SEG_ID_I(x)			(x<<16)		/**<	x = 0..63 (Segment ID for 'I') */
#define PKA_SFR_3           (*(volatile u32 *)((PKA_REG_BASE) + 0x000Cu))
	#define IS_NEGATIVE(SegID)	( ((PKA_SFR_3)>>(SegID))&1 )
	#define SET_SIGN(SegID)		( (PKA_SFR_3) |= (1<<(SegID)) )
	#define CLEAR_SIGN(SegID)	( (PKA_SFR_3) &= (~(1<<(SegID))) )
#if SSS_UNUSED
	#define PKA_ECC_INT_STAT
	#define PKA_ECC_UNCOORRECT_STAT		(1<<1)		/**< indicate double error bits */
	#define PKA_ECC_SEC_STAT			(1<<0)		/**< single error bit */
	#define PKA_ECC_INT_EN_SET
	#define PKA_ECC_INT_EN_CLR
	#define PKA_ECC_INT_PEND							/**< write 1 clear */
	#define PKA_ECC_INT_ENABLE
	#define PKA_ECC_ENABLE				(1<<0)		/**< ECC enable bit */
	#define PKA_ECC_ERRLOG_CLR
	#define PKA_ERRLOG_DECODER_CLR		(1<<2)		/**< ERR LOG Clear bit */
	#define PKA_ERRLOG_DED_CLR			(1<<1)		/**< ERR LOG Clear bit */
	#define PKA_ERRLOG_SEC_CLR			(1<<0)		/**< ERR LOG Clear bit */
	#define PKA_ECC_SEC_ADDR
	#define PKA_ECC_DED_ADDR
	#define PKA_ECC_ERR_STAT
	#define PKA_ERR_DECODER				(1<<2)		/**< ERR Status bit */
	#define PKA_ERR_DED					(1<<1)		/**< ERR Status bit */
	#define PKA_ERR_SEC					(1<<0)		/**< ERR Status bit */
#endif
/*
 * PKA_SRAM Defintion for crypt_pke_a_v1.20e
 */

#define SEGSZ_ECC256	(9) /* only for ECC 256 */

#define PKA_SRAM_BASE		(PKA_REG_BASE + PKA_SRAM_OFFSET)
#define ptrPKA_SEG(idx)		((u32*)PKA_SRAM_BASE+((idx)*(SEGSZ_ECC256)))
/*************** New Data Types (Basic Data Types)	***********************/

/*************** New Data Types *******************************************/

/*************** Constants ************************************************/
/*
 * Define Segment ID Number
 */
#define SEG_00		(0)
#define SEG_01		(1)
#define SEG_02		(2)
#define SEG_03		(3)
#define SEG_04		(4)
#define SEG_05		(5)
#define SEG_06		(6)
#define SEG_07		(7)
#define SEG_08		(8)
#define SEG_09		(9)
#define SEG_10		(10)
#define SEG_11		(11)
#define SEG_12		(12)
#define SEG_13		(13)
#define SEG_14		(14)
#define SEG_15		(15)
#define SEG_16		(16)
#define SEG_17		(17)
#define SEG_18		(18)
#define SEG_19		(19)
#define SEG_20		(20)
#define SEG_21		(21)
#define SEG_22		(22)
#define SEG_23		(23)
#define SEG_24		(24)
#define SEG_25		(25)
#define SEG_26		(26)
#define SEG_27		(27)
#define SEG_XX		(0xFFu)	/*	Dummy Segment Name (Un-used)*/

#define FLAG_TORNADO_SFR		(1<<0)
#define FLAG_TORNADO_PKARAM		(1<<1)

/*
 * Define Segment ID Number for ECC group operation
 */
#define SEG_ID_K			(SEG_02)
#define SEG_ID_Gx			(SEG_03)
#define SEG_ID_Gy			(SEG_04)
#define SEG_ID_P			(SEG_05)
#define SEG_ID_R2p			(SEG_06)
#define SEG_ID_N			(SEG_07)
#define SEG_ID_R2n			(SEG_08)
#define SEG_ID_K2			(SEG_10)
#define SEG_ID_Gx2			(SEG_11)
#define SEG_ID_Gy2			(SEG_12)
#define SEG_ID_Rx			(SEG_13)
#define SEG_ID_Ry			(SEG_14)
#define SEG_ID_Int_00		(SEG_16)
#define SEG_ID_Int_01		(SEG_17)
#define SEG_ID_Int_02		(SEG_18)
#define SEG_ID_Int_03		(SEG_19)
#define SEG_ID_Int_04		(SEG_20)
#define SEG_ID_Int_05		(SEG_21)
#define SEG_ID_Int_06		(SEG_22)
#define SEG_ID_Int_07		(SEG_23)
#define SEG_ID_Int_08		(SEG_24)
#define SEG_ID_Int_09		(SEG_25)
#define SEG_ID_Int_10		(SEG_26)
/*
 * todo
 SEG_ID_ECC_Coef_A	(9)
 SEG_ID_ECC_Coef_B	(10)
 */

#define SEG_ID_ECDSA_SignKey	(SEG_01)
#define SEG_ID_ECDSA_Qx			(SEG_11)
#define SEG_ID_ECDSA_Qy			(SEG_12)
#define SEG_ID_ECDSA_HMSG		(SEG_09)
#define SEG_ID_ECC_Gx			(SEG_03)
#define SEG_ID_ECC_Gy			(SEG_04)
#define SEG_ID_ECC_PrimeP		(SEG_05)
#define SEG_ID_ECC_R2p			(SEG_06)
#define SEG_ID_ECC_OrderN		(SEG_07)
#define SEG_ID_ECC_R2n			(SEG_08)
#define SEG_ID_ECDSA_SIGNr		(SEG_01)
#define SEG_ID_ECDSA_SIGNs		(SEG_02)
/*************** Variable declarations ************************************/

/*************** Prototypes ***********************************************/

/*!
 * @brief 		Initialize PKE
 * @param[in] 	Keysize							bit-wise length of key
 * @return
 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 Others										Fail

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
void PKE_A_Init(u32 Keysize);

/*!
 * @brief		Clear Tornado's SFR & PKA-RAM
 * @param		u32Flag		[in] if FLAG_TORNADO_SFR, Clear Tornado's SFR
 * 								 if FLAG_TORNADO_PKARAM, Clear PKA-RAM
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
void PKE_A_Clear(u32 u32Flag);

/*!
 * @brief 		Clear Sign & PKSRAM for target segment
 * @param[in]	seg_id		target segment id
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
void PKE_A_1SEG_Clear(u32 seg_id);

void PKE_A_1SEG_Copy(u32 dst_id, u32 src_id);

/*!
 * @brief 		PKA execution with input segmentations & function ID (with non-fixed segment size)
 * @param[in]	f_id  	PKA function ID = { MM(00), M1(01), MA(02), MS(03)	}
 * @param[in]	Seg_A 	Segment	A_SEG
 * @param[in]	Seg_B 	Segment B_SEG
 * @param[in]	Seg_M 	Segment M_SEG
 * @param[in]	Seg_S 	Segment S_SEG
 * @param[in]	Seg_I 	Segment I_SEG

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
void PKE_A_exe(u32 f_id, u32 Seg_A, u32 Seg_B, u32 Seg_M, u32 Seg_S, u32 Seg_I);

/*!
 * @brief		Modular Exponentiation: [Seg_Res] <= [Seg_Base] ^ [Seg_Exp] mod [Seg_Mod]
 * @param		Seg_Base	[in] Segment ID for Base Number
 * @param		Seg_Exp		[in] Segment ID for Exponent Number
 * @param		Seg_Mod		[in] Segment ID for Modulus Number
 * @param		Seg_Res		[in] Segment ID for saving Result of Exponent
 * @param		Seg_Int		[in] Segment ID for Intermediate Values
 * @param		u32ECC_wlen	[in] Word Length of Base Prime Number
 * @return		N/A

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
void Modular_Exp(u32 Seg_Base, u32 Seg_Exp, u32 Seg_Mod, u32 Seg_Res,
		u32 Seg_Int, u32 u32ECC_wlen);

/*!
 * @brief		Scalar Multiplication
 * @param		u32ECC_wlen	[in] Word Length of Base Prime Number
 * @return		N/A
 *
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
void Scalar_Mul(u32 u32ECC_wlen);

/*!
 * @brief		Two-Term Scalar Multiplication
 * @param		u32ECC_wlen	[in] Word Length of Base Prime Number
 * @return		N/A
 *
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
void TwoTerm_Scalar_Mul(u32 u32ECC_wlen);
/*************** END OF FILE **********************************************/
#endif /* SSS_LIB_PKE_A_H_ */

/** @} */
