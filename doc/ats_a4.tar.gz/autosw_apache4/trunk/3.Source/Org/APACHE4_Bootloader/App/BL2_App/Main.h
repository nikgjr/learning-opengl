/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 2018.03.01
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __MAIN_H__
#define __MAIN_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
 * APACHE4 Bootloader-BL1 Version
 */

#define BL2_VER_MAJOR               0
#define BL2_VER_MINOR1              3
#define BL2_VER_MINOR2              1

#define BL2_BUILD_DATE              __DATE__
#define BL2_BUILD_TIME              __TIME__


/*
 * APACHE4 Bootloader-BL2 Compile Option
 */

#if 1   // JTAG Boot

#define BL2_FAST_BOOT_ENABLE            0   // test : Only Peripheral ASIC simulation test
#define BL2_JTAG_BOOT_ENABLE            1   // test : FPGA JTAG download & debugging enable
#define BL2_CHECKSUM_ENABLE             1   // test : Checksum validation enable
#define BL2_DCLS_ONLY_ENABLE            0   // test : DLS core only run enable
//=============================================================================
#elif 0 // ASIC Fast Boot Simulation

#define BL2_FAST_BOOT_ENABLE            1   // test : Only Peripheral ASIC simulation test
#define BL2_JTAG_BOOT_ENABLE            0   // test : FPGA JTAG download & debugging enable
#define BL2_CHECKSUM_ENABLE             1   // test : Checksum validation enable
#define BL2_DCLS_ONLY_ENABLE            0   // test : DLS core only run enable
//=============================================================================
#else   // Real Boot & Post-Simulation

#define BL2_FAST_BOOT_ENABLE            0   // test : Only Peripheral ASIC simulation test
#define BL2_JTAG_BOOT_ENABLE            0   // test : FPGA JTAG download & debugging enable
#define BL2_CHECKSUM_ENABLE             1   // test : Checksum validation enable
#define BL2_DCLS_ONLY_ENABLE            0   // test : DLS core only run enable
//=============================================================================
#endif


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
#if 1
    UINT32 mImgLength;      // APP image length
    UINT32 mImgCSum;        // APP image checksum
    UINT32 mReserved0;      //
    UINT32 mReserved1;      //
#else
    UINT32 mSignature;      // APP header signature
    UINT8  mRetryCount;     // Retry count
    UINT8  mReserved0;      //
    UINT8  mReserved1;      //
    UINT8  mReserved2;      //
    UINT32 mTotalLength;    // APP header + image total length
    UINT32 mBUHSrcAddr;     // Backup APP header flash memory start address

    UINT32 mImgSrcAddr;     // APP flash memory source address
    UINT32 mImgDstAddr;     // APP system memory destination address
    UINT32 mImgLength;      // APP image length
    UINT32 mImgCSum;        // APP image checksum
#endif
} stAPP_Header, *pstAPP_Header;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/


#endif  /* __MAIN_H__ */


/* End Of File */

