/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_ECDSA256		SSS_ECDSA256
 * @ingroup SSS_API
 * @brief					ECDSA256 Library
 * @{
 */

/*!
 * @file		sss_api_ecdsa_256.c
 * @brief		Sourcefile for ECDSA API
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ********************************************/
#include "sss_lib_util.h"
#include "sss_api_ecdsa_256.h"

/*************** Assertions ***********************************************/

/*************** Definitions / Macros *************************************/

/*************** Constants ************************************************/

/*************** Variable declarations ************************************/

/*************** Prototypes ***********************************************/

/*************** Function *************************************************/
SSS_RV sss_ECDSA_Verify_256(stECC_PUBKEY *pstEcdsaPubKey,
		stOCTET_STRING *pstDigest, stECDSA_SIGN *pstSIGN)
{
	u32 ret = SSSR_SUCCESS;
	stECC_Param *pstECDSAParam;

	/*! > Sequence */
	/*! Step 1. Init */
	/*! - ECC Info */
	get_ECCInfo(OID_ECC_P256, &pstECDSAParam);

	/*! - ECDSA Init */
	ret = ECDSA_verify_Init(pstECDSAParam, pstEcdsaPubKey);
	if (SSSR_SUCCESS == ret)
	{

		/*! Step 2. Update */
		/*! - ECDSA Update with Digest */
		if ((256 / 8) == pstDigest->u32DataByteLen)
		{
			ECDSA_update(pstDigest, pstECDSAParam->u32Data_wlen);
			/*! Step 3. Final */
			/*! - ECDSA Final with Sign */
			ret = ECDSA_verify_final(pstECDSAParam, pstSIGN);
			/*! - Get result */
		}
		else
		{
			ret = ERROR_ECDSA_INVALID_LEN_MSG;
		}
	}

	return ret;
}

/*************** END OF FILE **********************************************/

/** @} */
