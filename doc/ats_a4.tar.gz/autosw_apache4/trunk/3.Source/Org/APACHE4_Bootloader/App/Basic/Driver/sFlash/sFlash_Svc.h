/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SFLASH_SVC_H__
#define __SFLASH_SVC_H__

/*
********************************************************************************
*              INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#define MEMORY_CAPACITY_512Kb                   0x00
#define MEMORY_CAPACITY_1Mb                     0x01
#define MEMORY_CAPACITY_2Mb                     0x02
#define MEMORY_CAPACITY_4Mb                     0x03
#define MEMORY_CAPACITY_8Mb                     0x04
#define MEMORY_CAPACITY_16Mb                    0x05
#define MEMORY_CAPACITY_32Mb                    0x06
#define MEMORY_CAPACITY_64Mb                    0x07
#define MEMORY_CAPACITY_128Mb                   0x08

#define SF_BLOCK_SIZE                           (64*KB)
#define SF_SECTOR_SIZE                          (4*KB)
#define SF_PAGE_SIZE                            (256)


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tSF_PARAM
{
    UINT32  mSpiCS;                 // SPI Chip Select
    BOOL    mQuadMode;              // 0: Standard SPI, 1: Quad SPI
    UINT32  mBitRate;               // Hz
} tSF_PARAM, *ptSF_PARAM;

extern volatile tSF_PARAM tSF_Info;


typedef struct _tSFLASH_ID
{
    UINT8   mbManufacture;          // Manufacture ID
    UINT8   mbMemoryType;           // Memory Type
    UINT8   mbMemoryCapacity;       // Memory Capacity
} tSFLASH_ID, *ptSFLASH_ID;


/*
********************************************************************************
*              FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32  ncSvc_SF_Init(ptSF_PARAM ptParam);

extern void   ncSvc_SF_WaitWIP(void);
extern void   ncSvc_SF_WriteEnable(void);
extern void   ncSvc_SF_WriteDisable(void);
extern UINT8  ncSvc_SF_ReadStatus(void);
extern UINT8  ncSvc_SF_ReadStatus2(void);
extern void   ncSvc_SF_WriteStatus(UINT8 Status);
extern void   ncSvc_SF_WriteStatus2(UINT8 Status1, UINT8 Status2);

extern INT32  ncSvc_SF_ReadDeviceIdentification(ptSFLASH_ID ptsFlashID);
extern INT32  ncSvc_SF_SectorErase(UINT32 PageAddr);

extern INT32  ncSvc_SF_WriteData(UINT32 Addr, UINT8 *pData, UINT32 size);
extern INT32  ncSvc_SF_ReadData(UINT32 Addr, UINT8 *pData, UINT32 Size);

extern INT32  ncSvc_SF_GetPadCtrl(void);
extern INT32  ncSvc_SF_FreePadCtrl(void);

extern void   ncSvc_SF_EnableWP(BOOL OnOff);

extern void   ncSvc_SF_QSPIEnable(BOOL OnOff);


#endif /* __SFLASH_SVC_H__ */


/* End Of File */

