/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_ECDSA		SSS_ECDSA
 * @ingroup SSS_Library
 * @brief					ECDSA Library
 * @{
 */

/*!
 * @file		sss_lib_ecdsa.h
 * @brief		Sourcefile for ECDSA function
 * @author		kiseok.bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ********************************************/
#include "sss_lib_util.h"
#include "sss_lib_ecdsa.h"

/*************** Assertions ***********************************************/

/*************** Definitions / Macros *************************************/

/*************** Constants ************************************************/

/*************** Variable declarations ************************************/

/*************** Prototypes ***********************************************/

/*************** Function *************************************************/

/**
 * @brief			ECDSA verification sequencer
 * @param[in]		pstDomainParam    ECC object = select EC parameter(160, 192, 224, 256, 384, 521)
 * @return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 Else

 * @author		kiseok.bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
static SSS_RV ECDSA_verify_seq(stECC_Param* pstDomainParam)
{
	u32 ret = 0;
	u32 SEG_ID_Temp1 = SEG_15; /*zero, p-2, 1*/
	u32 SEG_ID_Temp2 = SEG_16; /*temp seg i*/
	u32 u32ECC_wlen = pstDomainParam->u32Data_wlen;

	/*! > Sequence */
	/*! step 2. Input check */
	/*! * check r,S size is among [1,n-1] */
	ret = (chk_INPUT(SEG_01) | chk_INPUT(SEG_02));
	if (SSSR_SUCCESS == ret)
	{
		/*! step 3. calculate s^-1 by Modular exponentiation */
		/*! * calculate n-2 */
		/*! * s to montgomery domain */
		/*! * s'^ (n-2) mod n = s' inverse */
		/*! * skip convert to integer domain */
		PKE_A_1SEG_Clear(SEG_ID_Temp1);
		ptrPKA_SEG(SEG_ID_Temp1)[0] = 0x00000002;
		PKE_A_exe(FUNC_ID_MS, SEG_ID_N, SEG_ID_Temp1, SEG_ID_N, SEG_14,
				SEG_ID_Temp2); /*2 */
		PKE_A_exe(FUNC_ID_MM, SEG_02, SEG_08, SEG_ID_N, SEG_02, SEG_ID_Temp2); /*3 */
		/*
		 * ME
		 */
		Modular_Exp(SEG_02, SEG_14, SEG_ID_N, SEG_00, SEG_16, u32ECC_wlen); /*	[SEG_00] = s^{-1} mod n*/

		/*! step 4. calculate u1 */
		/*! * modular mulitplication (e, s'inverse) */
		/*! * make positive */
		PKE_A_exe(FUNC_ID_MM, SEG_09, SEG_00, SEG_ID_N, SEG_02, SEG_ID_Temp2); /*6 */
		PKE_A_exe(FUNC_ID_MA, SEG_02, SEG_ID_N, SEG_ID_N, SEG_02, SEG_ID_Temp2); /*8 */

		/*! step 5. calculate u2 */
		/*! * modular mulitplication (r, s'inverse) */
		/*! * make positive */
		PKE_A_exe(FUNC_ID_MM, SEG_01, SEG_00, SEG_ID_N, SEG_10, SEG_ID_Temp2); /*10 */
		PKE_A_exe(FUNC_ID_MA, SEG_10, SEG_ID_N, SEG_ID_N, SEG_10, SEG_ID_Temp2); /*12 */

		/*! step 7. run two-terms scalar multiplication u1G+u2Q */
		/* TS */
		TwoTerm_Scalar_Mul(u32ECC_wlen);
		ptrPKA_SEG(SEG_ID_Temp1)[0] = 0x00000000;
		/*! step 8. check r'(result of step 7) is zero */
		ret = sss_memcmp_u32(ptrPKA_SEG(SEG_13), ptrPKA_SEG(SEG_15),
				u32ECC_wlen); /*16*/
		if (SSSR_SUCCESS != ret)
		{
			/*! step 9. r' to integer domain */
			PKE_A_exe(FUNC_ID_M1, SEG_13, SEG_XX, SEG_ID_P, SEG_13,
					SEG_ID_Temp2); /*17 */
			/*! step 10. r' to positive*/
			if (TRUE == IS_NEGATIVE(SEG_13))
			{
				PKE_A_exe(FUNC_ID_MA, SEG_13, SEG_ID_P, SEG_ID_P, SEG_13,
						SEG_ID_Temp2); /*Rx to be positive */
			}
			PKE_A_exe(FUNC_ID_MA, SEG_13, SEG_ID_N, SEG_ID_N, SEG_13,
					SEG_ID_Temp2); /*Rx + order */
			/*word comparator */
			/*! step 11. check signature is valid or not */
			ret = sss_memcmp_u32(ptrPKA_SEG(SEG_01), ptrPKA_SEG(SEG_13),
					u32ECC_wlen); /*22*/
		}
	}

	if (SSSR_SUCCESS != ret)
	{
		ret = ERROR_ECDSA_INVALID_VAL_SIGN;
	}

	return ret;
}

SSS_RV ECDSA_verify_Init(stECC_Param *pstDomainParam, stECC_PUBKEY* pstPubkey)
{
	u32 ret = SSSR_SUCCESS;

	/*! > Sequence */
	/*! Step 1. check validity of input key */
	if( (pstPubkey->stBigNum_Qx.u32DataByteLen == 0) || (pstPubkey->stBigNum_Qy.u32DataByteLen == 0)
			|| (pstPubkey->stBigNum_Qx.u32DataByteLen > (pstDomainParam->u32Data_wlen * 4)) || (pstPubkey->stBigNum_Qy.u32DataByteLen > (pstDomainParam->u32Data_wlen * 4)) )
	{
		ret = ERROR_ECC_INVALID_LEN_KEY;
	}
	else
	{
		/*! Step 2. set ECC paramater */
		ECC_PARAM(pstDomainParam);
		/*! Step 3. set ECC Key */
		ECC_PUBKEY(pstPubkey);
	}

	return ret;
}

void ECDSA_update(stOCTET_STRING* pstDigest, u32 u32ECC_wlen)
{
	stOCTET_STRING stTempOS;
	u32 u32WordLen = pstDigest->u32DataByteLen / 4;

	stTempOS.pu08Data = pstDigest->pu08Data;
	stTempOS.u32DataByteLen = pstDigest->u32DataByteLen;

	/*! step 1. check digest message length */
	if (u32ECC_wlen >= u32WordLen)
	{
		/* zeropadding when ecc_wlen > hash_wlen */
		sss_memclr_u32( ptrPKA_SEG(SEG_ID_ECDSA_HMSG) + u32WordLen,
				(u32ECC_wlen - u32WordLen));
	}
	else
	{
		/* ecc_wlen < hash_wlen */
		stTempOS.u32DataByteLen = u32ECC_wlen * 4;
	}
	/*! step 2. seg set digest message */
	sss_OS_to_BN(ptrPKA_SEG(SEG_ID_ECDSA_HMSG), &stTempOS);
}

SSS_RV ECDSA_verify_final(stECC_Param *pstDomainParam, stECDSA_SIGN* pstSIGN)
{
	u32 ret = SSSR_FAIL;

	/*! step 0. check sign length */
	if ((pstSIGN->stSign_r.u32DataByteLen == 0)
			|| (pstSIGN->stSign_s.u32DataByteLen == 0)
			|| (pstSIGN->stSign_r.u32DataByteLen
					> 4 * pstDomainParam->u32Data_wlen)
			|| (pstSIGN->stSign_s.u32DataByteLen
					> 4 * pstDomainParam->u32Data_wlen))
	{
		ret = ERROR_ECDSA_INVALID_LEN_SIGN;
	}
	else
	{
		/*! step 1. Set Sign */
		sss_OS_to_BN(ptrPKA_SEG(SEG_ID_ECDSA_SIGNr), &pstSIGN->stSign_r);
		sss_OS_to_BN(ptrPKA_SEG(SEG_ID_ECDSA_SIGNs), &pstSIGN->stSign_s);

		/*! setp 2. Call Verify seq */
		ret = ECDSA_verify_seq(pstDomainParam);
	}

	return ret;
}

/*************** END OF FILE **********************************************/

/** @} */
