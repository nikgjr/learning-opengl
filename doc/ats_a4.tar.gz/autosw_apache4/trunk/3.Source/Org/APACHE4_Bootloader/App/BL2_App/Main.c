/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    :
*
*  @brief   :
*
*  @author  :
*
*  @date    : 2018.03.01
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "Apache.h"

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

/* Flash Memory Map Address */

#define BACKUP_APP1_IMAGE_S_ADD     0x00091010  //
#define BACKUP_APP1_HEADER_S_ADD    0x00091000  //

#define BACKUP_APP0_IMAGE_S_ADD     0x00011010  //
#define BACKUP_APP0_HEADER_S_ADD    0x00011000  //

#define NORMAL_APP1_IMAGE_S_ADD     0x00091010  // fixed address
#define NORMAL_APP1_HEADER_S_ADD    0x00091000  // fixed address

#define NORMAL_APP0_IMAGE_S_ADD     0x00011010  // fixed address
#define NORMAL_APP0_HEADER_S_ADD    0x00011000  // fixed address


/* System Memory Map Address */

#define SRAM_BASE_ADDRESS           APACHE_IRAM_BASE
#define SRAM_SIZE_MAX               (64*1024)

#define DDR3_APP1_BASE_ADDRESS      (APACHE_DRAM_BASE + 0x80000)
#define DDR3_APP0_BASE_ADDRESS      APACHE_DRAM_BASE
#define DDR3_APP_SIZE_MAX           (512*1024)


/* Boot Option */

#define BL2_RETRY_COUNT             3


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

stAPP_Header stAPPHeader;
E_CORE_RUN gCoreRunStatus = E_CORE_NONE;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION DEFINITIONS
********************************************************************************
*/

void ncBL2_BOOT_DebugStepMessage(UINT8 nMsg)
{
    BL2_STP_REG = nMsg;
    DEBUGMSG(MSGINFO, "%c", nMsg);
}


void ncBL2_SetRemap(void)
{
    if((gCoreRunStatus & E_CORE_DUAL) == E_CORE_DUAL)
    {
        // Dual-Core Lock Step DDR3 0x8000_0000 Remap
        REGRW32(APACHE_SYSCON_BASE, 0x0104) = 0x00000000;
        REGRW32(APACHE_SYSCON_BASE, 0x0124) = 0x80000007;

        REGRW32(APACHE_SYSCON_BASE, 0x0108) = 0x00000000;
        REGRW32(APACHE_SYSCON_BASE, 0x0128) = 0x80000007;

        // Single-Core DDR3 0x8008_0000 Remap
        REGRW32(APACHE_SYSCON_BASE, 0x0110) = 0x00000000;
        REGRW32(APACHE_SYSCON_BASE, 0x0130) = 0x80080007;
    }
    else if((gCoreRunStatus & E_CORE_DLS) == E_CORE_DLS)
    {
        // Dual-Core Lock Step DDR3 0x8000_0000 Remap
        REGRW32(APACHE_SYSCON_BASE, 0x0104) = 0x00000000;
        REGRW32(APACHE_SYSCON_BASE, 0x0124) = 0x80000007;

        REGRW32(APACHE_SYSCON_BASE, 0x0108) = 0x00000000;
        REGRW32(APACHE_SYSCON_BASE, 0x0128) = 0x80000007;

        // Single-Core DDR3 0x8008_0000 Remap
        REGRW32(APACHE_SYSCON_BASE, 0x0110) = 0x00000000;
        REGRW32(APACHE_SYSCON_BASE, 0x0130) = 0x80000007;
    }
    else if((gCoreRunStatus & E_CORE_SINGLE) == E_CORE_SINGLE)
    {
        // Dual-Core Lock Step DDR3 0x8000_0000 Remap
        REGRW32(APACHE_SYSCON_BASE, 0x0104) = 0x00000000;
        REGRW32(APACHE_SYSCON_BASE, 0x0124) = 0x80080007;

        REGRW32(APACHE_SYSCON_BASE, 0x0108) = 0x00000000;
        REGRW32(APACHE_SYSCON_BASE, 0x0128) = 0x80080007;

        // Single-Core DDR3 0x8008_0000 Remap
        REGRW32(APACHE_SYSCON_BASE, 0x0110) = 0x00000000;
        REGRW32(APACHE_SYSCON_BASE, 0x0130) = 0x80080007;
    }
    else
    {
        DEBUGMSG(MSGERR, "Failure, Apache4 bootloader-ram [%d] remap failure\n", gCoreRunStatus);
    }
}


void ncBL2_SetCore1_Reset(void)
{
    if((gCoreRunStatus & E_CORE_SINGLE) == E_CORE_SINGLE)
    {
        REGRW32(APACHE_SYSCON_BASE, 0x0024) &= ~0x00030000;
    }
}


void ncBL2_SetCoreRun(void)
{
    UINT32 i, temp;
    PrVoid Core0_PC_CountReset = (PrVoid)0x0;

    // Remap Enable
    REGRW32(APACHE_SYSCON_BASE, 0x0100) = 0x00000001;

#if 1
    while(1)
    {
        temp = REGRW32(APACHE_SYSCON_BASE, 0x0100);
        if(temp)
        {
            ncBL2_SetCore1_Reset();
            Core0_PC_CountReset();
            break;
        }
    }
#else
    for(i = 0; i < 10; i++)
    {;}

    ncBL2_SetCore1_Reset();
    Core0_PC_CountReset();
#endif
}


E_BL_ERROR ncBL2_SF_GetHeader(UINT32 nAddress)
{
    UINT32 i, app;
    UINT8 rBuff[256] __attribute__ ((aligned (8)));
    E_BL_ERROR ret = E_NOERROR;

    if((nAddress == NORMAL_APP0_HEADER_S_ADD) || (nAddress == BACKUP_APP0_HEADER_S_ADD)) app = 0;
    else app = 1;

    DEBUGMSG(MSGINFO, "\n1.Flash memory application_%d 0x%08X header read ...\n", app, nAddress);

#if BL_SPI_ENABLE   // SSP & QSPI
    if(ncSvc_SF_ReadData(nAddress, (UINT8 *)rBuff, SF_PAGE_SIZE) != NC_SUCCESS)
    {
        if(app == 0) ret = E_ERROR_APP0_HEADER;
        else ret = E_ERROR_APP1_HEADER;
    }

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------\n");
    for(i = 0; i < SF_PAGE_SIZE; i++)
    {
        if(!(i % 0x10))
            DEBUGMSG(MSGINFO, "\n 0x%02X : ", i & 0xFF);
        DEBUGMSG(MSGINFO, "%02X ", rBuff[i]);
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------\n");

    stAPPHeader.mImgLength = CharToInt(&rBuff[0]);  // APP image length
    stAPPHeader.mImgCSum   = CharToInt(&rBuff[4]);  // APP image checksum

    DEBUGMSG(MSGINFO, "APP%d Image Length  = 0x%08X(%d)\n", app, stAPPHeader.mImgLength, stAPPHeader.mImgLength);
    DEBUGMSG(MSGINFO, "APP%d Image CSum    = 0x%08X\n", app, stAPPHeader.mImgCSum);
    DEBUGMSG(MSGINFO, "\n");

    if((stAPPHeader.mImgLength == 0) || (stAPPHeader.mImgLength > DDR3_APP_SIZE_MAX))
    {
        DEBUGMSG(MSGERR, "Error, Flash Memory APP Image Length Failure\n");

        if(app == 0) ret = E_ERROR_APP0_HEADER;
        else ret = E_ERROR_APP1_HEADER;
    }
    else
    {
        ret = E_NOERROR;
    }
#endif

    if(ret == E_NOERROR)
    {
        DEBUGMSG(MSGINFO, " >> Success, read flash application_%d header\n", app);
    }
    else
    {
        DEBUGMSG(MSGERR, " >> Failure, read flash application_%d header\n", app);
    }

    return ret;
}


E_BL_ERROR ncBL2_SF_GetImage(UINT32 nAddress)
{
    UINT32 i, app, size, retry, reSize;
    UINT32 checksum = 0;
    //UINT8 rBuff[256] __attribute__ ((aligned (8)));
    UINT8 *pBuffer;
    UINT32 *pDwBuffer;
    E_BL_ERROR ret = E_NOERROR;

    if((nAddress == NORMAL_APP0_IMAGE_S_ADD) || (nAddress == BACKUP_APP0_IMAGE_S_ADD)) app = 0;
    else app = 1;

    DEBUGMSG(MSGINFO, "\n2.Flash memory application_%d 0x%08X image read ...\n", app, nAddress);

    size = Align(stAPPHeader.mImgLength, 8);

    if(app == 0)
    {
        pBuffer = (UINT8 *)DDR3_APP0_BASE_ADDRESS;
        pDwBuffer = (UINT32 *)DDR3_APP0_BASE_ADDRESS;
    }
    else
    {
        pBuffer = (UINT8 *)DDR3_APP1_BASE_ADDRESS;
        pDwBuffer = (UINT32 *)DDR3_APP1_BASE_ADDRESS;
    }


    // read serial flash memory of area APP image

#if BL_SPI_ENABLE
    for(retry = 0; retry < BL2_RETRY_COUNT; retry++)
    {
        if(ncSvc_SF_ReadData(nAddress, (UINT8 *)pBuffer, size) != NC_SUCCESS)
        {
            if(app == 0) ret = E_ERROR_APP0_IMAGE;
            else ret = E_ERROR_APP1_IMAGE;
            break;
        }

        // 32bit checksum ...

#if BL2_CHECKSUM_ENABLE
        checksum = 0;
        reSize = stAPPHeader.mImgLength/4;

        for(i = 0; i < reSize; i++)
        {
            checksum += pDwBuffer[i];
        }

        if(stAPPHeader.mImgCSum == checksum)
        {
            ret = E_NOERROR;
            break;
        }
        else
        {
            DEBUGMSG(MSGERR, " Error, flash memory APP%d image download checksum failure\n", app);
            DEBUGMSG(MSGERR, " mImgCSum(0x%08X) vs checksum(0x%08X)\n", stAPPHeader.mImgCSum, checksum);

            if(app == 0) ret = E_ERROR_APP0_IMAGE;
            else ret = E_ERROR_APP1_IMAGE;
        }
#else
        break;
#endif
    }
#endif

    if(ret == E_NOERROR)
    {
        DEBUGMSG(MSGINFO, " >> Success, read flash APP%d image, write DDR3\n", app);
    }
    else
    {
        DEBUGMSG(MSGERR, " >> Failure, read flash APP%d image, write DDR3\n", app);
    }

    return ret;
}


E_BL_ERROR ncBL2_FlashBootMode(void)
{
    E_BL_ERROR ret = E_NOERROR;

    ret = ncBL2_SF_GetHeader(NORMAL_APP0_HEADER_S_ADD);
    if(ret == E_ERROR_APP0_HEADER)
    {
        ncBL2_BOOT_DebugStepMessage('A');

        ret = ncBL2_SF_GetHeader(BACKUP_APP0_HEADER_S_ADD);
        if(ret == E_ERROR_APP0_HEADER)
        {
            ncBL2_BOOT_DebugStepMessage('E');
            goto app1_load;
        }
    }

    ret = ncBL2_SF_GetImage(NORMAL_APP0_IMAGE_S_ADD);
    if(ret == E_ERROR_APP0_IMAGE)
    {
        ncBL2_BOOT_DebugStepMessage('B');

        ret = ncBL2_SF_GetImage(BACKUP_APP0_IMAGE_S_ADD);
        if(ret == E_ERROR_APP0_IMAGE)
        {
            ncBL2_BOOT_DebugStepMessage('F');
        }
    }

    gCoreRunStatus = E_CORE_DLS;

app1_load:

#if BL2_DCLS_ONLY_ENABLE
    DEBUGMSG(MSGINFO, "Single core image download skip ... \n");
#else
    ret = ncBL2_SF_GetHeader(NORMAL_APP1_HEADER_S_ADD);
    if(ret == E_ERROR_APP1_HEADER)
    {
        ncBL2_BOOT_DebugStepMessage('C');

        ret = ncBL2_SF_GetHeader(BACKUP_APP1_HEADER_S_ADD);
        if(ret == E_ERROR_APP1_HEADER)
        {
            ncBL2_BOOT_DebugStepMessage('G');
            return ret;
        }
    }

    ret = ncBL2_SF_GetImage(NORMAL_APP1_IMAGE_S_ADD);
    if(ret == E_ERROR_APP1_IMAGE)
    {
        ncBL2_BOOT_DebugStepMessage('D');

        ret = ncBL2_SF_GetImage(BACKUP_APP1_IMAGE_S_ADD);
        if(ret == E_ERROR_APP1_IMAGE)
        {
            ncBL2_BOOT_DebugStepMessage('H');
            return ret;
        }
    }

    gCoreRunStatus |= E_CORE_SINGLE;
#endif

    return ret;
}


int main(void)
{
    UINT32 nBootStrap;
    E_BL_ERROR nErrStatus;

    BL2_VER_REG = 0;
    BL2_STP_REG = 0;
    BL2_RES_REG = 0;

    if(ncBL_SCU_Initialize() != NC_SUCCESS)
    {
        nErrStatus = E_ERROR_SCU_INIT;
    }

#if BL2_JTAG_BOOT_ENABLE
    nBootStrap = REGRW32(rSCU_DEBUG_REG, 0x0040) & 0x0F;

    gtBStrap.mMode      = (nBootStrap >> 3) & 0x1;
    gtBStrap.mFlashCS   = (nBootStrap >> 2) & 0x1;
    gtBStrap.mPLLConfig = (nBootStrap & 0x3);

    tSCUClk.mOSC  = OSC_CLOCK;
    tSCUClk.mCPU  = CPU_CLOCK;
    tSCUClk.mAXI  = AXI_CLOCK;
    tSCUClk.mAPB  = APB_CLOCK;
    tSCUClk.mDDR  = DDR_CLOCK;
    tSCUClk.mQSPI = QSPI_CLOCK;
#endif

#if BL_UART_ENABLE
    ncBL2_BOOT_DebugStepMessage('U');

    if(ncBL_UART_Initialize() != NC_SUCCESS)
    {
        nErrStatus = E_ERROR_UART_INIT;
    }
#endif

#if BL_SPI_ENABLE   // SSP & QSPI
    ncBL2_BOOT_DebugStepMessage('S');

    if(ncBL_SF_Initialize() != NC_SUCCESS)
    {
        nErrStatus = E_ERROR_SPI_INIT;
    }
#endif

    ncBL2_BOOT_DebugStepMessage('\n');
    ncBL2_BOOT_DebugStepMessage('B');
    ncBL2_BOOT_DebugStepMessage('L');
    ncBL2_BOOT_DebugStepMessage('2');
    ncBL2_BOOT_DebugStepMessage('\n');

    DEBUGMSG(MSGINFO, "\n\n");
    DEBUGMSG(MSGINFO, "===============================================================================\n");
    DEBUGMSG(MSGINFO, "- Apache4 Bootloader-Ram Start\n");
    DEBUGMSG(MSGINFO, "-------------------------------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "- BL2 Version: [V%d.%d.%d] [%s, %s]\n",
                      BL2_VER_MAJOR, BL2_VER_MINOR1, BL2_VER_MINOR2, BL2_BUILD_DATE, BL2_BUILD_TIME);
    DEBUGMSG(MSGINFO, "-------------------------------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, " ---- Strap Information\n");
    DEBUGMSG(MSGINFO, " Boot %s mode\n", gtBStrap.mMode?"Secure":"sFlash");
    DEBUGMSG(MSGINFO, " sFlash CS_%d\n", gtBStrap.mFlashCS);
    if(gtBStrap.mPLLConfig == 0)      DEBUGMSG(MSGINFO, " External clock mode\n");
    else if(gtBStrap.mPLLConfig == 1) DEBUGMSG(MSGINFO, " PLL min. clock Mode\n");
    else if(gtBStrap.mPLLConfig == 2) DEBUGMSG(MSGINFO, " PLL middle clock Mode\n");
    else if(gtBStrap.mPLLConfig == 3) DEBUGMSG(MSGINFO, " PLL max. clock Mode\n");
    DEBUGMSG(MSGINFO, " ---- sFlash Information\n");
    DEBUGMSG(MSGINFO, " Manufacture ID : 0x%02X\n", gtsFlashID.mManufacture);
    DEBUGMSG(MSGINFO, " Memory type ID : 0x%02X\n", gtsFlashID.mMemoryType);
    DEBUGMSG(MSGINFO, " Memory density : 0x%02X\n", gtsFlashID.mMemoryCapacity);
    DEBUGMSG(MSGINFO, " Memory size    : %d KB\n", gtsFlashID.mMemorySize/KB);
    DEBUGMSG(MSGINFO, " ---- Clock Information\n");
    DEBUGMSG(MSGINFO, " OSC = %8d, CPU = %8d, AXI = %8d, QSPI = = %8d, APB = %8d\n",
                        tSCUClk.mOSC, tSCUClk.mCPU, tSCUClk.mAXI, tSCUClk.mQSPI, tSCUClk.mAPB);
    DEBUGMSG(MSGINFO, "===============================================================================\n");
    DEBUGMSG(MSGINFO, "\n");

#if BL2_FAST_BOOT_ENABLE
    nErrStatus = E_NOERROR;
#else
    if(gtBStrap.mMode == BS_FLASH_BOOT)
    {
        ncBL2_BOOT_DebugStepMessage('0');

        nErrStatus = ncBL2_FlashBootMode();

        if(nErrStatus)
        {
            ncBL2_BOOT_DebugStepMessage('1');
        }
    }
    else    // BS_SECURE_BOOT
    {
        ncBL2_BOOT_DebugStepMessage('2');

        nErrStatus = ncBL2_FlashBootMode();

        if(nErrStatus)
        {
            ncBL2_BOOT_DebugStepMessage('3');
        }
    }

    ncBL2_BOOT_DebugStepMessage('4');

#if BL_SPI_ENABLE   // SSP & QSPI
    ncBL_SF_IOMuxRelease();
#endif
#endif

    if(nErrStatus)
    {
        BL2_RES_REG = ('N'<<8) | ('G'<<0);  // NG
        ncBL2_BOOT_DebugStepMessage('7');
        DEBUGMSG(MSGERR, "Failure, Apache4 bootloader-ram [%d] failure\n", nErrStatus);

        if(gCoreRunStatus != E_CORE_NONE)
        {
            ncBL2_SetRemap();
            ncBL2_SetCoreRun();
        }
    }
    else
    {
        BL2_RES_REG = ('O'<<8) | ('K'<<0);  // OK
        ncBL2_BOOT_DebugStepMessage('8');
        DEBUGMSG(MSGINFO, "Success, Apache4 bootloader-ram success\n");

        ncBL2_SetRemap();
        ncBL2_SetCoreRun();
    }

    ncBL2_BOOT_DebugStepMessage('9');

    return nErrStatus;
}


/* End Of File */

