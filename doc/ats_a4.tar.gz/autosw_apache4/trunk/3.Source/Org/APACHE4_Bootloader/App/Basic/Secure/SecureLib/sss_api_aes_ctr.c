/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_AES_CTR	SSS_AES_CTR
 * @ingroup SSS_API
 * @brief					AES_CTR Library
 * @{
 */

/**
 * @file		sss_api_aes_ctr.c
 * @brief		Sourdefile for AES CTR API
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ************************************************/
#include "sss_lib_util.h"
#include "sss_api_aes_ctr.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ****************************************************/

/*************** Prototypes ***************************************************/
SSS_RV sss_AES_Enc_CTR(stAES_PARAMS *pstAES_Params, const stAES_KEY *pstAES_Key,
		const stOCTET_STRING *pstAES_Plaintext,
		stOCTET_STRING *pstAES_Ciphertext)
{
	s32 ret = SSSR_SUCCESS;
	u32 u32Object_id = OID_AES_ENCRYPT;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step1. Check validity of parameter
	 */
	if (pstAES_Plaintext->u32DataByteLen == 0)
	{
		ret = ERROR_AES_INVALID_LEN_MSG;
	}
	else
	{
		/*!
		 * Step2. Assign object id according to key length
		 */

		switch (pstAES_Key->stKey.u32DataByteLen)
		{
		case 16:
			u32Object_id |= OID_AES_CTR_128;
			break;
		case 24:
			u32Object_id |= OID_AES_CTR_192;
			break;
		case 32:
			u32Object_id |= OID_AES_CTR_256;
			break;
		default:
			break;
		}

		/*!
		 * Step3. call AES Init
		 */
		ret = AESS1_init(u32Object_id, pstAES_Key, pstAES_Params);
		if (SSSR_SUCCESS == ret)
		{
			/*!
			 * Step4. call AES Update
			 */
			AESS1_update(pstAES_Plaintext, pstAES_Ciphertext);
		}

	}

	return ret;
}

SSS_RV sss_AES_Dec_CTR(stAES_PARAMS *pstAES_Params, const stAES_KEY *pstAES_Key,
		const stOCTET_STRING *pstAES_Ciphertext,
		stOCTET_STRING *pstAES_Plaintext)
{
	s32 ret = SSSR_SUCCESS;
	u32 u32Object_id = OID_AES_DECRYPT;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step1. Check validity of parameter
	 */
	if (pstAES_Ciphertext->u32DataByteLen == 0)
	{
		ret = ERROR_AES_INVALID_LEN_MSG;
	}
	else
	{
		/*!
		 * Step2. Assign object id according to key length
		 */

		switch (pstAES_Key->stKey.u32DataByteLen)
		{
		case 16:
			u32Object_id |= OID_AES_CTR_128;
			break;
		case 24:
			u32Object_id |= OID_AES_CTR_192;
			break;
		case 32:
			u32Object_id |= OID_AES_CTR_256;
			break;
		default:
			break;
		}


		/*!
		 * Step3. call AES Init
		 */
		ret = AESS1_init(u32Object_id, pstAES_Key, pstAES_Params);
		if (SSSR_SUCCESS == ret)
		{
			/*!
			 * Step4. call AES Update
			 */
			AESS1_update(pstAES_Ciphertext, pstAES_Plaintext);
		}
	}

	return ret;
}
/*************** END OF FILE **************************************************/

/** @} */
