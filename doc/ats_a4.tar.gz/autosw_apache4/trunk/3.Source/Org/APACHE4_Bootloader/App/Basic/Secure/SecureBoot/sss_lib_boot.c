/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_SBOOT	SSS_SBOOT
 * @ingroup SSS_Boot
 * @brief					Boot Library
 * @{
 */

/**
 * @file		sss_lib_boot.h
 * @brief		Header for secure boot library
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ************************************************/
#include "sss_lib_util.h"
#include "sss_lib_selftest.h"
#include "sss_lib_boot.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/
#define SSS_SIGN_VER	(0x00u) /* SFSB00 */
#define SSS_AUTH_TYPE	(OID_ECDSA_P256_SHA2_256|OID_AES_DECRYPT) /* ECDSA+Decryption */
#define SSS_RKEY_ROM		(0x00u)
#define SSS_RKEY_OTP		(0x01u)
#define SSS_RKEY_MAC		(0x02u) /* DECKEY Type = MAC */
/*************** Constants ****************************************************/

/*************** Prototypes ***************************************************/
static void init_header(stSFSB00_IMAGE_HEADER *pstHeader)
{
	pstHeader->u32BLSize = 0;
	pstHeader->u32NumOfSector = 0;
	pstHeader->u32SBOption = 0;
	pstHeader->u32SrcAddr = 0;
}
static void init_ctx(stSFSB00_CONTEXT *pstBootCTX)
{
	pstBootCTX->stBoot_info.u32CodeSignerVersion = 0x0;
	pstBootCTX->stBoot_info.u32RollbackCounter = 0x0;
	pstBootCTX->stBoot_info.u32AuthType = 0x0;
	pstBootCTX->stBoot_info.u32RKeyType = 0x0;

	pstBootCTX->stKey_info.u32RKeyType = 0x0;
	pstBootCTX->stKey_info.pu08Pubkey_Base = 0x0;
	pstBootCTX->stKey_info.pu08KeyTag_Base = 0x0;
	pstBootCTX->stKey_info.pu08Deckey_Base = 0x0;
	pstBootCTX->stKey_info.pu08AESIV_Base = 0x0;
}

SSS_RV sss_SecureBoot(u08 *pu08SrcAddr)
{
	u32 ret = SSSR_SUCCESS;
	u08 zu08DecKey[SFSB00_MAX_DECKEY_SIZE] =
	{ 0x0, };

	stSFSB00_IMAGE_HEADER zstHeader;
	stSFSB00_CONTEXT zstBootCTX;

	/*! > Step 0. Initialize & Check SSS HW */
	/*! - Call KAT function of Security HW (optional) */
	/* optional, can be removed */
	//ret = sss_boot_KAT();

	SB_STP_REG = 3;

	if (SSSR_SUCCESS == ret)
	{
		/*! - Initialize structure */
		init_header(&zstHeader);
		init_ctx(&zstBootCTX);
		zstBootCTX.stKey_info.pu08Deckey_Base = (u08*) zu08DecKey;

	    SB_STP_REG = 4;

		/*! - Assign Header */
		sss_memcpy_u08((u08*) &zstHeader, pu08SrcAddr,
				sizeof(stSFSB00_IMAGE_HEADER));
		zstHeader.u32SrcAddr = (u32) pu08SrcAddr;

	    SB_STP_REG = 5;

		/*! > Step 1. Check Validity */
		if (SBOOT_ENABLE == TRUE)
		{
	        SB_STP_REG = 6;

	        ret = sss_Check_Validity(&zstHeader, &zstBootCTX);
			if (SSSR_SUCCESS == ret)
			{
		        SB_STP_REG = 7;

		        /*! > Step 2. Check Authentication */
				ret = sss_Check_Authentication(&zstHeader, &zstBootCTX);
				if (SSSR_SUCCESS == ret)
				{
	                SB_STP_REG = 8;

	                /*! > Step 3. Check Confidentiality */
					ret = sss_Check_Confidentiality(&zstHeader, &zstBootCTX);
				}
			}
		}
		else
		{
            SB_STP_REG = 9;

            ret = SBOOT_ENABLE;
		}

		/*! > Step 4. Clear Key information */
		sss_memclr_u32((u32*) zu08DecKey, SFSB00_MAX_DECKEY_SIZE / 4);

		SB_STP_REG = 10;
	}
	else
	{
		ret = ERROR_BOOT_INVALID_STATUS_HW;
	}

	return ret;
}

static SSS_RV Check_HEADER(stSFSB00_IMAGE_HEADER* pstHeader)
{
	u32 ret = SSSR_SUCCESS;

	/*! > Step 1. Check OTP */
	/*! - to be modified */
	if (pstHeader->u32SBOption == FALSE)
	{
		ret |= SSSR_FAIL;
	}

	/*! > Step 1. Check Validity # of Image sector size */
	/*! - to be modified */
	if ((pstHeader->u32NumOfSector > CEIL_BY_WORD(SBOOT_IMAGE_SIZE))
			|| (pstHeader->u32NumOfSector <= 4))
	{
		ret |= SSSR_FAIL;
	}
	/*! > Step 2. ENC_BYTE_LEN */
	/*! - CBC requires multiple of 16 byte length */
	/*! - ENC_BYTE_LEN must be smaller than  u32NumOfSector */
	if ((pstHeader->u32BLSize & 0xf)
			|| (pstHeader->u32BLSize >= 4 * pstHeader->u32NumOfSector))
	{
		ret |= SSSR_FAIL;
	}

	return ret;
}

static SSS_RV Check_BOOT_INFO(stSFSB00_BOOT_INFO* pstInfo)
{
	u32 ret = SSSR_SUCCESS;

	/*! > Step 1. Check Signer Version */
	if (SSS_SIGN_VER != pstInfo->u32CodeSignerVersion)
	{
		ret |= SSSR_FAIL;
	}

#ifdef SBOOT_RBCNT
	/*! > Step 2. Check RB Counter */
	if (pstInfo->u32RollbackCounter > 32)
	{
		ret |= SSSR_FAIL;
	}
	if ((int) (SBOOT_RBCNT >> pstInfo->u32RollbackCounter) > 0)
	{
		ret |= SSSR_FAIL;
	}
#endif

	/*! > Step 3. Check Auth Type */
	if (SSS_AUTH_TYPE != pstInfo->u32AuthType)
	{
		ret |= SSSR_FAIL;
	}

	return ret;
}

static SSS_RV Check_KEY_INFO(stSFSB00_RKEY_INFO *pstInfo)
{
	u32 ret = SSSR_SUCCESS;
	stOCTET_STRING zstMessage;
	stOCTET_STRING zstKey;
	u32 *pu32temp;

	zstMessage.pu08Data = pstInfo->pu08Pubkey_Base;
	zstMessage.u32DataByteLen = SFSB00_MAX_PUBKEY_SIZE;
	zstKey.pu08Data = (u08*) SBOOT_DECKEY_MAC_BASE;
	zstKey.u32DataByteLen = SFSB00_MAX_DECKEY_SIZE;

	/*! > Step 1. Assign Checker */
	switch (pstInfo->u32RKeyType)
	{
	case SSS_RKEY_ROM:
		pstInfo->pu08KeyTag_Base = (u08*) SBOOT_PUBKEY_DIGEST_BASE;
		pu32temp = (u32*) SBOOT_DECKEY_ROM_BASE;
		break;

	case SSS_RKEY_OTP:
		pstInfo->pu08KeyTag_Base = (u08*) SBOOT_PUBKEY_DIGEST_BASE;
		pu32temp = (u32*) SBOOT_DECKEY_OTP_BASE;
		break;

	case SSS_RKEY_MAC:
		pstInfo->pu08KeyTag_Base = pstInfo->pu08Pubkey_Base
				+ SFSB00_MAX_PUBKEY_SIZE;
		pstInfo->pu08AESIV_Base += SFSB00_MAX_DECKEY_SIZE;
		pu32temp = (u32*) SBOOT_DECKEY_MAC_BASE;
		break;

	default:
		ret |= SSSR_FAIL;
		break;
	}

	/*! > Step 2. Check Key Validity */
	if (SSS_RKEY_MAC == pstInfo->u32RKeyType)
	{
		ret |= sss_HMAC_Compare(&zstKey, &zstMessage,
				(u32*) pstInfo->pu08KeyTag_Base);
	}
	else
	{
		ret |= sss_Hash_Compare(&zstMessage, (u32*) pstInfo->pu08KeyTag_Base);
	}

	if (SSSR_SUCCESS == ret)
	{
		sss_memcpy_u32((u32*) pstInfo->pu08Deckey_Base, pu32temp,
		SFSB00_MAX_DECKEY_SIZE / 4);

		if (SSS_RKEY_MAC == pstInfo->u32RKeyType)
		{
			/*! > Step 3. Get Decryption Key = MAC ^ OTP */
			sss_memxor_u32((u32*) pstInfo->pu08Deckey_Base, (u32*) pu32temp,
					(u32*) pstInfo->pu08KeyTag_Base, SFSB00_MAX_HASH_SIZE / 4);
		}
	}
	else
	{
		sss_memclr_u32((u32*) pstInfo->pu08Deckey_Base,
		SFSB00_MAX_DECKEY_SIZE / 4);
	}

	return ret;
}

SSS_RV sss_Check_Validity(stSFSB00_IMAGE_HEADER* pstHeader,
		stSFSB00_CONTEXT *pstContext)
{
	u32 ret = SSSR_FAIL;

	/*! > Step 1. Check Header */
	ret = Check_HEADER(pstHeader);
	if (SSSR_SUCCESS == ret)
	{
		/*! > Step 2. Check Boot Info */
		/*! - Assign Boot Info */
		sss_memcpy_u08((u08*) &pstContext->stBoot_info,
				(u08*) pstHeader->u32SrcAddr + sizeof(stSFSB00_IMAGE_HEADER)
						+ pstHeader->u32BLSize, sizeof(stSFSB00_BOOT_INFO));
		/*! - Check Boot Info */
		ret = Check_BOOT_INFO(&pstContext->stBoot_info);
		if (SSSR_SUCCESS == ret)
		{
			/*! > Step 3. Check Key Info */
			/*! - Assign Key Info */
			pstContext->stKey_info.u32RKeyType =
					pstContext->stBoot_info.u32RKeyType;
			pstContext->stKey_info.pu08Pubkey_Base =
					(u08*) pstHeader->u32SrcAddr + sizeof(stSFSB00_IMAGE_HEADER)
							+ pstHeader->u32BLSize + sizeof(stSFSB00_BOOT_INFO);
			pstContext->stKey_info.pu08AESIV_Base =
					pstContext->stKey_info.pu08Pubkey_Base
							+ SFSB00_MAX_PUBKEY_SIZE;
			/*! - Check Key Info */
			ret = Check_KEY_INFO(&pstContext->stKey_info);
		}
	}

	if (SSSR_SUCCESS != ret)
	{
		ret = ERROR_BOOT_INVALID_VAL_CONTEXT;
	}
	return ret;
}

SSS_RV sss_Check_Authentication(stSFSB00_IMAGE_HEADER* pstHeader,
		stSFSB00_CONTEXT *pstContext)
{
	u32 ret = SSSR_FAIL;
	stOCTET_STRING zstMsg;
	stOCTET_STRING zstDigest;
	stECC_PUBKEY zstEcdsaPubKey;
	stECDSA_SIGN zstSignature;
	u08 zu08temp[32] =
	{ 0, };

	/*! > Step 1. Get Digest */
	/*! - Assing Input */
	zstMsg.pu08Data = (u08*) pstHeader->u32SrcAddr;
	zstMsg.u32DataByteLen = sizeof(stSFSB00_IMAGE_HEADER)
			+ 4 * pstHeader->u32NumOfSector;
	zstDigest.pu08Data = zu08temp;
	/*! - Call SHA2_256 API */
	ret = sss_SHA2_256(&zstMsg, &zstDigest);

	/*! > Step 2. Check Auth Info */
	/*! - Assign Public key */
	zstEcdsaPubKey.u32KeyType = 0;
	zstEcdsaPubKey.u32EllipticCurveID = GET_ECDSA_MODE(pstContext->stBoot_info.u32AuthType);
	zstEcdsaPubKey.stBigNum_Qx.pu08Data = pstContext->stKey_info.pu08Pubkey_Base;
	zstEcdsaPubKey.stBigNum_Qx.u32DataByteLen =
			zstEcdsaPubKey.stBigNum_Qy.u32DataByteLen = SFSB00_MAX_PUBKEY_SIZE
					/ 2;
	zstEcdsaPubKey.stBigNum_Qy.pu08Data = zstEcdsaPubKey.stBigNum_Qx.pu08Data
			+ zstEcdsaPubKey.stBigNum_Qx.u32DataByteLen;
	/*! - Assign Signature */
	zstSignature.u32ECDSA_OID = zstEcdsaPubKey.u32EllipticCurveID;
	zstSignature.stSign_r.pu08Data = zstMsg.pu08Data + zstMsg.u32DataByteLen;
	zstSignature.stSign_r.u32DataByteLen = zstSignature.stSign_s.u32DataByteLen =
	SFSB00_MAX_SIGN_SIZE / 2;
	zstSignature.stSign_s.pu08Data = zstSignature.stSign_r.pu08Data
			+ zstSignature.stSign_r.u32DataByteLen;
	/*! - Call ECDSA Verify 256 API */
	ret |= sss_ECDSA_Verify_256(&zstEcdsaPubKey, &zstDigest, &zstSignature);

	if (SSSR_SUCCESS == ret)
	{
		/*! > Step 3. Update Auth Info */
		pstContext->stAuth_info.pu08DecHASH_Base = zstSignature.stSign_r.pu08Data
				+ SFSB00_MAX_SIGN_SIZE;
	}
	else
	{
		ret = ERROR_BOOT_INVALID_VAL_SIGN;
	}

	return ret;
}

SSS_RV sss_Check_Confidentiality(stSFSB00_IMAGE_HEADER* pstHeader,
		stSFSB00_CONTEXT *pstContext)
{
	u32 ret = SSSR_FAIL;

	stAES_KEY stAES_Key;
	stAES_PARAMS stAES_Param;
	stOCTET_STRING stAES_Input;
	stOCTET_STRING stAES_Cipher;

	/*! > Step 1 : Decryption */
	/*! - set Key */
	stAES_Key.stKey.pu08Data = pstContext->stKey_info.pu08Deckey_Base;
	stAES_Key.stKey.u32DataByteLen = SFSB00_MAX_DECKEY_SIZE;
	/*! - set parameter */
	stAES_Param.stIV.pu08Data = pstContext->stKey_info.pu08AESIV_Base;
	stAES_Param.stIV.u32DataByteLen = 16;
	/*! - set input */
	stAES_Cipher.pu08Data = (u08*) pstHeader->u32SrcAddr
			+ sizeof(stSFSB00_IMAGE_HEADER);
	stAES_Cipher.u32DataByteLen = pstHeader->u32BLSize;
	/*! - set output */
	stAES_Input.pu08Data = stAES_Cipher.pu08Data;
	/*! - Call CBC Decryption API */
	ret = sss_AES_Dec_CBC(&stAES_Param, &stAES_Key, &stAES_Cipher,
			&stAES_Input);

	/*! > Step 2 : Check Integrity */
	ret |= sss_Hash_Compare(&stAES_Input,
			(u32*) pstContext->stAuth_info.pu08DecHASH_Base);

	if (SSSR_SUCCESS != ret)
	{
		ret = ERROR_BOOT_INVALID_VAL_IMAGE;
		/*! > Step 3 : Clear invalid BL */
		sss_memclr_u32((u32*) pstHeader->u32SrcAddr,
				pstHeader->u32NumOfSector + sizeof(stSFSB00_IMAGE_HEADER));
	}
	return ret;
}
/*************** END OF FILE **************************************************/

/** @} */
