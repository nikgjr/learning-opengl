/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/


/**
 * @defgroup SSS_COMMON		SSS_COMMON
 * @ingroup SSS_Solution
 * @brief					Common Source (C & Head) File of SSS_Solution
 * @{
 */

/**
 * @file		sss_lib_oid.h
 * @brief		Headerfile for definition of object id
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */


#ifndef SSS_LIB_OID_H_
#define SSS_LIB_OID_H_


/*************** Include Files ************************************************/

/*************** Definitions *****************************************/
/*
 *		OID LIST 
 */
#define OID_AES_ECB				(0x00000008u)
#define OID_AES_ECB_128			(0x00100008u)
#define OID_AES_ECB_192			(0x00180008u)
#define OID_AES_ECB_256			(0x00200008u)
#define OID_AES_CBC				(0x00000108u)
#define OID_AES_CBC_128			(0x00100108u)
#define OID_AES_CBC_192			(0x00180108u)
#define OID_AES_CBC_256			(0x00200108u)
#define OID_AES_CTR				(0x00000208u)
#define OID_AES_CTR_128			(0x00100208u)
#define OID_AES_CTR_192			(0x00180208u)
#define OID_AES_CTR_256			(0x00200208u)
#define OID_AES_CCM				(0x00001008u)
#define OID_AES_CCM_128			(0x00101008u)
#define OID_AES_CCM_192			(0x00181008u)
#define OID_AES_CCM_256			(0x00201008u)
#define OID_AES_GCM				(0x00001108u)
#define OID_AES_GCM_128			(0x00101108u)
#define OID_AES_GCM_192			(0x00181108u)
#define OID_AES_GCM_256			(0x00201108u)
#define OID_AES_ENCRYPT			(0x00000000u)
#define OID_AES_DECRYPT			(0x01000000u)
#define OID_ENCRYPTION			(0x00000000u)
#define OID_DECRYPTION			(0x01000000u)


#define	OID_HMAC_SHA2_256		(0x00012300u)
#define OID_SHA2_256			(0x00002300u)



#define OID_ECC_P256				(0x00000013u)
#define OID_ECC_BP256				(0x00000053u)
#define OID_ECDSA_BP256_SHA2_256	( OID_ECC_BP256|OID_SHA2_256 )
#define OID_ECDSA_P256_SHA2_256		( OID_ECC_P256|OID_SHA2_256 )


/*************** Macros	 *****************************************/
#define GET_ECC_CURVE(OID)			((OID    )&0x07u)
#define GET_ECC_ALG(OID)			((OID>> 4)&0x0Fu)
#define Is_ECC_BP(OID)				(OID&0x40u)
#define	GET_ECDSA_MODE(OID)			(OID&0xffffu)

#define GET_HASH_SIZE(OID)			((OID>> 8)&0x07u)
#define GET_HASH_ALG(OID)			((OID>>12)&0x0Fu)

#define Is_HMAC_ALG(OID)			((OID>>16)&0x0Fu)

#define	GET_AES_MODE(OID)			(OID&0xffffu)
#define	GET_AES_SIZE(OID)			((OID>>16)&0xFFu)
#define	GET_ENC_DIRECTION(OID)		((OID>>24)&0x0Fu)


/*************** Constants ************************************************/

/*************** Variable declarations ************************************/

/*************** Error Message ********************************************/

/*************** Prototypes ***********************************************/

/*************** END OF FILE **********************************************/

#endif /* SSS_LIB_OID_H_ */

/** @} */

