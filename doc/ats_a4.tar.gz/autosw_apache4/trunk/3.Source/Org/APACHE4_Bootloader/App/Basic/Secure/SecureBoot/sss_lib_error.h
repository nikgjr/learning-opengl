/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_COMMON		SSS_COMMON
 * @ingroup SSS_Solution
 * @brief					Common Source (C & Head) File of SSS_Solution
 * @{
 */

/*!
 * @file		sss_lib_error.h
 * @brief		Header file for Error-Code
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

#ifndef SSS_LIB_ERROR_H_
#define SSS_LIB_ERROR_H_

/*************** Include Files ************************************************/

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** New Data Types ***********************************************/

/*************** Constants ****************************************************/
/**
 * @brief	Error Code of return
 *
 */
#define SSSR_SUCCESS	(0x00000000u)	/**< Success Code */
#define SSSR_FAIL		(0x00000001u)	/**< General Fail Code */

/**
 * @brief	Error Code in Target
 *
 */
#define ERR_OID									(0x01000000u)
#define ERR_MSG									(0x02000000u)
#define ERR_KEY									(0x03000000u)
#define ERR_PVKEY								(0x13000000u)
#define ERR_PBKEY								(0x23000000u)
#define ERR_MODE								(0x04000000u)
#define ERR_IV									(0x05000000u)
#define ERR_CNT									(0x06000000u)
#define ERR_SIGN								(0x07000000u)
#define ERR_BLCTX								(0xB1000000u)
#define ERR_BLBODY								(0xB2000000u)
#define ERR_BLSIGN								(0xB7000000u)
#define ERR_HW									(0xB8000000u)

/**
 * @brief	Error Code in Problem
 *
 */
#define INVALID_LEN								(0x00FF0000u)
#define INVALID_VAL								(0x00FE0000u)
#define INVALID_STATUS							(0x00FD0000u)

/**
 * @brief	Error Code in Dedicated hardware
 *
 */
#define ERROR_AES 								(0x00001000u)
#define ERROR_AES_ECB 							(0x00001100u)
#define ERROR_AES_CBC							(0x00001200u)
#define ERROR_AES_CTR 							(0x00001300u)
#define ERROR_AES_CCM 							(0x00001500u)
#define ERROR_AES_GCM 							(0x00001600u)

#define ERROR_SHA								(0x00002000u)
#define ERROR_SHA2 								(0x00002200u)

#define ERROR_HMAC 								(0x00003000u)
#define ERROR_HMAC_SHA2 						(0x00003200u)

#define ERROR_RNG 								(0x00004000u)
#define ERROR_RNG_TRNG							(0x00004100u)
#define ERROR_RNG_PRNG							(0x00004200u)
#define ERROR_RNG_PRNG_Instantiate				(0x00004300u)
#define ERROR_RNG_PRNG_Reseed					(0x00004400u)
#define ERROR_RNG_PRNG_Generate					(0x00004500u)

#define ERROR_ECC	 							(0x00006000u)
#define ERROR_ECDSA 							(0x00007000u)
#define ERROR_ECDSA_NIST_SIGN 					(0x00007100u)
#define ERROR_ECDSA_NIST_VRFY 					(0x00007110u)

#define ERROR_ECDH					 			(0x00008000u)
#define ERROR_ECDH_NIST_GEN_PARAM 				(0x00008110u)
#define ERROR_ECDH_NIST_GEN_SECRET 				(0x00008120u)

#define ERROR_BOOT		 						(0x0000B000u)

/*************** Variable declarations ****************************************/

/*************** Prototypes ***************************************************/

/*************** END OF FILE **************************************************/

#endif		/*	SSS_LIB_ERROR_H_ */

/** @} */

