/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SSP_DRV_H__
#define __SSP_DRV_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define rSSP_0_BASE                 APACHE_SPI_0_BASE
#define rSSP_1_BASE                 APACHE_SPI_1_BASE

#define rSSP_BASE(Ch)               (rSSP_0_BASE + (Ch*0x100000))


#define rSSP_CR0                    0x00        // RxTx : SPI Config Register
                                                //        - [31: 8] : Reserved
    #define bSSP_CR0_CSEN           (7)         //        -    [7] : CSN Signal Mapped
    #define bSSP_CR0_IEN            (6)         //        -    [6] : Enable Interrupt
    #define bSSP_CR0_SPH            (5)         //        -    [5] : Clock Phase
    #define bSSP_CR0_SPO            (4)         //        -    [4] : Clock Polarity
    #define bSSP_CR0_OP             (3)         //        -    [3] : Master/Slave Operation Mode
    #define bSSP_CR0_DIR            (2)         //        -    [2] : Data Direction                                     
    #define bSSP_CR0_MOD            (1)         //        -    [1] : Tx/Rx, Only Rx Mode
    #define bSSP_CR0_EN             (0)         //        -    [0] : Enable Operation


#define rSSP_CR1                    0x04        // RxTx : SPI Clock Prescale Register
                                                //        - [31:12] : Reserved
    #define bSSP_CR1_DS_MASK        (0xF<<8)    //        - [11: 8] : Transfer Byte Width SEL
    #define bSSP_CR1_BUSY           (1<<7)      //        -     [7] : Transfer is in process
                                                //        - [ 6: 4] : Reserved
    #define bSSP_CR1_CLK_MASK       (0xF<<0)    //        - [ 3: 0] : BaudRate                                                


#define rSSP_TX                     0x08        //   Tx : SPI Trensmit Data Register
                                                //        - [31:16] : Reserved
                                                //        - [15: 0] : Tx Buffer                                           
#define rSSP_RX                     0x08        // Rx   : SPI Receive Data Register
                                                //        - [31:16] : Reserved
                                                //        - [15: 0] : Rx Buffer 
                                                
#define rSSP_CLK_DIV                0x0C        // Rx   : SPI Clock Div Register
                                                //        - [31: 0] : Div Value [BaudRate = RefClk/Div, 0x02~0xFF]

#define rSSP_RX_CLR                 0x10        //   Tx : SPI RX buffer Clear
                                                //        -     [0] : SPI RX data be '0' pulse type


// SSP TimeOut - msec
#define SSP_WAIT_TIMEOUT            (500) 


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum _SSP_CH
{
    SSP_CH0 = 0,
    SSP_CH1,
    MAX_OF_SSP_CH
} eSSP_CH;

typedef enum _SSP_MODE
{
    SSP_MODE_MASTER = 0,    // Master Mode
    SSP_MODE_SLAVE          // Slave Mode
} eSSP_MODE;


typedef enum _SSP_ORDER
{
    SSP_MSB_FIRST = 0,
    SSP_LSB_FIRST
} eSSP_ORDER;


typedef enum _SSP_SPH       // Clock Phase
{
    SSP_SPH_LOW = 0,        // Catch data at falling edge
    SSP_SPH_HIGH            // Catch data at rising edge
} eSSP_SPH;


typedef enum _SSP_SPO       // Clock Polarity
{
    SSP_SPO_LOW = 0,        // Clock will remain low when SSP is in the idle state
    SSP_SPO_HIGH            // Clock will remain high when SSP is in the idle state
} eSSP_SPO;


// Data width
typedef enum _SSP_DS
{
    SSP_DS_4BIT = 3,
    SSP_DS_5BIT,
    SSP_DS_6BIT,
    SSP_DS_7BIT,
    SSP_DS_8BIT,
    SSP_DS_9BIT,
    SSP_DS_10BIT,
    SSP_DS_11BIT,
    SSP_DS_12BIT,
    SSP_DS_13BIT,
    SSP_DS_14BIT,
    SSP_DS_15BIT,
    SSP_DS_16BIT,
} eSSP_DS;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tSSP_PARAM
{
    BOOL            mIntEn;
    UINT32          mBitRate;

    eSSP_MODE       mMode;
    eSSP_DS         mDataWidth;
    eSSP_SPO        mSPO;
    eSSP_SPH        mSPH;
    eSSP_ORDER      mOrder;
} tSSP_PARAM, *ptSSP_PARAM;


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncDrv_SSP_WaitBusIsBusy(void);
extern void  ncDrv_SSP_SetDMAMode(UINT8 rwMode);
extern INT32 ncDrv_SSP_GetIntSts(eSSP_MODE Mode);
extern void  ncDrv_SSP_SetBitRate(UINT32 BitRate, UINT32 InClk);
extern INT32 ncDrv_SSP_mRead(UINT8 *pBuf, UINT32 Length);
extern INT32 ncDrv_SSP_mWrite(UINT8 *pBuf, UINT32 Length);


extern void ncDrv_SSP_CS_High(UINT32 Ch);
extern void ncDrv_SSP_CS_Low(UINT32 Ch);


#endif  /* __SSP_DRV_H__ */


/* End Of File */

