/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    :
*
*  @brief   :
*
*  @author  :
*
*  @date    : 2018.03.01
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "Apache.h"

#include "Main.h"
//#include "sss_lib_boot.h"
//#include "sss_lib_selftest.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

/* Flash Memory Map Address */

#define BACKUP_BL2_IMAGE_S_ADD      0x00001000  //
#define BACKUP_BL2_HEADER_S_ADD     0x00001000  //

#define NORMAL_BL2_IMAGE_S_ADD      0x00001000  // fixed address
#define NORMAL_BL2_HEADER_S_ADD     0x00001000  // fixed address


/* System Memory Map Address */

#define SRAM_BASE_ADDRESS           APACHE_IRAM_BASE
#define SRAM_SIZE_MAX               (64*1024)


/* Boot Option */

#define BL1_RETRY_COUNT             3


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

stBL_Header stBLHeader;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

extern UINT32 sss_boot_KAT(void);
extern UINT32 sss_boot_test(void);


/*
********************************************************************************
*               LOCAL FUNCTION DEFINITIONS
********************************************************************************
*/

void ncBL1_BOOT_DebugStepMessage(UINT8 nMsg)
{
    BL1_STP_REG = nMsg;
    DEBUGMSG(MSGINFO, "%c", nMsg);
}


void ncBL1_SetCore0_SRAMJump(void)
{
    PrVoid PC_CountReset = (PrVoid)(SRAM_BASE_ADDRESS+0x0010);   // offset header 16byte

    PC_CountReset();
}


E_BL_ERROR ncBL1_SF_GetHeader(UINT32 nAddress)
{
    UINT32 i;
    UINT8 rBuff[256] __attribute__ ((aligned (8)));
    E_BL_ERROR ret = E_NOERROR;

    DEBUGMSG(MSGINFO, "\n1.Flash memory BL2 0x%08X header read ...\n", nAddress);

#if BL_SPI_ENABLE
    if(ncSvc_SF_ReadData(nAddress, (UINT8 *)rBuff, SF_PAGE_SIZE) != NC_SUCCESS)
    {
        ret = E_ERROR_BL2_HEADER;
    }

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------\n");
    for(i = 0; i < SF_PAGE_SIZE; i++)
    {
        if(!(i % 0x10))
            DEBUGMSG(MSGINFO, "\n 0x%02X : ", i & 0xFF);
        DEBUGMSG(MSGINFO, "%02X ", rBuff[i]);
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------\n");

    stBLHeader.mImgLength    = CharToInt(&rBuff[0]);  // BL2 image length
    stBLHeader.mImgCSum      = CharToInt(&rBuff[4]);  // BL2 image checksum

    DEBUGMSG(MSGINFO, "BL2 Image Length  = 0x%08X(%d)\n", stBLHeader.mImgLength, stBLHeader.mImgLength);
    DEBUGMSG(MSGINFO, "BL2 Image CSum    = 0x%08X\n", stBLHeader.mImgCSum);
    DEBUGMSG(MSGINFO, "\n");

    if((stBLHeader.mImgLength == 0) || (stBLHeader.mImgLength > SRAM_SIZE_MAX))
    {
        DEBUGMSG(MSGERR, "Error, Flash Memory BL2 Image Length Failure\n");
        ret = E_ERROR_BL2_HEADER;
    }
    else
    {
        ret = E_NOERROR;
    }
#endif

    if(ret == E_NOERROR)
    {
        DEBUGMSG(MSGINFO, " >> Success, read flash BL2 header\n");
    }
    else
    {
        DEBUGMSG(MSGERR, " >> Failure, read flash BL2 header\n");
    }

    return ret;
}


E_BL_ERROR ncBL1_SF_GetImage(UINT32 nAddress)
{
    UINT32 i, size, retry, reSize;
    UINT32 checksum = 0;
    //UINT8 rBuff[256] __attribute__ ((aligned (8)));
    UINT8 *pBuffer;
    UINT32 *pDwBuffer;
    E_BL_ERROR ret = E_NOERROR;

    if(gtBStrap.mMode == BS_SECURE_BOOT)
    {
        nAddress += 0x10;   // Start offset of secure boot image
    }

    DEBUGMSG(MSGINFO, "\n2.Flash memory normal BL2 0x%08X image read ...\n", nAddress);

    size = Align(stBLHeader.mImgLength, 8);
    pBuffer = (UINT8 *)SRAM_BASE_ADDRESS;
    pDwBuffer = (UINT32 *)SRAM_BASE_ADDRESS;


    // read serial flash memory of area BL2 image

#if BL_SPI_ENABLE
    for(retry = 0; retry < BL1_RETRY_COUNT; retry++)
    {
        if(ncSvc_SF_ReadData(nAddress, (UINT8 *)pBuffer, size) != NC_SUCCESS)
        {
            ret = E_ERROR_BL2_IMAGE;
            break;
        }

        // 32bit checksum ...

#if BL1_CHECKSUM_ENABLE
        checksum = 0;

        if(gtBStrap.mMode == BS_SECURE_BOOT)
        {
            reSize = stBLHeader.mImgLength/4;

            for(i = 0; i < reSize; i++)
            {
                checksum += pDwBuffer[i];
            }
        }
        else
        {
            reSize = (stBLHeader.mImgLength/4)+4;

            for(i = 4; i < reSize; i++)
            {
                checksum += pDwBuffer[i];
            }
        }

        if(stBLHeader.mImgCSum == checksum)
        {
            ret = E_NOERROR;
            break;
        }
        else
        {
            DEBUGMSG(MSGERR, " Error, flash memory BL2 image download checksum failure\n");
            DEBUGMSG(MSGERR, " mImgCSum(0x%08X) vs checksum(0x%08X)\n", stBLHeader.mImgCSum, checksum);

            ret = E_ERROR_BL2_IMAGE;
        }
#else
        break;
#endif
    }
#endif

    if(ret == E_NOERROR)
    {
        DEBUGMSG(MSGINFO, " >> Success, read flash BL2 image, write SRAM\n");
    }
    else
    {
        DEBUGMSG(MSGERR, " >> Failure, read flash BL2 image, write SRAM\n");
    }

    return ret;
}


E_BL_ERROR ncBL1_FlashBootMode(void)
{
    E_BL_ERROR ret = E_NOERROR;

    ret = ncBL1_SF_GetHeader(NORMAL_BL2_HEADER_S_ADD);
    if(ret == E_ERROR_BL2_HEADER)
    {
        ncBL1_BOOT_DebugStepMessage('A');

        ret = ncBL1_SF_GetHeader(BACKUP_BL2_HEADER_S_ADD);
        if(ret == E_ERROR_BL2_HEADER)
        {
            ncBL1_BOOT_DebugStepMessage('C');
            return ret;
        }
    }

    ret = ncBL1_SF_GetImage(NORMAL_BL2_IMAGE_S_ADD);
    if(ret == E_ERROR_BL2_IMAGE)
    {
        ncBL1_BOOT_DebugStepMessage('B');

        ret = ncBL1_SF_GetImage(BACKUP_BL2_IMAGE_S_ADD);
        if(ret == E_ERROR_BL2_IMAGE)
        {
            ncBL1_BOOT_DebugStepMessage('D');
        }
    }

    return ret;
}


int main(void)
{
    UINT32 nBootStrap;
    E_BL_ERROR nErrStatus;

    BL1_VER_REG = 0;
    BL1_STP_REG = 0;
    BL1_RES_REG = 0;

    __CORE_INT_DIS();

    if(ncBL_SCU_Initialize() != NC_SUCCESS)
    {
        nErrStatus = E_ERROR_SCU_INIT;
    }

#if BL1_JTAG_BOOT_ENABLE    // test
    nBootStrap = REGRW32(rSCU_DEBUG_REG, 0x0040) & 0x0F;
    REGRW32(0x08000000, 0x00FC) = 0;

    gtBStrap.mMode      = (nBootStrap >> 3) & 0x1;
    gtBStrap.mFlashCS   = (nBootStrap >> 2) & 0x1;
    gtBStrap.mPLLConfig = (nBootStrap & 0x3);

    tSCUClk.mOSC  = OSC_CLOCK;
    tSCUClk.mCPU  = CPU_CLOCK;
    tSCUClk.mAXI  = AXI_CLOCK;
    tSCUClk.mAPB  = APB_CLOCK;
    tSCUClk.mDDR  = DDR_CLOCK;
    tSCUClk.mQSPI = QSPI_CLOCK;
#endif

#if BL_UART_ENABLE
    ncBL1_BOOT_DebugStepMessage('U');

    if(ncBL_UART_Initialize() != NC_SUCCESS)
    {
        nErrStatus = E_ERROR_UART_INIT;
    }
#endif

#if BL_SPI_ENABLE   // SSP & QSPI
    ncBL1_BOOT_DebugStepMessage('S');

    if(ncBL_SF_Initialize() != NC_SUCCESS)
    {
        nErrStatus = E_ERROR_SPI_INIT;
    }
#endif

    ncBL1_BOOT_DebugStepMessage('\n');
    ncBL1_BOOT_DebugStepMessage('B');
    ncBL1_BOOT_DebugStepMessage('L');
    ncBL1_BOOT_DebugStepMessage('1');
    ncBL1_BOOT_DebugStepMessage('\n');

    DEBUGMSG(MSGINFO, "\n\n");
    DEBUGMSG(MSGINFO, "===============================================================================\n");
    DEBUGMSG(MSGINFO, "- Apache4 Bootloader-Rom Start\n");
    DEBUGMSG(MSGINFO, "-------------------------------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "- BL1 Version: [V%d.%d.%d] [%s, %s]\n",
                      BL1_VER_MAJOR, BL1_VER_MINOR1, BL1_VER_MINOR2, BL1_BUILD_DATE, BL1_BUILD_TIME);
    DEBUGMSG(MSGINFO, "-------------------------------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, " ---- Strap Information\n");
    DEBUGMSG(MSGINFO, " Boot %s mode\n", gtBStrap.mMode?"Secure":"sFlash");
    DEBUGMSG(MSGINFO, " sFlash CS_%d\n", gtBStrap.mFlashCS);
    if(gtBStrap.mPLLConfig == 0)      DEBUGMSG(MSGINFO, " External clock mode\n");
    else if(gtBStrap.mPLLConfig == 1) DEBUGMSG(MSGINFO, " PLL min. clock Mode\n");
    else if(gtBStrap.mPLLConfig == 2) DEBUGMSG(MSGINFO, " PLL middle clock Mode\n");
    else if(gtBStrap.mPLLConfig == 3) DEBUGMSG(MSGINFO, " PLL max. clock Mode\n");
    DEBUGMSG(MSGINFO, " ---- sFlash Information\n");
    DEBUGMSG(MSGINFO, " Manufacture ID : 0x%02X\n", gtsFlashID.mManufacture);
    DEBUGMSG(MSGINFO, " Memory type ID : 0x%02X\n", gtsFlashID.mMemoryType);
    DEBUGMSG(MSGINFO, " Memory density : 0x%02X\n", gtsFlashID.mMemoryCapacity);
    DEBUGMSG(MSGINFO, " Memory size    : %d KB\n", gtsFlashID.mMemorySize/KB);
    DEBUGMSG(MSGINFO, " ---- Clock Information\n");
    DEBUGMSG(MSGINFO, " OSC = %8d, CPU = %8d, AXI = %8d, QSPI = = %8d, APB = %8d\n",
                        tSCUClk.mOSC, tSCUClk.mCPU, tSCUClk.mAXI, tSCUClk.mQSPI, tSCUClk.mAPB);
    DEBUGMSG(MSGINFO, "===============================================================================\n");
    DEBUGMSG(MSGINFO, "\n");

#if BL1_FAST_BOOT_ENABLE
    nErrStatus = E_NOERROR;
#else
    if(gtBStrap.mMode == BS_FLASH_BOOT)
    {
        ncBL1_BOOT_DebugStepMessage('0');

        nErrStatus = ncBL1_FlashBootMode();

        if(nErrStatus)
        {
            ncBL1_BOOT_DebugStepMessage('1');
        }
    }
    else    // BS_SECURE_BOOT
    {
        ncBL1_BOOT_DebugStepMessage('2');

#if BL1_SECURE_BOOT_ENABLE
        nErrStatus = ncBL1_FlashBootMode();

        if(nErrStatus)
        {
            ncBL1_BOOT_DebugStepMessage('3');
        }
        else
        {
            ncBL1_BOOT_DebugStepMessage('4');

            nErrStatus = sss_boot_test();
            DEBUGMSG(MSGINFO, "sss_boot_test(0x%08X)\n", nErrStatus);

            if(nErrStatus)
            {
                ncBL1_BOOT_DebugStepMessage('5');
            }
            else
            {
                __DCACHE_FLUSH(SRAM_BASE_ADDRESS, stBLHeader.mImgLength);
            }
        }
#endif
    }

    ncBL1_BOOT_DebugStepMessage('6');

#if BL_SPI_ENABLE   // SSP & QSPI
    ncBL_SF_IOMuxRelease();
#endif
#endif

    if(nErrStatus)
    {
        BL1_RES_REG = ('N'<<8) | ('G'<<0);  // NG
        ncBL1_BOOT_DebugStepMessage('7');
        DEBUGMSG(MSGERR, "Failure, Apache4 bootloader-rom [%d] failure\n", nErrStatus);
    }
    else
    {
        BL1_RES_REG = ('O'<<8) | ('K'<<0);  // OK
        ncBL1_BOOT_DebugStepMessage('8');
        DEBUGMSG(MSGINFO, "Success, Apache4 bootloader-rom success\n");

        ncBL1_SetCore0_SRAMJump();
    }

    ncBL1_BOOT_DebugStepMessage('9');

    return nErrStatus;
}


/* End Of File */

