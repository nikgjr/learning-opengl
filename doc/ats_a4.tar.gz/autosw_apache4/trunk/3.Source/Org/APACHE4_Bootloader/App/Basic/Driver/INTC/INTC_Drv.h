/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : INTC_Drv.h
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __INTC_DRV_H__
#define __INTC_DRV_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
 * Interrupt number value
 */
#define IRQS_START              32      // Interrupt source start number
#define IRQS_TOTAL              102     // Total interrupt source number


/*
 * CPU interrupt type value
 */
#define INTR_FIQ                0       // Group 0
#define INTR_IRQ                1       // Group 1


/*
 * GICv2 can only target up to 8 PEs
 */
#define GICV2_MAX_TARGET_PE     8

#define CPU_TARGET_IF0          0x01    // DCLS Core   - one CPU interface
#define CPU_TARGET_IF1          0x02    // DCLS Core   - two CPU interface
#define CPU_TARGET_IF2          0x04    // Single Core - three CPU interface
#define CPU_TARGET_IF3          0x08    // DSP Core    - four CPU interface
//#define CPU_TARGET_IF4          0x10    // five CPU interface
//#define CPU_TARGET_IF5          0x20    // six CPU interface
//#define CPU_TARGET_IF6          0x40    // seven CPU interface
//#define CPU_TARTET_IF7          0x80    // eight CPU interface
#define CPU_TARGET_IF02         0x05    // one & three CPU interface
#define CPU_TARGET_IF03         0x09    // one & four CPU interface
#define CPU_TARGET_IF23         0x0C    // three & four CPU interface
#define CPU_TARGET_IF023        0x0D    // one & three & four CPU interface


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum
{
    IRQ_NUM_NULL = 0,

    IRQ_NUM_SGI_0 = IRQ_NUM_NULL,
    IRQ_NUM_SGI_1,
    IRQ_NUM_SGI_2,
    IRQ_NUM_SGI_3,
    IRQ_NUM_SGI_MAX,

    // A = 0 group
    IRQ_NUM_TIMER0 = 32,    // (A+ 0)
    IRQ_NUM_TIMER1,         // (A+ 1)
    IRQ_NUM_TIMER2,         // (A+ 2)
    IRQ_NUM_TIMER3,         // (A+ 3)
    IRQ_NUM_TIMER4,         // (A+ 4)
    IRQ_NUM_TIMER5,         // (A+ 5)
    IRQ_NUM_TIMER6,         // (A+ 6)
    IRQ_NUM_TIMER7,         // (A+ 7)
    IRQ_NUM_UART0,          // (A+ 8)
    IRQ_NUM_UART1,          // (A+ 9)
    IRQ_NUM_UART2,          // (A+10)
    IRQ_NUM_UART3,          // (A+11)
    IRQ_NUM_I2C0,           // (A+12)
    IRQ_NUM_I2C1,           // (A+13)
    IRQ_NUM_SPI0,           // (A+14)
    IRQ_NUM_SPI1,           // (A+15)
    IRQ_NUM_QSPI,           // (A+16)
    IRQ_NUM_DMA_CHANNEL0,   // (A+17)
    IRQ_NUM_DMA_CHANNEL1,   // (A+18)
    IRQ_NUM_DMA_CHANNEL2,   // (A+19)
    IRQ_NUM_DMA_CHANNEL3,   // (A+20)
    IRQ_NUM_PWM0,           // (A+21)
    IRQ_NUM_PWM1,           // (A+22)
    IRQ_NUM_PWM3,           // (A+23)
    IRQ_NUM_PWM4,           // (A+24)
    IRQ_NUM_GPIO0,          // (A+25)
    IRQ_NUM_GPIO1,          // (A+26)
    IRQ_NUM_GPIO2,          // (A+27)
    IRQ_NUM_FMC,            // (A+28)
    IRQ_NUM_SDC,            // (A+29)
    IRQ_NUM_MCAN0,          // (A+30)
    IRQ_NUM_MCAN1,          // (A+31)

    // B = 32 group
    IRQ_NUM_ISP0 = 64,      // (A+32)
    IRQ_NUM_ISP1,           // (A+33)
    IRQ_NUM_ISP2,           // (A+34)
    IRQ_NUM_ISP3,           // (A+35)
    IRQ_NUM_ISP4,           // (A+36)
    IRQ_NUM_ISP5,           // (A+37)
    IRQ_NUM_ISP6,           // (A+38)
    IRQ_NUM_ISP7,           // (A+39)
    IRQ_NUM_ISP8,           // (A+40)
    IRQ_NUM_ISP9,           // (A+41)
    IRQ_NUM_VDUMP,          // (A+42)
    IRQ_NUM_DTRNG,          // (A+43)
    IRQ_NUM_AES,            // (A+44)
    IRQ_NUM_PKA0,           // (A+45)   // Done
    IRQ_NUM_PKA1,           // (A+46)   // ECC
    IRQ_NUM_PKA2,           // (A+47)   // Uncorrect
    IRQ_NUM_ADAS0,          // (A+48)
    IRQ_NUM_ADAS1,          // (A+49)
    IRQ_NUM_ADAS2,          // (A+50)
    IRQ_NUM_ADAS3,          // (A+51)
    IRQ_NUM_ADAS4,          // (A+52)
    IRQ_NUM_REV53,          // (A+53)
    IRQ_NUM_REV54,          // (A+54)
    IRQ_NUM_FAULT_SCU,      // (A+55)
    IRQ_NUM_FAULT_APRB,     // (A+56)
    IRQ_NUM_FAULT_CPRB,     // (A+57)
    IRQ_NUM_FAULT_LFT,      // (A+58)
    IRQ_NUM_FAULT_MFT,      // (A+59)
    IRQ_NUM_FAULT_PLATFORM, // (A+60)
    IRQ_NUM_FAULT_ISP,      // (A+61)
    IRQ_NUM_FAULT_RE,       // (A+62)
    IRQ_NUM_FAULT,          // (A+63)

    IRQ_NUM_IPC0,           // (A+64)
    IRQ_NUM_IPC1,           // (A+65)
    IRQ_NUM_IPC2,           // (A+66)
    IRQ_NUM_DSP_L,          // (A+67)
    IRQ_NUM_DSP_M,          // (A+68)
    IRQ_NUM_REV69,          // (A+69)
    IRQ_NUM_ISP_L,          // (A+70)
    IRQ_NUM_ISP_M,          // (A+71)
    IRQ_NUM_MCU_L,          // (A+72)
    IRQ_NUM_MCU_M,          // (A+73)
    IRQ_NUM_RE_L,           // (A+74)
    IRQ_NUM_RE_M,           // (A+75)

    MAX_IRQ_NUM,

    FIQ_NUM_NULL = MAX_IRQ_NUM,

    MAX_FIQ_NUM
} eINT_NUM;


/*
 * Enforce ARM recommendation to manage priority values such that group1 interrupts
 * always have a lower priority than group0 interrupts.
 * Note, lower numerical values are higher priorities so the comparison checks below
 * are reversed from what might be expected.
 */

typedef enum
{
    INTC_PRIO_LOW = 0xFE,
    INTC_PRIO_MIDDLE = 0xF0,
    INTC_PRIO_HIGH = 0x80,

    MAX_OF_INTC_PRIO_LEVEL
} eINTC_PRIO_LEVEL;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern void ncDrv_INTC_RegisterHandler(UINT32 nIntNum, PrHandler pHandler);
extern void ncDrv_INTC_UnRegisterHandler(UINT32 nIntNum);
extern void ncDrv_INTC_InitIntHandler(void);
extern void ncDrv_INTC_UserHandler(UINT32 nIntNum);

extern void ncDrv_INTC_HaltHandler(void);
extern void ncDrv_INTC_IrqHandler(void);
extern void ncDrv_INTC_FiqHandler(void);

extern INT32 ncDrv_INTC_Initialize(void);
extern INT32 ncDrv_INTC_Deinitialize(void);


#endif  /* __INTC_DRV_H__ */


/* End Of File */

