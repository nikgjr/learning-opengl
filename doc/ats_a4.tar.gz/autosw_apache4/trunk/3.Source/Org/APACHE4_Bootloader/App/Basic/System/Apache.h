/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 2018.03.01
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __APACHE_H__
#define __APACHE_H__


/*
********************************************************************************
*               INCLUDE                                    
********************************************************************************
*/

// Standard
//#include <string.h>
//#include <time.h>

// System
#include "Type.h"
#include "Config.h"
#include "System.h"
#include "Utility.h"

// Driver
#include "SCU_Drv.h"
#include "GICv2.h"
#include "INTC_Drv.h"
#include "QSPI_Drv.h"
#include "SSP_Drv.h"
#include "sFlash_Svc.h"
#include "Uart_Drv.h"


/*
********************************************************************************
*               MEMORY MAP FOR APACHE                             
********************************************************************************
*/

/* Storage Memory Map */

#define APACHE_IROM_BASE                0x00000000
#define APACHE_IRAM_BASE                0x04000000
#define APACHE_NAND_BASE                0x70000000
#define APACHE_DRAM_BASE                0x80000000


/* Peripheral Memory Map */

#define APACHE_SYSCON_BASE              0x08000000
#define APACHE_ICU_BASE                 0x08100000
#define APACHE_GPIO_BASE                0x08101000
#define APACHE_ADC_BASE                 0x08200000
#define APACHE_IPC_BASE                 0x0C400000
#define APACHE_INTC_BASE                0x10000000
#define APACHE_DMAC_BASE                0x10100000
#define APACHE_TIMER0_BASE              0x10300000
#define APACHE_TIMER1_BASE              0x10400000
#define APACHE_PWM_BASE                 0x10500000
#define APACHE_I2C_0_BASE               0x10600000
#define APACHE_I2C_1_BASE               0x10700000
#define APACHE_UART_0_BASE              0x10800000
#define APACHE_UART_1_BASE              0x10900000
#define APACHE_UART_2_BASE              0x10A00000
#define APACHE_UART_3_BASE              0x10B00000
#define APACHE_SPI_0_BASE               0x10C00000
#define APACHE_SPI_1_BASE               0x10D00000
#define APACHE_QSPI_BASE                0x10E00000
#define APACHE_CAN_BASE                 0x10F00000
#define APACHE_FMC_BASE                 0x12300000
#define APACHE_SDC_BASE                 0x12400000
#define APACHE_HMAC_BASE                0x12800000
#define APACHE_TRNG_BASE                0x12900000
#define APACHE_AES_BASE                 0x12A00000
#define APACHE_PKA_BASE                 0x12B00000
#define APACHE_DSP_BASE                 0x13000000
#define APACHE_ISP_BASE                 0x14800000


/* SCU Debug Register Map */

#define rSCU_DEBUG_REG                  (APACHE_SYSCON_BASE+0x1000)

#define BL1_VER_REG                     (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x0010))
#define BL1_STP_REG                     (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x0014))
#define BL1_RES_REG                     (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x0018))

#define BL2_VER_REG                     (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x0020))
#define BL2_STP_REG                     (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x0024))
#define BL2_RES_REG                     (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x0028))


/*
*******************************************************************************
*               DEFINITION FOR ARM ASM CODE SECTION                      
*******************************************************************************
*/

extern void __CORE_INT_EN(void);
extern void __CORE_INT_DIS(void);

//extern void __ENTER_CRITICAL_SECTION(void);
//extern void __EXIT_CRITICAL_SECTION(void);

extern void __DCACHE_FLUSH(UINT32 Addr, UINT32 Size);


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


#endif	/* __APACHE_H__ */


/* End Of File */

