/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_ECDSA256		SSS_ECDSA256
 * @ingroup SSS_API
 * @brief					ECDSA256 Library
 * @{
 */

/*!
 * @file		sss_api_ecdsa_256.h
 * @brief		Header for ECDSA API
 * @author		kiseok.bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

#ifndef SSS_API_ECDSA_256_H_
#define SSS_API_ECDSA_256_H_

/*************** Include Files ************************************************/
#include "sss_lib_ecdsa.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Error Message ************************************************/

/*************** Prototypes ***************************************************/
/*!
 * @brief		Ecdsa Signature Verification with digested message
 * @param[in]		pstEcdsaPubKey	pointer of verification key structure

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |u32KeyType			|Key type						|N/A						|
 |u32EllipticCurveID	|Ecc Curve id					|OID_ECDSA_P256_SHA2_256	|
 |stBigNum_Qx			|structure of x coordinate		|							|
 | - pu08Data			|pointer of octet string		|							|
 | - u32DataByteLen		|byte length of octet string	|32							|
 |stBigNum_Qy			|structure of y coordinate		|							|
 | - pu08Data			|pointer of octet string		|							|
 | - u32DataByteLen		|byte length of octet string	|32							|

 * @param[in]		pstDigest		pointer of hashed message structure (octet string)

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |pu08Data				|pointer of octet string		|							|
 |u32DataByteLen		|byte length of octet string	|32							|

 * @param[in]		pstSIGN			pointer of signature structure (octet string)

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |u32ECDSA_OID			|ECDSA id						|OID_ECDSA_P256_SHA2_256	|
 |stSign_r				|structure of sign r			|							|
 | - pu08Data			|pointer of octet string		|							|
 | - u32DataByteLen		|byte length of octet string	|32							|
 |stSign_s				|structure of sign s			|							|
 | - pu08Data			|pointer of octet string		|							|
 | - u32DataByteLen		|byte length of octet string	|32							|

 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV sss_ECDSA_Verify_256(
		stECC_PUBKEY	*pstEcdsaPubKey,
		stOCTET_STRING	*pstDigest,
		stECDSA_SIGN	*pstSIGN);

/*************** END OF FILE **************************************************/

#endif /* SSS_API_ECDSA_256_H_ */

/** @} */
