/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_AES_ECB	SSS_AES_ECB
 * @ingroup SSS_API
 * @brief					AES_ECB Library
 * @{
 */

/**
 * @file		sss_api_aes_ecb.h
 * @brief		Header for AES ECB API
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

#ifndef SSS_API_AES_ECB_H_
#define SSS_API_AES_ECB_H_

/*************** Include Files ************************************************/
#include "sss_lib_aes_s1.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ************************************************/

/*************** Variable declarations ************************************/

/*************** Error Message ********************************************/

/*************** Prototypes ***************************************************/

/**
 * @brief		AES ECB encryption
 * @param[in]	pstAES_Key			pointer of struct for AES Key

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |u32KeyType			|Key type						|N/A						|
 |stKey					|structure of AES Key			|							|
 | - pu08Data			|pointer of octet string		|							|
 | - u32DataByteLen		|byte length of octet string	|{16, 24, 32}				|

 * @param[in]	pstAES_Plaintext	pointer of struct for AES plaintext

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |pu08Data				|pointer of octet string		|							|
 |u32DataByteLen		|byte length of octet string	|0< x < 16*n				|

 * @param[out]	pstAES_Ciphertext	pointer of struct for AES ciphertext

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |pu08Data				|pointer of octet string		|							|
 |u32DataByteLen		|byte length of octet string	|0< x < 16*n				|

 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV sss_AES_Enc_ECB(const stAES_KEY *pstAES_Key,
		const stOCTET_STRING *pstAES_Plaintext,
		stOCTET_STRING *pstAES_Ciphertext);

/**
 * @brief		AES ECB decryption
 * @param[in]	pstAES_Key			pointer of struct for AES Key

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |u32KeyType			|Key type						|N/A						|
 |stKey					|structure of AES Key			|							|
 | - pu08Data			|pointer of octet string		|							|
 | - u32DataByteLen		|byte length of octet string	|{16, 24, 32}				|

 * @param[in]	pstAES_Ciphertext	pointer of struct for AES ciphertext

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |pu08Data				|pointer of octet string		|							|
 |u32DataByteLen		|byte length of octet string	|0< x < 16*n				|

 * @param[out]	pstAES_Plaintext	pointer of struct for AES plaintext

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |pu08Data				|pointer of octet string		|							|
 |u32DataByteLen		|byte length of octet string	|0< x < 16*n				|


 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV sss_AES_Dec_ECB(const stAES_KEY *pstAES_Key,
		const stOCTET_STRING *pstAES_Ciphertext,
		stOCTET_STRING *pstAES_Plaintext);
/*************** END OF FILE **************************************************/

#endif /* SSS_API_AES_ECB_H_ */

/** @} */
