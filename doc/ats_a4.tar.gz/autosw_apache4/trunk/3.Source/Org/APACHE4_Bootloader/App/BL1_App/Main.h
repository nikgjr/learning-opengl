/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 2018.03.01
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __MAIN_H__
#define __MAIN_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
 * APACHE4 Bootloader-BL1 Version
 */

#define BL1_VER_MAJOR               0
#define BL1_VER_MINOR1              3
#define BL1_VER_MINOR2              1

#define BL1_BUILD_DATE              __DATE__
#define BL1_BUILD_TIME              __TIME__


/*
 * APACHE4 Bootloader-BL1 Compile Option
 */

#if 1   // JTAG Boot

#define BL1_FAST_BOOT_ENABLE            0   // test : Only Peripheral ASIC simulation test
#define BL1_JTAG_BOOT_ENABLE            1   // test : FPGA JTAG download & debugging enable
#define BL1_SECURE_BOOT_ENABLE          1   // Samsung secure boot enable
#define BL1_CHECKSUM_ENABLE             1   // Checksum validation enable
//=============================================================================
#elif 0 // ASIC Fast Boot Simulation

#define BL1_FAST_BOOT_ENABLE            1   // test : Only Peripheral ASIC simulation test
#define BL1_JTAG_BOOT_ENABLE            0   // test : FPGA JTAG download & debugging enable
#define BL1_SECURE_BOOT_ENABLE          1   // Samsung secure boot enable
#define BL1_CHECKSUM_ENABLE             1   // Checksum validation enable
//=============================================================================
#else   // Real Boot & Post-Simulation

#define BL1_FAST_BOOT_ENABLE            0   // test : Only Peripheral ASIC simulation test
#define BL1_JTAG_BOOT_ENABLE            0   // test : FPGA JTAG download & debugging enable
#define BL1_SECURE_BOOT_ENABLE          1   // Samsung secure boot enable
#define BL1_CHECKSUM_ENABLE             1   // Checksum validation enable
//=============================================================================
#endif


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
#if 1
    UINT32 mImgLength;      // BL2 image length
    UINT32 mImgCSum;        // BL2 image checksum
    UINT32 mReserved0;      //
    UINT32 mReserved1;      //
#else
    UINT32 mSignature;      // BL2 header signature
    UINT8  mRetryCount;     // Retry count
    UINT8  mReserved0;      //
    UINT8  mReserved1;      //
    UINT8  mReserved2;      //
    UINT32 mTotalLength;    // BL2 header + image total length
    UINT32 mBUHSrcAddr;     // Backup BL2 header flash memory start address

    UINT32 mImgSrcAddr;     // BL2 flash memory source address
    UINT32 mImgDstAddr;     // BL2 system memory destination address
    UINT32 mImgLength;      // BL2 image length
    UINT32 mImgCSum;        // BL2 image checksum
#endif
} stBL_Header, *pstBL_Header;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/


#endif  /* __MAIN_H__ */


/* End Of File */

