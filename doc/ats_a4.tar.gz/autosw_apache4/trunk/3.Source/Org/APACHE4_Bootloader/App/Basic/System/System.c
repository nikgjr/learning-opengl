/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : System.c
*
*  @brief   :
*
*  @author  :
*
*  @date    : 2018.03.01
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

typedef struct
{
    UINT8   mPAD;
    UINT8   mFUNC;
    UINT8   mRegOffset;
    UINT8   mBitOffset;
} stIOList;

stIOList sFlashIOList[] =
{
    // SSPI (Single)
    {PAD_SPI2_CSN0, PAD_FUNC_4, 0x0004, 28},    // 0  // SSP_CS0
    {PAD_SPI2_CSN1, PAD_FUNC_4, 0x0008,  0},    // 1  // SSP_CS1
    {PAD_SPI2_DQ0,  PAD_FUNC_2, 0x0008,  4},    // 2  //{PAD_SPI2_DQ2,  PAD_FUNC_3, 0x0008, 12},    // 5
    {PAD_SPI2_DQ1,  PAD_FUNC_2, 0x0008,  8},    // 3  //{PAD_SPI2_DQ3,  PAD_FUNC_3, 0x0008, 16},    // 6
    {PAD_SPI2_SCK,  PAD_FUNC_2, 0x0008, 20},    // 4  //{PAD_SPI2_SCK,  PAD_FUNC_3, 0x0008, 20},    // 7

    // QSPI (Quad)
    {PAD_SPI2_CSN0, PAD_FUNC_1, 0x0004, 28},    // 5
    {PAD_SPI2_CSN1, PAD_FUNC_1, 0x0008,  0},    // 6
    {PAD_SPI2_DQ0,  PAD_FUNC_1, 0x0008,  4},    // 7
    {PAD_SPI2_DQ1,  PAD_FUNC_1, 0x0008,  8},    // 8
    {PAD_SPI2_DQ2,  PAD_FUNC_1, 0x0008, 12},    // 9
    {PAD_SPI2_DQ3,  PAD_FUNC_1, 0x0008, 16},    // 10
    {PAD_SPI2_SCK,  PAD_FUNC_1, 0x0008, 20},    // 11

    // SPI2_xx IO Release
    {PAD_SPI2_CSN0, PAD_FUNC_4, 0x0004, 28},    // 12
    {PAD_SPI2_CSN1, PAD_FUNC_4, 0x0008,  0},    // 13
    {PAD_SPI2_DQ0,  PAD_FUNC_4, 0x0008,  4},    // 14
    {PAD_SPI2_DQ1,  PAD_FUNC_4, 0x0008,  8},    // 15
    {PAD_SPI2_DQ2,  PAD_FUNC_4, 0x0008, 12},    // 16
    {PAD_SPI2_DQ3,  PAD_FUNC_4, 0x0008, 16},    // 17
    {PAD_SPI2_SCK,  PAD_FUNC_4, 0x0008, 20},    // 18
};


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

tSCU_CLK tSCUClk;
tBootStrap gtBStrap;
tsFLASH_ID gtsFlashID;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncBL_SetWaitForDone(UINT32 address, UINT32 offset, UINT32 value)
{
    UINT32 readData;
    UINT32 waitValue = 5000;
    INT32 ret = NC_SUCCESS;

#if 0
    while(waitValue)
    {
        readData = REGRW32(address, offset);
        if(readData & value)
        {
            break;
        }

        waitValue--;

        nc_mdelay(1);
    }
#else
    while(1)
    {
        readData = REGRW32(address, offset);
        if(readData & value)
        {
            break;
        }

        nc_mdelay(1);
    }
#endif

    if(waitValue == 0) ret = NC_FAILURE;

    return ret;
}


INT32 ncBL_ClearWaitForDone(UINT32 address, UINT32 offset, UINT32 value)
{
    UINT32 readData;
    UINT32 waitValue = 1000;
    INT32 ret = NC_SUCCESS;

    while(waitValue)
    {
        readData = REGRW32(address, offset);
        if((readData & value) == 0)
        {
            break;
        }

        waitValue--;

        nc_mdelay(1);
    }

    if(waitValue == 0) ret = NC_FAILURE;

    return ret;
}


INT32 ncBL_SCU_Initialize(void)
{
    UINT32 nBootStrap;
    INT32 ret = NC_SUCCESS;

    nBootStrap = 0;

    // SRAM done
    ret = ncBL_ClearWaitForDone(APACHE_SYSCON_BASE, 0x00F8, (0x1<<0));

    // DDR done
    ret = ncBL_SetWaitForDone(APACHE_SYSCON_BASE, 0x00F4, (0x1<<0));


    /*
     * clock enable & reset control
     */

    REGRW32(APACHE_SYSCON_BASE, 0x0000) |= 0x3<<12; // secure_hs, ls clock enable
    REGRW32(APACHE_SYSCON_BASE, 0x000C) |= 0xF<<8;  // secure_ip clock enable
    nc_mdelay(1);

    REGRW32(APACHE_SYSCON_BASE, 0x02BC) |= 0x1<<8;   // secure_ip reset
    REGRW32(APACHE_SYSCON_BASE, 0x02BC) |= 0x1<<9;   // secure_ip reset
    REGRW32(APACHE_SYSCON_BASE, 0x02BC) |= 0x1<<10;  // secure_ip reset

    ret |= ncBL_ClearWaitForDone(APACHE_SYSCON_BASE, 0x2BC, (0x1<<8));
    ret |= ncBL_ClearWaitForDone(APACHE_SYSCON_BASE, 0x2BC, (0x1<<9));
    ret |= ncBL_ClearWaitForDone(APACHE_SYSCON_BASE, 0x2BC, (0x1<<10));


    /*
     * get bootstrap
     */

    nBootStrap = REGRW32(APACHE_SYSCON_BASE, 0x00F0) & 0x0F;

    gtBStrap.mMode      = (nBootStrap >> 3) & 0x1;
    gtBStrap.mFlashCS   = (nBootStrap >> 2) & 0x1;
    gtBStrap.mPLLConfig = (nBootStrap & 0x3);


    /*
     * PLL setting and get clock
     *
     * PLL Configuration ...
     * 0 : OSC  27MHz
     * 1 : Low speed    (ex, CUP 200MHz)
     * 2 : Middle speed (ex, CUP 400MHz)
     * 3 : Max speed    (ex, CUP 800MHz)
     * ------------------------------------------
     * CPU 200MHz / DDR 100MHz / AXI 100MHz / APB 50MHz
     * CPU 400MHz / DDR 200MHz / AXI 200MHz / APB 100MHz
     * CPU 800MHz / DDR 400MHz / AXI 400MHz / APB 200MHz
     * ------------------------------------------
     */

    /* ToDo : gtBStrap.mPLLConfig */
    tSCUClk.mOSC  = OSC_CLOCK;
    tSCUClk.mCPU  = CPU_CLOCK;
    tSCUClk.mAXI  = AXI_CLOCK;
    tSCUClk.mAPB  = APB_CLOCK;
    tSCUClk.mDDR  = DDR_CLOCK;
    tSCUClk.mQSPI = QSPI_CLOCK;

    return ret;
}


#if BL_UART_ENABLE
INT32 ncBL_UART_Initialize(void)
{
    eUART_CH Ch = UART_CH;
    tUART_PARAM tUARTParam;
    UINT32 UartClock;
    INT32 ret = NC_SUCCESS;

    tUARTParam.mIntEn    = DISABLE;
    tUARTParam.mBaudRate = UT_BAUDRATE_115200;
    tUARTParam.mSPS      = UT_SPS_DIS;
    tUARTParam.mLEN      = UT_DATA_8BIT;
    tUARTParam.mSTP      = UT_STOP_1BIT;
    tUARTParam.mEPS      = UT_EPS_DIS;
    tUARTParam.mPEN      = UT_PARITY_DIS;
    tUARTParam.mBRK      = UT_BRK_DIS;

    ret = ncDrv_SCU_SetPinMux(PAD_UART0_TX, PAD_FUNC_1);
    UartClock = ncDrv_SCU_GetSystemClock(SCU_CLK_ID_UART);

    ncDrv_UART_Initialize(Ch, &tUARTParam, UartClock);

    return ret;
}
#endif


#if BL_SPI_ENABLE
void ncBL_SSP_SetIOMux(UINT32 Ch)
{
    UINT32 i;
    UINT8 Func, RegOff, BitOff;
    UINT32 resdValue;

    if(Ch == SSP_CH0)
    {
        // gpio
        REGRW32(APACHE_GPIO_BASE, 0x0004) |= (1<<15);   // output, PAD_SPI2_CSN0
        REGRW32(APACHE_GPIO_BASE, 0x0008) |= (1<<15);   // high
    }
    else if(Ch == SSP_CH1)
    {
        // gpio
        REGRW32(APACHE_GPIO_BASE, 0x0004) |= (1<<16);   // output, PAD_SPI2_CSN1
        REGRW32(APACHE_GPIO_BASE, 0x0008) |= (1<<16);   // high
    }

    // mux
    for(i = 0; i < 5; i++)
    {
        //Pad    = sFlashIOList[i].mPAD;
        Func   = sFlashIOList[i].mFUNC;
        RegOff = sFlashIOList[i].mRegOffset;
        BitOff = sFlashIOList[i].mBitOffset;

        resdValue = REGRW32(APACHE_ICU_BASE, RegOff);
        resdValue &= ~(0xF<<BitOff);

        REGRW32(APACHE_ICU_BASE, RegOff) = (resdValue | (Func<<BitOff));
    }
}


void ncBL_QSPI_SetIOMux(UINT32 Ch)
{
    UINT8 i;
    UINT8 Func, RegOff, BitOff;
    UINT32 resdValue;

    for(i = 5; i < 12; i++)
    {
        //Pad    = sFlashIOList[i].mPAD;
        Func   = sFlashIOList[i].mFUNC;
        RegOff = sFlashIOList[i].mRegOffset;
        BitOff = sFlashIOList[i].mBitOffset;

        resdValue = REGRW32(APACHE_ICU_BASE, RegOff);
        resdValue &= ~(0xF<<BitOff);

        REGRW32(APACHE_ICU_BASE, RegOff) = (resdValue | (Func<<BitOff));
    }
}


void ncBL_SF_IOMuxRelease(void)
{
    UINT8 i;
    UINT8 Func, RegOff, BitOff;
    UINT32 resdValue;

    for(i = 12; i < 19; i++)
    {
        //Pad    = sFlashIOList[i].mPAD;
        Func   = sFlashIOList[i].mFUNC;
        RegOff = sFlashIOList[i].mRegOffset;
        BitOff = sFlashIOList[i].mBitOffset;

        resdValue = REGRW32(APACHE_ICU_BASE, RegOff);
        resdValue &= ~(0xF<<BitOff);

        REGRW32(APACHE_ICU_BASE, RegOff) = (resdValue | (Func<<BitOff));
        REGRW32(APACHE_GPIO_BASE, 0x0004) &= ~(0x7F<<15);   // PAD_SPI2_XX 7-pin GPIO input
    }
}


INT32 ncBL_SF_Initialize(void)
{
    UINT32 i = 2;
    tSF_PARAM  tSFParam;
    tSFLASH_ID tFlashID;
    INT32 ret = NC_SUCCESS;

    // sFlash Operation Mode
    tSFParam.mSpiCS     = gtBStrap.mFlashCS;
    tSFParam.mQuadMode  = TRUE;
    tSFParam.mBitRate   = tSCUClk.mAPB/2;

    while(1)
    {
        i++;
        ret = ncSvc_SF_Init(&tSFParam);

        // Copy sFlash Ctrl Info.
        tSF_Info = tSFParam;

        ret = ncSvc_SF_ReadDeviceIdentification(&tFlashID);

        if(tFlashID.mbManufacture != 0xFF)
        {
            break;
        }
        else
        {
            tSFParam.mBitRate = tSCUClk.mAPB/i;
        }
    }

    gtsFlashID.mManufacture = tFlashID.mbManufacture;
    gtsFlashID.mMemoryType = tFlashID.mbMemoryType;
    gtsFlashID.mMemoryCapacity = tFlashID.mbMemoryCapacity;
    gtsFlashID.mMemorySize = 64*KB;

    for(i = MEMORY_CAPACITY_512Kb; i <= MEMORY_CAPACITY_128Mb; i++)
    {
        if((gtsFlashID.mMemoryCapacity&0xF) == i)
        {
            break;
        }
        else
        {
            gtsFlashID.mMemorySize = gtsFlashID.mMemorySize * 2;
        }
    }

    // Set QSPI Bitrate
    tSF_Info.mBitRate = tSCUClk.mQSPI/2;
    ncDrv_QSPI_SetBitRate((UINT32)tSF_Info.mBitRate, tSCUClk.mQSPI);

    // Set Sflash QSPI Mode
    ncSvc_SF_QSPIEnable(tSF_Info.mQuadMode);
    if(tSF_Info.mQuadMode)
    {
        ncBL_QSPI_SetIOMux(tSFParam.mSpiCS);
    }
    else
    {
        tSFParam.mQuadMode = FALSE;
    }

    return ret;
}
#endif


UINT32 nc_get_tick(UINT32 cls)
{
    if(cls)
    {
        // Clear : Count == 0
        REGRW32(APACHE_SYSCON_BASE, 0x3000) = 0x0;
    }

    return REGRW32(APACHE_SYSCON_BASE, 0x3000);
}


void nc_wait_tick(UINT32 ticks)
{
    UINT32 sTicks = nc_get_tick(1);

    while ((nc_get_tick(0) - sTicks) < ticks);
}


void nc_mdelay(UINT32 ms)
{
    // limit 10-sec
    if(ms > 10000) ms = 10000;

    nc_wait_tick((tSCUClk.mAPB / MSEC) * ms);
}


void nc_udelay(UINT32 us)
{
    // limit 10-sec
    if(us > 10000000) us = 10000000;

    nc_wait_tick((tSCUClk.mAPB / USEC) * us);
}


unsigned int nc_get_msec(UINT32 cls)
{
    UINT32 curr_tick = nc_get_tick(cls);

    if(curr_tick)
        curr_tick = curr_tick / (tSCUClk.mAPB / MSEC);

    return curr_tick;
}


/* End Of File */

