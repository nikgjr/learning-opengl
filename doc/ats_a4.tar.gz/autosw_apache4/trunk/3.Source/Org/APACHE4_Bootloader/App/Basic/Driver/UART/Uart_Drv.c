/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#if BL_UART_ENABLE

#include <stdarg.h>
#include <stdio.h>


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

UINT32 gDebugZone = 0;


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncDrv_UART_PutChar(eUART_CH Ch, UINT8 Data)
{
    UINT32 Reg;

    do 
    {
        Reg = REGRW32(rUART_BASE(Ch), rUART_LSR);
    } while ((Reg & bUART_LSR_THRE) != bUART_LSR_THRE);

    // Data Write
	REGRW32(rUART_BASE(Ch), rUART_TX) = Data;

    // WAIT_FOR_XMITR
    do 
    {
        Reg = REGRW32(rUART_BASE(Ch), rUART_LSR);
    } while ((Reg & (bUART_LSR_TEMT | bUART_LSR_THRE)) != (bUART_LSR_TEMT | bUART_LSR_THRE));
}


INT32 ncDrv_UART_GetFIFOCnt(eUART_CH Ch)
{
    UINT32 Reg;

    // Rx FIFO count    
    Reg = (REGRW32(rUART_BASE(Ch), rUART_RC)&bUART_RC_MASK);

    return Reg;
}


#if 0 // alessio
INT32 ncDrv_UART_GetSts(eUART_CH Ch)
{
    UINT32 Reg;

    // Interrupt Stats
    Reg = REGRW32(rUART_BASE(Ch), rUART_IIR)&0xff;

    return Reg;
}


INT8 ncDrv_UART_GetChar(eUART_CH Ch)
{
    if((REGRW32(rUART_BASE(Ch), rUART_LSR) & bUART_LSR_DR) == bUART_LSR_DR)
    {
        return (INT8)REGRW32(rUART_BASE(Ch), rUART_RX);
    }
    else
    {
        return -1;
    }
}
#endif


void ncDrv_UART_PutStr(eUART_CH Ch, char *str)
{
    char prev = 0x0;

    while(*str)
    {
        if(*str == '\n' && prev != '\r') ncDrv_UART_PutChar(Ch, '\r');

        ncDrv_UART_PutChar(Ch, *str);

        prev = *str++;
    }
}


void ncDrv_UART_SetBaudrate(eUART_CH Ch, UINT32 RefClk, UINT32 BaudRate)
{
    UINT32 Reg;
    UINT32 DIV;

    // open divisor latch
    Reg = (REGRW32(rUART_BASE(Ch), rUART_LCR) | bUART_LCR_DLAB);
    REGRW32(rUART_BASE(Ch), rUART_LCR) = Reg;

    // set divisor latch
    DIV = RefClk/(16 * BaudRate);
    REGRW32(rUART_BASE(Ch), rUART_DLL) = (DIV>>0)&0xff;
    REGRW32(rUART_BASE(Ch), rUART_DLM) = (DIV>>8)&0xff;

    // close divisor latch
    Reg = (REGRW32(rUART_BASE(Ch), rUART_LCR) & ~(bUART_LCR_DLAB));
    REGRW32(rUART_BASE(Ch), rUART_LCR) = Reg;
}


#if 0 // alessio
void ncDrv_UART_Deinitialize(eUART_CH Ch)
{
    REGRW32(rUART_BASE(Ch), rUART_FCR) = bUART_FCR_CLEAR_RCVR|bUART_FCR_CLEAR_XMIT;
    REGRW32(rUART_BASE(Ch), rUART_IER) = 0x0;
    REGRW32(rUART_BASE(Ch), rUART_EN)  = OFF;
}
#endif


void ncDrv_UART_Initialize(eUART_CH Ch, tUART_PARAM *ptUART, UINT32 RefClk)
{
    // Disable UART
    REGRW32(rUART_BASE(Ch), rUART_EN) = OFF;

    // Reset receiver and transmitter
    REGRW32(rUART_BASE(Ch), rUART_FCR) = (bUART_FCR_CLEAR_RCVR|bUART_FCR_CLEAR_XMIT|bUART_FCR_TRIGGER_14);

    // Set Interrupt Disable
#if 0 // alessio
    if(ptUART->mIntEn == ENABLE)
        REGRW32(rUART_BASE(Ch), rUART_IER) = (bUART_IER_RLSI|bUART_IER_TX|bUART_IER_RX);
    else
#endif
        REGRW32(rUART_BASE(Ch), rUART_IER) = 0x0;

    // Set 8 bit char, 1 stop bit, no parity */
    REGRW32(rUART_BASE(Ch), rUART_LCR) = (ptUART->mBRK|ptUART->mSPS|ptUART->mEPS|ptUART->mPEN|ptUART->mSTP|ptUART->mLEN);

    // Set baud rate
    ncDrv_UART_SetBaudrate(Ch, RefClk, ptUART->mBaudRate);

    // Enable UART
    REGRW32(rUART_BASE(Ch), rUART_EN) = ON;

    gDebugZone = 1;
}


void ncDrv_UART_Printf(UINT32 DebugZone, const char *fmt, ...)
{
    va_list vList;
    char Buff[512];
    eUART_CH Ch = UART_CH;

    if(DebugZone && gDebugZone)
    {
        if(DebugZone&MSGERR)  ncDrv_UART_PutStr(Ch, STR_COLOR_RED_ON);
        if(DebugZone&MSGWARN) ncDrv_UART_PutStr(Ch, STR_COLOR_YELLOW_ON);

        va_start(vList, fmt);

        vsnprintf(Buff, sizeof(Buff), fmt, vList);

        va_end(vList);

        ncDrv_UART_PutStr(Ch, Buff);

        if((DebugZone&MSGERR) || (DebugZone&MSGWARN))
        {
            ncDrv_UART_PutStr(Ch, STR_COLOR_OFF);
        }
    }
}


#endif  /* BL_UART_ENABLE */


/* End Of File */

