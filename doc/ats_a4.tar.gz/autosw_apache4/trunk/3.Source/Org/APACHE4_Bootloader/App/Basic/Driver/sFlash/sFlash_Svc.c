/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*              INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#if BL_SPI_ENABLE


/*
********************************************************************************
*              DEFINES
********************************************************************************
*/

#define CMD_sFLASH_WR_EN                        0x06
#define CMD_sFLASH_WR_DS                        0x04
#define CMD_sFLASH_RD_STS                       0x05
#define CMD_sFLASH_RD_STS2                      0x35		// for WINBOND SPI Flash
#define CMD_sFLASH_WR_STS                       0x01
#define CMD_sFLASH_RD_DATA                      0x03
#define CMD_sFLASH_PAGE_PROGRAM                 0x02
#define CMD_sFLASH_SECTOR_ERASE                 0x20
#define CMD_sFLASH_BLOCK_ERASE                  0xD8
#define CMD_sFLASH_RD_IDENTIFICATION            0x9F

#define STS_WIP                                 (0x1<<0)
#define STS_WEL                                 (0x1<<1)

#define FLASH_ID_WINBOND                        (0xEF)
#define FLASH_ID_EON                            (0x1C)
#define FLASH_ID_MXIC                           (0xC2)
#define FLASH_ID_MICRON                         (0x20)
#define FLASH_ID_SPANSION                       (0xEF)

#define BP0                                     (1<<2)
#define BP1                                     (1<<3)
#define BP2                                     (1<<4)
#define BP3                                     (1<<5)

#define SF_DMA_TIME_OUT                         100        // 100mSec


/*
********************************************************************************
*              GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

volatile tSF_PARAM tSF_Info;

#if 0 // alessio
typedef struct
{
    BOOL       mSSP_ChInit;
    eSSP_MODE  mSSP_Mode;
    eSSP_DS    mSSP_DataWidth;
} tSSP_INFO, *ptSSP_INFO;
tSSP_INFO gtSSP[MAX_OF_SSP_CH];
#endif


/*
********************************************************************************
*              FUNCTION DEFINITIONS
********************************************************************************
*/

BOOL ncSvc_SF_mTimeOut(UINT32 mSec)
{
    BOOL ret = FALSE;       
    static volatile UINT32 s_SF_TimeOutMsec = 0;  

    if(mSec > 0)
    {
        if(s_SF_TimeOutMsec == 0)
        {
            // Set TimeOut : SystemTick(msec) + TargetMsec;
            s_SF_TimeOutMsec = nc_get_msec(1) + mSec;
        }
        else
        {
            // Timeout Check. 
            if( nc_get_msec(0) > s_SF_TimeOutMsec)
            {
                ret = TRUE;
                s_SF_TimeOutMsec = 0;
            }
        }
    }
    else
    {
        s_SF_TimeOutMsec = 0;
    }
    
    return ret;
}



void ncSvc_SF_QSPIEnable(BOOL OnOff)
{
    tSFLASH_ID tsFlashID;
    UINT8 Status1;
    UINT8 Status2;

    ncSvc_SF_ReadDeviceIdentification(&tsFlashID);

    if(OnOff)
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status2 = ncSvc_SF_ReadStatus2();

            if( !(Status2 & (1<<1)) )
            {
                ncSvc_SF_WriteStatus2(Status1, Status2|(1<<1));
            }
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            if( !(Status1 & (1<<6)) )
            {
                ncSvc_SF_WriteStatus(Status1|(1<<6));
            }
        }
        else
        {
            tSF_Info.mQuadMode = FALSE;
        }
    }
    else
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status2 = ncSvc_SF_ReadStatus2();

            if( (Status2 & (1<<1)) )
            {
                Status2 &= (~1<<1);
                ncSvc_SF_WriteStatus2(Status1, Status2);
            }
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            if( (Status1 & (1<<6)) )
            {
                Status1 &= ~(1<<6);
                ncSvc_SF_WriteStatus(Status1);
            }
        }
    } 
}


void ncSvc_SF_WaitWIP(void)
{
    while(ncSvc_SF_ReadStatus() & STS_WIP) ;
}


void ncSvc_SF_WriteEnable(void)
{
    UINT8 Command;

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_Low(tSF_Info.mSpiCS);

    Command = CMD_sFLASH_WR_EN;
    ncDrv_SSP_mWrite(&Command, 1);

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_High(tSF_Info.mSpiCS);

    while( (ncSvc_SF_ReadStatus() & STS_WEL) != STS_WEL  ) ;
}


void ncSvc_SF_WriteDisable(void)
{
    UINT8 Command;

    while( ncSvc_SF_ReadStatus() & STS_WIP  ) ;

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_Low(tSF_Info.mSpiCS);

    Command = CMD_sFLASH_WR_DS;
    ncDrv_SSP_mWrite(&Command, 1);

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_High(tSF_Info.mSpiCS);
}


UINT8 ncSvc_SF_ReadStatus(void)
{
    UINT8 Command;
    UINT8 Status = 0;

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_Low(tSF_Info.mSpiCS);

    Command = CMD_sFLASH_RD_STS;
    ncDrv_SSP_mWrite(&Command, 1);
    ncDrv_SSP_mRead(&Status, 1);

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_High(tSF_Info.mSpiCS);

    return Status;
}


UINT8 ncSvc_SF_ReadStatus2(void)
{
    UINT8 Command;
    UINT8 Status = 0;

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_Low(tSF_Info.mSpiCS);

    Command = CMD_sFLASH_RD_STS2;
    ncDrv_SSP_mWrite(&Command, 1);
    ncDrv_SSP_mRead(&Status, 1);

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_High(tSF_Info.mSpiCS);

    return Status;
}


void ncSvc_SF_WriteStatus(UINT8 Status)
{
    UINT8 Command[2];

    ncSvc_SF_WriteEnable();

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_Low(tSF_Info.mSpiCS);

    Command[0] = CMD_sFLASH_WR_STS;
    Command[1] = Status;
    ncDrv_SSP_mWrite(Command, 2);

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_High(tSF_Info.mSpiCS);

    ncSvc_SF_WriteDisable();
}


void ncSvc_SF_WriteStatus2(UINT8 Status1, UINT8 Status2)
{
    UINT8 Command[3];

    ncSvc_SF_WriteEnable();

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_Low(tSF_Info.mSpiCS);

    Command[0] = CMD_sFLASH_WR_STS;
    Command[1] = Status1;
    Command[2] = Status2;	
    ncDrv_SSP_mWrite(Command, 3);

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_High(tSF_Info.mSpiCS);

    ncSvc_SF_WriteDisable();
}


INT32 ncSvc_SF_ReadDeviceIdentification(ptSFLASH_ID ptsFlashID)
{
    UINT8 Command;
    INT32 ret = NC_SUCCESS;

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_Low(tSF_Info.mSpiCS);

    Command = CMD_sFLASH_RD_IDENTIFICATION;
    ret = ncDrv_SSP_mWrite(&Command, 1);
    ret |= ncDrv_SSP_mRead((UINT8*)ptsFlashID, 3);

    ret |= ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_High(tSF_Info.mSpiCS);

    return ret;
}


INT32 ncSvc_SF_ReadData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    INT32 Ret = NC_SUCCESS;
    UINT8 Command[4];


    if((tSF_Info.mQuadMode == TRUE) && !(Size%8))   // Quad SPI 64bit Align      
    {
        // Data Read
        Ret = ncDrv_QSPI_ReadData(ON, Addr, (UINT32)pData, Size);
    }
    else
    {
        ncDrv_SSP_WaitBusIsBusy();
        ncDrv_SSP_CS_Low(tSF_Info.mSpiCS);

        Command[0] = CMD_sFLASH_RD_DATA;
        Command[1] = (Addr>>16 & 0xFF);
        Command[2] = (Addr>>8  & 0xFF);
        Command[3] = (Addr     & 0xFF);
        ncDrv_SSP_mWrite(Command, 4);
        Ret = ncDrv_SSP_mRead(pData, Size);

        ncDrv_SSP_WaitBusIsBusy();
        ncDrv_SSP_CS_High(tSF_Info.mSpiCS);
    }

    return Ret;
}


INT32 ncSvc_SF_WriteData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();


    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_Low(tSF_Info.mSpiCS);

    Command[0] = CMD_sFLASH_PAGE_PROGRAM;
    Command[1] = (Addr>>16 & 0xFF);
    Command[2] = (Addr>>8  & 0xFF);
    Command[3] = (Addr     & 0xFF);
    ncDrv_SSP_mWrite(Command, 4);
    ncDrv_SSP_mWrite(pData, Size);

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_High(tSF_Info.mSpiCS);


    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}


INT32 ncSvc_SF_SectorErase(UINT32 PageAddr)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_Low(tSF_Info.mSpiCS);

    Command[0] = CMD_sFLASH_SECTOR_ERASE;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);
    ncDrv_SSP_mWrite(Command, 4);

    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_SSP_CS_High(tSF_Info.mSpiCS);

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}


void ncSvc_SF_EnableWP(BOOL OnOff)
{
    tSFLASH_ID tsFlashID;
    UINT8 Status1;
    UINT8 Status2;
    UINT8 protection = BP3|BP2|BP1|BP0;

    ncSvc_SF_ReadDeviceIdentification(&tsFlashID);

    if(OnOff)
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            protection = (BP2|BP1|BP0);
            Status1 = ncSvc_SF_ReadStatus();
            Status2 = ncSvc_SF_ReadStatus2();
            Status1 |= protection;
            ncSvc_SF_WriteStatus2(Status1, Status2);
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status1 |= protection;
            ncSvc_SF_WriteStatus(Status1);
        }
    }
    else
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            protection = (BP2|BP1|BP0);
            Status1 = ncSvc_SF_ReadStatus();
            Status2 = ncSvc_SF_ReadStatus2();
            Status1 &= ~(protection);
            ncSvc_SF_WriteStatus2(Status1, Status2);
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status1 &= ~(protection);
            ncSvc_SF_WriteStatus(Status1);
        }
    }
}


INT32 ncSvc_SF_Init(ptSF_PARAM ptSFParam)
{
    INT32 Ret = NC_SUCCESS;
    UINT32 Reg;

    // Disable SSP and Clear, CR1 Clear
    REGRW32(APACHE_SPI_0_BASE, rSSP_CR0) = 0x0;
    REGRW32(APACHE_SPI_0_BASE, rSSP_CR1) = 0x0;

    // Set pin mux
    ncBL_SSP_SetIOMux(ptSFParam->mSpiCS);

    // SSP Bitrate
    ncDrv_SSP_SetBitRate(ptSFParam->mBitRate, tSCUClk.mAPB);

    // Set Data Width
    Reg = REGRW32(APACHE_SPI_0_BASE, rSSP_CR1);
    Reg &= ~bSSP_CR1_DS_MASK;
    Reg |= (SSP_DS_8BIT<<8);
    REGRW32(APACHE_SPI_0_BASE, rSSP_CR1) = Reg;

    // Set Operation and Enable SSP
    Reg = (0<<bSSP_CR0_CSEN)
        | (FALSE<<bSSP_CR0_IEN)
        | (SSP_SPH_HIGH<<bSSP_CR0_SPH)
        | (SSP_SPO_HIGH<<bSSP_CR0_SPO)
        | (SSP_MODE_MASTER<<bSSP_CR0_OP)
        | (SSP_MSB_FIRST<<bSSP_CR0_DIR)
        | (1<<bSSP_CR0_MOD)
        | (1<<bSSP_CR0_EN);
    REGRW32(APACHE_SPI_0_BASE, rSSP_CR0) = Reg;

    // CS high default
    ncDrv_SSP_CS_High(ptSFParam->mSpiCS);

    return Ret;
}



#endif  /* BL_SPI_ENABLE */


/* End Of File */

