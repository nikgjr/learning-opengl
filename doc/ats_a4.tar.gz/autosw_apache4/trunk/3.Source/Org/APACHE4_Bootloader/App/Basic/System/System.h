/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : System.h
*
*  @brief   :
*
*  @author  :
*
*  @date    : 2018.03.01
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __SYSTEM_H__
#define __SYSTEM_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
 * APACHE4 Strap Option
 */
#if 0
// simulation only mode
#define BS_RESERVED4                    (0x00<<6)
#define BS_SRAM_BOOT                    (0x01<<6)
#define BS_DDR_WBD_BOOT                 (0x02<<6)   // winbond boot
#define BS_DDR_RTL_BOOT                 (0x03<<6)

// reserved
#define BS_RESERVED3                    (0x00<<4)
#define BS_RESERVED2                    (0x01<<4)
#define BS_RESERVED1                    (0x02<<4)
#define BS_RESERVED0                    (0x03<<4)
#endif

// flash memory mode
#define BIT_BS_SECURE_BOOT              (0x01<<3)
#define BIT_BS_FLASH_BOOT               (0x00<<3)
#define BS_SECURE_BOOT                  (0x01)
#define BS_FLASH_BOOT                   (0x00)

// flash csn mode
#define BIT_BS_SPI_CSN_1                (0x01<<2)
#define BIT_BS_SPI_CSN_0                (0x00<<2)
#define BS_SPI_CSN_1                    (0x01)
#define BS_SPI_CSN_0                    (0x00)

// clock mode
#define BIT_BS_PLL3_MAX_CLOCK           (0x11<<0)   // max speed
#define BIT_BS_PLL2_MID_CLOCK           (0x10<<0)   // middle speed
#define BIT_BS_PLL1_MIN_CLOCK           (0x01<<0)   // min speed
#define BIT_BS_PLL0_OSC                 (0x00<<0)   // external clock
#define BS_PLL3_MAX_CLOCK               (0x11)
#define BS_PLL2_MID_CLOCK               (0x10)
#define BS_PLL1_MIN_CLOCK               (0x01)
#define BS_PLL0_OSC                     (0x00)


/*
 * APACHE4 SPI & UART Channel Option
 */

#define SPI_CH              SSP_CH0     // default
#define UART_CH             UART_CH0    // default


/*
 * APACHE4 Clock Option
 */

#define OSC_CLOCK           (27*MHZ)    // Input clock
#define CPU_CLOCK           (50*MHZ)    // ARM clock
#define AXI_CLOCK           (50*MHZ)    // High speed bus clock
#define APB_CLOCK           (25*MHZ)    // Low speed bus clock
#define DDR_CLOCK           (64*MHZ)    // DDR memory clock
#define QSPI_CLOCK          (25*MHZ)    // QSPI clock


/*
 * APACHE4 UART Debugging Message Macro
 */

#define MSGERR              (0x1<<0)    // Error message enable
#define MSGWARN             (0x1<<1)    // Warning message enable
#define MSGINFO             (0x1<<2)    // Information message enable
#define MSGOFF              (0x0<<0)

#if BL_UART_ENABLE

#define DEBUGMSG(zone, fmt, args...)  \
        do { if(zone) ncDrv_UART_Printf(zone, fmt, ## args); } while(0)

#else

#define DEBUGMSG(zone, fmt, args...)

#endif


// Align Macro

#define Align(a, b)                 (((a) + (b-1)) & ~(b-1))


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/
typedef enum
{
    E_CORE_NONE     = 0,
    E_CORE_DLS      = 0x01,
    E_CORE_SINGLE   = 0x10,
    E_CORE_DUAL     = 0x11,    // Only ARM core DLS and Single Core

    NUM_OF_CORE_RUN = 0x1000
} E_CORE_RUN;


typedef enum
{
    E_IMG_FIRST_HEADER,
    E_IMG_FIRST_IMAGE,

    E_IMG_SECOND_HEADER,
    E_IMG_SECOND_IMAGE,

    //E_IMG_THIRD_HEADER,
    //E_IMG_THIRD_IMAGE,

    NUM_OF_IMG_BACKUP_STEP
} E_IMG_BACKUP_STEP;


typedef enum
{
    E_NOERROR = 0,

    E_ERROR_BL2_HEADER,
    E_ERROR_BL2_IMAGE,

    E_ERROR_APP0_HEADER,
    E_ERROR_APP0_IMAGE,

    E_ERROR_APP1_HEADER,
    E_ERROR_APP1_IMAGE,

    E_ERROR_SCU_INIT,
    E_ERROR_SPI_INIT,
    E_ERROR_UART_INIT,

    E_ERROR_SECURE_INIT,

    NUM_OF_BL_ERROR
} E_BL_ERROR;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT8 mMode;
    UINT8 mFlashCS;
    UINT8 mPLLConfig;
    UINT8 Reserved;
} tBootStrap, *ptBootStrap;

typedef struct
{
    UINT32 OSC;     // OSC clock
    UINT32 CPU;     // CPU clock
    UINT32 AXI;     // AXI clock
    UINT32 APB;     // APB clock
} tClock, *ptClock;

typedef struct
{
    UINT8   mManufacture;       // Manufacture ID
    UINT8   mMemoryType;        // Memory Type
    UINT8   mMemoryCapacity;    // Memory Capacity
    UINT32  mMemorySize;        // Memory Size
} tsFLASH_ID, *ptsFLASH_ID;

typedef struct _tSUC_CLK
{
    UINT32      mOSC;
    UINT32      mCPU;
    UINT32      mAXI;
    UINT32      mAPB;
    UINT32      mDDR;
    UINT32      mQSPI;
} tSCU_CLK, *ptSCU_CLK;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

extern tSCU_CLK tSCUClk;
extern tBootStrap gtBStrap;
extern tsFLASH_ID gtsFlashID;


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern void  ncDrv_UART_Printf(UINT32 DebugZone, const char *fmt, ...);

extern INT32 ncBL_SCU_Initialize(void);

extern INT32 ncBL_UART_Initialize(void);

extern void ncBL_SSP_SetIOMux(UINT32 Ch);
extern void ncBL_QSPI_SetIOMux(UINT32 Ch);
extern void ncBL_SF_IOMuxRelease(void);
extern INT32 ncBL_SF_Initialize(void);

extern void nc_mdelay(UINT32 ms);
extern void nc_udelay(UINT32 us);
extern unsigned int nc_get_msec(UINT32 cls);


#endif  /* __SYSTEM_H__ */


/* End Of File */

