/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_HMAC2_256	SSS_HMAC_256
 * @ingroup SSS_API
 * @brief					HMAC SHA2_256 Library
 * @{
 */

/**
 * @file		sss_api_hmac_256.h
 * @brief		Header for HMAC_SHA2 API
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

#ifndef SSS_API_HMAC_256_H_
#define SSS_API_HMAC_256_H_

/*************** Include Files ************************************************/
#include "sss_lib_hmac_sha256.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ************************************************/

/*************** Variable declarations ************************************/

/*************** Error Message ********************************************/

/*************** Prototypes ***************************************************/

/**
 * @brief		hash digest function consisting init, update, and final
 * @param[in]	pstHMACKey	pointer of struct for input hmac key
 *
 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |pu08Data				|pointer of octet string		|							|
 |u32DataByteLen		|byte length of octet string	|(0< x < 64)				|

  * @param[in]	pstMessage	pointer of struct for input message

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |pu08Data				|pointer of octet string		|							|
 |u32DataByteLen		|byte length of octet string	|(0< x < 2^32)				|

 * @param[out]	pstDigest	pointer of struct for output digest

 |Name					|Description					|Variables					|
 |----------------------|-------------------------------|---------------------------|
 |pu08Data				|pointer of octet string		|							|
 |u32DataByteLen		|byte length of octet string	|32							|

 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV sss_HMAC_SHA2_256(const stOCTET_STRING *pstHMACKey, const stOCTET_STRING *pstMessage, stOCTET_STRING *pstDigest);


/*************** END OF FILE **************************************************/

#endif /* SSS_API_HMAC_256_H_ */

/** @} */
