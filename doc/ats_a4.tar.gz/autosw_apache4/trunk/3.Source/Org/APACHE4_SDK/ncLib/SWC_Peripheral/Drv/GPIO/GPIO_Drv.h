/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __GPIO_DRV_H__
#define __GPIO_DRV_H__

/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/
#include "GPIO_Lib.h"













/*
********************************************************************************
*                   	             DEFINES
********************************************************************************
*/

#define rGPIO_IN_PORT               (0x0)
#define rGPIO_DIR                   (0x4)
#define rGPIO_OUT_PORT              (0x8)
#define rGPIO_BASE(group)           (APACHE_GPIO_BASE + (group*0x10))


#define rGPIO_INT_EN                (0x30)
#define rGPIO_INT_ID                (0x40)

 











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern void  ncDrv_GPIO_SetDirection(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_DIR dir);
extern INT32 ncDrv_GPIO_GetData(eGPIO_GROUP group, eGPIO_PORT port);
extern void  ncDrv_GPIO_SetData(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_DATA level);
extern void  ncDrv_GPIO_SetIntc(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_INT_CH ch, BOOL OnOff);


#endif  /* __GPIO_DRV_H__ */


/* End Of File */

