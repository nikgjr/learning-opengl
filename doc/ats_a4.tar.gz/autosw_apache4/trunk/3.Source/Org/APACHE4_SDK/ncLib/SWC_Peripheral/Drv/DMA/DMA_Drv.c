/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "DMA_Drv.h"











/*
********************************************************************************
*                                  TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT32  mSrcAddr;
    UINT32  mDestAddr;
    UINT32  mSize;
    UINT32  mNextAddr;
} tDMA_LINK, *ptDMA_LINK;











/*
********************************************************************************
*                             VARIABLE DECLARATIONS
********************************************************************************
*/

volatile UINT32 gbDMA_STS[MAX_OF_DMA_CH];










/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __dma_debug_reg_dump(eDMA_CH Ch)
{
#if 0 // Debug
    UINT32 i;

    // Channel Register
    for(i=0; i<0x100; i+=4)
    {
        if(!(i%0x20)) 
            DEBUGMSG_SDK(MSGINFO, "\n0x%08x:", rDMAC_BASE(Ch) + i);
        DEBUGMSG_SDK(MSGINFO, " %08x", REGRW32(rDMAC_BASE(Ch), i));
    }	

    // Core Register
    for(i=0x1000; i<0x1100; i+=4)
    {
        if(!(i%0x20)) 
            DEBUGMSG_SDK(MSGINFO, "\n0x%08x:", rDMAC_BASE(0) + i);
        DEBUGMSG_SDK(MSGINFO, " %08x", REGRW32(rDMAC_BASE(0), i));
    }
#endif
}


static void __dma_debug_mem_dump(UINT32* pAddr, UINT32 Size)
{
#if 0 // Debug
    UINT32 i;

    for(i=0; i<Size; i++)
    {
        if(!(i%4)) 
            DEBUGMSG_SDK(MSGINFO, "\n0x%08x:", pAddr);
        DEBUGMSG_SDK(MSGINFO, " %08x", *pAddr++);
    }	
#endif
}


static UINT32 __dma_swap32(UINT32 a) 
{      
    UINT32 a_rev;

    a_rev = ((a&0xff)<<24) | ((a&0xff00)<<8) | ((a&0xff0000)>>8) | ((a&0xff000000)>>24);

    return a_rev;
}


BOOL ncDrv_DMA_IsIntcEn(eDMA_CH Ch)
{
    BOOL Ret = FALSE;
    UINT32 Reg;
    
    Reg = REGRW32(rDMAC_BASE(Ch), rDMAC_INT_EN);

    if(Reg & bDMAC_INT_MASK)
        Ret = TRUE;

    return Ret;
}


void ncDrv_DMA_SetIntc(eDMA_CH Ch, BOOL OnOff)
{
    if(OnOff == ON)
        REGRW32(rDMAC_BASE(Ch), rDMAC_INT_EN) = bDMAC_INT_MASK;
    else
        REGRW32(rDMAC_BASE(Ch), rDMAC_INT_EN) = 0x0; 
}


INT32 ncDrv_DMA_GetStatus(eDMA_CH Ch)
{
    INT32 Reg;

    // Get Interrupt Status
    Reg = (REGRW32(rDMAC_BASE(Ch), rDMAC_INT_RSTS)&bDMAC_INT_MASK);

    // Clear Interrupt
    REGRW32(rDMAC_BASE(Ch), rDMAC_INT_CLR) = Reg;

    // DMA Status Backup
    gbDMA_STS[Ch] |= Reg;

    return Reg;
}


INT32 ncDrv_DMA_CheckComplete(eDMA_CH Ch)
{
    INT32 ret = NC_FAILURE;

    // Check DMA Status
    if(ncDrv_DMA_IsIntcEn(Ch) == FALSE)
        ncDrv_DMA_GetStatus(Ch);

    if(gbDMA_STS[Ch]&(1<<bDMAC_INT_END))
    {
        // DMA Status Return
        ret = gbDMA_STS[Ch];

        // Clear
        gbDMA_STS[Ch] = 0;
    }

    return ret;
}


void ncDrv_DMA_SetBurstLen(ptDMA_INFO ptDMA, UINT32 Length)
{
    eDMA_CH Ch;
    UINT32  Reg;
    UINT32  BurstLen;


    // DMA Channel 
    Ch = ptDMA->mDMA_ChNum;


    // Set Read Ctrl
    BurstLen = (ptDMA->mDMA_Param.mRxBurstLen)?ptDMA->mDMA_Param.mRxBurstLen:1;
    if(ptDMA->mDMA_Param.mRxIncrEn == DISABLE)
    {
        if((BurstLen > 4) || (BurstLen == 3))
        {
            if((Length%4) == 0)         BurstLen = 4;
            else if((Length%2) == 0)    BurstLen = 2;
            else                        BurstLen = 1;
        }
    }
    
    Reg = (ptDMA->mDMA_Param.mRxIncrEn<<bDMAC_CR0_INCR)
        | (1<<bDMAC_CR0_CMD_MAX)     // Fixed
        | (1<<bDMAC_CR0_TOKENS)      // Fixed
        | (BurstLen<<bDMAC_CR0_BURST);

    if(ptDMA->mDMA_Param.mReqType == DMA_DEV_TO_MEM)
        Reg |= (1<<bDMAC_CR0_SWAP);
    
    REGRW32(rDMAC_BASE(Ch), rDMAC_CR0) = Reg;

    //DEBUGMSG_SDK(MSGINFO, "[DMA_Drv] Rx(%d, %d)", ptDMA->mDMA_Param.mRxIncrEn, BurstLen);


    // Set Write Ctrl
    BurstLen = (ptDMA->mDMA_Param.mRxBurstLen)?ptDMA->mDMA_Param.mRxBurstLen:1;
    if(ptDMA->mDMA_Param.mTxIncrEn == DISABLE)
    {
        if((BurstLen > 4) || (BurstLen == 3))
        {
            if((Length%4) == 0)         BurstLen = 4;
            else if((Length%2) == 0)    BurstLen = 2;
            else                        BurstLen = 1;
        }
    }

    Reg = (ptDMA->mDMA_Param.mTxIncrEn<<bDMAC_CR1_INCR)
        | (1<<bDMAC_CR1_CMD_MAX)
        | (1<<bDMAC_CR1_TOKENS)
        | (BurstLen<<bDMAC_CR1_BURST);

    if(ptDMA->mDMA_Param.mReqType == DMA_MEM_TO_DEV)
        Reg |= (1<<bDMAC_CR1_SWAP);
    
    REGRW32(rDMAC_BASE(Ch), rDMAC_CR1) = Reg;

    //DEBUGMSG_SDK(MSGINFO, " Tx(%d, %d)\n", ptDMA->mDMA_Param.mTxIncrEn, BurstLen);
}


void ncDrv_DMA_CreateLink(ptDMA_INFO ptDMA, UINT32 SrcAddr, UINT32 DestAddr, UINT32 Length)
{ 
    ptDMA_LINK pLink = (ptDMA_LINK)(ptDMA->mDMA_Param.mInstAddr);
    eDMA_CH Ch = (eDMA_CH)ptDMA->mDMA_ChNum;
    UINT32 i;
    UINT32 TranferEnd;


    // DMA Tranfer End Flag. 
    TranferEnd = (bDMAC_LINK_END|bDMAC_LINK_IEN);


    // bDMAC_SIZE_MAX = Align(bDMAC_SIZE_MASK)
    if(Length > bDMAC_SIZE_MAX)
    {
        i = 0;
        while(Length > 0)
        {
            pLink[i].mSrcAddr  = __dma_swap32(SrcAddr);
            pLink[i].mDestAddr = __dma_swap32(DestAddr);
            pLink[i].mSize     = __dma_swap32((Length >= bDMAC_SIZE_MAX)?bDMAC_SIZE_MAX:Length);

            if(ptDMA->mDMA_Param.mRxIncrEn == ENABLE)
                SrcAddr  += bDMAC_SIZE_MAX;
            if(ptDMA->mDMA_Param.mTxIncrEn == ENABLE)
                DestAddr += bDMAC_SIZE_MAX;
            Length   -= ((Length >= bDMAC_SIZE_MAX)?bDMAC_SIZE_MAX:Length);
            
            if(Length <= 0)
                pLink[i].mNextAddr = __dma_swap32(TranferEnd);
            else
                pLink[i].mNextAddr = __dma_swap32(((UINT32)(&pLink[i+1]))&0xfffffff0);
            i++;
        }
        
        srmmu_cache_flush();
        __dma_debug_mem_dump((UINT32*)(pLink), (i*4));
        
        // First Link Set
        REGRW32(rDMAC_BASE(Ch), rDMAC_SRC)  = __dma_swap32(pLink[0].mSrcAddr);
        REGRW32(rDMAC_BASE(Ch), rDMAC_DEST) = __dma_swap32(pLink[0].mDestAddr);    
        REGRW32(rDMAC_BASE(Ch), rDMAC_SIZE) = __dma_swap32(pLink[0].mSize);   
        REGRW32(rDMAC_BASE(Ch), rDMAC_LINK) = __dma_swap32(pLink[0].mNextAddr);
    }
    else
    {
        // One Link Set
        REGRW32(rDMAC_BASE(Ch), rDMAC_SRC) = SrcAddr;
        REGRW32(rDMAC_BASE(Ch), rDMAC_DEST) = DestAddr;    
        REGRW32(rDMAC_BASE(Ch), rDMAC_SIZE) = Length;   
        REGRW32(rDMAC_BASE(Ch), rDMAC_LINK) = TranferEnd;
    }
}


void ncDrv_DMA_Stop(eDMA_CH Ch)
{
    REGRW32(rDMAC_BASE(Ch), rDMAC_INT_EN) = 0x0;
    REGRW32(rDMAC_BASE(Ch), rDMAC_EN) = 0x0;
}


void ncDrv_DMA_Start(eDMA_CH Ch)
{
    UINT32 Reg;
    
    gbDMA_STS[Ch] = 0;
    
    REGRW32(rDMAC_BASE(Ch), rDMAC_EN) = bDMAC_CH_EN;  
    REGRW32(rDMAC_BASE(Ch), rDMAC_START) = bDMAC_CH_START;
}


INT32 ncDrv_DMA_Transfer(ptDMA_INFO ptDMA, UINT32 SrcAddr, UINT32 DestAddr, UINT32 Length)
{
    INT32   Ret = NC_SUCCESS;
    eDMA_CH Ch;
    UINT32  Reg;
    
    
    if((ptDMA != NULL) && (Length != 0))
    {
        // Set Channel
        Ch = ptDMA->mDMA_ChNum;

        
        // DMA Stop
        ncDrv_DMA_Stop(Ch);

        
        // Set DMA Link
        ncDrv_DMA_CreateLink(ptDMA, SrcAddr, DestAddr, Length);

        
        // Set Burst Ctrl
        ncDrv_DMA_SetBurstLen(ptDMA, Length);


        // Set Swap 
        Reg = (ptDMA->mDMA_Param.mSwap<<bDMAC_CR2_SWAP);
        REGRW32(rDMAC_BASE(Ch), rDMAC_CR2) = Reg;


        // Set Device(Peripheral) Number
        if(ptDMA->mDMA_Param.mReqType == DMA_MEM_TO_DEV)
            Reg = (ptDMA->mDMA_Param.mPeriNum<<bDMAC_PERI_WR_NUM);
        else if(ptDMA->mDMA_Param.mReqType == DMA_DEV_TO_MEM)
            Reg = (ptDMA->mDMA_Param.mPeriNum<<bDMAC_PERI_RD_NUM);
        else
            Reg = 0x0;
        REGRW32(rDMAC_BASE(Ch), rDMAC_PERI_CR0) = Reg;


        // Set Interrupt On/Off
        ncDrv_DMA_SetIntc(Ch, ptDMA->mDMA_Param.mIntEn);


        // display dma channel register
        __dma_debug_reg_dump(Ch);
 
        // Start DMA
        ncDrv_DMA_Start(Ch);
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


void ncDrv_DMA_DeInitialize(eDMA_CH Ch)
{
    ncDrv_DMA_Stop(Ch);
    
    REGRW32(rDMAC_BASE(Ch), rDMAC_SRC) = 0x0;
    REGRW32(rDMAC_BASE(Ch), rDMAC_DEST) = 0x0;    
    REGRW32(rDMAC_BASE(Ch), rDMAC_SIZE) = 0x0;   
    REGRW32(rDMAC_BASE(Ch), rDMAC_LINK) = 0x0;
    
    REGRW32(rDMAC_BASE(Ch), rDMAC_CR0) = 0x0;
    REGRW32(rDMAC_BASE(Ch), rDMAC_CR1) = 0x0;    
    REGRW32(rDMAC_BASE(Ch), rDMAC_CR2) = 0x0;
    
    REGRW32(rDMAC_BASE(Ch), rDMAC_PERI_CR0) = 0x0;

    REGRW32(rDMAC_BASE(Ch), rDMAC_INT_EN) = 0x0;
}


void ncDrv_DMA_Initialize(eDMA_CH Ch)
{
    ncDrv_DMA_DeInitialize(Ch);
}



/* End Of File */

