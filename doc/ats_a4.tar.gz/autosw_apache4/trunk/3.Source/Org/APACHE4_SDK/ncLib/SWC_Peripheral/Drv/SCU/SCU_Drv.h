/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SCU_DRV_H__
#define __SCU_DRV_H__

/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/
#include "SCU_Lib.h"












/*
********************************************************************************
*                   	             DEFINES
********************************************************************************
*/


//------------------------------------------------------------------------------
// SCU Register Structure 

#define rSCU_BASE                   APACHE_SYSCON_BASE

#define rSCU_TICK_CNT               0x3000


//------------------------------------------------------------------------------
// ICU Register Structure 

#define rICU_BASE                   APACHE_ICU_BASE

#define rICU_MUX_00                 0x0000
#define rICU_MUX_04                 0x0004
#define rICU_MUX_08                 0x0008
#define rICU_MUX_0C                 0x000C
#define rICU_MUX_10                 0x0010
#define rICU_MUX_14                 0x0014
#define rICU_MUX_18                 0x0018
#define rICU_MUX_1C                 0x001C
#define rICU_MUX_20                 0x0020
#define rICU_MUX_24                 0x0024
#define rICU_MUX_28                 0x0028













/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/
extern INT32  ncDrv_SCU_Init(void);
extern INT32  ncDrv_SCU_DeInit(void);
extern INT32  ncDrv_SCU_SetPinMux(UINT32 Pad, UINT32 Func);
extern INT32  ncDrv_SCU_GetSystemClock(UINT32 nClkType);
extern UINT32 ncDrv_SCU_GetData(UINT32 addr);
extern UINT32 ncDrv_SCU_SetData(UINT32 addr, UINT32 data);

#endif  /* __SCU_DRV_H__ */



/* End Of File */

