/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __APACHE_H__
#define __APACHE_H__

/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include <stdarg.h>
#include <string.h>

#include "Type.h"
#include "SCU_Lib.h"
#include "Debug_Lib.h"
#include "INTC_Lib.h"
#include "Timer_Lib.h"
#include "GPIO_Lib.h"
#include "I2C_Lib.h"
#include "Uart_Lib.h"
#include "INTC_Lib.h"
#include "PWM_Lib.h"
#include "SSP_Lib.h"
#include "QSPI_Lib.h"
#include "sFlash_Lib.h"
#include "DMA_Lib.h"
#include "JIG_Lib.h"











/*
********************************************************************************
*                           MEMORY MAP FOR APACHE               
********************************************************************************
*/

#define APACHE_IROM_BASE                0x00000000
#define APACHE_IRAM_BASE                0x02000000
#define APACHE_DRAM_BASE                0x20000000
#define APACHE_NAND_BASE                0x40000000
#define APACHE_EI_BASE                  0x80000000
#define APACHE_FT_BASE                  0x80100000
#define	APACHE_INTC_BASE                0x90000000
#define APACHE_DMAC_BASE                0x90100000
#define APACHE_TIMER0_BASE              0x90200000
#define APACHE_TIMER1_BASE              0x90280000
#define APACHE_PWM_BASE                 0x90300000
#define APACHE_DDRC_BASE                0x90400000
#define APACHE_I2C_0_BASE               0x90500000
#define APACHE_I2C_1_BASE               0x90600000 
#define APACHE_UART_0_BASE              0x90700000
#define APACHE_UART_1_BASE              0x90800000
#define APACHE_SPI_0_BASE               0x90900000
#define APACHE_SPI_1_BASE               0x90A00000
#define APACHE_QSPI_BASE                0x90B00000
#define APACHE_CAN_BASE                 0x90C00000
#define APACHE_SYSCON_BASE              0x90D00000
#define APACHE_ICU_BASE                 0x90E00000
#define APACHE_GPIO_BASE                0x90E01000
#define APACHE_ATOP_BASE                0x90F00000
#define APACHE_NANDC_BASE               0x91000000
#define APACHE_ISP_BASE                 0x92000000
#define APACEH_ADAS_BASE                0x93000000
#define APACHE_DSP_BASE                 0x94000000
#define APACHE_SE_BASE                  0xA0000000
#define APACHE_ISP_SM_BASE              0xA1000000
#define APACHE_RE_SM_BASE               0xA2000000











/*
********************************************************************************
*                         INLINE FUNCTION FOR APACHE
********************************************************************************
*/

//---------------------------------------------------------------------------
// Tick
//---------------------------------------------------------------------------

#ifdef __S_MAIN_C__
#define GLOBAL
#else
#define GLOBAL extern
#endif

// Set Value : ncLib_SCU_Open() Function Call.
GLOBAL unsigned int SYS_TICK_CLK;
#undef GLOBAL


static inline unsigned int nc_get_tick(unsigned int cls)
{
    if(cls)
    {
        // Clear : Count == 0
        REGRW32(APACHE_SYSCON_BASE, 0x3000) = 0x0;
    }
    
    return REGRW32(APACHE_SYSCON_BASE, 0x3000);
}


static inline void nc_wait_tick(unsigned int ticks)
{
    UINT32 sTicks = nc_get_tick(1);    

    while ((nc_get_tick(0) - sTicks) < ticks);
}


static inline void nc_delay(unsigned int s)
{
    // limit 10-sec
    if(s > 10) s = 10;
               
	nc_wait_tick(SYS_TICK_CLK * s);
}


static inline void nc_mdelay(unsigned int ms)
{  
    // limit 10-sec
    if(ms > 10000) ms = 10000;
    
	nc_wait_tick((SYS_TICK_CLK / MSEC) * ms);
}


static inline void nc_udelay(unsigned int us)
{
    // limit 10-sec
    if(us > 10000000) us = 10000000;

	nc_wait_tick((SYS_TICK_CLK / USEC) * us);
}


static inline unsigned int nc_get_msec(unsigned int cls)
{
    unsigned int curr_tick = nc_get_tick(cls);

    if(curr_tick)
        curr_tick = curr_tick / (SYS_TICK_CLK / MSEC);

    return curr_tick;
}


static inline unsigned int nc_get_usec(unsigned int cls)
{
    unsigned int curr_tick = nc_get_tick(cls);
    
    if(curr_tick)
        curr_tick = curr_tick / (SYS_TICK_CLK / USEC);

    return curr_tick;
}


static inline unsigned int nc_get_tick_auto_cls(void)
{
    // It is initialized to '0' when reading the register.
    return REGRW32(APACHE_SYSCON_BASE, 0x3004);
}


static inline unsigned int nc_get_msec_auto_cls(void)
{
    unsigned int curr_tick = nc_get_tick_auto_cls();

    if(curr_tick)
        curr_tick = curr_tick / (SYS_TICK_CLK / MSEC);

    return curr_tick;
}


static inline unsigned int nc_get_usec_auto_cls(void)
{
    unsigned int curr_tick = nc_get_tick_auto_cls();
    
    if(curr_tick)
        curr_tick = curr_tick / (SYS_TICK_CLK / USEC);

    return curr_tick;
}



//---------------------------------------------------------------------------
// asi r/w function
//---------------------------------------------------------------------------

static inline int ab_asi_io_read(unsigned long paddr)
{
    unsigned long val;
    __asm__ __volatile__("lda [%1] %2, %0\n\t"
            : "=r" (val)
            : "r" (paddr), "i" (0x20));
    return val;
}


static inline void ab_asi_io_write(unsigned int val, unsigned long paddr)
{
    __asm__ __volatile__("sta %0, [%1] %2 \n\t"
            : /* no outputs */
            : "r" (val), "r" (paddr), "i" (0x20)
            : "memory");
}


//---------------------------------------------------------------------------
// irq 
//---------------------------------------------------------------------------
#define PSR_PIL	0x00000f00 //for IRQ
static inline unsigned long ab_irq_save_asm(void)
{
	unsigned long retval;
	unsigned long tmp;

	__asm__ __volatile__(
		"rd	%%psr, %0\n\t"
		"nop; nop; nop\n"
		"or	%0, %2, %1\n\t"
		"wr	%1, 0, %%psr\n\t"
		"nop; nop; nop\n"
		: "=&r" (retval), "=r" (tmp)
		: "i" (PSR_PIL)
		: "memory");

	return retval;
}

static inline void ab_irq_enable_asm(void)
{
	unsigned long tmp;

	__asm__ __volatile__(
		"rd	%%psr, %0\n\t"
		"nop; nop; nop\n"
		"andn	%0, %1, %0\n\t"
		"wr	%0, 0, %%psr\n\t"
		"nop; nop; nop\n"
		: "=&r" (tmp)
		: "i" (PSR_PIL)
		: "memory");
}

static inline void ab_irq_disable_asm(void)
{
	unsigned long tmp;

	__asm__ __volatile__(
		"rd	%%psr, %0\n\t"
		"nop; nop; nop\n"
		"or	%0, %1, %0\n\t"
		"wr	%0, 0, %%psr\n\t"
		"nop; nop; nop\n"
		: "=&r" (tmp)
		: "i" (PSR_PIL)
		: "memory");
}

static inline void ab_irq_restore_asm(unsigned long old_psr)
{
	unsigned long tmp;

	__asm__ __volatile__(
		"rd	%%psr, %0\n\t"
		"and	%2, %1, %2\n\t"
		"nop; nop; nop\n"
		"andn	%0, %1, %0\n\t"
		"wr	%0, %2, %%psr\n\t"
		"nop; nop; nop\n"
		: "=&r" (tmp)
		: "i" (PSR_PIL), "r" (old_psr)
		: "memory");


}


//---------------------------------------------------------------------------
// SRMMU 
//---------------------------------------------------------------------------
#define ASI_M_RES00                 (0x00)   /* Don't touch... */
#define ASI_M_UNA01                 (0x01)   /* Same here... */
#define ASI_M_MXCC                  (0x02)   /* Access to TI VIKING MXCC registers */
#define ASI_M_FLUSH_PROBE           (0x03)   /* Reference MMU Flush/Probe; rw, ss */
#define ASI_M_MMUREGS               (0x04)   /* MMU Registers; rw, ss */
#define ASI_M_TLBDIAG               (0x05)   /* MMU TLB only Diagnostics */
#define ASI_M_DIAGS                 (0x06)   /* Reference MMU Diagnostics */
#define ASI_M_IODIAG                (0x07)   /* MMU I/O TLB only Diagnostics */
#define ASI_M_USERTXT               (0x08)   /* Same as ASI_USERTXT; rw, as */
#define ASI_M_KERNELTXT             (0x09)   /* Same as ASI_KERNELTXT; rw, as */
#define ASI_M_USERDATA              (0x0A)   /* Same as ASI_USERDATA; rw, as */
#define ASI_M_KERNELDATA            (0x0B)   /* Same as ASI_KERNELDATA; rw, as */
#define ASI_M_TXTC_TAG              (0x0C)   /* Instruction Cache Tag; rw, ss */
#define ASI_M_TXTC_DATA             (0x0D)   /* Instruction Cache Data; rw, ss */
#define ASI_M_DATAC_TAG             (0x0E)   /* Data Cache Tag; rw, ss */
#define ASI_M_DATAC_DATA            (0x0F)   /* Data Cache Data; rw, ss */
#define ASI_M_MMUBYPASS             (0x20)   /* MMU bypass; directly to the bus */
#define ASI_M_ABINFO                (0x30)   /* Aldebaran Core control */
#define ASI_M_CACHE                 (0x31)   /* Cache */

#define SRMMU_PTRS_PER_PMD          4

/* Definition of the values in the ET field of PTD's and PTE's */
#define SRMMU_CTRL_REG              0x00000000
#define SRMMU_CTXTBL_PTR            0x00000100
#define SRMMU_CTX_REG               0x00000200
#define SRMMU_FAULT_STATUS          0x00000300
#define SRMMU_FAULT_ADDR            0x00000400

#define SRMMU_ET_MASK               0x3
#define SRMMU_ET_INVALID            0x0
#define SRMMU_ET_PTD                0x1
#define SRMMU_ET_PTE                0x2
#define SRMMU_ET_REPTE              0x3 /* AIEEE, SuperSparc II reverse endian page! */

/* Physical page extraction from PTP's and PTE's. */
#define SRMMU_CTX_PMASK             0xfffffff0
#define SRMMU_PTD_PMASK             0xfffffff0
#define SRMMU_PTE_PMASK             0xffffff00

/* The pte non-page bits.  Some notes:
 *  * 1) cache, dirty, valid, and ref are frobbable
 *   *    for both supervisor and user pages.
 *    * 2) exec and write will only give the desired effect
 *     *    on user pages
 *      * 3) use priv and priv_readonly for changing the
 *       *    characteristics of supervisor ptes
 *        */
#define SRMMU_CACHE                 0x80
#define SRMMU_DIRTY                 0x40
#define SRMMU_REF                   0x20
#define SRMMU_NOREAD                0x10
#define SRMMU_EXEC                  0x08
#define SRMMU_WRITE                 0x04
#define SRMMU_VALID                 0x02 /* SRMMU_ET_PTE */
#define SRMMU_PRIV                  0x1c
#define SRMMU_PRIV_RDONLY           0x18

#define SRMMU_FILE                  0x40 /* Implemented in software */

#define SRMMU_PTE_FILE_SHIFT        8  /* == 32-PTE_FILE_MAX_BITS */

#define SRMMU_CHG_MASK              (0xffffff00 | SRMMU_REF | SRMMU_DIRTY)

static inline void srmmu_set_ctable_ptr(unsigned long paddr)
{
	paddr = ((paddr >> 4) & SRMMU_CTX_PMASK);
	__asm__ __volatile__("sta %0, [%1] %2\n\t" : :
			"r" (paddr), "r" (SRMMU_CTXTBL_PTR),
			"i" (ASI_M_MMUREGS) :
			"memory");
}

static inline unsigned long srmmu_get_ctable_ptr(void)
{
	unsigned int retval;

	__asm__ __volatile__("lda [%1] %2, %0\n\t" :
			"=r" (retval) :
			"r" (SRMMU_CTXTBL_PTR),
			"i" (ASI_M_MMUREGS));
	return (retval & SRMMU_CTX_PMASK) << 4;
}
static inline void srmmu_set_context(int context)
{
	__asm__ __volatile__("sta %0, [%1] %2\n\t" : :
			"r" (context), "r" (SRMMU_CTX_REG),
			"i" (ASI_M_MMUREGS) : "memory");
}

static inline int srmmu_get_context(void)
{
	register int retval;
	__asm__ __volatile__("lda [%1] %2, %0\n\t" :
			"=r" (retval) :
			"r" (SRMMU_CTX_REG),
			"i" (ASI_M_MMUREGS));
	return retval;
}

/* Accessing the MMU control register. */
static inline unsigned int srmmu_get_mmureg(void)
{
	unsigned int retval;
	__asm__ __volatile__("lda [%%g0] %1, %0\n\t" :
			"=r" (retval) :
			"i" (ASI_M_MMUREGS));
	return retval;
}

static inline void srmmu_set_mmureg(unsigned long regval)
{
	__asm__ __volatile__("sta %0, [%%g0] %1\n\t" : :
			"r" (regval), "i" (ASI_M_MMUREGS) : "memory");

}

static inline void srmmu_cache_flush(void)
{
    __asm__ __volatile__("flush \n\t");  //cache flush
}


#endif	/* __APACHE_H__ */



