/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*                                  INCLUDE                                 
********************************************************************************
*/

#include "SCU_Drv.h"











/*
********************************************************************************
*                                  TYPEDEFS
********************************************************************************
*/

typedef struct _tSUC_CLK
{
    UINT32      mOSC;    

    UINT32      mCPU;
    UINT32      mAXI;
    UINT32      mAPB;
    UINT32      mDDR;
    UINT32      mQSPI;
} tSCU_CLK, *ptSCU_CLK;











/*
********************************************************************************
*                             VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tSCU_CLK tSCUClk = {
                                27*MHZ,     // OSC
                                50*MHZ,     // CPU
                                50*MHZ,     // AXI
                                25*MHZ,     // APB
                                64*MHZ,     // DDR
                                25*MHZ      // QSPI
                            };











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

INT32 ncDrv_SCU_GetPad(UINT32 Offset, UINT32 Pos)
{
    return (REGRW32(rICU_BASE, Offset)>>Pos)&0xf;
}


void ncDrv_SCU_SetPad(UINT32 Func, UINT32 Offset, UINT32 Pos)
{
    UINT32 Reg;

    Reg = REGRW32(rICU_BASE, Offset);
    Reg &= ~(0x7<<Pos);         // Clear
    Reg |= ((Func&0x7)<<Pos);   // Set
    REGRW32(rICU_BASE, Offset) = Reg;
}


void ncDrv_SCU_GenClk(void)
{
    //------------------------------------
    // Do not delete it...
    SYS_TICK_CLK = tSCUClk.mAPB;
    //------------------------------------

    
}


INT32 ncDrv_SCU_GetPinMux(UINT32 Pad)
{
    INT32 ret = NC_SUCCESS;

    switch(Pad)
    {      
        //-----------------------------[0x00]----------------------------------
        case PAD_NTRST:         ret = ncDrv_SCU_GetPad(rICU_MUX_00,  0); break;
        case PAD_TCK:           ret = ncDrv_SCU_GetPad(rICU_MUX_00,  4); break;
        case PAD_TMS:           ret = ncDrv_SCU_GetPad(rICU_MUX_00,  8); break;
        case PAD_TDO:           ret = ncDrv_SCU_GetPad(rICU_MUX_00, 12); break;
        case PAD_TDI:           ret = ncDrv_SCU_GetPad(rICU_MUX_00, 16); break;
        case PAD_I2C0_SCL:      ret = ncDrv_SCU_GetPad(rICU_MUX_00, 20); break;
        case PAD_I2C0_SDA:      ret = ncDrv_SCU_GetPad(rICU_MUX_00, 24); break;
        case PAD_I2C1_SCL:      ret = ncDrv_SCU_GetPad(rICU_MUX_00, 28); break;

        //-----------------------------[0x04]----------------------------------
        case PAD_I2C1_SDA:      ret = ncDrv_SCU_GetPad(rICU_MUX_04,  0); break;
        case PAD_UART0_RX:      ret = ncDrv_SCU_GetPad(rICU_MUX_04,  4); break;
        case PAD_UART0_TX:      ret = ncDrv_SCU_GetPad(rICU_MUX_04,  8); break;
        case PAD_UART1_RX:      ret = ncDrv_SCU_GetPad(rICU_MUX_04, 12); break;
        case PAD_UART1_TX:      ret = ncDrv_SCU_GetPad(rICU_MUX_04, 16); break;
        case PAD_SPI2_CSN0:     ret = ncDrv_SCU_GetPad(rICU_MUX_04, 20); break;
        case PAD_SPI2_CSN1:     ret = ncDrv_SCU_GetPad(rICU_MUX_04, 24); break;
        case PAD_SPI2_DQ0:      ret = ncDrv_SCU_GetPad(rICU_MUX_04, 28); break;

        //-----------------------------[0x08]----------------------------------
        case PAD_SPI2_DQ1:      ret = ncDrv_SCU_GetPad(rICU_MUX_08,  0); break;
        case PAD_SPI2_DQ2:      ret = ncDrv_SCU_GetPad(rICU_MUX_08,  4); break;
        case PAD_SPI2_DQ3:      ret = ncDrv_SCU_GetPad(rICU_MUX_08,  8); break;
        case PAD_SPI2_SCK:      ret = ncDrv_SCU_GetPad(rICU_MUX_08, 12); break;
        case PAD_SEN_PCLK:      ret = ncDrv_SCU_GetPad(rICU_MUX_08, 16); break;
        case PAD_SEN_PV:        ret = ncDrv_SCU_GetPad(rICU_MUX_08, 20); break;
        case PAD_SEN_PH:        ret = ncDrv_SCU_GetPad(rICU_MUX_08, 24); break;
        case PAD_SEN_PD0:       ret = ncDrv_SCU_GetPad(rICU_MUX_08, 28); break;

        //-----------------------------[0x0C]----------------------------------
        case PAD_SEN_PD1:       ret = ncDrv_SCU_GetPad(rICU_MUX_0C,  0); break;
        case PAD_SEN_PD2:       ret = ncDrv_SCU_GetPad(rICU_MUX_0C,  4); break;
        case PAD_SEN_PD3:       ret = ncDrv_SCU_GetPad(rICU_MUX_0C,  8); break;
        case PAD_SEN_PD4:       ret = ncDrv_SCU_GetPad(rICU_MUX_0C, 12); break;
        case PAD_SEN_PD5:       ret = ncDrv_SCU_GetPad(rICU_MUX_0C, 16); break;
        case PAD_SEN_PD6:       ret = ncDrv_SCU_GetPad(rICU_MUX_0C, 20); break;
        case PAD_SEN_PD7:       ret = ncDrv_SCU_GetPad(rICU_MUX_0C, 24); break;
        case PAD_SEN_PD8:       ret = ncDrv_SCU_GetPad(rICU_MUX_0C, 28); break;

        //-----------------------------[0x10]----------------------------------
        case PAD_SEN_PD9:       ret = ncDrv_SCU_GetPad(rICU_MUX_10,  0); break;
        case PAD_SEN_PD10:      ret = ncDrv_SCU_GetPad(rICU_MUX_10,  4); break;
        case PAD_SEN_PD11:      ret = ncDrv_SCU_GetPad(rICU_MUX_10,  8); break;
        case PAD_SEN_PD12:      ret = ncDrv_SCU_GetPad(rICU_MUX_10, 12); break;
        case PAD_SEN_PD13:      ret = ncDrv_SCU_GetPad(rICU_MUX_10, 16); break;
        case PAD_SEN_PD14:      ret = ncDrv_SCU_GetPad(rICU_MUX_10, 20); break;
        case PAD_SEN_PD15:      ret = ncDrv_SCU_GetPad(rICU_MUX_10, 24); break;
        case PAD_VOUT_CK_O:     ret = ncDrv_SCU_GetPad(rICU_MUX_10, 28); break;

        //-----------------------------[0x14]----------------------------------
        case PAD_VOUT_VSYNC:    ret = ncDrv_SCU_GetPad(rICU_MUX_14,  0); break;
        case PAD_VOUT_HSYNC:    ret = ncDrv_SCU_GetPad(rICU_MUX_14,  4); break;
        case PAD_VOUT_Y0:       ret = ncDrv_SCU_GetPad(rICU_MUX_14,  8); break;
        case PAD_VOUT_Y1:       ret = ncDrv_SCU_GetPad(rICU_MUX_14, 12); break;
        case PAD_VOUT_Y2:       ret = ncDrv_SCU_GetPad(rICU_MUX_14, 16); break;
        case PAD_VOUT_Y3:       ret = ncDrv_SCU_GetPad(rICU_MUX_14, 20); break;
        case PAD_VOUT_Y4:       ret = ncDrv_SCU_GetPad(rICU_MUX_14, 24); break;
        case PAD_VOUT_Y5:       ret = ncDrv_SCU_GetPad(rICU_MUX_14, 28); break;

        //-----------------------------[0x18]----------------------------------
        case PAD_VOUT_Y6:       ret = ncDrv_SCU_GetPad(rICU_MUX_18,  0); break;
        case PAD_VOUT_Y7:       ret = ncDrv_SCU_GetPad(rICU_MUX_18,  4); break;
        case PAD_VOUT_C0:       ret = ncDrv_SCU_GetPad(rICU_MUX_18,  8); break;
        case PAD_VOUT_C1:       ret = ncDrv_SCU_GetPad(rICU_MUX_18, 12); break;
        case PAD_VOUT_C2:       ret = ncDrv_SCU_GetPad(rICU_MUX_18, 16); break;
        case PAD_VOUT_C3:       ret = ncDrv_SCU_GetPad(rICU_MUX_18, 20); break;
        case PAD_VOUT_C4:       ret = ncDrv_SCU_GetPad(rICU_MUX_18, 24); break;
        case PAD_VOUT_C5:       ret = ncDrv_SCU_GetPad(rICU_MUX_18, 28); break;

        //-----------------------------[0x1C]----------------------------------
        case PAD_VOUT_C6:       ret = ncDrv_SCU_GetPad(rICU_MUX_1C,  0); break;
        case PAD_VOUT_C7:       ret = ncDrv_SCU_GetPad(rICU_MUX_1C,  4); break;
        // [11:08] reserved
        // [15:12] reserved
        // [18:16] reserved
        // [22:20] reserved
        // [26:24] reserved
        // [30:28] reserved

        //---------------------------------------------------------------------
        default:
        {
            DEBUGMSG_SDK(MSGERR, "[SCU_Drv] PIM MUX Error (%d)\n", Pad);
            
            ret = NC_FAILURE;
        }
            break;
    }

    return ret;
}


INT32 ncDrv_SCU_SetPinMux(UINT32 Pad, UINT32 Func)
{
    INT32 ret = NC_SUCCESS;

    switch(Pad)
    {      
        //-----------------------------[0x00]----------------------------------
        case PAD_NTRST:         ncDrv_SCU_SetPad(Func, rICU_MUX_00,  0); break;
        case PAD_TCK:           ncDrv_SCU_SetPad(Func, rICU_MUX_00,  4); break;
        case PAD_TMS:           ncDrv_SCU_SetPad(Func, rICU_MUX_00,  8); break;   
        case PAD_TDO:           ncDrv_SCU_SetPad(Func, rICU_MUX_00, 12); break;
        case PAD_TDI:           ncDrv_SCU_SetPad(Func, rICU_MUX_00, 16); break;
        case PAD_I2C0_SCL:      ncDrv_SCU_SetPad(Func, rICU_MUX_00, 20); break;
        case PAD_I2C0_SDA:      ncDrv_SCU_SetPad(Func, rICU_MUX_00, 24); break;
        case PAD_I2C1_SCL:      ncDrv_SCU_SetPad(Func, rICU_MUX_00, 28); break;

        //-----------------------------[0x04]----------------------------------
        case PAD_I2C1_SDA:      ncDrv_SCU_SetPad(Func, rICU_MUX_04,  0); break;
        case PAD_UART0_RX:      ncDrv_SCU_SetPad(Func, rICU_MUX_04,  4); break;
        case PAD_UART0_TX:      ncDrv_SCU_SetPad(Func, rICU_MUX_04,  8); break;
        case PAD_UART1_RX:      ncDrv_SCU_SetPad(Func, rICU_MUX_04, 12); break;
        case PAD_UART1_TX:      ncDrv_SCU_SetPad(Func, rICU_MUX_04, 16); break;
        case PAD_SPI2_CSN0:     ncDrv_SCU_SetPad(Func, rICU_MUX_04, 20); break;
        case PAD_SPI2_CSN1:     ncDrv_SCU_SetPad(Func, rICU_MUX_04, 24); break;
        case PAD_SPI2_DQ0:      ncDrv_SCU_SetPad(Func, rICU_MUX_04, 28); break;

        //-----------------------------[0x08]----------------------------------
        case PAD_SPI2_DQ1:      ncDrv_SCU_SetPad(Func, rICU_MUX_08,  0); break;
        case PAD_SPI2_DQ2:      ncDrv_SCU_SetPad(Func, rICU_MUX_08,  4); break;
        case PAD_SPI2_DQ3:      ncDrv_SCU_SetPad(Func, rICU_MUX_08,  8); break;
        case PAD_SPI2_SCK:      ncDrv_SCU_SetPad(Func, rICU_MUX_08, 12); break;
        case PAD_SEN_PCLK:      ncDrv_SCU_SetPad(Func, rICU_MUX_08, 16); break;
        case PAD_SEN_PV:        ncDrv_SCU_SetPad(Func, rICU_MUX_08, 20); break;
        case PAD_SEN_PH:        ncDrv_SCU_SetPad(Func, rICU_MUX_08, 24); break;
        case PAD_SEN_PD0:       ncDrv_SCU_SetPad(Func, rICU_MUX_08, 28); break;

        //-----------------------------[0x0C]----------------------------------
        case PAD_SEN_PD1:       ncDrv_SCU_SetPad(Func, rICU_MUX_0C,  0); break;
        case PAD_SEN_PD2:       ncDrv_SCU_SetPad(Func, rICU_MUX_0C,  4); break;
        case PAD_SEN_PD3:       ncDrv_SCU_SetPad(Func, rICU_MUX_0C,  8); break;
        case PAD_SEN_PD4:       ncDrv_SCU_SetPad(Func, rICU_MUX_0C, 12); break;
        case PAD_SEN_PD5:       ncDrv_SCU_SetPad(Func, rICU_MUX_0C, 16); break;
        case PAD_SEN_PD6:       ncDrv_SCU_SetPad(Func, rICU_MUX_0C, 20); break;
        case PAD_SEN_PD7:       ncDrv_SCU_SetPad(Func, rICU_MUX_0C, 24); break;
        case PAD_SEN_PD8:       ncDrv_SCU_SetPad(Func, rICU_MUX_0C, 28); break;

        //-----------------------------[0x10]----------------------------------
        case PAD_SEN_PD9:       ncDrv_SCU_SetPad(Func, rICU_MUX_10,  0); break;
        case PAD_SEN_PD10:      ncDrv_SCU_SetPad(Func, rICU_MUX_10,  4); break;
        case PAD_SEN_PD11:      ncDrv_SCU_SetPad(Func, rICU_MUX_10,  8); break;
        case PAD_SEN_PD12:      ncDrv_SCU_SetPad(Func, rICU_MUX_10, 12); break;
        case PAD_SEN_PD13:      ncDrv_SCU_SetPad(Func, rICU_MUX_10, 16); break;
        case PAD_SEN_PD14:      ncDrv_SCU_SetPad(Func, rICU_MUX_10, 20); break;
        case PAD_SEN_PD15:      ncDrv_SCU_SetPad(Func, rICU_MUX_10, 24); break;
        case PAD_VOUT_CK_O:     ncDrv_SCU_SetPad(Func, rICU_MUX_10, 28); break;

        //-----------------------------[0x14]----------------------------------
        case PAD_VOUT_VSYNC:    ncDrv_SCU_SetPad(Func, rICU_MUX_14,  0); break;
        case PAD_VOUT_HSYNC:    ncDrv_SCU_SetPad(Func, rICU_MUX_14,  4); break;
        case PAD_VOUT_Y0:       ncDrv_SCU_SetPad(Func, rICU_MUX_14,  8); break;
        case PAD_VOUT_Y1:       ncDrv_SCU_SetPad(Func, rICU_MUX_14, 12); break;
        case PAD_VOUT_Y2:       ncDrv_SCU_SetPad(Func, rICU_MUX_14, 16); break;
        case PAD_VOUT_Y3:       ncDrv_SCU_SetPad(Func, rICU_MUX_14, 20); break;
        case PAD_VOUT_Y4:       ncDrv_SCU_SetPad(Func, rICU_MUX_14, 24); break;
        case PAD_VOUT_Y5:       ncDrv_SCU_SetPad(Func, rICU_MUX_14, 28); break;

        //-----------------------------[0x18]----------------------------------
        case PAD_VOUT_Y6:       ncDrv_SCU_SetPad(Func, rICU_MUX_18,  0); break;
        case PAD_VOUT_Y7:       ncDrv_SCU_SetPad(Func, rICU_MUX_18,  4); break;
        case PAD_VOUT_C0:       ncDrv_SCU_SetPad(Func, rICU_MUX_18,  8); break;
        case PAD_VOUT_C1:       ncDrv_SCU_SetPad(Func, rICU_MUX_18, 12); break;
        case PAD_VOUT_C2:       ncDrv_SCU_SetPad(Func, rICU_MUX_18, 16); break;
        case PAD_VOUT_C3:       ncDrv_SCU_SetPad(Func, rICU_MUX_18, 20); break;
        case PAD_VOUT_C4:       ncDrv_SCU_SetPad(Func, rICU_MUX_18, 24); break;
        case PAD_VOUT_C5:       ncDrv_SCU_SetPad(Func, rICU_MUX_18, 28); break;

        //-----------------------------[0x1C]----------------------------------
        case PAD_VOUT_C6:       ncDrv_SCU_SetPad(Func, rICU_MUX_1C,  0); break;
        case PAD_VOUT_C7:       ncDrv_SCU_SetPad(Func, rICU_MUX_1C,  4); break;
        // [11:08] reserved
        // [15:12] reserved
        // [18:16] reserved
        // [22:20] reserved
        // [26:24] reserved
        // [30:28] reserved

        //---------------------------------------------------------------------
        default:
        {
            DEBUGMSG_SDK(MSGERR, "[SCU_Drv] PIM MUX Error (%d)\n", Pad);
            
            ret = NC_FAILURE;
        }
            break;
    }

    return ret;
}


INT32 ncDrv_SCU_GetSystemClock(UINT32 nClkNum)
{
    INT32 Clock = NC_FAILURE;

    switch(nClkNum)
    {
        case SCU_CLK_ID_CPU:
            Clock = tSCUClk.mCPU;
            break;

        case SCU_CLK_ID_AXI:
        case SCU_CLK_ID_DMA:
            Clock = tSCUClk.mAXI;
            break;

        case SCU_CLK_ID_APB:
        case SCU_CLK_ID_SSPI:
        case SCU_CLK_ID_UART:
        case SCU_CLK_ID_TIMER:
        case SCU_CLK_ID_I2C:
        case SCU_CLK_ID_PWM:
            Clock = tSCUClk.mAPB;
            break;

        case SCU_CLK_ID_QSPI:
            Clock = tSCUClk.mQSPI;
            break;
            
        case SCU_CLK_ID_CAN:
            break;

        case SCU_CLK_ID_DDR:
            Clock = tSCUClk.mDDR;
            break;

        case SCU_CLK_ID_ADC: 
            break;

        case SCU_CLK_ID_TS:
            break;
            
        default:
            break;
    }

    return Clock;
}


UINT32 ncDrv_SCU_GetData(UINT32 offset)
{
    return REGRW32(rSCU_BASE, offset);
}


UINT32 ncDrv_SCU_SetData(UINT32 offset, UINT32 data)
{
    REGRW32(rSCU_BASE, offset) = data;
    
    return NC_SUCCESS;
}


INT32 ncDrv_SCU_Init(void)
{
    INT32 ret = NC_SUCCESS;

    ncDrv_SCU_GenClk();

    return ret;
}


INT32 ncDrv_SCU_DeInit(void)
{
    INT32  ret = NC_SUCCESS;

    return ret;
}



/* End Of File */

