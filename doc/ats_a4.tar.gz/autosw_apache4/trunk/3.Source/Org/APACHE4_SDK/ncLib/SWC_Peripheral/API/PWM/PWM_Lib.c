/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "PWM_Drv.h"











/*
********************************************************************************
*                             VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbPWMOpen = FALSE;

volatile BOOL gbPWM_CH[MAX_OF_PWM_CH];

tPAD_INFO gtPWM_PAD[MAX_OF_PWM_CH] = 
{
        // PWM-0
        {PAD_VOUT_CK_O,     {PAD_FUNC_3, PAD_FUNC_MAX}},
        // PWM-1
        {PAD_VOUT_VSYNC,    {PAD_FUNC_3, PAD_FUNC_MAX}},
        // PWM-2
        {PAD_VOUT_HSYNC,    {PAD_FUNC_3, PAD_FUNC_MAX}},
        // PWM-3
        {PAD_VOUT_Y0,       {PAD_FUNC_3, PAD_FUNC_MAX}}
};











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void ncLib_PWM_PinMuxCtrlGet(ePWM_CH Ch)
{
    if(Ch < MAX_OF_PWM_CH)
    { 
        // Back-up Current PinMux
        if(gtPWM_PAD[Ch].mFunc[1] == PAD_FUNC_MAX)
            gtPWM_PAD[Ch].mFunc[1] = ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gtPWM_PAD[Ch].mId, CMD_END);

        // Set PinMux
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtPWM_PAD[Ch].mId, gtPWM_PAD[Ch].mFunc[0], CMD_END);
    }
}


static void ncLib_PWM_PinMuxCtrlFree(ePWM_CH Ch)
{
    if(Ch < MAX_OF_PWM_CH)
    {   
        // Rollback PinMux
        if(gtPWM_PAD[Ch].mFunc[1] != PAD_FUNC_MAX)
        {
            ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtPWM_PAD[Ch].mId, gtPWM_PAD[Ch].mFunc[1], CMD_END);
            gtPWM_PAD[Ch].mFunc[1] = PAD_FUNC_MAX;
        }
    }
}


static INT32 ncLib_PWM_InfoInit(ePWM_CH Ch, ptPWM_PARAM ptPWM)
{
    INT32 Ret = NC_FAILURE;

    if(ptPWM != NULL)
    {
        gbPWM_CH[Ch] = ON;

        // Set PIN MUX
        ncLib_PWM_PinMuxCtrlGet(Ch);

        Ret = NC_SUCCESS;
    }
        
    return Ret;
}


static void ncLib_PWM_InfoDeInit(ePWM_CH Ch)
{
    gbPWM_CH[Ch] = OFF;

    // Free PIN MUX
    ncLib_PWM_PinMuxCtrlFree(Ch);       
}


static INT32 ncLib_PWM_IsNotAliveCh(void)
{
    INT32 Ret = NC_SUCCESS;
    ePWM_CH Ch;
    
    for(Ch=PWM_CH0; Ch<MAX_OF_PWM_CH; Ch++)
    {
        if(gbPWM_CH[Ch] == ON)
            Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_PWM_Open(void)
{
    INT32 Ret = NC_SUCCESS;
    ePWM_CH Ch;

    if(gbPWMOpen == FALSE)
    {
        ncLib_SCU_Control(GCMD_SCU_ENA_CLK, SCU_CLK_ID_PWM, CMD_END); 
        ncDrv_PWM_Initialize(0);
        
        for(Ch=PWM_CH0; Ch<MAX_OF_PWM_CH; Ch++)
            ncLib_PWM_InfoDeInit(Ch); 
        
        gbPWMOpen = TRUE;
        
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_PWM_Close(void)
{
    INT32 Ret;

    Ret = ncLib_PWM_IsNotAliveCh();
    if(Ret == NC_SUCCESS)
    {
        ncDrv_PWM_DeInitialize();
        
        ncLib_SCU_Control(GCMD_SCU_DIS_CLK, SCU_CLK_ID_PWM, CMD_END);  
        gbPWMOpen = FALSE;
    }

    return Ret;
}


INT32 ncLib_PWM_Read(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_PWM_Write(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_PWM_Control(ePWM_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[10];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    ePWM_CH Ch;
    UINT32  PWM_Clk;
    UINT32  Scal;


    if(gbPWMOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < 10; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, PWM no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Defence Code
            */
            
            Ch = (ePWM_CH)ArgData[0];
            if(Ch >= MAX_OF_PWM_CH) 
                Cmd = GCMD_PWM_MAX;

            
            /*
            * Implement Control Command Function
            */
            
            switch(Cmd)
            {
                case GCMD_PWM_INIT_CH:
                {
                    Ret = ncLib_PWM_InfoInit(Ch, (ptPWM_PARAM)ArgData[1]);
                    if(Ret == NC_SUCCESS)
                    {
                        PWM_Clk = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_PWM, CMD_END);
                        Ret = ncDrv_PWM_Init(Ch, (ptPWM_PARAM)ArgData[1], PWM_Clk);
                    }
                }
                break;


                case GCMD_PWM_DEINIT_CH:
                {
                    ncDrv_PWM_DeInit(Ch);
                    ncLib_PWM_InfoDeInit(Ch); 
                }
                break;


                case GCMD_PWM_START:
                {
                    ncDrv_PWM_Start(Ch);
                }
                break;


                case GCMD_PWM_STOP:
                {
                    ncDrv_PWM_Stop(Ch);
                }
                break;


                case GCMD_PWM_SET_FREQUENCY:
                {
                    PWM_Clk = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_PWM, CMD_END);
                    Scal    = ncDrv_PWM_GetScal(Ch);
                    ncDrv_PWM_SetFrequency(Ch, (UINT32)ArgData[1], (UINT32)ArgData[2], Scal, PWM_Clk);
                }
                break;


                case GCMD_PWM_GET_INT_STS:
                {
                    Ret = ncDrv_PWM_GetStatus(Ch);
                }
                break;   


                case GCMD_PWM_MAX:
                {
                    Ret = NC_FAILURE;
                }
                break;   

               
                default :
                {
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support PWM command\n");
                    Ret = NC_FAILURE;
                }
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}



/* End Of File */

