/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/
#include "Uart_Drv.h"














/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __uart_debug_reg_dump(eUART_CH Ch)
{
#if 0
    UINT32 i = 0x08;

    // Channel Register
    DEBUGMSG_SDK(MSGINFO, "\n-----------------------------------------------------------------------------------\n");    
    DEBUGMSG_SDK(MSGINFO, "0x%08x: xxxxxxxx xxxxxxxx", rUART_BASE(Ch));
    
    for(; i<0x2c; i+=4)
    {
        if(!(i%0x20)) 
            DEBUGMSG_SDK(MSGINFO, "\n0x%08x:", rUART_BASE(Ch) + i);
        DEBUGMSG_SDK(MSGINFO, " %08x", REGRW32(rUART_BASE(Ch), i));
    }
    DEBUGMSG_SDK(MSGINFO, "\n-----------------------------------------------------------------------------------\n");   
#endif
}


void ncDrv_UART_PutChar(eUART_CH Ch, UINT8 Data)
{
    UINT32 Reg;

    
    do 
    {
        Reg = REGRW32(rUART_BASE(Ch), rUART_LSR);
    } while ((Reg & bUART_LSR_THRE) != bUART_LSR_THRE);


    // Data Write
	REGRW32(rUART_BASE(Ch), rUART_TX) = Data;


    // WAIT_FOR_XMITR
    do 
    {
        Reg = REGRW32(rUART_BASE(Ch), rUART_LSR);
    } while ((Reg & (bUART_LSR_TEMT | bUART_LSR_THRE)) != (bUART_LSR_TEMT | bUART_LSR_THRE));
}


INT32 ncDrv_UART_GetFIFOCnt(eUART_CH Ch)
{ 
    UINT32 Reg;

    // Rx FIFO count    
    Reg = (REGRW32(rUART_BASE(Ch), rUART_RC)&bUART_RC_MASK);

    return Reg;
}


INT32 ncDrv_UART_GetSts(eUART_CH Ch)
{ 
    UINT32 Reg;

    __uart_debug_reg_dump(Ch);

    // Interrupt Stats
    Reg = REGRW32(rUART_BASE(Ch), rUART_IIR)&0xff;

    return Reg;
}


char ncDrv_UART_GetChar(eUART_CH Ch)
{
    if((REGRW32(rUART_BASE(Ch), rUART_LSR) & bUART_LSR_DR) == bUART_LSR_DR)
    {
        return (char)REGRW32(rUART_BASE(Ch), rUART_RX);
    }
    else
    {
        return -1;
    }
}


void ncDrv_UART_PutStr(eUART_CH Ch, char *str)
{
    char prev = 0x0;

    while(*str)
    {
        if(*str == '\n' && prev != '\r') ncDrv_UART_PutChar(Ch, '\r');

        ncDrv_UART_PutChar(Ch, *str);

        prev = *str++;
    }
}


void ncDrv_UART_SetBaudrate(eUART_CH Ch, UINT32 RefClk, UINT32 BaudRate)
{
    UINT32 Reg;
    UINT32 DIV;


    // open divisor latch
    Reg = (REGRW32(rUART_BASE(Ch), rUART_LCR) | bUART_LCR_DLAB);
    REGRW32(rUART_BASE(Ch), rUART_LCR) = Reg;


    // set divisor latch
    DIV = RefClk/(16 * BaudRate);
    REGRW32(rUART_BASE(Ch), rUART_DLL) = (DIV>>0)&0xff;
    REGRW32(rUART_BASE(Ch), rUART_DLM) = (DIV>>8)&0xff;


    // close divisor latch
    Reg = (REGRW32(rUART_BASE(Ch), rUART_LCR) & ~(bUART_LCR_DLAB));
    REGRW32(rUART_BASE(Ch), rUART_LCR) = Reg;
}


void ncDrv_UART_Deinitialize(eUART_CH Ch)
{
    REGRW32(rUART_BASE(Ch), rUART_FCR) = bUART_FCR_CLEAR_RCVR|bUART_FCR_CLEAR_XMIT;    
    REGRW32(rUART_BASE(Ch), rUART_IER) = 0x0;    
    REGRW32(rUART_BASE(Ch), rUART_EN)  = OFF;
}


void ncDrv_UART_Initialize(eUART_CH Ch, tUART_PARAM *ptUART, UINT32 RefClk)
{
    // Disable UART
    REGRW32(rUART_BASE(Ch), rUART_EN) = OFF;

    // Reset receiver and transmiter
    REGRW32(rUART_BASE(Ch), rUART_FCR) = (bUART_FCR_CLEAR_RCVR|bUART_FCR_CLEAR_XMIT|bUART_FCR_TRIGGER_14);

    // Set Interrupt Disable
    if(ptUART->mIntEn == ENABLE)
        REGRW32(rUART_BASE(Ch), rUART_IER) = (bUART_IER_RLSI|bUART_IER_TX|bUART_IER_RX);
    else
        REGRW32(rUART_BASE(Ch), rUART_IER) = 0x0;

    // Set 8 bit char, 1 stop bit, no parity */
    REGRW32(rUART_BASE(Ch), rUART_LCR) = (ptUART->mBRK|ptUART->mSPS|ptUART->mEPS|ptUART->mPEN|ptUART->mSTP|ptUART->mLEN);

    // Set baud rate
    ncDrv_UART_SetBaudrate(Ch, RefClk, ptUART->mBaudRate);

    // Enable UART
    REGRW32(rUART_BASE(Ch), rUART_EN) = ON;
}



/* End Of File */

