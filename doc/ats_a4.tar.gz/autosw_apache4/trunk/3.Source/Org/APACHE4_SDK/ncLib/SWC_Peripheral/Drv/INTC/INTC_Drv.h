/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __INTC_DRV_H__
#define __INTC_DRV_H__

/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "INTC_Lib.h"











/*
********************************************************************************
*                   	             DEFINES
********************************************************************************
*/

#define rINTC_ADDR                  APACHE_INTC_BASE

#define rINTC_CFG_LOW               0x00        // RxTx : Interrupt Config Register
#define rINTC_CFG_HIGH              0x90        // RxTx : Interrupt Config Register
                                                //        - [31:8] : Reserved     
    #define bINTC_CFG_SRC           (4)         //        - [ 7:4] : Interrupt Source Number          
                                                //        - [ 3:2] : Reserved   
    #define bINTC_CFG_POL           (1)         //        -    [1] : Polarity
    #define bINTC_CFG_EN            (0)         //        -    [0] : Enable Interrupt


#define rINTC_CLS                   0x80        // RxTx : Interrupt Clear Register
                                                //        - [31:16] : Reserved     
    #define bINTC_CLS_TRAP          (0xFFFF)    //        - [15:00] : Interrupt Clear Bit (for CoreINTC)          


#define rINTC_MASK                  0x84        // RxTx : Interrupt Mask Register
                                                //        - [31:16] : Reserved     
    #define bINTC_MASK_TRAP         (0xFFFF)    //        - [15:00] : Interrupt Mask Bit (for CoreINTC)          


#define rINTC_PEN_HIGH              0x200       // RxTx : Interrupt Pending HIGH Register
#define rINTC_PEN_LOW               0x204       // RxTx : Interrupt Pending LOW Register


#define rINTC_SRC_HIGH              0x300       // RxTx : Interrupt Trap HIGH Register
#define rINTC_SRC_LOW               0x304       // RxTx : Interrupt Trap LOW Register


#define rINTC_TYPE_HIGH             0x400       // RxTx : Interrupt Type HIGH Register
#define rINTC_TYPE_LOW              0x404       // RxTx : Interrupt Type LOW Register
                                                //        -       O : EDGE
                                                //        -       1 : Level                                           











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern void  ncDrv_INTC_RunHandler(eCORE_NUM CoreNum);
extern INT32 ncDrv_INTC_UnRegisterHandler(eCORE_NUM CoreNum, eINT_NUM nrcNum);
extern INT32 ncDrv_INTC_RegisterHandler(eCORE_NUM CoreNum, eINT_NUM SrcNum, eTRIG_MODE TrigMode, PrHandler pHandler);
extern INT32 ncDrv_INTC_DeInitialize(void);
extern INT32 ncDrv_INTC_Initialize(void);


#endif  /* __INTC_DRV_H__ */



/* End Of File */

