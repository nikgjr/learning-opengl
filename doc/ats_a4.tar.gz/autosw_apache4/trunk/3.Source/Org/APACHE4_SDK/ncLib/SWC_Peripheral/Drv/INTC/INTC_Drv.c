/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "INTC_Drv.h"

//#define __INTC_DRV_DEBUG__











/*
********************************************************************************
*                             VARIABLE DECLARATIONS
********************************************************************************
*/

PrHandler ncDrv_INTC_UserHandler[CORE_IRQ_MAX][MAX_IRQ_NUM];











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

void ncDrv_INTC_IRQ_UnMask(UINT32 CoreNum)
{
    UINT32 Reg;

    Reg = REGRW32(rINTC_ADDR, rINTC_MASK);
    Reg &= ~(1 << CoreNum);
    REGRW32(rINTC_ADDR, rINTC_MASK) = Reg;
}


void ncDrv_INTC_IRQ_Mask(UINT32 CoreNum)
{
    UINT32 Reg;

    Reg = REGRW32(rINTC_ADDR, rINTC_MASK);
    Reg |= (1 << CoreNum);
    REGRW32(rINTC_ADDR, rINTC_MASK) = Reg;
}


void ncDrv_INTC_IRQ_Clear(UINT32 CoreNum)
{
	REGRW32(rINTC_ADDR, rINTC_CLS) = (1<<CoreNum);
}


void ncDrv_INTC_IRQ_Enable(eCORE_NUM CoreNum, eTRIG_MODE TrigMode, UINT32 CfgAddr)
{
    UINT32 Reg;
    
	Reg =  ((CoreNum & 0xf) << bINTC_CFG_SRC) | (TrigMode<<bINTC_CFG_POL) | (ENABLE<<bINTC_CFG_EN);
	REGRW32(CfgAddr, 0x0) = Reg;
}


void ncDrv_INTC_IRQ_Disable(UINT32 CfgAddr)
{
	REGRW32(CfgAddr, 0x0) = 0x0;
}


UINT32 ncDrv_INTC_GetConfAddr(eCORE_NUM CoreNum, eINT_NUM SrcNum)
{
    INT32 Ret = NC_SUCCESS;
    UINT32 CfgAddr = 0;

    
    // Check Core Interrupt Number
    if((CoreNum < CORE_IRQ_01) || (CoreNum >= CORE_IRQ_MAX))
    {
        DEBUGMSG_SDK(MSGERR, "[INTC_Drv] UnRegister : BAD Core IRQ Number %d\n", CoreNum);
        Ret = NC_FAILURE;
    }


    // Check Source Interrupt Number
    if(SrcNum >= MAX_IRQ_NUM)
    {
        DEBUGMSG_SDK(MSGERR, "[INTC_Drv] UnRegister : BAD Src IRQ Number %d\n", SrcNum);
        Ret = NC_FAILURE;
    } 


    if(Ret == NC_SUCCESS)
    {
		// Check Config Register Addr
		if((SrcNum >= 0) && (SrcNum <= 31)) 
			CfgAddr = rINTC_ADDR + rINTC_CFG_LOW + (SrcNum * 4);
        else
			CfgAddr = rINTC_ADDR + rINTC_CFG_HIGH + ((SrcNum - 32) * 4);
    }

    return CfgAddr;
}


INT32 ncDrv_INTC_GetIRQNum(INT32 Idx, UINT32 CoreNum)
{   
    INT32  SrcNum = NC_FAILURE;    
    UINT64 TrapHigh;
    UINT64 TrapLow;
    UINT64 Trap;


    // Check Tirgger Interrupt Number
    TrapHigh = REGRW32(rINTC_ADDR, ((CoreNum-1)*8) + rINTC_SRC_HIGH);
    TrapLow  = REGRW32(rINTC_ADDR, ((CoreNum-1)*8) + rINTC_SRC_LOW);
    Trap = (TrapHigh<<32) | TrapLow;
    
    for( ;Idx>=0;Idx--)
    {
        if((Trap&((UINT64)1<<Idx)))
        {
#ifdef __INTC_DRV_DEBUG__          
            DEBUGMSG_SDK(MSGINFO, "[INTC_Drv] ISR %d", Idx);
#endif
            SrcNum = Idx;
            break;
        }
    }


#ifdef __INTC_DRV_DEBUG__       
    if(SrcNum != NC_FAILURE)
    {
        Idx--;
        for( ;Idx>=0;Idx--)
        {
            if((Trap&((UINT64)1<<Idx)))
            {
                DEBUGMSG_SDK(MSGINFO, " %d", Idx);
            }
        }
        DEBUGMSG_SDK(MSGINFO, "\n");
    }
#endif


#ifdef __INTC_DRV_DEBUG__        
    if(SrcNum == NC_FAILURE) // Trigger Interrupt End
    {   
        TrapHigh = REGRW32(rINTC_ADDR, ((CoreNum-1)*8) + rINTC_PEN_HIGH);
        TrapLow  = REGRW32(rINTC_ADDR, ((CoreNum-1)*8) + rINTC_PEN_LOW);
        Trap = (TrapHigh<<32) | TrapLow;

        for(Idx=MAX_IRQ_NUM ;Idx>=0;Idx--)
        {
            if((Trap&((UINT64)1<<Idx)))
            {
                DEBUGMSG_SDK(MSGWARN, "[INTC_Drv] PEN %d\n", Idx);
            }
        }
    }
#endif

    return SrcNum;
}


void ncDrv_INTC_SetTriggerType(eINT_NUM SrcNum)
{
    UINT32 Reg;
    
    if((SrcNum >= 0) && (SrcNum <= 31))
    {
        Reg = REGRW32(rINTC_ADDR, rINTC_TYPE_LOW);
        if(    
            ((SrcNum >= IRQ_NUM_I2C0) && (SrcNum <= IRQ_NUM_I2C1))
            || ((SrcNum >= IRQ_NUM_PWM0) && (SrcNum <= IRQ_NUM_PWM3))
        ) 
        {
            Reg |= (1<<SrcNum);         // LEVEL Type
        }
        else
        {
            Reg &= ~(1<<SrcNum);        // EDGE Type (Default)
        }
        REGRW32(rINTC_ADDR, rINTC_TYPE_LOW) = Reg;
        
    }
    else
    {
        Reg = REGRW32(rINTC_ADDR, rINTC_TYPE_HIGH);
        if(0)
        {
            Reg |= (1<<SrcNum-32);      // LEVEL Type
        }
        else
        {
            Reg &= ~(1<<SrcNum-32);     // EDGE Type (Default)
        }
        REGRW32(rINTC_ADDR, rINTC_TYPE_HIGH) = Reg;
    }
}


void ncDrv_INTC_RunHandler(eCORE_NUM CoreNum)
{ 
    INT32 SrcNum = MAX_IRQ_NUM;

    while(1)
    {
        SrcNum = ncDrv_INTC_GetIRQNum(SrcNum, CoreNum);
        if(SrcNum == NC_FAILURE)
            break;

        if(ncDrv_INTC_UserHandler[CoreNum][SrcNum] != NULL)    
            ncDrv_INTC_UserHandler[CoreNum][SrcNum](SrcNum);
        
        SrcNum--;
    }

    ncDrv_INTC_IRQ_Clear(CoreNum);
}

INT32 ncDrv_INTC_UnRegisterHandler(eCORE_NUM CoreNum, eINT_NUM SrcNum)
{
    INT32 Ret = NC_FAILURE;
    UINT32 ConfAddr;


    ConfAddr = ncDrv_INTC_GetConfAddr(CoreNum, SrcNum);

    // Free Interrupt Handler
    if(ConfAddr != 0)
    { 
        ncDrv_INTC_IRQ_Disable(ConfAddr);
        
        // Free Interrupt Handler
        ncDrv_INTC_UserHandler[CoreNum][SrcNum] = (PrHandler)NULL;

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncDrv_INTC_RegisterHandler(eCORE_NUM CoreNum, eINT_NUM SrcNum, eTRIG_MODE TrigMode, PrHandler pHandler)
{
    INT32  Ret = NC_FAILURE;    
	UINT32 CfgAddr;

    
    CfgAddr = ncDrv_INTC_GetConfAddr(CoreNum, SrcNum);
    if(CfgAddr != 0)
    {
        // IRQ Core Off
        ncDrv_INTC_IRQ_Mask(CoreNum);


        // Set Interrupt User Handler
        if(ncDrv_INTC_UserHandler[CoreNum][SrcNum] != NULL)
        {
            DEBUGMSG_SDK(MSGWARN, "[INTC_Drv] Register : ncDrv_INTC_UserHandler != NULL (%d, %d)\n", CoreNum, SrcNum);
        }
    	ncDrv_INTC_UserHandler[CoreNum][SrcNum] = (PrHandler)pHandler;


        // Set Interrupt Type
        ncDrv_INTC_SetTriggerType(SrcNum);

        
    	// Enable Intc
        ncDrv_INTC_IRQ_Enable(CoreNum, TrigMode, CfgAddr);


        // IRQ Core On
        ncDrv_INTC_IRQ_UnMask(CoreNum);

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncDrv_INTC_DeInitialize(void)
{
    INT32 Ret = NC_SUCCESS;
    UINT32 CoreNum;
    UINT32 SrcNum;


    // Free Interrupt User Handler
    for(CoreNum=CORE_IRQ_01;CoreNum<CORE_IRQ_MAX; CoreNum++)
    {
        for(SrcNum=0; SrcNum<MAX_IRQ_NUM; SrcNum++)
        {
            Ret |= ncDrv_INTC_UnRegisterHandler(CoreNum, SrcNum);
        }

        ncDrv_INTC_IRQ_Mask(CoreNum);
    }

    return Ret;
}


INT32 ncDrv_INTC_Initialize(void)
{
    INT32 Ret;
    
    Ret = ncDrv_INTC_DeInitialize();
    
    return Ret;
}



/* End Of File */

