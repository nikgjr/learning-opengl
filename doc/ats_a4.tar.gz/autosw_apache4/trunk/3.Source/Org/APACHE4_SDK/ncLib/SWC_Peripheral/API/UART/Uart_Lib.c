/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "Uart_Drv.h"











/*
********************************************************************************
*                                   TYPEDEFS                                    
********************************************************************************
*/

typedef struct
{
    tPAD_INFO RX;
    tPAD_INFO TX;     
} tUART_PAD, *ptUART_PAD;











/*
********************************************************************************
*                             VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbUartOpen = FALSE;

volatile BOOL gbUartCH[MAX_OF_UART_CH];

tUART_PAD gtUART_PAD[MAX_OF_UART_CH] = 
{
    {   // UART-0
        {PAD_UART0_RX, {PAD_FUNC_1, PAD_FUNC_MAX}},
        {PAD_UART0_TX, {PAD_FUNC_1, PAD_FUNC_MAX}}
    },
    {   // UART-1
        {PAD_UART1_RX, {PAD_FUNC_1, PAD_FUNC_MAX}},
        {PAD_UART1_TX, {PAD_FUNC_1, PAD_FUNC_MAX}}
    },
};











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/


static void ncLib_UART_PinMuxCtrlGet(eUART_CH Ch)
{
    if(Ch < MAX_OF_UART_CH)
    {
        // Back-up Current PinMux
        if(gtUART_PAD[Ch].RX.mFunc[1] == PAD_FUNC_MAX)
            gtUART_PAD[Ch].RX.mFunc[1] = ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gtUART_PAD[Ch].RX.mId, CMD_END);
        
        if(gtUART_PAD[Ch].TX.mFunc[1] == PAD_FUNC_MAX)
            gtUART_PAD[Ch].TX.mFunc[1] = ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, gtUART_PAD[Ch].TX.mId, CMD_END);

        // Set PinMux
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtUART_PAD[Ch].RX.mId, gtUART_PAD[Ch].RX.mFunc[0], CMD_END);
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtUART_PAD[Ch].TX.mId, gtUART_PAD[Ch].TX.mFunc[0], CMD_END);
    }
}


static void ncLib_UART_PinMuxCtrlFree(eUART_CH Ch)
{
    if(Ch < MAX_OF_UART_CH)
    {    
        // Rollback PinMux
        if(gtUART_PAD[Ch].RX.mFunc[1] != PAD_FUNC_MAX)
        {
            ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtUART_PAD[Ch].RX.mId, gtUART_PAD[Ch].RX.mFunc[1], CMD_END);
            gtUART_PAD[Ch].RX.mFunc[1] = PAD_FUNC_MAX;
        }

        if(gtUART_PAD[Ch].TX.mFunc[1] != PAD_FUNC_MAX)
        {
            ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, gtUART_PAD[Ch].TX.mId, gtUART_PAD[Ch].TX.mFunc[1], CMD_END); 
            gtUART_PAD[Ch].TX.mFunc[1] = PAD_FUNC_MAX;
        }
    }
}


static INT32 ncLib_UART_InfoInit(eUART_CH Ch, ptUART_PARAM ptUART)
{
    INT32 Ret = NC_FAILURE;
    
    if(ptUART != NULL)
    {    
        gbUartCH[Ch] = ON;

        // Set PIN MUX
        ncLib_UART_PinMuxCtrlGet(Ch);

        Ret = NC_SUCCESS;
    }

    return Ret;
}


static void ncLib_UART_InfoDeInit(eUART_CH Ch)
{
    gbUartCH[Ch] = OFF;

    // Free PIN MUX
    ncLib_UART_PinMuxCtrlFree(Ch);     
}


static INT32 ncLib_UART_IsNotAliveCh(void)
{
    INT32 Ret = NC_SUCCESS;
    eUART_CH Ch;
    
    for(Ch=UART_CH0; Ch<MAX_OF_UART_CH; Ch++)
    {
        if(gbUartCH[Ch] == ON)
            Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_UART_Open(void)
{
    INT32 Ret = NC_SUCCESS;
    eUART_CH Ch;
	
    if(gbUartOpen == FALSE)
    {
        ncLib_SCU_Control(GCMD_SCU_ENA_CLK, SCU_CLK_ID_UART, CMD_END); 

        for(Ch=UART_CH0; Ch<MAX_OF_UART_CH; Ch++)
            ncLib_UART_InfoDeInit(Ch); 
        
        gbUartOpen = TRUE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_UART_Close(void)
{
	INT32 Ret;

    Ret = ncLib_UART_IsNotAliveCh();
    if(Ret == NC_SUCCESS)
    {
        ncLib_SCU_Control(GCMD_SCU_DIS_CLK, SCU_CLK_ID_UART, CMD_END);  
        gbUartOpen = FALSE;
    }
    
    return Ret;
}


INT32 ncLib_UART_Read(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_UART_Write(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_UART_Control(eUART_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[10];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    eUART_CH Ch;
    UINT32   UART_Clk;


    if(gbUartOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < 10; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
			DEBUGMSG_SDK(MSGERR, "Error, UART no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Defence Code
            */
            
            Ch = (eUART_CH)ArgData[0];
            if(   (Ch >= MAX_OF_UART_CH) 
               || ((Cmd != GCMD_UT_INIT_CH) && (gbUartCH[Ch] == OFF)) )
            {
                Cmd = GCMD_UT_MAX;
            }

            
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case GCMD_UT_INIT_CH:
                {
                    Ret = ncLib_UART_InfoInit(Ch, (ptUART_PARAM)ArgData[1]);
                    if(Ret == NC_SUCCESS)
                    {
                        UART_Clk = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_UART, CMD_END);
                        ncDrv_UART_Initialize(Ch, (ptUART_PARAM)ArgData[1], UART_Clk);
                    }
                }
                break;


                case GCMD_UT_DEINIT_CH:
                {
                    ncDrv_UART_Deinitialize(Ch);
                    ncLib_UART_InfoDeInit(Ch);
                }
                break;


                case GCMD_UT_SET_BAUDRATE:
                {
                    UART_Clk = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_UART, CMD_END);
                    ncDrv_UART_SetBaudrate(Ch, UART_Clk, (UINT32)ArgData[1]);
                }
                break;


                case GCMD_UT_GET_INT_STS:
                {
                    Ret = ncDrv_UART_GetSts(Ch);
                }
                break;


                case GCMD_UT_GET_FIFO_CNT:
                {
                    Ret = ncDrv_UART_GetFIFOCnt(Ch);
                }
                break;


                case GCMD_UT_GET_CHAR:
                {
                    char buff;
                    
                    buff = ncDrv_UART_GetChar(Ch);
                    if(buff == -1)
                        Ret = NC_FAILURE;
                    else
                        Ret = buff&0xFF;
                }
                break;


                case GCMD_UT_PUT_CHAR:
                {
                    ncDrv_UART_PutChar(Ch, (UINT8)ArgData[1]);
                }
                break;


                case GCMD_UT_PUT_STR:
                {
                    ncDrv_UART_PutStr(Ch, (char *)ArgData[1]);
                }
                break;
                
                
                default :
                    Ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}



/* End Of File */

