/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __INTC_LIB_H__
#define __INTC_LIB_H__

/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "APACHE.h"











/*
********************************************************************************
*                                  ENUMERATION
********************************************************************************
*/

typedef enum
{
    /*
    * Generic Commands
    */
    
    GCMD_INTC_REGISTER_INT = 0,
    GCMD_INTC_UNREGISTER_INT,
    
    GCMD_INTC_MAX
    
} eINTC_CMD;


typedef enum
{
    IRQ_NUM_TIMER0 = 0,
    IRQ_NUM_TIMER1,
    IRQ_NUM_TIMER2,   
    IRQ_NUM_TIMER3,
    IRQ_NUM_TIMER4,
    IRQ_NUM_TIMER5,   
    IRQ_NUM_TIMER6,
    IRQ_NUM_TIMER7,
    IRQ_NUM_UART0,          
    IRQ_NUM_UART1,     


    //------- 10 -------
    IRQ_NUM_I2C0,
    IRQ_NUM_I2C1,          
    IRQ_NUM_SPI0,
    IRQ_NUM_SPI1,
    IRQ_NUM_QSPI,
    IRQ_NUM_DMA0,
    IRQ_NUM_DMA1,
    IRQ_NUM_DMA2,
    IRQ_NUM_DMA3,
    IRQ_NUM_PWM0,

    
    //------- 20 -------
    IRQ_NUM_PWM1,      
    IRQ_NUM_PWM2,
    IRQ_NUM_PWM3,
    IRQ_NUM_CAN,
    IRQ_NUM_GPIO0,  
    IRQ_NUM_GPIO1,
    IRQ_NUM_GPIO2,
        IRQ_NUM_REV_27,
        IRQ_NUM_REV_28,
        IRQ_NUM_REV_29,


    //------- 30 -------
        IRQ_NUM_REV_30,
        IRQ_NUM_REV_31,
    IRQ_NUM_ISP0,
    IRQ_NUM_ISP1,
    IRQ_NUM_ISP2,
    IRQ_NUM_ISP3,
    IRQ_NUM_ISP4,
    IRQ_NUM_ISP5,  
    IRQ_NUM_ISP6,  
    IRQ_NUM_ISP7,


    //------- 40 -------
    IRQ_NUM_ISP8,
    IRQ_NUM_ISP9,
    IRQ_NUM_VDUMP,
        IRQ_NUM_REV_43,
        IRQ_NUM_REV_44,
        IRQ_NUM_REV_45,
        IRQ_NUM_REV_46,
        IRQ_NUM_REV_47,
    IRQ_NUM_ADAS0,
    IRQ_NUM_ADAS1,


    //------- 50 -------
    IRQ_NUM_ADAS2,
    IRQ_NUM_ADAS3, 
    IRQ_NUM_ADAS4, 
        IRQ_NUM_REV_53,
        IRQ_NUM_REV_54,
        IRQ_NUM_REV_55,
    IRQ_NUM_NOC0,
    IRQ_NUM_NOC1,
    IRQ_NUM_NOC2,
    IRQ_NUM_NOC3, 


    //------- 60 -------
    IRQ_NUM_NOC4, 
    IRQ_NUM_NOC5,  
        IRQ_NUM_REV_62,
    IRQ_NUM_FAULT,
    
    MAX_IRQ_NUM,

    FIQ_NUM_NULL = MAX_IRQ_NUM,
    MAX_FIQ_NUM
} eINT_NUM;


typedef enum
{
    CORE_IRQ_REV = 0,
        
    CORE_IRQ_01,
    CORE_IRQ_02,
    CORE_IRQ_03,
    CORE_IRQ_04,
    CORE_IRQ_05,  
    CORE_IRQ_06,
    CORE_IRQ_07,
    CORE_IRQ_08,         
    CORE_IRQ_09,        
    CORE_IRQ_10,
    
    CORE_IRQ_11,          
    CORE_IRQ_12,
    CORE_IRQ_13,
    CORE_IRQ_14,
    CORE_IRQ_15,                    // (x)
    
    CORE_IRQ_MAX
} eCORE_NUM;


typedef enum
{
    TRIG_FALLING_EDGE = 0,          // (High->Low)
    TRIG_RISING_EDGE,               // (Low->High)
    TRIG_BOTH_EDGE                  // (High->Low) and (Low->High)
} eTRIG_MODE;











/*
********************************************************************************
*                                   TYPEDEFS
********************************************************************************
*/

typedef void (*PrHandler)(UINT32);











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32  ncLib_INTC_Open(void);
extern INT32  ncLib_INTC_Close(void);
extern INT32  ncLib_INTC_Read(void);
extern INT32  ncLib_INTC_Write(void);
extern INT32  ncLib_INTC_Control(eINTC_CMD Cmd, ...);

extern void   ncLib_INTC_IrqHandler(UINT32 CoreIrqNum);



#endif /* __INTC_LIB_H__ */

