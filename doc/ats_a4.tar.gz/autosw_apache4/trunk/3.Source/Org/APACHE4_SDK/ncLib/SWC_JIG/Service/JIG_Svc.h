/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __JIG_SVC_H__
#define __JIG_SVC_H__

/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "JIG_Lib.h"


/*
********************************************************************************
*									DEFINES
********************************************************************************
*/

#define JIG_ADDR_16BIT              2   // 16BIT JIG Command String Value
#define JIG_ADDR_32BIT              4   // 32BIT JIG Command String Value

#define	RX_BUF_SIZE                 256 //128




/*
********************************************************************************
*									TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UCHAR 	RxPointer;
	UCHAR 	RxRealBuffer[RX_BUF_SIZE];
	UCHAR 	RxTempBuffer[RX_BUF_SIZE];
	UCHAR	Protocol;                       // 2bit
	UCHAR 	RxInputCount;
	UCHAR	Command;                        // 1bit
	UCHAR	RxStart;
	UCHAR 	Mode;
	UCHAR	CmdProcess;
} STRUCT_HAL_UART;


/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern void ncSvc_JIG_IRQ_Handler(UINT32 irq);

extern void ncSvc_JIG_Init(void);
extern void ncSvc_JIG_DeInit(void);
extern INT32 ncSvc_JIG_CommandMain(void);



#endif  /* __JIG_SVC_H__ */



/* End Of File */

