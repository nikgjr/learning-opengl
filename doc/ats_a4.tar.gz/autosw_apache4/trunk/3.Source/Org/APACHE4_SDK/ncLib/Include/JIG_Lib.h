/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __JIG_LIB_H__
#define __JIG_LIB_H__


/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "APACHE.h"



/*
********************************************************************************
*                                    DEFINES
********************************************************************************
*/

#define JIGMSG(fmt, args...)  ncLib_JIG_Printf(fmt, ## args)







/*
********************************************************************************
*                                  ENUMERATION
********************************************************************************
*/

/*
* JIG GENERIC & SPECIFIC COMMANDS
*/

typedef enum
{
    /*
    * Generic Commands
    */
    GCMD_JIG_INIT = 0,
    GCMD_JIG_DEINIT,

    GCMD_JIG_DO_COMMAND,

    GCMD_JIG_MAX

 } eJIG_CMD;











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_JIG_Open(void);
extern INT32 ncLib_JIG_Close(void);
extern INT32 ncLib_JIG_Read(void);
extern INT32 ncLib_JIG_Write(void);
extern INT32 ncLib_JIG_Control(eJIG_CMD Cmd, ...);



#endif  /* __JIG_LIB_H__ */



/* End Of File */

