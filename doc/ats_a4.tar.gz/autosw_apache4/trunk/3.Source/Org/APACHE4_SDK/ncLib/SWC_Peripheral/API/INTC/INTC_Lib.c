/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "INTC_Drv.h"











/*
********************************************************************************
*                             VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbINTCOpen = FALSE;
volatile BOOL gbINTC_EN[CORE_IRQ_MAX][MAX_IRQ_NUM];











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

static INT32 ncLib_INTC_InfoInit(eCORE_NUM CoreNum, eINT_NUM SrcNum, PrHandler pHandler)
{
    INT32 Ret = NC_FAILURE;

    if(pHandler != NULL)
    {
        gbINTC_EN[CoreNum][SrcNum] = ON;

        Ret = NC_SUCCESS;
    }
        
    return Ret;
}


static void ncLib_INTC_InfoDeInit(eCORE_NUM CoreNum, eINT_NUM SrcNum)
{
    gbINTC_EN[CoreNum][SrcNum] = OFF;
}


static INT32 ncLib_INTC_IsNotAliveCh(void)
{
    INT32 Ret = NC_SUCCESS;
    eCORE_NUM CoreNum;
    eINT_NUM  SrcNum;

    for(CoreNum=CORE_IRQ_01; CoreNum<CORE_IRQ_MAX; CoreNum++)
    {
        for(SrcNum=0; SrcNum<MAX_IRQ_NUM; SrcNum++)
        {
            if(gbINTC_EN[CoreNum][SrcNum] == ON)
                Ret = NC_FAILURE;
        }
    }
    
    return Ret;
}


void ncLib_INTC_IrqHandler(UINT32 CoreIrqNum)
{
    ncDrv_INTC_RunHandler((eCORE_NUM)CoreIrqNum);
}


INT32 ncLib_INTC_Open(void)
{
    INT32 Ret = NC_SUCCESS;
    eCORE_NUM CoreNum;
    eINT_NUM  SrcNum;

    if(gbINTCOpen == FALSE)
    {        
        ncDrv_INTC_Initialize();
        ab_irq_enable_asm();

        for(CoreNum=CORE_IRQ_01;CoreNum<CORE_IRQ_MAX; CoreNum++)
        {
            for(SrcNum=0; SrcNum<MAX_IRQ_NUM; SrcNum++)
            {
                ncLib_INTC_InfoDeInit(CoreNum, SrcNum);
            }
        }
        gbINTCOpen = TRUE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_INTC_Close(void)
{
    INT32 Ret;

    Ret = ncLib_INTC_IsNotAliveCh();
    if(Ret == NC_SUCCESS)
    {
        ncDrv_INTC_DeInitialize();
        ab_irq_disable_asm();
        gbINTCOpen = FALSE;
    }

    return Ret;
}


INT32 ncLib_INTC_Read(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_INTC_Write(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_INTC_Control(eINTC_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[10];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    eCORE_NUM CoreNum;
    eINT_NUM  SrcNum;


    if(gbINTCOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < 10; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, INTC no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Defence Code
            */
            
            CoreNum = (eCORE_NUM)ArgData[0];
            SrcNum  = (eINT_NUM)ArgData[1];
            
            if((CoreNum < CORE_IRQ_01)||(CoreNum >= CORE_IRQ_MAX))
                Cmd = GCMD_INTC_MAX;
            else if(SrcNum >= MAX_IRQ_NUM)
                Cmd = GCMD_INTC_MAX;
            
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case GCMD_INTC_REGISTER_INT:
                {
                    Ret = ncLib_INTC_InfoInit(CoreNum, SrcNum, (PrHandler)ArgData[3]);
                    if(Ret == NC_SUCCESS)
                    {
                        Ret = ncDrv_INTC_RegisterHandler(CoreNum, SrcNum, (eTRIG_MODE)ArgData[2], (PrHandler)ArgData[3]);
                    }
                }
                break;


                case GCMD_INTC_UNREGISTER_INT:
                {
                    Ret = ncDrv_INTC_UnRegisterHandler(CoreNum, SrcNum);
                    ncLib_INTC_InfoDeInit(CoreNum, SrcNum);
                }
                break;

                
                default :
                {
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support INTC command\n");
                    Ret = NC_FAILURE;
                }
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}



/* End Of File */

