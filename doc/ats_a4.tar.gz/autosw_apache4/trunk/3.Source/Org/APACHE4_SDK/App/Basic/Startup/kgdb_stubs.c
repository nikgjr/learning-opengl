/* taken from sparc-stub.c by jychang */
/****************************************************************************

		THIS SOFTWARE IS NOT COPYRIGHTED

   HP offers the following for use in the public domain.  HP makes no
   warranty with regard to the software or it's performance and the
   user accepts the software "AS IS" with all faults.

   HP DISCLAIMS ANY WARRANTIES, EXPRESS OR IMPLIED, WITH REGARD
   TO THIS SOFTWARE INCLUDING BUT NOT LIMITED TO THE WARRANTIES
   OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

****************************************************************************/

/****************************************************************************
 *  Header: remcom.c,v 1.34 91/03/09 12:29:49 glenne Exp $
 *
 *  Module name: remcom.c $
 *  Revision: 1.34 $
 *  Date: 91/03/09 12:29:49 $
 *  Contributor:     Lake Stevens Instrument Division$
 *
 *  Description:     low level support for gdb debugger. $
 *
 *  Considerations:  only works on target hardware $
 *
 *  Written by:      Glenn Engel $
 *  ModuleState:     Experimental $
 *
 *  NOTES:           See Below $
 *
 *  Modified for SPARC by Stu Grossman, Cygnus Support.
 *
 *  This code has been extensively tested on the Fujitsu SPARClite demo board.
 *
 *  To enable debugger support, two things need to happen.  One, a
 *  call to set_debug_traps() is necessary in order to allow any breakpoints
 *  or error conditions to be properly intercepted and reported to gdb.
 *  Two, a breakpoint needs to be generated to begin communication.  This
 *  is most easily accomplished by a call to breakpoint().  Breakpoint()
 *  simulates a breakpoint by executing a trap #1.
 *
 *************
 *
 *    The following gdb commands are supported:
 *
 * command          function                               Return value
 *
 *    g             return the value of the CPU registers  hex data or ENN
 *    G             set the value of the CPU registers     OK or ENN
 *
 *    mAA..AA,LLLL  Read LLLL bytes at address AA..AA      hex data or ENN
 *    MAA..AA,LLLL: Write LLLL bytes at address AA.AA      OK or ENN
 *
 *    c             Resume at current address              SNN   ( signal NN)
 *    cAA..AA       Continue at address AA..AA             SNN
 *
 *    s             Step one instruction                   SNN
 *    sAA..AA       Step one instruction from AA..AA       SNN
 *
 *    k             kill
 *
 *    ?             What was the last sigval ?             SNN   (signal NN)
 *
 * All commands and responses are sent with a packet which includes a
 * checksum.  A packet consists of
 *
 * $<packet info>#<checksum>.
 *
 * where
 * <packet info> :: <characters representing the command or response>
 * <checksum>    :: < two hex digits computed as modulo 256 sum of <packetinfo>>
 *
 * When a packet is received, it is first acknowledged with either '+' or '-'.
 * '+' indicates a successful transfer.  '-' indicates a failed transfer.
 *
 * Example:
 *
 * Host:                  Reply:
 * $m0,10#2a               +$00010203040506070809101112131415#42
 *
 ****************************************************************************/

#include <sys/string.h>
#include <sys/signal.h>
#include "Debug_Lib.h"

/* BUFMAX defines the maximum number of characters in inbound/outbound buffers*/
#define BUFMAX 2048

#define JUMP_ADDR           0x20014     /* jump address   (IRAM:0x20014) */
#define SIG_FLAG           	0x20018     
#define REG_ADDR           	0x2001c     

/* This table contains the mapping between SPARC hardware trap types, and
   signals, which are primarily what GDB understands.  It also indicates
   which hardware traps we need to commandeer when initializing the stub. */

static struct hard_trap_info
{
    unsigned char tt;		/* Trap type code for SPARClite */
    unsigned char signo;		/* Signal that we map this trap into */
} hard_trap_info[] = {
    {1, SIGSEGV},			/* instruction access error */
    {2, SIGILL},			/* privileged instruction */
    {3, SIGILL},			/* illegal instruction */
    {4, SIGEMT},			/* fp disabled */
    {36, SIGEMT},			/* cp disabled */
    {7, SIGBUS},			/* mem address not aligned */
    {9, SIGSEGV},			/* data access exception */
    {10, SIGEMT},			/* tag overflow */
//    {128+1, SIGTRAP},	    /* ta 1 - normal breakpoint instruction */
    {128+1, 1},		        /* ta 1 - normal breakpoint instruction */
    {0, 0}			        /* Must be last */
};

static char remcomOutBuffer[BUFMAX];

static const char hexchars[]="0123456789abcdef";

enum regnames 
{
    G0, G1, G2, G3, G4, G5, G6, G7,
    O0, O1, O2, O3, O4, O5, SP, O7,
    L0, L1, L2, L3, L4, L5, L6, L7,
    I0, I1, I2, I3, I4, I5, FP, I7,

    F0, F1, F2, F3, F4, F5, F6, F7,
    F8, F9, F10, F11, F12, F13, F14, F15,
    F16, F17, F18, F19, F20, F21, F22, F23,
    F24, F25, F26, F27, F28, F29, F30, F31,
    Y, PSR, WIM, TBR, PC, NPC, FPSR, CPSR 
};


static inline int snake_mem_read(unsigned long paddr)
{
    unsigned long val;
    __asm__ __volatile__("lda [%1] %2, %0\n\t"
            : "=r" (val)
            : "r" (paddr), "i" (0x20));
    return val;
}

static inline void snake_mem_write(unsigned int val,unsigned int paddr)
{
    __asm__ __volatile__("sta %0, [%1] %2 \n\t"
            : /* no outputs */
            : "r" (val), "r" (paddr), "i" (0x20)
            : "memory");
}

/* Convert the memory pointed to by mem into hex, placing result in buf.
 * Return a pointer to the last char put in buf (null), in case of mem fault,
 * return 0.
 * If MAY_FAULT is non-zero, then we will handle memory faults by returning
 * a 0, else treat a fault like any other fault in the stub.
 */

static unsigned char *mem2hex (unsigned char *mem, unsigned char *buf, int count, int may_fault)
{
    unsigned char ch;

    while (count-- > 0)
    {
        ch = *mem++;
        *buf++ = hexchars[ch >> 4];
        *buf++ = hexchars[ch & 0xf];
    }

    *buf = 0;

    return buf;
}

/* Convert the SPARC hardware trap type code to a unix signal number. */

static int computeSignal (int tt)
{
    struct hard_trap_info *ht;

    for (ht = hard_trap_info; ht->tt && ht->signo; ht++)
    {
        if (ht->tt == tt)
            return ht->signo;
    }

    return SIGHUP;		/* default for things we don't know about */
}

void print_trap_error(int l0, int l1, int l2) /* print trap value */
{
	DEBUGMSG_SDK(MSGERR, "\nTRAP_error(t_NO: 0x%x )  PSR: 0x%08x, PC: 0x%08x \n",(l2>>4)&0xff,l0,l1); 
}

/*
 * This function does all command procesing for interfacing to gdb.  It
 * returns 1 if you should skip the instruction at the trap address, 0
 * otherwise.
 */
void handle_exception (unsigned long *registers)
{
    int tt;			/* Trap type */
    int sigval;
    int addr;
    int length;
    char *ptr;
    unsigned long *sp;

    /* First, we must force all of the windows to be spilled out */


    __asm__ __volatile__("	save %sp, -64, %sp \n\t \
                            save %sp, -64, %sp\n\t  \
                            save %sp, -64, %sp\n\t  \
                            save %sp, -64, %sp\n\t  \
                            save %sp, -64, %sp\n\t  \
                            save %sp, -64, %sp\n\t  \
                            save %sp, -64, %sp\n\t  \
                            save %sp, -64, %sp\n\t  \
                            restore\n\t  \
                            restore\n\t  \
                            restore\n\t  \
                            restore\n\t  \
                            restore\n\t  \
                            restore\n\t  \
                            restore\n\t  \
                            restore\n\t   ");


    sp = (unsigned long *)registers[SP];
    tt = (registers[TBR] >> 4) & 0xff;

    /* reply to host that an exception has occurred */
    sigval = computeSignal(tt);

    /* for Snake_OCD */ 
    snake_mem_write(sigval,(unsigned int )0x20004);

    ptr = remcomOutBuffer;

    *ptr++ = 'T';
    *ptr++ = hexchars[sigval >> 4];
    *ptr++ = hexchars[sigval & 0xf];

    *ptr++ = hexchars[PC >> 4];
    *ptr++ = hexchars[PC & 0xf];
    *ptr++ = ':';
    ptr = mem2hex((char *)&registers[PC], ptr, 4, 0);
    *ptr++ = ';';

    *ptr++ = hexchars[FP >> 4];
    *ptr++ = hexchars[FP & 0xf];
    *ptr++ = ':';
    ptr = mem2hex((char *)sp + 8 + 6, ptr, 4, 0); /* FP */
    *ptr++ = ';';

    *ptr++ = hexchars[SP >> 4];
    *ptr++ = hexchars[SP & 0xf];
    *ptr++ = ':';
    ptr = mem2hex((char *)&sp, ptr, 4, 0);
    *ptr++ = ';';

    *ptr++ = hexchars[NPC >> 4];
    *ptr++ = hexchars[NPC & 0xf];
    *ptr++ = ':';
    ptr = mem2hex((char *)&registers[NPC], ptr, 4, 0);
    *ptr++ = ';';

    *ptr++ = hexchars[O7 >> 4];
    *ptr++ = hexchars[O7 & 0xf];
    *ptr++ = ':';
    ptr = mem2hex((char *)&registers[O7], ptr, 4, 0);
    *ptr++ = ';';

    *ptr++ = 0;


    while (1)
    {
        remcomOutBuffer[0] = 0;

        __asm__ __volatile__(" flush \n\t");
        snake_mem_write((unsigned int)registers,(unsigned int)REG_ADDR);
        snake_mem_write(0,(unsigned int)JUMP_ADDR);
        snake_mem_write(sigval,(unsigned int)SIG_FLAG);

        do {

        } while( 0xcd !=(snake_mem_read(SIG_FLAG)));       /* leeyk: for snake_ocd */

        if ( snake_mem_read((unsigned int)JUMP_ADDR) !=0) 
        {
            registers[PC] = snake_mem_read((unsigned int)JUMP_ADDR); /* call address, jump */
            registers[NPC] = registers[PC]+4;
        }
        __asm__ __volatile__(" flush \n\t");

        return; 
    }
}

