
#include "APACHE.h"
//#include <asm/processor.h>

extern unsigned int pgd_table;
extern unsigned int _pgt_ctx;

void ab_mmu_on()
{
    unsigned int pgd_v;


    // ??????????
    pgd_v = (unsigned int)&pgd_table;
    ab_asi_io_write( (pgd_v >> 4) | 1, (unsigned int)&_pgt_ctx);


    srmmu_cache_flush();


    // MMU Disable
    srmmu_set_mmureg(DISABLE);


    // MMU page context pointer 0x27802000 for Viper - ????
    srmmu_set_ctable_ptr((unsigned long)&_pgt_ctx);
    srmmu_set_context(0);


    // MMU ENABLE
    srmmu_set_mmureg(ENABLE);


    srmmu_cache_flush();
}


