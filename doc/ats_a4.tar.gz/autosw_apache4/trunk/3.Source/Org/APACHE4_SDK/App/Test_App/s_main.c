/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#define __S_MAIN_C__

/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "test.h"











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

void APACHE_TEST_APP_Reboot(void)
{
    eTIMER_CH Ch = TC_CH0;       
    tTIMER_PARAM tTimerParam;


    // Timer Open
    ncLib_TIMER_Open();


    // Watchdog Timer Start
    tTimerParam.mMode	   = TC_MODE_WDT;
    tTimerParam.mPrescaler = 0;
    tTimerParam.mPeriod1   = 1; // Now (NoDelay)
    ncLib_TIMER_Control(GCMD_TC_INIT_CH, Ch, &tTimerParam, CMD_END );
    ncLib_TIMER_Control(GCMD_TC_START, Ch, CMD_END );


    // System Restart... 
    while(1);
    
}


void APACHE_TEST_APP_InitDebugPort(UINT32 nDbgZone_APP, UINT32 nDbgZone_SDK)
{ 
    // Open Debug Port (Used UART Interface)
    ncLib_DEBUG_Open();
    

    // Init Debug Port
    ncLib_DEBUG_Control(GCMD_DBG_INIT, UART_CH0, UT_BAUDRATE_115200, CMD_END);


    // APP Debug Zone - On/Off
    ncLib_DEBUG_Control(GCMD_DBG_APP_LOG_ZONE, nDbgZone_APP, ON, CMD_END);


    // SDK Debug Zone - On/Off
    ncLib_DEBUG_Control(GCMD_DBG_SDK_LOG_ZONE, nDbgZone_SDK, ON, CMD_END);
}


void APACHE_TEST_APP_InitInterface(void)
{
    //----------------------------------------------------------------------------
    // set pgt table (cache on/off)
    //----------------------------------------------------------------------------
    ab_mmu_on();


    //----------------------------------------------------------------------------
    // init default peripheral 
    //----------------------------------------------------------------------------
    ncLib_SCU_Open();
    ncLib_INTC_Open();
    ncLib_GPIO_Open();

    
    //----------------------------------------------------------------------------
    // init debug port (used uart-0)
    //----------------------------------------------------------------------------
    APACHE_TEST_APP_InitDebugPort(MSGFULL, MSGFULL); 
}


int main()
{   
    APACHE_TEST_APP_InitInterface();

    APACHE_TEST_APP_Main();

    APACHE_TEST_APP_Reboot();
    
    return 0;
}


#undef __S_MAIN_C__	



/* End of File */

