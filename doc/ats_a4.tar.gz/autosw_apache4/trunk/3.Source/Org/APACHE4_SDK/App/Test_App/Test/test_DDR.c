/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_DDR











/*
********************************************************************************
*                   	           DEFINES
********************************************************************************
*/

#define WRITE8(data, addr)              *((volatile unsigned char *)(addr))=data
#define READ8( addr )                   *((volatile unsigned char *)(addr))

#define WRITE16(data, addr)             *((volatile unsigned short *)(addr))=data
#define READ16( addr )                  *((volatile unsigned short *)(addr))

#define WRITE32(data, addr)             *((volatile unsigned int *)(addr))=data
#define READ32( addr )                  *((volatile unsigned int *)(addr))

#define TEST_MEM_BASE                   APACHE_DRAM_BASE
#define TEST_OFFSET                     (16*MB)
#define TEST_MEM_SIZE                   (256*MB)











/*
********************************************************************************
*                             VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL sDDR_DebugMsgOn = OFF;











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

void __ddr_test_clear_buff(UINT32 *pData, UINT32 size)
{
    UINT32 i;
    
    for(i=0;i<size/4;i++)
    {
        *pData++ = 0x00000000;
    }
}


INT32 APACHE_TEST_DDR_DataBus(UINT32 Addr)
{  
    INT32 i;
    UINT32 Pattern;
    UINT32 rData;

    DEBUGMSG(MSGINFO, "\r1");

    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n************* Memory Test Data Bus_1 ~~!! **************\n");

    // b'00000000 00000000 00000000 00000001
    // b'00000000 00000000 00000000 00000010
    // b'00000000 00000000 00000000 00000100
    // b'00000000 00000000 00000000 00001000
    // ~~
    // ~~
    // b'00010000 00000000 00000000 00000000
    // b'00100000 00000000 00000000 00000000
    // b'01000000 00000000 00000000 00000000
    // b'10000000 00000000 00000000 00000000
    for(Pattern=1; Pattern!=0; Pattern<<=1)
    {
        // Write the test pattern.
        WRITE32(Pattern, Addr);
        rData = READ32(Addr);

        if(sDDR_DebugMsgOn)
        {
            DEBUGMSG(MSGINFO, "0x%08x:", Addr);
            for(i=31; i>=0; --i)
                DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
            DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);	
        }

        if(rData != Pattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr, rData, Pattern);	
            //if(READ32(Addr) != Pattern)
                return -1;
        }
    }


    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n************* Memory Test Data Bus_2 ~~!! **************\n");
    // b'00000000 00000000 00000000 00000001
    // b'00000000 00000000 00000000 00000011
    // b'00000000 00000000 00000000 00000111
    // b'00000000 00000000 00000000 00001111
    // ~~
    // ~~
    // b'00011111 11111111 11111111 11111111
    // b'00111111 11111111 11111111 11111111
    // b'01111111 11111111 11111111 11111111
    for(Pattern=1; Pattern!=0xFFFFFFFF; Pattern|=(Pattern<<1))
    {
        WRITE32(Pattern, Addr);
        rData = READ32(Addr);

        if(sDDR_DebugMsgOn)
        {
            DEBUGMSG(MSGINFO, "0x%08x:", Addr);
            for(i=31; i>=0; --i)
                DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
            DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);	
        }

        if(rData != Pattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr, rData, Pattern);	
            //if(READ32(Addr) != Pattern)
                return -1;
        }
    }


    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n************* Memory Test Data Bus_3 ~~!! **************\n");
    // b'11111111 11111111 11111111 11111111
    // b'11111111 11111111 11111111 11111110
    // b'11111111 11111111 11111111 11111100
    // b'11111111 11111111 11111111 11111000
    // ~~
    // ~~
    // b'11110000 00000000 00000000 00000000
    // b'11100000 00000000 00000000 00000000
    // b'11000000 00000000 00000000 00000000
    for(Pattern=0xFFFFFFFF; Pattern!=0; Pattern<<=1)
    {
        WRITE32(Pattern, Addr);
        rData = READ32(Addr);

        if(sDDR_DebugMsgOn)
        {
            DEBUGMSG(MSGINFO, "0x%08x:", Addr);
            for(i=31; i>=0; --i)
                DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
            DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);	
        }

        if(rData != Pattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr, rData, Pattern);	
            //if(READ32(Addr) != Pattern)
                return -1;
        }
    }

    return 0;
}


INT32 APACHE_TEST_DDR_AddrBus(UINT32 Addr, UINT32 Bytes)
{  
    INT32 i;
    UINT32 Offset;
    UINT32 TestOffset;
    UINT32 AddrMask     = (Bytes-1)>>2;
    UINT32 Pattern      = 0xAAAAAAAA;
    UINT32 AntiPattern  = 0x55555555;
    UINT32 rData;


    DEBUGMSG(MSGINFO, "\r2");

    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n************* Memory Test Addr Bus wait ~~!! ***********\n");
    // Write the default pattern at each of the power-of-two offsets.
    // Offset
    // 0x00000001 -> 0x00000002 -> 0x00000004 -> 0x00000008
    // 0x00000010 -> 0x00000020 -> 0x00000040 -> 0x00000080
    // 0x00000100 -> 0x00000200 -> 0x00000400 -> 0x00000800
    // 0x00001000 -> 0x00002000 -> 0x00004000 -> 0x00008000
    // 0x00010000 -> 0x00020000 -> 0x00040000 -> 0x00080000
    // 0x00100000 -> 0x00200000 -> 0x00400000 -> 0x00800000
    // 0x01000000 -> End

    // Memory Address
    // 0x00000004 -> 0x00000008 -> 0x00000010 -> 0x00000020
    // 0x00000040 -> 0x00000080 -> 0x00000100 -> 0x00000200
    // 0x00000400 -> 0x00000800 -> 0x00001000 -> 0x00002000
    // 0x00004000 -> 0x00008000 -> 0x00010000 -> 0x00020000
    // 0x00040000 -> 0x00080000 -> 0x00100000 -> 0x00200000
    // 0x00400000 -> 0x00800000 -> 0x01000000 -> 0x02000000
    // 0x04000000 -> End
    for(Offset=1; (Offset&AddrMask)!=0; Offset<<=1)
    {
        WRITE32(Pattern, Addr+(Offset*4));		
        if(sDDR_DebugMsgOn)
            DEBUGMSG(MSGINFO, "\rPattern Write - [ 0x%08x : 0x%08x ]", Addr+(Offset*4), Pattern);
    }

    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n************* Memory Test Addr Bus_1 ~~!! **************\n");	
    // Check for address bits stuck high.
    WRITE32(AntiPattern, Addr);	

    if(sDDR_DebugMsgOn)
    {
        rData = READ32(Addr);
        DEBUGMSG(MSGINFO, "0x%08x:", Addr);
        for(i=31; i>=0; --i)
            DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
        DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);	
    }

    for(Offset=1; (Offset&AddrMask)!=0; Offset<<=1)
    {
        rData = READ32(Addr+(Offset*4));

        if(sDDR_DebugMsgOn)    
        {
            DEBUGMSG(MSGINFO, "0x%08x:", Addr+(Offset*4));
            for(i=31; i>=0; --i)
                DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
            DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);	
        }

        if(rData != Pattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+(Offset*4), rData, Pattern);	
            //if(READ32(Addr+(Offset*4)) != Pattern)
                return -1;
        }
    }


    // Check for address bits stuck low or shorted.
    WRITE32(Pattern, Addr);

    for(TestOffset=1; (TestOffset&AddrMask)!=0; TestOffset<<=1)
    {
        if(sDDR_DebugMsgOn)
            DEBUGMSG(MSGINFO, "\n************* Memory Test Addr Bus_2 ~~!! **************\n");

        WRITE32(AntiPattern, Addr+(TestOffset*4));

        rData = READ32(Addr);

        if(sDDR_DebugMsgOn)
        {
            DEBUGMSG(MSGINFO, "0x%08x:", Addr);
            for(i=31; i>=0; --i)
                DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
            DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);	
        }

        if(rData != Pattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr, rData, Pattern);	
            //if(READ32(Addr) != Pattern)
                return -1;
        }

        for(Offset=1; (Offset&AddrMask)!=0; Offset<<=1)
        {
            rData = READ32(Addr+(Offset*4));

            if(sDDR_DebugMsgOn)
            {
                DEBUGMSG(MSGINFO, "0x%08x:", Addr+(Offset*4));
                for(i=31; i>=0; --i)
                    DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
                DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);
            }

            if((rData!=Pattern)&&(Offset!=TestOffset))
            {
                DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+(Offset*4), rData, Pattern);	
                //if(READ32(Addr+(Offset*4))!=Pattern)
                    return -1;
            }
        } 
        WRITE32(Pattern, Addr+(TestOffset*4));
    } 


    return 0;
}


INT32 APACHE_TEST_DDR_08bit(UINT32 Addr, UINT32 Bytes)
{
    UINT32 Offset;
    UINT32 OffsetLimit = Bytes; 
    UINT32 Pattern;
    UINT32 Antipattern;
    UINT32 rData;

    DEBUGMSG(MSGINFO, "\r3");

    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n\n************* Memory Test (08bit)~~!! *********************************************\n");

    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset++)
    {
        WRITE8((Pattern&0xFF), Addr+Offset); 

        if(sDDR_DebugMsgOn)
        {
            if(!(Offset%0x1000) )
                DEBUGMSG(MSGINFO, "\rData Write - [ 0x%08x : 0x%02x ]", Addr+Offset, (Pattern&0xFF));
        }
    }


    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n************* Memory Test (08bit) 01 ~~!! *****************************************");

    // Check each location and invert it for the second pass.
    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset++)
    {
        rData = READ8(Addr+Offset);

        if(sDDR_DebugMsgOn)
        {
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            if(!(Offset%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%02x", rData);	
        }

        if((rData&0xFF) != (Pattern&0xFF))
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+Offset, rData, (Pattern&0xFF));	
            //if(READ8(Addr+Offset) != (UINT8)(Pattern&0xFF))
                return -1;
        }

        Antipattern = ~Pattern;
        WRITE8((Antipattern&0xFF), Addr+Offset);		
    } 

    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n************* Memory Test (08bit) 02 ~~!! *****************************************");

    // Check each location for the inverted pattern and zero it.
    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset++)
    {
        Antipattern = ~Pattern;
        rData = READ8(Addr+Offset);

        if(sDDR_DebugMsgOn)
        {
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            if(!(Offset%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%02x", rData);	
        }

        if((rData&0xFF) != (Antipattern&0xFF))
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+Offset, rData, (Antipattern&0xFF));	
            //if(READ8(Addr+Offset) != (UINT8)(Antipattern&0xFF))
                return -1;
        }
    } 

    return 0;
}


INT32 APACHE_TEST_DDR_16bit(UINT32 Addr, UINT32 Bytes)
{
    UINT32 Offset;
    UINT32 OffsetLimit = Bytes; 
    UINT32 Pattern;
    UINT32 Antipattern;
    UINT32 rData;

    DEBUGMSG(MSGINFO, "\r4");

    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n\n************* Memory Test (16bit)~~!! *********************************************\n");

    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset+=2)
    {
        WRITE16((Pattern&0xFFFF), Addr+Offset); 

        if(sDDR_DebugMsgOn)
        {
            if(!(Offset%0x1000) )
                DEBUGMSG(MSGINFO, "\rData Write - [ 0x%08x : 0x%04x ]", Addr+Offset, (Pattern&0xFFFF));
        }
    }


    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n************* Memory Test (16bit) 01 ~~!! *****************************************");

    // Check each location and invert it for the second pass.
    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset+=2)
    {
        rData = READ16(Addr+Offset);

        if(sDDR_DebugMsgOn)
        {
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            if(!(Offset%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%04x", rData);			
        }

        if((rData&0xFFFF) != (Pattern&0xFFFF))
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+Offset, rData, (Pattern&0xFFFF));	
            //if(READ16(Addr+Offset) != (UINT16)(Pattern&0xFFFF))
                return -1;
        }

        Antipattern = ~Pattern;
        WRITE16((Antipattern&0xFFFF), Addr+Offset);		
    } 


    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n************* Memory Test (16bit) 02 ~~!! *****************************************");

    // Check each location for the inverted pattern and zero it.
    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset+=2)
    {
        Antipattern = ~Pattern;
        rData = READ16(Addr+Offset);

        if(sDDR_DebugMsgOn)
        {
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            if(!(Offset%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%04x", rData);	
        }

        if((rData&0xFFFF) != (Antipattern&0xFFFF))
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+(Offset*2), rData, (Antipattern&0xFFFF));	
            //if(READ16(Addr+Offset) != (UINT16)(Antipattern&0xFFFF))
                return -1;
        }
    } 

    return 0;
}


INT32 APACHE_TEST_DDR_32bit(UINT32 Addr, UINT32 Bytes)
{
    UINT32 Offset;
    UINT32 OffsetLimit = Bytes; 
    UINT32 Pattern;
    UINT32 Antipattern;
    UINT32 rData;

    DEBUGMSG(MSGINFO, "\r5");

    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n\n************* Memory Test (32bit)~~!! *********************************************\n");

    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset+=4)
    {
        WRITE32(Pattern, Addr+Offset); 

        if(sDDR_DebugMsgOn)
        {
            if(!(Offset%0x1000) )
            DEBUGMSG(MSGINFO, "\rData Write - [ 0x%08x : 0x%04x ]", Addr+Offset, Pattern);
        }
    }


    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n************* Memory Test (32bit) 01 ~~!! *****************************************");

    // Check each location and invert it for the second pass.
    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset+=4)
    {
        rData = READ32(Addr+Offset);

        if(sDDR_DebugMsgOn)
        {
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            if(!(Offset%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%08x", rData);	
        }

        if(rData != Pattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+Offset, rData, Pattern);	
            //if(READ32(Addr+Offset) != Pattern)
                return -1;
        }

        Antipattern = ~Pattern;
        WRITE32(Antipattern, Addr+Offset);		
    } 

    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n************* Memory Test (32bit) 02 ~~!! *****************************************");

    // Check each location for the inverted pattern and zero it.
    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset+=4)
    {
        Antipattern = ~Pattern;
        rData = READ32(Addr+Offset);

        if(sDDR_DebugMsgOn)
        {
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            if(!(Offset%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%04x", rData);	
        }

        if(rData != Antipattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+Offset, rData, Antipattern);	
            //if(READ32(Addr+Offset) != Antipattern)
                return -1;
        }
    } 

    return 0;
}


#define PATTERN_MAX	64
INT32 APACHE_TEST_DDR_MemCopy(UINT32 StartAddr, UINT32 EndAddr)
{
    UINT32 i, j;
    UINT32 *pAddr;
    UINT32 Addr;
    UINT32 Size;
    UINT32 Pattern[PATTERN_MAX] ={  0xF2000000, 0xFFFF0001, 0xFFFF0010, 0xFFFF0100, 0xFFFF1000, 0xFFFF1110, 0x0001FFFF, 0x0010FFFF,
                                    0x11111111, 0x22222222, 0x33333333, 0x44444444, 0x55555555, 0x66666666, 0x77777777, 0x88888888,
                                    0x99999999, 0xAAAAAAAA, 0xBBBBBBBB, 0xCCCCCCCC, 0xDDDDDDDD, 0xEEEEEEEE, 0xFFFFFFFF, 0xFFFF0000,
                                    0x0000FFFF, 0xF0F0F0F0, 0x0F0F0F0F, 0xFF00FF00, 0x00FF00FF, 0x3C3C3C3C, 0xA5A5A5A5, 0x5A5A5A5A,
                                    0x80000000, 0xF8000000, 0xFF800000, 0xFFF80000, 0xFFFF8000, 0xFFFFF800, 0xFFFFFF80, 0xFFFFFFF8,
                                    0x40000000, 0xF4000000, 0xFF400000, 0xFFF40000, 0xFFFF4000, 0xFFFFF400, 0xFFFFFF40, 0xFFFFFFF4,
                                    0x20000000, 0xFFFF0000, 0xFF200000, 0xFFF20000, 0xFFFF2000, 0xFFFFF200, 0xFFFFFF20, 0xFFFFFFF2,
                                    0x10000000, 0xF1000000, 0xFF100000, 0xFFF10000, 0xFFFF1000, 0xFFFFF100, 0xFFFFFF10, 0xFFFFFFF1};

    DEBUGMSG(MSGINFO, "\r6");

    if(sDDR_DebugMsgOn)
    {
        DEBUGMSG(MSGINFO, "\n\n************* Memory_Test_MemCpy Wait~~!! *****************************************\n");

        for(i=0; i<PATTERN_MAX; i++)
        {
            if(!((i<<2)%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", &Pattern[i]);
            if(!((i<<2)%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%08x", Pattern[i]);	
        }
        DEBUGMSG(MSGINFO, "\n");
    }

    Addr  = StartAddr;
    Size  = sizeof(Pattern);
    while((Addr+Size) <= EndAddr)
    {
        memcpy((void*)Addr, (void*)Pattern, Size);
        Addr+=Size;

        if(sDDR_DebugMsgOn)
        {
            if(!(Addr%0x1000) )
                DEBUGMSG(MSGINFO, "\rPattern Write - [ 0x%08x ]", Addr);
        }
    };

    if(sDDR_DebugMsgOn) 
    {
        DEBUGMSG(MSGINFO, "\n************* Memory_Test_MemCpy 1~~!! ********************************************\n");	

        for(i=0; i<PATTERN_MAX; i++)
        {
            if(!((i<<2)%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", &Pattern[i]);
            if(!((i<<2)%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%08x", Pattern[i]);	
        }
        DEBUGMSG(MSGINFO, "\n");
    }

    Addr  = StartAddr;
    pAddr = (UINT32*)StartAddr;
    while((Addr+Size) <= EndAddr)
    {

        if(sDDR_DebugMsgOn) 
        {
            if(!(Addr%0x1000) )
                DEBUGMSG(MSGINFO, "\rPattern Check - [ 0x%08x ]", pAddr);
        }

        for(i=0; i<PATTERN_MAX; i++)
        {
            if(*pAddr != Pattern[i])
            {
                DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x %d\n", pAddr, *pAddr, Pattern[i], i);	

                for(i=0; i<PATTERN_MAX; i++)
                {
                    if(!((i<<2)%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", &Pattern[i]);
                    if(!((i<<2)%4)) DEBUGMSG(MSGINFO, " ");
                    DEBUGMSG(MSGINFO, "%08x", Pattern[i]);	
                }
                DEBUGMSG(MSGINFO, "\n");
                //if(*pAddr != Pattern[i])
                    return -1;
            }
            pAddr++;
        }
        Addr=(UINT32)pAddr;
    };

    if(sDDR_DebugMsgOn)
    {
        DEBUGMSG(MSGINFO, "\n***********************************************************************************");	

        pAddr-=Size;
        for(i=0; i<PATTERN_MAX; i++)
        {
            if(!(((UINT32)pAddr)%0x20)) 
                DEBUGMSG(MSGINFO, "\n0x%08x:", pAddr);
            DEBUGMSG(MSGINFO, " %08x", *pAddr++);
        }	
    }

    if(sDDR_DebugMsgOn)
        DEBUGMSG(MSGINFO, "\n\n************* Memory_Test_MemCpy 2~~!! *****************\n");	

    Size = (EndAddr-StartAddr)/16;
    for(i=0; i<PATTERN_MAX; i++)
    {
        pAddr = (UINT32*)StartAddr;
        for(j=0; j<Size ; j+=4)
            *pAddr++ = Pattern[i];

        if(sDDR_DebugMsgOn)
            DEBUGMSG(MSGINFO, " [%02d: 0x%08x ~ 0x%08x : 0x%08x]\n", i, StartAddr, pAddr, Pattern[i]);

        while((UINT32)(pAddr+(Size/4)) <= EndAddr)
        {
            if(sDDR_DebugMsgOn)
                DEBUGMSG(MSGINFO, " [%02d: 0x%08x ~ 0x%08x : 0x%08x]\n", i, pAddr, pAddr+(Size/4), Pattern[i]);

            memcpy((void*)pAddr, (void*)StartAddr, Size);
            pAddr+=(Size/4);
        };

        pAddr = (UINT32*)StartAddr;
        while((UINT32)pAddr < EndAddr)
        {
            if(sDDR_DebugMsgOn)
            {
                if(!(((UINT32)pAddr)%0x1000) )
                    DEBUGMSG(MSGINFO, "\rPattern Check - [ 0x%08x ]", pAddr);
            }

            if(*pAddr != Pattern[i])
            {
                DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x %d\n", pAddr, *pAddr, Pattern[i], i);	
                //if(*pAddr != Pattern[i])
                    return -1;
            }
            pAddr++;
        };
        if(sDDR_DebugMsgOn)
            DEBUGMSG(MSGINFO, "\n");
    }

    return 0;
}


INT32 APACHE_TEST_DDR_ErrorCase_01(UINT32 Addr, UINT32 OffsetLimit)
{
    UINT32 Offset;
    UINT32 rData;

    DEBUGMSG(MSGINFO, "\r7");

    if(sDDR_DebugMsgOn) 
        DEBUGMSG(MSGINFO, "\n\n************* Memory Test (Error Case 1)~~!! ***********\n");

    for(Offset=0; Offset<OffsetLimit; Offset+=8)
    {
        WRITE32(0x77777777, Addr+Offset); 
        WRITE32(0x88888888, Addr+Offset+4); 
    }

    if(sDDR_DebugMsgOn)
    {
        for(Offset=0; Offset<OffsetLimit; Offset+=4)
        {
            rData = READ32(Addr+Offset);
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            DEBUGMSG(MSGINFO, " %04x", rData);	
        } 
        DEBUGMSG(MSGINFO, "\n");	
    }

    for(Offset=0; Offset<OffsetLimit; Offset+=8)
    {
        rData = READ32(Addr+Offset);

        if(rData != 0x77777777)
        {
            DEBUGMSG(MSGINFO, "   0x%08x: %08x vs %08x\n", Addr+Offset, rData, 0x77777777);	
            //if(READ32(Addr+Offset) != 0x77777777)
                return -1;
        }
    } 

    return 0;
}


#define TEST_PATTERN_MAX    4
INT32 APACHE_TEST_DDR_ErrorCase_02(UINT32 Addr, UINT32 Bytes)
{
    UINT32 i;
    UINT32 Offset;
    UINT32 rData;
    UINT32 Pattern[TEST_PATTERN_MAX] = { 0x00000000, 0xFFFEFDFC, 0x03020100, 0x00000000 };

    DEBUGMSG(MSGINFO, "\r8");
    
    //__ddr_test_clear_buff((UINT32*) Addr, Bytes);

    for(Offset = 0x00F8; Offset<(Bytes-0x0100); Offset += 0x0100)
    {
        for(i=0; i<TEST_PATTERN_MAX; i++)
        {
            WRITE32(Pattern[i], Addr+ Offset+(i*4));
        }

        for(i=0; i<TEST_PATTERN_MAX; i++)
        {
            rData = READ32(Addr + Offset+(i*4));
            if(rData != Pattern[i])
            {
                DEBUGMSG(MSGINFO, "   0x%08x: %08x vs %08x\n", Addr+Offset+(i*4), rData, Pattern[i]);
                //if(REGRW32(Addr + Offset+(i*4)) != Pattern[i])
                    return -1; 
            }
        }
    }

    return 0;
}


INT32 APACHE_TEST_DDR_CUTMode(void)
{
    INT32 ret;
    INT32 select;
    char buf[16];
    UINT32 Addr = (TEST_MEM_BASE + TEST_OFFSET);
    UINT32 Size = (TEST_MEM_SIZE - TEST_OFFSET);
    UINT32 i = 1;


    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - DDR                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Memory Test                                                \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> Data Bus                                               \n");
        DEBUGMSG(MSGINFO, " <2> Address Bus                                            \n");
        DEBUGMSG(MSGINFO, " <3> 8bit Address                                           \n");
        DEBUGMSG(MSGINFO, " <4> 16bit Address                                          \n");
        DEBUGMSG(MSGINFO, " <5> 32bit Address                                          \n");
        DEBUGMSG(MSGINFO, " <6> Memory Copy                                            \n");
        DEBUGMSG(MSGINFO, " <7> Apache DDR Error Case -1 (Winbond)                     \n"); 
        DEBUGMSG(MSGINFO, " <8> Apache DDR Error Case -2 (Winbond)                     \n"); 
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <a> (1)~(8) Full Test (long time)                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ...                        \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");
        
        switch(select)
        {
            case 1:
                ret = APACHE_TEST_DDR_DataBus(Addr);
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;

            case 2:
                ret = APACHE_TEST_DDR_AddrBus(Addr, Size);
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;

            case 3:
                ret = APACHE_TEST_DDR_08bit(Addr, (0x100*1));
                //ret = APACHE_TEST_DDR_08bit(Addr, Size);
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;

            case 4:
                ret = APACHE_TEST_DDR_16bit(Addr, (0x10000*2));
                //ret = APACHE_TEST_DDR_16bit(Addr, Size);
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;

            case 5:
                ret = APACHE_TEST_DDR_32bit(Addr, (0x10000*4));
                //ret = APACHE_TEST_DDR_32bit(Addr, Size);
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;	

            case 6:
                ret = APACHE_TEST_DDR_MemCopy(Addr, Addr+0x80000);
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;

            case 7:
                ret = APACHE_TEST_DDR_ErrorCase_01(Addr, (0x10000*4));
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;	

            case 8:
                ret = APACHE_TEST_DDR_ErrorCase_02(Addr, (0x10000*4));
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;

            case 10: // a
            {
                //for(i=1; i<=1000; i++)
                {                    
                    if( 
                       (APACHE_TEST_DDR_ErrorCase_01(Addr, Size) != 0)
                    || (APACHE_TEST_DDR_ErrorCase_02(Addr, Size) != 0)
                    || (APACHE_TEST_DDR_DataBus(Addr) != 0)
                    || (APACHE_TEST_DDR_AddrBus(Addr, Size) != 0)
                    || (APACHE_TEST_DDR_08bit(Addr, Size) != 0)
                    || (APACHE_TEST_DDR_16bit(Addr, Size) != 0)
                    || (APACHE_TEST_DDR_32bit(Addr, Size) != 0)
                    || (APACHE_TEST_DDR_MemCopy(Addr, Addr+Size) != 0)
                    )
                    {
                        DEBUGMSG(MSGINFO, "\n >> Memory Test Fail - %dth\n", i);
                        break;
                    }
                    else
                    {
                        DEBUGMSG(MSGINFO, "\n >> Memory Test OK - %dth\n", i);
                    }
                }
            }
            break;	

            case 35: // z
                _REVERSE(sDDR_DebugMsgOn);
            break;	
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto DDR_Exit;
        }
    }

    DDR_Exit:

    return NC_SUCCESS;
}


#endif  /* ENABLE_IP_DDR */



/* End Of File */

