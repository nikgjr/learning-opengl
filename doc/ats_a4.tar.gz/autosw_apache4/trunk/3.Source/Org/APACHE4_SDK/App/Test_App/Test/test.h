/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __TEST_H__
#define __TEST_H__

/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "APACHE.h"












/*
********************************************************************************
*                   	           DEFINES
********************************************************************************
*/

#define TEST_APP_VER_MAJOR              7
#define TEST_APP_VER_MINOR1             8
#define TEST_APP_VER_MINOR2             1

#define TEST_APP_BUILD_DATE             __DATE__
#define TEST_APP_BUILD_TIME             __TIME__


#define ENABLE_IP_DDR                   TRUE
#define ENABLE_IP_FPU                   FALSE
#define ENABLE_IP_TIMER                 TRUE
#define ENABLE_IP_GPIO                  TRUE
#define ENABLE_IP_I2C                   TRUE
#define ENABLE_IP_PWM                   TRUE
#define ENABLE_IP_SPI                   TRUE
#define ENABLE_IP_SF                    TRUE
#define ENABLE_IP_DMAC                  TRUE
#define ENABLE_IP_UART                  TRUE
#define ENABLE_IP_NAND                  TRUE
#define ENABLE_IP_CORE                  TRUE











/*
********************************************************************************
*                                  ENUMERATION
********************************************************************************
*/

typedef enum _TEST_LIST
{
    FPGA_IP_TEST_QUIT = 0,      ///< 0 Quit

    // Unit Test

    FPGA_IP_TEST_DDR,           ///< 1 - DDR Test   
    FPGA_IP_TEST_DMAC,          ///< 2 - DMAC Test
    FPGA_IP_TEST_TIMER,         ///< 3 - Timer Test
    FPGA_IP_TEST_PWM,           ///< 4 - PWM Test
    FPGA_IP_TEST_I2C,           ///< 5 - I2C Test
    FPGA_IP_TEST_SPI,           ///< 6 - SPI Test
    FPGA_IP_TEST_GPIO,          ///< 7 - GPIO Test     
    FPGA_IP_TEST_UART,          ///< 8 - UART Test
    FPGA_IP_TEST_9,             ///< 9 - Reserved

    FPGA_IP_TEST_A,             ///< a - Reserved
    FPGA_IP_TEST_B,             ///< b - Reserved
    FPGA_IP_TEST_CORE,          ///< c - Core Mask Test
    FPGA_IP_TEST_D,             ///< d - Reserved
    FPGA_IP_TEST_E,             ///< e - Reserved

    FPGA_IP_TEST_FPU,           ///< f - FPU Test
    FPGA_IP_TEST_G,             ///< g - Reserved
    FPGA_IP_TEST_H,             ///< h - Reserved
    FPGA_IP_TEST_I,             ///< i - Reserved
    FPGA_IP_TEST_J,             ///< j - Reserved
    FPGA_IP_TEST_K,             ///< k - Reserved
    FPGA_IP_TEST_L,             ///< l - Reserved
    FPGA_IP_TEST_M,             ///< m - Reserved
    FPGA_IP_TEST_NAND,          ///< n - Nand Test

    FPGA_IP_TEST_O,             ///< o - Reserved
    FPGA_IP_TEST_P,             ///< p - Reserved
    FPGA_IP_TEST_Q,             ///< q - Reserved
    FPGA_IP_TEST_R,             ///< r - Reserved
    FPGA_IP_TEST_SF,            ///< s - sFlash Test (sflash Interface)
    FPGA_IP_TEST_T,             ///< t - Reserved
    FPGA_IP_TEST_U,             ///< u - Reserved
    FPGA_IP_TEST_V,             ///< v - Reserved
    FPGA_IP_TEST_W,             ///< w - Reserved
    FPGA_IP_TEST_X,             ///< x - Reserved
    FPGA_IP_TEST_Y,             ///< y - Reserved
    
    SCENARIO_CHIP_TESTING,      ///< z -  Reserved

    MAX_OF_FPGA_IP_TEST
} eTEST_LIST;


/*
 *----------------------------
 *  Only FPGA Debug GPIO Port 
 *  0x90D01040 [11:8]
 *      -. PORT0[8]
 *      -. PORT1[9]
 *      -. PORT2[10] 
 *      -. PORT3[11]
 *----------------------------
 */
typedef enum
{
    DBG_GPIO_PORT0,
    DBG_GPIO_PORT1,
    DBG_GPIO_PORT2,
    DBG_GPIO_PORT3,

    DBG_MAX_OF_GPIO_PORT,
} eDBG_GPIO_PORT;











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

// Test Main 
extern INT32 APACHE_TEST_APP_Main(void);


#if ENABLE_IP_DDR
// 1 - DDR Test Functions
extern INT32 APACHE_TEST_DDR_CUTMode(void);
#endif


#if ENABLE_IP_DMAC
// 2 - DMA Functions 
extern INT32 APACHE_TEST_DMA_CUTMode(void);
#endif


#if ENABLE_IP_TIMER
// 3 - TIMER Test Functions
extern INT32 APACHE_TEST_TIMER_CUTMode(void);
#endif


#if ENABLE_IP_PWM
// 4 - PWM Test Functions 
extern INT32 APACHE_TEST_PWM_CUTMode(void);
#endif


#if ENABLE_IP_I2C
// 5 - I2C Test Functions
extern INT32 APACHE_TEST_I2C_CUTMode(void);
#endif


#if ENABLE_IP_SPI
// 6 - SPI Test Functions
extern INT32 APACHE_TEST_SSP_CUTMode(void);
#endif


#if ENABLE_IP_GPIO
// 7 - GPIO Functions
extern INT32 APACHE_TEST_GPIO_CUTMode(void);
#endif

#if ENABLE_IP_UART
// 8 - UART Functions
extern INT32 APACHE_TEST_UART_CUTMode(void);
#endif


#if ENABLE_IP_CORE
// C - Core
extern INT32 APACHE_TEST_CORE_CUTMode(void);
#endif


#if ENABLE_IP_FPU
// F - FPU Test Functions
extern INT32 APACHE_TEST_FPU_CUTMode(void);
#endif


#if ENABLE_IP_NAND
// N - Nand Functions
extern INT32 APACHE_TEST_NAND_CUTMode(void);
#endif


#if ENABLE_IP_SF
// S - sFlash Functions
extern INT32 APACHE_TEST_SF_CUTMode(void);
#endif


// test_Utils.c
extern void  APACHE_TEST_DebugGPIOToggle(UINT32 Port);
extern void  APACHE_TEST_DebugGPIOInit(UINT32 Port);

extern INT32 APACHE_TEST_Asc2Int(char ch);
extern INT32 APACHE_TEST_AtoI(char *Str);

extern void  APACHE_TEST_GetArrowKey_Help(char* UpStr, char* DownStr, char* RightStr, char* LeftStr);
extern INT8  APACHE_TEST_GetArrowKey(INT8 buf);
extern INT8  APACHE_TEST_WaitKey(void);
extern BOOL  APACHE_TEST_mTimeOut(UINT32 mSec);
extern void  APACHE_TEST_StopWatch(BOOL OnOff);

#endif  /* __TEST_H__ */



/* End Of File */

