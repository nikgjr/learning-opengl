/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#define __S_MAIN_C__

/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "APACHE.h"











/*
********************************************************************************
*                   	           DEFINES
********************************************************************************
*/

#define CAM_APP_VER_MAJOR              0
#define CAM_APP_VER_MINOR1             0
#define CAM_APP_VER_MINOR2             1

#define CAM_APP_BUILD_DATE             __DATE__
#define CAM_APP_BUILD_TIME             __TIME__











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __debug_display_clock(void)
{
    DEBUGMSG(MSGINFO, STR_CLEAR_SCREEN);      
    DEBUGMSG(MSGINFO, "\n============================================================\n");
    DEBUGMSG(MSGINFO, "   CAM APP Version: [v%d.%d.%d]    [%s, %s]\n",
                      CAM_APP_VER_MAJOR, CAM_APP_VER_MINOR1, CAM_APP_VER_MINOR2, CAM_APP_BUILD_DATE, CAM_APP_BUILD_TIME);
    DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
    
    // Display Clock
    DEBUGMSG(MSGINFO, "    CPU   : %7d KHz    AXI   : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_CPU, CMD_END)/KHZ,   
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_AXI, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "    APB   : %7d KHz    SSPI  : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_APB, CMD_END)/KHZ,
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_SSPI, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "    QSPI  : %7d KHz    UART  : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_QSPI, CMD_END)/KHZ,  
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_UART, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "    TIMER : %7d KHz    I2C   : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_TIMER, CMD_END)/KHZ, 
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_I2C, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "    DDR   : %7d KHz    PWM   : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_DDR, CMD_END)/KHZ,
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_PWM, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
}



void APACHE_APP_InitInterface(void)
{
    //----------------------------------------------------------------------------
    // set pgt table (cache on/off)
    //----------------------------------------------------------------------------
    ab_mmu_on();


    //----------------------------------------------------------------------------
    // init default peripheral 
    //----------------------------------------------------------------------------
    ncLib_SCU_Open();
    ncLib_INTC_Open();
    ncLib_GPIO_Open();
    ncLib_UART_Open();
    ncLib_I2C_Open();

    

    //----------------------------------------------------------------------------
    // init Debug Port (Used UART Interface)
    //----------------------------------------------------------------------------
    ncLib_DEBUG_Open();
    ncLib_DEBUG_Control(GCMD_DBG_INIT, UART_CH0, UT_BAUDRATE_115200, CMD_END);
    ncLib_DEBUG_Control(GCMD_DBG_APP_LOG_ZONE, MSGFULL, ON, CMD_END);
    ncLib_DEBUG_Control(GCMD_DBG_SDK_LOG_ZONE, MSGFULL, ON, CMD_END);
    __debug_display_clock();


    //----------------------------------------------------------------------------
    // init Jig Port (Used UART Interface)
    //----------------------------------------------------------------------------
	ncLib_JIG_Open();
    //ncLib_JIG_Control(GCMD_JIG_INIT, UART_CH1, UT_BAUDRATE_57600, CMD_END);
    ncLib_JIG_Control(GCMD_JIG_INIT, UART_CH1, UT_BAUDRATE_38400, CMD_END);
}


int main()
{   
    // Init Default interface
    APACHE_APP_InitInterface();


    while(1)
    {
        ncLib_JIG_Control(GCMD_JIG_DO_COMMAND, CMD_END);
    }
    
    return 0;
}


#undef __S_MAIN_C__	



