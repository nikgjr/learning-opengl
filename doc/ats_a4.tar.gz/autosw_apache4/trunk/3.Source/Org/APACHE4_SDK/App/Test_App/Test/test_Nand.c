/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_NAND


//------------------------------------------------------------------------------
// Ab_fmc.h

#ifdef FMC_DEVICE_K9F1G08
	#define FMC_DEV_PAGE_BYTES_D			(2048+64)	// page's data bytes
#else
	#define FMC_DEV_PAGE_BYTES_D			(4096+224)	// page's data bytes of H27UAG8T2A
#endif


//--------------------------------------------------------------------
// fmc control structure
//--------------------------------------------------------------------
typedef struct AB_Fmc_Struct {
	// Setting up structure
	struct {
		unsigned	en_intr;
		unsigned	no_lp_mode;
		unsigned	en_ecc_intr;
		unsigned	en_wp_mode;
		// [27:25] t_prescale: prescaler, shift the counter bits by n.
		// [24:22] t_rr : busy to re_n (default=0)
		//                     between busy's up and ren
		// [21:19] t_alr: ID read time, 
		//                     between 'ale fall' and new data phase
		// [18:16] t_cea: ce access time
		//                     between 'ce 0' and new data phase
		// [15:12] t_wl : wen deassertion time (default=1)
		// [11:08] t_wh : wen assertion time (default=1)
		// [07:04] t_rh : ren deassertion time (default=1)
		// [03:00] t_rl : ren assertion time (default=1)
		unsigned	t_prescale:3;
		unsigned	t_rr:3;
		unsigned	t_alr:3;
		unsigned	t_cea:3;
		unsigned	t_wl:4;
		unsigned	t_wh:4;
		unsigned	t_rl:4;
		unsigned	t_rh:4;

		// fmc base address ([31:24])
		// (note) fmc pfr base is defined otherwise.
		unsigned	fmc_base;
	} setup;

	// Status
	struct {
		unsigned	st_run;
		unsigned	st_intr;
		unsigned	st_ecc_intr;
	} stat;

	// fmc cmd phase (to axi address/data)
	struct {
		unsigned	c_start_cmd;
		unsigned	c_n_addr_cycs;
		unsigned	c_end_cmd_v;
		unsigned	c_end_cmd;
		unsigned	c_rw;
		unsigned	c_addr_h_v;	// higher 32-bit is valid?
		unsigned	c_addr[8];

		// fmc data phase (to axi address)
		unsigned	d_clrcs;
		unsigned	d_end_cmd_v;
		unsigned	d_end_cmd;
		unsigned	d_ecc_last;
	} pcmd;

	// nand data storage
	struct {
		// write data, read data
		unsigned	cnt_data;
		unsigned	data[FMC_DEV_PAGE_BYTES_D];
	} pd;

} ABmFmc;


//--------------------------------------------------------------------
// fmc sfr, register's addr offset
//--------------------------------------------------------------------
#define FMC_OFFA_STATUS			(0x0000)	// sfr 'status'
#define FMC_OFFA_SETCFG			(0x0004)	// sfr 'set conf. regs'
#define FMC_OFFA_CLRCFG			(0x0008)	// sfr 'clear conf. regs'
#define FMC_OFFA_CYCREG			(0x000c)	// sfr 'nand cycles'

#define FMC_ADDR_STATUS			(APACHE_NANDC_BASE+FMC_OFFA_STATUS)
#define FMC_ADDR_SETCFG			(APACHE_NANDC_BASE+FMC_OFFA_SETCFG)
#define FMC_ADDR_CLRCFG			(APACHE_NANDC_BASE+FMC_OFFA_CLRCFG)
#define FMC_ADDR_CYCREG			(APACHE_NANDC_BASE+FMC_OFFA_CYCREG)

//--------------------------------------------------------------------
// fmc sfr's mask values
//--------------------------------------------------------------------
// sfr 'status'
#define FMC_STAT_MASK_RUN		(0x0001)	// nand is running?
#define FMC_STAT_MASK_INTR		(0x0002)	// intr is generated?
#define FMC_STAT_MASK_ECCINTR	(0x0004)	// ecc.intr is generated?

// sfr 'set conf. regs'
#define FMC_SETC_MASK_ENINT		(0x0001)	// enable int
#define FMC_SETC_MASK_ENLP		(0x0002)	// enable lp mode
#define FMC_SETC_MASK_ENECCINT	(0x0004)	// enable ecc.int
#define FMC_SETC_MASK_ENWP		(0x0008)	// enable write protection

// sfr 'clear conf. regs'
#define FMC_CLRC_MASK_CLRINT	(0x0001)	// clear int
//#define FMC_CLRC_MASK_VACANT
#define FMC_CLRC_MASK_CLRECCINT	(0x0004)	// clear ecc.int

// sfr 'nand cycles', bit position
#define FMC_NANC_BIT_PRESCALE		(25)
#define FMC_NANC_BIT_RR				(22)
#define FMC_NANC_BIT_ALR			(19)
#define FMC_NANC_BIT_CEA			(16)
#define FMC_NANC_BIT_WL				(12)
#define FMC_NANC_BIT_WH				(8)
#define FMC_NANC_BIT_RL				(4)
#define FMC_NANC_BIT_RH				(0)

//-----------------------------------------------------
// page program options 
//-----------------------------------------------------
#define PAGE_PROGRAM 0
#define PAGE_CACHE_PROGRAM 1


//-----------------------------------------------------
// fmc driver functions
//-----------------------------------------------------
extern int ab_fmc_setup(ABmFmc *);
extern int ab_fmc_block_erase(ABmFmc *, unsigned, unsigned);
extern int ab_fmc_page_write(ABmFmc *pfmc, unsigned cache_program_flag, unsigned addrl, unsigned addrh);
extern int ab_fmc_page_read(ABmFmc *, unsigned, unsigned);
extern int ab_fmc_page_random_read(ABmFmc *, unsigned, unsigned);
extern int ab_fmc_read_id(ABmFmc *);
extern int ab_fmc_page_copy(ABmFmc *pfmc, unsigned src_page_addr, unsigned dest_page_addr);










//------------------------------------------------------------------------------
// Ab_fmc.c

//--------------------------------------------------------------------
// o. Understanding the waveform make-up operation of fmc.
//
// fmc basically makes the signal waveform depending on
// the bus_addr and bus_data.
//
// < cmd phase >
//
// cle 
// -> (naddr==0,finish) ale 
// -> (ecmd_v==0,finish) ecmd 
// -> (rw==1,finish) rbusy
// -> idle
//
// < data phase >
//
// data read/write
// -> repeat
// -> check end command
//    if(rw==0), idle
//    if(rw==1), end command
// -> end command
// -> rbusy
// -> idle
//--------------------------------------------------------------------

//--------------------------------------------------------------------
// Setup
//--------------------------------------------------------------------
#define AB_NAND_DEBUG

int ab_fmc_setup(ABmFmc *pfmc)
{
	unsigned 	stat_val;

	// pfr.setcfg
	stat_val = 0;
	if(pfmc->setup.en_intr) 		stat_val |= FMC_SETC_MASK_ENINT;
	if(pfmc->setup.no_lp_mode)	stat_val |= FMC_SETC_MASK_ENLP;
	if(pfmc->setup.en_ecc_intr)	stat_val |= FMC_SETC_MASK_ENECCINT;
	if(pfmc->setup.en_wp_mode)	stat_val |= FMC_SETC_MASK_ENWP;

	ab_asi_io_write(stat_val, FMC_ADDR_SETCFG);

#ifdef AB_NAND_DEBUG
	DEBUGMSG(MSGINFO, "ab_fmc_setup-1\n");
	DEBUGMSG(MSGINFO, "W:%08x@%08x\n", stat_val,FMC_ADDR_SETCFG);
#endif


	// pfr.nand_cycles
	stat_val = 
			((pfmc->setup.t_prescale	& 0x07)	<< FMC_NANC_BIT_PRESCALE)
		|	((pfmc->setup.t_rr			& 0x07)	<< FMC_NANC_BIT_RR)
		|	((pfmc->setup.t_alr			& 0x0f) << FMC_NANC_BIT_ALR)
		|	((pfmc->setup.t_cea			& 0x07) << FMC_NANC_BIT_CEA)
		|	((pfmc->setup.t_wl			& 0x0f) << FMC_NANC_BIT_WL)
		|	((pfmc->setup.t_wh			& 0x0f) << FMC_NANC_BIT_WH)
		|	((pfmc->setup.t_rl			& 0x0f) << FMC_NANC_BIT_RL)
		|	((pfmc->setup.t_rh			& 0x0f) << FMC_NANC_BIT_RH);
	ab_asi_io_write(stat_val, FMC_ADDR_CYCREG);

#ifdef AB_NAND_DEBUG
	DEBUGMSG(MSGINFO, "ab_fmc_setup-2\n");
	DEBUGMSG(MSGINFO, "W:%x@%x\n", stat_val,FMC_ADDR_CYCREG);
#endif

	// pfr.addr base ([31:24] is valid)
	pfmc->setup.fmc_base = APACHE_NAND_BASE & 0xff000000;

	return 0;
}

//--------------------------------------------------------------------
// bus_addr setup for cmd and data phase
//--------------------------------------------------------------------
static inline unsigned ab_fmc_set_bus_addr_cmdphase(ABmFmc *pfmc)
{
	unsigned bus_addr;

	// bus address in cmd phase
	bus_addr = 
		(pfmc->setup.fmc_base & 0xff000000)
		// address high valid?
	|	((pfmc->pcmd.c_addr_h_v & 0x01) << 24)
		// number of address cycles
	|	((pfmc->pcmd.c_n_addr_cycs & 0x07) << 21)
		// end cmd is valid?
	|	((pfmc->pcmd.c_end_cmd_v & 0x01) << 20)
		// (Important) This is cmd phase
	|	(0x0 << 19)
		// end cmd
	|	((pfmc->pcmd.c_end_cmd & 0xff) << 11)
		// start cmd
	|	((pfmc->pcmd.c_start_cmd & 0xff) << 3)
		// read or write
	|	((pfmc->pcmd.c_rw & 0x01) << 2)
		// (note) lower 2-bit should be tied to 0.
	;

	return bus_addr;
}

static inline unsigned ab_fmc_set_bus_addr_dataphase(ABmFmc *pfmc)
{
	unsigned bus_addr;

	// bus address in data phase
	bus_addr = 
		(pfmc->setup.fmc_base & 0xff000000)
		// clear CS?
	|	((pfmc->pcmd.d_clrcs & 0x01) << 21)
		// end cmd is valid?
	|	((pfmc->pcmd.d_end_cmd_v & 0x01) << 20)
		// (Important) This is data phase.
	|	(0x1 << 19)
		// end cmd
	|	((pfmc->pcmd.d_end_cmd & 0xff) << 11)
		// ECC last?
	|	((pfmc->pcmd.d_ecc_last & 0x01) << 10)
	;

	return bus_addr;
}

static inline unsigned ab_fmc_set_dev_addr(ABmFmc *pfmc)
{
	unsigned dev_addr;

	// bus address in cmd phase
	dev_addr = 
		(pfmc->pcmd.c_addr[3] << 24)
	|	(pfmc->pcmd.c_addr[2] << 16)
	|	(pfmc->pcmd.c_addr[1] << 8)
	|	(pfmc->pcmd.c_addr[0] << 0);

	return dev_addr;
}

//--------------------------------------------------------------------
// Read status
//--------------------------------------------------------------------
static inline int ab_fmc_read_status(ABmFmc *pfmc)
{
	unsigned fmc_status;

	fmc_status = ab_asi_io_read(FMC_ADDR_STATUS);

	// Bits in status register.
	// [00]: run 
	// [01]: interrupt
	// [02]: interrupt by ecc
	pfmc->stat.st_run		= (fmc_status & 0x01);
	pfmc->stat.st_intr		= (fmc_status & 0x02) >> 1;
	pfmc->stat.st_ecc_intr	= (fmc_status & 0x04) >> 2;

	return 0;
}

//--------------------------------------------------------------------
// Data phase,read/write
//--------------------------------------------------------------------
static int ab_fmc_dataphase_read(ABmFmc *pfmc)
{
	unsigned bus_addr, bus_data, i;


	for(i=0; i<pfmc->pd.cnt_data; i++) {

		if((i+1)==(pfmc->pd.cnt_data)) {
			pfmc->pcmd.d_clrcs			= 1;
		} else {
			pfmc->pcmd.d_clrcs			= 0;
		}
		pfmc->pcmd.d_end_cmd_v		= 0;
		pfmc->pcmd.d_end_cmd		= 0x00;
		pfmc->pcmd.d_ecc_last		= 0;

		// make up bus address
		bus_addr = ab_fmc_set_bus_addr_dataphase(pfmc);


		// read data
		pfmc->pd.data[i] = ab_asi_io_read(bus_addr);
#ifdef AB_NAND_DEBUG
		 //*(volatile char*)(0x21000000+i)=pfmc->pd.data[i]; //aki
#endif

	}

#ifdef AB_NAND_DEBUG
		 //__asm__ __volatile__("flush \n\t");  //cache flush
#endif

	return 0;

}

static int ab_fmc_dataphase_write(ABmFmc *pfmc, unsigned cache_program_flag)
{
	unsigned bus_addr, bus_data, i;


	for(i=0; i<pfmc->pd.cnt_data; i++) {

		if((i+1)==(pfmc->pd.cnt_data)) {
			pfmc->pcmd.d_clrcs			= 1;
			pfmc->pcmd.d_end_cmd_v		= 1;
			if (cache_program_flag) pfmc->pcmd.d_end_cmd		= 0x15;
			else pfmc->pcmd.d_end_cmd		= 0x10;
			pfmc->pcmd.d_ecc_last		= 1;
		} else {
			pfmc->pcmd.d_clrcs			= 0;
			pfmc->pcmd.d_end_cmd_v		= 0;
			pfmc->pcmd.d_end_cmd		= 0x00;
			pfmc->pcmd.d_ecc_last		= 0;
		}

		// make up bus address
		bus_addr = ab_fmc_set_bus_addr_dataphase(pfmc);

		// write data
		ab_asi_io_write(pfmc->pd.data[i], bus_addr);

	}

	return 0;

}

//--------------------------------------------------------------------
// Read NAND device read ID
//--------------------------------------------------------------------
inline int ab_fmc_read_id(ABmFmc *pfmc)
{
	// bus addr, data
	unsigned 	bus_addr, bus_data;

	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x90;
	pfmc->pcmd.c_end_cmd_v		= 0;
	pfmc->pcmd.c_end_cmd		= 0x00;
	pfmc->pcmd.c_rw   			= 0;	// behave as if it is read. 
	pfmc->pcmd.c_n_addr_cycs	= 1;
	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_addr[0]		= 0x00;	// A19-A12
	pfmc->pcmd.c_addr[1]		= 0x00;	// A27-A20

	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	// -- actual command to start nand cycles.
	ab_asi_io_write(0, bus_addr);

	pfmc->pd.cnt_data = 16;
	ab_fmc_dataphase_read(pfmc);

	return 0;
}
//--------------------------------------------------------------------
// Read NAND device status
//--------------------------------------------------------------------
inline int ab_fmc_read_dev_status(ABmFmc *pfmc)
{
	// bus addr, data
	unsigned 	bus_addr, bus_data;




	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x70;
	pfmc->pcmd.c_end_cmd_v		= 0;
	pfmc->pcmd.c_end_cmd		= 0x00;
	pfmc->pcmd.c_rw   			= 0;	// behave as if it is read. 
	pfmc->pcmd.c_n_addr_cycs	= 0;
	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_addr[0]		= 0x00;	// A19-A12
	pfmc->pcmd.c_addr[1]		= 0x00;	// A27-A20

	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	// -- actual command to start nand cycles.
	ab_asi_io_write(0, bus_addr);

	pfmc->pd.cnt_data = 1;
	ab_fmc_dataphase_read(pfmc);

	if (pfmc->pd.data[0] & 0x1) DEBUGMSG(MSGERR, "Read device status error!\n");

	return 0;
}

//--------------------------------------------------------------------
// Block erase
//--------------------------------------------------------------------
int ab_fmc_block_erase(ABmFmc *pfmc, unsigned addrl, unsigned addrh)
{
	// bus addr, data
	unsigned 	bus_addr, bus_data;


	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x60;
	pfmc->pcmd.c_end_cmd_v		= 1;
	pfmc->pcmd.c_end_cmd		= 0xd0;
	pfmc->pcmd.c_rw   			= 0;	// behave as if it is read. 
#ifdef FMC_DEVICE_K9F1G08
#if 0
	// temporary code for h_v handling.
	pfmc->pcmd.c_addr_h_v 		= 1;
	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);
	ab_asi_io_write(0x000000aa, bus_addr);
#endif

	pfmc->pcmd.c_n_addr_cycs	= 2;
	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_addr[0]		= (addrl >> 12) & 0xff;	// A19-A12
	pfmc->pcmd.c_addr[1]		= (addrl >> 20) & 0xff;	// A27-A20
#else
	pfmc->pcmd.c_n_addr_cycs	= 3;
	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_addr[0]		= (addrl >> 13) & 0xff;	// A20-A13
	pfmc->pcmd.c_addr[1]		= (addrl >> 21) & 0xff;	// A28-A21
	pfmc->pcmd.c_addr[2]		= (addrl >> 29) & 0x07;	// A31-A29
#endif

	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	// -- actual command to start nand cycles.
	bus_data = ab_fmc_set_dev_addr(pfmc);
	ab_asi_io_write(bus_data, bus_addr);


	// -- wait until erase is finished.
	do {
		ab_fmc_read_status(pfmc);
	} while(pfmc->stat.st_run == 1);

	// -- read device status
	ab_fmc_read_dev_status(pfmc);
	
	return 0;
}

//--------------------------------------------------------------------
// Page write
//--------------------------------------------------------------------
int ab_fmc_page_write(ABmFmc *pfmc, unsigned cache_program_flag, unsigned addrl, unsigned addrh)
{
	// bus addr, data
	unsigned	i;
	unsigned 	bus_addr, bus_data;

	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x80;
	pfmc->pcmd.c_end_cmd_v		= 0;
	pfmc->pcmd.c_end_cmd		= 0;
	pfmc->pcmd.c_rw   			= 1;
#ifdef FMC_DEVICE_K9F1G08
	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_n_addr_cycs	= 4;
	pfmc->pcmd.c_addr[0]		= (addrl >> 0)  & 0xff;	// A07-A00
	pfmc->pcmd.c_addr[1]		= (addrl >> 8)  & 0x0f;	// A11-A08
	pfmc->pcmd.c_addr[2]		= (addrl >> 12) & 0xff;	// A19-A12
	pfmc->pcmd.c_addr[3]		= (addrl >> 20) & 0xff;	// A27-A20
#else
	pfmc->pcmd.c_addr[0]		= (addrl >> 0)  & 0xff;	// A07-A00
	pfmc->pcmd.c_addr[1]		= (addrl >> 8)  & 0x1f;	// A12-A08
	pfmc->pcmd.c_addr[2]		= (addrl >> 13) & 0xff;	// A20-A13
	pfmc->pcmd.c_addr[3]		= (addrl >> 21) & 0xff;	// A28-A21
	pfmc->pcmd.c_addr[4]		= (addrl >> 29) & 0x07;	// A31-A29

	pfmc->pcmd.c_addr_h_v 		= 1;
	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);
	ab_asi_io_write(pfmc->pcmd.c_addr[4], bus_addr);

	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_n_addr_cycs	= 5;
#endif

	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	// send command to fmc.
	// (note) We need to send cmd.phase twice if address is over 32-bit.
	// -- actual command to start nand cycles.
	bus_data = ab_fmc_set_dev_addr(pfmc);
	ab_asi_io_write(bus_data, bus_addr);

	// -- Do data phase
	if(cache_program_flag) ab_fmc_dataphase_write(pfmc, PAGE_CACHE_PROGRAM);
	else ab_fmc_dataphase_write(pfmc, PAGE_PROGRAM);

	// -- wait until erase is finished.
	do {
		ab_fmc_read_status(pfmc);
	} while(pfmc->stat.st_run == 1);

	// -- read device status
	ab_fmc_read_dev_status(pfmc);
	
	return 0;
}

//--------------------------------------------------------------------
// Read for copy back
//--------------------------------------------------------------------
int ab_fmc_page_copy(ABmFmc *pfmc, unsigned src_page_addr, unsigned dest_page_addr)
{
	// bus addr, data
	unsigned	i;
	unsigned 	bus_addr, bus_data;

	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x00;
	pfmc->pcmd.c_end_cmd_v		= 1;
	pfmc->pcmd.c_end_cmd		= 0x35;
	pfmc->pcmd.c_rw   			= 0;
#ifdef FMC_DEVICE_K9F1G08
	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_n_addr_cycs	= 4;
	pfmc->pcmd.c_addr[0]		= (src_page_addr >> 0)  & 0xff;	// A07-A00
	pfmc->pcmd.c_addr[1]		= (src_page_addr >> 8)  & 0x0f;	// A11-A08
	pfmc->pcmd.c_addr[2]		= (src_page_addr >> 12) & 0xff;	// A19-A12
	pfmc->pcmd.c_addr[3]		= (src_page_addr >> 20) & 0xff;	// A27-A20
#else
	pfmc->pcmd.c_addr[0]		= (src_page_addr >> 0)  & 0xff;	// A07-A00
	pfmc->pcmd.c_addr[1]		= (src_page_addr >> 8)  & 0x1f;	// A12-A08
	pfmc->pcmd.c_addr[2]		= (src_page_addr >> 13) & 0xff;	// A20-A13
	pfmc->pcmd.c_addr[3]		= (src_page_addr >> 21) & 0xff;	// A28-A21
	pfmc->pcmd.c_addr[4]		= (src_page_addr >> 29) & 0x07;	// A31-A29

	pfmc->pcmd.c_addr_h_v 		= 1;
	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);
	ab_asi_io_write(pfmc->pcmd.c_addr[4], bus_addr);

	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_n_addr_cycs	= 5;
#endif

	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);
	// send command to fmc.
	// (note) We need to send cmd.phase twice if address is over 32-bit.
	// -- actual command to start nand cycles.
	bus_data = ab_fmc_set_dev_addr(pfmc);
	ab_asi_io_write(bus_data, bus_addr);



	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x85;
	pfmc->pcmd.c_end_cmd_v		= 1;
	pfmc->pcmd.c_end_cmd		= 0x10;
	pfmc->pcmd.c_rw   			= 0;
#ifdef FMC_DEVICE_K9F1G08
	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_n_addr_cycs	= 4;
	pfmc->pcmd.c_addr[0]		= (dest_page_addr >> 0)  & 0xff;	// A07-A00
	pfmc->pcmd.c_addr[1]		= (dest_page_addr >> 8)  & 0x0f;	// A11-A08
	pfmc->pcmd.c_addr[2]		= (dest_page_addr >> 12) & 0xff;	// A19-A12
	pfmc->pcmd.c_addr[3]		= (dest_page_addr >> 20) & 0xff;	// A27-A20
#else
	pfmc->pcmd.c_addr[0]		= (dest_page_addr >> 0)  & 0xff;	// A07-A00
	pfmc->pcmd.c_addr[1]		= (dest_page_addr >> 8)  & 0x1f;	// A12-A08
	pfmc->pcmd.c_addr[2]		= (dest_page_addr >> 13) & 0xff;	// A20-A13
	pfmc->pcmd.c_addr[3]		= (dest_page_addr >> 21) & 0xff;	// A28-A21
	pfmc->pcmd.c_addr[4]		= (dest_page_addr >> 29) & 0x07;	// A31-A29

	pfmc->pcmd.c_addr_h_v 		= 1;
	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);
	ab_asi_io_write(pfmc->pcmd.c_addr[4], bus_addr);

	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_n_addr_cycs	= 5;

#endif

	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	// send command to fmc.
	// (note) We need to send cmd.phase twice if address is over 32-bit.
	// -- actual command to start nand cycles.
	bus_data = ab_fmc_set_dev_addr(pfmc);
	ab_asi_io_write(bus_data, bus_addr);

	do {
		ab_fmc_read_status(pfmc);
	} while(pfmc->stat.st_run == 1);

	// -- read device status
	ab_fmc_read_dev_status(pfmc);
	
	return 0;
}
//--------------------------------------------------------------------
// page read
//--------------------------------------------------------------------
int ab_fmc_page_read(ABmFmc *pfmc, unsigned addrl, unsigned addrh)
{
	// bus addr, data
	unsigned	i;
	unsigned 	bus_addr, bus_data;

	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x00;
	pfmc->pcmd.c_end_cmd_v		= 1;
	pfmc->pcmd.c_end_cmd		= 0x30;
	pfmc->pcmd.c_rw   			= 0;
#ifdef FMC_DEVICE_K9F1G08
	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_n_addr_cycs	= 4;
	pfmc->pcmd.c_addr[0]		= (addrl >> 0)  & 0xff;	// a07-a00
	pfmc->pcmd.c_addr[1]		= (addrl >> 8)  & 0x0f;	// a11-a08
	pfmc->pcmd.c_addr[2]		= (addrl >> 12) & 0xff;	// a19-a12
	pfmc->pcmd.c_addr[3]		= (addrl >> 20) & 0xff;	// a27-a20
#else
	pfmc->pcmd.c_addr[0]		= (addrl >> 0)  & 0xff;	// A07-A00
	pfmc->pcmd.c_addr[1]		= (addrl >> 8)  & 0x1f;	// A12-A08
	pfmc->pcmd.c_addr[2]		= (addrl >> 13) & 0xff;	// A20-A13
	pfmc->pcmd.c_addr[3]		= (addrl >> 21) & 0xff;	// A28-A21
	pfmc->pcmd.c_addr[4]		= (addrl >> 29) & 0x07;	// A31-A29


	pfmc->pcmd.c_addr_h_v 		= 1;
	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	ab_asi_io_write(pfmc->pcmd.c_addr[4], bus_addr);

#ifdef AB_NAND_DEBUG
	DEBUGMSG(MSGINFO, "ab_fmc_page_read-1!\n");
	DEBUGMSG(MSGINFO, "W:%08x@%08x\n", pfmc->pcmd.c_addr[4], bus_addr);
#endif

	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_n_addr_cycs	= 5;


#endif
	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);
	// send command to fmc.
	// (note) we need to send cmd.phase twice if address is over 32-bit.
	// -- actual command to start nand cycles.
	bus_data = ab_fmc_set_dev_addr(pfmc);

	//ab_printf("Aki--data2:%08x, bus_addr2:%08x\n", bus_data, bus_addr);
	ab_asi_io_write(bus_data, bus_addr);
#ifdef AB_NAND_DEBUG
	DEBUGMSG(MSGINFO, "ab_fmc_page_read-2!\n");
	DEBUGMSG(MSGINFO, "W:%08x@%08x\n", bus_data, bus_addr);
#endif

	// -- do data phase
	ab_fmc_dataphase_read(pfmc);
	
	return 0;
}

//--------------------------------------------------------------------
// page random read
//--------------------------------------------------------------------
int ab_fmc_page_random_read(ABmFmc *pfmc, unsigned addrl, unsigned addrh)
{
	// bus addr, data
	unsigned	i;
	unsigned 	bus_addr, bus_data;

	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x05;
	pfmc->pcmd.c_end_cmd_v		= 1;
	pfmc->pcmd.c_end_cmd		= 0xe0;
	pfmc->pcmd.c_rw   			= 0;
#ifdef FMC_DEVICE_K9F1G08
	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_n_addr_cycs	= 2;
	pfmc->pcmd.c_addr[0]		= (addrl >> 0)  & 0xff;	// a07-a00
	pfmc->pcmd.c_addr[1]		= (addrl >> 8)  & 0x0f;	// a11-a08
#else
	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_n_addr_cycs	= 2;
	pfmc->pcmd.c_addr[0]		= (addrl >> 0)  & 0xff;	// A07-A00
	pfmc->pcmd.c_addr[1]		= (addrl >> 8)  & 0x1f;	// A12-A08
#endif

	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	// send command to fmc.
	// (note) we need to send cmd.phase twice if address is over 32-bit.
	// -- actual command to start nand cycles.
	bus_data = ab_fmc_set_dev_addr(pfmc);
	ab_asi_io_write(bus_data, bus_addr);
	// -- do data phase
	ab_fmc_dataphase_read(pfmc);
	
	return 0;
}


//------------------------------------------------------------------------------

// fmc pointer
ABmFmc fmcst;
ABmFmc *pfmc;

//--------------------------------------------------------------------
// set up fmc
//--------------------------------------------------------------------

unsigned ab_fmc_flash_addr_gen(unsigned comumn_addr, unsigned row_addr, unsigned block_addr) {
	unsigned actual_flash_addr;
	actual_flash_addr =  ((block_addr&0xfff)<<20) | ((row_addr&0x7f)<<13)| (comumn_addr&0x1fff);
	return actual_flash_addr;
}



int setup_fmc()
{
	// setup parameter
	pfmc->setup.en_intr = 0;
	pfmc->setup.no_lp_mode = 0;
	pfmc->setup.en_ecc_intr = 0;
	pfmc->setup.en_wp_mode = 0;

	pfmc->setup.t_prescale	= 1;
	pfmc->setup.t_rr		= 1;
	pfmc->setup.t_alr		= 0;
	pfmc->setup.t_cea		= 0;
	pfmc->setup.t_wl		= 2;
	pfmc->setup.t_wh		= 2;
	pfmc->setup.t_rl		= 2;
	pfmc->setup.t_rh		= 2;
	
	// execute setup
	ab_fmc_setup(pfmc);

	return 0;
}

//--------------------------------------------------------------------
// Main function
//--------------------------------------------------------------------

//--------------------------------------------------------------------
// Array organization of H27UAG8T2A
//--------------------------------------------------------------------
// -> 1 Page 	: (4K+224) Bytes
// -> 1 Block 	: (4K+224) * 128 pages = (512K+28K) Bytes
// -> 1 Device 	: 4096 Block = 2G Byte
//--------------------------------------------------------------------

//--------------------------------------------------------------------
// Addesss Cycle Map
//--------------------------------------------------------------------
// 1st Cycle : A00 A01 A02 A03 A04 A05 A06 A07
// 2nd Cycle : A08 A09 A10 A11 A12 	0   0   0 
// 3rd Cycle : A13 A14 A15 A16 A17 A18 A19 A20
// 4th Cycle : A21 A22 A23 A25 A25 A26 A27 A28
// 5th Cycle : A29 A30 A31  0   0   0   0   0
//--------------------------------------------------------------------
// Column 	Address : (A00 - A12)
// Row 		Address : Page Adress (A13 - A19) & Plane Address (A20)
// Block 	Address : A21 - the last address
//--------------------------------------------------------------------

#define NAND_SIZE_OF_PAGE	4096
#define NAND_NUM_OF_PAGE 	128
#define NAND_NUM_OF_BLOCK 	4096

int __nand_test(void)
{
	int ret = 0;
	unsigned int flash_addr=0;

	unsigned x,i,j,k;
	unsigned WData[FMC_DEV_PAGE_BYTES_D];
	unsigned TData;
	unsigned number_of_blocks =0;
	unsigned application_mode=0;


	unsigned int BLOCK_START;
	unsigned int LOAD_SIZE;  //! Must be multiple of 512K
	unsigned int MEM_SRC_ADDR;
	unsigned int MEM_DST_ADDR;

	unsigned int mem_src_addr_index=0;
	unsigned int mem_dst_addr_index=0;


	DEBUGMSG(MSGINFO, "## ab_fmc flash write program.\n");

	//-- initialize fmc
	pfmc = (ABmFmc *)(&fmcst);

	setup_fmc();

	//-- read id 
	pfmc->pd.cnt_data = 4;
	for(i=0; i<6; i++) {
		pfmc->pd.data[i] = 0; //clear data buffer
	}
	ab_fmc_read_id(pfmc);

	for(i=0; i<6; i++) {
		DEBUGMSG(MSGINFO, "NAND ID[%d]: %02x\n", i, pfmc->pd.data[i]);
	}

#if 0
	BLOCK_START = 0;
	LOAD_SIZE = 128*(1024*1024);	//! Must be multiple of 512K
	MEM_SRC_ADDR = APACHE_DRAM_BASE+(256*MB);
	//write program
	//-- Block erase
	number_of_blocks = LOAD_SIZE / (512*1024);
	DEBUGMSG(MSGINFO, "# of Blocks : %d\n", number_of_blocks);
	for (i=0; i< number_of_blocks; i++ ) {
		flash_addr = ab_fmc_flash_addr_gen(0, 0, BLOCK_START+i); //column, row, block
		ab_fmc_block_erase(pfmc, flash_addr, 0);
		DEBUGMSG(MSGINFO, "Block %d erase done\n", BLOCK_START+i);
	}

	mem_src_addr_index = MEM_SRC_ADDR;


	//Fill MEM_SRC_ADDR

	for (i=0; i < NAND_SIZE_OF_PAGE; i++) {
		ab_asi_io_write(i, MEM_SRC_ADDR + i*4);
	}


	//-- Block write and verify
	for (i=0; i< number_of_blocks; i++ ) {
		DEBUGMSG(MSGINFO, "Block %d Program Start\n", BLOCK_START+i);
		for (j=0; j< NAND_NUM_OF_PAGE; j++ ) {
			//ab_printf("Page %d program start\n", j);
			flash_addr = ab_fmc_flash_addr_gen(0, j, BLOCK_START+i); //column, row, block
			pfmc->pd.cnt_data = NAND_SIZE_OF_PAGE;

			
			mem_src_addr_index = MEM_SRC_ADDR;

			for(k=0; k <NAND_SIZE_OF_PAGE; k++) {
				if ( (k & 0x3) ==0) {
					TData=ab_asi_io_read(mem_src_addr_index);
					mem_src_addr_index +=4;
				}
				pfmc->pd.data[k] = (TData >> (8*(3-(k & 0x3)))) & 0xff;
				WData[k] = pfmc->pd.data[k];
			}
			ab_fmc_page_write(pfmc, PAGE_PROGRAM, flash_addr, 0); //flash write

			ab_fmc_page_read(pfmc, flash_addr, 0); //read for write check
			for(k=0; k <NAND_SIZE_OF_PAGE; k++) {
				if (pfmc->pd.data[k] != WData[k]) {
					DEBUGMSG(MSGINFO, "Block[%d] PAGE[%d] R/W Error: R[%02x]:W[%02x]@%d \n", BLOCK_START+i, j, pfmc->pd.data[k], WData[k], k);
					return 0;	
				}
			}
			//ab_printf("Page %d program done\n", j);
		}
		//ab_printf("Block %d Program done\n", BLOCK_START+i);
	}
    
	DEBUGMSG(MSGINFO, "Test done\n", i);
#endif

	return 0;
}








/*
********************************************************************************
*                                  TYPEDEFS
********************************************************************************
*/

/*
********************************************************************************
*                             VARIABLE DECLARATIONS
********************************************************************************
*/

/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/


INT32 APACHE_TEST_NAND_CUTMode(void)
{
    INT32 select;
    char buf[256];

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - NAND                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " NAND Controller                                            \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                __nand_test();
            break;


            case 2:
            break;


            case 3:
            break;


            case 4:
            break;

            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to sub menu\n");
            goto Nand_Exit;
        }
    }

Nand_Exit:

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_NAND */



/* End Of File */

