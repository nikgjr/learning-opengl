/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "test.h"
#include "coremark.h"

#if ENABLE_IP_CORE











/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

INT32 APACHE_TEST_CORE_CUTMode(void)
{
    INT32 select;
    char buf[256];


    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - Core                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Core                                                       \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> Core Mask                                              \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                coremark_main();
            break;

            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to sub menu\n");
            goto Core_Exit;
        }
    }

Core_Exit:

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_CORE */



/* End Of File */

