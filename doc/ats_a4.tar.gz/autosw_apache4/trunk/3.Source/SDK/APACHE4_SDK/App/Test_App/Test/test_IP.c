/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_DUMMY
#include "test_DummyData.h"
#endif








/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

void APACHE_TEST_APP_DisplayClock(void)
{
    //DEBUGMSG(MSGINFO, STR_CLEAR_SCREEN);
    DEBUGMSG(MSGINFO, "\n============================================================\n");
    DEBUGMSG(MSGINFO, "   Test APP DB_%s [r%d]   [%s, %s]\n", (ASM_GET_CORE_ID())?"SINGLE":"DLS", TEST_APP_DB_VER, TEST_APP_BUILD_DATE, TEST_APP_BUILD_TIME);
    DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");

    // Display Clock
    DEBUGMSG(MSGINFO, "    CPU   : %7d KHz    AXI   : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_CPU, CMD_END)/KHZ,
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_AXI, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "    APB   : %7d KHz    SSPI  : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_APB, CMD_END)/KHZ,
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_SSPI, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "    QSPI  : %7d KHz    UART  : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_QSPI, CMD_END)/KHZ,
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_UART, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "    TIMER : %7d KHz    I2C   : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_TIMER, CMD_END)/KHZ,
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_I2C, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "    DDR   : %7d KHz    PWM   : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_DDR, CMD_END)/KHZ,
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_PWM, CMD_END)/KHZ);
}


void APACHE_TEST_APP_DisplayMemoryMap(void)
{
    DEBUGMSG(MSGINFO, "============================================================\n");
    DEBUGMSG(MSGINFO, "   Memory Map                                               \n");
    DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "    IROM        0x%08X       Boot ROM                       \n", APACHE_IROM_BASE);
    DEBUGMSG(MSGINFO, "    IRAM        0x%08X       System SRAM                    \n", APACHE_IRAM_BASE);
    DEBUGMSG(MSGINFO, "    DRAM        0x%08X       DDR Memory                     \n", APACHE_DRAM_BASE);
    DEBUGMSG(MSGINFO, "    SCU         0x%08X       System Control Unit            \n", APACHE_SYSCON_BASE);
    DEBUGMSG(MSGINFO, "    ICU         0x%08X       IO Control Unit                \n", APACHE_ICU_BASE);    
    DEBUGMSG(MSGINFO, "    INTC        0x%08X       Interrupt Controller           \n", APACHE_INTC_BASE);
    DEBUGMSG(MSGINFO, "    DMAC        0x%08X       Direct Memory Access           \n", APACHE_DMAC_BASE);
    DEBUGMSG(MSGINFO, "    TIMER0      0x%08X       Timer0/Watchdog                \n", APACHE_TIMER0_BASE);
    DEBUGMSG(MSGINFO, "    TIMER1      0x%08X       Timer1/Watchdog                \n", APACHE_TIMER1_BASE);
    DEBUGMSG(MSGINFO, "    PWM         0x%08X       Pulse Width Modulation         \n", APACHE_PWM_BASE);
    DEBUGMSG(MSGINFO, "    I2C0        0x%08X       Inter Integrated Circuit-0     \n", APACHE_I2C_0_BASE);
    DEBUGMSG(MSGINFO, "    I2C1        0x%08X       Inter Integrated Circuit-1     \n", APACHE_I2C_1_BASE);
    DEBUGMSG(MSGINFO, "    UART0       0x%08X       Universal Asynchronous R/T-0   \n", APACHE_UART_0_BASE);
    DEBUGMSG(MSGINFO, "    UART1       0x%08X       Universal Asynchronous R/T-1   \n", APACHE_UART_1_BASE);
    DEBUGMSG(MSGINFO, "    SPI0        0x%08X       Serial Peri. Interface-0       \n", APACHE_SPI_0_BASE);
    DEBUGMSG(MSGINFO, "    SPI1        0x%08X       Serial Peri. Interface-1       \n", APACHE_SPI_1_BASE);
    DEBUGMSG(MSGINFO, "    QSPI        0x%08X       Quad Serial Peri. Interface    \n", APACHE_QSPI_BASE);
    DEBUGMSG(MSGINFO, "    FMC         0x%08X       Nand Flash Controller          \n", APACHE_FMC_BASE);
    DEBUGMSG(MSGINFO, "    SDC         0x%08X       SD Interface Controller        \n", APACHE_SDC_BASE);
    DEBUGMSG(MSGINFO, "    DSP         0x%08X       Digital Signal Processing      \n", APACHE_DSP_BASE);
#if ENABLE_IP_DUMMY
    DEBUGMSG(MSGINFO, "    DUMMY       0x%08X       RO Dummy Data                  \n", DummyData[0]);
#endif
}


INT32 APACHE_TEST_APP_Main(void)
{
    INT32   select;
    char    buf[256];


    while(1)
    {
        APACHE_TEST_APP_DisplayClock();
        APACHE_TEST_APP_DisplayMemoryMap();
        
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "   Test Menu                                                \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, "    <1> DDR Memory R/W Test                                 \n");
        DEBUGMSG(MSGINFO, "    <2> DMAC Test                                           \n");
        DEBUGMSG(MSGINFO, "    <3> TIMER Test                                          \n");
        DEBUGMSG(MSGINFO, "    <4> PWM Test                                            \n");
        DEBUGMSG(MSGINFO, "    <5> I2C Test                                            \n");
        DEBUGMSG(MSGINFO, "    <6> SPI Test                                            \n");
        DEBUGMSG(MSGINFO, "    <7> GPIO Test                                           \n");
        DEBUGMSG(MSGINFO, "    <8> UART Test                                           \n");
        DEBUGMSG(MSGINFO, "    <9> CAN  Test                                           \n");          
        DEBUGMSG(MSGINFO, "    <A> sFlash Test                                         \n");
        DEBUGMSG(MSGINFO, "    <B> NAND Test                                           \n");
        DEBUGMSG(MSGINFO, "    <C> SDC Test                                            \n");
        DEBUGMSG(MSGINFO, "    <D> FPU Test                                            \n");
        DEBUGMSG(MSGINFO, "    <E> Core Benchmark Test                                 \n");
        DEBUGMSG(MSGINFO, "    <F> IPC Test                                            \n");
        DEBUGMSG(MSGINFO, "    <G> INTC Test                                           \n");
        DEBUGMSG(MSGINFO, "    <H> V-Dump Test                                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");  
        DEBUGMSG(MSGINFO, "    <I> ~ <Z> Reserved                                      \n"); 
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, "    <0> Quit                                                \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            /* IP Unit Test */
            case FPGA_IP_TEST_DDR:
                #if ENABLE_IP_DDR
                    APACHE_TEST_DDR_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "DDR-Test is disable!\n");
                #endif
            break;

            case FPGA_IP_TEST_DMAC:
                #if ENABLE_IP_DMAC
                    APACHE_TEST_DMA_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "DMA-Test is disable!\n");
                #endif
            break;


            case FPGA_IP_TEST_TIMER:
                #if ENABLE_IP_TIMER
                    APACHE_TEST_TIMER_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "Timer-Test is disable!\n");
                #endif
            break;

            case FPGA_IP_TEST_PWM:
                #if ENABLE_IP_PWM
                    APACHE_TEST_PWM_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "PWM is disable!\n");
                #endif
            break;

            case FPGA_IP_TEST_I2C:
                #if ENABLE_IP_I2C
                    APACHE_TEST_I2C_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "I2C is disable!\n");
                #endif
            break;

            case FPGA_IP_TEST_SPI:
                #if ENABLE_IP_SPI
                    APACHE_TEST_SSP_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "SPI is disable!\n");
                #endif
            break;

            case FPGA_IP_TEST_GPIO:
                #if ENABLE_IP_GPIO
                    APACHE_TEST_GPIO_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "GPIO is disable!\n");
                #endif
            break;

            case FPGA_IP_TEST_UART:
                #if ENABLE_IP_UART
                    APACHE_TEST_UART_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "UART is disable!\n");
                #endif
            break;

            case FPGA_IP_TEST_CAN:
                #if ENABLE_IP_CAN
                    APACHE_TEST_CAN_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "CAN is disable!\n");
                #endif
            break;

            case FPGA_IP_TEST_SF:
                #if ENABLE_IP_SF
                    APACHE_TEST_SF_CUTMode();              
                #else
                    DEBUGMSG(MSGWARN, "SF is disable!\n");
                #endif
            break;
                
            case FPGA_IP_TEST_NAND:
                #if ENABLE_IP_NAND
                    APACHE_TEST_NAND_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "NAND-Test is disable!\n");
                #endif
            break;

            case FPGA_IP_TEST_SDC:
                #if ENABLE_IP_SDC
                    APACHE_TEST_SDC_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "SDC-Test is disable!\n");
                #endif
            break;
                
            case FPGA_IP_TEST_FPU:
                #if ENABLE_IP_FPU
                    APACHE_TEST_FPU_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "FPU-Test is disable!\n");
                #endif
            break;                

            case FPGA_IP_TEST_CORE:
                #if ENABLE_IP_CORE
                    APACHE_TEST_CORE_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "CoreMask is disable!\n");
                #endif
            break;
                
            case FPGA_IP_TEST_IPC:
                #if ENABLE_IP_IPC
                    APACHE_TEST_IPC_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "IPC is disable!\n");
                #endif
            break;

            case FPGA_IP_TEST_INTC:
                #if ENABLE_IP_INTC
                    APACHE_TEST_INTC_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "INTC is disable!\n");
                #endif
            break;

            case FPGA_IP_TEST_VDUMP:
                #if ENABLE_IP_VDUMP
                    APACHE_TEST_VDUMP_CUTMode();
                #else
                    DEBUGMSG(MSGWARN, "VDUMP is disable!\n");
                #endif
            break;
            
            case FPGA_IP_TEST_I: break;
            case FPGA_IP_TEST_J: break;
            case FPGA_IP_TEST_K: break;
            case FPGA_IP_TEST_L: break;
            case FPGA_IP_TEST_M: break;
            case FPGA_IP_TEST_N: break;
            case FPGA_IP_TEST_O: break;
            case FPGA_IP_TEST_P: break;
            case FPGA_IP_TEST_Q: break;
            case FPGA_IP_TEST_R: break;
            case FPGA_IP_TEST_S: break;
            case FPGA_IP_TEST_T: break;
            case FPGA_IP_TEST_U: break;
            case FPGA_IP_TEST_V: break;
            case FPGA_IP_TEST_W: break;
            case FPGA_IP_TEST_X: break;
            case FPGA_IP_TEST_Y: break;
            case FPGA_IP_TEST_Z: break;
            
            case FPGA_IP_TEST_QUIT:
                DEBUGMSG(MSGINFO, " >>> Peripheral Test Exit <<<\n");
            goto IpCheck_Exit;
        }
    }

IpCheck_Exit:

    return NC_SUCCESS;
}


/* End Of File */

