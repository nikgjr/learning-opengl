/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"










/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define __G_TOLOWER(c)                      (((c) >= 'A' && (c) <= 'Z' ) ? (c)+('a'-'A') : (c))










/*
********************************************************************************
*               TYPEDEFS                                    
********************************************************************************
*/

typedef struct
{
    eGPIO_GROUP  mG;    
    eGPIO_PORT   mP;
    eGPIO_DATA   mS;
    eGPIO_DATA   mE;
} tHW_RST, *ptHW_RST;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

void APACHE_TEST_DebugGPIOToggle(UINT32 Port)
{
    INT32 Level;
    
    Level = ncLib_GPIO_Control(GCMD_GPIO_GET_DATA, GPIO_GROUP_D, Port, CMD_END);
    _REVERSE(Level);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_D, Port, Level, CMD_END);
}


void APACHE_TEST_DebugGPIOSet(UINT32 Port, UINT32 Level)
{
    ncLib_GPIO_Control(GCMD_GPIO_ENA, GPIO_GROUP_D, Port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, GPIO_GROUP_D, Port, GPIO_DIR_OUT, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_D, Port, Level, CMD_END);
}


INT32 APACHE_TEST_Asc2Int(char ch)
{
    if     ((ch>='0') && (ch<='9')) return  (ch-'0');
    else if((ch>='A') && (ch<='Z')) return ((ch-'A')+10 );
    else if((ch>='a') && (ch<='z')) return ((ch-'a')+10 );

    return -1;
}


INT32 APACHE_TEST_AtoI(char *Str)
{
    UINT32    Val;
    INT32     Offset, c;
    char      *Sp;

    Val = 0;
    Sp = Str;

    if((*Sp == '0') && (*(Sp+1) == 'x'))
    {
        Offset = 16;
        Sp += 2;
    }
    else if(*Sp == '0')
    {
        Offset = 8;
        Sp++;
    }
    else
    {
        Offset = 10;
    }

    for(; (*Sp != 0); Sp++)
    {
        c = (*Sp > '9') ? (__G_TOLOWER(*Sp) - 'a' + 10) : (*Sp - '0');
        Val = (Val * Offset) + c;
    }

    return(Val);
}


UINT32 APACHE_TEST_Display_InputValue(UINT32 MinNum, UINT32 MaxNum, char *Str)
{
    char   buf[100];
    UINT32 InputNum;

    do
    {
        InputNum = 0;
        DEBUGMSG(MSGINFO, "-------------------------------------------------------------\n");	
        DEBUGMSG(MSGINFO, " [%s] %u(0x%X) ~ %u(0x%X)\n", Str, MinNum, MinNum, MaxNum, MaxNum);
        DEBUGMSG(MSGINFO, " input >> ");        
        DBGSCANF(buf);

        InputNum = APACHE_TEST_AtoI(buf);
        if((InputNum < MinNum) || (InputNum > MaxNum))
            DEBUGMSG(MSGINFO, " input Fail : %u\n", InputNum);

    }while((InputNum < MinNum) || (InputNum > MaxNum));

    DEBUGMSG(MSGINFO, "\n input Ok : %u\n", InputNum);

    return InputNum;
}


void APACHE_TEST_GetArrowKey_Help(char* UpStr, char* DownStr, char* RightStr, char* LeftStr)
{
    DEBUGMSG(MSGINFO, "--------------------------------------\n");
    DEBUGMSG(MSGINFO, "| > Key Ctrl Help                    |\n");
    DEBUGMSG(MSGINFO, "|------------------------------------|\n");
    DEBUGMSG(MSGINFO, "|               Up(8)                |\n");
    DEBUGMSG(MSGINFO, "|   Left(4)               Right(6)   |\n");
    DEBUGMSG(MSGINFO, "|              Down(2)               |\n"); 
    DEBUGMSG(MSGINFO, "--------------------------------------\n");
    DEBUGMSG(MSGINFO, "  > Key Command                       \n");    
    if(UpStr != NULL)
        DEBUGMSG(MSGINFO, "    .8 or Up    - %s\n", UpStr);
    if(DownStr != NULL)
        DEBUGMSG(MSGINFO, "    .2 or Down  - %s\n", DownStr);
    if(RightStr != NULL) 
        DEBUGMSG(MSGINFO, "    .6 or Right - %s\n", RightStr);
    if(LeftStr != NULL) 
        DEBUGMSG(MSGINFO, "    .4 or Left  - %s\n", LeftStr);
    DEBUGMSG(MSGINFO, "    .Q or Enter - Exit\n");
    DEBUGMSG(MSGINFO, "--------------------------------------\n");    
}


INT8 APACHE_TEST_GetArrowKey(INT8 buf)
{
    UINT32 func_key_step;    

    // Support function key
    // .Key Enter [0x1B.0x4F.0x4D]
    // .key Up    [0x1B.0x5B.0x41] 
    // .key Down  [0x1B.0x5B.0x42] 
    // .key Right [0x1B.0x5B.0x43] 
    // .key Left  [0x1B.0x5B.0x44] 

    if(buf == ESCAPE_KEY)
    {
        func_key_step = 1;
        while(1)
        {
            buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

            if(buf != NC_FAILURE)
            {
                if( (func_key_step == 1) && ((buf == 'O') || (buf == '[')))
                {
                    func_key_step = 2;
                }
                else if(func_key_step == 2)
                {
                    if(buf == 'M')      buf = RETURN_KEY;   // Enter
                    else if(buf == 'A') buf = '8';          // UP    
                    else if(buf == 'B') buf = '2';          // Down
                    else if(buf == 'C') buf = '6';          // Right
                    else if(buf == 'D') buf = '4';          // Left
                        
                    break;
                }
                else
                {
                    break;
                }
            }
        };
    } 

    return buf;
}


INT8 APACHE_TEST_WaitKey(void)
{
    INT8 buf;
    
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);
        if(buf != NC_FAILURE)
        {
            buf = APACHE_TEST_GetArrowKey(buf);
            break;
        }
    }

    if((buf == 'q') || (buf == 'Q'))
        buf = 0;
    else
        buf = 1;

    return buf;
}


BOOL APACHE_TEST_ExitKey(void)
{
    BOOL ret = FALSE;   
    INT8 buf;
    
    // Input Key Exit - Test Stop
    buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);
    if(buf != NC_FAILURE)
    {
        if((buf == 'q') || (buf == 'Q'))
            ret = TRUE;
    }

    return ret;
}


BOOL APACHE_TEST_mTimeOut(UINT32 mSec)
{
    BOOL ret = FALSE;       
    static volatile UINT32 s_TimeOutMsec = 0;  

    if(mSec > 0)
    {
        if(s_TimeOutMsec == 0)
        {
            // Set TimeOut : SystemTick(msec) + TargetMsec;
            s_TimeOutMsec = nc_get_msec(1) + mSec;
        }
        else
        {
            // Timeout Check. 
            if( nc_get_msec(0) > s_TimeOutMsec)
            {
                ret = TRUE;
                s_TimeOutMsec = 0;
            }
        }
    }
    else
    {
        s_TimeOutMsec = 0;
    }
    
    return ret;
}


void APACHE_TEST_StopWatch(BOOL OnOff)
{ 
    UINT32 uDelay = nc_get_usec_auto_cls();

    if(OnOff == ON)
    {
        // 
    }
    else
    {   
        DEBUGMSG(MSGINFO, " - %06d us", uDelay);
    }
}


void APACHE_TEST_MemSet(void* pDstBuff, UINT8 Value, UINT32 nLength)
{
    INT32 ret = NC_SUCCESS; 
    INT32 i;

    eDMA_CH Ch;
    tDMA_PARAM tDMAParam;

    UINT8  pSrcBuff[16] __attribute__ ((aligned (4)));    
    UINT8* pInstBuff;


    // Select Channle
    if(ASM_GET_CORE_ID() == DLS_CORE) 
    {
        Ch = DMA_CH2;
        pInstBuff = (UINT8*)(APACHE_DRAM_BASE+0x0F000000);
    }
    else
    {
        Ch = DMA_CH3;
        pInstBuff = (UINT8*)(APACHE_DRAM_BASE+0x0F100000);
    }


    for(i=0; i<16; i++)
        pSrcBuff[i] = Value;


    // Set DMA Operation Mode 
    tDMAParam.mReqType    = DMA_MEM_TO_MEM; 
    tDMAParam.mInstAddr   = (UINT32)pInstBuff;  
    tDMAParam.mIntEn      = DISABLE;
    tDMAParam.mRxIncrEn   = DISABLE;  
    tDMAParam.mRxBurstLen = 4;  
    tDMAParam.mTxIncrEn   = ENABLE;  
    tDMAParam.mTxBurstLen = 4;  
    tDMAParam.mSwap       = DMA_SWAP_NO; 


    // Open DMA 
    ncLib_DMA_Open();


    // Init DAM Channel 
    ret = ncLib_DMA_Control(GCMD_DMA_INIT_CH, Ch, &tDMAParam, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel Init Error!\n");
        return;
    }


    // DMA Start
    ret = ncLib_DMA_Control(GCMD_DMA_START, Ch, (UINT32)pSrcBuff, (UINT32)pDstBuff, nLength, CMD_END);
    if(ret == NC_SUCCESS)
    {
        // DMA Done Wait
        while((ret = ncLib_DMA_Control(GCMD_DMA_DONE, Ch, CMD_END)) == NC_FAILURE)
        {
            if(APACHE_TEST_mTimeOut(2000))
            {
                DEBUGMSG(MSGWARN, " - DMA TimeOut!~\n");
                break;
            }
            APACHE_TEST_mTimeOut(0);
        }
    }
    else
    {
        DEBUGMSG(MSGERR, "DMA Start Error!\n"); 
    }
   

    // DMA Status Check
    if(ret != NC_FAILURE)
    {   
        if(ret != 0x01)
            DEBUGMSG(MSGWARN, "\nDMA Error Status : 0x%04X\n", ret);
    }


    // DeInit DMA Channel
    ret = ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, Ch, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel DeInit Error!\n");
        return;
    }


    // Close DMA
    ncLib_DMA_Close();    
}


/* End Of File */

