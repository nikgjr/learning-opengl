/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : testSim_Dma.c
*
*  @brief   :
*
*  @author  :
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "sim.h"


#if SIM_ENABLE_I2C

//#define __I2C_ACK_ENABLE__










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile UINT32 gTestSim_I2CDebugCnt;
volatile UINT32 gTestSim_I2CDebugIdx;










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

static void __testsim_i2c_init_debug(void)
{
    UINT32 i;
    
    for(i=0; i<=0x4C; i+=4)
    {
        REGRW32(SIM_DEBIG_REG, i) = 0x0;
    }
    
    gTestSim_I2CDebugCnt = 0;
    gTestSim_I2CDebugIdx = 0;
}


void APACHE_TEST_SIM_APP_I2C_Isr(UINT32 irq)
{
    INT32 Sts;
    UINT8 rBuff = 0;
    eI2C_CH Ch = (eI2C_CH)(irq - IRQ_NUM_I2C0);
    

    // INT Status Check 
    Sts = ncLib_I2C_Control(GCMD_I2C_GET_INT_STS, Ch, CMD_END);
    if(Sts&(1<<15))
    {
        // Start Status
        if(Sts&(1<<4))
        {
            ncLib_I2C_Read(Ch, 0x0, &rBuff, 1);

            DEBUGMSG(MSGINFO, ":Start:0x%02X", rBuff);
            REGRW32(SIM_DEBIG_REG, 0x0014+(gTestSim_I2CDebugCnt*16)) = rBuff;
                
            #ifdef __I2C_ACK_ENABLE__
                ncLib_I2C_Control(GCMD_I2C_SET_ACK_VALUE, Ch, 0, CMD_END);
            #endif
        } 


        // Master(W), Slave(R)
        if(Sts&(1<<2))
        {
            ncLib_I2C_Read(Ch, 0x0, &rBuff, 1);
            
            DEBUGMSG(MSGINFO, ":wACK :0x%02X", rBuff);
            if(gTestSim_I2CDebugIdx++ == 0)
                REGRW32(SIM_DEBIG_REG, 0x0018+(gTestSim_I2CDebugCnt*16)) = rBuff;
            else
                REGRW32(SIM_DEBIG_REG, 0x001C+(gTestSim_I2CDebugCnt*16)) = rBuff;
            
            #ifdef __I2C_ACK_ENABLE__
                ncLib_I2C_Control(GCMD_I2C_SET_ACK_VALUE, Ch, 0, CMD_END);
            #endif
        }


        // Stop Status
        if(Sts&(1<<5))
        {
            DEBUGMSG(MSGINFO, ":Stop   ");
            REGRW32(SIM_DEBIG_REG, 0x0010+(gTestSim_I2CDebugCnt*16)) = gTestSim_I2CDebugCnt+1;
            gTestSim_I2CDebugCnt++;
            gTestSim_I2CDebugIdx = 0;
        }
        
        // INT Clear
        ncLib_I2C_Control(GCMD_I2C_SET_INT_CLS, Ch, CMD_END);

        DEBUGMSG(MSGINFO, "\n"); 
    }
    else
    {
        if(Sts&(1<<5))
        {
            DEBUGMSG(MSGERR, "  > Mx:ISR - I2C_%d : 0x%04X : Arbitation lost", Ch, Sts);
            rSIM_RES00 = Ch;
            rSIM_RES01 = Sts;
        }
    }
}


void APACHE_TEST_SIM_APP_I2C_SlaveMode_UserAck(void)
{     
    UINT32 Reg;

    // Master I2C Channel
    eI2C_CH Master_Ch;
    tI2C_PARAM tI2CParam_M;

    // Slave I2C Channel
    eI2C_CH Slave_Ch;
    tI2C_PARAM tI2CParam_S;

    // Test buffer
    UINT8  wBuff;
    UINT32 RegAddr;

    // Set I2C Channel
    Master_Ch = I2C_CH1;
    Slave_Ch  = I2C_CH0;



    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, " Test Slave Mode : Master I2C_%d/ Slave I2C_%d !!!\n", Master_Ch, Slave_Ch);
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");



    // Step_01. Open I2C and FPGA Debug I2C LoopBack Mode - On
    rSIM_STEP = 1;   
    Reg = REGRW32(APACHE_SYSCON_BASE, 0x1040);
    Reg |= (1<<12); 
    REGRW32(APACHE_SYSCON_BASE, 0x1040) = Reg;
    ncLib_I2C_Open();



    
    // Step_02. Init I2C Channel - Master
    rSIM_STEP = 2;
    ncLib_INTC_Control(GCMD_INTC_REGISTER_INT
                      ,IRQ_NUM_I2C0 + Master_Ch
                      ,(PrHandler)APACHE_TEST_SIM_APP_I2C_Isr
                      ,CMD_END);

    tI2CParam_M.mIntEn      = ENABLE;
    tI2CParam_M.mOpMode     = I2C_OP_MODE_MASTER;
    tI2CParam_M.mLengthType = I2C_ADDR_8_DATA_8;
    tI2CParam_M.mDevBit     = I2C_DEV_7BIT;
    tI2CParam_M.mDevAddr    = 0x72;
    tI2CParam_M.mHz         = (100*KHZ);
    ncLib_I2C_Control(GCMD_I2C_INIT_CH, Master_Ch, &tI2CParam_M, CMD_END);




    // Step_02. Init I2C Channel - Slave
    rSIM_STEP = 4;
    ncLib_INTC_Control(GCMD_INTC_REGISTER_INT
                      ,IRQ_NUM_I2C0 + Slave_Ch
                      ,(PrHandler)APACHE_TEST_SIM_APP_I2C_Isr
                      ,CMD_END);

    tI2CParam_S.mIntEn      = ENABLE;
    tI2CParam_S.mOpMode     = I2C_OP_MODE_SLAVE;
    tI2CParam_S.mLengthType = I2C_ADDR_8_DATA_8;
    tI2CParam_S.mDevBit     = I2C_DEV_7BIT;
    tI2CParam_S.mDevAddr    = 0x72;
    tI2CParam_S.mHz         = (100*KHZ);
    ncLib_I2C_Control(GCMD_I2C_INIT_CH, Slave_Ch, &tI2CParam_S, CMD_END);




    //--------------------------------------------------------------------------------------------
    // Single byte wirte
    rSIM_STEP = 5;    
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "- Single-Byte Write Test\n");


    rSIM_STEP = 6; 
    RegAddr = 0x40;
    wBuff   = 0xA5;
    ncLib_I2C_Write(Master_Ch, RegAddr, &wBuff, 1);

    rSIM_STEP = 7; 
    RegAddr = 0x41;
    wBuff   = 0x5A;
    ncLib_I2C_Write(Master_Ch, RegAddr, &wBuff, 1);


    rSIM_STEP = 8; 
    RegAddr = 0x42;
    wBuff   = 0xF0;
    ncLib_I2C_Write(Master_Ch, RegAddr, &wBuff, 1);




    //--------------------------------------------------------------------------------------------
    // DeInit I2C Channel - Master
    rSIM_STEP = 9;  
    ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT
                      ,IRQ_NUM_I2C0 + Master_Ch
                      ,CMD_END);
    ncLib_I2C_Control(GCMD_I2C_DEINIT_CH, Master_Ch, CMD_END);




    //--------------------------------------------------------------------------------------------
    // DeInit I2C Channel - Slave
    rSIM_STEP = 10;  
    ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT
                      ,IRQ_NUM_I2C0 + Slave_Ch
                      ,CMD_END);
    ncLib_I2C_Control(GCMD_I2C_DEINIT_CH, Slave_Ch, CMD_END);




    //--------------------------------------------------------------------------------------------
    // Close I2C - FPGA Debug I2C LoopBack Mode
    rSIM_STEP = 11;  
    ncLib_I2C_Close();  
    
    Reg = REGRW32(APACHE_SYSCON_BASE, 0x1040);
    Reg &= ~(1<<12);
    REGRW32(APACHE_SYSCON_BASE, 0x1040) = Reg;
}


void APACHE_TEST_SIM_APP_I2C(void)
{
    __testsim_i2c_init_debug();
    
   APACHE_TEST_SIM_APP_I2C_SlaveMode_UserAck();
}


#endif /* SIM_ENABLE_I2C */


/* End Of File */

