/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_NAND


//------------------------------------------------------------------------------
// Ab_fmc.h
#define FMC_DEVICE_K9F1G08
#define FMC_DEV_PAGE_BYTES_D			(2048+64)	// page's data bytes



//--------------------------------------------------------------------
// fmc control structure
//--------------------------------------------------------------------
typedef struct AB_Fmc_Struct {
	// Setting up structure
	struct {
		unsigned	en_intr;
		unsigned	no_lp_mode;
		unsigned	en_ecc_intr;
		unsigned	en_wp_mode;
		// [27:25] t_prescale: prescaler, shift the counter bits by n.
		// [24:22] t_rr : busy to re_n (default=0)
		//                     between busy's up and ren
		// [21:19] t_alr: ID read time, 
		//                     between 'ale fall' and new data phase
		// [18:16] t_cea: ce access time
		//                     between 'ce 0' and new data phase
		// [15:12] t_wl : wen deassertion time (default=1)
		// [11:08] t_wh : wen assertion time (default=1)
		// [07:04] t_rh : ren deassertion time (default=1)
		// [03:00] t_rl : ren assertion time (default=1)
		unsigned	t_prescale:3;
		unsigned	t_rr:3;
		unsigned	t_alr:3;
		unsigned	t_cea:3;
		unsigned	t_wl:4;
		unsigned	t_wh:4;
		unsigned	t_rl:4;
		unsigned	t_rh:4;

		// fmc base address ([31:24])
		// (note) fmc pfr base is defined otherwise.
		unsigned	fmc_base;
	} setup;

	// Status
	struct {
		unsigned	st_run;
		unsigned	st_intr;
		unsigned	st_ecc_intr;
	} stat;

	// fmc cmd phase (to axi address/data)
	struct {
		unsigned	c_start_cmd;
		unsigned	c_n_addr_cycs;
		unsigned	c_end_cmd_v;
		unsigned	c_end_cmd;
		unsigned	c_rw;
		unsigned	c_addr_h_v;	// higher 32-bit is valid?
		unsigned    c_test_0;
        unsigned    c_continous_r;
		unsigned	c_addr[8];

		// fmc data phase (to axi address)
		unsigned	d_clrcs;
		unsigned	d_end_cmd_v;
		unsigned	d_end_cmd;
		unsigned	d_ecc_last;
	} pcmd;

	// nand data storage
	struct {
		// write data, read data
		unsigned	cnt_data;
		unsigned char data[FMC_DEV_PAGE_BYTES_D];
	} pd;

} ABmFmc;


//--------------------------------------------------------------------
// fmc sfr, register's addr offset
//--------------------------------------------------------------------
#define FMC_OFFA_STATUS			(0x0000)	// sfr 'status'
#define FMC_OFFA_SETCFG			(0x0004)	// sfr 'set conf. regs'
#define FMC_OFFA_CLRCFG			(0x0008)	// sfr 'clear conf. regs'
#define FMC_OFFA_CYCREG			(0x000c)	// sfr 'nand cycles'

#define FMC_ADDR_STATUS			(APACHE_FMC_BASE+FMC_OFFA_STATUS)
#define FMC_ADDR_SETCFG			(APACHE_FMC_BASE+FMC_OFFA_SETCFG)
#define FMC_ADDR_CLRCFG			(APACHE_FMC_BASE+FMC_OFFA_CLRCFG)
#define FMC_ADDR_CYCREG			(APACHE_FMC_BASE+FMC_OFFA_CYCREG)

//--------------------------------------------------------------------
// fmc sfr's mask values
//--------------------------------------------------------------------
// sfr 'status'
#define FMC_STAT_MASK_RUN		(0x0001)	// nand is running?
#define FMC_STAT_MASK_INTR		(0x0002)	// intr is generated?
#define FMC_STAT_MASK_ECCINTR	(0x0004)	// ecc.intr is generated?

// sfr 'set conf. regs'
#define FMC_SETC_MASK_ENINT		(0x0001)	// enable int
#define FMC_SETC_MASK_ENLP		(0x0002)	// enable lp mode
#define FMC_SETC_MASK_ENECCINT	(0x0004)	// enable ecc.int
#define FMC_SETC_MASK_ENWP		(0x0008)	// enable write protection

// sfr 'clear conf. regs'
#define FMC_CLRC_MASK_CLRINT	(0x0001)	// clear int
//#define FMC_CLRC_MASK_VACANT
#define FMC_CLRC_MASK_CLRECCINT	(0x0004)	// clear ecc.int

// sfr 'nand cycles', bit position
#define FMC_NANC_BIT_PRESCALE		(25)
#define FMC_NANC_BIT_RR				(22)
#define FMC_NANC_BIT_ALR			(19)
#define FMC_NANC_BIT_CEA			(16)
#define FMC_NANC_BIT_WL				(12)
#define FMC_NANC_BIT_WH				(8)
#define FMC_NANC_BIT_RL				(4)
#define FMC_NANC_BIT_RH				(0)

//-----------------------------------------------------
// page program options 
//-----------------------------------------------------
#define PAGE_PROGRAM 0
#define PAGE_CACHE_PROGRAM 1


//-----------------------------------------------------
// fmc driver functions
//-----------------------------------------------------
extern int ab_fmc_setup(ABmFmc *);
extern int ab_fmc_block_erase(ABmFmc *, unsigned, unsigned);
extern int ab_fmc_page_write(ABmFmc *pfmc, unsigned cache_program_flag, unsigned addrl, unsigned addrh);
extern int ab_fmc_page_read(ABmFmc *, unsigned, unsigned);
extern int ab_fmc_page_random_read(ABmFmc *, unsigned, unsigned);
extern int ab_fmc_read_id(ABmFmc *);
extern int ab_fmc_page_copy(ABmFmc *pfmc, unsigned src_page_addr, unsigned dest_page_addr);










//------------------------------------------------------------------------------
// Ab_fmc.c

//--------------------------------------------------------------------
// o. Understanding the waveform make-up operation of fmc.
//
// fmc basically makes the signal waveform depending on
// the bus_addr and bus_data.
//
// < cmd phase >
//
// cle 
// -> (naddr==0,finish) ale 
// -> (ecmd_v==0,finish) ecmd 
// -> (rw==1,finish) rbusy
// -> idle
//
// < data phase >
//
// data read/write
// -> repeat
// -> check end command
//    if(rw==0), idle
//    if(rw==1), end command
// -> end command
// -> rbusy
// -> idle
//--------------------------------------------------------------------

//--------------------------------------------------------------------
// Setup
//--------------------------------------------------------------------
//#define AB_NAND_DEBUG

#define NAND_SIZE_OF_PAGE	2048
#define NAND_NUM_OF_PAGE 	64


//-------------------------------------------------------------------------------------------------
// Pre-calculated 256-way 1 byte column parity
static const UINT8 nand_ecc_precalc_table[] = {
    0x00, 0x55, 0x56, 0x03, 0x59, 0x0c, 0x0f, 0x5a, 0x5a, 0x0f, 0x0c, 0x59, 0x03, 0x56, 0x55, 0x00,
    0x65, 0x30, 0x33, 0x66, 0x3c, 0x69, 0x6a, 0x3f, 0x3f, 0x6a, 0x69, 0x3c, 0x66, 0x33, 0x30, 0x65,
    0x66, 0x33, 0x30, 0x65, 0x3f, 0x6a, 0x69, 0x3c, 0x3c, 0x69, 0x6a, 0x3f, 0x65, 0x30, 0x33, 0x66,
    0x03, 0x56, 0x55, 0x00, 0x5a, 0x0f, 0x0c, 0x59, 0x59, 0x0c, 0x0f, 0x5a, 0x00, 0x55, 0x56, 0x03,
    0x69, 0x3c, 0x3f, 0x6a, 0x30, 0x65, 0x66, 0x33, 0x33, 0x66, 0x65, 0x30, 0x6a, 0x3f, 0x3c, 0x69,
    0x0c, 0x59, 0x5a, 0x0f, 0x55, 0x00, 0x03, 0x56, 0x56, 0x03, 0x00, 0x55, 0x0f, 0x5a, 0x59, 0x0c,
    0x0f, 0x5a, 0x59, 0x0c, 0x56, 0x03, 0x00, 0x55, 0x55, 0x00, 0x03, 0x56, 0x0c, 0x59, 0x5a, 0x0f,
    0x6a, 0x3f, 0x3c, 0x69, 0x33, 0x66, 0x65, 0x30, 0x30, 0x65, 0x66, 0x33, 0x69, 0x3c, 0x3f, 0x6a,
    0x6a, 0x3f, 0x3c, 0x69, 0x33, 0x66, 0x65, 0x30, 0x30, 0x65, 0x66, 0x33, 0x69, 0x3c, 0x3f, 0x6a,
    0x0f, 0x5a, 0x59, 0x0c, 0x56, 0x03, 0x00, 0x55, 0x55, 0x00, 0x03, 0x56, 0x0c, 0x59, 0x5a, 0x0f,
    0x0c, 0x59, 0x5a, 0x0f, 0x55, 0x00, 0x03, 0x56, 0x56, 0x03, 0x00, 0x55, 0x0f, 0x5a, 0x59, 0x0c,
    0x69, 0x3c, 0x3f, 0x6a, 0x30, 0x65, 0x66, 0x33, 0x33, 0x66, 0x65, 0x30, 0x6a, 0x3f, 0x3c, 0x69,
    0x03, 0x56, 0x55, 0x00, 0x5a, 0x0f, 0x0c, 0x59, 0x59, 0x0c, 0x0f, 0x5a, 0x00, 0x55, 0x56, 0x03,
    0x66, 0x33, 0x30, 0x65, 0x3f, 0x6a, 0x69, 0x3c, 0x3c, 0x69, 0x6a, 0x3f, 0x65, 0x30, 0x33, 0x66,
    0x65, 0x30, 0x33, 0x66, 0x3c, 0x69, 0x6a, 0x3f, 0x3f, 0x6a, 0x69, 0x3c, 0x66, 0x33, 0x30, 0x65,
    0x00, 0x55, 0x56, 0x03, 0x59, 0x0c, 0x0f, 0x5a, 0x5a, 0x0f, 0x0c, 0x59, 0x03, 0x56, 0x55, 0x00
};

#if 0
static INT32 __test_nand_ecc_hamming_simple_countbits(UINT32 b)
{
    INT32 res = 0;

    for (; b; b >>= 1)
        res += b & 0x01;
    
    return res;
}


static INT32 __test_nand_ecc_hamming_simple_correct(UINT8 *dat, UINT8 *read_ecc, UINT8 *calc_ecc)
{
    UINT32 byteoffs, bitnum;
    UINT8 s0, s1, s2;

    s1 = calc_ecc[0] ^ read_ecc[0];
    s0 = calc_ecc[1] ^ read_ecc[1];
    s2 = calc_ecc[2] ^ read_ecc[2];
    
    if ((s0 | s1 | s2) == 0)
        return 0;

    /* Check for a single bit error */
    if (   (((s0 ^ (s0 >> 1)) & 0x55) == 0x55)
        && (((s1 ^ (s1 >> 1)) & 0x55) == 0x55)
        && (((s2 ^ (s2 >> 1)) & 0x54) == 0x54)) 
    {
        byteoffs = (s1 << 0) & 0x80;
        byteoffs |= (s1 << 1) & 0x40;
        byteoffs |= (s1 << 2) & 0x20;
        byteoffs |= (s1 << 3) & 0x10;

        byteoffs |= (s0 >> 4) & 0x08;
        byteoffs |= (s0 >> 3) & 0x04;
        byteoffs |= (s0 >> 2) & 0x02;
        byteoffs |= (s0 >> 1) & 0x01;

        bitnum = (s2 >> 5) & 0x04;
        bitnum |= (s2 >> 4) & 0x02;
        bitnum |= (s2 >> 3) & 0x01;

        dat[byteoffs] ^= (1 << bitnum);

        return 1;
    }

    if (__test_nand_ecc_hamming_simple_countbits(s0 | ((UINT32)s1 << 8) | ((UINT32)s2 << 16)) == 1)
        return 1;

    return -1;
}
#endif

// Calculate 3-byte ECC for 256-byte block
static INT32 __test_nand_ecc_hamming_simple_calculate(const UINT8 *dat, UINT8 *ecc_code)
{
    UINT8 idx, reg1, reg2, reg3, tmp1, tmp2;
    INT32 i;

    /* Initialize variables */
    reg1 = reg2 = reg3 = 0;

    /* Build up column parity */
    for(i = 0; i < 256; i++) 
    {
        /* Get CP0 - CP5 from table */
        idx = nand_ecc_precalc_table[*dat++];
        reg1 ^= (idx & 0x3f);

        /* All bit XOR = 1 ? */
        if(idx & 0x40) 
        {
            reg3 ^= (UINT8) i;
            reg2 ^= ~((UINT8) i);
        }
    }

    /* Create non-inverted ECC code from line parity */
    tmp1  = (reg3 & 0x80) >> 0; /* B7 -> B7 */
    tmp1 |= (reg2 & 0x80) >> 1; /* B7 -> B6 */
    tmp1 |= (reg3 & 0x40) >> 1; /* B6 -> B5 */
    tmp1 |= (reg2 & 0x40) >> 2; /* B6 -> B4 */
    tmp1 |= (reg3 & 0x20) >> 2; /* B5 -> B3 */
    tmp1 |= (reg2 & 0x20) >> 3; /* B5 -> B2 */
    tmp1 |= (reg3 & 0x10) >> 3; /* B4 -> B1 */
    tmp1 |= (reg2 & 0x10) >> 4; /* B4 -> B0 */

    tmp2  = (reg3 & 0x08) << 4; /* B3 -> B7 */
    tmp2 |= (reg2 & 0x08) << 3; /* B3 -> B6 */
    tmp2 |= (reg3 & 0x04) << 3; /* B2 -> B5 */
    tmp2 |= (reg2 & 0x04) << 2; /* B2 -> B4 */
    tmp2 |= (reg3 & 0x02) << 2; /* B1 -> B3 */
    tmp2 |= (reg2 & 0x02) << 1; /* B1 -> B2 */
    tmp2 |= (reg3 & 0x01) << 1; /* B0 -> B1 */
    tmp2 |= (reg2 & 0x01) << 0; /* B7 -> B0 */

    /* Calculate final ECC code */
    ecc_code[0] = ~tmp1;
    ecc_code[1] = ~tmp2;
    ecc_code[2] = ((~reg1) << 2) | 0x03;

    return 0;
}
//-------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------
#define HAMMING_ERROR_ECC               2
#define HAMMING_ERROR_MULTIPLE_BITS     3
#define HAMMING_ERROR_SINGLE_BIT        1


static UINT32 __test_nand_ecc_hamming_count_bits_in_byte(UINT8 byte)
{
    UINT32 count = 0;

    while(byte > 0) 
    {
        if(byte & 1) 
            count++;
        
        byte >>= 1;
    }

    return count;
}


static void __test_nand_ecc_hamming_calculate(const UINT8 *data, UINT8 *code)
{
    UINT32 i;
    UINT8 column_sum = 0;
    UINT8 even_line_code = 0;
    UINT8 odd_line_code = 0;
    UINT8 even_column_code = 0;
    UINT8 odd_column_code = 0;

    /* 
     * Xor all bytes together to get the column sum.
     * At the same time, calculate the even and odd line codes.
     */
    for (i = 0; i < 256; i++) 
    {
        column_sum ^= data[i];

        /* 
         * If the xor sum of the byte is 0, then this byte has no incidence on
         * the computed code. So check if the sum is 1.
         */
        if ((__test_nand_ecc_hamming_count_bits_in_byte(data[i]) & 1) == 1) 
        {
            /*
             * Parity groups are formed by forcing a particular index bit to 0
             * (even) or 1 (odd).
             * Example on one byte:
             *
             * bits (dec)  7   6   5   4   3   2   1   0
             *      (bin) 111 110 101 100 011 010 001 000
             *                            '---'---'---'----------.
             *                                                   |
             * groups P4' ooooooooooooooo eeeeeeeeeeeeeee P4     |
             *        P2' ooooooo eeeeeee ooooooo eeeeeee P2     |
             *        P1' ooo eee ooo eee ooo eee ooo eee P1     |
             *                                                   |
             * We can see that:                                  |
             *  - P4  -> bit 2 of index is 0 --------------------'
             *  - P4' -> bit 2 of index is 1.
             *  - P2  -> bit 1 of index if 0.
             *  - etc...
             * We deduce that a bit position has an impact on all even Px if
             * the log2(x)nth bit of its index is 0
             *     ex: log2(4) = 2, bit2 of the index must be 0 (-> 0 1 2 3)
             * and on all odd Px' if the log2(x)nth bit of its index is 1
             *     ex: log2(2) = 1, bit1 of the index must be 1 (-> 0 1 4 5)
             *
             * As such, we calculate all the possible Px and Px' values at the
             * same time in two variables, even_line_code and odd_line_code, such as
             *     even_line_code bits: P128  P64  P32  P16  P8  P4  P2  P1
             *     odd_line_code  bits: P128' P64' P32' P16' P8' P4' P2' P1'
             */
            even_line_code ^= (255 - i);
            odd_line_code ^= i;
        }
    }


    /*
     * At this point, we have the line parities, and the column sum. First, We
     * must calculate the parity group values on the column sum.
     */
    for (i = 0; i < 8; i++) 
    {
        if (column_sum & 1) 
        {
            even_column_code ^= (7 - i);
            odd_column_code ^= i;
        }
        column_sum >>= 1;
    }

    /*
     * Now, we must interleave the parity values, to obtain the following layout:
     * Code[0] = Line1
     * Code[1] = Line2
     * Code[2] = Column
     * Line = Px' Px P(x-1)- P(x-1) ...
     * Column = P4' P4 P2' P2 P1' P1 PadBit PadBit
     */
    code[0] = 0;
    code[1] = 0;
    code[2] = 0;

    for (i = 0; i < 4; i++) 
    {
        code[0] <<= 2;
        code[1] <<= 2;
        code[2] <<= 2;

        /* Line 1 */
        if ((odd_line_code & 0x80) != 0) 
            code[0] |= 2;

        if ((even_line_code & 0x80) != 0)
            code[0] |= 1;
        
        /* Line 2 */
        if ((odd_line_code & 0x08) != 0)
            code[1] |= 2;

        if ((even_line_code & 0x08) != 0) 
            code[1] |= 1;
        
        /* Column */
        if ((odd_column_code & 0x04) != 0)
            code[2] |= 2;
        

        if ((even_column_code & 0x04) != 0)
            code[2] |= 1;
       

        odd_line_code <<= 1;
        even_line_code <<= 1;
        odd_column_code <<= 1;
        even_column_code <<= 1;
    }

    /* Invert codes (linux compatibility) */
    code[0] = (~(UINT32) code[0]);
    code[1] = (~(UINT32) code[1]);
    code[2] = (~(UINT32) code[2]);

}

#if 0
static UINT32 __test_nand_ecc_hamming_count_bits_in_code(UINT8 *code)
{
    UINT32 res;

    res  = __test_nand_ecc_hamming_count_bits_in_byte(code[0]);
    res += __test_nand_ecc_hamming_count_bits_in_byte(code[1]);
    res += __test_nand_ecc_hamming_count_bits_in_byte(code[2]);
    
    return res;
}


static UINT32 __test_nand_ecc_hamming_verify(UINT8 *puc_data, const UINT8 *puc_original_code)
{
    /* Calculate new code */
    UINT8 computed_code[3];
    UINT8 correction_code[3];
    UINT8 byte;
    UINT8 bit;
    
    __test_nand_ecc_hamming_calculate(puc_data, computed_code);

    /* Xor both codes together */
    correction_code[0] = computed_code[0] ^ puc_original_code[0];
    correction_code[1] = computed_code[1] ^ puc_original_code[1];
    correction_code[2] = computed_code[2] ^ puc_original_code[2];


    /* If all bytes are 0, there is no error */
    if ((correction_code[0] == 0) && (correction_code[1] == 0) && (correction_code[2] == 0))
        return 0;
    

    /* If there is a single bit error, there are 11 bits set to 1 */
    if (__test_nand_ecc_hamming_count_bits_in_code(correction_code) == 11) 
    {
        /* Get byte and bit indexes */

        byte = correction_code[0] & 0x80;
        byte |= ((correction_code[0] << 1) & 0x40);
        byte |= ((correction_code[0] << 2) & 0x20);
        byte |= ((correction_code[0] << 3) & 0x10);

        byte |= ((correction_code[1] >> 4) & 0x08);
        byte |= ((correction_code[1] >> 3) & 0x04);
        byte |= ((correction_code[1] >> 2) & 0x02);
        byte |= ((correction_code[1] >> 1) & 0x01);

        bit = (correction_code[2] >> 5) & 0x04;
        bit |= ((correction_code[2] >> 4) & 0x02);
        bit |= ((correction_code[2] >> 3) & 0x01);

        /* Correct bit */
        puc_data[byte] ^= (1 << bit);

        return HAMMING_ERROR_SINGLE_BIT;
    }

    /* Check if ECC has been corrupted */
    if (__test_nand_ecc_hamming_count_bits_in_code(correction_code) == 1) 
        return HAMMING_ERROR_ECC;
    /* Otherwise, this is a multi-bit error */
    else 
        return HAMMING_ERROR_MULTIPLE_BITS;
}
#endif
//-------------------------------------------------------------------------------------------------


static void __test_nand_ecc_ewchon_ecc_test(UINT8* pBuff, UINT8* ecc_code)
{
    UINT8 ecc_bit[24]; 
    UINT32 i, j;
    UINT32 b;


    // Buffer Clear
    for(i=0; i<24; i++)
        ecc_bit[i] = 0;
    

    //----------------------------------------------------------------------------------------------------------
    // 0,1,2,3,4 ... 255 
    for(i=0; i<256; i+=1)
    {
        // Bit-0
        ecc_bit[0]  += ( ((pBuff[i]>>7)&0x1) + ((pBuff[i]>>5)&0x1) + ((pBuff[i]>>3)&0x1) + ((pBuff[i]>>1)&0x1) );

        // Bit-1
        ecc_bit[1]  += ( ((pBuff[i]>>7)&0x1) + ((pBuff[i]>>6)&0x1) + ((pBuff[i]>>3)&0x1) + ((pBuff[i]>>2)&0x1) );

        // Bit-2
        ecc_bit[2]  += ( ((pBuff[i]>>7)&0x1) + ((pBuff[i]>>6)&0x1) + ((pBuff[i]>>5)&0x1) + ((pBuff[i]>>4)&0x1) );

        // Bit-11
        ecc_bit[11] += ( ((pBuff[i]>>6)&0x1) + ((pBuff[i]>>4)&0x1) + ((pBuff[i]>>2)&0x1) + ((pBuff[i]>>0)&0x1) );

        // Bit-12
        ecc_bit[12] += ( ((pBuff[i]>>5)&0x1) + ((pBuff[i]>>4)&0x1) + ((pBuff[i]>>1)&0x1) + ((pBuff[i]>>0)&0x1) );

        // Bit-13
        ecc_bit[13] += ( ((pBuff[i]>>3)&0x1) + ((pBuff[i]>>2)&0x1) + ((pBuff[i]>>1)&0x1) + ((pBuff[i]>>0)&0x1) );
    }


    //----------------------------------------------------------------------------------------------------------
    // 0,2,4,8,10 ... 254 
    for(i=0; i<256; i+=2)
    {
        for(j=0; j<1; j++)
        {
            // Bit 0~7 Bit
            for(b=0; b<8; b++)
            {
                // Bit-3  :   1,  3,  5,  7,  9 ...     255
                ecc_bit[3]  += ((pBuff[i+j+1]>>b)&0x1);
                
                // Bit-14 : 0,  2,  4,  6,  8,  ... 254,
                ecc_bit[14] += ((pBuff[i+j+0]>>b)&0x1);
            }
        }
    }


    //----------------------------------------------------------------------------------------------------------
    // 0,4,8,12,16 ... 252 
    for(i=0; i<256; i+=4)
    {
        for(j=0; j<2; j++)
        {
            // Bit 0~7 Bit
            for(b=0; b<8; b++) 
            {
                // Bit-4  :     2,3,    6,7,      ...         254,255
                ecc_bit[4]  += ((pBuff[i+j+2]>>b)&0x1);

                // Bit-15 : 0,1,    4,5,    8,9,  ... 252,253,
                ecc_bit[15] += ((pBuff[i+j+0]>>b)&0x1); 
            }
        }
    }


    //----------------------------------------------------------------------------------------------------------
    // 0,8,16,24,32 ... 248 
    for(i=0; i<256; i+=8)
    {
        for(j=0; j<4; j++)
        {
            // Bit 0~7 Bit
            for(b=0; b<8; b++) 
            {
                // Bit-5  :     4~7,      12~15 ...         252~255
                ecc_bit[5]  += ((pBuff[i+j+4]>>b)&0x1);

                // Bit-16 : 0~3,    8~11,       ... 248~251,
                ecc_bit[16] += ((pBuff[i+j+0]>>b)&0x1);
            }
        }
    }


    //----------------------------------------------------------------------------------------------------------
    // 0,16,32,48,64 ... 240 
    for(i=0; i<256; i+=16)
    {
        for(j=0; j<8; j++)
        {
            // Bit 0~7 Bit
            for(b=0; b<8; b++) 
            {
                // Bit-6  :     8~15,      24~31 ...          248~255
                ecc_bit[6]  += ((pBuff[i+j+8]>>b)&0x1);

                // Bit-17 : 0~7,     16~23,       ... 240~247,
                ecc_bit[17] += ((pBuff[i+j+0]>>b)&0x1);
            }
        }
    }



    //----------------------------------------------------------------------------------------------------------
    // 0,32,64,96,128 ... 224 
    for(i=0; i<256; i+=32)
    {
        for(j=0; j<16; j++)
        {
            // Bit 0~7 Bit
            for(b=0; b<8; b++) 
            {
                // Bit-7  :      16~31,      48~63 ...         240~255
                ecc_bit[7]  += ((pBuff[i+j+16]>>b)&0x1);
                
                // Bit-18 : 0~15,      32~47,      ... 224~239,
                ecc_bit[18] += ((pBuff[i+j+0]>>b)&0x1);
            }
        }
    }


    //----------------------------------------------------------------------------------------------------------
    // 0,64,128,192 
    for(i=0; i<256; i+=64)
    {
         for(j=0; j<32; j++)
         {
            // Bit 0~7 Bit
            for(b=0; b<8; b++) 
            {
                // Bit-8  :      32~63,      96~127 ...        224~255
                ecc_bit[8]  += ((pBuff[i+j+32]>>b)&0x1);
                
                // Bit-19 : 0~31,      64~95,       ... 192~223,
                ecc_bit[19] += ((pBuff[i+j+0]>>b)&0x1);
            }
         }
    }


    //----------------------------------------------------------------------------------------------------------
    // 0,128 
    for(i=0; i<256; i+=128)
    {
         for(j=0; j<64; j++)
         {
            // Bit 0~7 Bit
            for(b=0; b<8; b++) 
            {
                // Bit-9  :      65~127,       192~255
                ecc_bit[9] += ((pBuff[i+j+64]>>b)&0x1);
                
                // Bit-20 : 0~64,      128~191,
                ecc_bit[20] += ((pBuff[i+j+0]>>b)&0x1);
            }
         }
    }



    //----------------------------------------------------------------------------------------------------------
    // 0
    for(i=0; i<256; i+=256)
    {
        for(j=0; j<128; j++)
        {
            // Bit 0~7 Bit
            for(b=0; b<8; b++) 
            {
                // Bit-10  :      128~255
                ecc_bit[10] += ((pBuff[i+j+128]>>b)&0x1);

                // Bit-21 : 0~127,     
                ecc_bit[21] += ((pBuff[i+j+0]>>b)&0x1);
            }
        }
    }



    // Buffer Clear
    for(i=0; i<3; i++)
        ecc_code[i] = 0;

    for(i=0; i<8; i++)
    {
        ecc_code[0] |= ((ecc_bit[i+0]&0x1)<<i);
        ecc_code[1] |= ((ecc_bit[i+8]&0x1)<<i); 
        ecc_code[2] |= ((ecc_bit[i+16]&0x1)<<i); 
    }
}

 
static void __test_nand_ecc_create(UINT8* pBuff)
{
    UINT32 i, j;

    for(i=0, j=0; i<NAND_SIZE_OF_PAGE; i+=256, j++)
    {
        __test_nand_ecc_ewchon_ecc_test(&pBuff[i], &pBuff[NAND_SIZE_OF_PAGE+(j*3)]);
    }

    DEBUGMSG(MSGINFO, " > Ewchon  ECC\n");
    for(j=0; j<24; j++)
        DEBUGMSG(MSGINFO, "%02X ", pBuff[NAND_SIZE_OF_PAGE+j]);	
    DEBUGMSG(MSGINFO, "\n");
}


static void __test_nand_display_buff(UINT8 *pBuff, UINT32 Size, UINT32 PageAddr)
{
    UINT32 i;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");	
    DEBUGMSG(MSGINFO, "\n>> PageAddr = 0x%08X", PageAddr);	
    for(i=0;i<Size;i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", PageAddr+i);	
        DEBUGMSG(MSGINFO, "%02X ", pBuff[i]);	
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");	
}


static void __test_nand_clear_buff(UINT8 *pData, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        *pData++ = 0x00;
    }
}


static void __test_nand_dummy_buff(UINT8 *pData, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        *pData++ = i+1;
    }
}

static void __test_nand_dummy_buff_marking(UINT8 *pData, UINT32 PageAddr)
{
    pData[0] = (PageAddr>>24 & 0xFF);
    pData[1] = (PageAddr>>16 & 0xFF);
    pData[2] = (PageAddr>>8  & 0xFF);
    pData[3] = (PageAddr     & 0xFF); 
}


int ab_fmc_setup(ABmFmc *pfmc)
{
    unsigned int stat_val;

    // pfr.setcfg
    stat_val = 0;
    if(pfmc->setup.en_intr)     stat_val |= FMC_SETC_MASK_ENINT;
    if(pfmc->setup.no_lp_mode)	stat_val |= FMC_SETC_MASK_ENLP;
    if(pfmc->setup.en_ecc_intr)	stat_val |= FMC_SETC_MASK_ENECCINT;
    if(pfmc->setup.en_wp_mode)	stat_val |= FMC_SETC_MASK_ENWP;
    REGRW32(FMC_ADDR_SETCFG, 0) = stat_val;

    
#ifdef AB_NAND_DEBUG
     DEBUGMSG(MSGINFO, "fmc.setup: REGRW32(%04x, %04x)\n", FMC_ADDR_SETCFG, stat_val);
#endif


    // pfr.nand_cycles
    stat_val = 0;
    stat_val |= 
                ((pfmc->setup.t_prescale	& 0x07)	<< FMC_NANC_BIT_PRESCALE)
            |	((pfmc->setup.t_rr			& 0x07)	<< FMC_NANC_BIT_RR)
            |	((pfmc->setup.t_alr			& 0x07) << FMC_NANC_BIT_ALR)
            |	((pfmc->setup.t_cea			& 0x07) << FMC_NANC_BIT_CEA)
            |	((pfmc->setup.t_wl			& 0x0f) << FMC_NANC_BIT_WL)
            |	((pfmc->setup.t_wh			& 0x0f) << FMC_NANC_BIT_WH)
            |	((pfmc->setup.t_rl			& 0x0f) << FMC_NANC_BIT_RL)
            |	((pfmc->setup.t_rh			& 0x0f) << FMC_NANC_BIT_RH);
    REGRW32(FMC_ADDR_CYCREG, 0) = stat_val;
    
#ifdef AB_NAND_DEBUG
    DEBUGMSG(MSGINFO, "fmc.setup: REGRW32(%04x, %04x)\n", FMC_ADDR_CYCREG, stat_val);
#endif

    // pfr.addr base ([31:24] is valid)
    pfmc->setup.fmc_base = APACHE_NAND_BASE & 0xff000000;

	return 0;}

//--------------------------------------------------------------------
// bus_addr setup for cmd and data phase
//--------------------------------------------------------------------
static unsigned ab_fmc_set_bus_addr_cmdphase(ABmFmc *pfmc)
{
	unsigned bus_addr;

	// bus address in cmd phase
	bus_addr = 
		(pfmc->setup.fmc_base & 0xfe000000)
		// ??
	|	((pfmc->pcmd.c_test_0 & 0x01) << 25)
		// address high valid?
	|	((pfmc->pcmd.c_addr_h_v & 0x01) << 24)
		// number of address cycles
	|	((pfmc->pcmd.c_n_addr_cycs & 0x07) << 21)
		// end cmd is valid?
	|	((pfmc->pcmd.c_end_cmd_v & 0x01) << 20)
		// (Important) This is cmd phase
	|	(0x0 << 19)
		// end cmd
	|	((pfmc->pcmd.c_end_cmd & 0xff) << 11)
		// start cmd
	|	((pfmc->pcmd.c_start_cmd & 0xff) << 3)
		// read or write
	|	((pfmc->pcmd.c_rw & 0x01) << 2)
		// (note) lower 2-bit should be tied to 0.
	;

	return bus_addr;
}

static unsigned ab_fmc_set_bus_addr_dataphase(ABmFmc *pfmc)
{
	unsigned bus_addr;

	// bus address in data phase
	bus_addr = 
		(pfmc->setup.fmc_base & 0xfe000000)
		// ??
	|	((pfmc->pcmd.c_test_0 & 0x01) << 25)
		// clear CS?
	|	((pfmc->pcmd.d_clrcs & 0x01) << 21)
		// end cmd is valid?
	|	((pfmc->pcmd.d_end_cmd_v & 0x01) << 20)
		// (Important) This is data phase.
	|	(0x1 << 19)
		// end cmd
	|	((pfmc->pcmd.d_end_cmd & 0xff) << 11)
		// ECC last?
	|	((pfmc->pcmd.d_ecc_last & 0x01) << 10)
	    // Continous read mode
	|	((pfmc->pcmd.c_continous_r & 0x01) << 3)
	;

	return bus_addr;
}

static unsigned ab_fmc_set_dev_addr(ABmFmc *pfmc)
{
	unsigned dev_addr;

	// bus address in cmd phase

#if 0 // parkjy_endian
	dev_addr = 
		(pfmc->pcmd.c_addr[3] << 0)
	|	(pfmc->pcmd.c_addr[2] << 8)
	|	(pfmc->pcmd.c_addr[1] << 16)
	|	(pfmc->pcmd.c_addr[0] << 24);
#else
	dev_addr = 
		(pfmc->pcmd.c_addr[3] << 24)
	|	(pfmc->pcmd.c_addr[2] << 16)
	|	(pfmc->pcmd.c_addr[1] << 8)
	|	(pfmc->pcmd.c_addr[0] << 0);
#endif

	return dev_addr;
}

//--------------------------------------------------------------------
// Read status
//--------------------------------------------------------------------
static int ab_fmc_read_status(ABmFmc *pfmc)
{
	unsigned fmc_status;

	fmc_status = REGRW32(FMC_ADDR_STATUS, 0);

	// Bits in status register.
	// [00]: run 
	// [01]: interrupt
	// [02]: interrupt by ecc
	pfmc->stat.st_run		= (fmc_status & 0x01);
	pfmc->stat.st_intr		= (fmc_status & 0x02) >> 1;
	pfmc->stat.st_ecc_intr	= (fmc_status & 0x04) >> 2;

	return 0;
}

//--------------------------------------------------------------------
// Data phase,read/write
//--------------------------------------------------------------------
static int ab_fmc_dataphase_read(ABmFmc *pfmc)
{
	unsigned bus_addr, i;


    if(pfmc->pcmd.c_continous_r == 0)
    {
    	for(i=0; i<pfmc->pd.cnt_data; i++) 
        {
    		if((i+1)==(pfmc->pd.cnt_data)) 
    			pfmc->pcmd.d_clrcs = 1;
            else 
    			pfmc->pcmd.d_clrcs = 0;
            
    		pfmc->pcmd.d_end_cmd_v = 0;
    		pfmc->pcmd.d_end_cmd   = 0x00;
    		pfmc->pcmd.d_ecc_last  = 0;

    		// make up bus address
    		bus_addr = ab_fmc_set_bus_addr_dataphase(pfmc);

    		// read data
    		pfmc->pd.data[i] = REGRW32(bus_addr, 0); 
    	}
    }
    else
    {
    	    pfmc->pcmd.d_clrcs = 1;
    		pfmc->pcmd.d_end_cmd_v = 0;
    		pfmc->pcmd.d_end_cmd   = 0x00;
    		pfmc->pcmd.d_ecc_last  = 0;

    		// make up bus address
    		bus_addr = ab_fmc_set_bus_addr_dataphase(pfmc);

    		// read data
    		REGRW32(bus_addr, 0); 
    }
    

	return 0;
}


static int ab_fmc_dataphase_write(ABmFmc *pfmc, unsigned cache_program_flag)
{
	unsigned bus_addr, i;

	for(i=0; i<pfmc->pd.cnt_data; i++) 
    {
		if((i+1)==(pfmc->pd.cnt_data)) 
        {
			pfmc->pcmd.d_clrcs			= 1;
			pfmc->pcmd.d_end_cmd_v		= 1;
			if (cache_program_flag) 
                pfmc->pcmd.d_end_cmd = 0x15;
			else 
                pfmc->pcmd.d_end_cmd = 0x10;
			pfmc->pcmd.d_ecc_last		= 1;
		} 
        else 
        {
			pfmc->pcmd.d_clrcs			= 0;
			pfmc->pcmd.d_end_cmd_v		= 0;
			pfmc->pcmd.d_end_cmd		= 0x00;
			pfmc->pcmd.d_ecc_last		= 0;
		}

		// make up bus address
		bus_addr = ab_fmc_set_bus_addr_dataphase(pfmc);

		// write data
		REGRW32(bus_addr, 0) = pfmc->pd.data[i];

	}

	return 0;
}


//--------------------------------------------------------------------
// Read NAND device read ID
//--------------------------------------------------------------------
int ab_fmc_read_id(ABmFmc *pfmc)
{
	// bus addr, data
	unsigned 	bus_addr;
    
	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x90;
	pfmc->pcmd.c_end_cmd_v		= 0;
	pfmc->pcmd.c_end_cmd		= 0x00;
	pfmc->pcmd.c_rw   			= 0;	// behave as if it is read. 
	pfmc->pcmd.c_n_addr_cycs	= 1;
	pfmc->pcmd.c_addr_h_v 		= 0;
    pfmc->pcmd.c_test_0         = 0;
	pfmc->pcmd.c_continous_r    = 0;
	pfmc->pcmd.c_addr[0]		= 0x00;	// A19-A12
	pfmc->pcmd.c_addr[1]		= 0x00;	// A27-A20

	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	// -- actual command to start nand cycles.
	REGRW32(bus_addr, 0) = 0x00;

	pfmc->pd.cnt_data = 5;
	ab_fmc_dataphase_read(pfmc);

	return 0;
}
//--------------------------------------------------------------------
// Read NAND device status
//--------------------------------------------------------------------
int ab_fmc_read_dev_status(ABmFmc *pfmc)
{
	// bus addr, data
	unsigned 	bus_addr;


	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x70;
	pfmc->pcmd.c_end_cmd_v		= 0;
	pfmc->pcmd.c_end_cmd		= 0x00;
	pfmc->pcmd.c_rw   			= 0;	// behave as if it is read. 
	pfmc->pcmd.c_n_addr_cycs	= 0;
	pfmc->pcmd.c_addr_h_v 		= 0;
    pfmc->pcmd.c_test_0         = 0;
	pfmc->pcmd.c_continous_r    = 0;
	pfmc->pcmd.c_addr[0]		= 0x00;	// A19-A12
	pfmc->pcmd.c_addr[1]		= 0x00;	// A27-A20

	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	// -- actual command to start nand cycles.
	REGRW32(bus_addr, 0) = 0x00;

	pfmc->pd.cnt_data = 1;
	ab_fmc_dataphase_read(pfmc);

	if (pfmc->pd.data[0] & 0x1) DEBUGMSG(MSGERR, "Read device status error!\n");

	return 0;
}

//--------------------------------------------------------------------
// Block erase
//--------------------------------------------------------------------
int ab_fmc_block_erase(ABmFmc *pfmc, unsigned addrl, unsigned addrh)
{
	// bus addr, data
	unsigned 	bus_addr, bus_data;


	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x60;
	pfmc->pcmd.c_end_cmd_v		= 1;
	pfmc->pcmd.c_end_cmd		= 0xd0;
	pfmc->pcmd.c_rw   			= 0;	// behave as if it is read. 
	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_test_0         = 0;
	pfmc->pcmd.c_n_addr_cycs	= 3;
	pfmc->pcmd.c_addr[0]		= (addrl >> 12) & 0xff;	// A19-A12
	pfmc->pcmd.c_addr[1]		= (addrl >> 20) & 0xff;	// A27-A20
	pfmc->pcmd.c_addr[2]		= (addrl >> 28) & 0x01;	//     A28	


	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	// -- actual command to start nand cycles.
	bus_data = ab_fmc_set_dev_addr(pfmc);
	REGRW32(bus_addr, 0) = bus_data;


	// -- wait until erase is finished.
	do {
		ab_fmc_read_status(pfmc);
	} while(pfmc->stat.st_run == 1);

	// -- read device status
	ab_fmc_read_dev_status(pfmc);
	
	return 0;
}

//--------------------------------------------------------------------
// Page write
//--------------------------------------------------------------------
int ab_fmc_page_write(ABmFmc *pfmc, unsigned cache_program_flag, unsigned addrl, unsigned addrh)
{
	// bus addr, data
	unsigned 	bus_addr, bus_data;

	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x80;
	pfmc->pcmd.c_end_cmd_v		= 0;
	pfmc->pcmd.c_end_cmd		= 0;
	pfmc->pcmd.c_rw   			= 1;
	pfmc->pcmd.c_n_addr_cycs	= 5;
	pfmc->pcmd.c_addr[0]		= (addrl >> 0)  & 0xff;	// A07-A00
	pfmc->pcmd.c_addr[1]		= (addrl >> 8)  & 0x0f;	// A11-A08
	pfmc->pcmd.c_addr[2]		= (addrl >> 12) & 0xff;	// A19-A12
	pfmc->pcmd.c_addr[3]		= (addrl >> 20) & 0xff;	// A27-A20
	pfmc->pcmd.c_addr[4]		= (addrl >> 28) & 0x01;	//     A28
	pfmc->pcmd.c_test_0         = 0;
	pfmc->pcmd.c_continous_r    = 0;
	pfmc->pcmd.c_addr_h_v 		= 1;
	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);
	REGRW32(bus_addr, 0) = pfmc->pcmd.c_addr[4];  
    
	pfmc->pcmd.c_addr_h_v 		= 0;
	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	// send command to fmc.
	// (note) We need to send cmd.phase twice if address is over 32-bit.
	// -- actual command to start nand cycles.
	bus_data = ab_fmc_set_dev_addr(pfmc);
	REGRW32(bus_addr, 0) = bus_data;

	// -- Do data phase
	if(cache_program_flag) ab_fmc_dataphase_write(pfmc, PAGE_CACHE_PROGRAM);
	else ab_fmc_dataphase_write(pfmc, PAGE_PROGRAM);

	// -- wait until erase is finished.
	do {
		ab_fmc_read_status(pfmc);
	} while(pfmc->stat.st_run == 1);

	// -- read device status
	ab_fmc_read_dev_status(pfmc);
	
	return 0;
}

//--------------------------------------------------------------------
// Read for copy back
//--------------------------------------------------------------------
int ab_fmc_page_copy(ABmFmc *pfmc, unsigned src_page_addr, unsigned dest_page_addr)
{
	// bus addr, data
	unsigned 	bus_addr, bus_data;

	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x00;
	pfmc->pcmd.c_end_cmd_v		= 1;
	pfmc->pcmd.c_end_cmd		= 0x35;
	pfmc->pcmd.c_rw   			= 0;
	pfmc->pcmd.c_addr_h_v 		= 0;
    pfmc->pcmd.c_test_0         = 0;
	pfmc->pcmd.c_n_addr_cycs	= 4;
	pfmc->pcmd.c_addr[0]		= (src_page_addr >> 0)  & 0xff;	// A07-A00
	pfmc->pcmd.c_addr[1]		= (src_page_addr >> 8)  & 0x0f;	// A11-A08
	pfmc->pcmd.c_addr[2]		= (src_page_addr >> 12) & 0xff;	// A19-A12
	pfmc->pcmd.c_addr[3]		= (src_page_addr >> 20) & 0xff;	// A27-A20

	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);
	// send command to fmc.
	// (note) We need to send cmd.phase twice if address is over 32-bit.
	// -- actual command to start nand cycles.
	bus_data = ab_fmc_set_dev_addr(pfmc);
	REGRW32(bus_addr, 0) = bus_data;



	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x85;
	pfmc->pcmd.c_end_cmd_v		= 1;
	pfmc->pcmd.c_end_cmd		= 0x10;
	pfmc->pcmd.c_rw   			= 0;
	pfmc->pcmd.c_addr_h_v 		= 0;
    pfmc->pcmd.c_test_0         = 0;
	pfmc->pcmd.c_n_addr_cycs	= 4;
	pfmc->pcmd.c_addr[0]		= (dest_page_addr >> 0)  & 0xff;	// A07-A00
	pfmc->pcmd.c_addr[1]		= (dest_page_addr >> 8)  & 0x0f;	// A11-A08
	pfmc->pcmd.c_addr[2]		= (dest_page_addr >> 12) & 0xff;	// A19-A12
	pfmc->pcmd.c_addr[3]		= (dest_page_addr >> 20) & 0xff;	// A27-A20


	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	// send command to fmc.
	// (note) We need to send cmd.phase twice if address is over 32-bit.
	// -- actual command to start nand cycles.
	bus_data = ab_fmc_set_dev_addr(pfmc);
	REGRW32(bus_addr, 0) = bus_data;

	do {
		ab_fmc_read_status(pfmc);
	} while(pfmc->stat.st_run == 1);

	// -- read device status
	ab_fmc_read_dev_status(pfmc);
	
	return 0;
}
//--------------------------------------------------------------------
// page read
//--------------------------------------------------------------------
int ab_fmc_page_read(ABmFmc *pfmc, unsigned addrl, unsigned addrh)
{
	// bus addr, data
	unsigned 	bus_addr, bus_data;

	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x00;
	pfmc->pcmd.c_end_cmd_v		= 1;
	pfmc->pcmd.c_end_cmd		= 0x30;
	pfmc->pcmd.c_rw   			= 0;
	pfmc->pcmd.c_n_addr_cycs	= 5;
	pfmc->pcmd.c_addr[0]		= (addrl >> 0)  & 0xff;	// a07-a00
	pfmc->pcmd.c_addr[1]		= (addrl >> 8)  & 0x0f;	// a11-a08
	pfmc->pcmd.c_addr[2]		= (addrl >> 12) & 0xff;	// a19-a12
	pfmc->pcmd.c_addr[3]		= (addrl >> 20) & 0xff;	// a27-a20
	pfmc->pcmd.c_addr[4]		= (addrl >> 28) & 0x01;	//     A28	

	pfmc->pcmd.c_test_0         = 0;
	pfmc->pcmd.c_addr_h_v 		= 1;
	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);
	REGRW32(bus_addr, 0) = pfmc->pcmd.c_addr[4];
	pfmc->pcmd.c_addr_h_v 		= 0;

	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);
	// send command to fmc.
	// (note) we need to send cmd.phase twice if address is over 32-bit.
	// -- actual command to start nand cycles.
	bus_data = ab_fmc_set_dev_addr(pfmc);

	//ab_printf("Aki--data2:%08x, bus_addr2:%08x\n", bus_data, bus_addr);
	REGRW32(bus_addr, 0) = bus_data;
#ifdef AB_NAND_DEBUG
	DEBUGMSG(MSGINFO, "ab_fmc_page_read-2!\n");
	DEBUGMSG(MSGINFO, "W:%08x@%08x\n", bus_data, bus_addr);
#endif

	// -- do data phase
	ab_fmc_dataphase_read(pfmc);
	
	return 0;
}

//--------------------------------------------------------------------
// page random read
//--------------------------------------------------------------------
int ab_fmc_page_random_read(ABmFmc *pfmc, unsigned addrl, unsigned addrh)
{
	// bus addr, data
	unsigned 	bus_addr, bus_data;

	// bus address in cmd phase
	pfmc->pcmd.c_start_cmd		= 0x05;
	pfmc->pcmd.c_end_cmd_v		= 1;
	pfmc->pcmd.c_end_cmd		= 0xe0;
	pfmc->pcmd.c_rw   			= 0;
	pfmc->pcmd.c_addr_h_v 		= 0;
	pfmc->pcmd.c_test_0         = 0;
	pfmc->pcmd.c_n_addr_cycs	= 2;
	pfmc->pcmd.c_addr[0]		= (addrl >> 0)  & 0xff;	// a07-a00
	pfmc->pcmd.c_addr[1]		= (addrl >> 8)  & 0x0f;	// a11-a08


	bus_addr = ab_fmc_set_bus_addr_cmdphase(pfmc);

	// send command to fmc.
	// (note) we need to send cmd.phase twice if address is over 32-bit.
	// -- actual command to start nand cycles.
	bus_data = ab_fmc_set_dev_addr(pfmc);
	REGRW32(bus_addr, 0) = bus_data;
	// -- do data phase
	ab_fmc_dataphase_read(pfmc);
	
	return 0;
}


//------------------------------------------------------------------------------

// fmc pointer
ABmFmc fmcst;
ABmFmc *pfmc;

//--------------------------------------------------------------------
// set up fmc
//--------------------------------------------------------------------

unsigned ab_fmc_flash_addr_gen(unsigned comumn_addr, unsigned row_addr, unsigned block_addr) {
	unsigned actual_flash_addr;
	actual_flash_addr =  ((block_addr&0x7ff)<<18) | ((row_addr&0x3f)<<12)| (comumn_addr&0xfff);
	return actual_flash_addr;
}



int setup_fmc()
{
    // setup parameter
    pfmc->setup.en_intr     = 0;
    pfmc->setup.no_lp_mode  = 0;
    pfmc->setup.en_ecc_intr = 0;
    pfmc->setup.en_wp_mode  = 0;

    pfmc->setup.t_prescale	= 1;
    pfmc->setup.t_rr		= 1;
    pfmc->setup.t_alr		= 0;
    pfmc->setup.t_cea		= 0;
    pfmc->setup.t_wl		= 2;
    pfmc->setup.t_wh		= 2;
    pfmc->setup.t_rl		= 2;
    pfmc->setup.t_rh		= 2;

    // execute setup
    ab_fmc_setup(pfmc);
    
	return 0;
}

//--------------------------------------------------------------------
// Main function
//--------------------------------------------------------------------

//--------------------------------------------------------------------
// Array organization of H27UAG8T2A
//--------------------------------------------------------------------
// -> 1 Page 	: (4K+224) Bytes
// -> 1 Block 	: (4K+224) * 128 pages = (512K+28K) Bytes
// -> 1 Device 	: 4096 Block = 2G Byte
//--------------------------------------------------------------------

//--------------------------------------------------------------------
// Addesss Cycle Map
//--------------------------------------------------------------------
// 1st Cycle : A00 A01 A02 A03 A04 A05 A06 A07
// 2nd Cycle : A08 A09 A10 A11 A12 	0   0   0 
// 3rd Cycle : A13 A14 A15 A16 A17 A18 A19 A20
// 4th Cycle : A21 A22 A23 A25 A25 A26 A27 A28
// 5th Cycle : A29 A30 A31  0   0   0   0   0
//--------------------------------------------------------------------
// Column 	Address : (A00 - A12)
// Row 		Address : Page Adress (A13 - A19) & Plane Address (A20)
// Block 	Address : A21 - the last address
//--------------------------------------------------------------------




void __nand_test_m_to_m(void* pSrcBuff, void* pDstBuff, UINT32 nLength)
{
    INT32 ret = NC_SUCCESS; 

    eDMA_CH Ch = DMA_CH2;
    tDMA_PARAM tDMAParam;

    UINT8* pInstBuff = (UINT8*)(APACHE_DRAM_BASE+0x0F000000);;


    // Set DMA Operation Mode 
    tDMAParam.mReqType    = DMA_MEM_TO_MEM; 
    tDMAParam.mInstAddr   = (UINT32)pInstBuff;  
    tDMAParam.mIntEn      = DISABLE;
    tDMAParam.mRxIncrEn   = ENABLE;  
    tDMAParam.mRxBurstLen = 4;  
    tDMAParam.mTxIncrEn   = ENABLE;  
    tDMAParam.mTxBurstLen = 4;  
    tDMAParam.mSwap       = DMA_SWAP_NO; 


    // Open DMA 
    ncLib_DMA_Open();


    // Init DAM Channel 
    ret = ncLib_DMA_Control(GCMD_DMA_INIT_CH, Ch, &tDMAParam, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel Init Error!\n");
        return;
    }


    // DMA Start
    ret = ncLib_DMA_Control(GCMD_DMA_START, Ch, (UINT32)pSrcBuff, (UINT32)pDstBuff, nLength, CMD_END);
    if(ret == NC_SUCCESS)
    {
        // DMA Done Wait
        while((ret = ncLib_DMA_Control(GCMD_DMA_DONE, Ch, CMD_END)) == NC_FAILURE)
        {
            if(APACHE_TEST_mTimeOut(2000))
            {
                DEBUGMSG(MSGWARN, " - DMA TimeOut!~\n");
                break;
            }
            APACHE_TEST_mTimeOut(0);
        }
    }
    else
    {
        DEBUGMSG(MSGERR, "DMA Start Error!\n"); 
    }


    // DMA Status Check
    if(ret != NC_FAILURE)
    {   
        if(ret != 0x01)
            DEBUGMSG(MSGWARN, "\nDMA Error Status : 0x%04X\n", ret);
    }


    // DeInit DMA Channel
    ret = ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, Ch, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel DeInit Error!\n");
        return;
    }


    // Close DMA
    ncLib_DMA_Close();    
}



int __nand_test(void)
{
    UINT8* pSrcBuff  = (UINT8*)(0x72000000);
    UINT8* pDstBuff  = (UINT8*)(0x82000000);
    
	unsigned int flash_addr=0;
    
	unsigned int BLOCK_START;
	unsigned int LOAD_SIZE;
	unsigned int BLOCK_CNT; 
    
	unsigned i,j,k;
	unsigned char WData[FMC_DEV_PAGE_BYTES_D];


	DEBUGMSG(MSGINFO, "## ab_fmc flash write program.\n");


	// Initialize FMC
	pfmc = (ABmFmc *)(&fmcst);
	setup_fmc();


	// Read id 
	for(i=0; i<5; i++) 
		pfmc->pd.data[i] = 0;
    
	ab_fmc_read_id(pfmc);

	for(i=0; i<5; i++)
	{
        DEBUGMSG(MSGINFO, "NAND ID[%d]: %02x\n", i, pfmc->pd.data[i]);
	}

    if( 
        (pfmc->pd.data[0] != 0xEF)
     || (pfmc->pd.data[1] != 0xDA)
     || (pfmc->pd.data[2] != 0x90)
     || (pfmc->pd.data[3] != 0x95)     
     || (pfmc->pd.data[4] != 0x04)
     )
    {
        return 0;
    }

    
#if 1
	BLOCK_START = 0;
	LOAD_SIZE   = (256*MB);
    BLOCK_CNT = LOAD_SIZE / (NAND_SIZE_OF_PAGE*NAND_NUM_OF_PAGE);
    BLOCK_CNT = 1;

    // Erase
	for (i=0; i< BLOCK_CNT; i++ ) 
    {
		flash_addr = ab_fmc_flash_addr_gen(0, 0, BLOCK_START+i); //column, row, block
        DEBUGMSG(MSGINFO, "\rErase : Addr(0x%08X) : Block %04d", flash_addr, BLOCK_START+i);
        
        ab_fmc_block_erase(pfmc, flash_addr, 0);
	}
    DEBUGMSG(MSGINFO, "\n");


#if 0
    // Read
    for (i=0; i< BLOCK_CNT; i++ ) 
    {
		for (j=0; j< NAND_NUM_OF_PAGE; j++ ) 
		//for (j=0; j< 2; j++ ) 
        {
			flash_addr = ab_fmc_flash_addr_gen(0, j, BLOCK_START+i); //column, row, block
			
            DEBUGMSG(MSGINFO, "\rRead  : Addr(0x%08X) : Block %04d, Page %02d", flash_addr, BLOCK_START+i, j);


            // Clear Buffer
            __test_nand_clear_buff(&(pfmc->pd.data[0]), NAND_SIZE_OF_PAGE);

            
            // Page Read
			pfmc->pd.cnt_data = NAND_SIZE_OF_PAGE+64;
			ab_fmc_page_read(pfmc, flash_addr, 0);



            // Data Compare
            for(k=0; k< NAND_SIZE_OF_PAGE+64; k++)
            {
				if(pfmc->pd.data[k] != 0xFF) 
                {
					DEBUGMSG(MSGERR, "\n>> Block[%d] PAGE[%d] Erase Error: R[%02x]@%d \n", BLOCK_START+i, j, pfmc->pd.data[k], k);
                    __test_nand_display_buff(&(pfmc->pd.data[0]), NAND_SIZE_OF_PAGE+64, flash_addr);
                    break;
				}
            }
		}
	}
    DEBUGMSG(MSGINFO, "\n");
#endif



    // Write
    __test_nand_dummy_buff(&(pfmc->pd.data[0]), NAND_SIZE_OF_PAGE);    
	for (i=0; i< BLOCK_CNT; i++ ) 
    {
		//for (j=0; j< NAND_NUM_OF_PAGE; j++ )
        for (j=0; j< 1; j++ )    
        {
			flash_addr = ab_fmc_flash_addr_gen(0, j, BLOCK_START+i); //column, row, block
			
            DEBUGMSG(MSGINFO, "\rWrite : Addr(0x%08X) : Block %04d, Page %02d", flash_addr, BLOCK_START+i, j);

            // Create Pattern
            __test_nand_dummy_buff_marking(&(pfmc->pd.data[0]), flash_addr);

            // Create Ecc
            __test_nand_ecc_create(&(pfmc->pd.data[0]));

            // Page Write
			pfmc->pd.cnt_data = FMC_DEV_PAGE_BYTES_D;
			ab_fmc_page_write(pfmc, PAGE_PROGRAM, flash_addr, 0); //flash write
		}
	}
    DEBUGMSG(MSGINFO, "\n");


#if 1
	// Read
	for (i=0; i< BLOCK_CNT; i++ ) 
    {
		//for (j=0; j< NAND_NUM_OF_PAGE; j++ ) 
        for (j=0; j< 1; j++ )     
        {
			flash_addr = ab_fmc_flash_addr_gen(0, j, BLOCK_START+i); //column, row, block
			
            DEBUGMSG(MSGINFO, "\rRead  : Addr(0x%08X) : Block %04d, Page %02d", flash_addr, BLOCK_START+i, j);

            // Clear Buffer
            __test_nand_clear_buff(&(pfmc->pd.data[0]), NAND_SIZE_OF_PAGE);

            // Page Read
			pfmc->pd.cnt_data = NAND_SIZE_OF_PAGE;
            pfmc->pcmd.c_continous_r = 0;
			ab_fmc_page_read(pfmc, flash_addr, 0);


            // Create Pattern
            __test_nand_dummy_buff(&WData[0], NAND_SIZE_OF_PAGE);
            __test_nand_dummy_buff_marking(&WData[0], flash_addr);


            // Data Compare
			for(k=0; k <NAND_SIZE_OF_PAGE; k++) 
            {
				if(pfmc->pd.data[k] != WData[k]) 
                {
					DEBUGMSG(MSGERR, "\n>> Block[%d] PAGE[%d] R/W Error: R[%02x]:W[%02x]@%d \n", BLOCK_START+i, j, pfmc->pd.data[k], WData[k], k);
                    __test_nand_display_buff(&(pfmc->pd.data[0]), NAND_SIZE_OF_PAGE+64, flash_addr);
                    break;
				}
			}

            __test_nand_display_buff(&(pfmc->pd.data[0]), 256, flash_addr);
		}
	}
#endif    


#if 1
	// Read
    i=0;
    j=0;
    flash_addr = ab_fmc_flash_addr_gen(0, j, BLOCK_START+i); //column, row, block
			
    DEBUGMSG(MSGINFO, "\rRead  : Addr(0x%08X) : Block %04d, Page %02d", flash_addr, BLOCK_START+i, j);

    // Clear Buffer
    __test_nand_clear_buff(&(pfmc->pd.data[0]), NAND_SIZE_OF_PAGE);

    // Page Read
	pfmc->pd.cnt_data = 1;
    pfmc->pcmd.c_continous_r = 1;
	ab_fmc_page_read(pfmc, flash_addr, 0);


    __nand_test_m_to_m(pSrcBuff, pDstBuff, 256);
#endif    
#endif

	DEBUGMSG(MSGINFO, "\nTest done\n");


	return 0;
}











/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/


void APACHE_TEST_NAND_Init(void)
{
    ncLib_NAND_Open();
    
    ncLib_NAND_Control(GCMD_NAND_INIT, CMD_END);
}


void APACHE_TEST_NAND_DeInit(void)
{ 
    ncLib_NAND_Control(GCMD_NAND_DEINIT, CMD_END);
    
    ncLib_NAND_Close();    
}


void APACHE_TEST_NAND_ReadID(void)
{

    DEBUGMSG(MSGINFO, "[NAND_TEST] Read Identification\n");

    APACHE_TEST_NAND_Init();

    __nand_test();

    APACHE_TEST_NAND_DeInit();
}


void APACHE_TEST_NAND_Ecc(void)
{
    UINT32 i;
	UINT8 wData[256];
	UINT8 rEccCode[3];


    // Buffer Clear
    __test_nand_dummy_buff(&wData[0], 256);
    __test_nand_display_buff(&wData[0], 256, 0x0);


    // Test - 1
    __test_nand_ecc_hamming_simple_calculate(&wData[0], &rEccCode[0]);
    DEBUGMSG(MSGINFO, " > Simple  ECC - ");
    for(i=0; i<3; i++)
        DEBUGMSG(MSGINFO, "%02X ", rEccCode[i]);
    DEBUGMSG(MSGINFO, "\n");


    // Test - 2
    __test_nand_ecc_hamming_calculate(&wData[0], &rEccCode[0]);
    DEBUGMSG(MSGINFO, " > Hamming ECC - ");
    for(i=0; i<3; i++)
        DEBUGMSG(MSGINFO, "%02X ", rEccCode[i]);
    DEBUGMSG(MSGINFO, "\n");


    __test_nand_ecc_ewchon_ecc_test(&wData[0], &rEccCode[0]);
    DEBUGMSG(MSGINFO, " > Ewchon  ECC - ");
    for(i=0; i<3; i++)
        DEBUGMSG(MSGINFO, "%02X ", rEccCode[i]);
    DEBUGMSG(MSGINFO, "\n");
    
}


INT32 APACHE_TEST_NAND_CUTMode(void)
{
    INT32 select;
    char buf[256];
    
    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - NAND                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " NAND Controller                                            \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> Nand Read ID                                           \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_NAND_ReadID();
            break;

            case 2:
                APACHE_TEST_NAND_Ecc();
            break;
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to sub menu\n");
            goto Nand_Exit;
        }
    }

Nand_Exit:

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_NAND */


/* End Of File */

