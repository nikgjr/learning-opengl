/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_PWM










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum
{
    PWM_TEST_CMD_FREQ_UP,
    PWM_TEST_CMD_FREQ_DOWN,
    PWM_TEST_CMD_FREQ_AUTO,
    
    PWM_TEST_CMD_DUTY_UP,
    PWM_TEST_CMD_DUTY_DOWN,
    PWM_TEST_CMD_DUTY_AUTO,

    PWM_TEST_CMD_GET_FREQ_DUTY,

    PWM_TEST_CMD_MAX
    
} ePWM_TEST_CMD;










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    // PWM Control Info
    ePWM_CH     mPWM_CtrlCh; 
    BOOL        mPWM_InitCh[MAX_OF_PWM_CH];
    BOOL        mPWM_RunCh[MAX_OF_PWM_CH];
    BOOL        mPWM_IsrCh[MAX_OF_PWM_CH];   
    UINT32      mPWM_FreqCh[MAX_OF_PWM_CH];       // MIX(100Hz) ~ MAX(1MHz)
    UINT32      mPWM_DutyCh[MAX_OF_PWM_CH];       // MIN(   1%) ~ MAX( 99%)


    // PWM Test Min/Max
    UINT32      mPWM_TestFreqMax;
    UINT32      mPWM_TestFreqStep;
    UINT32      mPWM_TestDutyStep;
    

    // Debug Message OnOff
    BOOL        mPWM_DebugMsgOn;
    
    // AutoTest Run/Stop (used timer)
    BOOL        mPWM_AutoOnOffRun;
    eTIMER_CH   mPWM_AutoOnOffCh;

    // AutoTest Frequency (used timer)
    BOOL        mPWM_AutoFreqRun;
    eTIMER_CH   mPWM_AutoFreqCh;

    // AutoTest Frequency (used timer)
    BOOL        mPWM_AutoDutyRun;    
    eTIMER_CH   mPWM_AutoDutyCh;
} tPWMTEST_FLAG, *ptPWMTEST_FLAG;










/*
********************************************************************************
*               ARIABLE DECLARATIONS
********************************************************************************
*/

volatile tPWMTEST_FLAG tPWMTestFlag; 
volatile tPWMTEST_FLAG tPWMTestFlag_Def = {                                         
                                            // Current Ctrl PWM Channel 
                                            PWM_CH0

                                            // PWM Channel Info
                                            // CH-0     CH-1        CH-2         CH-3
                                            ,{OFF,      OFF,        OFF,        OFF}
                                            ,{OFF,      OFF,        OFF,        OFF}
                                            ,{OFF,      OFF,        OFF,        OFF}
                                            ,{100,      100,        100,        100}   
                                            ,{50,       50,         50,         50}
                                            
                                            // Test Freq Max/Step
                                            ,(10*KHZ)
                                            ,1
                                            ,1

                                            // AutoTest Debug Message OnOff
                                            ,OFF

                                            // AutoTest Run/Stop (used timer)
                                            ,OFF
                                            ,TC_CH0 

                                            // AutoTest Frequency (used timer)
                                            ,OFF
                                            ,TC_CH1

                                            // AutoTest Frequency (used timer)
                                            ,OFF
                                            ,TC_CH2
                                          };










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

void __pwm_test_ctrl_freqency(ePWM_CH Ch, ePWM_TEST_CMD Mode)
{
    volatile static BOOL s_test_frequency_Upflag[MAX_OF_PWM_CH] = {ON, ON, ON, ON};          
    volatile static BOOL s_test_dutycycle_Upflag[MAX_OF_PWM_CH] = {ON, ON, ON, ON};
    
    BOOL   Update   = OFF;
    UINT32 FreqMax  = tPWMTestFlag.mPWM_TestFreqMax;
    UINT32 FreqStep = tPWMTestFlag.mPWM_TestFreqStep;
    UINT32 DutyStep = tPWMTestFlag.mPWM_TestDutyStep;


    switch(Mode)
    {
        case PWM_TEST_CMD_FREQ_UP:
        {
            if(tPWMTestFlag.mPWM_FreqCh[Ch] <= (FreqMax-FreqStep))
            {
                tPWMTestFlag.mPWM_FreqCh[Ch] += FreqStep;
                Update = ON;
            }
        }
        break;


        case PWM_TEST_CMD_FREQ_DOWN:
        {
            if(tPWMTestFlag.mPWM_FreqCh[Ch] >= (PWM_FREQ_MIN+FreqStep))
            {
                tPWMTestFlag.mPWM_FreqCh[Ch] -= FreqStep;
                Update = ON;
            }
        }
        break;


        case PWM_TEST_CMD_DUTY_UP:
        {
            if(tPWMTestFlag.mPWM_DutyCh[Ch] <= (PWM_DUTY_MAX-DutyStep))
            {
                tPWMTestFlag.mPWM_DutyCh[Ch] += DutyStep;
                Update = ON;
            }
        }
        break;


        case PWM_TEST_CMD_DUTY_DOWN:
        {
            if(tPWMTestFlag.mPWM_DutyCh[Ch] >= (PMW_DUTY_MIN+DutyStep))
            {
                tPWMTestFlag.mPWM_DutyCh[Ch] -= DutyStep;
                Update = ON;
            }
        }
        break;


        case PWM_TEST_CMD_FREQ_AUTO:
        {
            if((tPWMTestFlag.mPWM_AutoFreqRun == ON) && (tPWMTestFlag.mPWM_InitCh[Ch] == ON) && (tPWMTestFlag.mPWM_RunCh[Ch] == ON))
            {
                if(s_test_frequency_Upflag[Ch] == ON)
                {
                    if(tPWMTestFlag.mPWM_FreqCh[Ch] <= (FreqMax-FreqStep))
                    {
                        tPWMTestFlag.mPWM_FreqCh[Ch] += FreqStep;
                        Update = ON;
                    }
                    else
                    {
                        s_test_frequency_Upflag[Ch] = OFF;
                    }
                }
                else
                {
                    if(tPWMTestFlag.mPWM_FreqCh[Ch] >= (PWM_FREQ_MIN+FreqStep))
                    {
                        tPWMTestFlag.mPWM_FreqCh[Ch] -= FreqStep;
                        Update = ON;
                    }
                    else
                    {
                        s_test_frequency_Upflag[Ch] = ON;
                    }
                }

                if(tPWMTestFlag.mPWM_DebugMsgOn == ON)
                    DEBUGMSG(MSGINFO, "\r > PWM[%d] Freq(%d)Hz, Duty(%d)%%", Ch, tPWMTestFlag.mPWM_FreqCh[Ch], tPWMTestFlag.mPWM_DutyCh[Ch]);
            }
        }
        break;


        case PWM_TEST_CMD_DUTY_AUTO:
        {
            if((tPWMTestFlag.mPWM_AutoDutyRun == ON) && (tPWMTestFlag.mPWM_InitCh[Ch] == ON) && (tPWMTestFlag.mPWM_RunCh[Ch] == ON))
            {
                if(s_test_dutycycle_Upflag[Ch] == ON)
                {
                    if(tPWMTestFlag.mPWM_DutyCh[Ch] <= (PWM_DUTY_MAX-DutyStep))
                    {
                        tPWMTestFlag.mPWM_DutyCh[Ch] += DutyStep;
                        Update = ON;
                    }
                    else
                    {
                        s_test_dutycycle_Upflag[Ch] = OFF;
                    }
                }
                else
                {
                    if(tPWMTestFlag.mPWM_DutyCh[Ch] >= (PMW_DUTY_MIN+DutyStep))
                    {
                        tPWMTestFlag.mPWM_DutyCh[Ch] -= DutyStep;
                        Update = ON;
                    }
                    else
                    {
                        s_test_dutycycle_Upflag[Ch] = ON;
                    }
                }

                if(tPWMTestFlag.mPWM_DebugMsgOn == ON)
                    DEBUGMSG(MSGINFO, "\r > PWM[%d] Freq(%d)Hz, Duty(%d)%%", Ch, tPWMTestFlag.mPWM_FreqCh[Ch], tPWMTestFlag.mPWM_DutyCh[Ch]);
            }
        }
        break;


        case PWM_TEST_CMD_GET_FREQ_DUTY:
        {
            if((tPWMTestFlag.mPWM_AutoFreqRun == ON) || (tPWMTestFlag.mPWM_AutoOnOffRun == ON))
            {
                if(s_test_frequency_Upflag[Ch] == ON)
                {
                    if(tPWMTestFlag.mPWM_FreqCh[Ch] <= (FreqMax-FreqStep))
                        tPWMTestFlag.mPWM_FreqCh[Ch] += FreqStep;
                    else
                        s_test_frequency_Upflag[Ch] = OFF;
                }
                else
                {
                    if(tPWMTestFlag.mPWM_FreqCh[Ch] >= (PWM_FREQ_MIN+FreqStep))
                        tPWMTestFlag.mPWM_FreqCh[Ch] -= FreqStep;
                    else
                        s_test_frequency_Upflag[Ch] = ON;
                }
            }
            
            if((tPWMTestFlag.mPWM_AutoDutyRun == ON) || (tPWMTestFlag.mPWM_AutoOnOffRun == ON))
            {
                if(s_test_dutycycle_Upflag[Ch] == ON)
                {
                    if(tPWMTestFlag.mPWM_DutyCh[Ch] <= (PWM_DUTY_MAX-DutyStep))
                        tPWMTestFlag.mPWM_DutyCh[Ch] += DutyStep;
                    else
                        s_test_dutycycle_Upflag[Ch] = OFF;
                }
                else
                {
                    if(tPWMTestFlag.mPWM_DutyCh[Ch] >= (PMW_DUTY_MIN+DutyStep))
                        tPWMTestFlag.mPWM_DutyCh[Ch] -= DutyStep;
                    else
                        s_test_dutycycle_Upflag[Ch] = ON;
                }
            }
            
            if(tPWMTestFlag.mPWM_DebugMsgOn == ON)
                DEBUGMSG(MSGINFO, "\r > PWM[%d] Freq(%d)Hz, Duty(%d)%%", Ch, tPWMTestFlag.mPWM_FreqCh[Ch], tPWMTestFlag.mPWM_DutyCh[Ch]);
        }
        break;
    }

    if(Update == ON)
        ncLib_PWM_Control(GCMD_PWM_SET_FREQUENCY, Ch, tPWMTestFlag.mPWM_FreqCh[Ch], tPWMTestFlag.mPWM_DutyCh[Ch], CMD_END);

}


void APACHE_TEST_PWM_FreqMaxChange(void)
{
    tPWMTestFlag.mPWM_TestFreqMax = APACHE_TEST_Display_InputValue(PWM_FREQ_MIN, (1*MHZ), "Change Test Frequence Max");
}


void APACHE_TEST_PWM_FreqStepChange(void)
{
    tPWMTestFlag.mPWM_TestFreqStep = APACHE_TEST_Display_InputValue(1, (1*KHZ), "Change Test Frequence Step");
}


void APACHE_TEST_PWM_DutyStepChange(void)
{
    tPWMTestFlag.mPWM_TestDutyStep = APACHE_TEST_Display_InputValue(1, 20, "Change Test Duty Step");
}


void APACHE_TEST_PWM_SetDebugPort(BOOL OnOff)
{
    UINT32 Reg;

    Reg = REGRW32(APACHE_SYSCON_BASE, 0x1040);
    Reg &= ~(7<<16);

    if(OnOff == ON)
        Reg |= (1<<16); 
    
    REGRW32(APACHE_SYSCON_BASE, 0x1040) = Reg;
}


void APACHE_TEST_PWM_Isr(UINT32 irq)
{
    INT32 IntSts;
    ePWM_CH Ch = (ePWM_CH)(irq - IRQ_NUM_PWM0);

    IntSts = ncLib_PWM_Control(GCMD_PWM_GET_INT_STS, Ch, CMD_END);
    //DEBUGMSG(MSGINFO, "  > PWM_%d ISR : 0x%03x", Ch, IntSts);
    
    if(IntSts != NC_FAILURE)
    {
        if(IntSts & (1<<Ch))
        {
            if(tPWMTestFlag.mPWM_AutoOnOffRun == OFF)
            {
                __pwm_test_ctrl_freqency(Ch, PWM_TEST_CMD_GET_FREQ_DUTY);
                ncLib_PWM_Control(GCMD_PWM_SET_FREQUENCY, Ch, tPWMTestFlag.mPWM_FreqCh[Ch], tPWMTestFlag.mPWM_DutyCh[Ch], CMD_END);
            }

            if(!(IntSts & PWM_MODE_AUTO_RELOAD))
            {
                // One Shot Mode
                ncLib_PWM_Control(GCMD_PWM_START, Ch, CMD_END);
            }
        }
        else
        {
            DEBUGMSG(MSGERR, "  > PWM ISR Error    : 0x%03x", IntSts);
        }
    }
}


void APACHE_TEST_PWM_Isr_Init(ePWM_CH Ch)
{
    if(tPWMTestFlag.mPWM_IsrCh[Ch] == ON)    
    {
        // Register PWM Interrupt handler
        ncLib_INTC_Control(GCMD_INTC_REGISTER_INT
                          ,IRQ_NUM_PWM0 + Ch
                          ,(PrHandler)APACHE_TEST_PWM_Isr
                          ,CMD_END);
    }
}


void APACHE_TEST_PWM_Isr_DeInit(ePWM_CH Ch)
{
    if(tPWMTestFlag.mPWM_IsrCh[Ch] == ON)
    {
        // Unregister PWM Interrupt Handler
        ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT
                          ,IRQ_NUM_PWM0 + Ch
                          ,CMD_END);
    }
}


void APACHE_TEST_PWM_ChangeChannel(ePWM_CH Ch)
{
    INT8 buf = 0;

    APACHE_TEST_GetArrowKey_Help("Channel Up", "Channel Down", NULL, NULL);
    
    DEBUGMSG(MSGINFO, "  > PWM Select    : %d", Ch);
    
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(Ch < PWM_CH3)
                    ++Ch;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(Ch > PWM_CH0)
                    --Ch;
            }

            DEBUGMSG(MSGINFO, "\r  > PWM Select    : %d", Ch, buf, buf);
        }
    }

    tPWMTestFlag.mPWM_CtrlCh = Ch;
}


void APACHE_TEST_PWM_CtrlFreqDuty(ePWM_CH Ch)
{   
    INT8 buf = 0;

    if( (tPWMTestFlag.mPWM_IsrCh[Ch] == OFF) && (tPWMTestFlag.mPWM_InitCh[Ch] == ON) && (tPWMTestFlag.mPWM_RunCh[Ch] == ON))
    {
        APACHE_TEST_GetArrowKey_Help("Freqency Up", "Freqency Down", "DutyCycle UP", "DutyCycle Down");
        DEBUGMSG(MSGINFO, " > PWM[%d] Freq(%d)Hz, Duty(%d)%%", Ch, tPWMTestFlag.mPWM_FreqCh[Ch], tPWMTestFlag.mPWM_DutyCh[Ch]);
        
        while(1)
        {
            buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

            if(buf != NC_FAILURE)
            {
                // Support Direction Key
                buf = APACHE_TEST_GetArrowKey(buf);

                // Enter Key
                if(buf == RETURN_KEY)
                {
                    DEBUGMSG(MSGINFO, "\n");
                    break;
                }

                // Number Key '8' and Direction Key 'Up'
                if(buf == '8')
                {
                    __pwm_test_ctrl_freqency(Ch, PWM_TEST_CMD_FREQ_UP);
                }
                // Number Key '2' and Direction Key 'Down'
                else if(buf == '2')
                {
                     __pwm_test_ctrl_freqency(Ch, PWM_TEST_CMD_FREQ_DOWN);
                }
                // Number Key '6' and Direction Key 'Rigth'
                else if(buf == '6')
                {
                    __pwm_test_ctrl_freqency(Ch, PWM_TEST_CMD_DUTY_UP);
                }
                // Number Key '4' and Direction Key 'Left'
                else if(buf == '4')
                {
                    __pwm_test_ctrl_freqency(Ch, PWM_TEST_CMD_DUTY_DOWN);
                }
                
                DEBUGMSG(MSGINFO, "\r > PWM[%d] Freq(%d)Hz, Duty(%d)%%", Ch, tPWMTestFlag.mPWM_FreqCh[Ch], tPWMTestFlag.mPWM_DutyCh[Ch]);
                   
            }
  
            nc_mdelay(10);
        }
    }
}


void APACHE_TEST_PWM_Run(ePWM_CH Ch)
{
    if(tPWMTestFlag.mPWM_InitCh[Ch] == ON)
    {
        if(tPWMTestFlag.mPWM_RunCh[Ch] == ON)
            ncLib_PWM_Control(GCMD_PWM_STOP, Ch, CMD_END);
        else
            ncLib_PWM_Control(GCMD_PWM_START, Ch, CMD_END);

        _REVERSE(tPWMTestFlag.mPWM_RunCh[Ch]);
    }
}


void APACHE_TEST_PWM_DeInit(ePWM_CH Ch)
{
    if(tPWMTestFlag.mPWM_InitCh[Ch] == ON)
    {    
        APACHE_TEST_PWM_Isr_DeInit(Ch);
        
        ncLib_PWM_Control(GCMD_PWM_DEINIT_CH, Ch, CMD_END);
        
        tPWMTestFlag.mPWM_InitCh[Ch] = OFF;
        tPWMTestFlag.mPWM_RunCh[Ch]  = OFF; 

        ncLib_PWM_Close();
    }
}


void APACHE_TEST_PWM_Init(ePWM_CH Ch)
{   
    INT32 ret;   
    tPWM_PARAM tPWMParam;
    

    if(tPWMTestFlag.mPWM_InitCh[Ch] == OFF)
    {

        // Open PWM
        ncLib_PWM_Open();   


        // Set INT On/Off  
        if(tPWMTestFlag.mPWM_IsrCh[Ch] == ON)
        {
            tPWMParam.mIsrEn = PWM_ISR_EN;
            tPWMParam.mMode  = PWM_MODE_ONE_SHOT;
        }
        else
        {
            tPWMParam.mIsrEn = PWM_ISR_DIS;    
            tPWMParam.mMode  = PWM_MODE_AUTO_RELOAD;
        }

        
        // Debug - Auto Test Code. 
        __pwm_test_ctrl_freqency(Ch, PWM_TEST_CMD_GET_FREQ_DUTY);


        // Set PWM Operation Mode 
        tPWMParam.mOutEn = PWM_OUT_EN;
        tPWMParam.mLevel = PWM_LEVEL_LOW;
        tPWMParam.mScale = PWM_SCALE_1X;
        //tPWMParam.mMode  = PWM_MODE_AUTO_RELOAD;
        tPWMParam.mFrequency = tPWMTestFlag.mPWM_FreqCh[Ch];
        tPWMParam.mDutyCycle = tPWMTestFlag.mPWM_DutyCh[Ch];


        // Init PWM Channel
        ret = ncLib_PWM_Control(GCMD_PWM_INIT_CH, Ch, &tPWMParam, CMD_END);
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "PWM Init Error!\n");
            return;
        }

        // Register Isr
        APACHE_TEST_PWM_Isr_Init(Ch);

        tPWMTestFlag.mPWM_InitCh[Ch] = ON;

        // PWM Start
        APACHE_TEST_PWM_Run(Ch);
    }
    else
    {
        APACHE_TEST_PWM_DeInit(Ch);
    }
}


void APACHE_TEST_PWM_AutoTest_Isr( UINT32 irq )
{
    ePWM_CH Ch;
    eTIMER_CH TimerCh = (eTIMER_CH)(irq - IRQ_NUM_TIMER0);

    ncLib_TIMER_Control(GCMD_TC_GET_INT_STS, TimerCh, CMD_END);

    for(Ch=PWM_CH0; Ch<MAX_OF_PWM_CH; Ch++)
    {
        if(irq == (IRQ_NUM_TIMER0 + tPWMTestFlag.mPWM_AutoOnOffCh))
        {
            #if 1
                APACHE_TEST_PWM_Init(Ch);
            #else
                APACHE_TEST_PWM_Run(Ch);
            #endif
        }
        else if(irq == (IRQ_NUM_TIMER0 + tPWMTestFlag.mPWM_AutoFreqCh))
        {
            if(tPWMTestFlag.mPWM_IsrCh[Ch] == OFF)
                __pwm_test_ctrl_freqency(Ch, PWM_TEST_CMD_FREQ_AUTO);
        }
        else if(irq == (IRQ_NUM_TIMER0 + tPWMTestFlag.mPWM_AutoDutyCh))
        {
            if(tPWMTestFlag.mPWM_IsrCh[Ch] == OFF)
                __pwm_test_ctrl_freqency(Ch, PWM_TEST_CMD_DUTY_AUTO);
        } 
    }
}


void APACHE_TEST_PWM_AutoTest_UpdateSts(eTIMER_CH Ch)
{
    if(Ch == tPWMTestFlag.mPWM_AutoOnOffCh)
    {
        _REVERSE(tPWMTestFlag.mPWM_AutoOnOffRun);
    }
    else if(Ch == tPWMTestFlag.mPWM_AutoFreqCh)
    {
        _REVERSE(tPWMTestFlag.mPWM_AutoFreqRun);
    }
    else if(Ch == tPWMTestFlag.mPWM_AutoDutyCh)
    {
        _REVERSE(tPWMTestFlag.mPWM_AutoDutyRun);
    }
}
    

void APACHE_TEST_PWM_AutoTest_DeInit(eTIMER_CH Ch)
{
    // timer Stop
    ncLib_TIMER_Control(GCMD_TC_STOP, Ch, CMD_END );

    // Unregister TIMER Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT
                       ,IRQ_NUM_TIMER0 + Ch
                       ,CMD_END);

    // Close Timer
    ncLib_TIMER_Close();


    // Update AutoTest Flag
    APACHE_TEST_PWM_AutoTest_UpdateSts(Ch);    
}


void APACHE_TEST_PWM_AutoTest_Init(eTIMER_CH Ch)
{
    INT32 ret;
    tTIMER_PARAM tTimerParam;


    // Open Timer
    ncLib_TIMER_Open();


    // Init Timer Channel
    tTimerParam.mMode	   = TC_MODE_PERIOD;
    tTimerParam.mPrescaler = 0;
    tTimerParam.mPeriod1   = 10000;
    ret = ncLib_TIMER_Control(GCMD_TC_INIT_CH, Ch, &tTimerParam, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Init Error!\n");
    }


    // Register Interrupt handler
    ncLib_INTC_Control(GCMD_INTC_REGISTER_INT
                      ,IRQ_NUM_TIMER0 + Ch
                      ,(PrHandler)APACHE_TEST_PWM_AutoTest_Isr
                      ,CMD_END);


    // Start timer
    ret = ncLib_TIMER_Control( GCMD_TC_START, Ch, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Start Error!\n");
    }


    // Update AutoTest Flag
    APACHE_TEST_PWM_AutoTest_UpdateSts(Ch);    
}


INT32 APACHE_TEST_PWM_CUTMode(void)
{
    INT32 select;
    char buf[256];
    
    UINT32 i;
    ePWM_CH Ch;


    // Debug Port Enable
    APACHE_TEST_PWM_SetDebugPort(ON);


    // Default Init Variable
    tPWMTestFlag = tPWMTestFlag_Def;

  
    while(1)
    {        
        Ch = tPWMTestFlag.mPWM_CtrlCh;
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - PWM                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " PWM Status                                                 \n");
        for(i=0; i<MAX_OF_PWM_CH; i++)
        {
        DEBUGMSG(MSGINFO, " - PWM Channel[%d]                                          \n", i);             
        DEBUGMSG(MSGINFO, "   .Init        : %s                                        \n", (tPWMTestFlag.mPWM_InitCh[i])?"Init":"DeInit"); 
        DEBUGMSG(MSGINFO, "   .Run         : %s                                        \n", (tPWMTestFlag.mPWM_RunCh[i])?"Run":"Stop");    
        DEBUGMSG(MSGINFO, "   .Isr         : %s                                        \n", (tPWMTestFlag.mPWM_IsrCh[i])?"On":"Off");    
        DEBUGMSG(MSGINFO, "   .Frequency   : %d(Hz)                                    \n", tPWMTestFlag.mPWM_FreqCh[i]); 
        DEBUGMSG(MSGINFO, "   .Duty        : %d(%%)                                    \n", tPWMTestFlag.mPWM_DutyCh[i]);  
        }
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");   
        DEBUGMSG(MSGINFO, " PWM Channel-%d Ctrl                                        \n", Ch);
        DEBUGMSG(MSGINFO, " <1> PWM Channel Change                                     \n");
        DEBUGMSG(MSGINFO, " <2> PWM Channel Init/DeInit    : %s                        \n", (tPWMTestFlag.mPWM_InitCh[Ch])?"Init":"DeInit");
        DEBUGMSG(MSGINFO, " <3> PWM Channel Run/Stop       : %s                        \n", (tPWMTestFlag.mPWM_RunCh[Ch])?"Run":"Stop"); 
        DEBUGMSG(MSGINFO, " <4> PWM Channel Isr On/Off     : %s                        \n", (tPWMTestFlag.mPWM_IsrCh[Ch])?"On":"Off"); 
        DEBUGMSG(MSGINFO, " <5> PWM Channel Freq/Duty Ctrl                             \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " PWM Auto Test - All Channel                                \n");
        DEBUGMSG(MSGINFO, " <6> Auto OnOff Test            : %s                        \n", (tPWMTestFlag.mPWM_AutoOnOffRun)?"On":"Off");
        DEBUGMSG(MSGINFO, " <7> Auto Frequency Test        : %s                        \n", (tPWMTestFlag.mPWM_AutoFreqRun)?"On":"Off");
        DEBUGMSG(MSGINFO, " <8> Auto DutyCycle Test        : %s                        \n", (tPWMTestFlag.mPWM_AutoDutyRun)?"On":"Off");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " PWM Test Flag                                              \n");
        DEBUGMSG(MSGINFO, " <A> All Channel On/Off                                     \n");
        DEBUGMSG(MSGINFO, " <B> All Interrupt On/Off                                   \n");
        DEBUGMSG(MSGINFO, " <C> Test Frequence Max         : %d Hz                     \n", tPWMTestFlag.mPWM_TestFreqMax);
        DEBUGMSG(MSGINFO, " <D> Test Frequence Step        : %d Hz                     \n", tPWMTestFlag.mPWM_TestFreqStep);
        DEBUGMSG(MSGINFO, " <E> Test Duty Step             : %d %%                     \n", tPWMTestFlag.mPWM_TestDutyStep);
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ...                        \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            //////////////////////////////////////////////////////////////
            // PWM Channel Change 
            case 1: 
                APACHE_TEST_PWM_ChangeChannel(Ch);
            break;

            // PWM Channel Init/DeInit
            case 2:
                APACHE_TEST_PWM_Init(Ch);
            break;

            // PWM Channel Run/Stop
            case 3:
                APACHE_TEST_PWM_Run(Ch);
            break;

            // PWM Isr On/Off
            case 4:
                if(tPWMTestFlag.mPWM_InitCh[Ch] == OFF)
                    _REVERSE(tPWMTestFlag.mPWM_IsrCh[Ch]);
                else
                    DEBUGMSG(MSGINFO, " > Please PWM_%d Channel DeInit...\n");
            break;

            // PWM Channel Freq/Duty Ctrl
            case 5:
                APACHE_TEST_PWM_CtrlFreqDuty(Ch);
            break;
            


            //////////////////////////////////////////////////////////////
            // Auto OnOff Test (Used Timer)    
            case 6:
            {
                if((tPWMTestFlag.mPWM_AutoFreqRun == OFF) && (tPWMTestFlag.mPWM_AutoDutyRun == OFF))
                {
                    if(tPWMTestFlag.mPWM_AutoOnOffRun == OFF)
                        APACHE_TEST_PWM_AutoTest_Init(tPWMTestFlag.mPWM_AutoOnOffCh);
                    else
                        APACHE_TEST_PWM_AutoTest_DeInit(tPWMTestFlag.mPWM_AutoOnOffCh);
                }
                else
                {
                    DEBUGMSG(MSGINFO, " > Please AutoFreq or AutoDuty Test Off...\n");
                }
            }
            break;

            // Auto Frequency Test (Used Timer)
            case 7:
            {
                if(tPWMTestFlag.mPWM_AutoOnOffRun == OFF)
                {
                    if(tPWMTestFlag.mPWM_AutoFreqRun == OFF)
                        APACHE_TEST_PWM_AutoTest_Init(tPWMTestFlag.mPWM_AutoFreqCh);
                    else
                        APACHE_TEST_PWM_AutoTest_DeInit(tPWMTestFlag.mPWM_AutoFreqCh);
                }
                else
                {
                    DEBUGMSG(MSGINFO, " > Please AutoOnOff Test Off...\n");
                }
            }
            break;

            // Auto DutyCycle Test (Used Timer)
            case 8:
            {
                if(tPWMTestFlag.mPWM_AutoOnOffRun == OFF)
                {
                    if(tPWMTestFlag.mPWM_AutoDutyRun == OFF)
                        APACHE_TEST_PWM_AutoTest_Init(tPWMTestFlag.mPWM_AutoDutyCh);
                    else
                        APACHE_TEST_PWM_AutoTest_DeInit(tPWMTestFlag.mPWM_AutoDutyCh);
                }
                else
                {
                    DEBUGMSG(MSGINFO, " > Please AutoOnOff Test Off...\n");
                }
            }
            break;



            //////////////////////////////////////////////////////////////
            case 10: // 'A'
            {
                for(Ch=PWM_CH0; Ch<MAX_OF_PWM_CH; Ch++)
                    APACHE_TEST_PWM_Init(Ch);
            }
            break;

            case 11: // 'B'
            {
                for(Ch=PWM_CH0; Ch<MAX_OF_PWM_CH; Ch++)
                {
                    if(tPWMTestFlag.mPWM_InitCh[Ch] == OFF)
                        _REVERSE(tPWMTestFlag.mPWM_IsrCh[Ch]);
                }
            }
            break;


            case 12: // 'C'
            {
                APACHE_TEST_PWM_FreqMaxChange();
            }
            break;


            case 13: // 'D'
            {
                APACHE_TEST_PWM_FreqStepChange();
            }
            break;


            case 14: // 'E'
            {
                APACHE_TEST_PWM_DutyStepChange();
            }
            break;

            
            case 35: // 'Z'
            {
                _REVERSE(tPWMTestFlag.mPWM_DebugMsgOn);
            }
            break;


            case 0:  // '0'
            {
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
                
                if(tPWMTestFlag.mPWM_AutoOnOffRun == ON)
                    APACHE_TEST_PWM_AutoTest_DeInit(tPWMTestFlag.mPWM_AutoOnOffCh);

                if(tPWMTestFlag.mPWM_AutoFreqRun == ON)
                    APACHE_TEST_PWM_AutoTest_DeInit(tPWMTestFlag.mPWM_AutoFreqCh); 

                if(tPWMTestFlag.mPWM_AutoDutyRun == ON)
                    APACHE_TEST_PWM_AutoTest_DeInit(tPWMTestFlag.mPWM_AutoDutyCh);

                for(Ch=PWM_CH0; Ch<MAX_OF_PWM_CH; Ch++)
                    APACHE_TEST_PWM_DeInit(Ch);
            }
            goto PWM_Exit;
        }
    }

PWM_Exit:

    // Debug Port Disable
    APACHE_TEST_PWM_SetDebugPort(OFF);

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_PWM */


/* End Of File */

