/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : testSim_Dma.c
*
*  @brief   :
*
*  @author  :
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "sim.h"


#if SIM_ENABLE_SPI










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/











/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

static void __test_ssp_sim_dummy_buff(UINT8 *pAddr, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        pAddr[i] = i;
    }
}


UINT8 APACHE_TEST_SIM_APP_SSP_sFlash_ReadStatusCmd(eSSP_CH Ch)
{
    UINT8 Command;
    UINT8 Status;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command = 0x05;
    ncLib_SSP_Write(Ch, &Command, 1);	
    ncLib_SSP_Read(Ch, &Status, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	

    return Status;
}


void APACHE_TEST_SIM_APP_SSP_sFlash_WriteDisableCmd(eSSP_CH Ch)
{
    UINT8 Command;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command = 0x04;
    ncLib_SSP_Write(Ch, &Command, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	
}


void APACHE_TEST_SIM_APP_SSP_sFlash_WriteEnableCmd(eSSP_CH Ch)
{
    UINT8 Command;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	
    
    Command = 0x06;
    ncLib_SSP_Write(Ch, &Command, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	

    while( (APACHE_TEST_SIM_APP_SSP_sFlash_ReadStatusCmd(Ch) & (0x1<<1)) != (0x1<<1) ) ;
}


void APACHE_TEST_SIM_APP_SSP_sFlash_WaitWIPCmd(eSSP_CH Ch)
{
    while(APACHE_TEST_SIM_APP_SSP_sFlash_ReadStatusCmd(Ch) & (0x1<<0)) ;
}


void APACHE_TEST_SIM_APP_SSP_sFlash_ReadIDCmd(eSSP_CH Ch, UINT8 *pBuff)
{
    UINT8 Command;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command = 0x9F;
    ncLib_SSP_Write(Ch, &Command, 1);	
    ncLib_SSP_Read(Ch, pBuff, 3);		

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);		
}


void APACHE_TEST_SIM_APP_SSP_sFlash_SectorEraseCmd(eSSP_CH Ch, UINT32 SectorAddr)
{
    UINT8 Command[4];

    APACHE_TEST_SIM_APP_SSP_sFlash_WaitWIPCmd(Ch);
    APACHE_TEST_SIM_APP_SSP_sFlash_WriteEnableCmd(Ch);


    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command[0] = 0x20;
    Command[1] = (SectorAddr>>16 & 0xFF);
    Command[2] = (SectorAddr>>8  & 0xFF);
    Command[3] = (SectorAddr     & 0xFF);
    ncLib_SSP_Write(Ch, Command, 4);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	


    APACHE_TEST_SIM_APP_SSP_sFlash_WaitWIPCmd(Ch);
    APACHE_TEST_SIM_APP_SSP_sFlash_WriteDisableCmd(Ch);
}


void APACHE_TEST_SIM_APP_SSP_sFlash_WritePageCmd(eSSP_CH Ch, UINT32 PageAddr, UINT8 *pBuff)
{
    UINT8 Command[4];
    

    APACHE_TEST_SIM_APP_SSP_sFlash_WaitWIPCmd(Ch);
    APACHE_TEST_SIM_APP_SSP_sFlash_WriteEnableCmd(Ch);


    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command[0] = 0x02;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);
    ncLib_SSP_Write(Ch, Command, 4);	

    ncLib_SSP_Write(Ch, pBuff, 256);	


    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	


    APACHE_TEST_SIM_APP_SSP_sFlash_WaitWIPCmd(Ch);
    APACHE_TEST_SIM_APP_SSP_sFlash_WriteDisableCmd(Ch);


}


void APACHE_TEST_SIM_APP_SSP_sFlash_ReadPageCmd(eSSP_CH Ch, UINT32 PageAddr, UINT8 *pBuff)
{
    UINT8 Command[4];

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command[0] = 0x03;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);
    ncLib_SSP_Write(Ch, Command, 4);		
    ncLib_SSP_Read(Ch, pBuff, 256);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	
}


void APACHE_TEST_SIM_APP_SSP_DeInit(eSSP_CH Ch, ptSSP_PARAM ptSSPParam)
{
    INT32 ret;


    // Deinit SSP Channel
    ret = ncLib_SSP_Control(GCMD_SSP_DEINIT_CH, Ch, CMD_END);	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "SSP DeInit Error!\n");
    } 


    // Close Synchronous Serial Port Interface.
    ncLib_SSP_Close();	
}

void APACHE_TEST_SIM_APP_SSP_Init(eSSP_CH Ch, ptSSP_PARAM ptSSPParam)
{
    INT32 ret;
    

    // Open Synchronous Serial Port Interface. (Only SPI Interface Support)
    ncLib_SSP_Open();	



    // Set SSP Channel Operation  
    ptSSPParam->mMode      = SSP_MODE_MASTER;
    ptSSPParam->mIntEn     = DISABLE;    
    ptSSPParam->mDataWidth = SSP_DS_8BIT;
    ptSSPParam->mBitRate   = 12500000;
    ptSSPParam->mSPO       = SSP_SPO_HIGH;
    ptSSPParam->mSPH       = SSP_SPH_HIGH;
    ptSSPParam->mOrder     = SSP_MSB_FIRST;
    

    // Init SSP Channel 
    ret = ncLib_SSP_Control(GCMD_SSP_INIT_CH, Ch, ptSSPParam, CMD_END);	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "SSP Init Error!\n");
    } 
}



void APACHE_TEST_SIM_APP_SSP_Erase_Write_Read_16(void)
{
    eSSP_CH Ch = SSP_CH0;    
    tSSP_PARAM tSSPParam;    
    UINT32 PageAddr = 0;
 
    UINT8 wBuff[256];
    UINT8 rBuff[256];


    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Sector Erase -> Program Page -> Read Page\n");


    // Init SSP Channel
    rSIM_STEP = 1;  
    APACHE_TEST_SIM_APP_SSP_Init(Ch, &tSSPParam);


    // Generate Write Test Data
    rSIM_STEP = 2;
    __test_ssp_sim_dummy_buff(wBuff, 256);


    // Block Erase 
    rSIM_STEP = 3;
    APACHE_TEST_SIM_APP_SSP_sFlash_SectorEraseCmd(Ch, PageAddr);


    // Page Write
    rSIM_STEP = 4;
    APACHE_TEST_SIM_APP_SSP_sFlash_WritePageCmd(Ch, PageAddr, wBuff);


    // Page Read
    rSIM_STEP = 5;
    APACHE_TEST_SIM_APP_SSP_sFlash_ReadPageCmd(Ch, PageAddr, rBuff);


    // Deinit SSP Channel
    rSIM_STEP = 6;
    APACHE_TEST_SIM_APP_SSP_DeInit(Ch, &tSSPParam);


    rSIM_STEP = 7;
}


void APACHE_TEST_SIM_APP_SSP(void)
{
   APACHE_TEST_SIM_APP_SSP_Erase_Write_Read_16();
}


#endif /* SIM_ENABLE_SPI */


/* End Of File */

