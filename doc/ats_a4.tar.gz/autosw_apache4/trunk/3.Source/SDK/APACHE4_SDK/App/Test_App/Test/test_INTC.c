/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_INTC










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

UINT32 gDebugIrqTick;
UINT32 gDebugFiqTick;
BOOL   gDebugIrqWait;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

void APACHE_TEST_INTC_TIMER_IRQ_Isr(UINT32 irq)
{
    INT32 Sts;
    eTIMER_CH Ch = (eTIMER_CH)(irq - IRQ_NUM_TIMER0);
    
    // Debug Gpio High
    APACHE_TEST_DebugGPIOSet(DBG_GPIO_PORT0, HIGH);

    // Timer Intc Status Clear
    Sts = ncLib_TIMER_Control(GCMD_TC_GET_INT_STS, Ch, CMD_END);

    gDebugIrqTick++;
    DEBUGMSG(MSGINFO, " > INT_%02d S:0x%08x IiqTick : %04d\n", irq, &Sts, gDebugIrqTick);

    if(!(gDebugIrqTick%5)) 
        gDebugIrqWait = TRUE;
    else 
        gDebugIrqWait = FALSE;

    // Wait
    while(gDebugIrqWait == TRUE);

    // Debug Gpio Low
    APACHE_TEST_DebugGPIOSet(DBG_GPIO_PORT0, LOW);
}


void APACHE_TEST_INTC_TIMER_FIQ_Isr(UINT32 fiq)
{
    INT32 Sts;
    eTIMER_CH Ch = (eTIMER_CH)(fiq - IRQ_NUM_TIMER0);

    // Debug Gpio High
    APACHE_TEST_DebugGPIOSet(DBG_GPIO_PORT1, HIGH);

    // Timer Intc Status Clear
    Sts = ncLib_TIMER_Control(GCMD_TC_GET_INT_STS, Ch, CMD_END);

    gDebugFiqTick++;
    DEBUGMSG(MSGINFO, " > INT_%02d S:0x%08x                FiqTick : %04d", fiq, &Sts, gDebugFiqTick);
    
    if(gDebugIrqWait == TRUE)
        DEBUGMSG(MSGINFO, "(Nested)");
    DEBUGMSG(MSGINFO, "\n");
    
    gDebugIrqWait = FALSE;

    // Debug Gpio Low    
    APACHE_TEST_DebugGPIOSet(DBG_GPIO_PORT1, LOW);
}


int APACHE_TEST_INTC_GicInformation(void)
{
    tGIC_ID GicID;
    int ret = NC_SUCCESS;

    ret |= ncLib_INTC_Control(GCMD_INTC_GET_GICID, &GicID, CMD_END);

    if(GicID.Dist_CompID != 0xB105F00D) ret = NC_FAILURE;

    if(ret == NC_SUCCESS)
    {
        UINT32 ContinuationCode, DIST_Revision, ArchRrev, UsesJEPcode, ArchID, DevID;
        UINT32 Implementer, CPUI_Revision, ArchVer, ProductID;

        DevID = GicID.Dist_PeriID0 & 0xFFF;
        ArchID = (GicID.Dist_PeriID0>>12) & 0x3F;
        UsesJEPcode = (GicID.Dist_PeriID0>>19) & 0x1;
        ArchRrev = (GicID.Dist_PeriID0>>20) & 0xF;
        DIST_Revision = (GicID.Dist_PeriID0>>28) & 0xF;
        ContinuationCode = GicID.Dist_PeriID4 & 0xF;

        Implementer = GicID.CPU_IdentID & 0xFFF;
        CPUI_Revision = (GicID.CPU_IdentID>>12) & 0xF;
        ArchVer = (GicID.CPU_IdentID>>16) & 0xF;
        ProductID = (GicID.CPU_IdentID>>20) & 0xFFF;

        DEBUGMSG(MSGINFO, "ARM GIC Identification ...\n\n");
        DEBUGMSG(MSGINFO, "--------------------------------------------------\n");
        DEBUGMSG(MSGINFO, "Distributor descriptions\n");
        DEBUGMSG(MSGINFO, "--------------------------------------------------\n");

        DEBUGMSG(MSGINFO, "Device ID : 0x%04X\n", DevID);
        DEBUGMSG(MSGINFO, " - Identifies the device as a particular GIC implementation.\n");

        DEBUGMSG(MSGINFO, "Architecture ID : 0x%04X\n", ArchID);
        DEBUGMSG(MSGINFO, " - Identifies ARM as the designer of the GIC architecture.\n");

        DEBUGMSG(MSGINFO, "Uses JEP106 code : 0x%04X\n", UsesJEPcode);
        DEBUGMSG(MSGINFO, " - Identifies ARM as the designer of the GIC architecture.\n");

        DEBUGMSG(MSGINFO, "Architecture version : GIC v%d\n", ArchRrev);
        DEBUGMSG(MSGINFO, " - Architecturally-defined revision number for the ARM GIC architecture.\n");

        DEBUGMSG(MSGINFO, "Revision : 0x%04X\n", DIST_Revision);
        DEBUGMSG(MSGINFO, " - An IMPLEMENTATION DEFINED revision number for the Distributer.\n");

        DEBUGMSG(MSGINFO, "Continuation code : 0x%04X\n", ContinuationCode);
        DEBUGMSG(MSGINFO, " - JEP106 continuation code for ARM.\n");

        DEBUGMSG(MSGINFO, "Component ID (0xB105F00D) : 0x%08X\n", GicID.Dist_CompID);
        DEBUGMSG(MSGINFO, " - ARM-Defined Fixed Values for the preamble for component discovery.\n");

        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "--------------------------------------------------\n");
        DEBUGMSG(MSGINFO, "CPU Interface descriptions\n");
        DEBUGMSG(MSGINFO, "--------------------------------------------------\n");

        DEBUGMSG(MSGINFO, "Implementer (0x43B) : 0x%04X\n", Implementer);
        DEBUGMSG(MSGINFO, " - Contains the JEP106 code of the company that implemented the GIC CPU interface.\n");

        DEBUGMSG(MSGINFO, "Revision : 0x%04X\n", CPUI_Revision);
        DEBUGMSG(MSGINFO, " - An IMPLEMENTATION DEFINED revision number for the CPU interface.\n");

        DEBUGMSG(MSGINFO, "Architecture version GIC v%d\n", ArchVer);
        DEBUGMSG(MSGINFO, " - The value of this field depends on the GIC architecture version.\n");

        DEBUGMSG(MSGINFO, "Product ID : 0x%04X\n", ProductID);
        DEBUGMSG(MSGINFO, " - An IMPLEMENTATION DEFINED product identifier.\n");
    }
    else
    {
        DEBUGMSG(MSGERR, "failure, read GIC information\n");
    }

    return ret;
}


void APACHE_TEST_INTC_FIQNestedTest(void)
{
    eTIMER_CH Ch_IRQ, Ch_FIQ;
    tTIMER_PARAM tTimerParam_IRQ;
    tTIMER_PARAM tTimerParam_FIQ;
    INT32 IntcRet = NC_SUCCESS;
    INT32 TimerRet = NC_SUCCESS;


    gDebugIrqTick = 0;
    gDebugFiqTick = 0;
    gDebugIrqWait = FALSE;
    

    ncLib_TIMER_Open();

    /*
     * TIMER interrupt type IRQ - Channel 0
     * */

    Ch_IRQ = TC_CH0;
    tTimerParam_IRQ.mMode      = TC_MODE_PERIOD;
    tTimerParam_IRQ.mPrescaler = 0;
    tTimerParam_IRQ.mPeriod1   = 500000;   // 500mSec

    IntcRet |= ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_TIMER0+Ch_IRQ, (PrHandler)APACHE_TEST_INTC_TIMER_IRQ_Isr, CMD_END);

    TimerRet |= ncLib_TIMER_Control(GCMD_TC_INIT_CH, Ch_IRQ, &tTimerParam_IRQ, CMD_END);
    TimerRet |= ncLib_TIMER_Control(GCMD_TC_START, Ch_IRQ, CMD_END);


    /*
     * TIMER interrupt type FIQ - Channel 1
     * */

    Ch_FIQ = TC_CH1;
    tTimerParam_FIQ.mMode      = TC_MODE_PERIOD;
    tTimerParam_FIQ.mPrescaler = 0;
    tTimerParam_FIQ.mPeriod1   = 1000000;   // 1Sec

    IntcRet |= ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_TIMER0+Ch_FIQ, (PrHandler)APACHE_TEST_INTC_TIMER_FIQ_Isr, CMD_END);

    TimerRet |= ncLib_TIMER_Control(GCMD_TC_INIT_CH, Ch_FIQ, &tTimerParam_FIQ, CMD_END);
    TimerRet |= ncLib_TIMER_Control(GCMD_TC_START, Ch_FIQ, CMD_END);


    // Wait Input Key;
    DEBUGMSG(MSGINFO, " > [Pless any Key - Stop] \n");
    APACHE_TEST_WaitKey();


    /*
     * TIMER interrupt type IRQ close
     * */

    TimerRet |= ncLib_TIMER_Control(GCMD_TC_STOP, Ch_IRQ, CMD_END);
    TimerRet |= ncLib_TIMER_Control(GCMD_TC_DEINIT_CH, Ch_IRQ, CMD_END);

    IntcRet |= ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT, IRQ_NUM_TIMER0+Ch_IRQ, CMD_END);

    /*
     * TIMER interrupt type FIQ close
     * */

    TimerRet |= ncLib_TIMER_Control(GCMD_TC_STOP, Ch_FIQ, CMD_END);
    TimerRet |= ncLib_TIMER_Control(GCMD_TC_DEINIT_CH, Ch_FIQ, CMD_END);

    IntcRet |= ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT, IRQ_NUM_TIMER0+Ch_FIQ, CMD_END);


    ncLib_TIMER_Close();


    /*
     * Function result ...
     * */

    if((IntcRet == NC_SUCCESS) && (TimerRet == NC_SUCCESS))
    {
        DEBUGMSG(MSGINFO, "success, APACHE_TEST_INTC_FIQTest()\n");
    }
    else
    {
        if(IntcRet == NC_SUCCESS)
        {
            DEBUGMSG(MSGERR, "failure, APACHE_TEST_INTC_FIQTest(intc lib fail)\n");
        }
        else if(TimerRet == NC_SUCCESS)
        {
            DEBUGMSG(MSGERR, "failure, APACHE_TEST_INTC_FIQTest(timer lib fail)\n");
        }
    }
}


INT32 APACHE_TEST_INTC_CUTMode(void)
{
    INT32 select;
    char buf[256];

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - INTC                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Generic Interrupt Controller                               \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> GIC Information                                        \n");
        //DEBUGMSG(MSGINFO, " <2> FIQ Nested Priority Test                               \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_INTC_GicInformation();
            break;

            case 2:
                //APACHE_TEST_INTC_FIQNestedTest();
            break;

            case 3:
                // test Data Abort (read)
                REGRW32(0x73000000, 0x00);
            break;

            case 4:
                // test Data Abort (write)
                REGRW32(0x73000000, 0x00) = 0x01;
            break;

            case 0:
                DEBUGMSG(MSGINFO, "Move on to sub menu\n");
            goto INTC_Exit;
        }
    }

INTC_Exit:

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_INTC */


/* End Of File */

