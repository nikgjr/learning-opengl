/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SIM_H__
#define __SIM_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"











/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

// function list enable in Simulation test
#define SIM_ENABLE_MEMORY           FALSE
#define SIM_ENABLE_DMA              FALSE
#define SIM_ENABLE_I2C              FALSE
#define SIM_ENABLE_SPI              FALSE









// debug message on/off
#define SIM_ENABLE_DEBUG_MSG        FALSE









// Simualtion debug register
#define SIM_DEBIG_REG               (APACHE_SYSCON_BASE+0x1000)

#define rSIM_STEP                   (*(volatile unsigned *)(SIM_DEBIG_REG+0x0000))
#define rSIM_RES00                  (*(volatile unsigned *)(SIM_DEBIG_REG+0x0004))
#define rSIM_RES01                  (*(volatile unsigned *)(SIM_DEBIG_REG+0x0008))
#define rSIM_RES02                  (*(volatile unsigned *)(SIM_DEBIG_REG+0x000C))
#define rSIM_RES03                  (*(volatile unsigned *)(SIM_DEBIG_REG+0x0010))
#define rSIM_RES04                  (*(volatile unsigned *)(SIM_DEBIG_REG+0x0014))
#define rSIM_RES05                  (*(volatile unsigned *)(SIM_DEBIG_REG+0x0018))
#define rSIM_RES06                  (*(volatile unsigned *)(SIM_DEBIG_REG+0x001C))
#define rSIM_RES07                  (*(volatile unsigned *)(SIM_DEBIG_REG+0x0020))
#define rSIM_RES08                  (*(volatile unsigned *)(SIM_DEBIG_REG+0x0024))
#define rSIM_RES09                  (*(volatile unsigned *)(SIM_DEBIG_REG+0x0028))
#define rSIM_RES10                  (*(volatile unsigned *)(SIM_DEBIG_REG+0x002C))
#define rSIM_END                    (*(volatile unsigned *)(SIM_DEBIG_REG+0x004C))










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

#if SIM_ENABLE_MEMORY
// DDR Test
extern void APACHE_TEST_SIM_APP_DDR(void);
#endif

#if SIM_ENABLE_DMA
// DMA Test
extern void APACHE_TEST_SIM_APP_DMA(void);
#endif

#if SIM_ENABLE_I2C
// I2C Test
extern void APACHE_TEST_SIM_APP_I2C(void);
#endif

#if SIM_ENABLE_SPI
// SPI Test
extern void APACHE_TEST_SIM_APP_SSP(void);
#endif


#endif  /* __SIM_H__ */


/* End Of File */

