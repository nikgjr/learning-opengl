/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_VDUMP.c
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"


#if ENABLE_IP_VDUMP










/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

//#define __TEST_VDUMP_SEMIHOSTING_ENABLE__










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    // V-Dump Operation Test
    BOOL        mVDP_IsrEn;
    BOOL        mVDP_FrameEdge;
    UINT8       mVDP_InputPath; 
    BOOL        mVDP_InFormat;
    BOOL        mVDP_YUVSelect;
    BOOL        mVDP_FrameType;

    // V-Dump Crop Test
    BOOL        mVDP_CropEn;        
    INT32       mVDP_CropStartH;
    INT32       mVDP_CropEndH;
    INT32       mVDP_CropStartV;
    INT32       mVDP_CropEndV;

    // V-Dump Scaler Test
    BOOL        mVDP_ScalEn;        
    INT32       mVDP_ScalOutputH;
    INT32       mVDP_ScalOutputV;


    // V-Dump WDMA Test
    BOOL        mVDP_ChEn[MAX_OF_VDP_CH];    
    BOOL        mVDP_Endian[MAX_OF_VDP_CH];
    UINT8       mVDP_Parsing[MAX_OF_VDP_CH];
    UINT8       mVDP_Bit[MAX_OF_VDP_CH];
    UINT8       mVDP_Burst[MAX_OF_VDP_CH];
    UINT32      mVDP_DMAAddr[MAX_OF_VDP_CH];

    // Againg Test Flag
    BOOL        mVDP_DebugTestCtrlEn;
    BOOL        mVDP_DebugTestPatternEn;      
    UINT32      mVDP_DebugTestOffset;     
    UINT32      mVDP_DebugTestCropScalStep;
    UINT32      mVDP_DebugTestCropStep;
    UINT32      mVDP_DebugTestScalStep;
    UINT32      mVDP_DebugTestChOpStep;
    UINT32      mVDP_DebugTestCtrlStep;

    // Debug Flag
    eVDP_CH     mVDP_DebugCtrlCh;
    INT32       mVDP_DebugIntSts;
    UINT32      mVDP_DebugTimeOut;
    UINT32      mVDP_DebugFileCnt;
    UINT8       mVDP_DebugPatternIdx;
    
    BOOL        mVDP_DebugBuffCls;
    BOOL        mVDP_DebugFileWrite;
    BOOL        mVDP_DebugMsgOn;
} tVDPTEST_FLAG, *ptVDPTEST_FLAG;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tVDPTEST_FLAG tVDPTestFlag; 
volatile tVDPTEST_FLAG tVDPTestFlag_Def = {                                                
                                                ENABLE
                                                ,VDP_SEL_FRAME_START
                                                ,VDP_I_YC_CROP_OUT_PATH
                                                ,VDP_I_YUV_FORMAT
                                                ,VDP_YUV444
                                                ,VDP_FRAME_VIEWING_FRAME

                                                ,DISABLE
                                                ,320
                                                ,320+1280
                                                ,180
                                                ,180+720
                                                
                                                ,DISABLE
                                                ,640
                                                ,480

                                                // Channel Info
                                                // CH-0                 CH-1                        CH-2
                                                ,{ENABLE,               ENABLE,                     ENABLE}
                                                ,{VDP_ENDIAN_LITTLE,    VDP_ENDIAN_LITTLE,          VDP_ENDIAN_LITTLE}
                                                ,{VDP_P_CRCBY_BGR,      VDP_P_CRCBY_BGR,            VDP_P_CRCBY_BGR}   
                                                ,{VDP_BIT_32,           VDP_BIT_32,                 VDP_BIT_32}
                                                ,{VDP_BURST_16,         VDP_BURST_16,               VDP_BURST_16}
                                                ,{TEST_PHY_DDR_BASE,    TEST_PHY_DDR_BASE+(32*MB),  TEST_PHY_DDR_BASE+(64*MB)} 

                                                ,OFF
                                                ,ON
                                                ,128
                                                ,0
                                                ,0
                                                ,0
                                                ,0
                                                ,0
                                                
                                                ,VDP_CH0
                                                ,0
                                                ,1000
                                                ,0
                                                ,5
                                                
                                                ,OFF
                                                ,OFF
                                                ,OFF
                                           };


const UINT8 cInputPath[MAX_OF_VDP_INPUT_PATH][10]=
{
    {"YC_CROP" },
    {"LDC"     },
    {"OPD"     },
    {"OVERLAY" }
};


const UINT8 cParsing[MAX_OF_VDP_INPUT_FORMAT][MAX_OF_VDP_DATA_BIT][MAX_OF_VDP_PARSING][10]=
{
    {
        {
            {"Y"},
            {"Y"},
            {"Cb"},
            {"Cr"},
            {"Cb"},
            {"Cr"}
        },    
        {
            {"YCb"},
            {"YCr"},
            {"CbY"},
            {"CrY"},
            {"CbCr"},
            {"CrCb"}
        },
        {
            {"YCbCr"},
            {"YCrCb"},
            {"CbYCr"},
            {"CrYCb"},
            {"CbCrY"},
            {"CrCbY"}
        }
    },
    {
        {
            {"R"},
            {"R"},
            {"G"},
            {"B"},
            {"G"},
            {"B"}
        },
        {
            {"RG"},
            {"RB"},
            {"GR"},
            {"BR"},
            {"GB"},
            {"BG"}
        },
        {
            {"RGB"},
            {"RBG"},
            {"BRB"},
            {"BRG"},
            {"GBR"},
            {"BGR"}
        } 
    }
};


const UINT8 cBit[MAX_OF_VDP_DATA_BIT]=
{
    8, 16, 32
};


const UINT8 cBurstMode[MAX_OF_VDP_WRITE_BURST]=
{
    1, 2, 4, 6, 8, 16, 32
};










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

static void __test_vdump_debug_change_frametype(BOOL FrameType)
{
#if 0 // Only Test
    UINT32 Reg;

    Reg = REGRW32(APACHE_ISP_BASE, 0x670);
    Reg &= ~(0x7<<2);
    if(FrameType == VDP_FRAME_VIEWING_FRAME)
        Reg |= (4<<2);
    else
        Reg |= (5<<2);
    REGRW32(APACHE_ISP_BASE, 0x670) = Reg;
#endif
}


static void __test_vdump_debug_change_pattern(UINT8 Idx, BOOL Change)
{
    INT8 buf = 0;
    UINT32 Reg;

    if(Change == TRUE)
    {
        APACHE_TEST_GetArrowKey_Help("Up", "Down", NULL, NULL);
        
        DEBUGMSG(MSGINFO, "  > Pattern Select : %d", Idx);
        
        while(1)
        {
            buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

            if(buf != NC_FAILURE)
            {
                // Support Direction Key
                buf = APACHE_TEST_GetArrowKey(buf);
                
                // Enter Key
                if(buf == RETURN_KEY)
                {
                    DEBUGMSG(MSGINFO, "\n");
                    break;
                }

                // Number Key '8' and Direction Key 'Up'
                if(buf == '8')
                {
                    if(Idx < 5)
                        ++Idx;
                }
                // Number Key '2' and Direction Key 'Down'
                else if(buf == '2')
                {
                    if(Idx > 0)
                        --Idx;
                }

                DEBUGMSG(MSGINFO, "\r  > Pattern Select : %d", Idx);
            }
        }
    }

    // Update
    Reg = REGRW32(APACHE_ISP_BASE, 0x680)&0xFF;
    Reg &= ~(0x17);
    Reg |= Idx;
    REGRW32(APACHE_ISP_BASE, 0x680) = Reg;
    
    tVDPTestFlag.mVDP_DebugPatternIdx = Idx;
}


static void __test_vdump_debug_change_time_out_value(void)
{
    tVDPTestFlag.mVDP_DebugTimeOut = APACHE_TEST_Display_InputValue(100, 5000, "Change Time out value");
}


static void __test_vdump_debug_change_dma_addr(eVDP_CH Ch)
{
    tVDPTestFlag.mVDP_DMAAddr[Ch] = APACHE_TEST_Display_InputValue(TEST_PHY_DDR_BASE, (TEST_PHY_DDR_BASE+(254*MB)), "Change Test DMA Addr");
}


static void __test_vdump_debug_change_scal_out_v(void)
{
    tVDPTestFlag.mVDP_ScalOutputV = APACHE_TEST_Display_InputValue(0, VDUMP_MAX_H_SIZE, "Change Test Scaler V-Size");
}


static void __test_vdump_debug_change_scal_out_h(void)
{
    tVDPTestFlag.mVDP_ScalOutputH = APACHE_TEST_Display_InputValue(0, VDUMP_MAX_H_SIZE, "Change Test Scaler H-Size");
}


static void __test_vdump_debug_change_crop_end_v(void)
{
    tVDPTestFlag.mVDP_CropEndV = APACHE_TEST_Display_InputValue(0, VDUMP_MAX_V_SIZE, "Change Test Crop End V-Position");
}


static void __test_vdump_debug_change_crop_end_h(void)
{
    tVDPTestFlag.mVDP_CropEndH = APACHE_TEST_Display_InputValue(0, VDUMP_MAX_H_SIZE, "Change Test Crop End H-Position");
}


static void __test_vdump_debug_change_crop_start_v(void)
{
    tVDPTestFlag.mVDP_CropStartV = APACHE_TEST_Display_InputValue(0, VDUMP_MAX_V_SIZE, "Change Test Crop Start V-Position");
}


static void __test_vdump_debug_change_crop_start_h(void)
{
    tVDPTestFlag.mVDP_CropStartH = APACHE_TEST_Display_InputValue(0, VDUMP_MAX_H_SIZE, "Change Test Crop Start H-Position");
}


static void __test_vdump_debug_change_burst_length(eVDP_CH Ch, UINT8 Idx)
{
    INT8 buf = 0;

    APACHE_TEST_GetArrowKey_Help("Up", "Down", NULL, NULL);
    
    DEBUGMSG(MSGINFO, "  > Burst Select : VDP_BURST_%d", cBurstMode[Idx]);
    
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(Idx < VDP_BURST_32)
                    ++Idx;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(Idx > VDP_BURST_1)
                    --Idx;
            }

            DEBUGMSG(MSGINFO, "\033[1K\r  > Burst Select : VDP_BURST_%d", cBurstMode[Idx]);
        }
    }

    tVDPTestFlag.mVDP_Burst[Ch] = Idx;
}


static void __test_vdump_debug_change_bit(eVDP_CH Ch, UINT8 Idx)
{
    INT8 buf = 0;

    APACHE_TEST_GetArrowKey_Help("Up", "Down", NULL, NULL);
    
    DEBUGMSG(MSGINFO, "  > Bit Select : VDP_BIT_%d", cBit[Idx]);
    
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(Idx < VDP_BIT_32)
                    ++Idx;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(Idx > VDP_BIT_8)
                    --Idx;
            }

            DEBUGMSG(MSGINFO, "\033[1K\r  > Bit Select : VDP_BIT_%d", cBit[Idx]);
        }
    }

   tVDPTestFlag.mVDP_Bit[Ch] = Idx;
}


static void __test_vdump_debug_change_data_pasing(eVDP_CH Ch, UINT8 Idx)
{
    INT8 buf = 0;

    APACHE_TEST_GetArrowKey_Help("Up", "Down", NULL, NULL);

    DEBUGMSG(MSGINFO, "  > Parsing Select : %s", cParsing[tVDPTestFlag.mVDP_InFormat][tVDPTestFlag.mVDP_Bit[Ch]][Idx]);
    
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(Idx < VDP_P_CRCBY_BGR)
                    ++Idx;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(Idx > VDP_P_YCBCR_RGB)
                    --Idx;
            }
            
            DEBUGMSG(MSGINFO, "\033[1K\r  > Parsing Select : %s", cParsing[tVDPTestFlag.mVDP_InFormat][tVDPTestFlag.mVDP_Bit[Ch]][Idx]);
        }
    }

    tVDPTestFlag.mVDP_Parsing[Ch] = Idx;
}


static void __test_vdump_debug_change_input_path(UINT8 Idx)
{
    INT8 buf = 0;

    APACHE_TEST_GetArrowKey_Help("Up", "Down", NULL, NULL);
    
    DEBUGMSG(MSGINFO, "  > InputPath Select : VDP_I_%s_OUT_PATH", cInputPath[Idx]);
    
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(Idx < VDP_I_OVERLAY_OUT_PATH)
                    ++Idx;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(Idx > VDP_I_YC_CROP_OUT_PATH)
                    --Idx;
            }

            DEBUGMSG(MSGINFO, "\033[1K\r  > InputPath Select : VDP_I_%s_OUT_PATH", cInputPath[Idx]);
        }
    }

    tVDPTestFlag.mVDP_InputPath = Idx;
}


static void __test_vdump_debug_loop_size_offset(void)
{
    tVDPTestFlag.mVDP_DebugTestOffset = APACHE_TEST_Display_InputValue(1, 0xffff, "Change Decrease Size");
}


static void __test_vdump_debug_loop_next_pattern(void)
{
    UINT8 Idx = tVDPTestFlag.mVDP_DebugPatternIdx;

    Idx = ((Idx==0)?2:(Idx==2)?5:0);
    __test_vdump_debug_change_pattern(Idx, FALSE);
}


static INT32 __test_vdump_debug_loop_next_crop_scaler_size(void)
{
    INT32 ret = NC_SUCCESS;
    
    UINT32 nInWidth;
    UINT32 nInHeigth;

    static UINT32 sTestCurrStep = 3;

    // Get Input Path Image Size
    ncLib_VDP_Control(GCMD_VDP_GET_INPUT_SIZE, &nInWidth, &nInHeigth,  CMD_END);


    switch(tVDPTestFlag.mVDP_DebugTestCropScalStep)
    {
        // Test Step - 0 : H/V-Line Decrease Test Start
        case 0:
        {
            //----------------------------------CROP-----------------------------------
            // Test Start Postion Setting 
            tVDPTestFlag.mVDP_CropEn     = ENABLE;
            tVDPTestFlag.mVDP_CropStartH = 0;
            tVDPTestFlag.mVDP_CropEndH   = (nInWidth - tVDPTestFlag.mVDP_CropStartH);
            tVDPTestFlag.mVDP_CropStartV = 0;
            tVDPTestFlag.mVDP_CropEndV   = (nInHeigth - tVDPTestFlag.mVDP_CropStartV);

            // V/H-Line Decrease
            tVDPTestFlag.mVDP_CropEndH -= tVDPTestFlag.mVDP_DebugTestOffset;
            tVDPTestFlag.mVDP_CropEndV -= tVDPTestFlag.mVDP_DebugTestOffset;

            // Check V/H-Min Size
            if(tVDPTestFlag.mVDP_CropEndH < VDUMP_MIN_H_SIZE) 
                tVDPTestFlag.mVDP_CropEndH = VDUMP_MIN_H_SIZE;
            if(tVDPTestFlag.mVDP_CropEndV < VDUMP_MIN_V_SIZE) 
                tVDPTestFlag.mVDP_CropEndV = VDUMP_MIN_H_SIZE;


            //----------------------------------SCAL-----------------------------------
            // Test Start Postion Setting 
            tVDPTestFlag.mVDP_ScalEn      = ENABLE;
            tVDPTestFlag.mVDP_ScalOutputH = tVDPTestFlag.mVDP_CropEndH;
            tVDPTestFlag.mVDP_ScalOutputV = tVDPTestFlag.mVDP_CropEndV;

            // V/H-Line Decrease
            tVDPTestFlag.mVDP_ScalOutputH -= tVDPTestFlag.mVDP_DebugTestOffset;
            tVDPTestFlag.mVDP_ScalOutputV -= tVDPTestFlag.mVDP_DebugTestOffset; 

            // Check V/H-Min Size
            if(tVDPTestFlag.mVDP_ScalOutputH < VDUMP_MIN_H_SIZE) 
                tVDPTestFlag.mVDP_ScalOutputH = VDUMP_MIN_H_SIZE;
            if(tVDPTestFlag.mVDP_ScalOutputV < VDUMP_MIN_V_SIZE) 
                tVDPTestFlag.mVDP_ScalOutputV = VDUMP_MIN_V_SIZE;
            
            // Next Test Step
            tVDPTestFlag.mVDP_DebugTestCropScalStep++;
        }
        break;


        // Test Step - 1 : Scal H/V-Line Decrease Test
        case 1:
        {
            // V/H Line Decrease
            tVDPTestFlag.mVDP_ScalOutputH -= tVDPTestFlag.mVDP_DebugTestOffset;
            tVDPTestFlag.mVDP_ScalOutputV -= tVDPTestFlag.mVDP_DebugTestOffset;
            
            // Defence Code
            if(tVDPTestFlag.mVDP_ScalOutputV < VDUMP_MIN_V_SIZE) 
                tVDPTestFlag.mVDP_ScalOutputV = VDUMP_MIN_V_SIZE;
                
            // Check H-Min Size
            if(tVDPTestFlag.mVDP_ScalOutputH < VDUMP_MIN_H_SIZE)
            {
                tVDPTestFlag.mVDP_ScalOutputH = VDUMP_MIN_H_SIZE;

                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestCropScalStep++;
            }
        }
        break;


        // Test Step - 2 : Scal H/V-Line Increase Test
        case 2:
        {
            // V/H Line Increase
            tVDPTestFlag.mVDP_ScalOutputH += tVDPTestFlag.mVDP_DebugTestOffset;
            tVDPTestFlag.mVDP_ScalOutputV += tVDPTestFlag.mVDP_DebugTestOffset;
            
            // Check V-Max Size
            if(tVDPTestFlag.mVDP_ScalOutputV >= tVDPTestFlag.mVDP_CropEndV) 
                tVDPTestFlag.mVDP_ScalOutputV = (tVDPTestFlag.mVDP_CropEndV - tVDPTestFlag.mVDP_DebugTestOffset);
                
            // Check H-Max Size
            if(tVDPTestFlag.mVDP_ScalOutputH >= tVDPTestFlag.mVDP_CropEndH)
            {
                // H-Line Max Setting
                tVDPTestFlag.mVDP_ScalOutputH = (tVDPTestFlag.mVDP_CropEndH - tVDPTestFlag.mVDP_DebugTestOffset);
                
                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestCropScalStep = sTestCurrStep;
            }
        }
        break;


        // Test Step - 3 : Crop H/V-Line Decrease
        case 3:
        {
            sTestCurrStep = 3;
            //----------------------------------CROP-----------------------------------
            // V/H Line Decrease
            tVDPTestFlag.mVDP_CropEndH -= tVDPTestFlag.mVDP_DebugTestOffset; 
            tVDPTestFlag.mVDP_CropEndV -= tVDPTestFlag.mVDP_DebugTestOffset;

            // Check V-Min Size
            if(tVDPTestFlag.mVDP_CropEndV < VDUMP_MIN_V_SIZE) 
                tVDPTestFlag.mVDP_CropEndV = VDUMP_MIN_V_SIZE; 

            // Check H-Min Size
            if(tVDPTestFlag.mVDP_CropEndH < VDUMP_MIN_H_SIZE)
            {
                 // H-Line Min Set
                tVDPTestFlag.mVDP_CropEndH = VDUMP_MIN_H_SIZE;

                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestCropScalStep++;
            }
            else
            {
                //----------------------------------SCAL-----------------------------------
                // Test Start Postion Setting 
                tVDPTestFlag.mVDP_ScalOutputH = tVDPTestFlag.mVDP_CropEndH;
                tVDPTestFlag.mVDP_ScalOutputV = tVDPTestFlag.mVDP_CropEndV;

                // V/H-Line Decrease
                tVDPTestFlag.mVDP_ScalOutputH -= tVDPTestFlag.mVDP_DebugTestOffset;
                tVDPTestFlag.mVDP_ScalOutputV -= tVDPTestFlag.mVDP_DebugTestOffset; 

                // Defence Code
                if(tVDPTestFlag.mVDP_ScalOutputH < VDUMP_MIN_H_SIZE) 
                    tVDPTestFlag.mVDP_ScalOutputH = VDUMP_MIN_H_SIZE;
                if(tVDPTestFlag.mVDP_ScalOutputV < VDUMP_MIN_V_SIZE) 
                    tVDPTestFlag.mVDP_ScalOutputV = VDUMP_MIN_V_SIZE;

                // Scaler Test Step
                tVDPTestFlag.mVDP_DebugTestCropScalStep = 1;
            }
        }
        break;


        // Test Step - 4 : Crop H/V-Line Increase
        case 4:
        {
            sTestCurrStep = 4;
            //----------------------------------CROP-----------------------------------
            // V/H-Line Increase
            tVDPTestFlag.mVDP_CropEndH += tVDPTestFlag.mVDP_DebugTestOffset;
            tVDPTestFlag.mVDP_CropEndV += tVDPTestFlag.mVDP_DebugTestOffset;

            // Check V-Max Size
            if(tVDPTestFlag.mVDP_CropEndV >= nInHeigth) 
                tVDPTestFlag.mVDP_CropEndV = (nInHeigth - tVDPTestFlag.mVDP_DebugTestOffset - tVDPTestFlag.mVDP_CropStartV);
            
            // Check H-Max Size
            if(tVDPTestFlag.mVDP_CropEndH >= nInWidth)
            {
                // H-Line Max Setting
                tVDPTestFlag.mVDP_CropEndH = (nInWidth - tVDPTestFlag.mVDP_DebugTestOffset - tVDPTestFlag.mVDP_CropStartH);
              
                // Test End
                tVDPTestFlag.mVDP_CropEn = DISABLE;
                tVDPTestFlag.mVDP_ScalEn = DISABLE;
                tVDPTestFlag.mVDP_DebugTestCropScalStep = 0;
                sTestCurrStep = 3;
                ret = NC_FAILURE;
            }
            else
            {
                //----------------------------------SCAL-----------------------------------
                // Test Start Postion Setting 
                tVDPTestFlag.mVDP_ScalOutputH = tVDPTestFlag.mVDP_CropEndH;
                tVDPTestFlag.mVDP_ScalOutputV = tVDPTestFlag.mVDP_CropEndV;

                // V/H-Line Decrease
                tVDPTestFlag.mVDP_ScalOutputH -= tVDPTestFlag.mVDP_DebugTestOffset;
                tVDPTestFlag.mVDP_ScalOutputV -= tVDPTestFlag.mVDP_DebugTestOffset; 

                // Defence Code
                if(tVDPTestFlag.mVDP_ScalOutputH < VDUMP_MIN_H_SIZE) 
                    tVDPTestFlag.mVDP_ScalOutputH = VDUMP_MIN_H_SIZE;
                if(tVDPTestFlag.mVDP_ScalOutputV < VDUMP_MIN_V_SIZE) 
                    tVDPTestFlag.mVDP_ScalOutputV = VDUMP_MIN_V_SIZE;

                // Scaler Test Step
                tVDPTestFlag.mVDP_DebugTestCropScalStep = 1;
            }
        }
        break;
        
    }


    return ret;
}


static INT32 __test_vdump_debug_loop_next_scaler_size(void)
{
    INT32 ret = NC_SUCCESS;
    
    UINT32 nInWidth;
    UINT32 nInHeigth;


    // Get Input Path Image Size
    if(tVDPTestFlag.mVDP_CropEn == ENABLE)
    {
        nInWidth  = tVDPTestFlag.mVDP_CropEndH - tVDPTestFlag.mVDP_CropStartH;
        nInHeigth = tVDPTestFlag.mVDP_CropEndV - tVDPTestFlag.mVDP_CropStartV;

        if(nInWidth  < tVDPTestFlag.mVDP_ScalOutputH)    
            nInWidth = tVDPTestFlag.mVDP_ScalOutputH;
        if(nInHeigth < tVDPTestFlag.mVDP_ScalOutputV)    
            nInHeigth = tVDPTestFlag.mVDP_ScalOutputV;
    }
    else
    {
        ncLib_VDP_Control(GCMD_VDP_GET_INPUT_SIZE, &nInWidth, &nInHeigth, CMD_END);
    }


    switch(tVDPTestFlag.mVDP_DebugTestScalStep)
    {
        // Test Step - 0 : H/V-Line Decrease Test Start
        case 0:
        {
            // Test Start Postion Setting 
            tVDPTestFlag.mVDP_ScalEn      = ENABLE;
            tVDPTestFlag.mVDP_ScalOutputH = nInWidth;
            tVDPTestFlag.mVDP_ScalOutputV = nInHeigth;

            // H-Line Decrease
            tVDPTestFlag.mVDP_ScalOutputH -= tVDPTestFlag.mVDP_DebugTestOffset;

            // Check H-Min Size
            if(tVDPTestFlag.mVDP_ScalOutputH < VDUMP_MIN_H_SIZE) 
                tVDPTestFlag.mVDP_ScalOutputH = VDUMP_MIN_H_SIZE;

            // Next Test Step
            tVDPTestFlag.mVDP_DebugTestScalStep++;
        }
        break;


        // Test Step - 1 : H-Line Decrease Test 
        case 1:
        {
            // H-Line Decrease
            tVDPTestFlag.mVDP_ScalOutputH -= tVDPTestFlag.mVDP_DebugTestOffset; 

            // Check H-Min Size
            if(tVDPTestFlag.mVDP_ScalOutputH < VDUMP_MIN_H_SIZE)
            {
                // H-Line Roll-Back
                tVDPTestFlag.mVDP_ScalOutputH = nInWidth;

                // V-Line Decrease
                tVDPTestFlag.mVDP_ScalOutputV -= tVDPTestFlag.mVDP_DebugTestOffset; 

                // Check V-Min Size
                if(tVDPTestFlag.mVDP_ScalOutputV < VDUMP_MIN_V_SIZE) 
                    tVDPTestFlag.mVDP_ScalOutputV = VDUMP_MIN_V_SIZE;

                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestScalStep++;
            }
        }
        break;


        // Test Step - 2 : V-Line Decrease Test
        case 2:
        {
            // V-Line Decrease
            tVDPTestFlag.mVDP_ScalOutputV -= tVDPTestFlag.mVDP_DebugTestOffset; 

            // Check V-Min Size
            if(tVDPTestFlag.mVDP_ScalOutputV < VDUMP_MIN_V_SIZE)
            {
                // V-Line Roll-Back
                tVDPTestFlag.mVDP_ScalOutputV = nInHeigth;

                // V/H Line Decrease
                tVDPTestFlag.mVDP_ScalOutputH -= tVDPTestFlag.mVDP_DebugTestOffset;
                tVDPTestFlag.mVDP_ScalOutputV -= tVDPTestFlag.mVDP_DebugTestOffset;
                
                // Check V/H-Min Size
                if(tVDPTestFlag.mVDP_ScalOutputH < VDUMP_MIN_H_SIZE) 
                    tVDPTestFlag.mVDP_ScalOutputH = VDUMP_MIN_H_SIZE;
                if(tVDPTestFlag.mVDP_ScalOutputV < VDUMP_MIN_V_SIZE) 
                    tVDPTestFlag.mVDP_ScalOutputV = VDUMP_MIN_V_SIZE;

                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestScalStep++;
            }
        }
        break;


        // Test Step - 3 : H/V-Line Decrease Test
        case 3:
        {
            // V/H Line Decrease
            tVDPTestFlag.mVDP_ScalOutputH -= tVDPTestFlag.mVDP_DebugTestOffset;
            tVDPTestFlag.mVDP_ScalOutputV -= tVDPTestFlag.mVDP_DebugTestOffset;
            
            // Check V-Min Size
            if(tVDPTestFlag.mVDP_ScalOutputV < VDUMP_MIN_V_SIZE) 
                tVDPTestFlag.mVDP_ScalOutputV = VDUMP_MIN_V_SIZE;
                
            // Check H-Min Size
            if(tVDPTestFlag.mVDP_ScalOutputH < VDUMP_MIN_H_SIZE)
            {
                // H-Line Min Set
                tVDPTestFlag.mVDP_ScalOutputH = VDUMP_MIN_H_SIZE;
                
                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestScalStep++;
            }
        }
        break;


        // Test Step - 4 : H-Line Increase Test 
        case 4:
        {
            // H-Line Increase
            tVDPTestFlag.mVDP_ScalOutputH += tVDPTestFlag.mVDP_DebugTestOffset; 

            // Check H-Min Size
            if(tVDPTestFlag.mVDP_ScalOutputH >= nInWidth)
            {
                // H-Line Roll-Back
                tVDPTestFlag.mVDP_ScalOutputH = VDUMP_MIN_H_SIZE;

                // V-Line Increase
                tVDPTestFlag.mVDP_ScalOutputV += tVDPTestFlag.mVDP_DebugTestOffset; 

                // Check V/H-Max Size
                if(tVDPTestFlag.mVDP_ScalOutputV >= nInHeigth) 
                    tVDPTestFlag.mVDP_ScalOutputV = (nInHeigth - tVDPTestFlag.mVDP_DebugTestOffset);

                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestScalStep++;
            }
        }
        break;


        // Test Step - 5 : V-Line Increase Test
        case 5:
        {
            // V-Line Increase
            tVDPTestFlag.mVDP_ScalOutputV += tVDPTestFlag.mVDP_DebugTestOffset; 

            // Check V-Max Size
            if(tVDPTestFlag.mVDP_ScalOutputV >= nInHeigth)
            {
                // V-Line Roll-Back
                tVDPTestFlag.mVDP_ScalOutputV = VDUMP_MIN_V_SIZE;
                
                // H/V-Line Increase
                tVDPTestFlag.mVDP_ScalOutputH += tVDPTestFlag.mVDP_DebugTestOffset;
                tVDPTestFlag.mVDP_ScalOutputV += tVDPTestFlag.mVDP_DebugTestOffset; 

                // Check V/H-Max Size
                if(tVDPTestFlag.mVDP_ScalOutputH >= nInWidth) 
                    tVDPTestFlag.mVDP_ScalOutputH = (nInWidth - tVDPTestFlag.mVDP_DebugTestOffset);
                if(tVDPTestFlag.mVDP_ScalOutputV >= nInHeigth) 
                    tVDPTestFlag.mVDP_ScalOutputV = (nInHeigth - tVDPTestFlag.mVDP_DebugTestOffset);

                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestScalStep++;
            }
        }
        break;


        // Test Step - 6 : H/V-Line Increase Test
        case 6:
        {
            // V/H Line Increase
            tVDPTestFlag.mVDP_ScalOutputH += tVDPTestFlag.mVDP_DebugTestOffset;
            tVDPTestFlag.mVDP_ScalOutputV += tVDPTestFlag.mVDP_DebugTestOffset;
            
            // Check V-Max Size
            if(tVDPTestFlag.mVDP_ScalOutputV >= nInHeigth) 
                tVDPTestFlag.mVDP_ScalOutputV = (nInHeigth - tVDPTestFlag.mVDP_DebugTestOffset);
                
            // Check H-Max Size
            if(tVDPTestFlag.mVDP_ScalOutputH >= nInWidth)
            {
                // H-Line Max Setting
                tVDPTestFlag.mVDP_ScalOutputH = (nInWidth - tVDPTestFlag.mVDP_DebugTestOffset);
                
                // Test End
                tVDPTestFlag.mVDP_ScalEn = DISABLE;
                tVDPTestFlag.mVDP_DebugTestScalStep = 0;
                ret = NC_FAILURE;
            }
        }
        break;
    }


    return ret;
}


static INT32 __test_vdump_debug_loop_next_crop_size(void)
{
    INT32 ret = NC_SUCCESS;
    
    UINT32 nInWidth;
    UINT32 nInHeigth;


    // Get Input Path Image Size
    ncLib_VDP_Control(GCMD_VDP_GET_INPUT_SIZE, &nInWidth, &nInHeigth,  CMD_END);


    switch(tVDPTestFlag.mVDP_DebugTestCropStep)
    {
        // Test Step - 0 : H/V-Line Decrease Test Start
        case 0:
        {
            // Test Start Postion Setting 
            tVDPTestFlag.mVDP_CropEn     = ENABLE;
            tVDPTestFlag.mVDP_CropStartH = 0;
            tVDPTestFlag.mVDP_CropEndH   = (nInWidth - tVDPTestFlag.mVDP_CropStartH);
            tVDPTestFlag.mVDP_CropStartV = 0;
            tVDPTestFlag.mVDP_CropEndV   = (nInHeigth - tVDPTestFlag.mVDP_CropStartV);

            // H-Line Decrease
            tVDPTestFlag.mVDP_CropEndH -= tVDPTestFlag.mVDP_DebugTestOffset;

            // Check H-Min Size
            if(tVDPTestFlag.mVDP_CropEndH < VDUMP_MIN_H_SIZE) 
                tVDPTestFlag.mVDP_CropEndH = VDUMP_MIN_H_SIZE;

            // Next Test Step
            tVDPTestFlag.mVDP_DebugTestCropStep++;
        }
        break;


        // Test Step - 1 : H-Line Decrease Test
        case 1:
        {
            // H-Line Decrease
            tVDPTestFlag.mVDP_CropEndH -= tVDPTestFlag.mVDP_DebugTestOffset; 

            // Check H-Min Size
            if(tVDPTestFlag.mVDP_CropEndH < VDUMP_MIN_H_SIZE)
            {
                // H-Line Roll-Back
                tVDPTestFlag.mVDP_CropEndH = (nInWidth - tVDPTestFlag.mVDP_CropStartH);

                // V-Line Decrease
                tVDPTestFlag.mVDP_CropEndV -= tVDPTestFlag.mVDP_DebugTestOffset;

                // Check V-Min Size
                if(tVDPTestFlag.mVDP_CropEndV < VDUMP_MIN_V_SIZE) 
                    tVDPTestFlag.mVDP_CropEndV = VDUMP_MIN_V_SIZE;

                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestCropStep++;
            }
        }
        break;


        // Test Step - 2 : V-Line Decrease Test
        case 2:
        {
            // V-Line Decrease
            tVDPTestFlag.mVDP_CropEndV -= tVDPTestFlag.mVDP_DebugTestOffset; 

            // Check V-Min Size
            if(tVDPTestFlag.mVDP_CropEndV < VDUMP_MIN_V_SIZE)
            {
                // V-Line Roll-Back
                tVDPTestFlag.mVDP_CropEndV = (nInHeigth - tVDPTestFlag.mVDP_CropStartV);

                // V/H Line Decrease
                tVDPTestFlag.mVDP_CropEndH -= tVDPTestFlag.mVDP_DebugTestOffset; 
                tVDPTestFlag.mVDP_CropEndV -= tVDPTestFlag.mVDP_DebugTestOffset;
                
                // Check V/H-Min Size
                if(tVDPTestFlag.mVDP_CropEndH < VDUMP_MIN_H_SIZE) 
                    tVDPTestFlag.mVDP_CropEndH = VDUMP_MIN_H_SIZE;
                if(tVDPTestFlag.mVDP_CropEndV < VDUMP_MIN_V_SIZE) 
                    tVDPTestFlag.mVDP_CropEndV = VDUMP_MIN_V_SIZE;

                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestCropStep++;
            }
        }
        break;


        // Test Step - 3 : H/V-Line Decrease Test
        case 3:
        {
            // V/H Line Decrease
            tVDPTestFlag.mVDP_CropEndH -= tVDPTestFlag.mVDP_DebugTestOffset; 
            tVDPTestFlag.mVDP_CropEndV -= tVDPTestFlag.mVDP_DebugTestOffset;

            // Check V-Min Size
            if(tVDPTestFlag.mVDP_CropEndV < VDUMP_MIN_V_SIZE) 
                tVDPTestFlag.mVDP_CropEndV = VDUMP_MIN_V_SIZE;
            
            // Check H-Min Size
            if(tVDPTestFlag.mVDP_CropEndH < VDUMP_MIN_H_SIZE)
            {
                // H-Line Min Set
                tVDPTestFlag.mVDP_CropEndH = VDUMP_MIN_H_SIZE;

                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestCropStep++;
            }
        }
        break;


        // Test Step - 4 : H-Line Increase Test
        case 4:
        {
            // H-Line Increase
            tVDPTestFlag.mVDP_CropEndH += tVDPTestFlag.mVDP_DebugTestOffset; 

            // Check H-Min Size
            if(tVDPTestFlag.mVDP_CropEndH >= nInWidth)
            {
                // H-Line Roll-Back
                tVDPTestFlag.mVDP_CropEndH = VDUMP_MIN_H_SIZE;

                // V-Line Increase
                tVDPTestFlag.mVDP_CropEndV += tVDPTestFlag.mVDP_DebugTestOffset;

                // Check V-Max Size
                if(tVDPTestFlag.mVDP_CropEndV >= nInHeigth) 
                    tVDPTestFlag.mVDP_CropEndV = (nInHeigth - tVDPTestFlag.mVDP_DebugTestOffset - tVDPTestFlag.mVDP_CropStartV);

                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestCropStep++;
            }
        }
        break;


        // Test Step - 5 : V-Line Increase Test
        case 5:
        {
            // V-Line Increase
            tVDPTestFlag.mVDP_CropEndV += tVDPTestFlag.mVDP_DebugTestOffset; 

            // Check V-Max Size
            if(tVDPTestFlag.mVDP_CropEndV >= nInHeigth)
            {
                // V-Line Roll-Back
                tVDPTestFlag.mVDP_CropEndV = VDUMP_MIN_V_SIZE;

                // H/V-Line Increase
                tVDPTestFlag.mVDP_CropEndH += tVDPTestFlag.mVDP_DebugTestOffset;
                tVDPTestFlag.mVDP_CropEndV += tVDPTestFlag.mVDP_DebugTestOffset;

                // Check V/H-Max Size
                if(tVDPTestFlag.mVDP_CropEndH >= nInWidth) 
                    tVDPTestFlag.mVDP_CropEndH = (nInWidth - tVDPTestFlag.mVDP_DebugTestOffset - tVDPTestFlag.mVDP_CropStartH);
                if(tVDPTestFlag.mVDP_CropEndV >= nInHeigth) 
                    tVDPTestFlag.mVDP_CropEndV = (nInHeigth - tVDPTestFlag.mVDP_DebugTestOffset - tVDPTestFlag.mVDP_CropStartV);

                // Next Test Step
                tVDPTestFlag.mVDP_DebugTestCropStep++;
            }
        }
        break;


        // Test Step - 6 : H/V-Line Increase Test
        case 6:
        {
            // V/H-Line Increase
            tVDPTestFlag.mVDP_CropEndH += tVDPTestFlag.mVDP_DebugTestOffset;
            tVDPTestFlag.mVDP_CropEndV += tVDPTestFlag.mVDP_DebugTestOffset;

            // Check V-Max Size
            if(tVDPTestFlag.mVDP_CropEndV >= nInHeigth) 
                tVDPTestFlag.mVDP_CropEndV = (nInHeigth - tVDPTestFlag.mVDP_DebugTestOffset - tVDPTestFlag.mVDP_CropStartV);
            
            // Check H-Max Size
            if(tVDPTestFlag.mVDP_CropEndH >= nInWidth)
            {
                // H-Line Max Setting
                tVDPTestFlag.mVDP_CropEndH = (nInWidth - tVDPTestFlag.mVDP_DebugTestOffset - tVDPTestFlag.mVDP_CropStartH);
                
                // Test End
                tVDPTestFlag.mVDP_CropEn = DISABLE;
                tVDPTestFlag.mVDP_DebugTestCropStep = 0;
                ret = NC_FAILURE;
            }
        }
        break;
    }


    return ret;
}


static INT32 __test_vdump_debug_loop_next_ch_operation(void)
{
    INT32 ret = NC_SUCCESS;
    eVDP_CH Ch;
    //static UINT8 sTestParsingIdx = VDP_P_YCBCR_RGB;


    switch(tVDPTestFlag.mVDP_DebugTestChOpStep)
    {
        //------------------------------------------------------8Bit-------------------------------------------------------
        case 0 : 
        {
            for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++) 
            {
                tVDPTestFlag.mVDP_Bit[Ch]     = VDP_BIT_8; 
                tVDPTestFlag.mVDP_Burst[Ch]   = VDP_BURST_4;
                tVDPTestFlag.mVDP_Parsing[Ch] = VDP_P_CRCBY_BGR;
            }
            tVDPTestFlag.mVDP_DebugTestChOpStep++;
 
        }
        break;
        case 1 : for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++) tVDPTestFlag.mVDP_Burst[Ch] = VDP_BURST_8;  tVDPTestFlag.mVDP_DebugTestChOpStep++; break;
        case 2 : for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++) tVDPTestFlag.mVDP_Burst[Ch] = VDP_BURST_16; tVDPTestFlag.mVDP_DebugTestChOpStep++; break;
        case 3 : for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++) tVDPTestFlag.mVDP_Burst[Ch] = VDP_BURST_32; tVDPTestFlag.mVDP_DebugTestChOpStep++; break;


        //-----------------------------------------------------16Bit-------------------------------------------------------
        case 4 : 
        {
            for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++) 
            {
                tVDPTestFlag.mVDP_Bit[Ch]   = VDP_BIT_16; 
                tVDPTestFlag.mVDP_Burst[Ch] = VDP_BURST_8;
            }
            tVDPTestFlag.mVDP_DebugTestChOpStep++;
        }
        break;
        case 5 : for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++) tVDPTestFlag.mVDP_Burst[Ch] = VDP_BURST_16; tVDPTestFlag.mVDP_DebugTestChOpStep++; break;
        case 6 : for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++) tVDPTestFlag.mVDP_Burst[Ch] = VDP_BURST_32; tVDPTestFlag.mVDP_DebugTestChOpStep++; break;

        
        //-----------------------------------------------------32Bit-------------------------------------------------------
        case 7 : 
        {
            for(Ch=VDP_CH0; Ch<VDP_CH2; Ch++) 
            {
                tVDPTestFlag.mVDP_Bit[Ch]   = VDP_BIT_32; 
                tVDPTestFlag.mVDP_Burst[Ch] = VDP_BURST_8;
            }
            tVDPTestFlag.mVDP_DebugTestChOpStep++;
        }
        break;
        case 8 : for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++) tVDPTestFlag.mVDP_Burst[Ch] = VDP_BURST_16; tVDPTestFlag.mVDP_DebugTestChOpStep++; break;
        case 9 : for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++) tVDPTestFlag.mVDP_Burst[Ch] = VDP_BURST_32; tVDPTestFlag.mVDP_DebugTestChOpStep++; break;


        //-----------------------------------------------------End---------------------------------------------------------
        case 10: 
        {
            tVDPTestFlag.mVDP_DebugTestChOpStep = 0; 

            //if(++sTestParsingIdx >= MAX_OF_VDP_PARSING)   
            {
                // Test End
                //sTestParsingIdx = VDP_P_YCBCR_RGB;
                ret = NC_FAILURE; 
            }
        }
        break;
    }


    return ret;
}


static INT32 __test_vdump_debug_loop_next_operation(void)
{
    INT32 ret = NC_SUCCESS;
    //static BOOL sTestIntEn = 0;


    if(tVDPTestFlag.mVDP_DebugTestCtrlEn == OFF)
        return NC_FAILURE;


    // Channel Opeartion Change
    if(__test_vdump_debug_loop_next_ch_operation() == NC_FAILURE) 
        tVDPTestFlag.mVDP_DebugTestCtrlStep++; 


    switch(tVDPTestFlag.mVDP_DebugTestCtrlStep)
    {
        ///------------------------------RGB-----------------------------------
        case 0 : 
        {
            tVDPTestFlag.mVDP_InFormat  = VDP_I_RGB_FORMAT;
            tVDPTestFlag.mVDP_FrameType = VDP_FRAME_VIEWING_FRAME;
            tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_START;
            tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
        }
        break;
        case 1 : tVDPTestFlag.mVDP_InputPath = VDP_I_LDC_OUT_PATH;          break;
        case 2 : tVDPTestFlag.mVDP_InputPath = VDP_I_OPD_OUT_PATH;          break;    
        case 3 : tVDPTestFlag.mVDP_InputPath = VDP_I_OVERLAY_OUT_PATH;      break;  

        case 4 : 
        {
            tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_END;
            tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
        }
        break;
        case 5 : tVDPTestFlag.mVDP_InputPath = VDP_I_LDC_OUT_PATH;          break;
        case 6 : tVDPTestFlag.mVDP_InputPath = VDP_I_OPD_OUT_PATH;          break;    

        case 7 : 
        {
            tVDPTestFlag.mVDP_FrameType = VDP_FRAME_SENSING_FRAME;
            tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_START;
            tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
        }
        break;
        case 8 : tVDPTestFlag.mVDP_InputPath = VDP_I_LDC_OUT_PATH;          break;
        case 9 : tVDPTestFlag.mVDP_InputPath = VDP_I_OPD_OUT_PATH;          break;    

        case 10: 
        {
            tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_END;
            tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
        }
        break;
        case 11: tVDPTestFlag.mVDP_InputPath = VDP_I_LDC_OUT_PATH;          break;
        case 12: tVDPTestFlag.mVDP_InputPath = VDP_I_OPD_OUT_PATH;          break;    


        //------------------------------YUV422---------------------------------
        case 13: 
        {
            tVDPTestFlag.mVDP_InFormat  = VDP_I_YUV_FORMAT;
            tVDPTestFlag.mVDP_YUVSelect = VDP_YUV422;
            tVDPTestFlag.mVDP_FrameType = VDP_FRAME_VIEWING_FRAME;
            tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_START;
            tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
        }
        break;
        case 14: tVDPTestFlag.mVDP_InputPath = VDP_I_LDC_OUT_PATH;          break;
        case 15: tVDPTestFlag.mVDP_InputPath = VDP_I_OPD_OUT_PATH;          break;     

        case 16: 
        {
            tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_END;
            tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
        }
        break;
        case 17: tVDPTestFlag.mVDP_InputPath = VDP_I_LDC_OUT_PATH;          break;
        case 18: tVDPTestFlag.mVDP_InputPath = VDP_I_OPD_OUT_PATH;          break;      

        case 19: 
        {
            tVDPTestFlag.mVDP_FrameType = VDP_FRAME_SENSING_FRAME;
            tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_START;
            tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
            
        }
        break;
        case 20: tVDPTestFlag.mVDP_InputPath = VDP_I_LDC_OUT_PATH;          break;
        case 21: tVDPTestFlag.mVDP_InputPath = VDP_I_OPD_OUT_PATH;          break;    

        case 22: 
        {
            tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_END;
            tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
        }
        break;
        case 23: tVDPTestFlag.mVDP_InputPath = VDP_I_LDC_OUT_PATH;          break;
        case 24: tVDPTestFlag.mVDP_InputPath = VDP_I_OPD_OUT_PATH;          break;    


        //------------------------------YUV444---------------------------------
        case 25: 
        {
            tVDPTestFlag.mVDP_YUVSelect = VDP_YUV444; 
            tVDPTestFlag.mVDP_FrameType = VDP_FRAME_VIEWING_FRAME;
            tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_START;
            tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
        }
        break;
        case 26: tVDPTestFlag.mVDP_InputPath = VDP_I_LDC_OUT_PATH;          break;
        case 27: tVDPTestFlag.mVDP_InputPath = VDP_I_OPD_OUT_PATH;          break;    

        case 28: 
        {
            tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_END;
            tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
        }
        break;
        case 29: tVDPTestFlag.mVDP_InputPath = VDP_I_LDC_OUT_PATH;          break;
        case 30: tVDPTestFlag.mVDP_InputPath = VDP_I_OPD_OUT_PATH;          break;    

        case 31: 
        {
            tVDPTestFlag.mVDP_FrameType = VDP_FRAME_SENSING_FRAME;
            tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_START;
            tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
        }
        break;
        case 32: tVDPTestFlag.mVDP_InputPath = VDP_I_LDC_OUT_PATH;          break;
        case 33: tVDPTestFlag.mVDP_InputPath = VDP_I_OPD_OUT_PATH;          break;    

        case 34: 
        {
            tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_END;
            tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
        }
        break;
        case 35: tVDPTestFlag.mVDP_InputPath = VDP_I_LDC_OUT_PATH;          break;
        case 36: tVDPTestFlag.mVDP_InputPath = VDP_I_OPD_OUT_PATH;          break;    


        //------------------------------END-----------------------------------
        case 37: 
        {
            // Next Step '0'
            tVDPTestFlag.mVDP_DebugTestCtrlStep = 0; 

            // Interrupt On->Off, Off->On 
            _REVERSE(tVDPTestFlag.mVDP_IsrEn); 

            // Test End
            //if(sTestIntEn == 1)
            {
                tVDPTestFlag.mVDP_YUVSelect = VDP_YUV444; 
                tVDPTestFlag.mVDP_FrameType = VDP_FRAME_VIEWING_FRAME;
                tVDPTestFlag.mVDP_FrameEdge = VDP_SEL_FRAME_START;
                tVDPTestFlag.mVDP_InputPath = VDP_I_YC_CROP_OUT_PATH;
                
                ret = NC_FAILURE; 
            }
            
            //_REVERSE(sTestIntEn);
        }
       break;        
    }


    return ret;
}


static void __test_vdump_debug_buff_clear(void)
{
    eVDP_CH Ch;
    UINT32  nLength;
    UINT32  nOutWidth;
    UINT32  nOutHeigth;
    INT32   nDumpSize;
    
    ncLib_VDP_Control(GCMD_VDP_GET_OUTPUT_SIZE, &nOutWidth, &nOutHeigth, CMD_END);

    if(tVDPTestFlag.mVDP_DebugMsgOn == ON)
        DEBUGMSG(MSGINFO, " > Video Dump Buff Clear\n");
    
    for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++)
    {
        if(tVDPTestFlag.mVDP_ChEn[Ch] == ENABLE)
        {
            nLength    = (nOutHeigth * ((nOutWidth*(1<<tVDPTestFlag.mVDP_Bit[Ch])))/4)*4;
            nDumpSize  = ncLib_VDP_Control(GCMD_VDP_GET_DUMP_SIZE, Ch, CMD_END);
            
            if(tVDPTestFlag.mVDP_DebugMsgOn == ON)
            {
                DEBUGMSG(MSGINFO, "   -. %dx%d SA:%08X EA:%08X S:%06X(%06X)\n"
                                                                        ,nOutWidth
                                                                        ,nOutHeigth
                                                                        ,tVDPTestFlag.mVDP_DMAAddr[Ch]
                                                                        ,tVDPTestFlag.mVDP_DMAAddr[Ch]+nDumpSize
                                                                        ,nDumpSize
                                                                        ,nLength);
            }

            APACHE_TEST_MemSet((void*)(tVDPTestFlag.mVDP_DMAAddr[Ch]), 0x00, nDumpSize);

        }
    }
}


static void __test_vdump_debug_file_dump(void)
{
#ifdef __TEST_VDUMP_SEMIHOSTING_ENABLE__
    FILE  *OutFile = NULL;
#endif
    char  FileName[256];

    eVDP_CH Ch;
    UINT32 nFileIdx_1;
    UINT32 nFileIdx_2;
    INT32  nOutWidth;
    INT32  nOutHeigth;
    INT32  nLength;

    DEBUGMSG(MSGINFO, "\n > Video Dump Fiie Write Start\n"); 
    
    ncLib_VDP_Control(GCMD_VDP_GET_OUTPUT_SIZE, &nOutWidth, &nOutHeigth, CMD_END);

    nFileIdx_1 = (TEST_APP_BUILD_YEAR*10000)  + (TEST_APP_BUILD_MONTH*100)   + TEST_APP_BUILD_DAY;
    nFileIdx_2 = (TEST_APP_BUILD_HOURS*10000) + (TEST_APP_BUILD_MINUTES*100) + TEST_APP_BUILD_SECONDS + tVDPTestFlag.mVDP_DebugFileCnt++;


    for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++)
    {
        if(tVDPTestFlag.mVDP_ChEn[Ch] == ENABLE)
        {
            // Channel Video Dump Size
            nLength  = ncLib_VDP_Control(GCMD_VDP_GET_DUMP_SIZE, Ch, CMD_END);

            // File Name Create
            sprintf(FileName, "H:\\VDUMP\\%08d_%06d_CH%d_%02dBit_Crop%s_Scal%s_%dx%d_%s.bin" 
                                                                                ,nFileIdx_1
                                                                                ,nFileIdx_2
                                                                                ,Ch
                                                                                ,cBit[tVDPTestFlag.mVDP_Bit[Ch]]
                                                                                ,(tVDPTestFlag.mVDP_CropEn)?"O":"X"
                                                                                ,(tVDPTestFlag.mVDP_ScalEn)?"O":"X"
                                                                                ,nOutWidth
                                                                                ,nOutHeigth
                                                                                ,cParsing[tVDPTestFlag.mVDP_InFormat][tVDPTestFlag.mVDP_Bit[Ch]][tVDPTestFlag.mVDP_Parsing[Ch]]
                                                                                );


            DEBUGMSG(MSGINFO, "   -. %s", FileName);
            APACHE_TEST_StopWatch(ON);

#ifdef __TEST_VDUMP_SEMIHOSTING_ENABLE__
            // File Open
            OutFile = fopen(FileName, "wb");
            if(OutFile == NULL)
            {
                DEBUGMSG(MSGINFO, "(Fail)");
            }
            else
            {   
                // File Write
                fwrite((void*)(tVDPTestFlag.mVDP_DMAAddr[Ch]), nLength, 1, OutFile);
                fclose(OutFile);

                DEBUGMSG(MSGINFO, "(Ok)");
            }
#endif
            APACHE_TEST_StopWatch(OFF);
            DEBUGMSG(MSGINFO, "(%d-KB)\n" , (nLength/KB));
        }
    }
}


static void __test_vdump_debug_set_operation(ptVDP_PARAM ptVDPParam)
{
    eVDP_CH Ch; 

    
    // Set Crop Operation
    ptVDPParam->mCropEn     = tVDPTestFlag.mVDP_CropEn;
    ptVDPParam->mCropStartH = tVDPTestFlag.mVDP_CropStartH;
    ptVDPParam->mCropEndH   = tVDPTestFlag.mVDP_CropEndH;
    ptVDPParam->mCropStartV = tVDPTestFlag.mVDP_CropStartV;
    ptVDPParam->mCropEndV   = tVDPTestFlag.mVDP_CropEndV;


    // Set Scaler Operation
    ptVDPParam->mScalEn      = tVDPTestFlag.mVDP_ScalEn;
    ptVDPParam->mScalOutputH = tVDPTestFlag.mVDP_ScalOutputH;
    ptVDPParam->mScalOutputV = tVDPTestFlag.mVDP_ScalOutputV;


    // Set Ctrl Operation
    ptVDPParam->mIntEn     = tVDPTestFlag.mVDP_IsrEn;
    ptVDPParam->mFrameEdge = (eVDP_UPDATA_SEL)  tVDPTestFlag.mVDP_FrameEdge;
    ptVDPParam->mInputPath = (eVDP_INPUT_PATH)  tVDPTestFlag.mVDP_InputPath;
    ptVDPParam->mInFormat  = (eVDP_INPUT_FORMAT)tVDPTestFlag.mVDP_InFormat; 
    ptVDPParam->mYUVSelect = (eVDP_YUV_FORMAT)  tVDPTestFlag.mVDP_YUVSelect;
    ptVDPParam->mFrameType = (eVDP_FRAME_MODE)  tVDPTestFlag.mVDP_FrameType;
    __test_vdump_debug_change_frametype(tVDPTestFlag.mVDP_FrameType);

    // Set Channel Operation 
    for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++)
    {
        ptVDPParam->mDumpCh[Ch].mChEnable = tVDPTestFlag.mVDP_ChEn[Ch];
        ptVDPParam->mDumpCh[Ch].mEndian   = (eVDP_ENDIAN)tVDPTestFlag.mVDP_Endian[Ch];
        ptVDPParam->mDumpCh[Ch].mParsing  = (eVDP_PARSING)tVDPTestFlag.mVDP_Parsing[Ch];
        ptVDPParam->mDumpCh[Ch].mBit      = (eVDP_DATA_BIT)tVDPTestFlag.mVDP_Bit[Ch];
        ptVDPParam->mDumpCh[Ch].mBurst    = (eVDP_WRITE_BURST)tVDPTestFlag.mVDP_Burst[Ch];
        ptVDPParam->mDumpCh[Ch].mDumpAddr = tVDPTestFlag.mVDP_DMAAddr[Ch];
    } 
}


static void __test_vdump_debug_init(ptVDP_PARAM ptVDPParam)
{
    eVDP_CH Ch;    
    UINT32  nInWidth;
    UINT32  nInHeigth;
    UINT32  Port;


    // Debug v-dump run information
    ncLib_VDP_Control(GCMD_VDP_GET_INPUT_SIZE,  &nInWidth,  &nInHeigth,  CMD_END);

    DEBUGMSG(MSGINFO, "\033[1K\r > %s(%s) %s:%d F:%d I:%04dx%04d ", (ptVDPParam->mInFormat)?"RGB...":(ptVDPParam->mYUVSelect)?"YUV422":"YUV444"
                                                                  , (ptVDPParam->mIntEn)?"E":"D"
                                                                  , (ptVDPParam->mFrameType)?"V":"S"
                                                                  , ptVDPParam->mInputPath
                                                                  , ptVDPParam->mFrameEdge
                                                                  , nInWidth, nInHeigth);
    if(ptVDPParam->mCropEn == ENABLE)
        DEBUGMSG(MSGINFO, "-> C:%04dx%04d ", (ptVDPParam->mCropEndH - ptVDPParam->mCropStartH), (ptVDPParam->mCropEndV - ptVDPParam->mCropStartV));
    if(ptVDPParam->mScalEn == ENABLE)
        DEBUGMSG(MSGINFO, "-> S:%04dx%04d ", ptVDPParam->mScalOutputH, ptVDPParam->mScalOutputV);
    for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++)
    {
        if(ptVDPParam->mDumpCh[Ch].mChEnable == ENABLE)
            DEBUGMSG(MSGINFO, "(%d.%d.%02db.%02dB) " , Ch, ptVDPParam->mDumpCh[Ch].mParsing, cBit[ptVDPParam->mDumpCh[Ch].mBit], cBurstMode[ptVDPParam->mDumpCh[Ch].mBurst]);
    }
    DEBUGMSG(MSGINFO, "%03d", tVDPTestFlag.mVDP_DebugTestOffset);
    if(tVDPTestFlag.mVDP_DebugMsgOn == ON)
        DEBUGMSG(MSGINFO, "\n");


    // Debug buff clear
    if(tVDPTestFlag.mVDP_DebugBuffCls == ON)
        __test_vdump_debug_buff_clear();
    

    // Debug Variable init
    tVDPTestFlag.mVDP_DebugIntSts = 0; 


    // Debug GPIO Init
    for(Port = DBG_GPIO_PORT0; Port<DBG_MAX_OF_GPIO_PORT; Port++)
        APACHE_TEST_DebugGPIOSet(Port, GPIO_LOW);
}


void APACHE_TEST_VDUMP_Isr(UINT32 irq)
{
    INT32 Sts;

    // ISR Status Clear (Return : Current Status)
    Sts = ncLib_VDP_Control(GCMD_VDP_INT_CLEAR, CMD_END); 

    if(Sts != NC_FAILURE)
    {     
        /*
         *----------------------------------------------------------------------------
         *
         *               V-Dump Start Command
         * 
         *                |<--------------->|
         *
         *      v-end _ v-start           v-end _ v-start           v-end _ v-start    
         *           | |                       | |                       | |       
         * __________| |_______________________| |_______________________| |__________
         * 
         *----------------------------------------------------------------------------
         * if EDGE Type
         *                          v-dump start(o)                      v-dump end(o)
         *                                         _____________________
         *                                        |                     |
         * _______________________________________|                     |_____________
         *
         *----------------------------------------------------------------------------
         * if Level Type
         * 
         *                          v-dump start(x)                      v-dump end(o)
         *                                                               _____________
         *                                                              |
         * _____________________________________________________________|
         *
         */


        // input frame V-Sync
        if((Sts&VDP_STS_I_VSYNC_START) || (Sts&VDP_STS_I_VSYNC_END))  APACHE_TEST_DebugGPIOToggle(DBG_GPIO_PORT0);

        // v-dump channel-0 intc
        if((Sts&VDP_STS_CH0_START)     || (Sts&VDP_STS_CH0_END))      APACHE_TEST_DebugGPIOToggle(DBG_GPIO_PORT1);

        // v-dump channel-1 intc
        if((Sts&VDP_STS_CH1_START)     || (Sts&VDP_STS_CH1_END))      APACHE_TEST_DebugGPIOToggle(DBG_GPIO_PORT2);

        // v-dump channel-2 intc
        if((Sts&VDP_STS_CH2_START)     || (Sts&VDP_STS_CH2_END))      APACHE_TEST_DebugGPIOToggle(DBG_GPIO_PORT3);


        // For Debug
        tVDPTestFlag.mVDP_DebugIntSts |= Sts;
    }
}


void APACHE_TEST_VDUMP_Init(ptVDP_PARAM ptVDPParam)
{
    INT32 ret;    
    

    // Open V-Dump 
    ncLib_VDP_Open();


    // Set Ctrl Operation 
    __test_vdump_debug_set_operation(ptVDPParam);


    // Register V-Dump Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_REGISTER_INT
                      ,IRQ_NUM_VDUMP
                      ,(PrHandler)APACHE_TEST_VDUMP_Isr
                      ,CMD_END);


    // Init V-Dump
    ret = ncLib_VDP_Control(GCMD_VDP_INIT, ptVDPParam, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "V-Dump Init Error!\n");
        return;
    }
}


void APACHE_TEST_VDUMP_DeInit(void)
{
    INT32 ret;


    // Unregister V-Dump Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT
                      ,IRQ_NUM_VDUMP
                      ,CMD_END);



    // DeInit V-Dump Channel
    ret = ncLib_VDP_Control(GCMD_VDP_DEINIT, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "V-Dump DeInit Error!\n");
        return;
    }

    
    // Close V-Dump
    ret = ncLib_VDP_Close();    
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "V-Dump Close Error!\n");
        return;
    }
}


INT32 APACHE_TEST_VDUMP_Result(ptVDP_PARAM ptVDPParam, INT32 Status)
{
    INT32 ret = NC_SUCCESS;    
    eVDP_CH Ch;

    // Input Size
    UINT32  nInWidth;
    UINT32  nInHeigth;

    // Output Size
    UINT32  nOutWidth;
    UINT32  nOutHeigth;

    // Dump Size
    INT32   nDumpSize;

    // Error Status
    INT32   nError;

    // Debug Crop Pixel Cnt
    UINT32  nCropCntV;
    UINT32  nCropCntP;

    // Debug Scaler Pixel Cnt
    UINT32  nScalCntV;
    UINT32  nScalCntP;    

    // Debug Frm Status
    INT32   nOneFrmStt;

    // Debug Output Pixel Cnt
    INT32   nLineCnt;
    INT32   nPixelCnt;


    // Check in/out Size
    ncLib_VDP_Control(GCMD_VDP_GET_INPUT_SIZE,  &nInWidth,  &nInHeigth,  CMD_END);
    ncLib_VDP_Control(GCMD_VDP_GET_OUTPUT_SIZE, &nOutWidth, &nOutHeigth, CMD_END);
    ncLib_VDP_Control(GCMD_VDP_GET_CROP_CNT,    &nCropCntV, &nCropCntP,  CMD_END);
    ncLib_VDP_Control(GCMD_VDP_GET_SCAL_CNT,    &nScalCntV, &nScalCntP,  CMD_END);


    // Error Case - Debug Msg On
    if((tVDPTestFlag.mVDP_DebugIntSts&VDP_STS_ERR_ALL) || (Status&VDP_STS_ERR_ALL))
        tVDPTestFlag.mVDP_DebugMsgOn = ON;


    // V-Dump Information Display
    if(tVDPTestFlag.mVDP_DebugMsgOn == ON)
    {
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, " > Video Dump Result Infomation (0x%08X, 0x%08X)\n", tVDPTestFlag.mVDP_DebugIntSts, Status);
        DEBUGMSG(MSGINFO, "   -. IN:%dx%d ", nInWidth, nInHeigth);
        if(ptVDPParam->mCropEn == ENABLE)
            DEBUGMSG(MSGINFO, "-> CROP:%dx%d ", (nCropCntP/nCropCntV), nCropCntV);
        if(ptVDPParam->mScalEn == ENABLE)
            DEBUGMSG(MSGINFO, "-> SCAL:%dx%d ", (nScalCntP/nScalCntV), nScalCntV);
        DEBUGMSG(MSGINFO, "-> OUT:%dx%d\n", nOutWidth, nOutHeigth);
    }
    

    // Channel Status Check. 
    for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++)
    {
        if(ptVDPParam->mDumpCh[Ch].mChEnable == ENABLE)
        {
            nDumpSize  = ncLib_VDP_Control(GCMD_VDP_GET_DUMP_SIZE, Ch, CMD_END);
            nLineCnt   = ncLib_VDP_Control(GCMD_VDP_GET_LINE_CNT,  Ch, CMD_END);
            nPixelCnt  = ncLib_VDP_Control(GCMD_VDP_GET_PIXEL_CNT, Ch, CMD_END);
            nOneFrmStt = ncLib_VDP_Control(GCMD_VDP_GET_FRM_STS,   Ch, CMD_END);
            nError     = ncLib_VDP_Control(GCMD_VDP_CHK_ERROR,     Ch, CMD_END);

            if(tVDPTestFlag.mVDP_DebugMsgOn == ON)
            {
                DEBUGMSG(MSGINFO, "   -. [Ch_%d] A:%08X S:%06X P:%d L:%d F:%d E:%d", 
                                   Ch, ptVDPParam->mDumpCh[Ch].mDumpAddr, nDumpSize, 
                                   nPixelCnt/nLineCnt, nLineCnt, nOneFrmStt, nError);
            }

            if((nPixelCnt/nLineCnt) != nOutWidth)   nError |= VDP_ERR_H_OUT_ERROR;   
            if(nLineCnt != nOutHeigth)              nError |= VDP_ERR_V_OUT_ERROR;   
            
            if(nError)
            {
                DEBUGMSG(MSGERR, " - Fail(");
                if(nError & VDP_ERR_DMA_BUFF_OVER)
                    DEBUGMSG(MSGERR, "OVER:");
                if(nError & VDP_ERR_DUMP_TIME_OVER)
                    DEBUGMSG(MSGERR, "TIME:");
                if(nError & VDP_ERR_H_OUT_ERROR)
                    DEBUGMSG(MSGERR, "H-Size:");
                if(nError & VDP_ERR_V_OUT_ERROR)
                    DEBUGMSG(MSGERR, "V-Size");
                DEBUGMSG(MSGERR, ")\n");
                
                ret = NC_FAILURE;
            }
            else
            {
                if(tVDPTestFlag.mVDP_DebugMsgOn == ON)
                    DEBUGMSG(MSGINFO, " - OK\n");
            }
        }
    }


    // Crop Size Error 
    if((ptVDPParam->mCropEn == ENABLE) && 
        (((ptVDPParam->mCropEndH - ptVDPParam->mCropStartH) != (nCropCntP/nCropCntV))
        || ((ptVDPParam->mCropEndV - ptVDPParam->mCropStartV) != nCropCntV)))
    {
        DEBUGMSG(MSGERR, "   -. Crop Size Error : %dx%d vs %dx%d\n", (nCropCntP/nCropCntV), nCropCntV, (ptVDPParam->mCropEndH - ptVDPParam->mCropStartH), (ptVDPParam->mCropEndV - ptVDPParam->mCropStartV));
        ret = NC_FAILURE;
    }

    // Scaler Size Error
    if((ptVDPParam->mScalEn == ENABLE) && 
      ((ptVDPParam->mScalOutputH != (nScalCntP/nScalCntV)) || (ptVDPParam->mScalOutputV != nScalCntV)))
    {
        DEBUGMSG(MSGERR, "   -. Scal Size Error : %dx%d vs %dx%d\n", (nScalCntP/nScalCntV), nScalCntV, ptVDPParam->mScalOutputH, ptVDPParam->mScalOutputV);
        ret = NC_FAILURE;
    }
    

    // Debug File Dump
    if(tVDPTestFlag.mVDP_DebugFileWrite == ON)
        __test_vdump_debug_file_dump();

    return ret;
}


INT32 APACHE_TEST_VDUMP_Start(ptVDP_PARAM ptVDPParam)
{
    INT32 ret = NC_SUCCESS;
    INT32 Sts;

 
    // Debug - Only Test
    __test_vdump_debug_init(ptVDPParam);


    // Debug run-time check : start
    if(tVDPTestFlag.mVDP_DebugMsgOn == ON)
        DEBUGMSG(MSGINFO, " > Video Dump Start \n");
    APACHE_TEST_StopWatch(ON);


    // Start V-Dump
    ret = ncLib_VDP_Control(GCMD_VDP_START, CMD_END);
    if(ret == NC_SUCCESS)
    {
        // V-Dump Done Wait
        while((Sts = ncLib_VDP_Control(GCMD_VDP_DONE, CMD_END)) == NC_FAILURE)
        {
            // Time-out 
            if(APACHE_TEST_mTimeOut(tVDPTestFlag.mVDP_DebugTimeOut))
            {
                if(tVDPTestFlag.mVDP_DebugMsgOn == OFF)
                    DEBUGMSG(MSGERR, "\n");
                DEBUGMSG(MSGERR, "   -. TimeOut\n");

                // Check Last Status
                Sts = ncLib_VDP_Control(GCMD_VDP_GET_STS, CMD_END); 

                // Error Case - Debug Msg On
                tVDPTestFlag.mVDP_DebugMsgOn = ON;
     
                ret = NC_FAILURE;
                break;
            }
        }
        APACHE_TEST_mTimeOut(0);
    }
    else
    {
        DEBUGMSG(MSGERR, "   -. Start Error!\n"); 
    }


    // Debug run-time check : End
    if(tVDPTestFlag.mVDP_DebugMsgOn == ON)
    {
        DEBUGMSG(MSGINFO, "   -. Run Time");
        APACHE_TEST_StopWatch(OFF);
    }


    // Debug Result Display
    ret |= APACHE_TEST_VDUMP_Result(ptVDPParam, Sts);


    // Stop V-Dump
    ncLib_VDP_Control(GCMD_VDP_STOP, CMD_END);


    if(tVDPTestFlag.mVDP_DebugMsgOn == ON)
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");

    
    return ret;
}


void APACHE_TEST_VDUMP_UpdateOp(ptVDP_PARAM ptVDPParam)
{
    UINT32  Port;

    // Debug GPIO Init
    for(Port = DBG_GPIO_PORT0; Port<DBG_MAX_OF_GPIO_PORT; Port++)
        APACHE_TEST_DebugGPIOSet(Port, GPIO_LOW);


    // Update Operation 
    __test_vdump_debug_set_operation(ptVDPParam);
    ncLib_VDP_Control(GCMD_VDP_UPDATE_OP, ptVDPParam, CMD_END); 
}


INT32 APACHE_TEST_VDUMP_Loop_Crop_Scaler(void) 
{
    INT32 ret = NC_SUCCESS;
    tVDP_PARAM tVDPParam;
    UINT32  TestOffset_org;


    DEBUGMSG(MSGINFO, "\n============================================================\n");
    DEBUGMSG(MSGINFO, " > Loop Test : Change %s Crop + Scaler\n", (tVDPTestFlag.mVDP_DebugTestCtrlEn)?"Operattion +":"x");
    DEBUGMSG(MSGINFO, "   -. Test Exit Command : 'Q' or 'q'\n");


    
    // Back Up
    TestOffset_org = tVDPTestFlag.mVDP_DebugTestOffset;


    // Init V-Dump 
    APACHE_TEST_VDUMP_Init(&tVDPParam);


    // Long Time ~~~
    while(tVDPTestFlag.mVDP_DebugTestOffset)
    {
        // First Set Test Value
        __test_vdump_debug_loop_next_operation();
        __test_vdump_debug_loop_next_crop_scaler_size();
        APACHE_TEST_VDUMP_UpdateOp(&tVDPParam);


        while(1)
        {
            // Run V-Dump
            ret = APACHE_TEST_VDUMP_Start(&tVDPParam);
            if(ret == NC_FAILURE)
            {
                // Error Case : File Dump
                __test_vdump_debug_file_dump();
                break;
            }


            // Input Key Exit ('Q' or 'q')
            if(APACHE_TEST_ExitKey())
            {
                // User Test Stop
                ret = NC_FAILURE;
                break;
            }


            // Get Test Operation
            ret = __test_vdump_debug_loop_next_operation();
            if(ret == NC_FAILURE)
            {
                // Get Test Crop and Scal Size
                ret = __test_vdump_debug_loop_next_crop_scaler_size();
                if(ret == NC_FAILURE)
                {
                    // Operation Change End
                    ret = NC_SUCCESS;
                    break;
                }
            }


            // Update Operation Mode
            APACHE_TEST_VDUMP_UpdateOp(&tVDPParam);


            // Change Input Test Pattern
            __test_vdump_debug_loop_next_pattern();
        }
        DEBUGMSG(MSGINFO, "\n"); 

        // Test End
        if(ret == NC_FAILURE)
            break;


        // Test Decrease Size Change
        #if 1
            // stop
            ret = NC_SUCCESS;
            break;
        #else
            tVDPTestFlag.mVDP_DebugTestOffset = (tVDPTestFlag.mVDP_DebugTestOffset>>1); // offset x (1/2)
        #endif
    }


    // DeInit V-Dump 
    APACHE_TEST_VDUMP_DeInit();


    // Roll-Back
    tVDPTestFlag.mVDP_DebugTestOffset = TestOffset_org;


    return ret;
}


INT32 APACHE_TEST_VDUMP_Loop_Scaler(void)
{
    INT32 ret = NC_SUCCESS;
    tVDP_PARAM tVDPParam;
    UINT32  TestOffset_org;


    DEBUGMSG(MSGINFO, "\n============================================================\n");
    DEBUGMSG(MSGINFO, " > Loop Test : Change %s Scaler\n", (tVDPTestFlag.mVDP_DebugTestCtrlEn)?"Operattion +":"x");
    DEBUGMSG(MSGINFO, "   -. Test Exit Command : 'Q' or 'q'\n");


    // Back Up
    TestOffset_org = tVDPTestFlag.mVDP_DebugTestOffset;


    // Init V-Dump 
    APACHE_TEST_VDUMP_Init(&tVDPParam);


    // Long Time ~~~
    while(tVDPTestFlag.mVDP_DebugTestOffset)
    {
        // First Set Test Value
        __test_vdump_debug_loop_next_operation();
        __test_vdump_debug_loop_next_scaler_size();
        APACHE_TEST_VDUMP_UpdateOp(&tVDPParam);


        while(1)
        {
            // Run V-Dump
            ret = APACHE_TEST_VDUMP_Start(&tVDPParam);
            if(ret == NC_FAILURE)
            {
                // Error Case : File Dump
                __test_vdump_debug_file_dump();
                break;
            }


            // Input Key Exit ('Q' or 'q')
            if(APACHE_TEST_ExitKey())
            {
                // User Test Stop
                ret = NC_FAILURE;
                break;
            }


            // Get Test Operation
            ret = __test_vdump_debug_loop_next_operation();
            if(ret == NC_FAILURE)
            {
                // Get Test Scal Size
                ret = __test_vdump_debug_loop_next_scaler_size();
                if(ret == NC_FAILURE)
                {
                    // Operation Change End
                    ret = NC_SUCCESS;
                    break;
                }
            }


            // Update Operation Mode
            APACHE_TEST_VDUMP_UpdateOp(&tVDPParam);


            // Change Input Test Pattern
            __test_vdump_debug_loop_next_pattern();
        }
        DEBUGMSG(MSGINFO, "\n"); 

        // Test End
        if(ret == NC_FAILURE)
            break;


        // Test Decrease Size Change
        #if 1
            // stop
            ret = NC_SUCCESS;
            break;
        #else
            tVDPTestFlag.mVDP_DebugTestOffset = (tVDPTestFlag.mVDP_DebugTestOffset>>1); // offset x (1/2) 
        #endif
    }


    // DeInit V-Dump 
    APACHE_TEST_VDUMP_DeInit();


    // Roll-Back
    tVDPTestFlag.mVDP_DebugTestOffset = TestOffset_org;


    return ret;
}



INT32 APACHE_TEST_VDUMP_Loop_Crop(void)
{
    INT32 ret = NC_SUCCESS;
    tVDP_PARAM tVDPParam;
    UINT32  TestOffset_org;


    DEBUGMSG(MSGINFO, "\n============================================================\n");
    DEBUGMSG(MSGINFO, " > Loop Test : Change %s Crop\n", (tVDPTestFlag.mVDP_DebugTestCtrlEn)?"Operattion +":"x");
    DEBUGMSG(MSGINFO, "   -. Test Exit Command : 'Q' or 'q'\n");



    // Back Up
    TestOffset_org = tVDPTestFlag.mVDP_DebugTestOffset;


    // Init V-Dump 
    APACHE_TEST_VDUMP_Init(&tVDPParam);


    // Long Time ~~~
    while(tVDPTestFlag.mVDP_DebugTestOffset)
    {
        // First Set Test Value
        __test_vdump_debug_loop_next_operation();
        __test_vdump_debug_loop_next_crop_size();
        APACHE_TEST_VDUMP_UpdateOp(&tVDPParam);

        
        while(1)
        {
            // Run V-Dump
            ret = APACHE_TEST_VDUMP_Start(&tVDPParam);
            if(ret == NC_FAILURE)
            {
                // Error Case : File Dump
                 __test_vdump_debug_file_dump();
                break;
            }


            // Input Key Exit ('Q' or 'q')
            if(APACHE_TEST_ExitKey())
            {
                // User Test Stop
                ret = NC_FAILURE;
                break;
            }


            // Get Test Operation
            ret = __test_vdump_debug_loop_next_operation();
            if(ret == NC_FAILURE)
            {
                // Get Test Crop Size
                ret = __test_vdump_debug_loop_next_crop_size();
                if(ret == NC_FAILURE)
                {
                    // Operation Change End
                    ret = NC_SUCCESS;
                    break;
                }
            }


            // Update Operation Mode
            APACHE_TEST_VDUMP_UpdateOp(&tVDPParam);


            // Change Input Test Pattern
            __test_vdump_debug_loop_next_pattern();
        }
        DEBUGMSG(MSGINFO, "\n"); 

        // Test End
        if(ret == NC_FAILURE)
            break;


        // Test Decrease Size Change
        #if 1
            // stop
            ret = NC_SUCCESS;
            break;
        #else
            tVDPTestFlag.mVDP_DebugTestOffset = (tVDPTestFlag.mVDP_DebugTestOffset>>1); // offset x (1/2)
        #endif
    }


    // DeInit V-Dump 
    APACHE_TEST_VDUMP_DeInit();


    // Roll-Back
    tVDPTestFlag.mVDP_DebugTestOffset = TestOffset_org;


    return ret;
}


INT32 APACHE_TEST_VDUMP_Loop_Ctrl(void)
{
    INT32 ret = NC_SUCCESS;
    tVDP_PARAM tVDPParam;
    BOOL  TestCtrlEn_org;


    DEBUGMSG(MSGINFO, "\n============================================================\n");
    DEBUGMSG(MSGINFO, " > Loop Test : Change Operation\n");
    DEBUGMSG(MSGINFO, "   -. Test Exit Command : 'Q' or 'q'\n");


    // Back Up
    TestCtrlEn_org = tVDPTestFlag.mVDP_DebugTestCtrlEn;
    tVDPTestFlag.mVDP_DebugTestCtrlEn = ON;

    
    // Init V-Dump 
    APACHE_TEST_VDUMP_Init(&tVDPParam);

    

    // First Set Test Value
    __test_vdump_debug_loop_next_operation();
    APACHE_TEST_VDUMP_UpdateOp(&tVDPParam);


    while(1)
    {
        // Run V-Dump
        ret = APACHE_TEST_VDUMP_Start(&tVDPParam);
        if(ret == NC_FAILURE)
        {
            // Error Case : File Dump
             __test_vdump_debug_file_dump();
            break;
        }


        // Input Key Exit ('Q' or 'q')
        if(APACHE_TEST_ExitKey())
        {
            // User Test Stop
            ret = NC_FAILURE;
            break;
        }


        // Get Test Operation
        ret = __test_vdump_debug_loop_next_operation();
        if(ret == NC_FAILURE)
        {
            // Operation Change End
            ret = NC_SUCCESS;
            break;
        }


        // Update Operation Mode
        APACHE_TEST_VDUMP_UpdateOp(&tVDPParam);


        // Change Input Test Pattern
        __test_vdump_debug_loop_next_pattern();
    }


    // DeInit V-Dump 
    APACHE_TEST_VDUMP_DeInit();


    // Roll-Back
    tVDPTestFlag.mVDP_DebugTestCtrlEn = TestCtrlEn_org;


    return ret;
}


INT32 APACHE_TEST_VDUMP_Loop(void) 
{
    INT32 ret = NC_SUCCESS;

    if(ret == NC_SUCCESS)     
        ret = APACHE_TEST_VDUMP_Loop_Ctrl();

    if(ret == NC_SUCCESS)   
        ret = APACHE_TEST_VDUMP_Loop_Crop();
    
    if(ret == NC_SUCCESS)   
        ret = APACHE_TEST_VDUMP_Loop_Scaler();
    
    if(ret == NC_SUCCESS)   
        ret = APACHE_TEST_VDUMP_Loop_Crop_Scaler();

    return ret;
}


INT32 APACHE_TEST_VDUMP_Normal(void)
{
    INT32 ret;    
    tVDP_PARAM tVDPParam;

    
    // Init V-Dump 
    APACHE_TEST_VDUMP_Init(&tVDPParam);


#if 1
    // Run V-Dump
    APACHE_TEST_VDUMP_Start(&tVDPParam);
#else
    while(1)
    {
        // Run V-Dump
        ret = APACHE_TEST_VDUMP_Start(&tVDPParam);
        if(ret == NC_FAILURE)
        {
            // Error Case : File Dump
            __test_vdump_debug_file_dump();
            break;
        }


        // Input Key Exit ('Q' or 'q')
        if(APACHE_TEST_ExitKey())
        {
            // User Test Stop
            ret = NC_FAILURE;
            break;
        }


        // Change Input Test Pattern
        __test_vdump_debug_loop_next_pattern();
    }
#endif


    // DeInit V-Dump 
    APACHE_TEST_VDUMP_DeInit();


    return ret;
}


INT32 APACHE_TEST_VDUMP_CUTMode(void)
{ 
    INT32 select;
    char buf[256];

    UINT32 i;
    eVDP_CH Ch;    


    // Default Init Variable
    tVDPTestFlag = tVDPTestFlag_Def;
    __test_vdump_debug_change_pattern(tVDPTestFlag.mVDP_DebugPatternIdx, FALSE);


    while(1)
    {
        Ch =  tVDPTestFlag.mVDP_DebugCtrlCh;
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - VDUMP                        \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Video Dump Controller                                      \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> V-Dump Test (Normal)                                   \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Aging Test Menu (long Time~)                               \n");
        DEBUGMSG(MSGINFO, " <2> Aging loop Full Test                                   \n");
        DEBUGMSG(MSGINFO, " <3> Aging Operation Change Test                            \n");
        DEBUGMSG(MSGINFO, " <4> Aging Crop Size Change Test                            \n");
        DEBUGMSG(MSGINFO, " <5> Aging Scal Size Change Test                            \n");
        DEBUGMSG(MSGINFO, " <6> Aging Crop+Scal Change Test                            \n");
        DEBUGMSG(MSGINFO, " <7> Aging Offset Size      : %d                            \n", tVDPTestFlag.mVDP_DebugTestOffset);   
        DEBUGMSG(MSGINFO, " <8> Aging Pattern On/Off   : %s                            \n", (tVDPTestFlag.mVDP_DebugTestPatternEn)?"ON":"OFF");   
        DEBUGMSG(MSGINFO, " <9> Aging Operation On/Off : %s                            \n", (tVDPTestFlag.mVDP_DebugTestCtrlEn)?"ON":"OFF");  
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Operation Control Meun                                     \n");
        DEBUGMSG(MSGINFO, " <A> Interrupt              : %s                            \n", (tVDPTestFlag.mVDP_IsrEn)?"ENABLE":"DISABLE");
        DEBUGMSG(MSGINFO, " <B> FrameEdge              : VDP_SEL_FRAME_%s              \n", (tVDPTestFlag.mVDP_FrameEdge)?"END":"START");
        DEBUGMSG(MSGINFO, " <C> Input Path             : VDP_I_%s_OUT_PATH             \n", cInputPath[tVDPTestFlag.mVDP_InputPath]);
        DEBUGMSG(MSGINFO, " <D> Input Format           : VDP_I_%s_FORMAT               \n", (tVDPTestFlag.mVDP_InFormat)?"RGB":"YUV");
        DEBUGMSG(MSGINFO, " <E> YVU Select             : VDP_YUV%d                     \n", (tVDPTestFlag.mVDP_YUVSelect)?422:444);
        DEBUGMSG(MSGINFO, " <F> Format Type            : VDP_FRAME_%s_FRAME            \n", (tVDPTestFlag.mVDP_FrameType)?"VIEWING":"SENSING");
        DEBUGMSG(MSGINFO, " <G> Crop On/Off            : %s                            \n", (tVDPTestFlag.mVDP_CropEn)?"ENABLE":"DISABLE");
        DEBUGMSG(MSGINFO, " <H> Crop Start H-Pos       : %04d                          \n", tVDPTestFlag.mVDP_CropStartH);
        DEBUGMSG(MSGINFO, " <I> Crop End   H-Pos       : %04d (%d)                     \n", tVDPTestFlag.mVDP_CropEndH , tVDPTestFlag.mVDP_CropEndH - tVDPTestFlag.mVDP_CropStartH);
        DEBUGMSG(MSGINFO, " <J> Crop Start V-Pos       : %04d                          \n", tVDPTestFlag.mVDP_CropStartV);
        DEBUGMSG(MSGINFO, " <K> Crop End   V-POs       : %04d (%d)                     \n", tVDPTestFlag.mVDP_CropEndV,  tVDPTestFlag.mVDP_CropEndV - tVDPTestFlag.mVDP_CropStartV);
        DEBUGMSG(MSGINFO, " <L> Scaler On/Off          : %s                            \n", (tVDPTestFlag.mVDP_ScalEn)?"ENABLE":"DISABLE");
        DEBUGMSG(MSGINFO, " <M> Scaler H-Size          : %d                            \n", tVDPTestFlag.mVDP_ScalOutputH);
        DEBUGMSG(MSGINFO, " <N> Scaler V-Size          : %d                            \n", tVDPTestFlag.mVDP_ScalOutputV);
        for(i=0; i<MAX_OF_VDP_CH; i++)
        {
        DEBUGMSG(MSGINFO, "\n");
        if( i == Ch )
        {
        DEBUGMSG(MSGINFO, " <O> Ctrl Channle Change                                    \n");
        DEBUGMSG(MSGINFO, " <P> CH_%d - On/Off          : %s                           \n", i, (tVDPTestFlag.mVDP_ChEn[i])?"ENABLE":"DISABLE");
        DEBUGMSG(MSGINFO, " <Q> CH_%d - Endian          : VDP_ENDIAN_%s                \n", i, (tVDPTestFlag.mVDP_Endian[i])?"BIG":"LITTLE");
        DEBUGMSG(MSGINFO, " <R> CH_%d - Data Parsing    : VDP_P_%s                     \n", i, cParsing[tVDPTestFlag.mVDP_InFormat][tVDPTestFlag.mVDP_Bit[i]][tVDPTestFlag.mVDP_Parsing[i]]);   
        DEBUGMSG(MSGINFO, " <S> CH_%d - Packet Bit      : VDP_BIT_%d                   \n", i, cBit[tVDPTestFlag.mVDP_Bit[i]]);
        DEBUGMSG(MSGINFO, " <T> CH_%d - Burst Length    : VDP_BURST_%d                 \n", i, cBurstMode[tVDPTestFlag.mVDP_Burst[i]]);
        DEBUGMSG(MSGINFO, " <U> CH_%d - Dump Addr       : 0x%08X                       \n", i, tVDPTestFlag.mVDP_DMAAddr[i]);
        }
        else
        {
        DEBUGMSG(MSGINFO, " < > CH_%d - On/Off          : %s                           \n", i, (tVDPTestFlag.mVDP_ChEn[i])?"ENABLE":"DISABLE");
        DEBUGMSG(MSGINFO, " < > CH_%d - Endian          : VDP_ENDIAN_%s                \n", i, (tVDPTestFlag.mVDP_Endian[i])?"BIG":"LITTLE");
        DEBUGMSG(MSGINFO, " < > CH_%d - Data Parsing    : VDP_P_%s                     \n", i, cParsing[tVDPTestFlag.mVDP_InFormat][tVDPTestFlag.mVDP_Bit[i]][tVDPTestFlag.mVDP_Parsing[i]]);   
        DEBUGMSG(MSGINFO, " < > CH_%d - Packet Bit      : VDP_BIT_%d                   \n", i, cBit[tVDPTestFlag.mVDP_Bit[i]]);
        DEBUGMSG(MSGINFO, " < > CH_%d - Burst Length    : VDP_BURST_%d                 \n", i, cBurstMode[tVDPTestFlag.mVDP_Burst[i]]);
        DEBUGMSG(MSGINFO, " < > CH_%d - Dump Addr       : 0x%08X                       \n", i, tVDPTestFlag.mVDP_DMAAddr[i]);
        }
        }
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <V> Test Pattern Change    : %d                            \n", tVDPTestFlag.mVDP_DebugPatternIdx);   
        DEBUGMSG(MSGINFO, " <W> TimeOut Value Change   : %d                            \n", tVDPTestFlag.mVDP_DebugTimeOut);            
        DEBUGMSG(MSGINFO, " <X> Buff Clear On/Off      : %s                            \n", (tVDPTestFlag.mVDP_DebugBuffCls)?"ON":"OFF");   
        DEBUGMSG(MSGINFO, " <Y> File Write On/Off      : %s                            \n", (tVDPTestFlag.mVDP_DebugFileWrite)?"ON":"OFF");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ..%s                       \n", (tVDPTestFlag.mVDP_DebugMsgOn)?"o":"x");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_VDUMP_Normal();
            break;
            
            case 2:
                APACHE_TEST_VDUMP_Loop();
            break;

            case 3:
                APACHE_TEST_VDUMP_Loop_Ctrl();
            break;

            case 4:
                APACHE_TEST_VDUMP_Loop_Crop();
            break;

            case 5:
                APACHE_TEST_VDUMP_Loop_Scaler();
            break;

            case 6:
                APACHE_TEST_VDUMP_Loop_Crop_Scaler();
            break;

            case 7:
                __test_vdump_debug_loop_size_offset();
            break;
            
            case 8:
                _REVERSE(tVDPTestFlag.mVDP_DebugTestPatternEn);
            break;

            case 9:
                _REVERSE(tVDPTestFlag.mVDP_DebugTestCtrlEn);
            break; 

            
            // Operation Ctrl
            case 10: // A
                _REVERSE(tVDPTestFlag.mVDP_IsrEn);
            break;

            case 11: // B
                _REVERSE(tVDPTestFlag.mVDP_FrameEdge);
            break;

            case 12: // C
                __test_vdump_debug_change_input_path(tVDPTestFlag.mVDP_InputPath);
            break;

            case 13: // D
                _REVERSE(tVDPTestFlag.mVDP_InFormat);
            break;

            case 14: // E
                _REVERSE(tVDPTestFlag.mVDP_YUVSelect);
            break;      

            case 15: // F
                _REVERSE(tVDPTestFlag.mVDP_FrameType);
            break; 

            case 16: // G
                _REVERSE(tVDPTestFlag.mVDP_CropEn);
            break; 

            case 17: // H
                __test_vdump_debug_change_crop_start_h();
            break; 

            case 18: // I
                __test_vdump_debug_change_crop_end_h();
            break;  
            
            case 19: // J
                __test_vdump_debug_change_crop_start_v();
            break; 
               
            case 20: // K
                __test_vdump_debug_change_crop_end_v();
            break;       

            case 21: // L
                _REVERSE(tVDPTestFlag.mVDP_ScalEn);  
            break; 
            
            case 22: // M
                __test_vdump_debug_change_scal_out_h();
            break;       

            case 23: // N
                __test_vdump_debug_change_scal_out_v();
            break;       

            
            // Channel Ctrl
            case 24: // O
                if(++tVDPTestFlag.mVDP_DebugCtrlCh > VDP_CH2)
                    tVDPTestFlag.mVDP_DebugCtrlCh = VDP_CH0;
            break;
            
            case 25: // P
                _REVERSE(tVDPTestFlag.mVDP_ChEn[Ch]);
            break;  

            case 26: // Q
                _REVERSE(tVDPTestFlag.mVDP_Endian[Ch]);
            break;     

            case 27: // R
                __test_vdump_debug_change_data_pasing(Ch, tVDPTestFlag.mVDP_Parsing[Ch]);
            break;  
            
            case 28: // S
                __test_vdump_debug_change_bit(Ch,tVDPTestFlag.mVDP_Bit[Ch]);
            break;

            case 29: // T
                __test_vdump_debug_change_burst_length(Ch, tVDPTestFlag.mVDP_Burst[Ch]);
            break;

            case 30: // U
                __test_vdump_debug_change_dma_addr(Ch);
            break;


            // Debug variable ctrl
            case 31: // V
                __test_vdump_debug_change_pattern(tVDPTestFlag.mVDP_DebugPatternIdx, TRUE);
            break;

            case 32: // W
               __test_vdump_debug_change_time_out_value();
            break;

            case 33: // X
                _REVERSE(tVDPTestFlag.mVDP_DebugBuffCls);
            break;
            
            case 34: // Y
            {
                #if 0 
                    UINT32 Reg;

                    while(1)
                    {
                        Reg = (REGRW32(APACHE_ISP_BASE, 0x670)>>5)&0x3;
                        DEBUGMSG(MSGINFO, ">> %d\n", Reg);

                        if(APACHE_TEST_ExitKey())
                            break;
                    }  
                #endif
                _REVERSE(tVDPTestFlag.mVDP_DebugFileWrite);
            }
            break;

            case 35: // Z
                _REVERSE(tVDPTestFlag.mVDP_DebugMsgOn);
            break;
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto Vdump_Exit;
        }
    }

Vdump_Exit:

    return NC_SUCCESS;
}

#endif /* ENABLE_IP_VDUMP */


/* End Of File */

