/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_SF










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    eSSP_CH mSF_TestCh; 
    UINT32  mSF_TestDiv;
    UINT32  mSF_TestAddr; 
    UINT32  mSF_TestFlashSize;

    BOOL    mSF_QuadMode;
    BOOL    mSF_DMAMode;
    BOOL    mSF_WP;     
    BOOL    mSF_TestWriteSkip;
    BOOL    mSF_DebugMsgOn;      
} tSFTEST_FLAG, *ptSFTEST_FLAG;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tSFTEST_FLAG tSFTestFlag;
volatile tSFTEST_FLAG tSFTestFlag_Def = {                                             
                                            SSP_CH0,    // Test SPI Controller Channel
                                            0xE,        // Test SPI/QSPI Controller Clock Div Value
                                            0x0,        // Test sflash Start Addr
                                            (2*MB),     // Test sflash Size

                                            ON,         // Test QuadMode On/Off
                                            ON,         // Test DMAMode On/Off
                                            0,          // Test sflash Write Project On/Off
                                            OFF,        // Test sflash Write Skip On/Off
                                            OFF         // Test Debug Message Display On/Off
                                            };

#if defined(__TEST_BUFF_BSS_ZONE__)
// To use QSPI, a 8-byte aligned buffer is required.
UINT8  gTestsFlashwBuff[SF_PAGE_SIZE]   __attribute__ ((aligned (8)));
UINT8  gTestsFlashrBuff[SF_SECTOR_SIZE] __attribute__ ((aligned (8)));

#elif defined(__TEST_BUFF_STACK_ZONE__)
// The buffer is inside the function.

#else
UINT8* gTestsFlashwBuff  = (UINT8*)(TEST_PHY_DDR_BASE);
UINT8* gTestsFlashrBuff  = (UINT8*)(TEST_PHY_DDR_BASE+SF_PAGE_SIZE);

#endif










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __test_sf_display_buff(UINT8 *pBuff, UINT32 Size, UINT32 PageAddr)
{
    UINT32 i;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");	
    DEBUGMSG(MSGINFO, "\n>> PageAddr = 0x%08X, BuffAddr = 0x%08X", PageAddr, (UINT32)pBuff);	
    for(i=0;i<Size;i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", PageAddr+i);	
        DEBUGMSG(MSGINFO, "%02X ", pBuff[i]);	
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");	
}


static UINT32 __test_sf_get_memory_size(UINT8 Capacity)
{
    UINT32 nChipSize = 64*KB;
    UINT32 i;

    for(i = MEMORY_CAPACITY_512Kb; i <= MEMORY_CAPACITY_128Mb; i++)
    {
        if(Capacity == i)
        {
            break;
        }
        else
        {
            nChipSize = nChipSize * 2;
        }
    }

    return nChipSize;
}


static void __test_sf_dummy_buff_marking(UINT8 *pAddr, UINT32 PageAddr)
{
    pAddr[0] = (PageAddr>>24 & 0xFF);
    pAddr[1] = (PageAddr>>16 & 0xFF);
    pAddr[2] = (PageAddr>>8  & 0xFF);
    pAddr[3] = (PageAddr     & 0xFF);    

    pAddr[SF_PAGE_SIZE-4] = (PageAddr>>24 & 0xFF);
    pAddr[SF_PAGE_SIZE-3] = (PageAddr>>16 & 0xFF);
    pAddr[SF_PAGE_SIZE-2] = (PageAddr>>8  & 0xFF);
    pAddr[SF_PAGE_SIZE-1] = (PageAddr     & 0xFF);    
}


static void __test_sf_dummy_buff(UINT8 *pAddr, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        pAddr[i] = i;
    }  
}


static void __test_sf_clear_buff(UINT8 *pAddr, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        pAddr[i] = 0x0;
    }    
}


static void __test_sf_mode_display(void)
{
    DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, " Write [Standard SPI-%s Mode], Read [%s Mode]\n", (tSFTestFlag.mSF_DMAMode)?"DMA":"PIO", 
                      (tSFTestFlag.mSF_QuadMode)?"Quad SPI":(tSFTestFlag.mSF_DMAMode)?"Standard SPI-DMA":"Standard SPI-PIO");
    DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");    
}


void APACHE_TEST_SF_SetDebugPort(BOOL OnOff, eSSP_CH Ch)
{
    UINT32 Reg;

    Reg = REGRW32(APACHE_SYSCON_BASE, 0x1040);
    Reg &= ~(7<<16);

    if(OnOff == ON)
    {
        if(Ch == SSP_CH0)
            Reg |= (4<<16);
        else if (Ch == SSP_CH1)
            Reg |= (5<<16); 
        else
            Reg |= (6<<16); 
    }
    
    REGRW32(APACHE_SYSCON_BASE, 0x1040) = Reg;
}


void APACHE_TEST_SF_StartAddrChange(void)
{
    tSFTestFlag.mSF_TestAddr = APACHE_TEST_Display_InputValue(0x0, (tSFTestFlag.mSF_TestFlashSize-SF_BLOCK_SIZE), "Change StartAddr");
}

UINT32 APACHE_TEST_SF_GetClock(UINT32 Div)
{
                        // 0x0,  0x1,  0x2,  0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xA, 0xB, 0xC, 0xD, 0xE, 0xF
    UINT32 DivValue[] = { 4095, 2500, 1250, 1000, 500, 250, 125,  50,  25,  12,  10,   5,   4,   3,   2,   0};
    UINT32 Clk = 0;
    
    if(tSFTestFlag.mSF_QuadMode == ON)
    {
        // [0x01 ~ 0x0E]
        if(Div > 0xE) 
            Div = 0x0E;
        else if(Div < 0x01) 
            Div = 0x01;

        Clk = (ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_QSPI, CMD_END)/DivValue[Div]);
    }
    else
    {
        if(Div < 2)
            Div = 2;

        return (ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_SSPI, CMD_END)/Div);   
    }

    return Clk;        
}


void APACHE_TEST_SF_Init(void)
{
    tSF_PARAM  tSFParam;
    tSFLASH_ID tFlashID;


    // Open sFlash Interface (Used SSP, QSPI, DMA)
    ncLib_SF_Open();



    // sFlash Operation Mode
    tSFParam.mSpiCh 	= tSFTestFlag.mSF_TestCh;
    tSFParam.mDmaMode	= tSFTestFlag.mSF_DMAMode;
    tSFParam.mQuadMode	= tSFTestFlag.mSF_QuadMode;
    tSFParam.mBitRate	= APACHE_TEST_SF_GetClock(tSFTestFlag.mSF_TestDiv);

    ncLib_SF_Control(GCMD_SF_INIT, &tSFParam, CMD_END);


    // if (DMA or QSPI Not Support)
    tSFTestFlag.mSF_DMAMode  = tSFParam.mDmaMode;
    tSFTestFlag.mSF_QuadMode = tSFParam.mQuadMode;


    // Cruuent sFlash Write Protect Status 
    tSFTestFlag.mSF_WP = (ncLib_SF_Control(GCMD_SF_READ_STATUS, CMD_END)>>2)&0x0f;


    // sFlash ID Check.     
    ncLib_SF_Control(GCMD_SF_READ_ID, &tFlashID, CMD_END);
    tSFTestFlag.mSF_TestFlashSize = __test_sf_get_memory_size(tFlashID.mbMemoryCapacity&0xf);
    
}


void APACHE_TEST_SF_DeInit(void)
{ 
    ncLib_SF_Control(GCMD_SF_DEINIT, CMD_END);
    ncLib_SF_Close();
}


void APACHE_TEST_SF_ReInit(void)
{
    APACHE_TEST_SF_DeInit();
    APACHE_TEST_SF_Init();
}


void APACHE_TEST_SF_SetWP(void)
{
    DEBUGMSG(MSGINFO, "[SF_TEST] Write Protect\n");

    /* Open Serial Flash Library */
    //APACHE_TEST_SF_Init();

    if(tSFTestFlag.mSF_WP & 0x07)
        ncLib_SF_Control(GCMD_SF_ENABLE_WP, FALSE, CMD_END);
    else
        ncLib_SF_Control(GCMD_SF_ENABLE_WP, TRUE, CMD_END);   
    tSFTestFlag.mSF_WP = (ncLib_SF_Control(GCMD_SF_READ_STATUS, CMD_END)>>2)&0x0f;

    /* Close Serial Flash Library */
    //APACHE_TEST_SF_DeInit();
}


void APACHE_TEST_SF_ReadID(void)
{
    tSFLASH_ID tFlashID;



    DEBUGMSG(MSGINFO, "[SF_TEST] Read Identification\n");



    /* Open Serial Flash Library */
    //APACHE_TEST_SF_Init();
    


    /* Get Chip Size from RDID */
    ncLib_SF_Control(GCMD_SF_READ_ID, &tFlashID, CMD_END);
    tSFTestFlag.mSF_TestFlashSize = __test_sf_get_memory_size(tFlashID.mbMemoryCapacity&0xf);



    /* Display Test Result */
    DEBUGMSG(MSGINFO, " Spi-Flash >> \n");
    DEBUGMSG(MSGINFO, "  manufacturer ID : 0x%02X\n", tFlashID.mbManufacture);
    DEBUGMSG(MSGINFO, "  memory type     : 0x%02X\n", tFlashID.mbMemoryType);
    DEBUGMSG(MSGINFO, "  memory density  : 0x%02X\n", tFlashID.mbMemoryCapacity);
    DEBUGMSG(MSGINFO, "  memory size     : %d KB\n", (tSFTestFlag.mSF_TestFlashSize/KB));



    /* Close Serial Flash Library */
    //APACHE_TEST_SF_DeInit();
}


void APACHE_TEST_SF_BlockErase(void)
{
    UINT32 Addr;
    UINT32 i;
    UINT32 nErrCnt;
    UINT32 nChipSize;

#ifdef __TEST_BUFF_STACK_ZONE__
    UINT8  rBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* rBuff = (UINT8*)&gTestsFlashrBuff[0];
#endif


    DEBUGMSG(MSGINFO, "\n[SF_TEST] Block Erase -> Read Page -> Check Data (0xFF)\n");



    /* Open Serial Flash Library */
    //APACHE_TEST_SF_Init();
    __test_sf_mode_display();


    /* Chip Size */
    nChipSize = tSFTestFlag.mSF_TestFlashSize;


    /* Whole Chip Erase */
    for(Addr = tSFTestFlag.mSF_TestAddr; Addr < nChipSize; Addr += SF_BLOCK_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Block Erase : 0x%08x", Addr);
        ncLib_SF_Control(GCMD_SF_BLOCK_ERASE, Addr, CMD_END );
    }
    DEBUGMSG(MSGINFO, "\n");



    /* Page Read - Check Erased Chip(0xFF) */
    for(Addr = tSFTestFlag.mSF_TestAddr, nErrCnt = 0; Addr < nChipSize; Addr += SF_PAGE_SIZE)
    {
        __test_sf_clear_buff(rBuff, SF_PAGE_SIZE);	
        
        DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", Addr);
        ncLib_SF_Read(Addr, (UINT8 *)rBuff, SF_PAGE_SIZE);

        for(i=0; i<SF_PAGE_SIZE; i++)
        {
            if(rBuff[i] != 0xFF)
            {
                nErrCnt++;

                if(tSFTestFlag.mSF_DebugMsgOn == ON)
                {
                    __test_sf_display_buff(rBuff, SF_PAGE_SIZE, Addr);
                    tSFTestFlag.mSF_DebugMsgOn = APACHE_TEST_WaitKey();
                }
                break;  
            }
        }
    }
    
    /* Display Test Result */
    if(nErrCnt == 0)
    {
        DEBUGMSG(MSGINFO, " - Success!\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, " - Fail! (%d)\n", nErrCnt);
    }



    /* Close Serial Flash Library */
    //APACHE_TEST_SF_DeInit();
}


void APACHE_TEST_SF_PageRead(void)
{
    UINT32 Addr = tSFTestFlag.mSF_TestAddr;    

#ifdef __TEST_BUFF_STACK_ZONE__
    UINT8  rBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* rBuff = (UINT8*)&gTestsFlashrBuff[0];
#endif


    DEBUGMSG(MSGINFO, "\n[SF_TEST] Read Page\n");



    /* Open Serial Flash Library */
    //APACHE_TEST_SF_Init();
    __test_sf_mode_display();
    

    /* Page Read  */
    __test_sf_clear_buff(rBuff, SF_PAGE_SIZE);	
    ncLib_SF_Read(Addr, (UINT8 *)rBuff, SF_PAGE_SIZE);    
    __test_sf_display_buff(rBuff, SF_PAGE_SIZE, Addr);


    /* Close Serial Flash Library */
    //APACHE_TEST_SF_DeInit();
}


void APACHE_TEST_SF_PageWrite(void)
{
    UINT32 Addr = tSFTestFlag.mSF_TestAddr;    

#ifdef __TEST_BUFF_STACK_ZONE__
    UINT8  wBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* wBuff = (UINT8*)&gTestsFlashwBuff[0];
#endif


    DEBUGMSG(MSGINFO, "\n[SF_TEST] Page Write\n");



    /* Open Serial Flash Library */
    //APACHE_TEST_SF_Init();
    __test_sf_mode_display();


    /* Page Write  */
    __test_sf_dummy_buff(wBuff, SF_PAGE_SIZE);
    ncLib_SF_Control(GCMD_SF_SECTOR_ERASE, Addr, CMD_END );    
    ncLib_SF_Write(Addr, (UINT8 *)wBuff, SF_PAGE_SIZE);
    __test_sf_display_buff(wBuff, SF_PAGE_SIZE, Addr);



    /* Close Serial Flash Library */
    //APACHE_TEST_SF_DeInit();
}


void APACHE_TEST_SF_SectorErase_DataWrite_DataRead_Compare(void)
{
    UINT32 Addr = 0;  
    UINT32 Offset;    
    UINT32 i;
    UINT32 nErrCnt;    

#ifdef __TEST_BUFF_STACK_ZONE__
    UINT8  wBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
    UINT8  rBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* wBuff = (UINT8*)&gTestsFlashwBuff[0];
    UINT8* rBuff = (UINT8*)&gTestsFlashrBuff[0];
#endif


    DEBUGMSG(MSGINFO, "\n[SF_TEST] Sector Erase -> Write Data -> Data Read -> Compare\n");



    /* Generate Write Data */	
    __test_sf_dummy_buff(wBuff, SF_PAGE_SIZE);



    /* Open Serial Flash Library */
    //APACHE_TEST_SF_Init();
    __test_sf_mode_display();
    


    if(tSFTestFlag.mSF_TestWriteSkip == OFF)
    {
        /* Whole Chip Erase and Write Pattern */
        APACHE_TEST_StopWatch(ON);
        for(Addr = tSFTestFlag.mSF_TestAddr; Addr < (tSFTestFlag.mSF_TestAddr+SF_SECTOR_SIZE); Addr += SF_SECTOR_SIZE)
        {
            ncLib_SF_Control(GCMD_SF_SECTOR_ERASE, Addr, CMD_END );

            for(Offset = 0; Offset < SF_SECTOR_SIZE; Offset += SF_PAGE_SIZE)
            {
                DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", Addr+Offset);
                
                __test_sf_dummy_buff_marking(wBuff, Addr+Offset);  
                for(i=0; i<SF_PAGE_SIZE; i++)
                {
                    ncLib_SF_Write(Addr+Offset+i, (UINT8 *)(wBuff+i), 1);
                }
            }
        }
        APACHE_TEST_StopWatch(OFF);
        DEBUGMSG(MSGINFO, "\n");
    }


    /* Page Read and Compare Data */
    APACHE_TEST_StopWatch(ON);
    for(Addr = tSFTestFlag.mSF_TestAddr, nErrCnt = 0; Addr < (tSFTestFlag.mSF_TestAddr+SF_SECTOR_SIZE); Addr += SF_PAGE_SIZE)
    {
        __test_sf_clear_buff(rBuff, SF_PAGE_SIZE);	
        __test_sf_dummy_buff_marking(wBuff, Addr);  
        
        DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", Addr);
        for(i=0; i<SF_PAGE_SIZE; i++)
        {
            ncLib_SF_Read(Addr+i, (UINT8 *)(rBuff+i), 1);
        }

        for(i=0; i<SF_PAGE_SIZE; i++)
        {
            if(wBuff[i] != rBuff[i])
            {
                nErrCnt++;

                if(tSFTestFlag.mSF_DebugMsgOn == ON)
                {
                    __test_sf_display_buff(rBuff, SF_PAGE_SIZE, Addr);
                    tSFTestFlag.mSF_DebugMsgOn = APACHE_TEST_WaitKey();
                }
                break;  
            }
        }
    }
    APACHE_TEST_StopWatch(OFF);
    
    /* Display Test Result */
    if(nErrCnt == 0)
    {
        DEBUGMSG(MSGINFO, " - Success!\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, " - Fail! (%d)\n", nErrCnt);
    }



    /* Close Serial Flash Library */
    //APACHE_TEST_SF_DeInit();
}


void APACHE_TEST_SF_SectorErase_Write_Read_Compare(void)
{
    UINT32 Addr;
    UINT32 Offset;
    UINT32 i;
    UINT32 nErrCnt;
    UINT32 nChipSize;

#ifdef __TEST_BUFF_STACK_ZONE__
    UINT8  wBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
    UINT8  rBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* wBuff = (UINT8*)&gTestsFlashwBuff[0];
    UINT8* rBuff = (UINT8*)&gTestsFlashrBuff[0];
#endif


    DEBUGMSG(MSGINFO, "\n[SF_TEST] Sector Erase -> Program Page -> Read Page -> Compare\n");



    /* Generate Write Data */	
    __test_sf_dummy_buff(wBuff, SF_PAGE_SIZE);



    /* Open Serial Flash Library */
    //APACHE_TEST_SF_Init();
    __test_sf_mode_display();


    /* Chip Size */
    nChipSize = tSFTestFlag.mSF_TestFlashSize;




    if(tSFTestFlag.mSF_TestWriteSkip == OFF)
    {
        /* Whole Chip Erase and Write Pattern */
        APACHE_TEST_StopWatch(ON);
        for(Addr = tSFTestFlag.mSF_TestAddr; Addr < nChipSize; Addr += SF_SECTOR_SIZE)
        {
            ncLib_SF_Control(GCMD_SF_SECTOR_ERASE, Addr, CMD_END );

            for(Offset = 0; Offset < SF_SECTOR_SIZE; Offset += SF_PAGE_SIZE)
            {
                DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", Addr+Offset);
                
                __test_sf_dummy_buff_marking(wBuff, Addr+Offset);              
                ncLib_SF_Write(Addr+Offset, (UINT8 *)wBuff, SF_PAGE_SIZE);
            }
        }
        APACHE_TEST_StopWatch(OFF);
        DEBUGMSG(MSGINFO, "\n");
    }


    /* Page Read and Compare Data */
    APACHE_TEST_StopWatch(ON);
    for(Addr = tSFTestFlag.mSF_TestAddr, nErrCnt = 0; Addr < nChipSize; Addr += SF_PAGE_SIZE)
    {
        __test_sf_clear_buff(rBuff, SF_PAGE_SIZE);	
        __test_sf_dummy_buff_marking(wBuff, Addr);  
        
        DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", Addr);
        ncLib_SF_Read(Addr, (UINT8 *)rBuff, SF_PAGE_SIZE);

        for(i=0; i<SF_PAGE_SIZE; i++)
        {
            if(wBuff[i] != rBuff[i])
            {
                nErrCnt++;

                if(tSFTestFlag.mSF_DebugMsgOn == ON)
                {	
                    __test_sf_display_buff(wBuff, SF_PAGE_SIZE, Addr);
                    __test_sf_display_buff(rBuff, SF_PAGE_SIZE, Addr);
                    tSFTestFlag.mSF_DebugMsgOn = APACHE_TEST_WaitKey();
                }
                break;  
            }
        }
    }
    APACHE_TEST_StopWatch(OFF);

    
    /* Display Test Result */
    if(nErrCnt == 0)
    {
        DEBUGMSG(MSGINFO, " - Success!\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, " - Fail! (%d)\n", nErrCnt);
    }



    /* Close Serial Flash Library */
    //APACHE_TEST_SF_DeInit();
}


void APACHE_TEST_SF_BlockErase_Write_Read_Compare(void)
{
    UINT32 Addr, MakingAddr;
    UINT32 Offset;
    UINT32 i,j;
    UINT32 nErrCnt;
    UINT32 nChipSize;

#ifdef __TEST_BUFF_STACK_ZONE__
    UINT8  wBuff[SF_PAGE_SIZE]   __attribute__ ((aligned (8)));
    UINT8  rBuff[SF_SECTOR_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* wBuff = (UINT8*)&gTestsFlashwBuff[0];
    UINT8* rBuff = (UINT8*)&gTestsFlashrBuff[0];
#endif


    DEBUGMSG(MSGINFO, "\n[SF_TEST] Block Erase -> Program Page -> Read Data -> Compare\n");



    /* Generate Write Data */	
    __test_sf_dummy_buff(wBuff, SF_PAGE_SIZE);



    /* Open Serial Flash Library */
    //APACHE_TEST_SF_Init();
    __test_sf_mode_display();


    /* Chip Size */
    nChipSize = tSFTestFlag.mSF_TestFlashSize;



    if(tSFTestFlag.mSF_TestWriteSkip == OFF)
    {
        APACHE_TEST_StopWatch(ON);
        /* Whole Chip Erase and Write Pattern */
        for(Addr = tSFTestFlag.mSF_TestAddr; Addr < nChipSize; Addr += SF_BLOCK_SIZE)
        {
            ncLib_SF_Control(GCMD_SF_BLOCK_ERASE, Addr, CMD_END );

            for(Offset = 0; Offset < SF_BLOCK_SIZE; Offset += SF_PAGE_SIZE)
            {
                DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", Addr+Offset);

                __test_sf_dummy_buff_marking(wBuff, Addr+Offset);                
                ncLib_SF_Write(Addr+Offset, (UINT8 *)wBuff, SF_PAGE_SIZE);
            }
        }
        APACHE_TEST_StopWatch(OFF);
        DEBUGMSG(MSGINFO, "\n");
    }


    /* Data Read and Compare Data */
    for(Addr = tSFTestFlag.mSF_TestAddr, nErrCnt = 0; Addr < nChipSize; Addr += SF_SECTOR_SIZE)
    {
        __test_sf_clear_buff(rBuff, SF_SECTOR_SIZE);	

        DEBUGMSG(MSGINFO, "\r  Data Read   : 0x%08x", Addr);
        ncLib_SF_Read(Addr, (UINT8 *)rBuff, SF_SECTOR_SIZE);

        MakingAddr = Addr;        
        for(i=0, j=0; i<SF_SECTOR_SIZE; i++)
        {
            if(j >= SF_PAGE_SIZE)
            {
                j=0;
                MakingAddr+=SF_PAGE_SIZE;
            }

            if(j == 0)
                __test_sf_dummy_buff_marking(wBuff, MakingAddr); 

            if(wBuff[j++] != rBuff[i])
            {
                nErrCnt++;

                if(tSFTestFlag.mSF_DebugMsgOn == ON)
                {
                    DEBUGMSG(MSGINFO, "\n wBuff[%d]:%02x vs rBuff[%d]:%02x\n", j-1, wBuff[j-1], i, rBuff[i]);

                    __test_sf_display_buff(wBuff, SF_PAGE_SIZE, Addr);
                    for(i=0; i<SF_SECTOR_SIZE; i+=SF_PAGE_SIZE)
                        __test_sf_display_buff(&rBuff[i], SF_PAGE_SIZE, Addr+i);

                    tSFTestFlag.mSF_DebugMsgOn = APACHE_TEST_WaitKey();
                }
                break;
            }
        }
    }
    
    /* Display Test Result */
    if(nErrCnt == 0)
    {
        DEBUGMSG(MSGINFO, " - Success!\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, " - Fail! (%d)\n", nErrCnt);
    }



    /* Close Serial Flash Library */
    //APACHE_TEST_SF_DeInit();
}


void APACHE_TEST_SF_SelectClock(void)
{
    INT8 buf; 
    UINT32 nHz; 
    UINT32 Div = tSFTestFlag.mSF_TestDiv;  
    
    nHz = APACHE_TEST_SF_GetClock(Div);
    APACHE_TEST_GetArrowKey_Help("Clock Up", "Clock Down", NULL, NULL);
    DEBUGMSG(MSGINFO, "  > Clock Select    : %06d-KHz", (nHz/KHZ));
 
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }


            if(tSFTestFlag.mSF_QuadMode == ON)
            {
                // Number Key '8' and Direction Key 'Up'
                if(buf == '8')
                {
                    if(Div < 0x0F)
                        ++Div;
                }
                // Number Key '2' and Direction Key 'Down'
                else if(buf == '2')
                {
                    if(Div > 0x01)
                        --Div;
                }
            }
            else
            {
                // Number Key '8' and Direction Key 'Up'
                if(buf == '8')
                {
                    if(Div > 0x02)
                        --Div;
                }
                // Number Key '2' and Direction Key 'Down'
                else if(buf == '2')
                {
                    if(Div < 0xFF)
                        ++Div;
                }
            }
            nHz = APACHE_TEST_SF_GetClock(Div);
            DEBUGMSG(MSGINFO, "\r  > Clock Select    : %06d-KHz", (nHz/KHZ));
        }
    }

    // Update BitRate
    ncLib_SF_Control(GCMD_SF_SET_BITRATE, nHz, CMD_END);

    tSFTestFlag.mSF_TestDiv = Div;
}


void APACHE_TEST_SF_BitrateChange(void)
{
    UINT32 Div;
    UINT32 nHz;
    tSFLASH_ID tFlashID;
    
    UINT32 Addr, MakingAddr;
    UINT32 Offset;
    UINT32 i,j;
    UINT32 nErrCnt;
    UINT32 nChipSize;

#ifdef __TEST_BUFF_STACK_ZONE__
    UINT8  wBuff[SF_PAGE_SIZE]   __attribute__ ((aligned (8)));
    UINT8  rBuff[SF_SECTOR_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* wBuff = (UINT8*)&gTestsFlashwBuff[0];
    UINT8* rBuff = (UINT8*)&gTestsFlashrBuff[0];
#endif


    DEBUGMSG(MSGINFO, "[SF_TEST] Bitrate Change\n");



    /* Generate Write Data */	
    __test_sf_dummy_buff(wBuff, SF_PAGE_SIZE);


    
    /* Open Serial Flash Library */
    //APACHE_TEST_SF_Init();



    /* mHz Change Start */	
    for(Div = tSFTestFlag.mSF_TestDiv ; Div < 0xFF; Div++)
    {
        // Debug SSP
        APACHE_TEST_SF_SetDebugPort(ON, tSFTestFlag.mSF_TestCh);

        
        /* Set mHz */
        nHz = APACHE_TEST_SF_GetClock(Div);
        ncLib_SF_Control(GCMD_SF_SET_BITRATE, nHz, CMD_END);



        /* Get Chip Size from RDID */
        ncLib_SF_Control(GCMD_SF_READ_ID, &tFlashID, CMD_END);
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " >> BitRate   : %d-KHz(%0x2X)\n", (nHz/KHZ), Div);        
        DEBUGMSG(MSGINFO, " sFlash ID    : 0x%02x 0x%02x 0x%02x\n", tFlashID.mbManufacture,
                                                                    tFlashID.mbMemoryType,
                                                                    tFlashID.mbMemoryCapacity);
        nChipSize = __test_sf_get_memory_size((tFlashID.mbMemoryCapacity&0xf));
        DEBUGMSG(MSGINFO, " sFlash Size  : %d KB\n", nChipSize / KB);



        if(tSFTestFlag.mSF_TestWriteSkip == OFF)
        {
            /* Whole Chip Erase and Write Pattern */
            APACHE_TEST_StopWatch(ON);
            for(Addr = tSFTestFlag.mSF_TestAddr; Addr < nChipSize; Addr += SF_BLOCK_SIZE)
            {
                ncLib_SF_Control(GCMD_SF_BLOCK_ERASE, Addr, CMD_END );

                for(Offset = 0; Offset < SF_BLOCK_SIZE; Offset += SF_PAGE_SIZE)
                {
                    DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", Addr+Offset);
                    
                     __test_sf_dummy_buff_marking(wBuff, Addr+Offset);    
                    ncLib_SF_Write(Addr+Offset, (UINT8 *)wBuff, SF_PAGE_SIZE);
                }
            }
            APACHE_TEST_StopWatch(OFF);
            DEBUGMSG(MSGINFO, "\n");
        }
        


        // Debug QSPI
        if(tSFTestFlag.mSF_QuadMode == ON)
        {
            APACHE_TEST_SF_SetDebugPort(ON, MAX_OF_SSP_CH);
        }


        
        /* Page Read and Compare Data */
        APACHE_TEST_StopWatch(ON);
        for(Addr = tSFTestFlag.mSF_TestAddr, nErrCnt = 0; Addr < nChipSize; Addr += SF_PAGE_SIZE)
        {
            __test_sf_clear_buff(rBuff, SF_PAGE_SIZE);	
            __test_sf_dummy_buff_marking(wBuff, Addr); 

            DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", Addr);
            ncLib_SF_Read(Addr, (UINT8 *)rBuff, SF_PAGE_SIZE);

            for(i=0; i<SF_PAGE_SIZE; i++)
            {	
                if(wBuff[i] != rBuff[i])
                {
                    nErrCnt++;
                    
                    if(tSFTestFlag.mSF_DebugMsgOn == ON)
                    {
                        __test_sf_display_buff(wBuff, SF_PAGE_SIZE, Addr);                    
                        __test_sf_display_buff(rBuff, SF_PAGE_SIZE, Addr);
                        tSFTestFlag.mSF_DebugMsgOn = (BOOL)APACHE_TEST_WaitKey();
                    }
                    break;  
                }
            }

            if(nErrCnt != 0) 
                break;
        }
        APACHE_TEST_StopWatch(OFF);
        
        /* Display Test Result */
        if(nErrCnt == 0)
        {
            DEBUGMSG(MSGINFO, " - Success!\n");
        }
        else
        {
            DEBUGMSG(MSGINFO, " - Fail! (%d)\n", nErrCnt);
            break;
        }



        /* Data Read and Compare Data */
        APACHE_TEST_StopWatch(ON);
        for(Addr = tSFTestFlag.mSF_TestAddr, nErrCnt = 0; Addr < nChipSize; Addr += SF_SECTOR_SIZE)
        {
            __test_sf_clear_buff(rBuff, SF_SECTOR_SIZE);	

            DEBUGMSG(MSGINFO, "\r  Data Read   : 0x%08x", Addr);
            ncLib_SF_Read(Addr, (UINT8 *)rBuff, SF_SECTOR_SIZE);

            MakingAddr = Addr;     
            for(i=0, j=0; i<SF_SECTOR_SIZE; i++)
            {
                if(j >= SF_PAGE_SIZE)
                {
                    j=0;
                    MakingAddr+=SF_PAGE_SIZE;
                }

                if(j == 0)
                    __test_sf_dummy_buff_marking(wBuff, MakingAddr); 

                if(wBuff[j++] != rBuff[i])
                {
                    nErrCnt++;

                    if(tSFTestFlag.mSF_DebugMsgOn == ON)
                    {
                        DEBUGMSG(MSGINFO, "\n wBuff[%d]:%02x vs rBuff[%d]:%02x\n", j-1, wBuff[j-1], i, rBuff[i]);
                        for(i=0; i<SF_SECTOR_SIZE; i+=SF_PAGE_SIZE)
                            __test_sf_display_buff(&rBuff[i], SF_PAGE_SIZE, Addr+i);

                        tSFTestFlag.mSF_DebugMsgOn = APACHE_TEST_WaitKey();
                    }
                    break;
                }
            }

            if(nErrCnt != 0) 
                break;
        }
        APACHE_TEST_StopWatch(OFF);

    
        /* Display Test Result */
        if(nErrCnt == 0)
        {
            DEBUGMSG(MSGINFO, " - Success!\n");
        }
        else
        {
            DEBUGMSG(MSGINFO, " - Fail! (%d)\n", nErrCnt);
            break;
        }        


        // Input Key Exit ('Q' or 'q')
        if(APACHE_TEST_ExitKey())
            break;
        
    }



    /* Close Serial Flash Library */
    //APACHE_TEST_SF_DeInit();
}


INT32 APACHE_TEST_SF_CUTMode(void)
{
    INT32 	select;
    char 	buf[256];


    // Default Init Variable
    tSFTestFlag = tSFTestFlag_Def;


    // Debug Port Enable
    APACHE_TEST_SF_SetDebugPort(ON, tSFTestFlag.mSF_TestCh);


    
    APACHE_TEST_SF_Init();


    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - Serial Flash Interface       \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Standard SPI Controller : Read & Write Support             \n");
        DEBUGMSG(MSGINFO, " Quad     SPI Controller : Read Support                     \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> SF: Read Serial Flash ID							   \n");
        DEBUGMSG(MSGINFO, " <2> SF: Block Erase Test                                   \n");
        DEBUGMSG(MSGINFO, " <3> SF: Page Read Test                                     \n");
        DEBUGMSG(MSGINFO, " <4> SF: Page Write Test                                    \n"); 
        DEBUGMSG(MSGINFO, " <5> SF: Sector Erase -> Data Write -> Data Read -> Compare \n");          
        DEBUGMSG(MSGINFO, " <6> SF: Sector Erase -> Write Page -> Read Page -> Compare \n");
        DEBUGMSG(MSGINFO, " <7> SF: Block  Erase -> Write Page -> Read Data -> Compare \n");
        DEBUGMSG(MSGINFO, " <8> SF: Bit-rate Test                                      \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <A> SPI Channel Change  : CH-%d                            \n",  tSFTestFlag.mSF_TestCh); 
        DEBUGMSG(MSGINFO, " <B> SPI Mode Change     : %s SPI Mode                      \n", (tSFTestFlag.mSF_QuadMode)?"Quad":"Stardard"); 
        DEBUGMSG(MSGINFO, " <C> Tranfer Mode Change : %s Mode                          \n", (tSFTestFlag.mSF_DMAMode)?"DMA":"PIO");    
        DEBUGMSG(MSGINFO, " <D> BitRate Change      : %d KHz                           \n",  APACHE_TEST_SF_GetClock(tSFTestFlag.mSF_TestDiv)/KHZ);   
        DEBUGMSG(MSGINFO, " <E> Write Protect       : %s (0x%X)                        \n", (tSFTestFlag.mSF_WP&0xf)?"ENABLE":"DISABLE", tSFTestFlag.mSF_WP); 
        DEBUGMSG(MSGINFO, " <F> Test Area Change    : 0x%06X                           \n",  tSFTestFlag.mSF_TestAddr);   
        DEBUGMSG(MSGINFO, " <G> Write Skip          : %s                               \n", (tSFTestFlag.mSF_TestWriteSkip)?"On":"Off");    
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");  
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ..%s                       \n", (tSFTestFlag.mSF_DebugMsgOn)?"o":"x");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_SF_ReadID();
            break;

            case 2:
                APACHE_TEST_SF_BlockErase();
            break;

            case 3:
                APACHE_TEST_SF_PageRead();
            break;

            case 4:
                APACHE_TEST_SF_PageWrite();
            break;
            
            case 5:
                APACHE_TEST_SF_SectorErase_DataWrite_DataRead_Compare();
            break;
            
            case 6:
                APACHE_TEST_SF_SectorErase_Write_Read_Compare();
            break;

            case 7:
                APACHE_TEST_SF_BlockErase_Write_Read_Compare();
            break;
            
            case 8:
                APACHE_TEST_SF_BitrateChange();
            break;

            case 10: // A
            {
                tSFTestFlag.mSF_TestCh = (tSFTestFlag.mSF_TestCh?SSP_CH0:SSP_CH1);
                APACHE_TEST_SF_ReInit();
            }
            break;

            case 11: // B
            {
                _REVERSE(tSFTestFlag.mSF_QuadMode);
                APACHE_TEST_SF_ReInit();
            }
            break;

            case 12: // C
            {
                _REVERSE(tSFTestFlag.mSF_DMAMode);
                APACHE_TEST_SF_ReInit();
            }
            break;

            case 13: // D
                APACHE_TEST_SF_SelectClock();
            break;

            case 14: // E
                APACHE_TEST_SF_SetWP();
            break;
            
            case 15: // F
                APACHE_TEST_SF_StartAddrChange();
            break;

            case 16: // G
                _REVERSE(tSFTestFlag.mSF_TestWriteSkip);
            break;

            case 35: // Z
                _REVERSE(tSFTestFlag.mSF_DebugMsgOn);
            break;
            
            case 0:
                APACHE_TEST_SF_DeInit();
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
                goto SF_Exit;
            //break;
        }
    }
    
SF_Exit:

    // Debug Port Enable
    APACHE_TEST_SF_SetDebugPort(OFF, tSFTestFlag.mSF_TestCh);

    
    return NC_SUCCESS;
}


#endif /* ENABLE_IP_SF */


/* End Of File */

