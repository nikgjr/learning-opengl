/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_UART










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    BOOL            mUART_IsrEn;
  
    UINT32          mUART_BaudRate;
    UINT8           mUART_TriggerLevel;
    BOOL            mUART_TestRun; 

    UINT32          mUART_DebugCnt;
    BOOL            mUART_DebugMsgOn;
} tUARTTEST_FLAG, *ptUARTTEST_FLAG;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tUARTTEST_FLAG tUARTTestFlag; 
volatile tUARTTEST_FLAG tUARTTestFlag_Def = { 
                                                ON

                                                ,UT_BAUDRATE_115200
                                                ,1
                                                ,OFF
                                                
                                                ,0
                                                ,OFF
                                           };










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __uart_test_reg_dump(eUART_CH Ch)
{
    UINT32 i = 0x08;

    // UART Channel Register
    DEBUGMSG(MSGINFO, "-----------------------------------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "0x%08x: xxxxxxxx xxxxxxxx", APACHE_UART_0_BASE + (Ch*0x100000));
    
    for(; i<=0x28; i+=4)
    {
        if(!(i%0x20)) 
            DEBUGMSG(MSGINFO, "\n0x%08x:", APACHE_UART_0_BASE + (Ch*0x100000) + i);
        DEBUGMSG(MSGINFO, " %08x", REGRW32(APACHE_UART_0_BASE, (Ch*0x100000) + i));
    }
    
    DEBUGMSG(MSGINFO, "\n-----------------------------------------------------------------------------------\n");
}


static void __uart_test_change_triggerlevel(eUART_CH Ch, UINT8 Level)
{
    REGRW32(APACHE_UART_0_BASE, (Ch*0x100000)+0x08) = (Level<<6);
}


static eUART_CH __uart_test_get_used_port(void)
{
    eUART_CH Ch = UART_CH1;
    
    if(SYS_DEBUG_PORT == UART_CH1)
        Ch = UART_CH0;
    else if(SYS_DEBUG_PORT == UART_CH2)
        Ch = UART_CH3;
    else if(SYS_DEBUG_PORT == UART_CH3)
        Ch = UART_CH2;

    return Ch;
}


void APACHE_TEST_UART_SetDebugPort(BOOL OnOff)
{
    UINT32 Reg;

    Reg = REGRW32(APACHE_SYSCON_BASE, 0x1040);
    Reg &= ~(7<<16);

    if(OnOff == ON)
        Reg |= (2<<16); 
    
    REGRW32(APACHE_SYSCON_BASE, 0x1040) = Reg;
}


UINT32 APACHE_TEST_UART_GetBaudRateIdx(UINT32 BaudRate)
{
    UINT32 i;    
    UINT32 aBaudRate[] = { UT_BAUDRATE_300
                        , UT_BAUDRATE_600
                        , UT_BAUDRATE_1200
                        , UT_BAUDRATE_2400
                        , UT_BAUDRATE_4800
                        , UT_BAUDRATE_9600
                        , UT_BAUDRATE_19200
                        , UT_BAUDRATE_38400
                        , UT_BAUDRATE_57600
                        , UT_BAUDRATE_115200
                        , UT_BAUDRATE_230400
                        , UT_BAUDRATE_460800
                        , UT_BAUDRATE_921600
                        };


    for(i=0; i<13; i++)
    {
        if(aBaudRate[i] == BaudRate)
            break;
    }

    return i;
}


UINT32 APACHE_TEST_UART_GetBaudRate(UINT32 Idx)
{
    UINT32 aBaudRate[] = { UT_BAUDRATE_300
                        , UT_BAUDRATE_600
                        , UT_BAUDRATE_1200
                        , UT_BAUDRATE_2400
                        , UT_BAUDRATE_4800
                        , UT_BAUDRATE_9600
                        , UT_BAUDRATE_19200
                        , UT_BAUDRATE_38400
                        , UT_BAUDRATE_57600
                        , UT_BAUDRATE_115200
                        , UT_BAUDRATE_230400
                        , UT_BAUDRATE_460800
                        , UT_BAUDRATE_921600
                        };


    return aBaudRate[Idx];
}


void APACHE_TEST_UART_ChangeBaudRate(void)
{
    INT8 buf;
    UINT32 Idx;    
    UINT32 BaudRate = tUARTTestFlag.mUART_BaudRate;  

    
    APACHE_TEST_GetArrowKey_Help("BaudRate Up", "BaudRate  Down", NULL, NULL);
    DEBUGMSG(MSGINFO, "  > BaudRate Select    : %06d", BaudRate);


    Idx = APACHE_TEST_UART_GetBaudRateIdx(BaudRate);
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(Idx < 12)
                    ++Idx;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(Idx > 0)
                    --Idx;
            }
            BaudRate = APACHE_TEST_UART_GetBaudRate(Idx);
            DEBUGMSG(MSGINFO, "\r  > BaudRate Select    : %06d", BaudRate);
        }
    }

    tUARTTestFlag.mUART_BaudRate = BaudRate;
}


void APACHE_TEST_UART_ChangeTriggerLevel(void)
{
    INT8  buf;  
    UINT8 Level = tUARTTestFlag.mUART_TriggerLevel;  

    
    APACHE_TEST_GetArrowKey_Help("Trigger Level Up", "Trigger Level Down", NULL, NULL);
    DEBUGMSG(MSGINFO, "  > Trigger Level Select    : %d", Level);

    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(Level < 3)
                    ++Level;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(Level > 0)
                    --Level;
            }
            DEBUGMSG(MSGINFO, "\r  > Trigger Level Select    : %d", Level);
        }
    }

    tUARTTestFlag.mUART_TriggerLevel = Level;
}


void APACHE_TEST_UART_Isr(UINT32 irq)
{
    eUART_CH Ch = (eUART_CH)(irq - IRQ_NUM_UART0);
    INT8  buf;
    INT32 Reg;
    UINT8 IntInfo;


    Reg = ncLib_UART_Control(GCMD_UT_GET_INT_STS, Ch, CMD_END);
    IntInfo = (Reg&0xE)>>1;


    // Debug
    if(tUARTTestFlag.mUART_DebugCnt++ > 0x10000000)
        tUARTTestFlag.mUART_DebugCnt = 0;


    if(IntInfo == 1) // Tx Empty Status (Tx Done)
    {
        //DEBUGMSG(MSGINFO, " - Isr_%08x : Sts(0x%02x) - Tx\n", tUARTTestFlag.mUART_DebugCnt, (Reg&0xFF));   
    }
    else
    {
        DEBUGMSG(MSGINFO, " - Isr_%08x : Sts(0x%02x) - ", tUARTTestFlag.mUART_DebugCnt, (Reg&0xFF));    

        // Recived data available
        while(ncLib_UART_Control(GCMD_UT_GET_FIFO_CNT, Ch, CMD_END))
        {
            buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, Ch, CMD_END);

            if(buf != NC_FAILURE)
            {
                // Exit
                if(buf == ESCAPE_KEY)
                    tUARTTestFlag.mUART_TestRun = OFF; 

                // echo
                if(buf == RETURN_KEY)
                {
                    DEBUGMSG(MSGINFO, "\\n");
                    ncLib_UART_Control(GCMD_UT_PUT_STR, Ch, "\n", CMD_END); 
                }
                else
                {
                    DEBUGMSG(MSGINFO, "%c", buf);
                    ncLib_UART_Control(GCMD_UT_PUT_CHAR, Ch, buf, CMD_END);
                }
            }
        }
        DEBUGMSG(MSGINFO, "\n");

        if(tUARTTestFlag.mUART_DebugMsgOn == ON)
            __uart_test_reg_dump(Ch);
    }
    
}


void APACHE_TEST_UART_Isr_Init(eUART_CH Ch)
{
    tUARTTestFlag.mUART_DebugCnt = 0;
    
    // Register UART Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_REGISTER_INT
                      ,IRQ_NUM_UART0 + Ch
                      ,(PrHandler)APACHE_TEST_UART_Isr
                      ,CMD_END);
}


void APACHE_TEST_UART_Isr_DeInit(eUART_CH Ch)
{
    // Unregister UART Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT
                      ,IRQ_NUM_UART0 + Ch
                      ,CMD_END);
}


void APACHE_TEST_UART_Init(eUART_CH Ch, BOOL IntEn)
{
    tUART_PARAM tUARTParam;

    ncLib_UART_Open();
    
    // Set Operation Mode
    tUARTParam.mIntEn    = IntEn;
    tUARTParam.mBaudRate = tUARTTestFlag.mUART_BaudRate;
    tUARTParam.mSPS      = UT_SPS_DIS;
    tUARTParam.mLEN      = UT_DATA_8BIT;
    tUARTParam.mSTP      = UT_STOP_1BIT;
    tUARTParam.mEPS      = UT_EPS_DIS;
    tUARTParam.mPEN      = UT_PARITY_DIS;
    tUARTParam.mBRK      = UT_BRK_DIS;
    ncLib_UART_Control(GCMD_UT_INIT_CH, Ch, &tUARTParam, CMD_END);
}


void APACEH_TEST_UART_DeInit(eUART_CH Ch)
{
    ncLib_UART_Control(GCMD_UT_DEINIT_CH, Ch, CMD_END);

    ncLib_UART_Close();
}


void APACEH_TEST_UART_InOut(void)
{
    eUART_CH Ch; 
    eUART_CH TestCh;
    INT8 buf = 0;

    Ch = __uart_test_get_used_port();
    if(Ch == UART_CH0)      TestCh = UART_CH1;
    else if(Ch == UART_CH1) TestCh = UART_CH0;
    else if(Ch == UART_CH2) TestCh = UART_CH3;
    else if(Ch == UART_CH3) TestCh = UART_CH2;


    DEBUGMSG(MSGINFO, " > APACEH_TEST_UART_InOut - %06d\n", tUARTTestFlag.mUART_BaudRate);

    
    // Init UART Channel
    APACHE_TEST_UART_Init(Ch, tUARTTestFlag.mUART_IsrEn);


    // Register UART Interrupt Handler
    if(tUARTTestFlag.mUART_IsrEn == ENABLE)
    {
        __uart_test_change_triggerlevel(Ch, tUARTTestFlag.mUART_TriggerLevel); 
        APACHE_TEST_UART_Isr_Init(Ch);
    }


    // Display Command
    DEBUGMSG(MSGINFO, "\n>> Please enter your keypad [Exit: Esc]\n");
    ncLib_UART_Control(GCMD_UT_PUT_STR, Ch, "\r\n>> Please enter your keypad [Exit: Esc]\r\n", CMD_END);


    // Test Run
    tUARTTestFlag.mUART_TestRun = ON;
    while(tUARTTestFlag.mUART_TestRun)
    {   
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, TestCh, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Exit Key
            if(buf == ESCAPE_KEY)
                tUARTTestFlag.mUART_TestRun = OFF;

            // Echo 
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n"); 
                ncLib_UART_Control(GCMD_UT_PUT_STR, Ch, "\n", CMD_END); 
            }
            else
            {
                DEBUGMSG(MSGINFO, "%c", buf);
                ncLib_UART_Control(GCMD_UT_PUT_CHAR, Ch, buf, CMD_END);
            }
        }

        if(tUARTTestFlag.mUART_IsrEn == DISABLE)
        {
            // Toggle Channel
            if(TestCh == UART_CH0)      TestCh = UART_CH1;
            else if(TestCh == UART_CH1) TestCh = UART_CH0;
            else if(TestCh == UART_CH2) TestCh = UART_CH3;
            else if(TestCh == UART_CH3) TestCh = UART_CH2;
        }
    }
    
    DEBUGMSG(MSGINFO, "\n>> Test End \n", CMD_END);
    ncLib_UART_Control(GCMD_UT_PUT_STR, Ch, "\r\n>> Test End \r\n", CMD_END);


    // Unregister UART Interrupt Handler
    if(tUARTTestFlag.mUART_IsrEn == ENABLE)
        APACHE_TEST_UART_Isr_DeInit(Ch);

    
    // DeInit UART Channel
    APACEH_TEST_UART_DeInit(Ch);
}


void APACEH_TEST_UART_Input(void)
{
    eUART_CH Ch; 
    INT8 buf = 0;


    Ch = __uart_test_get_used_port();
    DEBUGMSG(MSGINFO, " > APACEH_TEST_UART_Input - %06d\n", tUARTTestFlag.mUART_BaudRate);

    
    // Init UART Channel
    APACHE_TEST_UART_Init(Ch, tUARTTestFlag.mUART_IsrEn);


    // Register UART Interrupt Handler
    if(tUARTTestFlag.mUART_IsrEn == ENABLE)
    {
        __uart_test_change_triggerlevel(Ch, tUARTTestFlag.mUART_TriggerLevel); 
        APACHE_TEST_UART_Isr_Init(Ch);
    }


    // Display Command
    ncLib_UART_Control(GCMD_UT_PUT_STR, Ch, "\r\n>> Please enter your keypad [Exit: Esc]\r\n", CMD_END);

    // Test Run
    tUARTTestFlag.mUART_TestRun = ON;
    while(tUARTTestFlag.mUART_TestRun)
    {   
        if(tUARTTestFlag.mUART_IsrEn == DISABLE) 
        {
            buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, Ch, CMD_END);

            if(buf != NC_FAILURE)
            {
                // Exit
                if(buf == ESCAPE_KEY)
                    tUARTTestFlag.mUART_TestRun = OFF; 
                
                // Echo 
                if(buf == RETURN_KEY)
                {
                    DEBUGMSG(MSGINFO, "\n");
                    ncLib_UART_Control(GCMD_UT_PUT_STR, Ch, "\n", CMD_END); 
                }
                else
                {
                    DEBUGMSG(MSGINFO, "%c", buf);
                    ncLib_UART_Control(GCMD_UT_PUT_CHAR, Ch, buf, CMD_END);
                }
            }
        }
    }
    
    ncLib_UART_Control(GCMD_UT_PUT_STR, Ch, "\r\n>> Test End \r\n", CMD_END);


    // Unregister UART Interrupt Handler
    if(tUARTTestFlag.mUART_IsrEn == ENABLE)
        APACHE_TEST_UART_Isr_DeInit(Ch);

    
    // DeInit UART Channel
    APACEH_TEST_UART_DeInit(Ch);
}

void APACEH_TEST_UART_Output_ext(void)
{
    eUART_CH Ch; 
    char buf[100];
    UINT8 Data;


    Ch = __uart_test_get_used_port(); 
    DEBUGMSG(MSGINFO, " > APACEH_TEST_UART_Output_ext - %06d\n", tUARTTestFlag.mUART_BaudRate);

    
    // Init UART Channel
    APACHE_TEST_UART_Init(Ch, DISABLE);


    while(1)
    {
        DEBUGMSG(MSGINFO, "\r   [Exit: '0xFF'] input >> ");   
        DBGSCANF(buf);

        Data = (UINT8)APACHE_TEST_AtoI(buf);
        
        if(Data == 0xFF)
            break;

        ncLib_UART_Control(GCMD_UT_PUT_CHAR, Ch, Data, CMD_END);
    }

    
    // DeInit UART Channel
    APACEH_TEST_UART_DeInit(Ch);
}


void APACEH_TEST_UART_Output(void)
{
    eUART_CH Ch; 
    INT8 Buff;


    //-----------------------------------------------------------------------------------------------
    // 0x21  0x22  0x23  0x24  0x25  0x26  0x27  0x28  0x29  0x2a  0x2b  0x2c  0x2d  0x2e  0x2f  0x30 
    //    !     "     #     $     %     &     '     (     )     *     +     ,     -     .     /     0
    //
    // 0x31  0x32  0x33  0x34  0x35  0x36  0x37  0x38  0x39  0x3a  0x3b  0x3c  0x3d  0x3e  0x3f  0x40 
    //    1     2     3     4     5     6     7     8     9     :     ;     <     =     >     ?     @
    //
    // 0x41  0x42  0x43  0x44  0x45  0x46  0x47  0x48  0x49  0x4a  0x4b  0x4c  0x4d  0x4e  0x4f  0x50 
    //    A     B     C     D     E     F     G     H     I     J     K     L     M     N     O     P
    //
    // 0x51  0x52  0x53  0x54  0x55  0x56  0x57  0x58  0x59  0x5a  0x5b  0x5c  0x5d  0x5e  0x5f  0x60 
    //    Q     R     S     T     U     V     W     X     Y     Z     [     \     ]     ^     _     `
    //
    // 0x61  0x62  0x63  0x64  0x65  0x66  0x67  0x68  0x69  0x6a  0x6b  0x6c  0x6d  0x6e  0x6f  0x70 
    //    a     b     c     d     e     f     g     h     i     j     k     l     m     n     o     p
    //
    // 0x71  0x72  0x73  0x74  0x75  0x76  0x77  0x78  0x79  0x7a  0x7b  0x7c  0x7d  0x7e 
    //    q     r     s     t     u     v     w     x     y     z     {     |     }     ~
    //-----------------------------------------------------------------------------------------------
 

    Ch = __uart_test_get_used_port();; 
    DEBUGMSG(MSGINFO, " > APACEH_TEST_UART_Output - %06d\n", tUARTTestFlag.mUART_BaudRate);

    
    // Init UART Channel
    APACHE_TEST_UART_Init(Ch, DISABLE);


    DEBUGMSG(MSGINFO, "\n--------------------------------\n");
    ncLib_UART_Control(GCMD_UT_PUT_STR, Ch, "\r\n--------------------------------\r\n", CMD_END);

    for(Buff=0x21; Buff<=0x7E; Buff++)
    {
        // set data
        DEBUGMSG(MSGINFO, "%c", Buff);
        ncLib_UART_Control(GCMD_UT_PUT_CHAR, Ch, Buff, CMD_END);


        // set "space"
        DEBUGMSG(MSGINFO, " ", Buff);
        ncLib_UART_Control(GCMD_UT_PUT_CHAR, Ch, ' ', CMD_END);        // 0x20 : space


        // set "carrige return" and "line feed"
        if(!(Buff%0x10))
        {
            DEBUGMSG(MSGINFO, "\n");
            ncLib_UART_Control(GCMD_UT_PUT_CHAR, Ch, '\r', CMD_END);    // 0x0D : carrige return
            ncLib_UART_Control(GCMD_UT_PUT_CHAR, Ch, '\n', CMD_END);    // 0x0A : line feed
        }
    }

    DEBUGMSG(MSGINFO, "\n--------------------------------\n");
    ncLib_UART_Control(GCMD_UT_PUT_STR, Ch, "\r\n--------------------------------\r\n", CMD_END);

    
    // DeInit UART Channel
    APACEH_TEST_UART_DeInit(Ch);
}


INT32 APACHE_TEST_UART_CUTMode(void)
{
    INT32 select;
    char buf[256];


    // Debug Port Enable
    APACHE_TEST_UART_SetDebugPort(ON);



    // Default Init Variable
    tUARTTestFlag = tUARTTestFlag_Def;


    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - UART                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " UART Controller                                            \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> UART Output Test                                       \n");
        DEBUGMSG(MSGINFO, " <2> UART Input Test                                        \n");
        DEBUGMSG(MSGINFO, " <3> UART Input/Output Test                                 \n");        
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <A> UART Interrupt %s                                      \n", (tUARTTestFlag.mUART_IsrEn)?"On":"Off"); 
        DEBUGMSG(MSGINFO, " <B> UART BaudRate Change     : UT_BAUDRATE_%d              \n", tUARTTestFlag.mUART_BaudRate); 
        DEBUGMSG(MSGINFO, " <C> UART TriggerLevel Change : %d                          \n", tUARTTestFlag.mUART_TriggerLevel); 
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ..%s                        \n",(tUARTTestFlag.mUART_DebugMsgOn)?"o":"x");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACEH_TEST_UART_Output();
            break;

            case 2:
                APACEH_TEST_UART_Input();
            break;

            case 3:
                APACEH_TEST_UART_InOut();
            break;   

            case 4:
                APACEH_TEST_UART_Output_ext();
            break;   
 
            case 10: // 'A'
                _REVERSE(tUARTTestFlag.mUART_IsrEn);
            break;

            case 11: // 'B'
                APACHE_TEST_UART_ChangeBaudRate();
            break;

            case 12: // 'C'
                APACHE_TEST_UART_ChangeTriggerLevel();
            break;
            
            case 35: // 'Z'
                _REVERSE(tUARTTestFlag.mUART_DebugMsgOn);
            break;
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to sub menu\n");
            goto Uart_Exit;
        }
    }

Uart_Exit:

    // Debug Port Enable
    APACHE_TEST_UART_SetDebugPort(OFF);

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_UART */


/* End Of File */

