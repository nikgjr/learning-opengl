

#include "App.h"
#include "ISP2M_Init.h"


#if TEST_MODE_ISP2M


//============================================================================
//      Definitions - Resolution
//============================================================================
// 256X64
#define SMALL_HTOT      1056
#define SMALL_HACT      256
#define SMALL_HBLK      800
#define SMALL_VTOT      80 
#define SMALL_VACT      64
#define SMALL_VBLK      16

// 1280X720
#define HD_HTOT         1650
#define HD_HACT         1280
#define HD_HBLK         370
#define HD_VTOT         750
#define HD_VACT         720
#define HD_VBLK         30

// 1920X1080
#define FHD_HTOT        2200
#define FHD_HACT        1920
#define FHD_HBLK        280
#define FHD_VTOT        1125
#define FHD_VACT        1080
#define FHD_VBLK        45

// 2048X1536
#define AHD_3M_HTOT     3000
#define AHD_3M_HACT     2048
#define AHD_3M_HBLK     952
#define AHD_3M_VTOT     1650
#define AHD_3M_VACT     1536
#define AHD_3M_VBLK     1536

// 2560X1440
#define QHD_HTOT        3300
#define QHD_HACT        2560
#define QHD_HBLK        740
#define QHD_VTOT        1500
#define QHD_VACT        1440
#define QHD_VBLK        60

// 3088X1728
#define MAX_R_HTOT      3188
#define MAX_R_HACT      3088
#define MAX_R_HBLK      100
#define MAX_R_VTOT      1750
#define MAX_R_VACT      1728
#define MAX_R_VBLK      22

//--------------------------------------------------------------
// ICDC resolution
//--------------------------------------------------------------
#define ICDC_HTOT           FHD_HTOT
#define ICDC_HACT           FHD_HACT
#define ICDC_HBLK           FHD_HBLK
#define ICDC_VTOT           FHD_VTOT
#define ICDC_VACT           FHD_VACT

//--------------------------------------------------------------
// FRC resolution
//--------------------------------------------------------------
// frc output
#define FRC_HTOT            FHD_HTOT
#define FRC_HACT            FHD_HACT
#define FRC_HBLK            FHD_HBLK
#define FRC_VACT            FHD_VACT
#define FRC_VBLK            FHD_VBLK

#define FRC_AFTER_HTOT      (FRC_HTOT*2)
#define FRC_AFTER_HACT      FRC_HACT
#define FRC_AFTER_HBLK      (FRC_AFTER_HTOT-FRC_AFTER_HACT)

//--------------------------------------------------------------
// resolution
//--------------------------------------------------------------

#define CROP_VACT           0
#define CROP_HACT           0

#define I_DS_VACT           FRC_VACT
#define I_DS_HACT           FRC_HACT

#define O_DS_VACT           FRC_VACT
#define O_DS_HACT           FRC_HACT

//#define LDC_MODE                ON
#define LDC_MODE                OFF

//#define DNR_WRAP_EN             ON
#define LUT_BASE_ADDR           0x817F0000  // ~ 0x81800000
#define LDC_BASE_ADDR           0x81433800  // ~ 0x8172AE00 (1.5Frame)
#define DNR_BASE_ADDR           0x81030000  // ~ 0x81433800 (1Frame + 16) * 2
#define DPC_BASE_ADDR           0x81000000
//============================================================================

//////////////////////////////////////////////////
// Interrupt
//////////////////////////////////////////////////

//////////////////////////////////////////////////
// define function
//////////////////////////////////////////////////



void delay(USHORT para);

// interrupt

// Linear calculator
void linear_cal(void);

// Divider
void divider(void);

// indirect test
void indirect_test(void);

// skip frame
void skip_frame_set(void);

// mipi set
void mipi_rx_set(void);

// DDR Memory
// input interface
void input_interface_set(void);

// input CDC
void input_cdc_set(void);

// input test pattern
void itp_set(void);

// ADC
void adc_set(void);

// DPC
void dpc_static_wr(void);
void dpc_static_rd(void);
void dpc_static_scan(void);
void dpc_live(void);
void dpc_sdram(void);

// AWB
void awb_adj_set(void);

// 3DNR
void NR3D_set(void);

// FRC
void FRC_set(void);

// LDC
void LDC_set(void);

// CSC
void csc_set(void);

// CI
void ci_set(void);

// OPD
void opd_set(void);
void opd_grid_set(void);

// BLC
void BLC_set(void);

// LSC
void LSC_set(void);

// Y-Process
void YPROC_set(void);
void CPROC_set(void);
void C_HL_set(void);
void C_SUP_AGC_set(void);

// HLC
void HLC_set(void);

// RGB BOX
void RGB_BOX_set(void);

// Private Mask
void PMASK_set(void);

// Flicker
void FLK_set(void);

// LPF
void LPF_set(void);

// AllNR, LTM
void ACCE_set(void);
void ALLNR_LTM_set(void);

// DS_Crop
void CROP_set(void);

// Down Scaler
void HV_DS_set(void);

// Edge Enhance
void BEDGE_set(void);
void HPF_set(void);

// Noise Reduction
void IHNR_set(void);

// BMD
void BMD_set(void);

// PGL
void PGL_set(void);

// YC444toYC422
void YC444toYC422_set(void);

// Output Test Pattern
void OTP_set(void);

// DEFOG
void DEFOG_set(void);

// IRIS
void IRIS_set(void);

void OUTPUT_FORMATTER_set(void);

// OSD
#define OSD_STYLE_MAX       8
#define OSD_COLOR_MAX       8
#define OSD_BOX_MAX         4
#define OSD_ATTR_TRANS_MAX  8
#define OSD_ATTR_BLK_MAX    4
#define OSD_ATTR_COLOR_MAX  16
#define OSD_GVRINDEX_MAX    1023
unsigned int    gl_gvr_hnum;
unsigned int    gl_gvr_vnum;
unsigned long   gl_fnt_addr;
unsigned char   Command_Clear(BOOL bWait, BOOL bStyle, BOOL bColor, BOOL bIndex, unsigned char Style, unsigned char Color, unsigned int Index);
unsigned char   Command_Change(BOOL bWait, BOOL bStyle, BOOL bColor, BOOL bIndex, unsigned int st_vpos, unsigned int st_hpos, unsigned int ed_vpos, unsigned int ed_hpos, unsigned char Style, unsigned char Color, unsigned int Index);
void            OSD_FontWrite(unsigned int gvr_hpos, unsigned int gvr_vpos, unsigned int fnt_style, unsigned int fnt_color, unsigned int fnt_index);
void            OSD_Init(void);
void OSD_set(void);


void APACHE_APP_InitISP2M(void)
{

   sim_printf("-- ISP TEST 2M --\n");    
//    ab_asi_io_write     (0x22222222, 0x90D000C4); // PLL0 Selection
    REGRW32(APACHE_SYSCON_BASE,0x268) = 0x23333333; // SEN Selection
    REGRW32(APACHE_ICU_BASE,0x00)   = 0x11100000;
    REGRW32(APACHE_ICU_BASE,0x04)   = 0x11111111;
    REGRW32(APACHE_ICU_BASE,0x08)   = 0x11111111;
    REGRW32(APACHE_ICU_BASE,0x0C)   = 0x11111111;
    REGRW32(APACHE_ICU_BASE,0x10)   = 0x11111111;
    REGRW32(APACHE_ICU_BASE,0x14)   = 0x11111111;
    REGRW32(APACHE_ICU_BASE,0x18)   = 0x11111111;
    REGRW32(APACHE_ICU_BASE,0x1C)   = 0x00000011;
    REGRW32(APACHE_SYSCON_BASE,0x1040) = 0x01300000; // SEN Selection
//    ab_asi_io_write     (0x20, 0x92003680); // BT1120 HSYNC INV
    sim_printf("DEBUG0\n");
    sim_printf("DEBUG1\n");
   // mipi_rx_set();
    input_cdc_set();


    //////////////////////////////////////////////////
    // Load Resgisters
    //////////////////////////////////////////////////
    input_interface_set();
    sim_printf("DEBUG4\n");
    ci_set();
    sim_printf("DEBUG5\n");
    linear_cal();
    sim_printf("DEBUG6\n");
    skip_frame_set();
    sim_printf("DEBUG7\n");
//    itp_set();
    sim_printf("DEBUG8\n");
    adc_set();
    sim_printf("DEBUG9\n");
    HLC_set();
    sim_printf("DEBUG10\n");
    awb_adj_set();
    sim_printf("DEBUG11\n");
    dpc_static_wr();
    sim_printf("DEBUG12\n");
    dpc_static_rd();
    sim_printf("DEBUG13\n");
    dpc_static_scan();
    sim_printf("DEBUG14\n");
    dpc_live();
    sim_printf("DEBUG15\n");
//    opd_set();
    sim_printf("DEBUG16\n");
//    NR3D_set();
    sim_printf("DEBUG17\n");
//  FRC_set();
    sim_printf("DEBUG18\n");
//    LDC_set();
    sim_printf("DEBUG19\n");
    csc_set();
    sim_printf("DEBUG20\n");
    BLC_set();
    sim_printf("DEBUG21\n");
    LSC_set();
    sim_printf("DEBUG22\n");
    YPROC_set();
    sim_printf("DEBUG23\n");
    CPROC_set();
    sim_printf("DEBUG24\n");
    C_SUP_AGC_set();
    sim_printf("DEBUG25\n");
    C_HL_set();
    sim_printf("DEBUG26\n");

//    RGB_BOX_set();
    sim_printf("DEBUG27\n");
    FLK_set();
    sim_printf("DEBUG28\n");
    LPF_set();
    sim_printf("DEBUG29\n");
    ACCE_set();
    sim_printf("DEBUG30\n");
   // ALLNR_LTM_set();
    sim_printf("DEBUG31\n");

    CROP_set();
    sim_printf("DEBUG32\n");
    HPF_set();
    sim_printf("DEBUG33\n");
    BEDGE_set();
    sim_printf("DEBUG34\n");
    IHNR_set();
    sim_printf("DEBUG35\n");

//    opd_grid_set();
    sim_printf("DEBUG36\n");
//    PMASK_set();
    sim_printf("DEBUG37\n");
//    BMD_set();
    sim_printf("DEBUG38\n");
    //    PGL_set();
    sim_printf("DEBUG39\n");
//    OSD_set();
    sim_printf("DEBUG40\n");
  //  DEFOG_set();
    sim_printf("DEBUG41\n");
    OUTPUT_FORMATTER_set();
    sim_printf("DEBUG42\n");


//    OTP_set();
    sim_printf("DEBUG44\n");
    YC444toYC422_set();
    sim_printf("DEBUG45\n");
    divider();
    sim_printf("DEBUG46\n");

    /////////////////////////////////////////////////////////
    // 1 frame
    /////////////////////////////////////////////////////////

#if (LDC_MODE == ON)
    ISPRW8(APACHE_ISP_BASE,0x2400 )=  0x01;  // LDC_EN
    ISPRW8(APACHE_ISP_BASE,0x2430 )=  0x33;  // LDC_EN
#endif
    sim_printf("DEBUG47\n");

    delay(100);
    delay(100);
    delay(100);
    delay(100);
    delay(100);
    delay(100);
    HV_DS_set();
    sim_printf("DEBUG48\n");

    //---DPC----
    // Save to SRAM
//    ISPRW8(APACHE_ISP_BASE,0x0400 )=  0x2B;  //DPC_STATIC_TEST   : [7]
                            //DPC_TEST_pre      : [6]
                            //DPC_LIVE_EN_pre   : [5]
                            //DPC_MANUAL_EN_pre : [4]
                            //DPC_STATIC_EN_pre : [3]
                            //DPC_MCU           : [2]
                            //DPC_SRAM          : [1]
                            //DPC_EN_pre        : [0]

    // Save to DDR
//    ISPRW8(APACHE_ISP_BASE,0x0681 )=  0x10;  // {3'd0,DPC_R_ENABLE,3'd0,DPC_W_ENABLE}
//    ISPRW8(APACHE_ISP_BASE,0x0400 )=  0x29;  //DPC_STATIC_TEST   : [7]
                            //DPC_TEST_pre      : [6]
                            //DPC_LIVE_EN_pre   : [5]
                            //DPC_MANUAL_EN_pre : [4]
                            //DPC_STATIC_EN_pre : [3]
                            //DPC_MCU           : [2]
                            //DPC_SRAM          : [1]
                            //DPC_EN_pre        : [0]
    //-----------
    /////////////////////////////////////////////////////////
    //   frame
    /////////////////////////////////////////////////////////
//    ISPRW8(APACHE_ISP_BASE,0x1E00 )=  0xC1;  // {DNR_MD_SEL[7:6],DNR_REG_SEL[5:4],DNR_REG_MODE[3],DNR_H_SWAP[2],DNR_V_SWAP[1],DNR_EN[0]};
//    ISPRW8(APACHE_ISP_BASE,0x1EB4 )=  0x09;
  sim_printf("DEBUG49\n");
    
    
    REGRW32(APACHE_SYSCON_BASE,0x0030) = 0xFFFFFFFF;
    REGRW32(APACHE_SYSCON_BASE,0x0030) = 0x00000000;

    REGRW32(APACHE_SYSCON_BASE,0x104C) = 0x00000001;

}

void delay(USHORT para)
{
    unsigned int i = 0;
    unsigned int delayPara = para;

    while(1)
    {
        if(i>delayPara)
            break;
        i++;
    }
}



void linear_cal()
{
    ISPRW8(APACHE_ISP_BASE,0x0032 )=  0x00;  // LINEAR_X0[15:8]
    ISPRW8(APACHE_ISP_BASE,0x0031 )=  0x00;  // LINEAR_X0[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0034 )=  0x00;  // LINEAR_X1[15:8]
    ISPRW8(APACHE_ISP_BASE,0x0033 )=  0x40;  // LINEAR_X1[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0036 )=  0x00;  // LINEAR_Y0[15:8]
    ISPRW8(APACHE_ISP_BASE,0x0035 )=  0x20;  // LINEAR_Y0[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0038 )=  0x00;  // LINEAR_Y1[15:8]
    ISPRW8(APACHE_ISP_BASE,0x0037 )=  0x60;  // LINEAR_Y1[7:0]
    ISPRW8(APACHE_ISP_BASE,0x003A )=  0x00;  // LINEAR_SRC_X0[15:8]
    ISPRW8(APACHE_ISP_BASE,0x0039 )=  0x20;  // LINEAR_SRC_X1[7:0]
}

void divider()
{
    ISPRW8(APACHE_ISP_BASE,0x0027 )=  0x08; // DIVISOR[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x0028 )=  0x00; // DIVISOR[15:8]
    ISPRW8(APACHE_ISP_BASE,0x0029 )=  0x82; // DIVIDEND[ 7:0 ]
    ISPRW8(APACHE_ISP_BASE,0x002A )=  0x00; // DIVIDEND[15:8 ]
    ISPRW8(APACHE_ISP_BASE,0x002B )=  0x00; // DIVIDEND[23:16]
    ISPRW8(APACHE_ISP_BASE,0x002C )=  0x00; // DIVIDEND[31:24]
}

void dpc_static_wr(void){
    ISPRW8(APACHE_ISP_BASE,0x003C )=  0x90;  // BANK

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x00;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x01;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x09;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x02;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x03;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x09;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x04;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x05;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x10;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x06;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x07;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x10;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x08;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x09;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x19;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x0A;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x0B;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x1B;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x0C;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x0D;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x1D;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x0E;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x0F;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x1F;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x10;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x01;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x11;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x01;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x12;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x01;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x13;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x03;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x14;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x01;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x15;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x05;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x16;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x01;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x17;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x07;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x18;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x01;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x19;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x09;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1A;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x01;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1B;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x0B;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1C;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x01;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1D;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x0D;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1E;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x01;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1F;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x0F;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1C;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x01;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1D;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x0D;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1E;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x01;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1F;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x0F;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x20;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x21;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x22;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x23;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x24;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x25;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x26;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x27;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x28;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x29;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x2A;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x2B;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x2C;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x2D;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x2E;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x2F;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x30;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x31;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x32;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x33;  // addr
    ISPRW8(APACHE_ISP_BASE,0x003E )=  0x00;  // WDATA
}

void dpc_static_rd(void)
{
#if 0 // alessio_
    UINT32 DPC_STATIC_0;
    UCHAR DPC_STATIC_1;
    UCHAR DPC_STATIC_2;
    UCHAR DPC_STATIC_3;
    UCHAR DPC_STATIC_4;
    UCHAR DPC_STATIC_5;
    UCHAR DPC_STATIC_6;
    UCHAR DPC_STATIC_7;
    UCHAR DPC_STATIC_8;
    UCHAR DPC_STATIC_9;
    UCHAR DPC_STATIC_10;
    UCHAR DPC_STATIC_11;
    UCHAR DPC_STATIC_12;
    UCHAR DPC_STATIC_13;
    UCHAR DPC_STATIC_14;
    UCHAR DPC_STATIC_15;
    UCHAR DPC_STATIC_16;
    UCHAR DPC_STATIC_17;
    UCHAR DPC_STATIC_18;
    UCHAR DPC_STATIC_19;
    UCHAR DPC_STATIC_20;
    UCHAR DPC_STATIC_21;
    UCHAR DPC_STATIC_22;
    UCHAR DPC_STATIC_23;
    UCHAR DPC_STATIC_24;
    UCHAR DPC_STATIC_25;
    UCHAR DPC_STATIC_26;
    UCHAR DPC_STATIC_27;
    UCHAR DPC_STATIC_28;
    UCHAR DPC_STATIC_29;
    UCHAR DPC_STATIC_30;
    UCHAR DPC_STATIC_31;
    UCHAR DPC_STATIC_32;
    UCHAR DPC_STATIC_33;
    UCHAR DPC_STATIC_34;
    UCHAR DPC_STATIC_35;
    UCHAR DPC_STATIC_36;
    UCHAR DPC_STATIC_37;
    UCHAR DPC_STATIC_38;
    UCHAR DPC_STATIC_39;
    UCHAR DPC_STATIC_40;
    UCHAR DPC_STATIC_41;
    UCHAR DPC_STATIC_42;
    UCHAR DPC_STATIC_43;
    UCHAR DPC_STATIC_44;
    UCHAR DPC_STATIC_45;
    UCHAR DPC_STATIC_46;
    UCHAR DPC_STATIC_47;
    UCHAR DPC_STATIC_48;
    UCHAR DPC_STATIC_49;
//    UCHAR DPC_STATIC_50;
    UCHAR DPC_STATIC_51;
//    UCHAR DPC_STATIC_52;

    ISPRW8(APACHE_ISP_BASE,0x003C )=  0x90;      // addr

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x00;      // addr
    DPC_STATIC_0 = ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x01;      // addr
    DPC_STATIC_1 = ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x02;      // addr
    DPC_STATIC_2 = ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x03;      // addr
    DPC_STATIC_3 = ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x04;      // addr
    DPC_STATIC_4 = ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x05;      // addr
    DPC_STATIC_5 = ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x06;      // addr
    DPC_STATIC_6 = ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x07;      // addr
    DPC_STATIC_7 = ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x08;      // addr
    DPC_STATIC_8 = ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x09;      // addr
    DPC_STATIC_9 = ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x0a;      // addr
    DPC_STATIC_10= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x0b;      // addr
    DPC_STATIC_11= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x0c;      // addr
    DPC_STATIC_12= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x0d;      // addr
    DPC_STATIC_13= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x0e;      // addr
    DPC_STATIC_14= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x0f;      // addr
    DPC_STATIC_15= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x10;      // addr
    DPC_STATIC_16= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x11;      // addr
    DPC_STATIC_17= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x12;      // addr
    DPC_STATIC_18= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x13;      // addr
    DPC_STATIC_19= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x14;      // addr
    DPC_STATIC_20= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x15;      // addr
    DPC_STATIC_21= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x16;      // addr
    DPC_STATIC_22= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x17;      // addr
    DPC_STATIC_23= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x18;      // addr
    DPC_STATIC_24= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x19;      // addr
    DPC_STATIC_25= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1a;      // addr
    DPC_STATIC_26= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1b;      // addr
    DPC_STATIC_27= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1c;      // addr
    DPC_STATIC_28= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1d;      // addr
    DPC_STATIC_29= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1e;      // addr
    DPC_STATIC_30= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x1f;      // addr
    DPC_STATIC_31= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x20;      // addr
    DPC_STATIC_32= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA

    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x21;      // addr
    DPC_STATIC_33= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x22;      // addr
    DPC_STATIC_34= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x23;      // addr
    DPC_STATIC_35= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x24;      // addr
    DPC_STATIC_36= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x25;      // addr
    DPC_STATIC_37= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x26;      // addr
    DPC_STATIC_38= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x27;      // addr
    DPC_STATIC_39= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x28;      // addr
    DPC_STATIC_40= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x29;      // addr
    DPC_STATIC_41= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x2a;      // addr
    DPC_STATIC_42= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x2b;      // addr
    DPC_STATIC_43= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x2c;      // addr
    DPC_STATIC_44= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x2d;      // addr
    DPC_STATIC_45= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x2e;      // addr
    DPC_STATIC_46= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x2f;      // addr
    DPC_STATIC_47= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x30;      // addr
    DPC_STATIC_48= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x31;      // addr
    DPC_STATIC_49= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x32;      // addr
    DPC_STATIC_40= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0x33;      // addr
    DPC_STATIC_51= ISPRW8(APACHE_ISP_BASE,0x003E);      // RDATA
#endif
}

void dpc_static_scan(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0400 )=  0x23;  //DPC_STATIC_TEST   : [7]
                            //DPC_TEST_pre      : [6]
                            //DPC_LIVE_EN_pre   : [5]
                            //DPC_MANUAL_EN_pre : [4]
                            //DPC_STATIC_EN_pre : [3]
                            //DPC_MCU           : [2]
                            //DPC_SRAM          : [1]
                            //DPC_EN_pre        : [0]

    ISPRW8(APACHE_ISP_BASE,0x0401 )=  0x5F;  //DPC_STATIC_VIEW     : [7]
                            //DPC_STATIC_SCAN     : [6]
                            //DPC_STATIC_SCAN2    : [4]
                            //DPC_STATIC_TH[11:8] : [3:0]

    ISPRW8(APACHE_ISP_BASE,0x0402 )=  0x00;  // DPC_STATIC_TH[7:0];

//    ISPRW8(APACHE_ISP_BASE,0x044E )=  0x78;  // DPC_BLACK_STATIC_SCAN   : [5]
                            // DPC_BLACK_STATIC_EN_pre : [4]
                            // DPC_BLACK_STATIC_TEST   : [3]
                            // DPC_LINE_DEBUG          : [2:0]

    ISPRW8(APACHE_ISP_BASE,0x044F )=  0xFF;  // DPC_MAX_NUM[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0450 )=  0x10;  // DPC_BLACK_STATIC_TH[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0451 )=  0x30;  // DPC_MAX_NUM[10:8]         : [6:4] 
                            // DPC_BLACK_STATIC_TH[11:8] : [3:0]

    ISPRW8(APACHE_ISP_BASE,0x0482 )=  0x01;  // DPC_W_SCAN_AREA_START_X[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0483 )=  0x01;  // DPC_W_SCAN_AREA_START_Y[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0484 )=  0x80;  // DPC_W_SCAN_AREA_WIDTH[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0485 )=  0x38;  // DPC_W_SCAN_AREA_HEIGHT[7:0];

    ISPRW8(APACHE_ISP_BASE,0x0486 )=  0x00;  // DPC_W_SCAN_AREA_START_X[11:8] : [7:4] 
                            // DPC_W_SCAN_AREA_START_Y[11:8] : [3:0]

    ISPRW8(APACHE_ISP_BASE,0x0487 )=  0x74;  // DPC_W_SCAN_AREA_WIDTH[11:8]  : [7:4]
                            // DPC_W_SCAN_AREA_HEIGHT[11:8] : [3:0]

    ISPRW8(APACHE_ISP_BASE,0x0488 )=  0x01;  // DPC_B_SCAN_AREA_START_X[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0489 )=  0x01;  // DPC_B_SCAN_AREA_START_Y[7:0];
    ISPRW8(APACHE_ISP_BASE,0x048A )=  0x80;  // DPC_B_SCAN_AREA_WIDTH[7:0];
    ISPRW8(APACHE_ISP_BASE,0x048B )=  0x38;  // DPC_B_SCAN_AREA_HEIGHT[7:0];

    ISPRW8(APACHE_ISP_BASE,0x048C )=  0x00;  // DPC_B_SCAN_AREA_START_X[11:8] : [7:4]
                            // DPC_B_SCAN_AREA_START_Y[11:8] : [3:0]

    ISPRW8(APACHE_ISP_BASE,0x048D )=  0x74;  // DPC_B_SCAN_AREA_WIDTH[11:8]  : [7:4]
                            // DPC_B_SCAN_AREA_HEIGHT[11:8] : [3:0]
}

void dpc_live(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0433 )=  0x05;  // {2'd0,DPC_OUT_SEL[1:0],DPC_MEDIAN_SEL,V_SWAP,H_SWAP,DPC_K_MAX}
    ISPRW8(APACHE_ISP_BASE,0x0434 )=  0x04;  // {4'd0,DPC_DA_GAIN[3:0]}
    ISPRW8(APACHE_ISP_BASE,0x0435 )=  0x32;  // DPC_K_TH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0436 )=  0x08;  // DPC_DIFF_GAIN[7:0]

    ISPRW8(APACHE_ISP_BASE,0x0437 )=  0xFF;  // DPC_BLACK_TH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0438 )=  0x00;  // {4'd0,DPC_BLACK_TH[11:8]}
    ISPRW8(APACHE_ISP_BASE,0x0439 )=  0x96;  // DPC_BLACK_LOW[7:0]
    ISPRW8(APACHE_ISP_BASE,0x043A )=  0xFA;  // DPC_BLACK_HIGH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x043B )=  0x34;  // DPC_BLACK_H_OFFSET[7:4]
                            // DPC_BLACK_L_OFFSET[3:0]

    ISPRW8(APACHE_ISP_BASE,0x043C )=  0xFF;  // DPC_WHITE_TH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x043D )=  0x0C;  // {4'd0,DPC_WHITE_TH[11:8]}
    ISPRW8(APACHE_ISP_BASE,0x043E )=  0xC8;  // DPC_WHITE_LOW[7:0]
    ISPRW8(APACHE_ISP_BASE,0x043F )=  0xD2;  // DPC_WHITE_HIGH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0440 )=  0x12;  // DPC_WHITE_H_OFFSET[7:4]
                            // DPC_WHITE_L_OFFSET[3:0]

    ISPRW8(APACHE_ISP_BASE,0x0441 )=  0x32;  // DPC_ADD_K_BASE[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0442 )=  0xC8;  // DPC_ADD_K_MAX[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0443 )=  0x02;  // {4'd0,DPC_DIR_OFFSET1[3:0]}
    ISPRW8(APACHE_ISP_BASE,0x0444 )=  0x78;  // DPC_DIR_OFFSET2[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0445 )=  0x00;  // {4'd0,DPC_DIR_OFFSET2[11:8]}
    ISPRW8(APACHE_ISP_BASE,0x0446 )=  0xF4;  // DPC_AROUND_TH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0447 )=  0x01;  // {4'd0,DPC_AROUND_TH[11:8]}
    ISPRW8(APACHE_ISP_BASE,0x0448 )=  0x08;  // {4'd0,DPC_CW}
    }

void dpc_sdram(void)
{
//    ISPRW8(APACHE_ISP_BASE,0x0680 )=  0x08;  // {4'd0, DPC_W_OVERFOLW, DPC_W_FRAME_DONE, DPC_R_OVERFLOW, DPC_R_FRAME_DONE}
    ISPRW8(APACHE_ISP_BASE,0x0681 )=  0x01;  // {3'd0,DPC_R_ENABLE,3'd0,DPC_W_ENABLE}
    ISPRW8(APACHE_ISP_BASE,0x0682 )=  0xFF & (DPC_BASE_ADDR);  // {DPC_R_READ_ADDR[7:0]}
    ISPRW8(APACHE_ISP_BASE,0x0683 )=  0xFF & (DPC_BASE_ADDR >> 8);  // {DPC_R_READ_ADDR[15:8]}
    ISPRW8(APACHE_ISP_BASE,0x0684 )=  0xFF & (DPC_BASE_ADDR >> 16);  // {DPC_R_READ_ADDR[23:16]}
    ISPRW8(APACHE_ISP_BASE,0x0685 )=  0xFF & (DPC_BASE_ADDR >> 24);  // {DPC_R_READ_ADDR[31:24]}
    ISPRW8(APACHE_ISP_BASE,0x0686 )=  0x04;  // {4'd0,DPC_R_BURST_CTRL}
    ISPRW8(APACHE_ISP_BASE,0x0687 )=  0xFF & (DPC_BASE_ADDR);        // {DPC_W_WRITE_ADDR[7:0]}
    ISPRW8(APACHE_ISP_BASE,0x0688 )=  0xFF & (DPC_BASE_ADDR >> 8);   // {DPC_W_WRITE_ADDR[15:8]}
    ISPRW8(APACHE_ISP_BASE,0x0689 )=  0xFF & (DPC_BASE_ADDR >> 16);  // {DPC_W_WRITE_ADDR[23:16]}
    ISPRW8(APACHE_ISP_BASE,0x068A )=  0xFF & (DPC_BASE_ADDR >> 24);  // {DPC_W_WRITE_ADDR[31:24]}
    ISPRW8(APACHE_ISP_BASE,0x068B )=  0x05;  // {4'd0,DPC_W_BURST_CTRL}
}

void ci_set(void)
{
     ISPRW8(APACHE_ISP_BASE,0x1200 )=  0x12;  // CI_LINE_MEM_INIT[7]
                             // CI_H_TOTAL_AUTO[6]
                             // CI_SIZE_CUSTOM[5]
                             // CI_HSYNC_BYPASS[4]
                             // JCIA_H_SWAP[2]
                             // JCIA_VSWAP[1] 
     ISPRW8(APACHE_ISP_BASE,0x1206 )=  0x00;  // {5'h0,i_gamma_pre};
     ISPRW8(APACHE_ISP_BASE,0x1207 )=  0x00;  // {2'h0,
                             //  CI_GDIR_SEL,
                             //  2'h0,
                             //  i_gdir_disable_pre,
                             //  i_rb_no_refer_pre};
     ISPRW8(APACHE_ISP_BASE,0x1208 )=  0x00;  // {i_debug_ch  };
     ISPRW8(APACHE_ISP_BASE,0x1209 )=  0x00;  // {i_debug_mode};
     ISPRW8(APACHE_ISP_BASE,0x120A )=  0x00;  // {i_debug_ctrl};:

     ISPRW8(APACHE_ISP_BASE,0x120B )=  0x1C;  // {i_hmg_thr };
     ISPRW8(APACHE_ISP_BASE,0x120C )=  0x14;  // {i_hmg_diff};
     ISPRW8(APACHE_ISP_BASE,0x120D )=  0x23;  // {2'h0,
                             //  i_hdir_diff_th_method,
                             //  2'h0,
                             //  i_hdir_diff_method,
                             //  i_hdir_hmg_method};
     ISPRW8(APACHE_ISP_BASE,0x120E )=  0x30;  // {      i_min_diff_thr            };
     ISPRW8(APACHE_ISP_BASE,0x120F )=  0x08;  // {      i_diff_thr                };
     ISPRW8(APACHE_ISP_BASE,0x1210 )=  0x05;  // {3'h0,
                             //  i_g_method,    
                             //  i_high_freq_old
                             //  i_res_enhance_pre,
                             //  i_diff_uv_en,
                             //  i_high_freq_en};

     ISPRW8(APACHE_ISP_BASE,0x1211 )=  0x00;  // i_ci_dither_en,
                             // 4'h0, i_ci_dither_level

     ISPRW8(APACHE_ISP_BASE,0x1212 )=  0x00;  // {      ci_dir_tab                };

     ISPRW8(APACHE_ISP_BASE,0x1213 )=  0x20;  // {      i_gdiff_thr   [7:0]       };
     ISPRW8(APACHE_ISP_BASE,0x1214 )=  0x00;  // {      i_gdiff_thr   [9:8]       };
     ISPRW8(APACHE_ISP_BASE,0x1215 )=  0x48;  // {      i_gdiff_thr2  [7:0]       };
     ISPRW8(APACHE_ISP_BASE,0x1216 )=  0x00;  // {      i_gdiff_thr2  [9:8]       };
     ISPRW8(APACHE_ISP_BASE,0x1217 )=  0x38;  // {      i_gdiff_thr3  [7:0]       };
     ISPRW8(APACHE_ISP_BASE,0x1218 )=  0x00;  // {      i_gdiff_thr3  [9:8]       };
     ISPRW8(APACHE_ISP_BASE,0x1219 )=  0x01;  // {3'h0,i_flat_mix_src,2'h0,i_flat_mix_mode[1:0]};
     ISPRW8(APACHE_ISP_BASE,0x121A )=  0x18;  // {2'h0,i_jcia_flat_th[5:0]       };
     ISPRW8(APACHE_ISP_BASE,0x121B )=  0x20;  // {      i_jcia_flat_alpha[7:0]    };
     ISPRW8(APACHE_ISP_BASE,0x121C )=  0x00;  // {7'h0, i_jcia_bw_mode            };
}

void opd_set(void)
{

}

void opd_grid_set(void)
{

}

void skip_frame_set(void)
{
    // AR0330 : 2048x1536 Total: 2240x1548
    ISPRW8(APACHE_ISP_BASE,0x0100 )=  0x00;  // SF_SKIP_FRAME_EN_pre[0]
    ISPRW8(APACHE_ISP_BASE,0x0101 )=  0x00;  // SF_SKIP_PERIOD_pre[5:0]
    ISPRW8(APACHE_ISP_BASE,0x0102 )=  0x00;  // SF_SKIP_AUTO_EN_pre[0]
    ISPRW8(APACHE_ISP_BASE,0x0103 )=  0x00;  // SF_SKIP_TH[ 7: 0]
    ISPRW8(APACHE_ISP_BASE,0x0104 )=  0x00;  // SF_SKIP_TH[15: 8]
    ISPRW8(APACHE_ISP_BASE,0x0105 )=  0x00;  // SF_SKIP_TH[22:16]
    ISPRW8(APACHE_ISP_BASE,0x0106 )=  0x00;  // SF_FRAME_PATTERN_pre[ 7: 0]
    ISPRW8(APACHE_ISP_BASE,0x0107 )=  0x00;  // SF_FRAME_PATTERN_pre[15: 8]
    ISPRW8(APACHE_ISP_BASE,0x0108 )=  0x00;  // SF_FRAME_PATTERN_pre[23:16]
    ISPRW8(APACHE_ISP_BASE,0x0109 )=  0x00;  // SF_FRAME_PATTERN_pre[31:24]
    ISPRW8(APACHE_ISP_BASE,0x010A )=  0x00;  // SF_FRAME_PATTERN_pre[39:32]
    ISPRW8(APACHE_ISP_BASE,0x010B )=  0x00;  // SF_FRAME_PATTERN_pre[47:40]
    ISPRW8(APACHE_ISP_BASE,0x010C )=  0x00;  // SF_FRAME_PATTERN_pre[55:48]
    ISPRW8(APACHE_ISP_BASE,0x010D )=  0x00;  // SF_FRAME_PATTERN_pre[59:56]
    ISPRW8(APACHE_ISP_BASE,0x010E )=  0x00;  // SF_INIT_SKIP[5:0]
    ISPRW8(APACHE_ISP_BASE,0x010F )=  0x00;  // SF_INIT_FRAME_PATTERN[ 7: 0]
    ISPRW8(APACHE_ISP_BASE,0x0110 )=  0x00;  // SF_INIT_FRAME_PATTERN[15: 8]
    ISPRW8(APACHE_ISP_BASE,0x0111 )=  0x00;  // SF_INIT_FRAME_PATTERN[23:16]
    ISPRW8(APACHE_ISP_BASE,0x0112 )=  0x00;  // SF_INIT_FRAME_PATTERN[31:24]
    ISPRW8(APACHE_ISP_BASE,0x0113 )=  0x00;  // SF_INIT_FRAME_PATTERN[39:32]
    ISPRW8(APACHE_ISP_BASE,0x0114 )=  0x00;  // SF_INIT_FRAME_PATTERN[47:40]
    ISPRW8(APACHE_ISP_BASE,0x0115 )=  0x00;  // SF_INIT_FRAME_PATTERN[55:48]
    ISPRW8(APACHE_ISP_BASE,0x0116 )=  0x00;  // SF_INIT_FRAME_PATTERN[59:56]
}

void mipi_rx_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0007 )=  ISPRW8(APACHE_ISP_BASE,0x0007 | 0x40); // {CLK_MIPI_MSEL[7:6], 1'h0,ADC_PD,ADC_RUN,ADC_CLK_P,ADC_SEL_AUTO,ADC_EOC_FREE}
    ISPRW8(APACHE_ISP_BASE,0x00F0 )=  0x8A;  //  {5'd0,O_CLK_SRC_SEL,r_LVDS_IP_SEL,O_LVDS_IP_SEL_CLK};

    ISPRW8(APACHE_ISP_BASE,0x1908 )=  0x00;  //  CSI2_RESETN[0]
    ISPRW8(APACHE_ISP_BASE,0x1909 )=  0x00;  //      
    ISPRW8(APACHE_ISP_BASE,0x190A )=  0x00;  //      
    ISPRW8(APACHE_ISP_BASE,0x190B )=  0x00;  //      
    ISPRW8(APACHE_ISP_BASE,0x1944 )=  0x00;  //  DPHY_RSTZ[0]
    ISPRW8(APACHE_ISP_BASE,0x1945 )=  0x00;  //  
    ISPRW8(APACHE_ISP_BASE,0x1946 )=  0x00;  //  
    ISPRW8(APACHE_ISP_BASE,0x1947 )=  0x00;  //  
    ISPRW8(APACHE_ISP_BASE,0x1940 )=  0x00;  //  PHY_SHUTDOWNZ[0]
    ISPRW8(APACHE_ISP_BASE,0x1941 )=  0x00;  //  
    ISPRW8(APACHE_ISP_BASE,0x1942 )=  0x00;  //  
    ISPRW8(APACHE_ISP_BASE,0x1943 )=  0x00;  //  
    ISPRW8(APACHE_ISP_BASE,0x0005 )=  0xDF & (ISPRW8(APACHE_ISP_BASE,0x0005));   // PLL0 KDIV = 2  (0)  & OD = 2 (1), MIPI_SRC_SEL[7:6], CLK_MIPI_SEL[5]

    ISPRW8(APACHE_ISP_BASE,0x1A80 )=  0x00;  //  PC[5], EFN[4:2], SyncMode[1:0]
    ISPRW8(APACHE_ISP_BASE,0x1A81 )=  0x7E;  //  SMT_D[7:4], SMT_C[3:0]
    ISPRW8(APACHE_ISP_BASE,0x1A82 )=  0x01;  //  ipi_fifo_sleep[0]
    ISPRW8(APACHE_ISP_BASE,0x1A84 )=  0x00;  //  rxskewcalhs[0]

    ISPRW8(APACHE_ISP_BASE,0x1A90 )=  0x02;  //  (R)header_fs_flag[7], (R)header_fe_flag[6], (R)header_ls_flag[5], (R)header_le_flag[4]
                            //  header_clear[2], header_read[1], header_read_done[0]
    ISPRW8(APACHE_ISP_BASE,0x1A91 )=  0x00;  //  Target_VC
    ISPRW8(APACHE_ISP_BASE,0x1A92 )=  0x2C;  //  Target Data Type, RAW12
  //ISPRW8(APACHE_ISP_BASE,0x1A92 )=  0x2B;  //  Target Data Type, RAW10
  //ISPRW8(APACHE_ISP_BASE,0x1A92 )=  0x2A;  //  Target Data Type, RAW8
    ISPRW8(APACHE_ISP_BASE,0x1A93 )=  0x0A;  //  Target Line[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1A94 )=  0x00;  //  Target Line[15:8]

    ISPRW8(APACHE_ISP_BASE,0x1904 )=  0x03;  //  0: 1 Lane,    1: 2 Lanes,    3: 4 Lanes
    ISPRW8(APACHE_ISP_BASE,0x1905 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1906 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1907 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1980 )=  0x01;  //  [0] ipi_mode[ - 0:Camera timing 1:Controller timing
    ISPRW8(APACHE_ISP_BASE,0x1981 )=  0x01;  //  [8] ipi_color_com - 0:48bit interface, 1:16bit interface
    ISPRW8(APACHE_ISP_BASE,0x1982 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1983 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1984 )=  0x00;  //  [1:0] IP_VCID
    ISPRW8(APACHE_ISP_BASE,0x1985 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1986 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1987 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1988 )=  0x2C;  //  [5:0] IP_DATA_TYPE, RAW12
  //ISPRW8(APACHE_ISP_BASE,0x1988 )=  0x2B;  //  [5:0] IP_DATA_TYPE, RAW10
  //ISPRW8(APACHE_ISP_BASE,0x1988 )=  0x2A;  //  [5:0] IP_DATA_TYPE, RAW8
    ISPRW8(APACHE_ISP_BASE,0x1989 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x198A )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x198B )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1990 )=  0x32;  //  [11:0] IPI_HSA_TIME
    ISPRW8(APACHE_ISP_BASE,0x1991 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1992 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1993 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1994 )=  0x30;  //  [11:0] IPI_HBP_TIME
    ISPRW8(APACHE_ISP_BASE,0x1995 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1996 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1997 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x1998 )=  0x14;  //  [11:0] IPI_HBD_TIME
    ISPRW8(APACHE_ISP_BASE,0x1999 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x199A )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x199B )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x199C )=  0x98;  //  [14:0] IPI_HLINE_TIME
    ISPRW8(APACHE_ISP_BASE,0x199D )=  0x08;  //
    ISPRW8(APACHE_ISP_BASE,0x199E )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x199F )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x19B0 )=  0x01;  //  [9:0] IPI_VSA_LINES
    ISPRW8(APACHE_ISP_BASE,0x19B1 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x19B2 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x19B3 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x19B4 )=  0x01;  //  [9:0] IPI_VBP_LINES
    ISPRW8(APACHE_ISP_BASE,0x19B5 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x19B6 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x19B7 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x19B8 )=  0x2B;  //  [9:0] IPI_VFP_LINES
    ISPRW8(APACHE_ISP_BASE,0x19B9 )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x19BA )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x19BB )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x19BC )=  0x38;  //  [13:0] IPI_VACTIVE_LINES
    ISPRW8(APACHE_ISP_BASE,0x19BD )=  0x04;  //
    ISPRW8(APACHE_ISP_BASE,0x19BE )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x19BF )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x198C )=  0x00;  //  [7:0] IPI_MEM_FLUSH
    ISPRW8(APACHE_ISP_BASE,0x198D )=  0x01;  //
    ISPRW8(APACHE_ISP_BASE,0x198E )=  0x00;  //
    ISPRW8(APACHE_ISP_BASE,0x198F )=  0x00;  //

    ISPRW8(APACHE_ISP_BASE,0x1908 )=  0x01;  //  CSI2_RESETN[0]
    ISPRW8(APACHE_ISP_BASE,0x1909 )=  0x00;  //      
    ISPRW8(APACHE_ISP_BASE,0x190A )=  0x00;  //      
    ISPRW8(APACHE_ISP_BASE,0x190B )=  0x00;  //  
    ISPRW8(APACHE_ISP_BASE,0x1944 )=  0x01;  //  DPHY_RSTZ[0]
    ISPRW8(APACHE_ISP_BASE,0x1945 )=  0x00;  //  
    ISPRW8(APACHE_ISP_BASE,0x1946 )=  0x00;  //  
    ISPRW8(APACHE_ISP_BASE,0x1947 )=  0x00;  //  
    ISPRW8(APACHE_ISP_BASE,0x1940 )=  0x01;  //  PHY_SHUTDOWNZ[0]
    ISPRW8(APACHE_ISP_BASE,0x1941 )=  0x00;  //  
    ISPRW8(APACHE_ISP_BASE,0x1942 )=  0x00;  //  
    ISPRW8(APACHE_ISP_BASE,0x1943 )=  0x00;  //  

    // Sensor Software Reset
    ISPRW8(APACHE_ISP_BASE,0x0001  )=  0x00;   // {O_SWRESET_AHD, O_SWRESET_DIGIT,O_SWRESET_MCU_PERI,O_SWRESET_SEN,O_SWRESET_LCDC,O_SWRESET_PCLK,O_SWRESET_ISP,O_SWRESET_ENC};
    ISPRW8(APACHE_ISP_BASE,0x00F5  )=  0x03;

    ISPRW8(APACHE_ISP_BASE,0x1AC0 )=  0x30;  // {2'h0,MIPI_RX0_DT30_SET_DT};
    ISPRW8(APACHE_ISP_BASE,0x1AC1 )=  0x31;  // {2'h0,MIPI_RX0_DT31_SET_DT};
    ISPRW8(APACHE_ISP_BASE,0x1AC2 )=  0x32;  // {2'h0,MIPI_RX0_DT32_SET_DT};
    ISPRW8(APACHE_ISP_BASE,0x1AC3 )=  0x33;  // {2'h0,MIPI_RX0_DT33_SET_DT};
    ISPRW8(APACHE_ISP_BASE,0x1AC4 )=  0x34;  // {2'h0,MIPI_RX0_DT34_SET_DT};
    ISPRW8(APACHE_ISP_BASE,0x1AC5 )=  0x35;  // {2'h0,MIPI_RX0_DT35_SET_DT};
    ISPRW8(APACHE_ISP_BASE,0x1AC6 )=  0x36;  // {2'h0,MIPI_RX0_DT36_SET_DT};
    ISPRW8(APACHE_ISP_BASE,0x1AC7 )=  0x37;  // {2'h0,MIPI_RX0_DT37_SET_DT};
    ISPRW8(APACHE_ISP_BASE,0x1AC8 )=  0x00;  // {3'h0,MIPI_RX0_CAP_SEL,2'h0,MIPI_RX0_RAW16_SET,MIPI_RX0_RAW20_SET};
    ISPRW8(APACHE_ISP_BASE,0x1AC9 )=  0x1C;  // {2'h0, MIPI_RX0_VSYNC_POL,MIPI_RX0_HSYNC_POL,MIPI_RX0_CDC_HSIZE_SET,MIPI_RX0_HACT_SEL,MIPI_RX0_CDC_OUT_SEL,MIPI_RX0_CDC_SEL};
    ISPRW8(APACHE_ISP_BASE,0x1ACA )=  0x00;  // {MIPI_RX0_CDC_DLY[7:0]};
    ISPRW8(APACHE_ISP_BASE,0x1ACB )=  0x00;  // {4'h0,MIPI_RX0_CDC_DLY[11:8]};
    ISPRW8(APACHE_ISP_BASE,0x1ACC )=  0x00;  // {MIPI_RX0_CDC_HSIZE[7:0]};
    ISPRW8(APACHE_ISP_BASE,0x1ACD )=  0x00;  // {4'h0,MIPI_RX0_CDC_HSIZE[11:8]};
    ISPRW8(APACHE_ISP_BASE,0x1ACE )=  0x24;  // {2'h0,MIPI_RX0_SCH_SEL,MIPI_RX0_MCH_SEL,MIPI_RX0_LCH_SEL};
}


void input_interface_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0120 )=  0x4A;  // IIF_CLK_EN_SEL      : [6]
                            // IIF_MC2_EN          : [5]
                            // IIF_MC1_EN          : [4]
                            // IIF_IS_INPUT_HACT   : [3]
                            // IIF_INPUT_VSYNC_POL : [2]
                            // IIF_INPUT_HSYNC_POL : [1]

    ISPRW8(APACHE_ISP_BASE,0x0121 )=  0x00;  // IIF_HACT_F_PORCH_VSYNC[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x0122 )=  0x00;  // IIF_HACT_F_PORCH_VSYNC[12:8]
    ISPRW8(APACHE_ISP_BASE,0x0123 )=  0x00;  // IIF_HACT_F_PORCH_HSYNC[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x0124 )=  0x00;  // IIF_HACT_F_PORCH_HSYNC[12:8]
    ISPRW8(APACHE_ISP_BASE,0x0125 )=  0x38;  // IIF_HACT_HEIGHT[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x0126 )=  0x04;  // IIF_HACT_HEIGHT[12:8]
    ISPRW8(APACHE_ISP_BASE,0x0127 )=  0x80;  // IIF_HACT_WIDTH[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x0128 )=  0x07;  // IIF_HACT_WIDTH[12:8]
    ISPRW8(APACHE_ISP_BASE,0x0129 )=  0x00;  // IIF_OBACT1_F_PORCH_VSYNC[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x012A )=  0x00;  // IIF_OBACT1_F_PORCH_VSYNC[12:8]
    ISPRW8(APACHE_ISP_BASE,0x012B )=  0x00;  // IIF_OBACT1_F_PORCH_HSYNC[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x012C )=  0x00;  // IIF_OBACT1_F_PORCH_HSYNC[12:8]
    ISPRW8(APACHE_ISP_BASE,0x012D )=  0x00;  // IIF_OBACT1_HEIGHT[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x012E )=  0x00;  // IIF_OBACT1_HEIGHT[12:8]
    ISPRW8(APACHE_ISP_BASE,0x012F )=  0x00;  // IIF_OBACT1_WIDTH[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x0130 )=  0x00;  // IIF_OBACT1_WIDTH[12:8]

//    ISPRW8(APACHE_ISP_BASE,0x0131 )=  0x00;    //
    ISPRW8(APACHE_ISP_BASE,0x0132 )=  0x01;  // IIF_MC1_ASSIGN_BIT_01[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0133 )=  0x02;  // IIF_MC1_ASSIGN_BIT_02[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0134 )=  0x03;  // IIF_MC1_ASSIGN_BIT_03[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0135 )=  0x04;  // IIF_MC1_ASSIGN_BIT_04[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0136 )=  0x05;  // IIF_MC1_ASSIGN_BIT_05[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0137 )=  0x06;  // IIF_MC1_ASSIGN_BIT_06[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0138 )=  0x07;  // IIF_MC1_ASSIGN_BIT_07[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0139 )=  0x08;  // IIF_MC1_ASSIGN_BIT_08[4:0]
    ISPRW8(APACHE_ISP_BASE,0x013A )=  0x09;  // IIF_MC1_ASSIGN_BIT_09[4:0]
    ISPRW8(APACHE_ISP_BASE,0x013B )=  0x0A;  // IIF_MC1_ASSIGN_BIT_10[4:0]
    ISPRW8(APACHE_ISP_BASE,0x013C )=  0x0B;  // IIF_MC1_ASSIGN_BIT_11[4:0]
    ISPRW8(APACHE_ISP_BASE,0x013D )=  0x0C;  // IIF_MC1_ASSIGN_BIT_12[4:0]
    ISPRW8(APACHE_ISP_BASE,0x013E )=  0x0D;  // IIF_MC1_ASSIGN_BIT_13[4:0]
    ISPRW8(APACHE_ISP_BASE,0x013F )=  0x0E;  // IIF_MC1_ASSIGN_BIT_14[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0140 )=  0x0F;  // IIF_MC1_ASSIGN_BIT_15[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0141 )=  0x10;  // IIF_MC1_ASSIGN_BIT_16[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0142 )=  0x11;  // IIF_MC1_ASSIGN_BIT_17[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0143 )=  0x12;  // IIF_MC1_ASSIGN_BIT_18[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0144 )=  0x13;  // IIF_MC1_ASSIGN_BIT_19[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0145 )=  0x14;  // IIF_MC1_ASSIGN_BIT_20[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0146 )=  0x15;  // IIF_MC1_ASSIGN_BIT_21[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0147 )=  0x16;  // IIF_MC1_ASSIGN_BIT_22[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0148 )=  0x17;  // IIF_MC1_ASSIGN_BIT_23[4:0]
    ISPRW8(APACHE_ISP_BASE,0x0149 )=  0x18;  // IIF_MC1_ASSIGN_BIT_24[4:0]

    ISPRW8(APACHE_ISP_BASE,0x014A )=  0x02;  // IIF_OBACT2_F_PORCH_VSYNC[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x014B )=  0x06;  // IIF_OBACT2_F_PORCH_VSYNC[12:8]
    ISPRW8(APACHE_ISP_BASE,0x014C )=  0x00;  // IIF_OBACT2_F_PORCH_HSYNC[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x014D )=  0x00;  // IIF_OBACT2_F_PORCH_HSYNC[12:8]
    ISPRW8(APACHE_ISP_BASE,0x014E )=  0x08;  // IIF_OBACT2_HEIGHT[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x014F )=  0x00;  // IIF_OBACT2_HEIGHT[12:8]
    ISPRW8(APACHE_ISP_BASE,0x0150 )=  0x00;  // IIF_OBACT2_WIDTH[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x0151 )=  0x08;  // IIF_OBACT2_WIDTH[12:8]
    ISPRW8(APACHE_ISP_BASE,0x0152 )=  0x01;  // IIF_MAX_CLK_EN [4:0]
    ISPRW8(APACHE_ISP_BASE,0x0153 )=  0x01;  // IIF_MERGE_CLK_EN[7:0]

    ISPRW8(APACHE_ISP_BASE,0x0154 )=  0x00;  // IIF_LWDR_CH_SEQ   : [6:4]
                            // IIF_LWDR_EN       : [3]
                            // IIF_LWDR_CH       : [2]
                            // EST_SEN_VSYNC_POL : [1]
                            // EST_SEN_HSYNC_POL : [0]
}

void input_cdc_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0180 )=  0xC9;  // ICDC_VS_HACT       : [7:6]
                            // ICDC_MEM_FREE      : [5]
                            // ICDC_RD_V_POS_SEL  : [3] = 1
                            // ICDC_RD_H_CMP_SEL  : [4] = 1 
                            // ICDC_HMIR          : [2]
                            // ICDC_REGEN_VBLK_EN : [1] = 0
                            // ICDC_RESET_EN      : [0] = 1

    ISPRW8(APACHE_ISP_BASE,0x019C )=  0x03;  // ICDC_RD_RST_SEL[0] = 1

    ISPRW8(APACHE_ISP_BASE,0x0199 )=  0x68;  // ICDC_HDLY_SIZE[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x019A )=  0x06;  // ICDC_HDLY_SIZE[12:8]

    ISPRW8(APACHE_ISP_BASE,0x0181 )=  0xFF & (ICDC_VTOT      );  // ICDC_V_TOT[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0182 )=  0x1F & (ICDC_VTOT >> 8 );  // ICDC_V_TOT[12:8]
    ISPRW8(APACHE_ISP_BASE,0x0183 )=  0xFF & (ICDC_VACT      );  // ICDC_V_ACT[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0184 )=  0x1F & (ICDC_VACT >> 8 );  // ICDC_V_ACT[12:8]
    ISPRW8(APACHE_ISP_BASE,0x0185 )=  0xFF & (ICDC_HTOT      );  // ICDC_H_TOT[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x0186 )=  0x1F & (ICDC_HTOT >> 8 );  // ICDC_H_TOT[12:8]
    ISPRW8(APACHE_ISP_BASE,0x0187 )=  0xFF & (ICDC_HACT      );  // ICDC_H_ACT[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x0188 )=  0x1F & (ICDC_HACT >>8  );  // ICDC_H_ACT[12:8]

    ISPRW8(APACHE_ISP_BASE,0x2353 )=  0xFF & (FRC_HACT       ); //  FRC_HACT_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x2354 )=  0x0F & (FRC_HACT >> 8  ); //  FRC_HACT_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x2355 )=  0xFF & (FRC_HTOT       ); //  FRC_HTOT_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x2356 )=  0x0F & (FRC_HTOT >> 8  ); //  FRC_HTOT_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x2357 )=  0xFF & (FRC_VACT       ); //  FRC_VACT_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x2358 )=  0x0F & (FRC_VACT >> 8  ); //  FRC_VACT_SIZE[11:8] 
}


void itp_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x01A0 )=  0xD0;  // {ITP_EN,ITP_HSWAP,ITP_VSWAP,ITP_SYNCGEN_EN,ITP_COLOR_FULL,1'h0,ITP_PATTERN[1:0]}

    ISPRW8(APACHE_ISP_BASE,0x01A1 )=  0xFF & (ICDC_HTOT      );  // ITP_H_TOTAL[7:0]
    ISPRW8(APACHE_ISP_BASE,0x01A2 )=  0x0F & (ICDC_HTOT >> 8 );  // ITP_H_TOTAL[11:8]
    ISPRW8(APACHE_ISP_BASE,0x01A3 )=  0xFF & (ICDC_VTOT      );  // ITP_V_TOTAL[7:0]
    ISPRW8(APACHE_ISP_BASE,0x01A4 )=  0x0F & (ICDC_VTOT >> 8 );  // ITP_V_TOTAL[11:8]
    ISPRW8(APACHE_ISP_BASE,0x01A5 )=  0xFF & (ICDC_HBLK      );  // ITP_H_START[7:0]
    ISPRW8(APACHE_ISP_BASE,0x01A6 )=  0x0F & (ICDC_HBLK >> 8 );  // ITP_H_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x01A9 )=  0xFF & (ICDC_HACT      );  // ITP_H_ACT[7:0]
    ISPRW8(APACHE_ISP_BASE,0x01AA )=  0x0F & (ICDC_HACT >> 8 );  // ITP_H_ACT[11:8]
    ISPRW8(APACHE_ISP_BASE,0x01AB )=  0xFF & (ICDC_VACT      );  // ITP_V_ACT[7:0]
    ISPRW8(APACHE_ISP_BASE,0x01AC )=  0x0F & (ICDC_VACT >> 8 );  // ITP_V_ACT[11:8]

    ISPRW8(APACHE_ISP_BASE,0x01AE )=  0xFF;  // ITP_W_DEFECT[7:0];
    ISPRW8(APACHE_ISP_BASE,0x01AF )=  0x40;  // ITP_B_DEFECT[7:0];
}

void input_interface_test(void)
{
    unsigned char rdata;
    rdata = ISPRW8(APACHE_ISP_BASE,0x0E40);
    ISPRW8(APACHE_ISP_BASE,0x1140 )=  rdata;
    rdata = ISPRW8(APACHE_ISP_BASE,0x0F80);
    ISPRW8(APACHE_ISP_BASE,0x1141 )=  rdata;
}

void adc_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0007 )=  0x19; // ADC_PD       : [4]
                           // ADC_RUN      : [3]
                           // ADC_CLK_P    : [2]
                           // ADC_SEL_AUTO : [1]
                           // ADC_EOC_FREE : [0]

    ISPRW8(APACHE_ISP_BASE,0x0008 )=  0x07; // ADC_SEL : [3:2]
                           // ADC_SPD : [1:0]
}

void awb_adj_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x003F )=  0x14;  // [7]:O_AWB_H_SWAP
                            // [6]:O_AWB_V_SWAP
                            // [5]:
                            // [4]:O_AWB_EN
                            // [3]:O_ADJ_EN2
                            // [2]:O_ADJ_EN

    ISPRW8(APACHE_ISP_BASE,0x0040 )=  0x82;  // ADJ_GAIN[7:0] <= 5.7 format
    ISPRW8(APACHE_ISP_BASE,0x0041 )=  0x00;  // ADJ_GAIN[14:8]
    ISPRW8(APACHE_ISP_BASE,0x0042 )=  0x00;  // ADJ_OFFSET[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0043 )=  0x00;  // ADJ_OFFSET[12:8]
    ISPRW8(APACHE_ISP_BASE,0x0046 )=  0x54;  // AGC_LEVEL[7:0]

    ISPRW8(APACHE_ISP_BASE,0x0047 )=  0x41;  // AWB_R_GAIN[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0048 )=  0x00;  // AWB_R_GAIN[8]
    ISPRW8(APACHE_ISP_BASE,0x0049 )=  0x42;  // AWB_G_GAIN[7:0]
    ISPRW8(APACHE_ISP_BASE,0x004A )=  0x00;  // AWB_G_GAIN[8]
    ISPRW8(APACHE_ISP_BASE,0x004B )=  0x3F;  // AWB_B_GAIN[7:0]
    ISPRW8(APACHE_ISP_BASE,0x004C )=  0x00;  // AWB_B_GAIN[8]
}

void NR3D_set(void)
{
    unsigned int DNR_RB_IMG_WLINE, DNR_WB_IMG_WLINE;

    ISPRW8(APACHE_ISP_BASE,0x1E00 )=  0xC0;  // DNR_MD_SEL : [7:6]
                            // DNR_H_SWAP : [2]
                            // DNR_V_SWAP : [1]
                            // DNR_EN     : [0]

    ISPRW8(APACHE_ISP_BASE,0x1E01 )=  0x27;  // DNR_ADJ_EN     : [7]
                            // AWB_GAIN_EN    : [6]
                            // DNR_SEL_G_DLY  : [5]
                            // NR3D_RB_NOSYNC : [4]
                            // DNR_MD_MODE    : [2:1]
                            // DNR_MANUAL_SET : [0]

    ISPRW8(APACHE_ISP_BASE,0x1E02 )=  0xFF;  // DNR_MANUAL_TH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1E03 )=  0x03;  // DNR_MANUAL_TH[9:8]  : [1:0]
//    ISPRW8(APACHE_ISP_BASE,0x1E02 )=  0x08;  // DNR_MANUAL_TH[7:0]
//    ISPRW8(APACHE_ISP_BASE,0x1E03 )=  0x00;  // DNR_MANUAL_TH[9:8]  : [1:0]

    ISPRW8(APACHE_ISP_BASE,0x1E04 )=  0xFF;  // DNR_MANUAL_RTH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1E05 )=  0x03;  // DNR_MANUAL_RTH[9:8] : [1:0]
    ISPRW8(APACHE_ISP_BASE,0x1E06 )=  0xFF;  // DNR_MANUAL_GTH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1E07 )=  0x03;  // DNR_MANUAL_GTH[9:8] : [1:0]
    ISPRW8(APACHE_ISP_BASE,0x1E08 )=  0xFF;  // DNR_MANUAL_BTH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1E09 )=  0x03;  // DNR_MANUAL_BTH[9:8] : [1:0]

    ISPRW8(APACHE_ISP_BASE,0x1E0A )=  0x80;  // DNR_MANUAL_LPF_ALPHA
    ISPRW8(APACHE_ISP_BASE,0x1E15 )=  0x00;  // DNR_DSP_MODE[7:0]
//    ISPRW8(APACHE_ISP_BASE,0x1E15 )=  0x0B;  // DNR_DSP_MODE[7:0]


    ISPRW8(APACHE_ISP_BASE,0x1E20 )=  0x08;  // TH_param0[7:0] 
//  ISPRW8(APACHE_ISP_BASE,0x1E21 )=  0x00;  // TH_param0[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E22 )=  0x0F;  // TH_param1[7:0] 
//  ISPRW8(APACHE_ISP_BASE,0x1E23 )=  0x00;  // TH_param1[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E24 )=  0x30;  // TH_param2[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E25 )=  0x00;  // TH_param2[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E26 )=  0x30;  // TH_param3[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E27 )=  0x00;  // TH_param3[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E28 )=  0x30;  // TH_param4[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E29 )=  0x00;  // TH_param4[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E2A )=  0x30;  // TH_param5[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E2B )=  0x00;  // TH_param5[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E2C )=  0x30;  // TH_param6[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E2D )=  0x00;  // TH_param6[9:8]  
//  ISPRW8(APACHE_ISP_BASE,0x1E2E )=  0x00;  // TH_param7[7:0] 
//  ISPRW8(APACHE_ISP_BASE,0x1E2F )=  0x00;  // TH_param7[9:8] 
//  ISPRW8(APACHE_ISP_BASE,0x1E30 )=  0x00;  // RTH_param0[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E31 )=  0x00;  // RTH_param0[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E32 )=  0x00;  // RTH_param1[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E33 )=  0x00;  // RTH_param1[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E34 )=  0x00;  // RTH_param2[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E35 )=  0x00;  // RTH_param2[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E36 )=  0x00;  // RTH_param3[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E37 )=  0x00;  // RTH_param3[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E38 )=  0x00;  // RTH_param4[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E39 )=  0x00;  // RTH_param4[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E3A )=  0x00;  // RTH_param5[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E3B )=  0x00;  // RTH_param5[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E3C )=  0x00;  // RTH_param6[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E3D )=  0x00;  // RTH_param6[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E3E )=  0x00;  // RTH_param7[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E3F )=  0x00;  // RTH_param7[9:8]


//  ISPRW8(APACHE_ISP_BASE,0x1E40 )=  0x00;  // GTH_param0[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x1E41 )=  0x50;  // GTH_param0[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E42 )=  0x00;  // GTH_param1[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E43 )=  0x00;  // GTH_param1[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E44 )=  0x00;  // GTH_param2[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E45 )=  0x00;  // GTH_param2[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E46 )=  0x00;  // GTH_param3[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E47 )=  0x00;  // GTH_param3[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E48 )=  0x00;  // GTH_param4[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E49 )=  0x00;  // GTH_param4[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E4A )=  0x00;  // GTH_param5[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E4B )=  0x00;  // GTH_param5[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E4C )=  0x00;  // GTH_param6[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E4D )=  0x00;  // GTH_param6[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E4E )=  0x00;  // GTH_param7[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E4F )=  0x00;  // GTH_param7[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E50 )=  0x00;  // BTH_param0[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E51 )=  0x00;  // BTH_param0[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E52 )=  0x00;  // BTH_param1[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E53 )=  0x00;  // BTH_param1[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E54 )=  0x00;  // BTH_param2[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E55 )=  0x00;  // BTH_param2[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E56 )=  0x00;  // BTH_param3[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E57 )=  0x00;  // BTH_param3[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E58 )=  0x00;  // BTH_param4[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E59 )=  0x00;  // BTH_param4[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E5A )=  0x00;  // BTH_param5[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E5B )=  0x00;  // BTH_param5[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E5C )=  0x00;  // BTH_param6[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E5D )=  0x00;  // BTH_param6[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E5E )=  0x00;  // BTH_param7[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E5F )=  0x00;  // BTH_param7[9:8]

//  ISPRW8(APACHE_ISP_BASE,0x1E60 )=  0x00;  // L_param0  
//  ISPRW8(APACHE_ISP_BASE,0x1E61 )=  0x00;  // L_param1 
//  ISPRW8(APACHE_ISP_BASE,0x1E62 )=  0x00;  // L_param2 
//  ISPRW8(APACHE_ISP_BASE,0x1E63 )=  0x00;  // L_param3 
//  ISPRW8(APACHE_ISP_BASE,0x1E64 )=  0x00;  // L_param4 
//  ISPRW8(APACHE_ISP_BASE,0x1E65 )=  0x00;  // L_param5 
//  ISPRW8(APACHE_ISP_BASE,0x1E66 )=  0x00;  // L_param6 
//  ISPRW8(APACHE_ISP_BASE,0x1E67 )=  0x00;  // L_param7 

//  ISPRW8(APACHE_ISP_BASE,0x1E68 )=  0x00;  // FIL_param0  
//  ISPRW8(APACHE_ISP_BASE,0x1E69 )=  0x00;  // FIL_param1 
//  ISPRW8(APACHE_ISP_BASE,0x1E6A )=  0x00;  // FIL_param2 
//  ISPRW8(APACHE_ISP_BASE,0x1E6B )=  0x00;  // FIL_param3 
//  ISPRW8(APACHE_ISP_BASE,0x1E6C )=  0x00;  // FIL_param4 
//  ISPRW8(APACHE_ISP_BASE,0x1E6D )=  0x00;  // FIL_param5 
//  ISPRW8(APACHE_ISP_BASE,0x1E6E )=  0x00;  // FIL_param6 

//  ISPRW8(APACHE_ISP_BASE,0x1E70 )=  0x00;  // TH_param_FIL1[7:0] 
//  ISPRW8(APACHE_ISP_BASE,0x1E71 )=  0x00;  // TH_param_FIL1[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E72 )=  0x09;  // TH_param_FIL2[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E73 )=  0x00;  // TH_param_FIL2[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E74 )=  0x10;  // TH_param_FIL3[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E75 )=  0x00;  // TH_param_FIL3[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E76 )=  0x10;  // TH_param_FIL4[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E77 )=  0x00;  // TH_param_FIL4[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E78 )=  0x3E;  // RTH_param_FIL1[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x1E79 )=  0x10;  // RTH_param_FIL1[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E7A )=  0x00;  // RTH_param_FIL2[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E7B )=  0x00;  // RTH_param_FIL2[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E7C )=  0x00;  // RTH_param_FIL3[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E7D )=  0x00;  // RTH_param_FIL3[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E7E )=  0x00;  // RTH_param_FIL4[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E7F )=  0x00;  // RTH_param_FIL4[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E80 )=  0x00;  // GTH_param_FIL1[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E81 )=  0x00;  // GTH_param_FIL1[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E82 )=  0x00;  // GTH_param_FIL2[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E83 )=  0x00;  // GTH_param_FIL2[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E84 )=  0x00;  // GTH_param_FIL3[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E85 )=  0x00;  // GTH_param_FIL3[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E86 )=  0x00;  // GTH_param_FIL4[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E87 )=  0x00;  // GTH_param_FIL4[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E88 )=  0x0A;  // BTH_param_FIL1[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E89 )=  0x00;  // BTH_param_FIL1[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E8A )=  0x00;  // BTH_param_FIL2[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E8B )=  0x00;  // BTH_param_FIL2[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E8C )=  0x13;  // BTH_param_FIL3[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E8D )=  0x00;  // BTH_param_FIL3[9:8]
//  ISPRW8(APACHE_ISP_BASE,0x1E8E )=  0x00;  // BTH_param_FIL4[7:0]
//  ISPRW8(APACHE_ISP_BASE,0x1E8F )=  0x00;  // BTH_param_FIL4[9:8]


    ISPRW8(APACHE_ISP_BASE,0x1E93 )=  0x0a;  // O_DNR_NUM_MT_RTH[5:0]
    ISPRW8(APACHE_ISP_BASE,0x1E94 )=  0x0a;  // O_DNR_NUM_MT_GTH[5:0]
    ISPRW8(APACHE_ISP_BASE,0x1E95 )=  0x0a;  // O_DNR_NUM_MT_BTH[5:0]

    ISPRW8(APACHE_ISP_BASE,0x1E96 )=  0x80;  // O_DNR_DMT_MAX[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1E97 )=  0x00;  // O_DNR_DMT_MAX[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E98 )=  0x80;  // O_DNR_DMT_R_MAX[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1E99 )=  0x00;  // O_DNR_DMT_R_MAX[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E9A )=  0x80;  // O_DNR_DMT_G_MAX[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1E9B )=  0x00;  // O_DNR_DMT_G_MAX[9:8]
    ISPRW8(APACHE_ISP_BASE,0x1E9C )=  0x80;  // O_DNR_DMT_B_MAX[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1E9D )=  0x00;  // O_DNR_DMT_B_MAX[9:8]


    ISPRW8(APACHE_ISP_BASE,0x1EA1 )=  0x00;  // ADP_FIL_SIZE2[2:0]
    ISPRW8(APACHE_ISP_BASE,0x1EA2 )=  0x33;  // O_DNR_PIX_DIF_IIR : [5]
                            // O_DNR_ADP_FIL_EN  : [4]
                            // O_DNR_ADP_FIL_SIZE[2:0]

//    ISPRW8(APACHE_ISP_BASE,0x1E05 )=  0x00;  // O_DNR_MANUAL_RTH[9:8]
//    ISPRW8(APACHE_ISP_BASE,0x1E04 )=  0x10;  // O_DNR_MANUAL_RTH[7:0]
//    ISPRW8(APACHE_ISP_BASE,0x1E06 )=  0x10;  // O_DNR_MANUAL_GTH[7:0]
//    ISPRW8(APACHE_ISP_BASE,0x1E08 )=  0x10;  // O_DNR_MANUAL_BTH[7:0]

    ISPRW8(APACHE_ISP_BASE,0x1E90 )=  0x20;  // DNR_DISP_LPF_TYPE : [5:4]
                            // DNR_LPF_EDGE_EN   : [0]
    ISPRW8(APACHE_ISP_BASE,0x1E91 )=  0xFF;  // DNR_DISP_SIGMA 
    ISPRW8(APACHE_ISP_BASE,0x1E92 )=  0x0A;  // DNR_MT_NUM_YTH[5:0]

    ISPRW8(APACHE_ISP_BASE,0x1EA0 )=  0x00;  // DNR_GAMMA_ALPHA     : [7:3]
                            // DNR_GAMMA_EN        : [2]
                            // DNR_IIR_SMTH_NMT_EN : [0]

#if(DNR_WRAP_EN == ON)
    DNR_RB_IMG_WLINE = (unsigned int)((ICDC_VACT+16) * 2);
    DNR_WB_IMG_WLINE = (unsigned int)((ICDC_VACT+16) * 2);
#else
    DNR_RB_IMG_WLINE = (unsigned int)(ICDC_VACT);
    DNR_WB_IMG_WLINE = (unsigned int)(ICDC_VACT);
#endif

//  ISPRW8(APACHE_ISP_BASE,0x1EB5 )=  0x00;                              // {DNR_RB_PRI_SET[6:4],1'b0,DNR_RB_PRI_MODE[1:0]}
    ISPRW8(APACHE_ISP_BASE,0x1EB7 )=  0x07 & (ICDC_HACT >> 8         );  // DNR_RB_IMG_HPIXEL[10:8]
    ISPRW8(APACHE_ISP_BASE,0x1EB6 )=  0xFF & (ICDC_HACT              );  // DNR_RB_IMG_HPIXEL[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1EB9 )=  0x07 & (ICDC_VACT >> 8         );  // DNR_RB_IMG_VLINE[10:8]
    ISPRW8(APACHE_ISP_BASE,0x1EB8 )=  0xFF & (ICDC_VACT              );  // DNR_RB_IMG_VLINE[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1EBB )=  0x1F & (DNR_RB_IMG_WLINE >> 8  );  // DNR_RB_IMG_WLINE[12:8]
    ISPRW8(APACHE_ISP_BASE,0x1EBA )=  0xFF & (DNR_RB_IMG_WLINE       );  // DNR_RB_IMG_WLINE[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1EBC )=  0x05;                              // DNR_RB_BURST_CTRL[3:0]

    ISPRW8(APACHE_ISP_BASE,0x1EC7 )=  0xFF & (DNR_BASE_ADDR >> 24    );  // DNR_WB_WRITE_ADDR[31:24] 
    ISPRW8(APACHE_ISP_BASE,0x1EC6 )=  0xFF & (DNR_BASE_ADDR >> 16    );  // DNR_WB_WRITE_ADDR[23:16] 
    ISPRW8(APACHE_ISP_BASE,0x1EC5 )=  0xFF & (DNR_BASE_ADDR >> 8     );  // DNR_WB_WRITE_ADDR[15:8] 
    ISPRW8(APACHE_ISP_BASE,0x1EC4 )=  0xFF & (DNR_BASE_ADDR          );  // DNR_WB_WRITE_ADDR[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x1EC9 )=  0x1F & (ICDC_HACT >> 8         );  // DNR_WB_LINE_WIDTH[12:8]
    ISPRW8(APACHE_ISP_BASE,0x1EC8 )=  0xFF & (ICDC_HACT              );  // DNR_WB_LINE_WIDTH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1ECB )=  0x07 & (ICDC_VACT >> 8         );  // DNR_WB_IMG_VLINE[10:8]
    ISPRW8(APACHE_ISP_BASE,0x1ECA )=  0xFF & (ICDC_VACT              );  // DNR_WB_IMG_VLINE[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1ECD )=  0x1F & (DNR_WB_IMG_WLINE >> 8  );  // DNR_WB_IMG_WLINE[12:8]
    ISPRW8(APACHE_ISP_BASE,0x1ECC )=  0xFF & (DNR_WB_IMG_WLINE       );  // DNR_WB_IMG_WLINE[7:0]
    ISPRW8(APACHE_ISP_BASE,0x1ECE )=  0x05;                              // {4'h0,DNR_WB_BURST_CTRL[3:0]}
//  ISPRW8(APACHE_ISP_BASE,0x1ECF )=  0x00;                              // {DNR_WB_PRI_SET[6:4],2'h0,DNR_WB_PRI_MODE[1:0}

    ISPRW8(APACHE_ISP_BASE,0x1EB4 )=  0x08 | ISPRW8(APACHE_ISP_BASE,0x1EB4);     // {DNR_RB_DPCM_EN[3],1'd0,DNR_RB_READ_MODE[1],DNR_RB_ENABLE[0]}
#if(DNR_WRAP_EN == ON)
    ISPRW8(APACHE_ISP_BASE,0x1EC3 )=  0x0B | ISPRW8(APACHE_ISP_BASE,0x1EC3);     // {I_NR3D_WB_DPCM_EN[3], I_NR3D_WB_INIT[2], I_NR3D_WB_WRAP_EN[1], I_NR3D_WB_ENABLE[0]}
#else
    ISPRW8(APACHE_ISP_BASE,0x1EC3 )=  0x09 | ISPRW8(APACHE_ISP_BASE,0x1EC1);     // {I_NR3D_WB_DPCM_EN[3], I_NR3D_WB_INIT[2], I_NR3D_WB_WRAP_EN[1], I_NR3D_WB_ENABLE[0]}
#endif
}

void FRC_set(void)
{
    unsigned int DNR_RB_IMG_WLINE;

    ISPRW8(APACHE_ISP_BASE,0x2300 )=  0x24;  //  I_NR3D_NOSYNC   : [7]
                            //  I_HACT_POSITION : [6]
                            //  I_DPCM_EN       : [5]
                            //  I_VFLIP_EN      : [4]
                            //  I_READ_MODE     : [3]
                            //  I_HSYNC_MODE    : [2]
                            //  I_SYNC_MODE     : [1:0]

    ISPRW8(APACHE_ISP_BASE,0x2301 )=  0xFF & (FRC_VACT           );  //  I_VSYNC_NUM[7:0]     
    ISPRW8(APACHE_ISP_BASE,0x2302 )=  0x1F & (FRC_VACT >> 8      );  //  I_VSYNC_NUM[11:8]    
    ISPRW8(APACHE_ISP_BASE,0x2303 )=  0xFF & (FRC_VBLK           );  //  I_VBLANK_NUM[7:0]    
    ISPRW8(APACHE_ISP_BASE,0x2304 )=  0xFF & (FRC_VBLK >> 8      );  //  I_VBLANK_NUM[15:8]  

    ISPRW8(APACHE_ISP_BASE,0x2305 )=  0xFF & (DNR_BASE_ADDR      );  //  I_START_ADDR[7:0]    
    ISPRW8(APACHE_ISP_BASE,0x2306 )=  0xFF & (DNR_BASE_ADDR >> 8);   //  I_START_ADDR[15:8]   
    ISPRW8(APACHE_ISP_BASE,0x2307 )=  0xFF & (DNR_BASE_ADDR >> 16);  //  I_START_ADDR[23:16]  
    ISPRW8(APACHE_ISP_BASE,0x2308 )=  0xFF & (DNR_BASE_ADDR >> 24);  //  I_START_ADDR[31:24]  

    ISPRW8(APACHE_ISP_BASE,0x2309 )=  0xFF & (FRC_AFTER_HACT     );  //  I_HACT_PIXEL[7:0]    
    ISPRW8(APACHE_ISP_BASE,0x230A )=  0x0F & (FRC_AFTER_HACT >> 8);  //  I_HACT_PIXEL[11:8]   
    ISPRW8(APACHE_ISP_BASE,0x230B )=  0xFF & (FRC_AFTER_HBLK     );  //  I_HBLANK_PIXEL[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x230C )=  0xFF & (FRC_AFTER_HBLK >> 8);  //  I_HBLANK_PIXEL[15:8] 

    ISPRW8(APACHE_ISP_BASE,0x230D )=  0x00;  // I_OUT_VSYNC_POL : [2]  
                            // I_OUT_HSYNC_POL : [1]
                            // I_OUT_HACT_POL  : [0]
 
    ISPRW8(APACHE_ISP_BASE,0x230E )=  0x00;  // I_VFPORCH_NUM[7:0]            
    ISPRW8(APACHE_ISP_BASE,0x230F )=  0x00;  // I_VFPORCH_NUM[15:8]        
    ISPRW8(APACHE_ISP_BASE,0x2310 )=  0x00;  // I_VBPORCH_NUM[7:0]    
    ISPRW8(APACHE_ISP_BASE,0x2311 )=  0x00;  // I_VBPORCH_NUM[15:8]   

#if(DNR_WRAP_EN == ON)
    DNR_RB_IMG_WLINE = (unsigned int)((ICDC_VACT+16) * 2);
#else
    DNR_RB_IMG_WLINE = (unsigned int)(ICDC_VACT);
#endif

    ISPRW8(APACHE_ISP_BASE,0x2312 )=  0xFF & (FRC_HACT               );  // I_FRC_IMG_HPIXEL[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x2313 )=  0x0F & (FRC_HACT >> 8          );  // I_FRC_IMG_HPIXEL[11:8]
    ISPRW8(APACHE_ISP_BASE,0x2314 )=  0xFF & (FRC_VACT               );  // I_FRC_IMG_VLINE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x2315 )=  0x0F & (FRC_VACT >> 8          );  // I_FRC_IMG_VLINE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x2316 )=  0xFF & (DNR_RB_IMG_WLINE       );  // I_FRC_IMG_WLINE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x2317 )=  0x3F & (DNR_RB_IMG_WLINE >> 8  );  // I_FRC_IMG_WLINE[13:8] 

    ISPRW8(APACHE_ISP_BASE,0x2318 )=  0x00;  //  I_PRI_SET  : [6:4]
                            //  I_PRI_MODE : [1:0]

    ISPRW8(APACHE_ISP_BASE,0x2319 )=  0x00;  //  I_EXT_HSYNC_MODE : [5:4]
                            //  I_EXT_SYNC_FORCE : [3]
                            //  I_EXT_VSYNC_POL  : [2]
                            //  I_EXT_HSYNC_POL  : [1]
                            //  I_EXT_HACT_POL   : [0]

    ISPRW8(APACHE_ISP_BASE,0x231A )=  0x00;  //  I_BURST_CTRL : [7:4] 


    ISPRW8(APACHE_ISP_BASE,0x2320 )=  0x00;  //  I_FRC_CROP_EN        : [3]
                            //  I_FRC_CROP_INC_EN    : [2]
                            //  I_FRC_CROP_HSYNC_SEL : [1]
                            //  I_FRC_CROP_VSYNC_SEL : [0]

    ISPRW8(APACHE_ISP_BASE,0x2321 )=  0x00;  //  I_FRC_CROP_VPOS[7:0]       
    ISPRW8(APACHE_ISP_BASE,0x2322 )=  0x00;  //  I_FRC_CROP_VPOS[11:8]     
    ISPRW8(APACHE_ISP_BASE,0x2323 )=  0x00;  //  I_FRC_CROP_HSPOS[7:0]     
    ISPRW8(APACHE_ISP_BASE,0x2324 )=  0x00;  //  I_FRC_CROP_HSPOS[11:8]    
    ISPRW8(APACHE_ISP_BASE,0x2325 )=  0x00;  //  I_FRC_CROP_HPOS[7:0]      
    ISPRW8(APACHE_ISP_BASE,0x2326 )=  0x00;  //  I_FRC_CROP_HPOS[11:8]     
    ISPRW8(APACHE_ISP_BASE,0x2327 )=  0x00;  //  I_FRC_CROP_ORG_VSIZE[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x2328 )=  0x00;  //  I_FRC_CROP_ORG_VSIZE[11:8]
    ISPRW8(APACHE_ISP_BASE,0x2329 )=  0x00;  //  I_FRC_CROP_VSIZE[7:0]     
    ISPRW8(APACHE_ISP_BASE,0x232A )=  0x00;  //  I_FRC_CROP_VSIZE[11:8]    
    ISPRW8(APACHE_ISP_BASE,0x232B )=  0x00;  //  I_FRC_CROP_HSSIZE[7:0]    
    ISPRW8(APACHE_ISP_BASE,0x232C )=  0x00;  //  I_FRC_CROP_HSSIZE[11:8]   
    ISPRW8(APACHE_ISP_BASE,0x232D )=  0x00;  //  I_FRC_CROP_HSIZE[7:0]     
    ISPRW8(APACHE_ISP_BASE,0x232E )=  0x00;  //  I_FRC_CROP_HSIZE[11:8]    
    ISPRW8(APACHE_ISP_BASE,0x232F )=  0x00;  //  I_FRC_CROP_VFPORCH[7:0]   

    ISPRW8(APACHE_ISP_BASE,0x2330 )=  0x00;  //  I_FRC_CROP_VFPORCH[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x2331 )=  0x00;  //  I_FRC_CROP_VBPORCH[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x2332 )=  0x00;  //  I_FRC_CROP_VBPORCH[11:8] 

    ISPRW8(APACHE_ISP_BASE,0x2340 )=  0x00;  //  I_FRC_OUT_CROP_EN        : [3] 
                            //  I_FRC_OUT_CROP_INC_EN    : [2]
                            //  I_FRC_OUT_CROP_HSYNC_SEL : [1]
                            //  I_FRC_OUT_CROP_VSYNC_SEL : [0]

    ISPRW8(APACHE_ISP_BASE,0x2341 )=  0x00;  //  I_FRC_OUT_CROP_VPOS[7:0]       
    ISPRW8(APACHE_ISP_BASE,0x2342 )=  0x00;  //  I_FRC_OUT_CROP_VPOS[11:8]     
    ISPRW8(APACHE_ISP_BASE,0x2343 )=  0x00;  //  I_FRC_OUT_CROP_HSPOS[7:0]     
    ISPRW8(APACHE_ISP_BASE,0x2344 )=  0x00;  //  I_FRC_OUT_CROP_HSPOS[11:8]    
    ISPRW8(APACHE_ISP_BASE,0x2345 )=  0x00;  //  I_FRC_OUT_CROP_HPOS[7:0]      
    ISPRW8(APACHE_ISP_BASE,0x2346 )=  0x00;  //  I_FRC_OUT_CROP_HPOS[11:8]     
    ISPRW8(APACHE_ISP_BASE,0x2347 )=  0x00;  //  I_FRC_OUT_CROP_ORG_VSIZE[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x2348 )=  0x00;  //  I_FRC_OUT_CROP_ORG_VSIZE[11:8]
    ISPRW8(APACHE_ISP_BASE,0x2349 )=  0x00;  //  I_FRC_OUT_CROP_VSIZE[7:0]     
    ISPRW8(APACHE_ISP_BASE,0x234A )=  0x00;  //  I_FRC_OUT_CROP_VSIZE[11:8]    
    ISPRW8(APACHE_ISP_BASE,0x234B )=  0x00;  //  I_FRC_OUT_CROP_HSSIZE[7:0]    
    ISPRW8(APACHE_ISP_BASE,0x234C )=  0x00;  //  I_FRC_OUT_CROP_HSSIZE[11:8]   
    ISPRW8(APACHE_ISP_BASE,0x234D )=  0x00;  //  I_FRC_OUT_CROP_HSIZE[7:0]     
    ISPRW8(APACHE_ISP_BASE,0x234E )=  0x00;  //  I_FRC_OUT_CROP_HSIZE[11:8]    
    ISPRW8(APACHE_ISP_BASE,0x234F )=  0x00;  //  I_FRC_OUT_CROP_VFPORCH[7:0]   

    ISPRW8(APACHE_ISP_BASE,0x2350 )=  0x00;  //  I_FRC_OUT_CROP_VFPORCH[11:8]  
    ISPRW8(APACHE_ISP_BASE,0x2351 )=  0x00;  //  I_FRC_OUT_CROP_VBPORCH[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x2352 )=  0x00;  //  I_FRC_OUT_CROP_VBPORCH[11:8] 
}


void LDC_set(void)
{
    // LDC setting for 32 sampling

    unsigned int    ldc_out_delay   = (unsigned int) O_DS_VACT >> 1;
    unsigned int    ldc_base_addr   = (unsigned int) LDC_BASE_ADDR;
    unsigned int    lut_base_addr   = (unsigned int) LUT_BASE_ADDR;
    unsigned int    ldc_in_width    = (unsigned int) O_DS_HACT;
    unsigned int    ldc_in_height   = (unsigned int) O_DS_VACT;
    unsigned int    ldc_in_wrap     = (unsigned int) ldc_in_height*1.5;
    unsigned int    ldc_out_hblk    = (unsigned int) FRC_HBLK;
    unsigned int    ldc_out_vblk    = (unsigned int) FRC_VBLK;

    ISPRW8(APACHE_ISP_BASE,0x2400 )=  0x00;      // O_LDC_READ_SYNC_MODE : [1]
                                // O_LDC_EN             : [0]

    ISPRW8(APACHE_ISP_BASE,0x2401 )=  (ldc_out_delay & 0xFF);      // O_LDC_OUT_LINE_DELAY[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x2402 )=  (ldc_out_delay >> 8) & 0xFF;      // O_LDC_OUT_LINE_DELAY[15:8]

    ISPRW8(APACHE_ISP_BASE,0x2403 )=  0x08;      // O_LDC_PRE_VSYNC_DELAY[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x2404 )=  (ldc_in_width)      & 0xFF; // O_LDC_IN_HWIDTH[7:0]      
    ISPRW8(APACHE_ISP_BASE,0x2405 )=  (ldc_in_width >> 8) & 0xFF; // O_LDC_IN_HWIDTH[10:8]      
    ISPRW8(APACHE_ISP_BASE,0x2406 )=  (ldc_in_width)      & 0xFF; // O_LDC_MEM_HWIDTH[ 7:0]     
    ISPRW8(APACHE_ISP_BASE,0x2407 )=  (ldc_in_width >> 8) & 0xFF; // O_LDC_MEM_HWIDTH[10:8]     
    ISPRW8(APACHE_ISP_BASE,0x2408 )=  (ldc_in_width)      & 0xFF; // O_LDC_OUT_HWIDTH[ 7:0]     
    ISPRW8(APACHE_ISP_BASE,0x2409 )=  (ldc_in_width >> 8) & 0xFF; // O_LDC_OUT_HWIDTH[10:8]     
    ISPRW8(APACHE_ISP_BASE,0x240A )=  (ldc_out_hblk)      & 0xFF; // O_LDC_OUT_HBLANK[ 7:0]     
    ISPRW8(APACHE_ISP_BASE,0x240B )=  (ldc_out_hblk >> 8) & 0xFF; // O_LDC_OUT_HBLANK[15:8]     

#if (LDC_MODE == ON)
    ISPRW8(APACHE_ISP_BASE,0x240C )=  0x01;      // 
#else
    ISPRW8(APACHE_ISP_BASE,0x240C )=  0x00;      // o_lut_ratio_fix_sel : [7]
                                // o_lut_ratio_fix     : [6]
                                //                     : [5]
                                // O_LDC_OUT_DITHER_EN : [4]
                                // o_bypass_en         : [3]
                                // o_yscale_down       : [2]
                                // o_xscale_down       : [1]
                                // o_ldc_mode          : [0]
#endif

    ISPRW8(APACHE_ISP_BASE,0x240D )=  0x00;      // o_lut_ratio 

    ISPRW8(APACHE_ISP_BASE,0x240E )=  (((ldc_in_width  >> 6)<<1)+0x1) & 0xFF;      // o_TXCNT     
    ISPRW8(APACHE_ISP_BASE,0x240F )=  (((ldc_in_height >> 6)<<1)+0x1) & 0xFF;      // o_TYCNT_1   

    ISPRW8(APACHE_ISP_BASE,0x2410 )=  0x00;      // o_SOFFSET     
    ISPRW8(APACHE_ISP_BASE,0x2411 )=  0x00;      // o_TOFFSET     
    ISPRW8(APACHE_ISP_BASE,0x2412 )=  0x07;      // o_DSTW_1      
    ISPRW8(APACHE_ISP_BASE,0x2413 )=  0x07;      // o_DSTH_1      
    ISPRW8(APACHE_ISP_BASE,0x2414 )=  0x00;      // o_INCRW[ 7:0] 
    ISPRW8(APACHE_ISP_BASE,0x2415 )=  0x10;      // o_INCRW[15:8] 
    ISPRW8(APACHE_ISP_BASE,0x2416 )=  0x00;      // o_INCRH[ 7:0] 
    ISPRW8(APACHE_ISP_BASE,0x2417 )=  0x10;      // o_INCRH[15:8] 

    ISPRW8(APACHE_ISP_BASE,0x2418 )=  0x00;      // o_chblur_sel : [5:4]
                                // o_yhblur_sel : [1:0] 

    ISPRW8(APACHE_ISP_BASE,0x2419 )=  0x00;      // o_hscl_main_wr_dto[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x241A )=  0x01;      // o_hscl_main_wr_dto[12:8]
    ISPRW8(APACHE_ISP_BASE,0x241B )=  0x00;      // o_vscl_main_wr_dto[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x241C )=  0x01;      // o_vscl_main_wr_dto[12:8]
    ISPRW8(APACHE_ISP_BASE,0x241D )=  0x00;      // o_hscl_main_rd_dto[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x241E )=  0x01;      // o_hscl_main_rd_dto[12:8]
    ISPRW8(APACHE_ISP_BASE,0x241F )=  0x00;      // o_vscl_main_rd_dto[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x2420 )=  0x01;      // o_vscl_main_rd_dto[12:8] 
    ISPRW8(APACHE_ISP_BASE,0x2421 )=  0x00;      // o_lut_hpos[ 7:0]         
    ISPRW8(APACHE_ISP_BASE,0x2422 )=  0x00;      // o_lut_hpos[11:8]         
    ISPRW8(APACHE_ISP_BASE,0x2423 )=  0x00;      // o_lut_vpos[ 7:0]         
    ISPRW8(APACHE_ISP_BASE,0x2424 )=  0x00;      // o_lut_vpos[11:8]       
  
    ISPRW8(APACHE_ISP_BASE,0x2425 )=  0x01;      // O_LUT_RMAIN_EN           
    ISPRW8(APACHE_ISP_BASE,0x2426 )=  (lut_base_addr >> 0 ) & 0xFF;      // O_LUT_BASE_ADDR0[ 7: 0] 
    ISPRW8(APACHE_ISP_BASE,0x2427 )=  (lut_base_addr >> 8 ) & 0xFF;      // O_LUT_BASE_ADDR0[15: 8] 
    ISPRW8(APACHE_ISP_BASE,0x2428 )=  (lut_base_addr >> 16) & 0xFF;      // O_LUT_BASE_ADDR0[23:16] 
    ISPRW8(APACHE_ISP_BASE,0x2429 )=  (lut_base_addr >> 24) & 0xFF;      // O_LUT_BASE_ADDR0[31:24] 
    ISPRW8(APACHE_ISP_BASE,0x242A )=  (lut_base_addr >> 0 ) & 0xFF;      // O_LUT_BASE_ADDR1[ 7: 0] 
    ISPRW8(APACHE_ISP_BASE,0x242B )=  (lut_base_addr >> 8 ) & 0xFF;      // O_LUT_BASE_ADDR1[15: 8] 
    ISPRW8(APACHE_ISP_BASE,0x242C )=  (lut_base_addr >> 16) & 0xFF;      // O_LUT_BASE_ADDR1[23:16] 
    ISPRW8(APACHE_ISP_BASE,0x242D )=  (lut_base_addr >> 24) & 0xFF;      // O_LUT_BASE_ADDR1[31:24] 
    ISPRW8(APACHE_ISP_BASE,0x242E )=  0x07;      // O_LUT_BURST_CTRL        
    ISPRW8(APACHE_ISP_BASE,0x242F )=  0x00;      // O_LUT_PRI_SET  : [6:4]                 
                                // O_LUT_PRI_MODE : [1:0]

    ISPRW8(APACHE_ISP_BASE,0x2430 )=  0x23;      // O_LDC_RMAIN_READ_MODE    : [5]
                                // O_LDC_RMAIN_EN           : [4]
                                //
                                // O_LDC_WMAIN_WRAP_INIT_EN : [2]
                                // O_LDC_WMAIN_WRAP_EN      : [1]
                                // O_LDC_WMAIN_EN           : [0]
                                //

    // Width 
    ISPRW8(APACHE_ISP_BASE,0x2431 )=  (ldc_base_addr >> 0 ) & 0xFF;      // O_LDC_WMAIN_START_ADDR[ 7: 0]
    ISPRW8(APACHE_ISP_BASE,0x2432 )=  (ldc_base_addr >> 8 ) & 0xFF;      // O_LDC_WMAIN_START_ADDR[15: 8]
    ISPRW8(APACHE_ISP_BASE,0x2433 )=  (ldc_base_addr >> 16) & 0xFF;      // O_LDC_WMAIN_START_ADDR[23:16]
    ISPRW8(APACHE_ISP_BASE,0x2434 )=  (ldc_base_addr >> 24) & 0xFF;      // O_LDC_WMAIN_START_ADDR[31:24]
    ISPRW8(APACHE_ISP_BASE,0x2435 )=  (ldc_in_width  >> 0)  & 0xFF;       // O_LDC_WMAIN_HPIXEL[ 7:0]     
    ISPRW8(APACHE_ISP_BASE,0x2436 )=  (ldc_in_width  >> 8)  & 0xFF;       // O_LDC_WMAIN_HPIXEL[10:8]     
    ISPRW8(APACHE_ISP_BASE,0x2437 )=  (ldc_in_height >> 0)  & 0xFF;       // O_LDC_WMAIN_VLINE[ 7:0]      
    ISPRW8(APACHE_ISP_BASE,0x2438 )=  (ldc_in_height >> 8)  & 0xFF;       // O_LDC_WMAIN_VLINE[10:8]      
    ISPRW8(APACHE_ISP_BASE,0x2439 )=  (ldc_in_wrap   >> 8)  & 0xFF;       // O_LDC_WMAIN_WLINE[ 7:0]      
    ISPRW8(APACHE_ISP_BASE,0x243A )=  (ldc_in_wrap   >> 8)  & 0xFF;       // O_LDC_WMAIN_WLINE[12:8]      
    ISPRW8(APACHE_ISP_BASE,0x243B )=  (ldc_in_width  >> 8)  & 0xFF;       // O_LDC_RMAIN_HPIXEL[ 7:0]     
    ISPRW8(APACHE_ISP_BASE,0x243C )=  (ldc_in_width  >> 8)  & 0xFF;       // O_LDC_RMAIN_HPIXEL[10:8]     
    ISPRW8(APACHE_ISP_BASE,0x243D )=  (ldc_in_height >> 8)  & 0xFF;       // O_LDC_RMAIN_VLINE[ 7:0]      
    ISPRW8(APACHE_ISP_BASE,0x243E )=  (ldc_in_height >> 8)  & 0xFF;       // O_LDC_RMAIN_VLINE[10:8]      
    ISPRW8(APACHE_ISP_BASE,0x243F )=  (ldc_in_wrap   >> 8)  & 0xFF;       // O_LDC_RMAIN_WLINE[ 7:0]      
    ISPRW8(APACHE_ISP_BASE,0x2440 )=  (ldc_in_wrap   >> 8)  & 0xFF;       // O_LDC_RMAIN_WLINE[12:8]

    ISPRW8(APACHE_ISP_BASE,0x2441 )=  0x77;      // O_LDC_RMAIN_BURST_CTRL : [7:4]
                                // O_LDC_WMAIN_BURST_CTRL : [3:0]
    ISPRW8(APACHE_ISP_BASE,0x2442 )=  0x00;      // O_LDC_WMAIN_PRI_SET  : [6:4]
                                // O_LDC_WMAIN_PRI_MODE : [1:0]
    ISPRW8(APACHE_ISP_BASE,0x2443 )=  0x00;      // O_LDC_RMAIN_PRI_SET  : [6:4] 
                                // O_LDC_RMAIN_PRI_MODE : [1:0]  


    ISPRW8(APACHE_ISP_BASE,0x2450 )=  0x00;      // O_PIP_MEM_HWIDTH[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x2451 )=  0x00;      // O_PIP_MEM_HWIDTH[ 9:8]
    ISPRW8(APACHE_ISP_BASE,0x2452 )=  0x00;      // O_PIP_OUT_HWIDTH[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x2453 )=  0x00;      // O_PIP_OUT_HWIDTH[ 9:8]
    ISPRW8(APACHE_ISP_BASE,0x2454 )=  0x00;      // PIP_REG_UPDATE_SEL : [0]
    ISPRW8(APACHE_ISP_BASE,0x2455 )=  0x00;      // o_pip_lut_ratio_fix_sel: [7] 
                                // o_pip_lut_ratio_fix    : [6]
                                //
                                //
                                // r_pip_bypass_en        : [3]
                                // r_pip_yscale_down      : [2]
                                // r_pip_xscale_down      : [1]
                                // o_pip_en               : [0]
 
    ISPRW8(APACHE_ISP_BASE,0x2456 )=  0x00;      // r_pip_xst[ 7:0] 
    ISPRW8(APACHE_ISP_BASE,0x2457 )=  0x00;      // r_pip_xst[10:8] 
    ISPRW8(APACHE_ISP_BASE,0x2458 )=  0x00;      // r_pip_yst[ 7:0] 
    ISPRW8(APACHE_ISP_BASE,0x2459 )=  0x00;      // r_pip_yst[10:8] 
    ISPRW8(APACHE_ISP_BASE,0x245A )=  0x00;      // r_pip_lut_ratio 
    ISPRW8(APACHE_ISP_BASE,0x245B )=  0x00;      // r_PIP_TXCNT     
    ISPRW8(APACHE_ISP_BASE,0x245C )=  0x00;      // r_PIP_TYCNT_1   
    ISPRW8(APACHE_ISP_BASE,0x245D )=  0x00;      // r_PIP_SOFFSET   
    ISPRW8(APACHE_ISP_BASE,0x245E )=  0x00;      // r_PIP_TOFFSET   
    ISPRW8(APACHE_ISP_BASE,0x245F )=  0x00;      // r_PIP_DSTW_1    
    ISPRW8(APACHE_ISP_BASE,0x2460 )=  0x00;      // r_PIP_DSTH_1       
    ISPRW8(APACHE_ISP_BASE,0x2461 )=  0x00;      // r_PIP_INCRW[ 7:0] 
    ISPRW8(APACHE_ISP_BASE,0x2462 )=  0x00;      // r_PIP_INCRW[15:8] 
    ISPRW8(APACHE_ISP_BASE,0x2463 )=  0x00;      // r_PIP_INCRH[ 7:0] 
    ISPRW8(APACHE_ISP_BASE,0x2464 )=  0x00;      // r_PIP_INCRH[15:8] 

    ISPRW8(APACHE_ISP_BASE,0x2465 )=  0x00;      // r_pip_yhblur_sel : [5:4]
                                // r_pip_chblur_sel : [1:0]
    ISPRW8(APACHE_ISP_BASE,0x2466 )=  0x00;      // r_hscl_pip_wr_dto[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x2467 )=  0x00;      // r_hscl_pip_wr_dto[12:8]
    ISPRW8(APACHE_ISP_BASE,0x2468 )=  0x00;      // r_vscl_pip_wr_dto[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x2469 )=  0x00;      // r_vscl_pip_wr_dto[12:8]
    ISPRW8(APACHE_ISP_BASE,0x246A )=  0x00;      // r_hscl_pip_rd_dto[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x246B )=  0x00;      // r_hscl_pip_rd_dto[12:8]
    ISPRW8(APACHE_ISP_BASE,0x246C )=  0x00;      // r_vscl_pip_rd_dto[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x246D )=  0x00;      // r_vscl_pip_rd_dto[12:8]
    ISPRW8(APACHE_ISP_BASE,0x246E )=  0x00;      // r_pip_lut_hpos[ 7:0]   
    ISPRW8(APACHE_ISP_BASE,0x246F )=  0x00;      // r_pip_lut_hpos[10:8]   
    ISPRW8(APACHE_ISP_BASE,0x2470 )=  0x00;      // r_pip_lut_vpos[ 7:0] 
    ISPRW8(APACHE_ISP_BASE,0x2471 )=  0x00;      // r_pip_lut_vpos[10:8] 

    ISPRW8(APACHE_ISP_BASE,0x2472 )=  0x00;      // O_PIP_LUT_RMAIN_EN         
    ISPRW8(APACHE_ISP_BASE,0x2473 )=  0x00;      // O_PIP_LUT_BASE_ADDR0[ 7: 0]
    ISPRW8(APACHE_ISP_BASE,0x2474 )=  0x00;      // O_PIP_LUT_BASE_ADDR0[15: 8]
    ISPRW8(APACHE_ISP_BASE,0x2475 )=  0x00;      // O_PIP_LUT_BASE_ADDR0[23:16]
    ISPRW8(APACHE_ISP_BASE,0x2476 )=  0x00;      // O_PIP_LUT_BASE_ADDR0[31:24]
    ISPRW8(APACHE_ISP_BASE,0x2477 )=  0x00;      // O_PIP_LUT_BASE_ADDR1[ 7: 0]
    ISPRW8(APACHE_ISP_BASE,0x2478 )=  0x00;      // O_PIP_LUT_BASE_ADDR1[15: 8]
    ISPRW8(APACHE_ISP_BASE,0x2479 )=  0x00;      // O_PIP_LUT_BASE_ADDR1[23:16]
    ISPRW8(APACHE_ISP_BASE,0x247A )=  0x00;      // O_PIP_LUT_BASE_ADDR1[31:24]
    ISPRW8(APACHE_ISP_BASE,0x247B )=  0x00;      // O_PIP_LUT_BURST_CTRL       
    ISPRW8(APACHE_ISP_BASE,0x247C )=  0x00;      // O_PIP_LUT_PRI_SET  : [6:4]                
                                // O_PIP_LUT_PRI_MODE : [1:0] 
    ISPRW8(APACHE_ISP_BASE,0x247D )=  0x00;      // O_PIP_RMAIN_READ_MODE    : [5]
                                // O_PIP_RMAIN_EN           : [4]
                                //
                                // O_PIP_WMAIN_WRAP_INIT_EN : [2]
                                // O_PIP_WMAIN_WRAP_EN      : [1]
                                // O_PIP_WMAIN_EN           : [0]

    ISPRW8(APACHE_ISP_BASE,0x247E )=  0x00;      // O_PIP_WMAIN_START_ADDR[ 7: 0] 
    ISPRW8(APACHE_ISP_BASE,0x247F )=  0x00;      // O_PIP_WMAIN_START_ADDR[15: 8]
    ISPRW8(APACHE_ISP_BASE,0x2480 )=  0x00;      // O_PIP_WMAIN_START_ADDR[23:16]
    ISPRW8(APACHE_ISP_BASE,0x2481 )=  0x00;      // O_PIP_WMAIN_START_ADDR[31:24]
    ISPRW8(APACHE_ISP_BASE,0x2482 )=  0x00;      // O_PIP_WMAIN_HPIXEL[ 7:0]     
    ISPRW8(APACHE_ISP_BASE,0x2483 )=  0x00;      // O_PIP_WMAIN_HPIXEL[ 9:8]     
    ISPRW8(APACHE_ISP_BASE,0x2484 )=  0x00;      // O_PIP_WMAIN_VLINE[ 7:0]      
    ISPRW8(APACHE_ISP_BASE,0x2485 )=  0x00;      // O_PIP_WMAIN_VLINE[ 9:8]      
    ISPRW8(APACHE_ISP_BASE,0x2486 )=  0x00;      // O_PIP_WMAIN_WLINE[ 7:0]      
    ISPRW8(APACHE_ISP_BASE,0x2487 )=  0x00;      // O_PIP_WMAIN_WLINE[11:8]      
    ISPRW8(APACHE_ISP_BASE,0x2488 )=  0x00;      // O_PIP_RMAIN_HPIXEL[ 7:0]     
    ISPRW8(APACHE_ISP_BASE,0x2489 )=  0x00;      // O_PIP_RMAIN_HPIXEL[ 9:8]     
    ISPRW8(APACHE_ISP_BASE,0x248A )=  0x00;      // O_PIP_RMAIN_VLINE[ 7:0]      
    ISPRW8(APACHE_ISP_BASE,0x248B )=  0x00;      // O_PIP_RMAIN_VLINE[ 9:8]      
    ISPRW8(APACHE_ISP_BASE,0x248C )=  0x00;      // O_PIP_RMAIN_WLINE[ 7:0]      
    ISPRW8(APACHE_ISP_BASE,0x248D )=  0x00;      // O_PIP_RMAIN_WLINE[11:8]      
    ISPRW8(APACHE_ISP_BASE,0x248E )=  0x00;      // O_PIP_RMAIN_BURST_CTRL : [7:4]
                                // O_PIP_WMAIN_BURST_CTRL : [3:0]
    ISPRW8(APACHE_ISP_BASE,0x248F )=  0x00;      // O_PIP_WMAIN_PRI_SET  : [6:4]
                                // O_PIP_WMAIN_PRI_MODE : [1:0]
    ISPRW8(APACHE_ISP_BASE,0x2490 )=  0x00;      // O_PIP_RMAIN_PRI_SET  : [6:4]
                                // O_PIP_RMAIN_PRI_MODE : [1:0]

    ISPRW8(APACHE_ISP_BASE,0x2491 )=  (ldc_in_height     ) & 0xFF;      // O_LDC_IN_VHEIGHT[7:0]    
    ISPRW8(APACHE_ISP_BASE,0x2492 )=  (ldc_in_height >> 8) & 0xFF;      // O_LDC_IN_VHEIGHT[10:8]  
    ISPRW8(APACHE_ISP_BASE,0x2493 )=  (ldc_in_height     ) & 0xFF;      // O_LDC_MEM_VHEIGHT[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x2494 )=  (ldc_in_height >> 8) & 0xFF;      // O_LDC_MEM_VHEIGHT[10:8] 
    ISPRW8(APACHE_ISP_BASE,0x2495 )=  (ldc_in_height     ) & 0xFF;      // O_LDC_OUT_VHEIGHT[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x2496 )=  (ldc_in_height >> 8) & 0xFF;      // O_LDC_OUT_VHEIGHT[10:8] 
    ISPRW8(APACHE_ISP_BASE,0x2497 )=  (ldc_out_vblk  >> 8) & 0xFF;      // O_LDC_OUT_VBLANK[7:0]   
    ISPRW8(APACHE_ISP_BASE,0x2498 )=  (ldc_out_vblk  >> 8) & 0xFF;      // O_LDC_OUT_VBLANK[15:8]  
    ISPRW8(APACHE_ISP_BASE,0x2499 )=  0x00;      // O_PIP_MEM_VHEIGHT[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x249A )=  0x00;      // O_PIP_MEM_VHEIGHT[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x249B )=  0x00;      // O_PIP_OUT_VHEIGHT[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x249C )=  0x00;      // O_PIP_OUT_VHEIGHT[9:8]  

    // Main Section
    ISPRW8(APACHE_ISP_BASE,0x24A0 )=  0x00;      // o_bg_color[ 7: 0] 
    ISPRW8(APACHE_ISP_BASE,0x24A1 )=  0x00;      // o_bg_color[15: 8]
    ISPRW8(APACHE_ISP_BASE,0x24A2 )=  0x00;      // o_bg_color[23:16]
    ISPRW8(APACHE_ISP_BASE,0x24A3 )=  0x00;      // o_sect1_en : [4]
                                // o_sect0_en : [0]
    ISPRW8(APACHE_ISP_BASE,0x24A4 )=  0x00;      // o_sect0_xst[ 7:0]     
    ISPRW8(APACHE_ISP_BASE,0x24A5 )=  0x00;      // o_sect0_xst[10:8]    
    ISPRW8(APACHE_ISP_BASE,0x24A6 )=  0x00;      // o_sect0_wid_m1[ 7:0] 
    ISPRW8(APACHE_ISP_BASE,0x24A7 )=  0x00;      // o_sect0_wid_m1[10:8] 
    ISPRW8(APACHE_ISP_BASE,0x24A8 )=  0x00;      // o_sect0_yst[ 7:0]    
    ISPRW8(APACHE_ISP_BASE,0x24A9 )=  0x00;      // o_sect0_yst[10:8]    
    ISPRW8(APACHE_ISP_BASE,0x24AA )=  0x00;      // o_sect0_hei_m1[ 7:0] 
    ISPRW8(APACHE_ISP_BASE,0x24AB )=  0x00;      // o_sect0_hei_m1[10:8] 
    ISPRW8(APACHE_ISP_BASE,0x24AC )=  0x00;      // o_sect1_xst[ 7:0]    
    ISPRW8(APACHE_ISP_BASE,0x24AD )=  0x00;      // o_sect1_xst[10:8]    
    ISPRW8(APACHE_ISP_BASE,0x24AE )=  0x00;      // o_sect1_wid_m1[ 7:0] 
    ISPRW8(APACHE_ISP_BASE,0x24AF )=  0x00;      // o_sect1_wid_m1[10:8] 
    ISPRW8(APACHE_ISP_BASE,0x24B0 )=  0x00;      // o_sect1_yst[ 7:0]   
    ISPRW8(APACHE_ISP_BASE,0x24B1 )=  0x00;      // o_sect1_yst[10:8]   
    ISPRW8(APACHE_ISP_BASE,0x24B2 )=  0x00;      // o_sect1_hei_m1[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x24B3 )=  0x00;      // o_sect1_hei_m1[10:8]

    // PIP Section
    ISPRW8(APACHE_ISP_BASE,0x24B4 )=  0x00;      // r_pip_bg_color[ 7: 0]
    ISPRW8(APACHE_ISP_BASE,0x24B5 )=  0x00;      // r_pip_bg_color[15: 8]
    ISPRW8(APACHE_ISP_BASE,0x24B6 )=  0x00;      // r_pip_bg_color[23:16]
    ISPRW8(APACHE_ISP_BASE,0x24B7 )=  0x00;      // r_pip_sect1_en : [4]
                                // r_pip_sect0_en : [0]
    ISPRW8(APACHE_ISP_BASE,0x24B8 )=  0x00;      // r_pip_sect0_xst[ 7:0]   
    ISPRW8(APACHE_ISP_BASE,0x24B9 )=  0x00;      // r_pip_sect0_xst[ 9:8]   
    ISPRW8(APACHE_ISP_BASE,0x24BA )=  0x00;      // r_pip_sect0_wid_m1[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x24BB )=  0x00;      // r_pip_sect0_wid_m1[ 9:8]
    ISPRW8(APACHE_ISP_BASE,0x24BC )=  0x00;      // r_pip_sect0_yst[ 7:0]   
    ISPRW8(APACHE_ISP_BASE,0x24BD )=  0x00;      // r_pip_sect0_yst[ 9:8]   
    ISPRW8(APACHE_ISP_BASE,0x24BE )=  0x00;      // r_pip_sect0_hei_m1[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x24BF )=  0x00;      // r_pip_sect0_hei_m1[ 9:8]
    ISPRW8(APACHE_ISP_BASE,0x24C0 )=  0x00;      // r_pip_sect1_xst[ 7:0]     
    ISPRW8(APACHE_ISP_BASE,0x24C1 )=  0x00;      // r_pip_sect1_xst[ 9:8]    
    ISPRW8(APACHE_ISP_BASE,0x24C2 )=  0x00;      // r_pip_sect1_wid_m1[ 7:0] 
    ISPRW8(APACHE_ISP_BASE,0x24C3 )=  0x00;      // r_pip_sect1_wid_m1[ 9:8] 
    ISPRW8(APACHE_ISP_BASE,0x24C4 )=  0x00;      // r_pip_sect1_yst[ 7:0]    
    ISPRW8(APACHE_ISP_BASE,0x24C5 )=  0x00;      // r_pip_sect1_yst[ 9:8]    
    ISPRW8(APACHE_ISP_BASE,0x24C6 )=  0x00;      // r_pip_sect1_hei_m1[ 7:0] 
    ISPRW8(APACHE_ISP_BASE,0x24C7 )=  0x00;      // r_pip_sect1_hei_m1[ 9:8] 

    // Pre Y HPF
    ISPRW8(APACHE_ISP_BASE,0x24F0 )=  0x00;      // PYHPF_SEL : [2:1]
                                // PYHPF_EN  : [0]
    ISPRW8(APACHE_ISP_BASE,0x24F1 )=  0x00;      // PYHPF_PLUS_OFFSET  
    ISPRW8(APACHE_ISP_BASE,0x24F2 )=  0x00;      // PYHPF_MINUS_OFFSET 
    ISPRW8(APACHE_ISP_BASE,0x24F3 )=  0x00;      // PYHPF_PLUS_GAIN    
    ISPRW8(APACHE_ISP_BASE,0x24F4 )=  0x00;      // PYHPF_MINUS_GAIN   
}

void csc_set(void)
{
    // RGB2YCbCr
    ISPRW8(APACHE_ISP_BASE,0x02A5 )=  0x6D;      // CSC_Y_R_GAIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02A6 )=  0x00;      // CSC_Y_R_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02A7 )=  0x6E;      // CSC_Y_G_GAIN[7:0]
    ISPRW8(APACHE_ISP_BASE,0x02A8 )=  0x01;      // CSC_Y_G_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02A9 )=  0x25;      // CSC_Y_B_GAIN[7:0]
    ISPRW8(APACHE_ISP_BASE,0x02AA )=  0x00;      // CSC_Y_B_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02AB )=  0x00;      // CSC_Y_OFFSET[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02AC )=  0x00;      // CSC_Y_OFFSET[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02AD )=  0x00;      // CSC_Y_MIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02AE )=  0x00;      // CSC_Y_MIN[9:8]
    ISPRW8(APACHE_ISP_BASE,0x02AF )=  0xFF;      // CSC_Y_MAX[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02B0 )=  0x03;      // CSC_Y_MAX[9:8]

    ISPRW8(APACHE_ISP_BASE,0x02B1 )=  0xC5;      // CSC_CB_R_GAIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02B2 )=  0x0F;      // CSC_CB_R_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02B3 )=  0x3B;      // CSC_CB_G_GAIN[7:0]
    ISPRW8(APACHE_ISP_BASE,0x02B4 )=  0x0F;      // CSC_CB_G_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02B5 )=  0x00;      // CSC_CB_B_GAIN[7:0]
    ISPRW8(APACHE_ISP_BASE,0x02B6 )=  0x01;      // CSC_CB_B_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02B7 )=  0x00;      // CSC_CB_OFFSET[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02B8 )=  0x02;      // CSC_CB_OFFSET[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02B9 )=  0x00;      // CSC_CB_MIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02BA )=  0x00;      // CSC_CB_MIN[9:8]
    ISPRW8(APACHE_ISP_BASE,0x02BB )=  0xFF;      // CSC_CB_MAX[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02BC )=  0x03;      // CSC_CB_MAX[9:8]

    ISPRW8(APACHE_ISP_BASE,0x02BD )=  0x00;      // CSC_CR_R_GAIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02BE )=  0x01;      // CSC_CR_R_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02BF )=  0x17;      // CSC_CR_G_GAIN[7:0]
    ISPRW8(APACHE_ISP_BASE,0x02C0 )=  0x0F;      // CSC_CR_G_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02C1 )=  0xE9;      // CSC_CR_B_GAIN[7:0]
    ISPRW8(APACHE_ISP_BASE,0x02C2 )=  0x0F;      // CSC_CR_B_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02C3 )=  0x00;      // CSC_CR_OFFSET[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02C4 )=  0x02;      // CSC_CR_OFFSET[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02C5 )=  0x00;      // CSC_CR_MIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02C6 )=  0x00;      // CSC_CR_MIN[9:8]
    ISPRW8(APACHE_ISP_BASE,0x02C7 )=  0xFF;      // CSC_CR_MAX[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02C8 )=  0x03;      // CSC_CR_MAX[9:8]

    // RGB2RGB
    ISPRW8(APACHE_ISP_BASE,0x02E0 )=  0x00;      // CSC_R_R_GAIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02E1 )=  0x01;      // CSC_R_R_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02E2 )=  0x00;      // CSC_R_G_GAIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02E3 )=  0x00;      // CSC_R_G_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02E4 )=  0x00;      // CSC_R_B_GAIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02E5 )=  0x00;      // CSC_R_B_GAIN[11:8]

    ISPRW8(APACHE_ISP_BASE,0x02E6 )=  0x00;      // CSC_G_R_GAIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02E7 )=  0x00;      // CSC_G_R_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02E8 )=  0x00;      // CSC_G_G_GAIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02E9 )=  0x01;      // CSC_G_G_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02EA )=  0x00;      // CSC_G_B_GAIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02EB )=  0x00;      // CSC_G_B_GAIN[11:8]

    ISPRW8(APACHE_ISP_BASE,0x02EC )=  0x00;      // CSC_B_R_GAIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02ED )=  0x00;      // CSC_B_R_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02EE )=  0x00;      // CSC_B_G_GAIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02EF )=  0x00;      // CSC_B_G_GAIN[11:8]
    ISPRW8(APACHE_ISP_BASE,0x02F0 )=  0x00;      // CSC_B_B_GAIN[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02F1 )=  0x01;      // CSC_B_B_GAIN[11:8]

    ISPRW8(APACHE_ISP_BASE,0x02F2 )=  0x00;      // CSC_R_OFFSET[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02F3 )=  0x00;      // CSC_G_OFFSET[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x02F4 )=  0x00;      // CSC_B_OFFSET[ 7:0]
//    ISPRW8(APACHE_ISP_BASE,0x02F5 )=  0x00;      // CSC_RGB_ALPHA
}

void BLC_set()
{
    ISPRW8(APACHE_ISP_BASE,0x0160 )=  0x02;  // [7]:1'h0,
                            // [6]:BLC_AGC
                            // [5]:BLC_V_OB
                            // [4]:BLC_H_OB
                            // [3]:BLC_OFFSET_H_SWAP
                            // [2]:BLC_OFFSET_V_SWAP
                            // [1]:BLC_OFFSET_EN
                            // [0]:BLC_EN

    ISPRW8(APACHE_ISP_BASE,0x0161 )=  0x00;  // [7:6]:BLC_FRAME 
                            // [5:4]:BLC_PRE
                            // [2:0]:BLC_MODE

    ISPRW8(APACHE_ISP_BASE,0x0162 )=  0x00;  // [3]:BLC_GR_SIGN
                            // [2]:BLC_R_SIGN
                            // [1]:BLC_B_SIGN
                            // [0]:BLC_GB_SIGN

    ISPRW8(APACHE_ISP_BASE,0x0163 )=  0x0A;  // BLC_OFFSET_GR_pre[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x0164 )=  0x00;  // BLC_OFFSET_GR_pre[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0165 )=  0x0A;  // BLC_OFFSET_R_pre[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x0166 )=  0x00;  // BLC_OFFSET_R_pre[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0167 )=  0x0A;  // BLC_OFFSET_B_pre[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x0168 )=  0x00;  // BLC_OFFSET_B_pre[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0169 )=  0x0A;  // BLC_OFFSET_GB_pre[ 7:0]
    ISPRW8(APACHE_ISP_BASE,0x016A )=  0x00;  // BLC_OFFSET_GB_pre[11:8]
    ISPRW8(APACHE_ISP_BASE,0x016B )=  0x00;  // H_OB_HSYNC_SIZE 
    ISPRW8(APACHE_ISP_BASE,0x016C )=  0x00;  // H_OB_VSYNC_SIZE[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x016D )=  0x00;  // H_OB_VSYNC_SIZE[11:8]
    ISPRW8(APACHE_ISP_BASE,0x016E )=  0x00;  // V_OB_HSYNC_SIZE[7:0]
    ISPRW8(APACHE_ISP_BASE,0x016F )=  0x00;  // V_OB_HSYNC_SIZE[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0170 )=  0x00;  // V_OB_VSYNC_SIZE 
    ISPRW8(APACHE_ISP_BASE,0x0171 )=  0x00;  // BLACK_LEVEL[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0172 )=  0x00;  // BLACK_LEVEL[11:8]
}

void LSC_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x01B0 )=  0x00;  // LSAC_DIST_MODE[4], LSC_H_SWAP[3], LSC_V_SWAP[2], LSC_EN[0]

    ISPRW8(APACHE_ISP_BASE,0x01B1 )=  0x00;  // LSC_CENT_X[3:0], 4'h0
    ISPRW8(APACHE_ISP_BASE,0x01B2 )=  0x51;  // LSC_CENT_X[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01B3 )=  0XC0;  // LSC_CENT_Y[3:0], 4'h0
    ISPRW8(APACHE_ISP_BASE,0x01B4 )=  0x3C;  // LSC_CENT_Y[11:4]

    ISPRW8(APACHE_ISP_BASE,0x01B5 )=  0x08;  // LSC_GR_GAIN
    ISPRW8(APACHE_ISP_BASE,0x01B6 )=  0x01;  // LSC_R_GAIN
    ISPRW8(APACHE_ISP_BASE,0x01B7 )=  0x01;  // LSC_B_GAIN
    ISPRW8(APACHE_ISP_BASE,0x01B8 )=  0x08;  // LSC_GB_GAIN

    ISPRW8(APACHE_ISP_BASE,0x01B9 )=  0x88;  // LSC_R_SHIFT, LSC_GR_SHIFT
    ISPRW8(APACHE_ISP_BASE,0x01BA )=  0x88;  // LSC_GB_SHIFT, LSC_B_SHIFT

    ISPRW8(APACHE_ISP_BASE,0x01BB )=  0x00;  // 3'h0, LSC_Y_MODE, LSC_Y_SHIFT[3:0]
    ISPRW8(APACHE_ISP_BASE,0x01BC )=  0x00;  // LSC_Y_GAIN
}

void YPROC_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0700 )=  0x01;  // {C_SAT_BW,
                            //  C_SAT_EN,
                            //  C_HUE_EN,
                            //  C_ENHANCE_EN,
                            //  SEL_OLD_HUE,
                            //  INIT_BLACK,
                            //  NEGA_EN,
                            //  Y_ENHANCE_EN};
    ISPRW8(APACHE_ISP_BASE,0x0701 )=  0x10;  // Y_OFFSET[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0702 )=  0x00;  // 5'd0,Y_OFFSET[10:8]}
    ISPRW8(APACHE_ISP_BASE,0x0703 )=  0x00;  // Y_OFFSET2[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0704 )=  0x00;  // {5'd0,Y_OFFSET2[10:8]};
    ISPRW8(APACHE_ISP_BASE,0x0705 )=  0x90;  // Y_GAIN[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0706 )=  0x00;  // {4'd0,Y_GAIN[11:8]};
    ISPRW8(APACHE_ISP_BASE,0x0707 )=  0xFF;  // Y_CLIP_TH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0708 )=  0x03;  // {6'd0,Y_CLIP_TH[9:8]}
}
void CPROC_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0700 )=  0x61;  // {C_SAT_BW,C_SAT_EN,C_HUE_EN,C_ENHANCE_EN, 1'h0,INIT_BLACK,NEGA_EN,Y_ENHANCE_EN};
    ISPRW8(APACHE_ISP_BASE,0x0709 )=  0x7F;  // CB_SAT_GAIN
    ISPRW8(APACHE_ISP_BASE,0x070A )=  0x7F;  // CR_SAT_GAIN
    ISPRW8(APACHE_ISP_BASE,0x070B )=  0x00;  // C_HUE1
    ISPRW8(APACHE_ISP_BASE,0x070C )=  0x00;  // C_HUE2
    ISPRW8(APACHE_ISP_BASE,0x070D )=  0x00;  // C_HUE3
    ISPRW8(APACHE_ISP_BASE,0x070E )=  0x00;  // C_HUE4
    ISPRW8(APACHE_ISP_BASE,0x070F )=  0x00;  // C_HUE5
    ISPRW8(APACHE_ISP_BASE,0x0710 )=  0x00;  // C_HUE6
    ISPRW8(APACHE_ISP_BASE,0x0711 )=  0x80;  // C_HUE_GAIN1
    ISPRW8(APACHE_ISP_BASE,0x0712 )=  0x80;  // C_HUE_GAIN2
    ISPRW8(APACHE_ISP_BASE,0x0713 )=  0x80;  // C_HUE_GAIN3
    ISPRW8(APACHE_ISP_BASE,0x0714 )=  0x80;  // C_HUE_GAIN4
    ISPRW8(APACHE_ISP_BASE,0x0715 )=  0x80;  // C_HUE_GAIN5
    ISPRW8(APACHE_ISP_BASE,0x0716 )=  0x80;  // C_HUE_GAIN6
    ISPRW8(APACHE_ISP_BASE,0x0717 )=  0x40;  // C_DIFF_REF[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0718 )=  0x00;  // C_DIFF_REF[9:8]
    ISPRW8(APACHE_ISP_BASE,0x0719 )=  0x10;  // CB_DIFF_OFFSET[7:0]
    ISPRW8(APACHE_ISP_BASE,0x071A )=  0x00;  // CB_DIFF_OFFSET[9:8]
    ISPRW8(APACHE_ISP_BASE,0x071B )=  0x10;  // CR_DIFF_OFFSET[7:0]
    ISPRW8(APACHE_ISP_BASE,0x071C )=  0x00;  // CR_DIFF_OFFSET[9:8]
}

void C_HL_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0720 )=  0x00;  // {HL_TEST_MODE,
                            //  C_HL_SUP_EN,
                            //  C_AGC_SUP_EN,
                            //  5'h0};

    ISPRW8(APACHE_ISP_BASE,0x0721 )=  0x84;  // C_HL_SUP_HI[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0722 )=  0x01;  // {7'h0, C_HL_SUP_HI[8]};
    ISPRW8(APACHE_ISP_BASE,0x0723 )=  0x00;  // C_HL_SUP_LOW[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0724 )=  0x00;  // {7'h0, C_HL_SUP_LOW[8]};
    ISPRW8(APACHE_ISP_BASE,0x0725 )=  0xFF;  // C_HL_SUP_HI_GAIN  
    ISPRW8(APACHE_ISP_BASE,0x0726 )=  0x00;  // C_HL_SUP_LOW_GAIN 

}

void C_SUP_AGC_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0720 )=  0x00;  // {HL_TEST_MODE,
                            //  C_HL_SUP_EN,
                            //  C_AGC_SUP_EN,
                            //  5'h0};

    ISPRW8(APACHE_ISP_BASE,0x0727 )=  0x10;  // C_AGC_START_X
    ISPRW8(APACHE_ISP_BASE,0x0728 )=  0x80;  // C_AGC_MIDDLE_X
    ISPRW8(APACHE_ISP_BASE,0x0729 )=  0xFF;  // C_AGC_END_X
    ISPRW8(APACHE_ISP_BASE,0x072A )=  0x20;  // C_AGC_START_Y
    ISPRW8(APACHE_ISP_BASE,0x072B )=  0x40;  // C_AGC_MIDDLE_Y
    ISPRW8(APACHE_ISP_BASE,0x072C )=  0x80;  // C_AGC_END_Y
}

void HLC_set()
{
    ISPRW8(APACHE_ISP_BASE,0x01C0 )=  0x02;  // 6'd0,HLC_MIX_VISUAL_EN, HLC_MIX_EN

    ISPRW8(APACHE_ISP_BASE,0x01C1 )=  128;  // HLC_PIX_TH
    ISPRW8(APACHE_ISP_BASE,0x01C2 )=  0xff;  // HLC_CNT_LIM

    ISPRW8(APACHE_ISP_BASE,0x01C3 )=  0x00;  // HLC_X0_START[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01C4 )=  0x00;  // HLC_Y0_START[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01C5 )=  0x28;  // HLC_X0_WIDTH[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01C6 )=  0x1E;  // HLC_Y0_HEIGHT[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01C7 )=  0x00;  // HLC_X0_START[3:0],HLC_Y0_START[3:0]
    ISPRW8(APACHE_ISP_BASE,0x01C8 )=  0x86;  // HLC_X0_WIDTH[3:0],HLC_Y0_HEIGHT[3:0]
    ISPRW8(APACHE_ISP_BASE,0x01C9 )=  0x05;  // HLC_ATTR0

    ISPRW8(APACHE_ISP_BASE,0x01CA )=  0x79;  // HLC_X1_START[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01CB )=  0x00;  // HLC_Y1_START[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01CC )=  0x28;  // HLC_X1_WIDTH[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01CD )=  0x1E;  // HLC_Y1_HEIGHT[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01CE )=  0x80;  // HLC_X1_START[3:0],HLC_Y1_START[3:0]
    ISPRW8(APACHE_ISP_BASE,0x01CF )=  0x86;  // HLC_X1_WIDTH[3:0],HLC_Y1_HEIGHT[3:0]
    ISPRW8(APACHE_ISP_BASE,0x01D0 )=  0x05;  // HLC_ATTR1

    ISPRW8(APACHE_ISP_BASE,0x01D1 )=  0x00;  // HLC_X2_START[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01D2 )=  0x5B;  // HLC_Y2_START[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01D3 )=  0x28;  // HLC_X2_WIDTH[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01D4 )=  0x1E;  // HLC_Y2_HEIGHT[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01D5 )=  0x02;  // HLC_X2_START[3:0],HLC_Y2_START[3:0]
    ISPRW8(APACHE_ISP_BASE,0x01D6 )=  0x86;  // HLC_X2_WIDTH[3:0],HLC_Y2_HEIGHT[3:0]
    ISPRW8(APACHE_ISP_BASE,0x01D7 )=  0x05;  // HLC_ATTR2

    ISPRW8(APACHE_ISP_BASE,0x01D8 )=  0x79;  // HLC_X3_START[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01D9 )=  0x5B;  // HLC_Y3_START[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01DA )=  0x28;  // HLC_X3_WIDTH[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01DB )=  0x1E;  // HLC_Y3_HEIGHT[11:4]
    ISPRW8(APACHE_ISP_BASE,0x01DC )=  0x82;  // HLC_X3_START[3:0],HLC_Y3_START[3:0]
    ISPRW8(APACHE_ISP_BASE,0x01DD )=  0x86;  // HLC_X3_WIDTH[3:0],HLC_Y3_HEIGHT[3:0]
    ISPRW8(APACHE_ISP_BASE,0x01DE )=  0x05;  // HLC_ATTR3
}

void RGB_BOX_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0690 )=  0x09;  // 4'd0, RGB_BOX_SIZE[2:0],RGB_BOX_EN
    ISPRW8(APACHE_ISP_BASE,0x0691 )=  0x00;  // RGB_BOX_POINT_X[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0692 )=  0x00;  // RGB_BOX_POINT_Y[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0693 )=  0x00;  // RGB_BOX_POINT_X[11:8],RGB_BOX_POINT_Y[11:8]
}

void PMASK_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0750 )=  0xC3; // [7:6]:PM_CH_EN
                           // [5:4]:PM_BLINK
                           // [3]  :1'd0
                           // [2:1]:PM_SEL
                           // [0]  :PM_ENABLE
    ISPRW8(APACHE_ISP_BASE,0x0751 )=  0x0D; // [7:6]:AE_AREA_BLINK
                           // [5]  :PM_BOUNDARY_EN0
                           // [4:3]:PM_TRANS0
                           // [2]  :PM_BOUNDARY_EN1
                           // [1:0]:PM_TRANS1
    ISPRW8(APACHE_ISP_BASE,0x0752 )=  0x00; // PM_H0_START[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0753 )=  0x00; // PM_H0_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0754 )=  0x00; // PM_V0_START[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0755 )=  0x00; // PM_V0_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0756 )=  0x00; // PM_H0_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x0757 )=  0x0A; // PM_H0_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x0758 )=  0x0F; // PM_V0_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x0759 )=  0x00; // PM_V0_SIZE[11:8] 

    ISPRW8(APACHE_ISP_BASE,0x075A )=  0x00; // PM_H1_START[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x075B )=  0x00; // PM_H1_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x075C )=  0x00; // PM_V1_START[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x075D )=  0x00; // PM_V1_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x075E )=  0x40; // PM_H1_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x075F )=  0x00; // PM_H1_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x0760 )=  0xA0; // PM_V1_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x0761 )=  0x05; // PM_V1_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x0762 )=  0xFF; // PM_Y_VAL0[7:0]   

    ISPRW8(APACHE_ISP_BASE,0x0763 )=  0xE2; // PM_CB_VAL0[3:0]   
                           // PM_CR_VAL0[3:0]
    ISPRW8(APACHE_ISP_BASE,0x0764 )=  0xFF; // PM_Y_VAL1[7:0]   
    ISPRW8(APACHE_ISP_BASE,0x0765 )=  0x2E; // PM_CB_VAL1[3:0]   
                           // PM_CR_VAL1[3:0]
}

void FLK_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0200 )=  0x00;  // FLK_HSTART
    ISPRW8(APACHE_ISP_BASE,0x0201 )=  0x00;  // FLK_VSTART
    ISPRW8(APACHE_ISP_BASE,0x0202 )=  0x15;  // FLK_HWIDTH[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0203 )=  0x0A;  // FLK_HWIDTH[12:8]
    ISPRW8(APACHE_ISP_BASE,0x0204 )=  0x1F;  // FLK_VHEIGHT
    ISPRW8(APACHE_ISP_BASE,0x0205 )=  0x20;  // FLK_MODE,FLK_FRAME_SEL,FLK_SHIFT[3:0]
}

void LPF_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x04A0 )=  0xA1 ;    // {LPF_LEVEL[7:4],1'd0,r_iblur_debug_mode, LPF_EN[0]}
    ISPRW8(APACHE_ISP_BASE,0x04A2 )=  0x00 ;    // {IBLUR_EDGE_RATIO[7:4], IBLUR_INT3_EDGE[1:0]
}

void DEFOG_set (void) {
    ISPRW8(APACHE_ISP_BASE,0x0300 )=  0x17;  // [7]:-
                            // [6]:DEFOG_ZONE_AAH[1]
                            // [5]:DEFOG_ZONE_AAH[0]
                            // [4]:DEFOG_ALPHA_EN
                            // [3]:DEFOG_INIT
                            // [2]:DEFOG_ON
                            // [1]:FOG_AH_ON
                            // [0]:FOG_DETEC_ON

    ISPRW8(APACHE_ISP_BASE,0x0301 )=  0xF2;  // DEFOG_BOUND_MULT[3:0]
                            // DEFOG_CE_GAIN[3:0]
 
    ISPRW8(APACHE_ISP_BASE,0x0302 )=  0x00;  // DEFOG_ZONE_HPOS[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0303 )=  0x00;  // DEFOG_ZONE_VPOS[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0304 )=  0x00;  // DEFOG_ZONE_HLEN[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0305 )=  0x20;  // DEFOG_ZONE_VLEN[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0306 )=  0x09;  // DEFOG_ZONE_HPOS[9:8]
                            // DEFOG_ZONE_VPOS[9:8]
                            // DEFOG_ZONE_HLEN[9:8]
                            // DEFOG_ZONE_VLEN[9:8]

    ISPRW8(APACHE_ISP_BASE,0x0307 )=  0xD7;  // FOG_AH_MAX_TH
    ISPRW8(APACHE_ISP_BASE,0x0308 )=  0x00;  // FOG_AH_MIN_TH
    ISPRW8(APACHE_ISP_BASE,0x0309 )=  0x00;  // FOG_AH_IIR_LEVEL
    ISPRW8(APACHE_ISP_BASE,0x030A )=  0x00;  // FOG_DETEC_ON_TH
    ISPRW8(APACHE_ISP_BASE,0x030B )=  0x00;  // FOG_DETEC_OFF_TH
    ISPRW8(APACHE_ISP_BASE,0x030C )=  0x00;  // FOG_DETEC_IIR_LEVEL

    ISPRW8(APACHE_ISP_BASE,0x030D )=  0x00;  // DEFOG_HS_MAX_Y[7:0]
    ISPRW8(APACHE_ISP_BASE,0x030E )=  0x53;  // DEFOG_HS_MAX_Y[15:8]
    ISPRW8(APACHE_ISP_BASE,0x030F )=  0x00;  // DEFOG_HS_MIN_Y[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0310 )=  0x51;  // DEFOG_HS_MIN_Y[15:8]
    ISPRW8(APACHE_ISP_BASE,0x0311 )=  0x1F;  // DEFOG_HS_MAX_Y[23:16]

    ISPRW8(APACHE_ISP_BASE,0x0312 )=  0xFF;  // DEFOG_HS_SMAX_Y
    ISPRW8(APACHE_ISP_BASE,0x0313 )=  0x00;  // DEFOG_HS_SMIN_Y

    ISPRW8(APACHE_ISP_BASE,0x0314 )=  0x00;  // DEFOG_IYMAX_IIR_LEVEL
    ISPRW8(APACHE_ISP_BASE,0x0315 )=  0x00;  // DEFOG_IYMIN_IIR_LEVEL

    ISPRW8(APACHE_ISP_BASE,0x0316 )=  0xC0;  // DEFOG_IYMAX 
    ISPRW8(APACHE_ISP_BASE,0x0317 )=  0x50;  // DEFOG_IYMIN 

    ISPRW8(APACHE_ISP_BASE,0x0318 )=  0xFF;  // DEFOG_CHG_INC 
    ISPRW8(APACHE_ISP_BASE,0x0319 )=  0x00;  // DEFOG_ON_TIME 
    ISPRW8(APACHE_ISP_BASE,0x031A )=  0x00;  // DEFOG_OFF_TIME 

    ISPRW8(APACHE_ISP_BASE,0x031B )=  0x00;  // [7]:DEFOG_IYMAX_SEL 
                            // [6]:DEFOG_IYMIN_SEL
                            // [3]:DEFOG_ON_TIME[9:8]
                            // [2]:DEFOG_ON_TIME[9:8]
                            // [1]:DEFOG_OFF_TIME[9:8]
                            // [0]:DEFOG_OFF_TIME[9:8]
    ISPRW8(APACHE_ISP_BASE,0x0325 )=  0x00;  // DEFOG_HS_MIN_Y[23:16] 
}

void ACCE_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x07FC )=  0xFF & (FRC_HACT     );
    ISPRW8(APACHE_ISP_BASE,0x07FD )=  0xFF & (FRC_HACT >> 8);
    ISPRW8(APACHE_ISP_BASE,0x07FE )=  0xFF & (FRC_VACT     );
    ISPRW8(APACHE_ISP_BASE,0x07FF )=  0xFF & (FRC_VACT >> 8);
}

void ALLNR_LTM_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x0770 )=  0x70;  // ALLNR_EN[4]
    ISPRW8(APACHE_ISP_BASE,0x0775 )=  0x41;  // LTM_BLUR1_SEL[6:5] (0:3x3, 1:5x5, 2:5x5, 3:md)
                            // LTM_EN[0]
    ISPRW8(APACHE_ISP_BASE,0x0776 )=  0x80;  // LTM_BRATIO2[7:4] (0:strong, 1:weak)
                            // LTM_BRATIO [3:0] (0:strong, 1:weak)
    ISPRW8(APACHE_ISP_BASE,0x0777 )=  0x10;  // LTM_THR_X0
    ISPRW8(APACHE_ISP_BASE,0x0778 )=  0x20;  // LTM_THR_X1
    ISPRW8(APACHE_ISP_BASE,0x0779 )=  0x30;  // LTM_THR_X2
    ISPRW8(APACHE_ISP_BASE,0x077B )=  0x02;  // LTM_THR_Y0
    ISPRW8(APACHE_ISP_BASE,0x077B )=  0x12;  // LTM_THR_Y1
    ISPRW8(APACHE_ISP_BASE,0x077C )=  0x22;  // LTM_THR_Y2
    ISPRW8(APACHE_ISP_BASE,0x077D )=  0x44;  // LTM_THR_Y3
    ISPRW8(APACHE_ISP_BASE,0x077E )=  0x18;  // LTM_EHC_GAIN
    ISPRW8(APACHE_ISP_BASE,0x077F )=  0x50;  // LTM_EHC_GAIN2
    ISPRW8(APACHE_ISP_BASE,0x0780 )=  0x00;  // LTM_DEBUG

    ISPRW8(APACHE_ISP_BASE,0x0781 )=  0x00;  // unused
    ISPRW8(APACHE_ISP_BASE,0x0782 )=  0x00;  // unused
    ISPRW8(APACHE_ISP_BASE,0x0783 )=  0x00;  // unused
    ISPRW8(APACHE_ISP_BASE,0x0784 )=  0x00;  // unused
    ISPRW8(APACHE_ISP_BASE,0x0785 )=  0x00;  // unused
    ISPRW8(APACHE_ISP_BASE,0x0786 )=  0x00;  // unused
    ISPRW8(APACHE_ISP_BASE,0x0787 )=  0x00;  // unused
    ISPRW8(APACHE_ISP_BASE,0x0788 )=  0x00;  // unused

    ISPRW8(APACHE_ISP_BASE,0x0789 )=  0x1C;  // LTM_BLUR0_SEL[4:3] (0:3x3,1:5x5,2:md,3:original)
                            // LTM_COV_GAIN_EN[2]
    ISPRW8(APACHE_ISP_BASE,0x078A )=  0xFF;  // LTM_COV_GAIN
    ISPRW8(APACHE_ISP_BASE,0x078B )=  0xFF;  // LTM_COV_GAIN
    ISPRW8(APACHE_ISP_BASE,0x078C )=  0x00;  // LTM_COV_TH
    ISPRW8(APACHE_ISP_BASE,0x078D )=  0x00;  // LTM_COV_TH
}

void CROP_set(void)
{

    ISPRW8(APACHE_ISP_BASE,0x0600 )=  0x11; // bypass
//    ISPRW8(APACHE_ISP_BASE,0x0600 )=  0x21; // crop use
    ISPRW8(APACHE_ISP_BASE,0x0601 )=  0xFF & CROP_VACT;
    ISPRW8(APACHE_ISP_BASE,0x0602 )=  0x0F & (CROP_VACT>>8);
    ISPRW8(APACHE_ISP_BASE,0x0603 )=  0xFF & CROP_HACT; 
    ISPRW8(APACHE_ISP_BASE,0x0604 )=  0x0F & (CROP_HACT>>8);
    ISPRW8(APACHE_ISP_BASE,0x0605 )=  0xFF & I_DS_VACT;
    ISPRW8(APACHE_ISP_BASE,0x0606 )=  0x0F & (I_DS_VACT>>8);
    ISPRW8(APACHE_ISP_BASE,0x0607 )=  0xFF & I_DS_HACT;
    ISPRW8(APACHE_ISP_BASE,0x0608 )=  0x0F & (I_DS_HACT>>8);
}

void HV_DS_set(void)
{
    unsigned long h_dto, v_dto;
    unsigned long w_dto, r_dto;
    unsigned long delay_time;

    h_dto = (unsigned long)I_DS_HACT * 4096 / O_DS_HACT;
    v_dto = (unsigned long)I_DS_VACT * 4096 / O_DS_VACT;

    w_dto = (unsigned long)I_DS_HACT * 4096 / O_DS_HACT;
    r_dto = (unsigned long)O_DS_VACT * 4096 / O_DS_VACT; 

    delay_time = (unsigned long)(O_DS_HACT * (w_dto - r_dto) / 4096) + 5;
    
    ISPRW8(APACHE_ISP_BASE,0x0610 )=  0x0e;                   
    ISPRW8(APACHE_ISP_BASE,0x0613 )=  0x1F & (FRC_HACT>> 8);  
    ISPRW8(APACHE_ISP_BASE,0x0612 )=  0xFF & FRC_HACT;        
    ISPRW8(APACHE_ISP_BASE,0x0615 )=  0x1F & (FRC_HBLK>> 8);  
    ISPRW8(APACHE_ISP_BASE,0x0614 )=  0xFF & FRC_HBLK;        
    ISPRW8(APACHE_ISP_BASE,0x0617 )=  0x1F & (FRC_VACT>> 8);  
    ISPRW8(APACHE_ISP_BASE,0x0616 )=  0xFF & FRC_VACT;        

    ISPRW8(APACHE_ISP_BASE,0x061B )=  0xFF & (h_dto >> 8);    
    ISPRW8(APACHE_ISP_BASE,0x061A )=  0xFF & h_dto;           
    ISPRW8(APACHE_ISP_BASE,0x061D )=  0xFF & (v_dto >> 8);    
    ISPRW8(APACHE_ISP_BASE,0x061C )=  0xFF & v_dto;           
    ISPRW8(APACHE_ISP_BASE,0x061F )=  0x0F & (O_DS_HACT >> 8);
    ISPRW8(APACHE_ISP_BASE,0x061E )=  0xFF & O_DS_HACT;       
    ISPRW8(APACHE_ISP_BASE,0x0621 )=  0x0F & (O_DS_VACT >> 8);
    ISPRW8(APACHE_ISP_BASE,0x0620 )=  0xFF & O_DS_VACT;       

//    ISPRW8(APACHE_ISP_BASE,0x0618 )=  0x08;                   
    ISPRW8(APACHE_ISP_BASE,0x0618 )=  0x00; // bypass                   
    ISPRW8(APACHE_ISP_BASE,0x0611 )=  0xFF;                   

    ISPRW8(APACHE_ISP_BASE,0x0623 )=  0x0F & (O_DS_HACT >> 8);
    ISPRW8(APACHE_ISP_BASE,0x0622 )=  0xFF & O_DS_HACT;       

    ISPRW8(APACHE_ISP_BASE,0x0626 )=  0x00; // bypass
//    ISPRW8(APACHE_ISP_BASE,0x0626 )=  0x0F; // h_upscaler use


    ISPRW8(APACHE_ISP_BASE,0x0628 )=  0x0F & (delay_time >> 8);
    ISPRW8(APACHE_ISP_BASE,0x0627 )=  0xFF & delay_time;
    ISPRW8(APACHE_ISP_BASE,0x062A )=  0x0F & (delay_time >> 8);
    ISPRW8(APACHE_ISP_BASE,0x0629 )=  0xFF & delay_time;       

    ISPRW8(APACHE_ISP_BASE,0x062C )=  0x0F & (O_DS_HACT >> 8);
    ISPRW8(APACHE_ISP_BASE,0x062B )=  0xFF & O_DS_HACT;       

    ISPRW8(APACHE_ISP_BASE,0x062E )=  0x0F & (delay_time >> 8);
    ISPRW8(APACHE_ISP_BASE,0x062D )=  0xFF & delay_time;       
    ISPRW8(APACHE_ISP_BASE,0x062F )=  0x00;  // bypass
//    ISPRW8(APACHE_ISP_BASE,0x062F )=  0x02;  // 

    ISPRW8(APACHE_ISP_BASE,0x0631 )=  0x40;
    ISPRW8(APACHE_ISP_BASE,0x0630 )=  0x00;

    ISPRW8(APACHE_ISP_BASE,0x0633 )=  0x0F & (O_DS_HACT >> 8);
    ISPRW8(APACHE_ISP_BASE,0x0632 )=  0xFF & O_DS_HACT;       
}

void BEDGE_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x05B0 )=  0x03;  // {BEDGE_DEBUG_PRE[7:3],
                            //  BEDGE_DEBUG_DISP_EN_PRE[2],
                            //  BEDGE_COR_EN_PRE[1],
                            //  BEDGE_EN_PRE[0]}

    ISPRW8(APACHE_ISP_BASE,0x05B1 )=  0x04;  // BEDGE_COR_START_PRE[7:0]
    ISPRW8(APACHE_ISP_BASE,0x05B2 )=  0x00;  // BEDGE_COR_START_PRE[9:8]
    ISPRW8(APACHE_ISP_BASE,0x05B3 )=  0x10;  // BEDGE_COR_P00_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05B4 )=  0x00;  // BEDGE_COR_P00_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05B5 )=  0x20;  // BEDGE_COR_P01_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05B6 )=  0x00;  // BEDGE_COR_P01_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05B7 )=  0x30;  // BEDGE_COR_P02_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05B8 )=  0x00;  // BEDGE_COR_P02_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05B9 )=  0x40;  // BEDGE_COR_P03_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05BA )=  0x00;  // BEDGE_COR_P03_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05BB )=  0x50;  // BEDGE_COR_P04_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05BC )=  0x00;  // BEDGE_COR_P04_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05BD )=  0x60;  // BEDGE_COR_P05_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05BE )=  0x00;  // BEDGE_COR_P05_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05BF )=  0x70;  // BEDGE_COR_P06_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05C0 )=  0x00;  // BEDGE_COR_P06_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05C1 )=  0x80;  // BEDGE_COR_P07_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05C2 )=  0x00;  // BEDGE_COR_P07_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05C3 )=  0x90;  // BEDGE_COR_P08_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05C4 )=  0x00;  // BEDGE_COR_P08_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05C5 )=  0xFF;  // BEDGE_COR_P09_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05C6 )=  0x00;  // BEDGE_COR_P09_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05C7 )=  0x30;  // BEDGE_COR_P10_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05C8 )=  0x01;  // BEDGE_COR_P10_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05C9 )=  0x50;  // BEDGE_COR_P11_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05CA )=  0x01;  // BEDGE_COR_P11_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05CB )=  0x80;  // BEDGE_COR_P12_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05CC )=  0x01;  // BEDGE_COR_P12_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05CD )=  0xF0;  // BEDGE_COR_P13_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05CE )=  0x01;  // BEDGE_COR_P13_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05CF )=  0x50;  // BEDGE_COR_P14_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05D0 )=  0x02;  // BEDGE_COR_P14_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05D1 )=  0xA0;  // BEDGE_COR_P15_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05D2 )=  0x02;  // BEDGE_COR_P15_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05D3 )=  0x00;  // BEDGE_COR_P16_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05D4 )=  0x03;  // BEDGE_COR_P16_PRE[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x05D5 )=  0xFF;  // BEDGE_COR_END_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05D6 )=  0x03;  // BEDGE_COR_END_PRE[9:8]  

    ISPRW8(APACHE_ISP_BASE,0x05D7 )=  0x10;  // BEDGE_COR_GAIN_START_PRE[7:0]
    ISPRW8(APACHE_ISP_BASE,0x05D8 )=  0x10;  // BEDGE_COR_GAIN_P00_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05D9 )=  0x10;  // BEDGE_COR_GAIN_P01_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05DA )=  0x10;  // BEDGE_COR_GAIN_P02_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05DB )=  0x10;  // BEDGE_COR_GAIN_P03_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05DC )=  0x10;  // BEDGE_COR_GAIN_P04_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05DD )=  0x10;  // BEDGE_COR_GAIN_P05_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05DE )=  0x10;  // BEDGE_COR_GAIN_P06_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05DF )=  0x10;  // BEDGE_COR_GAIN_P07_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05E0 )=  0x10;  // BEDGE_COR_GAIN_P08_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05E1 )=  0x10;  // BEDGE_COR_GAIN_P09_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05E2 )=  0x10;  // BEDGE_COR_GAIN_P10_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05E3 )=  0x10;  // BEDGE_COR_GAIN_P11_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05E4 )=  0x10;  // BEDGE_COR_GAIN_P12_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05E5 )=  0x10;  // BEDGE_COR_GAIN_P13_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05E6 )=  0x10;  // BEDGE_COR_GAIN_P14_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05E7 )=  0x10;  // BEDGE_COR_GAIN_P15_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05E8 )=  0x10;  // BEDGE_COR_GAIN_P16_PRE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x05E9 )=  0x10;  // BEDGE_COR_GAIN_END_PRE[7:0]  

    ISPRW8(APACHE_ISP_BASE,0x05EA )=  0x00;  // {BEDGE_COR_GAIN_SIGN_START_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P00_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P01_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P02_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P03_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P04_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P05_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P06_PRE}

    ISPRW8(APACHE_ISP_BASE,0x05EB )=  0x00;  // {BEDGE_COR_GAIN_SIGN_P07_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P08_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P09_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P10_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P11_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P12_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P13_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P14_PRE}

    ISPRW8(APACHE_ISP_BASE,0x05EC )=  0x00;  // {BEDGE_COR_GAIN_SIGN_P15_PRE,
                            //  BEDGE_COR_GAIN_SIGN_P16_PRE,
                            //  BEDGE_COR_GAIN_SIGN_END_PRE}

    ISPRW8(APACHE_ISP_BASE,0x05ED )=  0x01;  // {BEDGE_PRE_EN_PRE[1],
                            //  BEDGE_POST_EN_PRE[0]}
}

void HPF_set(void)
{
    /* EDGE */
    ISPRW8(APACHE_ISP_BASE,0x0500 )=  0x49;  // YHPF_LIGHT_F0_COR_Y0[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0501 )=  0x02;  // YHPF_LIGHT_F0_COR_Y0[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0502 )=  0x92;  // YHPF_LIGHT_F0_COR_Y1[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0503 )=  0x04;  // YHPF_LIGHT_F0_COR_Y1[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0504 )=  0xBD;  // YHPF_LIGHT_F0_COR_Y2[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0505 )=  0x06;  // YHPF_LIGHT_F0_COR_Y2[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0506 )=  0x24;  // YHPF_LIGHT_F0_COR_Y3[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0507 )=  0x09;  // YHPF_LIGHT_F0_COR_Y3[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0508 )=  0x6D;  // YHPF_LIGHT_F0_COR_Y4[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0509 )=  0x0B;  // YHPF_LIGHT_F0_COR_Y4[11:8]
    ISPRW8(APACHE_ISP_BASE,0x050A )=  0xB6;  // YHPF_LIGHT_F0_COR_Y5[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x050B )=  0x0D;  // YHPF_LIGHT_F0_COR_Y5[11:8]

    ISPRW8(APACHE_ISP_BASE,0x050C )=  0x10;  // YHPF_LIGHT_F0_GAIN0
    ISPRW8(APACHE_ISP_BASE,0x050D )=  0x10;  // YHPF_LIGHT_F0_GAIN1
    ISPRW8(APACHE_ISP_BASE,0x050E )=  0x10;  // YHPF_LIGHT_F0_GAIN2
    ISPRW8(APACHE_ISP_BASE,0x050F )=  0x10;  // YHPF_LIGHT_F0_GAIN3
    ISPRW8(APACHE_ISP_BASE,0x0510 )=  0x10;  // YHPF_LIGHT_F0_GAIN4
    ISPRW8(APACHE_ISP_BASE,0x0511 )=  0x10;  // YHPF_LIGHT_F0_GAIN5
    ISPRW8(APACHE_ISP_BASE,0x0512 )=  0x10;  // YHPF_LIGHT_F0_GAIN6

    ISPRW8(APACHE_ISP_BASE,0x0513 )=  0x49;  // YHPF_LIGHT_F1_COR_Y0[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0514 )=  0x02;  // YHPF_LIGHT_F1_COR_Y0[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0515 )=  0x92;  // YHPF_LIGHT_F1_COR_Y1[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0516 )=  0x04;  // YHPF_LIGHT_F1_COR_Y1[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0517 )=  0xBD;  // YHPF_LIGHT_F1_COR_Y2[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0518 )=  0x06;  // YHPF_LIGHT_F1_COR_Y2[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0519 )=  0x24;  // YHPF_LIGHT_F1_COR_Y3[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x051A )=  0x09;  // YHPF_LIGHT_F1_COR_Y3[11:8]
    ISPRW8(APACHE_ISP_BASE,0x051B )=  0x6D;  // YHPF_LIGHT_F1_COR_Y4[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x051C )=  0x0B;  // YHPF_LIGHT_F1_COR_Y4[11:8]
    ISPRW8(APACHE_ISP_BASE,0x051D )=  0xB6;  // YHPF_LIGHT_F1_COR_Y5[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x051E )=  0x0D;  // YHPF_LIGHT_F1_COR_Y5[11:8]

    ISPRW8(APACHE_ISP_BASE,0x051F )=  0x10;  // YHPF_LIGHT_F1_GAIN0
    ISPRW8(APACHE_ISP_BASE,0x0520 )=  0x10;  // YHPF_LIGHT_F1_GAIN1
    ISPRW8(APACHE_ISP_BASE,0x0521 )=  0x10;  // YHPF_LIGHT_F1_GAIN2
    ISPRW8(APACHE_ISP_BASE,0x0522 )=  0x10;  // YHPF_LIGHT_F1_GAIN3
    ISPRW8(APACHE_ISP_BASE,0x0523 )=  0x10;  // YHPF_LIGHT_F1_GAIN4
    ISPRW8(APACHE_ISP_BASE,0x0524 )=  0x10;  // YHPF_LIGHT_F1_GAIN5
    ISPRW8(APACHE_ISP_BASE,0x0525 )=  0x10;  // YHPF_LIGHT_F1_GAIN6


    ISPRW8(APACHE_ISP_BASE,0x0530 )=  0x80;  // {YHPF_EN[7], 4'd0,
                            //  YHPF_EDGE_TEST[2:0]}

    ISPRW8(APACHE_ISP_BASE,0x0531 )=  0x44;  // YHPF_F0_MODE[7:4],
                            // YHPF_F1_MODE[3:0]

    ISPRW8(APACHE_ISP_BASE,0x0532 )=  0x14;  // YHPF_F0_COR_Y0[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0533 )=  0x00;  // YHPF_F0_COR_Y0[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0534 )=  0x18;  // YHPF_F0_COR_Y1[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0535 )=  0x00;  // YHPF_F0_COR_Y1[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0536 )=  0x1C;  // YHPF_F0_COR_Y2[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0537 )=  0x00;  // YHPF_F0_COR_Y2[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0538 )=  0x20;  // YHPF_F0_COR_Y3[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0539 )=  0x00;  // YHPF_F0_COR_Y3[11:8]
    ISPRW8(APACHE_ISP_BASE,0x053A )=  0x24;  // YHPF_F0_COR_Y4[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x053B )=  0x00;  // YHPF_F0_COR_Y4[11:8]
    ISPRW8(APACHE_ISP_BASE,0x053C )=  0x28;  // YHPF_F0_COR_Y5[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x053D )=  0x00;  // YHPF_F0_COR_Y5[11:8]
    ISPRW8(APACHE_ISP_BASE,0x053E )=  0x2C;  // YHPF_F0_COR_Y6[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x053F )=  0x00;  // YHPF_F0_COR_Y6[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0540 )=  0x30;  // YHPF_F0_COR_Y7[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0541 )=  0x00;  // YHPF_F0_COR_Y7[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0542 )=  0x34;  // YHPF_F0_COR_Y8[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0543 )=  0x00;  // YHPF_F0_COR_Y8[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0544 )=  0x38;  // YHPF_F0_COR_Y9[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0545 )=  0x00;  // YHPF_F0_COR_Y9[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0546 )=  0x3C;  // YHPF_F0_COR_YA[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0547 )=  0x00;  // YHPF_F0_COR_YA[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0548 )=  0x40;  // YHPF_F0_COR_YB[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0549 )=  0x00;  // YHPF_F0_COR_YB[11:8]
    ISPRW8(APACHE_ISP_BASE,0x054A )=  0x44;  // YHPF_F0_COR_YC[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x054B )=  0x00;  // YHPF_F0_COR_YC[11:8]
    ISPRW8(APACHE_ISP_BASE,0x054C )=  0x48;  // YHPF_F0_COR_YD[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x054D )=  0x00;  // YHPF_F0_COR_YD[11:8]

    ISPRW8(APACHE_ISP_BASE,0x054E )=  0x24;  // YHPF_F1_COR_Y0[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x054F )=  0x00;  // YHPF_F1_COR_Y0[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0550 )=  0x28;  // YHPF_F1_COR_Y1[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0551 )=  0x00;  // YHPF_F1_COR_Y1[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0552 )=  0x2C;  // YHPF_F1_COR_Y2[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0553 )=  0x00;  // YHPF_F1_COR_Y2[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0554 )=  0x30;  // YHPF_F1_COR_Y3[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0555 )=  0x00;  // YHPF_F1_COR_Y3[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0556 )=  0x34;  // YHPF_F1_COR_Y4[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0557 )=  0x00;  // YHPF_F1_COR_Y4[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0558 )=  0x38;  // YHPF_F1_COR_Y5[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0559 )=  0x00;  // YHPF_F1_COR_Y5[11:8]
    ISPRW8(APACHE_ISP_BASE,0x055A )=  0x3C;  // YHPF_F1_COR_Y6[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x055B )=  0x00;  // YHPF_F1_COR_Y6[11:8]
    ISPRW8(APACHE_ISP_BASE,0x055C )=  0x40;  // YHPF_F1_COR_Y7[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x055D )=  0x00;  // YHPF_F1_COR_Y7[11:8]
    ISPRW8(APACHE_ISP_BASE,0x055E )=  0x44;  // YHPF_F1_COR_Y8[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x055F )=  0x00;  // YHPF_F1_COR_Y8[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0560 )=  0x48;  // YHPF_F1_COR_Y9[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0561 )=  0x00;  // YHPF_F1_COR_Y9[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0562 )=  0x4C;  // YHPF_F1_COR_YA[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0563 )=  0x00;  // YHPF_F1_COR_YA[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0564 )=  0x50;  // YHPF_F1_COR_YB[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0565 )=  0x00;  // YHPF_F1_COR_YB[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0566 )=  0x54;  // YHPF_F1_COR_YC[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0567 )=  0x00;  // YHPF_F1_COR_YC[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0568 )=  0x58;  // YHPF_F1_COR_YD[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0569 )=  0x00;  // YHPF_F1_COR_YD[11:8]

    ISPRW8(APACHE_ISP_BASE,0x056A )=  0xFF;  // YHPF_F1_PLIMIT[7:0]
    ISPRW8(APACHE_ISP_BASE,0x056B )=  0x03;  // YHPF_F1_PLIMIT[9:8]
    ISPRW8(APACHE_ISP_BASE,0x056C )=  0xFF;  // YHPF_F1_MLIMIT[7:0]
    ISPRW8(APACHE_ISP_BASE,0x056D )=  0x03;  // YHPF_F1_MLIMIT[9:8]
    ISPRW8(APACHE_ISP_BASE,0x056E )=  0xFF;  // YHPF_F0_PLIMIT[7:0]
    ISPRW8(APACHE_ISP_BASE,0x056F )=  0x03;  // YHPF_F0_PLIMIT[9:8]
    ISPRW8(APACHE_ISP_BASE,0x0570 )=  0xFF;  // YHPF_F0_MLIMIT[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0571 )=  0x03;  // YHPF_F0_MLIMIT[9:8]

    ISPRW8(APACHE_ISP_BASE,0x0572 )=  0x00;  // {YHPF_DEBUG[7:4],
                            //  YHPF_DEBUG_SEL[2:1],
                            //  YHPF_DEBUG_DIS_EN[0]}

    ISPRW8(APACHE_ISP_BASE,0x0573 )=  0x10;  // YHPF_F0_PGAIN0
    ISPRW8(APACHE_ISP_BASE,0x0574 )=  0x10;  // YHPF_F0_PGAIN1
    ISPRW8(APACHE_ISP_BASE,0x0575 )=  0x10;  // YHPF_F0_PGAIN2
    ISPRW8(APACHE_ISP_BASE,0x0576 )=  0x10;  // YHPF_F0_PGAIN3
    ISPRW8(APACHE_ISP_BASE,0x0577 )=  0x10;  // YHPF_F0_PGAIN4
    ISPRW8(APACHE_ISP_BASE,0x0578 )=  0x10;  // YHPF_F0_PGAIN5
    ISPRW8(APACHE_ISP_BASE,0x0579 )=  0x10;  // YHPF_F0_PGAIN6
    ISPRW8(APACHE_ISP_BASE,0x057A )=  0x10;  // YHPF_F0_PGAIN7
    ISPRW8(APACHE_ISP_BASE,0x057B )=  0x10;  // YHPF_F0_PGAIN8
    ISPRW8(APACHE_ISP_BASE,0x057C )=  0x10;  // YHPF_F0_PGAIN9
    ISPRW8(APACHE_ISP_BASE,0x057D )=  0x10;  // YHPF_F0_PGAINA
    ISPRW8(APACHE_ISP_BASE,0x057E )=  0x10;  // YHPF_F0_PGAINB
    ISPRW8(APACHE_ISP_BASE,0x057F )=  0x10;  // YHPF_F0_PGAINC
    ISPRW8(APACHE_ISP_BASE,0x0580 )=  0x10;  // YHPF_F0_PGAIND
    ISPRW8(APACHE_ISP_BASE,0x0581 )=  0x10;  // YHPF_F0_PGAINE

    ISPRW8(APACHE_ISP_BASE,0x0582 )=  0x10;  // YHPF_F0_MGAIN0
    ISPRW8(APACHE_ISP_BASE,0x0583 )=  0x10;  // YHPF_F0_MGAIN1
    ISPRW8(APACHE_ISP_BASE,0x0584 )=  0x10;  // YHPF_F0_MGAIN2
    ISPRW8(APACHE_ISP_BASE,0x0585 )=  0x10;  // YHPF_F0_MGAIN3
    ISPRW8(APACHE_ISP_BASE,0x0586 )=  0x10;  // YHPF_F0_MGAIN4
    ISPRW8(APACHE_ISP_BASE,0x0587 )=  0x10;  // YHPF_F0_MGAIN5
    ISPRW8(APACHE_ISP_BASE,0x0588 )=  0x10;  // YHPF_F0_MGAIN6
    ISPRW8(APACHE_ISP_BASE,0x0589 )=  0x10;  // YHPF_F0_MGAIN7
    ISPRW8(APACHE_ISP_BASE,0x058A )=  0x10;  // YHPF_F0_MGAIN8
    ISPRW8(APACHE_ISP_BASE,0x058B )=  0x10;  // YHPF_F0_MGAIN9
    ISPRW8(APACHE_ISP_BASE,0x058C )=  0x10;  // YHPF_F0_MGAINA
    ISPRW8(APACHE_ISP_BASE,0x058D )=  0x10;  // YHPF_F0_MGAINB
    ISPRW8(APACHE_ISP_BASE,0x058E )=  0x10;  // YHPF_F0_MGAINC
    ISPRW8(APACHE_ISP_BASE,0x058F )=  0x10;  // YHPF_F0_MGAIND
    ISPRW8(APACHE_ISP_BASE,0x0590 )=  0x10;  // YHPF_F0_MGAINE

    ISPRW8(APACHE_ISP_BASE,0x0591 )=  0x10;  // YHPF_F1_PGAIN0
    ISPRW8(APACHE_ISP_BASE,0x0592 )=  0x10;  // YHPF_F1_PGAIN1
    ISPRW8(APACHE_ISP_BASE,0x0593 )=  0x10;  // YHPF_F1_PGAIN2
    ISPRW8(APACHE_ISP_BASE,0x0594 )=  0x10;  // YHPF_F1_PGAIN3
    ISPRW8(APACHE_ISP_BASE,0x0595 )=  0x10;  // YHPF_F1_PGAIN4
    ISPRW8(APACHE_ISP_BASE,0x0596 )=  0x10;  // YHPF_F1_PGAIN5
    ISPRW8(APACHE_ISP_BASE,0x0597 )=  0x10;  // YHPF_F1_PGAIN6
    ISPRW8(APACHE_ISP_BASE,0x0598 )=  0x10;  // YHPF_F1_PGAIN7
    ISPRW8(APACHE_ISP_BASE,0x0599 )=  0x10;  // YHPF_F1_PGAIN8
    ISPRW8(APACHE_ISP_BASE,0x059A )=  0x10;  // YHPF_F1_PGAIN9
    ISPRW8(APACHE_ISP_BASE,0x059B )=  0x10;  // YHPF_F1_PGAINA
    ISPRW8(APACHE_ISP_BASE,0x059C )=  0x10;  // YHPF_F1_PGAINB
    ISPRW8(APACHE_ISP_BASE,0x059D )=  0x10;  // YHPF_F1_PGAINC
    ISPRW8(APACHE_ISP_BASE,0x059E )=  0x10;  // YHPF_F1_PGAIND
    ISPRW8(APACHE_ISP_BASE,0x059F )=  0x10;  // YHPF_F1_PGAINE

    ISPRW8(APACHE_ISP_BASE,0x05A0 )=  0x10;  // YHPF_F1_MGAIN0
    ISPRW8(APACHE_ISP_BASE,0x05A1 )=  0x10;  // YHPF_F1_MGAIN1
    ISPRW8(APACHE_ISP_BASE,0x05A2 )=  0x10;  // YHPF_F1_MGAIN2
    ISPRW8(APACHE_ISP_BASE,0x05A3 )=  0x10;  // YHPF_F1_MGAIN3
    ISPRW8(APACHE_ISP_BASE,0x05A4 )=  0x10;  // YHPF_F1_MGAIN4
    ISPRW8(APACHE_ISP_BASE,0x05A5 )=  0x10;  // YHPF_F1_MGAIN5
    ISPRW8(APACHE_ISP_BASE,0x05A6 )=  0x10;  // YHPF_F1_MGAIN6
    ISPRW8(APACHE_ISP_BASE,0x05A7 )=  0x10;  // YHPF_F1_MGAIN7
    ISPRW8(APACHE_ISP_BASE,0x05A8 )=  0x10;  // YHPF_F1_MGAIN8
    ISPRW8(APACHE_ISP_BASE,0x05A9 )=  0x10;  // YHPF_F1_MGAIN9
    ISPRW8(APACHE_ISP_BASE,0x05AA )=  0x10;  // YHPF_F1_MGAINA
    ISPRW8(APACHE_ISP_BASE,0x05AB )=  0x10;  // YHPF_F1_MGAINB
    ISPRW8(APACHE_ISP_BASE,0x05AC )=  0x10;  // YHPF_F1_MGAINC
    ISPRW8(APACHE_ISP_BASE,0x05AD )=  0x10;  // YHPF_F1_MGAIND
    ISPRW8(APACHE_ISP_BASE,0x05AE )=  0x10;  // YHPF_F1_MGAINE
}

void IHNR_set(void)
{
    ISPRW8(APACHE_ISP_BASE,0x06E0 )=  0x01;  // IHNR_EN_PRE       
    ISPRW8(APACHE_ISP_BASE,0x06E1 )=  0x40;  // IHNR_STR_PRE[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x06E2 )=  0x00;  // IHNR_STR_PRE[15:8]
}

void BMD_set()
{
    ISPRW8(APACHE_ISP_BASE,0x0800 )=  0x03;  // [7:4]:MD_SUM_SHIFT
                            // [3:2]:MD_GRID_COLOR
                            // [1]  :MD_GRID_EN
                            // [0]  :MD_EN

    ISPRW8(APACHE_ISP_BASE,0x0801 )=  0x3D;  // {1'd0, O_VBNUM};
    ISPRW8(APACHE_ISP_BASE,0x0802 )=  0x51;  // {1'd0, O_HBNUM};
    ISPRW8(APACHE_ISP_BASE,0x0803 )=  0x00;  // [7:4]:MD_OFFSET_V[3:0]
                            // [3:0]:MD_OFFSET_H[3:0]

//  ISPRW8(APACHE_ISP_BASE,0x0804 )=  0x40;  // O_GAIN;
//  ISPRW8(APACHE_ISP_BASE,0x0805 )=  0x00;  // [7:6]:MD_UPLOAD_TYPE
                            // [5:0]:MD_UPLOAD_SKIPNUM
//  ISPRW8(APACHE_ISP_BASE,0x0806 )=  0x80;  // MD_UPLOAD_BLENDING;
    ISPRW8(APACHE_ISP_BASE,0x0807 )=  0x88;  // [7:4]:MD_CAP_TIME_MUL
                            // [3:0]:MD_BLK_INCLV
    ISPRW8(APACHE_ISP_BASE,0x0808 )=  0x80;  // MD_CAP_TIME_LEN
    ISPRW8(APACHE_ISP_BASE,0x0809 )=  0x01;  // MD0_THLV[7:0]
    ISPRW8(APACHE_ISP_BASE,0x080A )=  0x01;  // MD1_THLV[7:0]

    ISPRW8(APACHE_ISP_BASE,0x080B )=  0x3D;  // [5]:MD0_WIN0_EN
                            // [4]:MD0_WIN0_DPEN
                            // [3]:MD0_WIN0_COLOR[1]
                            // [2]:MD0_WIN0_COLOR[0]
                            // [1]:MD0_WIN0_TRANS[1]
                            // [0]:MD0_WIN0_TRANS[0]

    ISPRW8(APACHE_ISP_BASE,0x080C )=  0x06;  // [2]:MD0_WIN0_OUTLN_EN
                            // [1]:MD0_WIN0_OUTLN_TYPE
                            // [0]:MD0_WIN0_OUTLN_BLK

    ISPRW8(APACHE_ISP_BASE,0x080D )=  0x00;  // {1'd0,MD0_WIN0_HST};
    ISPRW8(APACHE_ISP_BASE,0x080E )=  0x00;  // {1'd0,MD0_WIN0_VST};
    ISPRW8(APACHE_ISP_BASE,0x080F )=  0x09;  // {1'd0,MD0_WIN0_WIDTH};
    ISPRW8(APACHE_ISP_BASE,0x0810 )=  0x06;  // {1'd0,MD0_WIN0_HEIGHT};
    ISPRW8(APACHE_ISP_BASE,0x0811 )=  0x00;  //       MD0_WIN0_THCNT_TH[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0812 )=  0x00;  // {5'd0,MD0_WIN0_THCNT_TH[10:8]};

    ISPRW8(APACHE_ISP_BASE,0x0813 )=  0x3A;  // [5]:MD0_WIN1_EN
                            // [4]:MD0_WIN1_DPEN
                            // [3]:MD0_WIN1_COLOR[1]
                            // [2]:MD0_WIN1_COLOR[0]
                            // [1]:MD0_WIN1_TRANS[1]
                            // [0]:MD0_WIN1_TRANS[0]

    ISPRW8(APACHE_ISP_BASE,0x0814 )=  0x06;  // [2]:MD0_WIN1_OUTLN_EN
                            // [1]:MD0_WIN1_OUTLN_TYPE
                            // [0]:MD0_WIN1_OUTLN_BLK

    ISPRW8(APACHE_ISP_BASE,0x0815 )=  0x48;  // {1'd0,MD0_WIN1_HST};
    ISPRW8(APACHE_ISP_BASE,0x0816 )=  0x00;  // {1'd0,MD0_WIN1_VST};
    ISPRW8(APACHE_ISP_BASE,0x0817 )=  0x09;  // {1'd0,MD0_WIN1_WIDTH};
    ISPRW8(APACHE_ISP_BASE,0x0818 )=  0x06;  // {1'd0,MD0_WIN1_HEIGHT};
    ISPRW8(APACHE_ISP_BASE,0x0819 )=  0x00;  //       MD0_WIN1_THCNT_TH[7:0];
    ISPRW8(APACHE_ISP_BASE,0x081A )=  0x00;  // {5'd0,MD0_WIN1_THCNT_TH[10:8];

    ISPRW8(APACHE_ISP_BASE,0x081B )=  0x36;  // [5]:MD1_WIN0_EN
                            // [4]:MD1_WIN0_DPEN
                            // [3]:MD1_WIN0_COLOR[1]
                            // [2]:MD1_WIN0_COLOR[0]
                            // [1]:MD1_WIN0_TRANS[1]
                            // [0]:MD1_WIN0_TRANS[0]

    ISPRW8(APACHE_ISP_BASE,0x081C )=  0x06;  // [2]:MD1_WIN0_OUTLN_EN
                            // [1]:MD1_WIN0_OUTLN_TYPE
                            // [0]:MD1_WIN0_OUTLN_BLK

    ISPRW8(APACHE_ISP_BASE,0x081D )=  0x00;  // {1'd0,MD1_WIN0_HST};
    ISPRW8(APACHE_ISP_BASE,0x081E )=  0x37;  // {1'd0,MD1_WIN0_VST};
    ISPRW8(APACHE_ISP_BASE,0x081F )=  0x09;  // {1'd0,MD1_WIN0_WIDTH};
    ISPRW8(APACHE_ISP_BASE,0x0820 )=  0x06;  // {1'd0,MD1_WIN0_HEIGHT};
    ISPRW8(APACHE_ISP_BASE,0x0821 )=  0x00;  //       MD1_WIN0_THCNT_TH[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0822 )=  0x00;  // {5'd0,MD1_WIN0_THCNT_TH[10:8]};

    ISPRW8(APACHE_ISP_BASE,0x0823 )=  0x32;  // [5]:MD1_WIN1_EN
                            // [4]:MD1_WIN1_DPEN
                            // [3]:MD1_WIN1_COLOR
                            // [2]:MD1_WIN1_COLOR
                            // [1]:MD1_WIN1_TRANS
                            // [0]:MD1_WIN1_TRANS

    ISPRW8(APACHE_ISP_BASE,0x0824 )=  0x06;  // [2]:MD1_WIN1_OUTLN_EN
                            // [1]:MD1_WIN1_OUTLN_TYPE
                            // [0]:MD1_WIN1_OUTLN_BLK

    ISPRW8(APACHE_ISP_BASE,0x0825 )=  0x48;  // {1'd0,MD1_WIN1_HST};
    ISPRW8(APACHE_ISP_BASE,0x0826 )=  0x37;  // {1'd0,MD1_WIN1_VST};
    ISPRW8(APACHE_ISP_BASE,0x0827 )=  0x09;  // {1'd0,MD1_WIN1_WIDTH};
    ISPRW8(APACHE_ISP_BASE,0x0828 )=  0x06;  // {1'd0,MD1_WIN1_HEIGHT};
    ISPRW8(APACHE_ISP_BASE,0x0829 )=  0x00;  //       MD1_WIN1_THCNT_TH[7:0];
    ISPRW8(APACHE_ISP_BASE,0x082A )=  0x00;  // {5'd0,MD1_WIN1_THCNT_TH[10:8]};

}

void PGL_set()
{
    ISPRW8(APACHE_ISP_BASE,0x0830 )=  0x11;  // {3'd0, PGL_EN, 3'd0, PGL_TRANS_EN};

    ISPRW8(APACHE_ISP_BASE,0x0831 )=  0xFA;  //       PGL_HLL_TOP[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0832 )=  0x02;  // {4'd0,PGL_HLL_TOP[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0833 )=  0x52;  //       PGL_HLL_BTM[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0834 )=  0x01;  // {4'd0,PGL_HLL_BTM[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0835 )=  0x65;  //       PGL_HRL_TOP[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0836 )=  0x04;  // {4'd0,PGL_HRL_TOP[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0837 )=  0xFA;  //       PGL_HRL_BTM[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0838 )=  0x05;  // {4'd0,PGL_HRL_BTM[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0839 )=  0x0C;  //       PGL_V_TOP[7:0]   
    ISPRW8(APACHE_ISP_BASE,0x083A )=  0x01;  // {4'd0,PGL_V_TOP[11:8]  
    ISPRW8(APACHE_ISP_BASE,0x083B )=  0xC0;  //       PGL_V_BTM[7:0]   
    ISPRW8(APACHE_ISP_BASE,0x083C )=  0x02;  // {4'd0,PGL_V_BTM[11:8]  
    ISPRW8(APACHE_ISP_BASE,0x083D )=  0xF0;  //       PGL_V1[7:0]      
    ISPRW8(APACHE_ISP_BASE,0x083E )=  0x00;  // {4'd0,PGL_V1[11:8]      
    ISPRW8(APACHE_ISP_BASE,0x083F )=  0xF0;  //       PGL_V2[7:0]      
    ISPRW8(APACHE_ISP_BASE,0x0840 )=  0x00;  // {4'd0,PGL_V2[11:8]      
    ISPRW8(APACHE_ISP_BASE,0x0841 )=  0xF0;  //       PGL_V3[7:0]      
    ISPRW8(APACHE_ISP_BASE,0x0842 )=  0x00;  // {4'd0,PGL_V3[11:8]      
      
    ISPRW8(APACHE_ISP_BASE,0x0843 )=  0x08;  //       PGL_H1_WIDTH 
    ISPRW8(APACHE_ISP_BASE,0x0844 )=  0x08;  //       PGL_H2_WIDTH 
    ISPRW8(APACHE_ISP_BASE,0x0845 )=  0x08;  //       PGL_H3_WIDTH 
    ISPRW8(APACHE_ISP_BASE,0x0846 )=  0x08;  //       PGL_H4_WIDTH 

    ISPRW8(APACHE_ISP_BASE,0x0847 )=  0x46;  //       PGL_H1_LENGTH
    ISPRW8(APACHE_ISP_BASE,0x0848 )=  0x46;  //       PGL_H2_LENGTH
    ISPRW8(APACHE_ISP_BASE,0x0849 )=  0x46;  //       PGL_H3_LENGTH
    ISPRW8(APACHE_ISP_BASE,0x084A )=  0x46;  //       PGL_H4_LENGTH

    ISPRW8(APACHE_ISP_BASE,0x084B )=  0x05;  //       PGL_LN1_SPACE
    ISPRW8(APACHE_ISP_BASE,0x084C )=  0x05;  //       PGL_LN2_SPACE
    ISPRW8(APACHE_ISP_BASE,0x084D )=  0x05;  //       PGL_LN3_SPACE
    ISPRW8(APACHE_ISP_BASE,0x084E )=  0x05;  //       PGL_LN4_SPACE

    ISPRW8(APACHE_ISP_BASE,0x084F )=  0xFC;  //       PGL_L1_Y[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x0850 )=  0x00;  // {6'd0,PGL_L1_Y[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x0851 )=  0x98;  //       PGL_L1_CB[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0852 )=  0x01;  // {6'd0,PGL_L1_CB[9:8] 
    ISPRW8(APACHE_ISP_BASE,0x0853 )=  0xC0;  //       PGL_L1_CR[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0854 )=  0x03;  // {6'd0,PGL_L1_CR[9:8] 
    ISPRW8(APACHE_ISP_BASE,0x0855 )=  0x6C;  //       PGL_L2_Y[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x0856 )=  0x03;  // {6'd0,PGL_L2_Y[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x0857 )=  0x40;  //       PGL_L2_CB[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0858 )=  0x00;  // {6'd0,PGL_L2_CB[9:8] 
    ISPRW8(APACHE_ISP_BASE,0x0859 )=  0x28;  //       PGL_L2_CR[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x085A )=  0x02;  // {6'd0,PGL_L2_CR[9:8] 
    ISPRW8(APACHE_ISP_BASE,0x085B )=  0xB4;  //       PGL_L3_Y[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x085C )=  0x02;  // {6'd0,PGL_L3_Y[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x085D )=  0xA8;  //       PGL_L3_CB[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x085E )=  0x00;  // {6'd0,PGL_L3_CB[9:8] 
    ISPRW8(APACHE_ISP_BASE,0x085F )=  0x68;  //       PGL_L3_CR[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0860 )=  0x00;  // {6'd0,PGL_L3_CR[9:8] 
    ISPRW8(APACHE_ISP_BASE,0x0861 )=  0x80;  //       PGL_L4_Y[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x0862 )=  0x00;  // {6'd0,PGL_L4_Y[9:8]  
    ISPRW8(APACHE_ISP_BASE,0x0863 )=  0xC0;  //       PGL_L4_CB[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0864 )=  0x03;  // {6'd0,PGL_L4_CB[9:8] 
    ISPRW8(APACHE_ISP_BASE,0x0865 )=  0xD8;  //       PGL_L4_CR[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0866 )=  0x01;  // {6'd0,PGL_L4_CR[9:8] 
    ISPRW8(APACHE_ISP_BASE,0x0867 )=  0xF4;  //       PGL_AR1_Y[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0868 )=  0x02;  // {6'd0,PGL_AR1_Y[9:8] 
    ISPRW8(APACHE_ISP_BASE,0x0869 )=  0x68;  //       PGL_AR1_CB[7:0]
    ISPRW8(APACHE_ISP_BASE,0x086A )=  0x02;  // {6'd0,PGL_AR1_CB[9:8]
    ISPRW8(APACHE_ISP_BASE,0x086B )=  0x40;  //       PGL_AR1_CR[7:0]
    ISPRW8(APACHE_ISP_BASE,0x086C )=  0x00;  // {6'd0,PGL_AR1_CR[9:8]
    ISPRW8(APACHE_ISP_BASE,0x086D )=  0x38;  //       PGL_AR2_Y[7:0] 

    ISPRW8(APACHE_ISP_BASE,0x086E )=  0x01;  //  {6'd0,PGL_AR2_Y[9:8] 
    ISPRW8(APACHE_ISP_BASE,0x086F )=  0x58;  //        PGL_AR2_CB[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0870 )=  0x03;  //  {6'd0,PGL_AR2_CB[9:8]
    ISPRW8(APACHE_ISP_BASE,0x0871 )=  0x98;  //        PGL_AR2_CR[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0872 )=  0x03;  //  {6'd0,PGL_AR2_CR[9:8]
    ISPRW8(APACHE_ISP_BASE,0x0873 )=  0xAC;  //        PGL_AR3_Y[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0874 )=  0x03;  //  {6'd0,PGL_AR3_Y[9:8] 
    ISPRW8(APACHE_ISP_BASE,0x0875 )=  0x00;  //        PGL_AR3_CB[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0876 )=  0x02;  //  {6'd0,PGL_AR3_CB[9:8]
    ISPRW8(APACHE_ISP_BASE,0x0877 )=  0x00;  //        PGL_AR3_CR[7:0]
    ISPRW8(APACHE_ISP_BASE,0x0878 )=  0x02;  //  {6'd0,PGL_AR3_CR[9:8]
    ISPRW8(APACHE_ISP_BASE,0x0879 )=  0x40;  //        PGL_AR4_Y[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x087A )=  0x00;  //  {6'd0,PGL_AR4_Y[9:8] 
    ISPRW8(APACHE_ISP_BASE,0x087B )=  0x00;  //        PGL_AR4_CB[7:0]
    ISPRW8(APACHE_ISP_BASE,0x087C )=  0x02;  //  {6'd0,PGL_AR4_CB[9:8]
    ISPRW8(APACHE_ISP_BASE,0x087D )=  0x00;  //        PGL_AR4_CR[7:0]
    ISPRW8(APACHE_ISP_BASE,0x087E )=  0x02;  //  {6'd0,PGL_AR4_CR[9:8]
    ISPRW8(APACHE_ISP_BASE,0x087F )=  0x80;  //  PGL_L1_BGR           
    ISPRW8(APACHE_ISP_BASE,0x0880 )=  0x80;  //  PGL_L2_BGR           
    ISPRW8(APACHE_ISP_BASE,0x0881 )=  0x80;  //  PGL_L3_BGR           
    ISPRW8(APACHE_ISP_BASE,0x0882 )=  0x80;  //  PGL_L4_BGR           
    ISPRW8(APACHE_ISP_BASE,0x0883 )=  0x80;  // PGL_AR1_BGR                    
    ISPRW8(APACHE_ISP_BASE,0x0884 )=  0x80;  // PGL_AR2_BGR                    
    ISPRW8(APACHE_ISP_BASE,0x0885 )=  0x80;  // PGL_AR3_BGR                    
    ISPRW8(APACHE_ISP_BASE,0x0886 )=  0x80;  // PGL_AR4_BGR                    
    ISPRW8(APACHE_ISP_BASE,0x0887 )=  0x00;  // {2'd0,PGL_AR1_FRAME            
    ISPRW8(APACHE_ISP_BASE,0x0888 )=  0x00;  // {2'd0,PGL_AR2_FRAME            
    ISPRW8(APACHE_ISP_BASE,0x0889 )=  0x00;  // {2'd0,PGL_AR3_FRAME            
    ISPRW8(APACHE_ISP_BASE,0x088A )=  0x00;  // {2'd0,PGL_AR4_FRAME            

    ISPRW8(APACHE_ISP_BASE,0x088B )=  0x14;  // PGL_AR1_H_SPACE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x088C )=  0x00;  // PGL_AR1_H_SPACE[11:8]
    ISPRW8(APACHE_ISP_BASE,0x088D )=  0x14;  // PGL_AR2_H_SPACE[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x088E )=  0x00;  // PGL_AR2_H_SPACE[11:8]
    ISPRW8(APACHE_ISP_BASE,0x088F )=  0x14;  // PGL_AR3_H_SPACE[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x0890 )=  0x00;  // PGL_AR3_H_SPACE[11:8]
    ISPRW8(APACHE_ISP_BASE,0x0891 )=  0x14;  // PGL_AR4_H_SPACE[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0892 )=  0x00;  // PGL_AR4_H_SPACE[11:8]

    ISPRW8(APACHE_ISP_BASE,0x0893 )=  0x04;  // PGL_AR1_V_SPACE
    ISPRW8(APACHE_ISP_BASE,0x0894 )=  0x04;  // PGL_AR2_V_SPACE
    ISPRW8(APACHE_ISP_BASE,0x0895 )=  0x04;  // PGL_AR3_V_SPACE
    ISPRW8(APACHE_ISP_BASE,0x0896 )=  0x04;  // PGL_AR4_V_SPACE
    ISPRW8(APACHE_ISP_BASE,0x0897 )=  0x03;  // {5'd0,PGL_BLUR_STEP}
    ISPRW8(APACHE_ISP_BASE,0x0898 )=  0x02;  // {5'd0,PGL_BLUR_FIXED_BIT}
  
    ISPRW8(APACHE_ISP_BASE,0x0899 )=  0x0C;  // PGL_HLR_TOP[7:0]
    ISPRW8(APACHE_ISP_BASE,0x089A )=  0x03;  // PGL_HLR_TOP[11:8]
    ISPRW8(APACHE_ISP_BASE,0x089B )=  0x80;  // PGL_HLR_BTM[7:0]
    ISPRW8(APACHE_ISP_BASE,0x089C )=  0x01;  // PGL_HLR_BTM[11:8]
    ISPRW8(APACHE_ISP_BASE,0x089D )=  0x78;  // PGL_HRR_TOP[7:0]
    ISPRW8(APACHE_ISP_BASE,0x089E )=  0x04;  // PGL_HRR_TOP[11:8]
    ISPRW8(APACHE_ISP_BASE,0x089F )=  0x2A;  // PGL_HRR_BTM[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x08A0 )=  0x06;  // PGL_HRR_BTM[11:8]    


    ISPRW8(APACHE_ISP_BASE,0x08A1 )=  0x0F;  // AREA_BK_SEL        
    ISPRW8(APACHE_ISP_BASE,0x08A2 )=  0x04;  // AREA3_WIDTH        
    ISPRW8(APACHE_ISP_BASE,0x08A3 )=  0x04;  // AREA2_WIDTH        
    ISPRW8(APACHE_ISP_BASE,0x08A4 )=  0x04;  // AREA1_WIDTH        
    ISPRW8(APACHE_ISP_BASE,0x08A5 )=  0x04;  // AREA0_WIDTH        

    ISPRW8(APACHE_ISP_BASE,0x08A6 )=  0x00;  // AREA0_H_START[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x08A7 )=  0x00;  // AREA0_H_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x08A8 )=  0x00;  // AREA0_V_START[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x08A9 )=  0x80;  // AREA0_V_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x08AA )=  0x00;  // AREA0_H_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x08AB )=  0x0A;  // AREA0_H_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x08AC )=  0xA0;  // AREA0_V_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x08AD )=  0x05;  // AREA0_V_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x08AE )=  0xA0;  // COLOR_ROM_00[23:16]
    ISPRW8(APACHE_ISP_BASE,0x08AF )=  0xE0;  // COLOR_ROM_00[15:8] 
    ISPRW8(APACHE_ISP_BASE,0x08B0 )=  0x20;  // COLOR_ROM_00[7:0]  

    ISPRW8(APACHE_ISP_BASE,0x08B1 )=  0x04;  // AREA1_H_START[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x08B2 )=  0x00;  // AREA1_H_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x08B3 )=  0x04;  // AREA1_V_START[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x08B4 )=  0x00;  // AREA1_V_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x08B5 )=  0xFB;  // AREA1_H_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x08B6 )=  0x09;  // AREA1_H_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x08B7 )=  0x9B;  // AREA1_V_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x08B8 )=  0x05;  // AREA1_V_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x08B9 )=  0xA0;  // COLOR_ROM_01[23:16]
    ISPRW8(APACHE_ISP_BASE,0x08BA )=  0x20;  // COLOR_ROM_01[15:8] 
    ISPRW8(APACHE_ISP_BASE,0x08BB )=  0xE0;  // COLOR_ROM_01[7:0]  

    ISPRW8(APACHE_ISP_BASE,0x08BC )=  0x08;  // AREA2_H_START[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x08BD )=  0x00;  // AREA2_H_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x08BE )=  0x08;  // AREA2_V_START[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x08BF )=  0x00;  // AREA2_V_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x08C0 )=  0xF8;  // AREA2_H_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x08C1 )=  0x09;  // AREA2_H_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x08C2 )=  0x93;  // AREA2_V_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x08C3 )=  0x05;  // AREA2_V_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x08C4 )=  0xA0;  // COLOR_ROM_02[23:16]
    ISPRW8(APACHE_ISP_BASE,0x08C5 )=  0x75;  // COLOR_ROM_02[15:8] 
    ISPRW8(APACHE_ISP_BASE,0x08C6 )=  0x22;  // COLOR_ROM_02[7:0]  

    ISPRW8(APACHE_ISP_BASE,0x08C7 )=  0x0C;  // AREA3_H_START[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x08C8 )=  0x00;  // AREA3_H_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x08C9 )=  0x0C;  // AREA3_V_START[7:0] 
    ISPRW8(APACHE_ISP_BASE,0x08CA )=  0x00;  // AREA3_V_START[11:8]
    ISPRW8(APACHE_ISP_BASE,0x08CB )=  0xF0;  // AREA3_H_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x08CC )=  0x09;  // AREA3_H_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x08CD )=  0x8F;  // AREA3_V_SIZE[7:0]  
    ISPRW8(APACHE_ISP_BASE,0x08CE )=  0x05;  // AREA3_V_SIZE[11:8] 
    ISPRW8(APACHE_ISP_BASE,0x08CF )=  0xA0;  // COLOR_ROM_03[23:16]
    ISPRW8(APACHE_ISP_BASE,0x08D0 )=  0x80;  // COLOR_ROM_03[15:8]
    ISPRW8(APACHE_ISP_BASE,0x08D1 )=  0xE0;  // COLOR_ROM_03[7:0] 

    ISPRW8(APACHE_ISP_BASE,0x08D2 )=  0x96;  // AREA3_BKT
                            // AREA2_BKT
                            // AREA1_BKT
                            // AREA0_BKT
}

void OSD_Write(USHORT pos, UCHAR wdata)
{
    ISPRW8(APACHE_ISP_BASE,0x003C )=  0x80 | (0x03 & (pos >> 8));    // IND_XSFR_BANK;
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0xFF & pos;                    // IND_XSFR_ADDR;
    ISPRW8(APACHE_ISP_BASE,0x003E )=  wdata;                         // IND_XSFR_RWDATA;
}

UCHAR OSD_Read(USHORT pos)
{
    ISPRW8(APACHE_ISP_BASE,0x003C )=  0x80 | (0x03 & (pos >> 8));    // IND_XSFR_BANK;
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0xFF & pos;                    // IND_XSFR_ADDR;
    ISPRW8(APACHE_ISP_BASE,0x003D )=  0xFF & pos;                    // IND_XSFR_ADDR;
    return ISPRW8(APACHE_ISP_BASE,0x003E);
}

void OSD_set()
{
    OSD_Init();

    OSD_FontWrite(1, 0, 0, 0, 1);
    OSD_FontWrite(2, 0, 0, 0, 6);

}
//////////////////////////////////////////////////
//                      OSD                     //
//////////////////////////////////////////////////
//#define OSD_OPTION_FSIZEX2
//#define OSD_OPTION_FMARGIN
//#define OSD_OPTION_CHINESE_TRADITIONAL
void OSD_Init(void) {
    gl_gvr_hnum     = 4;
    gl_gvr_vnum     = 4;

#if defined OSD_OPTION_FSIZEX2
    ISPRW8(APACHE_ISP_BASE,0x0907  )=  0x5F;                     // {1'd0, O_OSD_VSIZEx2, O_OSD_GRD_VSIZE};
    ISPRW8(APACHE_ISP_BASE,0x0908  )=  0x5F;                     // {1'd0, O_OSD_HSIZEx2, O_OSD_GRD_HSIZE};
#else
    ISPRW8(APACHE_ISP_BASE,0x0907  )=  0x1F;                     // {1'd0, O_OSD_VSIZEx2, O_OSD_GRD_VSIZE};
    ISPRW8(APACHE_ISP_BASE,0x0908  )=  0x1F;                     // {1'd0, O_OSD_HSIZEx2, O_OSD_GRD_HSIZE};
#endif

//  ISPRW8(APACHE_ISP_BASE,0x0909  )=  0x00;                     // O_OSD_GRD_PREVSYNC_OFFSET[7:0];
    ISPRW8(APACHE_ISP_BASE,0x090A  )=  0x10;                     // O_OSD_GRD_PREVSYNC_OFFSET[15:8];
//  ISPRW8(APACHE_ISP_BASE,0x090B  )=  0x00;                     // {7'd0, O_OSD_GRD_PREVSYNC_OFFSET[16]};
//  ISPRW8(APACHE_ISP_BASE,0x090C  )=  0x00;                     // {3'd0, O_OSD_GRD_SDRREQ_WAIT};

    ISPRW8(APACHE_ISP_BASE,0x0905  )=  gl_gvr_vnum-1;                // {2'd0, O_OSD_GRD_VNUM};
    ISPRW8(APACHE_ISP_BASE,0x0906  )=  gl_gvr_hnum-1;                // {2'd0, O_OSD_GRD_HNUM};

//  ISPRW8(APACHE_ISP_BASE,0x0901  )=  0x00;                         // O_OSD_GRD_VSTART[7:0];
//  ISPRW8(APACHE_ISP_BASE,0x0902  )=  0x00;                         // {5'd0, O_OSD_GRD_VSTART[10:8]};
//  ISPRW8(APACHE_ISP_BASE,0x0903  )=  0x00;                         // O_OSD_GRD_HSTART[7:0] ;
//  ISPRW8(APACHE_ISP_BASE,0x0904  )=  0x00;                         // {5'd0, O_OSD_GRD_HSTART[10:8]};

#if defined OSD_OPTION_FMARGIN
    ISPRW8(APACHE_ISP_BASE,0x090D  )=  0x33;                         // {I_GRD_MARGIN_V, I_GRD_MARGIN_H}
#else
//  ISPRW8(APACHE_ISP_BASE,0x090D  )=  0x00;                         // {I_GRD_MARGIN_V, I_GRD_MARGIN_H}
#endif

//  ISPRW8(APACHE_ISP_BASE,0x091F  )=  0x00;                         // O_OSD_ATTR_STYLE0;   // All off
    ISPRW8(APACHE_ISP_BASE,0x0920  )=  0x80;                         // O_OSD_ATTR_STYLE1;   // Trans ON
    ISPRW8(APACHE_ISP_BASE,0x0921  )=  0x40;                         // O_OSD_ATTR_STYLE2;   // blk ON
    ISPRW8(APACHE_ISP_BASE,0x0922  )=  0x01;                         // O_OSD_ATTR_STYLE3;   // BG ON

    ISPRW8(APACHE_ISP_BASE,0x092F  )=  0x67;                         // O_OSD_ATTR_COLOR0[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0930  )=  0x01;                         // O_OSD_ATTR_COLOR0[15:8];
    ISPRW8(APACHE_ISP_BASE,0x0931  )=  0x67;                         // O_OSD_ATTR_COLOR1[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0932  )=  0x23;                         // O_OSD_ATTR_COLOR1[15:8];
    ISPRW8(APACHE_ISP_BASE,0x0933  )=  0x67;                         // O_OSD_ATTR_COLOR2[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0934  )=  0x45;                         // O_OSD_ATTR_COLOR2[15:8];

    ISPRW8(APACHE_ISP_BASE,0x093F  )=  0xC0;                         // O_OSD_TRANS_TABLE0[7:0]; // 50%
    ISPRW8(APACHE_ISP_BASE,0x0940  )=  0xC0;                         // O_OSD_TRANS_TABLE0[15:8];
    ISPRW8(APACHE_ISP_BASE,0x0941  )=  0xC0;                         // O_OSD_TRANS_TABLE0[23:16];
    ISPRW8(APACHE_ISP_BASE,0x0942  )=  0xC0;                         // O_OSD_TRANS_TABLE0[31:24];

    ISPRW8(APACHE_ISP_BASE,0x0962  )=  0xF0;                         // O_OSD_BLK_TABLE0[31:24];
    ISPRW8(APACHE_ISP_BASE,0x0961  )=  0x1F;                         // O_OSD_BLK_TABLE0[23:16];
    ISPRW8(APACHE_ISP_BASE,0x0960  )=  0xFF;                         // O_OSD_BLK_TABLE0[15:8];
    ISPRW8(APACHE_ISP_BASE,0x095F  )=  0x80;                         // O_OSD_BLK_TABLE0[7:0];

    ISPRW8(APACHE_ISP_BASE,0x096F  )=  0x10;                         // O_OSD_COLOR0[7:0];   // White(y180:cb128:cr128)
    ISPRW8(APACHE_ISP_BASE,0x0970  )=  0xB6;                         // O_OSD_COLOR0[15:8];
    ISPRW8(APACHE_ISP_BASE,0x0971  )=  0xBA;                         // O_OSD_COLOR1[7:0];   // Red(y51:cb109:cr212)
    ISPRW8(APACHE_ISP_BASE,0x0972  )=  0x31;                         // O_OSD_COLOR1[15:8];
    ISPRW8(APACHE_ISP_BASE,0x0973  )=  0x4F;                         // O_OSD_COLOR2[7:0];   // Blue(y28:cb212:cr120)
    ISPRW8(APACHE_ISP_BASE,0x0974  )=  0x1F;                         // O_OSD_COLOR2[15:8];
    ISPRW8(APACHE_ISP_BASE,0x0975  )=  0xE6;                         // O_OSD_COLOR3[7:0];   // Green(y133:cb63:cr52)
    ISPRW8(APACHE_ISP_BASE,0x0976  )=  0x84;                         // O_OSD_COLOR3[15:8];
    ISPRW8(APACHE_ISP_BASE,0x0977  )=  0xB1;                         // O_OSD_COLOR4[7:0];   // Yellow(y168:cb44:cr136)
    ISPRW8(APACHE_ISP_BASE,0x0978  )=  0xA8;                         // O_OSD_COLOR4[15:8];
    ISPRW8(APACHE_ISP_BASE,0x0979  )=  0x45;                         // O_OSD_COLOR5[7:0];   // Cyan(y145:cb147:cr44)
    ISPRW8(APACHE_ISP_BASE,0x097A  )=  0x92;                         // O_OSD_COLOR5[15:8];
    ISPRW8(APACHE_ISP_BASE,0x097B  )=  0x19;                         // O_OSD_COLOR6[7:0];   // Megenta(y63:cb193:cr204)
    ISPRW8(APACHE_ISP_BASE,0x097C  )=  0x3F;                         // O_OSD_COLOR6[15:8];
    ISPRW8(APACHE_ISP_BASE,0x097D  )=  0x10;                         // O_OSD_COLOR7[7:0];   // Black(y16:cb128:cr128)
    ISPRW8(APACHE_ISP_BASE,0x097E  )=  0x12;                         // O_OSD_COLOR7[15:8];

    ISPRW8(APACHE_ISP_BASE,0x098F  )=  0x10;                         // O_OSD_OUTLINE_Y;
    ISPRW8(APACHE_ISP_BASE,0x0990  )=  0x80;                         // O_OSD_OUTLINE_CB;
    ISPRW8(APACHE_ISP_BASE,0x0991  )=  0x80;                         // O_OSD_OUTLINE_CR;

//  ISPRW8(APACHE_ISP_BASE,0x099B  )=  0x18;                         // {3'd0, O_OSD_BOX0_EN, 1'd0, O_OSD_BOX0_PRI, O_OSD_BOX0_TRANS_EN};
//  ISPRW8(APACHE_ISP_BASE,0x099C  )=  0x10;                         // O_OSD_BOX0_SX[7:0];
//  ISPRW8(APACHE_ISP_BASE,0x099D  )=  0x00;                         // {5'd0, O_OSD_BOX0_SX[10:8]};
//  ISPRW8(APACHE_ISP_BASE,0x099E  )=  0x10;                         // O_OSD_BOX0_SY[7:0];
//  ISPRW8(APACHE_ISP_BASE,0x099F  )=  0x00;                         // {5'd0, O_OSD_BOX0_SY[10:8]};
//  ISPRW8(APACHE_ISP_BASE,0x09A0  )=  0x20;                         // O_OSD_BOX0_EX[7:0];
//  ISPRW8(APACHE_ISP_BASE,0x09A1  )=  0x00;                         // {5'd0, O_OSD_BOX0_EX[10:8]};
//  ISPRW8(APACHE_ISP_BASE,0x09A2  )=  0x20;                         // O_OSD_BOX0_EY[7:0];
//  ISPRW8(APACHE_ISP_BASE,0x09A3  )=  0x00;                         // {5'd0, O_OSD_BOX0_EY[10:8]};
//  ISPRW8(APACHE_ISP_BASE,0x09A4  )=  0xA0;                         // O_OSD_BOX0_Y;
//  ISPRW8(APACHE_ISP_BASE,0x09A5  )=  0x80;                         // O_OSD_BOX0_CB;
//  ISPRW8(APACHE_ISP_BASE,0x09A6  )=  0x80;                         // O_OSD_BOX0_CR;
//  ISPRW8(APACHE_ISP_BASE,0x09A7  )=  0x40;                         // O_OSD_BOX0_TRANS_VALUE;
#ifdef OSD_OPTION_CHINESE_TRADITIONAL
    ISPRW8(APACHE_ISP_BASE,0x09CF  )=  0x0C;                         // {O_OSD_IN_CSWAP, O_OSD_YC422_CROMA, O_OSD_YC422_OUT, O_OSD_ROM_EN, O_OSD_ROM_CHINESE_TRADITIONAL, O_OSD_COLOR_OFF, O_OSD_BUS_ENABLE}
#else
    ISPRW8(APACHE_ISP_BASE,0x09CF  )=  0x08;                         // {O_OSD_IN_CSWAP, O_OSD_YC422_CROMA, O_OSD_YC422_OUT, O_OSD_ROM_EN, O_OSD_ROM_CHINESE_TRADITIONAL, O_OSD_COLOR_OFF, O_OSD_BUS_ENABLE}
#endif
    ISPRW8(APACHE_ISP_BASE,0x09D4  )=  0xFF;                         // O_HDOSD_BOX0_EDGEDEPTH;
//  ISPRW8(APACHE_ISP_BASE,0x09DA  )=  0x00;                         // {7'h0, I_ROM_SEL_FONT}

    Command_Clear(1, 0, 0, 0, 0, 0, 0);
    ISPRW8(APACHE_ISP_BASE,0x0900  )=  0x90;                         // {O_HDOSD_EN, O_HDOSD_GRD_INTERLACE, O_HDOSD_GRD_FSWAP, O_HDOSD_GRD_INDEXZERO_EN, O_HDOSD_FNT_YLPF_EN, O_HDOSD_FNT_CLPF_EN, O_HDOSD_BLKTIMER_RST, O_HDOSD_OUTLINE_EN}
}


//////////////////////////////////////////////////////////////////////////////////////////////////
//  Function    :   Command_Clear                                                               //
//  Error Msg   :   0x00        all green                                                       //
//                  0x01        vertical GVR index over                                         //
//                  0x02        horizontal GVR index over                                       //
//                  0x03        a previous command is not finished                              //
//  Assign Bits :                                                                               //
//       [15:12]  [11:8]   [7:4]     [3:0]                                                      //
//    {  Color1,  Color2,  Color3,  BFColor  }                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////
unsigned char   Command_Clear(BOOL bWait, BOOL bStyle, BOOL bColor, BOOL bIndex, unsigned char Style, unsigned char Color, unsigned int Index)
{
    unsigned char Cmd;

    // check previous command
    Cmd = ISPRW8(APACHE_ISP_BASE,0x0992);
    if(Cmd & 0x10)          return 0x03;

    ISPRW8(APACHE_ISP_BASE,0x0998  )=  ((Style & 0x07) << 5) | ((Color & 0x07) << 2);
    ISPRW8(APACHE_ISP_BASE,0x0999  )=  Index & 0xFF;
    ISPRW8(APACHE_ISP_BASE,0x099A  )=  (Index >> 8) & 0xFF;

    ISPRW8(APACHE_ISP_BASE,0x0992  )=  0x10 | ((bStyle & 0x01) << 2) | ((bColor & 0x01) << 1) | (bIndex & 0x01);
    if(bWait)
    {
        while(0x10 & ISPRW8(APACHE_ISP_BASE,0x0992))
        {
            delay(1);
        }
    }

    return 0x00;
}

//////////////////////////////////////////////////////////////////////////////////////////////////
//  Function    :   Command_Change                                                              //
//  Error Msg   :   0x00        all green                                                       //
//                  0x01        vertical GVR index over                                         //
//                  0x02        horizontal GVR index over                                       //
//                  0x03        a previous command is not finished                              //
//  Assign Bits :                                                                               //
//       [15:12]  [11:8]   [7:4]     [3:0]                                                      //
//    {  Color1,  Color2,  Color3,  BFColor  }                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////
unsigned char   Command_Change(BOOL bWait, BOOL bStyle, BOOL bColor, BOOL bIndex, unsigned int st_vpos, unsigned int st_hpos, unsigned int ed_vpos, unsigned int ed_hpos, unsigned char Style, unsigned char Color, unsigned int Index)
{
    unsigned int vpos_st, hpos_st, vpos_ed, hpos_ed;
    unsigned char Cmd;

    vpos_st    = (st_vpos >= gl_gvr_vnum)   ? (gl_gvr_vnum - 1)    : st_vpos;
    hpos_st    = (st_hpos >= gl_gvr_hnum)   ? (gl_gvr_hnum - 1)    : st_hpos;
    vpos_ed    = (ed_vpos >= gl_gvr_vnum)   ? (gl_gvr_vnum - 1)    : ed_vpos;
    hpos_ed    = (ed_hpos >= gl_gvr_hnum)   ? (gl_gvr_hnum - 1)    : ed_hpos;
    if(vpos_ed <= vpos_st)  return 0x01;
    if(hpos_ed <= hpos_st)  return 0x02;

    // check previous command
    Cmd = ISPRW8(APACHE_ISP_BASE,0x0993);
    if(Cmd & 0x10)          return 0x03;

    ISPRW8(APACHE_ISP_BASE,0x0994  )=  vpos_st & 0xFF;
    ISPRW8(APACHE_ISP_BASE,0x0995  )=  hpos_st & 0xFF;
    ISPRW8(APACHE_ISP_BASE,0x0996  )=  vpos_ed & 0xFF;
    ISPRW8(APACHE_ISP_BASE,0x0997  )=  hpos_ed & 0xFF;
    ISPRW8(APACHE_ISP_BASE,0x0998  )=  ((Style & 0x07) << 5) | ((Color & 0x07) << 2);
    ISPRW8(APACHE_ISP_BASE,0x0999  )=  Index & 0xFF;
    ISPRW8(APACHE_ISP_BASE,0x099A  )=  (Index >> 8) & 0xFF;

    ISPRW8(APACHE_ISP_BASE,0x0993  )=  0x10 | ((bStyle & 0x01) << 2) | ((bColor & 0x01) << 1) | (bIndex & 0x01);
    if(bWait)
    {
        while(0x10 & ISPRW8(APACHE_ISP_BASE,0x0993))
        {
            delay(1);
        }
    }

    return 0x00;
}

void OSD_FontWrite( unsigned int gvr_hpos,
                    unsigned int gvr_vpos,
                    unsigned int fnt_style,
                    unsigned int fnt_color,
                    unsigned int fnt_index)
{
    unsigned int h_pos, v_pos, font_pos;
    unsigned char font_data0, font_data1;

    h_pos     = (gl_gvr_hnum <= gvr_hpos) ? (gl_gvr_hnum - 1) : gvr_hpos;
    v_pos     = (gl_gvr_vnum <= gvr_vpos) ? (gl_gvr_vnum - 1) : gvr_vpos;
    font_pos  = v_pos * gl_gvr_hnum + h_pos;
    if(font_pos > OSD_GVRINDEX_MAX) font_pos    = OSD_GVRINDEX_MAX - 1;

    font_data1 = ((fnt_style & 0x07) << 5) | ((fnt_color & 0x07) << 2) | ((fnt_index >> 8) & 0x03);
    font_data0 = fnt_index & 0xFF;

    // FONT DISPLAY SETTING -   (x, y) [POS (bank[2:0], address[7:0]) [FONT (INDEX_PROPERITY)]
    ISPRW8(APACHE_ISP_BASE,0x003C )=  (0x80 | (0x07 & (font_pos >> 7))); // bank set
    ISPRW8(APACHE_ISP_BASE,0x003D )=  ((0xFF & (font_pos << 1)) | 0x01); // address set(MSB)
    ISPRW8(APACHE_ISP_BASE,0x003E )=  font_data1;                        // wdata      (MSB)
    ISPRW8(APACHE_ISP_BASE,0x003D )=  (0xFF & (font_pos << 1));          // address set(LSB)
    ISPRW8(APACHE_ISP_BASE,0x003E )=  font_data0;                        // wdata      (LSB)
}


void YC444toYC422_set(void)
{
    // change CROMA mode  (using mean : centering)

    UCHAR rdata;
//  rdata = ISPRW8(APACHE_ISP_BASE,0x0A02); // {2'd0, O_EXTMUX_CVBSMODE, O_EXTMUX_BT656MODE, 1'd0, O_EXTYCCVT_CROMA_MODE, O_EXTYCCVT_OUTPUT_MODE, O_EXT656ENC_YCSWAP};
    rdata = ISPRW8(APACHE_ISP_BASE,0x0A1C); // {2'd0,O_EXTYCCVT_CROMA_MODE,O_EXTYCCVT_OUTPUT_MODE,O_V_SCALE_EN,O_LCDC_C_SWAP,O_EXTSET_TG_HLD_EN,O_LCDC_HUP_EN};
    ISPRW8(APACHE_ISP_BASE,0x0A1C )=  rdata | 0x04;
}

void OTP_set()
{
    ISPRW8(APACHE_ISP_BASE,0x0A00 )=  0x18;  // {3'd0, O_EN, O_SYNCGEN_EN, O_TST_PAT[2:0]};
    ISPRW8(APACHE_ISP_BASE,0x0A01 )=  0x00;  // {3'd0, O_PAT0_BAR, O_PAT1_IW, O_PAT1_QB, O_PAT1_BAR};
}


void OUTPUT_FORMATTER_set()
{
    ISPRW8(APACHE_ISP_BASE,0x0D2B )=  0x06;  // {OF_BT1120ENC_INSERT_CRC_EN, OF_BT1120ENC_INSERT_CRC_IINV, OF_BT1120ENC_INSERT_CRC_OINV, OF_BT1120ENCO_HSY2HAT, OF_BT1120ENC0_YCSWAP, OF_BT1120_ENC_EN, OF_BT1120ENC_USINGSYNC, OF_BT1120ENC_INSERT_LINE_EN};
    ISPRW8(APACHE_ISP_BASE,0x0D30 )=  0x04;  // {OF_BT1120ENCM_EN[2], OF_BT1120ENCM_YCSWAP[1], OF_BT1120ENCM_ALIGN_SEL[0]}
}

void IRIS_set()
{
    ISPRW8(APACHE_ISP_BASE,0x0A70 )=  0x52;  // {O_REG_CHG, O_IRIS_LSEN, 1'd0, O_IRIS_LSEXTG, O_IRIS_LSSELLN, O_IRIS_LSSHIFT};
    ISPRW8(APACHE_ISP_BASE,0x0A71 )=  0x01;  // {6'd0, O_IRIS_VIDEO_BOUNDARY_VAL[9:8]};
    ISPRW8(APACHE_ISP_BASE,0x0A72 )=  0x00;  // O_IRIS_VIDEO_BOUNDARY_VAL[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0A73 )=  0x16;  // {O_IRIS_SEL, O_IRIS_VIDEO_SEL, 1'd0, O_IRIS_VIDEO_BOUNDARY_VBLK, O_IRIS_VIDEO_BOUNDARY_HBLK, O_IRIS_INV};
    ISPRW8(APACHE_ISP_BASE,0x0A74 )=  0x02;  // {6'd0, O_IRIS_USER_DCLEVEL[9:8]};
    ISPRW8(APACHE_ISP_BASE,0x0A75 )=  0x00;  // O_IRIS_USER_DCLEVEL[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0A76 )=  0x04;  // {2'd0, O_IRIS_1ND_AGCLEVEL[13:8]};
    ISPRW8(APACHE_ISP_BASE,0x0A77 )=  0x00;  // O_IRIS_1ND_AGCLEVEL[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0A78 )=  0x00;  // {5'd0, O_IRIS_1ND_OFFSET[10:8]};
    ISPRW8(APACHE_ISP_BASE,0x0A79 )=  0x01;  // O_IRIS_1ND_OFFSET[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0A7A )=  0x10;  // {2'd0, O_IRIS_2ND_AGCLEVEL[13:8]};
    ISPRW8(APACHE_ISP_BASE,0x0A7B )=  0x00;  // O_IRIS_2ND_AGCLEVEL[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0A7C )=  0x00;  // O_IRIS_2ND_AGCLF_SPD[15:8];
    ISPRW8(APACHE_ISP_BASE,0x0A7D )=  0x01;  // O_IRIS_2ND_AGCLF_SPD[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0A7E )=  0x0C;  // {O_PWM_ACC_SHIFT, O_REG_CHG_AUTO_EN, O_PWM_ACCEN, O_PWM_INV, O_PWM_BASE_INV};
    ISPRW8(APACHE_ISP_BASE,0x0A7F )=  0x00;  // O_PWM_MAX[15:8];
    ISPRW8(APACHE_ISP_BASE,0x0A80 )=  0x80;  // O_PWM_MAX[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0A81 )=  0x00;  // O_PWM_BASE_MAX[15:8];
    ISPRW8(APACHE_ISP_BASE,0x0A82 )=  0x80;  // O_PWM_BASE_MAX[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0A83 )=  0x00;  // O_PWM_BASE_HIGHVAL[15:8];
    ISPRW8(APACHE_ISP_BASE,0x0A84 )=  0x40;  // O_PWM_BASE_HIGHVAL[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0A85 )=  0x00;  // O_IRIS_2ND_AGCLF_STEP[12:8];
    ISPRW8(APACHE_ISP_BASE,0x0A86 )=  0x10;  // O_IRIS_2ND_AGCLF_STEP[7:0];
    ISPRW8(APACHE_ISP_BASE,0x0A87 )=  0x03;  // {6'd0, O_IRIS_2ND_AGCLF_USESTEP, O_IRIS_2ND_AGCLF_EN};

//    // Linear Function Test
//    delay(100);
//    ISPRW8(APACHE_ISP_BASE,0x0A7A )=  0x3F;  // {2'd0, O_IRIS_2ND_AGCLEVEL[13:8]};
//    ISPRW8(APACHE_ISP_BASE,0x0A7B )=  0xFF;  // O_IRIS_2ND_AGCLEVEL[7:0];
// 
//    delay(10000);
//    ISPRW8(APACHE_ISP_BASE,0x0A7A )=  0x00;  // {2'd0, O_IRIS_2ND_AGCLEVEL[13:8]};
//    ISPRW8(APACHE_ISP_BASE,0x0A7B )=  0x00;  // O_IRIS_2ND_AGCLEVEL[7:0];
// 
//    delay(10000);
//    ISPRW8(APACHE_ISP_BASE,0x0A7A )=  0x11;  // {2'd0, O_IRIS_2ND_AGCLEVEL[13:8]};
//    ISPRW8(APACHE_ISP_BASE,0x0A7B )=  0x11;  // O_IRIS_2ND_AGCLEVEL[7:0];
}
#endif /*TEST_MODE_ISP2M*/
