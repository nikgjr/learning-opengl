/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_IPC










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT32  mIPC_TestSendStartAddr;
    UINT32  mIPC_TestRecvStartAddr;
    UINT32  mIPC_TestBuffSize;
    
    UINT8   mIPC_TestSendEndFlag;
    UINT32  mIPC_TestSendFailCnt;
    UINT32  mIPC_TestSendBuff[MAX_OF_IPC_CH][MAX_OF_FIFO_ID];
    UINT32  mIPC_TestSendSize[MAX_OF_IPC_CH][MAX_OF_FIFO_ID];
    UINT32  mIPC_TestSendCnt[MAX_OF_IPC_CH][MAX_OF_FIFO_ID];
    
    UINT8   mIPC_TestRecvEndFlag;
    UINT32  mIPC_TestRecvFailCnt;
    UINT32  mIPC_TestRecvBuff[MAX_OF_IPC_CH][MAX_OF_FIFO_ID];
    UINT32  mIPC_TestRecvSize[MAX_OF_IPC_CH][MAX_OF_FIFO_ID];
    UINT32  mIPC_TestRecvCnt[MAX_OF_IPC_CH][MAX_OF_FIFO_ID];

    UINT8   mIPC_TestIntcThre[MAX_OF_IPC_CH][MAX_OF_FIFO_ID];

    UINT32  mIPC_TestEndData[3];
    BOOL    mIPC_DebugMsgOn;
} tIPCTEST_FLAG, *ptIPCTEST_FLAG;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tIPCTEST_FLAG tIPCTestFlag; 
volatile tIPCTEST_FLAG tIPCTestFlag_Def = {
                                             APACHE_DRAM_BASE
                                            ,APACHE_DRAM_BASE+(16*MB)    
                                            ,(1*KB)


                                            ,2
                                            ,0
                                            ,{
                                                 { 0, 0, 0, 0}
                                                ,{ 0, 0, 0, 0}
                                                ,{ 0, 0, 0 ,0}
                                             }
                                            ,{
                                                 { 0, 0, 0, 0}
                                                ,{ 0, 0, 0, 0}
                                                ,{ 0, 0, 0 ,0}
                                             }
                                            ,{
                                                 { 0, 0, 0, 0}
                                                ,{ 0, 0, 0, 0}
                                                ,{ 0, 0, 0 ,0}
                                             } 

                                            
                                            ,2
                                            ,0
                                            ,{
                                                 { 0, 0, 0, 0}
                                                ,{ 0, 0, 0, 0}
                                                ,{ 0, 0, 0 ,0}
                                             }
                                            ,{
                                                 { 0, 0, 0, 0}
                                                ,{ 0, 0, 0, 0}
                                                ,{ 0, 0, 0 ,0}
                                             }
                                            ,{
                                                 { 0, 0, 0, 0}
                                                ,{ 0, 0, 0, 0}
                                                ,{ 0, 0, 0 ,0}
                                             }

                                            // 
                                            ,{
                                                 { 1, 3, 5, 9}
                                                ,{ 1, 3, 5, 9}
                                                ,{ 1, 3, 5, 9}
                                             }

                                            ,{0, 0xA5A5A5A5, 0x5A5A5A5A}
                                            ,OFF
                                           };












/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __test_ipc_byte_display_buff(UINT8 *String, UINT8 *pBuff, UINT32 Size)
{
    UINT32 i;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");	
    DEBUGMSG(MSGINFO, "\n >> %s BuffAddr = 0x%08X, Size = 0x%08X", String, pBuff, Size);	
    for(i=0;i<Size;i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", pBuff+i);	
        DEBUGMSG(MSGINFO, "%02X ", pBuff[i]);	
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");	
}


static INT32 __test_ipc_compare_buff(UINT8 *pSrc, UINT8* pDes, UINT32 size)
{
    INT32  ret = NC_SUCCESS; 
    UINT32 i;
    
    for(i=0; i<size; i++)
    {
        if(pSrc[i] != pDes[i])
        {
            DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
            DEBUGMSG(MSGERR, " >> IPC Compare Error Case - 0x%08X\n", size);
            DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", &pSrc[i], &pDes[i]);
            DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", &pSrc[0], &pSrc[0]+size);
            DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", &pDes[0], &pDes[0]+size); 
            
            i -= ((i>=0x100)?0x80:i);
            __test_ipc_byte_display_buff("SRC", &pSrc[i], 0x100);
            __test_ipc_byte_display_buff("DST", &pDes[i], 0x100);
            
            ret = NC_FAILURE;
            break;
        }
    }

    return ret;
}


static void __test_ipc_clear_buff(UINT8 *pAddr, UINT32 size, UINT8 ClsValue)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        pAddr[i] = ClsValue;
    }
}


static void __test_ipc_buff_init(BOOL Clr)
{
    eIPC_CH  Ch;
    eFIFO_ID Id;

    UINT32 Addr;
    UINT32 Size = tIPCTestFlag.mIPC_TestBuffSize;
    

    if(Clr == TRUE)
    {
        if(tIPCTestFlag.mIPC_DebugMsgOn == ON)
        {
            DEBUGMSG(MSGINFO, "-----------------------------------------------------------------\n");
            DEBUGMSG(MSGINFO, " > Send Buffer Address\n");
        }
        Addr = tIPCTestFlag.mIPC_TestSendStartAddr;
        for(Ch=IPC_CH0; Ch<MAX_OF_IPC_CH; Ch++)
        {
            if(tIPCTestFlag.mIPC_DebugMsgOn == ON)
                DEBUGMSG(MSGINFO, "   -. %d ", Ch); 
            for(Id=IPC_FIFO0; Id<MAX_OF_FIFO_ID; Id++)
            {
                tIPCTestFlag.mIPC_TestSendBuff[Ch][Id] = Addr;
                tIPCTestFlag.mIPC_TestSendSize[Ch][Id]  = 0;
                tIPCTestFlag.mIPC_TestSendCnt[Ch][Id] = 0;
                Addr += Size;

                if(tIPCTestFlag.mIPC_DebugMsgOn == ON)
                    DEBUGMSG(MSGINFO, "0x%08x ", tIPCTestFlag.mIPC_TestSendBuff[Ch][Id]); 
            }
            if(tIPCTestFlag.mIPC_DebugMsgOn == ON)
                DEBUGMSG(MSGINFO, "\n"); 
        }


        if(tIPCTestFlag.mIPC_DebugMsgOn == ON)
            DEBUGMSG(MSGINFO, " > Recv Buffer Address\n");
        Addr = tIPCTestFlag.mIPC_TestRecvStartAddr;    
        for(Ch=IPC_CH0; Ch<MAX_OF_IPC_CH; Ch++)
        {
            if(tIPCTestFlag.mIPC_DebugMsgOn == ON)
                DEBUGMSG(MSGINFO, "   -. %d ", Ch); 
            for(Id=IPC_FIFO0; Id<MAX_OF_FIFO_ID; Id++)
            {
                tIPCTestFlag.mIPC_TestRecvBuff[Ch][Id] = Addr;
                tIPCTestFlag.mIPC_TestRecvSize[Ch][Id]  = 0;
                tIPCTestFlag.mIPC_TestRecvCnt[Ch][Id] = 0;
                Addr += Size;

                if(tIPCTestFlag.mIPC_DebugMsgOn == ON)
                    DEBUGMSG(MSGINFO, "0x%08x ", tIPCTestFlag.mIPC_TestRecvBuff[Ch][Id]); 
            }
            if(tIPCTestFlag.mIPC_DebugMsgOn == ON)
                DEBUGMSG(MSGINFO, "\n"); 
        }

        tIPCTestFlag.mIPC_TestSendEndFlag = 2;
        tIPCTestFlag.mIPC_TestRecvEndFlag = 2;
        tIPCTestFlag.mIPC_TestSendFailCnt = 0;
        tIPCTestFlag.mIPC_TestRecvFailCnt = 0;
    }
    else
    {
        Addr = tIPCTestFlag.mIPC_TestSendStartAddr;
        for(Ch=IPC_CH0; Ch<MAX_OF_IPC_CH; Ch++)
        {
            for(Id=IPC_FIFO0; Id<MAX_OF_FIFO_ID; Id++)
            {
                tIPCTestFlag.mIPC_TestSendBuff[Ch][Id] = Addr;
                Addr += Size;
            }
        }

        Addr = tIPCTestFlag.mIPC_TestRecvStartAddr;    
        for(Ch=IPC_CH0; Ch<MAX_OF_IPC_CH; Ch++)
        {
            for(Id=IPC_FIFO0; Id<MAX_OF_FIFO_ID; Id++)
            {
                tIPCTestFlag.mIPC_TestRecvBuff[Ch][Id] = Addr;
                Addr += Size;
            }
        }

    }
}


INT32 APACHE_TEST_IPC_Recv(eIPC_CH Ch, eFIFO_ID Id)
{
    INT32  ret = NC_FAILURE;
    INT32  Count;   
    UINT32 Data = 0;


    // Current FIFO Count
    Count = ncLib_IPC_Control(GCMD_IPC_GET_CNT, Ch, Id, CMD_END);
    
    // Recv Message
    if(Count == NC_FAILURE)
    {
        tIPCTestFlag.mIPC_TestRecvFailCnt++;
    }
    else if(Count > 0)
    {
        ret = ncLib_IPC_Read(Ch, Id, &Data);
        if(ret == NC_SUCCESS)
        {
            // Send total Count
            tIPCTestFlag.mIPC_TestRecvCnt[Ch][Id] += 1;

            // Debug Message
            if(tIPCTestFlag.mIPC_DebugMsgOn == ON)
                DEBUGMSG(MSGINFO, "\033[1K\r                                > R:%04d C:%d F:%d 0x%08X(%02d)\n", tIPCTestFlag.mIPC_TestRecvSize[Ch][Id], Ch, Id, Data, Count);


            if(tIPCTestFlag.mIPC_TestRecvSize[Ch][Id] <= (tIPCTestFlag.mIPC_TestBuffSize-4))
            {
                if((Data >= tIPCTestFlag.mIPC_TestSendStartAddr) && (Data < tIPCTestFlag.mIPC_TestRecvStartAddr))
                {
                    REGRW32(tIPCTestFlag.mIPC_TestRecvBuff[Ch][Id], 0) = REGRW32(Data, 0);
                    
                    tIPCTestFlag.mIPC_TestRecvBuff[Ch][Id] += 4;
                    tIPCTestFlag.mIPC_TestRecvSize[Ch][Id] += 4;
                }
                else
                {
                    DEBUGMSG(MSGINFO, "\033[1K\r                                 .R:%04d C:%d F:%d 0x%08X(%02d) - Range Fail\n", tIPCTestFlag.mIPC_TestRecvSize[Ch][Id], Ch, Id, Data, Count);
                }
            }

            // Test End Flag
            if((Id == IPC_FIFO0) && (tIPCTestFlag.mIPC_TestRecvEndFlag))
            {
                // Check End Message
                if(tIPCTestFlag.mIPC_TestEndData[tIPCTestFlag.mIPC_TestRecvEndFlag] == Data)
                {
                    // Recv End Message Display
                    //DEBUGMSG(MSGINFO, "\033[1K\r                                > R:%04d C:%d F:%d 0x%08X(%02d)\n", tIPCTestFlag.mIPC_TestRecvSize[Ch][Id], Ch, Id, Data, Count);

                    // End Flag Update
                    tIPCTestFlag.mIPC_TestRecvEndFlag--;
                }
                else
                {
                    // End Flag re-init
                    tIPCTestFlag.mIPC_TestRecvEndFlag = 2;
                }
            }
        }
    }

    return ret;
}


INT32 APACHE_TEST_IPC_Send(eIPC_CH Ch, eFIFO_ID Id)
{
    INT32 ret = NC_FAILURE;    
    INT32 Count;
    UINT32 Data;


    // Check Test Send Buffer Size
    if(tIPCTestFlag.mIPC_TestSendSize[Ch][Id] <= (tIPCTestFlag.mIPC_TestBuffSize-4))
    {
        // Get Test Send Buffer Address
        Data = tIPCTestFlag.mIPC_TestSendBuff[Ch][Id];


        // Current FIFO Count
        Count = ncLib_IPC_Control(GCMD_IPC_GET_CNT, Ch, Id, CMD_END);


        // Check FIFO Count
        if(Count == NC_FAILURE)
        {
            tIPCTestFlag.mIPC_TestSendFailCnt++;
        }
        else if(Count < 16)
        {
            // Debug Message Display
            if(tIPCTestFlag.mIPC_DebugMsgOn == ON)
                DEBUGMSG(MSGINFO, "\033[1K\r > S:%04d C:%d F:%d 0x%08X(%02d)\n", tIPCTestFlag.mIPC_TestSendSize[Ch][Id], Ch, Id, Data, Count);

            
            // Send Message
            ret = ncLib_IPC_Write(Ch, Id, Data);
            if(ret == NC_SUCCESS)
            {
                // Test Send Buffer Addr/Size Increase 
                tIPCTestFlag.mIPC_TestSendBuff[Ch][Id] += 4;
                tIPCTestFlag.mIPC_TestSendSize[Ch][Id] += 4;

                // Debug Send Success Count
                tIPCTestFlag.mIPC_TestSendCnt[Ch][Id] += 1;
            }
            else
            {
                // Send Message Fail
                DEBUGMSG(MSGINFO, "\033[1K\r  ....... C:%d F:%d 0x%08X(%02d) - Send Fail\n", Ch, Id, Data, Count);
            }
        }
    }
    else
    {
        // End Command
        if(   (tIPCTestFlag.mIPC_TestSendSize[Ch][0] == tIPCTestFlag.mIPC_TestBuffSize)
           && (tIPCTestFlag.mIPC_TestSendSize[Ch][1] == tIPCTestFlag.mIPC_TestBuffSize)
           && (tIPCTestFlag.mIPC_TestSendSize[Ch][2] == tIPCTestFlag.mIPC_TestBuffSize)
           && (tIPCTestFlag.mIPC_TestSendSize[Ch][3] == tIPCTestFlag.mIPC_TestBuffSize))
        {
            if(tIPCTestFlag.mIPC_TestSendEndFlag)
            {
                // End Data
                Data = tIPCTestFlag.mIPC_TestEndData[tIPCTestFlag.mIPC_TestSendEndFlag];
                
                // Current FIFO Count
                Count = ncLib_IPC_Control(GCMD_IPC_GET_CNT, Ch, IPC_FIFO0, CMD_END);

                // Check FIFO Count
                if(Count == NC_FAILURE)
                {
                    tIPCTestFlag.mIPC_TestSendFailCnt++;
                }
                else if(Count < 16)
                {
                    //DEBUGMSG(MSGINFO, "\033[1K\r > S:%04d C:%d F:%d 0x%08X(%02d)\n", tIPCTestFlag.mIPC_TestSendSize[Ch][IPC_FIFO0], Ch, IPC_FIFO0, Data, Count);
                    
                    // Send Message
                    ret = ncLib_IPC_Write(Ch, IPC_FIFO0, Data);
                    
                    if(ret == NC_SUCCESS)
                    {
                        // End Flag Update 
                        tIPCTestFlag.mIPC_TestSendEndFlag--;

                        // Debug Send Success Count
                        tIPCTestFlag.mIPC_TestSendCnt[Ch][IPC_FIFO0] += 1;
                    }
                }
            }
        }

        ret = NC_SUCCESS;
    }

    return ret;
}


void APACHE_TEST_IPC_Isr(UINT32 irq)
{
    INT32  ret = NC_SUCCESS;
    INT32  Sts;    
    
    eIPC_CH  Ch = (eIPC_CH)(irq - IRQ_NUM_IPC0);
    eFIFO_ID Id;


    // Check Channel Status 
    Sts = ncLib_IPC_Control(GCMD_IPC_GET_INT_STS, Ch, CMD_END);


    // Check FIFO Status. 
    for(Id=IPC_FIFO0; Id<MAX_OF_FIFO_ID; Id++)
    {
        // Message Recv
        if(Sts&(1<<2))
        {
            while(1)
            {
                ret = APACHE_TEST_IPC_Recv(Ch, Id);
                if(ret == NC_FAILURE)
                    break;
            }
        }

        // Overflow
        if(Sts&(1<<0))
            DEBUGMSG(MSGINFO, "\033[1K\r                                 .......  C:%d F:%d %02X - Overflow\n", Ch, Id, (Sts&0xf));

        // Underflow
        if(Sts&(1<<1))
            DEBUGMSG(MSGINFO, "\033[1K\r                                 .......  C:%d F:%d %02X - Underflow\n", Ch, Id, (Sts&0xf));

        // Next FIFO Check 
        Sts = (Sts>>4);
    }

    // Interrupt Status Clear 
    ncLib_IPC_Control(GCMD_IPC_CLR_INT_STS, Ch, CMD_END);
}


void APACHE_TEST_IPC_Isr_Init(eIPC_CH Ch)
{
    // Register IPC Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_REGISTER_INT
                      ,IRQ_NUM_IPC0 + Ch
                      ,(PrHandler)APACHE_TEST_IPC_Isr
                      ,CMD_END);
}


void APACHE_TEST_IPC_Isr_DeInit(eIPC_CH Ch)
{
    // Unregister SPI Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT
                      ,IRQ_NUM_IPC0 + Ch
                      ,CMD_END);
}


void APACHE_TEST_IPC_DeInit(eIPC_CH Ch)
{
    INT32 ret;


    // Unregister IPC Interrupt Handler
    APACHE_TEST_IPC_Isr_DeInit(Ch);


    // Deinit IPC Channel
    ret = ncLib_IPC_Control(GCMD_IPC_DEINIT, Ch, CMD_END);	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "IPC DeInit Error!\n");
    } 

        
    // Close 
    ncLib_IPC_Close();	
}


void APACHE_TEST_IPC_Init(eIPC_CH Ch)
{
    INT32 ret;
    eFIFO_ID Id;
    UINT8 Threshold[4];

    
    // Open IPC
    ncLib_IPC_Open();	


    // Register IPC Interrupt Handler
    APACHE_TEST_IPC_Isr_Init(Ch);


    // Set IPC FIFO Threshold  
    for(Id=IPC_FIFO0; Id<MAX_OF_FIFO_ID; Id++)
        Threshold[Id] = tIPCTestFlag.mIPC_TestIntcThre[Ch][Id];
        

    // Init IPC Channel 
    ret = ncLib_IPC_Control(GCMD_IPC_INIT, Ch, &Threshold[0], CMD_END);	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "IPC Init Error!\n");
    } 
}


void APACHE_TEST_IPC_TIMER_Isr(UINT32 irq)
{
    eTIMER_CH TimerCh = (eTIMER_CH)(irq - IRQ_NUM_TIMER0);
    
    eIPC_CH  IPC_SendCh;
    static eFIFO_ID IPC_Id = IPC_FIFO0;

    // timer Intc Clear and Status Check
    ncLib_TIMER_Control(GCMD_TC_GET_INT_STS, TimerCh, CMD_END);

    // IPC Channel Select
    if(ASM_GET_CORE_ID() == DLS_CORE) 
        IPC_SendCh = IPC_CH1;  
    else
        IPC_SendCh = IPC_CH0; 

    // Send Message
    APACHE_TEST_IPC_Send(IPC_SendCh, IPC_Id);
    if(++IPC_Id == MAX_OF_FIFO_ID)
        IPC_Id = IPC_FIFO0;
}


void APACHE_TEST_IPC_TIMER_DeInit(eTIMER_CH TimerCh)
{
    INT32 ret; 

    
    // Stop timer
    ret = ncLib_TIMER_Control(GCMD_TC_STOP, TimerCh, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Stop Error!\n");
    }


    // DeInit timer
    ret = ncLib_TIMER_Control(GCMD_TC_DEINIT_CH, TimerCh, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer DeInit Error!\n");
    }


    // Unregister TIMER Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT
                      ,IRQ_NUM_TIMER0 + TimerCh
                      ,CMD_END); 


    // Close Timer
    ncLib_TIMER_Close();
}


void APACHE_TEST_IPC_TIMER_Init(eTIMER_CH TimerCh)
{
    INT32 ret;   
    tTIMER_PARAM tTimerParam;

   
    // Open Timer
    ncLib_TIMER_Open();


    // Register TIMER Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_REGISTER_INT
                      ,IRQ_NUM_TIMER0 + TimerCh
                      ,(PrHandler)APACHE_TEST_IPC_TIMER_Isr
                      ,CMD_END);

    
    // Init Timer Channel 
    // Timer Channel Operation Mode
    tTimerParam.mMode      = TC_MODE_PERIOD;
    tTimerParam.mPrescaler = 0;
    if(TimerCh == TC_CH0) 
        tTimerParam.mPeriod1 = 100;
    else
        tTimerParam.mPeriod1 = 150; 

    
    ret = ncLib_TIMER_Control(GCMD_TC_INIT_CH, TimerCh, &tTimerParam, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Init Error!\n");
    }


    // Start timer
    ret = ncLib_TIMER_Control(GCMD_TC_START, TimerCh, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Start Error!\n");
    }
}


INT32 APACHE_TEST_IPC_Auto(void)
{ 
    INT32 ret = NC_SUCCESS;
    INT32 err;
    eIPC_CH   IPC_RecvCh;
    eIPC_CH   IPC_SendCh;
    eFIFO_ID  IPC_Id;
    eTIMER_CH TimerCh;
    static UINT8 sIPCTestInitValue = 0xFF;

    
    // Debug Test Buff
    __test_ipc_buff_init(TRUE);


    // Select Channle
    if(ASM_GET_CORE_ID() == DLS_CORE) 
    {
        IPC_RecvCh = IPC_CH0;
        IPC_SendCh = IPC_CH1;
        TimerCh    = TC_CH0;
    }
    else
    {
        IPC_RecvCh = IPC_CH1; 
        IPC_SendCh = IPC_CH0;
        TimerCh    = TC_CH4;
    }


    // Buffer Clear
    if(sIPCTestInitValue == 0xFF)
        sIPCTestInitValue = 0x00;
    else
        sIPCTestInitValue = 0xFF;
    for(IPC_Id=IPC_FIFO0; IPC_Id<MAX_OF_FIFO_ID; IPC_Id++)
        __test_ipc_clear_buff((void*)(tIPCTestFlag.mIPC_TestRecvBuff[IPC_RecvCh][IPC_Id]), tIPCTestFlag.mIPC_TestBuffSize, sIPCTestInitValue);



    DEBUGMSG(MSGINFO, "-----------------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, " > IPC Test Start [Recv:%d Send:%d] \n", IPC_RecvCh, IPC_SendCh);


    // IPC Init
    APACHE_TEST_IPC_Init(IPC_RecvCh);


    // Timer Init
    APACHE_TEST_IPC_TIMER_Init(TimerCh);


    // Wait
    while(1)
    {
        // Check Send/Recv End
        if((!tIPCTestFlag.mIPC_TestSendEndFlag) && (!tIPCTestFlag.mIPC_TestRecvEndFlag))
            break;

        // User Stop
        if(APACHE_TEST_ExitKey())
            break;
    }
    
    

    // Clean up the remaining data.
    DEBUGMSG(MSGINFO, " > Clean Up S:%08X R:%08X\n" , tIPCTestFlag.mIPC_TestSendFailCnt, tIPCTestFlag.mIPC_TestRecvFailCnt);
    for(IPC_Id=IPC_FIFO0; IPC_Id<MAX_OF_FIFO_ID; IPC_Id++)
    {
        while(1)
        {
            if(APACHE_TEST_IPC_Recv(IPC_RecvCh, IPC_Id) == NC_FAILURE)
                break;
        }
    }
        


    // Compare
    __test_ipc_buff_init(FALSE);
    for(IPC_Id=IPC_FIFO0; IPC_Id<MAX_OF_FIFO_ID; IPC_Id++)
    {
        DEBUGMSG(MSGINFO, " > CH_%d FIFO_%d %04d(%d) vs %04d(%d)", IPC_RecvCh, IPC_Id, 
                                                       tIPCTestFlag.mIPC_TestSendSize[IPC_SendCh][IPC_Id],
                                                       tIPCTestFlag.mIPC_TestSendCnt[IPC_SendCh][IPC_Id],
                                                       tIPCTestFlag.mIPC_TestRecvSize[IPC_RecvCh][IPC_Id],
                                                       tIPCTestFlag.mIPC_TestRecvCnt[IPC_RecvCh][IPC_Id]);
        
        err = __test_ipc_compare_buff((UINT8*)(tIPCTestFlag.mIPC_TestSendBuff[IPC_RecvCh][IPC_Id]), 
                                      (UINT8*)(tIPCTestFlag.mIPC_TestRecvBuff[IPC_RecvCh][IPC_Id]), 
                                               tIPCTestFlag.mIPC_TestRecvSize[IPC_RecvCh][IPC_Id]);

        DEBUGMSG(MSGINFO, " - S:0x%08X vs R:0x%08X", tIPCTestFlag.mIPC_TestSendBuff[IPC_RecvCh][IPC_Id],
                                                     tIPCTestFlag.mIPC_TestRecvBuff[IPC_RecvCh][IPC_Id]);
        
        
        if(err == NC_FAILURE)
        {
            ret = NC_FAILURE;
            DEBUGMSG(MSGINFO, " Compare Fail");
        }
        DEBUGMSG(MSGINFO, "\n");
    }


    // Timer DeInit
    APACHE_TEST_IPC_TIMER_DeInit(TimerCh);


    // IPC DeInit
    APACHE_TEST_IPC_DeInit(IPC_RecvCh);

    return ret;
}


void APACHE_TEST_IPC_Auto_loop(void)
{
    INT32 ret;    
    
    while(1)
    {
        // Test Run
        ret = APACHE_TEST_IPC_Auto();
        if(ret == NC_FAILURE)
        {
            // Error Case - Test Stop
            break;
        }


        // User Key Command - Test Stop
        DEBUGMSG(MSGINFO, "\n\n");
        DEBUGMSG(MSGINFO, " > Loop Test Stop Command \n");
        DEBUGMSG(MSGINFO, "   -. Pless 'Q' and 'q' Key \n");
        while((ret = APACHE_TEST_ExitKey()) == FALSE)
        {
            // Key Input Wait Time Out
            if(APACHE_TEST_mTimeOut(1000))
                break;
        }
        APACHE_TEST_mTimeOut(0);
        if(ret == TRUE)
            break;
    }
}

void APACHE_TEST_IPC_Manual(void)
{ 
    eIPC_CH  Ch = IPC_CH0;
    eFIFO_ID Id = IPC_FIFO0;
    
    INT8 buf = 0; 


    // Debug Test Buff
    __test_ipc_buff_init(TRUE);
    

    // IPC Init
    if(ASM_GET_CORE_ID() == DLS_CORE)
    {
        APACHE_TEST_IPC_Init(IPC_CH0);
        APACHE_TEST_IPC_Init(IPC_CH2);
    }
    else
    {
        APACHE_TEST_IPC_Init(IPC_CH1);
    }


    // Channel and FIFO Select Menu
    APACHE_TEST_GetArrowKey_Help("FIFO ID Up", "FIFO ID Down", "Channel Up", "Channel Down");
    DEBUGMSG(MSGINFO, " > Send C:%d F:%d", Ch, Id);
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Test End 
            if((buf == 'Q') || (buf == 'q'))
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(Id < IPC_FIFO3) Id++;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(Id > IPC_FIFO0) Id--;
            }
            // Number Key '6' and Direction Key 'Right'
            else if(buf == '6')
            {
                if(Ch < IPC_CH2) Ch++;
            }
            // Number Key '4' and Direction Key 'Left'
            else if(buf == '4')
            {
                if(Ch > IPC_CH0) Ch--;
            }
            
            // Send Data 
            if((buf == '5') || (buf == RETURN_KEY))
            {
                // Send Message
                APACHE_TEST_IPC_Send(Ch, Id);
            }
            
            DEBUGMSG(MSGINFO, "\033[1K\r > Send C:%d F:%d", Ch, Id);
        }
    }


    // IPC DeInit
    if(ASM_GET_CORE_ID() == DLS_CORE)
    {
        APACHE_TEST_IPC_DeInit(IPC_CH0);
        APACHE_TEST_IPC_DeInit(IPC_CH2);
    }
    else
    {
        APACHE_TEST_IPC_DeInit(IPC_CH1);
    }

}


INT32 APACHE_TEST_IPC_CUTMode(void)
{
    INT32 select;
    char buf[256];


    // Default Init Variable
    tIPCTestFlag = tIPCTestFlag_Def;


    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - IPC                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " IPC Controller                                             \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> IPC Send Message (Manual)                              \n");
        DEBUGMSG(MSGINFO, " <2> IPC Send Message (Auto, Used Timer)                    \n");
        DEBUGMSG(MSGINFO, " <3> IPC Send Loop Test                                     \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ..%s                       \n", (tIPCTestFlag.mIPC_DebugMsgOn)?"o":"x");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                 APACHE_TEST_IPC_Manual();
            break;
            
            case 2:
                 APACHE_TEST_IPC_Auto();
            break;

            case 3:
                APACHE_TEST_IPC_Auto_loop();
            break;

            case 35: // Z
                _REVERSE(tIPCTestFlag.mIPC_DebugMsgOn);
            break;
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to sub menu\n");
            goto IPC_Exit;
        }
    }

IPC_Exit:

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_IPC */


/* End Of File */

