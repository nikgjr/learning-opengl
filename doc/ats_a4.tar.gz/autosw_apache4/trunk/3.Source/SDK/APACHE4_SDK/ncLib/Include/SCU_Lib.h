/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SCU_LIB_H__
#define __SCU_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* SCU GENERIC & SPECIFIC COMMANDS
*/

typedef enum _SCU_CMD
{
    /*
     * Generic SCU Commands
     */
    GCMD_SCU_GET_STRAP_INFO = 0,
    GCMD_SCU_GET_CLK,

    GCMD_SCU_GET_PINMUX,
    GCMD_SCU_SET_PINMUX,

    GCMD_SCU_GET_DATA,
    GCMD_SCU_SET_DATA,

    GCMD_SCU_ENA_CLK,
    GCMD_SCU_DIS_CLK,

    GCMD_SCU_SET_RST,
  
    GCMD_SCU_MAX,


    /*
     * Specific SCU Commands
     */
    SCMD_SCU_DB_NUM = 100, 

    SCMD_SCU_MAX,
} eSCU_CMD;


/*
 * Clock ID for Apache
 */
typedef enum _SCU_CLK_ID
{
    SCU_CLK_ID_CPU = 0,     // CPU Clock
    SCU_CLK_ID_AXI,         // AXI0 Clock
    SCU_CLK_ID_AHB,         // Not Used
    SCU_CLK_ID_APB,         // APB Clock
    SCU_CLK_ID_ENC,         // Not Used
    SCU_CLK_ID_SSPI,        // Standard SPI Clock
    SCU_CLK_ID_QSPI,        // Quad SPI Clock for sFlash
    SCU_CLK_ID_UART,        // UART Clock
    SCU_CLK_ID_TIMER,       // Timer Clock
    SCU_CLK_ID_WDT,         // Not Used
    SCU_CLK_ID_I2C,         // I2C Clock
    SCU_CLK_ID_CAN,         // CAN Clock
    SCU_CLK_ID_DDR,         // DDR Clock
    SCU_CLK_ID_ADC,         // Not Used
    SCU_CLK_ID_TS,          // Not Used
    SCU_CLK_ID_PWM,         // PWM Clock             
    SCU_CLK_ID_DMA,         // DMA Clock   
    SCU_CLK_ID_IPC,         // IPC Clock
    SCU_CLK_ID_SDC,         // SDC Clock
    SCU_CLK_ID_VDUMP,       // VDUMP Clock

    SCU_CLK_ID_MAX
} eSCU_CLK_ID;


/*
 * Pad ID for Apache
 */
typedef enum _PAD_ID
{
    PAD_NTRST,              // 0
    PAD_TCK,
    PAD_TMS,
    PAD_TDO,
    PAD_TDI,

    //PAD_TM,               // No Ctrl

    PAD_I2C0_SCL,
    PAD_I2C0_SDA,
    PAD_I2C1_SCL,
    PAD_I2C1_SDA,           // 8

    PAD_UART0_RX,
    PAD_UART0_TX,
    PAD_UART1_RX,
    PAD_UART1_TX,
    PAD_UART2_RX,
    PAD_UART2_TX,

    PAD_SPI2_CSN0,          
    PAD_SPI2_CSN1,          // 16
    PAD_SPI2_DQ0,
    PAD_SPI2_DQ1,
    PAD_SPI2_DQ2,
    PAD_SPI2_DQ3,
    PAD_SPI2_SCK,

    //PAD_SYS_CK_I,         // No Ctrl
    //PAD_SAFE_CK_I,        // No Ctrl
    //PAD_SYS_RSTN_I,       // No Ctrl
    
    PAD_SEN_PCLK,
    PAD_SEN_PV,
    PAD_SEN_PH,             // 24
    PAD_SEN_PD0,
    PAD_SEN_PD1,
    PAD_SEN_PD2,
    PAD_SEN_PD3,
    PAD_SEN_PD4,
    PAD_SEN_PD5,
    PAD_SEN_PD6,
    PAD_SEN_PD7,            // 32
    PAD_SEN_PD8,
    PAD_SEN_PD9,
    PAD_SEN_PD10,
    PAD_SEN_PD11,
    PAD_SEN_PD12,
    PAD_SEN_PD13,
    PAD_SEN_PD14,
    PAD_SEN_PD15,           // 40
    
    PAD_VOUT_CK_O,
    PAD_VOUT_VSYNC,
    PAD_VOUT_HSYNC,
    PAD_VOUT_Y0,
    PAD_VOUT_Y1,
    PAD_VOUT_Y2,
    PAD_VOUT_Y3,
    PAD_VOUT_Y4,            // 48
    PAD_VOUT_Y5,
    PAD_VOUT_Y6,
    PAD_VOUT_Y7,
    PAD_VOUT_C0,
    PAD_VOUT_C1,
    PAD_VOUT_C2,
    PAD_VOUT_C3,
    PAD_VOUT_C4,            // 56
    PAD_VOUT_C5,
    PAD_VOUT_C6,
    PAD_VOUT_C7,

    //PAD_FAULT_P,          // No Ctrl
    //PAD_FAULT_N,          // No Ctrl

    PAD_MIPI_SEN_CLK,
    PAD_CAN_RX,
    PAD_CAN_TX,

    PAD_FMC_CLE,
    PAD_FMC_ALE,            // 64
    PAD_FMC_DQ0,
    PAD_FMC_DQ1, 
    PAD_FMC_DQ2,
    PAD_FMC_DQ3,
    PAD_FMC_DQ4,
    PAD_FMC_DQ5, 
    PAD_FMC_DQ6,
    PAD_FMC_DQ7,            // 72

    PAD_FMC_CEN,
    PAD_FMC_REN,
    PAD_FMC_WEN,
    PAD_FMC_WPN,
    PAD_FMC_RBN,

    PAD_SEN_RST_N,          // 78

    PAD_MAX
} ePAD_ID;


typedef enum _PAD_FUNC
{
    PAD_FUNC_0 = 0,
    PAD_FUNC_1,
    PAD_FUNC_2,
    PAD_FUNC_3,
    PAD_FUNC_4,
    PAD_FUNC_5, 
    PAD_FUNC_6, 
    PAD_FUNC_7, 
    PAD_FUNC_MAX,

    PAD_NOT_USED
} ePAD_FUNC;










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    ePAD_ID     mId;
    ePAD_FUNC   mFunc[2];
} tPAD_INFO, *ptPAD_INFO;










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

extern INT32 ncLib_SCU_Open(void);
extern INT32 ncLib_SCU_Close(void);
extern INT32 ncLib_SCU_Read(void);
extern INT32 ncLib_SCU_Write(void);
extern INT32 ncLib_SCU_Control(eSCU_CMD Cmd, ...);


#endif  /* __SCU_LIB_H__ */


/* End Of File */

