/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "JIG_Svc.h"










/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define PRODUCT_NAME                    "#APACHE4_AR\r\n"
#define FIRMWARE_VERISON                "#APACHE4_AR\r\n"


#define STATUS_REG_BASE                 0x8000










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

UCHAR ISP_R[5] = "ISPR?";
UCHAR ISP_W[5] = "ISPW=";
UCHAR ISP_RL[6] = "ISPRL?";
UCHAR ISP_WL[6] = "ISPWL=";

UCHAR ISP_R2[6] = "ISPR2?";
UCHAR ISP_W2[6] = "ISPW2=";

UCHAR BAUDTEST[2] = "TX";
UCHAR VER[4] = "VER?";
UCHAR FIRMWARE[8] = "FIRMWARE";
UCHAR PRODUCT[7] = "PRODUCT";

UCHAR gJigCmd[20];
UCHAR gRData[60];
STRUCT_HAL_UART sHalUart;










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncSvc_JIG_IRQ_Handler(UINT32 irq)
{
    INT32 Reg;
    UINT8 InputData;
    UCHAR InputCountBuffer = 0;
    UCHAR Count = 0;
    UINT8 IntInfo;
    eUART_CH Ch = (eUART_CH)(irq - IRQ_NUM_UART0);

    //DEBUGMSG_SDK(MSGINFO, "Isr_%08x\n", irq);

    Reg = ncLib_UART_Control(GCMD_UT_GET_INT_STS, Ch, CMD_END);
    IntInfo = (Reg&0xE)>>1;
    //DEBUGMSG_SDK(MSGINFO, "Sts(0x%02x)\n", IntInfo);

    if(IntInfo == 1) // Tx Empty Status (Tx Done)
    {
    }
    else
    {
        // Received data available
        while(ncLib_UART_Control(GCMD_UT_GET_FIFO_CNT, Ch, CMD_END))
        {
            InputData = ncLib_UART_Control(GCMD_UT_GET_CHAR, Ch, CMD_END);
            //DEBUGMSG_SDK(MSGINFO, "%02x,%c\n", InputData, InputData);

            if(sHalUart.Mode == 1)
            {
                sHalUart.RxTempBuffer[sHalUart.RxInputCount] = InputData;
                sHalUart.RxInputCount++;

                if(sHalUart.RxInputCount > RX_BUF_SIZE) sHalUart.RxInputCount = 0;
            }
            else if(sHalUart.Mode == 0)
            {
                if(sHalUart.RxStart == 0)
                {
                    if(InputData == '#') sHalUart.Protocol = 1;

                    if(InputData == '#')
                    {
                        sHalUart.CmdProcess = 1;
                        sHalUart.RxStart = 1;
                        sHalUart.RxInputCount = 0;
                        sHalUart.RxTempBuffer[sHalUart.RxInputCount] = InputData;
                        sHalUart.RxInputCount++;
                    }
                }
                else
                {
                    if(sHalUart.Protocol == 1)
                    {
                        if(InputData == '\r')
                        {
                            sHalUart.RxTempBuffer[sHalUart.RxInputCount] = InputData;

                            InputCountBuffer = sHalUart.RxInputCount + 1;
                            sHalUart.RxInputCount = 0;
                            sHalUart.RxStart = 0;

                            if(sHalUart.Command == FALSE)
                            {
                                for(Count = 0; Count < InputCountBuffer; Count++)
                                {
                                    sHalUart.RxRealBuffer[Count] = sHalUart.RxTempBuffer[Count];
                                    sHalUart.RxTempBuffer[Count] = 0;
                                }
                                sHalUart.Command = TRUE;
                            }
                        }
                        else
                        {
                            if(InputData == 0x08) // keyboard backspace key
                            {
                                if(sHalUart.RxInputCount > 0) sHalUart.RxInputCount--;
                            }
                            else
                            {
                                sHalUart.RxTempBuffer[sHalUart.RxInputCount] = InputData;
                                sHalUart.RxInputCount++;
                            }

                            if(sHalUart.RxInputCount > RX_BUF_SIZE)
                            {
                                sHalUart.RxInputCount = 0;

                                for(Count = 0; Count < InputCountBuffer; Count++)
                                {
                                    sHalUart.RxTempBuffer[Count] = 0;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


void ncSvc_JIG_Init(void)
{
    memset(&sHalUart, 0x0, sizeof(sHalUart));
}


void ncSvc_JIG_DeInit(void)
{
}


UCHAR ncSvc_JIG_Ascii_To_Hex_1byte(UCHAR data)    // test
{
    UCHAR tmp = 0, tmp1 = 0;

    if((data >= 'a') && (data <= 'z'))  data = (data - 32);

    if((data >= '0') && (data <= '9'))  tmp = (data - '0');
    else if((data >= 'A') && (data <= 'Z')) tmp = (data - 'A') + 10;
    else tmp1 = 1;

    if(tmp1 < 1)    return tmp;
    else            return FALSE;
}


UCHAR ncSvc_JIG_Ascii_To_Hex_2byte(UCHAR data_h, UCHAR data_l)    // test
{
    UCHAR tmp = 0, tmp1=0;

    if((data_h>='a')&&(data_h<='f')) data_h = data_h - 32;
    if((data_l>='a')&&(data_l<='f')) data_l = data_l - 32;

    if((data_h>='A')&&(data_h<='F'))        tmp = (data_h-'A'+10) << 4;
    else if((data_h>='0')&&(data_h<='9'))   tmp = (data_h-'0') << 4;
    else tmp1 = 1;

    if((data_l>='A')&&(data_l<='F'))        tmp |= (data_l-'A'+10) & 0x0F;
    else if((data_l>='0')&&(data_l<='9'))   tmp |= (data_l-'0') & 0x0F;
    else tmp1 = 1;

    if(tmp1 < 1)    return tmp;
    else            return FALSE;
}


UINT8 ncSvc_JIG_StatusReg_Read(UINT32 Addr)
{
    //return rSWReg.BYTE[Addr];
    return 0;
}


UINT8 ncSvc_JIG_StatusReg_Write(UINT32 Addr, UINT32 Wdata)
{
    //rSWReg.BYTE[Addr] = Wdata;
    //return Wdata;
    return 0xAA;
}


UCHAR ncSvc_JIG_ReadCommand(void)
{
    UCHAR r_data;

    r_data = (CHAR)sHalUart.RxRealBuffer[sHalUart.RxPointer];

    sHalUart.RxPointer++;

    if(sHalUart.RxPointer >= RX_BUF_SIZE)
    {
        sHalUart.RxPointer = RX_BUF_SIZE-1;
    }

    return r_data;
}


BOOL ncSvc_JIG_CmdParser(void)
{
    UCHAR ch = 0;
    UCHAR cmd_ch = 0;
    UCHAR cmd_cnt = 0;
    UCHAR data_cnt = 0;

    while(1)    // command synch.
    {
        if(sHalUart.RxPointer == RX_BUF_SIZE-1)
        {
            sHalUart.RxPointer = 0;
            return FALSE;
        }

        if(ncSvc_JIG_ReadCommand() == '#') break;
    }

    while(ch != 0x0D)
    {
        if(sHalUart.RxPointer == RX_BUF_SIZE-1)
        {
            sHalUart.RxPointer = 0;
            return FALSE;
        }

        ch = ncSvc_JIG_ReadCommand();

        if(cmd_ch==0)
        {
            if((ch >= 'a')&&(ch <= 'z')) ch = ch - 32;
            if((ch == '?')||(ch == '=')) cmd_ch = 1;

            gJigCmd[cmd_cnt] = ch;
            cmd_cnt++;
        }
        else
        {
            gRData[data_cnt] = ch;
            data_cnt++;
        }

        if(sHalUart.RxPointer == RX_BUF_SIZE) break;
    }

    sHalUart.RxPointer = 0;

    return TRUE;
}


CHAR ncSvc_JIG_CmdCompare(UCHAR *nCmp_Data, UCHAR nCmp_Cnt)
{
    CHAR cmd_signe = TRUE;
    UCHAR cmd_cnt = 0;
    UCHAR tmp1, tmp2;

    while(cmd_cnt < nCmp_Cnt)
    {
        tmp1 = gJigCmd[cmd_cnt];
        tmp2 = nCmp_Data[cmd_cnt];

        if(tmp1 != tmp2)
        {
            cmd_signe = FALSE;
            break;
        }
        else cmd_cnt++;
    }

    return cmd_signe;
}


INT32 ncSvc_JIG_CmdExecute(void)
{
    UCHAR uc_data1, uc_data2, uc_data3, isp_rw_reg[20], i, j; // uc_data4,
    //UCHAR Commandlist = 0;
    USHORT Address = 0;
    UCHAR buffer[64];
    UCHAR RdBuffer[40];
    UCHAR WrBuffer[40];

    if(ncSvc_JIG_CmdParser() == 0)
    {
        return NC_FAILURE;
    }

    if(ncSvc_JIG_CmdCompare((UCHAR *) ISP_R, 5))
    {
        uc_data1 = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[0], gRData[1]);  // bank
        uc_data2 = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[2], gRData[3]);  // addr

        Address = (uc_data1 << 8) | uc_data2;

        if((uc_data1 >> 4) == 0x08)
        {
            /* Software Register Read */

            Address = Address - STATUS_REG_BASE;

            uc_data3 = ncSvc_JIG_StatusReg_Read(Address);
        }
        else
        {
            /* ISP Register Read */

            Address = uc_data1;
            Address = (Address << 8) | uc_data2;

            uc_data3 = REGRW8(APACHE_ISP_BASE, Address);
        }

        JIGMSG("#data=%02x\r", uc_data3);
    }
    else if(ncSvc_JIG_CmdCompare((UCHAR *) ISP_W, 5))
    {
        uc_data1 = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[0], gRData[1]);  // addr
        uc_data2 = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[2], gRData[3]);  // addr
        uc_data3 = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[4], gRData[5]);  // data

        Address = (uc_data1 << 8) | uc_data2;

        if((uc_data1 >> 4) == 0x08)
        {
            Address = Address - STATUS_REG_BASE;

            uc_data3 = ncSvc_JIG_StatusReg_Write(Address, uc_data3);
        }
        else
        {
            Address = uc_data1;
            Address = ((Address << 8) | uc_data2);

            REGRW8(APACHE_ISP_BASE, Address) = uc_data3;
        }

        JIGMSG("#data=%02x\r", uc_data3);
    }
    else if(ncSvc_JIG_CmdCompare((UCHAR *) ISP_RL, 6))
    {
        uc_data1 = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[0], gRData[1]);  // addr
        uc_data2 = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[2], gRData[3]);  // addr

        Address = (uc_data1 << 8) | uc_data2;

        if((uc_data1 >> 4) == 0x08)
        {
            Address = Address - STATUS_REG_BASE;

            for(i=0; i<16; i++)
            {
                isp_rw_reg[i] = ncSvc_JIG_StatusReg_Read(Address+i);
            }
        }
        else
        {
            for(i=0; i<16; i++)
            {
                isp_rw_reg[i] = REGRW8(APACHE_ISP_BASE, Address + i);
            }
        }

        isp_rw_reg[16] = 0;

        JIGMSG("#data=");

        for(i=0; i<16; i++)
        {
            JIGMSG("%02x", isp_rw_reg[i]);
            isp_rw_reg[16] += isp_rw_reg[i];    // checksum
        }

        JIGMSG("%02x\r", isp_rw_reg[16]);
    }
    else if(ncSvc_JIG_CmdCompare((UCHAR *) ISP_WL, 6))
    {
        uc_data1 = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[0], gRData[1]);  // addr
        uc_data2 = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[2], gRData[3]);  // addr

        uc_data3 = 0;

        Address = (uc_data1 << 8) | uc_data2;

        if((uc_data1 >> 4) == 0x08)
        {
            Address = Address - STATUS_REG_BASE;

            for(i=0; i<16; i++)
            {
                ncSvc_JIG_StatusReg_Write(Address+i, ncSvc_JIG_Ascii_To_Hex_2byte(gRData[4+(i<<1)], gRData[5+(i<<1)]));
                uc_data3 += ncSvc_JIG_StatusReg_Read(Address+i);
            }

            isp_rw_reg[16] = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[4+(i<<1)], gRData[5+(i<<1)]);  // checksum

            if(isp_rw_reg[16] == uc_data3)
            {
                JIGMSG("#data=");

                isp_rw_reg[16] = 0;

                for(i=0; i<16; i++)
                {
                    JIGMSG("%02x", ncSvc_JIG_StatusReg_Read(Address + i));
                    isp_rw_reg[16] += ncSvc_JIG_StatusReg_Read(Address + i);
                }

                JIGMSG("%02x\r", isp_rw_reg[16]);
            }
        }
        else
        {
            for(i=0; i<16; i++)
            {
                isp_rw_reg[i] = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[4+(i<<1)], gRData[5+(i<<1)]);   // data
                uc_data3 += isp_rw_reg[i];
            }

            isp_rw_reg[16] = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[4+(i<<1)], gRData[5+(i<<1)]);  // checksum

            if(isp_rw_reg[16] == uc_data3)
            {
                if((!((uc_data1==0x00)&&(uc_data2<=0x17)))||((uc_data1==0x00)&&(uc_data2 == 0x11)))
                {
                    Address = uc_data1;
                    Address = ((Address << 8) | uc_data2);

                    for(i=0; i<16; i++)
                    {
                        REGRW8(APACHE_ISP_BASE, Address + i) = isp_rw_reg[i];
                    }
                }

                JIGMSG("#data=");
                isp_rw_reg[16] = 0;

                for(i=0; i<16; i++)
                {
                    JIGMSG("%x", isp_rw_reg[i]);
                    isp_rw_reg[16] += isp_rw_reg[i];
                }

                JIGMSG("%x\r", isp_rw_reg[16]);
            }
        }
    }
    else if(ncSvc_JIG_CmdCompare((UCHAR *) ISP_R2, 6))
    {
        UINT32 address = 0;
        UINT32 checksum = 0;
        UINT32 readData;
        UINT32 addr_remain;  // remainder;
        UINT32 size_quot;    // quotient;
        UINT32 size_remain;  // remainder;

        // address byte count
        uc_data1 = ncSvc_JIG_Ascii_To_Hex_1byte(gRData[0]);

        // data byte count
        uc_data2 = ncSvc_JIG_Ascii_To_Hex_1byte(gRData[1]);

        if(uc_data1 == JIG_ADDR_32BIT)
        {
            // address offset 0xXX00_0000
            address = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[2], gRData[3]) << 24;

            // address offset 0x00XX_0000
            address |= ncSvc_JIG_Ascii_To_Hex_2byte(gRData[4], gRData[5]) << 16;

            // address offset 0x0000_XX00
            address |= ncSvc_JIG_Ascii_To_Hex_2byte(gRData[6], gRData[7]) << 8;

            // address offset 0x0000_00XX
            address |= ncSvc_JIG_Ascii_To_Hex_2byte(gRData[8], gRData[9]);

            addr_remain = address % 4;

            size_quot = uc_data2 / 4;
            size_remain = uc_data2 % 4;

            if(size_quot == 0) size_quot = 1;
            else
            {
                if(size_remain == 0) size_quot += 1;
            }

            for(i = 0; i < size_quot; i++)
            {
                readData = REGRW32(address-addr_remain, i*4);

                for(j = 0; j < 4; j++)
                {
                    buffer[(i*4)+j] = readData>>(j*8);
                    //DEBUGMSG_SDK(MSGINFO, "buffer[%d] = 0x%02X\n", (i*4)+j, buffer[(i*4)+j]);
                }
            }

            for(i = addr_remain; i < (addr_remain+uc_data2); i++)
            {
                checksum += buffer[i];
                //DEBUGMSG_SDK(MSGINFO, "buffer[%d] = 0x%02X, checksum = 0x%02X\n", i, buffer[i], checksum);
            }
        }
        else
        {
            JIGMSG("#data=command error\n");
            DEBUGMSG_SDK(MSGERR, "Error, ISPR2? 16?32? New Jig Command Data Type %d Failure\n", uc_data1);

            return NC_FAILURE;
        }

        JIGMSG("#data=");

        for(i = addr_remain; i < (addr_remain+uc_data2); i++)
        {
            JIGMSG("%02X", buffer[i]);
        }

        JIGMSG("%02X\n", checksum & 0xFF);
    }
    else if(ncSvc_JIG_CmdCompare((UCHAR *) ISP_W2, 6))
    {
        UINT32 address = 0;
        UINT32 checksum = 0;
        UINT32 readData;
        UINT32 writeData;
        UINT32 addr_remain;  // remainder;
        UINT32 size_quot;    // quotient;
        UINT32 size_remain;  // remainder;

        // address byte count
        uc_data1 = ncSvc_JIG_Ascii_To_Hex_1byte(gRData[0]);

        // data byte count
        uc_data2 = ncSvc_JIG_Ascii_To_Hex_1byte(gRData[1]);

        if(uc_data1 == JIG_ADDR_32BIT)
        {
            // address offset 0xXX00_0000
            address = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[2], gRData[3]) << 24;

            // address offset 0x00XX_0000
            address |= ncSvc_JIG_Ascii_To_Hex_2byte(gRData[4], gRData[5]) << 16;

            // address offset 0x0000_XX00
            address |= ncSvc_JIG_Ascii_To_Hex_2byte(gRData[6], gRData[7]) << 8;

            // address offset 0x0000_00XX
            address |= ncSvc_JIG_Ascii_To_Hex_2byte(gRData[8], gRData[9]);

            for(i = 0; i < uc_data2; i++)
            {
                // write data
                buffer[i] = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[10+(i*2)], gRData[11+(i*2)]);
                checksum += buffer[i];
                //DEBUGMSG_SDK(MSGERR, "data[%d]=0x%02X\n", i, buffer[i]);
            }

            // checksum data
            buffer[i] = ncSvc_JIG_Ascii_To_Hex_2byte(gRData[10+(i*2)], gRData[11+(i*2)]);
            //DEBUGMSG_SDK(MSGERR, "pc checksum data[%d]=0x%02X\n", i, buffer[i]);
        }
        else
        {
            JIGMSG("#data=command error\n");
            DEBUGMSG_SDK(MSGERR, "Error, ISPW2= 16?32? New Jig Command Data Type %d Failure\n", uc_data1);

            return NC_FAILURE;
        }

        checksum &= 0xFF;

        if(checksum != buffer[i])
        {
            JIGMSG("#data=checksum error\n");
            DEBUGMSG_SDK(MSGERR, "Error, ISPW2= Checksum (J:0x%02X!=N:0x%02X) failure\n", checksum, buffer[i]);

            return NC_FAILURE;
        }

        addr_remain = address % 4;

        size_quot = uc_data2 / 4;
        size_remain = uc_data2 % 4;

        if(size_quot == 0) size_quot = 1;
        else
        {
            if(size_remain != 0) size_quot += 1;
        }

        for(i = 0; i < size_quot; i++)
        {
            readData = REGRW32(address-addr_remain, i*4);
            //DEBUGMSG_SDK(MSGINFO, "address = 0x%08X, rd = 0x%08X\n", (address-addr_remain)+(i*4), readData);

            for(j = 0; j < 4; j++)
            {
                RdBuffer[(i*4)+j] = readData>>(j*8);
                //DEBUGMSG_SDK(MSGINFO, "buffer[%d] = 0x%02X\n", (i*4)+j, RdBuffer[(i*4)+j]);

                WrBuffer[(i*4)+j] = RdBuffer[(i*4)+j];
            }
        }

        for(i = addr_remain; i < (addr_remain+uc_data2); i++)
        {
            if(RdBuffer[i] != buffer[(i-addr_remain)])
            {
                //DEBUGMSG_SDK(MSGINFO, "RdBuffer[%d] = 0x%02X, buffer[%d] = 0x%02X\n", i, i-addr_remain, RdBuffer[i], buffer[(i-addr_remain)]);
                WrBuffer[i] = buffer[(i-addr_remain)];
            }
            else
            {
                //DEBUGMSG_SDK(MSGINFO, "RdBuffer[%d] = 0x%02X, buffer[%d] = 0x%02X\n", i, i-addr_remain, RdBuffer[i], buffer[(i-addr_remain)]);
            }
        }

        JIGMSG("#data=");

        for(i = 0; i < size_quot; i++)
        {
            readData = 0;
            writeData = 0;

            for(j = 0; j < 4; j++)
            {
                readData = WrBuffer[(i*4)+j];
                writeData |= readData<<(j*8);
            }

            REGRW32(address-addr_remain, i*4) = writeData;

            //REGRW32(address-addr_remain, i*4) = writeData;
            //DEBUGMSG_SDK(MSGINFO, "0x%08X = 0x%08X %d %d\n", address-addr_remain+i*4, writeData, i, size_quot);
        }

        for(i = 0; i < uc_data2; i++)
        {
            JIGMSG("%02X", buffer[i]);
        }

        JIGMSG("%02X\n", checksum);
    }
    else if(ncSvc_JIG_CmdCompare(BAUDTEST, 2))
    {
        JIGMSG("#RX\r\n");
        DEBUGMSG_SDK(MSGINFO, "#RX\r\n");
    }
    else if(ncSvc_JIG_CmdCompare(VER, 3))
    {
        JIGMSG("#UART_v0.1\r\n");
        DEBUGMSG_SDK(MSGINFO, "#UART_v0.1\r\n");
    }
    else if(ncSvc_JIG_CmdCompare(FIRMWARE, 8))
    {
        JIGMSG("#Version_%s\r\n", __DATE__);
        DEBUGMSG_SDK(MSGINFO, "#Version_%s\r\n", __DATE__);
    }
    else if(ncSvc_JIG_CmdCompare(PRODUCT, 7))
    {
        JIGMSG(PRODUCT_NAME);
        DEBUGMSG_SDK(MSGINFO, PRODUCT_NAME);
    }

    return NC_SUCCESS;
}


INT32 ncSvc_JIG_CommandMain(void)
{
    INT32 Ret = NC_SUCCESS;

    if(sHalUart.Command)
    {
        if(sHalUart.RxRealBuffer[0] == '#')
        {
            Ret = ncSvc_JIG_CmdExecute();
        }

        sHalUart.Command = 0;
    }

	return Ret;
}


/* End Of File */

