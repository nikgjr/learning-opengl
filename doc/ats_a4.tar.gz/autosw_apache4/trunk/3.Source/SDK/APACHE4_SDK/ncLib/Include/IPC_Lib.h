/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __IPC_LIB_H__
#define __IPC_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* IPC GENERIC & SPECIFIC COMMANDS
*/

typedef enum _IPC_CMD
{
    /*
    * Generic Commands
    */

    GCMD_IPC_INIT = 0,
    GCMD_IPC_DEINIT,
    GCMD_IPC_GET_CNT,

    GCMD_IPC_GET_INT_STS,
    GCMD_IPC_CLR_INT_STS,
    
    GCMD_IPC_MAX,
    
} eIPC_CMD;


typedef enum _IPC_CH
{
    IPC_CH0 = 0,
    IPC_CH1,
    IPC_CH2,
    MAX_OF_IPC_CH
} eIPC_CH;


typedef enum _FIFO_ID
{
    IPC_FIFO0 = 0,
    IPC_FIFO1,
    IPC_FIFO2,
    IPC_FIFO3,
    MAX_OF_FIFO_ID
} eFIFO_ID;











/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_IPC_Open(void);
extern INT32 ncLib_IPC_Close(void);
extern INT32 ncLib_IPC_Read(eIPC_CH Ch, eFIFO_ID Id, UINT32* Data);
extern INT32 ncLib_IPC_Write(eIPC_CH Ch, eFIFO_ID Id, UINT32 Data);
extern INT32 ncLib_IPC_Control(eIPC_CMD Cmd, ...);


#endif /* __IPC_LIB_H__ */


/* End Of File */

