/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SDC_LIB_H__
#define __SDC_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* NAND GENERIC & SPECIFIC COMMANDS
*/

typedef enum _SDC_CMD
{
    /*
    * Generic Commands
    */

    GCMD_SDC_INIT = 0,
    GCMD_SDC_DEINIT,
    
    GCMD_SDC_MAX,
    
} eSDC_CMD;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_SDC_Open(void);
extern INT32 ncLib_SDC_Close(void);
extern INT32 ncLib_SDC_Read(void);
extern INT32 ncLib_SDC_Write(void);
extern INT32 ncLib_SDC_Control(eSDC_CMD Cmd, ...);


#endif /* __SDC_LIB_H__ */


/* End Of File */

