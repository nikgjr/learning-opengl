/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   : 
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __VDUMP_LIB_H__
#define __VDUMP_LIB_H__


/*
********************************************************************************
*                   INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*                   DEFINES
********************************************************************************
*/

// 5.3MP
#define VDUMP_MAX_H_SIZE        3072
#define VDUMP_MAX_V_SIZE        1728

// QCIF
#define VDUMP_MIN_H_SIZE        176
#define VDUMP_MIN_V_SIZE        144










/*
********************************************************************************
*                   ENUMERATION
********************************************************************************
*/

/*
* VDUMP GENERIC & SPECIFIC COMMANDS
*/

typedef enum _VDP_CMD
{
    /*
    * Generic Commands
    */

    GCMD_VDP_INIT = 0,
    GCMD_VDP_DEINIT,

    GCMD_VDP_UPDATE_OP,

    GCMD_VDP_START,
    GCMD_VDP_STOP,
    GCMD_VDP_DONE,

    // Only Interrupt Mode (Intc Status Get and Clear)
    GCMD_VDP_INT_CLEAR,
    GCMD_VDP_GET_STS,

    // Get V-Dump Status
    GCMD_VDP_GET_INPUT_SIZE,
    GCMD_VDP_GET_OUTPUT_SIZE,
    GCMD_VDP_GET_DUMP_SIZE,
    GCMD_VDP_GET_CROP_CNT,
    GCMD_VDP_GET_SCAL_CNT,    
    GCMD_VDP_GET_FRM_STS,
    GCMD_VDP_GET_LINE_CNT,
    GCMD_VDP_GET_PIXEL_CNT,
    GCMD_VDP_CHK_ERROR,

    GCMD_VDP_MAX,

} eVDP_CMD;


typedef enum
{
    VDP_CH0 = 0,
    VDP_CH1,
    VDP_CH2,
    MAX_OF_VDP_CH
} eVDP_CH;


typedef enum
{
    VDP_I_YC_CROP_OUT_PATH = 0,
    VDP_I_LDC_OUT_PATH,
    VDP_I_OPD_OUT_PATH,
    VDP_I_OVERLAY_OUT_PATH,
    MAX_OF_VDP_INPUT_PATH
} eVDP_INPUT_PATH;


typedef enum
{
    VDP_I_YUV_FORMAT = 0,
    VDP_I_RGB_FORMAT,
    MAX_OF_VDP_INPUT_FORMAT
} eVDP_INPUT_FORMAT;


typedef enum
{
    VDP_YUV444 = 0,
    VDP_YUV422,
    MAX_OF_VDP_VUV_FORMAT
} eVDP_YUV_FORMAT;


typedef enum
{
    VDP_P_YCBCR_RGB = 0,
    VDP_P_YCRCB_RBG,
    VDP_P_CBYCR_GRB,
    VDP_P_CRYCB_BRG,
    VDP_P_CBCRY_GBR,
    VDP_P_CRCBY_BGR,
    MAX_OF_VDP_PARSING
} eVDP_PARSING;


typedef enum
{
    VDP_STS_CH0_END        = 0x00000001,
    VDP_STS_CH0_START      = 0x00000002, 
    VDP_STS_CH0_BUFF_OVER  = 0x00000004,
    VDP_STS_CH0_TIME_OVER  = 0x00000008,     
    VDP_STS_CH1_END        = 0x00000100,
    VDP_STS_CH1_START      = 0x00000200,
    VDP_STS_CH1_BUFF_OVER  = 0x00000400,
    VDP_STS_CH1_TIME_OVER  = 0x00000800, 
    VDP_STS_CH2_END        = 0x00010000,
    VDP_STS_CH2_START      = 0x00020000,
    VDP_STS_CH2_BUFF_OVER  = 0x00040000,
    VDP_STS_CH2_TIME_OVER  = 0x00080000,     
    VDP_STS_ERR_ALL        = 0x000C0C0C,    
    VDP_STS_I_VSYNC_END    = 0x01000000,
    VDP_STS_I_VSYNC_START  = 0x02000000,
    MAX_OF_VDP_STS
} eVDP_STS;


typedef enum
{
    VDP_SEL_FRAME_START = 0,
    VDP_SEL_FRAME_END,
    MAX_OF_VDP_UPDATE_SEL
} eVDP_UPDATA_SEL;

typedef enum
{
    VDP_FRAME_SENSING_FRAME = 0,    
    VDP_FRAME_VIEWING_FRAME,
    MAX_OF_VDP_FRAME_MODE
} eVDP_FRAME_MODE;


typedef enum
{
    VDP_ENDIAN_LITTLE = 0,
    VDP_ENDIAN_BIG,
    MAX_OF_VDP_ENDIAN
} eVDP_ENDIAN;


typedef enum
{
    VDP_BIT_8 = 0,
    VDP_BIT_16,
    VDP_BIT_32,
    MAX_OF_VDP_DATA_BIT
} eVDP_DATA_BIT;


typedef enum
{
    VDP_BURST_1 = 0,
    VDP_BURST_2,
    VDP_BURST_4,
    VDP_BURST_6_RESERVED,
    VDP_BURST_8,
    VDP_BURST_16,
    VDP_BURST_32,
    MAX_OF_VDP_WRITE_BURST
} eVDP_WRITE_BURST;


typedef enum
{
    VDP_DBG_STT_IDLE = 0,
    VDP_DBG_STT_ONE_FRM,
    VDP_DBG_STT_WRITE_MODE,
    VDP_DBG_STT_HSYNC_MASK,
    VDP_DBG_STT_WAIT,
    MAX_OF_VDP_DBG_STATUS
} eVDP_DBG_STATUS;


typedef enum
{
    VDP_ERR_DMA_BUFF_OVER  = 0x01,
    VDP_ERR_DUMP_TIME_OVER = 0x02,
    VDP_ERR_H_OUT_ERROR    = 0x04,
    VDP_ERR_V_OUT_ERROR    = 0x08,
    MAX_OF_VDP_ERROR_STATUS
} eVDP_ERROR_STATUS;










/*
********************************************************************************
*                   TYPEDEFS
********************************************************************************
*/

typedef struct
{
    BOOL                mChEnable;    
    eVDP_ENDIAN         mEndian;
    eVDP_PARSING        mParsing;
    eVDP_DATA_BIT       mBit;
    eVDP_WRITE_BURST    mBurst;

    UINT32              mDumpAddr;
} tVDP_CH_INFO, *ptVDP_CH_INFO;


// Input -> Crop -> Scaler Flow 
typedef struct
{    
    BOOL                mCropEn;        
    INT32               mCropStartH;    // Crop Start Horizontal Position
    INT32               mCropEndH;      // Crop End Horizontal Position
    INT32               mCropStartV;    // Crop Start Vertical Position
    INT32               mCropEndV;      // Crop End Vertical Position
    
    BOOL                mScalEn;        
    INT32               mScalOutputH;   // Scaler Output Horizontal Length
    INT32               mScalOutputV;   // Scaler Output Vertical Length    

    BOOL                mIntEn;         // Interrupt Enable or Disable
    eVDP_UPDATA_SEL     mFrameEdge;     // Start, End Select
    eVDP_INPUT_PATH     mInputPath;     // Input Path Select
    eVDP_INPUT_FORMAT   mInFormat;      // YUV, RGB Format Select
    eVDP_YUV_FORMAT     mYUVSelect;     // YUV444, YUV422 Format Select
    eVDP_FRAME_MODE     mFrameType;     // Viewing, Sensing Select
    
    tVDP_CH_INFO        mDumpCh[MAX_OF_VDP_CH];
} tVDP_PARAM, *ptVDP_PARAM;










/*
********************************************************************************
*                   FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncLib_VDP_Open(void);
extern INT32 ncLib_VDP_Close(void);

extern INT32 ncLib_VDP_Read(void);
extern INT32 ncLib_VDP_Write(void);

extern INT32 ncLib_VDP_Control(eVDP_CMD Cmd, ...);


#endif /* __VDP_LIB_H__ */


/* End Of File */

