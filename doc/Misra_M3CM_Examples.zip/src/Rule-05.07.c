/* >>>------------------------------------------------------------
 * 
 * File: Rule-05.07.c,  Module: M3CM-1.0.3-QAC-8.2.2
 * 
 * RULE Rule-5.7 (Required):
 * A tag name shall be a unique identifier
 * 
 * Not enforced
 * 
 * <<<------------------------------------------------------------ */



#include "misra.h"
#include "m3cmex.h"

extern int16_t rule_0507( void )
{
   return 0;
}
