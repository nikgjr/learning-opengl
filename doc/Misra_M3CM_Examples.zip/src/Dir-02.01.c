/* >>>------------------------------------------------------------
 * 
 * File: Dir-02.01.c,  Module: M3CM-1.0.3-QAC-8.2.2
 * 
 * RULE Dir-2.1 (Required):
 * All source files shall compile without any compilation errors
 * 
 * Not enforced
 * 
 * <<<------------------------------------------------------------ */



#include "misra.h"
#include "m3cmex.h"

extern int16_t dir_0201( void )
{
   return 1;
}
