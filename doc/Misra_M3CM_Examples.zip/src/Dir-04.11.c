/* >>>------------------------------------------------------------
 * 
 * File: Dir-04.11.c,  Module: M3CM-1.0.3-QAC-8.2.2
 * 
 * RULE Dir-4.11 (Required):
 * The validity of values passed to library functions shall be
 * checked
 * 
 * Not enforced
 * 
 * <<<------------------------------------------------------------ */



#include "misra.h"
#include "m3cmex.h"

extern int16_t dir_0411( void )
{
   return 1;
}
