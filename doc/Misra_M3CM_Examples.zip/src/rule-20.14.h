/* >>>------------------------------------------------------------
 *
 * File: rule-20.14.h.h,  Module: M3CM-1.0.3-QAC-8.2.2
 *
 * <<<------------------------------------------------------------ */

/* Following #endif matches #if in parent file */

#endif                                                  /* 3318 */

/* Following #if is not matched in this file */

#if 1                                                   /* 3317 */
