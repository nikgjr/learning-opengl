/* >>>------------------------------------------------------------
 * 
 * File: Dir-03.01.c,  Module: M3CM-1.0.3-QAC-8.2.2
 * 
 * RULE Dir-3.1 (Required):
 * All code shall be traceable to documented requirements
 * 
 * Not enforced
 * 
 * <<<------------------------------------------------------------ */




#include "misra.h"
#include "m3cmex.h"

extern int16_t dir_0301( void )
{
   return 1;
}
