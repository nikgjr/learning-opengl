#include "test.h"

int32* test_main()
{
	uint8 i;
	int32 arr[10];
	
	for( i = 0 ; i < 300 ; i++)
	{
		arr[i] = i * 10;
	}
	return arr;
}

__asm int test()
{
	mov r1,r2;
}

inline int test2()
{
	long long value;
	value=1000;
	return value;
}

interrupt 2 int test3()
{
	return 0;
}


