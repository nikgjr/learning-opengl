#ifndef TYPE_H
#define TYPE_H

#if _CPU_==_HC12_
typedef signed long int32;
typedef unsigned long uint32;
typedef signed char int8;
typedef unsigned char uint8;
typedef signed short int16;
typedef unsigned short uint16;
#endif

#endif /* TYPE_H */