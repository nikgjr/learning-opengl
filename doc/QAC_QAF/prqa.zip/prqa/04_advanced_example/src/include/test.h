#ifndef TEST_H
#define TEST_H

#ifdef _CPU_
#include <type.h>
#else
#error _CPU_ Macro is not defined
#endif /* _CPU */



#endif /* TEST_H */