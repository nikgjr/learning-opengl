#pragma PRQA_MESSAGES_OFF 3602,3625
#ifndef _STRING_H
#define _STRING_H
#ifndef _SIZE_T
#define _SIZE_T
typedef PRQA_SIZE_T size_t;
#endif

#ifndef NULL
#define NULL    ((void *) 0)
#endif

extern void    *memcpy(void *s1,const void *s2,size_t n),
               *memmove(void *s1,const void *s2,size_t n),
               *memchr(const void *s, int c, size_t n),
               *memset(void *s, int c, size_t n);
extern char    *strcpy(char *s1, const char *s2),
               *strncpy(char *s1, const char *s2, size_t n),
               *strcat(char *s1, const char *s2),
               *strncat(char *s1, const char *s2, size_t n),
               *strchr(const char *s, int c),
               *strpbrk(const char *s1, const char *s2),
               *strrchr(const char *s, int c),
               *strstr(const char *s1, const char *s2),
               *strtok(char *s1, const char *s2),
               *strerror(int errnum);
extern int      memcmp(const void *s1,const void *s2, size_t n),
                strcmp(const char *s1,const char *s2),
                strcoll(const char *s1,const char *s2),
                strncmp(const char *s1,const char *s2,size_t n);
extern size_t   strxfrm(char *s1,const char *s2,size_t n),
                strcspn(const char *s1,const char *s2),
                strspn(const char *s1, const char *s2),
                strlen(const char *s);

#endif
