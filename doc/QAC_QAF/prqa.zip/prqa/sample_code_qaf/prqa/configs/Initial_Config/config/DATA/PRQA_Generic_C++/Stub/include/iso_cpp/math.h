/* math.h		lastmod 19 Nov 91  SAC
 *			created  8 Jun 89  SAC
 * version:	@(#)math.h	1.3
 * date:		95/03/02
 */
#ifndef _MATH_H
#define _MATH_H
#define HUGE_VAL	9.99999e307
extern
double acos(double)
     , asin(double)
     , atan(double)
     , atan2(double, double)
     , cos(double)
     , sin(double)
     , tan(double)
     , cosh(double)
     , sinh(double)
     , tanh(double)
     , exp(double)
     , frexp(double, int *)
     , ldexp(double, int)
     , log(double)
     , log10(double)
     , modf(double, double *)
     , pow(double, double)
     , sqrt(double)
     , ceil(double)
     , fabs(double)
     , floor(double)
     , fmod(double, double);
#endif
