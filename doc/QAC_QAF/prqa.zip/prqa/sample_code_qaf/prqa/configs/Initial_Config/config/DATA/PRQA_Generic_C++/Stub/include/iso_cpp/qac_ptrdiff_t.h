// qac_ptrdiff_t.h
//

#ifndef INCLUDED_QAC_PTRDIFF_T_H
#define INCLUDED_QAC_PTRDIFF_T_H


#if !defined(_PTRDIFF_T) && defined(PRQA_PTRDIFF_T)
#define _PTRDIFF_T
typedef PRQA_PTRDIFF_T ptrdiff_t;
#endif

#endif
