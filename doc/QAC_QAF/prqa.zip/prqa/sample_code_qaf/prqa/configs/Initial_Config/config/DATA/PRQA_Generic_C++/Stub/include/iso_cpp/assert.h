/* assert.h
 * $Id: assert.h,v 1.9 2007/06/29 10:13:14 richard Exp $
 */

#ifdef assert
#undef assert
#endif

#ifdef NDEBUG
#define assert(ignore) ((void)0)
#else
#define assert(expr) __assert(expr,#expr,__FILE__,__LINE__)
extern void __assert(bool,char const*,char const*,int);
#endif
