#pragma PRQA_MESSAGES_OFF 336,1307,3602,3625
#ifndef included_STDIO_H
#define included_STDIO_H
#ifndef NULL
#define NULL            ((void *) 0)
#endif

#ifndef _SIZE_T
#define _SIZE_T
typedef PRQA_SIZE_T size_t;
#endif

#define _IOFBF          0000
#define _IONBF          0004
#define _IOLBF          0200
#define BUFSIZ          1024
#define EOF             (-1)
#define FOPEN_MAX       8
#define FILENAME_MAX    76
#define L_tmpnam        12
#define SEEK_SET        0
#define SEEK_CUR        1
#define SEEK_END        2
#define TMP_MAX         25
typedef unsigned long   fpos_t;

/*
 * For some reason, Sun use a define instead of a typedef to define FILE
 */
#ifdef  sun
struct _iobuf { unsigned __the_contents_of_FILE_are_not_defined; };
#define FILE  struct _iobuf
#else
typedef struct { unsigned __the_contents_of_FILE_are_not_defined; } FILE;
#endif

extern FILE *stderr, *stdin, *stdout;

#ifndef _VA_LIST
#define _VA_LIST
typedef void * va_list;
#endif

extern int      remove(const char * filename),
                rename(const char * old, const char * n),
                fclose(FILE *stream),
                fflush(FILE *stream),
                setvbuf(FILE *stream, char *buf, int mode, size_t size),
                fprintf(FILE *stream, const char *format, ...),
                fscanf(FILE *stream, const char *format, ...),
                printf(const char *format, ...),
                scanf(const char *format, ...),
                sprintf(char *s, const char *format, ...),
                sscanf(const char *s, const char *format, ...),
                vfprintf(FILE *stream, const char *format, va_list arg),
                vprintf(const char *format, va_list arg),
                vsprintf(char *s, const char *format, va_list arg),
                fgetc(FILE *stream),
                fputc(int c, FILE *stream),
                fputs(const char *s, FILE *stream),
                getc(FILE *stream),
                getchar(void),
                putc(int c, FILE *stream),
                putchar(int c),
                puts(const char *s),
                ungetc(int c, FILE *stream),
                fgetpos(FILE *stream, fpos_t *pos),
                fseek(FILE *stream, long int offset, int whence),
                fsetpos(FILE *stream, const fpos_t *pos),
                feof(FILE *stream),
                ferror(FILE *stream);
extern FILE     *tmpfile(void),
                *fopen(const char *filename, const char *mode),
                *freopen(const char *filename, const char *mode, FILE *stream);
extern char     *tmpnam(char *s),
                *fgets(char *s, int n, FILE *stream),
                *gets(char *s);
extern size_t   fread(void *ptr, size_t size, size_t nmemb, FILE *stream),
                fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream);
extern long     ftell(FILE *stream);
extern void     setbuf(FILE *stream, char *buf),
                rewind(FILE *stream),
                clearerr(FILE *stream),
                perror(const char *s);

#endif
