// qac_size_t.h
//

#ifndef INCLUDED_QAC_SIZE_T_H
#define INCLUDED_QAC_SIZE_T_H

#ifndef _SIZE_T
#define _SIZE_T
typedef PRQA_SIZE_T size_t;
#endif

#endif
