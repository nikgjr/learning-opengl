#ifndef _MATH_H
#define _MATH_H

#define HUGE_VAL  9.99999e307

extern double   acos(double x),
                asin(double x),
                atan(double x),
                atan2(double y, double x),
                cos(double x),
                sin(double x),
                tan(double x),
                cosh(double x),
                sinh(double x),
                tanh(double x),
                exp(double x),
                frexp(double value, int *exp),
                ldexp(double x, int exp),
                log(double x),
                log10(double x),
                modf(double value, double *iptr),
                pow(double x, double y),
                sqrt(double x),
                ceil(double x),
                fabs(double x),
                floor(double x),
                fmod(double x, double y);

#endif
