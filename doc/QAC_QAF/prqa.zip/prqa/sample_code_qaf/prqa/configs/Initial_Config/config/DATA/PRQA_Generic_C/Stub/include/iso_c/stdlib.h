#pragma PRQA_MESSAGES_OFF 1307,1336,3602,3625,3672
#ifndef _STDLIB_H
#define _STDLIB_H
#ifndef _SIZE_T
#define _SIZE_T
typedef PRQA_SIZE_T size_t;
#endif

#ifndef _WCHAR_T
#define _WCHAR_T
typedef PRQA_WCHAR_T wchar_t;
#endif

#ifndef NULL
#define NULL    ((void *) 0)
#endif

typedef struct { unsigned _undefined_div; } div_t;
typedef struct { unsigned _undefined_ldiv; } ldiv_t;
#define EXIT_FAILURE  1
#define EXIT_SUCCESS  0
#define RAND_MAX      32767
#define MB_CUR_MAX    1
extern double   atof(const char *nptr),
                strtod(const char *nptr, char **endptr);
extern long     atol(const char *nptr),
                strtol(const char *nptr, char **endptr, int base),
                labs(long j);
extern unsigned long    strtoul(const char *nptr, char **endptr, int base);
extern int      atoi(const char *nptr),
                rand(void),
                atexit(void (*func)(void)),
                system(const char *string),
                abs(int j),
                mblen(const char *s, size_t n),
                mbtowc(wchar_t *pwc, const char *s, size_t n),
                wctomb(char *s, wchar_t wchar);
extern void     srand(unsigned int seed),
               *calloc(size_t nmemb, size_t size),
                free(void *ptr),
               *malloc(size_t size),
               *realloc(void *ptr, size_t size),
                abort(void),
                exit(int status),
               *bsearch(const void *key,const void *base,size_t nmemb,size_t size,int(*compar)(const void *,const void *)),
                qsort(void *base,size_t nmemb,size_t size,int(*compar)(const void *,const void *));
extern char    *getenv(const char *name);
extern div_t    div(int numer, int denom);
extern ldiv_t   ldiv(long numer, long denom);
extern size_t   mbstowcs(wchar_t *pwcs,const char *s,size_t n),
                wcstombs(char *s,const wchar_t *pwcs, size_t n);

#endif
