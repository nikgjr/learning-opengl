#ifndef _CTYPE_H
#define _CTYPE_H

int     isalnum(int c),
        isalpha(int c),
        iscntrl(int c),
        isdigit(int c),
        isgraph(int c),
        islower(int c),
        isprint(int c),
        ispunct(int c),
        isspace(int c),
        isupper(int c),
        isxdigit(int c),
        tolower(int c),
        toupper(int c);

#endif
