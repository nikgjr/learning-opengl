#ifndef LG_CDMA
  #ERROR "Please check define option!!"
#endif

#ifdef ARM
  struct f{
    int a;
    int b;
  };
#endif

#ifndef LG_GSM
  #ERROR "Please check define option!!"
#endif


