#include <stdio.h>
#include "my_stdio.h"

struct f y;

int test(int i){

  return (i%10);
}

int arr[10];

void main(void)
{
  int x,i;
  long rt,time;

  x = test(20);
  rt = x%255 + time;
  
  for(i=0;i<=10;i++){
    arr[i] = rt%32;
  }
}
