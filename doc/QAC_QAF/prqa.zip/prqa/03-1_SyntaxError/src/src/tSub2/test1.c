#include "my_stdio2.h"

int win32_test1(int i){
  int j,k;
  k=0;
  
  j = k + i;
  
  return j;
}


int main(){
  int test;
  
  test = win32_test1(10);

  return 0;
}
