unsigned short align(4) p;

int ignore_test1(int i){
  int j,k;
  
  k=0;
  
  j = k + i;
  
  return j;
}

int ignore_test2(int i) interrupt my_number{
  int far j,k;
  
  k=0;	
  
  j = k + i;
  
  return j;
}
