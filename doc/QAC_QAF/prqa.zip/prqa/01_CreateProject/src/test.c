#include <stdio.h>

int main(){
	int i = 10;
	int j;
	int k[10];

  printf("hello QAC!!\n");
	j = i * 10;
	
	k[10] = 10;
	
  return 0;
}

