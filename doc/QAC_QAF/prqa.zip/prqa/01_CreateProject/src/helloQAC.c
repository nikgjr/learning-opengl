#include <stdio.h>

int main(){
	int i = 10;
	int j;

  printf("hello QAC!!\n");
	j = i * 10;
  return 0;
}

