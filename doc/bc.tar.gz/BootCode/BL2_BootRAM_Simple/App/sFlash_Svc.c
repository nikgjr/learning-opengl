/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : sFlash_Svc.c
*
*  @brief   : This file is sFlash controller API for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.11.19
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define PAGE_SIZE								256

#define CMD_sFlash_WR_EN						0x06
#define CMD_sFlash_WR_DS						0x04
#define CMD_sFlash_RD_STS						0x05
#define CMD_sFlash_RD_STS2						0x35		// for WINBOND SPI Flash
#define CMD_sFlash_WR_STS						0x01
#define CMD_sFlash_RD_DATA						0x03
#define CMD_sFlash_PAGE_PROGRAM					0x02
#define CMD_sFlash_SECTOR_ERASE					0x20
#define CMD_sFlash_BLOCK_ERASE					0xD8
#define CMD_sFlash_RD_IDENTIFICATION			0x9F

#define CMD_sFlash_QUAD_ENABLE					0x35		// for MXIC SPI Flash
#define CMD_sFlash_QUAD_FAST_READ				0xEB

#define STS_WIP									(0x1<<0)
#define STS_WEL									(0x1<<1)

#define FLASH_ID_WINBOND						(0xEF)
#define FLASH_ID_EON							(0x1C)
#define FLASH_ID_MXIC							(0xC2)
#define FLASH_ID_MICRON							(0x20)
#define FLASH_ID_SPANSION						(0xEF)

#define FLASH_SECTOR_SIZE						(0x1000)
#define FLASH_BLOCK_SIZE						(0x10000)

//#define BP0     (1<<2)
//#define BP1     (1<<3)
//#define BP2     (1<<4)
//#define BP3     (1<<5)

/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

BOOL ncDrv_QSPI_WaitBusIsBusy(UINT32 TimeOut)
{
    BOOL Ret = FALSE;
    UINT32 Status;
    UINT32 Count;

    for(Count=0; Count<TimeOut; Count++)
    {
        Status = APACHE_READ(APACHE_QSPI_BASE+0x18);

        if(!(Status&(1<<16)))
        {
            Ret = TRUE;
            break;
        }
    }

    return Ret;
}


BOOL ncDrv_QSPI_WaitFrameDone(UINT32 TimeOut)
{
    BOOL Ret = FALSE;
    UINT32 Status;
    UINT32 Count;

    for(Count=0; Count<TimeOut; Count++)
    {
        Status = APACHE_READ(APACHE_QSPI_BASE+0x18);

        if((Status&(1<<22)))
        {
            Ret = TRUE;
            break;
        }
    }

    return Ret;
}


INT32 ncDrv_QSPI_ReadData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    //APACHE_WRITE(APACHE_QSPI_BASE+0x00, 0x00510DEB); // quad-spi clock bit[11:8], D : 1/3 49.5MHz
    APACHE_WRITE(APACHE_QSPI_BASE+0x00, 0x00510EEB); // quad-spi clock bit[11:8], E : 1/2 74.25MHz
    APACHE_WRITE(APACHE_QSPI_BASE+0x18, 0x00000000);

    APACHE_WRITE(APACHE_QSPI_BASE+0x10, (UINT32 )pData);
    APACHE_WRITE(APACHE_QSPI_BASE+0x14, 0x000000B0);

    APACHE_WRITE(APACHE_QSPI_BASE+0x04, Addr + Size);
    APACHE_WRITE(APACHE_QSPI_BASE+0x08, 0x00FF0000);
    APACHE_WRITE(APACHE_QSPI_BASE+0x0C, Addr);

    if(!ncDrv_QSPI_WaitBusIsBusy(0x1000000))
    {

    }	

    if(!ncDrv_QSPI_WaitFrameDone(0x1000000))
    {

    }	

    return NC_SUCCESS;
}

INT32 ncSvc_SF_Init(void)
{
    tSFLASH_ID tsFlashID;
    UINT8 Status1;
    UINT8 Status2;

    ncDrv_SSP_Init();

    ncSvc_SF_ReadDeviceIdentification(&tsFlashID);

    if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
    {
        Status1 = ncSvc_SF_ReadStatus();
        Status2 = ncSvc_SF_ReadStatus2();

        if( !(Status2 & 0x2) )
        {
            ncSvc_SF_WriteStatus2(Status1, Status2|0x2);
        }
    }
    else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
    {
        Status1 = ncSvc_SF_ReadStatus();
        if( !(Status1 & (1<<6)) )
        {
            ncSvc_SF_WriteStatus(Status1|(1<<6));
        }
    }

    return NC_SUCCESS;
}


INT32 ncSvc_SF_Release(void)
{
    INT32 ret;

    /*
    * Deinit SSP Channel
    */

    ret = ncDrv_SSP_DeInit();

    return ret;
}


void ncSvc_SF_WaitWIP(void)
{
    while(ncSvc_SF_ReadStatus() & STS_WIP) ;
}


void ncSvc_SF_WriteEnable(void)
{
    UINT8 Command;

    // GCMD_SSP_CS_ENABLE_CH	
    ncDrv_SSP_ClearRxFIFO();
    ncDrv_SSP_WaitBusIsBusy(1000);
    __BL2_SSP_CS_Low(gFlashCS);


    Command = CMD_sFlash_WR_EN;
    ncDrv_SSP_Write(&Command, 1);	

    // GCMD_SSP_CS_DISABLE_CH
    __BL2_SSP_CS_High(gFlashCS);

    while( (ncSvc_SF_ReadStatus() & STS_WEL) != STS_WEL  ) ;
}


void ncSvc_SF_WriteDisable(void)
{
    UINT8 Command;

    while( ncSvc_SF_ReadStatus() & STS_WIP  ) ;

    // GCMD_SSP_CS_ENABLE_CH	
    ncDrv_SSP_ClearRxFIFO();
    ncDrv_SSP_WaitBusIsBusy(1000);
    __BL2_SSP_CS_Low(gFlashCS);


    Command = CMD_sFlash_WR_DS;
    ncDrv_SSP_Write(&Command, 1);	

    // GCMD_SSP_CS_DISABLE_CH
    __BL2_SSP_CS_High(gFlashCS);
}


UINT8 ncSvc_SF_ReadStatus(void)
{
    UINT8 Command;
    UINT8 Status;

    // GCMD_SSP_CS_ENABLE_CH	
    ncDrv_SSP_ClearRxFIFO();
    ncDrv_SSP_WaitBusIsBusy(1000);
    __BL2_SSP_CS_Low(gFlashCS);


    Command = CMD_sFlash_RD_STS;
    ncDrv_SSP_Write(&Command, 1);	
    ncDrv_SSP_Read(&Status, 1);	

    // GCMD_SSP_CS_DISABLE_CH
    __BL2_SSP_CS_High(gFlashCS);

    return Status;
}


UINT8 ncSvc_SF_ReadStatus2(void)
{
    UINT8 Command;
    UINT8 Status;

    // GCMD_SSP_CS_ENABLE_CH	
    ncDrv_SSP_ClearRxFIFO();
    ncDrv_SSP_WaitBusIsBusy(1000);
    __BL2_SSP_CS_Low(gFlashCS);


    Command = CMD_sFlash_RD_STS2;
    ncDrv_SSP_Write(&Command, 1);	
    ncDrv_SSP_Read(&Status, 1);	

    // GCMD_SSP_CS_DISABLE_CH
    __BL2_SSP_CS_High(gFlashCS);	

    return Status;
}


void ncSvc_SF_WriteStatus(UINT8 Status)
{
    UINT8 Command[2];

    ncSvc_SF_WriteEnable();

    // GCMD_SSP_CS_ENABLE_CH	
    ncDrv_SSP_ClearRxFIFO();
    ncDrv_SSP_WaitBusIsBusy(1000);
    __BL2_SSP_CS_Low(gFlashCS);


    Command[0] = CMD_sFlash_WR_STS;
    Command[1] = Status;
    ncDrv_SSP_Write(Command, 2);

    // GCMD_SSP_CS_DISABLE_CH
    __BL2_SSP_CS_High(gFlashCS);

    ncSvc_SF_WriteDisable();
}


void ncSvc_SF_WriteStatus2(UINT8 Status1, UINT8 Status2)
{
    UINT8 Command[3];

    ncSvc_SF_WriteEnable();

    // GCMD_SSP_CS_ENABLE_CH	
    ncDrv_SSP_ClearRxFIFO();
    ncDrv_SSP_WaitBusIsBusy(1000);
    __BL2_SSP_CS_Low(gFlashCS);


    Command[0] = CMD_sFlash_WR_STS;
    Command[1] = Status1;
    Command[2] = Status2;	
    ncDrv_SSP_Write(Command, 3);

    // GCMD_SSP_CS_DISABLE_CH
    __BL2_SSP_CS_High(gFlashCS);	

    ncSvc_SF_WriteDisable();
}


INT32 ncSvc_SF_ReadDeviceIdentification(ptSFLASH_ID ptsFlashID)
{
    UINT8 Command;

    // GCMD_SSP_CS_ENABLE_CH	
    ncDrv_SSP_ClearRxFIFO();
    ncDrv_SSP_WaitBusIsBusy(1000);
    __BL2_SSP_CS_Low(gFlashCS);


    Command = CMD_sFlash_RD_IDENTIFICATION;
    ncDrv_SSP_Write(&Command, 1);	
    ncDrv_SSP_Read((UINT8*)ptsFlashID, 3);		

    // GCMD_SSP_CS_DISABLE_CH
    __BL2_SSP_CS_High(gFlashCS);

    return NC_SUCCESS;
}


/* End Of File */
