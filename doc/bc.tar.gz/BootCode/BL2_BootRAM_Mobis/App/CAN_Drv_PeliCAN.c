/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : CAN_Drv_PeliCAN.c
*
*  @brief   : Apache3 CAN2.0B module driver source file
*
*  @author  : alessio / TS Group / SoC SW Team
*
*  @date    : 2016.02.16
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*           INCLUDE
********************************************************************************
*/

#include "Main.h"


#if BL2_CAN_MODE_ENABLE

#include "CAN_Drv.h"
#include "CAN_Drv_PeliCAN.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncDrv_PeliCAN_Init(UINT32 inputclk, tCAN_PARAM *config)
{
    INT32 Result = NC_SUCCESS;
    UINT32 reg= 0;
    UINT32 btr0, btr1;

    //DEBUGMSG("CAN2.0B PeliCAN mode, %s %s setup\n", config->info.format == 0 ? "Standard" : "Extended", "format");

    // Switch-on reset mode
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_MOD) = (CANP_MOD_RM);

    // Set the periCAN mode and clock divider
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_CDR) = (CAN_CDR_PELI_MODE << CANP_CDR_MODE_SHIFT);
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_CDR) |= CANP_CDR_CLKOFF;

    // Set Mode Register
    reg = CANP_MOD_RM;
    if(config->filter == CAN_SINGLE_FILTER)
        reg |= CANP_MOD_AFM;

    if(config->mode == CAN_CDR_PELI_SELF_TEST_MODE)
        reg |= CANP_MOD_STM;
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_MOD) = reg;

    // Set command register to zero 
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_CMR) = 0;

    // Set the error warning limit to 96
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EWLR) = 0x60;

    // Disable all interrupts
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_IER) = 0;

    // Setting the bus timing
    //ncDrv_CAN_SetBusTimingBaudrate(inputclk, config->baudrate);
    ncDrv_CAN_CalculateBitTiming(inputclk, config->baudrate, &btr0, &btr1);
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_BTR0) = btr0;
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_BTR1) = btr1;

    // Set all acceptance code registers to 0xFF. Received messages must have these bits set
    ncDrv_PeliCAN_SetAcceptanceFilter(config->acrId, config->amrId);

    // Reset receive error counter
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_RXERR) = 0;

    // Reset transmit error counter 
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_TXERR) = 0;

    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_IER) =  CANP_IER_RIE;

    // Switch-off reset mode
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_MOD) &= ~CANP_MOD_RM;

    return Result;
}


void ncDrv_PeliCAN_DeInit(void)
{
    REGRW32(ncDrv_CAN_BaseAddr(), 0x10) = 0x00;  // Interrupt Enable All Disable
    REGRW32(ncDrv_CAN_BaseAddr(), 0x04) = 0x0C;  // Command Clear Data Overrun, Release Receive Buffer
    REGRW32(ncDrv_CAN_BaseAddr(), 0x00) = 0x01;  // Mode Reset
}


INT32 ncDrv_PeliCAN_Send(tCAN_MSG *txmsg)
{
    INT32 i;
    INT32 Result = NC_SUCCESS;

    //DEBUGMSG("CAN2.0B PeliCAN %s tx send\n", "Operation");

    if(txmsg->format == CAN_FI_EXTENDED_FORMAT)
    {
        // Tx frame information
        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_FI) = (txmsg->format<<7) | (txmsg->rtr<<6) | (txmsg->length&0x0F);

        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_ID1) = (txmsg->id>>21) & 0xFF; // ID.[28-21];
        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_ID2) = (txmsg->id>>13) & 0xFF; // ID.[20-13]
        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_ID3) = (txmsg->id>>5)  & 0xFF; // ID.[12-5]
        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_ID4) = (txmsg->id<<3)  & 0xF8; // ID.[4-0] last 3bits are don care.

        // Tx n bytes
        for(i = 0; i < txmsg->length; i++)
        {
            REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_DATA1 + (i*4)) = txmsg->data[i];
        }
    }
    else
    {
        // Tx frame information
        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_SFF_FI) = (txmsg->format<<7) | (txmsg->rtr<<6) | (txmsg->length&0x0F);

        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_SFF_ID1) = (txmsg->id>>3) & 0xFF; // ID.[28-21]
        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_SFF_ID2) = (txmsg->id<<5) & 0xE0; // ID.[20-13]

        // Tx n bytes
        for(i = 0; i < txmsg->length; i++)
        {
            REGRW32(ncDrv_CAN_BaseAddr(), rCANP_SFF_DATA1 + (i*4)) = txmsg->data[i];
        }
    }

    /*
     * Transmission request
     */
    if(REGRW32(ncDrv_CAN_BaseAddr(), rCANP_MOD) & CANP_MOD_STM)
    {
        //SelfTest Mode
        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_CMR) = CANP_CMR_SRR;
    }
    else
    {
        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_CMR) = CANP_CMR_TR;
    }

    Result = ncDrv_PeliCAN_SendComplete();
    if(Result == NC_FAILURE)
    {
        //DEBUGMSG("Error, PeliCAN Send Status 0x%02X\n", REGRW32(ncDrv_CAN_BaseAddr(), rCANP_SR));
    }

    return Result;
}


INT32 ncDrv_PeliCAN_SendComplete(void)
{
    UINT32 wait = 0;
    UINT32 status;
    INT32 Result = NC_SUCCESS;

    while(1)
    {
        wait++;
        status = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_SR);

        if(wait > 100000) // Approximately, Should be successful in 5ms
        {
            //DEBUGMSG("Error, Send Timeout 0x%02X\n", status);
            Result = NC_FAILURE;
            break;
        }

        if(status & CANP_SR_BS)  // bus off error
        {
            //DEBUGMSG("Error, Send Bus off 0x%02X\n", status);
            Result = NC_FAILURE;
            break;
        }

        if(status & CANP_SR_ES)  // error
        {
            //DEBUGMSG("Error, Send Abort Transmission 0x%02X\n", status);
            REGRW32(ncDrv_CAN_BaseAddr(), rCANP_CMR) = CANP_CMR_AT;
            Result = NC_FAILURE;
            break;
        }

        if(status & CANP_SR_TCS) // data transmit complete
        {
            //DEBUGMSG("Ok, Send data transmit complete 0x%02X\n", status);
            Result = NC_SUCCESS;
            break;
        }
    }

    return Result;
}


INT32 ncDrv_PeliCAN_Receive(tCAN_MSG *rxmsg)
{
    INT32 i, msgch;
    INT32 Result = NC_SUCCESS;
    UINT32 intr_status;
    //UINT32 status = 0;

    intr_status = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_IR) & 0xFF;
    //status = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_SR) & 0xFF;

    if(intr_status & CANP_IR_RI)
    {
        //DEBUGMSG("intr_status : %x\n", intr_status);
        //DEBUGMSG("status : %x\n", status);

        ncDrv_CAN_ISR_Handler();

        msgch = ncDrv_CAN_GetRxMsgBoxIndex();
        if(gp_CanRxMsgBox[msgch].objch == CAN_MSGOBJ_RESERVED)
        {
            Result = NC_FAILURE;
            goto receive_error;
        }

        rxmsg->mode = gp_CanRxMsgBox[msgch].mode;
        rxmsg->format = gp_CanRxMsgBox[msgch].format;
        rxmsg->rtr = gp_CanRxMsgBox[msgch].rtr;

        rxmsg->id = gp_CanRxMsgBox[msgch].id;
        rxmsg->length = gp_CanRxMsgBox[msgch].length;

        for(i = 0; i < rxmsg->length; i++)
        {
            rxmsg->data[i] = gp_CanRxMsgBox[msgch].data[i];
        }

        ncDrv_CAN_ClearRxMsgBoxIndex(msgch);

        if(rxmsg->rtr == CAN_FI_REMOTE_FRAME)
        {
            //DEBUGMSG("PeliCAN Remote Transmission Request !!!\n");
        }
    }
    else
    {
        Result = NC_FAILURE;
        //goto receive_error;
    }

receive_error:

    return Result;
}


void ncDrv_PeliCAN_SFF_ReadFIFO(tCAN_MSG *sffmsg)
{
    UINT8 i, rtr, dlc;
    UINT32 id, sff_fi;

    sff_fi = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_SFF_FI);

    rtr = (UINT8)(sff_fi>>6) & 0x1;
    dlc = (UINT8)(sff_fi) & 0xF;

    id = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_SFF_ID2) & 0xFF;
    id |= (REGRW32(ncDrv_CAN_BaseAddr(), rCANP_SFF_ID1) & 0xFF) << 8;

    sffmsg->rtr = (eCAN_FI_RTR)rtr;
    sffmsg->length = dlc;
    sffmsg->id = id>>5;

    if(rtr == CAN_FI_REMOTE_FRAME)
    {
        for(i = 0; i < 8; i++)
        {
            sffmsg->data[i] = 0;
        }
    }
    else
    {
        for(i = 0; i < dlc; i++)
        {
            sffmsg->data[i] = (UINT8)REGRW32(ncDrv_CAN_BaseAddr(), rCANP_SFF_DATA1 + (i*4));
            //DEBUGMSG("%x ", sffmsg->data[i]);
        }
        //DEBUGMSG("\n");
    }
}


void ncDrv_PeliCAN_EFF_ReadFIFO(tCAN_MSG *effmsg)
{
    UINT8 i, rtr, dlc;
    UINT32 id, eff_fi;

    eff_fi = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_FI);

    rtr = (UINT8)(eff_fi>>6) & 0x1;
    dlc = (UINT8)(eff_fi) & 0xF;

    id = (UINT8)REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_ID4);
    id |= (UINT8)REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_ID3) << 8;
    id |= (UINT8)REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_ID2) << 16;
    id |= (UINT8)REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_ID1) << 24;

    effmsg->rtr = (eCAN_FI_RTR)rtr;
    effmsg->length = dlc;
    effmsg->id = id>>3;

    if(rtr == CAN_FI_REMOTE_FRAME)
    {
        for(i = 0; i < 8; i++)
        {
            effmsg->data[i] = 0;
        }
    }
    else
    {
        for(i = 0; i < dlc; i++)
        {
            effmsg->data[i] = (UINT8)REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_DATA1 + (i*4));
        }
    }
}


void ncDrv_PeliCAN_SetAcceptanceFilter(UINT32 code, UINT32 mask)
{
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_ACR3) = (code>>24) & 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_ACR2) = (code>>16) & 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_ACR1) = (code>>8) & 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_ACR0) =  (code) & 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_AMR3) = (mask>>24) & 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_AMR2) = (mask>>16) & 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_AMR1) = (mask>>8) & 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_AMR0) = (mask) & 0xFF;
}


void ncDrv_PeliCAN_ISRHandler(void)
{
    UINT32 interrupt;
    UINT32 status;
    UINT32 extended=0;
    INT32 i=0;

    interrupt = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_IR) & 0xFF;
    status    = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_SR) & 0xFF;

#if CAN_ISR_DBG_MESSAGE
    UINT32 alc, ecc, ewl, rxec, txec;
#endif

#if CAN_ISR_DBG_MESSAGE
    if(status & CANP_SR_BS)
    	DEBUGMSG("Bus OFF, The CAN Controller moves to RESET MODE \n");
#endif

    // (PeliCAN only) Bus Error Interrupt
    if(interrupt & CANP_IR_BEI)
    {
#if CAN_ISR_DBG_MESSAGE
        ecc = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_ECC);
        rxec = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_RXERR);
        txec = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_TXERR);
        DEBUGMSG("Error, Generated Bus Error Interrupt\n");
        DEBUGMSG("       Status Register : 0x%X\n", status);
        DEBUGMSG("       Error Code Capture Register : 0x%X\n", ecc);
        DEBUGMSG("       RX Error Counter Register  : 0x%X\n", rxec);
        DEBUGMSG("       TX Error Counter Register : 0x%X\n", txec);
#endif
    }

    // (PeliCAN only) Arbitration Lost Interrupt
    if(interrupt & CANP_IR_ALI)
    {
#if CAN_ISR_DBG_MESSAGE
        alc = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_ALC);
        rxec = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_RXERR);
        txec = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_TXERR);
        DEBUGMSG("Error, Generated Arbitration Lost Interrupt\n");
        DEBUGMSG("       Status Register : 0x%X\n", status);
        DEBUGMSG("       Arbitration Lost Capture Register  : 0x%X\n", alc);
        DEBUGMSG("       RX Error Counter Register  : 0x%X\n", rxec);
        DEBUGMSG("       TX Error Counter Register : 0x%X\n", txec);
#endif
    }

    // (PeliCAN only) Error Passive Interrupt
    if(interrupt & CANP_IR_EPI)
    {
#if CAN_ISR_DBG_MESSAGE
        rxec = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_RXERR);
        txec = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_TXERR);
        DEBUGMSG("Error, Generated Error Passive Interrupt\n");
        DEBUGMSG("       Status Register : 0x%X\n", status);
        DEBUGMSG("       RX Error Counter Register  : 0x%X\n", rxec);
        DEBUGMSG("       TX Error Counter Register : 0x%X\n", txec);
#endif
    }
    // Data Overrun Interrupt
    if(interrupt & CANP_IR_DOI)
    {
#if CAN_ISR_DBG_MESSAGE
        DEBUGMSG("Error, Generated Data Overrun Interrupt\n");
        DEBUGMSG("       Status Register : 0x%X\n", status);
#endif
        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_CMR) |= (CANP_CMR_CDO | CANP_CMR_RRB);
    }

    // Error Warning Interrupt
    if(interrupt & CANP_IR_EI)
    {
#if CAN_ISR_DBG_MESSAGE
        ewl = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EWLR);
        rxec = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_RXERR);
        txec = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_TXERR);

        DEBUGMSG("Error, Error Warning Interrupt\n");
        DEBUGMSG("       Status Register : 0x%X\n", status);
        DEBUGMSG("       Warning Limit Register  : 0x%X\n", ewl);
        DEBUGMSG("       RX Error Counter Register  : 0x%X\n", rxec);
        DEBUGMSG("       TX Error Counter Register : 0x%X\n", txec);
#endif
    }

    // Transmit Interrupt
    if(interrupt & CANP_IR_TI)
    {

    }

    // Receive Interrupt
    if(interrupt & CANP_IR_RI)
    {
        if((i = ncDrv_CAN_SetRxMsgBoxIndex()) != NC_FAILURE)
        {
            extended = (REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EFF_FI) & 0x80) >> CANP_FI_FF_SHIFT;

            gp_CanRxMsgBox[i].format = (eCAN_FI_FRAME)extended;
            gp_CanRxMsgBox[i].mode = CAN_CDR_PELI_MODE;

            if(extended == CAN_FI_EXTENDED_FORMAT)
            {
                //ncDrv_PeliCAN_EFF_ReadFIFO(&gp_CanRxMsgBox[i]);
            }
            else
            {
                ncDrv_PeliCAN_SFF_ReadFIFO(&gp_CanRxMsgBox[i]);
            }
        }

        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_CMR) |= (CANP_CMR_RRB);
    }
}


#endif


/* End Of File */
