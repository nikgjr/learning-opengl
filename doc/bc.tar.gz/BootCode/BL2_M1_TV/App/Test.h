/*
********************************************************************************
*
*  Copyright (C) 2013 NEXTCHIP Inc. All rights reserved.
*
*  @file    :
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 2013.11.18 - CAN2.0 basic driver modified by Alessio
*
********************************************************************************
*/

#ifndef __TEST_H__
#define __TEST_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define BL2_JTAG_BOOT_ENABLE    0

#define OSC_25MHZ               25000000
#define OSC_37MHZ               37125000

#define FPGA_APB_CLOCK 			24975000
#define FPGA_CAN_CLOCK 			16000000

#define TV_PLL_CLOCK			216000000
#define TV_APB_CLOCK			74250000
#define TV_CAN_CLOCK			8250000

#define GPIO_DEALY				1
#define UART_TIME_OUT			10000
#define CAN_TIME_OUT			10000
#define I2C_TIME_OUT			10000
#define TIMER_TIME_OUT			1000
#define TIMER_PERIOD			100
#define SUB_TIMER_TIME_OUT		1000
#define SUB_TIMER_PERIOD		100
#define SPI_TIME_OUT


#define SF_TEST_START_PAGE 		0
#define SF_TEST_END_PAGE 		1
//#define SF_TEST_CS 				PAD_SPI2_CSN0 // external flash memory
#define SF_TEST_CS 				PAD_SPI2_CSN1 // internal flash memory

#define TEST_DATA_SZIE 16


/* QUARD SPI Test Option */
#define TEST_QSPI_SFLASH		0


/* ASC BGR Re-Temperature Calibrated Test Option */
//#define TEST_ADC_BGR			1	/* 1st ADC BGR Test Option */
#define TEST_ADC_RTC_BGR_2ND	0	/* 2nd ADC BGR Test Option */
#define TEST_ADC_RTC_BGR_3RD	1	/* 3rd ADC BGR Test Option */


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/


#endif  /* __TEST_DRV_H__ */


/* End Of File */
