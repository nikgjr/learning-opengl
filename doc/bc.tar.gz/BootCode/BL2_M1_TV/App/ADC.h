/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : ADC_Drv.h
*
*  @brief   : This file is ADC Controller Driver for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __ADC_DRV_H__
#define __ADC_DRV_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Type.h"


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
* ADC & TS Option ...
*/

#define ADC_TEMP_SENSOR 	0
#define ADC_ANALOG_INPUT 	1
#define ADC_BGR_INPUT 		3


#define ADC_DEFAUT_CAL 0x10

#define ADC_REF_VOLTAGE		3300
#define ADC_REF_A 			5336
#define ADC_REF_B 			2723500

#define BGF_REF_VOLTAGE     1200 // 1.2V
#define BGF_VTS_50C         1947 // 1.947(V)
#define BGF_VTS_0C          1645 // 1.645(V)
#define BGF_VTS_25          1796 // 1.796(V)


// 3rd ADC BGR Option

#define REF_LOW_TEMP 		(-28)
#define REF_ROOM_TEMP       25
#define REF_HIGH_TEMP       102





/*
* ADC & TS Register Structure
*/

#define rADC_BASE					APACHE_ICU_BASE
#define rADC_CTRL0					0x0428      // [6:4]: ADC channel select
												// [1]: ADC manual enable
                                                // [0]: ADC enable
#define rADC_DOUT                   0x042C      // [15:8]: ADC data channel#1
                                                // [7:0]: ADC data channel#0
#define rADC_EOC                    0x0430      // [6]: ADC_EOC
#define rTS_CTRL0                   0x0440      // [4]: Chopper enable
                                                // [0]: TS power down
#define rTS_CTRL1                   0x444       // [4:0]: TS calibration


/*
* ADC & TS Register Field
*/

/* ADC control 0 register fields */
#define ADC_CTRL0_MANU_MASK				(0x7<<4)
#define ADC_CTRL0_MANU_TEMP_SENSOR      (0x0<<4)
#define ADC_CTRL0_MANU_ANALOG_INPUT     (0x1<<4)
#define ADC_CTRL0_MANU_EN               (0x1<<1)
#define ADC_CTRL0_MANU_DI               (0x0<<1)
#define ADC_CTRL0_EN                    (0x1<<0)
#define ADC_CTRL0_DS                    (0x0<<0)

/* ADC Data output register fields */
#define ADC_EOC_MASK              		(0x1<<6)

/* ADC EOC register fields */
#define ADC_DOUT0_MASK    				(0x3FF<<6)
#define ADC_DOUT1_MASK                  ((UINT32)0x3FF<<22)
#define ADC_DOUT3_MASK                  ((UINT32)0x3FF<<22)


/* Temperature sensor control 0 register fields*/
#define TS_CTRL0_CHOP_EN            	(0x1<<4)
#define TS_CTRL0_CHOP_DS            	(0x0<<4)
#define TS_CTRL0_PD_ON              	(0x0<<0)
#define TS_CTRL0_PD_DOWN            	(0x1<<0)

/* Temperature sensor control 1 register fields*/
#define ADC_TRIG_MODE_MASK          	(0x1<<9)
#define ADC_PD_MASK                 	(0x1<<8)
#define TS_CTRL1_CAL_MASK           	(0x1F<<0)


/*
* SCU ADC Register Field
*/

#define S_ADC_CLK_EN                (1U<<31)
#define S_ADC_RST                   (1U<<31)
#define S_TS_CLK_EN                 (1<<16)

/* [0x0020] VDO Clock Divider Register */
#define S_DIV_VDO_CLK               (0)
#define S_DIV_ADC_SEL               (1)
#define S_DIV_ADC_SEL_MASK          (0x3)

/* [0x00A8] System Clock Divider Register */
#define S_ADC_DIV                   (24)


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

enum
{
    E_ADC_CH0_TS,
    E_ADC_CH1_AIN,
    E_ADC_CH2_RESERVED,
    E_ADC_CH3_BGR,

    MAX_OF_ADC_CH_TYPE
};

enum
{
	E_ADC_CLK_4KHZ,
	E_ADC_CLK_2KHZ,
	E_ADC_CLK_1KHZ,
	E_ADC_CLK_500HZ,

	MAX_OF_ADC_CLK_MAX
};

typedef enum
{
    ADC_TEMP_LT,
    ADC_TEMP_RT,
    ADC_TEMP_HT,
    ADC_TEMP_UNKNOWN,

    MAX_OF_TEMP_ENVIRON
} eTEMP_ENVIRONMENT;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

typedef struct
{
    UINT32 adc;
    UINT32 adc_min;
    UINT32 adc_avg;
    UINT32 adc_max;

    INT32 temp;
    INT32 temp_min;
    INT32 temp_avg;
    INT32 temp_max;

} tADC_INFO, *ptADC_INFO;

typedef struct
{
    tADC_INFO   Ch[MAX_OF_ADC_CH_TYPE];

    INT32       CurTemp;        // 1'st Calibrated x'C
    INT32       CurTemp_min;    // 1'st Calibrated x'C
    INT32       CurTemp_avg;    // 1'st Calibrated x'C
    INT32       CurTemp_max;    // 1'st Calibrated x'C

    UINT32      trimTS;         // 2'nd Calibrated ADC TS
    INT32       trimTS_min;     // 2'nd Calibrated x'C
    INT32       trimTS_avg;     // 2'nd Calibrated x'C
    INT32       trimTS_max;     // 2'nd Calibrated x'C

    UINT32      trimBGR;        // 2'nd Calibrated ADC BGR
    UINT32      trimREF_Volt;   // 2'nd Calibrated ADC Reference Voltage

    INT32       trimTemp;       // 2'nd Calibrated x'C
    INT32       trimTemp_min;   // 2'nd Calibrated x'C
    INT32       trimTemp_avg;   // 2'nd Calibrated x'C
    INT32       trimTemp_max;   // 2'nd Calibrated x'C

} tTEMP_INFO, *ptTEMP_INFO;

typedef struct
{
    UINT32      version;        // Update Version
    INT32       ref_L_temp;     // Reference Low  Temperature -28'C
    INT32       ref_R_temp;     // Reference Room Temperature +25'C
    INT32       ref_H_temp;     // Reference High Temperature +102'C

    UINT32      ref_LT_bgr;     // Reference Low  Temperature BGR
    UINT32      ref_RT_bgr;     // Reference Room Temperature BGR
    UINT32      ref_HT_bgr;     // Reference High Temperature BGR
    UINT32      reserved;       // Reserved

} tSF_REF_TEMP, *ptSF_REF_TEMP;


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern void APACHE_TEST_ADC_RTC_BGR_2ND(void);
extern void APACHE_TEST_ADC_RTC_BGR_3RD(void);


#endif  /* __ADC_DRV_H__ */


/* End Of File */
