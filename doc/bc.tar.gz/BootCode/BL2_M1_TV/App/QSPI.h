/*
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : QSPI_Drv.h
*
*  @brief   : This file is SSP Controller Driver for NEXTCHIP standard library
*
*  @author  : parkjy / SoCSW Team / TS Group
*
*  @date    : 2016.02.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note      :
*
*
********************************************************************************
*/
#ifndef __QSPI_DRV_H__
#define __QSPI_DRV_H__

/*
********************************************************************************
*                                 INCLUDE
********************************************************************************
*/

/*
********************************************************************************
*                   	          DEFINES
********************************************************************************
*/

/*
********************************************************************************
*                        DEFINITIONS FOR QUAD SPI REGISTER
********************************************************************************
*/
// QSPI Control Register
#define rQSPI_CTRL                      0x0000
    #define rQSPI_EN_POL                (1<<23)         // Read Data Enable Polarity
    #define rQSPI_INT_EN                (1<<22)         // Interrupt Enable
    #define rQSPI_CKPHA                 (1<<21)         // SCK Start PHASE
    #define rQSPI_SCKPOL                (1<<20)         // SCK Polarity
    #define rQSPI_TDIR                  (1<<19)         // Direction select(TX)
    #define rQSPI_MODE                  (1<<18)         // Master/Slave Mode
    #define rQSPI_MANU_EN               (1<<17)         // Maunal Enable
    #define rQSPI_EN                    (1<<16)         // Enable
    #define rQSPI_OEN_CON               (1<<14)         // OEN contorl
    #define rQSPI_RSWAP                 (1<<13)         // Read Data Swap
    #define rQSPI_RDIR                  (1<<12)         // Direcion select(RX)
    #define rQSPI_BRATE                 (8)             // BuadRate
    #define rQSPI_CMD                   (0)             // SPI Command

// QSPI End Address Resiger    
#define rQSPI_EADDR                     0x0004

// QSPI Dummy Address Register
#define rQSPI_DUMMY                     0x0008

// QSPI Start Address Register 
#define rQSPI_SADDR                     0x000C

// QSPI Master Interface Wirte Address Register 
#define rQSPI_MIADDR                    0x0010

// QSPI Master Interface Contorl Register
#define rQSPI_MICTRL                    0x0014
    #define rQSPI_PSWAP                 (8)             // Buffer Data Swap for APB Slave
    #define rQSPI_MIEN                  (1<<7)          // Master Interface Enable
    #define rQSPI_MIQSWIP               (1<<5)          // Master Interface Data Quad Swap
    #define rQSPI_MIHSWIP               (1<<4)          // Master Interface Data Half Swap
    #define rQSPI_MIBUST                (0)             // Master Interface Burst Control

// QSPI Master Interface Status Register
#define rQSPI_STS                       0x0018
    #define rQSPI_MIOVER                (1<<23)         // Master Interface Overflow Read Flag
    #define rQSPI_MIFDONE               (1<<22)         // Master Interface Frame Done ReadFlag
    #define rQSPI_CKERR                 (1<<20)         // Check Sum Error Flag
    #define rQSPI_BUSY                  (1<<16)         // Busy Flag
    #define rQSPI_RxDATA                (0)             // Rx Data

#define rQSPI_INTCLR                    0x001C
#define rQSPI_INTMASK                   0x0020
#define rQSPI_SRBUFF                    0x0024
#define rQSPI_SIGSTS                    0x0028
    #define rQSPI_STS_END               (1<<24)
    #define rQSPI_STS_FULL              (1<<8)
    #define rQSPI_STS_EMPTY             (1<<0)
#define rQSPI_INTSTS                    0x002C
#define rQSPI_OSG_DN                    0x0030
    #define rQSPI_OSG_DIS               (0)
    #define rQSPI_OSG_DIRECT            (1<<0)
    #define rQSPI_OSG_APB               (1<<1)
#define rQSPI_EXT_ADDR                  0x005C











/*
********************************************************************************
*                                ENUMERATION
********************************************************************************
*/



/*
********************************************************************************
*                                 TYPEDEFS
********************************************************************************
*/

/*
********************************************************************************
*                           CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                           VARIABLE DECLARATIONS
********************************************************************************
*/

/*
********************************************************************************
*                            FUNCTION DECLARATIONS
********************************************************************************
*/

extern void   ncDrv_QSPI_Init(void);
extern void   ncDrv_QSPI_DeInit(void);
extern INT32  ncDrv_QSPI_MenualReadData(UINT32 Addr, UINT32 BuffAddr, UINT32 Size);
extern INT32 ncDrv_QSPI_SetBitRate(UINT32 bitrate);

#endif  /* __QSPI_DRV_H__ */




