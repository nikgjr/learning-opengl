/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : sFlash_Svc.c
*
*  @brief   : This file is sFlash controller API for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.11.19
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note
*
*
*
*
********************************************************************************
*/
/*
********************************************************************************
*                                 INCLUDE
********************************************************************************
*/
#include "main.h"
#include "sFlash.h"

#include <stdarg.h>

#include "Apache35.h"
#include "Test.h"
#include "SSP.h"
#include "QSPI.h"
#include "SCU.h"
#include "GPIO.h"
#include "GIC.h"










/*
********************************************************************************
*                              LOCAL DEFINITIONS
********************************************************************************
*/
//#define __SUPPORT_DMA_MODE__                    // parkjy 20160623 : code size issue (del DMA Mode)


#define CMD_sFlash_WR_EN                        0x06
#define CMD_sFlash_WR_DS                        0x04
#define CMD_sFlash_RD_STS                       0x05
#define CMD_sFlash_RD_STS2                      0x35		// for WINBOND SPI Flash
#define CMD_sFlash_WR_STS                       0x01
#define CMD_sFlash_RD_DATA                      0x03
#define CMD_sFlash_PAGE_PROGRAM                 0x02
#define CMD_sFlash_SECTOR_ERASE                 0x20
#define CMD_sFlash_BLOCK_ERASE                  0xD8
#define CMD_sFlash_RD_IDENTIFICATION            0x9F
#define CMD_sFlash_SR_RD_DATA                   0x48
#define CMD_sFlash_SR_ERASE                     0x44
#define CMD_sFlash_SR_PROGRAM                   0x42

#define STS_WIP                                 (0x1<<0)
#define STS_WEL                                 (0x1<<1)

#define FLASH_ID_WINBOND                        (0xEF)
#define FLASH_ID_EON                            (0x1C)
#define FLASH_ID_MXIC                           (0xC2)
#define FLASH_ID_MICRON                         (0x20)
#define FLASH_ID_SPANSION                       (0xEF)

#define BP0     (1<<2)
#define BP1     (1<<3)
#define BP2     (1<<4)
#define BP3     (1<<5)

/*
********************************************************************************
*                           LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                                 LOCAL TYPEDEF
********************************************************************************
*/











/*
********************************************************************************
*                       IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                        GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/
BOOL 			gbDmaMode   = FALSE;
BOOL 			gbQuadMode  = FALSE;
UINT8 			gSSPChNum;

/*
********************************************************************************
*                       IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                         LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

/*
********************************************************************************
*                           FUNCTION DEFINITIONS
********************************************************************************
*/



static void ncLib_SSP_CS_High(UINT32 nChNum)
{
    ncDrv_GPIO_SetData(GPIO_GROUP_A, GPIO_PORT12, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
}

static void ncLib_SSP_CS_Low(UINT32 nChNum)
{
   	ncDrv_GPIO_SetData(GPIO_GROUP_A, GPIO_PORT12, GPIO_LOW, rGPIO_V2_OUT_PORT0);
}

static void ncLib_SSP_PinMux(UINT32 nChNum)
{
    if(nChNum == SSP_CH0)
    {
    	ncDrv_SCU_SetPinMux(SF_TEST_CS, PAD_FUNC_4); 	// Mux->GPIO_12
    	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ0,  PAD_FUNC_1);
    	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ1,  PAD_FUNC_1);
    	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ2,  PAD_FUNC_4); // Mux->GPIO_16
    	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ3,  PAD_FUNC_4); // Mux->GPIO_17
    	ncDrv_SCU_SetPinMux(PAD_SPI2_SCK,  PAD_FUNC_1);

    	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT12, GPIO_DIR_OUT, rGPIO_V2_DIR0);
    	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT16, GPIO_DIR_OUT, rGPIO_V2_DIR0);
    	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT17, GPIO_DIR_OUT, rGPIO_V2_DIR0);

    	ncDrv_GPIO_SetData(GPIO_GROUP_A, GPIO_PORT16, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
        ncDrv_GPIO_SetData(GPIO_GROUP_A, GPIO_PORT17, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
    }
    else if(nChNum == SSP_CH1)
    {
#if 0
        // Standard SPI Mode -> Controller SSP1
    	ncDrv_SCU_SetPinMux(PAD_GPIO2,    PAD_FUNC_4); // Mux->GPIOA[0]
    	ncDrv_SCU_SetPinMux(PAD_I2C0_SDA, PAD_FUNC_2); // Mux->SSP1_MOSI
    	ncDrv_SCU_SetPinMux(PAD_GPIO4,    PAD_FUNC_1); // Mux->SSP1_MISO
    	ncDrv_SCU_SetPinMux(PAD_I2C0_SCL, PAD_FUNC_2); // Mux->SSP1_CLK

    	ncDrv_GPIO_SetData(GPIO_GROUP_A, GPIO_PORT0, GPIO_DIR_OUT, rGPIO_V2_OUT_PORT0);
#endif
        ncDrv_SCU_SetPinMux(SF_TEST_CS, PAD_FUNC_4); // Mux->GPIO_12
        ncDrv_SCU_SetPinMux(PAD_SPI2_DQ0,  PAD_FUNC_2);
        ncDrv_SCU_SetPinMux(PAD_SPI2_DQ1,  PAD_FUNC_2);
        ncDrv_SCU_SetPinMux(PAD_SPI2_DQ2,  PAD_FUNC_4); // Mux->GPIO_16
        ncDrv_SCU_SetPinMux(PAD_SPI2_DQ3,  PAD_FUNC_4); // Mux->GPIO_17
        ncDrv_SCU_SetPinMux(PAD_SPI2_SCK,  PAD_FUNC_2);

        ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT12, GPIO_DIR_OUT, rGPIO_V2_DIR0);
        ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT16, GPIO_DIR_OUT, rGPIO_V2_DIR0);
        ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT17, GPIO_DIR_OUT, rGPIO_V2_DIR0);

        ncDrv_GPIO_SetData(GPIO_GROUP_A, GPIO_PORT16, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
        ncDrv_GPIO_SetData(GPIO_GROUP_A, GPIO_PORT17, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
    }

    ncLib_SSP_CS_High(nChNum);
}

static void ncLib_SSP_PinMuxFree(UINT32 nChNum)
{
        // Set GPIO Mode
    	ncDrv_SCU_SetPinMux(SF_TEST_CS, PAD_FUNC_4);
    	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ0,  PAD_FUNC_4);
    	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ1,  PAD_FUNC_4);
    	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ2,  PAD_FUNC_4);
    	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ3,  PAD_FUNC_4);
    	ncDrv_SCU_SetPinMux(PAD_SPI2_SCK,  PAD_FUNC_4);

        // Set GPIO InputMode
    	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT12, GPIO_DIR_IN, rGPIO_V2_DIR0);
    	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT14, GPIO_DIR_IN, rGPIO_V2_DIR0);
    	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT15, GPIO_DIR_IN, rGPIO_V2_DIR0);
    	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT16, GPIO_DIR_IN, rGPIO_V2_DIR0);
    	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT17, GPIO_DIR_IN, rGPIO_V2_DIR0);
    	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT18, GPIO_DIR_IN, rGPIO_V2_DIR0);
}


static void ncLib_QSPI_PinMux(void)
{
    // Quad SPI Mode
	ncDrv_SCU_SetPinMux(SF_TEST_CS, PAD_FUNC_2);
	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ0,  PAD_FUNC_0);
	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ1,  PAD_FUNC_0);
	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ2,  PAD_FUNC_0);
	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ3,  PAD_FUNC_0);
	ncDrv_SCU_SetPinMux(PAD_SPI2_SCK,  PAD_FUNC_0);
}

static void ncLib_QSPI_PinMuxFree(void)
{
    // Set GPIO Mode
	ncDrv_SCU_SetPinMux(SF_TEST_CS, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ0,  PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ1,  PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ2,  PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_SPI2_DQ3,  PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_SPI2_SCK,  PAD_FUNC_4);

    // Set GPIO InputMode
	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT12, GPIO_DIR_IN, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT14, GPIO_DIR_IN, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT15, GPIO_DIR_IN, rGPIO_V2_DIR0);
    ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT16, GPIO_DIR_IN, rGPIO_V2_DIR0);
    ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT17, GPIO_DIR_IN, rGPIO_V2_DIR0);
    ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT18, GPIO_DIR_IN, rGPIO_V2_DIR0);
}


/*
********************************************************************************
* Function Name : ncSvc_SF_Enable_Ch()
*
*
* Description :
*
*
* Arguments  : None
*
*
* Return     : None
********************************************************************************
*/

void ncSvc_SF_Enable_Ch(void)
{
	ncDrv_SSP_ClearRxFIFO(gSSPChNum);
    ncDrv_SSP_WaitBusIsBusy(gSSPChNum, 1000);
	ncLib_SSP_CS_Low(gSSPChNum);
}

void ncSvc_SF_Disable_Ch(void)
{
	ncLib_SSP_CS_High(gSSPChNum);
}

void ncSvc_SF_QSPI_Init(void)
{
    ncLib_QSPI_PinMux();
    ncDrv_QSPI_Init();
}

void ncSvc_SF_QSPI_DeInit(void)
{
    ncDrv_QSPI_DeInit();
    ncLib_QSPI_PinMuxFree();
}




/*
********************************************************************************
* Function Name : 
*
*
* Description : 
*
*
* Arguments  :
*
*
* Return     :
********************************************************************************
*/
void ncSvc_SF_QSPIEnable(BOOL OnOff)
{
    tSFLASH_ID tsFlashID;
    UINT8 Status1;
    UINT8 Status2;
    
    ncSvc_SF_ReadDeviceIdentification(&tsFlashID);

    if(OnOff)
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status2 = ncSvc_SF_ReadStatus2();

            if( !(Status2 & (1<<1)) )
            {
                ncSvc_SF_WriteStatus2(Status1, Status2|(1<<1));
            }
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            if( !(Status1 & (1<<6)) )
            {
                ncSvc_SF_WriteStatus(Status1|(1<<6));
            }
        }
    }
    else
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status2 = ncSvc_SF_ReadStatus2();

            if( (Status2 & (1<<1)) )
            {
                Status2 &= (~1<<1);
                ncSvc_SF_WriteStatus2(Status1, Status2);
            }
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            if( (Status1 & (1<<6)) )
            {
                Status1 &= ~(1<<6);
                ncSvc_SF_WriteStatus(Status1);
            }
        }
    }

    gbQuadMode = OnOff;    
}

/*
********************************************************************************
* Function Name : ncSvc_SF_GetPadCtrl()
*
*
* Description : 
*
*
* Arguments  : 
*
*
* Return     : None
********************************************************************************
*/
INT32 ncSvc_SF_GetPadCtrl(void)
{
    ncLib_SSP_PinMux(gSSPChNum);
    return NC_SUCCESS;
}

/*
********************************************************************************
* Function Name : ncSvc_SF_FreePadCtrl()
*
*
* Description : 
*
*
* Arguments  : 
*
*
* Return     : None
********************************************************************************
*/
INT32 ncSvc_SF_FreePadCtrl(void)
{
	ncLib_SSP_PinMuxFree(gSSPChNum);
        
    return NC_SUCCESS;
}

/*
********************************************************************************
* Function Name : ncSvc_SF_Init()
*
*
* Description : @ Initialize SPI controller by boot strap
*               @ Read serial flash identification
*               @ Set up all structure to boot up
*
*
* Arguments  : @ Mode  : 0 - Single SPI mode
*                        1 - Quad SPI mode
*
*
* Return     : @ TRUE  : Initialize is OK
*              @ FALSE : Initialize is FAIL
********************************************************************************
*/
INT32 ncSvc_SF_Init(ptSF_INIT_PARAM ptParam)
{
    INT32 ret = NC_SUCCESS;
    tSSP_INIT_PARAM tSSPParam;

    tSSPParam.mFormat       = SSP_FMT_SPI;
    tSSPParam.mMode         = SSP_MODE_MASTER;
    tSSPParam.mDataWidth    = SSP_DS_8BIT;
    tSSPParam.mBitRate      = ptParam->mBitRate;
    tSSPParam.mTxIntEn      = FALSE; 
    tSSPParam.mRxIntEn      = FALSE;
    tSSPParam.mSPO          = SSP_SPO_LOW;
    tSSPParam.mSPH          = SSP_SPH_LOW;	

    ncLib_SSP_PinMux(ptParam->mChNum);
    ret = ncDrv_SSP_Init(ptParam->mChNum, &tSSPParam);

    if(ncDrv_SSP_GetInterruptMask(ptParam->mChNum) & (SSP_TXIM_NOMASKED|SSP_RXIM_NOMASKED))
    {
        if(ptParam->mChNum)
        {
        	GIC_RegisterHandler(IRQ_NUM_SPI1, (PrHandler)ncDrv_SSP_Handler1);
            ncDrv_GIC_EnableIrq(IRQ_NUM_SPI1);
        }
        else
        {
        	GIC_RegisterHandler(IRQ_NUM_SPI0, (PrHandler)ncDrv_SSP_Handler0);
            ncDrv_GIC_EnableIrq(IRQ_NUM_SPI0);
        }
    }

    gSSPChNum = ptParam->mChNum;
#ifdef __SUPPORT_DMA_MODE__
    gbDmaMode = ptParam->mDmaMode;
#else
    gbDmaMode = FALSE;
#endif

    if(ptParam->mQuadMode == TRUE)
    {
#if BL2_JTAG_BOOT_ENABLE
    	ncDrv_QSPI_SetBitRate(QSPI_BR_DIV_10);
#else
    	ncDrv_QSPI_SetBitRate(ptParam->mBitRate);
#endif
    }

    ncSvc_SF_QSPIEnable( ptParam->mQuadMode );
    
    return ret;
}


/*
********************************************************************************
* Function Name : ncSvc_SF_Release()
*
*
* Description : Release SPI controller (All GPIO input mode)
*
*
* Arguments  : None
*
*
* Return     : @ TRUE  : Initialize is OK
*              @ FALSE : Initialize is FAIL
********************************************************************************
*/
INT32 ncSvc_SF_Release(void)
{
    INT32 ret = NC_SUCCESS;

    /*
    * Deinit QSPI 
    */
    if(gbQuadMode == TRUE)
    {
        ncSvc_SF_QSPIEnable(FALSE);
    }

    /*
    * Deinit SSP Channel
    */

    ncLib_SSP_PinMuxFree(gSSPChNum);
    ret = ncDrv_SSP_DeInit(gSSPChNum);

    if(ncDrv_SSP_GetInterruptMask(gSSPChNum) & (SSP_TXIM_NOMASKED|SSP_RXIM_NOMASKED))
    {
    	ncDrv_GIC_ClearAllRaisedIrq();

        if(gSSPChNum)
        {
        	GIC_UnRegisterHandler(IRQ_NUM_SPI1);
        	ncDrv_GIC_DisableIrq(IRQ_NUM_SPI1);
        }
        else
        {
        	GIC_UnRegisterHandler(IRQ_NUM_SPI0);
        	ncDrv_GIC_DisableIrq(IRQ_NUM_SPI0);
        }
    }

    gSSPChNum  = 0;
    gbQuadMode = 0;
    gbDmaMode  = 0;

    return ret;
}


/*
********************************************************************************
* Function Name : APACHE3_SPI_GetRxCount()
*
*
* Description : Read receive FIFO count
*
*
* Arguments  : bitrate 		SF_BITRATE_1Mbps	: 1Mbps
*                      		SF_BITRATE_2Mbps	: 2Mbps
*                      		SF_BITRATE_3Mbps	: 3Mbps
*                      		         .
*                      		         .
*                      		         .
*                      		SF_BITRATE_29Mbps	: 29Mbps
*                      		SF_BITRATE_30Mbps	: 30Mbps
*
*
* Return     : None
********************************************************************************
*/
void ncSvc_SF_SetBitRate(SF_BITRATE bitrate)
{
    if(gbQuadMode == TRUE)
    	ncDrv_QSPI_SetBitRate((UINT32)bitrate);
    if(bitrate > SF_BITRATE_40Mbps)
    {
        bitrate = SF_BITRATE_40Mbps;
    }   

    ncDrv_SSP_SetBitRate(gSSPChNum, bitrate);
}

/*
********************************************************************************
* Function Name : ncSvc_SF_WaitWIP()
*
*
* Description : Wait write in progressive status (WIP)
*
*
* Arguments  : None
*
*
* Return     : None
********************************************************************************
*/
void ncSvc_SF_WaitWIP(void)
{
    while(ncSvc_SF_ReadStatus() & STS_WIP) ;
}


/*
********************************************************************************
* Function Name : ncSvc_SF_WriteEnable()
*
*
* Description : Send "Write Enable" command to the serial flash to support block erase and page program
*
*
* Arguments  : None
*
*
* Return     : None
********************************************************************************
*/

void ncSvc_SF_WriteEnable(void)
{
    UINT8 Command;

    ncSvc_SF_Enable_Ch();

    Command = CMD_sFlash_WR_EN;
    ncDrv_SSP_Write(gSSPChNum, &Command, 1);

    ncSvc_SF_Disable_Ch();

    while( (ncSvc_SF_ReadStatus() & STS_WEL) != STS_WEL  ) ;
}


/*
********************************************************************************
* Function Name : ncSvc_SF_WriteEnable()
*
*
* Description : Send "Write Disable" command to the serial flash to escape block erase and page program mode
*
*
* Arguments  : None
*
*
* Return     : None
********************************************************************************
*/
void ncSvc_SF_WriteDisable(void)
{
    UINT8 Command;

    while( ncSvc_SF_ReadStatus() & STS_WIP  ) ;

    ncSvc_SF_Enable_Ch();

    Command = CMD_sFlash_WR_DS;
    ncDrv_SSP_Write(gSSPChNum, &Command, 1);

    ncSvc_SF_Disable_Ch();

}


/*
********************************************************************************
* Function Name : ncSvc_SF_ReadStatus()
*
*
* Description : Send "Read Status" command to the serial flash to check current status of it
*
*
* Arguments  : None
*
*
* Return     : None
********************************************************************************
*/
UINT8 ncSvc_SF_ReadStatus(void)
{
    UINT8 Command;
    UINT8 Status = 0;

    ncSvc_SF_Enable_Ch();

    Command = CMD_sFlash_RD_STS;
    ncDrv_SSP_Write(gSSPChNum, &Command, 1);
    ncDrv_SSP_Read(gSSPChNum, &Status, 1);

    ncSvc_SF_Disable_Ch();

    return Status;
}


/*
********************************************************************************
* Function Name : ncSvc_SF_ReadStatus2()
*
*
* Description : Send "Read Status2" command to the serial flash to check current status of it
*
*
* Arguments  : None
*
*
* Return     : None
********************************************************************************
*/
UINT8 ncSvc_SF_ReadStatus2(void)
{
    UINT8 Command;
    UINT8 Status = 0;

    ncSvc_SF_Enable_Ch();

    Command = CMD_sFlash_RD_STS2;
    ncDrv_SSP_Write(gSSPChNum, &Command, 1);
    ncDrv_SSP_Read(gSSPChNum, &Status, 1);

    ncSvc_SF_Disable_Ch();

    return Status;
}


/*
********************************************************************************
* Function Name : ncSvc_SF_WriteStatus()
*
*
* Description : Send "Write Status" command to the serial flash to set new status
*
*
* Arguments  : None
*
*
* Return     : None
********************************************************************************
*/
void ncSvc_SF_WriteStatus(UINT8 Status)
{
    UINT8 Command[2];

    ncSvc_SF_WriteEnable();

    ncSvc_SF_Enable_Ch();

    Command[0] = CMD_sFlash_WR_STS;
    Command[1] = Status;
    ncDrv_SSP_Write(gSSPChNum, Command, 2);

    ncSvc_SF_Disable_Ch();

    ncSvc_SF_WriteDisable();
}


/*
********************************************************************************
* Function Name : ncSvc_SF_WriteStatus2()
*
*
* Description : Send "Write Status2" command to the serial flash to set new status
*
*
* Arguments  : None
*
*
* Return     : None
********************************************************************************
*/
void ncSvc_SF_WriteStatus2(UINT8 Status1, UINT8 Status2)
{
    UINT8 Command[3];

    ncSvc_SF_WriteEnable();

    ncSvc_SF_Enable_Ch();

    Command[0] = CMD_sFlash_WR_STS;
    Command[1] = Status1;
    Command[2] = Status2;	
    ncDrv_SSP_Write(gSSPChNum, Command, 3);

    ncSvc_SF_Disable_Ch();

    ncSvc_SF_WriteDisable();
}


/*
********************************************************************************
* Function Name : ncSvc_SF_ReadDeviceIdentification()
*
*
* Description : Read serial flash identification from serial flash
*
*
* Arguments  : @ ptsFlashID : Serial flash identification will be stored in this structure
*
*
* Return     : None
********************************************************************************
*/



INT32 ncSvc_SF_ReadDeviceIdentification(ptSFLASH_ID ptsFlashID)
{
    UINT8 Command;

    ncSvc_SF_Enable_Ch();


    Command = CMD_sFlash_RD_IDENTIFICATION;
    ncDrv_SSP_Write(gSSPChNum, &Command, 1);
    ncDrv_SSP_Read(gSSPChNum, (UINT8*)ptsFlashID, 3);

    ncSvc_SF_Disable_Ch();

    return NC_SUCCESS;
}


/*
********************************************************************************
* Function Name : 
*
*
* Description :
*               
*
*
* Arguments  : 
*             
*
*
* Return     : 
********************************************************************************
*/
INT32 ncSvc_SF_ReadData_DMAMode(UINT8 *pData, UINT32 Size)
{   
#ifdef __SUPPORT_DMA_MODE__
    UINT32 Reg;
    
    ptDMA_INFO ptDMATx = &tDMAParm_SSPTx[gSSPChNum];   
    ptDMA_INFO ptDMARx = &tDMAParm_SSPRx[gSSPChNum];       
    UINT8 InstBuffTx[DMA_INST_BUFF_SIZE] __attribute__ ((aligned (8)));
    UINT8 InstBuffRx[DMA_INST_BUFF_SIZE] __attribute__ ((aligned (8)));



    
    // SSP DMA FIFO Close
    ncLib_SSP_Control(GCMD_SSP_SET_DMA_MODE_CH, gSSPChNum, 0, CMD_END);
    
    // Set Port(SSP/UART)
    if(gSSPChNum == 0)
    {
        Reg = ncLib_SCU_Control(GCMD_SCU_GET_DATA, 0x08, CMD_END);
        Reg |= (0x3<<0);
        ncLib_SCU_Control(GCMD_SCU_SET_DATA, 0x08, Reg, CMD_END);
    }
    else
    {
        Reg = ncLib_SCU_Control(GCMD_SCU_GET_DATA, 0x08, CMD_END);
        Reg |= (0x3<<2);
        ncLib_SCU_Control(GCMD_SCU_SET_DATA, 0x08, Reg, CMD_END);
    }
    
    
    // init DMA Tx/Rx
    ptDMATx->srcAddr   = (UINT32)APACHE_BOOT_RAM;
    ptDMATx->xferBytes = Size;
    ptDMATx->instBase  = (UINT32)&InstBuffTx[0];  
    ncLib_DMA_Control(GCMD_DMA_INIT_CH, ptDMATx->dmaCh, CMD_END);
    ncLib_DMA_Control(GCMD_DMA_START, ptDMATx, CMD_END);
    
    ptDMARx->dstAddr   = (UINT32)&pData[0];
    ptDMARx->xferBytes = Size;  
    ptDMARx->instBase  = (UINT32)&InstBuffRx[0];      
    ncLib_DMA_Control(GCMD_DMA_INIT_CH, ptDMARx->dmaCh, CMD_END);
    ncLib_DMA_Control(GCMD_DMA_START, ptDMARx, CMD_END);


    // SSP DMA FIFO Open
    ncLib_SSP_Control(GCMD_SSP_SET_DMA_MODE_CH, gSSPChNum, (SSP_DMAE_TX|SSP_DMAE_RX), CMD_END);

    // DMA Wait
    while(ncLib_DMA_Control(GCMD_DMA_DONE, ptDMATx->dmaCh, CMD_END) == NC_FAILURE);    
    while(ncLib_DMA_Control(GCMD_DMA_DONE, ptDMARx->dmaCh, CMD_END) == NC_FAILURE);  


    // Clear DMA Rx/Tx
    ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, ptDMATx->dmaCh, CMD_END);
    ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, ptDMARx->dmaCh, CMD_END);

    // Clear Port(SSP/UART)
    if(gSSPChNum == 0)
    {
        Reg = ncLib_SCU_Control(GCMD_SCU_GET_DATA, 0x08, CMD_END);
        Reg &= ~(0x3<<0);
        ncLib_SCU_Control(GCMD_SCU_SET_DATA, 0x08, Reg, CMD_END);
    }
    else
    {
        Reg = ncLib_SCU_Control(GCMD_SCU_GET_DATA, 0x08, CMD_END);
        Reg &= ~(0x3<<2);
        ncLib_SCU_Control(GCMD_SCU_SET_DATA, 0x08, Reg, CMD_END);
    }


    // SSP DMA FIFO Close
    ncLib_SSP_Control(GCMD_SSP_SET_DMA_MODE_CH, gSSPChNum, 0, CMD_END);
 
 
    return NC_SUCCESS;
#else
    return NC_FAILURE;
#endif
}

INT32 ncSvc_SF_WriteData_DMAMode(UINT8 *pData, UINT32 Size)
{
#ifdef __SUPPORT_DMA_MODE__
    UINT32 Reg;
    
    ptDMA_INFO ptDMATx = &tDMAParm_SSPTx[gSSPChNum];    
    UINT8 InstBuffTx[DMA_INST_BUFF_SIZE] __attribute__ ((aligned (8)));    


    // SSP DMA FIFO Close
    ncLib_SSP_Control(GCMD_SSP_SET_DMA_MODE_CH, gSSPChNum, 0, CMD_END);


    // Set Port(SSP/UART)
    if(gSSPChNum == 0)
    {
        Reg = ncLib_SCU_Control(GCMD_SCU_GET_DATA, 0x08, CMD_END);
        Reg |= (0x1<<0);
        ncLib_SCU_Control(GCMD_SCU_SET_DATA, 0x08, Reg, CMD_END);
    }
    else
    {
        Reg = ncLib_SCU_Control(GCMD_SCU_GET_DATA, 0x08, CMD_END);
        Reg |= (0x1<<2);
        ncLib_SCU_Control(GCMD_SCU_SET_DATA, 0x08, Reg, CMD_END);
    }

    
    // init DMATx
    ptDMATx->srcAddr   = (UINT32)&pData[0];
    ptDMATx->xferBytes = Size;
    ptDMATx->instBase  = (UINT32)&InstBuffTx[0];
    ncLib_DMA_Control(GCMD_DMA_INIT_CH, ptDMATx->dmaCh, CMD_END);
    ncLib_DMA_Control(GCMD_DMA_START, ptDMATx, CMD_END);


    // SSP DMA FIFO Open
    ncLib_SSP_Control(GCMD_SSP_SET_DMA_MODE_CH, gSSPChNum, SSP_DMAE_TX, CMD_END);

    // DMATx Done Wait
    while(ncLib_DMA_Control(GCMD_DMA_DONE, ptDMATx->dmaCh, CMD_END) == NC_FAILURE);    


    // de-init DMA Tx 
    ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, ptDMATx->dmaCh, CMD_END);


    // Clear Port(SSP/UART)
    if(gSSPChNum == 0)
    {
        Reg = ncLib_SCU_Control(GCMD_SCU_GET_DATA, 0x08, CMD_END);
        Reg &= ~(0x1<<0);
        ncLib_SCU_Control(GCMD_SCU_SET_DATA, 0x08, Reg, CMD_END);
    }
    else
    {
        Reg = ncLib_SCU_Control(GCMD_SCU_GET_DATA, 0x08, CMD_END);
        Reg &= ~(0x1<<2);
        ncLib_SCU_Control(GCMD_SCU_SET_DATA, 0x08, Reg, CMD_END);
    }

    // SSP DMA FIFO Close
    ncLib_SSP_Control(GCMD_SSP_SET_DMA_MODE_CH, gSSPChNum, 0, CMD_END);


    return NC_SUCCESS;
#else
    return NC_FAILURE;
#endif
}


/*
********************************************************************************
* Function Name : ncSvc_SF_ReadData()
*
*
* Description : Read data from serial flash
*
*
* Arguments  : @ PageAddr : Page address to be read
*              @ pData    : Data buffer to be read
*              @ Size 	  : Data size
*
*
* Return     : None
********************************************************************************
*/
INT32 ncSvc_SF_ReadData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    UINT8 Command[4];


    if((gbQuadMode == TRUE) && !(Size%8))   // Quad SPI 64bit Align      
    {
    	ncSvc_SF_QSPI_Init();
        ncDrv_QSPI_MenualReadData(Addr, (UINT32)pData, Size);
        ncSvc_SF_QSPI_DeInit();
        
        ncLib_SSP_PinMux(gSSPChNum);
    }
    else
    {
    	ncSvc_SF_Enable_Ch();

        Command[0] = CMD_sFlash_RD_DATA;
        Command[1] = (Addr>>16 & 0xFF);
        Command[2] = (Addr>>8  & 0xFF);
        Command[3] = (Addr     & 0xFF);
        ncDrv_SSP_Write(gSSPChNum, Command, 4);
        if((gbDmaMode == TRUE) && (Size>16))
            ncSvc_SF_ReadData_DMAMode(pData, Size);
        else
        	ncDrv_SSP_Read(gSSPChNum, pData, Size);

        ncSvc_SF_Disable_Ch();
    }

    return NC_SUCCESS;
}

/*
********************************************************************************
* Function Name : ncSvc_SF_SR_ReadData()
*
*
* Description : Security Register Read data from serial flash
*
*
* Arguments  : @ PageAddr : Page address to be read
*              @ pData    : Data buffer to be read
*              @ Size 	  : Data size
*
*
* Return     : None
********************************************************************************
*/
INT32 ncSvc_SF_SR_ReadData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    UINT8 Command[8];

	ncSvc_SF_Enable_Ch();

	Command[0] = CMD_sFlash_SR_RD_DATA;
	Command[1] = (Addr>>16 & 0xFF);
	Command[2] = (Addr>>8  & 0xFF);
	Command[3] = (Addr     & 0xFF);
	Command[4] = 0xFF;

	ncDrv_SSP_Write(gSSPChNum, Command, 5);
    ncDrv_SSP_Read(gSSPChNum, pData, Size);

	ncSvc_SF_Disable_Ch();

    return NC_SUCCESS;
}

/*
********************************************************************************
* Function Name : ncSvc_SF_WriteData()
*
*
* Description : @ Send "Page Program" command to write 1 page data into the serial flash through SPI bus
*               @ This driver can only support DMA mode in current version
*
*
* Arguments  : @ PageAddr  : Page address to be written to the serial flash
*              @ pData     : Data buffer to be written
*
*
* Return     : None
********************************************************************************
*/
INT32 ncSvc_SF_WriteData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();


    ncSvc_SF_Enable_Ch();

    Command[0] = CMD_sFlash_PAGE_PROGRAM;
    Command[1] = (Addr>>16 & 0xFF);
    Command[2] = (Addr>>8  & 0xFF);
    Command[3] = (Addr     & 0xFF);
    ncDrv_SSP_Write(gSSPChNum, Command, 4);
    if((gbDmaMode == TRUE) && (Size>16))
        ncSvc_SF_WriteData_DMAMode(pData, Size);
    else
    	ncDrv_SSP_Write(gSSPChNum, pData, Size);
    ncDrv_SSP_WaitBusIsBusy(gSSPChNum, 1000);
    
    ncSvc_SF_Disable_Ch();


    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}

/*
********************************************************************************
* Function Name : ncSvc_SF_SR_WriteData()
*
*
* Description : @ Send "Page Program" command to write 1 page data into the serial flash through SPI bus
*               @ This driver can only support DMA mode in current version
*
*
* Arguments  : @ PageAddr  : Page address to be written to the serial flash
*              @ pData     : Data buffer to be written
*
*
* Return     : None
********************************************************************************
*/
INT32 ncSvc_SF_SR_WriteData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();

    ncSvc_SF_Enable_Ch();

    Command[0] = CMD_sFlash_SR_PROGRAM;
    Command[1] = (Addr>>16 & 0xFF);
    Command[2] = (Addr>>8  & 0xFF);
    Command[3] = (Addr     & 0xFF);

    ncDrv_SSP_Write(gSSPChNum, Command, 4);
  	ncDrv_SSP_Write(gSSPChNum, pData, Size);

  	ncDrv_SSP_WaitBusIsBusy(gSSPChNum, 1000);

    ncSvc_SF_Disable_Ch();

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}


/*
********************************************************************************
* Function Name : ncSvc_SF_SectorErase()
*
*
* Description : Send "Sector Erase" command to erase 1 sector of serial flash
*               (1 sector size is 4KB)
*
*
* Arguments  : @ PageAddr : Sector address to be erased
*
*
* Return     : None
********************************************************************************
*/
INT32 ncSvc_SF_SectorErase(UINT32 PageAddr)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();

    ncSvc_SF_Enable_Ch();

    Command[0] = CMD_sFlash_SECTOR_ERASE;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);
    ncDrv_SSP_Write(gSSPChNum, Command, 4);

    ncSvc_SF_Disable_Ch();

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}


/*
********************************************************************************
* Function Name : ncSvc_SF_BlockErase()
*
*
* Description : Send "Block Erase" command to erase 1 block of serial flash
*               (1 Block Size is 64KB)
*
*
* Arguments  : @ PageAddr : Block address to be erased
*
*
* Return     : None
********************************************************************************
*/
INT32 ncSvc_SF_BlockErase(UINT32 PageAddr)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();

    ncSvc_SF_Enable_Ch();

    Command[0] = CMD_sFlash_BLOCK_ERASE;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);
    ncDrv_SSP_Write(gSSPChNum, Command, 4);

    ncSvc_SF_Disable_Ch();

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}


/*
********************************************************************************
* Function Name : ncSvc_SF_SR_Erase()
*
*
* Description : Send "Sector Erase" command to erase 1 sector of serial flash
*               (1 sector size is 4KB)
*
*
* Arguments  : @ PageAddr : Sector address to be erased
*
*
* Return     : None
********************************************************************************
*/
INT32 ncSvc_SF_SR_Erase(UINT32 PageAddr)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();

    ncSvc_SF_Enable_Ch();

    Command[0] = CMD_sFlash_SR_ERASE;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);

    ncDrv_SSP_Write(gSSPChNum, Command, 4);

    ncSvc_SF_Disable_Ch();

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}


/*
********************************************************************************
* Function Name : ncSvc_SF_EnableWP()
*
*
* Description : Set Data Protection by setting BP0, BP1, BP2, BP3 in Status Register.
*
*
* Arguments  :
*
*
* Return     : None
********************************************************************************
*/
void ncSvc_SF_EnableWP(BOOL OnOff)
{

    tSFLASH_ID tsFlashID;
    UINT8 Status1=0;
    UINT8 protection = BP3|BP2|BP1|BP0;

    ncSvc_SF_ReadDeviceIdentification(&tsFlashID);

    if(OnOff)
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            //TODO
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status1 |= protection;
            ncSvc_SF_WriteStatus(Status1);
        }
    }
    else
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            //TODO
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status1 &= ~(protection);
            ncSvc_SF_WriteStatus(Status1);
        }
    }
}


/* End Of File */
