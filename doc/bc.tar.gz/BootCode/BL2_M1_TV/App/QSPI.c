/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : QSPI_Drv.c
*
*  @brief   : This file is SSP Controller Driver for NEXTCHIP standard library
*
*  @author  : parkjy / SoCSW Team / TS Group
*
*  @date    : 2016.02.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

/*
********************************************************************************
*                               INCLUDE
********************************************************************************
*/
#include "Apache35.h"
#include "QSPI.h"










/*
********************************************************************************
*                              LOCAL DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                           LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                                 LOCAL TYPEDEF
********************************************************************************
*/

/*
********************************************************************************
*                       IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                        GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                       IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                            LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

/*
********************************************************************************
*                             FUNCTION DEFINITIONS
********************************************************************************
*/
void __qspi_delay(UINT32 delay)
{
    while(delay--);
}

BOOL ncDrv_QSPI_WaitFIFOSts(UINT32 TimeOut, UINT32 Offset)
{
    BOOL Ret = FALSE;
    UINT32 Status;
    UINT32 Count;

    for(Count=0; Count<TimeOut; Count++)
    {
        Status = REGRW32(APACHE_QSPI_BASE, rQSPI_SIGSTS);
        if( Status & rQSPI_STS_FULL )
        {
            Ret = TRUE;
            break;
        }

        if( Status & rQSPI_STS_END )
        {
            Ret = FALSE;
            break;
        }
    }

    if(Count>=TimeOut)
        DEBUGMSG_SDK(MSGINFO, " >> QSPI FIFO TimeOut - Sts(0x%08x), Offset(0x%08x)\n" , REGRW32(APACHE_QSPI_BASE, rQSPI_SIGSTS), Offset);
    
    return Ret;
}

BOOL ncDrv_QSPI_WaitBusIsBusy(UINT32 TimeOut)
{
    BOOL Ret = FALSE;
    UINT32 Status;
    UINT32 Count;

    for(Count=0; Count<TimeOut; Count++)
    {
        Status = REGRW32(APACHE_QSPI_BASE, rQSPI_STS);
        if(!(Status&(1<<16)))
        {
            Ret = TRUE;
            break;
        }
    }

    //DEBUGMSG_SDK(MSGINFO, "\n >> QSPI  Wait Count : %d\n", Count);
    return Ret;
}

BOOL ncDrv_QSPI_WaitFrameDone(UINT32 TimeOut)
{
    BOOL Ret = FALSE;
    UINT32 Status;
    UINT32 Count;

    for(Count=0; Count<TimeOut; Count++)
    {
        Status = REGRW32(APACHE_QSPI_BASE, rQSPI_STS);
        if((Status&(1<<22)))
        {
            Ret = TRUE;
            break;
        }
    }

    //DEBUGMSG_SDK(MSGINFO, "    Frame Done Count : %d\n", Count);
    return Ret;
}

void ncDrv_QSPI_Init(void)
{
    UINT32 bitRate;
    
    // QSPI Status Clear - Why?? Read Only Register, 
    REGRW32(APACHE_QSPI_BASE, rQSPI_STS) = 0x0;   

    // 20160216 <r627-a1_2016_0204> issue : address_error 0x1F4000 
    REGRW32(APACHE_QSPI_BASE, rQSPI_EXT_ADDR) = 0xFFFFFFFF; 



    // QSPI Ctrl Register 
    bitRate = REGRW32(APACHE_QSPI_BASE, rQSPI_CTRL) & (0xf<<rQSPI_BRATE);
    REGRW32(APACHE_QSPI_BASE, rQSPI_CTRL) = rQSPI_INT_EN | rQSPI_SCKPOL | rQSPI_EN | bitRate | (0xEB<<0);
}

void ncDrv_QSPI_DeInit(void)
{ 
    // Master Interface Disable
    //REGRW32(APACHE_QSPI_BASE, rQSPI_MICTRL) &= ~(rQSPI_MIEN);
    REGRW32(APACHE_QSPI_BASE, rQSPI_MICTRL) = 0;
		
    // OSG Mode Enable
    REGRW32(APACHE_QSPI_BASE, rQSPI_OSG_DN) = rQSPI_OSG_DIS;

}

INT32 ncDrv_QSPI_MenualReadData(UINT32 Addr, UINT32 BuffAddr, UINT32 Size)
{   
    // OSG Mode Disable
    REGRW32(APACHE_QSPI_BASE, rQSPI_OSG_DN) = rQSPI_OSG_DIS;
    // Master Interface Enable and Data Swap
    REGRW32(APACHE_QSPI_BASE, rQSPI_MICTRL) = rQSPI_MIEN | rQSPI_MIQSWIP | rQSPI_MIHSWIP;    



    // Master Interface Buffer Address
    REGRW32(APACHE_QSPI_BASE, rQSPI_MIADDR) = BuffAddr;
    // Dummy Address
    REGRW32(APACHE_QSPI_BASE, rQSPI_DUMMY) = 0x00FF0000; 
    // sFlash End Address
    REGRW32(APACHE_QSPI_BASE, rQSPI_EADDR) = (Addr+Size-1);
    // sFlash Start Address
    REGRW32(APACHE_QSPI_BASE, rQSPI_SADDR) = Addr;      



    if(!ncDrv_QSPI_WaitBusIsBusy(0x1000000))
    {
        DEBUGMSG_SDK(MSGERR, "\n >> QSPI Wait Busy TimeOut!\n");
    }	

    if(!ncDrv_QSPI_WaitFrameDone(0x1000000))
    {
        DEBUGMSG_SDK(MSGERR, "\n >> QSPI Frame Done TimeOut!\n");
    }	

    return NC_SUCCESS;
}


INT32 ncDrv_QSPI_SetBitRate(UINT32 bitrate)
{
    UINT32 Reg;
    UINT32 baudrate;

    if(bitrate > 40)         baudrate = 0x0E;   // AXI/2
    else if(bitrate == 40)   baudrate = 0x0D;   // AXI/3
    else if(bitrate > 30)    baudrate = 0x0C;   // AXI/4
    else if(bitrate > 20)    baudrate = 0x0B;   // AXI/5
    else if(bitrate > 15)    baudrate = 0x0A;   // AXI/6
    else if(bitrate > 10)    baudrate = 0x09;   // AXI/7
    else if(bitrate > 5)     baudrate = 0x08;   // AXI/8
    else if(bitrate > 3)     baudrate = 0x07;   // AXI/9
    else                     baudrate = 0x06;   // AXI/10

    Reg = REGRW32(APACHE_QSPI_BASE, rQSPI_CTRL) & ~(0xf<<rQSPI_BRATE);
    REGRW32(APACHE_QSPI_BASE, rQSPI_CTRL) = Reg | (baudrate<<rQSPI_BRATE);
    
    return NC_SUCCESS;
}

/* End Of File */

