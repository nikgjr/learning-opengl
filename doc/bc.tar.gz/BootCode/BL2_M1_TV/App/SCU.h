/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SCU_Drv.h
*
*  @brief   : SCU Driver Header File
*
*  @author  : parkjy / SoC SW Team / TS Group
*
*  @date    : 2016.01.27
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/
#ifndef __SCU_DRV_H__
#define __SCU_DRV_H__

/*
********************************************************************************
*                               INCLUDE FILES
********************************************************************************
*/
#include "Test.h"
#include "Apache35.h"
#include "Type.h"










/*
********************************************************************************
*                               DEFINES
********************************************************************************
*/

//------------------------------------------------------------------------------
// SCU Register Structure

#define rSCU_BASE                   APACHE_SYSCON_BASE

#define rSCU_RST_CTRL               0x0000      // RW, SW Reset Control Register
#define rSCU_CLK_EN                 0x0004      // RW, Clock Enable Register
#define rSCU_DMA_CFG                0x0008      // RW, DMA Configuration Register
#define rSCU_DDR_STS                0x000C      // RO, DDR Controller Status Register
#define rSCU_REMAP0_SADDR           0x0010      // RW, Remap0 Start Address Register
#define rSCU_REMAP0_EADDR           0x0014      // RW, Remap0 End Address Register
#define rSCU_REMAP0_OFFSET          0x0018      // RW, Remap0 Offset Address Register
#define rSCU_REMAP0_SET             0x001C      // RW, Remap0 Set Register
#define rSCU_VDO_CLK_DIV            0x0020      // RW, VDO Clock Divider Register
#define rSCU_REMAP1_EADDR           0x0024      // RW, Remap1 End Address Register      - Apache3.5 Not Used
#define rSCU_REMAP1_OFFSET          0x0028      // RW, Remap1 Offset Register           - Apache3.5 Not Used
#define rSCU_REMAP1_SET             0x002C      // RW, Remap1 Set Register              - Apache3.5 Not Used

#define rSCU_STRAP_INFO             0x0080      // R0, Strap Information Register
#define rSCU_PLL_EN                 0x0084      // RW, PLL Enable Register
#define rSCU_PLL_STA                0x0088      // RO, PLL Stable Register
#define rSCU_PLL0_DIV               0x008C      // RW. PLL0 Setting Register
#define rSCU_PLL1_DIV               0x0090      // RW, PLL1 Setting Register
#define rSCU_PLL2_DIV               0x0094      // RW, PLL2 Setting Register
#define rSCU_PLL_BW_ADJ             0x0098      // RW, PLL Bandwidth Adjust Register
#define rSCU_PLL_DIV                0x009C      // RW, PLL Output Divider Register      - Apache3.5 Not Used

#define rSCU_PLL_CLK_SET            0x00A0      // RW, PLL Clock Selection Register
#define rSCU_SYS_CLK_SET            0x00A4      // RW, System Clock Selection Register
#define rSCU_SYS_CLK_DIV            0x00A8      // RW, System Clock Divider Register
#define rSCU_SYS_CLK_DIV2           0x00AC      // RW, System Clock Divider2 Register
#define rSCU_ISP_CLK_SET            0x00B0      // RW, ISP Clock Selection Register
#define rSCU_ISP_CLK_DIV            0x00B4      // RW, ISP Clock Divider Register
#define rSCU_ISP_CLK_DELAY          0x00B8      // RW, ISP Clock Delay Register
#define rSCU_ISP_MODE_SET           0x00BC      // RW, ISP Mode Selection Register

#define rSCU_CHIP_VER               0x0F00      // R0, Chip Version Register

#define rSCU_DBG_00                 0x1030      // RW, Debug Tick Counter Register
#define rSCU_DBG_01                 0x1034
#define rSCU_DBG_02                 0x1038
#define rSCU_DBG_03                 0x103C
#define rSCU_DBG_04                 0x1040
#define rSCU_DBG_05                 0x1044
#define rSCU_DBG_06                 0x1048
#define rSCU_DBG_07                 0x104C
#define rSCU_DBG_08                 0x1050
#define rSCU_DBG_09                 0x1054
#define rSCU_DBG_10                 0x1058
#define rSCU_DBG_11                 0x105C
#define rSCU_DBG_12                 0x1060
#define rSCU_DBG_13                 0x1064
#define rSCU_DBG_14                 0x1068
#define rSCU_DBG_15                 0x106C

#define rSCU_DBG_TICK_CNT           0x1040
#define rSCU_DBG_IRQ                0x1044
#define rSCU_DBG_RST                0x1048
#define rSCU_DBG_TESTID             0x104C

#define rSCU_DBIST_EN               0x1100
#define rSCU_DBIST_CTRL0            0x1104
#define rSCU_DBIST_CTRL1            0x1108
#define rSCU_DBIST_COMP             0x110C
#define rSCU_DBIST_INIT0            0x1110
#define rSCU_DBIST_INIT1            0x1114
#define rSCU_DBIST_INIT2            0x1118
#define rSCU_DBIST_INIT3            0x111C



//------------------------------------------------------------------------------
// Register Field



#define rSCU_PLL_ENABLE         0x0084
#define PLL2_BYPS               (1<<6)
#define PLL1_BYPS               (1<<5)
#define PLL0_BYPS               (1<<4)
#define PLL2_RESET              (1<<2)
#define PLL1_RESET              (1<<1)
#define PLL0_RESET              (1<<0)

#define rSCU_PLL_STABLE         0x0088
#define PLL2_STBL               (1<<2)
#define PLL1_STBL               (1<<1)
#define PLL0_STBL               (1<<0)

#define rSCU_PLL0_CONFIG        0x008C
#define rSCU_PLL1_CONFIG        0x0090
#define rSCU_PLL2_CONFIG        0x0094
#define PLL_NF                  16
#define PLL_NR                  8
#define PLL_OD                  0

#define rSCU_PLL_BWADJ          0x0098
#define PLL2_BWADJ              16
#define PLL1_BWADJ              8
#define PLL0_BWADJ              0

#define rSCU_PLL_PD             0x009C

#define rSCU_PLL_CLK_SEL        0x00A0
#define PLL2_OUTSEL             8
#define PLL1_OUTSEL             4
#define PLL0_OUTSEL             0
#define INPUT_OSC               0
#define OUT_REV                 1
#define OUTPUT_PLL              2
#define EXT_CLK                 3

#define rSCU_SYS_CLK_SEL        0x00A4
#define SEL_CAN_CLK             4
#define SEL_SYS_CLK             0
#define SYS_PLL0                0
#define SYS_PLL1                1
#define SYS_PLL2                2
#define SYS_OSC                 3

#define rSCU_SYS_CLK_DIV1       0x00A8
#define DIV_ADC_CLK             24
#define DIV_CAN_CLK             16
#define DIV_DDR_CLK             12
#define DIV_APB_CLK             8
#define DIV_AXI_CLK             4
#define DIV_CPU_CLK             0

#define rSCU_SYS_CLK_DIV2       0x00AC
#define DIV_TS_CLK              0

#define rSCU_ISP_CLK_SEL        0x00B0
#define rSCU_ISP_CLK_DIV        0x00B4
#define rSCU_ISP_CLK_DLY        0x00B8
#define rSCU_ISP_MODE_SEL       0x00BC

//------------------------------------------------------------------------------
// ICU Register Structure

#define rICU_BASE                   APACHE_ICU_BASE

// ICU v1.0
#define rICU_GPIO0                  0x0128
#define rICU_GPIO1                  0x012C
#define rICU_GPIO2                  0x0130
#define rICU_GPIO3                  0x0134
#define rICU_GPIO4                  0x0138
#define rICU_EXTINT                 0x0150

#define rICU_I2C0_SCL               0x01B8
#define rICU_I2C0_SDA               0x01B4
#define rICU_I2C1_SCL               0x00DC
#define rICU_I2C1_SDA               0x00D8

#define rICU_CAN_RX                 0x0124
#define rICU_CAN_TX                 0x0120
#define rICU_UART_RX                0x011C
#define rICU_UART_TX                0x0118

#define rICU_SPI2_CSN0              0x00C4
#define rICU_SPI2_CSN1              0x00BC
#define rICU_SPI2_DQ0               0x00D4
#define rICU_SPI2_DQ1               0x00CC
#define rICU_SPI2_DQ2               0x00E0
#define rICU_SPI2_DQ3               0x00E4
#define rICU_SPI2_SCK               0x00C8

#define rICU_SEN_CK_O               0x0204
#define rICU_SEN_RSTN_O             0x01FC
#define rICU_SEN_PCK                0x0200
#define rICU_SEN_PH                 0x0208
#define rICU_SEN_PV                 0x020C
#define rICU_SEN_PD0                0x0210
#define rICU_SEN_PD1                0x0214
#define rICU_SEN_PD2                0x0034
#define rICU_SEN_PD3                0x0038
#define rICU_SEN_PD4                0x003C
#define rICU_SEN_PD5                0x0040
#define rICU_SEN_PD6                0x0044
#define rICU_SEN_PD7                0x0048
#define rICU_SEN_PD8                0x0088
#define rICU_SEN_PD9                0x008C
#define rICU_SEN_PD10               0x0090
#define rICU_SEN_PD11               0x0094

#define rICU_VOUT_CK_O              0x00F8
#define rICU_VOUT_VSYNC             0x00F0
#define rICU_VOUT_HSYNC             0x00EC
#define rICU_VOUT_HACT              0x00F4
#define rICU_VOUT_B0                0x0140
#define rICU_VOUT_B1                0x0114
#define rICU_VOUT_B2                0x0110
#define rICU_VOUT_B3                0x010C
#define rICU_VOUT_B4                0x0108
#define rICU_VOUT_B5                0x0104
#define rICU_VOUT_B6                0x0100
#define rICU_VOUT_B7                0x00FC
#define rICU_VOUT_G0_C0             0x0164
#define rICU_VOUT_G1_C1             0x0160
#define rICU_VOUT_G2_C2             0x015C
#define rICU_VOUT_G3_C3             0x0158
#define rICU_VOUT_G4_C4             0x0154
#define rICU_VOUT_G5_C5             0x014C
#define rICU_VOUT_G6_C6             0x0148
#define rICU_VOUT_G7_C7             0x0144
#define rICU_VOUT_R0_Y0             0x0188
#define rICU_VOUT_R1_Y1             0x0184
#define rICU_VOUT_R2_Y2             0x0180
#define rICU_VOUT_R3_Y3             0x017C
#define rICU_VOUT_R4_Y4             0x0178
#define rICU_VOUT_R5_Y5             0x0170
#define rICU_VOUT_R6_Y6             0x016C
#define rICU_VOUT_R7_Y7             0x0168


// ICU v2.0
#define rICU_MUX_00                 0x0000
#define rICU_MUX_04                 0x0004
#define rICU_MUX_08                 0x0008
#define rICU_MUX_0C                 0x000C
#define rICU_MUX_10                 0x0010
#define rICU_MUX_14                 0x0014
#define rICU_MUX_18                 0x0018
#define rICU_MUX_1C                 0x001C
#define rICU_MUX_20                 0x0020









/*
********************************************************************************
*                               ENUMERATION
********************************************************************************
*/

typedef enum _SCU_BOARD_TYPE
{
    SCU_BD_TYPE_FPGA_01 = 0,    // apache3p5_2016_0113 - Not Support
    SCU_BD_TYPE_FPGA_02,        // r560-a1_2016_0126
    SCU_BD_TYPE_FPGA_03,        // r560-a8_2016_0131
    SCU_BD_TYPE_FPGA_04,        // r627-a1_2016_0204
    SCU_BD_TYPE_FPGA_05,        // r730-a1_2016_0222
    SCU_BD_TYPE_FPGA_06,        // r844-a1_2016_0308
    SCU_BD_TYPE_FPGA_07,        // r1061-a1_2016_0325
    SCU_BD_TYPE_FPGA_08,
    SCU_BD_TYPE_FPGA_09,
    SCU_BD_TYPE_FPGA_10,
    SCU_BD_TYPE_ES,
    SCU_BD_TYPE_MAX
} eSCU_BOARD_TYPE;

typedef enum _SCU_CMD
{
    /*
     * Generic SCU Commands
     */
    GCMD_SCU_GET_STRAP_INFO = 0,
    GCMD_SCU_GET_CLK,

    GCMD_SCU_SET_PINMUX,
    GCMD_SCU_SET_PINMUX_GROUP,      // Apache3.5 Not Used

    GCMD_SCU_GET_DATA,
    GCMD_SCU_SET_DATA,

    GCMD_SCU_GET_MP2V,
    GCMD_SCU_GET_MV2P,

    GCMD_SCU_MAX,

    /*
     * Specific SCU Commands
     */
    SCMD_SCU_DB_NUM = 100,
    SCMD_SCU_MAX,
} eSCU_CMD;

/*
 * Clock ID for Apache3.5
 */
typedef enum _SCU_CLK_ID
{
    SCU_CLK_ID_CPU = 0,     // CPU Clock
    SCU_CLK_ID_AXI,         // AXI0 Clock
    SCU_CLK_ID_AHB,         // Apache3.5 Not Used
    SCU_CLK_ID_APB,         // APB Clock
    SCU_CLK_ID_ENC,         // Apache3.5 Not Used
    SCU_CLK_ID_SSPI,        // Standard SPI Clock
    SCU_CLK_ID_QSPI,        // Quad SPI Clock for sFlash
    SCU_CLK_ID_UART,        // UART Clock
    SCU_CLK_ID_TIMER,       // Timer Clock
    SCU_CLK_ID_WDT,         // WDT Clock
    SCU_CLK_ID_I2C,         // I2C Clock
    SCU_CLK_ID_CAN,         // CAN Clock
    SCU_CLK_ID_DDR,         // DDR Clock

    SCU_CLK_ID_IISP,
    SCU_CLK_ID_MISP,
    SCU_CLK_ID_OISP,
    SCU_CLK_ID_OF,
    SCU_CLK_ID_656,
    SCU_CLK_ID_VDO,
    SCU_CLK_ID_CVBS,
    SCU_CLK_ID_VEN,
    SCU_CLK_ID_DAC,
    SCU_CLK_ID_WDR,
    SCU_CLK_ID_OSG,
    SCU_CLK_ID_LDC,
    SCU_CLK_ID_OSD,
    SCU_CLK_ID_ADC,
    SCU_CLK_ID_TS,

    SCU_CLK_ID_MAX
} eSCU_CLK_ID;

/*
 * Pad ID for Apache3.5
 */
typedef enum _PAD_ID
{
    PAD_GPIO0 = 0,
    PAD_GPIO1,
    PAD_GPIO2,
    PAD_GPIO3,
    PAD_GPIO4,
    PAD_EXTINT,

    PAD_I2C0_SCL,
    PAD_I2C0_SDA,
    PAD_I2C1_SCL,
    PAD_I2C2_SDA,

    PAD_CAN_RX,
    PAD_CAN_TX,
    PAD_UART_RX,
    PAD_UART_TX,

    PAD_SPI2_CSN0,
    PAD_SPI2_CSN1,
    PAD_SPI2_DQ0,
    PAD_SPI2_DQ1,
    PAD_SPI2_DQ2,
    PAD_SPI2_DQ3,
    PAD_SPI2_SCK,

    PAD_SEN_CK_O,
    PAD_SEN_RSTN_O,
    PAD_SEN_PCK,
    PAD_SEN_PH,
    PAD_SEN_PV,
    PAD_SEN_PD0,
    PAD_SEN_PD1,
    PAD_SEN_PD2,
    PAD_SEN_PD3,
    PAD_SEN_PD4,
    PAD_SEN_PD5,
    PAD_SEN_PD6,
    PAD_SEN_PD7,
    PAD_SEN_PD8,
    PAD_SEN_PD9,
    PAD_SEN_PD10,
    PAD_SEN_PD11,

    PAD_VOUT_CK_O,
    PAD_VOUT_VSYNC,
    PAD_VOUT_HSYNC,
    PAD_VOUT_HACT,
    PAD_VOUT_B0,
    PAD_VOUT_B1,
    PAD_VOUT_B2,
    PAD_VOUT_B3,
    PAD_VOUT_B4,
    PAD_VOUT_B5,
    PAD_VOUT_B6,
    PAD_VOUT_B7,
    PAD_VOUT_G0_C0,
    PAD_VOUT_G1_C1,
    PAD_VOUT_G2_C2,
    PAD_VOUT_G3_C3,
    PAD_VOUT_G4_C4,
    PAD_VOUT_G5_C5,
    PAD_VOUT_G6_C6,
    PAD_VOUT_G7_C7,
    PAD_VOUT_R0_Y0,
    PAD_VOUT_R1_Y1,
    PAD_VOUT_R2_Y2,
    PAD_VOUT_R3_Y3,
    PAD_VOUT_R4_Y4,
    PAD_VOUT_R5_Y5,
    PAD_VOUT_R6_Y6,
    PAD_VOUT_R7_Y7,

    PAD_MAX
} ePAD_ID;

typedef enum _PAD_FUNC
{
    PAD_FUNC_0 = 0,
    PAD_FUNC_1,
    PAD_FUNC_2,
    PAD_FUNC_3,
    PAD_FUNC_4,

    PAD_FUNC_MAX
} ePAD_FUNC;






/*
********************************************************************************
*                               TYPEDEFS
********************************************************************************
*/

/*
********************************************************************************
*                               CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                               VARIABLE DECLARATIONS
********************************************************************************
*/

/*
********************************************************************************
*                               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32  ncDrv_SCU_Init(void);
extern INT32  ncDrv_SCU_DeInit(void);
extern UINT32 ncDrv_SCU_GetBootStrap(void);
extern INT32  ncDrv_SCU_SetPinMux(UINT32 Pad, UINT32 Func);
extern INT32  ncDrv_SCU_GetSystemClock(UINT32 nClkType);
extern UINT32 ncDrv_SCU_GetData(UINT32 addr);
extern UINT32 ncDrv_SCU_SetData(UINT32 addr, UINT32 data);
extern UINT32 ncDrv_SCU_Virtual2Physical(UINT32 addr);
extern UINT32 ncDrv_SCU_Physical2Virtual(UINT32 addr);
extern INT32  ncDrv_SCU_GetDBNum(void);
extern void ncDrv_SCU_mDelay(UINT32 mSec);
UINT32 ncDrv_SCU_GetApbClock(void);
UINT32 ncDrv_SCU_GetCanClock(void);


#endif  /* __SCU_DRV_H__ */


/* End Of File */
