/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.c
*
*  @brief   : This file is implemented about main of SR-ES TEST VECTOR (FUNC1 SF)
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  History  : TM_FUNC1_SF (for EDS, PLL/DDR Bypass)
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

typedef struct _tSFTEST_FLAG
{
    BOOL        QuadMode;
    BOOL        DMAMode;
    SF_BITRATE  BitRate;
} tSFEST_FLAG, *ptSFTEST_FLAG;


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

extern UINT32 gnSSPInClock;


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

tSFEST_FLAG tSFTestFlag = { FALSE, FALSE, SF_BITRATE_5Mbps };
BOOL g_sram_remap = 0;

UINT8 g_test_tx_data[TEST_DATA_SZIE];
UINT8 g_test_rx_data[TEST_DATA_SZIE];
BOOL g_intr_asserted;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

void APACHE_TEST_INIT(void);
void APACHE_TEST_GPIO_INIT(void);
void APACHE_TEST_GPIO_INIT_ADC_BGR(void);
void APACHE_TEST_GPIO_CONTROL(TEST_VECTOR tv, INT32 result);
void APACHE_TEST_INIT_DATA(void);
INT32 APACHE_TEST_VALIDATE_DATA(void);
void APACHE_TEST_SUB_TIMER_UserInterruptHandler(void);
void APACHE_TEST_SetSystemRemap(void);

INT32 APACHE_TEST_QSPI(void);
INT32 APACHE_TEST_SUB_TIMER(TIMER_CH channel);
INT32 APACHE_TEST_TIMER(TIMER_CH channel);
INT32 APACHE_TEST_CAN(void);
INT32 APACHE_TEST_I2C(void);
UINT32 APACHE_TEST_UART(UINT32 channel);


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void __test_sf_buff_pageaddr_marking(UINT8 *pData, UINT32 PageAddr)
{
    pData[0] = (PageAddr>>24 & 0xFF);
    pData[1] = (PageAddr>>16 & 0xFF);
    pData[2] = (PageAddr>>8  & 0xFF);
    pData[3] = (PageAddr     & 0xFF);

    pData[SF_PAGE_SIZE-4] = (PageAddr>>24 & 0xFF);
    pData[SF_PAGE_SIZE-3] = (PageAddr>>16 & 0xFF);
    pData[SF_PAGE_SIZE-2] = (PageAddr>>8  & 0xFF);
    pData[SF_PAGE_SIZE-1] = (PageAddr     & 0xFF);
}


static void __test_sf_dumy_buff(UINT8 *pData, UINT32 size)
{
    UINT32 i;

    for(i = 0; i < size; i++)
    {
        *pData++ = i;
    }
}


static void __test_sf_clear_buff(UINT8 *pData, UINT32 size)
{
    UINT32 i;

    for(i = 0; i < size; i++)
    {
        *pData++ = 0x0;
    }
}


static INT32 __test_sf_compare_buff(UINT8 *src, UINT8 *dst, UINT32 size)
{
    UINT32 i;
    INT32 ret = NC_SUCCESS;

    for(i = 0; i < size; i++)
    {
    	if(src[i] != dst[i])
    	{
    		ret = NC_FAILURE;
    		break;
    	}
    }

    return ret;
}


void APACHE_TEST_INIT(void)
{
    ncDrv_SCU_Init();
	ncDrv_GIC_Initialize();
	GIC_InitIntHandler();
}


void APACHE_TEST_GPIO_INIT(void)
{
	/* Group-B GPIO Pin Mux */
	ncDrv_SCU_SetPinMux(PAD_VOUT_CK_O, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_VSYNC, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_HSYNC, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_HACT, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B0, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B1, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B2, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B3, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B4, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B5, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B6, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B7, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G0_C0, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G1_C1, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G2_C2, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G3_C3, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G4_C4, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G5_C5, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G6_C6, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G7_C7, PAD_FUNC_4);

	/* Group-B GPIO Pin Direction */
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT4, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT5, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT6, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT7, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT8, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT9, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT10, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT11, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT12, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT13, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT14, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT15, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT16, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT17, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT18, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT19, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT20, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT21, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT22, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT23, GPIO_DIR_OUT, rGPIO_V2_DIR0);

	/* Group-B GPIO Pin Port Initialize */
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT4, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT5, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT6, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT7, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT8, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT9, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT10, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT11, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT12, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT13, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT14, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT15, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT16, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT17, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT18, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT19, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT20, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT21, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT22, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT23, GPIO_LOW, rGPIO_V2_OUT_PORT0);

	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT30, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT31, GPIO_LOW, rGPIO_V2_OUT_PORT0);
}


void APACHE_TEST_GPIO_INIT_ADC_BGR(void)
{
	/* Group-B GPIO Pin Mux */
	ncDrv_SCU_SetPinMux(PAD_CAN_RX, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_CAN_TX, PAD_FUNC_4);

	ncDrv_SCU_SetPinMux(PAD_SEN_PD8, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_SEN_PD9, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_SEN_PD10, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_SEN_PD11, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_CK_O, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_VSYNC, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_HSYNC, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_HACT, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B0, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B1, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B2, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B3, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B4, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B5, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B6, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_B7, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G0_C0, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G1_C1, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G2_C2, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G3_C3, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G4_C4, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G5_C5, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G6_C6, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_G7_C7, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_R0_Y0, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_R1_Y1, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_R2_Y2, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_R3_Y3, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_R4_Y4, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_R5_Y5, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_R6_Y6, PAD_FUNC_4);
	ncDrv_SCU_SetPinMux(PAD_VOUT_R7_Y7, PAD_FUNC_4);

	/* Group-B GPIO Pin Direction */
	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT8, GPIO_DIR_IN, rGPIO_V2_DIR0);	// ADC Clock Select
	ncDrv_GPIO_SetDirection(GPIO_GROUP_A, GPIO_PORT9, GPIO_DIR_IN, rGPIO_V2_DIR0);	// Serial Flash Update

#if TEST_ADC_RTC_BGR_3RD
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT29, GPIO_DIR_IN, rGPIO_V2_DIR0);	// Test Temperature Environ Select 0
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT30, GPIO_DIR_IN, rGPIO_V2_DIR0);	// Test Temperature Environ Select 1
#endif

	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT0, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT1, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT2, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT3, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT4, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT5, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT6, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT7, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT8, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT9, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT10, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT11, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT12, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT13, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT14, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT15, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT16, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT17, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT18, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT19, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT20, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT21, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT22, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT23, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT24, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT25, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT26, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT27, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT28, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT29, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT30, GPIO_DIR_OUT, rGPIO_V2_DIR0);
	ncDrv_GPIO_SetDirection(GPIO_GROUP_B, GPIO_PORT31, GPIO_DIR_OUT, rGPIO_V2_DIR0);

	/* Group-B GPIO Pin Port Initialize */
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT0, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT1, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT2, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT3, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT4, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT5, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT6, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT7, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT8, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT9, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT10, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT11, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT12, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT13, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT14, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT15, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT16, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT17, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT18, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT19, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT20, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT21, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT22, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT23, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT24, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT25, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT26, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT27, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT28, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	//ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT29, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	//ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT30, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT31, GPIO_LOW, rGPIO_V2_OUT_PORT0);
}


void APACHE_TEST_GPIO_CONTROl(TEST_VECTOR tv, INT32 result)
{
	eGPIO_DATA gpio_result = GPIO_HIGH;
	UINT32 dealy = GPIO_DEALY;

	if(result == NC_SUCCESS)
		gpio_result = GPIO_HIGH;
	else
		gpio_result = GPIO_LOW;

	switch(tv)
	{
		case TV_UART_0:
		{
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT4, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
			ncDrv_SCU_mDelay(dealy);
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT5, gpio_result, rGPIO_V2_OUT_PORT0);
		}
		break;

		case TV_UART_1:
		{
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT6, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
			ncDrv_SCU_mDelay(dealy);
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT7, gpio_result, rGPIO_V2_OUT_PORT0);
		}
		break;

		case TV_CAN:
		{
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT8, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
			ncDrv_SCU_mDelay(dealy);
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT9, gpio_result, rGPIO_V2_OUT_PORT0);
		}
		break;

		case TV_I2C:
		{
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT10, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
			ncDrv_SCU_mDelay(dealy);
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT11, gpio_result, rGPIO_V2_OUT_PORT0);
		}
		break;

		case TV_TIMER_0:
		{
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT12, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
			ncDrv_SCU_mDelay(dealy);
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT13, gpio_result, rGPIO_V2_OUT_PORT0);
		}
		break;

		case TV_TIMER_1:
		{
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT14, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
			ncDrv_SCU_mDelay(dealy);
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT15, gpio_result, rGPIO_V2_OUT_PORT0);
		}
		break;

		case TV_SUB_TIMER_0:
		{
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT16, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
			ncDrv_SCU_mDelay(dealy);
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT17, gpio_result, rGPIO_V2_OUT_PORT0);
		}
		break;

		case TV_SUB_TIMER_1:
		{
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT18, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
			ncDrv_SCU_mDelay(dealy);
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT19, gpio_result, rGPIO_V2_OUT_PORT0);
		}
		break;

		case TV_SUB_TIMER_2:
		{
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT20, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
			ncDrv_SCU_mDelay(dealy);
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT21, gpio_result, rGPIO_V2_OUT_PORT0);
		}
		break;

		case TV_SPI:
		{
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT22, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
			ncDrv_SCU_mDelay(dealy);
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT23, gpio_result, rGPIO_V2_OUT_PORT0);
		}
		break;

		case TV_QSPI:
		{
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT30, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
			ncDrv_SCU_mDelay(dealy);
			ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT31, gpio_result, rGPIO_V2_OUT_PORT0);
		}
		break;

		default:
		break;
	}
}


void APACHE_TEST_INIT_DATA(void)
{
	UINT32 i;

	for(i = 0; i < TEST_DATA_SZIE; i++)
	{
		g_test_tx_data[i] = i;
		g_test_rx_data[i] = 0;
	}
}


INT32 APACHE_TEST_VALIDATE_DATA(void)
{
	INT32 ret = NC_SUCCESS;
	UINT32 i;

	for(i = 0; i < TEST_DATA_SZIE; i++)
	{
		if(g_test_tx_data[i] != g_test_rx_data[i])
		{
			ret = NC_FAILURE;
			break;
		}
	}

	return ret;
}


void APACHE_TEST_SUB_TIMER_UserInterruptHandler(void)
{
	g_intr_asserted = TRUE;
}


void APACHE_TEST_SetSystemRemap(void)
{
    UINT32 nTemp, i;
    PrVoid PC_CountReset = (PrVoid)NULL;

    REGRW32(SYS_CON_BASE, SYSCON_REMAP_START)  = 0x00000000;
    REGRW32(SYS_CON_BASE, SYSCON_REMAP_END)    = SRAM_BASE_ADDRESS;
    REGRW32(SYS_CON_BASE, SYSCON_REMAP_ENABLE) = 1;
    g_sram_remap = TRUE;

#if 1 // v0.9.3 add
    while(1)
    {
        for(i = 0; i < 5; i++)
        {
            nTemp = REGRW32(SYS_CON_BASE, SYSCON_REMAP_ENABLE);
        }

        if(nTemp)
        {
            PC_CountReset();
        }
    }
#else
    PC_CountReset();
#endif
}


INT32 APACHE_TEST_QSPI(void)
{
    UINT32 i, Offset;
    UINT32 Addr = 0;
    UINT32 sAddr = SF_TEST_START_PAGE * SF_PAGE_SIZE;
    UINT32 eAddr = (SF_TEST_END_PAGE+1) * SF_PAGE_SIZE-1;
    UINT8  wBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
    UINT8  rBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
    tSF_INIT_PARAM tsFlashParam;
    tSFLASH_ID tFlashID;
	INT32 ret = NC_SUCCESS;

    gnSSPInClock = ncDrv_SCU_GetApbClock();

    /* Generate Write Data */
    __test_sf_dumy_buff(wBuff, SF_PAGE_SIZE);

    /*
     * SPI channel 0 test
     */
    tsFlashParam.mChNum 	= 0;
    tsFlashParam.mDmaMode	= FALSE;
    tsFlashParam.mQuadMode	= TRUE;
    tsFlashParam.mBitRate	= SF_BITRATE_40Mbps;

    ret = ncSvc_SF_Init(&tsFlashParam);

    if(ret == NC_FAILURE)
    {
    	goto SPI_Exit;
    }

    ncSvc_SF_ReadDeviceIdentification(&tFlashID);
    ret = ncSvc_SF_ReadData(Addr, rBuff, 4);


    /* Chip Erase and Write Pattern */
    for(Addr = sAddr; Addr < eAddr; Addr += SF_SECTOR_SIZE)
    {
    	ncSvc_SF_SectorErase(Addr);

        for(Offset = Addr; Offset < eAddr; Offset += SF_PAGE_SIZE)
        {
            __test_sf_buff_pageaddr_marking(wBuff, Offset);
            ncSvc_SF_WriteData(Offset, (UINT8 *)wBuff, SF_PAGE_SIZE);
        }
    }


    /* Data Read and Compare Data */
	for(Offset = sAddr; Offset < eAddr; Offset += SF_PAGE_SIZE)
	{
		__test_sf_clear_buff(rBuff, SF_PAGE_SIZE);
		ncSvc_SF_ReadData(Offset, rBuff, SF_PAGE_SIZE);

		__test_sf_buff_pageaddr_marking(wBuff, Offset);
		ret = __test_sf_compare_buff(rBuff, wBuff, SF_PAGE_SIZE);

		APACHE_TEST_GPIO_CONTROl(TV_QSPI, ret);
		ncDrv_SCU_mDelay(GPIO_DEALY);
		ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT30, GPIO_LOW, rGPIO_V2_OUT_PORT0);
		ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT31, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	}

    ncSvc_SF_Release();

SPI_Exit:

	return ret;
}


INT32 APACHE_TEST_SPI(void)
{
    UINT32 i = 0;
    UINT32 Addr = 0;
    UINT8  rBuff[4] __attribute__ ((aligned (8))) = {0,};
    tSF_INIT_PARAM tsFlashParam;
    tSFLASH_ID tFlashID;
	INT32 ret = NC_SUCCESS;

    gnSSPInClock = ncDrv_SCU_GetApbClock();


    /*
     * SPI channel 0 test
     */
    tsFlashParam.mChNum 	= 0;
    tsFlashParam.mDmaMode	= tSFTestFlag.DMAMode;
    tsFlashParam.mQuadMode	= tSFTestFlag.QuadMode;
    tsFlashParam.mBitRate	= tSFTestFlag.BitRate;

    ret = ncSvc_SF_Init(&tsFlashParam);

    if(ret == NC_FAILURE)
    {
    	goto SPI_Exit;
    }

    ncSvc_SF_ReadDeviceIdentification(&tFlashID);
    ret = ncSvc_SF_ReadData(Addr, rBuff, 4);

    if(!((rBuff[0] == 'A') && (rBuff[1] == 'P') && (rBuff[2] == '3') && (rBuff[3] == '5')))
    {
    	ret = NC_FAILURE;
    }

    ncSvc_SF_Release();

    for(i = 0; i < 4; i++)
    {
        rBuff[i] = 0;
    }


    /*
     * SPI channel 1 test
     */
    tsFlashParam.mChNum     = 1;
    tsFlashParam.mDmaMode   = tSFTestFlag.DMAMode;
    tsFlashParam.mQuadMode  = tSFTestFlag.QuadMode;
    tsFlashParam.mBitRate   = tSFTestFlag.BitRate;

    ret = ncSvc_SF_Init(&tsFlashParam);

    if(ret == NC_FAILURE)
    {
        goto SPI_Exit;
    }

    ncSvc_SF_ReadDeviceIdentification(&tFlashID);
    ret = ncSvc_SF_ReadData(Addr, rBuff, 4);

    if(!((rBuff[0] == 'A') && (rBuff[1] == 'P') && (rBuff[2] == '3') && (rBuff[3] == '5')))
    {
        ret = NC_FAILURE;
    }

SPI_Exit:

	return ret;
}


INT32 APACHE_TEST_SUB_TIMER(TIMER_CH channel)
{
	INT32 i = 0;
	UINT32 wait_cnt = SUB_TIMER_TIME_OUT;
	tTC_INIT_PARAM 	tTimerParam;
	INT32 ret = NC_SUCCESS;

	ncDrv_TIMER_Open(ncDrv_SCU_GetApbClock());

	if(channel == TC_CH2)
	{
		GIC_RegisterHandler(IRQ_NUM_SUB_TIMER0, (PrHandler)ncDrv_TIMER_IRQ_Handler2);
		ncDrv_GIC_EnableIrq(IRQ_NUM_SUB_TIMER0);
		ncDrv_TIMER_ConnectUserHandler(TC_CH2, (PrVoid)APACHE_TEST_SUB_TIMER_UserInterruptHandler);
	}
	else if(channel == TC_CH3)
	{
		GIC_RegisterHandler(IRQ_NUM_SUB_TIMER1, (PrHandler)ncDrv_TIMER_IRQ_Handler3);
		ncDrv_GIC_EnableIrq(IRQ_NUM_SUB_TIMER1);
		ncDrv_TIMER_ConnectUserHandler(TC_CH3, (PrVoid)APACHE_TEST_SUB_TIMER_UserInterruptHandler);
	}
	else if(channel == TC_CH4)
	{
		GIC_RegisterHandler(IRQ_NUM_SUB_TIMER2, (PrHandler)ncDrv_TIMER_IRQ_Handler4);
		ncDrv_GIC_EnableIrq(IRQ_NUM_SUB_TIMER2);
		ncDrv_TIMER_ConnectUserHandler(TC_CH4, (PrVoid)APACHE_TEST_SUB_TIMER_UserInterruptHandler);
	}
	else
	{
		ret = NC_FAILURE;
		goto SUB_TIMER_Exit;
	}

	tTimerParam.mMode		= TC_MODE_PWM;
    tTimerParam.mPrescaler	= 0;
    tTimerParam.mPeriod1 	= SUB_TIMER_PERIOD;

   	g_intr_asserted = FALSE;

   	ncDrv_TIMER_Init(channel, &tTimerParam);
	ncDrv_TIMER_Start(channel);

	i = 0;
	while(1)
	{
		if(g_intr_asserted == TRUE)
		{
			break;
		}

		if(i > wait_cnt)
		{
			ret = NC_FAILURE;
			goto SUB_TIMER_Exit;
		}

		i++;
	}

	ncDrv_TIMER_Stop(channel);

SUB_TIMER_Exit:

	return ret;
}


INT32 APACHE_TEST_TIMER(TIMER_CH channel)
{
	INT32 i = 0;
	UINT32 wait_cnt = TIMER_TIME_OUT;
	tTC_INIT_PARAM 	tTimerParam;
	INT32 ret = NC_SUCCESS;

	ncDrv_TIMER_Open(ncDrv_SCU_GetApbClock());

	if(channel == TC_CH0)
	{
		GIC_RegisterHandler(IRQ_NUM_TIMER0, (PrHandler)ncDrv_TIMER_IRQ_Handler0);
		ncDrv_GIC_EnableIrq(IRQ_NUM_TIMER0);
	}
	else if(channel == TC_CH1)
	{
		GIC_RegisterHandler(IRQ_NUM_TIMER1, (PrHandler)ncDrv_TIMER_IRQ_Handler1);
		ncDrv_GIC_EnableIrq(IRQ_NUM_TIMER1);
	}
	else
	{
		ret = NC_FAILURE;
		goto TIMER_Exit;
	}

	tTimerParam.mPrescaler		= 1;
    tTimerParam.mMode			= TC_MODE_ONESHOT;
    tTimerParam.mPeriod1 		= TIMER_PERIOD;

    ncDrv_TIMER_Init(channel, &tTimerParam);
    ncDrv_TIMER_Start(channel);

	i = 0;
	while(1)
	{
		if(ncDrv_TIMER_GetOneShotModeDone(channel) == TRUE)
		{
			break;
		}

		if(i > wait_cnt)
		{
			ret = NC_FAILURE;
			goto TIMER_Exit;
		}

		i++;
	}

	ncDrv_TIMER_Stop(channel);

TIMER_Exit:

	return ret;
}


INT32 APACHE_TEST_CAN(void)
{
	UINT32 i=0;
    tCAN_PARAM param;
    tCAN_MSG rx_msg;
    tCAN_INFO info;
	tCAN_MSG tx_msg =
	{   // CAN_DEVICE_TEST_ID
		0x1FF,
		0x01,
		{0x00,},
		CAN_MSGOBJ_ACTIVE,
		CAN_FI_STANDARD_FORMAT,
		CAN_FI_DATA_FRAME
	};
	INT32 ret = NC_SUCCESS;

    ncDrv_SCU_SetPinMux(PAD_CAN_RX, PAD_FUNC_0);    // uart_rx0   -> can_rx
    ncDrv_SCU_SetPinMux(PAD_CAN_TX, PAD_FUNC_0);    // uart_tx0   -> can_tx

    info.format = CAN_FI_STANDARD_FORMAT;
    info.baudrate = CAN_BPS_125KBPS;

    param.acrId = 0xFF;
    param.amrId = 0xFF;
    param.baudrate = info.baudrate;
    param.info = info;

    APACHE_TEST_INIT_DATA();

    ncDrv_CAN_Initialize();
    //ncDrv_CAN_PeriSetup(16000000, &param);
    ncDrv_CAN_PeriSelfTest_Setup(ncDrv_SCU_GetCanClock(), &param);

    for(i = 0; i < TEST_DATA_SZIE; i++)
    {
    	tx_msg.data[0] = g_test_tx_data[i];

    	ncDrv_CAN_PeriSelfTest_Send(&tx_msg);
    	ncDrv_CAN_PeriReceive(&rx_msg);

    	g_test_rx_data[i] = rx_msg.data[0];
    }

	if(APACHE_TEST_VALIDATE_DATA() == NC_FAILURE)
	{
		ret = NC_FAILURE;
		goto CAN_Exit;
	}

CAN_Exit:

	ncDrv_CAN_Deinitialize();

	return ret;
}


INT32 APACHE_TEST_I2C(void)
{
	UINT32 i = 0;
	UINT8 slave_rx_buf[4] = {0,};
    tI2C_INFO i2c0;
    tI2C_INFO i2c1;
	INT32 ret = NC_SUCCESS;

    ncDrv_SCU_SetPinMux(PAD_I2C0_SCL, PAD_FUNC_0);    // i2c0_scl
    ncDrv_SCU_SetPinMux(PAD_I2C0_SDA, PAD_FUNC_0);    // i2c0_sda
    ncDrv_SCU_SetPinMux(PAD_I2C1_SCL, PAD_FUNC_0);    // i2c1_scl
    ncDrv_SCU_SetPinMux(PAD_I2C2_SDA, PAD_FUNC_0);    // i2c1_sda

    /*
     * I2C_CH0 : Mater   I2C_CH1 : Slave
     */
    i2c0.channel = I2C_CH0;
    i2c0.mode = I2C_OP_MODE_MASTER;
    i2c0.byteOrder = I2C_LITTLE_ENDIAN;
    i2c0.type = I2C_ADDR_8_DATA_8;
    i2c0.master.id = 0xC0;          // device id ???
    i2c0.master.clock = I2C_BITRATE_30KBPS;
    i2c0.master.txBuf = (UINT8 *)0;
    i2c0.slave.rxBuf = (UINT8 *)0;
    i2c0.master.txIdx = 0;
    i2c0.slave.rxIdx = 0;

    ncDrv_I2C_MasterInitialize(&i2c0);
    ncDrv_I2C_SetClock(I2C_CH0, ncDrv_SCU_GetApbClock(), i2c0.master.clock);

    i2c1.channel = I2C_CH1;
    i2c1.mode = I2C_OP_MODE_SLAVE;
    i2c1.byteOrder = I2C_LITTLE_ENDIAN;
    i2c1.type = I2C_ADDR_8_DATA_8;
    i2c1.slave.id = 0xC0;           // device id ???
    i2c1.master.txBuf = (UINT8*)0;
    i2c1.slave.rxBuf = slave_rx_buf;
    i2c1.master.txIdx = 0;
    i2c1.slave.rxIdx = 0;

    ncDrv_I2C_SlaveInitialize(&i2c1);

    GIC_RegisterHandler(IRQ_NUM_I2C1, (PrHandler)ncDrv_I2C_IRQ_Handler1);
    ncDrv_GIC_EnableIrq(IRQ_NUM_I2C1);

    APACHE_TEST_INIT_DATA();
    ncDrv_SCU_mDelay(100);

    for(i = 0; i < TEST_DATA_SZIE; i++)
    {
    	ncDrv_I2C_mWriteData(I2C_CH0, i2c0.master.id, 0x00, g_test_tx_data[i], 1, i2c0.type);
    	g_test_rx_data[i] = ncDrv_I2C_sReadDataFromBuf(I2C_CH1);
    }

    if(APACHE_TEST_VALIDATE_DATA() == NC_FAILURE)
    {
		ret = NC_FAILURE;
		goto I2C_Exit;
	}

    ncDrv_GIC_DisableIrq(IRQ_NUM_I2C1);
    ncDrv_I2C_DeInitialize(I2C_CH0);
    ncDrv_I2C_DeInitialize(I2C_CH1);


    /*
     * I2C_CH1 : Mater   I2C_CH0 : Slave
     */
    i2c1.channel = I2C_CH1;
    i2c1.mode = I2C_OP_MODE_MASTER;
    i2c1.byteOrder = I2C_LITTLE_ENDIAN;
    i2c1.type = I2C_ADDR_8_DATA_8;
    i2c1.master.id = 0xC0;          // device id ???
    i2c1.master.clock = I2C_BITRATE_30KBPS;
    i2c1.master.txBuf = (UINT8 *)0;
    i2c1.slave.rxBuf = (UINT8 *)0;
    i2c1.master.txIdx = 0;
    i2c1.slave.rxIdx = 0;

    ncDrv_I2C_MasterInitialize(&i2c1);
    ncDrv_I2C_SetClock(I2C_CH1, ncDrv_SCU_GetApbClock(), i2c1.master.clock);

    i2c0.channel = I2C_CH0;
    i2c0.mode = I2C_OP_MODE_SLAVE;
    i2c0.byteOrder = I2C_LITTLE_ENDIAN;
    i2c0.type = I2C_ADDR_8_DATA_8;
    i2c0.slave.id = 0xC0;           // device id ???
    i2c0.master.txBuf = (UINT8*)0;
    i2c0.slave.rxBuf = slave_rx_buf;
    i2c0.master.txIdx = 0;
    i2c0.slave.rxIdx = 0;

    ncDrv_I2C_SlaveInitialize(&i2c0);

    GIC_RegisterHandler(IRQ_NUM_I2C0, (PrHandler)ncDrv_I2C_IRQ_Handler0);
    ncDrv_GIC_EnableIrq(IRQ_NUM_I2C0);

    APACHE_TEST_INIT_DATA();
    ncDrv_SCU_mDelay(100);

    for(i = 0; i < TEST_DATA_SZIE; i++)
    {
        ncDrv_I2C_mWriteData(I2C_CH1, i2c1.master.id, 0x00, g_test_tx_data[i], 1, i2c1.type);
        g_test_rx_data[i] = ncDrv_I2C_sReadDataFromBuf(I2C_CH0);
    }

    if(APACHE_TEST_VALIDATE_DATA() == NC_FAILURE)
    {
        ret = NC_FAILURE;
        goto I2C_Exit;
    }

I2C_Exit:

	ncDrv_GIC_DisableIrq(IRQ_NUM_I2C0);
    ncDrv_I2C_DeInitialize(I2C_CH0);
    ncDrv_I2C_DeInitialize(I2C_CH1);

    return ret;
}


UINT32 APACHE_TEST_UART(UINT32 channel)
{
	UINT32 i = 0;
	tREG_UART *rUART = UART0;
	tUART_PARAM param;
	INT32 ret = NC_SUCCESS;

	if(channel == 0)
	{
		ncDrv_SCU_SetPinMux(PAD_GPIO0, PAD_FUNC_0);     // uart_rx0 -> gpio0
		ncDrv_SCU_SetPinMux(PAD_GPIO1, PAD_FUNC_0);     // uart_tx0 -> gpio1
		ncDrv_SCU_SetPinMux(PAD_CAN_RX, PAD_FUNC_1);    // can_rx   -> uart_rx0
		ncDrv_SCU_SetPinMux(PAD_CAN_TX, PAD_FUNC_1);    // can_tx   -> uart_tx0
		rUART = UART0;
	}
	else
	{
		ncDrv_SCU_SetPinMux(PAD_UART_RX, PAD_FUNC_4);// uart_rx1 -> gpio_a[10]
		ncDrv_SCU_SetPinMux(PAD_UART_TX, PAD_FUNC_4);// uart_tx1 -> gpio_a[11]
		ncDrv_SCU_SetPinMux(PAD_CAN_RX, PAD_FUNC_3);    // can_rx   -> uart_rx1
		ncDrv_SCU_SetPinMux(PAD_CAN_TX, PAD_FUNC_3);    // can_tx   -> uart_tx1
		rUART = UART1;
	}

	param.uartClk = ncDrv_SCU_GetApbClock();
    param.baudRate = UT_BAUDRATE_115200;
    param.sps = UT_SPS_DIS;
    param.wlen = UT_DATA_8BIT;
    param.fen = UT_FIFO_ENA;
    param.stp2 = UT_STOP_1BIT;
    param.eps = UT_EPS_DIS;
    param.pen = UT_PARITY_DIS;
    param.brk = UT_BRK_DIS;

    APACHE_TEST_INIT_DATA();
	ncDrv_UART_Initialize(rUART, &param);

	for(i = 0; i < TEST_DATA_SZIE; i++)
	{
		ncDrv_UART_putchar(rUART, g_test_tx_data[i]);
		g_test_rx_data[i] = ncDrv_UART_getchar(rUART);
	}

	ncDrv_UART_Deinitialize(rUART);

	if(APACHE_TEST_VALIDATE_DATA() == NC_FAILURE)
	{
		ret =  NC_FAILURE;
		goto UART_Exit;
	}

UART_Exit:

	return ret;
}


INT32 main(void)
{
    INT32 ret = NC_SUCCESS;

    if(g_sram_remap == FALSE)
    {
    	APACHE_TEST_SetSystemRemap();
    }

    APACHE_TEST_INIT();

#if	TEST_QSPI_SFLASH
    APACHE_TEST_GPIO_INIT();

    APACHE_TEST_QSPI();
#elif TEST_ADC_RTC_BGR_2ND
    APACHE_TEST_GPIO_INIT_ADC_BGR();

    APACHE_TEST_ADC_RTC_BGR_2ND();
#elif TEST_ADC_RTC_BGR_3RD
    APACHE_TEST_GPIO_INIT_ADC_BGR();

    APACHE_TEST_ADC_RTC_BGR_3RD();
#else
    APACHE_TEST_GPIO_INIT();

    ret = APACHE_TEST_UART(0);
    APACHE_TEST_GPIO_CONTROl(TV_UART_0, ret);

	ret = APACHE_TEST_UART(1);
	APACHE_TEST_GPIO_CONTROl(TV_UART_1, ret);

    ret = APACHE_TEST_SPI();
    APACHE_TEST_GPIO_CONTROl(TV_SPI, ret);

    ret = APACHE_TEST_I2C();
    APACHE_TEST_GPIO_CONTROl(TV_I2C, ret);

    ret = APACHE_TEST_TIMER(TC_CH0);
    APACHE_TEST_GPIO_CONTROl(TV_TIMER_0, ret);

    ret = APACHE_TEST_TIMER(TC_CH1);
    APACHE_TEST_GPIO_CONTROl(TV_TIMER_1, ret);

    ret = APACHE_TEST_SUB_TIMER(TC_CH2);
    APACHE_TEST_GPIO_CONTROl(TV_SUB_TIMER_0, ret);

    ret = APACHE_TEST_SUB_TIMER(TC_CH3);
    APACHE_TEST_GPIO_CONTROl(TV_SUB_TIMER_1, ret);

    ret = APACHE_TEST_SUB_TIMER(TC_CH4);
    APACHE_TEST_GPIO_CONTROl(TV_SUB_TIMER_2, ret);

    ret = APACHE_TEST_CAN();
    APACHE_TEST_GPIO_CONTROl(TV_CAN, ret);
#endif

//    __ENTER_CRITICAL_SECTION();
//    __EXIT_CRITICAL_SECTION();

    while(1);

	return ret;
}


/* End Of File */
