/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Timer_Drv.c
*
*  @brief   : This file is Timer Controller Driver for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.01.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

/*
********************************************************************************
*                               INCLUDE
********************************************************************************
*/

#include "Apache35.h"
#include "Timer.h"


/*
********************************************************************************
*                              LOCAL DEFINITIONS
********************************************************************************
*/

#define DEFAULT_TIMER_CLOCK_DIVIDER			1

/*
********************************************************************************
*                           LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                                 LOCAL TYPEDEF
********************************************************************************
*/

/*
********************************************************************************
*                       IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                        GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/
tTIMER_INFO gTimerInfo[MAX_TIMER_CH];
UINT32  	gnTimerInClock				= 0;
UINT32 		gaTimerClock[TC_CH_MAX] 	= {0, };
UINT32      gaTimerDivider[TC_CH_MAX]	= {0, };
UINT32		gaTimerTickCount[TC_CH_MAX] = {0, };
FP32        gaTimerTickUnitTime[TC_CH_MAX]   = {0, };



/*
 * For User Handler
 */
PrVoid 	ncDrv_TIMER_UserHandler0  	= NULL;
PrVoid 	ncDrv_TIMER_UserHandler1  	= NULL;
PrVoid 	ncDrv_TIMER_UserHandler2  	= NULL;
PrVoid 	ncDrv_TIMER_UserHandler3  	= NULL;
PrVoid 	ncDrv_TIMER_UserHandler4  	= NULL;









/*
********************************************************************************
*                       IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*                            LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*                             FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*                 LOW LEVEL DRIVER FUNCTION DEFINITONS
********************************************************************************
*/
static INT32 __ipow(INT32 base, INT32 exp)
{
    INT32 result = 1;
    while (exp)
    {
        if (exp & 1)
            result *= base;
        exp >>= 1;
        base *= base;
    }

    return result;
}

UINT32 ncDrv_TIMER_BaseAddr(TIMER_CH channel)
{
    UINT32 base_addr;

    switch(channel)
    {
    	case TC_CH0:
    		base_addr = rTIMER_0_BASE;
    		break;

    	case TC_CH1:
    		base_addr = rTIMER_1_BASE;
    		break;

    	case TC_CH2:
    		base_addr = rTIMER_2_BASE;
    		break;

    	case TC_CH3:
    		base_addr = rTIMER_3_BASE;
    		break;

    	case TC_CH4:
    		base_addr = rTIMER_4_BASE;
    		break;

    	default:
    		break;
    }

    return base_addr;
}


/*
********************************************************************************
*                 HIGH LEVEL DRIVER FUNCTION DEFINITONS
********************************************************************************
*/
void ncDrv_TIMER_ISR_Handler(TIMER_CH channel)
{
    APACHE_SET_BIT(ncDrv_TIMER_BaseAddr(channel)+rTIMER_INTCLR, TCON_INT_CLR);

    if(gTimerInfo[channel].mode == TM_ONESHOT)
        gTimerInfo[channel].oneshotStatus = TOS_DONE;
}

void ncDrv_TIMER_IRQ_Handler0(void *param)
{
    /*
    * Default ISR Routine
    */
    ncDrv_TIMER_ISR_Handler(TC_CH0);


    /*
    * User Handler Call Back Function
    */
    if( ncDrv_TIMER_UserHandler0 != NULL  )
    {
        ncDrv_TIMER_UserHandler0();
    }
}


void ncDrv_TIMER_IRQ_Handler1(void *param)
{
    /*
    * Default ISR Routine
    */
    ncDrv_TIMER_ISR_Handler(TC_CH1);

    /*
    * User Handler Call Back Function
    */
    if( ncDrv_TIMER_UserHandler1 != NULL  )
    {
        ncDrv_TIMER_UserHandler1();
    }
}

void ncDrv_TIMER_IRQ_Handler2(void *param)
{
    /*
    * User Handler Call Back Function
    */
    if( ncDrv_TIMER_UserHandler2 != NULL  )
    {
        ncDrv_TIMER_UserHandler2();
    }
}

void ncDrv_TIMER_IRQ_Handler3(void *param)
{
    /*
    * User Handler Call Back Function
    */
    if( ncDrv_TIMER_UserHandler3 != NULL  )
    {
        ncDrv_TIMER_UserHandler3();
    }
}

void ncDrv_TIMER_IRQ_Handler4(void *param)
{
    /*
    * User Handler Call Back Function
    */
    if( ncDrv_TIMER_UserHandler4 != NULL  )
    {
        ncDrv_TIMER_UserHandler4();
    }
}

INT32 ncDrv_TIMER_ConnectUserHandler(TIMER_CH channel, PrVoid pfUserHandler)
{
    INT32 ret = NC_SUCCESS;


    switch(channel)
    {
        case TC_CH0:
            ncDrv_TIMER_UserHandler0 =  (PrVoid) pfUserHandler;
        break;

        case TC_CH1:
            ncDrv_TIMER_UserHandler1 =  (PrVoid) pfUserHandler;
        break;

        case TC_CH2:
            ncDrv_TIMER_UserHandler2 =  (PrVoid) pfUserHandler;
        break;

        case TC_CH3:
            ncDrv_TIMER_UserHandler3 =  (PrVoid) pfUserHandler;
        break;

        case TC_CH4:
            ncDrv_TIMER_UserHandler4 =  (PrVoid) pfUserHandler;
        break;

        default:
            ret = NC_FAILURE;
        break;
    }

    return ret;
}


INT32 ncDrv_TIMER_DisConnectUserHandler(TIMER_CH channel)
{
    INT32 ret = NC_SUCCESS;


    switch(channel)
    {
        case TC_CH0:
            ncDrv_TIMER_UserHandler0 = (PrVoid) NULL;
        break;

        case TC_CH1:
            ncDrv_TIMER_UserHandler1 = (PrVoid) NULL;
        break;

        case TC_CH2:
            ncDrv_TIMER_UserHandler2 = (PrVoid) NULL;
        break;

        case TC_CH3:
            ncDrv_TIMER_UserHandler3 = (PrVoid) NULL;
        break;

        case TC_CH4:
            ncDrv_TIMER_UserHandler4 = (PrVoid) NULL;
        break;

        default:
            ret = NC_FAILURE;
        break;
    }

    return ret;
}

INT32 ncDrv_TIMER_GetOneShotModeDone(TIMER_CH channel)
{
    INT32 Result = FALSE;

    if(gTimerInfo[channel].oneshotStatus == TOS_DONE)
    {
        Result = TRUE;
    }

    return Result;
}

INT32 ncDrv_TIMER_Start(TIMER_CH channel)
{
    if(channel < TC_CH2)
    {
        APACHE_SET_BIT(ncDrv_TIMER_BaseAddr(channel)+rTIMER_CTRL, TCON_ENABLE);
    }
    else
    {
        APACHE_SET_BIT(rSUBTIMER_BASE, ((channel-2)*2));
    }

    return NC_SUCCESS;
}


INT32 ncDrv_TIMER_Stop(TIMER_CH channel)
{
    if(channel < TC_CH2)
    {
        APACHE_CLEAR_BIT(ncDrv_TIMER_BaseAddr(channel)+rTIMER_CTRL, TCON_ENABLE);
    }
    else
    {
        APACHE_CLEAR_BIT(rSUBTIMER_BASE, ((channel-2)*2));
        APACHE_SET_BIT(rSUBTIMER_BASE, (((channel-2)*2)+1));
        REGRW32(ncDrv_TIMER_BaseAddr(channel), rTIMER_MOD) = 0;
    }

    return NC_SUCCESS;
    }


INT32 ncDrv_TIMER_Init(TIMER_CH channel, ptTC_INIT_PARAM ptTcParam)
{
    eTIMER_MODE mode;

    UINT32	usec1;
    UINT32	TimerMatch1;
    FP32 	TimerClk;
    FP32	TimerPeriod;

    ncDrv_TIMER_Stop(channel);

    if(channel < TC_CH2) // Main-Timer
    {
         // Set Timer mode
        if(ptTcParam->mMode == TC_MODE_PERIOD)
        {
            APACHE_CLEAR_BIT(ncDrv_TIMER_BaseAddr(channel)+rTIMER_CTRL, TCON_COUNT_MODE);
        }
        else if(ptTcParam->mMode == TC_MODE_ONESHOT)
        {
            APACHE_SET_BIT(ncDrv_TIMER_BaseAddr(channel)+rTIMER_CTRL, TCON_COUNT_MODE);
        }
        else
        {
            return NC_FAILURE;
        }

        APACHE_SET_BIT(ncDrv_TIMER_BaseAddr(channel)+rTIMER_CTRL, TCON_SIZE_32BIT);
        REGRW32(ncDrv_TIMER_BaseAddr(channel), rTIMER_CTRL) &= ~(0x03<<TCON_PRESCALE);
        APACHE_SET_BIT(ncDrv_TIMER_BaseAddr(channel)+rTIMER_CTRL, TCON_INT_ONOFF);
        APACHE_SET_BIT(ncDrv_TIMER_BaseAddr(channel)+rTIMER_CTRL, TCON_MODE_PERIOD);


        // Set prescaler
        if( (ptTcParam->mPrescaler != 1)
        && (ptTcParam->mPrescaler != 16)
        && (ptTcParam->mPrescaler != 256) )
        {
            ptTcParam->mPrescaler = 1;
        }
        if(ptTcParam->mPrescaler == 16)
            REGRW32(ncDrv_TIMER_BaseAddr(channel), rTIMER_CTRL) |= TCONL_PRESCALE_16;
        else if(ptTcParam->mPrescaler == 256)
            REGRW32(ncDrv_TIMER_BaseAddr(channel), rTIMER_CTRL) |= TCON_PRESCALE_256;
        else
            REGRW32(ncDrv_TIMER_BaseAddr(channel), rTIMER_CTRL) |= TCON_PRESCALE_1;


        // Gen Time Tick.
        usec1 		= ptTcParam->mPeriod1;
        TimerClk    = gaTimerClock[channel] / ptTcParam->mPrescaler;
        TimerPeriod = (1/TimerClk)*1000000;
        TimerMatch1 = (usec1 == 0 ? 0:  usec1/TimerPeriod);

        gaTimerTickCount[channel] 		= TimerMatch1;
        gaTimerTickUnitTime[channel] 	= (FP32)1000 /gaTimerTickCount[channel];

        REGRW32(ncDrv_TIMER_BaseAddr(channel), rTIMER_LOAD) = TimerMatch1;

    }
    else // Sub-Timer
    {
        // Set Timer mode
        if(ptTcParam->mMode == TC_MODE_PERIOD)
        {
            REGRW32(ncDrv_TIMER_BaseAddr(channel), rTIMER_MOD) |= (TMOD_INTER | TMOD_MATEN);
        }
        else if(ptTcParam->mMode == TC_MODE_PWM)
        {
            REGRW32(ncDrv_TIMER_BaseAddr(channel), rTIMER_MOD) |= (TMOD_PWM | TMOD_OVFEN | TMOD_MATEN);
            if(channel == TC_CH2)
                APACHE_SET_BIT(rSUBTIMER_BASE, T2_PWM_CONT);
            else
                APACHE_SET_BIT(rSUBTIMER_BASE, T34_PWM_CONT);
        }
        else
        {
            return NC_FAILURE;
        }


        // Set prescaler
        if( ptTcParam->mPrescaler > 11 )
            ptTcParam->mPrescaler = 11;
        REGRW32(ncDrv_TIMER_BaseAddr(channel), rTIMER_MOD) |= ptTcParam->mPrescaler<<TMOD_DIV;


        // Gen Time Tick.
        usec1 = ptTcParam->mPeriod1;
        TimerClk  = gaTimerClock[channel] / __ipow(2, (ptTcParam->mPrescaler+1));
        TimerPeriod = (1/TimerClk)*1000000;
        TimerMatch1 = (usec1 == 0 ? 0:  usec1/TimerPeriod);

        gaTimerTickCount[channel]    = TimerMatch1;
        gaTimerTickUnitTime[channel] = (FP32)1000 /gaTimerTickCount[channel];

        REGRW32(ncDrv_TIMER_BaseAddr(channel), rTIMER_DLSB) = (TimerMatch1&0xFF);
        REGRW32(ncDrv_TIMER_BaseAddr(channel), rTIMER_DMSB) = ((TimerMatch1>>8)&0xFF);

    }

    mode = (eTIMER_MODE)ptTcParam->mMode;
    gTimerInfo[channel].mode = mode;
    if(ptTcParam->mMode == TM_ONESHOT)
    {
        gTimerInfo[channel].oneshotStatus = TOS_NONE;
    }

    return NC_SUCCESS;
}

INT32 ncDrv_TIMER_Open(UINT32 nInputClk)
{
	INT32  ret = NC_SUCCESS;
	UINT32 i;

	gnTimerInClock = nInputClk;

	for (i = 0; i < TC_CH_MAX; i++) {
		gaTimerDivider[i] = DEFAULT_TIMER_CLOCK_DIVIDER;
		gaTimerClock[i] = gnTimerInClock / gaTimerDivider[i];
	}

	return ret;
}

/* End Of File */

