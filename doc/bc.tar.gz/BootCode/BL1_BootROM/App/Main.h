/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.h
*
*  @brief   : This file is implemented about main of BL1_BootROM
*
*  @author  : alessio / SoCSW Platform Team
*
*  @date    : 2016.01.10
*
*  @version : Version 0.0.1
*
********************************************************************************
*  History  :
*
********************************************************************************
*/

#ifndef __MAIN_H__
#define __MAIN_H__


/*
********************************************************************************
*               INCLUDE FILES
********************************************************************************
*/

#include "Type.h"
#include "Apache35.h"

#include "Utility.h"

#include "SCU.h"
#include "Uart_Drv.h"
#include "SSP_Drv.h"

#include "sFlash.h"


/*
********************************************************************************
*               DEFINITIONS
********************************************************************************
*/

/* APACHE3.5 Bootloader-BL1 Version */

#define BL1_VER_MAJOR               1
#define BL1_VER_MINOR1              1
#define BL1_VER_MINOR2              1


#define BL1_BUILD_DATE              __DATE__
#define BL1_BUILD_TIME              __TIME__


/* APACHE3.5 Simple Boot Option  */

#if FAST_BOOT_MODE // ASIC Test Fast Boot   // CodeSonar 2 warning ... (main remap null pointer, return)

#define BL1_FAST_BOOT_ENABLE            1   // test : Only Peripheral ASIC Simulation Test
#define BL1_JTAG_BOOT_ENABLE            0   // test : JTAG Download SW Test
#define BL1_SPI_CLK_DIV_LOOP            0   // SPI Clock Divide while loop enable
#define BOOT_DEBUG_STEP_PRINT_ENABLE    0   // test : Step value UART debug message enable
#define BOOT_DEBUG_PRINT_ENABLE         0   // test : Scenario test debug message enable

#else

#if 1   // Real Boot  & Post-Simulation     // CodeSonar 0 warning ...
#define BL1_FAST_BOOT_ENABLE            0   // test : Only Peripheral ASIC Simulation Test
#define BL1_JTAG_BOOT_ENABLE            0   // test : JTAG Download SW Test
#define BL1_SPI_CLK_DIV_LOOP            1   // SPI Clock Divide while loop enable
#define BOOT_DEBUG_STEP_PRINT_ENABLE    0   // test : Step value UART debug message enable
#define BOOT_DEBUG_PRINT_ENABLE         0   // test : Scenario test debug message enable

#elif 0 // Real Simple Printf Boot          // CodeSonar 2 warning ... (uart while, va_list)
#define BL1_FAST_BOOT_ENABLE            0   // test : Only Peripheral ASIC Simulation Test
#define BL1_JTAG_BOOT_ENABLE            0   // test : JTAG Download SW Test
#define BL1_SPI_CLK_DIV_LOOP            1   // SPI Clock Divide while loop enable
#define BOOT_DEBUG_STEP_PRINT_ENABLE    1   // test : Step value UART debug message enable
#define BOOT_DEBUG_PRINT_ENABLE         0   // test : Scenario test debug message enable

#elif 0 // SW Test FPGA Simple Printf Boot  // CodeSonar 2 warning ... (uart while, va_list)
#define BL1_FAST_BOOT_ENABLE            0   // test : Only Peripheral ASIC Simulation Test
#define BL1_JTAG_BOOT_ENABLE            1   // test : JTAG Download SW Test
#define BL1_SPI_CLK_DIV_LOOP            1   // SPI Clock Divide while loop enable
#define BOOT_DEBUG_STEP_PRINT_ENABLE    1   // test : Step value UART debug message enable
#define BOOT_DEBUG_PRINT_ENABLE         0   // test : Scenario test debug message enable

#elif 0 // SW Test FPGA Full Printf Boot    // CodeSonar 2 warning ... (uart while, va_list)
#define BL1_FAST_BOOT_ENABLE            0   // test : Only Peripheral ASIC Simulation Test
#define BL1_JTAG_BOOT_ENABLE            1   // test : JTAG Download SW Test
#define BL1_SPI_CLK_DIV_LOOP            1   // SPI Clock Divide while loop enable
#define BOOT_DEBUG_STEP_PRINT_ENABLE    1   // test : Step value UART debug message enable
#define BOOT_DEBUG_PRINT_ENABLE         1   // test : Scenario test debug message enable
#endif

#endif


/* APACHE3.5 SPI Option  */

#define SPI_CH                      SSP_CH0


/* APACHE3.5 UART Debugging Message Macro */

#define MSGERR                      (0x1<<0)    // Error message enable
#define MSGWARN                     (0x1<<1)    // Warning message enable
#define MSGINFO                     (0x1<<2)    // Information message enable
#define MSGON                       (0x1<<3)    // Force message enable

#define DEBUGMSG(zone, fmt, args...)  \
        do { if(zone) ncDrv_UART_printf(fmt, ## args); } while(0)


/* APACHE3.5 OSC Option  */

#define OSC_25MHZ                   25000000
#define OSC_27MHZ                   27000000
#define OSC_50MHZ                   50000000


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

enum
{
    BOOTSTRAP_BOOT_DOWNLOAD_MODE,
    BOOTSTRAP_BOOT_NORMAL_MODE,
};


enum
{
    BOOTSTRAP_BOOT_SIP_FLASH,
    BOOTSTRAP_BOOT_EXTERNAL_MODE,
};


typedef enum
{
    E_NOERROR = 0,

    E_ERROR_FLASH_MEMROY_INFO,

    E_ERROR_NORMAL_BL2_HEADER,
    E_ERROR_NORMAL_BL2_IMAGE,

    E_ERROR_BACKUP_BL2_HEADER,
    E_ERROR_BACKUP_BL2_IMAGE,

    NUM_OF_BL1_ERROR
} E_BL1_ERROR;   // BootLoader Error Number


typedef enum
{
    E_BACKUP_BL2_HEADER,
    E_BACKUP_BL2_IMAGE,

    NUM_OF_BL1_BACKUP
} E_BL1_BACKUP;   // BootLoader Error Number


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT32 mSignature;      // BL2 Header Signature
    UINT32 mRetryCount;     // BL2 Retry count
    UINT32 mBL2Length;      // BL2 Header + Image Total Length
    UINT32 Reserved;        // BL2 Reserved

    UINT32 mImgSrcAddr;     // BL2 Flash Memory Source Address
    UINT32 mImgDstAddr;     // BL2 System Memory Destination Address
    UINT32 mImgLength;      // BL2 Image Length
    UINT32 mImgCSum;        // BL2 Image Checksum
} stBL2_HEADER, *pstBL2_HEADER;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

void ncBL1_BOOT_DebugMessage(UINT8 nMsg);

INT32 ncBL1_sFlash_GetHeader(UINT32 nAddress);
INT32 ncBL1_sFlash_GetImage(UINT32 nAddress);

E_BL1_ERROR ncBL1_NormalBootMode(void);
E_BL1_ERROR ncBL1_BackupBootMode(E_BL1_BACKUP nScenario);


#endif /* __MAIN_H__ */
