/*
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : sFlash.h
*
*  @brief   : This file is serial flash memory control driver
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.25
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __SFLASH_H__
#define __SFLASH_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

// Serial Flash Command ...

#define CMD_PAGE_PROGRAM            0x02
#define CMD_RD_DATA                 0x03
#define CMD_WR_DS                   0x04
#define CMD_RD_STS                  0x05
#define CMD_WR_EN                   0x06
#define CMD_SECTOR_ERASE            0x20
#define CMD_BLOCK_ERASE             0xD8
#define CMD_RD_IDENTIFICATION       0x9F

#define FLASH_STS_WIP               (0x1<<0)
#define FLASH_STS_WEL               (0x1<<1)

#define FLASH_BLOCK_SIZE            (64*KB)
#define FLASH_SECTOR_SIZE           (4*KB)
#define FLASH_PAGE_SIZE             (256)


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tSFLASH_ID
{
    UINT8 mbManufacture;    // Manufacture ID
    UINT8 mbMemoryType;     // Memory Type
    UINT8 mbMemoryCapacity; // Memory Capacity
    UINT8 Reserved;
} tSFLASH_ID, *ptSFLASH_ID;

typedef struct _tSFLASH_INFO
{
    UINT32 mnPageSize;     // Page Size
    UINT32 mnBlockSize;    // Block Size
    UINT32 mnPageOfBlock;  // Page count per block

    BOOL   mbDmaMode;

    tSFLASH_ID mtsFlashID;
} tSFLASH_INFO, *ptSFLASH_INFO;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern void ncDrv_sFlash_Init(UINT32 nChNum, ptSSP_INIT_PARAM ptParam);
extern void ncDrv_sFlash_Deinit(UINT32 nChNum);

extern void ncDrv_sFlash_ReadID(UINT32 nChNum, UINT32 nCS, UINT8 *pBuff);
extern void ncDrv_sFlash_Read(UINT32 nChNum, UINT32 nCS, UINT32 PageAddr, UINT8 *pBuff);


#endif  /* __SFLASH_H__ */


/* End Of File */
