/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SCU.c
*
*  @brief   : This file is SCU, GPIO ...
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.02.06
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void __BL1_SetPinMux(UINT32 Func, UINT32 Offset, UINT32 Pos)
{
    REGRW32(APACHE_ICU_BASE, Offset) &= ~(0x7<<Pos);
    REGRW32(APACHE_ICU_BASE, Offset) |= ((Func&0x7)<<Pos);
}


void __BL1_SetGPIODir(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_DIR dir, UINT32 offset)
{
    switch(group)
    {
        case GPIO_GROUP_A:
        case GPIO_GROUP_B:
        {
            if(dir == GPIO_DIR_IN)
                REGRW32(rGPIO_BASE0, offset+(group*0x10)) &= ~(1<<port);
            else
                REGRW32(rGPIO_BASE0, offset+(group*0x10)) |= (1<<port);
        }
        break;

        case GPIO_GROUP_C:
        {
            if(dir == GPIO_DIR_IN)
                REGRW32(rGPIO_BASE1, rGPIO_DIR1) &= ~(1<<port);
            else
                REGRW32(rGPIO_BASE1, rGPIO_DIR1) |= (1<<port);
        }
        break;
    }
}


void __BL1_SetGPIOData(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_DATA level, UINT32 offset)
{
    switch(group)
    {
        case GPIO_GROUP_A:
        case GPIO_GROUP_B:
        {
            if(level == GPIO_LOW)
                REGRW32(rGPIO_BASE0, offset+(group*0x10)) &= ~(1<<port);
            else
                REGRW32(rGPIO_BASE0, offset+(group*0x10)) |= (1<<port);
        }
        break;

        case GPIO_GROUP_C:
        {
            if(level == GPIO_LOW)
                REGRW32(rGPIO_BASE1, rGPIO_OUT_PORT1) &= ~(1<<port);
            else
                REGRW32(rGPIO_BASE1, rGPIO_OUT_PORT1) |= (1<<port);
        }
        break;
    }
}


void __BL1_UART_PinMux(UINT32 nChNum)
{
    if(nChNum == UART_CH0)
    {
        __BL1_SetPinMux(PAD_FUNC_1, rICU_MUX_10, 8);    // RX
        __BL1_SetPinMux(PAD_FUNC_1, rICU_MUX_10, 12);   // TX
    }
    else
    {
        __BL1_SetPinMux(PAD_FUNC_0, rICU_MUX_0C, 28);   // RX
        __BL1_SetPinMux(PAD_FUNC_0, rICU_MUX_0C, 24);   // TX
    }
}


void __BL1_SSP_PinMux(UINT32 nChNum, UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 12); //SPI2_PINMUX_CS0  / SPI2_CSN0 / Mux->GPIO_12
        __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT12, GPIO_DIR_OUT, rGPIO_V2_DIR0); // Mux->GPIO_12
    }
    else
    {
        __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 8);  //SPI2_PINMUX_CS1  / SPI2_CSN1 / Mux->GPIO_13
        __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT13, GPIO_DIR_OUT, rGPIO_V2_DIR0); // Mux->GPIO_13
    }

    if(nChNum == SSP_CH0)
    {
        __BL1_SetPinMux(PAD_FUNC_1, rICU_MUX_04, 24); //SPI2_PINMUX_MOSI / SPI0_DQ0
        __BL1_SetPinMux(PAD_FUNC_1, rICU_MUX_04, 20); //SPI2_PINMUX_MISO / SPI2_DQ1
        __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 4);  //SPI2_PINMUX_MISO / SPI2_DQ2  / Mux->GPIO_16
        __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 8);  //SPI2_PINMUX_MISO / SPI2_DQ3  / Mux->GPIO_17
        __BL1_SetPinMux(PAD_FUNC_1, rICU_MUX_04, 16); //SPI2_PINMUX_CLK  / SPI2_SCK

        __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT16, GPIO_DIR_IN, rGPIO_V2_DIR0);
        __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT17, GPIO_DIR_IN, rGPIO_V2_DIR0);

#if 0
        __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT16, GPIO_DIR_OUT, rGPIO_V2_DIR0);
        __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT17, GPIO_DIR_OUT, rGPIO_V2_DIR0);
        __BL1_SetGPIOData(GPIO_GROUP_A, GPIO_PORT16, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
        __BL1_SetGPIOData(GPIO_GROUP_A, GPIO_PORT17, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
#endif
    }
    else if(nChNum == SSP_CH1)
    {
        // Standard SPI Mode -> Controller SSP1
        __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 24); //SPI2_PINMUX_MOSI / SPI2_DQ0  / Mux->GPIO_14
        __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 20); //SPI2_PINMUX_MISO / SPI2_DQ1  /Mux->GPIO_15
        __BL1_SetPinMux(PAD_FUNC_1, rICU_MUX_08, 4);  //SPI2_PINMUX_MISO / SPI2_DQ2
        __BL1_SetPinMux(PAD_FUNC_1, rICU_MUX_08, 8);  //SPI2_PINMUX_MISO / SPI2_DQ3
        __BL1_SetPinMux(PAD_FUNC_2, rICU_MUX_04, 16); //SPI2_PINMUX_CLK  / SPI2_SCK

        __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT14, GPIO_DIR_IN, rGPIO_V2_DIR0);
        __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT15, GPIO_DIR_IN, rGPIO_V2_DIR0);
    }

    __BL1_SSP_CS_High(nChNum, nCS);
}


void __BL1_SSP_PinMuxRelease(UINT32 nChNum, UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 12); //SPI2_PINMUX_CS0  / SPI2_CSN0 / Mux->GPIO_12
        __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT12, GPIO_DIR_IN, rGPIO_V2_DIR0); // Mux->GPIO_12
    }
    else // BOOTSTRAP_BOOT_EXTERNAL_MODE
    {
        __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 8);  //SPI2_PINMUX_CS1  / SPI2_CSN1 / Mux->GPIO_13
        __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT13, GPIO_DIR_IN, rGPIO_V2_DIR0); // Mux->GPIO_13
    }

    // PinMux SPI Port Release ...
    __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 24); //SPI1_PINMUX_MOSI / SPI2_DQ0
    __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 20); //SPI1_PINMUX_MISO / SPI2_DQ1
    __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 4); //SPI1_PINMUX_MISO / SPI2_DQ2
    __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 8); //SPI1_PINMUX_MISO / SPI2_DQ3
    __BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 16); //SPI1_PINMUX_CLK / SPI2_SCK

    // Set GPIO InputMode
    __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT14, GPIO_DIR_IN, rGPIO_V2_DIR0);
    __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT15, GPIO_DIR_IN, rGPIO_V2_DIR0);
    __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT16, GPIO_DIR_IN, rGPIO_V2_DIR0);
    __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT17, GPIO_DIR_IN, rGPIO_V2_DIR0);
    __BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT18, GPIO_DIR_IN, rGPIO_V2_DIR0);
}


void __BL1_SSP_CS_High(UINT32 nChNum, UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL1_SetGPIOData(GPIO_GROUP_A, GPIO_PORT12, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
    }
    else
    {
        __BL1_SetGPIOData(GPIO_GROUP_A, GPIO_PORT13, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
    }
}


void __BL1_SSP_CS_Low(UINT32 nChNum, UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL1_SetGPIOData(GPIO_GROUP_A, GPIO_PORT12, GPIO_LOW, rGPIO_V2_OUT_PORT0);
    }
    else
    {
        __BL1_SetGPIOData(GPIO_GROUP_A, GPIO_PORT13, GPIO_LOW, rGPIO_V2_OUT_PORT0);
    }
}


void __BL1_GPIO_PortInitialize(void)
{
    //__BL1_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 12);
    //__BL1_SetGPIODir(GPIO_GROUP_A, GPIO_PORT12, GPIO_DIR_OUT, rGPIO_V2_DIR0);
}


void __BL1_GPIO_PortSet(BOOL nData)
{
    if(nData == GPIO_LOW)
    {
        //__BL1_SetGPIOData(GPIO_GROUP_A, GPIO_PORT12, GPIO_LOW, rGPIO_V2_OUT_PORT0);
    }
    else
    {
        //__BL1_SetGPIOData(GPIO_GROUP_A, GPIO_PORT12, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
    }
}


/* End Of File */
