/*
********************************************************************************
*
*  Copyright (C) 2016 	NEXTCHIP Inc. All rights reserved.
*
*  @file	: SSP_Lib.c
*
*  @brief	: This file is SSP controller API for NEXTCHIP standard library
*
*  @author	: parkjy / SoC SW Group / Platform Team
*
*  @date	: 2016.01.09
*
*  @version	: Version 1.0.0
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

BOOL gbSSPOpen;
BOOL gaSSPChannel[SSP_CH_MAX] = {0, };


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncLib_SSP_Open(UINT32 nInputClk)
{
    INT32 ret = NC_SUCCESS;
    INT32 i;

    /*
    * Check error case
    */
    if(gbSSPOpen == TRUE)
    {
        ret = NC_FAILURE;
    }

    if(nInputClk == 0)
    {
        ret = NC_FAILURE;
    }

    if(ret == NC_SUCCESS)
    {
        gnSSPInClock = nInputClk;
        gbSSPOpen    = TRUE;

        for(i = 0; i < SSP_CH_MAX; i++)
        {
            gaSSPChannel[i] = FALSE;
        }
    }

    return ret;
}


INT32 ncLib_SSP_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbSSPOpen == TRUE)
    {
        gbSSPOpen = FALSE;
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_SSP_Read(UINT32 nChNum, UINT8 *pBuf, UINT32 nLength)
{
    INT32 ret = NC_SUCCESS;

    if(gbSSPOpen == TRUE)
    {
        ret = ncDrv_SSP_Read(nChNum, pBuf, nLength);
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_SSP_Write(UINT32 nChNum, UINT8 *pBuf, UINT32 nLength)
{
    INT32 ret = NC_SUCCESS;

    if(gbSSPOpen == TRUE)
    {
        ret = ncDrv_SSP_Write(nChNum, pBuf, nLength);
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_SSP_Control(eSSP_CMD Cmd, ...)
{
    INT32   ret = NC_SUCCESS;
    UINT32  nChNum;
    UINT32  count = 0;
    UINT32  argData[10];
    va_list vlist;
    BOOL    bEndCmd = FALSE;

    if(gbSSPOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vlist, Cmd);

        for(count=0; count<10; count++)
        {
            argData[count] = va_arg(vlist, UINT32);

            if(argData[count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vlist);


        if(bEndCmd == FALSE)
        {
            ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

            nChNum = (UINT32)argData[0];

            switch(Cmd)
            {
                case GCMD_SSP_INIT_CH:
                {
                    ret = ncDrv_SSP_Init(nChNum, (ptSSP_INIT_PARAM) argData[1]);
                }
                break;

                case GCMD_SSP_DEINIT_CH:
                {
                    ret = ncDrv_SSP_DeInit(nChNum);
                }
                break;

                case GCMD_SSP_CS_ENABLE_CH:
                {
                    ncDrv_SSP_ClearRxFIFO(nChNum);
                    ncDrv_SSP_WaitBusIsBusy(nChNum, 1000);
                    __BL2_SSP_CS_Low(nChNum, gFlashCS);
                }
                break;

                case GCMD_SSP_CS_DISABLE_CH:
                {
                    __BL2_SSP_CS_High(nChNum, gFlashCS);
                }
                break;

                case GCMD_SSP_SET_BITRATE:
                {
                    ncDrv_SSP_SetBitRate(nChNum, argData[1]);
                }
                break;

                case GCMD_SSP_WAIT_BUSY:
                {
                    ncDrv_SSP_WaitBusIsBusy(nChNum, 1000);
                }
                break;

                default :
                    ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


/* End Of File */
