/*
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : DDR.h
*
*  @brief   : This file is implemented about DDR of BL2_BootRAM
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.02.03
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __DDR_H__
#define __DDR_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define DDR_PHY_CONFIG                  (APACHE_DDRC_BASE+0x00)
#define DDR_ADDR_SIZE                   (APACHE_DDRC_BASE+0x04)
#define DDR_TIMING_0                    (APACHE_DDRC_BASE+0x08)
#define DDR_TIMING_1                    (APACHE_DDRC_BASE+0x0c)
#define DDR_TIMING_2                    (APACHE_DDRC_BASE+0x10)
#define DDR_LMR_EXT_STD                 (APACHE_DDRC_BASE+0x14)
#define DDR_LMR_EXT_3_2                 (APACHE_DDRC_BASE+0x18)
#define DDR_DELAY_CONFIG                (APACHE_DDRC_BASE+0x24)


#define DDR_PHY_INIT                    (1<<0)
#define DDR_PHY_CLR                     (1<<1)
#define DDR_PHY_COMPLETE                (1<<4)
#define DDR_PHY_SUCCESS                 (1<<5)


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncDrv_DDRC_Initialize(UINT32 nInputClk, UINT32 nDDRType);

extern void ncDrv_DDRC_Config(UINT32 nInputClk, UINT32 nDDRType);
extern UINT32 ncDrv_DDRC_Start(void);


#endif  /* __DDR_H__ */


/* End Of File */
