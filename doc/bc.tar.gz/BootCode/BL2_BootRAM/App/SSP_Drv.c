/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SSP_Drv.c
*
*  @brief   : This file is SSP Controller Driver for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.01.08
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : ARM PrimeCell�� SSP (PL022) / Revision: r1p3
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define DEFAULT_SSP_CLOCK_DIVIDER           2


#define	SPI_IS_BUSY(status)     ((status)&SSP_BSY)
#define	SPI_IS_RxReady(status)  ((status)&SSP_RNE)


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

UINT32 gnSSPInClock = 0;
BOOL   gaSSPDmaMode[SSP_CH_MAX] = {0, };
UINT32 gnSSPWidth[SSP_CH_MAX] = {0, };


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncDrv_SSP_SetBitRate(UINT32 nChNum, UINT32 bitrate)
{
    UINT32 Reg;
    UINT32 CPSDVR;
    UINT32 SCR;
    UINT32 SCR_0;
    UINT32 SCR_1;

    if( bitrate * 1000000 * 2 > gnSSPInClock)
    {
        SCR = 0;
    }
    else
    {
        /*
        * SPI clock formula
        * SCR = (InputClock/(CPSDVR * BitRate))-1
        */

        CPSDVR = DEFAULT_SSP_CLOCK_DIVIDER;
        SCR_0 = (gnSSPInClock / (CPSDVR*bitrate*1000000));	// Quotient of SCR
        SCR_1 = (gnSSPInClock % (CPSDVR*bitrate*1000000));	// Remainder of SCR

        if( SCR_1 > ((CPSDVR*bitrate*1000000)/2) )
        {
            SCR_0 = SCR_0 + 1;		// for rounding
        }

        SCR = SCR_0 - 1;
    }

    Reg = APACHE_SPI_READ(nChNum, SSP_CR0);
    Reg &= ~(SSP_SCR_MSK);
    Reg |= (SCR<<8);

    APACHE_SPI_WRITE(nChNum, SSP_CR0, Reg);
}


void ncDrv_SSP_ClearRxFIFO(UINT32 Port)
{
    UINT32 Count, temp;

    for(Count=0; Count<8; Count++)
    {
        if(APACHE_SPI_READ(Port, SSP_SR) & SSP_RNE)
        {
            temp = APACHE_SPI_READ(Port, SSP_DR);  // Drop Data
        }
        else
        {
            break;
        }
    }
}


BOOL ncDrv_SSP_WaitBusIsBusy(UINT32 Port, UINT32 TimeOut)
{
    UINT32 Status;
    UINT32 Count;
    UINT32 ret = FALSE;

    for(Count=0; Count<TimeOut; Count++)
    {
        Status = APACHE_SPI_READ(Port, SSP_SR);

        if(!SPI_IS_BUSY(Status))
        {
            ret = TRUE;
            break;
        }
    }

    return ret;
}


BOOL ncDrv_SSP_WaitRxFIFOIsReady(UINT32 Port, UINT32 TimeOut)
{
    UINT32 Status;
    UINT32 Count;
    UINT32 Ret = FALSE;

    for(Count=0; Count<TimeOut; Count++)
    {
        Status = APACHE_SPI_READ(Port, SSP_SR);
        if(SPI_IS_RxReady(Status))
        {
            Ret = TRUE;
            break;
        }
    }

    return Ret;
}


INT32 ncDrv_SSP_Init(UINT32 nChNum, ptSSP_INIT_PARAM ptParam)
{
    INT32 ret = NC_SUCCESS;

    UINT32 CPSDVR;
    UINT32 SCR;
    UINT32 SCR_0;
    UINT32 SCR_1;
    UINT32 nIntMask;

    if( ptParam->mBitRate * 1000000 * 2 > gnSSPInClock)
    {
        SCR = 0;
    }
    else
    {
        /*
        * SPI clock formula
        * SCR = (InputClock/(CPSDVR * BitRate))-1
        */

        CPSDVR = DEFAULT_SSP_CLOCK_DIVIDER;
        SCR_0 = (gnSSPInClock / (CPSDVR*ptParam->mBitRate*1000000));	// Quotient of SCR
        SCR_1 = (gnSSPInClock % (CPSDVR*ptParam->mBitRate*1000000));	// remainder of SCR

        if( SCR_1 > ((CPSDVR*ptParam->mBitRate*1000000)/2) )
        {
            SCR_0 = SCR_0 + 1;		// for rounding
        }

        SCR = SCR_0 - 1;
    }

    APACHE_SPI_WRITE(nChNum, SSP_CR0, (SCR<<8) | (ptParam->mSPH<<7) | (ptParam->mSPO<<6) | (ptParam->mFormat<<4) | ptParam->mDataWidth );
    APACHE_SPI_WRITE(nChNum, SSP_CR1,  SSP_SOD_EN | (ptParam->mMode<<2) | SSP_SSE_EN | SSP_LBM_DS);
    APACHE_SPI_WRITE(nChNum, SSP_CPSR, CPSDVR);

    nIntMask = SSP_TXIM_MASKED | SSP_RXIM_MASKED | SSP_RTIM_NOMASKED | SSP_RORIM_NOMASKED;

    if(ptParam->mTxIntEn == TRUE)
    {
        nIntMask |= SSP_TXIM_NOMASKED;
    }

    if(ptParam->mRxIntEn == TRUE)
    {
        nIntMask |= SSP_RXIM_NOMASKED;
    }

    APACHE_SPI_WRITE(nChNum, SSP_IMSC, nIntMask);
    APACHE_SPI_WRITE(nChNum, SSP_RIS, SSP_TXRIS | SSP_RXRIS | SSP_RTRIS | SSP_RORRIS);

    gaSSPDmaMode[nChNum] = ptParam->mDmaMode;
    gnSSPWidth[nChNum] = ptParam->mDataWidth;

    return ret;
}


INT32 ncDrv_SSP_DeInit(UINT32 nChNum)
{
    INT32 ret = NC_SUCCESS;

    APACHE_SPI_WRITE(nChNum, SSP_CR1, 0);

    return ret;
}


INT32 ncDrv_SSP_Read(UINT32 nChNum, UINT8 *pBuf, UINT32 nLength)
{
    INT32  ret = NC_SUCCESS;
    UINT32 i;
    UINT16 *pBuf16;
    UINT8  div = 1;

    if(gnSSPWidth[nChNum] > SSP_DS_8BIT)
    {
        pBuf16 = (UINT16 *) pBuf;
        div = 2;
    }


    for(i = 0; i < (nLength/div); i++)
    {
        /* Write dummy data */
        APACHE_SPI_WRITE(nChNum, SSP_DR, 0x00);

        if(!ncDrv_SSP_WaitBusIsBusy(nChNum, 1000))
        {
            ret = NC_FAILURE;
        }

        if(!ncDrv_SSP_WaitRxFIFOIsReady(nChNum, 1000))
        {
            ret = NC_FAILURE;
        }

        /* Read data */
        if(gnSSPWidth[nChNum] > SSP_DS_8BIT)
        {
            pBuf16[i] = (UINT16) APACHE_SPI_READ(nChNum, SSP_DR);
        }
        else
        {
            pBuf[i]   = (UINT8)  APACHE_SPI_READ(nChNum, SSP_DR);
        }
    }

    return ret;
}


INT32 ncDrv_SSP_Write(UINT32 nChNum, UINT8 *pBuf, UINT32 nLength)
{
    UINT32 i;
    UINT16 *pBuf16;
    UINT8  div = 1;
    INT32 ret = NC_SUCCESS;

    if(gnSSPWidth[nChNum] > SSP_DS_8BIT)
    {
        pBuf16 = (UINT16 *) pBuf;
        div = 2;
    }

    for(i = 0; i < (nLength/div); i++)
    {
        /* Write data */
        if(gnSSPWidth[nChNum] > SSP_DS_8BIT)
        {
            APACHE_SPI_WRITE(nChNum, SSP_DR, pBuf16[i]);
        }
        else
        {
            APACHE_SPI_WRITE(nChNum, SSP_DR, pBuf[i]);
        }

        ncDrv_SSP_WaitBusIsBusy(nChNum, 1000);

        /* Read dummy Data */
        ret = APACHE_SPI_READ(nChNum, SSP_DR);
    }

    return ret;
}


/* End Of File */
