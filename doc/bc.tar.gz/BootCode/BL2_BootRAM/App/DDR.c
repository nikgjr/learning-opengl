/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : DDR.c
*
*  @brief   : This file is implemented about DDR of BL2_BootRAM
*
*  @author  : alessio / SoCSW Platform Team
*
*  @date    : 2016.02.03
*
*  @version : Version 0.0.1
*
********************************************************************************
*  History  :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

UINT32 __ceil(FP32 F)
{
    FP32   X;
    UINT32 Y;

    X = F;
    Y = (UINT32)F;

    X = X - (FP32)Y;

    if(X != 0.0) X = 1.0;

    X += F;

    return (UINT32)X;
}


INT32 ncDrv_DDRC_Initialize(UINT32 nInputClk, UINT32 nDDRType)
{
    INT32 ret = NC_SUCCESS;

    ncDrv_DDRC_Config(nInputClk, nDDRType);

    if(ncDrv_DDRC_Start() == 0)
    {
        ret = NC_FAILURE;
    }

    if(nInputClk == 148500000)
    {
        WRITE32(0x08080808, (APACHE_DDRC_BASE+0x20));
    }
        
    return ret;
}


void ncDrv_DDRC_Config(UINT32 nInputClk, UINT32 nDDRType)
{
    //------------------------------------------------------------
    // [Offset:0x04] DDR Address Size Configuration
    UINT32 reg_DDRC_ADDR_SIZE;
        UINT32 ColumnAddressSize;
        UINT32 RowAddressSize;
        UINT32 BankAddressSize;
        UINT32 AddressAcccess;
        UINT32 isLPDDR;

    //------------------------------------------------------------
    // [Offset:0x08] DDR Timing Configuration 0
    UINT32 reg_DDRC_TIMING0;
        FP32 tRAS;
        FP32 tRFC;
        FP32 tRC;
        UINT32 tRASCycle;
        UINT32 tRFCCycle;
        UINT32 tRCCycle;

    //-------------------------------------------------------------
    // [Offset:0x0C] DDR Timing Configuration 1
    UINT32 reg_DDRC_TIMING1;
        FP32 tRCD;
        FP32 tRP;
        FP32 tRRD;
        FP32 tWR;
        UINT32 tRCDCycle;
        UINT32 tRPCycle;
        UINT32 tRRDCycle;
        UINT32 tWRCycle;
        UINT32 tWTRCycle;
        UINT32 tMRDCycle;
        UINT32 tDQSSCycle;

    //-------------------------------------------------------------
    // [Offset:0x10] DDR Timing Configuration 2
    UINT32 reg_DDRC_TIMING2;
        FP32 pRefrWindowHighPriority = 0.950;
        FP32 tREFI;
        FP32 tInitTime;
        UINT32 tREFICycle;
        UINT32 tInitTimeCycle;

    //------------------------------------------------------------
    // [Offset:0x14] DDR Standard and Extended Load Mode Registers
    UINT32 reg_DDRC_LMR_EXT_STD;
        UINT32 MRS_ModeRegisterSet;
            UINT32 CAS;
            UINT32 BurstType;
            UINT32 BurstLength;
        UINT32 EMRS_ExtendedModeRegisterSet;
            UINT32 DriverStrength;
            UINT32 SelfRefreshCoverage;

    //------------------------------------------------------------
    // [Offset:0x24] DDR Delay Register
    UINT32 reg_DDRC_DELAY_CONF;

    FP32 pClkMHz = (FP32)nInputClk/1000000.0;


    /*
    * [Offset:0x04] DDR Address Size Configuration
    *   [1:0]   : Column Size           -> 8+X  [0:2^8,  1:2^9  ...]
    *   [3:2]   : Row Size              -> 11+X [0:2^11, 2:2^12 ...]
    *   [4]     : Bank Size             -> 2+X  [0:2^2,  2:2^3  ...]
    *   [5]     : Address Access        -> [0:Bank-Row-Column, 1:Row-Bank-Column]
    *   [7]     : Select DDR2 or LPDDR  -> [0:DDR2, 1:LPDDR]
    */
    ColumnAddressSize = 0;  // 2^8
    RowAddressSize    = 0;  // 2^11
    BankAddressSize   = 0;  // 2^2
    AddressAcccess    = 1;  // Row-Bank-Column
    isLPDDR           = 1;  // Select LPDDR

    reg_DDRC_ADDR_SIZE = (isLPDDR<<7)|(AddressAcccess<<5)|(BankAddressSize<<4)|(RowAddressSize<<2)|ColumnAddressSize;


    /*
    * [Offset:0x08] DDR Timing Configuration 0
    *   [4:0]   : Activate to Precharge cycle                       [tRAS * Frequency / 1000]
    *   [14:8]  : Refresh to Activate or Refresh interval cycle     [tRFC * Frequency / 1000]
    *   [20:16] : Activate to Activate cycle                        [tRC  * Frequency / 1000]
    */
    tRAS = 42.0;
    tRFC = 72.0;
    tRC  = 60.0;

    if(nDDRType == LPDDR_ISSL)
    {
        tRFC = 70.0;
    }

    tRASCycle = __ceil((tRAS * pClkMHz)/1000.0);
    tRFCCycle = __ceil((tRFC * pClkMHz)/1000.0);
    tRCCycle  = __ceil(( tRC * pClkMHz)/1000.0);

    reg_DDRC_TIMING0 = (tRCCycle<<16)|(tRFCCycle<<8)|tRASCycle;


    /*
    * [Offset:0x0C] DDR Timing Configuration 1
    *   [3:0]   : Activate to Read or WRITE delay cycle                 [tRCD * Frequency / 1000]
    *   [7:4]   : Precharge period cycle                                [tRP  * Frequency / 1000]
    *   [11:8]  : Activate to Activate delay different bank cycle       [tRRD * Frequency / 1000]
    *   [15:12] : Write Recovery time cycle                             [tWR  * Frequency / 1000]
    *   [18:16] : Interval Write to Read delay cycle                    [tWTR * Frequency / 1000]
    *   [21:20] : LOAD MODE clcye time
    *   [23:22] : Write command to first DQS latching transition cycle(only LPDDR)
    */
    tRCD = 18.0;
    tRP  = 18.0;
    tRRD = 12.0;
    tWR  = 15.0;

    if(nDDRType == LPDDR_ISSL)
    {
        tWR = 12.0;
    }

    tRCDCycle  = __ceil((tRCD * pClkMHz)/1000.0);
    tRPCycle   = __ceil(( tRP * pClkMHz)/1000.0);
    tRRDCycle  = __ceil((tRRD * pClkMHz)/1000.0);
    tWRCycle   = __ceil(( tWR * pClkMHz)/1000.0);
    tWTRCycle  = 2;
    tMRDCycle  = 2;
    tDQSSCycle = 1;

    if(nDDRType == LPDDR_ISSL)
    {
        tWTRCycle  = 1;
    }

    reg_DDRC_TIMING1 = (tDQSSCycle<<22)|(tMRDCycle<<20)|(tWTRCycle<<16)|(tWRCycle<<12)|(tRRDCycle<<8)|(tRPCycle<<4)|(tRCDCycle);


    /*
    * [Offset:0x10] DDR Timing Configuration 12
    *   [15:0]  : Average periodic refresh          [tREFI * Frequency / 1000]
    *   [31:16] : Stable power-up and clock cycle
    */
#ifdef __BL2_DDR_tREFI_HIGH_TEMP__
    tREFI       =  3900.0;        // usec->nsec - 3.9us : 85 < T < 125
#else
    tREFI       =  15625.0;       // usec->nsec - 15.6us : -40 < T < 85
#endif
    tInitTime   = 200000.0;       // 200us

    tREFICycle     = __ceil((pRefrWindowHighPriority * tREFI * pClkMHz)/1000.0);
    tInitTimeCycle = __ceil((tInitTime * pClkMHz)/1000.0);

    reg_DDRC_TIMING2 = (tInitTimeCycle<<16)|tREFICycle;


    /*
    * [Offset:0x14] DDR Standard and Extended Load Mode Registers
    *   [14:0]  : Mode Register
    *   [30:16] : Extended Mode Register
    */
    BurstLength = 0x2;                                              // 4
    BurstType   = 0x0;                                              // sequential
    CAS         = 0x2;                                              // 2
    MRS_ModeRegisterSet = (CAS<<4)|(BurstType<<3)|BurstLength;

    SelfRefreshCoverage = 0x0;                                      // partial array self refresh   = Four Banks
    DriverStrength      = 0x2;                                      // 0=100%, 1=50%, 2=25%, 3=12%  = 1/4 Strength
    EMRS_ExtendedModeRegisterSet = (DriverStrength<<5)|SelfRefreshCoverage;

    reg_DDRC_LMR_EXT_STD = (EMRS_ExtendedModeRegisterSet<<16)|MRS_ModeRegisterSet;


    /*
    * [Offset:0x24] DDR Delay Registers
    *   [4:0]  : Delay Register
    */
    if(nInputClk == 148500000)
        reg_DDRC_DELAY_CONF = 0x00;
    else
        reg_DDRC_DELAY_CONF = 0x0E;   


    WRITE32(reg_DDRC_ADDR_SIZE,     DDR_ADDR_SIZE);
    WRITE32(reg_DDRC_TIMING0,       DDR_TIMING_0);
    WRITE32(reg_DDRC_TIMING1,       DDR_TIMING_1);
    WRITE32(reg_DDRC_TIMING2,       DDR_TIMING_2);
    WRITE32(reg_DDRC_LMR_EXT_STD,   DDR_LMR_EXT_STD);
    WRITE32(reg_DDRC_DELAY_CONF,    DDR_DELAY_CONFIG);


#if BOOT_DEBUG_PRINT_ENABLE
    DEBUGMSG(MSGINFO, " >> Main Freq         = %8d\n", nInputClk);
    DEBUGMSG(MSGINFO, "     DDR_PHY_CONFIG   = 0x%8x                \n", READ32(DDR_PHY_CONFIG));
    DEBUGMSG(MSGINFO, "     DDR_ADDR_SIZE    = 0x%8x, 0x%8x, 0x%8x\n", READ32(DDR_ADDR_SIZE),   reg_DDRC_ADDR_SIZE   ,READ32(DDR_ADDR_SIZE)^reg_DDRC_ADDR_SIZE);
    DEBUGMSG(MSGINFO, "     DDR_TIMING_0     = 0x%8x, 0x%8x, 0x%8x\n", READ32(DDR_TIMING_0),    reg_DDRC_TIMING0     ,READ32(DDR_TIMING_0)^reg_DDRC_TIMING0);
    DEBUGMSG(MSGINFO, "     DDR_TIMING_1     = 0x%8x, 0x%8x, 0x%8x\n", READ32(DDR_TIMING_1),    reg_DDRC_TIMING1     ,READ32(DDR_TIMING_1)^reg_DDRC_TIMING1);
    DEBUGMSG(MSGINFO, "     DDR_TIMING_2     = 0x%8x, 0x%8x, 0x%8x\n", READ32(DDR_TIMING_2),    reg_DDRC_TIMING2     ,READ32(DDR_TIMING_2)^reg_DDRC_TIMING2);
    DEBUGMSG(MSGINFO, "     DDR_LMR_EXT_STD  = 0x%8x, 0x%8x, 0x%8x\n", READ32(DDR_LMR_EXT_STD), reg_DDRC_LMR_EXT_STD ,READ32(DDR_LMR_EXT_STD)^reg_DDRC_LMR_EXT_STD);
    DEBUGMSG(MSGINFO, "     DDR_DELAY_CONFIG = 0x%8x, 0x%8x, 0x%8x\n", READ32(DDR_DELAY_CONFIG),reg_DDRC_DELAY_CONF  ,READ32(DDR_DELAY_CONFIG)^reg_DDRC_DELAY_CONF);
#endif
}


UINT32 ncDrv_DDRC_Start(void)
{
    UINT32 Reg;
    INT32 loop = 0x100000;

    // PHY init Start
    WRITE32(DDR_PHY_CLR|DDR_PHY_INIT, DDR_PHY_CONFIG);

    while(loop--)
    {
        Reg = READ32(DDR_PHY_CONFIG);

        // PHY init complete
        if(Reg & DDR_PHY_COMPLETE)
            break;
    }

#if BOOT_DEBUG_PRINT_ENABLE
    // PHY init result [1:success, 0:fail]
    DEBUGMSG(MSGINFO, " >> PHY Init - %s, Result - %s\n", loop<=0 ? "TimeOut":"Done", (Reg & DDR_PHY_SUCCESS) ? "Success":"Fail");
#endif

    return ((Reg & DDR_PHY_SUCCESS) ? TRUE:FALSE);
}


/* End Of File */
