/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SCU.c
*
*  @brief   : This file is SCU, GPIO ...
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.27
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

// Version 0.9.8 modify

UINT32 cPLLSelect[4][3]=
{
    // PLL0,    PLL1,      PLL2
    {192000000, 297000000,  16000000},
    {216000000, 297000000,  16000000},
    {297000000, 297000000,  16000000},
    {297000000, 297000000,  16000000}
};

UINT8 cPLLConfig[4][12]=
{
    {
      //NF  NR  OD  BWADJ
        63,  2,  2, 63,   // PLL0 192000000
        21,  0,  1, 21,   // PLL1 297000000
        15,  2,  8, 15,   // PLL2  16000000
    },    
    
    {
      //NF  NR  OD  BWADJ
        15,  0,  1, 15,   // PLL0 216000000
        21,  0,  1, 21,   // PLL1 297000000
        15,  2,  8, 15,   // PLL2  16000000
    },

    {
      //NF  NR  OD  BWADJ
        21,  0,  1, 21,   // PLL0 297000000
        21,  0,  1, 21,   // PLL1 297000000
        15,  2,  8, 15,   // PLL2  16000000
    },

    {
      //NF  NR  OD  BWADJ
        21,  0,  1, 21,   // PLL0 297000000
        21,  0,  1, 21,   // PLL1 297000000
        15,  2,  8, 15,   // PLL2  16000000
    },
};


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void __BL2_SetPinMux(UINT32 Func, UINT32 Offset, UINT32 Pos)
{
    REGRW32(APACHE_ICU_BASE, Offset) &= ~(0x7<<Pos);
    REGRW32(APACHE_ICU_BASE, Offset) |= ((Func&0x7)<<Pos);
}


void __BL2_SetGPIODir(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_DIR dir, UINT32 offset)
{
    switch(group)
    {
        case GPIO_GROUP_A:
        case GPIO_GROUP_B:
        {
            if(dir == GPIO_DIR_IN)
                REGRW32(rGPIO_BASE0, offset+(group*0x10)) &= ~(1<<port);
            else
                REGRW32(rGPIO_BASE0, offset+(group*0x10)) |= (1<<port);
        }
        break;

        case GPIO_GROUP_C:
        {
            if(dir == GPIO_DIR_IN)
                REGRW32(rGPIO_BASE1, rGPIO_DIR1) &= ~(1<<port);
            else
                REGRW32(rGPIO_BASE1, rGPIO_DIR1) |= (1<<port);
        }
        break;
    }
}


void __BL2_SetGPIOData(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_DATA level, UINT32 offset)
{
    switch(group)
    {
        case GPIO_GROUP_A:
        case GPIO_GROUP_B:
        {
            if(level == GPIO_LOW)
                REGRW32(rGPIO_BASE0, offset+(group*0x10)) &= ~(1<<port);
            else
                REGRW32(rGPIO_BASE0, offset+(group*0x10)) |= (1<<port);
        }
        break;

        case GPIO_GROUP_C:
        {
            if(level == GPIO_LOW)
                REGRW32(rGPIO_BASE1, rGPIO_OUT_PORT1) &= ~(1<<port);
            else
                REGRW32(rGPIO_BASE1, rGPIO_OUT_PORT1) |= (1<<port);
        }
        break;
    }
}


void __BL2_PLL_SetConfig(UINT8 nPLLSelect)
{
    UINT32 nEnable = 0;
    UINT32 nStable = 0;
    UINT32 nBwadj = 0;
    UINT32 nPllClockSel = 0;
    UINT32 nTemp, nDiv_xx;
    UINT32 nWaitCount = 100000;

// Version 0.9.8 modify

    /*
     * PLL Configuration ...
     * */

    gtPllConfig.mNF    = cPLLConfig[nPLLSelect][0];
    gtPllConfig.mNR    = cPLLConfig[nPLLSelect][1];
    gtPllConfig.mOD    = cPLLConfig[nPLLSelect][2];
    gtPllConfig.mBWADJ = cPLLConfig[nPLLSelect][3];

    nBwadj = gtPllConfig.mBWADJ<<PLL0_BWADJ;
    nTemp = (gtPllConfig.mNF << PLL_NF) | (gtPllConfig.mNR << PLL_NR) | (gtPllConfig.mOD << PLL_OD);
    REGRW32(SYS_CON_BASE, rSCU_PLL0_CONFIG) = nTemp;

    gtPllConfig.mNF    = cPLLConfig[nPLLSelect][4+0];
    gtPllConfig.mNR    = cPLLConfig[nPLLSelect][4+1];
    gtPllConfig.mOD    = cPLLConfig[nPLLSelect][4+2];
    gtPllConfig.mBWADJ = cPLLConfig[nPLLSelect][4+3];

    nBwadj |= gtPllConfig.mBWADJ<<PLL1_BWADJ;
    nTemp = (gtPllConfig.mNF << PLL_NF) | (gtPllConfig.mNR << PLL_NR) | (gtPllConfig.mOD << PLL_OD);
    REGRW32(SYS_CON_BASE, rSCU_PLL1_CONFIG) = nTemp;

    gtPllConfig.mNF    = cPLLConfig[nPLLSelect][8+0];
    gtPllConfig.mNR    = cPLLConfig[nPLLSelect][8+1];
    gtPllConfig.mOD    = cPLLConfig[nPLLSelect][8+2];
    gtPllConfig.mBWADJ = cPLLConfig[nPLLSelect][8+3];

    nBwadj |= gtPllConfig.mBWADJ<<PLL2_BWADJ;
    nTemp = (gtPllConfig.mNF << PLL_NF) | (gtPllConfig.mNR << PLL_NR) | (gtPllConfig.mOD << PLL_OD);
    REGRW32(SYS_CON_BASE, rSCU_PLL2_CONFIG) = nTemp;

    REGRW32(SYS_CON_BASE, rSCU_PLL_BWADJ) = nBwadj;


    /*
     * PLL Setting Completed ...
     * */

    nEnable = (PLL2_RESET | PLL1_RESET | PLL0_RESET);
    REGRW32(SYS_CON_BASE, rSCU_PLL_ENABLE) = nEnable;

    /*
     * PLL Stable Waiting ...
     * */

    nStable = (PLL2_STBL | PLL1_STBL | PLL0_STBL);

    while(nWaitCount--)
    {
        SysDelay(1);

        nTemp = REGRW32(SYS_CON_BASE, rSCU_PLL_STABLE) & 0xF;
        if(nTemp == nStable)
        {
            break;
        }
    }

    /*
     * PLL0.1.2 Clock Select ...
     * */

    nPllClockSel = (OUTPUT_PLL<<PLL2_OUTSEL) | (OUTPUT_PLL<<PLL1_OUTSEL) | (OUTPUT_PLL<<PLL0_OUTSEL);
    REGRW32(SYS_CON_BASE, rSCU_PLL_CLK_SEL) = nPllClockSel;

    /*
     * System, CAN Clock Select ...
     * */

    nPllClockSel = (SYS_PLL2<<SEL_CAN_CLK) | (SYS_PLL0<<SEL_SYS_CLK);
    REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_SEL) = nPllClockSel;

    /*
     * System Clock Divider (ADC, CAN, DDR, APB, AXI, CPU, TS)
     * */
    
    if(nPLLSelect == 0)
    {
        nDiv_xx = (2<<DIV_ADC_CLK) | (0<<DIV_CAN_CLK) | (0<<DIV_DDR_CLK) | (2<<DIV_APB_CLK) | (1<<DIV_AXI_CLK) | (0<<DIV_CPU_CLK);
        REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV1) = nDiv_xx;

        nTemp = (3<<DIV_ADC_SEL);
        REGRW32(SYS_CON_BASE, rSCU_SYS_VDO_CLK_DIV) = nTemp;

        nDiv_xx = (5<<DIV_TS_CLK);
        REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV2) = nDiv_xx;
    }
    else if(nPLLSelect == 1)
    {
        nDiv_xx = (2<<DIV_ADC_CLK) | (0<<DIV_CAN_CLK) | (0<<DIV_DDR_CLK) | (2<<DIV_APB_CLK) | (1<<DIV_AXI_CLK) | (1<<DIV_CPU_CLK);
        REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV1) = nDiv_xx;

        nTemp = (3<<DIV_ADC_SEL);
        REGRW32(SYS_CON_BASE, rSCU_SYS_VDO_CLK_DIV) = nTemp;

        nDiv_xx = (5<<DIV_TS_CLK);
        REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV2) = nDiv_xx;
    }
    else
    {
        nTemp = (4<<DIV_ADC_CLK) | (0<<DIV_CAN_CLK) | (0<<DIV_DDR_CLK) | (2<<DIV_APB_CLK) | (1<<DIV_AXI_CLK) | (0<<DIV_CPU_CLK);
        REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV1) = nTemp;

        nTemp = (3<<DIV_ADC_SEL);
        REGRW32(SYS_CON_BASE, rSCU_SYS_VDO_CLK_DIV) = nTemp;

        nTemp = (7<<DIV_TS_CLK);
        REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV2) = nTemp;
    }

    /*
     * Output Frequency ...
     * */

    gtPllConfig.PLL0_Freq = cPLLSelect[nPLLSelect][0];
    gtPllConfig.PLL1_Freq = cPLLSelect[nPLLSelect][1];
    gtPllConfig.PLL2_Freq = cPLLSelect[nPLLSelect][2];
}


void __BL2_UART_PinMux(UINT32 nChNum)
{
    if(nChNum == UART_CH0)
    {
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_0C, 0);    // vout_b6 -> po_gpio_b[14]
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 28);   // vout_b7 -> po_gpio_b[15]    
                
        __BL2_SetPinMux(PAD_FUNC_1, rICU_MUX_10, 8);    // RX
        __BL2_SetPinMux(PAD_FUNC_1, rICU_MUX_10, 12);   // TX
    }
    else
    {
        __BL2_SetPinMux(PAD_FUNC_0, rICU_MUX_0C, 28);   // RX
        __BL2_SetPinMux(PAD_FUNC_0, rICU_MUX_0C, 24);   // TX
    }
}


void __BL2_SSP_PinMux(UINT32 nChNum, UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 12); //SPI2_PINMUX_CS0  / SPI2_CSN0 / Mux->GPIO_12
        __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT12, GPIO_DIR_OUT, rGPIO_V2_DIR0); // Mux->GPIO_12
    }
    else
    {
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 8);  //SPI2_PINMUX_CS1  / SPI2_CSN1 / Mux->GPIO_13
        __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT13, GPIO_DIR_OUT, rGPIO_V2_DIR0); // Mux->GPIO_13
    }

    if(nChNum == SSP_CH0)
    {
        __BL2_SetPinMux(PAD_FUNC_1, rICU_MUX_04, 24); //SPI2_PINMUX_MOSI / SPI0_DQ0
        __BL2_SetPinMux(PAD_FUNC_1, rICU_MUX_04, 20); //SPI2_PINMUX_MISO / SPI2_DQ1
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 4);  //SPI2_PINMUX_MISO / SPI2_DQ2  / Mux->GPIO_16
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 8);  //SPI2_PINMUX_MISO / SPI2_DQ3  / Mux->GPIO_17
        __BL2_SetPinMux(PAD_FUNC_1, rICU_MUX_04, 16); //SPI2_PINMUX_CLK  / SPI2_SCK

        __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT16, GPIO_DIR_IN, rGPIO_V2_DIR0);
        __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT17, GPIO_DIR_IN, rGPIO_V2_DIR0);
    }
    else if(nChNum == SSP_CH1)
    {
        // Standard SPI Mode -> Controller SSP1
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 24); //SPI2_PINMUX_MOSI / SPI2_DQ0  / Mux->GPIO_14
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 20); //SPI2_PINMUX_MISO / SPI2_DQ1  /Mux->GPIO_15
        __BL2_SetPinMux(PAD_FUNC_1, rICU_MUX_08, 4);  //SPI2_PINMUX_MISO / SPI2_DQ2
        __BL2_SetPinMux(PAD_FUNC_1, rICU_MUX_08, 8);  //SPI2_PINMUX_MISO / SPI2_DQ3
        __BL2_SetPinMux(PAD_FUNC_2, rICU_MUX_04, 16); //SPI2_PINMUX_CLK  / SPI2_SCK

        __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT14, GPIO_DIR_IN, rGPIO_V2_DIR0);
        __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT15, GPIO_DIR_IN, rGPIO_V2_DIR0);
    }

    __BL2_SSP_CS_High(nChNum, nCS);
}


void __BL2_QSPI_PinMux(UINT32 nChNum, UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL2_SetPinMux(PAD_FUNC_2, rICU_MUX_04, 12); //SPI2_PINMUX_CS0  / SPI2_CSN0 / Mux->GPIO_12
    }
    else
    {
        __BL2_SetPinMux(PAD_FUNC_2, rICU_MUX_04, 8);  //SPI2_PINMUX_CS1  / SPI2_CSN1 / Mux->GPIO_13
    }

    __BL2_SetPinMux(PAD_FUNC_0, rICU_MUX_04, 24); //SPI2_PINMUX_MOSI / SPI0_DQ0
    __BL2_SetPinMux(PAD_FUNC_0, rICU_MUX_04, 20); //SPI2_PINMUX_MISO / SPI2_DQ1
    __BL2_SetPinMux(PAD_FUNC_0, rICU_MUX_08, 4);  //SPI2_PINMUX_MISO / SPI2_DQ2  / Mux->GPIO_16
    __BL2_SetPinMux(PAD_FUNC_0, rICU_MUX_08, 8);  //SPI2_PINMUX_MISO / SPI2_DQ3  / Mux->GPIO_17
    __BL2_SetPinMux(PAD_FUNC_0, rICU_MUX_04, 16); //SPI2_PINMUX_CLK  / SPI2_SCK
}


void __BL2_QSPI_PinMuxRelease(UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 12); //SPI2_PINMUX_CS0  / SPI2_CSN0 / Mux->GPIO_12
        __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT12, GPIO_DIR_IN, rGPIO_V2_DIR0); // Mux->GPIO_12
    }
    else // BOOTSTRAP_BOOT_EXTERNAL_MODE
    {
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 8);  //SPI2_PINMUX_CS1  / SPI2_CSN1 / Mux->GPIO_13
        __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT13, GPIO_DIR_IN, rGPIO_V2_DIR0); // Mux->GPIO_13
    }

    // PinMux SPI Port Release ...
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 24); //SPI1_PINMUX_MOSI / SPI2_DQ0
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 20); //SPI1_PINMUX_MISO / SPI2_DQ1
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 4); //SPI1_PINMUX_MISO / SPI2_DQ2
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 8); //SPI1_PINMUX_MISO / SPI2_DQ3
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 16); //SPI1_PINMUX_CLK / SPI2_SCK

    // Set GPIO InputMode
    __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT14, GPIO_DIR_IN, rGPIO_V2_DIR0);
    __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT15, GPIO_DIR_IN, rGPIO_V2_DIR0);
    __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT16, GPIO_DIR_IN, rGPIO_V2_DIR0);
    __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT17, GPIO_DIR_IN, rGPIO_V2_DIR0);
    __BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT18, GPIO_DIR_IN, rGPIO_V2_DIR0);
}


void __BL2_SSP_CS_High(UINT32 nChNum, UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL2_SetGPIOData(GPIO_GROUP_A, GPIO_PORT12, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
    }
    else
    {
        __BL2_SetGPIOData(GPIO_GROUP_A, GPIO_PORT13, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
    }
}


void __BL2_SSP_CS_Low(UINT32 nChNum, UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL2_SetGPIOData(GPIO_GROUP_A, GPIO_PORT12, GPIO_LOW, rGPIO_V2_OUT_PORT0);
    }
    else
    {
        __BL2_SetGPIOData(GPIO_GROUP_A, GPIO_PORT13, GPIO_LOW, rGPIO_V2_OUT_PORT0);
    }
}


void __BL2_GPIO_PortInitialize(void)
{
    //__BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 12);
    //__BL2_SetGPIODir(GPIO_GROUP_A, GPIO_PORT12, GPIO_DIR_OUT, rGPIO_V2_DIR0);
}


void __BL2_GPIO_PortSet(BOOL nData)
{
    if(nData == GPIO_LOW)
    {
        //__BL2_SetGPIOData(GPIO_GROUP_A, GPIO_PORT12, GPIO_LOW, rGPIO_V2_OUT_PORT0);
    }
    else
    {
        //__BL2_SetGPIOData(GPIO_GROUP_A, GPIO_PORT12, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
    }
}


/* End Of File */
