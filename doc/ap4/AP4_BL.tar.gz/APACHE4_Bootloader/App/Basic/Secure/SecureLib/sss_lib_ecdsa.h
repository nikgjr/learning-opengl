/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * \defgroup SSS_ECDSA		SSS_ECDSA
 * \ingroup SSS_Library
 * \brief					ECDSA Library
 * \{
 */

/*!
 * \file		sss_lib_ecdsa.h
 * \brief		Header for ECDSA function
 * \author		kiseok.bae (kiseok.bae at samsung.com)
 * \version		V1.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 |V0.01		|2018.03.30	|kiseok		|Beta Version   |
 |V1.00		|2018.04.27	|kiseok		|Final Version  |
 */

#ifndef SSS_LIB_ECDSA_H_
#define SSS_LIB_ECDSA_H_

/*************** Include Files ************************************************/
#include "sss_lib_ecc_core.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ****************************************************/

/*************** Variable declarations ****************************************/

/*************** Error Message ************************************************/
#define ERROR_ECDSA_INVALID_LEN_MSG 	(ERR_MSG|INVALID_LEN|ERROR_ECDSA)
#define ERROR_ECDSA_INVALID_LEN_SIGN 	(ERR_SIGN|INVALID_LEN|ERROR_ECDSA)
#define ERROR_ECDSA_INVALID_VAL_SIGN 	(ERR_SIGN|INVALID_VAL|ERROR_ECDSA)
#ifndef SBOOT_SOL
	#define ERROR_ECDSA_MAX_RNG_RETRY (ERR_RANDOM|INVALID_VAL|ERROR_ECDSA)
#endif
/*************** Prototypes ***************************************************/
/**
 * \brief		set ecdsa key data for verifying
 * \param[in]	pstDomainParam    	pointer of ECC Domain structure
 * \param[in]	pstPubkey			pointer of ECC_KEY structure (Public Key)
 * \return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 Else

 */
SSS_RV ECDSA_verify_Init(const stECC_Param *pstDomainParam, const  stECC_PUBKEY *pstPubkey);

/**
 * \brief		update ecdsa digest message
 * \param[in]	pstDigest		pointer of digested message
 * \param[in]	u32ECC_wlen		length of ECC data (word)
 * \return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 Else

 */
void ECDSA_update(stOCTET_STRING *pstDigest, u32 u32ECC_wlen);

/**
 * \brief		run ecdsa verification
 * \param[in]	pstDomainParam    	pointer of ECC Domain structure
 * \param[in]	pstSIGN				pointer of ECDSA_SIGN structure
 * \return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 Else

 */
SSS_RV ECDSA_verify_final(const stECC_Param *pstDomainParam, const stECDSA_SIGN *pstSIGN);
#ifndef SBOOT_SOL
/**
 * \brief		set ecdsa key data for signing
 * \param[in]	pstDomainParam    	pointer of ECC Domain structure
 * \param[in]	pstPrivkey			pointer of ECC_KEY structure (Private Key)
 * \return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 Else

 */
SSS_RV ECDSA_sign_Init(const stECC_Param *pstDomainParam, stECC_PRIVKEY *pstPrivkey);

/**
 * \brief		run ecdsa signing
 * \param[in]	pstDomainParam    	ECC object = select EC parameter(160, 192, 224, 256, 384, 521)
 * \param[out]	pstSIGN				pointer of ECDSA_SIGN structure
 * \return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 Else

 */
SSS_RV ECDSA_sign_final(const stECC_Param *pstDomainParam, stECDSA_SIGN *pstSIGN);
/*************** END OF FILE **************************************************/
#endif
#endif /* SSS_LIB_ECDSA_H_ */

/** \} */
