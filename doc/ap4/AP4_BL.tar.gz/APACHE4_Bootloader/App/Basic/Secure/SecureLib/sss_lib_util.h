/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * \defgroup SSS_COMMON		SSS_COMMON
 * \ingroup SSS_Solution
 * \brief					Common Source (C & Head) File of SSS_Solution
 * \{
 */

/**
 * \file		sss_lib_util.h
 * \brief		Header file for Utility Functions
 * \author		Kiseok Bae (kiseok.bae at samsung.com)
 * \version		V1.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 |V0.01		|2018.03.30	|kiseok		|Beta Version   |
 |V1.00		|2018.04.27	|kiseok		|Final Version  |
 */

#ifndef SSS_LIB_UTIL_H_
#define SSS_LIB_UTIL_H_

/*************** Include Files ************************************************/
#include "sss_lib_common.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** New Data Types ***********************************************/

/*************** Constants ****************************************************/

/*************** Variable declarations ****************************************/

/*************** Prototypes ***************************************************/
/*
 * General Memory Util Functions
 */
/*!
 * \brief		Memory Compare on u32 memory (Non-Secure Version)
 * \param[in]	pu32Src1		Address of 1st u32 Source Array
 * \param[in]	pu32Src2		Address of 2nd u32 Source Array
 * \param[in]	u32Size			Size (# of word) of Source Arrays to be compared

 * \return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 */
SSS_RV sss_memcmp_u32(const u32 *pu32Src1, const u32 *pu32Src2,
		const u32 u32Size);

/*!
 * \brief		Memory Compare on u08 memory (Non-Secure Version)
 * \param[in]	pu08Src1		Address of 1st u32 Source Array
 * \param[in]	pu08Src2		Address of 2nd u32 Source Array
 * \param[in]	u32_byte_size	Size (# of byte) of Source Arrays to be compared
 *
 * \return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 */
SSS_RV sss_memcmp_u08(const u08 *pu08Src1, const u08 *pu08Src2,
		u32 u32_byte_size);

/*!
 * \brief		Memory clear on u32 memory (Non-Secure Version)
 * \param[out]		pu32Dst		Address of u32 Array to be cleared
 * \param[in]		u32Size		Word Size (# of u32 data) of Array to be set
 * \return		N/A

 */
void sss_memclr_u32(u32 *pu32Dst, const u32 u32Size);

void sss_SFRclr(u32 u32DstAddr, const u32 u32Size);

/**
 * \brief		Memory clear on u08 memory (Non-Secure Version)
 * \param[out] 		pu08Dst		Address of u08 Array to be cleared
 * \param[in] 		u32Size		Byte Size (# of u08 data) of Array to be set
 * \return		N/A

 */
void sss_memclr_u08(u08 *pu08Dst, const u32 u32Size);

/*!
 * \brief		Memory Copy on u08 memory (Non-Secure Version)
 * \param[out]		pu32Dst		Address of u32 Destination Array
 * \param[in]		pu32Src		Address of u32 Source Array
 * \param[in]		u32Size		Word Size (# of u32 data) of Array to be copied
 * \return		N/A
|
 */
void sss_memcpy_u32(u32 *pu32Dst, const u32 *pu32Src, const u32 u32Size);

/*!
 * \brief		Memory Copy on u08 memory (Non-Secure Version)
 * \param[out]		pu08Dst		Address of u08 Destination Array
 * \param[in]		pu08Src		Address of u08 Source Array
 * \param[in]		u32Size		Byte Size (# of u08 data) of Array to be copied
 * \return		N/A

 */
void sss_memcpy_u08(u08 *pu08Dst, const u08 *pu08Src, const u32 u32Size);

void sss_memxor_u08(u08 *pu08Dst,const u08 *pu08Src1, const u08 *pu08Src2, u32 u08Bytelen);
/*
 * Structure Copy Functions
 */
/*!
 * \brief		Structure Copy function (OS->SFR)
 * \param[out]		pu32SFRAddr	Address of destination address
 * \param[in]		pstSrc		pointer of source structure
 * \return			N/A

 */
void sss_OS_to_SFR(u32 u32SFRAddr, const stOCTET_STRING *pstSrc);
void sss_OS_to_SFR_Swap(u32 u32SFRAddr, const stOCTET_STRING *pstSrc);
/*!
 * \brief		Structure Copy function (SFR->OS)
 * \param[out]		pstDst			pointer of destination structure
 * \param[in]		pu32SFRAddr		Address of source address
 * \return			N/A

 */
void sss_SFR_to_OS(stOCTET_STRING *pstDst, u32 u32SFRAddr);

/*!
 * \brief		Structure Copy with reverse word-endian function (SFR->OS)
 * \param[out]		pstDst				pointer of destination structure
 * \param[in]		pu32SFR_MSW_Addr	End Address of source address
 * \return			N/A

 */
void sss_SFR_to_OS_reversing(stOCTET_STRING *pstDst, u32 u32SFR_MSW_Addr);

/*
 * Convert Octet-String to Big-Number
 */
/*!
 * \brief		Structure Copy function (OS->Big-Number)
 * \param[out]		pu32Dst		Address of destination address
 * \param[in]		pstSrc		pointer of source structure
 * \return			N/A

 */
void sss_OS_to_BN(u32 *pu32Dst, const stOCTET_STRING *pstSrc);

#ifndef SBOOT_SOL
/*!
 * \brief		Structure Copy function (Big-Number->OS)
 * \param[out]		pstDst		pointer of destination structure
 * \param[in]		pu32Src		Address of source address
 * \return			N/A

 */
void sss_BN_to_OS(stOCTET_STRING *pstDst, u32 *pu32Src);
#endif


void WAIT_SFR_BIT_SET(u32 u32SFRAddr, u32 u32Bitposition);
void WAIT_SFR_BIT_CLR(u32 u32SFRAddr, u32 u32Bitposition);

/*************** END OF FILE **************************************************/

#endif		/* SSS_LIB_UTIL_H_ */

/** \} */
