/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * \defgroup SSS_ECC		SSS_ECC
 * \ingroup SSS_Library
 * \brief					ECC Core Library
 * \{
 */

/*!
 * \file		sss_lib_ecc_core.c
 * \brief		Sourcefile for ECC core function
 * \author		Kiseok Bae (kiseok.bae at samsung.com)
 * \version		V1.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 |V0.01		|2018.03.30	|kiseok		|Beta Version   |
 |V1.00		|2018.04.27	|kiseok		|Final Version  |
 */

/*************** Include Files ********************************************/
#include "sss_lib_util.h"
#include "sss_lib_ecc_core.h"

/*************** Assertions ***********************************************/

/*************** Definitions / Macros *************************************/

/*************** Constants ************************************************/

/*************** Variable declarations ************************************/

/*************** Prototypes ***********************************************/

/*************** Function *************************************************/

void get_ECC256Info(stECC_Param *pstECCParam)
{
	/* common */
	pstECCParam->u32CurveID = OID_ECC_P256;
	pstECCParam->u32Data_wlen = 32u/4u;
}

void ECC_PARAM(const stECC_Param *pstDomainParam)
{
	u32 zu32NIST_P256_PARAM[8][8] =
	{
			/* ECC parameters Group (NIST P256), reversed */
			/* prime P = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF */
			{ 0xffffffffu, 0xffffffffu, 0xffffffffu, 0x00000000u, 0x00000000u, 0x00000000u,	0x00000001u, 0xffffffffu },
			/* order n = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551 */
			{ 0xfc632551u, 0xf3b9cac2u, 0xa7179e84u, 0xbce6faadu, 0xffffffffu, 0xffffffffu,	0x00000000u, 0xffffffffu },
			/* R^2 mod p = 0x00000004FFFFFFFDFFFFFFFFFFFFFFFEFFFFFFFBFFFFFFFF0000000000000003 */
			{ 0x00000003u, 0x00000000u, 0xFFFFFFFFu, 0xFFFFFFFBu, 0xFFFFFFFEu, 0xFFFFFFFFu,	0xFFFFFFFDu, 0x00000004u },
			/* R^2 mod n = 0x66E12D94F3D956202845B2392B6BEC594699799C49BD6FA683244C95BE79EEA2 */
			{ 0xBE79EEA2u, 0x83244C95u, 0x49BD6FA6u, 0x4699799Cu, 0x2B6BEC59u, 0x2845B239u,	0xF3D95620u, 0x66E12D94u },
			/* Generator x (in M-domain) = 0x18905F76A53755C679FB732B7762251075BA95FC5FEDB60179E730D418A9143C */
			{ 0x18A9143Cu, 0x79E730D4u, 0x5FEDB601u, 0x75BA95FCu, 0x77622510u, 0x79FB732Bu,	0xA53755C6u, 0x18905F76u },
			/* Generator y (in M-domain) = 0x8571FF1825885D85D2E88688DD21F3258B4AB8E4BA19E45CDDF25357CE95560A */
			{ 0xCE95560Au, 0xDDF25357u, 0xBA19E45Cu, 0x8B4AB8E4u, 0xDD21F325u, 0xD2E88688u,	0x25885D85u, 0x8571FF18u },
			/* coefficient a(in M-domain) = FFFFFFFC00000004000000000000000000000003FFFFFFFFFFFFFFFFFFFFFFFC */
			{ 0xFFFFFFFCu, 0xFFFFFFFFu, 0xFFFFFFFFu, 0x00000003u, 0x00000000u, 0x00000000u,	0x00000004u, 0xFFFFFFFCu },
			/* coefficient b(in M-domain) = DC30061D04874834E5A220ABF7212ED6ACF005CD78843090D89CDF6229C4BDDF */
			{ 0x29C4BDDFu, 0xD89CDF62u, 0x78843090u, 0xACF005CDu, 0xF7212ED6u, 0xE5A220ABu,	0x04874834u, 0xDC30061Du },
	};



	/*! step 1. initialize */
	PKE_A_Init256();

	/*! Step 2. Load Param to PKA_SRAM */
	/* sss_lib_ecc_core.c:89:96: Warning:  #191-D: type qualifier is meaningless on cast type */
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_Gx), 			(const u32*)zu32NIST_P256_PARAM[4u], (u32)pstDomainParam->u32Data_wlen);
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_Gy),			(const u32*)zu32NIST_P256_PARAM[5u], (u32)pstDomainParam->u32Data_wlen);
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_P), 			(const u32*)zu32NIST_P256_PARAM[0u], (u32)pstDomainParam->u32Data_wlen);
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_N), 			(const u32*)zu32NIST_P256_PARAM[1u], (u32)pstDomainParam->u32Data_wlen);
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_R2p),			(const u32*)zu32NIST_P256_PARAM[2u], (u32)pstDomainParam->u32Data_wlen);
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_R2n), 			(const u32*)zu32NIST_P256_PARAM[3u], (u32)pstDomainParam->u32Data_wlen);
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_ECC_Coef_A), 	(const u32*)zu32NIST_P256_PARAM[6u], (u32)pstDomainParam->u32Data_wlen);
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_ECC_Coef_B), 	(const u32*)zu32NIST_P256_PARAM[7u], (u32)pstDomainParam->u32Data_wlen);
}

#ifndef SBOOT_SOL
SSS_RV ECC_PRVKEY(const stECC_PRIVKEY *pstECCkey, u32 SEG_ID)
{
	SSS_RV ret;

	/*!step 1. seg set Private key */
	/*!- if datawordlen == 0, it will be skipped */
	sss_OS_to_BN(ptrPKA_SEG(SEG_ID), (const stOCTET_STRING*)&pstECCkey->stBigNum_D);

	/*!- check key validity */
	ret = chk_INPUT(SEG_ID);

	if(SSSR_FAIL == ret)
	{
		ret = ERROR_ECC_INVALID_VAL_KEY;
	}

	return ret;
}
#endif

SSS_RV ECC_PUBKEY(const stECC_PUBKEY *pstECCkey, u32 SEG_ID_X)
{
	SSS_RV ret;

	u32 SEG_ID_Y = SEG_ID_X + 1u;

	/*!step 2. seg set Pubkey key */
	/*!if datawordlen == 0, it will be skipped */
	sss_OS_to_BN(ptrPKA_SEG(SEG_ID_X), (const stOCTET_STRING*)&pstECCkey->stBigNum_Qx);
	sss_OS_to_BN(ptrPKA_SEG(SEG_ID_Y), (const stOCTET_STRING*)&pstECCkey->stBigNum_Qy);

	/*!- check key validity */
	ret = chk_INPUT(SEG_ID_X)|chk_INPUT(SEG_ID_Y);

	if(SSSR_FAIL == ret)
	{
		ret = ERROR_ECC_INVALID_VAL_KEY;
	}
	else
	{
		/*!- move to M-domain */
		PKA_exe(FUNC_ID_MM, SEG_ID_X, SEG_ID_ECC_R2p,	SEG_ID_ECC_PrimeP, SEG_ID_X, 16u);
		PKA_exe(FUNC_ID_MM, SEG_ID_Y, SEG_ID_ECC_R2p,	SEG_ID_ECC_PrimeP, SEG_ID_Y, 16u);
		/* make positive for Twoterms */
		PKA_exe(FUNC_ID_MA, SEG_ID_X, SEG_ID_ECC_PrimeP,	SEG_ID_ECC_PrimeP, SEG_ID_X, 16u);
		PKA_exe(FUNC_ID_MA, SEG_ID_Y, SEG_ID_ECC_PrimeP,	SEG_ID_ECC_PrimeP, SEG_ID_Y, 16u);
	}

	return ret;
}

SSS_RV chk_INPUT(u32 SEG_ID)
{
	u32 SEG_ID_Temp = SEG_16;
	u32 SEG_ID_Result = SEG_00;
	SSS_RV ret = SSSR_FAIL;

	/*! > Sequence */
	/*! step 1. Assign 1*/
	PKE_A_1SEG_Clear(SEG_15);
	ptrPKA_SEG(SEG_15)[0u] = 1u;

	/*! step 2. When 1 - target ?= negative, return error */
	/*- 1.	1 - SEG_ID */
	PKA_exe(FUNC_ID_MS, SEG_15, SEG_ID, SEG_ID_N, SEG_ID_Result, SEG_ID_Temp);
	if (TRUE == IS_NEGATIVE(SEG_ID_Result))
	{
		/*! step 3. When (n-1) - target ?= negative, return error */
		/*- 2.	n - 1 */
		PKA_exe(FUNC_ID_MS, SEG_ID_N, SEG_15, SEG_ID_N, SEG_ID_Result, SEG_ID_Temp);
		/*- 3.	SEG_ID - (n - 1) */
		PKA_exe(FUNC_ID_MS, SEG_ID, SEG_ID_Result, SEG_ID_N, SEG_ID_Result, SEG_ID_Temp);

		if (TRUE == IS_NEGATIVE(SEG_ID_Result))
		{
			ret = SSSR_SUCCESS;
		}
	}

	return ret;
}

#ifndef SBOOT_SOL
SSS_RV get_random_scalar256(u32 seg_id)
{
	SSS_RV ret;
	u32 zu32temp[32/4];
	stOCTET_STRING zstTemp;

	/*call rng*/
	zstTemp.pu08Data = (u08*)zu32temp;
	zstTemp.u32DataByteLen = 32u;
	ret = sss_PRNG_Gen(&zstTemp, zstTemp.u32DataByteLen);
	if(SSSR_SUCCESS == ret)
	{
		/*copy to PKSRAM*/
		sss_OS_to_BN(ptrPKA_SEG(seg_id), (const stOCTET_STRING*)&zstTemp);

		/*- modular
		* in order to make less order n, modulus of order n
		* modulus by conversion to m-domain*/
		PKA_exe(FUNC_ID_M1,	seg_id,	SEG_ID_N,	SEG_ID_N,	seg_id,	SEG_16);
		PKA_exe(FUNC_ID_MA,	seg_id,	SEG_ID_N,	SEG_ID_N,	seg_id,	SEG_16);
	}

	return ret;
}
#endif
/*************** END OF FILE **********************************************/

/** \} */
