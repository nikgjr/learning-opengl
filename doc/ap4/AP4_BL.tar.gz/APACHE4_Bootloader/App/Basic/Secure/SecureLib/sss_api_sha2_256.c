/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * \defgroup SSS_SHA2_256	SSS_SHA2_256
 * \ingroup SSS_API
 * \brief					SHA2_256 Library
 * \{
 */

/**
 * \file		sss_api_sha2_256.c
 * \brief		Source for SHA2 API
 * \author		Kiseok Bae (kiseok.bae at samsung.com)
 * \version		V1.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 |V0.01		|2018.03.30	|kiseok		|Beta Version   |
 |V1.00		|2018.04.27	|kiseok		|Final Version  |
 */

/*************** Include Files ************************************************/
#include "sss_lib_util.h"

#include "sss_api_sha2_256.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ****************************************************/

/*************** Prototypes ***************************************************/
SSS_RV sss_SHA2_256(stOCTET_STRING *pstMessage, stOCTET_STRING *pstDigest)
{
	SSS_RV ret;
	stSHA_PARAMS zstHASH_Param;

	/*! > Step 0. Get Hash param data */
	get_Hash256Info(&zstHASH_Param);
	/* assign message to param */
	zstHASH_Param.pstMSG = (stOCTET_STRING*)pstMessage;

	/*! > Step 1. Hash init */
	ret = HMACSHA_init(&zstHASH_Param, HASH_ONLY);
	if (SSSR_SUCCESS == ret)
	{
		/*! > Step 2. Hash update during msg > block */
		HMACSHA_update(&zstHASH_Param);

		/*! > Step 3. Hash final */
		HMACSHA_final(&zstHASH_Param, pstDigest);
	}


	return ret;
}

/*************** END OF FILE **************************************************/

/** \} */
