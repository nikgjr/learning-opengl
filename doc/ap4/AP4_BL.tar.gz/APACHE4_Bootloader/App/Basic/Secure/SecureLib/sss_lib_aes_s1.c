/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * \defgroup SSS_AES_S1		SSS_AES_S1
 * \ingroup SSS_Driver
 * \brief					AES_S1 Driver & Library
 * \{
 */

/**
 * \file		sss_lib_aes_s1.c
 * \brief		Sourcefile for AES_S1 core function
 * \author		Kiseok Bae (kiseok.bae at samsung.com)
 * \version		V1.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 |V0.01		|2018.03.30	|kiseok		|Beta Version   |
 |V1.00		|2018.04.27	|kiseok		|Final Version  |
 */

/*************** Include Files ************************************************/
#include "sss_lib_util.h"
#include "sss_lib_aes_s1.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ************************************************/

/*************** Variable declarations ************************************/

/*************** Error Message ********************************************/

/*************** Prototypes ***************************************************/
static void AES_MODE(u32 objectid, u32 *pu32AES_Control);
static void AES_DIRECTION(u32 objectid, u32 *pu32AES_Control);
static SSS_RV AES_KEY(const stAES_KEY *pstAES_Key, u32 *pu32AES_Control);
static SSS_RV AES_IV(const stOCTET_STRING *pstIV);
static SSS_RV AES_Counter(const stOCTET_STRING *pstNonce, u32 u32CounterByteLen);
static SSS_RV AES_PARAM(u32 objectid, const stAES_PARAMS *pstAES_Params);
static void AESS1_Clear(void);

static void AES_MODE(u32 objectid, u32 *pu32AES_Control)
{
	u32 u32AES_Control = 0u;

	switch (GET_AES_MODE(objectid))
	{
	case OID_AES_CBC:
		u32AES_Control |= OPMODE_CBC;
		break;
	case OID_AES_CTR:
		u32AES_Control |= OPMODE_CTR;
		break;
	default:
		/* OID_AES_ECB */
		u32AES_Control |= OPMODE_ECB;
		break;
	}

	*pu32AES_Control = u32AES_Control;
}

static void AES_DIRECTION(u32 objectid, u32 *pu32AES_Control)
{
	u32 u32AES_Control = GET_ENC_DIRECTION(objectid);

	*pu32AES_Control |= u32AES_Control;
}

static SSS_RV AES_KEY(const stAES_KEY *pstAES_Key, u32 *pu32AES_Control)
{
	SSS_RV ret = SSSR_SUCCESS;
	/* sss_lib_aes_s1.c:90: Warning: C3017W: u32AES_Control may be used before being set */
	u32 u32AES_Control = KEYSIZE_256;

	switch (pstAES_Key->stKey.u32DataByteLen)
	{
	case 16:
		u32AES_Control = KEYSIZE_128;
		break;
	case 24:
		u32AES_Control = KEYSIZE_192;
		break;
	case 32:
		u32AES_Control = KEYSIZE_256;
		break;
	default:
		ret = ERROR_AES_INVALID_LEN_KEY;
		break;
	}

	if (SSSR_SUCCESS == ret)
	{
		*pu32AES_Control |= u32AES_Control;
		sss_OS_to_SFR_Swap(AES_KEY_BASE, (const stOCTET_STRING *)&pstAES_Key->stKey);
	}

	return ret;
}

static SSS_RV AES_IV(const stOCTET_STRING *pstIV)
{
	SSS_RV ret = SSSR_SUCCESS;

	/*
	 * - check CBC IV is 16byte
	 */

	if (pstIV->u32DataByteLen != 16u)
	{
		ret = ERROR_AES_INVALID_LEN_IV;
	}
	else
	{
		sss_OS_to_SFR_Swap(AES_IVCNT_BASE, (const stOCTET_STRING *)pstIV);
	}

	return ret;
}

static SSS_RV AES_Counter(const stOCTET_STRING *pstNonce, u32 u32CounterByteLen)
{
	SSS_RV ret = SSSR_SUCCESS;

	/*
	 * - check CTR Nonce is 16byte
	 */
	if (pstNonce->u32DataByteLen != 16u)
	{
		ret = ERROR_AES_INVALID_LEN_IV;
	}
	else
	{
		/*
		 * - check CTR Counter length & SFR setting
		 */
		switch (u32CounterByteLen)
		{
		case 2:
			SFR_BIT_SET(AES_CONTROL, COUNTER_16BIT);
			break;
		case 4:
			SFR_BIT_SET(AES_CONTROL, COUNTER_32BIT);
			break;
		case 8:
			SFR_BIT_SET(AES_CONTROL, COUNTER_64BIT);
			break;
		case 16:
			SFR_BIT_SET(AES_CONTROL, COUNTER_128BIT);
			break;
		default:
			ret = ERROR_AES_INVALID_LEN_CNT;
			break;
		}

		if (SSSR_SUCCESS == ret)
		{
			sss_OS_to_SFR_Swap(AES_IVCNT_BASE, pstNonce);
		}
	}

	return ret;
}

static SSS_RV AES_PARAM(u32 objectid, const stAES_PARAMS *pstAES_Params)
{
	SSS_RV ret = SSSR_SUCCESS;

	switch (GET_AES_MODE(objectid))
	{

	case OID_AES_CBC:
		ret = AES_IV(&pstAES_Params->stIV);
		break;

	case OID_AES_CTR:
		ret = AES_Counter(&pstAES_Params->stIV, pstAES_Params->u32CntByteLen);
		break;

	default:
		/*!
		 * none : when OID_AES_ECB
		 */
		break;

	}

	return ret;
}

static void AESS1_Clear(void)
{
	/*!
	 * > Sequence
	 */

	/*!
	 * Step1. AES SFR initialize
	 */
	SFR_SET(AES_CONTROL, 0x0u);
	sss_SFRclr(AES_IVCNT_BASE, 4u);
	sss_SFRclr(AES_KEY_BASE, 8u);
}

SSS_RV AESS1_init(u32 objectid, const stAES_KEY *pstAES_Key,
		const stAES_PARAMS *pstAES_Params)
{
	SSS_RV ret;
	u32 u32AES_Control = 0u;
	/*!
	 * > Sequence
	 */

	/*!
	 * Step1. AES_S1 SFR clear
	 */
	AESS1_Clear();

	/*!
	 * Step2. AES Mode Selection
	 */
	AES_MODE(objectid, &u32AES_Control);

	/*!
	 * Step3. AES Direction Selection
	 */
	AES_DIRECTION(objectid, &u32AES_Control);

	/*!
	 * Step4. AES Key Selection
	 */
	ret = AES_KEY(pstAES_Key, &u32AES_Control);
	if (SSSR_SUCCESS == ret)
	{

		/*!
		 * Step5. AES Setting
		 */
		SFR_SET(AES_CONTROL, u32AES_Control);
		ret = AES_PARAM(objectid, pstAES_Params);
	}

	return ret;
}

void AESS1_update(const stOCTET_STRING *pstAES_Input,
		stOCTET_STRING *pstAES_Output)
{
	u32 u32block1;
	u32 u32block2;
	u32 i;

	stOCTET_STRING stTemp_In;
	stOCTET_STRING stTemp_Out;

	u08 zu08Temp[16] = {0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u };

	stTemp_In.pu08Data = pstAES_Input->pu08Data;
	stTemp_In.u32DataByteLen = 16u;
	stTemp_Out.pu08Data = pstAES_Output->pu08Data;
	stTemp_Out.u32DataByteLen = 16u;

	u32block1 = pstAES_Input->u32DataByteLen/16u;
	u32block2 = pstAES_Input->u32DataByteLen&(0x0Fu);


	/*!
	 * > Sequence
	 */

	/*!
	 * Step1.Encrypt or Decrypt blocks
	 */
	for (i=0u;i<u32block1;i++)
	{
		/*!
		 * Step 2. Encrypt or Decrypt blocks
		 */
		WAIT_SFR_BIT_SET(AES_STATUS_ADDR, AES_IN_READY);

		/*!
		 * Step 3. Copy message to SFR
		 * Run AES automatically after writing 4 words in AES_INDATA register.
		 */
		sss_OS_to_SFR_Swap(AES_DATA_BASE, &stTemp_In);

		/*!
		 * Step 4. Check Output ready SFR
		 */

		WAIT_SFR_BIT_SET(AES_STATUS_ADDR, AES_OUT_VALID);

		/*!
		 * Step 5. Get output
		 */
		sss_SFR_to_OS_reversing(&stTemp_Out, AES_DATA_END);
		stTemp_In.pu08Data += 16;
		stTemp_Out.pu08Data += 16;
	}

	if (u32block2 != 0u)
	{
		/* zero padding */
		for (i=0u;i<16u;i++)
		{
			if (i<u32block2)
			{
				zu08Temp[i] = stTemp_In.pu08Data[i];
			}
			else
			{
				zu08Temp[i] = 0x00u;
			}
		}

		stTemp_In.pu08Data = zu08Temp;

		/*!
		 * Step 2. Encrypt or Decrypt blocks
		 */
		WAIT_SFR_BIT_SET(AES_STATUS_ADDR, AES_IN_READY);

		/*!
		 * Step 3. Copy message to SFR
		 * Run AES automatically after writing 4 words in AES_INDATA register.
		 */
		sss_OS_to_SFR_Swap(AES_DATA_BASE, &stTemp_In);

		/*!
		 * Step 4. Check Output ready SFR
		 */
		WAIT_SFR_BIT_SET(AES_STATUS_ADDR, AES_OUT_VALID);

		stTemp_Out.u32DataByteLen = u32block2;

		sss_SFR_to_OS_reversing(&stTemp_Out, AES_DATA_END);
	}

	/*!
	 * Step 6. Update the length of output structure
	 */
	pstAES_Output->u32DataByteLen = pstAES_Input->u32DataByteLen;
}
#ifndef SBOOT_SOL
void AESS1_update_zeropadding(const stOCTET_STRING *pstAES_Input)
{
	u32 u32block1;
	u32 u32block2;
	u32 i;
	u08 zu08Temp[16u] = {0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u, 0x0u };

	stOCTET_STRING stTemp_In;
	stTemp_In.pu08Data = pstAES_Input->pu08Data;
	stTemp_In.u32DataByteLen = 16u;

	u32block1 = pstAES_Input->u32DataByteLen/16u;
	u32block2 = pstAES_Input->u32DataByteLen&(0x0Fu);

	/*!
	 * > Sequence
	 */

	/*!
	 * Step1.Encrypt or Decrypt blocks
	 */
	for (i=0u;i<u32block1;i++)
	{
		/*!
		 * Step 2. Encrypt or Decrypt blocks
		 */
		WAIT_SFR_BIT_SET(AES_STATUS_ADDR, AES_IN_READY);

		/*!
		 * Step 3. Copy message to SFR
		 * Run AES automatically after writing 4 words in AES_INDATA register.
		 */
		sss_OS_to_SFR_Swap(AES_DATA_BASE, &stTemp_In);

		/*!
		 * Step 4. Check Output ready SFR
		 */
		WAIT_SFR_BIT_SET(AES_STATUS_ADDR, AES_OUT_VALID);
		stTemp_In.pu08Data += 16u;
	}

	if (u32block2 != 0u)
	{
		/* zero padding*/
		for (i=0u;i<16u;i++)
		{
			if (i<u32block2)
			{
				zu08Temp[i] = stTemp_In.pu08Data[i];
			}
			else
			{
				zu08Temp[i] = 0x00u;
			}
		}

		stTemp_In.pu08Data = zu08Temp;

		/*!
		 * Step 2. Encrypt or Decrypt blocks
		 */
		WAIT_SFR_BIT_SET(AES_STATUS_ADDR, AES_IN_READY);

		/*!
		 * Step 3. Copy message to SFR
		 * Run AES automatically after writing 4 words in AES_INDATA register.
		 */
		sss_OS_to_SFR_Swap(AES_DATA_BASE, &stTemp_In);

		/*!
		 * Step 4. Check Output ready SFR
		 */
		WAIT_SFR_BIT_SET(AES_STATUS_ADDR, AES_OUT_VALID);
	}

}



void AESS1_get_result(stOCTET_STRING *pstAES_Output)
{
	/*!
	 * > Sequence
	 */

	sss_SFR_to_OS_reversing(pstAES_Output, AES_DATA_END);
}
#endif

/*************** END OF FILE **************************************************/

/** \} */
