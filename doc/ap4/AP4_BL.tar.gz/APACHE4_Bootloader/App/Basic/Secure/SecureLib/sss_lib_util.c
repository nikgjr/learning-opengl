/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * \defgroup SSS_COMMON		SSS_COMMON
 * \ingroup SSS_Solution
 * \brief					Common Source (C & Head) File of SSS_Solution
 * \{
 */

/**
 * \file		sss_lib_util.c
 * \brief		Source file for Utility Functions
 * \author		Kiseok Bae (kiseok.bae at samsung.com)
 * \version		V1.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 |V0.01		|2018.03.30	|kiseok		|Beta Version   |
 |V1.00		|2018.04.27	|kiseok		|Final Version  |
 */

/*************** Include Files ************************************************/
#include "sss_lib_util.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** New Data Types ***********************************************/

/*************** Constants ****************************************************/

/*************** Function Prototypes ******************************************/

/*************** Function *****************************************************/

/*************** Function *****************************************************/

SSS_RV sss_memcmp_u08(const u08	*pu08Src1, const u08 *pu08Src2, u32 u32_byte_size)
{
	u32 i;
	SSS_RV ret = SSSR_FAIL;
	volatile u32 sum = 0u;

	for (i = 0u; i < u32_byte_size; i++)
	{
		if(*(pu08Src1 +i) == *(pu08Src2 +i))
		{
			sum += 0x1u;
		}
	}

	if ((i == sum) && (i == u32_byte_size))
	{
		ret = SSSR_SUCCESS;
	}

	return ret;
}

SSS_RV sss_memcmp_u32(const u32 *pu32Src1, const u32 *pu32Src2, const u32 u32Size)
{
	u32 i;
	SSS_RV ret = SSSR_FAIL;
	volatile u32 sum = 0u;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Check the mis-aligned address
	 */

	if (((((u32) pu32Src1) & ((u32)3u)) != 0u) || ((((u32) pu32Src2) & ((u32)3u)) != 0u))
	{
		ret = sss_memcmp_u08((const u08*) pu32Src1, (const u08*) pu32Src2, 4u * u32Size);
	}
	else
	{
		/*!
		 * Step 2 : Compare src1 and src2
		 */
		for (i = 0u; i < u32Size; i++)
		{
			if(*(pu32Src1 +i) == *(pu32Src2 +i))
			{
				sum += 0x1u;
			}
		}

		if ((i == sum) && (i == u32Size))
		{
			ret = SSSR_SUCCESS;
		}
	}

	return ret;
}

void sss_memclr_u08(u08 *pu08Dst, const u32 u32Size)
{
	u32 i;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Clear data
	 */
	for (i = 0u; i < u32Size; i++)
	{
		*(pu08Dst+i) = 0u;
	}
}

void sss_memclr_u32(u32 *pu32Dst, const u32 u32Size)
{
	u32 i;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Check the mis-aligned address
	 */
	if ( (((u32) pu32Dst) & 3u) != 0u)
	{
		sss_memclr_u08((u08*) pu32Dst, 4u * u32Size);
	}
	else
	{
		/*!
		 * Step 2 : Clear data
		 */
		for (i = 0u; i < u32Size; i++)
		{
			*(pu32Dst+i) = 0u;
		}
	}
}

void sss_SFRclr(u32 u32DstAddr, const u32 u32Size)
{
	u32 i;
	u32 *pu32Dst = (u32*)u32DstAddr;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 2 : Clear data
	 */
	for (i = 0u; i < u32Size; i++)
	{
		*(pu32Dst+i) = 0u;
	}

}

void sss_memcpy_u08(u08 *pu08Dst, const u08 *pu08Src, const u32 u32Size)
{
	u32 i;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Copy data from src to dst
	 */
	for (i = 0u; i < u32Size; i++)
	{
		pu08Dst[i] = pu08Src[i];
	}
}



void sss_memcpy_u32(u32 *pu32Dst, const u32 *pu32Src, const u32 u32Size)
{
	u32 i;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Check the mis-aligned address
	 */
	if ( ((((u32) pu32Src) & 3u) != 0u) ||( (((u32) pu32Dst) & 3u) != 0u))
	{
		sss_memcpy_u08((u08*) pu32Dst, (const u08*) pu32Src, 4u * u32Size);
	}
	else
	{
		/*!
		 * Step 2 : Copy data from src to dst
		 */
		for (i = 0u; i < u32Size; i++)
		{
			pu32Dst[i] = pu32Src[i];
		}
	}
}

void sss_memxor_u08(u08 *pu08Dst,const u08 *pu08Src1, const u08 *pu08Src2, u32 u08Bytelen)
{
	u32 i;

	for (i = 0u; i < u08Bytelen; i++)
	{
		pu08Dst[i] = pu08Src1[i] ^ pu08Src2[i];
	}
}

/*void sss_OS_to_SFR(u32 *pu32SFRAddr, const stOCTET_STRING *pstSrc)*/
void sss_OS_to_SFR(u32 u32SFRAddr, const stOCTET_STRING *pstSrc)
{
	volatile u32 u32Tmp = 0u;
	u08 *pu08Src = pstSrc->pu08Data;
	u32 *pu32Dst = (u32*)u32SFRAddr;
	u32 Index = pstSrc->u32DataByteLen;

	/*!
	 * > Sequence
	 */
	/*!
	 * Step 1 : Check Source address is aligned
	 */
	while (Index >= 4u)
	{
		u32Tmp = (((u32) *(pu08Src + 3u) << 24u)
				| ((u32) *(pu08Src + 2u) << 16u) | ((u32) *(pu08Src + 1u) << 8u)
				| (u32) *(pu08Src));
		*(pu32Dst++) = u32Tmp;

		pu08Src += 4u;
		Index -= 4u;
	}


	/* remainder */
	if (Index != 0u)
	{
		/* set default is zero */
		u32Tmp = 0u;
		/* define update value */
		if (Index >= 3u)
		{
			u32Tmp |= ((u32) *(pu08Src + 2u) << 16u);
		}
		if (Index >= 2u)
		{
			u32Tmp |= ((u32) *(pu08Src + 1u) << 8u);
		}

		u32Tmp |= ((u32) *(pu08Src));

		/* update to destination */
		*(pu32Dst) = u32Tmp;
	}
}

void sss_SFR_to_OS(stOCTET_STRING *pstDst, u32 u32SFRAddr)
{
	volatile u32 u32Tmp;
	u08 *pu08Dst = pstDst->pu08Data;
	u32 *pu32Src = (u32*)u32SFRAddr;
	u32 Index = pstDst->u32DataByteLen;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Check Source address is aligned
	 */
	while (Index >= 4u)
	{
		u32Tmp = *(pu32Src++);
		*(pu08Dst++) = (u08) (u32Tmp);
		*(pu08Dst++) = (u08) (u32Tmp >> 8u);
		*(pu08Dst++) = (u08) (u32Tmp >> 16u);
		*(pu08Dst++) = (u08) (u32Tmp >> 24u);
		Index -= 4u;
	}

	/*!
	 * Step 2 : Reminder
	 */
	if(Index != 0u)
	{
		/* load 32bit data */
		u32Tmp = *pu32Src;
		/* define update value */
		if (Index >= 3u)
		{
			*(pu08Dst + 2u) = (u08) (u32Tmp >> 16u);
		}
		if (Index >= 2u)
		{
			*(pu08Dst + 1u) = (u08) (u32Tmp >> 8u);
		}

		*(pu08Dst) = (u08) (u32Tmp);
	}
}

void sss_SFR_to_OS_reversing(stOCTET_STRING *pstDst, u32 u32SFR_MSW_Addr)
{
	u32 u32Tmp;
	u08 *pu08Dst = pstDst->pu08Data;
	u32 u32Index = pstDst->u32DataByteLen;
	u32 *pu32SrcTemp = (u32*)u32SFR_MSW_Addr;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Convert first multiple of 4 Bytes
	 */
	while (u32Index >= 4u)
	{
		u32Tmp = *pu32SrcTemp--;
		*(pu08Dst + 0u) = (u08) (u32Tmp >> 24);
		*(pu08Dst + 1u) = (u08) (u32Tmp >> 16);
		*(pu08Dst + 2u) = (u08) (u32Tmp >> 8);
		*(pu08Dst + 3u) = (u08) (u32Tmp);

		pu08Dst += 4u;
		u32Index -= 4u;
	}

	/*!
	 * Step 2 : Convert last remainder Bytes
	 */
	if(u32Index != 0u)
	{
		u32Tmp = *pu32SrcTemp;
		if (u32Index >= 3u)
		{
			*(pu08Dst + 2u) = (u08) (u32Tmp >> 8);
		}
		if (u32Index >= 2u)
		{
			*(pu08Dst + 1u) = (u08) (u32Tmp >> 16);
		}

		*(pu08Dst + 0u) = (u08) (u32Tmp >> 24);
	}
}

void sss_OS_to_BN(u32 *pu32Dst, const stOCTET_STRING *pstSrc)
{
	u32 i, u32Tmp;
	u08 *pu08Src = pstSrc->pu08Data;
	u32 u32BLen = pstSrc->u32DataByteLen;
	u32 *pu32Dstptr = pu32Dst;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Check Source address is aligned
	 */
	for (i = u32BLen; i >= 4u; i -= 4u)
	{
		u32Tmp = (((u32) pu08Src[i - 4u]) << 24) | (((u32) pu08Src[i - 3u]) << 16)
				| (((u32) pu08Src[i - 2u]) << 8) | ((u32) pu08Src[i - 1u]);
		*pu32Dstptr++ = u32Tmp;
	}

	/*!
	 * Step 2 : Convert last remainder Bytes
	 */
	if(i != 0u)
	{
		u32Tmp = 0u;
		if (i >= 3u)
		{
			u32Tmp = (((u32) pu08Src[i - 3u]) << 16);
		}
		if (i >= 2u)
		{
			u32Tmp |= (((u32) pu08Src[i - 2u]) << 8);
		}

		u32Tmp |= ((u32) pu08Src[i - 1u]);

		/* update to destination */
		*pu32Dstptr = u32Tmp;
	}
}

void sss_OS_to_SFR_Swap(u32 u32SFRAddr, const stOCTET_STRING *pstSrc)
{
	u32 i, u32Tmp;
	u08 *pu08Src = pstSrc->pu08Data;
	u32 u32BLen = pstSrc->u32DataByteLen;
	u32 *pu32Dstptr = (u32*)u32SFRAddr;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Check Source address is aligned
	 */
	for (i = u32BLen; i >= 4u; i -= 4u)
	{
		u32Tmp = (((u32) pu08Src[i - 4u]) << 24) | (((u32) pu08Src[i - 3u]) << 16)
				| (((u32) pu08Src[i - 2u]) << 8) | ((u32) pu08Src[i - 1u]);
		*pu32Dstptr++ = u32Tmp;
	}

	/*!
	 * Step 2 : Convert last remainder Bytes
	 */
	if(i != 0u)
	{
		u32Tmp = 0u;
		if (i >= 3u)
		{
			u32Tmp = (((u32) pu08Src[i - 3u]) << 16);
		}
		if (i >= 2u)
		{
			u32Tmp |= (((u32) pu08Src[i - 2u]) << 8);
		}

		u32Tmp |= ((u32) pu08Src[i - 1u]);

		/* update to destination */
		*pu32Dstptr = u32Tmp;
	}
}
#ifndef SBOOT_SOL
void sss_BN_to_OS(stOCTET_STRING *pstDst, u32 *pu32Src)
{

	u32 i, u32Tmp;
	u08 *pu08Dst = pstDst->pu08Data;
	u32 *pu32Srcptr = pu32Src;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Convert first multiple of 4 Bytes
	 */
	for (i = pstDst->u32DataByteLen; i >= 4u; i -= 4u)
	{
		u32Tmp = *pu32Srcptr++;
		pu08Dst[i - 4u] = (u08) (u32Tmp >> 24);
		pu08Dst[i - 3u] = (u08) (u32Tmp >> 16);
		pu08Dst[i - 2u] = (u08) (u32Tmp >> 8);
		pu08Dst[i - 1u] = (u08) (u32Tmp);
	}

	/*!
	 * Step 2 : Convert last remainder Bytes
	 */
	if(i != 0u)
	{
		u32Tmp = *pu32Srcptr;
		if (i >= 3u)
		{
			pu08Dst[i - 3u] = (u08) (u32Tmp >> 16u);
		}
		if (i >= 2u)
		{
			pu08Dst[i - 2u] = (u08) (u32Tmp >> 8u);
		}

		pu08Dst[i - 1u] = (u08) (u32Tmp);
	}
}
#endif


void WAIT_SFR_BIT_SET(u32 u32SFRAddr, u32 u32Bitposition)
{
#if 1 /* Compailer Optimizer Error (-O1, -O2 Fail) */
	while( ((*(volatile u32 *)(u32SFRAddr))&u32Bitposition) == 0x0u )
	{
		; /* wait until bit is set			*/
	}
#else
	u32 *pu32Addr = (u32 *)u32SFRAddr;

	while( ((*(pu32Addr))&u32Bitposition) == 0x0u )
	{
		; /* wait until bit is set			*/
	}
#endif
}

void WAIT_SFR_BIT_CLR(u32 u32SFRAddr, u32 u32Bitposition)
{
#if 1 /* Compailer Optimizer Error (-O1, -O2 Fail) */ 
	while( ((*(volatile u32 *)(u32SFRAddr))&u32Bitposition) != 0x0u )
	{
		; /* wait until bit is clr			*/
	}
#else
	u32 *pu32Addr = (u32 *)u32SFRAddr;

	while( ((*(pu32Addr))&u32Bitposition) != 0x0u )
	{
		; /* wait until bit is clr			*/
	}
#endif
}

/*************** END OF FILE **************************************************/

/** \} */
