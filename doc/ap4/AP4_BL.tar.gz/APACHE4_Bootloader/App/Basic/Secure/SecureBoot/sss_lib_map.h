/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/*\
 * \defgroup SSS_COMMON		SSS_COMMON
 * \ingroup SSS_Solution
 * \brief					Common Source (C & Head) File of SSS_Solution
 * \{
 */

/*!
 * \file		sss_lib_map.h
 * \brief		Base Address definition for Samsung Secure Solution
 * \author		Kiseok Bae (kiseok.bae at samsung.com)
 * \version		V1.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 |V0.01		|2018.03.30	|kiseok		|Beta Version   |
 |V1.00		|2018.04.27	|kiseok		|Final Version  |

 */

#ifndef SSS_APACHE4_MAP_H_
#define SSS_APACHE4_MAP_H_

/*************** Include Files ********************************************/
#include "Apache.h"
/*************** Assertions ***********************************************/
#define SBOOT_OTP

/*************** Definitions / Macros *************************************/
/** \name Base Address
 *  \todo update Base Security HW address
 */
/**\{*/
#define AES_REG_BASE                    APACHE_AES_BASE
#define HASH_REG_BASE                   APACHE_HMAC_BASE
#define TRNG_REG_BASE                   APACHE_TRNG_BASE
#define PKA_REG_BASE                    APACHE_PKA_BASE
/**\}*/


#ifdef SBOOT_OTP
/** \name OTP Address
 *  \todo update OTP address
 */
/**\{*/
    #define SBOOT_OTP_SIZE              (0x0100u)
    #define SBOOT_OTP_BASE              (APACHE_IRAM_BASE + APACHE_IRAM_SIZE - SBOOT_OTP_SIZE)
    #define SBOOT_ENABLE                (*(volatile u32 *)(SBOOT_OTP_BASE + 0x0000u))
    #define SBOOT_RBCNT                 (*(volatile u32 *)(SBOOT_OTP_BASE + 0x0004u))
    #define SBOOT_DECKEY_ROM_BASE       (SBOOT_OTP_BASE + 0x0010u) /*256bit, 32byte*/
    #define SBOOT_DECKEY_OTP_BASE       (SBOOT_OTP_BASE + 0x0030u) /*256bit, 32byte*/
    #define SBOOT_DECKEY_MAC_BASE       (SBOOT_OTP_BASE + 0x0050u) /*256bit, 32byte*/
    #define SBOOT_PUBKEY_DIGEST_BASE    (SBOOT_OTP_BASE + 0x0070u) /*256bit(digested), 32byte*/
/**\}*/
  
    #define SBOOT_IMAGE_SIZE            (APACHE_RMAP_SIZE) /*MAX byte length = 512KByte example*/
#endif

/*
 * Macro for SFR
 */
#define SFR_SET(sfr, val)               ((sfr) = (val))			/* 32bit SFR set by 32bit value		*/
#define SFR_BIT_SET(val, bit)           ((val) |= (bit))		/* bit set by bit value				*/
#define SFR_W0i1C(sfr, bit)             ((sfr) = (bit))			/* write 0 ignore & write 1 clear	*/


/*************** Constants ************************************************/

/*************** Variable declarations ************************************/

/*************** Error Message ********************************************/

/*************** Prototypes ***********************************************/

/*************** END OF FILE **********************************************/

#endif  /* SSS_APACHE4_MAP_H_ */

/** \} */
