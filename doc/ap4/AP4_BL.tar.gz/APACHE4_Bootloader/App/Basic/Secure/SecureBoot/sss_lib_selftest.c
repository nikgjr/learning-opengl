/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * \defgroup SSS_SBOOT	SSS_SBOOT
 * \ingroup SSS_Boot
 * \brief					Boot Library
 * \{
 */

/**
 * \file		sss_lib_selftest.c
 * \brief		Source file for KAT Functions
 * \author		Kiseok Bae (kiseok.bae at samsung.com)
 * \version		V1.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 |V0.01		|2018.03.30	|kiseok		|Beta Version   |
 |V1.00		|2018.04.27	|kiseok		|Final Version  |
 */

/*************** Include Files ************************************************/
#include "sss_lib_util.h"
#include "sss_lib_selftest.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ****************************************************/

/*************** Variable declarations ****************************************/

/*************** Prototype ****************************************************/
static SSS_RV KAT_AES_CBC(u32 *pu32Output);
static SSS_RV KAT_SHA2_256(u32 *pu32Output);
static SSS_RV KAT_HMACSHA2_256(u32 *pu32Output);
static SSS_RV KAT_ECDSA256_Verify(void);

/*************** Function ****************************************************/
static SSS_RV KAT_AES_CBC(u32 *pu32Output)
{
	u32 ret;

	stAES_KEY 		zstAES_Key;
	stAES_PARAMS 	zstAES_Param;
	stOCTET_STRING 	zstAES_Input;
	stOCTET_STRING 	zstAES_Cipher;
	/*
	 * AES CBC Cipher from gzu08TV_NIST_P256_SHA256_Digest_00 with zero 256bit key zero IV
	 */
	u08 gzu08TV_AES_CBC_CIPHER[32] =
	{ 0xDEu, 0x7Eu, 0xF0u, 0xFEu, 0xD6u, 0x51u, 0xEEu, 0x2Cu, 0x05u, 0xDCu, 0xCAu, 0xB5u, 0x9Fu,
			0xB0u, 0xA7u, 0xC7u, 0xBBu, 0xA9u, 0x2Bu, 0x1Au, 0x60u, 0xC6u, 0xADu, 0x33u, 0xDBu,
			0x47u, 0x1Bu, 0x56u, 0xC2u, 0xB5u, 0xEFu, 0xF3u, };

	/*
	 * message digest 32byte
	 * 44ACF6B7E36C1342C2C5897204FE09504E1E2EFB1A900377DBC4E7A6A133EC56
	 */
	u08 gzu08TV_NIST_P256_SHA256_Digest_00[32] =
	{ 0x44u, 0xACu, 0xF6u, 0xB7u, 0xE3u, 0x6Cu, 0x13u, 0x42u, 0xC2u, 0xC5u, 0x89u, 0x72u, 0x04u,
			0xFEu, 0x09u, 0x50u, 0x4Eu, 0x1Eu, 0x2Eu, 0xFBu, 0x1Au, 0x90u, 0x03u, 0x77u, 0xDBu,
			0xC4u, 0xE7u, 0xA6u, 0xA1u, 0x33u, 0xECu, 0x56u };


	/*! step 1 : set input parameter */
	/*! - set Key */
	zstAES_Key.stKey.pu08Data = (u08*) pu32Output;
	zstAES_Key.stKey.u32DataByteLen = 32u;
	/*! - set parameter */
	zstAES_Param.stIV.pu08Data = (u08*) pu32Output;
	zstAES_Param.stIV.u32DataByteLen = 16u;
	/*! - set input */
	zstAES_Input.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Digest_00;
	zstAES_Input.u32DataByteLen = 32u;
	/*! - set output */
	zstAES_Cipher.pu08Data = (u08*) pu32Output;

	/*! step 2 : Check target function  */
	ret = sss_AES_Enc_CBC(&zstAES_Param, &zstAES_Key, &zstAES_Input,
			&zstAES_Cipher);

	/*! step 3 : Compare with known answer  */
	if (SSSR_SUCCESS == ret)
	{
		ret = sss_memcmp_u08((const u08*)zstAES_Cipher.pu08Data, (const u08*) gzu08TV_AES_CBC_CIPHER, zstAES_Cipher.u32DataByteLen);
	}

	return ret;
}

static SSS_RV KAT_SHA2_256(u32 *pu32Output)
{
	u32 ret;

	stOCTET_STRING zstMessage;
	stOCTET_STRING zstDigest;

	/*
	 * message 128byte
	 * 5905238877c77421f73e43ee3da6f2d9e2ccad5fc942dcec0cbd25482935faaf416983fe165b1a045ee2bcd2e6dca3bdf46c4310a7461f9a37960ca672d3feb5473e253605fb1ddfd28065b53cb5858a8ad28175bf9bd386a5e471ea7a65c17cc934a9d791e91491eb3754d03799790fe2d308d16146d5c9b0d0debd97d79ce8
	 */
	u08 gzu08TV_NIST_P256_SHA256_Msg_00[128] =
	{ 0x59u, 0x05u, 0x23u, 0x88u, 0x77u, 0xc7u, 0x74u, 0x21u, 0xf7u, 0x3eu, 0x43u, 0xeeu, 0x3du,
			0xa6u, 0xf2u, 0xd9u, 0xe2u, 0xccu, 0xadu, 0x5fu, 0xc9u, 0x42u, 0xdcu, 0xecu, 0x0cu,
			0xbdu, 0x25u, 0x48u, 0x29u, 0x35u, 0xfau, 0xafu, 0x41u, 0x69u, 0x83u, 0xfeu, 0x16u,
			0x5bu, 0x1au, 0x04u, 0x5eu, 0xe2u, 0xbcu, 0xd2u, 0xe6u, 0xdcu, 0xa3u, 0xbdu, 0xf4u,
			0x6cu, 0x43u, 0x10u, 0xa7u, 0x46u, 0x1fu, 0x9au, 0x37u, 0x96u, 0x0cu, 0xa6u, 0x72u,
			0xd3u, 0xfeu, 0xb5u, 0x47u, 0x3eu, 0x25u, 0x36u, 0x05u, 0xfbu, 0x1du, 0xdfu, 0xd2u,
			0x80u, 0x65u, 0xb5u, 0x3cu, 0xb5u, 0x85u, 0x8au, 0x8au, 0xd2u, 0x81u, 0x75u, 0xbfu,
			0x9bu, 0xd3u, 0x86u, 0xa5u, 0xe4u, 0x71u, 0xeau, 0x7au, 0x65u, 0xc1u, 0x7cu, 0xc9u,
			0x34u, 0xa9u, 0xd7u, 0x91u, 0xe9u, 0x14u, 0x91u, 0xebu, 0x37u, 0x54u, 0xd0u, 0x37u,
			0x99u, 0x79u, 0x0fu, 0xe2u, 0xd3u, 0x08u, 0xd1u, 0x61u, 0x46u, 0xd5u, 0xc9u, 0xb0u,
			0xd0u, 0xdeu, 0xbdu, 0x97u, 0xd7u, 0x9cu, 0xe8u };

	/*
	 * message digest 32byte
	 * 44ACF6B7E36C1342C2C5897204FE09504E1E2EFB1A900377DBC4E7A6A133EC56
	 */
	u08 gzu08TV_NIST_P256_SHA256_Digest_00[32] =
	{ 0x44u, 0xACu, 0xF6u, 0xB7u, 0xE3u, 0x6Cu, 0x13u, 0x42u, 0xC2u, 0xC5u, 0x89u, 0x72u, 0x04u,
			0xFEu, 0x09u, 0x50u, 0x4Eu, 0x1Eu, 0x2Eu, 0xFBu, 0x1Au, 0x90u, 0x03u, 0x77u, 0xDBu,
			0xC4u, 0xE7u, 0xA6u, 0xA1u, 0x33u, 0xECu, 0x56u };

	/*! step 1 : set input parameter */
	zstMessage.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Msg_00;
	zstMessage.u32DataByteLen = 128u;
	zstDigest.pu08Data = (u08*) pu32Output;
	zstDigest.u32DataByteLen = 0u;

	/*! step 2 : call target function */
	ret = sss_SHA2_256(&zstMessage, &zstDigest);

	/*! step 3 : Compare with known answer  */
	if (SSSR_SUCCESS == ret)
	{
		ret = sss_memcmp_u08((const u08*) zstDigest.pu08Data, (const u08*) gzu08TV_NIST_P256_SHA256_Digest_00, zstDigest.u32DataByteLen);
	}

	return ret;
}

static SSS_RV KAT_HMACSHA2_256(u32 *pu32Output)
{
	u32 ret;

	stOCTET_STRING zstMessage;
	stOCTET_STRING zstDigest;
	stOCTET_STRING zstKey;

	/*
	 * message 128byte
	 * 5905238877c77421f73e43ee3da6f2d9e2ccad5fc942dcec0cbd25482935faaf416983fe165b1a045ee2bcd2e6dca3bdf46c4310a7461f9a37960ca672d3feb5473e253605fb1ddfd28065b53cb5858a8ad28175bf9bd386a5e471ea7a65c17cc934a9d791e91491eb3754d03799790fe2d308d16146d5c9b0d0debd97d79ce8
	 */
	u08 gzu08TV_NIST_P256_SHA256_Msg_00[128] =
	{ 0x59u, 0x05u, 0x23u, 0x88u, 0x77u, 0xc7u, 0x74u, 0x21u, 0xf7u, 0x3eu, 0x43u, 0xeeu, 0x3du,
			0xa6u, 0xf2u, 0xd9u, 0xe2u, 0xccu, 0xadu, 0x5fu, 0xc9u, 0x42u, 0xdcu, 0xecu, 0x0cu,
			0xbdu, 0x25u, 0x48u, 0x29u, 0x35u, 0xfau, 0xafu, 0x41u, 0x69u, 0x83u, 0xfeu, 0x16u,
			0x5bu, 0x1au, 0x04u, 0x5eu, 0xe2u, 0xbcu, 0xd2u, 0xe6u, 0xdcu, 0xa3u, 0xbdu, 0xf4u,
			0x6cu, 0x43u, 0x10u, 0xa7u, 0x46u, 0x1fu, 0x9au, 0x37u, 0x96u, 0x0cu, 0xa6u, 0x72u,
			0xd3u, 0xfeu, 0xb5u, 0x47u, 0x3eu, 0x25u, 0x36u, 0x05u, 0xfbu, 0x1du, 0xdfu, 0xd2u,
			0x80u, 0x65u, 0xb5u, 0x3cu, 0xb5u, 0x85u, 0x8au, 0x8au, 0xd2u, 0x81u, 0x75u, 0xbfu,
			0x9bu, 0xd3u, 0x86u, 0xa5u, 0xe4u, 0x71u, 0xeau, 0x7au, 0x65u, 0xc1u, 0x7cu, 0xc9u,
			0x34u, 0xa9u, 0xd7u, 0x91u, 0xe9u, 0x14u, 0x91u, 0xebu, 0x37u, 0x54u, 0xd0u, 0x37u,
			0x99u, 0x79u, 0x0fu, 0xe2u, 0xd3u, 0x08u, 0xd1u, 0x61u, 0x46u, 0xd5u, 0xc9u, 0xb0u,
			0xd0u, 0xdeu, 0xbdu, 0x97u, 0xd7u, 0x9cu, 0xe8u };

	/*
	 * HMAC TV from gzu08TV_NIST_P256_SHA256_Msg_00 with zero 256bit key
	 */
	u08 gzu08TV_HMAC256[32] =
	{ 0x44u, 0x77u, 0xf1u, 0x77u, 0x4cu, 0x51u, 0x40u, 0xc8u, 0x4bu, 0x46u, 0x97u, 0x46u, 0xc5u,
			0x50u, 0xceu, 0x09u, 0x8au, 0x71u, 0xf9u, 0xdau, 0xacu, 0x84u, 0xa0u, 0xa6u, 0x18u,
			0x23u, 0x84u, 0x01u, 0x4au, 0xcdu, 0x92u, 0x5fu, };

	/*! step 1 : set input parameter */
	zstMessage.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Msg_00;
	zstMessage.u32DataByteLen = 128u;
	zstDigest.pu08Data = (u08*) pu32Output;
	zstDigest.u32DataByteLen = 0u;
	zstKey.pu08Data = (u08*) pu32Output;
	zstKey.u32DataByteLen = 32u;

	/*! step 2 : call target function */
	ret = sss_HMAC_SHA2_256(&zstKey, &zstMessage, &zstDigest);

	/*! step 3 : Compare with known answer  */
	if (SSSR_SUCCESS == ret)
	{
		ret = sss_memcmp_u08(zstDigest.pu08Data,
				(u08*) gzu08TV_HMAC256,
				zstDigest.u32DataByteLen);
	}

	return ret;
}

static SSS_RV KAT_ECDSA256_Verify(void)
{
	u32 ret;

	stOCTET_STRING zstDigest;
	stECC_PUBKEY zstEcdsaPubKey;
	stECDSA_SIGN zstSignature;

	/*
	 * message digest 32byte
	 * 44ACF6B7E36C1342C2C5897204FE09504E1E2EFB1A900377DBC4E7A6A133EC56
	 */
	u08 gzu08TV_NIST_P256_SHA256_Digest_00[32] =
	{ 0x44u, 0xACu, 0xF6u, 0xB7u, 0xE3u, 0x6Cu, 0x13u, 0x42u, 0xC2u, 0xC5u, 0x89u, 0x72u, 0x04u,
			0xFEu, 0x09u, 0x50u, 0x4Eu, 0x1Eu, 0x2Eu, 0xFBu, 0x1Au, 0x90u, 0x03u, 0x77u, 0xDBu,
			0xC4u, 0xE7u, 0xA6u, 0xA1u, 0x33u, 0xECu, 0x56u };

	/*
	 * public key 64byte
	 * 1ccbe91c075fc7f4f033bfa248db8fccd3565de94bbfb12f3c59ff46c271bf83ce4014c68811f9a21a1fdb2c0e6113e06db7ca93b7404e78dc7ccd5ca89a4ca9
	 */
	u08 gzu08TV_NIST_P256_SHA256_Q_00[64] =
	{ 0x1cu, 0xcbu, 0xe9u, 0x1cu, 0x07u, 0x5fu, 0xc7u, 0xf4u, 0xf0u, 0x33u, 0xbfu, 0xa2u, 0x48u,
			0xdbu, 0x8fu, 0xccu, 0xd3u, 0x56u, 0x5du, 0xe9u, 0x4bu, 0xbfu, 0xb1u, 0x2fu, 0x3cu,
			0x59u, 0xffu, 0x46u, 0xc2u, 0x71u, 0xbfu, 0x83u, 0xceu, 0x40u, 0x14u, 0xc6u, 0x88u,
			0x11u, 0xf9u, 0xa2u, 0x1au, 0x1fu, 0xdbu, 0x2cu, 0x0eu, 0x61u, 0x13u, 0xe0u, 0x6du,
			0xb7u, 0xcau, 0x93u, 0xb7u, 0x40u, 0x4eu, 0x78u, 0xdcu, 0x7cu, 0xcdu, 0x5cu, 0xa8u,
			0x9au, 0x4cu, 0xa9u };
	/*
	 * sign 64byte
	 * f3ac8061b514795b8843e3d6629527ed2afd6b1f6a555a7acabb5e6f79c8c2ac8bf77819ca05a6b2786c76262bf7371cef97b218e96f175a3ccdda2acc058903
	 */
	u08 gzu08TV_NIST_P256_SHA256_Sign_00[64] =
	{ 0xf3u, 0xacu, 0x80u, 0x61u, 0xb5u, 0x14u, 0x79u, 0x5bu, 0x88u, 0x43u, 0xe3u, 0xd6u, 0x62u,
			0x95u, 0x27u, 0xedu, 0x2au, 0xfdu, 0x6bu, 0x1fu, 0x6au, 0x55u, 0x5au, 0x7au, 0xcau,
			0xbbu, 0x5eu, 0x6fu, 0x79u, 0xc8u, 0xc2u, 0xacu, 0x8bu, 0xf7u, 0x78u, 0x19u, 0xcau,
			0x05u, 0xa6u, 0xb2u, 0x78u, 0x6cu, 0x76u, 0x26u, 0x2bu, 0xf7u, 0x37u, 0x1cu, 0xefu,
			0x97u, 0xb2u, 0x18u, 0xe9u, 0x6fu, 0x17u, 0x5au, 0x3cu, 0xcdu, 0xdau, 0x2au, 0xccu,
			0x05u, 0x89u, 0x03u };

	/*! Step 1. set input parameter */
	/*! - set key */
	zstEcdsaPubKey.u32KeyType = 0u;
	zstEcdsaPubKey.u32EllipticCurveID = OID_ECDSA_P256_SHA2_256;
	zstEcdsaPubKey.stBigNum_Qx.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Q_00;
	zstEcdsaPubKey.stBigNum_Qx.u32DataByteLen = 64u/2u;
	zstEcdsaPubKey.stBigNum_Qy.pu08Data = (u08*) &gzu08TV_NIST_P256_SHA256_Q_00[zstEcdsaPubKey.stBigNum_Qx.u32DataByteLen];
	zstEcdsaPubKey.stBigNum_Qy.u32DataByteLen =64u/2u;
	/*! - set digested message */
	zstDigest.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Digest_00;
	zstDigest.u32DataByteLen = 32u;

	/*! - set signature */
	zstSignature.u32ECDSA_OID = zstEcdsaPubKey.u32EllipticCurveID;
	zstSignature.stSign_r.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Sign_00;
	zstSignature.stSign_r.u32DataByteLen = 64u/2u;
	zstSignature.stSign_s.pu08Data = (u08*) &zstSignature.stSign_r.pu08Data[zstSignature.stSign_r.u32DataByteLen];
	zstSignature.stSign_s.u32DataByteLen = 64u/2u;

	/*!step 2. Call ECDSA Verify API */
	ret = sss_ECDSA_Verify_256(&zstEcdsaPubKey, &zstDigest, &zstSignature);

	return ret;
}

SSS_RV sss_boot_KAT(void)
{
	u32 ret;
	u32 zu32Output[32u / 4u] =
	{ 0, };

	/*! > Step 1. AES CBC Test */
	ret = KAT_AES_CBC(zu32Output);
	sss_memclr_u32(zu32Output, 32u/4u);

	/*! > Step 2. SHA2 256 Test */
	ret += KAT_SHA2_256(zu32Output);
	sss_memclr_u32(zu32Output, 32u/4u);

	/*! > Step 3. HMACSHA2 256 Test */
	ret += KAT_HMACSHA2_256(zu32Output);
	sss_memclr_u32(zu32Output, 32u/4u);

	/*! > Step 4. ECDSA Verify Test */
	ret += KAT_ECDSA256_Verify();

	return ret;
}

/*************** END OF FILE **************************************************/

/** \} */
