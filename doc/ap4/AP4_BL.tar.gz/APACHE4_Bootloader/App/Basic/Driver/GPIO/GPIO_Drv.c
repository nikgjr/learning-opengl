/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

void ncDrv_GPIO_SetData(UINT32 Pad_Id, BOOL level)
{
    UINT32 Reg;      
    UINT32 group = Pad_Id/32;
    UINT32 port  = Pad_Id%32;


    // Set GPIO Direction - OutPut Mode
    Reg = REGRW32((APACHE_GPIO_BASE + (group*0x10)), 0x4);
    Reg |= (1<<port);
    REGRW32((APACHE_GPIO_BASE + (group*0x10)), 0x4) = Reg;


    // Set GPIO Level 
    Reg = REGRW32(APACHE_GPIO_BASE + (group*0x10), 0x08);
    if(level == LOW)
        Reg &= ~(1<<port);
    else
        Reg |= (1<<port);
    REGRW32(APACHE_GPIO_BASE + (group*0x10), 0x08) = Reg;
}


/* End Of File */

