/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#ifdef __DMA_ENABLE__

//#define __SYS_BIG_ENDIAN__  // for Aldebaran










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT32  mSrcAddr;
    UINT32  mDestAddr;
    UINT32  mSize;
    UINT32  mNextAddr;
} tDMA_LINK, *ptDMA_LINK;











/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __dma_debug_reg_dump(eDMA_CH Ch)
{
#if 0 // Debug
    UINT32 i;

    // Channel Register
    for(i=0; i<0x100; i+=4)
    {
        if(!(i%0x20)) 
            DEBUGMSG(MSGINFO, "\n0x%08x:", rDMAC_BASE(Ch) + i);
        DEBUGMSG(MSGINFO, " %08x", REGRW32(rDMAC_BASE(Ch), i));
    }	

    // Core Register
    for(i=0x1000; i<0x1100; i+=4)
    {
        if(!(i%0x20)) 
            DEBUGMSG(MSGINFO, "\n0x%08x:", rDMAC_BASE(0) + i);
        DEBUGMSG(MSGINFO, " %08x", REGRW32(rDMAC_BASE(0), i));
    }
#endif
}


static void __dma_debug_mem_dump(UINT32* pAddr, UINT32 Size)
{
#if 0 // Debug
    UINT32 i;

    for(i=0; i<Size; i++)
    {
        if(!(i%4)) 
            DEBUGMSG(MSGINFO, "\n0x%08x:", pAddr);
        DEBUGMSG(MSGINFO, " %08x", *pAddr++);
    }	
#endif
}


static UINT32 __dma_swap32(UINT32 a) 
{      
    UINT32 a_rev;

#ifdef __SYS_BIG_ENDIAN__
    a_rev = ((a&0xff)<<24) | ((a&0xff00)<<8) | ((a&0xff0000)>>8) | ((a&0xff000000)>>24);
#else
    a_rev = a;
#endif

    return a_rev;
}


static void ncDrv_DMA_CacheFlush(ptDMA_INFO ptDMA, UINT32 SrcAddr, UINT32 DestAddr, UINT32 Length)
{
    UINT32 InstAddr = ptDMA->mDMA_Param.mInstAddr;
    UINT32 InstSize = 0;

    if(ptDMA->mDMA_Param.mReqType == DMA_MEM_TO_MEM)
    {
        if(1) // SrcAddr < APACHE_DRAM_BASE)
        {
            if(ptDMA->mDMA_Param.mRxIncrEn == ENABLE)
                ASM_DCACHE_FLUSH(SrcAddr, Length);
            else
                ASM_DCACHE_FLUSH(SrcAddr, 0x0);
        }

        if(1) // DestAddr < APACHE_DRAM_BASE)
        {
            if(ptDMA->mDMA_Param.mTxIncrEn == ENABLE)
                ASM_DCACHE_FLUSH(DestAddr, Length);
            else
                ASM_DCACHE_FLUSH(DestAddr, 0x0);
        }
    }
    else if(ptDMA->mDMA_Param.mReqType == DMA_MEM_TO_DEV)
    {
        if(1) // SrcAddr < APACHE_DRAM_BASE)
        {
            if(ptDMA->mDMA_Param.mRxIncrEn == ENABLE)
                ASM_DCACHE_FLUSH(SrcAddr, Length);
            else
                ASM_DCACHE_FLUSH(SrcAddr, 0x0);
        }

        // Tx : device is non-cacheable. (do not flushed)
    }
    else if(ptDMA->mDMA_Param.mReqType == DMA_DEV_TO_MEM)
    {
        // Rx : device is non-cacheable. (do not flushed)

        if(1) // DestAddr < APACHE_DRAM_BASE)
        {
            if(ptDMA->mDMA_Param.mTxIncrEn == ENABLE)
                ASM_DCACHE_FLUSH(DestAddr, Length);
            else
                ASM_DCACHE_FLUSH(DestAddr, 0x0);
        }
    }


    if(1) // InstAddr < APACHE_DRAM_BASE)
    {
        // Check Instruction Buffer Size
        InstSize = (Length/DMA_TRANSFER_SIZE)*0x10;
        if(Length%DMA_TRANSFER_SIZE)
            InstSize+=0x10;

        if((InstSize != 0) && (InstAddr != 0))
        {
            ASM_DCACHE_FLUSH(InstAddr, InstSize);
        }
    }
}


static void ncDrv_DMA_SetIntc(eDMA_CH Ch, BOOL OnOff)
{
    INT32 Reg;

    // Interrupt Status Clear
    Reg = (REGRW32(rDMAC_BASE(Ch), rDMAC_INT_RSTS)&bDMAC_INT_MASK);
    REGRW32(rDMAC_BASE(Ch), rDMAC_INT_CLR)  = Reg;

    if(OnOff == ON)
        REGRW32(rDMAC_BASE(Ch), rDMAC_INT_EN) = (bDMAC_INT_ERR|(1<<bDMAC_INT_END));
    else
        REGRW32(rDMAC_BASE(Ch), rDMAC_INT_EN) = 0x0; 
}


static void ncDrv_DMA_SetPeriId(ptDMA_INFO ptDMA)
{
    UINT32 Reg;
    
    if(ptDMA->mDMA_Param.mReqType == DMA_MEM_TO_DEV)
        Reg = (ptDMA->mDMA_Param.mPeriNum<<bDMAC_PERI_WR_NUM);
    else if(ptDMA->mDMA_Param.mReqType == DMA_DEV_TO_MEM)
        Reg = (ptDMA->mDMA_Param.mPeriNum<<bDMAC_PERI_RD_NUM);
    else
        Reg = 0x0;
    REGRW32(rDMAC_BASE(ptDMA->mDMA_ChNum), rDMAC_PERI) = Reg;    
}



static void ncDrv_DMA_SetSwap(ptDMA_INFO ptDMA)
{
    UINT32 Reg;
    
    Reg = (ptDMA->mDMA_Param.mSwap<<bDMAC_CR2_SWAP);
    REGRW32(rDMAC_BASE(ptDMA->mDMA_ChNum), rDMAC_CR2) = Reg;
}


static void ncDrv_DMA_SetBurstLen(ptDMA_INFO ptDMA, UINT32 Length)
{
    eDMA_CH Ch;
    UINT32  Reg;
    UINT32  BurstLen;


    // DMA Channel 
    Ch = ptDMA->mDMA_ChNum;


    // Set Read Ctrl
    BurstLen = (ptDMA->mDMA_Param.mRxBurstLen)?ptDMA->mDMA_Param.mRxBurstLen:1;
    if(ptDMA->mDMA_Param.mRxIncrEn == DISABLE)
    {
        if((BurstLen > 4) || (BurstLen == 3))
        {
            if((Length%4) == 0)         BurstLen = 4;
            else if((Length%2) == 0)    BurstLen = 2;
            else                        BurstLen = 1;
        }
    }
    
    Reg = (ptDMA->mDMA_Param.mRxIncrEn<<bDMAC_CR0_INCR)
        | (1<<bDMAC_CR0_CMD_MAX)        // Fixed
        | (1<<bDMAC_CR0_TOKENS)         // Fixed
        | (BurstLen<<bDMAC_CR0_BURST);

#ifdef __SYS_BIG_ENDIAN__
    if(ptDMA->mDMA_Param.mReqType == DMA_DEV_TO_MEM)
        Reg |= (1<<bDMAC_CR0_SWAP);
#endif
    
    REGRW32(rDMAC_BASE(Ch), rDMAC_CR0) = Reg;

    //DEBUGMSG(MSGINFO, "[DMA_Drv] Rx(%d, %d)", ptDMA->mDMA_Param.mRxIncrEn, BurstLen);


    // Set Write Ctrl
    BurstLen = (ptDMA->mDMA_Param.mRxBurstLen)?ptDMA->mDMA_Param.mRxBurstLen:1;
    if(ptDMA->mDMA_Param.mTxIncrEn == DISABLE)
    {
        if((BurstLen > 4) || (BurstLen == 3))
        {
            if((Length%4) == 0)         BurstLen = 4;
            else if((Length%2) == 0)    BurstLen = 2;
            else                        BurstLen = 1;
        }
    }

    Reg = (ptDMA->mDMA_Param.mTxIncrEn<<bDMAC_CR1_INCR)
        | (1<<bDMAC_CR1_CMD_MAX)        // Fixed
        | (1<<bDMAC_CR1_TOKENS)         // Fixed
        | (BurstLen<<bDMAC_CR1_BURST);

#ifdef __SYS_BIG_ENDIAN__
    if(ptDMA->mDMA_Param.mReqType == DMA_MEM_TO_DEV)
        Reg |= (1<<bDMAC_CR1_SWAP);
#endif

    REGRW32(rDMAC_BASE(Ch), rDMAC_CR1) = Reg;

    //DEBUGMSG(MSGINFO, " Tx(%d, %d)\n", ptDMA->mDMA_Param.mTxIncrEn, BurstLen);
}


static INT32 ncDrv_DMA_CreateLink(ptDMA_INFO ptDMA, UINT32 SrcAddr, UINT32 DestAddr, UINT32 Length)
{ 
    INT32 ret = NC_SUCCESS;
    
    eDMA_CH Ch = (eDMA_CH)ptDMA->mDMA_ChNum;
    UINT32 InstAddr = ptDMA->mDMA_Param.mInstAddr;    
    ptDMA_LINK pLink = NULL;    
    
    UINT32 i;
    UINT32 TranferEnd;


    // Check 16 Align
    if(InstAddr&0xf)
    {
        //DEBUGMSG(MSGERR, "[DMA_Drv] Inst Buff Address 16_Align Error : %08x\n", InstAddr);
        ret = NC_FAILURE;
    }
    else
    {
        // Virtual to Physical
        if(InstAddr != 0)
        {
            // DMA InstAddr 
            pLink = (ptDMA_LINK)(InstAddr);
        }
 
        // DMA Tranfer End Flag. 
        TranferEnd = (bDMAC_LINK_END|bDMAC_LINK_IEN);


        // bDMAC_SIZE_MAX = Align(bDMAC_SIZE_MASK)
        if((Length > DMA_TRANSFER_SIZE) && (InstAddr != 0))
        {
            i = 0;
            while(Length > 0)
            {
                pLink[i].mSrcAddr  = __dma_swap32(SrcAddr);
                pLink[i].mDestAddr = __dma_swap32(DestAddr);
                pLink[i].mSize     = __dma_swap32((Length >= DMA_TRANSFER_SIZE)?DMA_TRANSFER_SIZE:Length);

                if(ptDMA->mDMA_Param.mRxIncrEn == ENABLE)
                    SrcAddr  += DMA_TRANSFER_SIZE;
                if(ptDMA->mDMA_Param.mTxIncrEn == ENABLE)
                    DestAddr += DMA_TRANSFER_SIZE;
                Length -= ((Length >= DMA_TRANSFER_SIZE)?DMA_TRANSFER_SIZE:Length);

                if(Length <= 0)
                    pLink[i].mNextAddr = __dma_swap32(TranferEnd);
                else
                    pLink[i].mNextAddr = __dma_swap32(((UINT32)(&pLink[i+1]))&0xfffffff0);
                i++;
            }

            __dma_debug_mem_dump((UINT32*)(pLink), (i*4));
            
            // First Link Set
            REGRW32(rDMAC_BASE(Ch), rDMAC_SRC)  = __dma_swap32(pLink[0].mSrcAddr);
            REGRW32(rDMAC_BASE(Ch), rDMAC_DEST) = __dma_swap32(pLink[0].mDestAddr);
            REGRW32(rDMAC_BASE(Ch), rDMAC_SIZE) = __dma_swap32(pLink[0].mSize);
            REGRW32(rDMAC_BASE(Ch), rDMAC_LINK) = __dma_swap32(pLink[0].mNextAddr);
        }
        else
        {
            // One Link Set
            REGRW32(rDMAC_BASE(Ch), rDMAC_SRC)  = SrcAddr;
            REGRW32(rDMAC_BASE(Ch), rDMAC_DEST) = DestAddr;    
            REGRW32(rDMAC_BASE(Ch), rDMAC_SIZE) = Length;   
            REGRW32(rDMAC_BASE(Ch), rDMAC_LINK) = TranferEnd;
        }
    }

    return ret;
}


static void ncDrv_DMA_Stop(eDMA_CH Ch)
{   
    // Interrupt Disable    
    ncDrv_DMA_SetIntc(Ch, OFF);

    // Channel Disable
    REGRW32(rDMAC_BASE(Ch), rDMAC_EN) = bDMAC_CH_DIS;
}


static void ncDrv_DMA_Start(eDMA_CH Ch, BOOL IntEn)
{
    // Set Interrupt On/Off
    ncDrv_DMA_SetIntc(Ch, IntEn);

    // Channel Enable
    REGRW32(rDMAC_BASE(Ch), rDMAC_EN) = bDMAC_CH_EN;  

    // Channel Start
    REGRW32(rDMAC_BASE(Ch), rDMAC_START) = bDMAC_CH_START;
}


INT32 ncDrv_DMA_CheckComplete(eDMA_CH Ch)
{
    INT32 ret = ON;
    UINT32 Reg;

    // Get Interrupt Status
    Reg = (REGRW32(rDMAC_BASE(Ch), rDMAC_INT_RSTS)&bDMAC_INT_MASK);

    // Clear Interrupt
    REGRW32(rDMAC_BASE(Ch), rDMAC_INT_CLR) = Reg;

    // DMA Done Check
    if(Reg & (1<<bDMAC_INT_END))
        ret = NC_SUCCESS;
    else if(Reg & bDMAC_INT_ERR)
        ret = NC_FAILURE;
        
    return ret;
}


INT32 ncDrv_DMA_Transfer(ptDMA_INFO ptDMA, UINT32 SrcAddr, UINT32 DestAddr, UINT32 Length)
{
    INT32   ret = NC_SUCCESS;
    eDMA_CH Ch;
    
    
    if((ptDMA != NULL) && (Length != 0))
    {        
        // Set Channel
        Ch = ptDMA->mDMA_ChNum;


        // Stop DMA
        ncDrv_DMA_Stop(Ch);


        // Set DMA Link
        ret = ncDrv_DMA_CreateLink(ptDMA, SrcAddr, DestAddr, Length);
        
        if(ret == NC_SUCCESS)
        {
            // Set Burst Ctrl
            ncDrv_DMA_SetBurstLen(ptDMA, Length);


            // Set Swap 
            ncDrv_DMA_SetSwap(ptDMA);

        
            // Set Device(Peripheral) Number
            ncDrv_DMA_SetPeriId(ptDMA);


            // display dma channel register
            __dma_debug_reg_dump(Ch);


            // cache clean and invalidate data
            ncDrv_DMA_CacheFlush(ptDMA, SrcAddr, DestAddr, Length);   


            // Start DMA
            ncDrv_DMA_Start(Ch, ptDMA->mDMA_Param.mIntEn);
        }
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


void ncDrv_DMA_DeInitialize(eDMA_CH Ch)
{
    ncDrv_DMA_Stop(Ch);

    // Clear Register
    REGRW32(rDMAC_BASE(Ch), rDMAC_SRC)  = 0x0;
    REGRW32(rDMAC_BASE(Ch), rDMAC_DEST) = 0x0;    
    REGRW32(rDMAC_BASE(Ch), rDMAC_SIZE) = 0x0;   
    REGRW32(rDMAC_BASE(Ch), rDMAC_LINK) = 0x0;
    REGRW32(rDMAC_BASE(Ch), rDMAC_CR0)  = 0x0;
    REGRW32(rDMAC_BASE(Ch), rDMAC_CR1)  = 0x0;    
    REGRW32(rDMAC_BASE(Ch), rDMAC_CR2)  = 0x0;
    REGRW32(rDMAC_BASE(Ch), rDMAC_PERI) = 0x0;
}


void ncDrv_DMA_Initialize(eDMA_CH Ch)
{
    ncDrv_DMA_DeInitialize(Ch);
}


#endif  /* __DMA_ENABLE__ */

/* End Of File */

