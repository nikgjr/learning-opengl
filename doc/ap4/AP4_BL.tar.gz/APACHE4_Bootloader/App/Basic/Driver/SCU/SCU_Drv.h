/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SCU_DRV_H__
#define __SCU_DRV_H__


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define rSCU_CLK_BUS                        0x00
    #define bSCU_CLK_BUS_PCLK_SDIO          (1<<31)
    #define bSCU_CLK_BUS_PCLK_IPC           (1<<30)
    #define bSCU_CLK_BUS_PCLK_FMC           (1<<29)
    #define bSCU_CLK_BUS_PCLK_QSPI          (1<<28)
    #define bSCU_CLK_BUS_PCLK_SPI           (1<<27)
    #define bSCU_CLK_BUS_PCLK_RE            (1<<26)
    #define bSCU_CLK_BUS_PCLK_ISP           (1<<25)
    #define bSCU_CLK_BUS_PCLK_DDRC          (1<<24)
    #define bSCU_CLK_BUS_PCLK_DMAC          (1<<23)
    #define bSCU_CLK_BUS_PCLK_PWM           (1<<22)
    #define bSCU_CLK_BUS_PCLK_UART          (1<<21)
    #define bSCU_CLK_BUS_PCLK_I2C           (1<<20)
    #define bSCU_CLK_BUS_PCLK_ICU           (1<<19)
    #define bSCU_CLK_BUS_PCLK_TIMER         (1<<18)
    #define bSCU_CLK_BUS_PCLK_ATOP          (1<<17)
    #define bSCU_CLK_BUS_PCLK_CAN           (1<<15)
    #define bSCU_CLK_BUS_HCLK_SECURE_HS     (1<<13)
    #define bSCU_CLK_BUS_HCLK_SECURE_IS     (1<<12)
    #define bSCU_CLK_BUS_ACLK_SDIO          (1<<11)
    #define bSCU_CLK_BUS_ACLK_ROM           (1<<10)
    #define bSCU_CLK_BUS_ACLK_RAM           (1<<9)
    #define bSCU_CLK_BUS_ACLK_VDPD          (1<<8)
    #define bSCU_CLK_BUS_ACLK_FMC           (1<<7)
    #define bSCU_CLK_BUS_ACLK_INTC          (1<<6)
    #define bSCU_CLK_BUS_ACLK_ISP           (1<<5)
    #define bSCU_CLK_BUS_ACLK_DDRC          (1<<4)
    #define bSCU_CLK_BUS_ACLK_RE            (1<<3)
    #define bSCU_CLK_BUS_ACLK_DMAC          (1<<2) 
    #define bSCU_CLK_BUS_ACLK_QSPI          (1<<1)
    
#define rSCU_CLK_DDRC                       0x08
    #define bSCU_CLK_DDRC_DFI               (1<<2)
    #define bSCU_CLK_DDRC_MDII              (1<<1) 
    #define bSCU_CLK_DDRC_PHT               (1<<0)
    
#define rSCU_CLK_IP                         0x0C
    #define bSCU_CLK_IP_TNG                 (1<<11)
    #define bSCU_CLK_IP_HMAC                (1<<10)
    #define bSCU_CLK_IP_PKA                 (1<<9)
    #define bSCU_CLK_IP_AES                 (1<<8)
    #define bSCU_CLK_IP_VOLT                (1<<7)
    #define bSCU_CLK_IP_TEMP                (1<<6)
    #define bSCU_CLK_IP_ADC                 (1<<5)
    #define bSCU_CLK_IP_SAFETY              (1<<4)
    #define bSCU_CLK_IP_SECURE              (1<<3)
    #define bSCU_CLK_IP_CAN                 (1<<2)
    #define bSCU_CLK_IP_SDIO                (1<<1)
    #define bSCU_CLK_IP_QSPI                (1<<0)

#define rSCU_RST_BUS                        0x20
    #define bSCU_RST_BUS_PRST_SDIO          (1<<31)
    #define bSCU_RST_BUS_PRST_IPC           (1<<30)
    #define bSCU_RST_BUS_PRST_FMC           (1<<29)
    #define bSCU_RST_BUS_PRST_QSPI          (1<<28)
    #define bSCU_RST_BUS_PRST_SPI           (1<<27)
    #define bSCU_RST_BUS_PRST_RE            (1<<26)
    #define bSCU_RST_BUS_PRST_ISP           (1<<25)
    #define bSCU_RST_BUS_PRST_DDRC          (1<<24)
    #define bSCU_RST_BUS_PRST_DMAC          (1<<23)
    #define bSCU_RST_BUS_PRST_PWM           (1<<22)
    #define bSCU_RST_BUS_PRST_UART          (1<<21)
    #define bSCU_RST_BUS_PRST_I2C           (1<<20)
    #define bSCU_RST_BUS_PRST_ICU           (1<<19)
    #define bSCU_RST_BUS_PRST_TIMER         (1<<18)
    #define bSCU_RST_BUS_PRST_ATOP          (1<<17)
    #define bSCU_RST_BUS_PRST_CAN           (1<<15)
    #define bSCU_RST_BUS_HRST_SECURE_HS     (1<<13)
    #define bSCU_RST_BUS_HRST_SECURE_IS     (1<<12)
    #define bSCU_RST_BUS_ARST_SDIO          (1<<11)
    #define bSCU_RST_BUS_ARST_ROM           (1<<10)
    #define bSCU_RST_BUS_ARST_RAM           (1<<9)
    #define bSCU_RST_BUS_ARST_VDPD          (1<<8)
    #define bSCU_RST_BUS_ARST_FMC           (1<<7)
    #define bSCU_RST_BUS_ARST_INTC          (1<<6)
    #define bSCU_RST_BUS_ARST_ISP           (1<<5)
    #define bSCU_RST_BUS_HRST_DDRC          (1<<4)
    #define bSCU_RST_BUS_HRST_RE            (1<<3)
    #define bSCU_RST_BUS_HRST_DMAC          (1<<2)
    #define bSCU_RST_BUS_HRST_QSPI          (1<<1)

#define rSCU_RST_CPU                        0x24

#define rSCU_RST_DDRC                       0x28
    #define bSCU_RST_DDRC_DFI               (1<<2)
    #define bSCU_RST_DDRC_MDII              (1<<1) 
    #define bSCU_RST_DDRC_PHT               (1<<0)
    
#define rSCU_RST_IP                         0x2C
    #define bSCU_RST_IP_TNG                 (1<<11)
    #define bSCU_RST_IP_HMAC                (1<<10)
    #define bSCU_RST_IP_PKA                 (1<<9)
    #define bSCU_RST_IP_AES                 (1<<8)
    #define bSCU_RST_IP_VOLT                (1<<7)
    #define bSCU_RST_IP_TEMP                (1<<6)
    #define bSCU_RST_IP_ADC                 (1<<5)
    #define bSCU_RST_IP_SAFETY              (1<<4)
    #define bSCU_RST_IP_SECURE              (1<<3)
    #define bSCU_RST_IP_CAN                 (1<<2)
    #define bSCU_RST_IP_SDIO                (1<<1)
    #define bSCU_RST_IP_QSPI                (1<<0)
    
#define rSCU_PLL0_SEL                       0x88
#define rSCU_PLL1_SEL                       0x8C
#define rSCU_PLL2_SEL                       0x90
#define rSCU_PLL3_SEL                       0x94

#define rSCU_BOOT_STRAP                     0xF0
    #define bSCU_BOOT_STRAP_NORMAL_MODE     (0)
    #define bSCU_BOOT_STRAP_SECURE_MODE     (1)
    #define bSCU_BOOT_STRAP_CSN0            (0)
    #define bSCU_BOOT_STRAP_CSN1            (1)
    #define bSCU_BOOT_STRAP_OSC             (0)
    #define bSCU_BOOT_STRAP_MIN             (1)
    #define bSCU_BOOT_STRAP_MID             (2)
    #define bSCU_BOOT_STRAP_MAX             (3)
    
#define rSCU_DDR_STS                        0xF4
    #define bSCU_DDR_STS_INIT_FAIL          (1<<1)
    #define bSCU_DDR_STS_INIT_DONE          (1<<0)
    
#define rSCU_SRAM_ECC                       0xFC
    #define bSCU_SRAM_ECC_DISABLE           (1)
    #define bSCU_SRAM_ECC_ENABLE            (0)


#define rSCU_REMAP_EN                       0x100

#define rSCU_REMAP_DLS_S_ADDR_00            0x104
#define rSCU_REMAP_DLS_E_ADDR_00            0x124
#define rSCU_REMAP_DLS_S_ADDR_01            0x108
#define rSCU_REMAP_DLS_E_ADDR_01            0x128
#define rSCU_REMAP_SIG_S_ADDR               0x110
#define rSCU_REMAP_SIG_E_ADDR               0x130

#define rSCU_CLK_SEL_R0M                    0x284
#define rSCU_CLK_DIV_RAM                    0x288

#define rSCU_CLK_SEL_ARM_LS_0               0x228
#define rSCU_CLK_SEL_RAM                    0x284
#define rSCU_CLK_SEL_BUS_AXI                0x200
#define rSCU_CLK_SEL_BUS_AXI_ISP            0x208

#define rSCU_CLK_SEL_SECURE                 0x28C
#define rSCU_CLK_DIV_SECURE                 0x290

#define rSCU_CLK_DIV_ARM                    0x22C

#define rSCU_TICK_CNT                       0x3000










//------------------------------------------------------------------------------
// SCU Debug Register Map
#define rSCU_DEBUG_REG                      (APACHE_SCU_BASE+0x1000)

#define SYS_APB_CLK                         (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x0000))
#define SYS_TIMEOUT_CNT                     (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x0004))
#define SYS_SPI_CLK                         (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x0008))
#define SYS_QSPI_CLK                        (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x000C))

#if 0
#define DBG_REV0_REG                        (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x0040)) // It should not be used.
#define DBG_REV1_REG                        (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x0044))
#define DBG_REV2_REG                        (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x0048))
#define DBG_REV3_REG                        (*(volatile unsigned int *)(rSCU_DEBUG_REG+0x004C))
#endif









/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum _PAD_ID
{
    PAD_NTRST,              // 0
    PAD_TCK,
    PAD_TMS,
    PAD_TDO,
    PAD_TDI,

    //PAD_TM,               // No Ctrl

    PAD_I2C0_SCL,
    PAD_I2C0_SDA,
    PAD_I2C1_SCL,
    PAD_I2C1_SDA,           // 8

    PAD_UART0_RX,
    PAD_UART0_TX,
    PAD_UART1_RX,
    PAD_UART1_TX,
    PAD_UART2_RX,
    PAD_UART2_TX,

    PAD_SPI2_CSN0,
    PAD_SPI2_CSN1,          // 16
    PAD_SPI2_DQ0,
    PAD_SPI2_DQ1,
    PAD_SPI2_DQ2,
    PAD_SPI2_DQ3,
    PAD_SPI2_SCK,

    //PAD_SYS_CK_I,         // No Ctrl
    //PAD_SAFE_CK_I,        // No Ctrl
    //PAD_SYS_RSTN_I,       // No Ctrl

    PAD_SEN_PCLK,
    PAD_SEN_PV,
    PAD_SEN_PH,             // 24
    PAD_SEN_PD0,
    PAD_SEN_PD1,
    PAD_SEN_PD2,
    PAD_SEN_PD3,
    PAD_SEN_PD4,
    PAD_SEN_PD5,
    PAD_SEN_PD6,
    PAD_SEN_PD7,            // 32
    PAD_SEN_PD8,
    PAD_SEN_PD9,
    PAD_SEN_PD10,
    PAD_SEN_PD11,
    PAD_SEN_PD12,
    PAD_SEN_PD13,
    PAD_SEN_PD14,
    PAD_SEN_PD15,           // 40

    PAD_VOUT_CK_O,
    PAD_VOUT_VSYNC,
    PAD_VOUT_HSYNC,
    PAD_VOUT_Y0,
    PAD_VOUT_Y1,
    PAD_VOUT_Y2,
    PAD_VOUT_Y3,
    PAD_VOUT_Y4,            // 48
    PAD_VOUT_Y5,
    PAD_VOUT_Y6,
    PAD_VOUT_Y7,
    PAD_VOUT_C0,
    PAD_VOUT_C1,
    PAD_VOUT_C2,
    PAD_VOUT_C3,
    PAD_VOUT_C4,            // 56
    PAD_VOUT_C5,
    PAD_VOUT_C6,
    PAD_VOUT_C7,

    //PAD_FAULT_P,          // No Ctrl
    //PAD_FAULT_N,          // No Ctrl

    PAD_MIPI_SEN_CLK,
    PAD_CAN_RX,
    PAD_CAN_TX,

    PAD_FMC_CLE,
    PAD_FMC_ALE,            // 64
    PAD_FMC_DQ0,
    PAD_FMC_DQ1,
    PAD_FMC_DQ2,
    PAD_FMC_DQ3,
    PAD_FMC_DQ4,
    PAD_FMC_DQ5,
    PAD_FMC_DQ6,
    PAD_FMC_DQ7,            // 72

    PAD_FMC_CEN,
    PAD_FMC_REN,
    PAD_FMC_WEN,
    PAD_FMC_WPN,
    PAD_FMC_RBN,

    PAD_SEN_RST_N,          // 78

    PAD_MAX
} ePAD_ID;

typedef enum _PAD_FUNC
{
    PAD_FUNC_0 = 0,
    PAD_FUNC_1,
    PAD_FUNC_2,
    PAD_FUNC_3,
    PAD_FUNC_4,
    PAD_FUNC_5,
    PAD_FUNC_6,
    PAD_FUNC_7,
    PAD_FUNC_MAX,

    PAD_NOT_USED
} ePAD_FUNC;










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

extern BOOL  ncDrv_SCU_mTimeOut(UINT32 mSec);
extern UINT8 ncDrv_SCU_GetPinMux(UINT32 Pad);
extern void  ncDrv_SCU_SetPinMux(UINT32 Pad, UINT32 Func);



#endif  /* __SCU_DRV_H__ */


/* End Of File */

