/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncDrv_SSP_WaitBusIsBusy(void)
{
    INT32 Ret = NC_SUCCESS;
    UINT32 TimeOut = SSP_WAIT_TIMEOUT;

    while(REGRW32(APACHE_SPI_0_BASE, rSSP_CR1)&bSSP_CR1_BUSY)
    {
        if(ncDrv_SCU_mTimeOut(TimeOut))
        {
            Ret = NC_FAILURE;
            break;
        }
    }
    ncDrv_SCU_mTimeOut(0);

    return Ret;
}


void ncDrv_SSP_SetDMAMode(UINT8 rwMode)
{
    UINT32 Reg;

    Reg = REGRW32(APACHE_SPI_0_BASE, rSSP_CR0);
    Reg &= ~(1<<8);
    Reg |= (rwMode<<8);
    REGRW32(APACHE_SPI_0_BASE, rSSP_CR0) = Reg;

}


UINT32 ncDrv_SSP_GetClockDiv(void)
{
    return REGRW32(APACHE_SPI_0_BASE, rSSP_CLK_DIV) + 1;
}


void ncDrv_SSP_SetBitRate(UINT32 *pBitRate, UINT32 RefClk)
{
    UINT32 Div = 2;
    UINT32 Sampling;

    while(1)
    {
        Sampling = (RefClk/Div);
        if(*pBitRate >= Sampling)
        {
            break;
        }
        else if(*pBitRate < Sampling)
        {
            Div++;
        }
    }

    // BaudRate = RefClk/(DIV+1) => 0x01~0xFFFFFFFF 
    REGRW32(APACHE_SPI_0_BASE, rSSP_CLK_DIV) = Div - 1;

    *pBitRate = RefClk/Div;
}


INT32 ncDrv_SSP_Read(UINT8 *pBuf, UINT32 Length)
{
    INT32  Ret = NC_FAILURE;
    UINT32 i;

    // Clear Rx Buffer
    REGRW32(APACHE_SPI_0_BASE, rSSP_RX_CLR) = 1;

    for(i=0; i<Length; i++)
    {  
        // Check Busy
        Ret = ncDrv_SSP_WaitBusIsBusy();


        // Write Dummy data
        REGRW32(APACHE_SPI_0_BASE, rSSP_TX) = 0x00;


        // Wait Transfer Done.
        Ret = ncDrv_SSP_WaitBusIsBusy();


        // Read data
        pBuf[i] = (UINT8)(REGRW32(APACHE_SPI_0_BASE, rSSP_RX)&0xFF);
    }

    return Ret;
}


INT32 ncDrv_SSP_Write(UINT8 *pBuf, UINT32 Length)
{
    INT32  Ret = NC_FAILURE;
    UINT32 i;

    for(i=0; i<Length; i++)
    {
        // Check Busy
        Ret = ncDrv_SSP_WaitBusIsBusy();


        // Data Write
        REGRW32(APACHE_SPI_0_BASE, rSSP_TX) = pBuf[i];


        // Wait Transfer Done.
        Ret = ncDrv_SSP_WaitBusIsBusy();

        
        // Clear Rx Buffer
        REGRW32(APACHE_SPI_0_BASE, rSSP_RX_CLR) = 1;
    }

    return Ret;
}


void ncDrv_SSP_DeInit(void)
{
    // CR1 Clear
    REGRW32(APACHE_SPI_0_BASE, rSSP_CR1) = 0x0;  

    // Disable SSP and Clear
    REGRW32(APACHE_SPI_0_BASE, rSSP_CR0) = 0x0;  
}


void ncDrv_SSP_Init(UINT32 BitRate, UINT32 RefClk)
{
    UINT32 Reg;

    // Disable SSP and Clear, CR1 Clear
    REGRW32(APACHE_SPI_0_BASE, rSSP_CR0) = 0x0;    
    REGRW32(APACHE_SPI_0_BASE, rSSP_CR1) = 0x0;

    // SSP Bitrate
    ncDrv_SSP_SetBitRate(&BitRate, RefClk);

    // Set Data Width
    REGRW32(APACHE_SPI_0_BASE, rSSP_CR1) = (SSP_DS_8BIT<<8);

    // Set Operation and Enable SSP
    Reg = (0<<bSSP_CR0_CSEN)
        | (0<<bSSP_CR0_IEN)
        | (SSP_SPH_HIGH<<bSSP_CR0_SPH)
        | (SSP_SPO_HIGH<<bSSP_CR0_SPO)
        | (SSP_MODE_MASTER<<bSSP_CR0_OP)
        | (SSP_MSB_FIRST<<bSSP_CR0_DIR)
        | (1<<bSSP_CR0_MOD)
        | (1<<bSSP_CR0_EN);
    REGRW32(APACHE_SPI_0_BASE, rSSP_CR0) = Reg;
}



/* End Of File */

