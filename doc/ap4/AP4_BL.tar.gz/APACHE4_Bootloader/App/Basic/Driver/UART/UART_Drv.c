/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#ifdef __UART_ENABLE__










/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define PAD_RIGHT       1
#define PAD_ZERO        2

/* the following should be enough for 32 bit int */
#define PRINT_BUF_LEN   12










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

static void __simple_printc(INT32 c)
{
    if(c == '\n')
      ncDrv_UART_PutChar('\r');  
    ncDrv_UART_PutChar(c);
}

static INT32 __simple_prints(const CHAR *string, INT32 width, INT32 pad)
{
    INT32 pc = 0, padchar = ' ';

    if (width > 0) 
    {
        INT32 len = 0;
        const CHAR *ptr;
        for (ptr = string; *ptr; ++ptr) 
            ++len;
        
        if (len >= width) 
            width = 0;
        else 
            width -= len;
        
        if (pad & PAD_ZERO) 
            padchar = '0';
    }
    
    if (!(pad & PAD_RIGHT)) 
    {
        for ( ; width > 0; --width) 
        {
            __simple_printc (padchar);
            ++pc;
        }
    }
    
    for ( ; *string ; ++string)
    {
        __simple_printc (*string);
        ++pc;
    }
    
    for ( ; width > 0; --width) 
    {
        __simple_printc (padchar);
        ++pc;
    }

    return pc;
}


static int __simple_printi(INT32 i, INT32 b, INT32 sg, INT32 width, INT32 pad, INT32 letbase)
{
    CHAR print_buf[PRINT_BUF_LEN];
    CHAR *s;
    INT32 t, neg = 0, pc = 0;
    UINT32 u = i;

    if(i == 0) 
    {
        print_buf[0] = '0';
        print_buf[1] = '\0';

        return __simple_prints (print_buf, width, pad);
    }

    if(sg && b == 10 && i < 0) 
    {
        neg = 1;
        u = -i;
    }

    s = print_buf + PRINT_BUF_LEN-1;
    *s = '\0';

    while(u) 
    {
        t = u % b;
        if( t >= 10 )
            t += letbase - '0' - 10;
        *--s = t + '0';
        u /= b;
    }

    if(neg) 
    {
        if( width && (pad & PAD_ZERO) ) 
        {
            __simple_printc ('-');
            ++pc;
            --width;
        }
        else 
        {
            *--s = '-';
        }
    }

    return pc + __simple_prints (s, width, pad);
}


static INT32 __simple_vsprintf(INT32 *varg)
{
    INT32 width, pad;
    INT32 pc = 0;
    CHAR *format = (CHAR *)(*varg++);
    CHAR scr[2];

    for(; *format != 0; ++format) 
    {
        if(*format == '%') 
        {
            ++format;
            width = pad = 0;
            if(*format == '\0') 
                break;
            
            if( *format == '%' ) 
            {
                __simple_printc (*format);
                ++pc;
                continue;
            }
            
            if( *format == '-' ) 
            {
                ++format;
                pad = PAD_RIGHT;
            }
            
            while( *format == '0' ) 
            {
                ++format;
                pad |= PAD_ZERO;
            }
            
            for( ; *format >= '0' && *format <= '9'; ++format) 
            {
                width *= 10;
                width += *format - '0';
            }
            
            if( *format == 's' ) 
            {
                CHAR *s = *((CHAR **)varg++);
                pc += __simple_prints (s?s:"(null)", width, pad);
                continue;
            }
            
            if( *format == 'd' ) 
            {
                pc += __simple_printi (*varg++, 10, 1, width, pad, 'a');
                continue;
            }
            
            if( *format == 'x' ) 
            {
                pc += __simple_printi (*varg++, 16, 0, width, pad, 'a');
                continue;
            }
            
            if( *format == 'X' ) 
            {
                pc += __simple_printi (*varg++, 16, 0, width, pad, 'A');
                continue;
            }
            
            if( *format == 'u' ) 
            {
                pc += __simple_printi (*varg++, 10, 0, width, pad, 'a');
                continue;
            }
            
            if( *format == 'c' ) 
            {
                /* char are converted to int then pushed on the stack */
                scr[0] = *varg++;
                scr[1] = '\0';
                pc += __simple_prints (scr, width, pad);
                continue;
            }
        }
        else
        {
            __simple_printc (*format);
            ++pc;
        }
    }
    
    return pc;
}



void ncDrv_UART_Printf(UINT32 DebugZone, const CHAR *fmt, ...)
{
    INT32 *varg = (INT32 *)(&fmt);

    if(DebugZone&MSGERR)  ncDrv_UART_PutStr(STR_COLOR_RED_ON);
    if(DebugZone&MSGWARN) ncDrv_UART_PutStr(STR_COLOR_YELLOW_ON);


    //---------------------------------------------------------------------
    // https://www.menie.org/georges/embedded/small_printf_source_code.html
    //---------------------------------------------------------------------
    __simple_vsprintf(varg);


    if((DebugZone&MSGERR) || (DebugZone&MSGWARN))
    {
        ncDrv_UART_PutStr(STR_COLOR_OFF);
    }
}


void ncDrv_UART_PutChar(UINT8 Data)
{
    eUART_CH Ch = UART_CH0;      
    UINT32 Reg;

    do 
    {
        Reg = REGRW32(rUART_BASE(Ch), rUART_LSR);
    } while ((Reg & bUART_LSR_THRE) != bUART_LSR_THRE);

    // Data Write
	REGRW32(rUART_BASE(Ch), rUART_TX) = Data;

    // WAIT_FOR_XMITR
    do 
    {
        Reg = REGRW32(rUART_BASE(Ch), rUART_LSR);
    } while ((Reg & (bUART_LSR_TEMT | bUART_LSR_THRE)) != (bUART_LSR_TEMT | bUART_LSR_THRE));
}


void ncDrv_UART_PutStr(CHAR *str)
{
    CHAR prev = 0x0;

    while(*str)
    {
        if(*str == '\n' && prev != '\r') ncDrv_UART_PutChar('\r');

        ncDrv_UART_PutChar(*str);

        prev = *str++;
    }
}


void ncDrv_UART_Initialize(UINT32 BaudRate, UINT32 RefClk)
{
    eUART_CH Ch = UART_CH0;  
    UINT32 Reg;
    UINT32 DIV;

    // Disable UART
    REGRW32(rUART_BASE(Ch), rUART_EN) = OFF;

    // Reset receiver and transmitter
    REGRW32(rUART_BASE(Ch), rUART_FCR) = (bUART_FCR_CLEAR_RCVR|bUART_FCR_CLEAR_XMIT|bUART_FCR_TRIGGER_14);

    // Set Interrupt Disable
    REGRW32(rUART_BASE(Ch), rUART_IER) = 0x0;

    // Set 8 bit char, 1 stop bit, no parity */
    REGRW32(rUART_BASE(Ch), rUART_LCR) = (UT_BRK_DIS|UT_SPS_DIS|UT_EPS_DIS|UT_PARITY_DIS|UT_STOP_1BIT|UT_DATA_8BIT);

    // Set baud rate : open divisor latch
    Reg = (REGRW32(rUART_BASE(Ch), rUART_LCR) | bUART_LCR_DLAB);
    REGRW32(rUART_BASE(Ch), rUART_LCR) = Reg;

    // Set baud rate : set divisor latch
    DIV = RefClk/(16 * BaudRate);
    REGRW32(rUART_BASE(Ch), rUART_DLL) = (DIV>>0)&0xff;
    REGRW32(rUART_BASE(Ch), rUART_DLM) = (DIV>>8)&0xff;

    // Set baud rate : close divisor latch
    Reg = (REGRW32(rUART_BASE(Ch), rUART_LCR) & ~(bUART_LCR_DLAB));
    REGRW32(rUART_BASE(Ch), rUART_LCR) = Reg;
    
    // Enable UART
    REGRW32(rUART_BASE(Ch), rUART_EN) = ON;
}



#endif  /* __UART_ENABLE__ */


/* End Of File */

