/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __TYPE_H__
#define __TYPE_H__


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef unsigned long long      UINT64;
typedef unsigned int            UINT32;
typedef unsigned int            ULONG;
typedef unsigned short          UINT16;
typedef unsigned short          USHORT;
typedef unsigned char           UINT8;
typedef unsigned char           UCHAR;

typedef signed long long        INT64;
typedef signed int              INT32;
typedef signed short            INT16;
typedef signed short            SHORT;
typedef signed char             INT8;
typedef signed char             CHAR;

typedef float                   FLOAT;
typedef float                   FP32;
typedef unsigned char           BOOL;










/*
********************************************************************************
*               LOGICAL SYMBOL TYPE                              
********************************************************************************
*/

#ifndef TRUE
#define TRUE                    1
#endif

#ifndef FALSE
#define FALSE                   0
#endif

// Logical Symbols
#ifndef	OK
#define OK                      1
#endif

#ifndef	ERROR
#define ERROR                   0
#endif

#ifndef ON
#define ON                      1
#endif

#ifndef OFF
#define	OFF                     0
#endif

#ifndef ENABLE
#define ENABLE                  1
#endif

#ifndef DISABLE
#define	DISABLE                 0
#endif

#ifndef HIGH
#define HIGH                    1
#endif

#ifndef LOW
#define	LOW                     0
#endif

#ifndef NULL
#define NULL                    0
#endif

// function return value

#define NC_FAILURE              (-1)
#define NC_SUCCESS              0


#define CMD_MAX                 10
#define CMD_END                 0xFEFF55AA

#define KB                      (1024)
#define MB                      (1048576)

#define KHZ                     (1000)
#define MHZ                     (1000000)

#define MSEC                    (1000)
#define USEC                    (1000000)










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

// A function with no argument returning pointer to a void function
typedef void (*PrVoid) 	   (void);
typedef void (*PrHandler)  (UINT32);                    // 1 parameter










/*
********************************************************************************
*               MACROS
********************************************************************************
*/

#define _REVERSE(A)                     (A=(A?0:1))
#define _ALIGN(x, s)                    (((x) + s - 1U) & ~(s-1U))

#define REGRW8(base_addr, offset)       (*(volatile unsigned char *) (base_addr + offset))
#define REGRW16(base_addr, offset)      (*(volatile unsigned short *)(base_addr + offset))
#define REGRW32(base_addr, offset)      (*(volatile unsigned int *)  (base_addr + offset))


#endif  /* __TYPE_H__ */


/* End Of File */

