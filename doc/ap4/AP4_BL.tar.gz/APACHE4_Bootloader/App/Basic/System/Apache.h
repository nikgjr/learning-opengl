/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __APACHE_H__
#define __APACHE_H__


/*
********************************************************************************
*               INCLUDE                                    
********************************************************************************
*/

// Default
#include "Type.h"
#include "Config.h"

// Driver
#include "SCU_Drv.h"
#include "GPIO_Drv.h"
#include "UART_Drv.h"
#include "SSP_Drv.h"
#include "QSPI_Drv.h"
#include "DMA_Drv.h"
#include "sFlash_Svc.h"
#include "GICv2.h"
#include "INTC_Drv.h"
#include "EFUSE_Drv.h"
#include "DDRC_Drv.h"
#include "Timer_Drv.h"










/*
********************************************************************************
*               MEMORY MAP FOR APACHE                             
********************************************************************************
*/

/* Storage Memory Map */

#define APACHE_IROM_BASE                0x00000000
#define APACHE_IRAM_BASE                0x04000000
#define APACHE_IRAM_SIZE                0x00010000
#define APACHE_DRAM_BASE                0x80000000
#define APACHE_RMAP_SIZE                0x00080000


/* Peripheral Memory Map */

#define APACHE_SCU_BASE                 0x08000000
#define APACHE_ICU_BASE                 0x08100000
#define APACHE_GPIO_BASE                0x08101000
#define APACHE_ATOP_BASE                0x08300000
#define APACHE_INTC_BASE                0x10000000
#define APACHE_DMAC_BASE                0x10100000
#define APACHE_TIMER0_BASE              0x10300000
#define APACHE_UART_0_BASE              0x10800000
#define APACHE_SPI_0_BASE               0x10C00000
#define APACHE_QSPI_BASE                0x10E00000
#define APACHE_CAN_BASE                 0x10F00000
#define APACHE_DREX0_BASE               0x12000000
#define APACHE_DPHY_BASE                0x12100000
#define APACHE_DREX1_BASE               0x12200000
#define APACHE_HMAC_BASE                0x12800000
#define APACHE_TRNG_BASE                0x12900000
#define APACHE_AES_BASE                 0x12A00000
#define APACHE_PKA_BASE                 0x12B00000
#define APACHE_SE_BASE                  0x1C000000










/*
*******************************************************************************
*               DEFINITION FOR ARM ASM CODE SECTION                      
*******************************************************************************
*/

extern void ASM_DCACHE_FLUSH(UINT32 Addr, UINT32 Size);


#endif	/* __APACHE_H__ */


/* End Of File */

