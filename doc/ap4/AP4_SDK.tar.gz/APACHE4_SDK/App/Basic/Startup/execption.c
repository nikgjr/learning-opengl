/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : execption.c
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"










/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define ARM_MODE_FIQ                0x11
#define ARM_MODE_IRQ                0x12
#define ARM_MODE_SVC                0x13
#define ARM_MODE_ABT                0x17
#define ARM_MODE_UNDEF              0x1B
#define ARM_MODE_SYS                0x1F
#define ARM_MODE_MASK               0x1F










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/
typedef struct 
{
    UINT32 FIQ_r13;
    UINT32 FIQ_r14;
    
    UINT32 IRQ_r13;
    UINT32 IRQ_r14;
    
    UINT32 SVC_r13;
    UINT32 SVC_r14;
    
    UINT32 ABT_r13;
    UINT32 ABT_r14;
    
    UINT32 UND_r13;
    UINT32 UND_r14;
    
    UINT32 SYS_r13;
    UINT32 SYS_r14;
} tARM_MODE_REG, *ptARM_MODE_REG;


typedef struct
{ 
    UINT32 mSPSR;
    UINT32 mSP;
    UINT32 mLR;
    UINT32 mReg[13];
    UINT32 mPC;
} tARM_FAULT, *ptARM_FAULT; 










/*
********************************************************************************
*               EXTERN DEFINITIONS                              
********************************************************************************
*/

extern void   ASM_GET_MODE_REG(void*);
extern UINT32 ASM_GET_DFSR(void);
extern UINT32 ASM_GET_DFAR(void);
extern UINT32 ASM_GET_IFSR(void);
extern UINT32 ASM_GET_IFAR(void);

extern UINT32 Image$$FIQ_STACK$$ZI$$Limit;
extern UINT32 Image$$IRQ_STACK$$ZI$$Limit;
extern UINT32 Image$$FAULT_STACK$$ZI$$Limit;
extern UINT32 Image$$ARM_LIB_STACK$$ZI$$Limit;











/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

static void __debug_data_abort_status(void)
{
    BOOL   RW_mode;
    UINT8  Fault_Sts;
    UINT32 Dfsr = ASM_GET_DFSR();
    UINT32 Dfar = ASM_GET_DFAR();

    DEBUGMSG(MSGINFO, " -. DFAR 0x%08X \n", Dfar);
    DEBUGMSG(MSGINFO, " -. DFSR 0x%08X (AXI %s Error)\n", Dfsr, _BIT_SHIFT(Dfsr, 12)? "Slave":"Decode");

    Fault_Sts = ((_BIT_GET(Dfsr, 10) ? (1<<4) : 0) | _BITS(Dfsr, 3, 0));
    RW_mode   = _BIT_SHIFT(Dfsr, 11);

    switch(Fault_Sts) 
    {
        case 0x00: // 0b00000: // background fault
            DEBUGMSG(MSGINFO, " -. Background fault on %s\n", RW_mode ? "write" : "read");
        break;
        case 0x01: // 0b00001: // alignment fault
            DEBUGMSG(MSGINFO, " -. Alignment fault on %s\n", RW_mode ? "write" : "read");
        break;
        case 0x05: // 0b00101:
        case 0x07: // 0b00111: // translation fault
            DEBUGMSG(MSGINFO, " -. Translation fault on %s\n", RW_mode ? "write" : "read");
        break;
        case 0x03: // 0b00011:
        case 0x06: // 0b00110: // access flag fault
            DEBUGMSG(MSGINFO, " -. Access flag fault on %s\n", RW_mode ? "write" : "read");
        break;
        case 0x09: // 0b01001:
        case 0x0B: // 0b01011: // domain fault
            DEBUGMSG(MSGINFO, " -. Domain fault, domain %lu\n", _BITS_SHIFT(Dfsr, 7, 4));
        break;
        case 0x0D: // 0b01101:
        case 0x0F: // 0b01111: // permission fault
            DEBUGMSG(MSGINFO, " -. Permission fault on %s\n", RW_mode ? "write" : "read");
        break;
        case 0x02: // 0b00010: // debug event
            DEBUGMSG(MSGINFO, " -. Debug event\n");
        break;
        case 0x08: // 0b01000: // synchronous external abort
            DEBUGMSG(MSGINFO, " -. Synchronous external abort on %s\n", RW_mode ? "write" : "read");
        break;
        case 0x16: // 0b10110: // asynchronous external abort
            DEBUGMSG(MSGINFO, " -. Asynchronous external abort on %s\n", RW_mode ? "write" : "read");
        break;
        case 0x10: // 0b10000: // TLB conflict event
        case 0x19: // 0b11001: // synchronous parity error on memory access
        case 0x04: // 0b00100: // fault on instruction cache maintenance
        case 0x0C: // 0b01100: // synchronous external abort on translation table walk
        case 0x0E: // 0b01110: //    "
        case 0x1C: // 0b11100: // synchronous parity error on translation table walk
        case 0x1E: // 0b11110: //    "
        case 0x18: // 0b11000: // asynchronous parity error on memory access
        default:
            DEBUGMSG(MSGINFO, " -. Unhandled fault\n");
        break;
    }
}


static void __debug_prefetch_abort_status(void)
{
    UINT8  Fault_Sts;
    UINT32 Ifsr = ASM_GET_IFSR();
    UINT32 Ifar = ASM_GET_IFAR();

    DEBUGMSG(MSGINFO, " -. IFAR 0x%08X \n", Ifar);
    DEBUGMSG(MSGINFO, " -. IFSR 0x%08X (AXI %s Error)\n", Ifsr, _BIT_SHIFT(Ifsr, 12)? "Slave":"Decode");

    Fault_Sts = ((_BIT_GET(Ifsr, 10) ? (1<<4) : 0) | _BITS(Ifsr, 3, 0));

    switch(Fault_Sts) 
    {
        case 0x00: // 0b00000: // background fault
            DEBUGMSG(MSGINFO, " -. Background fault\n");
        break;
        case 0x01: // 0b00001: // alignment fault
            DEBUGMSG(MSGINFO, " -. Alignment fault\n");
        break;
        case 0x05: // 0b00101:
        case 0x07: // 0b00111: // translation fault
            DEBUGMSG(MSGINFO, " -. Translation fault\n");
        break;
        case 0x03: // 0b00011:
        case 0x06: // 0b00110: // access flag fault
            DEBUGMSG(MSGINFO, " -. Access flag fault\n");
        break;
        case 0x09: // 0b01001:
        case 0x0B: // 0b01011: // domain fault
            DEBUGMSG(MSGINFO, " -. Domain fault, domain %lu\n", _BITS_SHIFT(Ifsr, 7, 4));
        break;
        case 0x0D: // 0b01101:
        case 0x0F: // 0b01111: // permission fault
            DEBUGMSG(MSGINFO, " -. Permission fault\n");
        break;
        case 0x02: // 0b00010: // debug event
            DEBUGMSG(MSGINFO, " -. Debug event\n");
        break;
        case 0x08: // 0b01000: // synchronous external abort
            DEBUGMSG(MSGINFO, " -. Synchronous external abort\n");
        break;
        case 0x16: // 0b10110: // asynchronous external abort
            DEBUGMSG(MSGINFO, " -. Asynchronous external abort\n");
        break;
        case 0x10: // 0b10000: // TLB conflict event
        case 0x19: // 0b11001: // synchronous parity error on memory access
        case 0x04: // 0b00100: // fault on instruction cache maintenance
        case 0x0C: // 0b01100: // synchronous external abort on translation table walk
        case 0x0E: // 0b01110: //    "
        case 0x1C: // 0b11100: // synchronous parity error on translation table walk
        case 0x1E: // 0b11110: //    "
        case 0x18: // 0b11000: // asynchronous parity error on memory access
        default:
            DEBUGMSG(MSGINFO, " -. Unhandled fault\n");
        break;
    }
}

static void __debug_core_reg_dump(ptARM_FAULT pFault, const char *msg)
{
	tARM_MODE_REG Regs;
	UINT32 Stack_sAddr;
	UINT32 Stack_eAddr;
    UINT32 i = 0;


    // Disable fiq/irq
    __disable_irq();
    __disable_fiq();


    // Display Current Core Register
    DEBUGMSG(MSGINFO, "\n------------------------------------------------\n");
    DEBUGMSG(MSGERR, " [Halt] Core %s Abort \n", msg);
    DEBUGMSG(MSGINFO, "------------------------------------------------\n"); 
	DEBUGMSG(MSGINFO, "   SPSR: 0x%08x\n", pFault->mSPSR);  
    DEBUGMSG(MSGINFO, "   PC  : 0x%08x  r%02d : 0x%08x\n", pFault->mPC, i, pFault->mReg[i]);    
    for(i=1; i<13; i+=2)
        DEBUGMSG(MSGINFO, "   r%02d : 0x%08x  r%02d : 0x%08x\n", i, pFault->mReg[i], i+1, pFault->mReg[i+1]);


    // Display Mode Resister
	ASM_GET_MODE_REG(&Regs);
	DEBUGMSG(MSGINFO, " %c r13 : 0x%08x  r14 : 0x%08x (ABT)\n", ((pFault->mSPSR & ARM_MODE_MASK) == ARM_MODE_ABT)   ? '*' : ' ', Regs.ABT_r13, Regs.ABT_r14);
	DEBUGMSG(MSGINFO, " %c r13 : 0x%08x  r14 : 0x%08x (UND)\n", ((pFault->mSPSR & ARM_MODE_MASK) == ARM_MODE_UNDEF) ? '*' : ' ', Regs.UND_r13, Regs.UND_r14);    
	DEBUGMSG(MSGINFO, " %c r13 : 0x%08x  r14 : 0x%08x (FIQ)\n", ((pFault->mSPSR & ARM_MODE_MASK) == ARM_MODE_FIQ)   ? '*' : ' ', Regs.FIQ_r13, Regs.FIQ_r14);
	DEBUGMSG(MSGINFO, " %c r13 : 0x%08x  r14 : 0x%08x (IRQ)\n", ((pFault->mSPSR & ARM_MODE_MASK) == ARM_MODE_IRQ)   ? '*' : ' ', Regs.IRQ_r13, Regs.IRQ_r14);
	DEBUGMSG(MSGINFO, " %c r13 : 0x%08x  r14 : 0x%08x (SVC)\n", ((pFault->mSPSR & ARM_MODE_MASK) == ARM_MODE_SVC)   ? '*' : ' ', Regs.SVC_r13, Regs.SVC_r14);
	DEBUGMSG(MSGINFO, " %c r13 : 0x%08x  r14 : 0x%08x (SYS)\n", ((pFault->mSPSR & ARM_MODE_MASK) == ARM_MODE_SYS)   ? '*' : ' ', Regs.SYS_r13, Regs.SYS_r14);


    // Check Stack Memory Range
    switch(pFault->mSPSR & ARM_MODE_MASK) 
    {
        case ARM_MODE_ABT:   Stack_sAddr = Regs.ABT_r13; Stack_eAddr = (UINT32)&(Image$$FAULT_STACK$$ZI$$Limit);    break;
        case ARM_MODE_UNDEF: Stack_sAddr = Regs.UND_r13; Stack_eAddr = (UINT32)&(Image$$FAULT_STACK$$ZI$$Limit);    break;        
        case ARM_MODE_FIQ:   Stack_sAddr = Regs.FIQ_r13; Stack_eAddr = (UINT32)&(Image$$FIQ_STACK$$ZI$$Limit);      break;
        case ARM_MODE_IRQ:   Stack_sAddr = Regs.IRQ_r13; Stack_eAddr = (UINT32)&(Image$$IRQ_STACK$$ZI$$Limit);      break;
        case ARM_MODE_SVC:   Stack_sAddr = Regs.SVC_r13; Stack_eAddr = (UINT32)&(Image$$ARM_LIB_STACK$$ZI$$Limit);  break;
        case ARM_MODE_SYS:   Stack_sAddr = Regs.SYS_r13; Stack_eAddr = 0;                                           break;
        default  : Stack_sAddr = 0;
    }

    // Diplay Stack Memory 
	if(Stack_sAddr != 0) 
    {
        DEBUGMSG(MSGINFO, "------------------------------------------------\n");
		DEBUGMSG(MSGINFO, " > Stack Memory Dump [0x%08x~0x%08x]", Stack_sAddr, Stack_eAddr);
        Stack_sAddr = _ALIGN(Stack_sAddr, 0x10) - 0x10;
        
        i=0;
        while(Stack_sAddr + i < Stack_eAddr)
        {
            if(!(i%0x10)) 
                DEBUGMSG(MSGINFO, "\n0x%08x:", Stack_sAddr + i);
            DEBUGMSG(MSGINFO, " %08x", REGRW32(Stack_sAddr, i));
            i+=4;

            if(i >= 0x100)
                break;
        }	
        DEBUGMSG(MSGINFO, "\n------------------------------------------------\n");
	}
}


void Exception_Undefined_Handler(ptARM_FAULT pFault)
{
    BOOL IsThumb;

    IsThumb = pFault->mSPSR & (1<<5) ;

    if(IsThumb)
        pFault->mPC -= 2;
    else
        pFault->mPC -= 4;
    __debug_core_reg_dump(pFault, "Undefined");

    while(1);
}


void Exception_SWI_Handler(ptARM_FAULT pFault)
{
    pFault->mPC -= 4;    
    __debug_core_reg_dump(pFault, "UnHandled syscall");

    while(1);
}


void Exception_Prefetch_Handler(ptARM_FAULT pFault)
{
    pFault->mPC -= 4;    
    __debug_core_reg_dump(pFault, "Prefetch");

    __debug_prefetch_abort_status();

    while(1);
}


void Exception_Abort_Handler(ptARM_FAULT pFault)
{
    pFault->mPC -= 8;      
    __debug_core_reg_dump(pFault, "Data");

    __debug_data_abort_status();

    while(1);
}


void Exception_IRQ_Handler(void)
{
    ncLib_INTC_IrqHandler();
}


void Exception_FIQ_Handler(void)
{
    ncLib_INTC_FiqHandler();
}


/* End Of File */

