/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : testSim_MemoryCheck.c
*
*  @brief   :
*
*  @author  :
*
*  @date    : 2018.01.06
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "sim.h"


#if SIM_ENABLE_MEMORY










/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


unsigned char gChar[256];
unsigned short gShort[256];
unsigned int gInt[256];










/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

int APACHE_TEST_SIM_APP_DDR_SimpleMemoryTest(void)
{
	unsigned int nTestStep = 0;
	int i;
	unsigned int ctemp, stemp, itemp;
	int ret = NC_SUCCESS;

	unsigned char  *ncSRAMtest = (unsigned char  *)0x02000000;
	unsigned short *nsSRAMtest = (unsigned short *)0x02001000;
	unsigned int   *niSRAMtest = (unsigned int   *)0x02002000;

	unsigned char  *ncDDRtest =  (unsigned char  *)0x80000000;
	unsigned short *nsDDRtest =  (unsigned short *)0x80001000;
	unsigned int   *niDDRtest =  (unsigned int   *)0x80002000;

	nTestStep = 0;
	rSIM_RES00 = nTestStep;	    // sram_1(rom) check result
	rSIM_RES01 = nTestStep;	    // sram_2 check result
	rSIM_RES02 = nTestStep;	    // ddr check result
	rSIM_STEP = nTestStep;    // simulation step

	/* -----------------------------------------------------------------------------------------------
	 * 1. chart, short, int address access test
	 * write 0 ~ 255
	 * */

	for(i = 0; i < 256; i++)
	{
		gChar[i] = i;
	}

	nTestStep = 1;
	rSIM_STEP = nTestStep;

	for(i = 0; i < 256; i++)
	{
		gShort[i] = (i<<8) | i;
	}

	nTestStep = 2;
	rSIM_STEP = nTestStep;

	for(i = 0; i < 256; i++)
	{
		gInt[i] = (i<<24) | (i<<16) | (i<<8) | i;
	}

	nTestStep = 3;
	rSIM_STEP = nTestStep;

	/*
	 * 1. chart, short, int address access test
	 * compare 0 ~ 255
	 * */

	for(i = 0; i < 256; i++)
	{
		ctemp = i;
		if(gChar[i] != ctemp)
		{
			rSIM_RES00 = nTestStep;
			REGRW32(0x08000000, 0x1010) = i;
			break;
		}
	}

	nTestStep = 4;
	rSIM_STEP = nTestStep;

	for(i = 0; i < 256; i++)
	{
		stemp = (i<<8) | i;
		if(gShort[i] != stemp)
		{
			rSIM_RES00 = nTestStep;
			REGRW32(0x08000000, 0x1010) = (i<<8) | i;
			break;
		}
	}

	nTestStep = 5;
	rSIM_STEP = nTestStep;

	for(i = 0; i < 256; i++)
	{
		itemp = (i<<24) | (i<<16) | (i<<8) | i;
		if(gInt[i] != itemp)
		{
			rSIM_RES00 = nTestStep;
			REGRW32(0x08000000, 0x1010) = (i<<24) | (i<<16) | (i<<8) | i;
			break;
		}
	}

	nTestStep = 0x10;
	rSIM_STEP = nTestStep;

    /* -----------------------------------------------------------------------------------------------
     * 2. SRAM chart, short, int address access test
     * write 0 ~ 255
     * */

    for(i = 0; i < 256; i++)
    {
        ncSRAMtest[i] = i;
    }

    nTestStep = 0x11;
    rSIM_STEP = nTestStep;

    for(i = 0; i < 256; i++)
    {
        nsSRAMtest[i] = (i<<8) | i;
    }

    nTestStep = 0x12;
    rSIM_STEP = nTestStep;

    for(i = 0; i < 256; i++)
    {
        niSRAMtest[i] = (i<<24) | (i<<16) | (i<<8) | i;
    }

    nTestStep = 0x13;
    rSIM_STEP = nTestStep;

    /*
     * 2. SRAM chart, short, int address access test
     * compare 0 ~ 255
     * */


    for(i = 0; i < 256; i++)
    {
        ctemp = i;
        if(ncSRAMtest[i] != ctemp)
        {
            rSIM_RES01 = nTestStep;
            REGRW32(0x08000000, 0x1010) = i;
            break;
        }
    }

    nTestStep = 0x14;
    rSIM_STEP = nTestStep;

    for(i = 0; i < 256; i++)
    {
        stemp = (i<<8) | i;
        if(nsSRAMtest[i] != stemp)
        {
            rSIM_RES01 = nTestStep;
            REGRW32(0x08000000, 0x1010) = (i<<8) | i;
            break;
        }
    }

    nTestStep = 0x15;
    rSIM_STEP = nTestStep;

    for(i = 0; i < 256; i++)
    {
        itemp = (i<<24) | (i<<16) | (i<<8) | i;
        if(niSRAMtest[i] != itemp)
        {
            rSIM_RES01 = nTestStep;
            REGRW32(0x08000000, 0x1010) = (i<<24) | (i<<16) | (i<<8) | i;
            break;
        }
    }

    nTestStep = 0x20;
    rSIM_STEP = nTestStep;

    /* -----------------------------------------------------------------------------------------------
     * 3. DDR chart, short, int address access test
     * write 0 ~ 255
     * */

    for(i = 0; i < 256; i++)
    {
        ncDDRtest[i] = i;
    }

    nTestStep = 0x21;
    rSIM_STEP = nTestStep;

    for(i = 0; i < 256; i++)
    {
        nsDDRtest[i] = (i<<8) | i;
    }

    nTestStep = 0x22;
    rSIM_STEP = nTestStep;

    for(i = 0; i < 256; i++)
    {
        niDDRtest[i] = (i<<24) | (i<<16) | (i<<8) | i;
    }

    nTestStep = 0x23;
    rSIM_STEP = nTestStep;

    /*
     * 2. SRAM chart, short, int address access test
     * compare 0 ~ 255
     * */


    for(i = 0; i < 256; i++)
    {
        ctemp = i;
        if(ncDDRtest[i] != ctemp)
        {
            rSIM_RES02 = nTestStep;
            REGRW32(0x08000000, 0x1010) = i;
            break;
        }
    }

    nTestStep = 0x24;
    rSIM_STEP = nTestStep;

    for(i = 0; i < 256; i++)
    {
        stemp = (i<<8) | i;
        if(nsDDRtest[i] != stemp)
        {
            rSIM_RES02 = nTestStep;
            REGRW32(0x08000000, 0x1010) = (i<<8) | i;
            break;
        }
    }

    nTestStep = 0x25;
    rSIM_STEP = nTestStep;

    for(i = 0; i < 256; i++)
    {
        itemp = (i<<24) | (i<<16) | (i<<8) | i;
        if(niDDRtest[i] != itemp)
        {
            rSIM_RES02 = nTestStep;
            REGRW32(0x08000000, 0x1010) = (i<<24) | (i<<16) | (i<<8) | i;
            break;
        }
    }

    nTestStep = 0x30;
    rSIM_STEP = nTestStep;

    if(rSIM_RES00 != 0) ret = NC_FAILURE;
    if(rSIM_RES01 != 0) ret |= NC_FAILURE;
    if(rSIM_RES02 != 0) ret |= NC_FAILURE;

    return ret;
}


void APACHE_TEST_SIM_APP_DDR(void)
{
    INT32 ret;

    DEBUGMSG(MSGINFO, "APACHE_TEST_SIM_APP_DDR!!! \n");

    ret = APACHE_TEST_SIM_APP_DDR_SimpleMemoryTest();
    if(ret == NC_SUCCESS)
    {
        DEBUGMSG(MSGINFO, "success, APACHE_TEST_SIM_APP_SimpleMemoryTest()\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, "failure, APACHE_TEST_SIM_APP_SimpleMemoryTest()\n");
    }
}


#endif /* SIM_ENABLE_MEMORY */


/* End Of File */

