/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.c
*
*  @brief   :
*
*  @author  :
*
*  @date    : 2017.11.27
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#define __MAIN_C__

/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "sim.h"










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/


void APACHE_TEST_SIM_APP_InitDebugPort(UINT32 nDbgZone_APP, UINT32 nDbgZone_SDK)
{
    // Open Debug Port (Used UART Interface)
    ncLib_DEBUG_Open();

    // Init Debug Port
    ncLib_DEBUG_Ctrl_Init(UART_CH0, UT_BAUDRATE_57600);

    // APP Debug Zone - On/Off
    ncLib_DEBUG_Ctrl_SetAppZone(nDbgZone_APP, ON);

    // SDK Debug Zone - On/Off
    ncLib_DEBUG_Ctrl_SetSdkZone(nDbgZone_SDK, ON);
}


void APACHE_TEST_SIM_APP_InitInterface(void)
{
    // used nc_delay
    ncLib_SCU_Open();
    ncLib_INTC_Open();
    ncLib_GPIO_Open();

#if SIM_ENABLE_DEBUG_MSG
    APACHE_TEST_SIM_APP_InitDebugPort(MSGFULL, MSGFULL);
#endif
}


INT32 main(void)
{
    UINT32 i = 0;


    // Default Init Peripheral
    APACHE_TEST_SIM_APP_InitInterface();


    // IP Simulation Function
#if SIM_ENABLE_MEMORY
    APACHE_TEST_SIM_APP_DDR();
#endif

#if SIM_ENABLE_DMA
    APACHE_TEST_SIM_APP_DMA();
#endif

#if SIM_ENABLE_I2C
    APACHE_TEST_SIM_APP_I2C();
#endif

#if SIM_ENABLE_SPI
    APACHE_TEST_SIM_APP_SSP();
#endif


    // Wait.
    while(i < 0xF0000000)
    {
        if((i % 16) == 0) DEBUGMSG(MSGINFO, "%d\n", i);
        else DEBUGMSG(MSGINFO, "%d, ", i);

        rSIM_END = i++;
        nc_mdelay(1000);
    }
    
    return 0;
}


#undef __MAIN_C__


/* End Of File */

