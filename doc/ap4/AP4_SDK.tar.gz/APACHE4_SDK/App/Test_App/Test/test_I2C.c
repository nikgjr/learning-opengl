/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_I2C










/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define TX_SLV0             (0x72)
#define TX_SLV1             (0x7A)










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    eI2C_CH         mI2C_MasterCh;      
    eI2C_CH         mI2C_SlaveCh;    
    
    BOOL            mI2C_MasterIsrEn; 
    BOOL            mI2C_SlaveIsrEn;
    
    UINT32          mI2C_Hz;
    UINT32          mI2C_Step;
    BOOL            mI2C_TestMode;

    BOOL            mI2C_DebugGpioPort;
    BOOL            mI2C_DebugPortOn;
    BOOL            mI2C_DebugMsgOn;
} tI2CTEST_FLAG, *ptI2CTEST_FLAG;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tI2CTEST_FLAG tI2CTestFlag; 
volatile tI2CTEST_FLAG tI2CTestFlag_Def = { 
                                                I2C_CH1,
                                                I2C_CH0,
                                                
                                                ON,
                                                ON,
                                                
                                                (100*KHZ),
                                                (1*KHZ),
                                                ON,

                                                DBG_GPIO_PORT0,
                                                ON,
                                                OFF
                                           };










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __test_i2c_sil9x34_reset(eI2C_CH Ch)
{
    UINT32 Reg;
    UINT32 RstPad;

    if(Ch == I2C_CH0)
        RstPad = 20;
    else
        RstPad = 21;

    // Low
    Reg = REGRW32(APACHE_SYSCON_BASE, 0x1040);
    Reg &= ~(1<<RstPad);
    REGRW32(APACHE_SYSCON_BASE, 0x1040) = Reg;

    nc_mdelay(10);

    // High
    Reg = REGRW32(APACHE_SYSCON_BASE, 0x1040);
    Reg |= (1<<RstPad);
    REGRW32(APACHE_SYSCON_BASE, 0x1040) = Reg;    

    nc_mdelay(10);    
}


static INT32 __test_i2c_sil9x34_write(UINT8 SlaveAddr, UINT8 RegAddr, UINT8 wData)
{
    INT32 ret = NC_SUCCESS;    

    eI2C_CH Ch;    
    UINT8 rData;


    // Set I2C Channel
    Ch = tI2CTestFlag.mI2C_MasterCh;   


    // Set Slave Address
    ncLib_I2C_Ctrl_SetDevAddr(Ch, SlaveAddr, I2C_DEV_7BIT);
    

    // Data Write
    ret = ncLib_I2C_Write(Ch, RegAddr, &wData, 1);


    if(tI2CTestFlag.mI2C_DebugMsgOn == ON)
    {

        // Data Read
        rData = 0;
        ret |= ncLib_I2C_Read(Ch, RegAddr, &rData, 1);


        // Compare 
        if(wData != rData)
        {
            if(SlaveAddr == TX_SLV0)
            {
                if((RegAddr == 0x05) || (RegAddr == 0x08))
                {
                    // Skip - No Error
                }
                else
                {
                    ret = NC_FAILURE;
                }
            }
            else
            {
                if(RegAddr == 0x3E)
                {
                    // Skip - No Error
                }
                else
                {
                    ret = NC_FAILURE;
                }
            }
        }

        if(ret == NC_FAILURE)
            DEBUGMSG(MSGINFO, "  > Fail");
        else
            DEBUGMSG(MSGINFO, "  > OK  ");
        DEBUGMSG(MSGINFO, " - DevID[0x%02X] Addr[0x%04X] W[0x%02X] vs R[0x%02X]\n", SlaveAddr, RegAddr, wData, rData);
    }
    

    return ret;
}


INT32 APACHE_TEST_I2C_InitSIL9x34(void)
{
    INT32 ret = NC_SUCCESS;


    // power down occilator - Enable
    ret |= __test_i2c_sil9x34_write(TX_SLV1, 0x3D, 0xF8);
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x08, 0x34);


    // Tune the video input table according to DM320 hardware spec
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x33, 0x30);
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x40, 0x6e); 
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x41, 0x00);
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x44, 0x28);
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x45, 0x00);
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x46, 0x05);
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x47, 0x05);
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x48, 0x30);
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x4A, 0x3D);


    // software reset 
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x05, 0x03);
    nc_mdelay(3);
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x05, 0xFC);


    // power up occilator - Disable
    ret |= __test_i2c_sil9x34_write(TX_SLV1, 0x3D, 0x07);
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x08, 0x35);


    // unmask the interrupt status
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x75, 0xff);
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x76, 0xff); 
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x77, 0xff);


    // Hdmi output setting - HDMI control register, enable HDMI, disable DVI
    ret |= __test_i2c_sil9x34_write(TX_SLV1, 0x2F, 0x01);


    // TMDS control register FPLL is 1.0*IDCK.
    // Internal source termination enabled.
    // Driver level shifter bias enabled. page 27
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x82, 0x25);


    // HDCP control handshaking
    ret |= __test_i2c_sil9x34_write(TX_SLV0, 0x0F, 0x00);


    // enable the avi repeat transmission
    ret |= __test_i2c_sil9x34_write(TX_SLV1, 0x3E, 0x31);


    // CEA-861 Info Frame control setting set the info frame type according to CEA-861 datasheet
    ret |= __test_i2c_sil9x34_write(TX_SLV1, 0x40, 0x82); 
    ret |= __test_i2c_sil9x34_write(TX_SLV1, 0x41, 0x02);
    ret |= __test_i2c_sil9x34_write(TX_SLV1, 0x42, 0x0D); 
    ret |= __test_i2c_sil9x34_write(TX_SLV1, 0x43, (0x82 + 0x02 + 0x0D + 0x3D));
    ret |= __test_i2c_sil9x34_write(TX_SLV1, 0x44, 0x3D);
    ret |= __test_i2c_sil9x34_write(TX_SLV1, 0x45, 0x68);
    ret |= __test_i2c_sil9x34_write(TX_SLV1, 0x46, 0x03);


    return ret;
}


void APACHE_TEST_I2C_SetDebugPort(BOOL OnOff)
{
    UINT32 Reg;

    Reg = REGRW32(APACHE_SYSCON_BASE, 0x1040);
    Reg &= ~(7<<16);

    if(OnOff == ON)
        Reg |= (3<<16); 
    
    REGRW32(APACHE_SYSCON_BASE, 0x1040) = Reg;
}


void APACHE_TEST_I2C_SetDebugLoopBack(BOOL OnOff)
{
    UINT32 Reg;

    Reg = REGRW32(APACHE_SYSCON_BASE, 0x1040);
    Reg &= ~(1<<12);

    if(OnOff == ON)
        Reg |= (1<<12); 
    
    REGRW32(APACHE_SYSCON_BASE, 0x1040) = Reg;
}


#if 0 // Old Version - Not Support
void APACHE_TEST_I2C_Isr_SlaveMode_AutoAck(eI2C_CH Ch, INT32 Sts)
{
    UINT32 RegAddr = APACHE_I2C_SLAVE_REG_00;
    UINT32 rBuff = 0;


    DEBUGMSG(MSGINFO, "  > S");
    if((Sts&0xFF) == 0)
    {
        DEBUGMSG(MSGINFO, " ");
    }
    else
    {
        // Data Read
        ncLib_I2C_Read(Ch, RegAddr, &rBuff, 4);

        
        // Trigger Master Write - Slave Read
        if(Sts&(1<<1))
        {
            DEBUGMSG(MSGINFO, "r");
        }


        // Trigger Master Read - Slave Write
        if(Sts&(1<<0))
        {
            DEBUGMSG(MSGINFO, "w");
        }
    }

    DEBUGMSG(MSGINFO, ":ISR - I2C_%d:0x%04X 0x%08X\n", Ch, Sts, rBuff);    
}
#endif


void APACHE_TEST_I2C_Isr_SlaveMode_UserAck(eI2C_CH Ch, INT32 Sts)
{
    UINT8 rBuff = 0;
    UINT8 wBuff = 0x5A;


    if(Sts&(1<<6))
    {
        ncLib_I2C_Read(Ch, 0x0, &rBuff, 1);
        
        DEBUGMSG(MSGINFO, ":ReStart:0x%02X", rBuff);

        // Set ACK
        ncLib_I2C_Ctrl_SetAckValue(Ch, 0);
    }

    
    if(Sts&(1<<5))
    {
        DEBUGMSG(MSGINFO, ":Stop   ");
    }

    
    if(Sts&(1<<4))
    {
        ncLib_I2C_Read(Ch, 0x0, &rBuff, 1);
        
        DEBUGMSG(MSGINFO, ":Start:0x%02X", rBuff);
        
        // Set ACK
        ncLib_I2C_Ctrl_SetAckValue(Ch, 0);
    } 

    if(Sts&(1<<3))
    {
        DEBUGMSG(MSGINFO, ":rAck ");
        
        ncLib_I2C_Write(Ch, 0x0, &wBuff, 1);
    }


    if(Sts&(1<<2))
    {
        ncLib_I2C_Read(Ch, 0x0, &rBuff, 1);
        
        DEBUGMSG(MSGINFO, ":wACK :0x%02X", rBuff);
        
        // Set ACK
        ncLib_I2C_Ctrl_SetAckValue(Ch, 0);
    }

    
    // INT Clear
    ncLib_I2C_Ctrl_SetIntcClear(Ch);

    DEBUGMSG(MSGINFO, "\n"); 
}


void APACHE_TEST_I2C_Isr_MasterMode(eI2C_CH Ch, INT32 Sts)
{
    DEBUGMSG(MSGINFO, "  > Mx:ISR - I2C_%d:0x%04X", Ch, Sts);

    // NACK or ACK
    if(Sts&(1<<7))
        DEBUGMSG(MSGINFO, ":N");
    else
        DEBUGMSG(MSGINFO, ":A");

    // Start or Stop
    if(!(Sts&(1<<6)))
        DEBUGMSG(MSGINFO, ":Stop ");

    if(Sts&(1<<5))
        DEBUGMSG(MSGERR, ":Arbitation lost");
    DEBUGMSG(MSGINFO, "\n");
}


void APACHE_TEST_I2C_Isr(UINT32 irq)
{
    INT32 Sts;
    eI2C_CH Ch = (eI2C_CH)(irq - IRQ_NUM_I2C0);


    // INT Status Check 
    Sts = ncLib_I2C_Ctrl_GetIntcStatus(Ch);
    if(Sts&(1<<15))
    {
        // Slave Mode - User Ctrl Ack
        APACHE_TEST_I2C_Isr_SlaveMode_UserAck(Ch, Sts);
    }
#if 0 // Old Version - Not Support
    else if(Sts&(1<<14))
    {
        // Slave Mode - Auto Ack
        APACHE_TEST_I2C_Isr_SlaveMode_AutoAck(Ch, Sts);
    }
#endif
    else
    {
        // Master Mode
        APACHE_TEST_I2C_Isr_MasterMode(Ch, Sts);
    }

    // Toggle - Debug Gpio Port
    APACHE_TEST_DebugGPIOToggle(tI2CTestFlag.mI2C_DebugGpioPort+Ch);
}


void APACHE_TEST_I2C_Isr_Init(eI2C_CH Ch)
{
    // Init - Debug Gpio Port
    APACHE_TEST_DebugGPIOSet(tI2CTestFlag.mI2C_DebugGpioPort+Ch, GPIO_LOW);

    
    // Register I2C Interrupt Handler
    ncLib_INTC_Ctrl_RegisterHandler((UINT32)(IRQ_NUM_I2C0 + Ch), (PrHandler)APACHE_TEST_I2C_Isr);
}


void APACHE_TEST_I2C_Isr_DeInit(eI2C_CH Ch)
{
    // Unregister I2C Interrupt Handler
    ncLib_INTC_Ctrl_UnRegisterHandler((UINT32)(IRQ_NUM_I2C0 + Ch));
}


void APACHE_TEST_I2C_Init(eI2C_CH Ch, ptI2C_PARAM ptI2CParam)
{
    INT32 ret;


    // Open I2C
    ncLib_I2C_Open();



    // Set I2C Operation Mode 
    ptI2CParam->mLengthType  = I2C_ADDR_8_DATA_8;
    ptI2CParam->mDevBit      = I2C_DEV_7BIT;
    ptI2CParam->mDevAddr     = TX_SLV0;
    ptI2CParam->mHz          = tI2CTestFlag.mI2C_Hz;



    // Enable Interrupt 
    if(ptI2CParam->mIntEn == ENABLE)
        APACHE_TEST_I2C_Isr_Init(Ch);



    // Init I2C Channel
    ret = ncLib_I2C_Ctrl_Init(Ch, ptI2CParam);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGINFO, "I2C Channel Init Fail\n");
    }

}


void APACHE_TEST_I2C_DeInit(eI2C_CH Ch, ptI2C_PARAM ptI2CParam)
{
    if(ptI2CParam->mIntEn == ENABLE)
        APACHE_TEST_I2C_Isr_DeInit(Ch);


    // DeInit I2C Channel 
    ncLib_I2C_Ctrl_DeInit(Ch);


    // Close I2C
    ncLib_I2C_Close();       
}


void APACHE_TEST_I2C_HzChange(void)
{
    tI2CTestFlag.mI2C_Hz = APACHE_TEST_Display_InputValue(100, (400*KHZ), "Change Hz");
}


void APACHE_TEST_I2C_StepChange(void)
{
    tI2CTestFlag.mI2C_Step = APACHE_TEST_Display_InputValue(1, (100*KHZ), "Change Step");
}


#if 0 // Old Version - Not Support
void APACHE_TEST_I2C_SlaveMode_AutoAck(void)
{    
    // Master I2C Channel
    eI2C_CH Master_Ch;
    tI2C_PARAM tI2CParam_M;

    // Slave I2C Channel
    eI2C_CH Slave_Ch;
    tI2C_PARAM tI2CParam_S;

    // Test buffer
    UINT32 i;
    UINT8 rBuff[4];
    UINT8 wBuff[4];


    //-------------------------------------------------------------------------
    // Test Device I2C Salve Mode
    //  - RegAddr:0x40 [7:0]
    //  - RegAddr:0x41 [7:0]
    //  - RegAddr:0x42 [7:0]
    //  - RegAddr:0x43 [7:0]
    //-------------------------------------------------------------------------
    UINT32 RegAddr = APACHE_I2C_SLAVE_REG_00;



    // Set I2C Channel
    Master_Ch = tI2CTestFlag.mI2C_MasterCh;
    Slave_Ch  = tI2CTestFlag.mI2C_SlaveCh;



    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, " Test Slave Mode : Master I2C_%d/ Slave I2C_%d !!!\n", Master_Ch, Slave_Ch);
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");




    // FPGA Debug I2C LoopBack Mode
    APACHE_TEST_I2C_SetDebugLoopBack(ON);



    // Init I2C Channel - Master
    tI2CParam_M.mIntEn  = tI2CTestFlag.mI2C_MasterIsrEn;
    tI2CParam_M.mOpMode = I2C_OP_MODE_MASTER;
    APACHE_TEST_I2C_Init(Master_Ch, &tI2CParam_M);



    // Init I2C Channel - Slave
    tI2CParam_S.mIntEn  = tI2CTestFlag.mI2C_SlaveIsrEn;
    tI2CParam_S.mOpMode = I2C_OP_MODE_SLAVE;
    APACHE_TEST_I2C_Init(Slave_Ch, &tI2CParam_S);




    //-------------------------------------------------------------------------
    // Single byte wirte
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "- Single-Byte Write Test\n");

    wBuff[0] = 0xAA;
    wBuff[1] = 0x55;
    wBuff[2] = 0xA5;
    wBuff[3] = 0x5A;

    for(i=0; i<4; i++)
    {
        ncLib_I2C_Write(Master_Ch, RegAddr+i, (UINT8 *)&wBuff[i], 1);
        if(tI2CTestFlag.mI2C_DebugMsgOn == ON)
        {
            DEBUGMSG(MSGINFO, "  > A:0x%02X W:0x%02X\n", RegAddr+i, wBuff[i]);
            APACHE_TEST_WaitKey();
        }
    }

    for(i=0; i<4; i++)
    {
        ncLib_I2C_Read(Slave_Ch, RegAddr+i, (UINT8 *)&rBuff[i], 1);
        DEBUGMSG(MSGINFO, "  > A:0x%02X - W:0x%02X vs R:0x%02X", RegAddr+i, wBuff[i], rBuff[i]);
        if(rBuff[i] == wBuff[i])
            DEBUGMSG(MSGINFO, " : OK\n");
        else
            DEBUGMSG(MSGINFO, " : Fail\n"); 
    }
    //-------------------------------------------------------------------------       




    //-------------------------------------------------------------------------
    // Single byte Read
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "- Single-Byte Read Test\n");

    rBuff[0] = 0x00;
    rBuff[1] = 0x00;
    rBuff[2] = 0x00;
    rBuff[3] = 0x00;
    
    for(i=0; i<4; i++)
    {
        ncLib_I2C_Read(Master_Ch, RegAddr+i, (UINT8 *)&rBuff[i], 1);
        if(tI2CTestFlag.mI2C_DebugMsgOn == ON)
        {
            DEBUGMSG(MSGINFO, "  > A:0x%02X R:0x%02X\n", RegAddr+i, rBuff[i]);
            APACHE_TEST_WaitKey();
        }
    }

    for(i=0; i<4; i++)
    {
        DEBUGMSG(MSGINFO, "  > A:0x%02X - W:0x%02X vs R:0x%02X", RegAddr+i, wBuff[i], rBuff[i]);
        if(rBuff[i] == wBuff[i])
            DEBUGMSG(MSGINFO, " : OK\n");
        else
            DEBUGMSG(MSGINFO, " : Fail\n"); 
    } 
    //-------------------------------------------------------------------------




    //-------------------------------------------------------------------------
    // Clear
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");    
    DEBUGMSG(MSGINFO, "- Clear\n");      
    
    wBuff[0] = 0x00;
    wBuff[1] = 0x00;
    wBuff[2] = 0x00;
    wBuff[3] = 0x00; 
    
    ncLib_I2C_Write(Slave_Ch, RegAddr, (UINT8 *)&wBuff[0], 4);
    ncLib_I2C_Read(Slave_Ch, RegAddr, (UINT8 *)&rBuff[0], 4);   
        
    for(i=0; i<4; i++)
    {
        if(rBuff[i] != wBuff[i])
            DEBUGMSG(MSGINFO, "- Clear Fail\n");
    }
    //-------------------------------------------------------------------------





    //-------------------------------------------------------------------------
    // Multi byte write
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "- Multi-Byte Write Test\n");

    wBuff[0] = 0x11;
    wBuff[1] = 0x22;
    wBuff[2] = 0x33;
    wBuff[3] = 0x44;

    ncLib_I2C_Write(Master_Ch, RegAddr, (UINT8 *)&wBuff[0], 4);
    if(tI2CTestFlag.mI2C_DebugMsgOn == ON)
        APACHE_TEST_WaitKey();
    ncLib_I2C_Read(Slave_Ch, RegAddr, (UINT8 *)&rBuff[0], 4);

    for(i=0; i<4; i++)
    {
        DEBUGMSG(MSGINFO, "  > A:0x%02X - W:0x%02X vs R:0x%02X", RegAddr+i, wBuff[i], rBuff[i]);
        if(rBuff[i] == wBuff[i])
            DEBUGMSG(MSGINFO, " : OK\n");
        else
            DEBUGMSG(MSGINFO, " : Fail\n"); 
    }
    //-------------------------------------------------------------------------


    

    //-------------------------------------------------------------------------
    // Multi byte read
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "- Multi-Byte Read Test\n");

    rBuff[0] = 0x00;
    rBuff[1] = 0x00;
    rBuff[2] = 0x00;
    rBuff[3] = 0x00;

    if(tI2CTestFlag.mI2C_DebugMsgOn == ON)
        APACHE_TEST_WaitKey();
    ncLib_I2C_Read(Master_Ch, RegAddr, (UINT8 *)&rBuff[0], 4);

    for(i=0; i<4; i++)
    {
        DEBUGMSG(MSGINFO, "  > A:0x%02X - W:0x%02X vs R:0x%02X", RegAddr+i, wBuff[i], rBuff[i]);
        if(rBuff[i] == wBuff[i])
            DEBUGMSG(MSGINFO, " : OK\n");
        else
            DEBUGMSG(MSGINFO, " : Fail\n"); 
    }
    //-------------------------------------------------------------------------




    // DeInit I2C Channel - Master
    APACHE_TEST_I2C_DeInit(Master_Ch, &tI2CParam_M);



    // DeInit I2C Channel - Slave
    APACHE_TEST_I2C_DeInit(Slave_Ch, &tI2CParam_S);



    // FPGA Debug I2C LoopBack Mode
    APACHE_TEST_I2C_SetDebugLoopBack(OFF);

}
#endif


void APACHE_TEST_I2C_SlaveMode_UserAck(void)
{    
    // Master I2C Channel
    eI2C_CH Master_Ch;
    tI2C_PARAM tI2CParam_M;

    // Slave I2C Channel
    eI2C_CH Slave_Ch;
    tI2C_PARAM tI2CParam_S;

    // Test buffer
    UINT32 i;
    UINT8 rBuff[4];
    UINT8 wBuff[4];


    //-------------------------------------------------------------------------
    // Test Device I2C Salve Mode
    //  - RegAddr:0x40 [7:0]
    //  - RegAddr:0x41 [7:0]
    //  - RegAddr:0x42 [7:0]
    //  - RegAddr:0x43 [7:0]
    //-------------------------------------------------------------------------
    UINT32 RegAddr = APACHE_I2C_SLAVE_REG_00;



    // Set I2C Channel
    Master_Ch = tI2CTestFlag.mI2C_MasterCh;
    Slave_Ch  = tI2CTestFlag.mI2C_SlaveCh;



    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, " Test Slave Mode : Master I2C_%d/ Slave I2C_%d !!!\n", Master_Ch, Slave_Ch);
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");




    // FPGA Debug I2C LoopBack Mode
    APACHE_TEST_I2C_SetDebugLoopBack(ON);



    // Init I2C Channel - Master
    tI2CParam_M.mIntEn  = tI2CTestFlag.mI2C_MasterIsrEn;
    tI2CParam_M.mOpMode = I2C_OP_MODE_MASTER;
    APACHE_TEST_I2C_Init(Master_Ch, &tI2CParam_M);



    // Init I2C Channel - Slave
    tI2CParam_S.mIntEn  = tI2CTestFlag.mI2C_SlaveIsrEn;
    tI2CParam_S.mOpMode = I2C_OP_MODE_SLAVE;
    APACHE_TEST_I2C_Init(Slave_Ch, &tI2CParam_S);
    


    //-------------------------------------------------------------------------
    // Single byte wirte
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "- Single-Byte Write Test\n");

    wBuff[0] = 0xAA;
    wBuff[1] = 0x55;
    wBuff[2] = 0xA5;
    wBuff[3] = 0x5A;

    for(i=0; i<4; i++)
    {
        ncLib_I2C_Write(Master_Ch, RegAddr+i, (UINT8 *)&wBuff[i], 1);
        if(tI2CTestFlag.mI2C_DebugMsgOn == ON)
        {
            DEBUGMSG(MSGINFO, "  > A:0x%02X W:0x%02X\n", RegAddr+i, wBuff[i]);
            APACHE_TEST_WaitKey();
        }
    }
    //-------------------------------------------------------------------------       


    //-------------------------------------------------------------------------
    // Single-byte read
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "- Single-Byte Read Test\n"); 

    for(i=0; i<4; i++)
    {
        ncLib_I2C_Read(Master_Ch, i, (UINT8 *)&rBuff[i], 1);
        if(tI2CTestFlag.mI2C_DebugMsgOn == ON)
        {
            DEBUGMSG(MSGINFO, " > A:0x%02X W:0x%02X\n", i, rBuff[i]);
            APACHE_TEST_WaitKey();
        }
    }
    //-------------------------------------------------------------------------


    // DeInit I2C Channel - Master
    APACHE_TEST_I2C_DeInit(Master_Ch, &tI2CParam_M);



    // DeInit I2C Channel - Slave
    APACHE_TEST_I2C_DeInit(Slave_Ch, &tI2CParam_S);



    // FPGA Debug I2C LoopBack Mode
    APACHE_TEST_I2C_SetDebugLoopBack(OFF);

}


void APACHE_TEST_I2C_HDMI_ChangeClock(void)
{    
    INT32 ret;
    
    eI2C_CH Ch;
    tI2C_PARAM tI2CParam;

    UINT32 Hz;    
    UINT8 rBuff[4];



    // Init I2C Channel
    Ch = tI2CTestFlag.mI2C_MasterCh;   



    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, " Test HDMI SIL9x34 I2C_%d BitRate Test!!!\n", Ch);
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");



    // Test Device HW Reset
    __test_i2c_sil9x34_reset(Ch);


    
    // Init I2C Channel  
    tI2CParam.mIntEn  = tI2CTestFlag.mI2C_MasterIsrEn;
    tI2CParam.mOpMode = I2C_OP_MODE_MASTER;    
    APACHE_TEST_I2C_Init(Ch, &tI2CParam);



    //-------------------------------------------------------------------------
    // Test Start....
    for(Hz=tI2CTestFlag.mI2C_Hz; Hz<=(400*KHZ); Hz+=tI2CTestFlag.mI2C_Step)
    {
        // Change Hz
        ncLib_I2C_Ctrl_SetBitRate(Ch, Hz);


        if(tI2CTestFlag.mI2C_TestMode == ON)
        {
            // Read ID
            ncLib_I2C_Read(Ch, 0x00, (UINT8 *)&rBuff[0], 4);

            // Compare - Display Device ID
            DEBUGMSG(MSGINFO, "\r %06d-Hz VND_ID 0x%04X DEV_ID 0x%04X", Hz, rBuff[1]<<8|rBuff[0], rBuff[3]<<8|rBuff[2]);
            if(    (((rBuff[1]<<8)|rBuff[0]) == 0x0001) 
                && ((((rBuff[3]<<8)|rBuff[2]) == 0x9034) || (((rBuff[3]<<8)|rBuff[2]) == 0x9134)))
                DEBUGMSG(MSGINFO, " : OK");
            else
                DEBUGMSG(MSGINFO, " : Fail\n"); 
        }
        else
        {
            // Devic HW Reset
            __test_i2c_sil9x34_reset(Ch);

            // HDMI Init
            ret = APACHE_TEST_I2C_InitSIL9x34();
            
            DEBUGMSG(MSGINFO, "\r %06d-Hz HDMI SIL9x35 Init", Hz);
            if(ret == NC_SUCCESS)
                DEBUGMSG(MSGINFO, " : OK");
            else
                DEBUGMSG(MSGINFO, " : Fail\n"); 
        }


        if(tI2CTestFlag.mI2C_DebugMsgOn == ON)
        {
            tI2CTestFlag.mI2C_DebugMsgOn = APACHE_TEST_WaitKey();
            DEBUGMSG(MSGINFO, "\n"); 
        }
    }
    //-------------------------------------------------------------------------



    // DeInit I2C Channel
    APACHE_TEST_I2C_DeInit(Ch, &tI2CParam);
 
}


void APACHE_TEST_I2C_HDMI_Initialize(void)
{
    INT32 ret;
    
    eI2C_CH Ch;
    tI2C_PARAM tI2CParam;
    


    // Init I2C Channel
    Ch = tI2CTestFlag.mI2C_MasterCh;   



    DEBUGMSG(MSGINFO, "====================================================\n");
    DEBUGMSG(MSGINFO, " Test HDMI SIL9x34 I2C_%d Initialize!!!\n", Ch);
    DEBUGMSG(MSGINFO, "====================================================\n");



    // Test Device HW Reset
    __test_i2c_sil9x34_reset(Ch);




    // Init I2C Channel
    tI2CParam.mIntEn  = tI2CTestFlag.mI2C_MasterIsrEn;
    tI2CParam.mOpMode = I2C_OP_MODE_MASTER;
    APACHE_TEST_I2C_Init(Ch, &tI2CParam);



    // HDMI Init
    ret = APACHE_TEST_I2C_InitSIL9x34();
    if(ret == NC_SUCCESS)
        DEBUGMSG(MSGINFO, " > HDMI SIL9x35 Init Success!!!\n\n");
    else
        DEBUGMSG(MSGINFO, " > HDMI SIL9x35 Init Failure!!!\n\n");



    // DeInit I2C Channel
    APACHE_TEST_I2C_DeInit(Ch, &tI2CParam);
  
}


void APACHE_TEST_I2C_HDMI_ReadID(void)
{    
    eI2C_CH Ch;
    tI2C_PARAM tI2CParam;

    UINT32 i;    
    UINT8 rBuff[4];
    UINT8 wBuff[4];



    // Init I2C Channel
    Ch = tI2CTestFlag.mI2C_MasterCh;   



    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, " Test HDMI SIL9x34 I2C_%d Interface Test!!!\n", Ch);
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");



    // Test Device HW Reset
    __test_i2c_sil9x34_reset(Ch);



    
    // Init I2C Channel 
    tI2CParam.mIntEn  = tI2CTestFlag.mI2C_MasterIsrEn;
    tI2CParam.mOpMode = I2C_OP_MODE_MASTER;    
    APACHE_TEST_I2C_Init(Ch, &tI2CParam);





    //-------------------------------------------------------------------------
    // Test Device HDMI SIL9x34
    //  - Vendor ID Low  Byte (RegAddr:0x00)
    //  - Vendor ID Higy Byte (RegAddr:0x01)
    //  - Device ID Low  Byte (RegAddr:0x02)
    //  - Device ID Higy Byte (RegAddr:0x03)
    //-------------------------------------------------------------------------
    // Single-byte read
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "- Single-Byte Read Test\n"); 

    for(i=0; i<4; i++)
    {
        ncLib_I2C_Read(Ch, i, (UINT8 *)&rBuff[i], 1);
        if(tI2CTestFlag.mI2C_DebugMsgOn == ON)
        {
            DEBUGMSG(MSGINFO, "  > A:0x%02X W:0x%02X\n", i, rBuff[i]);
            APACHE_TEST_WaitKey();
        }
    }

    DEBUGMSG(MSGINFO, "  > Vendor ID 0x%04X", rBuff[1]<<8|rBuff[0]);
    if( ((rBuff[1]<<8)|rBuff[0]) == 0x0001)
        DEBUGMSG(MSGINFO, " : OK\n");
    else
        DEBUGMSG(MSGINFO, " : Fail\n"); 

        
    DEBUGMSG(MSGINFO, "  > Device ID 0x%04X", rBuff[3]<<8|rBuff[2]);
    if( (((rBuff[3]<<8)|rBuff[2]) == 0x9034) || (((rBuff[3]<<8)|rBuff[2]) == 0x9134))
        DEBUGMSG(MSGINFO, " : OK\n");
    else
        DEBUGMSG(MSGINFO, " : Fail\n"); 
    //-------------------------------------------------------------------------



    //-------------------------------------------------------------------------
    // multi-byte read
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "- Multi-Byte Read Test\n");
    
    ncLib_I2C_Read(Ch, 0x00, (UINT8 *)&rBuff[0], 4);

    DEBUGMSG(MSGINFO, "  > Vendor ID 0x%04X", rBuff[1]<<8|rBuff[0]);
    if( ((rBuff[1]<<8)|rBuff[0]) == 0x0001)
        DEBUGMSG(MSGINFO, " : OK\n");
    else
        DEBUGMSG(MSGINFO, " : Fail\n"); 

        
    DEBUGMSG(MSGINFO, "  > Device ID 0x%04X", rBuff[3]<<8|rBuff[2]);
    if( (((rBuff[3]<<8)|rBuff[2]) == 0x9034) || (((rBuff[3]<<8)|rBuff[2]) == 0x9134))
        DEBUGMSG(MSGINFO, " : OK\n");
    else
        DEBUGMSG(MSGINFO, " : Fail\n"); 
    //-------------------------------------------------------------------------






    //-------------------------------------------------------------------------
    // Test Device HDMI SIL9x34
    //  - RegAddr:0x40 [7:0]
    //  - RegAddr:0x41 [1:0]
    //  - RegAddr:0x42 [7:0]
    //  - RegAddr:0x43 [3:0]
    //-------------------------------------------------------------------------
    // Single byte wirte and read
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "- Single-Byte Write Read Test\n");

    wBuff[0] = 0xA5;
    wBuff[1] = 0x03;
    wBuff[2] = 0x5A;
    wBuff[3] = 0x0F;

    // Write
    for(i=0; i<4; i++)
    {
        ncLib_I2C_Write(Ch, 0x40+i, (UINT8 *)&wBuff[i], 1);
        if(tI2CTestFlag.mI2C_DebugMsgOn == ON)
        {
            DEBUGMSG(MSGINFO, "  > A:0x%02X W:0x%02X\n", 0x40+i, wBuff[i]);
            APACHE_TEST_WaitKey();
        }
    }

    // Read
    for(i=0; i<4; i++)
    {
        ncLib_I2C_Read(Ch, 0x40+i, (UINT8 *)&rBuff[i], 1);
        if(tI2CTestFlag.mI2C_DebugMsgOn == ON)
        {
            DEBUGMSG(MSGINFO, "  > A:0x%02X R:0x%02X\n", 0x40+i, rBuff[i]);
            APACHE_TEST_WaitKey();
        }
    }

    // Compare
    for(i=0; i<4; i++)
    {
        DEBUGMSG(MSGINFO, "  > W:0x%02X vs R:0x%02X", wBuff[i], rBuff[i]);
        if(rBuff[i] == wBuff[i])
            DEBUGMSG(MSGINFO, " : OK\n");
        else
            DEBUGMSG(MSGINFO, " : Fail\n"); 
    }
    //-------------------------------------------------------------------------



    //-------------------------------------------------------------------------
    // Clear
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");    
    DEBUGMSG(MSGINFO, "- Clear\n");    
    
    wBuff[0] = 0x00;
    wBuff[1] = 0x00;
    wBuff[2] = 0x00;
    wBuff[3] = 0x00;
    
    ncLib_I2C_Write(Ch, 0x40, (UINT8 *)&wBuff[0], 4);
    ncLib_I2C_Read(Ch, 0x40, (UINT8 *)&rBuff[0], 4);

    for(i=0; i<4; i++)
    {
        if(rBuff[i] != wBuff[i])
            DEBUGMSG(MSGINFO, "- Clear Fail\n"); 
    }
    //-------------------------------------------------------------------------



    //-------------------------------------------------------------------------
    // Multi byte wirte and read
    DEBUGMSG(MSGINFO, "----------------------------------------------------\n");    
    DEBUGMSG(MSGINFO, "- Multi-Byte Write Read Test\n");

    wBuff[0] = 0xA5;
    wBuff[1] = 0x03;
    wBuff[2] = 0x5A;
    wBuff[3] = 0x0F;

    ncLib_I2C_Write(Ch, 0x40, (UINT8 *)&wBuff[0], 4);
    if(tI2CTestFlag.mI2C_DebugMsgOn == ON)
        APACHE_TEST_WaitKey();
    ncLib_I2C_Read(Ch, 0x40, (UINT8 *)&rBuff[0], 4);


    for(i=0; i<4; i++)
    {
        DEBUGMSG(MSGINFO, "  > W:0x%02X vs R:0x%02X", wBuff[i], rBuff[i]);
        if(rBuff[i] == wBuff[i])
            DEBUGMSG(MSGINFO, " : OK\n");
        else
            DEBUGMSG(MSGINFO, " : Fail\n"); 
    }
    //-------------------------------------------------------------------------





    // DeInit I2C Channel
    APACHE_TEST_I2C_DeInit(Ch, &tI2CParam);

}


INT32 APACHE_TEST_I2C_CUTMode(void)
{
    INT32 select;
    char buf[256];


    // FPGA Debug Display Port Enable (for Scope)
    APACHE_TEST_I2C_SetDebugPort(ON);


    // Default Init Variable
    tI2CTestFlag = tI2CTestFlag_Def;

    
    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - I2C                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " 2-Channel I2C Controller                                   \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> HDMI Sil9x34 Read ID         : I2C_CH%d                \n", tI2CTestFlag.mI2C_MasterCh);
        DEBUGMSG(MSGINFO, " <2> HDMI Sil9x34 Initialize      : I2C_CH%d                \n", tI2CTestFlag.mI2C_MasterCh);
        DEBUGMSG(MSGINFO, " <3> HDMI Sil9x34 Change BitRate  : I2C_CH%d                \n", tI2CTestFlag.mI2C_MasterCh);
        DEBUGMSG(MSGINFO, " <4> I2C Slave Test (UserCtrl)    : I2C_CH%d(M)/I2C_CH%d(S) \n", tI2CTestFlag.mI2C_MasterCh, tI2CTestFlag.mI2C_SlaveCh); 
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <A> I2C Channel Change                                     \n"); 
        DEBUGMSG(MSGINFO, " <B> I2C Master Interrupt On/Off  : %s                      \n", (tI2CTestFlag.mI2C_MasterIsrEn)?"On":"Off");         
        DEBUGMSG(MSGINFO, " <C> I2C Slave  Interrupt On/Off  : %s                      \n", (tI2CTestFlag.mI2C_SlaveIsrEn)?"On":"Off"); 
        DEBUGMSG(MSGINFO, " <D> I2C Debug Port On/Off        : %s                      \n", (tI2CTestFlag.mI2C_DebugPortOn)?"On":"Off");  
        DEBUGMSG(MSGINFO, " <E> I2C Clock Test Hz            : %06d Hz                 \n", tI2CTestFlag.mI2C_Hz);   
        DEBUGMSG(MSGINFO, " <F> I2C Clock Test Step          : %06d Hz                 \n", tI2CTestFlag.mI2C_Step);   
        DEBUGMSG(MSGINFO, " <G> I2C Clock Test Mode          : %s                      \n", (tI2CTestFlag.mI2C_TestMode)?"HDMI Read Id":"HDMI Init");   
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");      
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ..%s                       \n", (tI2CTestFlag.mI2C_DebugMsgOn)?"o":"x");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_I2C_HDMI_ReadID();
            break;

            case 2:
                APACHE_TEST_I2C_HDMI_Initialize();
            break;
            
            case 3:
                APACHE_TEST_I2C_HDMI_ChangeClock();
            break;

            case 4:
                APACHE_TEST_I2C_SlaveMode_UserAck();
            break;



            //-----------------------------------------------------------
            // Test Flow Ctrl
            case 10:
                tI2CTestFlag.mI2C_MasterCh = (tI2CTestFlag.mI2C_MasterCh?I2C_CH0:I2C_CH1);
                tI2CTestFlag.mI2C_SlaveCh  = (tI2CTestFlag.mI2C_SlaveCh?I2C_CH0:I2C_CH1);
            break;

            case 11:
                _REVERSE(tI2CTestFlag.mI2C_MasterIsrEn);
            break;

            case 12:
                _REVERSE(tI2CTestFlag.mI2C_SlaveIsrEn);
            break;

            case 13:
                _REVERSE(tI2CTestFlag.mI2C_DebugPortOn);
                APACHE_TEST_I2C_SetDebugPort(tI2CTestFlag.mI2C_DebugPortOn);
            break;

            case 14:
                APACHE_TEST_I2C_HzChange();
            break;
            
            case 15:
                APACHE_TEST_I2C_StepChange();
            break;

            case 16:
                _REVERSE(tI2CTestFlag.mI2C_TestMode);
            break;

            case 35:
                _REVERSE(tI2CTestFlag.mI2C_DebugMsgOn);
            break;
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto I2C_Exit;
        }
    }

I2C_Exit:

    // FPGA Debug Display Port Disable (for Scope)
    APACHE_TEST_I2C_SetDebugPort(OFF);

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_I2C */


 /* End Of File */

