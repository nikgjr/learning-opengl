/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_TIMER










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{  
    eTIMER_CH       mTIMER_TestCh;
    UINT32          mTIMER_TestPeriod;
    
    eDBG_GPIO_PORT  mTIMER_DebugGpioPort;
    UINT32          mTIMER_DebugTick;
    BOOL            mTIMER_DebugMsgOn;
} tTIMERTEST_FLAG, *ptTIMERTEST_FLAG;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tTIMERTEST_FLAG tTIMERTestFlag;
volatile tTIMERTEST_FLAG tTIMERTestFlag_Def = { 
                                                TC_CH0,
                                                400000,         // 400Msec
                                                DBG_GPIO_PORT0, 
                                                0,
                                                OFF
                                               };










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

void APACHE_TEST_TIMER_ChangeChannel(eTIMER_CH Ch)
{
    INT8 buf = 0;

    APACHE_TEST_GetArrowKey_Help("Channel Up", "Channel Down", NULL, NULL);
    
    DEBUGMSG(MSGINFO, "  > TIMER Select    : %d", Ch);
    
    while(1)
    {
        buf = ncLib_UART_Ctrl_GetChar(SYS_DEBUG_PORT);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(Ch < TC_CH7)
                    ++Ch;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(Ch > TC_CH1)
                    --Ch;
            }

            DEBUGMSG(MSGINFO, "\r  > TIMER Select    : %d", Ch, buf, buf);
        }
    }

    tTIMERTestFlag.mTIMER_TestCh = Ch;
}


void APACHE_TEST_TIMER_PeriodChange(void)
{
    tTIMERTestFlag.mTIMER_TestPeriod = APACHE_TEST_Display_InputValue(20, 10000000, "Change Period");
}


void APACHE_TEST_TIMER_Isr(UINT32 irq)
{
    INT32 Sts;
    eTIMER_CH Ch = (eTIMER_CH)(irq - IRQ_NUM_TIMER0);

    
    // Get timer status
    Sts = ncLib_TIMER_Ctrl_GetIntcStatus(Ch);
    
    // Toggle - Debug Gpio Port    
    APACHE_TEST_DebugGPIOToggle(tTIMERTestFlag.mTIMER_DebugGpioPort);

    if((tTIMERTestFlag.mTIMER_DebugMsgOn == ON) || (tTIMERTestFlag.mTIMER_TestPeriod > 10000))
    {
        DEBUGMSG(MSGINFO, " > [Pless any Key - Stop] IRQ_%02d_%x Period : %dus, DebugTick : %d\n", irq, Sts, tTIMERTestFlag.mTIMER_TestPeriod, tTIMERTestFlag.mTIMER_DebugTick); 
    }
    
    tTIMERTestFlag.mTIMER_DebugTick++; 
}


void APACHE_TEST_TIMER_Isr_Init(eTIMER_CH Ch)
{
    // Init - Debug Gpio Port
    APACHE_TEST_DebugGPIOSet(tTIMERTestFlag.mTIMER_DebugGpioPort, GPIO_LOW);

    
    // Register TIMER Interrupt Handler
    ncLib_INTC_Ctrl_RegisterHandler((UINT32)(IRQ_NUM_TIMER0 + Ch), (PrHandler)APACHE_TEST_TIMER_Isr);
}


void APACHE_TEST_TIMER_Isr_DeInit(eTIMER_CH Ch)
{
    // Unregister TIMER Interrupt Handler
    ncLib_INTC_Ctrl_UnRegisterHandler((UINT32)(IRQ_NUM_TIMER0 + Ch)); 
}


void APACHE_TEST_TIMER_Init(eTIMER_CH Ch, ptTIMER_PARAM ptTimerParam)
{
    INT32 ret;


    // Open Timer
    ncLib_TIMER_Open();


    // Register Isr
    APACHE_TEST_TIMER_Isr_Init(Ch);

    
    // Init Timer Channel 
    ret = ncLib_TIMER_Ctrl_Init(Ch, ptTimerParam);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Init Error!\n");
    }

    // Debug Port Trigger
    if(ptTimerParam->mMode == TC_MODE_ONESHOT)
    {
        APACHE_TEST_DebugGPIOToggle(tTIMERTestFlag.mTIMER_DebugGpioPort);
        nc_mdelay(10);
        APACHE_TEST_DebugGPIOToggle(tTIMERTestFlag.mTIMER_DebugGpioPort);
    }


    // Start timer
    ret = ncLib_TIMER_Ctrl_Start(Ch);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Start Error!\n");
    }
}


void APACHE_TEST_TIMER_DeInit(eTIMER_CH Ch)
{
    INT32 ret;


    // Stop timer
    ret = ncLib_TIMER_Ctrl_Stop(Ch);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Stop Error!\n");
    }


    // DeInit timer
    ret = ncLib_TIMER_Ctrl_DeInit(Ch);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer DeInit Error!\n");
    }

    
    // Unegister Isr
    APACHE_TEST_TIMER_Isr_DeInit(Ch);


    // Close Timer
    ncLib_TIMER_Close();
}


void APACHE_TEST_TIMER_CoreDelayCheck(void)
{
    INT8 buf = 0;    
    UINT32 msec = 1;


    // Init - Debug Gpio Port
    APACHE_TEST_DebugGPIOSet(tTIMERTestFlag.mTIMER_DebugGpioPort, GPIO_LOW);


    // User Guide Diplay
    APACHE_TEST_GetArrowKey_Help("Core Delay Up", "Core Delay Down", NULL, NULL);
    DEBUGMSG(MSGINFO, "  > msec(%04d)", msec); 


    // Test Run
    while(1)
    {
        buf = ncLib_UART_Ctrl_GetChar(SYS_DEBUG_PORT);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                msec++;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(msec > 1)
                    msec--;
            }
            // Number Key '6' and Direction Key 'Rigth'
            else if(buf == '6')
            {
                msec+=100;
            }
            // Number Key '4' and Direction Key 'Left'
            else if(buf == '4')
            {
                if(msec > 100)
                    msec-=100;
            }
            DEBUGMSG(MSGINFO, "\r  > msec(%04d)", msec);
        }

        // system delay
        nc_mdelay(msec);

        
        APACHE_TEST_DebugGPIOToggle(tTIMERTestFlag.mTIMER_DebugGpioPort);
    }    
}


void APACHE_TEST_TIMER_SWDelayCheck(void)
{
    volatile unsigned int i,j;    
 
    INT8 buf = 0;    
    UINT32 msec = 1;

    // DB_r2080
    //  - CPU 50Mhz, Cache On(10000), Cache Off(1000) 
    UINT32 sw_delay = 10000;


    // Init - Debug Gpio Port
    APACHE_TEST_DebugGPIOSet(tTIMERTestFlag.mTIMER_DebugGpioPort, GPIO_LOW);


    // User Guide Diplay
    APACHE_TEST_GetArrowKey_Help("SW Delay Up", "SW Delay Down", NULL, NULL);
    DEBUGMSG(MSGINFO, "  > msec(%04d), sw_delay(%04d)", msec, sw_delay); 


    // Test Run
    while(1)
    {
        buf = ncLib_UART_Ctrl_GetChar(SYS_DEBUG_PORT);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                sw_delay++;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(sw_delay > 1)
                    sw_delay--;
            }
            // Number Key '6' and Direction Key 'Rigth'
            else if(buf == '6')
            {
                msec++;
            }
            // Number Key '4' and Direction Key 'Left'
            else if(buf == '4')
            {
                if(msec > 1)
                    msec--;
            }
            
            DEBUGMSG(MSGINFO, "\r  > msec(%04d), sw_delay(%04d)", msec, sw_delay);
        }

        // sw delay
        for(i=0; i<msec; i++)
        {
            for(j=0; j<sw_delay; j++);
        }
        
        APACHE_TEST_DebugGPIOToggle(tTIMERTestFlag.mTIMER_DebugGpioPort);
    }    
}


void APACHE_TEST_TIMER_WDTMode(eTIMER_CH Ch)
{
    tTIMER_PARAM tTimerParam;
    UINT32 i;


    // Timer Channel Operation Mode
    tTimerParam.mMode      = TC_MODE_WDT;
    tTimerParam.mPrescaler = 0;
    tTimerParam.mPeriod1   = tTIMERTestFlag.mTIMER_TestPeriod;


    // Test Defence
    if(tTimerParam.mPeriod1 < 2000000)  // 2sec
        tTimerParam.mPeriod1 = 2000000;


    // Init Timer Channel 
    tTIMERTestFlag.mTIMER_DebugTick = 0;   
    APACHE_TEST_TIMER_Init(Ch, &tTimerParam);



    // Watchdog Reload(10s) -> Wait Wathdog TimeOut(Period)
    i= 0;
    while(1)
    {
        for( ; i<10; i++)
        {
            DEBUGMSG(MSGINFO, "   - Watch-Dog refresh %d(sec)\n", i+1);
            
            nc_delay(1);
            ncLib_TIMER_Ctrl_RefreshWDT(Ch);
        }

        nc_delay(1);
        DEBUGMSG(MSGINFO, "   - Watch-Dog reset mode waiting ...%d(sec)\n", ++tTIMERTestFlag.mTIMER_DebugTick);
    }   
    
}


void APACHE_TEST_TIMER_OneShotMode(eTIMER_CH Ch)
{
    tTIMER_PARAM tTimerParam;


    // Timer Channel Operation Mode
    tTimerParam.mMode      = TC_MODE_ONESHOT;
    tTimerParam.mPrescaler = 0;
    tTimerParam.mPeriod1   = tTIMERTestFlag.mTIMER_TestPeriod;



    // Init Timer Channel 
    tTIMERTestFlag.mTIMER_DebugTick = 0;   
    APACHE_TEST_TIMER_Init(Ch, &tTimerParam);



    // Wait Input Key;
    DEBUGMSG(MSGINFO, " > [Pless any Key - Stop] \n");
    APACHE_TEST_WaitKey();



    // DeInit Timer Channel
    APACHE_TEST_TIMER_DeInit(Ch);
    
}


void APACHE_TEST_TIMER_PeriodMode(eTIMER_CH Ch)
{
    tTIMER_PARAM tTimerParam;


    // Timer Channel Operation Mode
    tTimerParam.mMode      = TC_MODE_PERIOD;
    tTimerParam.mPrescaler = 0;
    tTimerParam.mPeriod1   = tTIMERTestFlag.mTIMER_TestPeriod;



    // Init Timer Channel 
    tTIMERTestFlag.mTIMER_DebugTick = 0;   
    APACHE_TEST_TIMER_Init(Ch, &tTimerParam);



    // Wait Input Key;
    DEBUGMSG(MSGINFO, " > [Pless any Key - Stop] \n");
    APACHE_TEST_WaitKey();



    // DeInit Timer Channel
    APACHE_TEST_TIMER_DeInit(Ch);
    
}


INT32 APACHE_TEST_TIMER_CUTMode(void)
{
    INT32 select;
    char buf[16];
    eTIMER_CH Ch;



    // Default Init Variable
    tTIMERTestFlag = tTIMERTestFlag_Def;



    while(1)
    {
        Ch = tTIMERTestFlag.mTIMER_TestCh;
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - TIMER       				   \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " 2-Channel(Sub-4) Timer Controller                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> Period Mode Test                                       \n");
        DEBUGMSG(MSGINFO, " <2> OneShot Mode Test                                      \n");
        DEBUGMSG(MSGINFO, " <3> Watchdog Mode Test                                     \n");
        DEBUGMSG(MSGINFO, " <4> SW Delay Value Check                                   \n");
        DEBUGMSG(MSGINFO, " <5> Core Delay Check                                       \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <6> TIMER Channel Change   : TIMER_CH%d                    \n", Ch);
        DEBUGMSG(MSGINFO, " <7> TIMER Period Change    : %d usec                       \n", tTIMERTestFlag.mTIMER_TestPeriod); 
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ..%s                       \n", (tTIMERTestFlag.mTIMER_DebugMsgOn)?"o":"x");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_TIMER_PeriodMode(Ch);
            break;


            case 2:
                APACHE_TEST_TIMER_OneShotMode(Ch);
            break;


            case 3:
                APACHE_TEST_TIMER_WDTMode(Ch);
            break;


            case 4:
                APACHE_TEST_TIMER_SWDelayCheck();
            break;


            case 5:
                APACHE_TEST_TIMER_CoreDelayCheck();
            break;


            case 6:
                APACHE_TEST_TIMER_ChangeChannel(Ch);
            break;   


            case 7:
                APACHE_TEST_TIMER_PeriodChange();
            break;   
            

            case 35: // Z
                _REVERSE(tTIMERTestFlag.mTIMER_DebugMsgOn);
            break;  

            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto TIMER_Exit;
        }
    }

TIMER_Exit:

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_TIMER */


/* End Of File */

