/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"
#include "./CoreMark/coremark.h"
#include "./Dhrystone/dhry.h"

#if ENABLE_IP_CORE










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{  
    eTIMER_CH       mCORE_TestTimerCh;
    UINT32          mCORE_TestTimerPeriod;

    eDBG_GPIO_PORT  mCORE_DebugGpioPort;    
    UINT32          mCORE_DebugTick;
} tCORETEST_FLAG, *ptCORETEST_FLAG;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tCORETEST_FLAG tCORETestFlag;
volatile tCORETEST_FLAG tCORETestFlag_Def = { 
                                                TC_CH7,
                                                100000,              // 100-msec
                                                DBG_GPIO_PORT0,
                                                0 
                                               };










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/


void __test_core_timer_isr(UINT32 irq)
{
    eTIMER_CH Ch = (eTIMER_CH)(irq - IRQ_NUM_TIMER0);

    ncLib_TIMER_Ctrl_GetIntcStatus(Ch);

    tCORETestFlag.mCORE_DebugTick++; 

    // Toggle - Debug Gpio Port    
    APACHE_TEST_DebugGPIOToggle(tCORETestFlag.mCORE_DebugGpioPort);
}


static __test_core_timer_init(void)
{
    INT32 ret;
    eTIMER_CH Ch = tCORETestFlag.mCORE_TestTimerCh;
    tTIMER_PARAM tTimerParam;


    // Timer Channel Operation Mode
    tTimerParam.mMode      = TC_MODE_PERIOD;
    tTimerParam.mPrescaler = 0;
    tTimerParam.mPeriod1   = tCORETestFlag.mCORE_TestTimerPeriod;


    // Open Timer
    ncLib_TIMER_Open();


    // Register TIMER Interrupt Handler
    ncLib_INTC_Ctrl_RegisterHandler((UINT32)(IRQ_NUM_TIMER0 + Ch), (PrHandler)__test_core_timer_isr);

    
    // Init Timer Channel 
    ret = ncLib_TIMER_Ctrl_Init(Ch, &tTimerParam);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Init Error!\n");
    }


    // Debug Flag
    tCORETestFlag.mCORE_DebugTick = 0;
    APACHE_TEST_DebugGPIOSet(tCORETestFlag.mCORE_DebugGpioPort, GPIO_LOW);


    // Start timer
    ret = ncLib_TIMER_Ctrl_Start(Ch);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Start Error!\n");
    }
}


static __test_core_timer_deinit(void)
{
    INT32 ret;
    eTIMER_CH Ch = tCORETestFlag.mCORE_TestTimerCh;

    // Stop timer
    ret = ncLib_TIMER_Ctrl_Stop(Ch);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Stop Error!\n");
    }


    // DeInit timer
    ret = ncLib_TIMER_Ctrl_DeInit(Ch);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer DeInit Error!\n");
    }

    
    // Unregister TIMER Interrupt Handler
    ncLib_INTC_Ctrl_UnRegisterHandler((UINT32)(IRQ_NUM_TIMER0 + Ch)); 


    // Close Timer
    ncLib_TIMER_Close(); 
}



/*
*-------------------------------------------------------------------------------
* DB_r2080 (CPU_50MHz)
*-------------------------------------------------------------------------------
* - Cache On
*    2K performance run parameters for coremark.
*    CoreMark Size    : 666
*    Total ticks      : 926008104
*    Total time (secs): 37.040324 -> (OK)
*    Iterations/Sec   : 80.992812 -> (OK)
*    Iterations       : 3000
*    Memory location  : STACK
*    seedcrc          : 0xe9f5
*    [0]crclist       : 0xe714
*    [0]crcmatrix     : 0x1fd7
*    [0]crcstate      : 0x8e3a
*    [0]crcfinal      : 0xcc42
*    Correct operation validated. See readme.txt for run and reporting ru.
*    CoreMark 1.0     : 80.992812/50MHz = 1.61985624 (OK)
*-------------------------------------------------------------------------------
*    > Total Time (37.000)msec => 81.081081/50MHz => 1.62162162
*-------------------------------------------------------------------------------
*
*
* - Cache Off
*    2K performance run parameters for coremark.
*    CoreMark Size    : 666
*    Total ticks      : 866579944 -> (Fail) The Tick value has been overflowed.
*    Total time (secs): 34.663198 -> (Fail) The Tick value has been overflowed.
*    Iterations/Sec   : 86.547122 -> (Fail) It was calculated as an invalid Tick.
*    Iterations       : 3000
*    Memory location  : STACK
*    seedcrc          : 0xe9f5
*    [0]crclist       : 0xe714
*    [0]crcmatrix     : 0x1fd7
*    [0]crcstate      : 0x8e3a
*    [0]crcfinal      : 0xcc42
*    Correct operation validated. See readme.txt for run and reporting ru.
*    CoreMark 1.0     : 86.547122/50MHz = 1.73094244 (Fail) 
*-------------------------------------------------------------------------------
*    > Total Time (378.300)msec => 7.930214/50MHz => 0.15860428
*-------------------------------------------------------------------------------
*/

/*
*-------------------------------------------------------------------------------
* DB_r2099_newcpu (CPU_50MHz)
*-------------------------------------------------------------------------------
* - Cache On
* Dhrystone Benchmark, Version 2.1 (Language: C)
*
* Program compiled without 'register' attribute
*
* Please give the number of runs through the benchmark: 32001
* Execution starts, 32001 runs through Dhrystone
* Execution ends
*
* Final values of the variables used in the benchmark:
*
* Int_Glob:            5
*         should be:   5
* Bool_Glob:           1
*         should be:   1
* Ch_1_Glob:           A
*         should be:   A
* Ch_2_Glob:           B
*         should be:   B
* Arr_1_Glob[8]:       7
*         should be:   7
* Arr_2_Glob[8][7]:    32011
*         should be:   Number_Of_Runs + 10
* Ptr_Glob->
*   Ptr_Comp:          33554456
*         should be:   (implementation-dependent)
*   Discr:             0
*         should be:   0
* Enum_Comp:           2
*         should be:   2
*   Int_Comp:          17
*         should be:   17
*   Str_Comp:          DHRYSTONE PROGRAM, SOME STRING
*         should be:   DHRYSTONE PROGRAM, SOME STRING
* Next_Ptr_Glob->
*   Ptr_Comp:          33554456
*         should be:   (implementation-dependent), same as above
*   Discr:             0
*         should be:   0
*   Enum_Comp:         1
*         should be:   1
*   Int_Comp:          18
*         should be:   18
*   Str_Comp:          DHRYSTONE PROGRAM, SOME STRING
*         should be:   DHRYSTONE PROGRAM, SOME STRING
* Int_1_Loc:           5
*         should be:   5
* Int_2_Loc:           13
*         should be:   13
* Int_3_Loc:           7
*         should be:   7
* Enum_Loc:            1
*         should be:   1
* Str_1_Loc:           DHRYSTONE PROGRAM, 1'ST STRING
*         should be:   DHRYSTONE PROGRAM, 1'ST STRING
* Str_2_Loc:           DHRYSTONE PROGRAM, 2'ND STRING
*         should be:   DHRYSTONE PROGRAM, 2'ND STRING
*
* Microseconds for one run through Dhrystone: 12.796
* Dhrystones per Second:                      78149.4
*
* -------------------------------------------------------
* Begin_Time: 93111778
* End_Time:   93521263
* User_Time:  409485
* -------------------------------------------------------
* DMIPS =     44.48
* DMIPS/MHz = 1.78
* -------------------------------------------------------
*
*
* - Cache Off
* Microseconds for one run through Dhrystone: 180.215
* Dhrystones per Second:                      5548.9
*
* -------------------------------------------------------
* Begin_Time: 80735853
* End_Time:   86502916
* User_Time:  5767063
* -------------------------------------------------------
* DMIPS =     3.16
* DMIPS/MHz = 0.13
* -------------------------------------------------------
*/


INT32 APACHE_TEST_CORE_CUTMode(void)
{
    INT32 select;
    char buf[256];


    // Default Init Variable
    tCORETestFlag = tCORETestFlag_Def;


    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - Core                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Core                                                       \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> CoreMask Test                                          \n");
        DEBUGMSG(MSGINFO, " <2> Dhrystone Test                                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                DEBUGMSG(MSGINFO, "> Please Wait ~~ \n");
                __test_core_timer_init();
                coremark_main();
                __test_core_timer_deinit();
                DEBUGMSG(MSGINFO, "> Total Time (%d)msec\n", tCORETestFlag.mCORE_DebugTick*(tCORETestFlag.mCORE_TestTimerPeriod/1000));
            break;

            case 2:
                DEBUGMSG(MSGINFO, "> Please Wait ~~ \n");
                __test_core_timer_init();
                dhrystone_main();
                __test_core_timer_deinit();
                DEBUGMSG(MSGINFO, "> Total Time (%d)msec\n", tCORETestFlag.mCORE_DebugTick*(tCORETestFlag.mCORE_TestTimerPeriod/1000));
            break;

            case 0:
                DEBUGMSG(MSGINFO, "Move on to sub menu\n");
            goto Core_Exit;
        }
    }

Core_Exit:

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_CORE */


/* End Of File */

