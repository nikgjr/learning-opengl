/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_FPU

#include <float.h>
#include <math.h>










/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#ifndef NAN
#define NAN (0.0/0.0)
#endif

#ifndef INFINITY
#define INFINITY (1.0/0.0)
#endif

#define DBL_NAN (NAN)
#define DBL_POS_INF (INFINITY)
#define DBL_NEG_INF (- DBL_POS_INF)

#define ERRSTR(X) ((X) ? " [ERROR]" : "")

#define TSTCONST(S,OP)                                          \
  DEBUGMSG(MSGINFO, "Constant expression 1 " S " DBL_MIN = %.20f\n"       \
          "Variable expression 1 " S " DBL_MIN = %.20f\n",      \
          1.0 OP DBL_MIN, 1.0 OP x);

#define TSTDIV(T,S)                                     \
  do                                                    \
    {                                                   \
      volatile T x = 1.0, y = 3.0;                      \
      x /= y;                                           \
      DEBUGMSG(MSGINFO, "1/3 in %-12s: %" S "f\n", #T, x);        \
    }                                                   \
  while (0)

#define TEST_PRNT(R, F, S)                                          \
 do                                                                 \
  {                                                                 \
    double x;                                                       \
    DEBUGMSG(MSGINFO, "%-11s", S);                                  \
    for (x = - bound; x <= bound; x += step)                        \
      if (x == 0)                                                   \
        {                                                           \
          DEBUGMSG(MSGINFO, R ? "%6.1f" : "%4d  ", F(-0.0));        \
          DEBUGMSG(MSGINFO, R ? "%6.1f" : "%4d  ", F(+0.0));        \
        }                                                           \
      else                                                          \
        {                                                           \
          DEBUGMSG(MSGINFO, R ? "%6.1f" : "%4d  ", F(x));           \
        }                                                           \
    DEBUGMSG(MSGINFO, "\n");                                        \
  }                                                                 \
  while (0)

#define TEST_FUNC(R, F) TEST_PRNT (R, F, #F)










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

static float flt_max = FLT_MAX;
static double dbl_max = DBL_MAX;
static long double ldbl_max = LDBL_MAX;

static float flt_epsilon = FLT_EPSILON;
static double dbl_epsilon = DBL_EPSILON;
static long double ldbl_epsilon = LDBL_EPSILON;

static double bound, step;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __test_float_h(void)
{
    DEBUGMSG(MSGINFO, "FLT_RADIX           = %d\n", (int) FLT_RADIX);
    DEBUGMSG(MSGINFO, "FLT_MANT_DIG        = %d\n", (int) FLT_MANT_DIG);
    DEBUGMSG(MSGINFO, "DBL_MANT_DIG        = %d\n", (int) DBL_MANT_DIG);
    DEBUGMSG(MSGINFO, "LDBL_MANT_DIG       = %d\n", (int) LDBL_MANT_DIG);
    DEBUGMSG(MSGINFO, "FLT_MIN_EXP         = %d\n", (int) FLT_MIN_EXP);
    DEBUGMSG(MSGINFO, "DBL_MIN_EXP         = %d\n", (int) DBL_MIN_EXP);
    DEBUGMSG(MSGINFO, "LDBL_MIN_EXP        = %d\n", (int) LDBL_MIN_EXP);
    DEBUGMSG(MSGINFO, "FLT_MAX_EXP         = %d\n", (int) FLT_MAX_EXP);
    DEBUGMSG(MSGINFO, "DBL_MAX_EXP         = %d\n", (int) DBL_MAX_EXP);
    DEBUGMSG(MSGINFO, "LDBL_MAX_EXP        = %d\n", (int) LDBL_MAX_EXP);
    DEBUGMSG(MSGINFO, "sizeof(float)       = %d\n", sizeof(float));
    DEBUGMSG(MSGINFO, "FLT_MIN             = %f\n", (float)FLT_MIN);
    DEBUGMSG(MSGINFO, "FLT_MAX             = %f\n", (float)FLT_MAX);
    DEBUGMSG(MSGINFO, "FLT_DIG             = %d\n", (int)FLT_DIG);
    DEBUGMSG(MSGINFO, "sizeof(double)      = %d\n", sizeof(double));
    DEBUGMSG(MSGINFO, "DBL_MIN             = %f\n", (double)DBL_MIN);
    //DEBUGMSG(MSGINFO, "DBL_MAX             = %f\n", (double)DBL_MAX);  
    DEBUGMSG(MSGINFO, "DBL_DIG             = %d\n", (int)DBL_DIG);
    DEBUGMSG(MSGINFO, "sizeof(long double) = %d\n", sizeof(long double));
    DEBUGMSG(MSGINFO, "LDBL_MIN            = %f\n", (long double)LDBL_MIN);
    //DEBUGMSG(MSGINFO, "LDBL_MAX            = %f\n", (long double)LDBL_MAX);  
    DEBUGMSG(MSGINFO, "LDBL_DIG            = %d\n\n", (int)LDBL_DIG);  
}


static void __tsteval_method (void)
{
    volatile double x, y, z;

    x = 9007199254740994.0; /* 2^53 + 2 */
    y = 1.0 - 1/65536.0;
    z = x + y;
    DEBUGMSG(MSGINFO, "x + y, with x = 9007199254740994.0 and y = 1.0 - 1/65536.0"
            " (type double).\n"
            "The IEEE-754 result is 9007199254740994 with double precision.\n"
            "The IEEE-754 result is 9007199254740996 with extended precision.\n"
            "The obtained result is %.17f.\n", z);

    if (z == 9007199254740996.0)  /* computations in extended precision */
    {
        volatile double a, b;
        double c;

        a = 9007199254740992.0; /* 2^53 */
        b = a + 0.25;
        c = a + 0.25;
        if (b != c)
        DEBUGMSG(MSGINFO, "\nBUG:\nThe implementation doesn't seem to convert values "
                "to the target type after\nan assignment (see ISO/IEC 9899: "
                "5.1.2.3#12, 6.3.1.5#2 and 6.3.1.8#2[52]).\n");
    }
}


static void __ldcast_test (void)
{
    volatile double a = 4294967219.0;
    volatile double b = 4294967429.0;
    double c, d;
    long double al, bl;

    al = a;
    bl = b;
    c = (long double) a * (long double) b;
    d = al * bl;
    if (c != d)
    {
        DEBUGMSG(MSGINFO, "\nBUG: Casts to long double do not seem to be taken into "
                "account when\nthe result to stored to a variable of type "
                "double. If your compiler\nis gcc (version < 4.3.4), this "
                "may be the following bug:\n    "
                "https://gcc.gnu.org/bugzilla/show_bug.cgi?id=36578\n");
    }
}


static void __tstnan (void)
{
    double d;

    /* Various tests to detect a NaN without using the math library (-lm).
    * MIPSpro 7.3.1.3m (IRIX64) does too many optimisations, so that
    * both NAN != NAN and !(NAN >= 0.0 || NAN <= 0.0) give 0 instead
    * of 1. As a consequence, in MPFR, one needs to use
    *    #define DOUBLE_ISNAN(x) (!(((x) >= 0.0) + ((x) <= 0.0)))
    * in this case. */

    d = NAN;
    DEBUGMSG(MSGINFO, "\n");
    DEBUGMSG(MSGINFO, "NAN != NAN --> %d (should be 1)\n", d != d);
    DEBUGMSG(MSGINFO, "isnan(NAN) --> %d (should be 1)\n", isnan (d));
    DEBUGMSG(MSGINFO, "NAN >= 0.0 --> %d (should be 0)\n", d >= 0.0);
    DEBUGMSG(MSGINFO, "NAN <= 0.0 --> %d (should be 0)\n", d <= 0.0);
    DEBUGMSG(MSGINFO, "  #3||#4   --> %d (should be 0)\n", d >= 0.0 || d <= 0.0);
    DEBUGMSG(MSGINFO, "!(#3||#4)  --> %d (should be 1)\n", !(d >= 0.0 || d <= 0.0));
    DEBUGMSG(MSGINFO, "  #3 + #4  --> %d (should be 0)\n", (d >= 0.0) + (d <= 0.0));
    DEBUGMSG(MSGINFO, "!(#3 + #4) --> %d (should be 1)\n\n", !((d >= 0.0) + (d <= 0.0)));
}


static void __tstcast (void)
{
    double x;
    x = (double) 0;
    DEBUGMSG(MSGINFO, "(double) 0 = %f\n", x);
}


/* This mostly tests signed zero support. This test is written in
   such a way that "gcc -O -ffast-math" gives a wrong result. */
static void __signed_zero_inf (void)
{
    double x = 0.0, y = -0.0, px, py, nx, ny;

    DEBUGMSG(MSGINFO, "Signed zero tests (x is 0.0 and y is -0.0):\n");

    if (x == y)
        DEBUGMSG(MSGINFO, "  Test 1.0 / x != 1.0 / y  returns %d (should be 1).\n",1.0 / x != 1.0 / y);
    else
        DEBUGMSG(MSGINFO, "x != y; this is wrong!\n");

    px = +x;
    if (x == px)
        DEBUGMSG(MSGINFO, "  Test 1.0 / x == 1.0 / +x returns %d (should be 1).\n", 1.0 / x == 1.0 / px);
    else
        DEBUGMSG(MSGINFO, "x != +x; this is wrong!\n");

    py = +y;
    if (x == py)
        DEBUGMSG(MSGINFO, "  Test 1.0 / x != 1.0 / +y returns %d (should be 1).\n", 1.0 / x != 1.0 / py);
    else
        DEBUGMSG(MSGINFO, "x != +y; this is wrong!\n");

    nx = -x;
    if (x == nx)
        DEBUGMSG(MSGINFO, "  Test 1.0 / x != 1.0 / -x returns %d (should be 1).\n", 1.0 / x != 1.0 / nx);
    else
        DEBUGMSG(MSGINFO, "x != -x; this is wrong!\n");

    ny = -y;
    if (x == ny)
        DEBUGMSG(MSGINFO, "  Test 1.0 / x == 1.0 / -y returns %d (should be 1).\n", 1.0 / x == 1.0 / ny);
    else
        DEBUGMSG(MSGINFO, "x != -y; this is wrong!\n");
}


static void __tstadd (double x, double y)
{
    double a, s;

    a = x + y;
    s = x - y;
    DEBUGMSG(MSGINFO, "%f + %f = %f\n", x, y, a);
    DEBUGMSG(MSGINFO, "%f - %f = %f\n", x, y, s);
}


static void __tstmul (double x, double y)
{
    double m;

    m = x * y;
    DEBUGMSG(MSGINFO, "%f * %f = %f\n", x, y, m);
}


static void __tstconst (void)
{
    volatile double x = DBL_MIN;

    TSTCONST ("+", +);
    TSTCONST ("-", -);
}


static void __tstpow (void)
{
    double val[] = { 0.0, 0.0, 0.0, +0.0, -0.0, +0.5, -0.5, +1.0, -1.0, +2.0, -2.0 };
    int i, j;

    /* Not used above to avoid an error with IRIX64 cc. */
    val[0] = DBL_NAN;
    val[1] = DBL_POS_INF;
    val[2] = DBL_NEG_INF;

    for (i = 0; i < sizeof (val) / sizeof (val[0]); i++)
    {
        for (j = 0; j < sizeof (val) / sizeof (val[0]); j++)
        {
            double p;
            p = pow (val[i], val[j]);
            DEBUGMSG(MSGINFO, "pow(%f, %f) = %f\n", val[i], val[j], p);
        }
    }
}


static void __tstall (void)
{
    float fm = FLT_MAX, fe = FLT_EPSILON;
    double dm = DBL_MAX, de = DBL_EPSILON;
    long double lm = LDBL_MAX, le = LDBL_EPSILON;

    __tstcast ();
    __signed_zero_inf ();

    __tstadd (+0.0, +0.0);
    __tstadd (+0.0, -0.0);
    __tstadd (-0.0, +0.0);
    __tstadd (-0.0, -0.0);
    __tstadd (+1.0, +1.0);
    __tstadd (+1.0, -1.0);

    __tstmul (+0.0, +0.0);
    __tstmul (+0.0, -0.0);
    __tstmul (-0.0, +0.0);
    __tstmul (-0.0, -0.0);

    __tstconst ();
    
    TSTDIV (float, "");
    TSTDIV (double, "");
    TSTDIV (long double, "L");

    DEBUGMSG(MSGINFO, "Dec 1.1  = %f\n", (double) 1.1);
    DEBUGMSG(MSGINFO, "FLT_MAX  = %f%s\n", (double) fm, ERRSTR (fm != flt_max));
    DEBUGMSG(MSGINFO, "DBL_MAX  = %f%s\n", dm, ERRSTR (dm != dbl_max));
    DEBUGMSG(MSGINFO, "LDBL_MAX = %Lf%s\n", lm, ERRSTR (lm != ldbl_max));
    DEBUGMSG(MSGINFO, "FLT_EPSILON  = %f%s\n", (double) fe, ERRSTR (fe != flt_epsilon));
    DEBUGMSG(MSGINFO, "DBL_EPSILON  = %f%s\n", de, ERRSTR (de != dbl_epsilon));
    DEBUGMSG(MSGINFO, "LDBL_EPSILON = %f%s\n", le, ERRSTR (le != ldbl_epsilon));

    __tstpow ();

}


static double __myrint (double x)
{
    static const double TWO52 = 4503599627370496.0;

    if (fabs (x) < TWO52)
    {
        if (x > 0.0)
        {
            x += TWO52;
            x -= TWO52;
            if (x == 0.0)
                x = 0.0;
        }
        else if (x < 0.0)
        {
            x -= TWO52;
            x += TWO52;
            if (x == 0.0)
                x = -0.0;
        }
    }

    return x;
}


void __out (double x, char *s)
{
    int exp;
    long long m;

    m = frexp (x, &exp) * 9007199254740992LL;
    DEBUGMSG(MSGINFO, "%s = %-23.17f (mant: %lld/2^53, exp: %d)\n", s, x, m, exp);
}


void APACHE_TEST_FPU_Ieee754(void)
{
    __test_float_h();
    __tsteval_method();
    __ldcast_test();
    __tstnan();
    __tstall();
}


void APACHE_TEST_FPU_NearestInt(void)
{
    bound = 4.5;
    step = 1;  
    
    TEST_PRNT (1, , "");
    TEST_PRNT (0, (int), "casttoint");
    
    //TEST_FUNC (1, trunc);
    TEST_FUNC (1, floor);
    TEST_FUNC (1, ceil);
    //TEST_FUNC (1, round);
    //TEST_FUNC (1, nearbyint);
    TEST_FUNC (1, __myrint);
    TEST_FUNC (1, rint);
}


void APACHE_TEST_FPU_TrigonometricFunc(void)
{
    double x, y;


    //--------------------------------------------------------------------------
    //      x  = 1.00000000000000000     (mant: 4503599627370496/2^53, exp: 1)
    //  sin(x) = 0.84147098480789655     (mant: 7579296827247854/2^53, exp: 0)
    //--------------------------------------------------------------------------
    x = 1.0;
    y = sin (x);

    __out (x, "      x ");
    __out (y, "  sin(x)");   



    //--------------------------------------------------------------------------
    //      x  = 1.00000000000000000     (mant: 4503599627370496/2^53, exp: 1)
    //  cos(x) = 0.54030230586813977     (mant: 4866610526750348/2^53, exp: 0)
    //--------------------------------------------------------------------------
    //x = 1.0;
    y = cos (x);
    __out (y, "  cos(x)");



    //--------------------------------------------------------------------------
    //      x  = 1.00000000000000000     (mant: 4503599627370496/2^53, exp: 1)
    //  tan(x) = 1.55740772465490229     (mant: 7013940848419750/2^53, exp: 1)
    //--------------------------------------------------------------------------
    //x = 1.0;
    y = tan (x);
    __out (y, "  tan(x)");



    //--------------------------------------------------------------------------
    //      x  = 1.55740772465490229     (mant: 7013940848419750/2^53, exp: 1)
    // atan(x) = 1.00000000000000000     (mant: 4503599627370496/2^53, exp: 1)
    //--------------------------------------------------------------------------
    x = y;
    y = atan (x);
    __out (y, " atan(x)");
    
}


void APACHE_TEST_FPU_Logarithm(void)
{
    double x, y;

    //--------------------------------------------------------------------------
    //      x  = 1.10000000000000009     (mant: 4953959590107546/2^53, exp: 1)
    //  log(x) = 0.09531017980432493     (mant: 6867822244021964/2^53, exp: -3)
    // logf(x) = 0.09531020373106003     (mant: 6867823968124928/2^53, exp: -3)
    //--------------------------------------------------------------------------
    x = 1.1;
    y = log (x);
    __out (x, "      x ");
    __out (y, "  log(x)");    

    y = logf (x);
    __out (y, " logf(x)");    
   
}


void APACHE_TEST_FPU_Sqrt(void)
{
    double n1, n2;

    n1 = 1.0;
    n2 = 2.0;

    DEBUGMSG(MSGINFO, "Before : %f %f \n", n1, n2);

    n1 = sqrt(n1);
    n2 = sqrt(n2);

    DEBUGMSG(MSGINFO, "After  : %f %f \n", n1, n2);
}


INT32 APACHE_TEST_FPU_CUTMode(void)
{
    INT32 select;
    char buf[16];
    

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - FPU                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Floating Point Test                                        \n");
        DEBUGMSG(MSGINFO, "  - URL : http://www.vinc17.net/research/fptest.en.html     \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> IEEE754                                                \n");
        DEBUGMSG(MSGINFO, " <2> Nearest Interger Func                                  \n");
        DEBUGMSG(MSGINFO, " <3> Trigonometric Func                                     \n");
        DEBUGMSG(MSGINFO, " <4> Logarithm Func                                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ...                        \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");
        
        switch(select)
        {
            case 1:
                APACHE_TEST_FPU_Ieee754();
            break;

            case 2:
                APACHE_TEST_FPU_NearestInt();
            break;

            case 3:
                APACHE_TEST_FPU_TrigonometricFunc();
            break;

            case 4:
                APACHE_TEST_FPU_Logarithm();
            break;
            
            case 5:
                APACHE_TEST_FPU_Sqrt();
            break;
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto FPU_Exit;
        }
    }

FPU_Exit:

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_FPU */


/* End Of File */

