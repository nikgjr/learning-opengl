/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/


void APACHE_TEST_FUNC_BitSeparation(void)
{
#if 0
    INT32    i, j;
    UINT32   nTmp;
    UINT32   nMaxBit;


    DEBUGMSG(MSGINFO, "\n\n"); 
    DEBUGMSG(MSGINFO, "UINT8 gaIrqTable[][] = { \n");


    // Check Irq Max Bit
    for(i=8; i>=0; i--)
    {
        if(MAX_IRQ_NUM&(1U<<i)) 
        {
            nMaxBit = (1<<i);
            break;
        }
    }


    // Check input irq Min ~ Max
    for(i=IRQ_NUM_TIMER0; i<nMaxBit; i++)
    {
        DEBUGMSG(MSGINFO, "    { ");
        
        // Valid Range
        for(j=IRQ_NUM_TIMER0;j<=IRQ_NUM_IPC2; j++)
        {
            nTmp = i & j;

            // Check Valid Irq
            if( nTmp == j )
                DEBUGMSG(MSGINFO, "%d, ", nTmp); 
        }
        DEBUGMSG(MSGINFO, "0 },\n");
    }
    DEBUGMSG(MSGINFO, "}\n");
#endif    
}


void APACHE_TEST_FUNC_MakeASM(void)
{
#if 0
    UINT32 InAddr = 0x80000018;

    InAddr &= ~(0x1f);
    //BIC r0, r0, #0x1F ; r0 - Align(32)
#endif
}


void APACHE_TEST_FUNC_ConvVirToPhy(void)
{
#if 0
    UINT32 REG_REMAP_START;
    UINT32 REG_REMAP_END;
    UINT32 REG_REMAP_SIZE;
    
    UINT32 InAddr;
    UINT32 ConvAddr;
    

    while(1)
    {
        // test value : change JTAG (used debug register)
        InAddr   = REGRW32(APACHE_SYSCON_BASE, 0x100C);
        ConvAddr = InAddr;  

        DEBUGMSG(MSGINFO, "------------------------\n");    
        
        if(REGRW32(APACHE_SYSCON_BASE, 0x1000)&0x01) 
        {
            REG_REMAP_START  = REGRW32(APACHE_SYSCON_BASE, 0x1004)&0xFFFF0000;
            REG_REMAP_END    = REGRW32(APACHE_SYSCON_BASE, 0x1008)&0xFFFF0000;
            REG_REMAP_SIZE   = REGRW32(APACHE_SYSCON_BASE, 0x1008)&0x0000FFFF;

            DEBUGMSG(MSGINFO, " RemapStart : 0x%08X\n", REG_REMAP_START);
            DEBUGMSG(MSGINFO, " RemapEnd   : 0x%08X\n", REG_REMAP_END);
            DEBUGMSG(MSGINFO, " RemapSize  : 0x%08X\n", ((REG_REMAP_SIZE+1)*(64*KB)));
            
            if((ConvAddr >= REG_REMAP_START) && (ConvAddr < (REG_REMAP_START + ((REG_REMAP_SIZE+1)*(64*KB)))))
            {
                ConvAddr = ConvAddr&~(REG_REMAP_START);
                ConvAddr |= REG_REMAP_END;
                
                DEBUGMSG(MSGINFO, " ChangeAddr : Vir to Phy \n");
            }
        }

        DEBUGMSG(MSGINFO, " InAddr     : 0x%08X\n", InAddr);
        DEBUGMSG(MSGINFO, " ConvAddr   : 0x%08X\n", ConvAddr);
        DEBUGMSG(MSGINFO, "\n");
    }
#endif
}


INT32 APACHE_TEST_FUNC_CUTMode(void)
{
    INT32 ret = NC_SUCCESS;
    
    APACHE_TEST_FUNC_ConvVirToPhy();

    APACHE_TEST_FUNC_MakeASM();

    APACHE_TEST_FUNC_BitSeparation();

    return ret;
}


/* End Of File */

