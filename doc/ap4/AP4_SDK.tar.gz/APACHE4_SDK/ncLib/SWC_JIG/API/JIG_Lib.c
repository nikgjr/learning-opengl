/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "JIG_Svc.h"










/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

// MISRA_C_2014_Rule 17.1 : The features of <stdarg.h> shall not be used 
#define __JIG_SIMPLE_PRINTF__

#ifdef __JIG_SIMPLE_PRINTF__
    #define JIG_PAD_RIGHT       1
    #define JIG_PAD_ZERO        2
    /* the following should be enough for 32 bit int */
    #define JIG_PRINT_BUF_LEN   12
#endif










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL     gbJIGOpen = FALSE;
volatile eUART_CH gJigPort  = MAX_OF_UART_CH;










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

#ifdef __JIG_SIMPLE_PRINTF__
static void ncLib_JIG_Printc(INT32 c)
{
    if(c == '\n')
      ncLib_UART_Ctrl_PutChar(gJigPort, '\r');  
    ncLib_UART_Ctrl_PutChar(gJigPort, c);
}

static INT32 ncLib_JIG_Prints(const CHAR *string, INT32 width, INT32 pad)
{
    INT32 pc = 0, padchar = ' ';

    if (width > 0) 
    {
        INT32 len = 0;
        const CHAR *ptr;
        for (ptr = string; *ptr; ++ptr) 
            ++len;
        
        if (len >= width) 
            width = 0;
        else 
            width -= len;
        
        if (pad & JIG_PAD_ZERO) 
            padchar = '0';
    }
    
    if (!(pad & JIG_PAD_RIGHT)) 
    {
        for ( ; width > 0; --width) 
        {
            ncLib_JIG_Printc (padchar);
            ++pc;
        }
    }
    
    for ( ; *string ; ++string)
    {
        ncLib_JIG_Printc (*string);
        ++pc;
    }
    
    for ( ; width > 0; --width) 
    {
        ncLib_JIG_Printc (padchar);
        ++pc;
    }

    return pc;
}


static int ncLib_JIG_Printi(INT32 i, INT32 b, INT32 sg, INT32 width, INT32 pad, INT32 letbase)
{
    CHAR print_buf[JIG_PRINT_BUF_LEN];
    CHAR *s;
    INT32 t, neg = 0, pc = 0;
    UINT32 u = i;

    if(i == 0) 
    {
        print_buf[0] = '0';
        print_buf[1] = '\0';

        return ncLib_JIG_Prints (print_buf, width, pad);
    }

    if(sg && b == 10 && i < 0) 
    {
        neg = 1;
        u = -i;
    }

    s = print_buf + JIG_PRINT_BUF_LEN-1;
    *s = '\0';

    while(u) 
    {
        t = u % b;
        if( t >= 10 )
            t += letbase - '0' - 10;
        *--s = t + '0';
        u /= b;
    }

    if(neg) 
    {
        if( width && (pad & JIG_PAD_ZERO) ) 
        {
            ncLib_JIG_Printc ('-');
            ++pc;
            --width;
        }
        else 
        {
            *--s = '-';
        }
    }

    return pc + ncLib_JIG_Prints (s, width, pad);
}


static INT32 ncLib_JIG_vsPrintf(INT32 *varg)
{
    INT32 width, pad;
    INT32 pc = 0;
    CHAR *format = (CHAR *)(*varg++);
    CHAR scr[2];

    for(; *format != 0; ++format) 
    {
        if(*format == '%') 
        {
            ++format;
            width = pad = 0;
            if(*format == '\0') 
                break;
            
            if( *format == '%' ) 
            {
                ncLib_JIG_Printc (*format);
                ++pc;
                continue;
            }
            
            if( *format == '-' ) 
            {
                ++format;
                pad = JIG_PAD_RIGHT;
            }
            
            while( *format == '0' ) 
            {
                ++format;
                pad |= JIG_PAD_ZERO;
            }
            
            for( ; *format >= '0' && *format <= '9'; ++format) 
            {
                width *= 10;
                width += *format - '0';
            }
            
            if( *format == 's' ) 
            {
                CHAR *s = *((CHAR **)varg++);
                pc += ncLib_JIG_Prints (s?s:"(null)", width, pad);
                continue;
            }
            
            if( *format == 'd' ) 
            {
                pc += ncLib_JIG_Printi (*varg++, 10, 1, width, pad, 'a');
                continue;
            }
            
            if( *format == 'x' ) 
            {
                pc += ncLib_JIG_Printi (*varg++, 16, 0, width, pad, 'a');
                continue;
            }
            
            if( *format == 'X' ) 
            {
                pc += ncLib_JIG_Printi (*varg++, 16, 0, width, pad, 'A');
                continue;
            }
            
            if( *format == 'u' ) 
            {
                pc += ncLib_JIG_Printi (*varg++, 10, 0, width, pad, 'a');
                continue;
            }
            
            if( *format == 'c' ) 
            {
                /* char are converted to int then pushed on the stack */
                scr[0] = *varg++;
                scr[1] = '\0';
                pc += ncLib_JIG_Prints (scr, width, pad);
                continue;
            }
        }
        else
        {
            ncLib_JIG_Printc (*format);
            ++pc;
        }
    }
    
    return pc;
}
#endif


INT32 ncLib_JIG_Open(void)
{
    INT32 Ret = NC_SUCCESS;

    gbJIGOpen = TRUE;

    return Ret;
}


INT32 ncLib_JIG_Close(void)
{
    INT32 Ret = NC_SUCCESS;

    gbJIGOpen = FALSE;
        
    return Ret;
}


INT32 ncLib_JIG_Write(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_JIG_Read(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


#if 0 // MISRA_C_2014_Rule 17.1
INT32 ncLib_JIG_Control(eJIG_CMD Cmd,  ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    
    if(gbJIGOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case GCMD_JIG_INIT:
                {
                    tUART_PARAM tUARTParam;

                    gJigPort = (eUART_CH)ArgData[0];

                    tUARTParam.mIntEn    = ENABLE;
                    tUARTParam.mBaudRate = (UINT32)ArgData[1];
                    tUARTParam.mSPS      = UT_SPS_DIS;
                    tUARTParam.mLEN      = UT_DATA_8BIT;
                    tUARTParam.mSTP      = UT_STOP_1BIT;
                    tUARTParam.mEPS      = UT_EPS_DIS;
                    tUARTParam.mPEN      = UT_PARITY_DIS;
                    tUARTParam.mBRK      = UT_BRK_DIS;

                    ncLib_UART_Ctrl_Init(gJigPort, &tUARTParam);

                    // Register UART Interrupt Handler
                    ncLib_INTC_Ctrl_RegisterHandler((UINT32)(IRQ_NUM_UART0+gJigPort), (PrHandler)ncSvc_JIG_IRQ_Handler);

                    ncSvc_JIG_Init();
                }
                break;

                case GCMD_JIG_DEINIT:
                {
                    ncLib_UART_Ctrl_DeInit(gJigPort);

                    ncSvc_JIG_DeInit();
                }
                break;

                case GCMD_JIG_DO_COMMAND:
                    Ret = ncSvc_JIG_CommandMain();
                break;

                default:
                    Ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}
#else
INT32 ncLib_JIG_Ctrl_Init(eUART_CH Ch, eUART_BAUDRATE BaudRate)
{
    INT32 Ret = NC_FAILURE;
    tUART_PARAM tUARTParam;
    
    if((gbJIGOpen == TRUE) && (gJigPort == MAX_OF_UART_CH))
    {
        // Default Value
        tUARTParam.mIntEn    = ENABLE;
        tUARTParam.mSPS      = UT_SPS_DIS;
        tUARTParam.mLEN      = UT_DATA_8BIT;
        tUARTParam.mSTP      = UT_STOP_1BIT;
        tUARTParam.mEPS      = UT_EPS_DIS;
        tUARTParam.mPEN      = UT_PARITY_DIS;
        tUARTParam.mBRK      = UT_BRK_DIS;
        
        tUARTParam.mBaudRate = BaudRate;
        Ret = ncLib_UART_Ctrl_Init(Ch, &tUARTParam);

        if(Ret == NC_SUCCESS)
        {
            // Register UART Interrupt Handler
            Ret = ncLib_INTC_Ctrl_RegisterHandler((UINT32)(IRQ_NUM_UART0+Ch), (PrHandler)ncSvc_JIG_IRQ_Handler);

            ncSvc_JIG_Init();

            if(Ret == NC_SUCCESS)
            {
                gJigPort = Ch;
            }
        }
    }

    return Ret;
}


INT32 ncLib_JIG_Ctrl_DeInit(void)
{
    INT32 Ret = NC_FAILURE;
    
    if(gbJIGOpen == TRUE)
    {
        Ret = ncLib_UART_Ctrl_DeInit(gJigPort);
        ncSvc_JIG_DeInit();
    }

    return Ret;
}


INT32 ncLib_JIG_Ctrl_RunCommand(void)
{
    INT32 Ret = NC_FAILURE;
    
    if(gbJIGOpen == TRUE)
    {
        Ret = ncSvc_JIG_CommandMain();
    }

    return Ret;
}
#endif


void ncLib_JIG_Printf(const char *fmt, ...)
{
#ifdef __JIG_SIMPLE_PRINTF__    
    INT32 *varg = (INT32 *)(&fmt);

    ncLib_JIG_vsPrintf(varg);
#else
    va_list vList;
    char Buff[512];

    va_start(vList, fmt);

    vsnprintf(Buff, sizeof(Buff), fmt, vList);

    va_end(vList);

    ncLib_UART_Ctrl_PutStr(gJigPort, Buff);
#endif
}


/* End Of File */

