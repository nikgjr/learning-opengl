/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "sFlash_Svc.h"










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbSFOpen = FALSE;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

INT32 ncLib_SF_Open(void)
{
    INT32 Ret = NC_SUCCESS;

    gbSFOpen = TRUE;

    return Ret;
}


INT32 ncLib_SF_Close(void)
{
    INT32 Ret = NC_SUCCESS;

    gbSFOpen = FALSE;

    return Ret;
}


INT32 ncLib_SF_Read(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    INT32 Ret = NC_SUCCESS;

    Ret = ncSvc_SF_ReadData(Addr, pData, Size);
    
    return Ret;
}


INT32 ncLib_SF_Write(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    INT32 Ret = NC_SUCCESS;

    Ret = ncSvc_SF_WriteData(Addr, pData, Size);

    return Ret;
}


#if 0 // MISRA_C_2014_Rule 17.1
INT32 ncLib_SF_Control(eSF_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;


    if(gbSFOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, SF no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */
            switch(Cmd)
            {
                case GCMD_SF_INIT:
                    Ret = ncSvc_SF_Init((ptSF_PARAM)ArgData[0]);
                break;

                case GCMD_SF_DEINIT:
                    Ret = ncSvc_SF_DeInit();
                break;

                case GCMD_SF_SET_BITRATE:
                    ncSvc_SF_SetBitRate((UINT32) ArgData[0]);
                break;

                case GCMD_SF_BLOCK_ERASE:
                    Ret = ncSvc_SF_BlockErase( ArgData[0] );
                break;

                case GCMD_SF_SECTOR_ERASE:
                    Ret = ncSvc_SF_SectorErase( ArgData[0] );
                break;

                case GCMD_SF_READ_ID:
                    Ret = ncSvc_SF_ReadDeviceIdentification( (tSFLASH_ID *) ArgData[0]);
                break;

                case GCMD_SF_READ_STATUS:
                    Ret = ncSvc_SF_ReadStatus();
                break;

                case GCMD_SF_WRTIE_STATUS:
                    ncSvc_SF_WriteStatus(ArgData[0]);
                break;

                case GCMD_SF_READ_STATUS2:
                    Ret = ncSvc_SF_ReadStatus2();
                break;

                case GCMD_SF_WRITE_STATUS2:
                    ncSvc_SF_WriteStatus2(ArgData[0], ArgData[1]);
                break;

                case GCMD_SF_WAIT_WIP:
                    ncSvc_SF_WaitWIP();
                break;

                case GCMD_SF_WRITE_EN:
                    ncSvc_SF_WriteEnable();
                break;

                case GCMD_SF_WRITE_DS:
                    ncSvc_SF_WriteDisable();
                break;

                case GCMD_SF_ENABLE_WP:
                    ncSvc_SF_EnableWP(ArgData[0]);
                break;

                case SCMD_SF_OSG_READ_EN:
                    Ret = ncSvc_SF_QSPIReadDirectOSG(TRUE); 
                break;   

                case SCMD_SF_OSG_READ_DS:
                    Ret = ncSvc_SF_QSPIReadDirectOSG(FALSE); 
                break;

                case SCMD_SF_OSG_READ_DATA:
                    Ret = ncSvc_SF_QSPIReadAPBOSG(ArgData[0], ArgData[1], ArgData[2]);
                break;
                
                case SCMD_SF_LUT_READ_DATA:
                    Ret = ncSvc_SF_QSPIReadLUT(ArgData[0], (UINT8 *)ArgData[1], ArgData[2]);
                break;
                
                case SCMD_SF_GET_PAD_CTRL:
                    ncSvc_SF_GetPadCtrl();
                break;

                case SCMD_SF_FREE_PAD_CTRL:
                    ncSvc_SF_FreePadCtrl();
                break;  
        
                default :
                {
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support SF command\n");
                    Ret = NC_FAILURE;
                }
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}
#else
INT32 ncLib_SF_Ctrl_Init(ptSF_PARAM ptSFParam)
{
    INT32 Ret = NC_FAILURE;

    if((gbSFOpen == TRUE) && (ptSFParam != NULL))
    {
        Ret = ncSvc_SF_Init((ptSF_PARAM)ptSFParam);
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_DeInit(void)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        Ret = ncSvc_SF_DeInit();
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_SetBitRate(UINT32 Bitrate)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        ncSvc_SF_SetBitRate(Bitrate);
        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_BlockErase(UINT32 PageAddr)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        Ret = ncSvc_SF_BlockErase(PageAddr);
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_SectorErase(UINT32 PageAddr)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        Ret = ncSvc_SF_SectorErase(PageAddr);
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_ReadID(ptSFLASH_ID ptsFlashID)
{
    INT32 Ret = NC_FAILURE;

    if((gbSFOpen == TRUE) && (ptsFlashID != NULL))
    {
        Ret = ncSvc_SF_ReadDeviceIdentification(ptsFlashID);
    }

    return Ret;
}


UINT8 ncLib_SF_Ctrl_ReadStatus(void)
{
    UINT8 Ret = NC_SUCCESS;

    if(gbSFOpen == TRUE)
    {
        Ret = ncSvc_SF_ReadStatus();
    }

    return Ret;
}


UINT8 ncLib_SF_Ctrl_ReadStatus2(void)
{
    INT32 Ret = NC_SUCCESS;

    if(gbSFOpen == TRUE)
    {
        Ret = ncSvc_SF_ReadStatus2();;
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_WriteStatus(UINT8 Status)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        ncSvc_SF_WriteStatus(Status);
        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_WriteStatus2(UINT8 Status1, UINT8 Status2)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        ncSvc_SF_WriteStatus2(Status1, Status2);
        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_WaitWIP(void)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        ncSvc_SF_WaitWIP();
        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_WriteEnable(void)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        ncSvc_SF_WriteEnable();
        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_WriteDisable(void)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        ncSvc_SF_WriteDisable();
        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_EnableWP(BOOL OnOff)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        ncSvc_SF_EnableWP(OnOff);
        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_OSGReadEnable(void)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        Ret = ncSvc_SF_QSPIReadDirectOSG(TRUE);
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_OSGReadDisable(void)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        Ret = ncSvc_SF_QSPIReadDirectOSG(FALSE);
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_OSGReadData(UINT32 Addr, UINT32 BuffAddr, UINT32 Size)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        Ret = ncSvc_SF_QSPIReadAPBOSG(Addr, BuffAddr, Size);
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_LUTReadData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        Ret = ncSvc_SF_QSPIReadLUT(Addr, (UINT8 *)pData, Size);
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_GetPad(void)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        Ret = ncSvc_SF_GetPadCtrl();
    }

    return Ret;
}


INT32 ncLib_SF_Ctrl_FreePad(void)
{
    INT32 Ret = NC_FAILURE;

    if(gbSFOpen == TRUE)
    {
        Ret = ncSvc_SF_FreePadCtrl();
    }

    return Ret;
}
#endif

/* End Of File */

