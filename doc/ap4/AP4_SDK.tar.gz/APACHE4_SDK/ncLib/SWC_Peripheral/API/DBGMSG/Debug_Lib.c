/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"










/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define __DEBUG_ERROR_BOLD__

// MISRA_C_2014_Rule 17.1 : The features of <stdarg.h> shall not be used 
#define __DEBUG_SIMPLE_PRINTF__

#ifdef __DEBUG_SIMPLE_PRINTF__
    #define DEBUG_PAD_RIGHT       1
    #define DEBUG_PAD_ZERO        2
    /* the following should be enough for 32 bit int */
    #define DEBUG_PRINT_BUF_LEN   12
#endif










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL     gbDebugOpen = FALSE;
volatile UINT32   gDebugZone  = 0;
volatile eUART_CH gDebugPort  = MAX_OF_UART_CH;










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

#ifdef __DEBUG_SIMPLE_PRINTF__
static void ncLib_DEBUG_Printc(INT32 c)
{
    if(c == '\n')
      ncLib_UART_Ctrl_PutChar(gDebugPort, '\r');  
    ncLib_UART_Ctrl_PutChar(gDebugPort, c);
}

static INT32 ncLib_DEBUG_Prints(const CHAR *string, INT32 width, INT32 pad)
{
    INT32 pc = 0, padchar = ' ';

    if (width > 0) 
    {
        INT32 len = 0;
        const CHAR *ptr;
        for (ptr = string; *ptr; ++ptr) 
            ++len;
        
        if (len >= width) 
            width = 0;
        else 
            width -= len;
        
        if (pad & DEBUG_PAD_ZERO) 
            padchar = '0';
    }
    
    if (!(pad & DEBUG_PAD_RIGHT)) 
    {
        for ( ; width > 0; --width) 
        {
            ncLib_DEBUG_Printc (padchar);
            ++pc;
        }
    }
    
    for ( ; *string ; ++string)
    {
        ncLib_DEBUG_Printc (*string);
        ++pc;
    }
    
    for ( ; width > 0; --width) 
    {
        ncLib_DEBUG_Printc (padchar);
        ++pc;
    }

    return pc;
}


static int ncLib_DEBUG_Printi(INT32 i, INT32 b, INT32 sg, INT32 width, INT32 pad, INT32 letbase)
{
    CHAR print_buf[DEBUG_PRINT_BUF_LEN];
    CHAR *s;
    INT32 t, neg = 0, pc = 0;
    UINT32 u = i;

    if(i == 0) 
    {
        print_buf[0] = '0';
        print_buf[1] = '\0';

        return ncLib_DEBUG_Prints (print_buf, width, pad);
    }

    if(sg && b == 10 && i < 0) 
    {
        neg = 1;
        u = -i;
    }

    s = print_buf + DEBUG_PRINT_BUF_LEN-1;
    *s = '\0';

    while(u) 
    {
        t = u % b;
        if( t >= 10 )
            t += letbase - '0' - 10;
        *--s = t + '0';
        u /= b;
    }

    if(neg) 
    {
        if( width && (pad & DEBUG_PAD_ZERO) ) 
        {
            ncLib_DEBUG_Printc ('-');
            ++pc;
            --width;
        }
        else 
        {
            *--s = '-';
        }
    }

    return pc + ncLib_DEBUG_Prints (s, width, pad);
}


static INT32 ncLib_DEBUG_vsPrintf(INT32 *varg)
{
    INT32 width, pad;
    INT32 pc = 0;
    CHAR *format = (CHAR *)(*varg++);
    CHAR scr[2];

    for(; *format != 0; ++format) 
    {
        if(*format == '%') 
        {
            ++format;
            width = pad = 0;
            if(*format == '\0') 
                break;
            
            if( *format == '%' ) 
            {
                ncLib_DEBUG_Printc (*format);
                ++pc;
                continue;
            }
            
            if( *format == '-' ) 
            {
                ++format;
                pad = DEBUG_PAD_RIGHT;
            }
            
            while( *format == '0' ) 
            {
                ++format;
                pad |= DEBUG_PAD_ZERO;
            }
            
            for( ; *format >= '0' && *format <= '9'; ++format) 
            {
                width *= 10;
                width += *format - '0';
            }
            
            if( *format == 's' ) 
            {
                CHAR *s = *((CHAR **)varg++);
                pc += ncLib_DEBUG_Prints (s?s:"(null)", width, pad);
                continue;
            }
            
            if( *format == 'd' ) 
            {
                pc += ncLib_DEBUG_Printi (*varg++, 10, 1, width, pad, 'a');
                continue;
            }
            
            if( *format == 'x' ) 
            {
                pc += ncLib_DEBUG_Printi (*varg++, 16, 0, width, pad, 'a');
                continue;
            }
            
            if( *format == 'X' ) 
            {
                pc += ncLib_DEBUG_Printi (*varg++, 16, 0, width, pad, 'A');
                continue;
            }
            
            if( *format == 'u' ) 
            {
                pc += ncLib_DEBUG_Printi (*varg++, 10, 0, width, pad, 'a');
                continue;
            }
            
            if( *format == 'c' ) 
            {
                /* char are converted to int then pushed on the stack */
                scr[0] = *varg++;
                scr[1] = '\0';
                pc += ncLib_DEBUG_Prints (scr, width, pad);
                continue;
            }
        }
        else
        {
            ncLib_DEBUG_Printc (*format);
            ++pc;
        }
    }
    
    return pc;
}
#endif


INT32 ncLib_DEBUG_Open(void)
{
    INT32 Ret = NC_SUCCESS;

    if(gbDebugOpen == FALSE)
    {
        ncLib_UART_Open();
        
        gbDebugOpen = TRUE;
        gDebugZone = 0;
    }

    return Ret;
}


INT32 ncLib_DEBUG_Close(void)
{
    INT32 Ret = NC_SUCCESS;

    gbDebugOpen = FALSE;
    gDebugZone = 0;
        
    return Ret;
}


INT32 ncLib_DEBUG_Read(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_DEBUG_Write(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


#if 0 // MISRA_C_2014_Rule 17.1
INT32 ncLib_DEBUG_Control(eDBG_CMD Cmd,  ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;


    if(gbDebugOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case GCMD_DBG_INIT:
                {
                    tUART_PARAM tUARTParam;
                    
                    gDebugPort = (eUART_CH)ArgData[0];
                    tUARTParam.mIntEn    = DISABLE;
                    tUARTParam.mBaudRate = (UINT32)ArgData[1];
                    tUARTParam.mSPS      = UT_SPS_DIS;
                    tUARTParam.mLEN      = UT_DATA_8BIT;
                    tUARTParam.mSTP      = UT_STOP_1BIT;
                    tUARTParam.mEPS      = UT_EPS_DIS;
                    tUARTParam.mPEN      = UT_PARITY_DIS;
                    tUARTParam.mBRK      = UT_BRK_DIS;

                    ncLib_UART_Ctrl_Init(gDebugPort, &tUARTParam);
                }
                break;

                case GCMD_DBG_DEINIT:
                    ncLib_UART_Ctrl_DeInit(gDebugPort);
                break;

                case GCMD_DBG_APP_LOG_ZONE:
                case GCMD_DBG_SDK_LOG_ZONE:
                {
                    UINT32 Zone   = ArgData[0];
                    UINT32 Enable = ArgData[1];

                    if(Cmd == GCMD_DBG_SDK_LOG_ZONE)
                        Zone <<= MSGPOS;

                    if(Enable == ON)
                        gDebugZone |= Zone;
                    else
                        gDebugZone &= ~Zone;
                }
                break;

                default:
                    Ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}
#else
INT32 ncLib_DEBUG_Ctrl_Init(eUART_CH Ch, eUART_BAUDRATE BaudRate)
{
    INT32 Ret = NC_FAILURE;
    tUART_PARAM tUARTParam;
    
    if((gbDebugOpen == TRUE) && (gDebugPort == MAX_OF_UART_CH))
    {
        // Default Value
        tUARTParam.mIntEn    = DISABLE;
        tUARTParam.mSPS      = UT_SPS_DIS;
        tUARTParam.mLEN      = UT_DATA_8BIT;
        tUARTParam.mSTP      = UT_STOP_1BIT;
        tUARTParam.mEPS      = UT_EPS_DIS;
        tUARTParam.mPEN      = UT_PARITY_DIS;
        tUARTParam.mBRK      = UT_BRK_DIS;
        
        tUARTParam.mBaudRate = BaudRate;
        Ret = ncLib_UART_Ctrl_Init(Ch, &tUARTParam);

        if(Ret == NC_SUCCESS)
        {
            gDebugPort = Ch;
        }
    }

    return Ret;
}


INT32 ncLib_DEBUG_Ctrl_DeInit(void)
{
    INT32 Ret = NC_FAILURE;
    
    if(gbDebugOpen == TRUE)
    {
        Ret = ncLib_UART_Ctrl_DeInit(gDebugPort);
        if(Ret == NC_SUCCESS)
        {
            gDebugPort = MAX_OF_UART_CH;
        }
    }

    return Ret;
}


INT32 ncLib_DEBUG_Ctrl_SetAppZone(UINT32 Zone, UINT32 Enable)
{
    INT32 Ret = NC_FAILURE;
    
    if((gbDebugOpen == TRUE) && (gDebugPort < MAX_OF_UART_CH))
    {
        if(Enable == ON)
            gDebugZone |= Zone;
        else
            gDebugZone &= ~Zone;

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_DEBUG_Ctrl_SetSdkZone(UINT32 Zone, UINT32 Enable)
{
    INT32 Ret = NC_FAILURE;
    
    if((gbDebugOpen == TRUE) && (gDebugPort < MAX_OF_UART_CH))
    {
        Zone <<= MSGPOS;

        if(Enable == ON)
            gDebugZone |= Zone;
        else
            gDebugZone &= ~Zone;

        Ret = NC_SUCCESS;
    }

    return Ret;
}
#endif


void ncLib_DEBUG_Printf(UINT32 DebugZone, const char *fmt, ...)
{
#ifdef __DEBUG_SIMPLE_PRINTF__    
    INT32 *varg = (INT32 *)(&fmt);
#else
    va_list vList;
    char Buff[512];
#endif

    if(gbDebugOpen == TRUE)
    {
        if(DebugZone & gDebugZone)
        {
            #ifdef __DEBUG_ERROR_BOLD__
                if(DebugZone&MSGERR)
                    ncLib_UART_Ctrl_PutStr(gDebugPort, STR_COLOR_RED_ON);
            
                if(DebugZone&(MSGERR<<MSGPOS))
                    ncLib_UART_Ctrl_PutStr(gDebugPort, STR_COLOR_RED_ON);
                
                if(DebugZone&(MSGWARN<<MSGPOS))
                    ncLib_UART_Ctrl_PutStr(gDebugPort, STR_COLOR_YELLOW_ON);   
            #endif


            //--------------------------------------------------------------------
            #ifdef __DEBUG_SIMPLE_PRINTF__
                ncLib_DEBUG_vsPrintf(varg);
            #else
                va_start(vList, fmt);
            vsnprintf(Buff, sizeof(Buff), fmt, vList);
            va_end(vList);

            ncLib_UART_Ctrl_PutStr(gDebugPort, Buff);
            #endif
            //--------------------------------------------------------------------



            #ifdef __DEBUG_ERROR_BOLD__
                if( (DebugZone&MSGERR) || (DebugZone&(MSGERR<<MSGPOS)) || (DebugZone&(MSGWARN<<MSGPOS)) )
                    ncLib_UART_Ctrl_PutStr(gDebugPort, STR_COLOR_OFF);
            #endif
        }
    }
}


UINT32 ncLib_DEBUG_Scanf(char *buf)
{
    char *cp;
    INT8 data;
    UINT32 count = 0;

    if(gbDebugOpen == TRUE)
    {
        cp = buf;

        do
        {
            data = ncLib_UART_Ctrl_GetChar(gDebugPort);

            switch(data)
            {
                case ESCAPE_KEY:
                {
                    UINT32 func_key_step = 1;
                    
                    while(1)
                    {
                        data = ncLib_UART_Ctrl_GetChar(gDebugPort);

                        if(data != NC_FAILURE)
                        {
                            // Enter Key [0x1B.0x4F.0x4D]
                            if( (func_key_step == 1) && (data == 'O') )
                            {
                                func_key_step = 2;
                            }
                            else if((func_key_step == 2) && (data == 'M'))
                            {
                                *cp = '\0';
                                ncLib_UART_Ctrl_PutChar(gDebugPort, '\n');
                                
                                data = RETURN_KEY;
                                break;
                            }
                            else
                            {
                                break;
                            }
                        }
                    };
                }
                break;
                
                case RETURN_KEY:
                {
                    if(count < 256)
                    {
                        *cp = '\0';
                        ncLib_UART_Ctrl_PutChar(gDebugPort, '\n');
                    }
                }
                break;

                case BACKSP_KEY:
                case DELETE_KEY:
                {
                    if(count)
                    {
                        count--;
                        *(--cp) = '\0';
                        ncLib_UART_Ctrl_PutStr(gDebugPort, "\b \b");
                    }
                }
                break;

                default:
                {
//                  if(data > 0x1F && data < 0x7F && count < 256)
                    if(data > 0x1F && data < 0x7F && count < 255) // jsw modified 18.07.12
                    {
                        *cp = (char)data;
                        cp++;
                        count++;

                        ncLib_UART_Ctrl_PutChar(gDebugPort, data);
                    }
                }
                break;
            }
        }
        while(data != RETURN_KEY);
    }

    return count;
}


/* End Of File */

