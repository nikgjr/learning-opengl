/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "GPIO_Drv.h"










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbGPIOOpen = FALSE;

volatile ePAD_FUNC gaPadFunc_org[PAD_MAX];










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static ePAD_ID __gpio_to_pad(eGPIO_GROUP Group, eGPIO_PORT Port)
{
    return (ePAD_ID)((Group*MAX_OF_GPIO_PORT)+Port);
}


static void __pad_to_gpio(ePAD_ID Pad_Id, eGPIO_GROUP* Group, eGPIO_PORT* Port)
{
    *Group = (eGPIO_GROUP)(Pad_Id/MAX_OF_GPIO_PORT);
    *Port  = (eGPIO_PORT) (Pad_Id%MAX_OF_GPIO_PORT);
}


INT32 ncLib_GPIO_Open(void)
{
    INT32 Ret = NC_SUCCESS;
    UINT32 i;
    
    if(gbGPIOOpen == FALSE)
    {
        gbGPIOOpen = TRUE;
        
        for(i=0; i<PAD_MAX; i++)
            gaPadFunc_org[i]= PAD_FUNC_MAX;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_GPIO_Close(void)
{
    INT32 Ret = NC_SUCCESS;

    if(gbGPIOOpen == TRUE)
    {
        gbGPIOOpen = FALSE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_GPIO_Read(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_GPIO_Write(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


#if 0 // MISRA_C_2014_Rule 17.1
INT32 ncLib_GPIO_Control(eGPIO_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    ePAD_ID Pad_Id;
    UINT32  Group;
    UINT32  Port;
    

    if(gbGPIOOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, GPIO no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */
            switch(Cmd)
            {
                case GCMD_GPIO_ENA:
                {
                    switch(ArgData[0])
                    {
                        case GPIO_GROUP_A:
                        case GPIO_GROUP_B:
                        case GPIO_GROUP_C:
                        { 
                            // GPIO to PAD_ID
                            Pad_Id = __gpio_to_pad((UINT32)ArgData[0], (UINT32)ArgData[1]);

                            // Backup Before Pad Func
                            gaPadFunc_org[Pad_Id] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, Pad_Id, CMD_END);

                            // Set GPIO Mode
                            ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, Pad_Id, PAD_FUNC_4, CMD_END);
                        }
                        break;
                        
                        case GPIO_GROUP_D:
                        {
                            // Only GPIO Port (PIMMUX is unnecessary)
                        }
                        break;

                        case GPIO_GROUP_PAD:
                        {
                            // PAD_ID
                            Pad_Id = (ePAD_ID)ArgData[1];

                            // Backup Before Pad Func
                            gaPadFunc_org[Pad_Id] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, Pad_Id, CMD_END);

                            // Set GPIO Mode
                            ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, Pad_Id, PAD_FUNC_4, CMD_END);
                        }
                    } 
                }
                break;

                case GCMD_GPIO_DIS:
                {
                     switch(ArgData[0])
                    {
                        case GPIO_GROUP_A:
                        case GPIO_GROUP_B:
                        case GPIO_GROUP_C:
                        {  
                            // GPIO Input Mode
                            ncDrv_GPIO_SetDirection((eGPIO_GROUP)ArgData[0], (eGPIO_PORT)ArgData[1], GPIO_DIR_IN);

                            // GPIO to PAD_ID
                            Pad_Id = __gpio_to_pad((UINT32)ArgData[0], (UINT32)ArgData[1]);

                            // Roll-Back Pad Func
                            if(gaPadFunc_org[Pad_Id] != PAD_FUNC_MAX)
                                ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, Pad_Id,  gaPadFunc_org[Pad_Id], CMD_END);
                            else
                                ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, Pad_Id,  PAD_FUNC_0, CMD_END);  
                        }
                        break;
                        
                        case GPIO_GROUP_D:
                        {
                            // Only GPIO Port (PIMMUX is unnecessary)
                        }
                        break;

                        case GPIO_GROUP_PAD:
                        {
                            // GPIO Input Mode
                            __pad_to_gpio((UINT32)ArgData[1], &Group, &Port);
                            ncDrv_GPIO_SetDirection((eGPIO_GROUP)Group, (eGPIO_PORT)Port, GPIO_DIR_IN);

                            // Roll-Back Pad Func
                            Pad_Id = (ePAD_ID)ArgData[1];
                            if(gaPadFunc_org[Pad_Id] != PAD_FUNC_MAX)
                                ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, Pad_Id,  gaPadFunc_org[Pad_Id], CMD_END);
                            else
                                ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, Pad_Id,  PAD_FUNC_0, CMD_END);  
                        }
                    } 
                }
                break;

                case GCMD_GPIO_SET_DIR:
                {
                    if(ArgData[0] == GPIO_GROUP_PAD)
                    {
                        // PAD_ID to GPIO
                        __pad_to_gpio((UINT32)ArgData[1], &Group, &Port);
                        ncDrv_GPIO_SetDirection((eGPIO_GROUP)Group, (eGPIO_PORT)Port, (eGPIO_DIR)ArgData[2]);
                    }
                    else
                    {
                        ncDrv_GPIO_SetDirection((eGPIO_GROUP)ArgData[0], (eGPIO_PORT)ArgData[1], (eGPIO_DIR)ArgData[2]);
                    }
                }
                break;

                case GCMD_GPIO_SET_DATA:
                {
                    if(ArgData[0] == GPIO_GROUP_PAD)
                    {
                        // PAD_ID to GPIO
                        __pad_to_gpio((UINT32)ArgData[1], &Group, &Port);
                        ncDrv_GPIO_SetData((eGPIO_GROUP)Group, (eGPIO_PORT)Port, (eGPIO_DATA)ArgData[2]);
                    }
                    else
                    {
                        ncDrv_GPIO_SetData((eGPIO_GROUP)ArgData[0], (eGPIO_PORT)ArgData[1], (eGPIO_DATA)ArgData[2]);
                    }
                }
                break;

                case GCMD_GPIO_GET_DATA:
                {
                    if(ArgData[0] == GPIO_GROUP_PAD)
                    {
                        // PAD_ID to GPIO
                        __pad_to_gpio((UINT32)ArgData[1], &Group, &Port);
                        Ret = ncDrv_GPIO_GetData((eGPIO_GROUP)Group, (eGPIO_PORT)Port);
                    }
                    else
                    {
                        Ret = ncDrv_GPIO_GetData((eGPIO_GROUP)ArgData[0], (eGPIO_PORT)ArgData[1]);
                    }
                }
                break;

                case GCMD_GPIO_SET_INTC:
                {
                    if(ArgData[0] == GPIO_GROUP_PAD)
                    {
                        // PAD_ID to GPIO
                        __pad_to_gpio((UINT32)ArgData[1], &Group, &Port);
                        ncDrv_GPIO_SetIntc((eGPIO_GROUP)Group, (eGPIO_PORT)Port, (eGPIO_INT_CH)ArgData[2], (eGPIO_TRIG)ArgData[3], (BOOL)ArgData[4]);
                    }
                    else
                    {
                        ncDrv_GPIO_SetIntc((eGPIO_GROUP)ArgData[0], (eGPIO_PORT)ArgData[1], (eGPIO_INT_CH)ArgData[2], (eGPIO_TRIG)ArgData[3], (BOOL)ArgData[4]);
                    }
                }
                break;
                
                default :
                {
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support GPIO command\n");
                    Ret = NC_FAILURE;
                }
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}
#else
INT32 ncLib_GPIO_Ctrl_EnablePort(eGPIO_GROUP Group, eGPIO_PORT Port)
{
    INT32 Ret = NC_FAILURE;
    ePAD_ID Pad_Id;
    
    if(gbGPIOOpen == TRUE)
    {
        switch(Group)
        {
            case GPIO_GROUP_A:
            case GPIO_GROUP_B:
            case GPIO_GROUP_C:
            { 
                // GPIO to PAD_ID
                Pad_Id = __gpio_to_pad(Group, Port);

                // Backup Before Pad Func
                gaPadFunc_org[Pad_Id] = (ePAD_FUNC)ncLib_SCU_Ctrl_GetPinMux(Pad_Id);

                // Set GPIO Mode
                ncLib_SCU_Ctrl_SetPinMux(Pad_Id, PAD_FUNC_4);
            }
            break;
            
            case GPIO_GROUP_D:
            {
                // Only GPIO Port (PIMMUX is unnecessary)
            }
            break;
        } 

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_GPIO_Ctrl_DisablePort(eGPIO_GROUP Group, eGPIO_PORT Port)
{
    INT32 Ret = NC_FAILURE;
    ePAD_ID Pad_Id;
    
    if(gbGPIOOpen == TRUE)
    {
        switch(Group)
        {
            case GPIO_GROUP_A:
            case GPIO_GROUP_B:
            case GPIO_GROUP_C:
            { 
                // GPIO Input Mode
                ncDrv_GPIO_SetDirection(Group, Port, GPIO_DIR_IN);

                // GPIO to PAD_ID
                Pad_Id = __gpio_to_pad(Group, Port);

                // Roll-Back Pad Func
                if(gaPadFunc_org[Pad_Id] != PAD_FUNC_MAX)
                    ncLib_SCU_Ctrl_SetPinMux(Pad_Id,  gaPadFunc_org[Pad_Id]);
                else
                    ncLib_SCU_Ctrl_SetPinMux(Pad_Id,  PAD_FUNC_0);  
            }
            break;
            
            case GPIO_GROUP_D:
            {
                // Only GPIO Port (PIMMUX is unnecessary)
            }
            break;
        } 

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_GPIO_Ctrl_SetDirectionPort(eGPIO_GROUP Group, eGPIO_PORT Port, eGPIO_DIR Dir)
{
    INT32 Ret = NC_FAILURE;
    
    if(gbGPIOOpen == TRUE)
    {
        ncDrv_GPIO_SetDirection(Group, Port, Dir);
 
        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_GPIO_Ctrl_SetDataPort(eGPIO_GROUP Group, eGPIO_PORT Port, eGPIO_DATA Level)
{
    INT32 Ret = NC_FAILURE;
    
    if(gbGPIOOpen == TRUE)
    {
        ncDrv_GPIO_SetData(Group, Port, Level);
 
        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_GPIO_Ctrl_GetDataPort(eGPIO_GROUP Group, eGPIO_PORT Port)
{
    INT32 Ret = NC_FAILURE;
    
    if(gbGPIOOpen == TRUE)
    {
        Ret = ncDrv_GPIO_GetData(Group, Port);
    }

    return Ret;
}


INT32 ncLib_GPIO_Ctrl_SetIntcPort(eGPIO_GROUP Group, eGPIO_PORT Port, eGPIO_INT_CH IntCh, eGPIO_TRIG TrigMode, BOOL OnOff)
{
    INT32 Ret = NC_FAILURE;
    
    if(gbGPIOOpen == TRUE)
    {
        ncDrv_GPIO_SetIntc(Group, Port, IntCh, TrigMode, OnOff);
        
        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_GPIO_Ctrl_EnablePad(ePAD_ID Pad_Id)
{
    INT32 Ret = NC_FAILURE;
    
    if(gbGPIOOpen == TRUE)
    {
        // Backup Before Pad Func
        gaPadFunc_org[Pad_Id] = (ePAD_FUNC)ncLib_SCU_Ctrl_GetPinMux(Pad_Id);

        // Set GPIO Mode
        ncLib_SCU_Ctrl_SetPinMux(Pad_Id, PAD_FUNC_4);

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_GPIO_Ctrl_DisablePad(ePAD_ID Pad_Id)
{
    INT32 Ret = NC_FAILURE;
    eGPIO_GROUP Group;
    eGPIO_PORT  Port;
    
    if(gbGPIOOpen == TRUE)
    {
        // GPIO Input Mode
        __pad_to_gpio(Pad_Id, &Group, &Port);
        ncDrv_GPIO_SetDirection(Group, Port, GPIO_DIR_IN);

        // Roll-Back Pad Func
        if(gaPadFunc_org[Pad_Id] != PAD_FUNC_MAX)
            ncLib_SCU_Ctrl_SetPinMux(Pad_Id,  gaPadFunc_org[Pad_Id]);
        else
            ncLib_SCU_Ctrl_SetPinMux(Pad_Id,  PAD_FUNC_0);  

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_GPIO_Ctrl_SetDirectionPad(ePAD_ID Pad_Id, eGPIO_DIR Dir)
{
    INT32 Ret = NC_FAILURE;
    eGPIO_GROUP Group;
    eGPIO_PORT  Port;
    
    if(gbGPIOOpen == TRUE)
    {
        __pad_to_gpio(Pad_Id, &Group, &Port);
        ncDrv_GPIO_SetDirection(Group, Port, Dir);

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_GPIO_Ctrl_SetDataPad(ePAD_ID Pad_Id, eGPIO_DATA Level)
{
    INT32 Ret = NC_FAILURE;
    eGPIO_GROUP Group;
    eGPIO_PORT  Port;
    
    if(gbGPIOOpen == TRUE)
    {
        __pad_to_gpio(Pad_Id, &Group, &Port);
        ncDrv_GPIO_SetData(Group, Port, Level);

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_GPIO_Ctrl_GetDataPad(ePAD_ID Pad_Id)
{
    INT32 Ret = NC_FAILURE;
    eGPIO_GROUP Group;
    eGPIO_PORT  Port;
    
    if(gbGPIOOpen == TRUE)
    {
        __pad_to_gpio(Pad_Id, &Group, &Port);        
        Ret = ncDrv_GPIO_GetData(Group, Port);
    }

    return Ret;
}


INT32 ncLib_GPIO_Ctrl_SetIntcPad(ePAD_ID Pad_Id, eGPIO_INT_CH IntCh, eGPIO_TRIG TrigMode, BOOL OnOff)
{
    INT32 Ret = NC_FAILURE;
    eGPIO_GROUP Group;
    eGPIO_PORT  Port;
    
    if(gbGPIOOpen == TRUE)
    {
        __pad_to_gpio(Pad_Id, &Group, &Port);    
        ncDrv_GPIO_SetIntc(Group, Port, IntCh, TrigMode, OnOff);
        
        Ret = NC_SUCCESS;
    }

    return Ret;
}
#endif


/* End Of File */

