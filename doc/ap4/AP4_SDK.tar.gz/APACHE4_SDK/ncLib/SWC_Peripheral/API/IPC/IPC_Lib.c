/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "IPC_Drv.h"










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbIPCOpen = FALSE;

volatile BOOL gbIPC_CH[MAX_OF_IPC_CH];










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void ncLib_IPC_InfoInit(eIPC_CH Ch)
{
    gbIPC_CH[Ch] = ON;
}


static void ncLib_IPC_InfoDeInit(eIPC_CH Ch)
{
    gbIPC_CH[Ch] = OFF;  
}


static INT32 ncLib_IPC_IsNotAliveCh(void)
{
    INT32 Ret = NC_SUCCESS;
    eIPC_CH Ch;
    
    for(Ch=IPC_CH0; Ch<MAX_OF_IPC_CH; Ch++)
    {
        if(gbIPC_CH[Ch] == ON)
            Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_IPC_Open(void)
{
    INT32 Ret = NC_SUCCESS;
    eIPC_CH Ch;
    
    if(gbIPCOpen == FALSE)
    {
        ncLib_SCU_Ctrl_EnableClock(IP_IPC); 
        //ncLib_SCU_Ctrl_ResetIP(IP_IPC); 
        
        for(Ch=IPC_CH0; Ch<MAX_OF_IPC_CH; Ch++)
            ncLib_IPC_InfoDeInit(Ch);
        
        gbIPCOpen = TRUE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_IPC_Close(void)
{
    INT32 Ret;

    Ret = ncLib_IPC_IsNotAliveCh();
    if(Ret == NC_SUCCESS)
    {
        ncLib_SCU_Ctrl_DisableClock(IP_IPC); 
        
        gbIPCOpen = FALSE;
    }

    return Ret;
}


INT32 ncLib_IPC_Read(eIPC_CH Ch, eFIFO_ID Id, UINT32* Data)
{
    INT32 Ret = NC_FAILURE;

    if((Ch < MAX_OF_IPC_CH) && (Id < MAX_OF_FIFO_ID))
    {
    Ret = ncDrv_IPC_GetFIFO(Ch, Id, Data);
    }

    return Ret;
}


INT32 ncLib_IPC_Write(eIPC_CH Ch, eFIFO_ID Id, UINT32 Data)
{
    INT32 Ret = NC_FAILURE;

    if((Ch < MAX_OF_IPC_CH) && (Id < MAX_OF_FIFO_ID))
    {
    Ret = ncDrv_IPC_SetFIFO(Ch, Id, Data);
    }

    return Ret;
}


#if 0 // MISRA_C_2014_Rule 17.1
INT32 ncLib_IPC_Control(eIPC_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    eIPC_CH Ch;
    

    if(gbIPCOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, IPC no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Defence Code
            */
            
            Ch = (eIPC_CH)ArgData[0];
            if(Ch >= MAX_OF_IPC_CH) 
                Cmd = GCMD_IPC_MAX;

            
            /*
            * Implement Control Command Function
            */
            
            switch(Cmd)
            {
                case GCMD_IPC_INIT:
                {
                    ncLib_IPC_InfoInit(Ch);
                    ncDrv_IPC_Init(Ch, (UINT8*)ArgData[1]);
                }
                break;

                case GCMD_IPC_DEINIT:
                {
                    ncDrv_IPC_DeInit(Ch);
                    ncLib_IPC_InfoDeInit(Ch);
                }
                break;

                case GCMD_IPC_GET_CNT:
                {
                    Ret = ncDrv_IPC_GetFIFOCnt(Ch, (eFIFO_ID)ArgData[1]);
                }
                break;

                case GCMD_IPC_GET_INT_STS:
                {
                    Ret = ncDrv_IPC_GetStatus(Ch);
                }
                break;

                case GCMD_IPC_CLR_INT_STS:
                {
                    ncDrv_IPC_IntClear(Ch);
                }
                break;
                
                default :
                {
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support IPC command\n");
                    Ret = NC_FAILURE;
                }
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}
#else
INT32 ncLib_IPC_Ctrl_Init(eIPC_CH Ch, UINT8* pThreshold)
{
    INT32 Ret = NC_FAILURE;

    if((gbIPCOpen == TRUE) && (Ch < MAX_OF_IPC_CH))
    {
        if(gbIPC_CH[Ch] == OFF)
        {
            ncLib_IPC_InfoInit(Ch);
            ncDrv_IPC_Init(Ch, pThreshold);

            Ret = NC_SUCCESS;
        }
    }

    return Ret;
}


INT32 ncLib_IPC_Ctrl_DeInit(eIPC_CH Ch)
{
    INT32 Ret = NC_FAILURE;

    if((gbIPCOpen == TRUE) && (Ch < MAX_OF_IPC_CH))
    {
        if(gbIPC_CH[Ch] == ON)
        {
            ncDrv_IPC_DeInit(Ch);
            ncLib_IPC_InfoDeInit(Ch);

            Ret = NC_SUCCESS;
        }
    }

    return Ret;
}


INT32 ncLib_IPC_Ctrl_GetFIFOCount(eIPC_CH Ch, eFIFO_ID Id)
{
    INT32 Ret = NC_FAILURE;

    if((gbIPCOpen == TRUE) && (Ch < MAX_OF_IPC_CH) && (Id < MAX_OF_FIFO_ID))
    {
        if(1) //gbIPC_CH[Ch] == ON)
        {
            Ret = ncDrv_IPC_GetFIFOCnt(Ch, Id);
        }
    }

    return Ret;
}


INT32 ncLib_IPC_Ctrl_GetIntcStatus(eIPC_CH Ch)
{
    INT32 Ret = NC_FAILURE;

    if((gbIPCOpen == TRUE) && (Ch < MAX_OF_IPC_CH))
    {
        if(gbIPC_CH[Ch] == ON)
        {
            Ret = ncDrv_IPC_GetStatus(Ch);
        }
    }

    return Ret;
}


INT32 ncLib_IPC_Ctrl_SetIntcClear(eIPC_CH Ch)
{
    INT32 Ret = NC_FAILURE;

    if((gbIPCOpen == TRUE) && (Ch < MAX_OF_IPC_CH))
    {
        if(gbIPC_CH[Ch] == ON)
        {
            ncDrv_IPC_IntClear(Ch);

            Ret = NC_SUCCESS;
        }
    }

    return Ret;
}
#endif


/* End Of File */

