/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SysTime_Lib.c
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "SysTime_Svc.h"










/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

BOOL gbSysTimeOpen = FALSE;










/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncLib_SYSTIME_Open(void)
{
    UINT32 ApbClock;
    INT32 ret = NC_SUCCESS;

    /*
    * Check System Timer is Opened
    */
    if(gbSysTimeOpen == TRUE)
    {
        ret = NC_FAILURE;
        //DEBUGMSG_SDK(MSGERR, "%s\n",LOG_ERR_ALREADY_OPEN);
    }
    else
    {
        gbSysTimeOpen = TRUE;

        ApbClock = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_APB, CMD_END);

        ncSvc_SYSTIME_Init(ApbClock);
    }

    return ret;
}


INT32 ncLib_SYSTIME_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbSysTimeOpen == TRUE)
    {
        gbSysTimeOpen = FALSE;
    }
    else
    {
        //DEBUGMSG_SDK(MSGERR, "%s\n", "[SYSTIME_CLOSE] This Module is not Opened");
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_SYSTEM_Read(void)
{
    INT32 ret = NC_SUCCESS;

    //DEBUGMSG_SDK(MSGERR, "%s\n", LOG_ERR_NOT_SUPPORT_FUN);

    return ret;
}


INT32 ncLib_SYSTEM_Write(void)
{
    INT32 ret = NC_SUCCESS;

    //DEBUGMSG_SDK(MSGERR, "%s\n", LOG_ERR_NOT_SUPPORT_FUN);

    return ret;
}


INT32 ncLib_SYSTIME_Control(eSYSTIME_CMD Cmd, ...)
{
    UINT32 	    count;
    UINT32 	    argData[CMD_MAX];
    va_list     vlist;
    BOOL        bEndCmd = FALSE;
    INT32       ret = NC_SUCCESS;


    if(gbSysTimeOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */
        va_start(vlist, Cmd);
        for(count = 0; count < CMD_MAX; count++)
        {
            argData[count] = va_arg(vlist, UINT32);
            if(argData[count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }
        va_end(vlist);

        if(bEndCmd == FALSE)
        {
            //DEBUGMSG_SDK(MSGERR, "%s\n", LOG_ERR_NO_CMD_END);
            ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */
            switch(Cmd)
            {
                case GCMD_ST_MDELAY:
                {
                    UINT32 msec = argData[0];

                    if(msec < 5000)
                    {
                        ncSvc_SYSTIME_mDelay(msec);
                    }
                    else
                    {
                        ret = NC_FAILURE;
                    }
                }
                break;

                default:
                break;
            }
        }
    }
    else
    {
        ret = NC_FAILURE;
        //DEBUGMSG_SDK(MSGERR, "%s\n", "[SYSTIME_CTRL] This Module is not Opened");
    }

    return ret;
}


/* End Of File */

