/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "QSPI_Drv.h"










/*
********************************************************************************
*               TYPEDEFS                                    
********************************************************************************
*/

typedef struct
{
    tPAD_INFO CS0;
    tPAD_INFO CS1;
    tPAD_INFO DQ0;
    tPAD_INFO DQ1;        
    tPAD_INFO DQ2;
    tPAD_INFO DQ3;    
    tPAD_INFO SCK;    
} tQSPI_PAD, *ptQSPI_PAD;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbQSPIOpen = FALSE;

tQSPI_PAD gtQSPI_PAD = 
{
    {PAD_SPI2_CSN0, {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_SPI2_CSN1, {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_SPI2_DQ0,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_SPI2_DQ1,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_SPI2_DQ2,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_SPI2_DQ3,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_SPI2_SCK,  {PAD_FUNC_1, PAD_FUNC_MAX}}
};










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __qspi_get_padctrl(ptPAD_INFO Pad)
{
    if(Pad->mFunc[1] == PAD_FUNC_MAX)
        Pad->mFunc[1] = (ePAD_FUNC)ncLib_SCU_Ctrl_GetPinMux(Pad->mId);
    ncLib_SCU_Ctrl_SetPinMux(Pad->mId, Pad->mFunc[0]);
}


static void __qspi_free_padctrl(ptPAD_INFO Pad)
{
    if(Pad->mFunc[1] != PAD_FUNC_MAX)
    {
        ncLib_SCU_Ctrl_SetPinMux(Pad->mId, Pad->mFunc[1]);
        Pad->mFunc[1] = PAD_FUNC_MAX;
    }
}


static void ncLib_QSPI_PinMuxCtrlGet(void)
{
    //-----------------------------------------------------------------------------------------------------    
    __qspi_get_padctrl(&gtQSPI_PAD.CS0);
    __qspi_get_padctrl(&gtQSPI_PAD.CS1);
    __qspi_get_padctrl(&gtQSPI_PAD.DQ0);    
    __qspi_get_padctrl(&gtQSPI_PAD.DQ1);
    __qspi_get_padctrl(&gtQSPI_PAD.DQ2);
    __qspi_get_padctrl(&gtQSPI_PAD.DQ3);
    __qspi_get_padctrl(&gtQSPI_PAD.SCK);



    //-----------------------------------------------------------------------------------------------------  
    // CSN : GPIO Ctrl Mode
    if(gtQSPI_PAD.CS0.mFunc[0] == PAD_FUNC_4)
    {
        ncLib_GPIO_Ctrl_SetDirectionPad(gtQSPI_PAD.CS0.mId, GPIO_DIR_OUT);
        //ncLib_GPIO_Ctrl_SetDataPad(gtQSPI_PAD.CS0.mId, GPIO_HIGH);
    }
    
    if(gtQSPI_PAD.CS1.mFunc[0] == PAD_FUNC_4)
    {
        ncLib_GPIO_Ctrl_SetDirectionPad(gtQSPI_PAD.CS1.mId, GPIO_DIR_OUT);
        //ncLib_GPIO_Ctrl_SetDataPad(gtQSPI_PAD.CS1.mId, GPIO_HIGH);        
    }
    


    //-----------------------------------------------------------------------------------------------------  
    // Ctrl Chip Select PIN
    if( 0 ) // if((ncLib_SCU_Ctrl_GetStrapInfo() >> 2) & 0x01)
    {
        if(gtQSPI_PAD.CS1.mFunc[0] == PAD_FUNC_4)
            ncLib_GPIO_Ctrl_SetDataPad(gtQSPI_PAD.CS1.mId, GPIO_LOW);
        else
            ncDrv_QSPI_IsExternalMemory(TRUE);
    }
    else
    {
        if(gtQSPI_PAD.CS0.mFunc[0] == PAD_FUNC_4)
            ncLib_GPIO_Ctrl_SetDataPad(gtQSPI_PAD.CS0.mId, GPIO_LOW);
        else
            ncDrv_QSPI_IsExternalMemory(FALSE);  
    }
}


static void ncLib_QSPI_PinMuxCtrlFree(void)
{
    //-----------------------------------------------------------------------------------------------------
    // if ( Ctrl Chip Select PIN - GPIO)
    if( 0 ) // if((ncLib_SCU_Ctrl_GetStrapInfo() >> 2) & 0x01)
    {
        if(gtQSPI_PAD.CS1.mFunc[0] == PAD_FUNC_4)
            ncLib_GPIO_Ctrl_SetDataPad(gtQSPI_PAD.CS1.mId, GPIO_HIGH);
    }
    else
    {
        if(gtQSPI_PAD.CS0.mFunc[0] == PAD_FUNC_4)
            ncLib_GPIO_Ctrl_SetDataPad(gtQSPI_PAD.CS0.mId, GPIO_HIGH);
    }


    //------------------------------------------------------------------------------------------------------
    // Rollback PinMux
    __qspi_free_padctrl(&gtQSPI_PAD.CS0);
    __qspi_free_padctrl(&gtQSPI_PAD.CS1);
    __qspi_free_padctrl(&gtQSPI_PAD.DQ0);    
    __qspi_free_padctrl(&gtQSPI_PAD.DQ1);
    __qspi_free_padctrl(&gtQSPI_PAD.DQ2);
    __qspi_free_padctrl(&gtQSPI_PAD.DQ3);
    __qspi_free_padctrl(&gtQSPI_PAD.SCK);  
}


INT32 ncLib_QSPI_Open(void)
{
    INT32 Ret = NC_SUCCESS;

    if(gbQSPIOpen == FALSE)
    {
        ncLib_SCU_Ctrl_EnableClock(IP_QSPI);  
        gbQSPIOpen = TRUE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_QSPI_Close(void)
{
    INT32 Ret = NC_SUCCESS;
    
    if(gbQSPIOpen == TRUE)
    {
        ncLib_SCU_Ctrl_DisableClock(IP_QSPI);  
        gbQSPIOpen = FALSE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_QSPI_Read(UINT32 Addr, UINT8 *pBuff, UINT32 nLength)
{
    INT32 Ret = NC_FAILURE;

    if(gbQSPIOpen == TRUE)
    {
        // Set PIN MUX
        ncLib_QSPI_PinMuxCtrlGet();

        // Data Read
        Ret = ncDrv_QSPI_ReadData(ON, Addr, (UINT32)pBuff, nLength);

        // Free PIN MUX
        ncLib_QSPI_PinMuxCtrlFree();
    }

    return Ret;
}


INT32 ncLib_QSPI_Write(UINT32 Addr, UINT8 *pBuff, UINT32 nLength)
{
    INT32 Ret = NC_FAILURE;

    return Ret;
}


#if 0 // MISRA_C_2014_Rule 17.1
INT32 ncLib_QSPI_Control(eQSPI_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    UINT32  QSPI_Clk;
    
    if(gbQSPIOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, QSPI no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */
            switch(Cmd)
            {
                case GCMD_QSPI_INIT:
                {
                    ncLib_QSPI_PinMuxCtrlGet();
                    ncDrv_QSPI_Init();
                }
                break;


                case GCMD_QSPI_DEINIT:
                {
                    ncDrv_QSPI_DeInit();
                    ncLib_QSPI_PinMuxCtrlFree();
                }
                break;


                case GCMD_QSPI_SET_BITRATE:
                {
                    QSPI_Clk = ncLib_SCU_Control(GCMD_SCU_GET_CLK, IP_QSPI, CMD_END);
                    ncDrv_QSPI_SetBitRate((UINT32)ArgData[0], QSPI_Clk);
                }
                break;


                case GCMD_QSPI_LUT_READ:
                {
                    ncLib_QSPI_PinMuxCtrlGet();
                    Ret = ncDrv_QSPI_ReadData(OFF, ArgData[0], (UINT32)ArgData[1], ArgData[2]);
                    ncLib_QSPI_PinMuxCtrlFree();
                }
                break;


                case GCMD_QSPI_OSG_READ:
                {
                    Ret = ncDrv_QSPI_OSGReadData((eQSPI_OSG)ArgData[0], ArgData[1], ArgData[2], ArgData[3]);
                }
                break;
    
                default :
                {
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support QSPI command\n");
                    Ret = NC_FAILURE;
                }
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}
#else
INT32 ncLib_QSPI_Ctrl_Init(void)
{
    INT32 Ret = NC_FAILURE;

    if(gbQSPIOpen == TRUE)
    {
        ncLib_QSPI_PinMuxCtrlGet();
        ncDrv_QSPI_Init();

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_QSPI_Ctrl_DeInit(void)
{
    INT32 Ret = NC_FAILURE;

    if(gbQSPIOpen == TRUE)
    {
        ncDrv_QSPI_DeInit();
        ncLib_QSPI_PinMuxCtrlFree();

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_QSPI_Ctrl_SetBitRate(UINT32 Bitrate)
{
    INT32 Ret = NC_FAILURE;
    UINT32 QSPI_Clk;

    if(gbQSPIOpen == TRUE)
    {
        QSPI_Clk = ncLib_SCU_Ctrl_GetClock(IP_QSPI);
        ncDrv_QSPI_SetBitRate(Bitrate, QSPI_Clk);

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_QSPI_Ctrl_LUTRead(UINT32 Addr, UINT8 *pBuff, UINT32 Size)
{
    INT32 Ret = NC_FAILURE;

    if(gbQSPIOpen == TRUE)
    {
        ncLib_QSPI_PinMuxCtrlGet();
        Ret = ncDrv_QSPI_ReadData(OFF, Addr, (UINT32)pBuff, Size);
        ncLib_QSPI_PinMuxCtrlFree();
    }

    return Ret;
}


INT32 ncLib_QSPI_Ctrl_OSGRead(eQSPI_OSG DN_Mode, UINT32 Addr, UINT32 BuffAddr, UINT32 Size)
{
    INT32 Ret = NC_FAILURE;

    if(gbQSPIOpen == TRUE)
    {
        Ret = ncDrv_QSPI_OSGReadData(DN_Mode, Addr, BuffAddr, Size);
    }

    return Ret;
}
#endif


/* End Of File */

