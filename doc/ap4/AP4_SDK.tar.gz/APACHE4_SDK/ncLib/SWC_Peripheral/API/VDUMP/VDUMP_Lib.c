/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   : 
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "VDUMP_Drv.h"










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbVDPOpen = FALSE;
tVDP_INFO gtVDP;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static INT32 ncLib_VDP_InfoInit(ptVDP_PARAM ptVDPParam)
{
    INT32 Ret = NC_FAILURE;
    eVDP_CH Ch;
    
    if(ptVDPParam != NULL)
    {
        // Lib Init Check Flag
        gtVDP.mInit   = ON;

        // ISR On/Off Flag
        gtVDP.mIntEn  = ptVDPParam->mIntEn;

        // Interrupt Enable and Status Flag
        gtVDP.mIntSts   = 0;
        gtVDP.mDoneFlag = 0;

        // Channel Enable Flag
        gtVDP.mFrameSel = ptVDPParam->mFrameEdge;
        for(Ch = VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++)
            gtVDP.mChEn[Ch] = ptVDPParam->mDumpCh[Ch].mChEnable;
            
        Ret = NC_SUCCESS;
    }

    return Ret;
}


static void ncLib_VDP_InfoDeInit(void)
{
    gtVDP.mInit = OFF;
}


INT32 ncLib_VDP_Open(void)
{
    INT32 Ret = NC_SUCCESS;

    if(gbVDPOpen == FALSE)
    {
        ncLib_SCU_Ctrl_EnableClock(IP_VDUMP);  
        ncLib_SCU_Ctrl_ResetIP(IP_VDUMP); 

        ncLib_VDP_InfoDeInit();
        gbVDPOpen = TRUE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_VDP_Close(void)
{
    INT32 Ret = NC_SUCCESS;

    if(gbVDPOpen == TRUE)
    {
        ncLib_SCU_Ctrl_DisableClock(IP_VDUMP);  
        
        gbVDPOpen = FALSE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_VDP_Read(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_VDP_Write(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


#if 0 // MISRA_C_2014_Rule 17.1
INT32 ncLib_VDP_Control(eVDP_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;
    
    if(gbVDPOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Defence Code
            */
            
            if( ((Cmd != GCMD_VDP_INIT) && (gtVDP.mInit == OFF)) )
            {
                Cmd = GCMD_VDP_MAX; 
            }

            
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case GCMD_VDP_INIT:
                {
                    Ret = ncLib_VDP_InfoInit((ptVDP_PARAM)ArgData[0]);
                    if(Ret == NC_SUCCESS)
                    {
                        ncDrv_VDP_Initialize();
                        ncDrv_VDP_SetOperation(&gtVDP, (ptVDP_PARAM)ArgData[0]);
                    }
                }
                break;

                case GCMD_VDP_DEINIT:
                {
                    ncLib_VDP_InfoDeInit();
                    ncDrv_VDP_DeInitialize(); 
                }
                break;

                case GCMD_VDP_UPDATE_OP:
                {
                    Ret = ncLib_VDP_InfoInit((ptVDP_PARAM)ArgData[0]);
                    if(Ret == NC_SUCCESS)
                        ncDrv_VDP_SetOperation(&gtVDP, (ptVDP_PARAM)ArgData[0]);
                }
                break;

                case GCMD_VDP_START:
                {
                     Ret = ncDrv_VDP_Start(&gtVDP);
                }
                break;

                case GCMD_VDP_STOP:
                {
                     ncDrv_VDP_Stop();
                }
                break;

                case GCMD_VDP_DONE:
                {
                    Ret = ncDrv_VDP_CheckComplete(&gtVDP);
                }
                break;
                
                case GCMD_VDP_INT_CLEAR:
                {
                    Ret = ncDrv_VDP_IntStsClr(&gtVDP);
                }
                break;

                case GCMD_VDP_GET_STS:
                {
                    Ret = ncDrv_VDP_GetStatus(&gtVDP);
                }
                break;

                case GCMD_VDP_GET_INPUT_SIZE:
                {
                    *(UINT32*)ArgData[0] = (UINT32)gtVDP.mInHACT;
                    *(UINT32*)ArgData[1] = (UINT32)gtVDP.mInVACT;
                }
                break;
                
                case GCMD_VDP_GET_OUTPUT_SIZE:
                {
                    ncDrv_VDP_GetOutPutSize((UINT32*)ArgData[0], (UINT32*)ArgData[1]);
                }
                break;
                
                case GCMD_VDP_GET_DUMP_SIZE:
                {
                    Ret = ncDrv_VDP_GetOutPutDumpSize((eVDP_CH)ArgData[0]);
                }
                break;

                case GCMD_VDP_GET_CROP_CNT:
                {
                    ncDrv_VDP_GetCropCnt((UINT32*)ArgData[0], (UINT32*)ArgData[1]);
                }
                break;

                case GCMD_VDP_GET_SCAL_CNT:
                {
                    ncDrv_VDP_GetScalCnt((UINT32*)ArgData[0], (UINT32*)ArgData[1]);
                }
                break;

                case GCMD_VDP_GET_FRM_STS:
                {
                    Ret = ncDrv_VDP_GetOneFrameStatus((eVDP_CH)ArgData[0]);
                }
                break;

                case GCMD_VDP_GET_LINE_CNT:
                {
                    Ret = ncDrv_VDP_GetLineCnt((eVDP_CH)ArgData[0]);
                }
                break;

                case GCMD_VDP_GET_PIXEL_CNT:
                {
                    Ret = ncDrv_VDP_GetPixelCnt((eVDP_CH)ArgData[0]);
                }
                break;

                case GCMD_VDP_CHK_ERROR:
                {
                    Ret = ncDrv_VDP_GetOneFrameErrorStatus((eVDP_CH)ArgData[0]);
                }
                break;
                
                default :
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support VDUMP command\n");
                    Ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}
#else
INT32 ncLib_VDP_Ctrl_Init(ptVDP_PARAM ptVDPParam)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == OFF))
    {
        Ret = ncLib_VDP_InfoInit(ptVDPParam);
        if(Ret == NC_SUCCESS)
        {
            ncDrv_VDP_Initialize();
            ncDrv_VDP_SetOperation(&gtVDP, ptVDPParam);
        }
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_DeInit(void)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        ncLib_VDP_InfoDeInit();
        ncDrv_VDP_DeInitialize(); 

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_SetOpUpdate(ptVDP_PARAM ptVDPParam)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        Ret = ncLib_VDP_InfoInit(ptVDPParam);
        if(Ret == NC_SUCCESS)
        {
            ncDrv_VDP_SetOperation(&gtVDP, ptVDPParam);
        }
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_Start(void)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        Ret = ncDrv_VDP_Start(&gtVDP);
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_Stop(void)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        ncDrv_VDP_Stop();

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_CheckDone(void)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        Ret = ncDrv_VDP_CheckComplete(&gtVDP);
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_GetStatus(void)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        Ret = ncDrv_VDP_GetStatus(&gtVDP);
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_GetIntcStatus(void)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        Ret = ncDrv_VDP_IntStsClr(&gtVDP);
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_GetInputSize(UINT32* pInWidth, UINT32* pInHeigth)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        *pInWidth  = gtVDP.mInHACT;
        *pInHeigth = gtVDP.mInVACT;

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_GetOutputSize(UINT32* pOutWidth, UINT32* pOutHeigth)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        ncDrv_VDP_GetOutPutSize(pOutWidth, pOutHeigth);

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_GetDumpSize(eVDP_CH Ch)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        Ret = ncDrv_VDP_GetOutPutDumpSize(Ch);
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_GetCropCount(UINT32* V_CNT, UINT32* P_CNT)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        ncDrv_VDP_GetCropCnt(V_CNT, P_CNT);

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_GetScalCount(UINT32* V_CNT, UINT32* P_CNT)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        ncDrv_VDP_GetScalCnt(V_CNT, P_CNT);

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_GetFRMStatus(eVDP_CH Ch)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        Ret = ncDrv_VDP_GetOneFrameStatus(Ch);
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_GetLineCount(eVDP_CH Ch)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        Ret = ncDrv_VDP_GetLineCnt(Ch);
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_GetPixelCount(eVDP_CH Ch)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        Ret = ncDrv_VDP_GetPixelCnt(Ch);
    }

    return Ret;
}


INT32 ncLib_VDP_Ctrl_GetErrorStatus(eVDP_CH Ch)
{
    INT32 Ret = NC_FAILURE;

    if((gbVDPOpen == TRUE) && (gtVDP.mInit == ON))
    {
        Ret = ncDrv_VDP_GetOneFrameErrorStatus(Ch);
    }

    return Ret;
}
#endif


/* End Of File */

