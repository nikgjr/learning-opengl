/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "NAND_Drv.h"










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    tPAD_INFO DIR;      // In/Out Direction
    
    tPAD_INFO CE;       // Chip Enable
    
    tPAD_INFO WE;       // Write Enable
    tPAD_INFO RE;       // Read Enable  
    
    tPAD_INFO ALE;      // Address Latch Enable
    tPAD_INFO CLE;      // Command Latch Enable  
    
    tPAD_INFO WP;       // Write Protect
    tPAD_INFO RB;       // Read/Busy

    tPAD_INFO DQ0;      // Input and Output (I/Ox)      
    tPAD_INFO DQ1;          
    tPAD_INFO DQ2;
    tPAD_INFO DQ3;
    tPAD_INFO DQ4;
    tPAD_INFO DQ5;          
    tPAD_INFO DQ6;
    tPAD_INFO DQ7;
} tFMC_PAD, *ptFMC_PAD;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbNANDOpen = FALSE;


tFMC_PAD gtFMC_PAD = 
{
    {PAD_UART2_TX, {PAD_FUNC_2, PAD_FUNC_MAX}},
    
    {PAD_FMC_CEN,  {PAD_FUNC_1, PAD_FUNC_MAX}},
        
    {PAD_FMC_WEN,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_FMC_REN,  {PAD_FUNC_1, PAD_FUNC_MAX}},
        
    {PAD_FMC_ALE,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_FMC_CLE,  {PAD_FUNC_1, PAD_FUNC_MAX}}, 
        
    {PAD_FMC_WPN,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_FMC_RBN,  {PAD_FUNC_1, PAD_FUNC_MAX}},   

    {PAD_FMC_DQ0,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_FMC_DQ1,  {PAD_FUNC_1, PAD_FUNC_MAX}},     
    {PAD_FMC_DQ2,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_FMC_DQ3,  {PAD_FUNC_1, PAD_FUNC_MAX}},   
    {PAD_FMC_DQ4,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_FMC_DQ5,  {PAD_FUNC_1, PAD_FUNC_MAX}},     
    {PAD_FMC_DQ6,  {PAD_FUNC_1, PAD_FUNC_MAX}},
    {PAD_FMC_DQ7,  {PAD_FUNC_1, PAD_FUNC_MAX}}
};










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/


static void __fmc_get_padctrl(ptPAD_INFO Pad)
{
    if(Pad->mFunc[1] == PAD_FUNC_MAX)
        Pad->mFunc[1] = (ePAD_FUNC)ncLib_SCU_Ctrl_GetPinMux(Pad->mId);
    ncLib_SCU_Ctrl_SetPinMux(Pad->mId, Pad->mFunc[0]);
}


static void __fmc_free_padctrl(ptPAD_INFO Pad)
{
    if(Pad->mFunc[1] != PAD_FUNC_MAX)
    {
        ncLib_SCU_Ctrl_SetPinMux(Pad->mId, Pad->mFunc[1]);
        Pad->mFunc[1] = PAD_FUNC_MAX;
    }
}


static void ncLib_FMC_PinMuxCtrlGet(void)
{
    __fmc_get_padctrl(&(gtFMC_PAD.DIR));
    
    __fmc_get_padctrl(&(gtFMC_PAD.CE));
    __fmc_get_padctrl(&(gtFMC_PAD.WE)); 
    __fmc_get_padctrl(&(gtFMC_PAD.RE));
    __fmc_get_padctrl(&(gtFMC_PAD.ALE));     
    __fmc_get_padctrl(&(gtFMC_PAD.CLE)); 
    __fmc_get_padctrl(&(gtFMC_PAD.WP));     
    __fmc_get_padctrl(&(gtFMC_PAD.RB)); 
    __fmc_get_padctrl(&(gtFMC_PAD.DQ0));     
    __fmc_get_padctrl(&(gtFMC_PAD.DQ1));  
    __fmc_get_padctrl(&(gtFMC_PAD.DQ2));     
    __fmc_get_padctrl(&(gtFMC_PAD.DQ3));  
    __fmc_get_padctrl(&(gtFMC_PAD.DQ4));     
    __fmc_get_padctrl(&(gtFMC_PAD.DQ5));  
    __fmc_get_padctrl(&(gtFMC_PAD.DQ6));     
    __fmc_get_padctrl(&(gtFMC_PAD.DQ7));  
}


static void ncLib_FMC_PinMuxCtrlFree(void)
{
    __fmc_free_padctrl(&(gtFMC_PAD.DIR)); 
    
    __fmc_free_padctrl(&(gtFMC_PAD.CE));
    __fmc_free_padctrl(&(gtFMC_PAD.WE)); 
    __fmc_free_padctrl(&(gtFMC_PAD.RE));
    __fmc_free_padctrl(&(gtFMC_PAD.ALE));     
    __fmc_free_padctrl(&(gtFMC_PAD.CLE)); 
    __fmc_free_padctrl(&(gtFMC_PAD.WP));     
    __fmc_free_padctrl(&(gtFMC_PAD.RB)); 
    __fmc_free_padctrl(&(gtFMC_PAD.DQ0));     
    __fmc_free_padctrl(&(gtFMC_PAD.DQ1));  
    __fmc_free_padctrl(&(gtFMC_PAD.DQ2));     
    __fmc_free_padctrl(&(gtFMC_PAD.DQ3));  
    __fmc_free_padctrl(&(gtFMC_PAD.DQ4));     
    __fmc_free_padctrl(&(gtFMC_PAD.DQ5));  
    __fmc_free_padctrl(&(gtFMC_PAD.DQ6));     
    __fmc_free_padctrl(&(gtFMC_PAD.DQ7));  
}


INT32 ncLib_NAND_Open(void)
{
    INT32 ret = NC_SUCCESS;
    
    if(gbNANDOpen == FALSE)
    {
        ncLib_FMC_PinMuxCtrlGet();
        gbNANDOpen = TRUE;
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_NAND_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbNANDOpen == TRUE)
    {
        ncLib_FMC_PinMuxCtrlFree();
        gbNANDOpen = FALSE;
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_NAND_Read(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_NAND_Write(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


#if 0 // MISRA_C_2014_Rule 17.1
INT32 ncLib_NAND_Control(eNAND_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    

    if(gbNANDOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, NAND no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */
            switch(Cmd)
            {
                case GCMD_NAND_INIT:
                {

                }
                break;

                case GCMD_NAND_DEINIT:
                {

                }
                break;

                default :
                {
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support NAND command\n");
                    Ret = NC_FAILURE;
                }
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}
#else
INT32 ncLib_NAND_Ctrl_Init(void)
{
    INT32 Ret = NC_FAILURE;

    if(gbNANDOpen == TRUE)
    {
        // TODO
        
        Ret = NC_SUCCESS;
    }

    return Ret;
}

INT32 ncLib_NAND_Ctrl_DeInit(void)
{
    INT32 Ret = NC_FAILURE;

    if(gbNANDOpen == TRUE)
    {
        // TODO
        
        Ret = NC_SUCCESS;
    }

    return Ret;
}
#endif


/* End Of File */

