/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __PWM_DRV_H__
#define __PWM_DRV_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define rPWM_BASE                   (APACHE_PWM_BASE)
#define rPWM_ADDR(ch)               (APACHE_PWM_BASE + (ch*0x10))


//------------------------------------------------------------------------------   
#define	rPWM_CFG                    0x00        // RxTx : Line Status Register  
                                                //        - [31:10] : Reserved     
    #define bPWM_CFG_SLEV           (1<<9)      //        -     [9] : Start Value(High or Low), when PWM Enable            
    #define bPWM_CFG_OP             (1<<8)      //        -     [8] : 0.OneShort, 1.AutoLoad   
    #define bPWM_CFG_SCAL_MASK      (0xF0)      //        -   [7:4] : Scal Value, Period = 1/(Scale+1)   
    #define bPWM_CFG_SCAL           (4)         //     
    #define bPWM_CFG_ILEV           (1<<3)      //        -     [3] : Initial Value(High or Low), when PWM Disable                      
    #define bPWM_CFG_OUT            (1<<2)      //        -     [2] : Enable Output                 
    #define bPWM_CFG_IEN            (1<<1)      //        -     [1] : Enable Interrupt                   
    #define bPWM_CFG_EN             (1<<0)      //        -     [0] : Enable Opeartion


//------------------------------------------------------------------------------       
#define rPWM_CNTPA                  0x04        // RxTx : Count value for Phase_A
#define rPWM_CNTPO                  0x08        // RxTx : Count value for Phase_0
#define rPWM_CCNT                   0x0C        // Rx   : Current count value of PWM  
                                                //-------------------------------
                                                //       Phase_0
                                                //      <------->
                                                //
                                                //      |-------|      |----
                                                //      |       |      |
                                                //      |       |      | 
                                                //  -----       --------
                                                //
                                                //      <-------------->
                                                //          Phase_A
                                                //--------------------------------


//------------------------------------------------------------------------------   
#define rPWM_SCALE                  0x40        // RxTx : Global Scale Register
                                                //        - [31:16] : Reserved  
                                                //        - [15:00] : Global pre-scale value
                                                //                    PWM Clock = Ref_Clock/(g_scale+1)


//------------------------------------------------------------------------------   
#define rPWM_START                  0x44        //   Tx : PWM Channel Start Register    
                                                //        - [31:04] : Reserved  
    #define bPWM_START_CH3          (1<<3)      //        -     [3] : Start PWM Channe-3                     
    #define bPWM_START_CH2          (1<<2)      //        -     [2] : Start PWM Channe-2           
    #define bPWM_START_CH1          (1<<1)      //        -     [1] : Start PWM Channe-1               
    #define bPWM_START_CH0          (1<<0)      //        -     [0] : Start PWM Channe-0


//------------------------------------------------------------------------------       
#define rPWM_INT_STS                0x48        // RxTx : PWM Interrupt Status Register    
#define rPWM_INT_CLR                0x48        // RxTx : PWM Interrupt Clear Register    
                                                //        - [31:04] : Reserved  
    #define bPWM_INT_CH3            (1<3)       //        -     [3] : Interrupt occurred Channel-3                     
    #define bPWM_INT_CH2            (1<2)       //        -     [2] : Interrupt occurred Channel-2           
    #define bPWM_INT_CH1            (1<1)       //        -     [1] : Interrupt occurred Channel-1               
    #define bPWM_INT_CH0            (1<0)       //        -     [0] : Interrupt occurred Channel-0










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern UINT32 ncDrv_PWM_GetScal(ePWM_CH Ch);
extern INT32  ncDrv_PWM_SetFrequency(ePWM_CH Ch, UINT32 Freq, UINT32 Duty, UINT32 Scal, UINT32 RefClk);

extern INT32 ncDrv_PWM_GetStatus(ePWM_CH Ch);
extern void  ncDrv_PWM_Stop(ePWM_CH Ch);
extern void  ncDrv_PWM_Start(ePWM_CH Ch);

extern void  ncDrv_PWM_DeInit(ePWM_CH Ch);
extern INT32 ncDrv_PWM_Init(ePWM_CH Ch, ptPWM_PARAM ptPWM, UINT32 RefClk);

extern void  ncDrv_PWM_DeInitialize(void);
extern INT32 ncDrv_PWM_Initialize(UINT32 PreScale);


#endif  /* __PWM_DRV_H__ */


/* End Of File */

