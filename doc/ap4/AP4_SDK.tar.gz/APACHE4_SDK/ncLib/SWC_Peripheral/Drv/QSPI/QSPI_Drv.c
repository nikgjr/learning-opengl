/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "QSPI_Drv.h"










/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define QSPI_TIMEOUT_MAX            (1000)     // 1-sec










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static BOOL ncDrv_QSPI_TimeOut(UINT32 mSec)
{
    BOOL Ret = FALSE;       
    static volatile UINT32 sQSPI_TimeOutMsec = 0;  

    if(mSec > 0)
    {
        if(sQSPI_TimeOutMsec == 0)
        {
            // Set TimeOut : SystemTick(msec) + TargetMsec;
            sQSPI_TimeOutMsec = nc_get_msec(1) + mSec;
        }
        else
        {
            // Timeout Check. 
            if(nc_get_msec(0) > sQSPI_TimeOutMsec)
            {
                Ret = TRUE;
                sQSPI_TimeOutMsec = 0;
            }
        }
    }
    else
    {
        sQSPI_TimeOutMsec = 0;
    }
    
    return Ret;
}


static BOOL ncDrv_QSPI_WaitFIFOSts(UINT32 Offset)
{
    BOOL Ret = FALSE;
    UINT32 TimeOut = QSPI_TIMEOUT_MAX;
    UINT32 Status;


    while(1)
    {
        Status = REGRW32(APACHE_QSPI_BASE, rQSPI_SIGSTS);
        if( Status & bQSPI_STS_FULL )
        {
            Ret = TRUE;
            break;
        }

        if( Status & bQSPI_STS_END )
        {
            break;
        }

        if(ncDrv_QSPI_TimeOut(TimeOut))
        {
            DEBUGMSG_SDK(MSGERR, "[QSPI_Drv] Error, FIFO Time Out(%dms) - Sts(0x%08x), Offset(0x%08x)\n" , TimeOut, REGRW32(APACHE_QSPI_BASE, rQSPI_SIGSTS), Offset);
            break;
        }
    }
    ncDrv_QSPI_TimeOut(0);
    
    return Ret;
}


static BOOL ncDrv_QSPI_WaitBusIsBusy(void)
{
    BOOL Ret = TRUE;
    UINT32 TimeOut = QSPI_TIMEOUT_MAX;

    
    while(REGRW32(APACHE_QSPI_BASE, rQSPI_STS) & bQSPI_BUSY)
    {
        if(ncDrv_QSPI_TimeOut(TimeOut))
        {
            DEBUGMSG_SDK(MSGERR, "[QSPI_Drv] Error, Busy Time Out(%dms)\n", TimeOut);
            Ret = FALSE;
            break;
        }
    }
    ncDrv_QSPI_TimeOut(0);

    return Ret;
}


static BOOL ncDrv_QSPI_WaitFrameDone(void)
{
    BOOL Ret = TRUE;
    UINT32 TimeOut = QSPI_TIMEOUT_MAX;

    
    while(!(REGRW32(APACHE_QSPI_BASE, rQSPI_STS) & bQSPI_MIFDONE))
    {
        if(ncDrv_QSPI_TimeOut(TimeOut))
        {
            DEBUGMSG_SDK(MSGERR, "[QSPI_Drv] Error, Done Time Out(%dms)\n", TimeOut);
            Ret = FALSE;
            break;
        }
    }
    ncDrv_QSPI_TimeOut(0);
    
    return Ret;
}


static void ncDrv_QSPI_IntClear(void)
{
    UINT32 Reg;

    // Get Intc Status
    Reg = REGRW32(APACHE_QSPI_BASE, rQSPI_INT_STS);
    
    // Clear Intc Status
    REGRW32(APACHE_QSPI_BASE, rQSPI_INT_CLR) = Reg;
}


static void ncDrv_QSPI_IntDisable(void)
{
    // 0: Intc Mask, 1: Intc Un-Mask
    REGRW32(APACHE_QSPI_BASE, rQSPI_INT_MASK) = 0;
}


void ncDrv_QSPI_IsExternalMemory(UINT8 IsExternal)
{
    //----------------------------------------------
    // if( rQSPI_START_ADDR < rQSPI_EXT_ADDR)
    //    ChipSelect = CSN0   
    // else if( rQSPI_START_ADDR >= rQSPI_EXT_ADDR)
    //    ChipSelect = CSN1
    //----------------------------------------------
    
    if(IsExternal == TRUE)
        REGRW32(APACHE_QSPI_BASE, rQSPI_EXT_ADDR) = 0x00; 
    else
        REGRW32(APACHE_QSPI_BASE, rQSPI_EXT_ADDR) = 0xFFFFFF;
}


INT32 ncDrv_QSPI_SetBitRate(UINT32 BitRate, UINT32 InClk)
{
    UINT32 DivValue[] = {0, 2500, 1250, 1000, 500, 250, 125, 50, 25, 12, 10, 5, 4, 3, 2, 0};    

    UINT32 i;
    UINT32 Reg;
    UINT32 SCK_SEL;
    UINT32 TempRete;

    
    if( BitRate * 2 > InClk )
    {
        SCK_SEL = 0x0E; // Max
    }
    else
    {
        i = 1;
        do
        {
            TempRete = InClk/DivValue[i];

            if(TempRete >= BitRate)
                break;
                
        }while(DivValue[++i] != 0);

        if(DivValue[i] != 0)
            SCK_SEL = i; 
        else
            SCK_SEL = i-1;
    }
    
    Reg = REGRW32(APACHE_QSPI_BASE, rQSPI_CTRL) & ~(0xf<<bQSPI_BRATE);
    REGRW32(APACHE_QSPI_BASE, rQSPI_CTRL) = (Reg | (SCK_SEL<<bQSPI_BRATE));

    //DEBUGMSG_SDK(MSGINFO, " > [QSPI_Drv] Src(%d) Dest(%d), SCK(%X)\n", BitRate, InClk/DivValue[SCK_SEL], SCK_SEL);
    
    return NC_SUCCESS;
}


INT32 ncDrv_QSPI_OSGReadData(eQSPI_OSG DN_Mode, UINT32 SrcAddr, UINT32 DstAddr, UINT32 Size)
{  
    UINT32 Offset = 0;
    UINT32 Count; 


    // Master Interface Disable
    REGRW32(APACHE_QSPI_BASE, rQSPI_MICTRL) = 0;
		
    // OSG Mode Enable
    REGRW32(APACHE_QSPI_BASE, rQSPI_OSG_DN) = DN_Mode;


    // OSG APB Mode
    if(DN_Mode == QSPI_OSG_APB)
    {
        // Dummy Address
        REGRW32(APACHE_QSPI_BASE, rQSPI_DUMMY) = 0x00FF0000; 
        // sFlash End Address
        REGRW32(APACHE_QSPI_BASE, rQSPI_EADDR) = (SrcAddr+Size-1);
        // sFlash Start Address
        REGRW32(APACHE_QSPI_BASE, rQSPI_SADDR) = SrcAddr;      


        // wait - start bit
        while( REGRW32(APACHE_QSPI_BASE, rQSPI_SIGSTS) & bQSPI_STS_EMPTY )
        {
            if(ncDrv_QSPI_TimeOut(QSPI_TIMEOUT_MAX))
            {
                break;
            }
        }
        ncDrv_QSPI_TimeOut(0);

        
        do
        {
            if(!ncDrv_QSPI_WaitFIFOSts(Offset))
            {
                return NC_FAILURE;
            }
   
            Count = 0; 
            while( !(REGRW32(APACHE_QSPI_BASE, rQSPI_SIGSTS) & bQSPI_STS_EMPTY) )
            { 
                REGRW32(DstAddr, Offset) = REGRW32(APACHE_QSPI_BASE, rQSPI_SRBUFF);
                Offset += 0x4;

                if(++Count >= 16)
                    break;       
            }
            
        } while( !(REGRW32(APACHE_QSPI_BASE, rQSPI_SIGSTS) & bQSPI_STS_END) );
    }

    return NC_SUCCESS;
}


INT32 ncDrv_QSPI_ReadData(BOOL DataSwap, UINT32 Addr, UINT32 BuffAddr, UINT32 Size)
{   
    INT32 Ret = NC_SUCCESS;    
    UINT32 Reg;


    // cache clean and invalidate data
    ASM_DCACHE_FLUSH(BuffAddr, Size);


    // check ddr remap
    BuffAddr = nc_conv_vir_to_phy(BuffAddr);


    // QSPI Init
    ncDrv_QSPI_Init();


    // OSG Mode Disable
    REGRW32(APACHE_QSPI_BASE, rQSPI_OSG_DN) = bQSPI_OSG_DIS;
    
    // Master Interface Enable
    Reg = bQSPI_MIEN;      
    if(DataSwap == ON)
        Reg |= (bQSPI_MIQSWIP | bQSPI_MIHSWIP);   
    REGRW32(APACHE_QSPI_BASE, rQSPI_MICTRL) = Reg;  


    // Master Interface Buffer Address
    REGRW32(APACHE_QSPI_BASE, rQSPI_MIADDR) = BuffAddr;
    // Dummy Address
    REGRW32(APACHE_QSPI_BASE, rQSPI_DUMMY)  = 0x00FF0000; 
    // sFlash End Address
    REGRW32(APACHE_QSPI_BASE, rQSPI_EADDR)  = (Addr+Size-1);
    // sFlash Start Address
    REGRW32(APACHE_QSPI_BASE, rQSPI_SADDR)  = Addr;      


    // Wait Busy
    if(!ncDrv_QSPI_WaitBusIsBusy())
        Ret = NC_FAILURE;


    // Wait Done
    if(!ncDrv_QSPI_WaitFrameDone())
        Ret = NC_FAILURE;


    // Disable QSPI
    ncDrv_QSPI_DeInit();

    return Ret;
}


void ncDrv_QSPI_DeInit(void)
{ 
    // Master Interface Disable
    REGRW32(APACHE_QSPI_BASE, rQSPI_MICTRL) = 0x0;
		
    // OSG Mode Disable
    REGRW32(APACHE_QSPI_BASE, rQSPI_OSG_DN) = bQSPI_OSG_DIS;
}


void ncDrv_QSPI_Init(void)
{
    UINT32 Reg;

    // INTC Disable - Not used
    ncDrv_QSPI_IntClear();
    ncDrv_QSPI_IntDisable();

    // QSPI Status Clear - Why?? Read Only Register, 
    REGRW32(APACHE_QSPI_BASE, rQSPI_STS) = 0x0;   

    // QSPI Ctrl Register 
    Reg = REGRW32(APACHE_QSPI_BASE, rQSPI_CTRL) & (0xf<<bQSPI_BRATE);
    Reg |= (bQSPI_INT_EN | bQSPI_SCKPOL | bQSPI_EN  | (0xEB<<0));
    REGRW32(APACHE_QSPI_BASE, rQSPI_CTRL) = Reg;
}


/* End Of File */

