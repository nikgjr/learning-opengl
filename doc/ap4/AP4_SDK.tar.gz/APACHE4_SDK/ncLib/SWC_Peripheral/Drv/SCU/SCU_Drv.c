/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "SCU_Drv.h"










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tSUC_CLK
{
    UINT32      mOSC;    

    UINT32      mCPU;
    UINT32      mAXI;
    UINT32      mAPB;
    UINT32      mDDR;
    UINT32      mQSPI;
} tSCU_CLK, *ptSCU_CLK;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tSCU_CLK tSCUClk = {
                                27*MHZ,     // OSC
                                50*MHZ,     // CPU
                                45*MHZ,     // AXI
                                14795*KHZ,  // APB
                                50*MHZ,     // DDR
                                20*MHZ      // QSPI
                            };










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncDrv_SCU_GetPad(UINT32 Offset, UINT32 Pos)
{
    return (REGRW32(rICU_BASE, Offset)>>Pos)&0xf;
}


void ncDrv_SCU_SetPad(UINT32 Func, UINT32 Offset, UINT32 Pos)
{
    UINT32 Reg;

    Reg = REGRW32(rICU_BASE, Offset);
    Reg &= ~(0x7<<Pos);         // Clear
    Reg |= ((Func&0x7)<<Pos);   // Set
    REGRW32(rICU_BASE, Offset) = Reg;

    //DEBUGMSG_SDK(MSGINFO, "[SCU_Drv] PIM MUX Set (%d, 0x%02x, %d)\n", Func, Offset, Pos);
}


void ncDrv_SCU_GenClk(void)
{
    //------------------------------------
    // Do not delete it...
    SYS_TICK_CLK = tSCUClk.mAPB;
    //------------------------------------

    
}


INT32 ncDrv_SCU_GetPinMux(ePAD_ID Id)
{
    INT32 ret = NC_SUCCESS;

    UINT32 Offset = 0;
    UINT32 Pos    = 0;
    
    if(Id < PAD_MAX)
    {
        if(Id != PAD_NTRST)
        {
            Offset = (UINT32)((Id / 8)*4);
            Pos    = (UINT32)((Id % 8)*4);
        }
        
        ret = ncDrv_SCU_GetPad(Offset, Pos);
    }
    else
    {
        DEBUGMSG_SDK(MSGERR, "[SCU_Drv] PIM MUX Set Error (%d)\n", Id);
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncDrv_SCU_SetPinMux(ePAD_ID Id, ePAD_FUNC Func)
{
    INT32  ret = NC_SUCCESS;
 
    UINT32 Offset = 0;
    UINT32 Pos    = 0;

    if(Id < PAD_MAX)
    {
        if(Id != PAD_NTRST)
        {
            Offset = (UINT32)((Id / 8)*4);
            Pos    = (UINT32)((Id % 8)*4);
        }
        
        ncDrv_SCU_SetPad(Func, Offset, Pos);
    }
    else
    {
        DEBUGMSG_SDK(MSGERR, "[SCU_Drv] PIM MUX Set Error (%d)\n", Id);
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncDrv_SCU_GetSystemClock(eIP_ID Id)
{
    INT32 Clock = NC_FAILURE;

    switch(Id)
    {
        case IP_CPU:
            if(ASM_GET_CORE_ID() == DLS_CORE)
                Clock = tSCUClk.mCPU;
            else
                Clock = (39706*KHZ);
            break;

        case IP_AXI:
        case IP_DMA:
            Clock = tSCUClk.mAXI;
            break;

        case IP_APB:
        case IP_SSPI:
        case IP_UART:
        case IP_TIMER:
        case IP_I2C:
        case IP_PWM:
            Clock = tSCUClk.mAPB;
            break;

        case IP_QSPI:
            Clock = tSCUClk.mQSPI;
            break;
            
        case IP_CAN:
            break;

        case IP_DDR:
            Clock = tSCUClk.mDDR;
            break;

        case IP_ADC: 
            break;

        case IP_TS:
            break;
            
        default:
            break;
    }

    return Clock;
}


INT32 ncDrv_SCU_ResetIP(eIP_ID Id)
{
    INT32 ret = NC_SUCCESS;

    switch (Id)
    {
        case IP_VDUMP:
            REGRW32(APACHE_SDC_BASE, 0x2C0) = (1<<8);
            while(REGRW32(APACHE_SDC_BASE, 0x2C0)&(1<<8));
        break;

        case IP_IPC:
            REGRW32(APACHE_SDC_BASE, 0x2B0) = (1<<30);
            while(REGRW32(APACHE_SDC_BASE, 0x2B0)&(1<<30));
        break;


        case IP_SSPI:
        break;

        default:
            ret = NC_FAILURE;
        break;
    }

    return ret;
}


INT32 ncDrv_SCU_EnableClk(eIP_ID Id)
{
    INT32 ret = NC_SUCCESS;

    switch (Id)
    {
        case IP_I2C:
        break;

        case IP_SSPI:
        break;

        default:
            ret = NC_FAILURE;
        break;
    }

    return ret;
}


INT32 ncDrv_SCU_DisableClk(eIP_ID Id)
{
    INT32 ret = NC_SUCCESS;

    switch (Id)
    {
        case IP_I2C:
        break;

        case IP_SSPI:
        break;

        default:
            ret = NC_FAILURE;
        break;
    }

    return ret;
}


UINT32 ncDrv_SCU_GetData(UINT32 offset)
{
    return REGRW32(rSCU_BASE, offset);
}


UINT32 ncDrv_SCU_SetData(UINT32 offset, UINT32 data)
{
    REGRW32(rSCU_BASE, offset) = data;
    
    return NC_SUCCESS;
}


INT32 ncDrv_SCU_Init(void)
{
    INT32 ret = NC_SUCCESS;

    ncDrv_SCU_GenClk();

    return ret;
}


INT32 ncDrv_SCU_DeInit(void)
{
    INT32  ret = NC_SUCCESS;

    return ret;
}


/* End Of File */

