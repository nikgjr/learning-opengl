/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : INTC_Drv.c
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "INTC_Drv.h"
#include "GICv2.h"










/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define IRQ_NUM_RESERVED        0x3FF










/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

typedef struct
{
    UINT32 mIntNum;
    UINT8  mTrigType;
    UINT8  mPriority;
    UINT8  mCpuTarget;
    UINT8  mIntType;
} stIntrList;


stIntrList gcIntrList[]=
{
    // Int Number,           Trigger Type,       Priority,   CPU Target,         Interrupt Type
    {IRQ_NUM_TIMER0,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+ 0)
    {IRQ_NUM_TIMER1,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+ 1)
    {IRQ_NUM_TIMER2,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+ 2)
    {IRQ_NUM_TIMER3,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+ 3)
    {IRQ_NUM_TIMER4,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ}, // (A+ 4)
    {IRQ_NUM_TIMER5,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ}, // (A+ 5)
    {IRQ_NUM_TIMER6,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ}, // (A+ 6)
    {IRQ_NUM_TIMER7,         GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ}, // (A+ 7)

    {IRQ_NUM_UART0,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+ 8)
    {IRQ_NUM_UART1,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+ 9)
    {IRQ_NUM_UART2,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+10)
    {IRQ_NUM_UART3,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+11)  
    
    {IRQ_NUM_I2C0,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+12)
    {IRQ_NUM_I2C1,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+13)
    
    {IRQ_NUM_SPI0,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+14)
    {IRQ_NUM_SPI1,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+15)
    {IRQ_NUM_QSPI,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+16)

    {IRQ_NUM_DMA0,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+17)
    {IRQ_NUM_DMA1,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+18)
    {IRQ_NUM_DMA2,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ}, // (A+19)
    {IRQ_NUM_DMA3,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ}, // (A+20)

    {IRQ_NUM_PWM0,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+21)
    {IRQ_NUM_PWM1,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+22)
    {IRQ_NUM_PWM3,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+23)
    {IRQ_NUM_PWM4,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+24)

    {IRQ_NUM_GPIO0,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+25)
    {IRQ_NUM_GPIO1,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+26)
    {IRQ_NUM_GPIO2,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+27)
    {IRQ_NUM_FMC,            GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+28)
    {IRQ_NUM_SDC,            GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+29)
    {IRQ_NUM_CAN0,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+30)
    {IRQ_NUM_CAN1,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+31)


    {IRQ_NUM_ISP0,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+32)
    {IRQ_NUM_ISP1,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+33)
    {IRQ_NUM_ISP2,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+34)
    {IRQ_NUM_ISP3,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+35)
    {IRQ_NUM_ISP4,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+36)
    {IRQ_NUM_ISP5,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+37)
    {IRQ_NUM_ISP6,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+38)
    {IRQ_NUM_ISP7,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+39)
    {IRQ_NUM_ISP8,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+40)
    {IRQ_NUM_ISP9,           GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+41)

    {IRQ_NUM_VDUMP,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+42)
    {IRQ_NUM_RESERVED,       GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+43)
    {IRQ_NUM_RESERVED,       GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+44)
    {IRQ_NUM_RESERVED,       GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+45)
    {IRQ_NUM_RESERVED,       GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+46)
    {IRQ_NUM_RESERVED,       GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+47)

    {IRQ_NUM_ADAS0,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+48)
    {IRQ_NUM_ADAS1,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+49)
    {IRQ_NUM_ADAS2,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+50)
    {IRQ_NUM_ADAS3,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+51)
    {IRQ_NUM_ADAS4,          GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+52)
    {IRQ_NUM_RESERVED,       GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+53)
    {IRQ_NUM_RESERVED,       GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+54)
    {IRQ_NUM_FAULT_SCU,      GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+55)

    {IRQ_NUM_FAULT_APRB,     GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+56)
    {IRQ_NUM_FAULT_CPRB,     GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+57)
    {IRQ_NUM_FAULT_LFT,      GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+58)
    {IRQ_NUM_FAULT_MFT,      GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+59)
    {IRQ_NUM_FAULT_PLATFORM, GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+60)
    {IRQ_NUM_FAULT_ISP,      GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+61)
    {IRQ_NUM_FAULT_RE,       GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+62)

    {IRQ_NUM_FAULT,          GIT_1_N_EDGE,       240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+63)

    {IRQ_NUM_IPC0,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF0),   INTR_IRQ}, // (A+64)
    {IRQ_NUM_IPC1,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF2),   INTR_IRQ}, // (A+65)
    {IRQ_NUM_IPC2,           GIT_1_N_LEVEL,      240,        (CPU_TARGET_IF3),   INTR_IRQ}, // (A+66)
    {0,                      0,                  0,          (0),                0       }, // (END)
};










/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

typedef struct _INTC_PARAM
{
    UINT32      mIntNum;
    PrHandler   mHandler1;
} tINTC_PARAM, *ptINTC_PARAM;










/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

tINTC_PARAM gtIntInfo[IRQS_TOTAL];








/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

UINT8 ncDrv_INTC_GetCpuTarget(UINT32 IntNum)
{
    UINT8 nCpuTarget;

    nCpuTarget = gcIntrList[IntNum-IRQS_START].mCpuTarget;

    return nCpuTarget;
}


void ncDrv_INTC_RegisterHandler(UINT32 nIntNum, PrHandler pHandler)
{
    gtIntInfo[nIntNum].mIntNum   = nIntNum;
    gtIntInfo[nIntNum].mHandler1 = pHandler;
}


void ncDrv_INTC_UnRegisterHandler(UINT32 nIntNum)
{
    gtIntInfo[nIntNum].mIntNum   = 0;
    gtIntInfo[nIntNum].mHandler1 = 0;
}


void ncDrv_INTC_InitIntHandler(void)
{
    UINT32 i;

    /* Initialize interrupt pointer function */

    for(i = 0; i < IRQS_TOTAL; i++)
    {
        gtIntInfo[i].mIntNum   = 0;
        gtIntInfo[i].mHandler1 = 0;
    }
}


void ncDrv_INTC_UserHandler(UINT32 nIntNum)
{
    /* Execute interrupt handler */

    if(gtIntInfo[nIntNum].mHandler1)
    {
        gtIntInfo[nIntNum].mHandler1(nIntNum);
    }
}


void ncDrv_INTC_HaltHandler(void)
{
    DEBUGMSG_SDK(MSGERR, "Halt_Handler ignore\n");
}


void ncDrv_INTC_IrqHandler(void)
{
    UINT32 nIntNum;
    UINT8 nCpuTarget;

    /* read group 1 Acknowledge ID */
    nIntNum = ncDrv_GIC_CPUI_GetAliasedIntAcknowledge();

    if(nIntNum < MAX_IRQ_NUM)
    {
        if(gtIntInfo[nIntNum].mHandler1)
        {
            ncDrv_GIC_DisableIrq(nIntNum);
            
            /* Interrupt Service routine */
            ncDrv_INTC_UserHandler(nIntNum);

            ncDrv_GIC_ClearPendingIrq(nIntNum);

            nCpuTarget = ncDrv_INTC_GetCpuTarget(nIntNum);
            ncDrv_GIC_SetGrp1EndOfIntID(nCpuTarget, nIntNum);

            ncDrv_GIC_EnableIrq(nIntNum);
        }
        else
        {
            DEBUGMSG_SDK(MSGERR, "IRQ_Handler Null %d\n", nIntNum);
        }
    }
    else
    {
        DEBUGMSG_SDK(MSGERR, "IRQ_Handler ignore %d\n", nIntNum);

        //ncDrv_GIC_ClearPendingIrq(nIntNum);
        //ncDrv_GIC_SetGrp1EndOfIntID(CPU_TARGET_IF0, nIntNum);
    }
}


void ncDrv_INTC_FiqHandler(void)
{
    UINT32 nIntNum;
    UINT8 nCpuTarget;

    /* read group 0 Acknowledge ID */
    nIntNum = ncDrv_GIC_CPUI_GetIntAcknowledge();

    if(nIntNum < MAX_IRQ_NUM)
    {
        if(gtIntInfo[nIntNum].mHandler1)
        {
            ncDrv_GIC_DisableIrq(nIntNum);
            
            /* Interrupt Service routine */
            ncDrv_INTC_UserHandler(nIntNum);

            ncDrv_GIC_ClearPendingIrq(nIntNum);

            nCpuTarget = ncDrv_INTC_GetCpuTarget(nIntNum);
            ncDrv_GIC_SetGrp0EndOfIntID(nCpuTarget, nIntNum);

            ncDrv_GIC_EnableIrq(nIntNum);
        }
        else
        {
            DEBUGMSG_SDK(MSGERR, "FIQ_Handler Null %d\n", nIntNum);
        }
    }
    else
    {
        DEBUGMSG_SDK(MSGERR, "FIQ_Handler ignore\n");

        //ncDrv_GIC_ClearPendingIrq(nIntNum);
        //ncDrv_GIC_SetGrp0EndOfIntID(CPU_TARGET_IF0, nIntNum);
    }
}


INT32 ncDrv_INTC_Initialize(void)
{
    INT32 i;
    UINT8 nIntNum, nTrigType, nCpuTarget, nIntType, nPriority;

    ncDrv_GIC_DistIf_Disable();
    ncDrv_GIC_CpuIf_Disable();

    ncDrv_GIC_AllDisableIrqs();

    for(i = 0; i < IRQS_TOTAL; i++)
    {
        nIntNum = gcIntrList[i].mIntNum;

        if(nIntNum == 0) break;

        if(nIntNum != IRQ_NUM_RESERVED)
        {
            nCpuTarget = gcIntrList[i].mCpuTarget;
            nTrigType  = gcIntrList[i].mTrigType;
            nIntType   = gcIntrList[i].mIntType;
            nPriority  = gcIntrList[i].mPriority;

            ncDrv_GIC_SetIrqCPUTarget(nIntNum, nCpuTarget);
            ncDrv_GIC_SetIntTrigType(nIntNum, nTrigType);
            ncDrv_GIC_SetIntTypeGroup(nIntNum, nIntType);

            if(nIntType == INTR_FIQ)
            {
                ncDrv_GIC_SetPriorityLevel(nIntNum, INTC_PRIO_HIGH);
            }
            else // INTR_IRQ
            {
                ncDrv_GIC_SetPriorityLevel(nIntNum, nPriority);
            }
        }
    }

    ncDrv_GIC_DistIf_Enable();
    ncDrv_GIC_CpuIf_Enable();

    ncDrv_GIC_CPUI_SetIntPriorityMask(GPM_LEVEL_256 & 0xFF);

    ncDrv_GIC_AllClearPendingIrqs();

    __enable_irq();
    __enable_fiq();

    return NC_SUCCESS;
}


INT32 ncDrv_INTC_Deinitialize(void)
{
    ncDrv_GIC_DistIf_Disable();
    ncDrv_GIC_CpuIf_Disable();

    __disable_irq();
    __disable_fiq();

    return NC_SUCCESS;
}


/* End Of File */

