/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : GICv2.h
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __GICV2_H__
#define __GICV2_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
 * GICv2 Register Map
 */

#define rGIC_DIST_BASE      (APACHE_INTC_BASE + 0x1000)
#define rGIC_CPUI_BASE      (APACHE_INTC_BASE + 0x2000)

// SGI : Software Generated Interrupt
// PPI : Private Peripheral Interrupt
// SPI : Shared Peripheral Interrupt

//----------------------------------------------------------
// Distributor register map

#define GICD_CTLR           0x0000  // RW, 32bit, Distributor Control Register
#define GICD_TYPER          0x0004  // RO, 32bit, Interrupt Controller Type Register
#define GICD_IIDR           0x0008  // RO, 32bit, 0x0200143B, Distributor Implementer Identification Register
#define GICD_IGROUPRn       0x0080  // RW, 16bit, 0x0080 Interrupt Group Register for SGIs
                                    // RW, 16bit, 0x0082 Interrupt Group Register for PPIs
                                    // RW, 32bit, 0x0084 ~ 0x0FC Interrupt Group Register for SPIs
#define GICD_ISENABLERn     0x0100  // RW, 16bit, 0x0100 Interrupt Set-Enable Registers for SGIs
                                    // RW, 16bit, 0x0102 Interrupt Set-Enable Registers for PPIs
                                    // RW, 32bit, 0x0104 ~ 0x017C Interrupt Set-Enable Registers for SPIs
#define GICD_ICENABLERn     0x0180  // RW, 16bit, 0x0180 Interrupt Clear-Enable Registers for SGIs
                                    // RW, 16bit, 0x0182 Interrupt Clear-Enable Registers for PPIs
                                    // RW, 32bit, 0x0184 ~ 0x01FC Interrupt Clear-Enable Registers for SPIs
#define GICD_ISPENDRn       0x0200  // RW, 16bit, 0x0200 Interrupt Set-Pending Registers for SGIs
                                    // RW, 16bit, 0x0202 Interrupt Set-Pending Registers for PPIs
                                    // RW, 32bit, 0x0204 ~ 0x027C Interrupt Set-Pending Registers for SPIs
#define GICD_ICPENDRn       0x0280  // RW, 16bit, 0x0280 Interrupt Clear-Pending Registers for SGIs
                                    // RW, 16bit, 0x0282 Interrupt Clear-Pending Registers for PPIs
                                    // RW, 32bit, 0x0284 ~ 0x02FC Interrupt Clear-Pending Registers for SPIs
#define GICD_ISACTIVERn     0x0300  // RW, 16bit, 0x0300 Interrupt Set-Active Registers for SGIs
                                    // RW, 16bit, 0x0302 Interrupt Set-Active Registers for PPIs
                                    // RW, 32bit, 0x0304 ~ 0x037C Interrupt Set-Active Registers for SPIs
#define GICD_ICACTIVERn     0x0380  // RW, 16bit, 0x0380 Interrupt Clear-Active Registers for SGIs
                                    // RW, 16bit, 0x0382 Interrupt Clear-Active Registers for PPIs
                                    // RW, 32bit, 0x0384 ~ 0x03FC Interrupt Clear-Active Registers for SPIs
#define GICD_IPRIORITYRn    0x0400  // RW, 8bit,  0x0400 ~ 0x040F Interrupt Priority Registers for SGIs
                                    // RW, 8bit,  0x0410 ~ 0x041F Interrupt Priority Registers for PPIs
                                    // RW, 8bit,  0x0420 ~ 0x07F8 Interrupt Priority Registers for SPIs
#define GICD_ITARGETSRn     0x0800  // RO, 8bit,  0x0800 ~ 0x081C Interrupt Processor Target Registers for SGIs, PPIs
                                    // RW, 8bit,  0x0820 ~ 0x0BF8 Interrupt Processor Target Registers for SPIs
#define GICD_ICFGRn         0x0C00  // RO, 32bit, 0x0C00 ~ 0x0C04 Interrupt Configuration Registers for SGIs, PPIs
                                    // RW, 32bit, 0x0C08 ~ 0x0CFC Interrupt Configuration Registers for SPIs
#define GICD_PPISR          0x0D00  // RO, 32bit, PPI Status Register (Private Peripheral Interrupt)
#define GICD_SPISRn         0x0D04  // RO, 32bit, 0x0D04 ~ 0x0D3C SPI Status Register (Shared Peripheral Interrupt)
#define GICD_NSACRn         0x0E00  // RW, 32bit, 0x0E00 ~ 0x0EFC Non-secure Access Control Registers, optional
#define GICD_SGIR           0x0F00  // WO, 32bit, Software Generated Interrupt Register
#define GICD_CPENDSGIRn     0x0F10  // RW, 32bit, SGI Clear-Pending Register
#define GICD_SPENDSGIRn     0x0F20  // RW, 32bit, SGI Set-Pending Register
#define GICD_PIDRn          0x0FD0  // RO, 32bit, 0x0FD0 ~ 0x0FEC Peripheral ID 4,5,6,7,0,1,2,3 Register
#define GICD_CIDRn          0x0FF0  // RO, 32bit, 0x0FF0 ~ 0x0FFC Component ID 0,1,2,3 Register


//----------------------------------------------------------
// CPU interface register map

#define GICC_CTLR           0x0000  // RW, 32bit, CPU Interface Control Register
#define GICC_PMR            0x0004  // RW, 32bit, Interrupt Priority Mask Register
#define GICC_BPR            0x0008  // RW, 32bit, Binary Point Register
#define GICC_IAR            0x000C  // RO, 32bit, Interrupt Acknowledge Register
#define GICC_EOIR           0x0010  // WO, 32bit, End of Interrupt Register
#define GICC_RPR            0x0014  // RO, 32bit, Running Priority Register
#define GICC_HPPIR          0x0018  // RO, 32bit, Highest Priority Pending Interrupt Register
#define GICC_ABPR           0x001C  // RW, 32bit, Aliased Binary Point Register
#define GICC_AIAR           0x0020  // RO, 32bit, Aliased Interrupt Acknowledge Register
#define GICC_AEOIR          0x0024  // RO, 32bit, Aliased End of Interrupt Register
#define GICC_AHPPIR         0x0028  // RO, 32bit, Aliased Highest Priority Pending Interrupt Register
#define GICC_APR0n          0x00D0  // RW, 32bit, 0x00D0 ~ 0x00DC Active Priority Register
#define GICC_NSAPR0n        0x00E0  // RW, 32bit, 0x00E0 ~ 0x00EC Non-Secure Active Priority Register
#define GICC_IIDR           0x00FC  // RO, 32bit, CPU Interface Identification Register
#define GICC_DIR            0x1000  // WO, 32bit, Deactivate Interrupt Register


/*
 * Mask bit value and bit, register offset shift value
 */

#define BIT_32_PER_REG          32
#define BIT_16_PER_REG          16
#define BIT_4_PER_REG           4
#define BIT_2_PER_REG           2

#define BIT_32_FIELD_MASK       0xFFFFFFFF
#define BIT_16_FIELD_MASK       0xFFFF
#define BIT_8_FIELD_MASK        0xFF
#define BIT_4_FIELD_MASK        0xF
#define BIT_2_FIELD_MASK        0x3

#define BIT_32_FIELD_WIDTH      32
#define BIT_16_FIELD_WIDTH      16
#define BIT_8_FIELD_WIDTH       8
#define BIT_4_FIELD_WIDTH       4
#define BIT_2_FIELD_WIDTH       2


/*
 * Register Bit Field defines
 */

//----------------------------------------------------
// GICv2 specific Distributor interface register offsets and constants.

/* GICD_CTLR bit definitions */
#define CTLR_ENABLE_G1_SHIFT    1
#define CTLR_ENABLE_G1_MASK     0x1
#define CTLR_ENABLE_G1_BIT      (1 << CTLR_ENABLE_G1_SHIFT)

#define ITARGETSR_SHIFT         2
#define GIC_TARGET_CPU_MASK     0xff

#define CPENDSGIR_SHIFT         2
#define SPENDSGIR_SHIFT         CPENDSGIR_SHIFT

#define SGIR_TGTLSTFLT_SHIFT    24
#define SGIR_TGTLSTFLT_MASK     0x3
#define SGIR_TGTLST_SHIFT       16
#define SGIR_TGTLST_MASK        0xff
#define SGIR_INTID_MASK         0xf
#define SGIR_TGT_SPECIFIC       0

/* GICD_ISENABLERn bit definitions */
#define ISE_INTERRUPT_ENABLE    1

/* Interrupt group definitions */
#define GICV2_INTR_GROUP0       0   // group 0, secure, FIQ
#define GICV2_INTR_GROUP1       1   // group 0, non-secure, IRQ

/* Interrupt IDs reported by the HPPIR and IAR registers */
#define PENDING_G1_INTID        1022


//----------------------------------------------------
// GICv2 specific CPU interface register offsets and constants.

/* GICC_CTLR bit definitions */
#define EOI_MODE_NS             (1 << 10)
#define EOI_MODE_S              (1 << 9)
#define IRQ_BYP_DIS_GRP1        (1 << 8)
#define FIQ_BYP_DIS_GRP1        (1 << 7)
#define IRQ_BYP_DIS_GRP0        (1 << 6)
#define FIQ_BYP_DIS_GRP0        (1 << 5)
#define CBPR                    (1 << 4)
#define FIQ_EN_SHIFT            3
#define FIQ_EN_BIT              (1 << FIQ_EN_SHIFT)
#define ACK_CTL                 (1 << 2)
#define CTLR_ENABLE_G1          (1 << 1)
#define CTLR_ENABLE_G0          (1 << 0)

/* GICC_IAR, EOIR, AIAR, AEOIR bit definitions */
#define GICC_CPUID_SHIFT        10
#define GICC_INTID_SHIFT        0

/* GICC_IIDR bit masks and shifts */
#define GICC_IIDR_PID_SHIFT     20
#define GICC_IIDR_ARCH_SHIFT    16
#define GICC_IIDR_REV_SHIFT     12
#define GICC_IIDR_IMP_SHIFT     0

#define GICC_IIDR_PID_MASK      0xfff
#define GICC_IIDR_ARCH_MASK     0xf
#define GICC_IIDR_REV_MASK      0xf
#define GICC_IIDR_IMP_MASK      0xfff

/* Interrupt ID mask for HPPIR, AHPPIR, IAR and AIAR CPU Interface registers */
#define INT_ID_MASK             0x3ff





/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum
{
#if 0
    GIT_N_N_LEVEL,
    GIT_N_N_EDGE,
    GIT_1_N_LEVEL,
    GIT_1_N_EDGE,
#else
    GIT_N_N_LEVEL,
    GIT_1_N_LEVEL,
    GIT_N_N_EDGE,
    GIT_1_N_EDGE,
#endif

    MAX_OF_GICD_CFG
} eGICD_INT_CFG;


typedef enum
{
    GPM_LEVEL_16 = 0xF0,    // 0x00 - 0xF0 (0-240), in steps of 16
    GPM_LEVEL_32 = 0xF8,    // 0x00 - 0xF8 (0-248), in steps of 8
    GPM_LEVEL_64 = 0xFC,    // 0x00 - 0xFC (0-252), in steps of 4
    GPM_LEVEL_128 = 0xFE,   // 0x00 - 0xFE (0-254), even values only
    GPM_LEVEL_256 = 0xFF,   // 0x00 - 0xFF (0-255), all values
    MAX_OF_GICC_PRIO_MASK
} eGICC_PRIO_MASK;


typedef enum
{
    IAR_CPUID,
    IAR_INTRID,
    MAX_OF_GICC_IAR
} eGICC_IAR;


typedef enum
{
    EOIR_CPUID,
    EOIR_EOIINTID,
    MAX_OF_GICC_EOIR
} eGICC_EOIR;


typedef enum
{
    IF_IDENT_IMPLEMEMT,
    IF_IDENT_REVISION,
    IF_IDENT_ARCH_VERSION,
    IF_IDENT_PRODUCTID,
    MAX_OF_GICC_IF_IDENT
} eGICC_IF_IDENT;










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

// Distributor function control

extern void   ncDrv_GIC_DIST_SetControl(UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetControl(void);
extern UINT32 ncDrv_GIC_DIST_GetIntContolType(void);
extern UINT32 ncDrv_GIC_DIST_GetImpIdentification(void);
extern void   ncDrv_GIC_DIST_SetIntGroup(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetIntGroup(UINT32 offset);
extern void   ncDrv_GIC_DIST_SetIntSetEnable(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetIntSetEnable(UINT32 offset);
extern void   ncDrv_GIC_DIST_SetIntClearEnable(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetIntClearEnable(UINT32 offset);
extern void   ncDrv_GIC_DIST_SetIntSetPending(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetIntSetPending(UINT32 offset);
extern void   ncDrv_GIC_DIST_SetIntClearPending(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetIntClearPending(UINT32 offset);
extern void   ncDrv_GIC_DIST_SetIntSetActive(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetIntSetActive(UINT32 offset);
extern void   ncDrv_GIC_DIST_SetIntClearActive(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetIntClearActive(UINT32 offset);
extern void   ncDrv_GIC_DIST_SetIntPriority(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetIntPriority(UINT32 offset);
extern void   ncDrv_GIC_DIST_SetIntProcTarget(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetIntProcTarget(UINT32 offset);
extern void   ncDrv_GIC_DIST_SetIntConfig(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetIntConfig(UINT32 offset);
extern UINT32 ncDrv_GIC_DIST_GetPPIStatus(void);
extern UINT32 ncDrv_GIC_DIST_GetSPIStatus(UINT32 offset);
extern void   ncDrv_GIC_DIST_SetNonSecureAccessControl(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetNonSecureAccessControl(UINT32 offset);
extern void   ncDrv_GIC_DIST_SetSGIControl(UINT32 value);
extern void   ncDrv_GIC_DIST_SetSGIClearPending(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetSGIClearPending(UINT32 offset);
extern void   ncDrv_GIC_DIST_SetSGISetPending(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_DIST_GetSGISetPending(UINT32 offset);
extern void   ncDrv_GIC_DIST_GetPeripheralID(UINT32 *PID0, UINT32 *PID4);
extern UINT32 ncDrv_GIC_DIST_GetComponentID(void);

// CPU Interface function control

extern void   ncDrv_GIC_CPUI_SetControl(UINT32 value);
extern UINT32 ncDrv_GIC_CPUI_GetControl(void);
extern void   ncDrv_GIC_CPUI_SetIntPriorityMask(UINT32 value);
extern UINT32 ncDrv_GIC_CPUI_GetIntPriorityMask(void);
extern void   ncDrv_GIC_CPUI_SetBinaryPoint(UINT32 value);
extern UINT32 ncDrv_GIC_CPUI_GetBinaryPoint(void);
extern UINT32 ncDrv_GIC_CPUI_GetIntAcknowledge(void);
extern void   ncDrv_GIC_CPUI_SetEndOfInterrupt(UINT32 value);
extern UINT32 ncDrv_GIC_CPUI_GetRunningPrioriry(void);
extern UINT32 ncDrv_GIC_CPUI_GetHighPriorityPendingInterrupt(void);
extern void   ncDrv_GIC_CPUI_SetAliasedBinaryPoint(UINT32 value);
extern UINT32 ncDrv_GIC_CPUI_GetAliasedBinaryPoint(void);
extern UINT32 ncDrv_GIC_CPUI_GetAliasedIntAcknowledge(void);
extern void   ncDrv_GIC_CPUI_SetAliasedEndOfInterrupt(UINT32 value);
extern UINT32 ncDrv_GIC_CPUI_GetAliasedHighPriorityPendingInterrupt(void);
extern void   ncDrv_GIC_CPUI_SetActivePriorities(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_CPUI_GetActivePriorities(UINT32 offset);
extern void   ncDrv_GIC_CPUI_SetNonSecureActivePriorities(UINT32 offset, UINT32 value);
extern UINT32 ncDrv_GIC_CPUI_GetNonSecureActivePriorities(UINT32 offset);
extern UINT32 ncDrv_GIC_CPUI_GetInterfaceID(void);
extern void   ncDrv_GIC_CPUI_SetDeactiveInterrupt(UINT32 value);

// GICv2 Driver function control

extern void ncDrv_GIC_DistIf_Enable(void);
extern void ncDrv_GIC_DistIf_Disable(void);
extern void ncDrv_GIC_CpuIf_Enable(void);
extern void ncDrv_GIC_CpuIf_Disable(void);
extern void ncDrv_GIC_EnableIrq(UINT32 irq);
extern void ncDrv_GIC_DisableIrq(UINT32 irq);
extern void ncDrv_GIC_AllDisableIrqs(void);
extern void ncDrv_GIC_ClearPendingIrq(UINT32 irq);
extern void ncDrv_GIC_AllClearPendingIrqs(void);
extern void ncDrv_GIC_SetIrqCPUTarget(UINT32 irq, UINT32 value);
extern void ncDrv_GIC_SetIntTrigType(UINT32 irq, UINT32 value);
extern void ncDrv_GIC_SetPriorityLevel(UINT32 irq, UINT32 value);
extern void ncDrv_GIC_SetGrp0EndOfIntID(UINT32 cpuId, UINT32 eoiId);
extern void ncDrv_GIC_SetGrp1EndOfIntID(UINT32 cpuId, UINT32 eoiId);
extern void ncDrv_GIC_SetIntTypeGroup(UINT32 intId, UINT32 group);
extern void ncDrv_GIC_SetSGITrigger(UINT32 irq);
extern void ncDrv_GIC_GetInformation(tGIC_ID *Gic);


#endif  /* __GICV2_H__ */


/* End Of File */
