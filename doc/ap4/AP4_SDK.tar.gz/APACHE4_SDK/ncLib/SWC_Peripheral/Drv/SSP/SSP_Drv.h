/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SSP_DRV_H__
#define __SSP_DRV_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define rSSP_0_BASE                 APACHE_SPI_0_BASE
#define rSSP_1_BASE                 APACHE_SPI_1_BASE

#define rSSP_BASE(Ch)               (rSSP_0_BASE + (Ch*0x100000))


#define rSSP_CR0                    0x00        // RxTx : SPI Config Register
                                                //        - [31: 8] : Reserved
    #define bSSP_CR0_CSEN           (7)         //        -    [7] : CSN Signal Mapped
    #define bSSP_CR0_IEN            (6)         //        -    [6] : Enable Interrupt
    #define bSSP_CR0_SPH            (5)         //        -    [5] : Clock Phase
    #define bSSP_CR0_SPO            (4)         //        -    [4] : Clock Polarity
    #define bSSP_CR0_OP             (3)         //        -    [3] : Master/Slave Operation Mode
    #define bSSP_CR0_DIR            (2)         //        -    [2] : Data Direction                                     
    #define bSSP_CR0_MOD            (1)         //        -    [1] : Tx/Rx, Only Rx Mode
    #define bSSP_CR0_EN             (0)         //        -    [0] : Enable Operation


#define rSSP_CR1                    0x04        // RxTx : SPI Clock Prescale Register
                                                //        - [31:12] : Reserved
    #define bSSP_CR1_DS_MASK        (0xF<<8)    //        - [11: 8] : Transfer Byte Width SEL
    #define bSSP_CR1_BUSY           (1<<7)      //        -     [7] : Transfer is in process
                                                //        - [ 6: 4] : Reserved
    #define bSSP_CR1_CLK_MASK       (0xF<<0)    //        - [ 3: 0] : BaudRate                                                


#define rSSP_TX                     0x08        //   Tx : SPI Trensmit Data Register
                                                //        - [31:16] : Reserved
                                                //        - [15: 0] : Tx Buffer                                           
#define rSSP_RX                     0x08        // Rx   : SPI Receive Data Register
                                                //        - [31:16] : Reserved
                                                //        - [15: 0] : Rx Buffer 
                                                
#define rSSP_CLK_DIV                0x0C        // Rx   : SPI Clock Div Register
                                                //        - [31: 0] : Div Value [BaudRate = RefClk/Div, 0x02~0xFF]

#define rSSP_RX_CLR                 0x10        //   Tx : SPI RX buffer Clear
                                                //        -     [0] : SPI RX data be '0' pulse type


// SSP TimeOut - msec
#define SSP_WAIT_TIMEOUT            (500) 










/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncDrv_SSP_WaitBusIsBusy(eSSP_CH Ch, INT8* Str);
extern void  ncDrv_SSP_SetDMAMode(eSSP_CH Ch, UINT8 rwMode);
extern INT32 ncDrv_SSP_GetIntSts(eSSP_CH Ch, eSSP_MODE Mode);
extern void  ncDrv_SSP_SetBitRate(eSSP_CH Ch, UINT32 BitRate, UINT32 InClk);
extern INT32 ncDrv_SSP_sRead(eSSP_CH Ch, UINT8 *pBuf, UINT32 Length, eSSP_DS DataWidth);
extern INT32 ncDrv_SSP_sWrite(eSSP_CH Ch, UINT8 *pBuf, UINT32 Length, eSSP_DS DataWidth);
extern INT32 ncDrv_SSP_mRead(eSSP_CH Ch, UINT8 *pBuf, UINT32 Length, eSSP_DS DataWidth);
extern INT32 ncDrv_SSP_mWrite(eSSP_CH Ch, UINT8 *pBuf, UINT32 Length, eSSP_DS DataWidth);
extern void  ncDrv_SSP_DeInit(eSSP_CH Ch);
extern void  ncDrv_SSP_Init(eSSP_CH Ch, ptSSP_PARAM ptSSPParam, UINT32 InClk);

#endif  /* __SSP_DRV_H__ */


/* End Of File */

