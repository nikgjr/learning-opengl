/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "NAND_Drv.h"










/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/


void ncDrv_NAND_DeInit(void)
{
    REGRW32(rFSM_BASE, rFSM_CFG)    = 0;  
    REGRW32(rFSM_BASE, rFSM_CYCLES) = 0;  
}


void ncDrv_NAND_Init(ptNAND_PARAM ptNandParam)
{
    UINT32 Reg;

    // Set Operation Mode
    Reg = ((ptNandParam->mEccEn<<4)
          |(0<<3)
          |(0<<1)
          |(ptNandParam->mIntEn<<0)); 
    REGRW32(rFSM_BASE, rFSM_CFG) = Reg;  


    // Set Cycles
    Reg = ((0x1<<bFSM_CYCLES_PRESCALE)
          |(0x1<<bFSM_CYCLES_RR)
          |(0x1<<bFSM_CYCLES_ALR)
          |(0x1<<bFSM_CYCLES_CEA)
          |(0x1<<bFSM_CYCLES_WL)
          |(0x1<<bFSM_CYCLES_WH)
          |(0x1<<bFSM_CYCLES_RH)
          |(0x1<<bFSM_CYCLES_RL));
    REGRW32(rFSM_BASE, rFSM_CYCLES) = Reg;  
}


/* End Of File */

