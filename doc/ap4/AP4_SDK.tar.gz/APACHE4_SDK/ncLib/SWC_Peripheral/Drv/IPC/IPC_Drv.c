/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*                                    INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "IPC_Drv.h"










/*
********************************************************************************
*                             FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void ncDrv_IPC_DeQ_UnLock(eIPC_CH Ch, eFIFO_ID Id)
{
    UINT32 Reg = 0x11110000;

    // Step-1. Set Write Flag
    //  - if (Ch == 0) 0x1110_xxxx;
    Reg &= ~(1<<((Id*4)+16)); 

    // Step-2. [0], [4], [8], [12] 1-Bit : Set '0'
    //  - if (Ch == 0) 0x1110_xxx0;
    REGRW32(rIPC_BASE(Ch), rIPC_DEQ_LOCK) = Reg;
}


static void ncDrv_IPC_DeQ_Lock(eIPC_CH Ch, eFIFO_ID Id)
{
    UINT32 Reg = 0x11110000;

    // Step-1. Set Write Flag
    //  - if (Ch == 0) 0x1110_xxxx;
    Reg &= ~(1<<((Id*4)+16)); 

    // Step-2. [0], [4], [8], [12] 1-Bit : Set '1'
    //  - if (Ch == 0) 0x1110_xxx1;
    Reg |= (1<<(Id*4));
    REGRW32(rIPC_BASE(Ch), rIPC_DEQ_LOCK) = Reg;
}


static void ncDrv_IPC_EnQ_UnLock(eIPC_CH Ch, eFIFO_ID Id)
{
    UINT32 Reg = 0x11110000;

    // Step-1. Set Write Flag
    //  - if (Ch == 0) 0x1110_xxxx;
    Reg &= ~(1<<((Id*4)+16)); 

    // Step-2. [0], [4], [8], [12] 1-Bit : Set '0'
    //  - if (Ch == 0) 0x1110_xxx0;
    REGRW32(rIPC_BASE(Ch), rIPC_ENQ_LOCK) = Reg;
}


static void ncDrv_IPC_EnQ_Lock(eIPC_CH Ch, eFIFO_ID Id)
{
    UINT32 Reg = 0x11110000;

    // Step-1. Set Write Flag
    //  - if (Ch == 0) 0x1110_xxxx;
    Reg &= ~(1<<((Id*4)+16)); 

    // Step-2. [0], [4], [8], [12] 1-Bit : Set '1'
    //  - if (Ch == 0) 0x1110_xxx1;
    Reg |= (1<<(Id*4));
    REGRW32(rIPC_BASE(Ch), rIPC_ENQ_LOCK) = Reg;
}


static INT32 ncDrv_IPC_IsEnable(eIPC_CH Ch)
{
    INT32 Ret = NC_FAILURE;

    if(REGRW32(rIPC_BASE(Ch), rIPC_EN)&0x01)
        Ret = NC_SUCCESS;

    return Ret;
}


static void ncDrv_IPC_Enable(eIPC_CH Ch)
{
    REGRW32(rIPC_BASE(Ch), rIPC_EN) = ENABLE;
}


static void ncDrv_IPC_Disable(eIPC_CH Ch)
{
     REGRW32(rIPC_BASE(Ch), rIPC_EN) = DISABLE;
}


INT32 ncDrv_IPC_GetTherCnt(eIPC_CH Ch, eFIFO_ID Id)
{
    UINT32 Reg;

    // FIFO Count
    // [0], [8], [16], [24] 5-Bit
    Reg = (REGRW32(rIPC_BASE(Ch), rIPC_INTC_THRE)>>(Id*8));

    return (INT32)(Reg&0x1f);
}


static void ncDrv_IPC_IntTriggerMode(eIPC_CH Ch)
{
    UINT32 nTrigType;

    nTrigType = REGRW32(APACHE_SYSCON_BASE, 0x148);

    if(nTrigType&(1U<<((Ch+IRQ_NUM_IPC0)-IRQ_NUM_IPC0)))
        REGRW32(rIPC_BASE(Ch), rIPC_INTC_WIDTH) = 1;  // Edge Type
    else
        REGRW32(rIPC_BASE(Ch), rIPC_INTC_WIDTH) = 0;  // Level Type

    REGRW32(rIPC_BASE(Ch), rIPC_INTC_TERM)  = 0x0;
}


static void ncDrv_IPC_IntEnable(eIPC_CH Ch, eFIFO_ID Id, UINT8 Threshold)
{
    UINT32 Reg;

    // Enable FIFO Threshold Intc
    // [0], [8], [16], [20] 5-Bit : Set Threshold
    Reg = REGRW32(rIPC_BASE(Ch), rIPC_INTC_THRE);
    Reg &= ~(0x1f<<(Id*8));
    Reg |= ((Threshold&0x1f)<<(Id*8));
    REGRW32(rIPC_BASE(Ch), rIPC_INTC_THRE) = Reg;

    // Enable FIFO Error Intc
    // [0], [4], [8], [12] 2-Bit : Set '0x0'
    Reg = REGRW32(rIPC_BASE(Ch), rIPC_INTC_MASK);
    Reg &= ~(0x3<<(Id*4));
    REGRW32(rIPC_BASE(Ch), rIPC_INTC_MASK) = Reg;
}


static void ncDrv_IPC_IntDisable(eIPC_CH Ch, eFIFO_ID Id)
{
    UINT32 Reg;

    // Disable FIFO Threshold Intc
    // [0], [8], [16], [20] 5-Bit : Set '0x0'
    Reg = REGRW32(rIPC_BASE(Ch), rIPC_INTC_THRE);
    Reg &= ~(0x1f<<(Id*8));
    REGRW32(rIPC_BASE(Ch), rIPC_INTC_THRE) = Reg;

    // Disable FIFO Error Intc
    // [0], [4], [8], [12] 2-Bit : Set '0x3'
    Reg = REGRW32(rIPC_BASE(Ch), rIPC_INTC_MASK);
    Reg |= (0x3<<(Id*4));
    REGRW32(rIPC_BASE(Ch), rIPC_INTC_MASK) = Reg;
}


void ncDrv_IPC_IntClear(eIPC_CH Ch)
{
    // Clear Intc Status
    REGRW32(rIPC_BASE(Ch), rIPC_INTC_STS_CLR) = 1;
}


INT32 ncDrv_IPC_GetStatus(eIPC_CH Ch)
{
    UINT32 Reg;
    UINT32 Tmp;
    
    eFIFO_ID Id;  
   
    INT32  Cnt;
    INT32  Ther;


    // Get IPC Status
    Reg = REGRW32(rIPC_BASE(Ch), rIPC_STS)&0x17777;


    // Clear FIFO Status
    REGRW32(rIPC_BASE(Ch), rIPC_FIFO_STS_CLR) = Reg;


#if 1 // debug
    for(Id=IPC_FIFO0; Id<MAX_OF_FIFO_ID; Id++)
    {
        Cnt  = ncDrv_IPC_GetFIFOCnt(Ch, Id);
        Ther = ncDrv_IPC_GetTherCnt(Ch, Id);
        
        if((Cnt != 0) && (Cnt >= Ther))
        {
            // [2], [6], [10], [14] 1-Bit : Check '1'
            if(!(Reg&(1<<((Id*4)+2))))
            {
                // Timming issue - Againg Read Status Register
                Tmp = REGRW32(rIPC_BASE(Ch), rIPC_STS)&0x17777;
                if(!(Tmp&(1<<((Id*4)+2))))
                {
                    DEBUGMSG_SDK(MSGERR, "[IPC_DRV] A CH_%d Id_%d Sts(%05X), %d, %d\n", Ch, Id, Reg, Cnt, Ther); 
                }
            }
        }
        else if(Reg&(1<<((Id*4)+2)))
        {
           DEBUGMSG_SDK(MSGERR, "[IPC_DRV] B CH_%d Id_%d Sts(%05X), %d, %d\n", Ch, Id, Reg, Cnt, Ther); 
        }
    }
#endif

    return (INT32)Reg;
}


INT32 ncDrv_IPC_GetFIFOCnt(eIPC_CH Ch, eFIFO_ID Id)
{
    INT32 Ret;

    // Check IPC Enable
    Ret = ncDrv_IPC_IsEnable(Ch);

    if(Ret == NC_SUCCESS)
    {
        // FIFO Count
        // [0], [8], [16], [24] 5-Bit
        Ret = (REGRW32(rIPC_BASE(Ch), rIPC_FIFO_CNT)>>(Id*8))&0x1f;
    }

    return Ret;
}


INT32 ncDrv_IPC_GetFIFO(eIPC_CH Ch, eFIFO_ID Id, UINT32* Data)
{
    INT32 Ret;

    // Check IPC Enable
    Ret = ncDrv_IPC_IsEnable(Ch);

    if(Ret == NC_SUCCESS)
    {
        // Check FIFO Count
        if(ncDrv_IPC_GetFIFOCnt(Ch, Id) == 0)
            Ret = NC_FAILURE;
        
        // Dequeue unlock
        ncDrv_IPC_DeQ_UnLock(Ch, Id);
        
        // Get Data
        *Data = rIPC_POP(Ch, Id);
            
        // Dequeue lock
        ncDrv_IPC_DeQ_Lock(Ch, Id);
    }

    // Fail
    if(Ret == NC_FAILURE)
        *Data = 0;

    return Ret;
}


INT32 ncDrv_IPC_SetFIFO(eIPC_CH Ch, eFIFO_ID Id, UINT32 Data)
{
    INT32 Ret;

    // Check IPC Enable
    Ret = ncDrv_IPC_IsEnable(Ch);

    if(Ret == NC_SUCCESS)
    {
        // Check FIFO Count
        if(ncDrv_IPC_GetFIFOCnt(Ch, Id) == 16)
            Ret = NC_FAILURE;

        // Eequeue unlock
        ncDrv_IPC_EnQ_UnLock(Ch, Id);
                
        // Set Data and Overflow Occurs 
        rIPC_PUSH(Ch, Id) = Data;

        // Eequeue lock
        ncDrv_IPC_EnQ_Lock(Ch, Id);      
    }
    
    return Ret;
}


void ncDrv_IPC_DeInit(eIPC_CH Ch)
{
    eFIFO_ID Id;
    INT32  Cnt;


    // IPC Channel Disable
    ncDrv_IPC_Disable(Ch);


    // Interrupt Disable
    for(Id=IPC_FIFO0; Id<MAX_OF_FIFO_ID; Id++)
        ncDrv_IPC_IntDisable(Ch, Id);


    // FIFO DeQ UnLock
    for(Id=IPC_FIFO0; Id<MAX_OF_FIFO_ID; Id++)
        ncDrv_IPC_DeQ_UnLock(Ch, Id);


    // FIFO Clear and Lock
    for(Id=IPC_FIFO0; Id<MAX_OF_FIFO_ID; Id++)
    {
        // Get FIFO Count
        Cnt = (REGRW32(rIPC_BASE(Ch), rIPC_FIFO_CNT)>>(Id*8))&0x1f;

        // Clear FIFO
        while(Cnt-- > 0)
            rIPC_POP(Ch, Id);

        // FIFO EnQ/DeQ Lock
        ncDrv_IPC_EnQ_Lock(Ch, Id);
        ncDrv_IPC_DeQ_Lock(Ch, Id);
    }


    // Clear Intc Status
    ncDrv_IPC_GetStatus(Ch);
    ncDrv_IPC_IntClear(Ch);
}


void ncDrv_IPC_Init(eIPC_CH Ch, UINT8* Threshold)
{
    eFIFO_ID Id;

    // IPC Channel Disable and FIFO Clear
    ncDrv_IPC_DeInit(Ch);

    // Interrupt Enable
    ncDrv_IPC_IntTriggerMode(Ch);
    for(Id=IPC_FIFO0; Id<MAX_OF_FIFO_ID; Id++)
        ncDrv_IPC_IntEnable(Ch, Id, Threshold[Id]);

    // IPC Channel Enable
    ncDrv_IPC_Enable(Ch);
}


/* End Of File */

