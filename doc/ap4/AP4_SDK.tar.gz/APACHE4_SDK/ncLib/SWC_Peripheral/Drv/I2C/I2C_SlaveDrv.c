/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "I2C_Drv.h"

#define __I2C_ACK_CTRL_MODE__










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static BOOL ncDrv_I2C_sIsAckCtrlMode(eI2C_CH Ch)
{
    BOOL Ret = FALSE;

    if(REGRW32(rI2C_BASE(Ch), rI2C_SCTR) & bI2C_SCTR_EN_A_CTRL)
        Ret = TRUE;

    return Ret;
}


static void ncDrv_I2C_sDisable(eI2C_CH Ch)
{
    UINT32 Reg;

    Reg = REGRW32(rI2C_BASE(Ch), rI2C_SCTR);
    Reg &= ~bI2C_SCTR_EN;
    REGRW32(rI2C_BASE(Ch), rI2C_SCTR) = Reg;
}


static void ncDrv_I2C_sEnable(eI2C_CH Ch)
{
    UINT32 Reg;

    Reg = REGRW32(rI2C_BASE(Ch), rI2C_SCTR);
    Reg |= bI2C_SCTR_EN;
    REGRW32(rI2C_BASE(Ch), rI2C_SCTR) = Reg;
}


static void ncDrv_I2C_sIntDisable(eI2C_CH Ch)
{
    UINT32 Reg;

    // Interrupt Clear 
    ncDrv_I2C_sIntClear(Ch);

    // Interrupt Disable
    Reg = REGRW32(rI2C_BASE(Ch), rI2C_SCTR);
    if(ncDrv_I2C_sIsAckCtrlMode(Ch) == TRUE)
        Reg &= ~(bI2C_SCTR_IEN_A_W|bI2C_SCTR_IEN_A_R|bI2C_SCTR_IEN_S|bI2C_SCTR_IEN_E);
    else
        Reg &= ~(bI2C_SCTR_IEN_R|bI2C_SCTR_IEN_W);  
    REGRW32(rI2C_BASE(Ch), rI2C_SCTR) = Reg;
}


static void ncDrv_I2C_sIntEnable(eI2C_CH Ch)
{
    UINT32 Reg;

    // Interrupt Clear 
    ncDrv_I2C_sIntClear(Ch);

    // Interrupt Enable
    Reg = REGRW32(rI2C_BASE(Ch), rI2C_SCTR);
    if(ncDrv_I2C_sIsAckCtrlMode(Ch) == TRUE)    
        Reg |= (bI2C_SCTR_IEN_A_W|bI2C_SCTR_IEN_A_R|bI2C_SCTR_IEN_S|bI2C_SCTR_IEN_E);
    else
    Reg |= (bI2C_SCTR_IEN_R|bI2C_SCTR_IEN_W);  

    REGRW32(rI2C_BASE(Ch), rI2C_SCTR) = Reg;
}

void ncDrv_I2C_sSetAckValue(eI2C_CH Ch, UINT32 Value)
{
    REGRW32(rI2C_BASE(Ch), rI2C_SLV_ACK_CON) = Value;
}

void ncDrv_I2C_sSetAckCtrlMode(eI2C_CH Ch)
{
    UINT32 Reg;

    Reg = REGRW32(rI2C_BASE(Ch), rI2C_SCTR);
#ifdef __I2C_ACK_CTRL_MODE__
    Reg |= bI2C_SCTR_EN_A_CTRL;   
#else
    Reg &= ~bI2C_SCTR_EN_A_CTRL; 
#endif
    REGRW32(rI2C_BASE(Ch), rI2C_SCTR) = Reg; 
}


void ncDrv_I2C_sIntClear(eI2C_CH Ch)
{
    INT32 Reg;

    Reg = REGRW32(rI2C_BASE(Ch), rI2C_SST);

    REGRW32(rI2C_BASE(Ch), rI2C_SST) = Reg;
}


INT32 ncDrv_I2C_sGetIntSts(eI2C_CH Ch)
{
    INT32 Reg;

    Reg = REGRW32(rI2C_BASE(Ch), rI2C_SST);

    if(ncDrv_I2C_sIsAckCtrlMode(Ch) == TRUE)
    {   
        // Do not Int Clear
        
        
        // Master Ack Value
        if(Reg&(1<<24))
            Reg |= (1<<13);
        
        Reg |= (1<<15);
    }
    else
    {
        // Int Clear
        REGRW32(rI2C_BASE(Ch), rI2C_SST) = Reg;

        // Marking Slave Mode Interrupt
        Reg |= (1<<14);
    }
    
    return (Reg&0xFFFF);
}


void ncDrv_I2C_sSetDevAddr(eI2C_CH Ch, UINT16 DevAddr)
{
    REGRW32(rI2C_BASE(Ch), rI2C_SIDA) = DevAddr&0xFF;
}


INT32 ncDrv_I2C_sSetClock(eI2C_CH Ch, UINT32 RefClk, UINT32 TargetClk)
{
    INT32 Ret = NC_SUCCESS;

    // currently the device does nothing...    

    return Ret;
}


INT32 ncDrv_I2C_sReadData(eI2C_CH Ch, UINT16 RegAddr, UINT8* pBuff, UINT32 UnitCnt)
{
    INT32 Ret = NC_SUCCESS;    
    UINT32 i = 0;

    if(ncDrv_I2C_sIsAckCtrlMode(Ch) == TRUE)
    {
        *pBuff = ((REGRW32(rI2C_BASE(Ch), rI2C_SST)>>16)&0xff); 
    }
    else
    {
        // Check Start Point
        switch(RegAddr)
        {
            case APACHE_I2C_SLAVE_REG_00: i=0; break;
            case APACHE_I2C_SLAVE_REG_01: i=1; break;
            case APACHE_I2C_SLAVE_REG_02: i=2; break;        
            case APACHE_I2C_SLAVE_REG_03: i=3; break;  
            default: 
                Ret = NC_FAILURE;
            break;
        }
        UnitCnt += i;
        
        if(Ret == NC_SUCCESS)
        {
            // Check End Point
            if(UnitCnt > 4) 
                UnitCnt = 4;  
            
            // Read Data
            for( ; i<UnitCnt; i++)
            {
                *pBuff++ = REGRW32(rI2C_BASE(Ch), rI2C_SRXR_40 + (i*4))&0xff; 
            }
        }
    }

    return Ret;
}


INT32 ncDrv_I2C_sWriteData(eI2C_CH Ch, UINT16 RegAddr, UINT8* pBuff, UINT32 UnitCnt)
{
    INT32 Ret = NC_SUCCESS;    
    UINT32 i = 0;

    if(ncDrv_I2C_sIsAckCtrlMode(Ch) == TRUE)
    {
        REGRW32(rI2C_BASE(Ch), rI2C_SLV_TX) = *pBuff;
    }
    else
    {
        // Check Start Point
        switch(RegAddr)
        {
            case APACHE_I2C_SLAVE_REG_00: i=0; break;
            case APACHE_I2C_SLAVE_REG_01: i=1; break;
            case APACHE_I2C_SLAVE_REG_02: i=2; break;        
            case APACHE_I2C_SLAVE_REG_03: i=3; break;  
            default: 
                Ret = NC_FAILURE;
            break;
        }
        UnitCnt += i;

        if(Ret == NC_SUCCESS)
        {
            // Write Data
            for( ; i<UnitCnt; i++)
            {
                REGRW32(rI2C_BASE(Ch), rI2C_STXR_40 + (i*4)) = *pBuff++;
            }
        }
    }

    return Ret;
}


INT32 ncDrv_I2C_sDeInitialize(eI2C_CH Ch)
{
    INT32 Ret = NC_SUCCESS;
    UINT32 i;

    // Disable Channel
    ncDrv_I2C_sDisable(Ch);

    // Interrupt Clear
    ncDrv_I2C_sIntDisable(Ch);

    // Slave Addr Clear
    ncDrv_I2C_sSetDevAddr(Ch, 0x0);

    // Buff Clear
    for(i=0; i<4; i++)
        REGRW32(rI2C_BASE(Ch), rI2C_STXR_40 + (i*4)) = 0x0;

    return Ret;
}


INT32 ncDrv_I2C_sInitialize(eI2C_CH Ch, BOOL mIntEn, UINT16 DevAddr)
{
    INT32 Ret = NC_SUCCESS;

    // Disable Channel
    ncDrv_I2C_sDisable(Ch);

    // Set Slave Address
    ncDrv_I2C_sSetDevAddr(Ch, DevAddr);   

    // Set ACK Ctrl Mode
    ncDrv_I2C_sSetAckCtrlMode(Ch);

    // Set Interrupt
    if(mIntEn == ENABLE)
        ncDrv_I2C_sIntEnable(Ch);
    else
        ncDrv_I2C_sIntDisable(Ch);

    // Enable Channel
    ncDrv_I2C_sEnable(Ch);

    return Ret;
}


/* End Of File */

