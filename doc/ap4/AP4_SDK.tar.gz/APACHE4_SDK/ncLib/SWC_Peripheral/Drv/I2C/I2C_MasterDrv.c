/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "I2C_Drv.h"

//#define __DEBUG_I2C_DRV__










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/
 
volatile BOOL gbI2C_ISR_DONE[MAX_OF_I2C_CH];










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

#ifdef __DEBUG_I2C_DRV__
static void ncDrv_I2C_mStopWatch(BOOL OnOff, INT8* Str)
{ 
    UINT32 uDelay = nc_get_usec_auto_cls();

    if(OnOff == ON)
    {
        DEBUGMSG_SDK(MSGINFO, "> %s", Str);
    }
    else
    {   
        DEBUGMSG_SDK(MSGINFO, " - %06d us\n", uDelay);
    }
}
#endif


static BOOL ncDrv_I2C_mTimeOut(UINT32 mSec)
{
    BOOL ret = FALSE;       
    static volatile UINT32 sI2C_TimeOutMsec = 0;  

    if(mSec > 0)
    {
        if(sI2C_TimeOutMsec == 0)
        {
            // Set TimeOut : SystemTick(msec) + TargetMsec;
            sI2C_TimeOutMsec = nc_get_msec(1) + mSec;
        }
        else
        {
            // Timeout Check. 
            if( nc_get_msec(0) > sI2C_TimeOutMsec)
            {
                ret = TRUE;
                sI2C_TimeOutMsec = 0;
            }
        }
    }
    else
    {
        sI2C_TimeOutMsec = 0;
    }
    
    return ret;
}


static BOOL ncDrv_I2C_mIsIntEnable(eI2C_CH Ch)
{
    UINT32 OnOff = FALSE;

    if(REGRW32(rI2C_BASE(Ch), rI2C_CTR)&bI2C_CTR_IEN)
        OnOff = TRUE;
    
    return OnOff;
}


static void ncDrv_I2C_mSetNACK(eI2C_CH Ch)
{
    // Read from Slave - and NACK Condition
    REGRW32(rI2C_BASE(Ch), rI2C_CR) = (bI2C_CR_RD | bI2C_CR_NACK | bI2C_CR_STO);
}


static void ncDrv_I2C_mSetACK(eI2C_CH Ch)
{
    // Read from Slave - and ACK Condition
    REGRW32(rI2C_BASE(Ch), rI2C_CR) = (bI2C_CR_RD | bI2C_CR_ACK); 
}


static void ncDrv_I2C_mSetStart(eI2C_CH Ch)
{
    // Write to Slave - and Start Condition
    REGRW32(rI2C_BASE(Ch), rI2C_CR) = (bI2C_CR_STA | bI2C_CR_WR);
}


static void ncDrv_I2C_mSetStop(eI2C_CH Ch)
{
    // Write to Slave - and Stop Condition
    REGRW32(rI2C_BASE(Ch), rI2C_CR) = (bI2C_CR_STO | bI2C_CR_WR); 
}


static void ncDrv_I2C_mSetNoCond(eI2C_CH Ch)
{
    // Write to Slave - No Condition
    REGRW32(rI2C_BASE(Ch), rI2C_CR) = bI2C_CR_WR; 
}


static UINT8 ncDrv_I2C_mGetData(eI2C_CH Ch)
{
    // Get Data
    return (UINT8)(REGRW32(rI2C_BASE(Ch), rI2C_RXR)&0xff);
}


static void ncDrv_I2C_mSetData(eI2C_CH Ch, UINT8 Data)
{
    // Set Data
    REGRW32(rI2C_BASE(Ch), rI2C_TXR) = Data;
}


static INT32 ncDrv_I2C_mCheckStatus(eI2C_CH Ch, eI2C_COND Cond, UINT8 Sts)
{
    INT32 Ret = NC_FAILURE;
    INT8* aConStr[] = { "Start", "ReStart", "ACK" ,"NACK" ,"STOP", "NONE"};


    if(Sts&bI2C_SR_LOST)
    {
        DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Arbitation Lost\n");
    }
    else
    {
        if(Cond == I2C_COND_NACK)
        {
            // NACK Condtion
            if(Sts&bI2C_SR_NACK)
                Ret = NC_SUCCESS;
        }
        else if(Cond == I2C_COND_STOP)
        {
            // ACK Or NACK
            Ret = NC_SUCCESS;
        }
        else
        {
            // ACK Condtion
            if(!(Sts&bI2C_SR_NACK))
                Ret = NC_SUCCESS;
        }
        
    }


    if(Sts&bI2C_SR_INT)
    {
        ncDrv_I2C_mIntClear(Ch);
    }

   
    if(Ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Error, I2C_%d %s 0x%02X\n", Ch, aConStr[Cond], Sts);
    }

    return Ret;
}


static INT32 ncDrv_I2C_mWaitBusy(eI2C_CH Ch)
{
    INT32 Ret = NC_FAILURE;
    UINT8 Sts;


#ifdef __DEBUG_I2C_DRV__
    ncDrv_I2C_mStopWatch(ON, "BUSY");
#endif

    // Wait - Bus Busy
    while(REGRW32(rI2C_BASE(Ch), rI2C_SR)&bI2C_SR_BUSY)
    {
        if(ncDrv_I2C_mTimeOut(I2C_WAIT_TIMEOUT))
        {
            DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Error, I2C_%d Time Out(%dms)\n", Ch, I2C_WAIT_TIMEOUT);
            break;
        }
    }
    ncDrv_I2C_mTimeOut(0);

#ifdef __DEBUG_I2C_DRV__
    ncDrv_I2C_mStopWatch(OFF, NULL);
#endif


    // Status Check.. 
    Sts = REGRW32(rI2C_BASE(Ch), rI2C_SR)&0xFF;
    if(!(Sts&bI2C_SR_BUSY))
        Ret = NC_SUCCESS;

    return Ret;
}


static void ncDrv_I2C_mIntFlagUpdete(eI2C_CH Ch)
{
    // Set Interrupt End Flag 
    if(ncDrv_I2C_mIsIntEnable(Ch) == TRUE)
        gbI2C_ISR_DONE[Ch] = 0;
    else
        gbI2C_ISR_DONE[Ch] = 1;
}

  
static INT32 ncDrv_I2C_mWaitComplet(eI2C_CH Ch, eI2C_COND Cond)
{
    INT32 Ret = NC_FAILURE;
    UINT8 Sts;


#ifdef __DEBUG_I2C_DRV__
    ncDrv_I2C_mStopWatch(ON, "TIP ");
#endif

    // Wait - Transfer End
    while(REGRW32(rI2C_BASE(Ch), rI2C_SR)&bI2C_SR_TIP)
    {
        if(ncDrv_I2C_mTimeOut(I2C_WAIT_TIMEOUT))
        {
            DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Error, I2C_%d Time Out(%dms)\n", Ch, I2C_WAIT_TIMEOUT);
            break;
        }
    }
    ncDrv_I2C_mTimeOut(0);

#ifdef __DEBUG_I2C_DRV__
    ncDrv_I2C_mStopWatch(OFF, NULL);
#endif

   
    // Status Check.. 
    if(gbI2C_ISR_DONE[Ch])
    {
        Sts = REGRW32(rI2C_BASE(Ch), rI2C_SR)&0xFF;
        if(!(Sts&bI2C_SR_TIP))
            Ret = ncDrv_I2C_mCheckStatus(Ch, Cond, Sts);
    }


    return Ret;
}


static INT32 ncDrv_I2C_mRecvData(eI2C_CH Ch, UINT8 *pData, eI2C_COND Cond)
{
    INT32 Ret = NC_SUCCESS;


    // Set Interrupt Done Flag 
    ncDrv_I2C_mIntFlagUpdete(Ch);


    // Recv Data and Condition
    if(Cond == I2C_COND_NACK)
       ncDrv_I2C_mSetNACK(Ch);
    else if(Cond == I2C_COND_ACK)
       ncDrv_I2C_mSetACK(Ch);
    else
       Ret = NC_FAILURE;

   
    if(Ret == NC_SUCCESS)
    {
        // Wait Recv Complet
        Ret = ncDrv_I2C_mWaitComplet(Ch, Cond);

        // Read Data
        *pData = ncDrv_I2C_mGetData(Ch);
    }

    return Ret;
}


static INT32 ncDrv_I2C_mSendData(eI2C_CH Ch, UINT8 Data, eI2C_COND Cond)
{
    INT32 Ret;


    // Set Interrupt Done Flag 
    ncDrv_I2C_mIntFlagUpdete(Ch);


    // Set Data
    ncDrv_I2C_mSetData(Ch, Data);


    // Send Data and Condition
    if((Cond == I2C_COND_START) || (Cond == I2C_COND_RESTART))
        ncDrv_I2C_mSetStart(Ch);
    else if (Cond == I2C_COND_STOP)
        ncDrv_I2C_mSetStop(Ch);
    else
        ncDrv_I2C_mSetNoCond(Ch);


    // Wait Send Complet
    Ret = ncDrv_I2C_mWaitComplet(Ch, Cond);


    return Ret;
}


static INT32 ncDrv_I2C_mSetRegAddr(eI2C_CH Ch, UINT16 RegAddr, UINT8 Byte, eI2C_COND Cond)
{
    INT32 Ret;
    
    do
    {
        Byte--;

        Ret = ncDrv_I2C_mSendData(Ch, ((RegAddr>>(Byte?8:0))&0xff), Cond);
        if(Ret == NC_FAILURE)
            return Ret;
    }
    while(Byte);

    return Ret;
}


static INT32 ncDrv_I2C_mSetSlaveAddr(eI2C_CH Ch, UINT16 DevAddr, eI2C_DEV_BIT_TYPE DevBit, eI2C_CMD_MODE Mode, eI2C_COND Cond)
{
    INT32 Ret; 
    
    if(DevBit == I2C_DEV_10BIT)
    {        
        // Addr[9:0] -                9 8            7 6 5 4 3 2 1 0
        // Outupt    - 'S' [1 1 1 1 0 x x RW] 'ACK' [x x x x x x x x] 'ACK'
        Ret = ncDrv_I2C_mSendData(Ch, (((DevAddr>>7)&0x06) | 0xF0 | Mode), Cond);
        if(Ret == NC_SUCCESS)
        {
            Ret = ncDrv_I2C_mSendData(Ch, (DevAddr&0xFF), I2C_COND_NONE);
        }
    }
    else
    {
        // Addr[6:0] -      6 5 4 3 2 1 0
        // Outupt    - 'S' [x x x x x x x RW] 'ACK'
        Ret = ncDrv_I2C_mSendData(Ch, (DevAddr | Mode), Cond);
    }

    return Ret;
}


static void ncDrv_I2C_mDisable(eI2C_CH Ch)
{
    UINT32 Reg;

    Reg = REGRW32(rI2C_BASE(Ch), rI2C_CTR);
    Reg &= ~bI2C_CTR_EN;
    REGRW32(rI2C_BASE(Ch), rI2C_CTR) = Reg;
}


static void ncDrv_I2C_mEnable(eI2C_CH Ch)
{
    UINT32 Reg;

    Reg = REGRW32(rI2C_BASE(Ch), rI2C_CTR);
    Reg |= bI2C_CTR_EN;
    REGRW32(rI2C_BASE(Ch), rI2C_CTR) = Reg;
}


static void ncDrv_I2C_mIntDisable(eI2C_CH Ch)
{
    UINT32 Reg;

    // Interrupt Clear
    ncDrv_I2C_mIntClear(Ch);

    // Interrupt Disable
    Reg = REGRW32(rI2C_BASE(Ch), rI2C_CTR);
    Reg &= ~bI2C_CTR_IEN;
    REGRW32(rI2C_BASE(Ch), rI2C_CTR) = Reg;
}


static void ncDrv_I2C_mIntEnable(eI2C_CH Ch)
{
    UINT32 Reg;

    // Interrupt Clear
    ncDrv_I2C_mIntClear(Ch);

    // Interrupt Enable
    Reg = REGRW32(rI2C_BASE(Ch), rI2C_CTR);
    Reg |= bI2C_CTR_IEN;
    REGRW32(rI2C_BASE(Ch), rI2C_CTR) = Reg;
}


void ncDrv_I2C_mIntClear(eI2C_CH Ch)
{
    REGRW32(rI2C_BASE(Ch), rI2C_CR) = bI2C_CR_INT;

    gbI2C_ISR_DONE[Ch] = 1;
}


INT32 ncDrv_I2C_mGetIntSts(eI2C_CH Ch)
{
    INT32 Ret;

    Ret = REGRW32(rI2C_BASE(Ch), rI2C_SR);
    
    ncDrv_I2C_mIntClear(Ch);
    
    return Ret;
}


void ncDrv_I2C_mSetDevAddr(eI2C_CH Ch, UINT16 DevAddr)
{
    // currently the device does nothing... 
}


INT32 ncDrv_I2C_mSetClock(eI2C_CH Ch, UINT32 RefClk, UINT32 TargetClk)
{
    INT32 Ret = NC_FAILURE;
    UINT32 DIV;

    if((RefClk != 0) && (TargetClk != 0))
    {
        if(TargetClk < 100)
            TargetClk = 100;
        
        DIV = (RefClk / (TargetClk * 5))-1;

        REGRW32(rI2C_BASE(Ch), rI2C_PRERLO) = DIV&0xFF;   
        REGRW32(rI2C_BASE(Ch), rI2C_PRERHI) = (DIV>>8)&0xFF;

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncDrv_I2C_mReadData(ptI2C_INFO ptI2C, UINT16 RegAddr, UINT8* pBuff, UINT32 UnitCnt)
{
    INT32 Ret = NC_SUCCESS;
    
    eI2C_CH   Ch = ptI2C->mI2C_ChNum;
    eI2C_COND Cond; 
    UINT8     AddrByte;    
    UINT32    DataByte;
    UINT8     TempBuff;


    // Conv Byte Type - Target Register Address and Data
    DataByte = UnitCnt;
    switch(ptI2C->mI2C_Param.mLengthType)
    {
        case I2C_ADDR_8_DATA_8:   AddrByte = 1; DataByte *= 1; break;
        case I2C_ADDR_8_DATA_16:  AddrByte = 1; DataByte *= 2; break;
        case I2C_ADDR_16_DATA_8:  AddrByte = 2; DataByte *= 1; break;
        case I2C_ADDR_16_DATA_16: AddrByte = 2; DataByte *= 2; break;
        default :                 AddrByte = 1; DataByte *= 1; break;
    }


    // Busy Check
    Ret = ncDrv_I2C_mWaitBusy(Ch);
    if(Ret != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Error, I2C_%d R:Busy\n" , Ch);
        //goto RSTOP;
    }



    // Set - Start Condition and Slave Address (Write Mode)
    Cond = I2C_COND_START;
    Ret = ncDrv_I2C_mSetSlaveAddr(Ch, ptI2C->mI2C_Param.mDevAddr, ptI2C->mI2C_Param.mDevBit, I2C_CMD_W, Cond);
    if(Ret != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Error, I2C_%d R:Send SlaveID(s) - 0x%X\n", Ch, ptI2C->mI2C_Param.mDevAddr);
        goto RSTOP;
    }



    // Set - Register Address
    Cond = I2C_COND_NONE;
    Ret = ncDrv_I2C_mSetRegAddr(Ch, RegAddr, AddrByte, Cond);
    if(Ret != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Error, I2C_%d R:Send RegAddr - 0x%x\n", Ch, RegAddr);
        goto RSTOP;
    }



    // Set - Repeated Start Condition and Slave Address (Read Mode)
    Cond = I2C_COND_RESTART;
    Ret = ncDrv_I2C_mSetSlaveAddr(Ch, ptI2C->mI2C_Param.mDevAddr, ptI2C->mI2C_Param.mDevBit, I2C_CMD_R, Cond);
    if(Ret != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Error, I2C_%d R:Send SlaveID(sr) - 0x%x\n", Ch, ptI2C->mI2C_Param.mDevAddr);
        goto RSTOP;
    }



    // Data Read and Condition Send (ACK or NACK)
    Cond = I2C_COND_ACK;
    do
    {
        if(DataByte == 1)
            Cond = I2C_COND_NACK;

        Ret = ncDrv_I2C_mRecvData(Ch, pBuff, Cond);
        if(Ret != NC_SUCCESS)
        {
            DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Error, I2C_%d R:Recv Data - 0x%x\n", Ch, *pBuff);
            goto RSTOP;
        }
        
        pBuff++;
        DataByte--;
    }
    while(DataByte);


RSTOP:

    if(Ret == NC_FAILURE)
        ncDrv_I2C_mRecvData(Ch, &TempBuff, I2C_COND_NACK);

    return Ret;
}


INT32 ncDrv_I2C_mWriteData(ptI2C_INFO ptI2C, UINT16 RegAddr, UINT8* pBuff, UINT32 UnitCnt)
{
    INT32 Ret = NC_SUCCESS;
    
    eI2C_CH   Ch = ptI2C->mI2C_ChNum;
    eI2C_COND Cond; 
    UINT8     AddrByte;    
    UINT32    DataByte;



    // Conv Byte Type - Target Register Address and Data 
    DataByte = UnitCnt;
    switch(ptI2C->mI2C_Param.mLengthType)
    {
        case I2C_ADDR_8_DATA_8:   AddrByte = 1; DataByte *= 1; break;
        case I2C_ADDR_8_DATA_16:  AddrByte = 1; DataByte *= 2; break;
        case I2C_ADDR_16_DATA_8:  AddrByte = 2; DataByte *= 1; break;
        case I2C_ADDR_16_DATA_16: AddrByte = 2; DataByte *= 2; break;
        default :                 AddrByte = 1; DataByte *= 1; break;
    }



    // Busy Check
    Ret = ncDrv_I2C_mWaitBusy(Ch);
    if(Ret != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Error, I2C_%d Busy\n" , Ch);
        //goto WSTOP;
    }



    // Set - Start Condition and Slave Address (Write Mode)
    Cond = I2C_COND_START;
    Ret = ncDrv_I2C_mSetSlaveAddr(Ch, ptI2C->mI2C_Param.mDevAddr, ptI2C->mI2C_Param.mDevBit, I2C_CMD_W, Cond);
    if(Ret != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Error, I2C_%d W:Send SlaveID - 0x%x\n", Ch, ptI2C->mI2C_Param.mDevAddr);
        goto WSTOP;
    }



    // Set - Register Address
    Cond = I2C_COND_NONE;
    Ret = ncDrv_I2C_mSetRegAddr(Ch, RegAddr, AddrByte, Cond);
    if(Ret != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Error, I2C_%d W:Send RegAddr - 0x%x\n", Ch, RegAddr);
        goto WSTOP;
    }



    // Data Write and Condition Stop
    do
    {
        if(DataByte == 1)
            Cond = I2C_COND_STOP;

        Ret = ncDrv_I2C_mSendData(Ch, *pBuff, Cond);
        if(Ret != NC_SUCCESS)
        {
            DEBUGMSG_SDK(MSGERR, "[I2C_Drv] Error, I2C_%d W:Send Data - 0x%x\n", Ch, *pBuff);
            goto WSTOP;
        }
        
        pBuff++;
        DataByte--;
    }
    while(DataByte);

WSTOP:

    return Ret;
}


INT32 ncDrv_I2C_mDeInitialize(eI2C_CH Ch)
{
    INT32 Ret = NC_SUCCESS;

    // Disable I2C Core
    ncDrv_I2C_mDisable(Ch);

    // Disable Interrupt
    ncDrv_I2C_mIntDisable(Ch);

    return Ret;
}


INT32 ncDrv_I2C_mInitialize(eI2C_CH Ch, BOOL mIntEn, UINT32 RefClk, UINT32 Hz)
{
    INT32 Ret;

    // Disable Channel
    ncDrv_I2C_mDisable(Ch);

    // Set Clock
    Ret = ncDrv_I2C_mSetClock(Ch, RefClk, Hz);

    if(Ret == NC_SUCCESS)
    {
        // Set Interrupt 
        if(mIntEn == ENABLE)
            ncDrv_I2C_mIntEnable(Ch);
        else
            ncDrv_I2C_mIntDisable(Ch);

        // Enable Channel 
        ncDrv_I2C_mEnable(Ch);
    }

    return Ret;
}


/* End Of File */

