/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*              INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "sFlash_Svc.h"

#define __SUPPORT_DMA_MODE__










/*
********************************************************************************
*              DEFINES
********************************************************************************
*/

#define CMD_sFLASH_WR_EN                        0x06
#define CMD_sFLASH_WR_DS                        0x04
#define CMD_sFLASH_RD_STS                       0x05
#define CMD_sFLASH_RD_STS2                      0x35		// for WINBOND SPI Flash
#define CMD_sFLASH_WR_STS                       0x01
#define CMD_sFLASH_RD_DATA                      0x03
#define CMD_sFLASH_PAGE_PROGRAM                 0x02
#define CMD_sFLASH_SECTOR_ERASE                 0x20
#define CMD_sFLASH_BLOCK_ERASE                  0xD8
#define CMD_sFLASH_RD_IDENTIFICATION            0x9F

#define STS_WIP                                 (0x1<<0)
#define STS_WEL                                 (0x1<<1)

#define FLASH_ID_WINBOND                        (0xEF)
#define FLASH_ID_EON                            (0x1C)
#define FLASH_ID_MXIC                           (0xC2)
#define FLASH_ID_MICRON                         (0x20)
#define FLASH_ID_SPANSION                       (0xEF)

#define BP0                                     (1<<2)
#define BP1                                     (1<<3)
#define BP2                                     (1<<4)
#define BP3                                     (1<<5)


#define SF_DMA_TIME_OUT                         3000        // 3sec










/*
********************************************************************************
*              GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

volatile tSF_PARAM tSF_Info;

#ifdef __SUPPORT_DMA_MODE__
/*
* To use DMA, a 16-byte aligned instuction-buffer is required.
* However, ARM_Compiler_RVDS_v4.0 does not support 16 aligns.
* ARM_Compiler_RVDS_v4.0 - [local  variable] 1,2,4,8(Support), 16(Not Support)
*                          [global variable] 1,2,4,8,16(Support)
* Therefore, the instuction buffer must be set to the BSS area.
*/
UINT8 gSF_TxSrcBuff[16]   __attribute__ ((aligned (16)));
UINT8 gSF_TxInstBuff[512] __attribute__ ((aligned (16)));
UINT8 gSF_RxInstBuff[512] __attribute__ ((aligned (16)));
#endif










/*
********************************************************************************
*              FUNCTION DEFINITIONS                              
********************************************************************************
*/

BOOL ncSvc_SF_mTimeOut(UINT32 mSec)
{
    BOOL ret = FALSE;       
    static volatile UINT32 s_SF_TimeOutMsec = 0;  

    if(mSec > 0)
    {
        if(s_SF_TimeOutMsec == 0)
        {
            // Set TimeOut : SystemTick(msec) + TargetMsec;
            s_SF_TimeOutMsec = nc_get_msec(1) + mSec;
        }
        else
        {
            // Timeout Check. 
            if( nc_get_msec(0) > s_SF_TimeOutMsec)
            {
                ret = TRUE;
                s_SF_TimeOutMsec = 0;
            }
        }
    }
    else
    {
        s_SF_TimeOutMsec = 0;
    }
    
    return ret;
}



INT32 ncSvc_SF_QSPIReadAPBOSG(UINT32 Addr, UINT32 BuffAddr, UINT32 Size)
{
    INT32 Ret = NC_FAILURE;

    if((tSF_Info.mQuadMode == TRUE) && !(Size%8))   // Quad SPI 64bit Align     
    {
        ncLib_QSPI_Ctrl_Init();
        ncLib_QSPI_Ctrl_OSGRead(QSPI_OSG_APB, Addr, BuffAddr, Size);
        ncLib_QSPI_Ctrl_DeInit();
        
        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncSvc_SF_QSPIReadDirectOSG(BOOL OnOff)
{
    INT32 Ret = NC_FAILURE;
    
    if(tSF_Info.mQuadMode == TRUE)
    {
        if(OnOff)
        {
            ncLib_QSPI_Ctrl_Init();
            ncLib_QSPI_Ctrl_OSGRead(QSPI_OSG_DIRECT, NULL, NULL, NULL);
        }
        else
        {
            ncLib_QSPI_Ctrl_DeInit();
        }

        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncSvc_SF_QSPIReadLUT(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    INT32 Ret = NC_FAILURE;
        
    if((tSF_Info.mQuadMode == TRUE) && !(Size%8))   // Quad SPI 64bit Align      
    {         
        ncLib_QSPI_Ctrl_LUTRead(Addr, (UINT8 *)pData, Size);
        Ret = NC_SUCCESS;
    }

    return Ret;
}


INT32 ncSvc_SF_GetPadCtrl(void)
{
    ncLib_SSP_Ctrl_GetPad(tSF_Info.mSpiCh);

    return NC_SUCCESS;
}


INT32 ncSvc_SF_FreePadCtrl(void)
{
    ncLib_SSP_Ctrl_FreePad(tSF_Info.mSpiCh);
        
    return NC_SUCCESS;
}


void ncSvc_SF_QSPIEnable(BOOL OnOff)
{
    tSFLASH_ID tsFlashID;
    UINT8 Status1;
    UINT8 Status2;

    ncSvc_SF_ReadDeviceIdentification(&tsFlashID);
    
    if(OnOff)
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status2 = ncSvc_SF_ReadStatus2();

            if( !(Status2 & (1<<1)) )
            {
                ncSvc_SF_WriteStatus2(Status1, Status2|(1<<1));
            }
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            if( !(Status1 & (1<<6)) )
            {
                ncSvc_SF_WriteStatus(Status1|(1<<6));
            }
        }
        else
        {
            tSF_Info.mQuadMode = FALSE;
        }
    }
    else
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status2 = ncSvc_SF_ReadStatus2();

            if( (Status2 & (1<<1)) )
            {
                Status2 &= (~1<<1);
                ncSvc_SF_WriteStatus2(Status1, Status2);
            }
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            if( (Status1 & (1<<6)) )
            {
                Status1 &= ~(1<<6);
                ncSvc_SF_WriteStatus(Status1);
            }
        }
    } 
}


void ncSvc_SF_SetBitRate(UINT32 bitrate)
{
    if(tSF_Info.mQuadMode == TRUE)
        ncLib_QSPI_Ctrl_SetBitRate((UINT32)bitrate);

    ncLib_SSP_Ctrl_SetBitRate(tSF_Info.mSpiCh, bitrate);
}


void ncSvc_SF_WaitWIP(void)
{
    while(ncSvc_SF_ReadStatus() & STS_WIP) ;
}


void ncSvc_SF_WriteEnable(void)
{
    UINT8 Command;

    ncLib_SSP_Ctrl_CsEnable(tSF_Info.mSpiCh);

    Command = CMD_sFLASH_WR_EN;
    ncLib_SSP_Write(tSF_Info.mSpiCh, &Command, 1);	

    ncLib_SSP_Ctrl_CsDisable(tSF_Info.mSpiCh);

    while( (ncSvc_SF_ReadStatus() & STS_WEL) != STS_WEL  ) ;
}


void ncSvc_SF_WriteDisable(void)
{
    UINT8 Command;

    while( ncSvc_SF_ReadStatus() & STS_WIP  ) ;

    ncLib_SSP_Ctrl_CsEnable(tSF_Info.mSpiCh);

    Command = CMD_sFLASH_WR_DS;
    ncLib_SSP_Write(tSF_Info.mSpiCh, &Command, 1);	

    ncLib_SSP_Ctrl_CsDisable(tSF_Info.mSpiCh);
}


UINT8 ncSvc_SF_ReadStatus(void)
{
    UINT8 Command;
    UINT8 Status = 0;

    ncLib_SSP_Ctrl_CsEnable(tSF_Info.mSpiCh);

    Command = CMD_sFLASH_RD_STS;
    ncLib_SSP_Write(tSF_Info.mSpiCh, &Command, 1);	
    ncLib_SSP_Read(tSF_Info.mSpiCh, &Status, 1);	

    ncLib_SSP_Ctrl_CsDisable(tSF_Info.mSpiCh);

    return Status;
}


UINT8 ncSvc_SF_ReadStatus2(void)
{
    UINT8 Command;
    UINT8 Status = 0;

    ncLib_SSP_Ctrl_CsEnable(tSF_Info.mSpiCh);

    Command = CMD_sFLASH_RD_STS2;
    ncLib_SSP_Write(tSF_Info.mSpiCh, &Command, 1);	
    ncLib_SSP_Read(tSF_Info.mSpiCh, &Status, 1);	

    ncLib_SSP_Ctrl_CsDisable(tSF_Info.mSpiCh);

    return Status;
}


void ncSvc_SF_WriteStatus(UINT8 Status)
{
    UINT8 Command[2];

    ncSvc_SF_WriteEnable();

    ncLib_SSP_Ctrl_CsEnable(tSF_Info.mSpiCh);

    Command[0] = CMD_sFLASH_WR_STS;
    Command[1] = Status;
    ncLib_SSP_Write(tSF_Info.mSpiCh, Command, 2);

    ncLib_SSP_Ctrl_CsDisable(tSF_Info.mSpiCh);

    ncSvc_SF_WriteDisable();
}


void ncSvc_SF_WriteStatus2(UINT8 Status1, UINT8 Status2)
{
    UINT8 Command[3];

    ncSvc_SF_WriteEnable();

    ncLib_SSP_Ctrl_CsEnable(tSF_Info.mSpiCh);

    Command[0] = CMD_sFLASH_WR_STS;
    Command[1] = Status1;
    Command[2] = Status2;	
    ncLib_SSP_Write(tSF_Info.mSpiCh, Command, 3);

    ncLib_SSP_Ctrl_CsDisable(tSF_Info.mSpiCh);

    ncSvc_SF_WriteDisable();
}


INT32 ncSvc_SF_ReadDeviceIdentification(ptSFLASH_ID ptsFlashID)
{
    UINT8 Command;

    ncLib_SSP_Ctrl_CsEnable(tSF_Info.mSpiCh);

    Command = CMD_sFLASH_RD_IDENTIFICATION;
    ncLib_SSP_Write(tSF_Info.mSpiCh, &Command, 1);	
    ncLib_SSP_Read(tSF_Info.mSpiCh, (UINT8*)ptsFlashID, 3);		

    ncLib_SSP_Ctrl_CsDisable(tSF_Info.mSpiCh);

    return NC_SUCCESS;
}


INT32 ncSvc_SF_ReadData_DMAMode(UINT8 *pData, UINT32 Size)
{
#ifdef __SUPPORT_DMA_MODE__
    INT32 Ret = NC_SUCCESS;
    
    tDMA_PARAM tDMAParam;
    UINT32 DevRegister;

    eDMA_CH TxCh = DMA_CH0;
    eDMA_CH RxCh = DMA_CH1;
    
    UINT8* pTxSrcBuff   = (UINT8*)&gSF_TxSrcBuff[0];
    UINT8* pTxInstBuff  = (UINT8*)&gSF_TxInstBuff[0];
    UINT8* pRxInstBuff  = (UINT8*)&gSF_RxInstBuff[0];      


    // Set SSP DMA Mode
    ncLib_SSP_Ctrl_SetDMAMode(tSF_Info.mSpiCh, 0);
    
    // Set SPI Data Register
    if(tSF_Info.mSpiCh == SSP_CH0)
        DevRegister = (APACHE_SPI_0_BASE + 0x08);
    else
        DevRegister = (APACHE_SPI_1_BASE + 0x08);


    // Set TxDMA Channel (for dummy clock)
    tDMAParam.mIntEn      = DISABLE;
    tDMAParam.mReqType    = DMA_MEM_TO_DEV;     
    tDMAParam.mPeriNum    = (eDMA_PERI_NUM)(tSF_Info.mSpiCh + DMA_SPI0);
    tDMAParam.mSwap       = DMA_SWAP_NO; 
    tDMAParam.mRxIncrEn   = DISABLE;  
    tDMAParam.mRxBurstLen = 1;  
    tDMAParam.mTxIncrEn   = DISABLE;  
    tDMAParam.mTxBurstLen = 1;  
    tDMAParam.mInstAddr   = (UINT32)pTxInstBuff; 
    Ret |= ncLib_DMA_Ctrl_Init(TxCh, &tDMAParam);

    // Set RxDMA Channel
    tDMAParam.mIntEn      = DISABLE;
    tDMAParam.mReqType    = DMA_DEV_TO_MEM; 
    tDMAParam.mPeriNum    = (eDMA_PERI_NUM)(tSF_Info.mSpiCh + DMA_SPI0);
    tDMAParam.mSwap       = DMA_SWAP_NO; 
    tDMAParam.mRxIncrEn   = DISABLE;  
    tDMAParam.mRxBurstLen = 1;  
    tDMAParam.mTxIncrEn   = ENABLE;  
    tDMAParam.mTxBurstLen = 1;  
    tDMAParam.mInstAddr   = (UINT32)pRxInstBuff; 
    Ret |= ncLib_DMA_Ctrl_Init(RxCh, &tDMAParam);
    
    if(Ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, " - SF DMA Channel Init Error!\n");
    }
    else
    {
        Ret |= ncLib_DMA_Ctrl_Start(RxCh, (UINT32)DevRegister, (UINT32)pData,       Size);
        Ret |= ncLib_DMA_Ctrl_Start(TxCh, (UINT32)pTxSrcBuff,  (UINT32)DevRegister, Size);
        if(Ret == NC_SUCCESS)
        {
            // DMA Done Wait
            while((Ret = ncLib_DMA_Ctrl_CheckDone(TxCh)) == NC_FAILURE)
            {
                if(ncSvc_SF_mTimeOut(SF_DMA_TIME_OUT))
                {
                    DEBUGMSG_SDK(MSGERR, " - SF DMA Tx rTimeOut!~\n");
                    break;
                }
            }
            ncSvc_SF_mTimeOut(0);

            
            // DMA Done Wait
            while((Ret = ncLib_DMA_Ctrl_CheckDone(RxCh)) == NC_FAILURE)
            {
                if(ncSvc_SF_mTimeOut(SF_DMA_TIME_OUT))
                {
                    DEBUGMSG_SDK(MSGERR, " - SF DMA Rx rTimeOut!~\n");
                    break;
                }
            }
            ncSvc_SF_mTimeOut(0);
        }


        // DeInit DMA Channel
        ncLib_DMA_Ctrl_DeInit(RxCh);
        ncLib_DMA_Ctrl_DeInit(TxCh);
    }

    return Ret;
#else
    return NC_FAILURE;
#endif
}


INT32 ncSvc_SF_WriteData_DMAMode(UINT8 *pData, UINT32 Size)
{
#ifdef __SUPPORT_DMA_MODE__
    INT32 Ret = NC_SUCCESS;

    tDMA_PARAM tDMAParam;
    UINT32 DevRegister;

    eDMA_CH TxCh = DMA_CH0;
    
    UINT8* pTxInstBuff  = (UINT8*)&gSF_TxInstBuff[0];   


    // Set SSP DMA Mode
    ncLib_SSP_Ctrl_SetDMAMode(tSF_Info.mSpiCh, 1);

    // Set SPI Data Register
    if(tSF_Info.mSpiCh == SSP_CH0)
        DevRegister = (APACHE_SPI_0_BASE + 0x08);
    else
        DevRegister = (APACHE_SPI_1_BASE + 0x08);


    // Init DMA Channel
    tDMAParam.mIntEn      = DISABLE;
    tDMAParam.mReqType    = DMA_MEM_TO_DEV; 
    tDMAParam.mPeriNum    = (eDMA_PERI_NUM)(tSF_Info.mSpiCh + DMA_SPI0);
    tDMAParam.mSwap       = DMA_SWAP_NO; 
    tDMAParam.mRxIncrEn   = ENABLE;  
    tDMAParam.mRxBurstLen = 1;  
    tDMAParam.mTxIncrEn   = DISABLE;  
    tDMAParam.mTxBurstLen = 1;  
    tDMAParam.mInstAddr   = (UINT32)pTxInstBuff; 
    
    Ret = ncLib_DMA_Ctrl_Init(TxCh, &tDMAParam);
    if(Ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, " - SF DMA Channel Init Error!\n");
    }
    else
    {
        // Run Data Transfer
        Ret = ncLib_DMA_Ctrl_Start(TxCh, (UINT32)pData, (UINT32)DevRegister, Size);
        if(Ret == NC_SUCCESS)
        {
            // DMA Done Wait
            while((Ret = ncLib_DMA_Ctrl_CheckDone(TxCh)) == NC_FAILURE)
            {
                if(ncSvc_SF_mTimeOut(SF_DMA_TIME_OUT))
                {
                    DEBUGMSG_SDK(MSGERR, " - SF DMA Tx wTimeOut!~\n");
                    break;
                }
            }
            ncSvc_SF_mTimeOut(0);
        }
        
        // DeInit DMA Channel
        ncLib_DMA_Ctrl_DeInit(TxCh);
    }

    return Ret;
#else
    return NC_FAILURE;
#endif
}


INT32 ncSvc_SF_ReadData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    INT32 Ret = NC_SUCCESS;
    UINT8 Command[4];


    if((tSF_Info.mQuadMode == TRUE) && !(Size%8))   // Quad SPI 64bit Align      
    {   
        Ret = ncLib_QSPI_Read(Addr, (UINT8 *)pData, Size);
    }
    else
    {
        ncLib_SSP_Ctrl_CsEnable(tSF_Info.mSpiCh);

        Command[0] = CMD_sFLASH_RD_DATA;
        Command[1] = (Addr>>16 & 0xFF);
        Command[2] = (Addr>>8  & 0xFF);
        Command[3] = (Addr     & 0xFF);
        ncLib_SSP_Write(tSF_Info.mSpiCh, Command, 4);	
        if((tSF_Info.mDmaMode == TRUE) && (Size>16) && (Size<(16*KB)))
            Ret = ncSvc_SF_ReadData_DMAMode(pData, Size);
        else
            Ret = ncLib_SSP_Read(tSF_Info.mSpiCh, pData, Size);	

        ncLib_SSP_Ctrl_CsDisable(tSF_Info.mSpiCh);
    }

    return Ret;
}


INT32 ncSvc_SF_WriteData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();

    ncLib_SSP_Ctrl_CsEnable(tSF_Info.mSpiCh);

    Command[0] = CMD_sFLASH_PAGE_PROGRAM;
    Command[1] = (Addr>>16 & 0xFF);
    Command[2] = (Addr>>8  & 0xFF);
    Command[3] = (Addr     & 0xFF);
    ncLib_SSP_Write(tSF_Info.mSpiCh, Command, 4);	
    if((tSF_Info.mDmaMode == TRUE) && (Size>16) && (Size<(16*KB)))
        ncSvc_SF_WriteData_DMAMode(pData, Size);
    else
        ncLib_SSP_Write(tSF_Info.mSpiCh, pData, Size);

    ncLib_SSP_Ctrl_CsDisable(tSF_Info.mSpiCh);

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}


INT32 ncSvc_SF_SectorErase(UINT32 PageAddr)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();

    ncLib_SSP_Ctrl_CsEnable(tSF_Info.mSpiCh);

    Command[0] = CMD_sFLASH_SECTOR_ERASE;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);
    ncLib_SSP_Write(tSF_Info.mSpiCh, Command, 4);	

    ncLib_SSP_Ctrl_CsDisable(tSF_Info.mSpiCh);

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}


INT32 ncSvc_SF_BlockErase(UINT32 PageAddr)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();

    ncLib_SSP_Ctrl_CsEnable(tSF_Info.mSpiCh);

    Command[0] = CMD_sFLASH_BLOCK_ERASE;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);
    ncLib_SSP_Write(tSF_Info.mSpiCh, Command, 4);	

    ncLib_SSP_Ctrl_CsDisable(tSF_Info.mSpiCh);

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}


void ncSvc_SF_EnableWP(BOOL OnOff)
{
    tSFLASH_ID tsFlashID;
    UINT8 Status1;
    UINT8 Status2;
    UINT8 protection = BP3|BP2|BP1|BP0;

    ncSvc_SF_ReadDeviceIdentification(&tsFlashID);

    if(OnOff)
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            protection = (BP2|BP1|BP0);
            Status1 = ncSvc_SF_ReadStatus();
            Status2 = ncSvc_SF_ReadStatus2();
            Status1 |= protection;
            ncSvc_SF_WriteStatus2(Status1, Status2);
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status1 |= protection;
            ncSvc_SF_WriteStatus(Status1);
        }
    }
    else
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            protection = (BP2|BP1|BP0);
            Status1 = ncSvc_SF_ReadStatus();
            Status2 = ncSvc_SF_ReadStatus2();
            Status1 &= ~(protection);
            ncSvc_SF_WriteStatus2(Status1, Status2);
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status1 &= ~(protection);
            ncSvc_SF_WriteStatus(Status1);
        }
    }
}


INT32 ncSvc_SF_DeInit(void)
{
    INT32 Ret;


    // Deinit DMA
    if(tSF_Info.mDmaMode == TRUE)
        ncLib_DMA_Close();


    // Deinit QSPI 
    if(tSF_Info.mQuadMode == TRUE)
    {
        ncSvc_SF_QSPIEnable(FALSE);
        ncLib_QSPI_Close();
    }


    // Deinit SSP Channel
    Ret = ncLib_SSP_Ctrl_DeInit(tSF_Info.mSpiCh);
    if(Ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, "SSP DeInit Error!\n");
    }


    // Close SSP Interface
    ncLib_SSP_Close();


    return NC_SUCCESS;
}


INT32 ncSvc_SF_Init(ptSF_PARAM ptSFParam)
{
    INT32 Ret;
    tSSP_PARAM tSSPParam;


    // Open SSP
    ncLib_SSP_Open();	



    // Set SSP Channel Operation 
    tSSPParam.mIntEn     = FALSE;   
    tSSPParam.mMode      = SSP_MODE_MASTER;
    tSSPParam.mDataWidth = SSP_DS_8BIT;
    tSSPParam.mBitRate   = ptSFParam->mBitRate;
    tSSPParam.mSPO       = SSP_SPO_HIGH;
    tSSPParam.mSPH       = SSP_SPH_HIGH;
    tSSPParam.mOrder     = SSP_MSB_FIRST;

    Ret = ncLib_SSP_Ctrl_Init(ptSFParam->mSpiCh, &tSSPParam);
    if(Ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, "SSP Init Error!\n");
    }
    else
    {
        #ifndef __SUPPORT_DMA_MODE__
            ptSFParam->mDmaMode = FALSE;
        #endif


        // Copy sFlash Ctrl Info.
        tSF_Info = *ptSFParam;


        // Init Dma Interface 
        if(tSF_Info.mDmaMode == TRUE)
            ncLib_DMA_Open();
            

        // Init Quad Interface 
        if(tSF_Info.mQuadMode == TRUE)
        {
            ncLib_QSPI_Open();        
            ncLib_QSPI_Ctrl_SetBitRate((UINT32)tSF_Info.mBitRate);
        }

        // Set Sflash QSPI Mode
        ncSvc_SF_QSPIEnable(tSF_Info.mQuadMode);
        if(tSF_Info.mQuadMode == FALSE)
            ptSFParam->mQuadMode = FALSE;
    }
    
    return Ret;
}


/* End Of File */

