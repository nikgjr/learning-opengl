/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SFLASH_LIB_H__
#define __SFLASH_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define MEMORY_CAPACITY_512Kb                   0x00
#define MEMORY_CAPACITY_1Mb                     0x01
#define MEMORY_CAPACITY_2Mb                     0x02
#define MEMORY_CAPACITY_4Mb                     0x03
#define MEMORY_CAPACITY_8Mb                     0x04
#define MEMORY_CAPACITY_16Mb                    0x05
#define MEMORY_CAPACITY_32Mb                    0x06
#define MEMORY_CAPACITY_64Mb                    0x07
#define MEMORY_CAPACITY_128Mb                   0x08

#define SF_BLOCK_SIZE                           (64*KB)
#define SF_SECTOR_SIZE                          (4*KB)
#define SF_PAGE_SIZE                            (256)










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

#if 0 // MISRA_C_2014_Rule 17.1
/*
* SF GENERIC & SPECIFIC COMMANDS
*/

typedef enum _SF_CMD
{
    /*
    * Generic Serial Flash Commands
    */
    GCMD_SF_DUMMY = 0,

    GCMD_SF_INIT,
    GCMD_SF_DEINIT,
    GCMD_SF_SET_BITRATE,
    GCMD_SF_BLOCK_ERASE,
    GCMD_SF_SECTOR_ERASE,
    GCMD_SF_READ_ID,
    GCMD_SF_READ_STATUS,
    GCMD_SF_WRTIE_STATUS,
    GCMD_SF_READ_STATUS2,
    GCMD_SF_WRITE_STATUS2,
    GCMD_SF_WAIT_WIP,
    GCMD_SF_WRITE_EN,
    GCMD_SF_WRITE_DS,
    GCMD_SF_ENABLE_WP,
    
    GCMD_SF_MAX,

    /*
    * Specific Serial Flash Commands
    */
    SCMD_SF_OSG_READ_EN = 100,
    SCMD_SF_OSG_READ_DS,	
    SCMD_SF_OSG_READ_DATA,
    SCMD_SF_LUT_READ_DATA,
    SCMD_SF_GET_PAD_CTRL,
    SCMD_SF_FREE_PAD_CTRL,
    SCMD_SF_MAX,
} eSF_CMD;
#endif









/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tSF_PARAM
{
    eSSP_CH mSpiCh;                 // SPI Channel Number
    BOOL    mDmaMode;               // 0: Off, 1: On
    BOOL    mQuadMode;              // 0: Standard SPI, 1: Quad SPI
    UINT32  mBitRate;               // Hz
} tSF_PARAM, *ptSF_PARAM;


typedef struct _tSFLASH_ID {
    UINT8   mbManufacture;          // Manufacture ID
    UINT8   mbMemoryType;           // Memory Type
    UINT8   mbMemoryCapacity;       // Memory Capacity
} tSFLASH_ID, *ptSFLASH_ID;










/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32  ncLib_SF_Open(void);
extern INT32  ncLib_SF_Close(void);
extern INT32  ncLib_SF_Read(UINT32 Addr, UINT8 *pData, UINT32 Size);
extern INT32  ncLib_SF_Write(UINT32 Addr, UINT8 *pData, UINT32 Size);
#if 0 // MISRA_C_2014_Rule 17.1
extern INT32  ncLib_SF_Control(eSF_CMD Cmd, ...);
#else
extern INT32  ncLib_SF_Ctrl_Init(ptSF_PARAM ptSFParam);
extern INT32  ncLib_SF_Ctrl_DeInit(void);
extern INT32  ncLib_SF_Ctrl_SetBitRate(UINT32 Bitrate);
extern INT32  ncLib_SF_Ctrl_BlockErase(UINT32 PageAddr);
extern INT32  ncLib_SF_Ctrl_SectorErase(UINT32 PageAddr);
extern INT32  ncLib_SF_Ctrl_ReadID(ptSFLASH_ID ptsFlashID);
extern UINT8  ncLib_SF_Ctrl_ReadStatus(void);
extern UINT8  ncLib_SF_Ctrl_ReadStatus2(void);
extern INT32  ncLib_SF_Ctrl_WriteStatus(UINT8 Status);
extern INT32  ncLib_SF_Ctrl_WriteStatus2(UINT8 Status1, UINT8 Status2);
extern INT32  ncLib_SF_Ctrl_WaitWIP(void);
extern INT32  ncLib_SF_Ctrl_WriteEnable(void);
extern INT32  ncLib_SF_Ctrl_WriteDisable(void);
extern INT32  ncLib_SF_Ctrl_EnableWP(BOOL OnOff);
extern INT32  ncLib_SF_Ctrl_OSGReadEnable(void);
extern INT32  ncLib_SF_Ctrl_OSGReadDisable(void);
extern INT32  ncLib_SF_Ctrl_OSGReadData(UINT32 Addr, UINT32 BuffAddr, UINT32 Size);
extern INT32  ncLib_SF_Ctrl_LUTReadData(UINT32 Addr, UINT8 *pData, UINT32 Size);
extern INT32  ncLib_SF_Ctrl_GetPad(void);
extern INT32  ncLib_SF_Ctrl_FreePad(void);
#endif


#endif /* __SFLASH_LIB_H__ */


/* End Of File */

