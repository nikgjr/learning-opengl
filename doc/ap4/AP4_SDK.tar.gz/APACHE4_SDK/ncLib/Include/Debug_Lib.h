/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __DEBUG_LIB__
#define __DEBUG_LIB__


/*
********************************************************************************
*               INCLUDE                                    
********************************************************************************
*/

#include "Uart_Lib.h"










/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

//------------------------------------------------------------------------
// Debug Log Zone
//------------------------------------------------------------------------
#define MSGPOS				4

#define MSGERR				(0x1<<0)	// Error message enable
#define MSGWARN				(0x1<<1)	// Warning message enable
#define MSGINFO				(0x1<<2)	// Information message enable
#define MSGOFF				(0x0<<0)
#define MSGFULL				(MSGINFO|MSGWARN|MSGERR)





//------------------------------------------------------------------------
// Re-define debug functions for all log level
//------------------------------------------------------------------------

// Used in application layer
#define DEBUGMSG(zone, fmt, args...)  \
        do { if(zone) ncLib_DEBUG_Printf(zone, fmt, ## args); } while(0)

// Used in SDK layer
#define DEBUGMSG_SDK(zone, fmt, args...)  \
        do { if(zone<<MSGPOS) ncLib_DEBUG_Printf(zone<<MSGPOS, fmt, ## args); } while(0)

#define DBGSCANF(msg)   ncLib_DEBUG_Scanf(msg)





//------------------------------------------------------------------------
// ETC
//------------------------------------------------------------------------
#define STR_CLEAR_SCREEN        "\033[2J"
#define STR_MOVE_CURSOR_LEFT    "\033[1D"
#define STR_MOVE_CURSOR_LEFT4   "\033[4D"

#define STR_COLOR_RED_ON        "\033[1;31m"
#define STR_COLOR_GREEN_ON      "\033[1;32m"
#define STR_COLOR_YELLOW_ON     "\033[1;33m"
#define STR_COLOR_BLUE_ON       "\033[1;34m"
#define STR_COLOR_MAGENTA_ON    "\033[1;35m"
#define STR_COLOR_CYAN_ON       "\033[1;36m"
#define STR_COLOR_OFF           "\033[0m"










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

#if 0 // MISRA_C_2014_Rule 17.1
/*
* DEBUG GENERIC & SPECIFIC COMMANDS
*/

typedef enum _DBG_CMD
{
    /*
    * Generic Commands
    */

    GCMD_DBG_INIT = 0,
    GCMD_DBG_DEINIT,
    GCMD_DBG_APP_LOG_ZONE,
    GCMD_DBG_SDK_LOG_ZONE,

    GCMD_DBG_MAX
} eDBG_CMD;
#endif










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_DEBUG_Open(void);
extern INT32 ncLib_DEBUG_Close(void);
extern INT32 ncLib_DEBUG_Read(void);
extern INT32 ncLib_DEBUG_Write(void);
#if 0 // MISRA_C_2014_Rule 17.1
extern INT32 ncLib_DEBUG_Control(eDBG_CMD Cmd, ...);
#else
extern INT32 ncLib_DEBUG_Ctrl_Init(eUART_CH Ch, eUART_BAUDRATE BaudRate);
extern INT32 ncLib_DEBUG_Ctrl_DeInit(void);
extern INT32 ncLib_DEBUG_Ctrl_SetAppZone(UINT32 Zone, UINT32 Enable);
extern INT32 ncLib_DEBUG_Ctrl_SetSdkZone(UINT32 Zone, UINT32 Enable);
#endif

// Debug Message Library
extern void   ncLib_DEBUG_Printf(UINT32 DebugZone, const char *fmt, ...);
extern UINT32 ncLib_DEBUG_Scanf(char *buf);


#endif  /* __DEBUG_LIB__ */


/* End Of File */

