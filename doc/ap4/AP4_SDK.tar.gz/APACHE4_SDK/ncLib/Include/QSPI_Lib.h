/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __QSPI_LIB_H__
#define __QSPI_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

#if 0 // MISRA_C_2014_Rule 17.1
/*
* QSPI GENERIC & SPECIFIC COMMANDS
*/

typedef enum _QSPI_CMD
{
    /*
    * Generic Commands
    */
    
    GCMD_QSPI_INIT = 0,
    GCMD_QSPI_DEINIT,
    GCMD_QSPI_SET_BITRATE,
    GCMD_QSPI_LUT_READ,
    GCMD_QSPI_OSG_READ,

    GCMD_QSPI_MAX

} eQSPI_CMD;
#endif

typedef enum
{
    QSPI_OSG_DIRECT = (1<<0),
    QSPI_OSG_APB    = (1<<1),
    MAX_OF_QSPI_OSG
} eQSPI_OSG;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32  ncLib_QSPI_Open(void);
extern INT32  ncLib_QSPI_Close(void);
extern INT32  ncLib_QSPI_Read(UINT32 Addr, UINT8 *pBuff, UINT32 nLength);
extern INT32  ncLib_QSPI_Write(UINT32 Addr, UINT8 *pBuff, UINT32 nLength);
#if 0 // MISRA_C_2014_Rule 17.1
extern INT32  ncLib_QSPI_Control(eQSPI_CMD Cmd, ...);
#else
extern INT32  ncLib_QSPI_Ctrl_Init(void);
extern INT32  ncLib_QSPI_Ctrl_DeInit(void);
extern INT32  ncLib_QSPI_Ctrl_SetBitRate(UINT32 Bitrate);
extern INT32  ncLib_QSPI_Ctrl_LUTRead(UINT32 Addr, UINT8 *pBuff, UINT32 Size);
extern INT32  ncLib_QSPI_Ctrl_OSGRead(eQSPI_OSG DN_Mode, UINT32 Addr, UINT32 BuffAddr, UINT32 Size);
#endif


#endif /* __QSPI_LIB_H__ */


/* End Of File */

