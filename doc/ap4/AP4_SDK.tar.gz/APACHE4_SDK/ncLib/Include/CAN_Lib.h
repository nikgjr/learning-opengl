/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __CAN_LIB_H__
#define __CAN_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

#if 0 // MISRA_C_2014_Rule 17.1
/*
* CAN GENERIC & SPECIFIC COMMANDS
*/

typedef enum _CAN_CMD
{
    /*
    * Generic Commands
    */

    GCMD_CAN_INIT = 0,
    GCMD_CAN_DEINIT,
    
    GCMD_CAN_MAX,
    
} eCAN_CMD;
#endif










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_CAN_Open(void);
extern INT32 ncLib_CAN_Close(void);
extern INT32 ncLib_CAN_Read(void);
extern INT32 ncLib_CAN_Write(void);
#if 0 // MISRA_C_2014_Rule 17.1
extern INT32 ncLib_CAN_Control(eCAN_CMD Cmd, ...);
#else

#endif

#endif /* __CAN_LIB_H__ */


/* End Of File */

