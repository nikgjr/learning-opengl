/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : INTC_Lib.h
*
*  @brief   :
*
*  @author  :
*
*  @date    : 2018.01.15
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __INTC_LIB_H__
#define __INTC_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

//#define DEF_INTC_TRIGGER_LEVEL      TRIG_HIGH_LEVEL
#define DEF_INTC_PRIORITY_LEVEL     240










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

#if 0 // MISRA_C_2014_Rule 17.1
/*
* INTC GENERIC & SPECIFIC COMMANDS
*/

typedef enum
{
	GCMD_INTC_REGISTER_INT = 0,
	GCMD_INTC_UNREGISTER_INT,
	GCMD_INTC_SGI_TRIGGER,

	GCMD_INTC_ENABLE_INT,
	GCMD_INTC_DISABLE_INT,
    //GCMD_INTC_SET_PRIORITY_LEVEL,
	GCMD_INTC_GET_GICID,

	GCMD_INTC_MAX
} eINTC_CMD;
#endif


#if 0
typedef enum
{
	TRIG_LEVEL_HIGH = 0,
	TRIG_LEVEL_LOW,
	TRIG_EDGE_HIGH,
	TRIG_EDGE_LOW,
	TRIG_EDGE_BOTH
} eTRIG_MODE;
#endif

typedef enum
{
    CPU_DCLS = 0,
    CPU_RESERVED,
    CPU_SINGLE,
    CPU_DSP,

    MAX_OF_CPU_ID
} eCPU_ID;

typedef enum
{
    IRQ_NUM_NULL = 0,

    IRQ_NUM_SGI_0 = IRQ_NUM_NULL,
    IRQ_NUM_SGI_1,
    IRQ_NUM_SGI_2,   
    IRQ_NUM_SGI_3,
    IRQ_NUM_SGI_MAX,

    // A = 0 group
    IRQ_NUM_TIMER0 = 32,    // (A+ 0)
    IRQ_NUM_TIMER1,         // (A+ 1)
    IRQ_NUM_TIMER2,         // (A+ 2)
    IRQ_NUM_TIMER3,         // (A+ 3)
    IRQ_NUM_TIMER4,         // (A+ 4)
    IRQ_NUM_TIMER5,         // (A+ 5)
    IRQ_NUM_TIMER6,         // (A+ 6)
    IRQ_NUM_TIMER7,         // (A+ 7)
    IRQ_NUM_UART0,          // (A+ 8)
    IRQ_NUM_UART1,          // (A+ 9)
    IRQ_NUM_UART2,          // (A+10)
    IRQ_NUM_UART3,          // (A+11)
    IRQ_NUM_I2C0,           // (A+12)
    IRQ_NUM_I2C1,           // (A+13)
    IRQ_NUM_SPI0,           // (A+14)
    IRQ_NUM_SPI1,           // (A+15)
    IRQ_NUM_QSPI,           // (A+16)
    IRQ_NUM_DMA0,           // (A+17)
    IRQ_NUM_DMA1,           // (A+18)
    IRQ_NUM_DMA2,           // (A+19)
    IRQ_NUM_DMA3,           // (A+20)
    IRQ_NUM_PWM0,           // (A+21)
    IRQ_NUM_PWM1,           // (A+22)
    IRQ_NUM_PWM3,           // (A+23)
    IRQ_NUM_PWM4,           // (A+24)
    IRQ_NUM_GPIO0,          // (A+25)
    IRQ_NUM_GPIO1,          // (A+26)
    IRQ_NUM_GPIO2,          // (A+27)
    IRQ_NUM_FMC,            // (A+28)
    IRQ_NUM_SDC,            // (A+29)
    IRQ_NUM_CAN0,           // (A+30)
    IRQ_NUM_CAN1,           // (A+31)

    // B = 32 group
    IRQ_NUM_ISP0 = 64,      // (A+32)
    IRQ_NUM_ISP1,           // (A+33)
    IRQ_NUM_ISP2,           // (A+34)
    IRQ_NUM_ISP3,           // (A+35)
    IRQ_NUM_ISP4,           // (A+36)
    IRQ_NUM_ISP5,           // (A+37)
    IRQ_NUM_ISP6,           // (A+38)
    IRQ_NUM_ISP7,           // (A+39)
    IRQ_NUM_ISP8,           // (A+40)
    IRQ_NUM_ISP9,           // (A+41)
    IRQ_NUM_VDUMP,          // (A+42)
    IRQ_NUM_REV43,          // (A+43)
    IRQ_NUM_REV44,          // (A+44)
    IRQ_NUM_REV45,          // (A+45)
    IRQ_NUM_REV46,          // (A+46)
    IRQ_NUM_REV47,          // (A+47)
    IRQ_NUM_ADAS0,          // (A+48)
    IRQ_NUM_ADAS1,          // (A+49)
    IRQ_NUM_ADAS2,          // (A+50)
    IRQ_NUM_ADAS3,          // (A+51)
    IRQ_NUM_ADAS4,          // (A+52)
    IRQ_NUM_REV53,          // (A+53)
    IRQ_NUM_REV54,          // (A+54)
    IRQ_NUM_FAULT_SCU,      // (A+55)
    IRQ_NUM_FAULT_APRB,     // (A+56)
    IRQ_NUM_FAULT_CPRB,     // (A+57)
    IRQ_NUM_FAULT_LFT,      // (A+58)
    IRQ_NUM_FAULT_MFT,      // (A+59)
    IRQ_NUM_FAULT_PLATFORM, // (A+60)
    IRQ_NUM_FAULT_ISP,      // (A+61)
    IRQ_NUM_FAULT_RE,       // (A+62)
    IRQ_NUM_FAULT,          // (A+63)

    IRQ_NUM_IPC0,           // (A+64)
    IRQ_NUM_IPC1,           // (A+65)
    IRQ_NUM_IPC2,           // (A+66)
    IRQ_NUM_REV67,          // (A+67)
    IRQ_NUM_REV68,          // (A+68)
    IRQ_NUM_REV69,          // (A+69)
    IRQ_NUM_REV70,          // (A+70)
    IRQ_NUM_REV71,          // (A+71)
    IRQ_NUM_REV72,          // (A+72)
    IRQ_NUM_REV73,          // (A+73)   
    IRQ_NUM_REV74,          // (A+74)   
    IRQ_NUM_REV75,          // (A+75)
    IRQ_NUM_REV76,          // (A+76)
    IRQ_NUM_REV77,          // (A+77)
    IRQ_NUM_REV78,          // (A+78)   
    IRQ_NUM_REV79,          // (A+79)   
    IRQ_NUM_REV80,          // (A+80)
    IRQ_NUM_REV81,          // (A+81)
    IRQ_NUM_REV82,          // (A+82)
    IRQ_NUM_REV83,          // (A+83)   
    IRQ_NUM_REV84,          // (A+84)   
    IRQ_NUM_REV85,          // (A+85)
    IRQ_NUM_REV86,          // (A+86)
    IRQ_NUM_REV87,          // (A+87)
    IRQ_NUM_REV88,          // (A+88)   
    IRQ_NUM_REV89,          // (A+89) 
    IRQ_NUM_REV90,          // (A+90)
    IRQ_NUM_REV91,          // (A+91)
    IRQ_NUM_REV92,          // (A+92)
    IRQ_NUM_REV93,          // (A+93)   
    IRQ_NUM_REV94,          // (A+94)   
    IRQ_NUM_REV95,          // (A+95)

    MAX_IRQ_NUM,

    FIQ_NUM_NULL = MAX_IRQ_NUM,

    MAX_FIQ_NUM
} eINT_NUM;










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT32 Dist_PeriID0;
    UINT32 Dist_PeriID4;
    UINT32 Dist_CompID;
    UINT32 CPU_IdentID;

} tGIC_ID;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32  ncLib_INTC_Open(void);
extern INT32  ncLib_INTC_Close(void);
extern INT32  ncLib_INTC_Read(void);
extern INT32  ncLib_INTC_Write(void);
#if 0 // MISRA_C_2014_Rule 17.1
extern INT32  ncLib_INTC_Control(eINTC_CMD Cmd, ...);
#else
extern INT32 ncLib_INTC_Ctrl_RegisterHandler(UINT32 nIntNum, PrHandler pHandler);
extern INT32 ncLib_INTC_Ctrl_UnRegisterHandler(UINT32 nIntNum);
extern INT32 ncLib_INTC_Ctrl_GetGicId(tGIC_ID *Gic);
#endif

extern void   ncLib_INTC_IrqHandler(void);
extern void   ncLib_INTC_FiqHandler(void);


#endif /* __INTC_LIB_H__ */


/* End Of File */

