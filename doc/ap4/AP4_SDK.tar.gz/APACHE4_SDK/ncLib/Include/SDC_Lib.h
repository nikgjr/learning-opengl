/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SDC_LIB_H__
#define __SDC_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

#if 0 // MISRA_C_2014_Rule 17.1
/*
* NAND GENERIC & SPECIFIC COMMANDS
*/

typedef enum _SDC_CMD
{
    /*
    * Generic Commands
    */

    GCMD_SDC_INIT = 0,
    GCMD_SDC_DEINIT,
    
    GCMD_SDC_MAX,
    
} eSDC_CMD;
#endif









/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_SDC_Open(void);
extern INT32 ncLib_SDC_Close(void);
extern INT32 ncLib_SDC_Read(void);
extern INT32 ncLib_SDC_Write(void);
#if 0 // MISRA_C_2014_Rule 17.1
extern INT32 ncLib_SDC_Control(eSDC_CMD Cmd, ...);
#else
extern INT32 ncLib_SDC_Ctrl_Init(void);
extern INT32 ncLib_SDC_Ctrl_DeInit(void);
#endif

#endif /* __SDC_LIB_H__ */


/* End Of File */

