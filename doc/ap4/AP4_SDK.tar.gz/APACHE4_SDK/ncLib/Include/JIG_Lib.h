/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __JIG_LIB_H__
#define __JIG_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define JIGMSG(fmt, args...)  ncLib_JIG_Printf(fmt, ## args)










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

#if 0 // MISRA_C_2014_Rule 17.1
/*
* JIG GENERIC & SPECIFIC COMMANDS
*/

typedef enum
{
    /*
    * Generic Commands
    */
    GCMD_JIG_INIT = 0,
    GCMD_JIG_DEINIT,

    GCMD_JIG_DO_COMMAND,

    GCMD_JIG_MAX

} eJIG_CMD;
#endif










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_JIG_Open(void);
extern INT32 ncLib_JIG_Close(void);
extern INT32 ncLib_JIG_Read(void);
extern INT32 ncLib_JIG_Write(void);
#if 0 // MISRA_C_2014_Rule 17.1
extern INT32 ncLib_JIG_Control(eJIG_CMD Cmd, ...);
#else
extern INT32 ncLib_JIG_Ctrl_Init(eUART_CH Ch, eUART_BAUDRATE BaudRate);
extern INT32 ncLib_JIG_Ctrl_DeInit(void);
extern INT32 ncLib_JIG_Ctrl_RunCommand(void);
#endif

extern void ncLib_JIG_Printf(const char *fmt, ...);


#endif  /* __JIG_LIB_H__ */


/* End Of File */

