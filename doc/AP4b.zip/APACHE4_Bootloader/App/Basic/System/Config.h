/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  :
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __CONFIG_H__
#define __CONFIG_H__


/*
********************************************************************************
*               USER SELECTION AREA
********************************************************************************
*/


#define __FPGA_MODE__ 
#define __UART_ENABLE__
#define __DMA_ENABLE__


//#define __BL2_DDR_ENABLE__
//#define __BL2_INTC_ENABLE__


// for only test  (IRQ/FIQ in BL2)
//#define __BL2_TIMER_ENABLE__


#endif  /* __CONFIG_H__ */


/* End Of File */

