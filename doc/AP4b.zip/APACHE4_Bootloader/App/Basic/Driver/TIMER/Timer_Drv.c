/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#ifdef __BL2_TIMER_ENABLE__









/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static UINT32 rTIMER_ADDR(eTIMER_CH Ch)
{
    return (APACHE_TIMER0_BASE + ((Ch)*(0x20)));
}


INT32 ncDrv_TIMER_GetIntSts(eTIMER_CH Ch)
{
    UINT32 Reg;    

    Reg = REGRW32(rTIMER_ADDR(Ch), rTIMER_CSR);
    Reg |= (1<<5);
    REGRW32(rTIMER_ADDR(Ch), rTIMER_CSR) = Reg;
    
    return ((Reg>>12)&0xF);
}


void ncDrv_TIMER_ReLoad(eTIMER_CH Ch)
{
    UINT32 Reg;

    Reg = REGRW32(rTIMER_ADDR(Ch), rTIMER_CSR);
    Reg |= (1<<4);
    REGRW32(rTIMER_ADDR(Ch), rTIMER_CSR) = Reg;
}


void ncDrv_TIMER_Start(eTIMER_CH Ch)
{
    UINT32 Reg;

    Reg = REGRW32(rTIMER_ADDR(Ch), rTIMER_CSR);
    Reg |= (1<<0);
    REGRW32(rTIMER_ADDR(Ch), rTIMER_CSR) = Reg;
}


void ncDrv_TIMER_Stop(eTIMER_CH Ch)
{  
    UINT32 Reg;

    Reg = REGRW32(rTIMER_ADDR(Ch), rTIMER_CSR);
    Reg &= ~(1<<0);
    REGRW32(rTIMER_ADDR(Ch), rTIMER_CSR) = Reg;
}


INT32 ncDrv_TIMER_Init(eTIMER_CH Ch, ptTIMER_PARAM ptTIMER, UINT32 RefClk)
{
    UINT32  Reg = 0;

    UINT32	Usec;
    UINT32	TimerMatch;
    FP32 	TimerClk;
    FP32	TimerPeriod;


    ncDrv_TIMER_Stop(Ch);
    
    // Set Timer mode       
    if(ptTIMER->mMode == TC_MODE_PERIOD)
    {
        Reg |= (1<<1);
    }
    else if(ptTIMER->mMode == TC_MODE_ONESHOT)
    {
        Reg |= (0<<1);
    }
    else if(ptTIMER->mMode == TC_MODE_WDT)
    {
        Reg |= (1<<2);
    }
    else
    {
        return NC_FAILURE;
    }

    // Intc Enable
    Reg |= (1<<5)|(1<<8);

    
    // write command
    REGRW32(rTIMER_ADDR(Ch), rTIMER_CSR) = Reg;


    // Set PreScaler
    REGRW32(rTIMER_ADDR(Ch), rTIMER_PRESCALER) = ptTIMER->mPrescaler;
    

    // defense code  
    if(ptTIMER->mPeriod1 < 10)
        ptTIMER->mPeriod1 = 10;

    // Gen Time Tick.    
    Usec 		= ptTIMER->mPeriod1;
    TimerClk    = RefClk / (ptTIMER->mPrescaler+1);
    TimerPeriod = (1/TimerClk)*1000000;	
    TimerMatch  = (Usec/TimerPeriod);	


    // write periodic_load value
    REGRW32(rTIMER_ADDR(Ch), rTIMER_LOAD) = TimerMatch;

    
    return NC_SUCCESS;
}


#endif  /* __BL2_TIMER_ENABLE__ */


/* End Of File */

