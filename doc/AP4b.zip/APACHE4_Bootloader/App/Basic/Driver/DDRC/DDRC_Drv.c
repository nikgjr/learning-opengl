/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#ifdef __BL2_DDR_ENABLE__








/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define NCA4_LPDDR3_MODEL

#ifdef    NCA4_DDR3_MODEL
  #define      DDR3_MODEL        1
#else  
  #define      DDR3_MODEL        0
#endif 

#ifdef    NCA4_LPDDR3_MODEL
  #define      LPDDR3_MODEL      1
#else  
  #define      LPDDR3_MODEL      0
#endif 

#if         DDR3_MODEL
    #define     tRFCPB 110        
    #define     tREFIPB 0.4875    //
    #define     tREFI  3.9        //
    #define     tRFC   110       
    #define     tRRD   7.5         
    #define     tRP    13.75         
    #define     tRCD   13.75         
    #define     tRAS   35         
    #define     tWTR   7.5        
    #define     tWR    15         
    #define     tRTP   7.5        
    #define     tFAW   40         
    #define     tXSR   0.512     // tXSDLL       
    #define     tXP    24        // tXPDLL        
    #define     tRC    48.75         
    #define     tDQSCK 0.255        
#elif        LPDDR3_MODEL
    #define     tRFCPB 110        
    #define     tREFIPB 0.4875    
    #define     tREFI  3.9        
    #define     tRFC   130         // 130 + 0
    #define     tRRD   10          // 10  * 1
    #define     tRP    21          // 21  * 2
    #define     tRCD   18          // 18  * 2
    #define     tRAS   42          // 42  * 1
    #define     tWTR   7.5         // 7.5 * 3
    #define     tWR    15          // 15  * 1
    #define     tRTP   7.5         // 7.5 * 1
    #define     tFAW   50          // 50  * 1
    #define     tXSR   140         // 140 + 20
    #define     tXP    7.5         // 7.5 * 3
    #define     tRC    63          // tRAS + tRP
    #define     tDQSCK 5.5         // 5.5 * 3
#endif  //  DDR_MODEL







extern void  ncLib_DPHY_init(UINT32 md, UINT32 wl, UINT32 bl, UINT32 rl);
extern INT32 ncLib_DREX0_dfi_init(void);
extern INT32 ncLib_DREX0_cg_ctrl(UINT32 cg_en);
extern void  ncLib_DREX0_fp_resync(void);
extern void  ncLib_DREX0_phy_control(UINT32 ctrl_shgate,UINT32 ctrl_pd,UINT32 rec_gate_cyc,UINT32 pause_resync_en,UINT32 dqs_delay,UINT32 fp_resync,UINT32 sl_dln_con,UINT32 gen_read_gate);
extern void  ncLib_DREX0_mem_control(UINT32 pb_ref_en, UINT32 bl, UINT32 mem_type, UINT32 add_lat_pall, UINT32 dsref_en, UINT32 dpwrdn_type, UINT32 dpwrdn_en, UINT32 clk_stop_en);
extern void  ncLib_DREX0_timing_row0(UINT32 t_aclk);
extern void  ncLib_DREX0_timing_data0(UINT32 t_aclk, UINT32 RL4, UINT32 W2W, UINT32 R2R, UINT32 WL, UINT32 RL);
extern void  ncLib_DREX0_timing_power0(UINT32 t_aclk, UINT32 CKESR, UINT32 CKE, UINT32 MRD);
extern void  ncLib_DREX0_rd_fetch0(UINT32 rd_fetch);
extern void  ncLib_DREX0_direct_cmd(UINT32 cmd_type, UINT32 ma, UINT32 ca);
extern void  ncLib_DREX0_con_control(UINT32 dfi_init_start, UINT32 timeout_level0, UINT32 same_dir_prep, UINT32 pause_mem_st, UINT32 empty, UINT32 io_pd_con, UINT32 aref_en, UINT32 update_mode, UINT32 ca_swap);
extern void  ncLib_DREX0_all_init_indi(UINT32 all_init_done);
extern void  ncLib_DREX0_delay(UINT32 usec);
extern void  ncLib_DREX1_mem_config0(UINT32 rank_inter_en, UINT32 bank_lsb, UINT32 bit_sel_en1, UINT32 bit_sel_en0, UINT32 bit_sel1, UINT32 bit_sel0, UINT32 chip_map, UINT32 chip_col, UINT32 chip_row, UINT32 chip_bank);
extern void  ncLib_DPHY_gnr_con0(UINT32 ctrl_upd_time,UINT32 ctrl_upd_range,UINT32 ctrl_dfdqs,UINT32 ctrl_ddr_mode,UINT32 ctrl_fnc_fb,UINT32 ctrl_wrlat,UINT32 ctrl_bstlen,UINT32 ctrl_twpre,UINT32 ctrl_ckdis,UINT32 ctrl_cmosrcv,UINT32 ctrl_rdlat);

/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/
void ncLib_DPHY_init(UINT32 md, UINT32 wl, UINT32 bl, UINT32 rl)
{
    //                 (ctrl_upd_time,ctrl_upd_range,ctrl_dfdqs,ctrl_ddr_mode,ctrl_fnc_fb,ctrl_wrlat,ctrl_bstlen,ctrl_twpre,ctrl_ckdis,ctrl_cmosrcv,ctrl_rdlat);
    ncLib_DPHY_gnr_con0(          0x1,           0x0,       0x1,           md,        0x0,        wl,         bl,       0x0,       0x0,         0x0,        rl);

}

INT32 ncLib_DREX0_dfi_init()
{
    INT32 ret = NC_SUCCESS;
    INT32 failure_cnt;
    failure_cnt = 0;
    // DREX Initial Start
    //                     (dfi_init_start, timeout_level0, same_dir_prep, pause_mem_st, empty, io_pd_con, aref_en, update_mode, ca_swap);
    ncLib_DREX0_con_control(           0x1,          0xFFF,           0x1,          0x0,   0x1,       0x0,     0x0,         0x0,     0x0);
    while(1)
    {
        if(REGRW32(APACHE_DREX0_BASE , 0x0040) & 0x8) // PHY_STATUS.dfi_init_complete [3]
        {
            break;
        }
        if (failure_cnt == 2000)
        {
            ret = NC_FAILURE;
            break;
        }
        failure_cnt++;
    }
    //                     (dfi_init_start, timeout_level0, same_dir_prep, pause_mem_st, empty, io_pd_con, aref_en, update_mode, ca_swap);
    ncLib_DREX0_con_control(           0x0,          0xFFF,           0x1,          0x0,   0x1,       0x0,     0x0,         0x0,     0x0);

    if(ret == NC_FAILURE)
    {
        //DEBUGMSG(MSGERR, "Error, DREX %s\n", LOG_ERR_OPEN);
    }

    return ret;
}

INT32 ncLib_DREX0_cg_ctrl(UINT32 cg_en)
{
    INT32 ret = NC_SUCCESS;
    UINT32  rdata;
    UINT32  mask;
    
    // DREX Initial Start
    mask                                = 0xFFFFFE00;  // [9:0]
    rdata                               = mask  &  REGRW32(APACHE_DREX0_BASE  , 0x0008); // read 
    REGRW32(APACHE_DREX0_BASE , 0x0008) = rdata | (cg_en & ~mask); // CG_CONTROL

    if(ret == NC_FAILURE)
    {
        //DEBUGMSG(MSGERR, "Error, DREX %s\n", LOG_ERR_OPEN);
    }

    return ret;
}

void ncLib_DREX0_fp_resync()
{
    
    //                     (ctrl_shgate,ctrl_pd,rec_gate_cyc,pause_resync_en,dqs_delay,fp_resync,sl_dll_dyn_con,gen_read_gate);
    ncLib_DREX0_phy_control(        0x0,    0x0,         0x5,            0x1,      0x0,      0x1,           0x0,          0x0);
    //                     (ctrl_shgate,ctrl_pd,rec_gate_cyc,pause_resync_en,dqs_delay,fp_resync,sl_dll_dyn_con,gen_read_gate);
    ncLib_DREX0_phy_control(        0x0,    0x0,         0x5,            0x1,      0x0,      0x0,           0x0,          0x0);

}

//--------------------------------------------------------------------------
// REG BANK
//--------------------------------------------------------------------------
void ncLib_DREX0_phy_control(UINT32 ctrl_shgate,UINT32 ctrl_pd,UINT32 rec_gate_cyc,UINT32 pause_resync_en,UINT32 dqs_delay,UINT32 fp_resync,UINT32 sl_dll_dyn_con,UINT32 gen_read_gate)
{
    REGRW32(APACHE_DREX0_BASE , 0x0018) =   ctrl_shgate      << 29 |
                                            ctrl_pd          << 24 |
                                            rec_gate_cyc     << 12 |
                                            pause_resync_en  <<  7 |
                                            dqs_delay        <<  4 |
                                            fp_resync        <<  3 |
                                            sl_dll_dyn_con   <<  1 |
                                            gen_read_gate    <<  0 ;
}

void ncLib_DREX0_mem_control(UINT32 pb_ref_en, UINT32 bl, UINT32 mem_type, UINT32 add_lat_pall, UINT32 dsref_en, UINT32 dpwrdn_type, UINT32 dpwrdn_en, UINT32 clk_stop_en)
{
    REGRW32(APACHE_DREX0_BASE , 0x0004) = pb_ref_en    << 27 | bl          << 20  | 0x2         << 12 |
                                          mem_type     <<  8 | add_lat_pall <<  6 | dsref_en    <<  5 |
                                          dpwrdn_type  <<  2 | dpwrdn_en    <<  1 | clk_stop_en       ;

}

void ncLib_DREX0_timing_rfcpb(UINT32 t_aclk)
{
    REGRW32(APACHE_DREX0_BASE , 0x0020) =  1 + (UINT32)(tRFCPB * 1000) / t_aclk  << 16 |
                                           1 + (UINT32)(tRFCPB * 1000) / t_aclk  <<  0 ;
}


void ncLib_DREX0_timing_aref(UINT32 t_rclk)
{
    REGRW32(APACHE_DREX0_BASE , 0x0030) =  (UINT32)(tREFIPB * 1000) / t_rclk  << 16 |
                                           (UINT32)(tREFI   * 1000) / t_rclk  <<  0 ;
}

void ncLib_DREX0_timing_row0(UINT32 t_aclk)
{
    REGRW32(APACHE_DREX0_BASE , 0x0034) =  2 +  (UINT32)(tRFC * 1000) / t_aclk  << 24 |
                                           2 +  (UINT32)(tRRD * 1000) / t_aclk  << 20 |
                                           2 +  (UINT32)(tRP  * 1000) / t_aclk  << 16 |
                                           2 +  (UINT32)(tRCD * 1000) / t_aclk  << 12 |
                                           2 +  (UINT32)(tRC  * 1000) / t_aclk  <<  6 |
                                           2 +  (UINT32)(tRAS * 1000) / t_aclk  <<  0 ;
}

void ncLib_DREX0_timing_data0(UINT32 t_aclk, UINT32 RL4, UINT32 W2W, UINT32 R2R, UINT32 WL, UINT32 RL)
{
    REGRW32(APACHE_DREX0_BASE , 0x0038) =   2 + (UINT32)(tWTR   * 1000) / t_aclk      << 28 |
                                            2 + (UINT32)(tWR    * 1000) / t_aclk      << 24 |
                                            2 + (UINT32)(tRTP   * 1000) / t_aclk      << 20 |
                                                         RL4                          << 18 |
                                                         W2W                          << 14 |
                                                         R2R                          << 12 |
                                                         WL                           <<  8 |
                                            1 + (UINT32)(tDQSCK * 1000) /(t_aclk / 2) <<  4 |
                                                         RL                           <<  0 ;
}

void ncLib_DREX0_timing_power0(UINT32 t_aclk, UINT32 CKESR, UINT32 CKE, UINT32 MRD)
{
    REGRW32(APACHE_DREX0_BASE , 0x003C) =   2 + (UINT32)(tFAW   * 1000) / t_aclk      << 26 |
                                            2 + (UINT32)(tXSR   * 1000) / t_aclk      << 16 |
                                            2 + (UINT32)(tXP    * 1000) / t_aclk      << 12 |
                                                         CKESR                        <<  8 |
                                                         CKE                          <<  4 |
                                                         MRD                          <<  0 ;

}

void ncLib_DREX0_rd_fetch0(UINT32 rd_fetch)
{
    REGRW32(APACHE_DREX0_BASE , 0x004C) =   rd_fetch;

}

void ncLib_DREX0_prech_config0()
{
    REGRW32(APACHE_DREX0_BASE , 0x0014) =   0x1 << 28 |
                                            0x1 << 16 ;
}

void ncLib_DREX0_prech_config1(UINT32 tp_cnt3, UINT32 tp_cnt2, UINT32 tp_cnt1, UINT32 tp_cnt0)
{
    REGRW32(APACHE_DREX0_BASE , 0x001C) =   tp_cnt3 << 24 |
                                            tp_cnt2 << 16 |
                                            tp_cnt1 <<  8 |
                                            tp_cnt0 <<  0 ;
}

void ncLib_DREX0_direct_cmd(UINT32 cmd_type, UINT32 ma, UINT32 ca)
{
    UINT32 cmd;
    if (cmd_type == 0x0)
    {
        cmd = (ma >> 6 & 0x3) | ((ma >> 3) & 0x7) << 16 | ( ma & 0x7) << 10 | ( ca & 0xFF) << 2 ;
    }
    else
    {
        cmd = cmd_type << 24;
    }

    REGRW32(APACHE_DREX0_BASE , 0x0010) = cmd;

}

void ncLib_DREX0_direct_cmd_ddr3(UINT32 cmd_type, UINT32 cmd_chip_all, UINT32 cmd_chip, UINT32 cmd_addr_16, UINT32 cmd_bank, UINT32 cmd_addr)
{
    UINT32 cmd;
    cmd = (cmd_type     << 24) |
          (cmd_chip_all << 21) |
          (cmd_chip     << 20) |
          (cmd_addr_16  << 19) |
          (cmd_bank     << 16) |
          (cmd_addr     <<  0) ;

    REGRW32(APACHE_DREX0_BASE , 0x0010) = cmd;

}

void ncLib_DREX0_con_control(UINT32 dfi_init_start, UINT32 timeout_level0, UINT32 same_dir_prep, UINT32 pause_mem_st, UINT32 empty, UINT32 io_pd_con, UINT32 aref_en, UINT32 update_mode, UINT32 ca_swap)
{
    REGRW32(APACHE_DREX0_BASE , 0x0000) =   dfi_init_start   << 28 |
                                            timeout_level0   << 16 |
                                            same_dir_prep    << 12 |
                                            pause_mem_st     <<  9 |
                                            empty            <<  8 |
                                            io_pd_con        <<  6 |
                                            aref_en          <<  5 |
                                            update_mode      <<  3 |
                                            ca_swap          <<  0 ;
}

void ncLib_DREX0_all_init_indi(UINT32 all_init_done)
{
    REGRW32(APACHE_DREX0_BASE , 0x0400) =   all_init_done   ;
}

void ncLib_DREX0_winconfig_ctrlread(void)
{
    REGRW32(APACHE_DREX0_BASE , 0x0308) =   0x22110   ;
}
void ncLib_DREX0_winconfig_ctrlgate(void)
{
    REGRW32(APACHE_DREX0_BASE , 0x030C) =   0x22110   ;
}


void ncLib_DREX0_pipeline_config(void)
{
    REGRW32(APACHE_DREX0_BASE , 0x0310) =   0x21   ;
}

void ncLib_DREX0_resetn(UINT32 val)
{
    REGRW32(APACHE_SCU_BASE , 0x01C4) =   val   ;
}

void ncLib_DREX0_delay(UINT32 usec)
{
    UINT32 i, j;    

    for(i = 0; i < usec; i++)
    {
        // for(j = 0; j < 300; j++);
        for(j = 0; j < 70; j++);
    }
}

void ncLib_DREX1_mem_config0(UINT32 rank_inter_en, UINT32 bank_lsb, UINT32 bit_sel_en1, UINT32 bit_sel_en0, UINT32 bit_sel1, UINT32 bit_sel0, UINT32 chip_map, UINT32 chip_col, UINT32 chip_row, UINT32 chip_bank)
{
    REGRW32(APACHE_DREX1_BASE , 0x0F10) =   rank_inter_en   << 24 |
                                            bank_lsb        << 20 |
                                            bit_sel_en1     << 19 |
                                            bit_sel_en0     << 18 |
                                            bit_sel1        << 17 |
                                            bit_sel0        << 16 |
                                            chip_map        << 12 |
                                            chip_col        <<  8 |
                                            chip_row        <<  4 |
                                            chip_bank       <<  0 ; 

}

void ncLib_DPHY_gnr_con0(UINT32 ctrl_upd_time,UINT32 ctrl_upd_range,UINT32 ctrl_dfdqs,UINT32 ctrl_ddr_mode,UINT32 ctrl_fnc_fb,UINT32 ctrl_wrlat,UINT32 ctrl_bstlen,UINT32 ctrl_twpre,UINT32 ctrl_ckdis,UINT32 ctrl_cmosrcv,UINT32 ctrl_rdlat)
{
    REGRW32(APACHE_DPHY_BASE , 0x0000) =   ctrl_upd_time      << 30 |
                                           ctrl_upd_range     << 28 |
                                           ctrl_dfdqs         << 26 |
                                           ctrl_ddr_mode      << 24 |
                                           ctrl_fnc_fb        << 21 |
                                           ctrl_wrlat         << 16 |
                                           ctrl_bstlen        <<  8 |
                                           ctrl_twpre         <<  7 |
                                           ctrl_ckdis         <<  6 |
                                           ctrl_cmosrcv       <<  5 |
                                           ctrl_rdlat         <<  0 ;
}


//--------------------------------------------------------------------------
// DREX INIT
//--------------------------------------------------------------------------
void ncDrv_DDRC_Init(void)
{
#if     LPDDR3_MODEL

    DEBUGMSG(MSGINFO, "################################################################");
    DEBUGMSG(MSGINFO, "# TEST DREX : LPDDR3                                            ");
    DEBUGMSG(MSGINFO, "################################################################");

    ncLib_DREX0_pipeline_config();
    //--------------------------------------------------------------------------
    // PHY INITIALIZATION
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# PHY INITIALIZATION");
    ncLib_DPHY_init(0x3, 0x7, 0x8, 0xC); // WL(6+1), BL(8), RL(12)
    //--------------------------------------------------------------------------
    // DREX INIT START
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX INIT START");
    ncLib_DREX0_dfi_init();
    //--------------------------------------------------------------------------
    // DREX clock gate disable
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX clock gate disable");
    ncLib_DREX0_cg_ctrl(0x000);
    //-------------------------------------------------------------------------- 
    // DREX update DLL information
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX update DLL information");
    ncLib_DREX0_fp_resync();
    //--------------------------------------------------------------------------
    // DREX MEMORY CONFIG0 --> ASP
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX MEMORY CONFIG0 --> ASP");
    REGRW32(APACHE_SCU_BASE,    0x198 ) =  0x0; // secure_boot
    REGRW32(APACHE_DREX1_BASE , 0x000C) =  0x1; // ASP_ITOP
    //                     (rank_inter_en,bank_lsb,bit_sel_en1,bit_sel_en0,bit_sel1,bit_sel0,chip_map,chip_col,chip_row,chip_bank);
    ncLib_DREX1_mem_config0(          0x0,     0x0,        0x0,        0x0,     0x1,     0x1,     0x2,     0x2,     0x2,      0x3);
    REGRW32(APACHE_DREX1_BASE , 0x0E08) =  0x1; // ASP_ITOP
    REGRW32(APACHE_SCU_BASE, 0x198) = 0x1; // secure_boot
    //--------------------------------------------------------------------------
    // DREX TIMING
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX TIMING");
    //                      ( t_aclk);
    ncLib_DREX0_timing_rfcpb(   2500);
    //                     (t_rclk)
    ncLib_DREX0_timing_aref(    41);
    //                     (t_aclk);
    ncLib_DREX0_timing_row0(  2500); // ps
    //                      (t_aclk, RL4, W2W, R2R,  WL + 2,  RL + 2);
    ncLib_DREX0_timing_data0(  2500, 0x0, 0x0, 0x0,     0x6,     0xC);
    //                       (t_aclk, CKESR, CKE, MRD);
    ncLib_DREX0_timing_power0(  2500,   0x6, 0x2, 0x2);
    //                   (rd_fetch);
    ncLib_DREX0_rd_fetch0(     0x2);
    //-------------------------------------------------------------------------- 
    // DREX update DLL information
    //--------------------------------------------------------------------------
    ncLib_DREX0_fp_resync();
    //-------------------------------------------------------------------------- 
    // DREX PHY CKE
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX PHY CKE");
    // CKE --> HW RESET --> 500us --> CLOCK -> 10ns
    //                    (cmd_type,   ma,   ca);
    ncLib_DREX0_direct_cmd(     0x0, 0xC0, 0x01); // NOP command
    //               ( usec);
    ncLib_DREX0_delay(  200);
    //--------------------------------------------------------------------------
    // DREX MEMORY CONTROL
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX MEMORY CONTROL");
    //                     (pb_ref_en,  bl, mem_type, add_lat_pall, dsref_en, dpwrdn_type, dpwrdn_en, clk_stop_en);
    ncLib_DREX0_mem_control(      0x1, 0x3,      0x7,          0x0,      0x0,         0x1,       0x0,         0x0);
    DEBUGMSG(MSGINFO, "# DREX PHY RESET");
    //                    (cmd_type,   ma,   ca);
    ncLib_DREX0_direct_cmd(     0x0, 0x3f, 0x00); // RESET command
    //               ( usec);
    ncLib_DREX0_delay(   10);
    //--------------------------------------------------------------------------
    // DREX CA Calib
    //--------------------------------------------------------------------------
//    DEBUGMSG(MSGINFO, "# DREX PHY CA CALIB");
//    //                    (cmd_type,   ma,   ca);
//    ncLib_DREX0_direct_cmd(     0x0, 0x29, 0xA4); // CA calibration command
//    //                    (cmd_type,   ma,   ca);
//    ncLib_DREX0_direct_cmd(     0x0, 0x2A, 0xA8); // CA calibration command
//    //                    (cmd_type,   ma,   ca);
//    ncLib_DREX0_direct_cmd(     0x0, 0x30, 0xC0); // CA calibration command
//    //                    (cmd_type,   ma,   ca);
//    ncLib_DREX0_direct_cmd(     0x0, 0x2A, 0xA8); // CA calibration command
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX PHY IO CALIB");
    //                    (cmd_type,   ma,   ca);
    ncLib_DREX0_direct_cmd(     0x0, 0x0A, 0xFF); // IO calibration command
    DEBUGMSG(MSGINFO, "# DREX PHY ACT");
    //                    (cmd_type,   ma,   ca);
    ncLib_DREX0_direct_cmd(     0xE, 0x00, 0x00); // ACT command
    DEBUGMSG(MSGINFO, "# DREX PHY RL & WL");
    //                    (cmd_type,   ma,   ca);
    ncLib_DREX0_direct_cmd(     0x0, 0x02, 0x0A); // RL & WL
    //--------------------------------------------------------------------------
    // DREX AUTO REFRESH COUNTER : aref_en
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX AUTO REFRESH COUNTER");
    //                     (dfi_init_start, timeout_level0, same_dir_prep, pause_mem_st, empty, io_pd_con, aref_en, update_mode, ca_swap);
    ncLib_DREX0_con_control(           0x0,          0xFFF,           0x1,          0x0,   0x1,       0x0,     0x1,         0x0,     0x0);
    //--------------------------------------------------------------------------
    // DREX clock gate enable
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX Clock gate enable");
    ncLib_DREX0_cg_ctrl(0x1FF);
    //--------------------------------------------------------------------------
    // DREX ALL INIT DONE
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX ALL INIT DONE");
    //                       ( all_init_done);
    ncLib_DREX0_all_init_indi(           0x1);
#elif      DDR3_MODEL

    DEBUGMSG(MSGINFO, "################################################################");
    DEBUGMSG(MSGINFO, "# TEST DREX : DDR3                                            ");
    DEBUGMSG(MSGINFO, "################################################################");

    ncLib_DREX0_pipeline_config();
    //--------------------------------------------------------------------------
    // RESET Release 200us
    //--------------------------------------------------------------------------
    ncLib_DREX0_resetn(0x3);
    
    //--------------------------------------------------------------------------
    // PHY INITIALIZATION
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# PHY INITIALIZATION");
    ncLib_DPHY_init(0x1, 0x8, 0x8, 0xB); // WL(8), BL(8), RL(11)
    //--------------------------------------------------------------------------
    // DREX INIT START
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX INIT START");
    ncLib_DREX0_dfi_init();
    //--------------------------------------------------------------------------
    // DREX clock gate disable
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX clock gate disable");
    ncLib_DREX0_cg_ctrl(0x000);
    //-------------------------------------------------------------------------- 
    // DREX update DLL information
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX update DLL information");
    ncLib_DREX0_fp_resync();

    //--------------------------------------------------------------------------
    // DREX MEMORY CONFIG0 --> ASP
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX MEMORY CONFIG0 --> ASP");
    REGRW32(APACHE_SCU_BASE,    0x198 ) =  0x0; // secure_boot
    REGRW32(APACHE_DREX1_BASE , 0x000C) =  0x1; // ASP_ITOP
    //                     (rank_inter_en,bank_lsb,bit_sel_en1,bit_sel_en0,bit_sel1,bit_sel0,chip_map,chip_col,chip_row,chip_bank);
    ncLib_DREX1_mem_config0(          0x0,     0x0,        0x0,        0x0,     0x1,     0x1,     0x2,     0x3,     0x2,      0x3);
    REGRW32(APACHE_DREX1_BASE , 0x0E08) =  0x1; // ASP_ITOP
    REGRW32(APACHE_SCU_BASE, 0x198) = 0x1; // secure_boot
    //--------------------------------------------------------------------------
    // DREX TIMING
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX TIMING");
    //                     (t_rclk)
    ncLib_DREX0_timing_aref(    40);
    //                     (t_aclk);
    ncLib_DREX0_timing_row0(  2500); // ps
    //                      (t_aclk, RL4, W2W, R2R,      WL,      RL);
    ncLib_DREX0_timing_data0(  2500, 0x0, 0x0, 0x0,     0x8,     0xB);
    //                       (t_aclk, CKESR, CKE, MRD);
    ncLib_DREX0_timing_power0(  2500,   0x6, 0x3, 0x7);
    //                   (rd_fetch);
    ncLib_DREX0_rd_fetch0(     0x2);
    //
    ncLib_DREX0_prech_config0();
    //                       (tp_cnt3, tp_cnt2, tp_cnt1, tp_cnt0);
    ncLib_DREX0_prech_config1(   0x10,    0x10,    0x10,    0x10);
    //-------------------------------------------------------------------------- 
    // DREX update DLL information
    //--------------------------------------------------------------------------
    ncLib_DREX0_fp_resync();
    //               ( usec);
    ncLib_DREX0_delay(  500);
    //-------------------------------------------------------------------------- 
    // DREX PHY CKE
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX PHY CKE");
    // CKE --> HW RESET --> 500us --> CLOCK -> 10ns
    //                         (cmd_type, cmd_chip_all, cmd_chip, cmd_addr_16, cmd_bank, cmd_addr);
    ncLib_DREX0_direct_cmd_ddr3(     0x7,          0x0,      0x0,         0x0,      0x2,     0x00);
    //               ( usec);
    ncLib_DREX0_delay(   10);
    DEBUGMSG(MSGINFO, "# DIRECT_CMD");
    //                         (cmd_type, cmd_chip_all, cmd_chip, cmd_addr_16, cmd_bank, cmd_addr); // CAS Wrtie Latency
    ncLib_DREX0_direct_cmd_ddr3(     0x0,          0x1,      0x0,         0x0,      0x2,     0x18);
    //                         (cmd_type, cmd_chip_all, cmd_chip, cmd_addr_16, cmd_bank, cmd_addr);
    ncLib_DREX0_direct_cmd_ddr3(     0x0,          0x1,      0x0,         0x0,      0x3,     0x00);
    //                         (cmd_type, cmd_chip_all, cmd_chip, cmd_addr_16, cmd_bank, cmd_addr); // Additive Latency
    ncLib_DREX0_direct_cmd_ddr3(     0x0,          0x1,      0x0,         0x0,      0x1,     0x00); 
    //                         (cmd_type, cmd_chip_all, cmd_chip, cmd_addr_16, cmd_bank, cmd_addr); // CAS Latency
    ncLib_DREX0_direct_cmd_ddr3(     0x0,          0x1,      0x0,         0x0,      0x0,     0x70);
    //                         (cmd_type, cmd_chip_all, cmd_chip, cmd_addr_16, cmd_bank, cmd_addr); // DLL reset
    ncLib_DREX0_direct_cmd_ddr3(     0x0,          0x1,      0x0,         0x0,      0x0,    0x170);
    //                         (cmd_type, cmd_chip_all, cmd_chip, cmd_addr_16, cmd_bank, cmd_addr); // ZQINT
    ncLib_DREX0_direct_cmd_ddr3(     0xa,          0x1,      0x0,         0x0,      0x0,      0x0);
    //               ( usec);
    ncLib_DREX0_delay(   10);
    //--------------------------------------------------------------------------
    // DREX CA Calib
    //--------------------------------------------------------------------------
//    DEBUGMSG(MSGINFO, "# DREX PHY CA CALIB");
//    //                    (cmd_type,   ma,   ca);
//    ncLib_DREX0_direct_cmd(     0x0, 0x29, 0xA4); // CA calibration command
//    //                    (cmd_type,   ma,   ca);
//    ncLib_DREX0_direct_cmd(     0x0, 0x2A, 0xA8); // CA calibration command
//    //                    (cmd_type,   ma,   ca);
//    ncLib_DREX0_direct_cmd(     0x0, 0x30, 0xC0); // CA calibration command
//    //                    (cmd_type,   ma,   ca);
//    ncLib_DREX0_direct_cmd(     0x0, 0x2A, 0xA8); // CA calibration command
    //--------------------------------------------------------------------------
    //                         (cmd_type, cmd_chip_all, cmd_chip, cmd_addr_16, cmd_bank, cmd_addr);
    ncLib_DREX0_direct_cmd_ddr3(     0x1,          0x1,      0x0,         0x0,      0x0,     0x00);
    // DEBUGMSG(MSGINFO, "# DREX PHY RL & WL");
    //                    (cmd_type,   ma,   ca);
    // ncLib_DREX0_direct_cmd(     0x0, 0x02, 0x0A); // RL & WL
    //-------------------------------------------------------------------------- 
    // DREX update DLL information
    //--------------------------------------------------------------------------
    ncLib_DREX0_fp_resync();
    //--------------------------------------------------------------------------
    // DREX MEMORY CONTROL
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX MEMORY CONTROL");
    //                     (pb_ref_en,  bl, mem_type, add_lat_pall, dsref_en, dpwrdn_type, dpwrdn_en, clk_stop_en);
    ncLib_DREX0_mem_control(      0x0, 0x3,      0x6,          0x0,      0x0,         0x1,       0x0,         0x0);
    //--------------------------------------------------------------------------
    // DREX AUTO REFRESH COUNTER : aref_en
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX AUTO REFRESH COUNTER");
    //                     (dfi_init_start, timeout_level0, same_dir_prep, pause_mem_st, empty, io_pd_con, aref_en, update_mode, ca_swap);
    ncLib_DREX0_con_control(           0x0,          0xFFF,           0x1,          0x0,   0x1,       0x0,     0x1,         0x0,     0x0);
    //--------------------------------------------------------------------------
    // DREX clock gate enable
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX Clock gate enable");
    ncLib_DREX0_cg_ctrl(0x1FF);
    //--------------------------------------------------------------------------
    // DREX ALL INIT DONE
    //--------------------------------------------------------------------------
    DEBUGMSG(MSGINFO, "# DREX ALL INIT DONE");
    //                       ( all_init_done);
    ncLib_DREX0_all_init_indi(           0x1);
#elif      LPDDR2_MODEL
#endif  // NCA4_DDR_MODEL
}


#endif  /* __BL2_DDR_ENABLE__ */

/* End Of File */

