/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

UINT32 ncDrv_SCU_GetTick(UINT32 cls)
{
    if(cls)
    {
        // Clear : Count == 0
        REGRW32(APACHE_SCU_BASE, rSCU_TICK_CNT) = 0x0;
    }

    return REGRW32(APACHE_SCU_BASE, rSCU_TICK_CNT);
}


unsigned int ncDrv_SCU_GetMsec(UINT32 cls)
{
    UINT32 curr_tick = ncDrv_SCU_GetTick(cls);

    if(curr_tick)
        curr_tick = curr_tick / (SYS_APB_CLK / MSEC);

    return curr_tick;
}


BOOL ncDrv_SCU_mTimeOut(UINT32 mSec)
{
    BOOL Ret = FALSE;       

    if(mSec > 0)
    {
        if(SYS_TIMEOUT_CNT == 0)
        {
            // Set TimeOut : SystemTick(msec) + TargetMsec;
            SYS_TIMEOUT_CNT = ncDrv_SCU_GetMsec(1) + mSec;
        }
        else
        {
            // Timeout Check. 
            if(ncDrv_SCU_GetMsec(0) > SYS_TIMEOUT_CNT)
            {
                Ret = TRUE;
                SYS_TIMEOUT_CNT = 0;
            }
        }
    }
    else
    {
        SYS_TIMEOUT_CNT = 0;
    }
    
    return Ret;
}


UINT8 ncDrv_SCU_GetPinMux(UINT32 Pad)
{
    UINT32 Offset;
    UINT32 Pos;
    
    Offset = (Pad / 8)*4;
    Pos    = (Pad % 8)*4;

    return (REGRW32(APACHE_ICU_BASE, Offset)>>Pos)&0xf;
}


void ncDrv_SCU_SetPinMux(UINT32 Pad, UINT32 Func)
{
    UINT32 Reg;    
    UINT32 Offset;
    UINT32 Pos;

    Offset = (Pad / 8)*4;
    Pos    = (Pad % 8)*4;
    
    Reg = REGRW32(APACHE_ICU_BASE, Offset);
    Reg &= ~(0x7<<Pos); 
    Reg |= ((Func&0x7)<<Pos);
    REGRW32(APACHE_ICU_BASE, Offset) = Reg;
}


/* End Of File */

