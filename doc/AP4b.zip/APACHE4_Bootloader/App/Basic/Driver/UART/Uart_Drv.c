/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#ifdef __UART_ENABLE__

#include <stdarg.h>
#include <stdio.h>










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncDrv_UART_PutChar(eUART_CH Ch, UINT8 Data)
{
    UINT32 Reg;

    do 
    {
        Reg = REGRW32(rUART_BASE(Ch), rUART_LSR);
    } while ((Reg & bUART_LSR_THRE) != bUART_LSR_THRE);

    // Data Write
	REGRW32(rUART_BASE(Ch), rUART_TX) = Data;

    // WAIT_FOR_XMITR
    do 
    {
        Reg = REGRW32(rUART_BASE(Ch), rUART_LSR);
    } while ((Reg & (bUART_LSR_TEMT | bUART_LSR_THRE)) != (bUART_LSR_TEMT | bUART_LSR_THRE));
}


void ncDrv_UART_PutStr(eUART_CH Ch, char *str)
{
    char prev = 0x0;

    while(*str)
    {
        if(*str == '\n' && prev != '\r') ncDrv_UART_PutChar(Ch, '\r');

        ncDrv_UART_PutChar(Ch, *str);

        prev = *str++;
    }
}


void ncDrv_UART_Initialize(eUART_CH Ch, UINT32 BaudRate, UINT32 RefClk)
{
    UINT32 Reg;
    UINT32 DIV;

    // Disable UART
    REGRW32(rUART_BASE(Ch), rUART_EN) = OFF;

    // Reset receiver and transmitter
    REGRW32(rUART_BASE(Ch), rUART_FCR) = (bUART_FCR_CLEAR_RCVR|bUART_FCR_CLEAR_XMIT|bUART_FCR_TRIGGER_14);

    // Set Interrupt Disable
    REGRW32(rUART_BASE(Ch), rUART_IER) = 0x0;

    // Set 8 bit char, 1 stop bit, no parity */
    REGRW32(rUART_BASE(Ch), rUART_LCR) = (UT_BRK_DIS|UT_SPS_DIS|UT_EPS_DIS|UT_PARITY_DIS|UT_STOP_1BIT|UT_DATA_8BIT);

    // Set baud rate : open divisor latch
    Reg = (REGRW32(rUART_BASE(Ch), rUART_LCR) | bUART_LCR_DLAB);
    REGRW32(rUART_BASE(Ch), rUART_LCR) = Reg;

    // Set baud rate : set divisor latch
    DIV = RefClk/(16 * BaudRate);
    REGRW32(rUART_BASE(Ch), rUART_DLL) = (DIV>>0)&0xff;
    REGRW32(rUART_BASE(Ch), rUART_DLM) = (DIV>>8)&0xff;

    // Set baud rate : close divisor latch
    Reg = (REGRW32(rUART_BASE(Ch), rUART_LCR) & ~(bUART_LCR_DLAB));
    REGRW32(rUART_BASE(Ch), rUART_LCR) = Reg;
    
    // Enable UART
    REGRW32(rUART_BASE(Ch), rUART_EN) = ON;
}


void ncDrv_UART_Printf(UINT32 DebugZone, const char *fmt, ...)
{
    eUART_CH Ch = UART_CH0; 
    
    va_list vList;
    char Buff[512];

    if(DebugZone&MSGERR)  ncDrv_UART_PutStr(Ch, STR_COLOR_RED_ON);
    if(DebugZone&MSGWARN) ncDrv_UART_PutStr(Ch, STR_COLOR_YELLOW_ON);

    va_start(vList, fmt);

    vsnprintf(Buff, sizeof(Buff), fmt, vList);

    va_end(vList);

    ncDrv_UART_PutStr(Ch, Buff);

    if((DebugZone&MSGERR) || (DebugZone&MSGWARN))
    {
        ncDrv_UART_PutStr(Ch, STR_COLOR_OFF);
    }
}


#endif  /* __UART_ENABLE__ */


/* End Of File */

