/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*              INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"










/*
********************************************************************************
*              FUNCTION DEFINITIONS
********************************************************************************
*/

void ncSvc_SF_GetPadCtrl(UINT8 CSN, UINT32 CtrlMode)
{
    if(CtrlMode == QSPI_MODE)
    {
        // Set Pin Mux : QSPI Interface                         // Ctrl-IP
        ncDrv_SCU_SetPinMux(PAD_SPI2_CSN0 + CSN, PAD_FUNC_1);   //  -. QSPI
        ncDrv_SCU_SetPinMux(PAD_SPI2_DQ0, PAD_FUNC_1);          //  -. QSPI
        ncDrv_SCU_SetPinMux(PAD_SPI2_DQ1, PAD_FUNC_1);          //  -. QSPI
        ncDrv_SCU_SetPinMux(PAD_SPI2_DQ2, PAD_FUNC_1);          //  -. QSPI
        ncDrv_SCU_SetPinMux(PAD_SPI2_DQ3, PAD_FUNC_1);          //  -. QSPI
        ncDrv_SCU_SetPinMux(PAD_SPI2_SCK, PAD_FUNC_1);          //  -. QSPI

        ncDrv_QSPI_SetCSN(CSN);
    }
    else
    {
        // Set Pin Mux : SPI-0 Interface                        // Ctrl-IP
        ncDrv_SCU_SetPinMux(PAD_SPI2_CSN0 + CSN, PAD_FUNC_4);   //  -. GPIO
        ncDrv_SCU_SetPinMux(PAD_SPI2_DQ0, PAD_FUNC_2);          //  -. SPI-0
        ncDrv_SCU_SetPinMux(PAD_SPI2_DQ1, PAD_FUNC_2);          //  -. SPI-0
        ncDrv_SCU_SetPinMux(PAD_SPI2_DQ2, PAD_FUNC_4);          //  -. GPIO
        ncDrv_SCU_SetPinMux(PAD_SPI2_DQ3, PAD_FUNC_4);          //  -. GPIO
        ncDrv_SCU_SetPinMux(PAD_SPI2_SCK, PAD_FUNC_2);          //  -. SPI-0

        // Default Pull-Up Status
        ncDrv_GPIO_SetData(PAD_SPI2_CSN0 + CSN, HIGH);          // ChipSelect
        ncDrv_GPIO_SetData(PAD_SPI2_DQ2,        HIGH);          // WP
        ncDrv_GPIO_SetData(PAD_SPI2_DQ3,        HIGH);          // HOLD
    }
}


void ncSvc_SF_FreePadCtrl(UINT8 CSN)
{
    // Release PIN Ctrl                               
    ncDrv_SCU_SetPinMux(PAD_SPI2_CSN0 + CSN, PAD_FUNC_0);
    ncDrv_SCU_SetPinMux(PAD_SPI2_DQ0,        PAD_FUNC_0);
    ncDrv_SCU_SetPinMux(PAD_SPI2_DQ1,        PAD_FUNC_0);
    ncDrv_SCU_SetPinMux(PAD_SPI2_DQ2,        PAD_FUNC_0); 
    ncDrv_SCU_SetPinMux(PAD_SPI2_DQ3,        PAD_FUNC_0);
    ncDrv_SCU_SetPinMux(PAD_SPI2_SCK,        PAD_FUNC_0);
}


void ncSvc_SF_CSEnable(UINT8 CSN)
{
    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_GPIO_SetData(PAD_SPI2_CSN0 + CSN, LOW);
}


void ncSvc_SF_CSDisable(UINT8 CSN)
{
    ncDrv_SSP_WaitBusIsBusy();
    ncDrv_GPIO_SetData(PAD_SPI2_CSN0 + CSN, HIGH);
}


UINT8 ncSvc_SF_ReadStatus(UINT8 CSN)
{
    UINT8 Command;
    UINT8 Status = 0;

    ncSvc_SF_CSEnable(CSN);

    Command = CMD_sFLASH_RD_STS;
    ncDrv_SSP_Write(&Command, 1);
    ncDrv_SSP_Read(&Status, 1);

    ncSvc_SF_CSDisable(CSN);

    return Status;
}


UINT8 ncSvc_SF_ReadStatus2(UINT8 CSN)
{
    UINT8 Command;
    UINT8 Status = 0;

    ncSvc_SF_CSEnable(CSN);

    Command = CMD_sFLASH_RD_STS2;
    ncDrv_SSP_Write(&Command, 1);
    ncDrv_SSP_Read(&Status, 1);

    ncSvc_SF_CSDisable(CSN);

    return Status;
}


void ncSvc_SF_WriteEnable(UINT8 CSN)
{
    UINT8 Command;

    ncSvc_SF_CSEnable(CSN);

    Command = CMD_sFLASH_WR_EN;
    ncDrv_SSP_Write(&Command, 1);

    ncSvc_SF_CSDisable(CSN);

    while( (ncSvc_SF_ReadStatus(CSN) & STS_WEL) != STS_WEL  ) ;
}


void ncSvc_SF_WriteDisable(UINT8 CSN)
{
    UINT8 Command;

    while( ncSvc_SF_ReadStatus(CSN) & STS_WIP  ) ;

    ncSvc_SF_CSEnable(CSN);

    Command = CMD_sFLASH_WR_DS;
    ncDrv_SSP_Write(&Command, 1);

    ncSvc_SF_CSDisable(CSN);
}

void ncSvc_SF_WriteStatus(UINT8 CSN, UINT8 Status)
{
    UINT8 Command[2];

    ncSvc_SF_WriteEnable(CSN);

    ncSvc_SF_CSEnable(CSN);

    Command[0] = CMD_sFLASH_WR_STS;
    Command[1] = Status;
    ncDrv_SSP_Write(Command, 2);

    ncSvc_SF_CSDisable(CSN);

    ncSvc_SF_WriteDisable(CSN);
}


void ncSvc_SF_WriteStatus2(UINT8 CSN, UINT8 Status1, UINT8 Status2)
{
    UINT8 Command[3];

    ncSvc_SF_WriteEnable(CSN);

    ncSvc_SF_CSEnable(CSN);

    Command[0] = CMD_sFLASH_WR_STS;
    Command[1] = Status1;
    Command[2] = Status2;	
    ncDrv_SSP_Write(Command, 3);

    ncSvc_SF_CSDisable(CSN);

    ncSvc_SF_WriteDisable(CSN);
}


void ncSvc_SF_ReadID(UINT8 CSN, UINT8* pBuff)
{
    UINT8 Command;

    ncSvc_SF_CSEnable(CSN);

    Command = CMD_sFLASH_RD_IDENTIFICATION;
    ncDrv_SSP_Write(&Command, 1);
    ncDrv_SSP_Read(pBuff, 3);

    ncSvc_SF_CSDisable(CSN);
}


INT32 ncSvc_SF_QspiEnable(UINT8 CSN, UINT8* pRDID)
{
    INT32 Ret = NC_SUCCESS;
    UINT8 Status1;
    UINT8 Status2;


    // PIN Mux Change (Command Only SPI Mode)
    ncSvc_SF_GetPadCtrl(CSN, SPI_MODE);


    // ID Read
    ncSvc_SF_ReadID(CSN, pRDID);


    // Check Support ID
    if((pRDID[0] == FLASH_ID_WINBOND) || (pRDID[0] == FLASH_ID_CYPRESS))
    {
        Status1 = ncSvc_SF_ReadStatus(CSN);
        Status2 = ncSvc_SF_ReadStatus2(CSN);

        if( !(Status2 & (1<<1)) )
        {
            ncSvc_SF_WriteStatus2(CSN, Status1, Status2|(1<<1));
        }
    }
    else if(pRDID[0] == FLASH_ID_MXIC)
    {
        Status1 = ncSvc_SF_ReadStatus(CSN);
        if( !(Status1 & (1<<6)) )
        {
            ncSvc_SF_WriteStatus(CSN, Status1|(1<<6));
        }
    }
    else if(pRDID[0] == FLASH_ID_EON)
    {
        //-----------------------------------------------
        //  8-Clock Instruction : Apache4 Support (??)
        //   -. Enable Bit and Command (X)
        //  2-Clock Instruction : Apache4 Not Support
        //   -. EQIO(0x38) - Quad IO Enable Command
        //-----------------------------------------------
    }
    else
    {
        //-----------------------------------------------
        // FLASH_ID_MICRON
        //  2-Clock Instruction : Apache4 Not Support
        //   -. 0xB5(RDNVCR), 0xB1(WRNVCR) - Set QSPI Enable Bit
        // FAASH_ID_SST
        //  -. The method is different.
        //  -. 8Clck Inst->24Clk Addr : Apache4 Not Support
        // FLASH_ID_ATML
        //  -. No supported devices found.
        //-----------------------------------------------

        Ret = NC_FAILURE;
    }
    
    return Ret;
}



INT32 ncSvc_SF_ReadData_DMAMode(UINT8 *pData, UINT32 Size, UINT32 InstBuff)
{
#ifdef __DMA_ENABLE__  
    INT32 Ret = NC_SUCCESS;

    tDMA_INFO tDMA[2];    
    UINT32 DevRegister;

    eDMA_CH TxCh = DMA_CH0;
    eDMA_CH RxCh = DMA_CH1;

    UINT32 InstSize;
    UINT32 pTxSrcBuff   = (InstBuff - 0x10);
    UINT32 pTxInstBuff  = 0;
    UINT32 pRxInstBuff  = 0;


    // Set DMA instuction-buffer 
    if(Size > DMA_TRANSFER_SIZE)
    {
        InstBuff = _ALIGN(InstBuff, 16);
        InstSize = (Size/DMA_TRANSFER_SIZE)*0x10;
        if(Size%DMA_TRANSFER_SIZE)
            InstSize+=0x10;
        
        pTxInstBuff = InstBuff - InstSize - 0x10;
        pRxInstBuff = pTxInstBuff - InstSize - 0x10;
        pTxSrcBuff  = pRxInstBuff - 0x10;
    }


    // Set SSP DMA Read-Mode
    ncDrv_SSP_SetDMAMode(0);


    // Set SPI Data Register
    DevRegister = (APACHE_SPI_0_BASE + 0x08);


    // Set TxDMA Channel (for dummy clock)
    tDMA[TxCh].mDMA_ChInit            = ENABLE;
    tDMA[TxCh].mDMA_ChNum             = TxCh;
    tDMA[TxCh].mDMA_Param.mIntEn      = DISABLE;
    tDMA[TxCh].mDMA_Param.mReqType    = DMA_MEM_TO_DEV;     
    tDMA[TxCh].mDMA_Param.mPeriNum    = (eDMA_PERI_NUM)(DMA_SPI0);
    tDMA[TxCh].mDMA_Param.mSwap       = DMA_SWAP_NO; 
    tDMA[TxCh].mDMA_Param.mRxIncrEn   = DISABLE;  
    tDMA[TxCh].mDMA_Param.mRxBurstLen = 1;  
    tDMA[TxCh].mDMA_Param.mTxIncrEn   = DISABLE;  
    tDMA[TxCh].mDMA_Param.mTxBurstLen = 1;  
    tDMA[TxCh].mDMA_Param.mInstAddr   = (UINT32)pTxInstBuff; 
    ncDrv_DMA_Initialize(TxCh);


    // Set RxDMA Channel
    tDMA[RxCh].mDMA_ChInit            = ENABLE;
    tDMA[RxCh].mDMA_ChNum             = RxCh;        
    tDMA[RxCh].mDMA_Param.mIntEn      = DISABLE;
    tDMA[RxCh].mDMA_Param.mReqType    = DMA_DEV_TO_MEM; 
    tDMA[RxCh].mDMA_Param.mPeriNum    = (eDMA_PERI_NUM)(DMA_SPI0);
    tDMA[RxCh].mDMA_Param.mSwap       = DMA_SWAP_NO; 
    tDMA[RxCh].mDMA_Param.mRxIncrEn   = DISABLE;  
    tDMA[RxCh].mDMA_Param.mRxBurstLen = 1;  
    tDMA[RxCh].mDMA_Param.mTxIncrEn   = ENABLE;  
    tDMA[RxCh].mDMA_Param.mTxBurstLen = 1;  
    tDMA[RxCh].mDMA_Param.mInstAddr   = (UINT32)pRxInstBuff; 
    ncDrv_DMA_Initialize(RxCh);
    

    Ret |= ncDrv_DMA_Transfer(&tDMA[RxCh], (UINT32)DevRegister, (UINT32)pData,       Size);
    Ret |= ncDrv_DMA_Transfer(&tDMA[TxCh], (UINT32)pTxSrcBuff,  (UINT32)DevRegister, Size);
    

    if(Ret == NC_SUCCESS)
    {
        // DMA Done Wait
        while((Ret = ncDrv_DMA_CheckComplete(TxCh)) == ON)
        {
            if(ncDrv_SCU_mTimeOut(SF_DMA_TIME_OUT))
            {
                DEBUGMSG(MSGERR, " - SF DMA Tx rTimeOut!~\n");
                break;
            }
        }
        ncDrv_SCU_mTimeOut(0);

        
        // DMA Done Wait
        while((Ret = ncDrv_DMA_CheckComplete(RxCh)) == ON)
        {
            if(ncDrv_SCU_mTimeOut(SF_DMA_TIME_OUT))
            {
                DEBUGMSG(MSGERR, " - SF DMA Rx rTimeOut!~\n");
                break;
            }
        }
        ncDrv_SCU_mTimeOut(0);
    }


    // DeInit DMA Channel
    ncDrv_DMA_DeInitialize(RxCh);
    ncDrv_DMA_DeInitialize(TxCh);


    return Ret;
#else
    return NC_FAILURE;
#endif
}


INT32 ncSvc_SF_ReadData(UINT8 CSN, UINT32 CtrlMode, UINT32 InstBuff, UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    INT32 Ret = NC_SUCCESS;
    UINT8 Command[4];


    if((CtrlMode == QSPI_MODE) && !(Size%8))
    {
        ncSvc_SF_GetPadCtrl(CSN, QSPI_MODE);
        
        // QSPI Data Read : Quad-SPI 64bit(8Byte) Align
        Ret = ncDrv_QSPI_ReadData(Addr, (UINT32)pData, Size);
    }
    else
    {
        ncSvc_SF_GetPadCtrl(CSN, SPI_MODE);
        
        ncSvc_SF_CSEnable(CSN);

        Command[0] = CMD_sFLASH_RD_DATA;
        Command[1] = (Addr>>16 & 0xFF);
        Command[2] = (Addr>>8  & 0xFF);
        Command[3] = (Addr     & 0xFF);
        ncDrv_SSP_Write(Command, 4);
        if((CtrlMode == DMA_MODE) && (Size>=16))
            Ret = ncSvc_SF_ReadData_DMAMode(pData, Size, InstBuff);
        else
            Ret = ncDrv_SSP_Read(pData, Size);

        ncSvc_SF_CSDisable(CSN);
    }

    return Ret;
}


void ncSvc_SF_DeInit(UINT8 CSN)
{
    // Free IO PinMux    
    ncSvc_SF_FreePadCtrl(CSN);

    // DeInit SSP
    ncDrv_SSP_DeInit();
}


void ncSvc_SF_Init(UINT8 CSN, UINT32 BitRate, UINT32 RefClk)
{
    // Set IO PinMux : Default SPI Mode
    ncSvc_SF_GetPadCtrl(CSN, SPI_MODE);

    // Init SPI
    ncDrv_SSP_Init(BitRate, RefClk);
}


/* End Of File */

