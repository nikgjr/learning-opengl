/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_ECC		SSS_ECC
 * @ingroup SSS_Library
 * @brief					ECC Core Library
 * @{
 */

/*!
 * @file		sss_lib_ecc_core.c
 * @brief		Sourcefile for ECC core function
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ********************************************/
#include "sss_lib_util.h"
#include "sss_lib_ecc_core.h"

/*************** Assertions ***********************************************/

/*************** Definitions / Macros *************************************/

/*************** Constants ************************************************/
/*!
	 * @brief ECC parameters Group (NIST P256)
	 */
	/* prime P = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF */
	const u32 zu32NIST_P256_P_rev[8] =
	{ 0xffffffffu, 0xffffffffu, 0xffffffffu, 0x00000000u, 0x00000000u, 0x00000000u,
			0x00000001u, 0xffffffffu };
	/* order n = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551 */
	const u32 zu32NIST_P256_N_rev[8] =
	{ 0xfc632551u, 0xf3b9cac2u, 0xa7179e84u, 0xbce6faadu, 0xffffffffu, 0xffffffffu,
			0x00000000u, 0xffffffffu };
	/* R^2 mod p = 0x00000004FFFFFFFDFFFFFFFFFFFFFFFEFFFFFFFBFFFFFFFF0000000000000003 */
	const u32 zu32NIST_P256_R2p_rev[8] =
	{ 0x00000003u, 0x00000000u, 0xFFFFFFFFu, 0xFFFFFFFBu, 0xFFFFFFFEu, 0xFFFFFFFFu,
			0xFFFFFFFDu, 0x00000004u };
	/* R^2 mod n = 0x66E12D94F3D956202845B2392B6BEC594699799C49BD6FA683244C95BE79EEA2 */
	const u32 zu32NIST_P256_R2n_rev[8] =
	{ 0xBE79EEA2u, 0x83244C95u, 0x49BD6FA6u, 0x4699799Cu, 0x2B6BEC59u, 0x2845B239u,
			0xF3D95620u, 0x66E12D94u };
	/* Generator x (in M-domain) = 0x18905F76A53755C679FB732B7762251075BA95FC5FEDB60179E730D418A9143C */
	const u32 zu32NIST_P256_Gx_rev[8] =
	{ 0x18A9143Cu, 0x79E730D4u, 0x5FEDB601u, 0x75BA95FCu, 0x77622510u, 0x79FB732Bu,
			0xA53755C6u, 0x18905F76u };
	/* Generator y (in M-domain) = 0x8571FF1825885D85D2E88688DD21F3258B4AB8E4BA19E45CDDF25357CE95560A */
	const u32 zu32NIST_P256_Gy_rev[8] =
	{ 0xCE95560Au, 0xDDF25357u, 0xBA19E45Cu, 0x8B4AB8E4u, 0xDD21F325u, 0xD2E88688u,
			0x25885D85u, 0x8571FF18u };
	/* coefficient a(in M-domain) = FFFFFFFC00000004000000000000000000000003FFFFFFFFFFFFFFFFFFFFFFFC */
	const u32 zu32NIST_P256_CoeA_rev[8] =
	{ 0xFFFFFFFCu, 0xFFFFFFFFu, 0xFFFFFFFFu, 0x00000003u, 0x00000000u, 0x00000000u,
			0x00000004u, 0xFFFFFFFCu };
	/* coefficient b(in M-domain) = DC30061D04874834E5A220ABF7212ED6ACF005CD78843090D89CDF6229C4BDDF */
	const u32 zu32NIST_P256_CoeB_rev[8] =
	{ 0x29C4BDDFu, 0xD89CDF62u, 0x78843090u, 0xACF005CDu, 0xF7212ED6u, 0xE5A220ABu,
			0x04874834u, 0xDC30061Du };
	/*!
	 * @brief Domain Parameter for NIST Curves
	 */
	const stECC_Param stECC_Params_NISTP256 =
	{
			OID_ECC_P256, zu32NIST_P256_Gx_rev, zu32NIST_P256_Gy_rev, zu32NIST_P256_P_rev,
			zu32NIST_P256_N_rev, zu32NIST_P256_CoeA_rev, zu32NIST_P256_CoeB_rev,
			zu32NIST_P256_R2p_rev, zu32NIST_P256_R2n_rev, 8, 256,
	};


/*************** Variable declarations ************************************/

/*************** Prototypes ***********************************************/

/*************** Function *************************************************/
void get_ECCInfo(u32 u32ECCOID, stECC_Param **pstDomainParams)
{
	switch ((u32ECCOID & 0xff))
	{
#if SSS_UNUSED
		case OID_ECC_P192:
		*pstDomainParams = (stECC_Param*) &stNISTParam[0];
		break;
		case OID_ECC_P224:
		*pstDomainParams = (stECC_Param*) &stNISTParam[1];
		break;
#endif
	case OID_ECC_P256:
		*pstDomainParams = (stECC_Param*) &stECC_Params_NISTP256;
		break;
#if SSS_UNUSED
		case OID_ECC_P384:
		*pstDomainParams = (stECC_Param*) &stNISTParam[3];
		break;
		case OID_ECC_P521:
		*pstDomainParams = (stECC_Param*) &stNISTParam[4];
		break;
		case OID_ECC_BP192:
		*pstDomainParams = (stECC_Param*) &stBPParam[0];
		break;
		case OID_ECC_BP224:
		*pstDomainParams = (stECC_Param*) &stBPParam[1];
		break;
		case OID_ECC_BP256:
		*pstDomainParams = (stECC_Param*) &stBPParam[2];
		break;
		case OID_ECC_BP384:
		*pstDomainParams = (stECC_Param*) &stBPParam[3];
		break;
		case OID_ECC_BP512:
		*pstDomainParams = (stECC_Param*) &stBPParam[4];
		break;

		case OID_ECC_25519:
		*pstDomainParams = (stECC_Param*) &stCurve25519Param[0];
		break;
#endif
	default:
		break;

	}
}

void ECC_PARAM(stECC_Param *pstDomainParam)
{
	/*! step 1. initialize */
	PKE_A_Init(pstDomainParam->u32ECC_bitsize);
	/*! Step 2. Load Param to PKA_SRAM */
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_Gx), (u32*) pstDomainParam->pu32Gx,
			pstDomainParam->u32Data_wlen);
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_Gy), (u32*) pstDomainParam->pu32Gy,
			pstDomainParam->u32Data_wlen);
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_P), (u32*) pstDomainParam->pu32PrimeP,
			pstDomainParam->u32Data_wlen);
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_N), (u32*) pstDomainParam->pu32OrderN,
			pstDomainParam->u32Data_wlen);
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_R2p),
			(u32*) pstDomainParam->pu32R2modP,
			pstDomainParam->u32Data_wlen);
	sss_memcpy_u32(ptrPKA_SEG(SEG_ID_R2n),
			(u32*) pstDomainParam->pu32R2modN,
			pstDomainParam->u32Data_wlen);
	/*
	 * todo
	 SEG_ID_ECC_Coef_A	(9)
	 SEG_ID_ECC_Coef_B	(10)

	 */
}

SSS_RV ECC_PRVKEY(stECC_PRIVKEY* pstECCkey)
{
	u32 ret = SSSR_FAIL;

	/*!step 1. seg set Private key */
	/*!- if datawordlen == 0, it will be skipped */
	sss_OS_to_BN(ptrPKA_SEG(SEG_ID_ECDSA_SignKey), &pstECCkey->stBigNum_D);

	/*!- check key validity */
	ret = chk_INPUT(SEG_ID_ECDSA_SignKey);

	return ret;
}

void ECC_PUBKEY(stECC_PUBKEY* pstECCkey)
{
	/*!step 2. seg set Pubkey key */
	/*!if datawordlen == 0, it will be skipped */
	sss_OS_to_BN(ptrPKA_SEG(SEG_ID_ECDSA_Qx), &pstECCkey->stBigNum_Qx);
	sss_OS_to_BN(ptrPKA_SEG(SEG_ID_ECDSA_Qy), &pstECCkey->stBigNum_Qy);

	/*!- move to M-domain */
	PKE_A_exe(FUNC_ID_MM, SEG_ID_ECDSA_Qx, SEG_ID_ECC_R2p,
	SEG_ID_ECC_PrimeP, SEG_ID_ECDSA_Qx, 16);
	PKE_A_exe(FUNC_ID_MM, SEG_ID_ECDSA_Qy, SEG_ID_ECC_R2p,
	SEG_ID_ECC_PrimeP, SEG_ID_ECDSA_Qy, 16);
	/* make positive for Twoterms */
	PKE_A_exe(FUNC_ID_MA, SEG_ID_ECDSA_Qx, SEG_ID_ECC_PrimeP,
	SEG_ID_ECC_PrimeP, SEG_ID_ECDSA_Qx, 16);
	PKE_A_exe(FUNC_ID_MA, SEG_ID_ECDSA_Qy, SEG_ID_ECC_PrimeP,
	SEG_ID_ECC_PrimeP, SEG_ID_ECDSA_Qy, 16);
}

SSS_RV chk_INPUT(s32 SEG_ID)
{
	s32 SEG_ID_One = SEG_15;
	s32 SEG_ID_Temp = SEG_16;
	s32 SEG_ID_Result = SEG_00;
	u32 ret = SSSR_FAIL;

	/*! > Sequence */
	/*! step 1. Assign 1*/
	PKE_A_1SEG_Clear(SEG_ID_One);
	ptrPKA_SEG(SEG_ID_One)[0] = 1;

	/*! step 2. When 1 - target ?= negative, return error */
	/*- 1.	1 - SEG_ID */
	PKE_A_exe(FUNC_ID_MS, SEG_ID_One, SEG_ID, SEG_ID_N, SEG_ID_Result,
			SEG_ID_Temp);
	if (TRUE == IS_NEGATIVE(SEG_ID_Result))
	{
		/*! step 3. When (n-1) - target ?= negative, return error */
		/*- 2.	n - 1 */
		PKE_A_exe(FUNC_ID_MS, SEG_ID_N, SEG_ID_One, SEG_ID_N, SEG_ID_Result,
				SEG_ID_Temp);
		/*- 3.	SEG_ID - (n - 1) */
		PKE_A_exe(FUNC_ID_MS, SEG_ID, SEG_ID_Result, SEG_ID_N, SEG_ID_Result,
				SEG_ID_Temp);

		if (TRUE == IS_NEGATIVE(SEG_ID_Result))
		{
			ret = SSSR_SUCCESS;
		}
	}

	return ret;
}

/*************** END OF FILE **********************************************/

/** @} */
