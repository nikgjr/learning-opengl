/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_HMACSHA		SSS_HMACSHA
 * @ingroup SSS_Driver
 * @brief					HMAC_SHA Driver & Library
 * @{
 */

/**
 * @file		sss_lib_hmac_sha256.h
 * @brief		Header for HMAC_SHA core function
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

#ifndef SSS_LIB_HMAC_SHA256_H_
#define SSS_LIB_HMAC_SHA256_H_

/*************** Include Files ************************************************/
#include "sss_lib_common.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/
/*
 * SFR Defintion for crypt_hmac_sha256_v1.30e
 */
#define HASH_CONTROL					(*(volatile u32 *)(HASH_REG_BASE + 0x0000u))
	#define HASH_SW_RESET					(1<<6)
	#define HMAC_EN							(1<<4)
	#define START_INIT_BIT					(1<<3)
#define HASH_DATA_SIZE_LOW				(*(volatile u32 *)(HASH_REG_BASE + 0x0004u))
#define HASH_BYTE_SWAP					(*(volatile u32 *)(HASH_REG_BASE + 0x000Cu))
	#define	HASH_BYTESWAP_IV				(1<<3)
	#define	HASH_BYTESWAP_KEY				(1<<2)
	#define	HASH_BYTESWAP_DO				(1<<1)
	#define	HASH_BYTESWAP_DI				(1<<0)
#define HASH_STATUS						(*(volatile u32 *)(HASH_REG_BASE + 0x0010u))
	#define HASH_MSG_DONE					(1<<1)	/**< warning!! write 1 clear */
	#define HASH_BUFFER_READY				(1<<0)
#define HASH_HMAC_KEY_IN_1				(*(volatile u32 *)(HASH_REG_BASE + 0x0020u))
#define HASH_HMAC_KEY_IN_16				(*(volatile u32 *)(HASH_REG_BASE + 0x005Cu))
#define HASH_RESULT_1					(*(volatile u32 *)(HASH_REG_BASE + 0x0060u))
#define HASH_DATA_IN_1					(*(volatile u32 *)(HASH_REG_BASE + 0x0100u))

/**
 * @brief	struct of Hash parameter for hash core function
 */
typedef struct
{
	u32 opmode; /**< operation mode = NORMAL(0), DMA(N/A), DescriptorDMA(N/A) */
	stOCTET_STRING *pstMSG; /**< message octet string */
	stOCTET_STRING *pstMACKey; /**< key octet string */
	u32 u32Block_byte_len; /**< block byte length */
	u32 u32Digest_byte_len; /**< digest byte length */

} stSHA_PARAMS;

/*************** Constants ************************************************/
/*
 * Flag
 */
#define HASH_ONLY (0x0u)
#define HMAC_FLAG (0x1u)

/*************** Variable declarations ************************************/

/*************** Error Message ********************************************/
#define ERROR_HMAC_SHA2_INVALID_LEN_KEY (ERR_KEY|INVALID_LEN|ERROR_HMAC_SHA2)
#define ERROR_HMAC_SHA2_INVALID_LEN_MSG (ERR_MSG|INVALID_LEN|ERROR_HMAC_SHA2)

/*************** Prototypes ***************************************************/
/**
 * @brief		get Hash algorithm information
 * @param[in]	u32OID				indicator of Hash algorithm
 * @param[out]	pstHASH_PARAM		pointer of HASH_PARAM structure
 * @return		N/A
 *
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
void get_HashInfo(u32 u32OID, stSHA_PARAMS *pstHASH_PARAM);

/**
 * @brief		Initialize HMAC_SHA
 * @param[in]	pstHASH_PARAM		pointer of HASH_PARAM structure
 * @param[in]	u32HMAC_Flag		indicator of HMAC operation
 *
 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV HMACSHA_init(stSHA_PARAMS* pstHASH_PARAM, u32 u32HMAC_Flag);

/**
 * @brief		hash update function
 * @param[in]	pstHASH_PARAM		pointer of HASH_PARAM structure
 * @return		N/A
 *
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
void HMACSHA_update(stSHA_PARAMS* pstHASH_PARAM);

/**
 * @brief		hash final function
 * @param[in]	pstHASH_PARAM		pointer of HASH_PARAM structure
 * @param[out]	pstDigest			pointer of Output structure
 * @return		N/A
 *
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
void HMACSHA_final(stSHA_PARAMS* pstHASH_PARAM, stOCTET_STRING* pstDigest);

/**
 * @brief		hash digest & compare function
 * @param[in]	pstInput		pointer of input structure
 * @param[in]	pu32Target		pointer of target structure

 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Matched							|
 |Others		|Mismatched							|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV sss_Hash_Compare(const stOCTET_STRING *pstInput, u32 *pu32Target);

/**
 * @brief		hmac digest & compare function
 * @param[in]	pstKey			pointer of hmac key structure
 * @param[in]	pstInput		pointer of input structure
 * @param[in]	pu32Target		pointer of target structure

 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Matched							|
 |Others		|Mismatched							|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV sss_HMAC_Compare(const stOCTET_STRING *pstKey,
						const stOCTET_STRING *pstInput, u32 *pu32Target);

/*************** END OF FILE **************************************************/

#endif /* SSS_LIB_HMAC_SHA256_H_ */

/** @} */
