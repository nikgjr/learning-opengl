/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_AES_S1		SSS_AES_S1
 * @ingroup SSS_Driver
 * @brief					AES_S1 Driver & Library
 * @{
 */

/**
 * @file		sss_lib_aes_s1.h
 * @brief		Header for AES_S1 core function
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

#ifndef SSS_LIB_AES_S1_H_
#define SSS_LIB_AES_S1_H_

/*************** Include Files ************************************************/
#include "sss_lib_common.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/
/*
 * SFR Defintion for crypt_aes_s1_v1.00e
 * @warning Key order is backward
 */
#define AES_CONTROL						(*(volatile u32 *)(AES_REG_BASE + 0x0000u))
#define OPMODE_ECB						(0<<5)
#define OPMODE_CTR						(1<<5)
#define OPMODE_CBC						(2<<5)
#define COUNTER_128BIT					(0<<3)
#define COUNTER_64BIT					(1<<3)
#define COUNTER_32BIT					(2<<3)
#define COUNTER_16BIT					(3<<3)
#define KEYSIZE_128						(0<<1)
#define KEYSIZE_192						(1<<1)
#define KEYSIZE_256						(2<<1)
#define DIRECTION_DEC					(1<<0)
#define DIRECTION_ENC					(0<<0)
#define AES_STATUS						(*(volatile u32 *)(AES_REG_BASE + 0x0004u))
#define AES_IN_READY					(1<<1)
#define AES_OUT_VALID					(1<<0)
#define AES_DATA_01						(*(volatile u32 *)(AES_REG_BASE + 0x0010u))
#define AES_DATA_04						(*(volatile u32 *)(AES_REG_BASE + 0x001Cu))
#define AES_IVCNT_01					(*(volatile u32 *)(AES_REG_BASE + 0x0030u))
#define AES_KEY_01						(*(volatile u32 *)(AES_REG_BASE + 0x0080u))


/**
 * @brief	struct of AES Key.
 */
typedef struct
{
	u32 u32KeyType; /**< type of key. {Userkey, DerivedKey by PUF/OTP/PUF_OTP} */
	stOCTET_STRING stKey; /**< struct of stOCTET_STRING to represent of AES Key */
} stAES_KEY;

/**
 * @brief	struct of AES parameter for cbc/ctr/xts mode
 *          Iv means Initial Vector or Nonce
 */
typedef struct
{
	stOCTET_STRING stIV; /**<  struct of stOCTET_STRING to represent of AES IV */
	u32 u32CntByteLen; /**< length of Counter byte length = {2, 4, 8, 16} for CTR mode only */
} stAES_PARAMS;

#if SSS_UNUSED
/**
 * @brief	struct of AES parameter for ccm/gcm mode
 *          Iv means Initial Vector or Nonce
 *			Aad means additional authentication data
 */
typedef struct
{
	stOCTET_STRING stIV; /**< struct of stOCTET_STRING to represent of AES IV */
	stOCTET_STRING stAAD; /**< struct of stOCTET_STRING to represent of AES Additional Authentication Data */
} stAES_PARAMS_AUTH;
#endif
/*************** Constants ************************************************/

/*************** Variable declarations ************************************/

/*************** Error Message ********************************************/
#define ERROR_AES_INVALID_VAL_OID (ERR_OID|INVALID_VAL|ERROR_AES)
#define ERROR_AES_INVALID_LEN_KEY (ERR_KEY|INVALID_LEN|ERROR_AES)
#define ERROR_AES_INVALID_LEN_IV  (ERR_IV |INVALID_LEN|ERROR_AES)
#define ERROR_AES_INVALID_LEN_CNT (ERR_CNT|INVALID_LEN|ERROR_AES)
#define ERROR_AES_INVALID_LEN_MSG (ERR_MSG|INVALID_LEN|ERROR_AES)

/*************** Prototypes ***********************************************/

/**
 * @brief		Initialize AES_S1
 * @param[in]	objectid			Object ID
 * @param[in]	pstAES_Key			pointer of struct for AES Key

 Name						Description												Variables
 pu08Key					array of Key
 u32KeyByteLen				Byte length of Key 										{16, 24, 32} for ECB/CBC/CTR/CCM/GCM,
 u32KeyType					Type of Key 											Userkey, DerivedKey, GENERATEDKEY such as

 * @param[in]	pstAES_Params		pointer of struct for IV Parameter

 Name						Description												Variables
 pu08Iv						array of IV, It will be updated after operation
 u32IvByteLen				Byte length of IV										depended on AES opmode


 * @return

 Error Code									Description
 SSSR_SUCCESS								Function operates normally
 Others										Fail

 * @author		kiseok.bae (kiseok.bae@samsung.com)
 * @version		V0.00

 Version	Date		Person		Description
 V0.00		2018.02.28	kiseok		Initial Version
 */
SSS_RV AESS1_init(u32 objectid, const stAES_KEY *pstAES_Key,
		stAES_PARAMS *pstAES_Params);

/**
 * @brief		aes update function
 * @param[in]	pstAES_Input		pointer of struct for AES Input

 Name						Description												Variables
 pu08Data					array of Data
 u32DataByteLen				Byte length of Data 									must be the multiple of 16 and no zero length support(16, 32, ..., 16*n)

 * @param[out]	pstAES_Output		pointer of struct for AES Output

 Name						Description												Variables
 pu08Data					array of Data
 u32DataByteLen				Byte length of Data 									zero length and byte length support, (0<= < 2^32)

 * @author		kiseok.bae (kiseok.bae@samsung.com)
 * @version		V0.00

 Version	Date		Person		Description
 V0.00		2018.02.28	kiseok		Initial Version
 */
void AESS1_update(const stOCTET_STRING *pstAES_Input,
		stOCTET_STRING *pstAES_Output);

/*************** END OF FILE **********************************************/

#endif /* SSS_LIB_AES_S1_H_ */

/** @} */
