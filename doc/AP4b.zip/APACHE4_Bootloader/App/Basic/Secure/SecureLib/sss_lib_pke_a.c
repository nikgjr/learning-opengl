/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_PKE_A		SSS_PKE_A
 * @ingroup SSS_Driver
 * @brief					PKA Driver & Library
 * @{
 */

/*!
 * @file		sss_lib_pke_a.c
 * @brief		Source file for pka library
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ************************************************/
#include "sss_lib_util.h"
#include "sss_lib_pke_a.h"
/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** New Data Types ***********************************************/

/*************** Constants ****************************************************/

/*************** Variable declarations ****************************************/

/*************** Function ****************************************************/

void PKE_A_Init(u32 Keysize)
{
	/*!
	 * > Sequence
	 */

	/*!
	 * Step1. PKA SFR & SRAM initialize
	 */
	PKE_A_Clear(FLAG_TORNADO_SFR | FLAG_TORNADO_PKARAM);

	/*!
	 * Step2. Define Chunk/Precision/Addkeysize according to Keysize
	 */
	switch (Keysize)
	{
#if SSS_UNUSED
	case 224:
		SFR_SET(PKA_SFR_0, (SEG_SIZE_036B | PREC_ID(6))); /**< (6+1)*32 = 224 */
		break;
#endif
	case 256:
		SFR_SET(PKA_SFR_0, (SEG_SIZE_036B | PREC_ID(7))); /**< (7+1)*32 = 256 */
		break;
#if SSS_UNUSED
	case 384:
		SFR_SET(PKA_SFR_0, (SEG_SIZE_068B | PREC_ID(11))); /**< (11+1)*32 = 384 */
		break;
	case 512:
		SFR_SET(PKA_SFR_0, (SEG_SIZE_068B | PREC_ID(15))); /**< (15+1)*32 = 512 */
		break;
	case 521:
		SFR_SET(PKA_SFR_0, (SEG_SIZE_068B | PREC_ID(16))); /**< (16+1)*32 = 544 */
		break;
#endif
	default:
		SFR_SET(PKA_SFR_0, 0x0u);
		break;
	}
}

void PKE_A_Clear(u32 u32Flag)
{
	/*!
	 * > Sequence
	 */

	/*!
	 * Step1. Check flag & clear
	 */
	if (u32Flag & FLAG_TORNADO_SFR)
	{
		sss_memclr_u32((u32*) (PKA_REG_BASE), 5);
	}
	if (u32Flag & FLAG_TORNADO_PKARAM)
	{
		sss_memclr_u32((u32*) (PKA_SRAM_BASE), 28 * SEGSZ_ECC256); /*Total 28-Segments*/
	}

	/*!
	 * Step2. clear Interrupt
	 * todo
	 */

}

void PKE_A_1SEG_Clear(u32 seg_id)
{
	u32 u32temp = 0;
	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : clear sign-bit of target segment
	 */
	u32temp = (~(0x01u << seg_id));
	SFR_SET(PKA_SFR_3, (PKA_SFR_3 & u32temp));

	/*!
	 * Step 2 : clear PKA_SRAM
	 * sss_memclr_u32((u32*) PKA_SEG(seg_id), SEGSZ_ECC);
	 */
	sss_memclr_u32((ptrPKA_SEG(seg_id)), SEGSZ_ECC256);
}

void PKE_A_1SEG_Copy(u32 dst_id, u32 src_id)
{
	sss_memcpy_u32(ptrPKA_SEG(dst_id), ptrPKA_SEG(src_id), SEGSZ_ECC256);

	/*! Copy Sign of [Seg_Base] */
	if (IS_NEGATIVE(src_id))
	{
		SET_SIGN(dst_id);
	}
	else
	{
		CLEAR_SIGN(dst_id);
	}
}

void PKE_A_exe(u32 f_id, u32 Seg_A, u32 Seg_B, u32 Seg_M, u32 Seg_S, u32 Seg_I)
{
	u32 u32temp = 0;
	/*!
	 * > Sequence
	 */

	/*!
	 * Step 1 : Set PKA_SFR1 with A,B,M,S Segment id
	 */
	u32temp = SEG_ID_A(
			Seg_A) | SEG_ID_B(Seg_B) | SEG_ID_M(Seg_M) | SEG_ID_S(Seg_S);
	SFR_SET(PKA_SFR_1, u32temp);

	/*!
	 * Step 2 : Set PKA_SFR2 with I Segment id
	 */
	u32temp = SEG_ID_I(Seg_I);
	SFR_SET(PKA_SFR_2, u32temp);

	/*!
	 * Step 3 : Set PKA_SFR0 with EXEC_ON
	 */
	u32temp = ((PKA_SFR_0 & 0xFFFFFF00u) | (f_id | 0x01u));
	SFR_SET(PKA_SFR_0, u32temp);

	/*!
	 * Step 4 : Wait for EXEC_ON be low
	 */
	WAIT_SFR_BIT_CLR(PKA_SFR_0, EXEC_ON);
}

/*************** Complex Function **************************************/

void Modular_Exp(u32 Seg_Base, u32 Seg_Exp, u32 Seg_Mod, u32 Seg_Res,
		u32 Seg_Int, u32 u32ECC_wlen)
{
	s32 idx_msb = (32 * u32ECC_wlen - 1);

	/*!	> Get the MSB (Most Significant Bit] of [Seg_Exp] */
	while ((ptrPKA_SEG(Seg_Exp)[idx_msb / 32] & (1 << (idx_msb % 32))) == 0)
	{
		idx_msb--;
	}

	/*!	> Copy [Seg_Base] to [Seg_Res] */
	PKE_A_1SEG_Copy(Seg_Res, Seg_Base);

	/*!	> Main Exponentiation Operation */
	do
	{
		idx_msb--;
		/*!	> Squaring Part */
		PKE_A_exe(FUNC_ID_MM, Seg_Res, Seg_Res, Seg_Mod, Seg_Res, Seg_Int);

		/*!	> Multiplication Part */
		if ((ptrPKA_SEG(Seg_Exp)[idx_msb / 32] & (1 << (idx_msb % 32))) != 0)
		{
			PKE_A_exe(FUNC_ID_MM, Seg_Res, Seg_Base, Seg_Mod, Seg_Res, Seg_Int);
		}

	} while (idx_msb > 0);

}

/*!
 * @brief		Elliptic Point Doubling: [Seg_S, Seg_S+1, Seg_S+2] <= 2 [Seg_A, Seg_A+1, Seg_A+2]
 * @param[in]		Seg_A		Segment ID for Elliptic Point [Seg_A, Seg_A+1, Seg_A+2]
 * @param[in]		Seg_M		Segment ID for Base Prime Number
 * @param[in]		Seg_S		Segment ID for Result Point [Seg_S, Seg_S+1, Seg_S+2]
 * @param[in]		Seg_I		Segment ID for Intermediate Values (Seg_I ~ Seg_I+4)

 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
static void Point_Doubling(u32 Seg_A, u32 Seg_M, u32 Seg_S, u32 Seg_I)
{
	PKE_A_exe(FUNC_ID_MA, Seg_A + 1, Seg_A + 1, Seg_M, Seg_I + 1, Seg_I); /* Step_01 */
	PKE_A_exe(FUNC_ID_MA, Seg_A, Seg_A, Seg_M, Seg_I + 2, Seg_I); /* Step_02 */
	PKE_A_exe(FUNC_ID_MM, Seg_A + 2, Seg_A + 2, Seg_M, Seg_I + 4, Seg_I); /* Step_03 */
	PKE_A_exe(FUNC_ID_MM, Seg_I + 1, Seg_A + 2, Seg_M, Seg_S + 2, Seg_I); /* Step_04 */
	PKE_A_exe(FUNC_ID_MM, Seg_I + 1, Seg_A + 1, Seg_M, Seg_I + 1, Seg_I); /* Step_05 */
	PKE_A_exe(FUNC_ID_MM, Seg_I + 1, Seg_I + 2, Seg_M, Seg_I + 3, Seg_I); /* Step_06 */
	PKE_A_exe(FUNC_ID_MM, Seg_I + 1, Seg_I + 1, Seg_M, Seg_I + 1, Seg_I); /* Step_07 */
	PKE_A_exe(FUNC_ID_MA, Seg_I + 1, Seg_I + 1, Seg_M, Seg_I + 1, Seg_I); /* Step_08 */
	PKE_A_exe(FUNC_ID_MA, Seg_A, Seg_I + 4, Seg_M, Seg_I + 2, Seg_I); /* Step_09 */
	PKE_A_exe(FUNC_ID_MS, Seg_A, Seg_I + 4, Seg_M, Seg_I + 4, Seg_I); /* Step_10 */
	PKE_A_exe(FUNC_ID_MM, Seg_I + 2, Seg_I + 4, Seg_M, Seg_I + 4, Seg_I); /* Step_11 */
	PKE_A_exe(FUNC_ID_MA, Seg_I + 4, Seg_I + 4, Seg_M, Seg_I + 2, Seg_I); /* Step_12 */
	PKE_A_exe(FUNC_ID_MA, Seg_I + 2, Seg_I + 4, Seg_M, Seg_I + 4, Seg_I); /* Step_13 */
	PKE_A_exe(FUNC_ID_MM, Seg_I + 4, Seg_I + 4, Seg_M, Seg_I + 2, Seg_I); /* Step_14 */
	PKE_A_exe(FUNC_ID_MA, Seg_I + 3, Seg_I + 3, Seg_M, Seg_S, Seg_I); /* Step_15 */
	PKE_A_exe(FUNC_ID_MS, Seg_I + 2, Seg_S, Seg_M, Seg_S, Seg_I); /* Step_16 */
	PKE_A_exe(FUNC_ID_MS, Seg_I + 3, Seg_S, Seg_M, Seg_S + 1, Seg_I); /* Step_17 */
	PKE_A_exe(FUNC_ID_MM, Seg_S + 1, Seg_I + 4, Seg_M, Seg_S + 1, Seg_I); /* Step_18 */
	PKE_A_exe(FUNC_ID_MS, Seg_S + 1, Seg_I + 1, Seg_M, Seg_S + 1, Seg_I); /* Step_19 */
}

/*!
 * @brief		Elliptic Point Addition:
 * 					[Seg_S, Seg_S+1, Seg_S+2] <= [Seg_A, Seg_A+1, Seg_A+2] + [Seg_B, Seg_B+1]
 * @param[in]		Seg_A		    Segment ID for First Point [Seg_A, Seg_A+1, Seg_A+2]
 * @param[in]		Seg_B		    Segment ID for Second Point [Seg_B, Seg_B+1]
 * @param[in]		Seg_M		    Segment ID for Base Prime Number
 * @param[in]		Seg_S		    Segment ID for Result Point [Seg_S, Seg_S+1, Seg_S+2]
 * @param[in]		Seg_I		    Segment ID for Intermediate Values (Seg_I ~ Seg_I+4)
 * @param[in]		u32ECC_wlen	    Word Length of Base Prime Number
 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
static void Point_Addition(u32 Seg_A, u32 Seg_B, u32 Seg_M, u32 Seg_S,
		u32 Seg_I, u32 u32ECC_wlen)
{
	u32 u32Flag_C, u32Flag_D;
	u32 zu32ECC_wlen = u32ECC_wlen;

	if (zu32ECC_wlen == 7)
	{
		zu32ECC_wlen++;
	}

	/*!	> If [Seg_A+2]==0 then [Seg_S, Seg_S+1, Seg_S+2] <= [Seg_B, Seg_B+1, 1] & return */
	/* sss_memclr_u32(ptrPKA_SEG(Seg_I + 4), u32ECC_wlen); */
	/* Step_01 */
	PKE_A_1SEG_Clear(Seg_I + 4);
	ptrPKA_SEG(Seg_I + 4)[0] = 1;
	/* Step_02 */
	PKE_A_exe(FUNC_ID_MA, Seg_A + 2, Seg_M, Seg_M, Seg_I + 3, Seg_I);
	PKE_A_exe(FUNC_ID_MS, Seg_I + 3, Seg_I + 4, Seg_M, Seg_I + 2, Seg_I);
	/*	Step_04 */
	if (IS_NEGATIVE(Seg_I + 2))
	{
		/*! Case B is INFINITY : return A to S */
		/*	Sx */
		PKE_A_1SEG_Copy(Seg_S, Seg_B);

		/*	Sy */
		PKE_A_1SEG_Copy((Seg_S + 1), (Seg_B + 1));

		/*	Sz */
		PKE_A_exe(FUNC_ID_M1, Seg_M + 1, SEG_XX, Seg_M, Seg_S + 2, Seg_I);
	}
	else
	{
		/*!	>> Check if A==B or A==-B */
		PKE_A_exe(FUNC_ID_MM, Seg_A + 2, Seg_A + 2, Seg_M, Seg_I + 1, SEG_XX);/*	Step_05 */
		PKE_A_exe(FUNC_ID_MM, Seg_A + 2, Seg_I + 1, Seg_M, Seg_I + 2, SEG_XX);/*	Step_06 */
		PKE_A_exe(FUNC_ID_MM, Seg_I + 1, Seg_B, Seg_M, Seg_I + 1, Seg_I); /*	Step_07 */
		PKE_A_exe(FUNC_ID_MM, Seg_I + 2, Seg_B + 1, Seg_M, Seg_I + 2, Seg_I); /*	Step_08 */
		PKE_A_exe(FUNC_ID_MS, Seg_A, Seg_I + 1, Seg_M, Seg_I + 3, Seg_I); /*	Step_09 */
		PKE_A_exe(FUNC_ID_MS, Seg_I + 1, Seg_A, Seg_M, Seg_I + 1, Seg_I); /*	Step_10 */
		u32Flag_C = IS_NEGATIVE(Seg_I+3) ^ IS_NEGATIVE(Seg_I + 1); /*	Step_11 */
		PKE_A_exe(FUNC_ID_MS, Seg_I + 1, Seg_I + 2, Seg_M, Seg_I + 3, Seg_I); /*	Step_12 */
		PKE_A_exe(FUNC_ID_MS, Seg_I + 2, Seg_A + 1, Seg_M, Seg_I + 2, Seg_I); /*	Step_13 */
		u32Flag_D = IS_NEGATIVE(Seg_I+3) ^ IS_NEGATIVE(Seg_I + 2); /*	Step_14 */

		if (u32Flag_C == 0)
		{
			/*!	>> Case A==B, then return A+A */
			if (u32Flag_D == 0) /*	Case of A=B */
			{
				Point_Doubling(Seg_A, Seg_M, Seg_S, Seg_I);
			}
			/*!	>> Case A==-B, then return INFINITY*/
			else /*	Case of A=-B*/
			{
				PKE_A_exe(FUNC_ID_MS, Seg_M, Seg_M, Seg_M, Seg_S + 2, Seg_I);
			}
		}
		else
		{
			/*! >> Case General, point addition */
			PKE_A_exe(FUNC_ID_MM, Seg_A + 2, Seg_I + 1, Seg_M, Seg_S + 2,
			SEG_XX);/*	Step_16 */
			PKE_A_exe(FUNC_ID_MM, Seg_I + 1, Seg_I + 1, Seg_M, Seg_I + 3,
			SEG_XX);/*	Step_17 */
			PKE_A_exe(FUNC_ID_MM, Seg_I + 1, Seg_I + 3, Seg_M, Seg_I + 1,
					Seg_I); /*	Step_18 */
			PKE_A_exe(FUNC_ID_MM, Seg_I + 3, Seg_A, Seg_M, Seg_I + 3, Seg_I); /*	Step_19 */
			PKE_A_exe(FUNC_ID_MA, Seg_I + 3, Seg_I + 3, Seg_M, Seg_I + 4,
			SEG_XX);/*	Step_20 */
			PKE_A_exe(FUNC_ID_MA, Seg_I + 4, Seg_I + 1, Seg_M, Seg_I + 4,
					Seg_I); /*	Step_21 */
			PKE_A_exe(FUNC_ID_MM, Seg_I + 2, Seg_I + 2, Seg_M, Seg_S, SEG_XX);/*	Step_22 */
			PKE_A_exe(FUNC_ID_MS, Seg_S, Seg_I + 4, Seg_M, Seg_S, SEG_XX); /*	Step_23 */
			PKE_A_exe(FUNC_ID_MM, Seg_I + 1, Seg_A + 1, Seg_M, Seg_I + 1,
					Seg_I); /*	Step_24 */
			PKE_A_exe(FUNC_ID_MS, Seg_I + 3, Seg_S, Seg_M, Seg_I + 3, Seg_I); /*	Step_25 */
			PKE_A_exe(FUNC_ID_MM, Seg_I + 3, Seg_I + 2, Seg_M, Seg_I + 3,
					Seg_I); /*	Step_26 */
			PKE_A_exe(FUNC_ID_MS, Seg_I + 3, Seg_I + 1, Seg_M, Seg_S + 1,
			SEG_XX);/*	Step_27 */

		}
	}
}

void Scalar_Mul(u32 u32ECC_wlen)
{
	/*	Input:	FUNC_ID_SM indicate Scalar Multiplication
	 SegA (SEG_02): Scalar value		(=u)
	 SegA+1 (SEG_03): X of G		(Montgomery-Space over P)
	 SegA+2 (SEG_04): Y of G		(Montgomery-Space over P)
	 SegB (SEG_XX): Un-Used
	 SegM (SEG_05): Prime P
	 SegM+1 (SEG_06): R^2 Value of Prime P
	 SegS (SEG_13): X of result k(Seg.02) * G(Seg.03, Seg.04)		(Montgomery-Space over P)
	 SegS+1 (SEG_14): Y of result k(Seg.02) * G(Seg.03, Seg.04)	(Montgomery-Space over P)
	 SegI (SEG_16~SEG_25): Intermediate Segments
	 */
	s32 idx_msb = (32 * u32ECC_wlen);
	u32 sign_scalar = 0;

	/*!	Compute (SEG_ID_Int_05) <- (SEG_ID_P) - 2 = p-2 */
	sss_memclr_u32(ptrPKA_SEG(SEG_ID_Int_05), u32ECC_wlen);
	ptrPKA_SEG(SEG_ID_Int_05)[0] = 2;
	PKE_A_exe(FUNC_ID_MS, SEG_ID_P, SEG_ID_Int_05, SEG_ID_P, SEG_ID_Int_05,
	SEG_ID_Int_00);

	/*!	> Find MSB of Scalar Value */
	do
	{
		idx_msb--;
		sign_scalar = (ptrPKA_SEG(SEG_ID_K)[idx_msb / 32] >> (idx_msb % 32));
	} while (FALSE == (sign_scalar));

	/*!	> Starting Elliptic Point */
	PKE_A_1SEG_Copy(SEG_ID_Int_06, SEG_ID_Gx);
	PKE_A_1SEG_Copy(SEG_ID_Int_07, SEG_ID_Gy);
	/* z */
	PKE_A_exe(FUNC_ID_M1, SEG_ID_R2p, SEG_XX, SEG_ID_P, SEG_ID_Int_08,
	SEG_ID_Int_00);

	/*!	> Core Part */
	do
	{
		idx_msb--;
		/*!	> point doubling */
		Point_Doubling(SEG_ID_Int_06, SEG_ID_P, SEG_ID_Int_06, SEG_ID_Int_00);

		sign_scalar = 0x1
				& ((ptrPKA_SEG(SEG_ID_K)[idx_msb / 32] >> (idx_msb % 32)));

		/*!	> point addition */
		if (TRUE == sign_scalar)
		{
			Point_Addition(SEG_ID_Int_06, SEG_ID_Gx, SEG_ID_P, SEG_ID_Int_06,
			SEG_ID_Int_00, u32ECC_wlen);
		}
	} while (idx_msb > 0);


	/*!	> Coordinate Conversion */
	PKE_A_exe(FUNC_ID_MM, SEG_ID_Int_08, SEG_ID_Int_08, SEG_ID_P, SEG_ID_Int_01,
	SEG_ID_Int_00); /*	Z^2 */
	PKE_A_exe(FUNC_ID_MM, SEG_ID_Int_01, SEG_ID_Int_08, SEG_ID_P, SEG_ID_Int_02,
	SEG_ID_Int_00); /*	Z^3 */
	Modular_Exp(SEG_ID_Int_02, SEG_ID_Int_05, SEG_ID_P, SEG_ID_Int_04,
	SEG_ID_Int_00, u32ECC_wlen); /*	Z^-3 */
	PKE_A_exe(FUNC_ID_MM, SEG_ID_Int_04, SEG_ID_Int_08, SEG_ID_P, SEG_ID_Int_03,
	SEG_ID_Int_00); /*	Z^-2 */
	PKE_A_exe(FUNC_ID_MM, SEG_ID_Int_06, SEG_ID_Int_03, SEG_ID_P, SEG_ID_Rx,
	SEG_ID_Int_00); /*	X * Z^-2 */
	PKE_A_exe(FUNC_ID_MM, SEG_ID_Int_07, SEG_ID_Int_04, SEG_ID_P, SEG_ID_Ry,
	SEG_ID_Int_00); /*	Y * Z^-3 */
}

void TwoTerm_Scalar_Mul(u32 u32ECC_wlen)
{
	s32 idx_msb = (32 * u32ECC_wlen);
	u32 sign_scalar1 = 0;
	u32 sign_scalar2 = 0;

	/*!	Step.1 p-2 */
	PKE_A_1SEG_Clear(SEG_ID_Int_05);
	ptrPKA_SEG(SEG_ID_Int_05)[0] = 2;
	PKE_A_exe(FUNC_ID_MS, SEG_ID_P, SEG_ID_Int_05, SEG_ID_P, SEG_ID_Int_05,
	SEG_ID_Int_00);

	/*!	Step 2. Precompute A+B = SEG_09/10 */
	PKE_A_exe(FUNC_ID_MS, SEG_ID_Gx2, SEG_ID_Gx, SEG_ID_P, SEG_ID_Int_01,
	SEG_ID_Int_00);
	Modular_Exp(SEG_ID_Int_01, SEG_ID_Int_05, SEG_ID_P, SEG_ID_Int_02,
	SEG_ID_Int_00, u32ECC_wlen);

	PKE_A_exe(FUNC_ID_MS, SEG_ID_Gy2, SEG_ID_Gy, SEG_ID_P, SEG_ID_Int_01,
	SEG_ID_Int_00);
	PKE_A_exe(FUNC_ID_MM, SEG_ID_Int_01, SEG_ID_Int_02, SEG_ID_P, SEG_ID_Int_10,
	SEG_ID_Int_00);
	PKE_A_exe(FUNC_ID_MM, SEG_ID_Int_10, SEG_ID_Int_10, SEG_ID_P, SEG_ID_Int_09,
	SEG_ID_Int_00);
	PKE_A_exe(FUNC_ID_MS, SEG_ID_Int_09, SEG_ID_Gx, SEG_ID_P, SEG_ID_Int_09,
	SEG_ID_Int_00);
	PKE_A_exe(FUNC_ID_MS, SEG_ID_Int_09, SEG_ID_Gx2, SEG_ID_P, SEG_ID_Int_09,
	SEG_ID_Int_00);
	PKE_A_exe(FUNC_ID_MS, SEG_ID_Gx, SEG_ID_Int_09, SEG_ID_P, SEG_ID_Int_03,
	SEG_ID_Int_00);
	PKE_A_exe(FUNC_ID_MM, SEG_ID_Int_10, SEG_ID_Int_03, SEG_ID_P, SEG_ID_Int_10,
	SEG_ID_Int_00);
	PKE_A_exe(FUNC_ID_MS, SEG_ID_Int_10, SEG_ID_Gy, SEG_ID_P, SEG_ID_Int_10,
	SEG_ID_Int_00);
	PKE_A_exe(FUNC_ID_MA, SEG_ID_Int_09, SEG_ID_P, SEG_ID_P, SEG_ID_Int_09,
	SEG_ID_Int_00);
	PKE_A_exe(FUNC_ID_MA, SEG_ID_Int_10, SEG_ID_P, SEG_ID_P, SEG_ID_Int_10,
	SEG_ID_Int_00);

	/*!	Step.3 Get the MSB (Most Significant Bit] of [u, v] */
	do
	{
		idx_msb--;
		sign_scalar1 = (ptrPKA_SEG(SEG_ID_K)[idx_msb / 32] >> (idx_msb % 32));
		sign_scalar2 = (ptrPKA_SEG(SEG_ID_K2)[idx_msb / 32] >> (idx_msb % 32));
	} while (FALSE == (sign_scalar1 | sign_scalar2));

	/*!	> Copy start point */
	if ((sign_scalar1 == 0) && (sign_scalar2 == 1))
	{
		/*	Set (SEG_ID_Int_06/7/8) <- (SEG_ID_Gx2/Gy2/RmodP) = B */
		PKE_A_1SEG_Copy(SEG_ID_Int_06, SEG_ID_Gx2);
		PKE_A_1SEG_Copy(SEG_ID_Int_07, SEG_ID_Gy2);
	}
	else if ((sign_scalar1 == 1) && (sign_scalar2 == 0))
	{
		/*	Set (SEG_ID_Int_06/7/8) <- (SEG_ID_Gx/Gy/RmodP) = A */
		PKE_A_1SEG_Copy(SEG_ID_Int_06, SEG_ID_Gx);
		PKE_A_1SEG_Copy(SEG_ID_Int_07, SEG_ID_Gy);
	}
	else
	{
		/*	Set (SEG_ID_Int_06/7/8) <- (SEG_ID_Int_09/10/RmodP) = A+B */
		PKE_A_1SEG_Copy(SEG_ID_Int_06, SEG_ID_Int_09);
		PKE_A_1SEG_Copy(SEG_ID_Int_07, SEG_ID_Int_10);
	}
	/* z */
	PKE_A_exe(FUNC_ID_M1, SEG_ID_R2p, SEG_XX, SEG_ID_P, SEG_ID_Int_08,
	SEG_ID_Int_00);

	/*!	> Main Loop */
	do
	{
		idx_msb--;
		/*!	> point doubling */
		Point_Doubling(SEG_ID_Int_06, SEG_ID_P, SEG_ID_Int_06, SEG_ID_Int_00);
		sign_scalar1 = 0x1
				& ((ptrPKA_SEG(SEG_ID_K)[idx_msb / 32] >> (idx_msb % 32)));
		sign_scalar2 = 0x1
				& ((ptrPKA_SEG(SEG_ID_K2)[idx_msb / 32] >> (idx_msb % 32)));
		/*!	> point addition */
		switch ((sign_scalar1 << 1) | sign_scalar2)
		{
		case 1:
			Point_Addition(SEG_ID_Int_06, SEG_ID_Gx2, SEG_ID_P,
			SEG_ID_Int_06, SEG_ID_Int_00, u32ECC_wlen);
			break;

		case 2:
			Point_Addition(SEG_ID_Int_06, SEG_ID_Gx, SEG_ID_P,
			SEG_ID_Int_06, SEG_ID_Int_00, u32ECC_wlen);
			break;

		case 3:
			Point_Addition(SEG_ID_Int_06, SEG_ID_Int_09, SEG_ID_P,
			SEG_ID_Int_06, SEG_ID_Int_00, u32ECC_wlen);
			break;

		default:
			break;
		}
	} while (idx_msb > 0);

	/*!	> Coordinate Conversion */
	PKE_A_exe(FUNC_ID_MM,
	SEG_ID_Int_08, SEG_ID_Int_08, SEG_ID_P, SEG_ID_Int_01,
	SEG_ID_Int_00); /*	Z^2 */
	PKE_A_exe(FUNC_ID_MM,
	SEG_ID_Int_01, SEG_ID_Int_08, SEG_ID_P, SEG_ID_Int_02,
	SEG_ID_Int_00); /*	Z^3 */
	Modular_Exp(SEG_ID_Int_02, SEG_ID_Int_05, SEG_ID_P, SEG_ID_Int_04,
	SEG_ID_Int_00, u32ECC_wlen); /*	Z^-3 */
	PKE_A_exe(FUNC_ID_MM,
	SEG_ID_Int_04, SEG_ID_Int_08, SEG_ID_P, SEG_ID_Int_03,
	SEG_ID_Int_00); /*	Z^-2 */
	PKE_A_exe(FUNC_ID_MM,
	SEG_ID_Int_06, SEG_ID_Int_03, SEG_ID_P, SEG_ID_Rx,
	SEG_ID_Int_00); /*	X * Z^-2 */
	PKE_A_exe(FUNC_ID_MM,
	SEG_ID_Int_07, SEG_ID_Int_04, SEG_ID_P, SEG_ID_Ry,
	SEG_ID_Int_00); /*	Y * Z^-3 */
}

/******* End of File **********************************************************/

/** @} */
