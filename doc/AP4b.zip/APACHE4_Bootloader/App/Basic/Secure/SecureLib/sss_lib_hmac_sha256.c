/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_HMACSHA		SSS_HMACSHA
 * @ingroup SSS_Driver
 * @brief					HMAC_SHA Driver & Library
 * @{
 */

/**
 * @file		sss_lib_hmac_sha256.c
 * @brief		Source for HMAC_SHA core function
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ************************************************/
#include "sss_lib_hmac_sha256.h"
#include "sss_lib_util.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ****************************************************/

/*************** Prototypes ***************************************************/
void get_HashInfo(u32 u32OID, stSHA_PARAMS *pstHASH_PARAM)
{
	/*! > Get hash parameters using the variable written at HASH_CONTROL */
	switch ((u32OID & 0xff00u))
	{
	case OID_SHA2_256:
		/*! - case : HASH_CONTROL_SHA2_256 */
		/*! 	+ block length : 16 word */
		/*! 	+ hash output length : 8 word */
		pstHASH_PARAM->u32Block_byte_len = 64;
		pstHASH_PARAM->u32Digest_byte_len = 32;
		break;

	default:
		pstHASH_PARAM->u32Block_byte_len = 0;
		pstHASH_PARAM->u32Digest_byte_len = 0;
		break;
	}
}

static SSS_RV HMACKEY(stSHA_PARAMS* pstHASH_PARAM)
{
	u32 ret = SSSR_SUCCESS;

	sss_memclr_u32((u32*) &HASH_HMAC_KEY_IN_1,
			(pstHASH_PARAM->u32Block_byte_len / 4));

	if (pstHASH_PARAM->u32Block_byte_len
			>= pstHASH_PARAM->pstMACKey->u32DataByteLen)
	{
		sss_OS_to_SFR((u32*) &HASH_HMAC_KEY_IN_1, pstHASH_PARAM->pstMACKey);

		SFR_BIT_SET(HASH_CONTROL, HMAC_EN);
	}
	else
	{
		ret = ERROR_HMAC_SHA2_INVALID_LEN_KEY;
	}

	return ret;
}

SSS_RV HMACSHA_init(stSHA_PARAMS* pstHASH_PARAM, u32 u32HMAC_Flag)
{
	u32 ret = SSSR_SUCCESS;
	/*! > Sequence */

	/*! Step1. HMAC_SHA SFR Clear & SWAP */
	SFR_SET(HASH_CONTROL, HASH_SW_RESET);
	SFR_SET(HASH_BYTE_SWAP,
			(HASH_BYTESWAP_IV|HASH_BYTESWAP_KEY|HASH_BYTESWAP_DO|HASH_BYTESWAP_DI));

	/*! Step2. Set the message size in bytes */
	SFR_SET(HASH_DATA_SIZE_LOW, pstHASH_PARAM->pstMSG->u32DataByteLen);

	/*! Step3. HMAC Setting if HMAC */
	if (u32HMAC_Flag)
	{
		ret = HMACKEY(pstHASH_PARAM);
	}

	/*! Step4. Start HMAC_SHA */
	if (SSSR_SUCCESS == ret)
	{
		SFR_BIT_SET(HASH_CONTROL, START_INIT_BIT);
	}

	return ret;
}

void HMACSHA_update(stSHA_PARAMS* pstHASH_PARAM)
{
	stOCTET_STRING stTemp;
	u32 u32ByteLen = pstHASH_PARAM->pstMSG->u32DataByteLen;

	stTemp.pu08Data = pstHASH_PARAM->pstMSG->pu08Data;
	stTemp.u32DataByteLen = pstHASH_PARAM->u32Block_byte_len;

	/*! > Sequence */
	while (u32ByteLen != 0)
	{
		WAIT_SFR_BIT_SET(HASH_STATUS, HASH_BUFFER_READY);

		if(u32ByteLen < pstHASH_PARAM->u32Block_byte_len)
		{
			stTemp.u32DataByteLen = u32ByteLen;
		}
		sss_OS_to_SFR((u32*) &HASH_DATA_IN_1, &stTemp);
		stTemp.pu08Data += stTemp.u32DataByteLen;
		u32ByteLen -= stTemp.u32DataByteLen;
	}
}

void HMACSHA_final(stSHA_PARAMS* pstHASH_PARAM, stOCTET_STRING* pstDigest)
{
	u32 *pu32Src;
	static const u08 zu08SHA256_NullDigest[32] =
	{ 0xe3u, 0xb0u, 0xc4u, 0x42u, 0x98u, 0xfcu, 0x1cu, 0x14u, 0x9au, 0xfbu,
			0xf4u, 0xc8u, 0x99u, 0x6fu, 0xb9u, 0x24u, 0x27u, 0xaeu, 0x41u,
			0xe4u, 0x64u, 0x9bu, 0x93u, 0x4cu, 0xa4u, 0x95u, 0x99u, 0x1bu,
			0x78u, 0x52u, 0xb8u, 0x55u };
	/*!
	 * > Sequence
	 */

	/*!
	 * Step1. Wait for Done
	 */
	if (pstHASH_PARAM->pstMSG->u32DataByteLen != 0)
	{
		WAIT_SFR_BIT_SET(HASH_STATUS, HASH_MSG_DONE);

		SFR_W0i1C(HASH_STATUS, HASH_MSG_DONE);

		pu32Src = (u32*) &HASH_RESULT_1;
	}
	else
	{
		/*!
		 * Step1-1. Zero message
		 */
		pu32Src = (u32*) zu08SHA256_NullDigest;
	}

	/*!
	 * Step2. update to Output
	 */
	pstDigest->u32DataByteLen = pstHASH_PARAM->u32Digest_byte_len;
	sss_SFR_to_OS(pstDigest, pu32Src);

}

SSS_RV sss_Hash_Compare(const stOCTET_STRING *pstInput, u32 *pu32Target)
{
	u32 ret;
	stSHA_PARAMS zstHASH_Param;
	stOCTET_STRING zstDigest;
	u08 zu08Temp[32];

	/*! > Step 0. Get Hash param data */
	get_HashInfo(OID_SHA2_256, &zstHASH_Param);
	/* assign message to param */
	zstHASH_Param.pstMSG = (stOCTET_STRING*) pstInput;

	/*! > Step 1. Hash init */
	ret = HMACSHA_init(&zstHASH_Param, HASH_ONLY);
	if (SSSR_SUCCESS == ret)
	{
		/*! > Step 2. Hash update during msg > block */
		if (zstHASH_Param.pstMSG->u32DataByteLen != 0)
		{
			HMACSHA_update(&zstHASH_Param);
		}
		zstDigest.pu08Data = zu08Temp;

		/*! > Step 3. Hash final */
		HMACSHA_final(&zstHASH_Param, &zstDigest);

		/*! > Step 4. Compare*/
		ret = sss_memcmp_u32(pu32Target, (u32 *) zu08Temp,
				zstHASH_Param.u32Digest_byte_len / 4);
	}

	return ret;
}

SSS_RV sss_HMAC_Compare(const stOCTET_STRING *pstKey,
		const stOCTET_STRING *pstInput, u32 *pu32Target)
{
	u32 ret;
	stSHA_PARAMS zstHASH_Param;
	stOCTET_STRING zstDigest;
	u08 zu08Temp[32];

	zstDigest.pu08Data = zu08Temp;

	/*! > Step 0. Get Hash param data */
	get_HashInfo(OID_SHA2_256, &zstHASH_Param);
	/* assign message to param */
	zstHASH_Param.pstMSG = (stOCTET_STRING*) pstInput;

	/* assign key to param */
	zstHASH_Param.pstMACKey = (stOCTET_STRING*) pstKey;

	/*! > Step 2. HMAC init */
	ret = HMACSHA_init(&zstHASH_Param, HMAC_FLAG);
	if (SSSR_SUCCESS == ret)
	{
		/*! > Step 3. HMAC update during msg > block */
		if (zstHASH_Param.pstMSG->u32DataByteLen != 0)
		{
			HMACSHA_update(&zstHASH_Param);
		}

		/*! > Step 4. HMAC final */
		HMACSHA_final(&zstHASH_Param, &zstDigest);

		/*! > Step 4. Compare*/
		ret = sss_memcmp_u32(pu32Target, (u32 *) zstDigest.pu08Data,
				zstHASH_Param.u32Digest_byte_len / 4);
	}

	return ret;
}
/*************** END OF FILE **************************************************/

/** @} */
