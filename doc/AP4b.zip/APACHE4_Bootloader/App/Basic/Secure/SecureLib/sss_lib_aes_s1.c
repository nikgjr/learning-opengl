/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_AES_S1		SSS_AES_S1
 * @ingroup SSS_Driver
 * @brief					AES_S1 Driver & Library
 * @{
 */

/**
 * @file		sss_lib_aes_s1.c
 * @brief		Sourcefile for AES_S1 core function
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ************************************************/
#include "sss_lib_util.h"
#include "sss_lib_aes_s1.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ************************************************/

/*************** Variable declarations ************************************/

/*************** Error Message ********************************************/

/*************** Prototypes ***************************************************/

static void AES_MODE(u32 objectid, u32 *pu32AES_Control)
{
	u32 u32AES_Control = 0;

	switch (GET_AES_MODE(objectid))
	{
	case OID_AES_ECB:
		u32AES_Control |= OPMODE_ECB;
		break;
	case OID_AES_CBC:
		u32AES_Control |= OPMODE_CBC;
		break;
	case OID_AES_CTR:
		u32AES_Control |= OPMODE_CTR;
		break;
	default:
		break;
	}

	*pu32AES_Control = u32AES_Control;
}

static void AES_DIRECTION(u32 objectid, u32 *pu32AES_Control)
{
	u32 u32AES_Control = GET_ENC_DIRECTION(objectid);

	*pu32AES_Control |= u32AES_Control;
}

static SSS_RV AES_KEY(const stAES_KEY *pstAES_Key, u32 *pu32AES_Control)
{
	u32 ret = SSSR_SUCCESS;
	u32 u32AES_Control = 0;

	switch (pstAES_Key->stKey.u32DataByteLen)
	{
	case 16:
		u32AES_Control = KEYSIZE_128;
		break;
	case 24:
		u32AES_Control = KEYSIZE_192;
		break;
	case 32:
		u32AES_Control = KEYSIZE_256;
		break;
	default:
		ret = ERROR_AES_INVALID_LEN_KEY;
		break;
	}

	if (SSSR_SUCCESS == ret)
	{
		*pu32AES_Control |= u32AES_Control;
		sss_OS_to_BN((u32*) &AES_KEY_01, &pstAES_Key->stKey);
	}

	return ret;
}

static SSS_RV AES_IV(const stOCTET_STRING *pstIV)
{
	u32 ret = SSSR_SUCCESS;

	/*
	 * - check CBC IV is 16byte
	 */

	if (pstIV->u32DataByteLen != 16)
	{
		ret = ERROR_AES_INVALID_LEN_IV;
	}
	else
	{
		sss_OS_to_BN((u32*) &AES_IVCNT_01, pstIV);
	}

	return ret;
}

static SSS_RV AES_Counter(const stOCTET_STRING *pstNonce, u32 u32CounterByteLen)
{
	u32 ret = SSSR_SUCCESS;

	/*
	 * - check CTR Nonce is 16byte
	 */
	if (pstNonce->u32DataByteLen != 16)
	{
		ret = ERROR_AES_INVALID_LEN_IV;
	}
	else
	{
		/*
		 * - check CTR Counter length & SFR setting
		 */
		switch (u32CounterByteLen)
		{
		case 2:
			SFR_BIT_SET(AES_CONTROL, COUNTER_16BIT);
			break;
		case 4:
			SFR_BIT_SET(AES_CONTROL, COUNTER_32BIT);
			break;
		case 8:
			SFR_BIT_SET(AES_CONTROL, COUNTER_64BIT);
			break;
		case 16:
			SFR_BIT_SET(AES_CONTROL, COUNTER_128BIT);
			break;
		default:
			ret = ERROR_AES_INVALID_LEN_CNT;
			break;
		}

		if (SSSR_SUCCESS == ret)
		{
			sss_OS_to_BN((u32*) &AES_IVCNT_01, pstNonce);
		}
	}

	return ret;
}

static SSS_RV AES_PARAM(u32 objectid, const stAES_PARAMS *pstAES_Params)
{
	u32 ret = SSSR_SUCCESS;

	switch (GET_AES_MODE(objectid))
	{
	case OID_AES_ECB:
		/*!
		 * none
		 */
		break;

	case OID_AES_CBC:
		ret = AES_IV(&pstAES_Params->stIV);
		break;

	case OID_AES_CTR:
		ret = AES_Counter(&pstAES_Params->stIV, pstAES_Params->u32CntByteLen);
		break;

	default:
		ret = ERROR_AES_INVALID_VAL_OID;
		break;

	}

	return ret;
}

static void AESS1_Clear(void)
{
	/*!
	 * > Sequence
	 */

	/*!
	 * Step1. AES SFR initialize
	 */
	SFR_SET(AES_CONTROL, 0x0);
	sss_memclr_u32((u32*) (&AES_IVCNT_01), 4);
	sss_memclr_u32((u32*) (&AES_KEY_01), 8);

}

SSS_RV AESS1_init(u32 objectid, const stAES_KEY *pstAES_Key,
		stAES_PARAMS *pstAES_Params)
{
	u32 ret = SSSR_SUCCESS;
	u32 u32AES_Control = 0;
	/*!
	 * > Sequence
	 */

	/*!
	 * Step1. AES_S1 SFR clear
	 */
	AESS1_Clear();

	/*!
	 * Step2. AES Mode Selection
	 */
	AES_MODE(objectid, &u32AES_Control);

	/*!
	 * Step3. AES Direction Selection
	 */
	AES_DIRECTION(objectid, &u32AES_Control);

	/*!
	 * Step4. AES Key Selection
	 */
	ret = AES_KEY(pstAES_Key, &u32AES_Control);
	if (SSSR_SUCCESS == ret)
	{

		/*!
		 * Step5. AES Setting
		 */
		SFR_SET(AES_CONTROL, u32AES_Control);
		ret = AES_PARAM(objectid, pstAES_Params);
	}

	return ret;
}

void AESS1_update(const stOCTET_STRING *pstAES_Input,
		stOCTET_STRING *pstAES_Output)
{
	stOCTET_STRING stTemp_In;
	stOCTET_STRING stTemp_Out;
	s32 u32ByteLen = (s32) pstAES_Input->u32DataByteLen;

	stTemp_In.pu08Data = pstAES_Input->pu08Data;
	stTemp_In.u32DataByteLen = 16;
	stTemp_Out.pu08Data = pstAES_Output->pu08Data;
	stTemp_Out.u32DataByteLen = 16;

	/*!
	 * > Sequence
	 */

	/*!
	 * Step1.Encrypt or Decrypt blocks
	 */
	for (; u32ByteLen > 0; u32ByteLen -= 16)
	{
		/*!
		 * Step 2. Encrypt or Decrypt blocks
		 */
		WAIT_SFR_BIT_SET(AES_STATUS, AES_IN_READY);

		/*!
		 * Step 3. Copy message to SFR
		 * Run AES automatically after writing 4 words in AES_INDATA register.
		 */
		sss_OS_to_BN(((u32*) &AES_DATA_01), &stTemp_In);

		/*!
		 * Step 4. Check Output ready SFR
		 */
		WAIT_SFR_BIT_SET(AES_STATUS, AES_OUT_VALID);

		/*!
		 * Step 5. Get output
		 */
		if (u32ByteLen < 16)
		{
			stTemp_Out.u32DataByteLen = u32ByteLen;
			sss_SFR_to_OS_reversing(&stTemp_Out, ((u32*) &AES_DATA_04));
		}
		else
		{
			sss_SFR_to_OS_reversing(&stTemp_Out, ((u32*) &AES_DATA_04));
			stTemp_In.pu08Data += 16;
			stTemp_Out.pu08Data += 16;
		}
	}

	/*!
	 * Step 6. Update the length of output structure
	 */
	pstAES_Output->u32DataByteLen = pstAES_Input->u32DataByteLen;
}


/*************** END OF FILE **************************************************/

/** @} */
