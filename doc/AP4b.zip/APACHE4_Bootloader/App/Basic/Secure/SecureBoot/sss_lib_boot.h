/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_SBOOT	SSS_SBOOT
 * @ingroup SSS_Boot
 * @brief					Boot Library
 * @{
 */

/**
 * @file		sss_lib_boot.h
 * @brief		Header for secure boot library
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

#ifndef SSS_LIB_BOOT_H_
#define SSS_LIB_BOOT_H_

/*************** Include Files ********************************************/
#include "Apache.h"
#include "sss_api_aes_cbc.h"
#include "sss_api_ecdsa_256.h"
#include "sss_api_sha2_256.h"
#include "sss_api_hmac_256.h"
/*************** Assertions ***********************************************/

/*************** Definitions / Macros *************************************/
/** @name Signed BL Header
 *  struct of Signed BL Header
 */
/**@{*/
typedef struct
{
	/*! Secure Boot Option */
	u32 u32SBOption;
	/*! Num. of Sector(BL + Key Info), sector is 32bitword */
	u32 u32NumOfSector;
	/*! BL byte length(BL Only) */
	u32 u32BLSize;
	/*! Address of Target Stored */
	u32 u32SrcAddr;
} stSFSB00_IMAGE_HEADER;
/**@}*/

/** @name Secure Boot Info
 *  struct of Secure Boot Info
 */
/**@{*/
typedef struct
{
	/*! Code signer version */
	u32 u32CodeSignerVersion;
	/*! Signed rollback version */
	u32 u32RollbackCounter;
	/*! Authentication Type  = {00(ECDSA), N/A(Others) }*/
	u32 u32AuthType;
	/*! Root Key Type = {01(Hashed Public Key, AES Key), 02(HMAC Key), N/A(Others) }*/
	u32 u32RKeyType;
} stSFSB00_BOOT_INFO;
/**@}*/

/** @name Secure Root Key Info
 *  struct of Root Key Info
 */
/**@{*/
typedef struct
{
	/*! Root Key Type = {01(Hashed Public Key, AES Key), 02(HMAC Key), N/A(Others) }*/
	u32 u32RKeyType;
	/*! Root Public Key */
	u08 *pu08Pubkey_Base;
	/*! Root Key Tagy*/
	u08 *pu08KeyTag_Base;
	/*! Root Decryption Key*/
	u08 *pu08Deckey_Base;
	/*! AES IV for decryption */
	u08 *pu08AESIV_Base;
} stSFSB00_RKEY_INFO;
/**@}*/

/** @name Secure Authentication Info
 *  struct of Authentication Info
 */
/**@{*/
typedef struct
{
	/*! signature */
	u08 *pu08Signature_Base;
	/*! KeyMAC */
	u08 *pu08KeyMAC_Base;
	/*! HASH after decryption */
	u08 *pu08DecHASH_Base;
} stSFSB00_AUTH_INFO;
/**@}*/

/** @name Signed BL Context
 *  struct of Signed BL Context
 */
/**@{*/
typedef struct
{
	stSFSB00_BOOT_INFO stBoot_info;
	stSFSB00_RKEY_INFO stKey_info;
	stSFSB00_AUTH_INFO stAuth_info;
} stSFSB00_CONTEXT;
/**@}*/

/*************** Constants ************************************************/
/** @name SFSB00 Option Value
 *  sf_secure_boot_v1.00 specification
 */
/**@{*/
#define SFSB00_MAX_PUBKEY_SIZE	 (64) /* ECDSA256 authentication */
#define SFSB00_MAX_DECKEY_SIZE	 (32) /* AES CBC 256 */
#define SFSB00_MAX_SIGN_SIZE	 (SFSB00_MAX_PUBKEY_SIZE) /* ECDSA 256 */
#define SFSB00_MAX_HASH_SIZE	 (SFSB00_MAX_DECKEY_SIZE) /* SHA2 256 */
/**@}*/

/*************** Variable declarations ************************************/

/*************** Error Message ********************************************/
/** @name SFSB00 Error Code
 *  Error code of Boot Solution
 */
/**@{*/
#define ERROR_BOOT_INVALID_VAL_CONTEXT		(ERROR_BOOT| INVALID_VAL | ERR_BLCTX)
#define ERROR_BOOT_INVALID_VAL_SIGN			(ERROR_BOOT| INVALID_VAL | ERR_BLSIGN)
#define ERROR_BOOT_INVALID_VAL_IMAGE		(ERROR_BOOT| INVALID_VAL | ERR_BLBODY)
#define ERROR_BOOT_INVALID_STATUS_HW		(ERROR_BOOT| INVALID_STATUS | ERR_HW)
/**@}*/

/*************** Prototypes ***********************************************/
/**
 * @brief		Secure Boot Solution
 * @param[in]	pu08SrcAddr		pointer of boot image to be verified
 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV sss_SecureBoot(u08 *pu08SrcAddr);

/**
 * @brief		Check Root Key Validity
 * @param[in]	pstHeader		pointer of Boot Image Header
 * @param[in]	pstContext		pointer of Boot Context
 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV sss_Check_Validity(stSFSB00_IMAGE_HEADER* pstHeader, stSFSB00_CONTEXT *pstContext);

/**
 * @brief		Verify Authority of Boot Image
 * @param[in]	pstHeader		pointer of Boot Image Header
 * @param[in]	pstContext		pointer of Boot Context
 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV sss_Check_Authentication(stSFSB00_IMAGE_HEADER* pstHeader, stSFSB00_CONTEXT *pstContext);

/**
 * @brief		Decrypt Authenticated Boot Image
 * @param[in]	pstHeader		pointer of Boot Image Header
 * @param[in]	pstContext		pointer of Boot Context
 * @return

 |Error Code	|Description						|
 |--------------|-----------------------------------|
 |SSSR_SUCCESS	|Function operates normally			|
 |Others		|Failed								|

 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */
SSS_RV sss_Check_Confidentiality(stSFSB00_IMAGE_HEADER* pstHeader, stSFSB00_CONTEXT *pstContext);


/*************** END OF FILE **********************************************/

#endif  /* SSS_LIB_BOOT_H_ */

/** @} */
