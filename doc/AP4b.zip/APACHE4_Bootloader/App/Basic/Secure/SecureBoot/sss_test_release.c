/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/


/**
 * @file		sss_test_release.h
 * @brief		integration test
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ************************************************/
#include "sss_lib_boot.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/
/*
 * to be modifed
 */
#define SIGNEDBL0_SRC_BASE  (0x20010000u)
#define SIGNEDBL0_BYTE_SIZE (0x4f0u)
#define BL0_DST_BASE        (0x20018000u)


/*************** Constants ****************************************************/

/*************** Prototypes ***************************************************/

static void sss_swap(u32 *pDst, u32 *pSrc, u32 nSize)
{
    u32 i;

    for(i = 0; i < nSize/4; i++)
    {
        pDst[i] = ((pSrc[i]&0xff)<<24) 
                  |((pSrc[i]&0xff00)<<8) 
                  |((pSrc[i]&0xff0000)>>8) 
                  |((pSrc[i]&0xff000000)>>24);
    }
}


static void sss_clear_key(void)
{
    u32 i;

    for(i=0;i<0x100;i+=4)
    {
        REGRW32(SBOOT_OTP_BASE, i) = 0x0;
    }
}


static void sss_apply_key(u08 RollBackCnt)
{
    sss_clear_key();
    
    ncDrv_EFUSE_Enable();
    
    sss_swap((u32 *)SBOOT_DECKEY_ROM_BASE,      (u32 *)(APACHE_ATOP_BASE+0x10C0), 32);       // ???
    sss_swap((u32 *)SBOOT_DECKEY_OTP_BASE,      (u32 *)(APACHE_ATOP_BASE+0x10C0), 32);       // AES
    sss_swap((u32 *)SBOOT_DECKEY_MAC_BASE,      (u32 *)(APACHE_ATOP_BASE+0x10C0), 32);       // HMAC
    sss_swap((u32 *)SBOOT_PUBKEY_DIGEST_BASE,   (u32 *)(APACHE_ATOP_BASE+0x10A0), 32);       // PublicKey
    
    ncDrv_EFUSE_Disable();

    SBOOT_RBCNT  = RollBackCnt; 
    SBOOT_ENABLE = TRUE;    

#ifdef __UART_ENABLE__
    DEBUGMSG(MSGINFO, "    -. Key Update\n");
#endif
}

s32 sss_boot(u32 Addr, u08 RollBackCnt)
{
    s32 ret;

#ifdef __UART_ENABLE__
    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");  
    DEBUGMSG(MSGINFO, "  > SSS In %08X\n", Addr);
#endif

    /*! > Step 1. Loading Signed Boot Image to SRAM */
    /*
     *  example)
     *  memcpy((u08*)BL0_DST_BASE, (u08*)SIGNEDBL0_SRC_BASE, SIGNEDBL0_BYTE_SIZE);
     */
    sss_apply_key(RollBackCnt);
    

    /*! > Step 2. Start Secure Boot */

    ret = sss_SecureBoot((u08*) Addr);

    if(SSSR_SUCCESS != ret)
    {
        /*
         * example)
         * printf("ERROR CODE = %08x\n", ret);
         */

        ret = NC_FAILURE;
    }

    sss_clear_key();


#ifdef __UART_ENABLE__
    DEBUGMSG(MSGINFO, "  > SSS Out %08X\n", ret);
#endif

    return ret;
}

/*************** END OF FILE **************************************************/

