/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @mainpage	Samsung Secure Boot Solution
 * @section		intro Introduction
 * > Supporting functions on Secure Boot
 *		- SecuSol \n
 *			. Boot Solution (including Boot Key Validation, Sign Verification, and Image Decryption) \n
 *		- SecuLib \n
 *			. AES : ECB, CBC, CTR (128, 192, 256bits)	\n
 *			. Hash : SHA2-256	    	\n
 *			. HMAC : SHA2-256	    	\n
 *			. ECDSA : Sign Verification with NIST-P256
 *
 * > Supporting functions on EVITA-M
 *		- SecuLib \n
 *			. AES : ECB, CBC (128, 192, 256bits)	\n
 *			. AES_AE : SW CCM, GCM (128, 192, 256bits)	\n
 *			. TRNG : TRNG Boot-up	\n
 *			. PRNG : SW AES-CTR based PRNG	\n
 *			. HMAC : SHA2-256	    	\n
 *			. ECDSA : Sign Sign Generation & Verification with NIST P256 and Brainpool 256    \n
 *			. ECDH : Key Agreeemnt PHASE-1, PHASE-2, and Compute Publickey with NIST-P256 and Brainpool 256
 *
 * @b Description
 *        - Supporting Total ## APIs in Alpha Release
 *        - The source code conforms to the standard C-language and can be compiled without any modificaiton    \n
 *        - The designation of API functions are as following    \n
 *            . "sss_SecureBoot": Referece Secure Boot function    \n
 *            . "sss_Check_{Validity, Authentication, Confidentiality}": Secure Boot API function to be called from outside    \n
 *            . "sss_{ALGORITHM CAPITHAL}": API function to be called from outside    \n
 *
 * @section CREATEINFO Information
 * @author	Kiseok Bae (kiseok.bae@samsung.com)
 * @version	V0.00

		Version		Date		Person		Description
		V0.00		2018.02.28	kiseok		Initial Version
 */

/**
 * @defgroup SSS_Solution	SSS_Solution
 * @brief					Samsung Security Solution
 */

/**
 * @defgroup SSS_API		SSS_API
 * @ingroup SSS_Solution
 * @brief					Function API for User
 */

/**
 * @defgroup SSS_Library	SSS_Library
 * @ingroup SSS_Solution
 * @brief					Source (C & Head) File of SSS Library
 */

/**
 * @defgroup SSS_Driver		SSS_Driver
 * @ingroup SSS_Solution
 * @brief					Source (C & Head) File of SSS Driver
 */

/**
 * @defgroup SSS_COMMON		SSS_COMMON
 * @ingroup SSS_Solution
 * @brief					Common Source (C & Head) File of SSS_Solution
 * @{
 */

/**
 * @file		sss_lib_common.h
 * @brief		Common header file
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

#ifndef SSS_LIB_COMMON_H_
#define SSS_LIB_COMMON_H_

/*************** Include Files ************************************************/
#include "sss_lib_oid.h"
#include "sss_lib_map.h"
#include "sss_lib_error.h"

/*************** Assertions ***************************************************/
/*
 * u08: 8bits unsigned data type
 * u16: 16bits unsigned data type
 * u32: 32bits unsigned data type
 * u64: 64bits unsigned data type
 * uwd: CPU size bits unsigned data type
 * s08: 8bits signed data type
 * s16: 16bits signed data type
 * s32: 32bits signed data type
 * s64: 64bits signed data type
 * swd: CPU size bits signed data type
 *
 */
typedef unsigned char u08;
typedef unsigned int u32;
typedef int s32;

#if SSS_UNUSED
	typedef unsigned short u16;
	typedef unsigned long long u64;
	typedef unsigned int uwd;
	typedef char s08;
	typedef short s16;
	typedef long long s64;
	typedef int swd;
	typedef u08* ptr_u08;
	typedef u32* ptr_u32;
#endif
/*
 * return error code
 */
typedef u32 SSS_RV;

/*************** Definitions / Macros *****************************************/
#define CEIL_BY_WORD(val) 		(((val)+3)>>2)
#define SSS_UNUSED				(0)

/*************** New Data Types *******************************************/
/**
 * @brief	Structure type for OCTET String / length & address
 *
 */
typedef struct
{
	u32  u32DataByteLen; /**< byte length of Data. */
	u08* pu08Data; 		/**< byte address of Data. */
} stOCTET_STRING;

/*************** Constants ****************************************************/
#ifndef FALSE
#define FALSE 			(0)
#endif
#ifndef TRUE
#define TRUE 			(1)
#endif
/*************** Variable declarations ****************************************/

/*************** Prototypes ***************************************************/

/*************** END OF FILE **************************************************/
#endif /* SSS_LIB_COMMON_H_ */

/** @} */
