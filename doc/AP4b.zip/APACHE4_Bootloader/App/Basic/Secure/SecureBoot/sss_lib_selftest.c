/**************************************************************************************/
/* Copyright (c) Samsung Electronics Co., Ltd. All rights reserved.                   */
/*                                                                                    */
/* -INSTRUCTIONS-                                                                     */
/* THIS SOFTWARE IS A CONFIDENTIAL STUFFS AND PROPRIETARY OF SAMSUNG ELECTRONICS CO., */
/* LTD. SO YOU SHALL NOT DISCLOSE THIS SOFTWARE OTHER COMPANY OR PERSONS WITHOUT PER- */
/* MISSION OF SAMSUNG AND SHALL USE THIS SOFTWARE ONLY IN ACCORDANCE WITH THE LICENSE */
/* AGREEMENT OF SAMSUNG.                                                              */
/* SAMSUNG MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE        */
/* SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE              */
/* IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR        */
/* NON-INFRINGEMENT. SAMSUNG SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE */
/* AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.  */
/**************************************************************************************/

/**
 * @defgroup SSS_SBOOT	SSS_SBOOT
 * @ingroup SSS_Boot
 * @brief					Boot Library
 * @{
 */

/**
 * @file		sss_lib_selftest.h
 * @brief		Source file for KAT Functions
 * @author		Kiseok Bae (kiseok.bae@samsung.com)
 * @version		V0.00

 |Version	|Date		|Person		|Description	|
 |----------|-----------|-----------|---------------|
 |V0.00		|2018.02.28	|kiseok		|Initial Version|
 */

/*************** Include Files ************************************************/
#include "sss_lib_util.h"
#include "sss_lib_selftest.h"

/*************** Assertions ***************************************************/

/*************** Definitions / Macros *****************************************/

/*************** Constants ****************************************************/
/*
 * message 128byte
 * 5905238877c77421f73e43ee3da6f2d9e2ccad5fc942dcec0cbd25482935faaf416983fe165b1a045ee2bcd2e6dca3bdf46c4310a7461f9a37960ca672d3feb5473e253605fb1ddfd28065b53cb5858a8ad28175bf9bd386a5e471ea7a65c17cc934a9d791e91491eb3754d03799790fe2d308d16146d5c9b0d0debd97d79ce8
 */
static const u08 gzu08TV_NIST_P256_SHA256_Msg_00[128] =
{ 0x59, 0x05, 0x23, 0x88, 0x77, 0xc7, 0x74, 0x21, 0xf7, 0x3e, 0x43, 0xee, 0x3d,
		0xa6, 0xf2, 0xd9, 0xe2, 0xcc, 0xad, 0x5f, 0xc9, 0x42, 0xdc, 0xec, 0x0c,
		0xbd, 0x25, 0x48, 0x29, 0x35, 0xfa, 0xaf, 0x41, 0x69, 0x83, 0xfe, 0x16,
		0x5b, 0x1a, 0x04, 0x5e, 0xe2, 0xbc, 0xd2, 0xe6, 0xdc, 0xa3, 0xbd, 0xf4,
		0x6c, 0x43, 0x10, 0xa7, 0x46, 0x1f, 0x9a, 0x37, 0x96, 0x0c, 0xa6, 0x72,
		0xd3, 0xfe, 0xb5, 0x47, 0x3e, 0x25, 0x36, 0x05, 0xfb, 0x1d, 0xdf, 0xd2,
		0x80, 0x65, 0xb5, 0x3c, 0xb5, 0x85, 0x8a, 0x8a, 0xd2, 0x81, 0x75, 0xbf,
		0x9b, 0xd3, 0x86, 0xa5, 0xe4, 0x71, 0xea, 0x7a, 0x65, 0xc1, 0x7c, 0xc9,
		0x34, 0xa9, 0xd7, 0x91, 0xe9, 0x14, 0x91, 0xeb, 0x37, 0x54, 0xd0, 0x37,
		0x99, 0x79, 0x0f, 0xe2, 0xd3, 0x08, 0xd1, 0x61, 0x46, 0xd5, 0xc9, 0xb0,
		0xd0, 0xde, 0xbd, 0x97, 0xd7, 0x9c, 0xe8 };
/*
 * message digest 32byte
 * 44ACF6B7E36C1342C2C5897204FE09504E1E2EFB1A900377DBC4E7A6A133EC56
 */
static const u08 gzu08TV_NIST_P256_SHA256_Digest_00[32] =
{ 0x44, 0xAC, 0xF6, 0xB7, 0xE3, 0x6C, 0x13, 0x42, 0xC2, 0xC5, 0x89, 0x72, 0x04,
		0xFE, 0x09, 0x50, 0x4E, 0x1E, 0x2E, 0xFB, 0x1A, 0x90, 0x03, 0x77, 0xDB,
		0xC4, 0xE7, 0xA6, 0xA1, 0x33, 0xEC, 0x56 };
/*
 * sign 64byte
 * f3ac8061b514795b8843e3d6629527ed2afd6b1f6a555a7acabb5e6f79c8c2ac8bf77819ca05a6b2786c76262bf7371cef97b218e96f175a3ccdda2acc058903
 */
static const u08 gzu08TV_NIST_P256_SHA256_Sign_00[64] =
{ 0xf3, 0xac, 0x80, 0x61, 0xb5, 0x14, 0x79, 0x5b, 0x88, 0x43, 0xe3, 0xd6, 0x62,
		0x95, 0x27, 0xed, 0x2a, 0xfd, 0x6b, 0x1f, 0x6a, 0x55, 0x5a, 0x7a, 0xca,
		0xbb, 0x5e, 0x6f, 0x79, 0xc8, 0xc2, 0xac, 0x8b, 0xf7, 0x78, 0x19, 0xca,
		0x05, 0xa6, 0xb2, 0x78, 0x6c, 0x76, 0x26, 0x2b, 0xf7, 0x37, 0x1c, 0xef,
		0x97, 0xb2, 0x18, 0xe9, 0x6f, 0x17, 0x5a, 0x3c, 0xcd, 0xda, 0x2a, 0xcc,
		0x05, 0x89, 0x03 };
/*
 * public key 64byte
 * 1ccbe91c075fc7f4f033bfa248db8fccd3565de94bbfb12f3c59ff46c271bf83ce4014c68811f9a21a1fdb2c0e6113e06db7ca93b7404e78dc7ccd5ca89a4ca9
 */
static const u08 gzu08TV_NIST_P256_SHA256_Q_00[64] =
{ 0x1c, 0xcb, 0xe9, 0x1c, 0x07, 0x5f, 0xc7, 0xf4, 0xf0, 0x33, 0xbf, 0xa2, 0x48,
		0xdb, 0x8f, 0xcc, 0xd3, 0x56, 0x5d, 0xe9, 0x4b, 0xbf, 0xb1, 0x2f, 0x3c,
		0x59, 0xff, 0x46, 0xc2, 0x71, 0xbf, 0x83, 0xce, 0x40, 0x14, 0xc6, 0x88,
		0x11, 0xf9, 0xa2, 0x1a, 0x1f, 0xdb, 0x2c, 0x0e, 0x61, 0x13, 0xe0, 0x6d,
		0xb7, 0xca, 0x93, 0xb7, 0x40, 0x4e, 0x78, 0xdc, 0x7c, 0xcd, 0x5c, 0xa8,
		0x9a, 0x4c, 0xa9 };

#if SSS_UNUSED
static const u08 gzu08TV_NIST_P256_SHA256_d_00[32] =
{ 0x51, 0x9b, 0x42, 0x3d, 0x71, 0x5f, 0x8b, 0x58, 0x1f, 0x4f, 0xa8, 0xee, 0x59,
		0xf4, 0x77, 0x1a, 0x5b, 0x44, 0xc8, 0x13, 0x0b, 0x4e, 0x3e, 0xac, 0xca,
		0x54, 0xa5, 0x6d, 0xda, 0x72, 0xb4, 0x64 };
#endif

/*
 * AES CBC Cipher from gzu08TV_NIST_P256_SHA256_Digest_00 with zero 256bit key zero IV
 */
static const u08 gzu08TV_AES_CBC_CIPHER[32] =
{ 0xDE, 0x7E, 0xF0, 0xFE, 0xD6, 0x51, 0xEE, 0x2C, 0x05, 0xDC, 0xCA, 0xB5, 0x9F,
		0xB0, 0xA7, 0xC7, 0xBB, 0xA9, 0x2B, 0x1A, 0x60, 0xC6, 0xAD, 0x33, 0xDB,
		0x47, 0x1B, 0x56, 0xC2, 0xB5, 0xEF, 0xF3, };

/*
 * HMAC TV from gzu08TV_NIST_P256_SHA256_Msg_00 with zero 256bit key
 */
static const u08 gzu08TV_HMAC256[32] =
{ 0x44, 0x77, 0xf1, 0x77, 0x4c, 0x51, 0x40, 0xc8, 0x4b, 0x46, 0x97, 0x46, 0xc5,
		0x50, 0xce, 0x09, 0x8a, 0x71, 0xf9, 0xda, 0xac, 0x84, 0xa0, 0xa6, 0x18,
		0x23, 0x84, 0x01, 0x4a, 0xcd, 0x92, 0x5f, };

/*************** Variable declarations ****************************************/

/*************** Function ****************************************************/
static SSS_RV KAT_AES_CBC(u32 *pu32Output)
{
	u32 ret = SSSR_FAIL;

	stAES_KEY 		zstAES_Key;
	stAES_PARAMS 	zstAES_Param;
	stOCTET_STRING 	zstAES_Input;
	stOCTET_STRING 	zstAES_Cipher;

	/*! step 1 : set input parameter */
	/*! - set Key */
	zstAES_Key.stKey.pu08Data = (u08*) pu32Output;
	zstAES_Key.stKey.u32DataByteLen = 32;
	/*! - set parameter */
	zstAES_Param.stIV.pu08Data = (u08*) pu32Output;
	zstAES_Param.stIV.u32DataByteLen = 16;
	/*! - set input */
	zstAES_Input.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Digest_00;
	zstAES_Input.u32DataByteLen = 32;
	/*! - set output */
	zstAES_Cipher.pu08Data = (u08*) pu32Output;

	/*! step 2 : Check target function  */
	ret = sss_AES_Enc_CBC(&zstAES_Param, &zstAES_Key, &zstAES_Input,
			&zstAES_Cipher);

	/*! step 3 : Compare with known answer  */
	if (SSSR_SUCCESS == ret)
	{
		ret = sss_memcmp_u08(zstAES_Cipher.pu08Data,
				(u08*) gzu08TV_AES_CBC_CIPHER, zstAES_Cipher.u32DataByteLen);
	}

	return ret;
}

static SSS_RV KAT_SHA2_256(u32 *pu32Output)
{
	u32 ret = SSSR_FAIL;

	stOCTET_STRING zstMessage;
	stOCTET_STRING zstDigest;

	/*! step 1 : set input parameter */
	zstMessage.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Msg_00;
	zstMessage.u32DataByteLen = 128;
	zstDigest.pu08Data = (u08*) pu32Output;
	zstDigest.u32DataByteLen = 0;

	/*! step 2 : call target function */
	ret = sss_SHA2_256(&zstMessage, &zstDigest);

	/*! step 3 : Compare with known answer  */
	if (SSSR_SUCCESS == ret)
	{
		ret = sss_memcmp_u08(zstDigest.pu08Data,
				(u08*) gzu08TV_NIST_P256_SHA256_Digest_00,
				zstDigest.u32DataByteLen);
	}

	return ret;
}

static SSS_RV KAT_HMACSHA2_256(u32 *pu32Output)
{
	u32 ret = SSSR_FAIL;

	stOCTET_STRING zstMessage;
	stOCTET_STRING zstDigest;
	stOCTET_STRING zstKey;

	/*! step 1 : set input parameter */
	zstMessage.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Msg_00;
	zstMessage.u32DataByteLen = 128;
	zstDigest.pu08Data = (u08*) pu32Output;
	zstDigest.u32DataByteLen = 0;
	zstKey.pu08Data = (u08*) pu32Output;
	zstKey.u32DataByteLen = 32;

	/*! step 2 : call target function */
	ret = sss_HMAC_SHA2_256(&zstKey, &zstMessage, &zstDigest);

	/*! step 3 : Compare with known answer  */
	if (SSSR_SUCCESS == ret)
	{
		ret = sss_memcmp_u08(zstDigest.pu08Data,
				(u08*) gzu08TV_HMAC256,
				zstDigest.u32DataByteLen);
	}

	return ret;
}

static SSS_RV KAT_ECDSA256_Verify(void)
{
	u32 ret = SSSR_FAIL;

	stOCTET_STRING zstDigest;
	stECC_PUBKEY zstEcdsaPubKey;
	stECDSA_SIGN zstSignature;

	/*! Step 1. set input parameter */
	/*! - set key */
	zstEcdsaPubKey.u32KeyType = 0;
	zstEcdsaPubKey.u32EllipticCurveID = OID_ECDSA_P256_SHA2_256;
	zstEcdsaPubKey.stBigNum_Qx.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Q_00;
	zstEcdsaPubKey.stBigNum_Qx.u32DataByteLen = 64/2;
	zstEcdsaPubKey.stBigNum_Qy.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Q_00 + zstEcdsaPubKey.stBigNum_Qx.u32DataByteLen;
	zstEcdsaPubKey.stBigNum_Qy.u32DataByteLen =64/2;
	/*! - set digested message */
	zstDigest.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Digest_00;
	zstDigest.u32DataByteLen = 32;

	/*! - set signature */
	zstSignature.u32ECDSA_OID = zstEcdsaPubKey.u32EllipticCurveID;
	zstSignature.stSign_r.pu08Data = (u08*) gzu08TV_NIST_P256_SHA256_Sign_00;
	zstSignature.stSign_r.u32DataByteLen = 64/2;
	zstSignature.stSign_s.pu08Data = zstSignature.stSign_r.pu08Data + zstSignature.stSign_r.u32DataByteLen;
	zstSignature.stSign_s.u32DataByteLen = 64/2;

	/*!step 2. Call ECDSA Verify API */
	ret = sss_ECDSA_Verify_256(&zstEcdsaPubKey, &zstDigest, &zstSignature);

	return ret;
}

SSS_RV sss_boot_KAT(void)
{
	u32 ret = SSSR_FAIL;
	u32 zu32Output[32 / 4] =
	{ 0, };

	/*! > Step 1. AES CBC Test */
	ret = KAT_AES_CBC(zu32Output);
	sss_memclr_u32(zu32Output, 32/4);

	/*! > Step 2. SHA2 256 Test */
	ret += KAT_SHA2_256(zu32Output);
	sss_memclr_u32(zu32Output, 32/4);

	/*! > Step 3. HMACSHA2 256 Test */
	ret += KAT_HMACSHA2_256(zu32Output);
	sss_memclr_u32(zu32Output, 32/4);

	/*! > Step 4. ECDSA Verify Test */
	ret += KAT_ECDSA256_Verify();

	return ret;
}

/*************** END OF FILE **************************************************/

/** @} */
