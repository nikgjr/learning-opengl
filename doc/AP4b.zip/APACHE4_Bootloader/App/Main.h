/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __MAIN_H__
#define __MAIN_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#ifdef __BL1__
    #define BL_NUM                          1
    #define BL_VER_MAJOR                    0
    #define BL_VER_MINOR1                   4
    #define BL_VER_MINOR2                   1

    #define BL_IMG_SIGNATURE_ID             0x30345041

    #define BL_IMG_MAX_SIZE                 APACHE_IRAM_SIZE    
    #define BL_TEMP_BUFF_ADDR               APACHE_IRAM_BASE

    // To use DMA, 16-byte aligned instuction-buffer is required.
    // 0x430 : Align( SRAM Max Size(64KB) / DMA Tranfer Size(0x3E0) x 16 + 16 * 2(Rx/Tx) )
    #define BL_INST_BUFF_ADDR               (APACHE_IRAM_BASE+APACHE_IRAM_SIZE)

    #define BL_IMG_LOADING_CNT              1           

    #define BL_IMG_DLS_SRC_NORMAL_ADDR      0x00001000  
    #define BL_IMG_DLS_SRC_BACKUP_ADDR      0x00011000  
    #define BL_IMG_DLS_DEST_ADDR            APACHE_IRAM_BASE

    #define BL_IMG_SIG_SRC_NORMAL_ADDR      0x00000000  
    #define BL_IMG_SIG_SRC_BACKUP_ADDR      0x00000000
    #define BL_IMG_SIG_DEST_ADDR            0x00000000

    #define BL_IMG_DSP_SRC_NORMAL_ADDR      0x00000000  
    #define BL_IMG_DSP_SRC_BACKUP_ADDR      0x00000000
    #define BL_IMG_DSP_DEST_ADDR            0x00000000

    #define DBG_VER_REG                     (*(volatile unsigned int *)(APACHE_SCU_BASE+0x1010))
    #define DBG_STP_REG                     (*(volatile unsigned int *)(APACHE_SCU_BASE+0x1014))
    #define DBG_RES_REG                     (*(volatile unsigned int *)(APACHE_SCU_BASE+0x1018))
    #define DBG_RTY_REG                     (*(volatile unsigned int *)(APACHE_SCU_BASE+0x101C))


#else
    #define BL_NUM                          2
    #define BL_VER_MAJOR                    0
    #define BL_VER_MINOR1                   4
    #define BL_VER_MINOR2                   1

    #define BL_IMG_SIGNATURE_ID             0x30345041  

    #define BL_IMG_MAX_SIZE                 APACHE_RMAP_SIZE
    #define BL_TEMP_BUFF_ADDR               APACHE_DRAM_BASE

    // To use DMA, 16-byte aligned instuction-buffer is required.
    // (DDR has many areas to use) Set to the address that is not used in the boot step of the DDR area.
    // 0x2110 : Align( SRAM Max Size(512KB) / DMA Tranfer Size(0x3E0) x 16 + 16 * 2(Rx/Tx)
    #define BL_INST_BUFF_ADDR               (APACHE_DRAM_BASE+(BL_IMG_MAX_SIZE*2)+(0x2110*2)) 

    #define BL_IMG_LOADING_CNT              2
    
    #define BL_IMG_DLS_SRC_NORMAL_ADDR      0x00021000
    #define BL_IMG_DLS_SRC_BACKUP_ADDR      0x00121000
    #define BL_IMG_DLS_DEST_ADDR            APACHE_DRAM_BASE    

    #define BL_IMG_SIG_SRC_NORMAL_ADDR      0x000A1000  
    #define BL_IMG_SIG_SRC_BACKUP_ADDR      0x001A1000 
    #define BL_IMG_SIG_DEST_ADDR            (APACHE_DRAM_BASE+BL_IMG_MAX_SIZE)

    #define BL_IMG_DSP_SRC_NORMAL_ADDR      0x00000000  
    #define BL_IMG_DSP_SRC_BACKUP_ADDR      0x00000000  
    #define BL_IMG_DSP_DEST_ADDR            0x00000000

    #define DBG_VER_REG                     (*(volatile unsigned int *)(APACHE_SCU_BASE+0x1020))
    #define DBG_STP_REG                     (*(volatile unsigned int *)(APACHE_SCU_BASE+0x1024))
    #define DBG_RES_REG                     (*(volatile unsigned int *)(APACHE_SCU_BASE+0x1028))
    #define DBG_RTY_REG                     (*(volatile unsigned int *)(APACHE_SCU_BASE+0x102C))


#endif

#define SB_REG                              (*(volatile unsigned int *)(APACHE_SCU_BASE+0x1030))
#define SB_STP_REG                          (*(volatile unsigned int *)(APACHE_SCU_BASE+0x1034))
#define SB_RES_REG                          (*(volatile unsigned int *)(APACHE_SCU_BASE+0x1038))


#define BL_IMG_HEADER_SIZE                  (16)


// External(OSC) Speed
#define BL_OSC_CPU_CLOCK                    (13500*KHZ) 
#define BL_OSC_APB_CLOCK                    ( 3375*KHZ)
#define BL_OSC_DDR_CLOCK                    ( 3375*KHZ)
#define BL_OSC_QSPI_CLOCK                   (  1687500)

// Low Speed
#define BL_MIN_CPU_CLOCK                    (148500*KHZ)    
#define BL_MIN_APB_CLOCK                    ( 37125*KHZ)
#define BL_MIN_DDR_CLOCK                    ( 37125*KHZ)
#define BL_MIN_QSPI_CLOCK                   (  18562500)

// Mid Speed
#define BL_MID_CPU_CLOCK                    (398250*KHZ)    
#define BL_MID_APB_CLOCK                    (  99562500)
#define BL_MID_DDR_CLOCK                    (  99562500)
#define BL_MID_QSPI_CLOCK                   (  49781250)

// Max Speed
#define BL_MAX_CPU_CLOCK                    (796500*KHZ)    
#define BL_MAX_APB_CLOCK                    (199215*KHZ)
#define BL_MAX_DDR_CLOCK                    (199215*KHZ)
#define BL_MAX_QSPI_CLOCK                   (  99562500)

// FPGA Speed (r3246)
#define BL_SIM_CPU_CLOCK                    (50*MHZ)
#define BL_SIM_APB_CLOCK                    (14795*KHZ)
#define BL_SIM_DDR_CLOCK                    (45*MHZ) 
#define BL_SIM_QSPI_CLOCK                   (20*MHZ)    










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum _DEBUG_STEP
{

    DBG_STP_SCU_IN = 0,
    DBG_STP_SCU_OUT,

    DBG_STP_UART_IN,
    DBG_STP_UART_OUT,

    DBG_STP_INTC_IN,
    DBG_STP_INTC_OUT,

    DBG_STP_DDR_IN,
    DBG_STP_DDR_OUT,                        // [7:0]


    DBG_STP_SF_IN,
        DBG_STP_SPI_IN,
        DBG_STP_SPI_OUT,
        
        DBG_STP_QSPI_IN,
        DBG_STP_QSPI_OUT,
        
        DBG_STP_DMA_IN,
        DBG_STP_DMA_OUT,
    DBG_STP_SF_OUT,                         // [15:8]

    
    DBG_STP_IMG_IN,
        DBG_STP_IMG_0_IN,
        DBG_STP_IMG_SECU_0_IN,
        DBG_STP_IMG_SECU_0_OUT,
        DBG_STP_IMG_0_OUT,
        
        DBG_STP_IMG_1_IN,
        DBG_STP_IMG_SECU_1_IN,
        DBG_STP_IMG_SECU_1_OUT,             // [23:16]
        DBG_STP_IMG_1_OUT,

        DBG_STP_IMG_2_IN,
        DBG_STP_IMG_SECU_2_IN,
        DBG_STP_IMG_SECU_2_OUT,            
        DBG_STP_IMG_2_OUT,
    DBG_STP_IMG_OUT,                        // 29

    DBG_STP_JUMP,
    DBG_STP_WAIT                            // 31
} eDBG_STEP;


typedef enum _BOOT_IMG_TYPE
{
    E_IMG_NORMAL = 0,
    E_IMG_BACKUP,
    
    E_IMG_TYPE_MAX
} eBOOT_IMG_TYPE;


typedef enum _BOOT_CORE_TYPE
{
    E_CORE_DLS = 0,
    E_CORE_SIG,
    E_CORE_DSP,
    
    E_CORE_TYPE_MAX
} eBOOT_CORE_TYPE;










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

#ifdef __UART_ENABLE__
    typedef struct _tBOOT_VER
    {
        UINT8       mBootNum;
        UINT8       mMajor;
        UINT8       mMinor1;
        UINT8       mMinor2;
        UINT32*     pBuildData;
        UINT32*     pBuildTime;
    } tBOOT_VER, *ptBOOT_VER;
#endif


typedef struct _tBOOT_CLK
{
    UINT32      mCPU;
    UINT32      mDDR;    
    UINT32      mAPB;
    UINT32      mQSPI;
} tBOOT_CLK, *ptBOOT_CLK;


typedef struct _tBOOT_STRAP
{
    UINT8       mSecureEn;
    UINT8       mFlashCS;
    UINT8       mPLLConfig;
    UINT8       Reserved;
} tBOOT_STRAP, *ptBOOT_STRAP;


typedef struct _tBOOT_IMG
{
    UINT32      mCtrlMode;                                      // 0: SPI 1:QSPI 2:DMA Mode 
    UINT32      mTempBuff;                                      // Used QSPI/DMA BitRate Test Area (Only Temp)  
    UINT32      mInstBuff;                                      // Used Only DMA Mode  (Instruction Buffer, Align(16))
    UINT32      mTotalCnt;                                      // Image Loading Total Count
    UINT32      mLimitSize;                                     // Image Loading Limit Size
    UINT32      mDestAddr[E_CORE_TYPE_MAX];                     // Image Loading Destination Address
    UINT32      mFlashAddr[E_CORE_TYPE_MAX][E_IMG_TYPE_MAX];    // 0: Original, 1:Backup
} tBOOT_IMG, *ptBOOT_IMG;


typedef struct _tBOOT_HD
{
    UINT32      mLength;                                        // Image length
    UINT32      mCheckSum;                                      // Image Checksum
    UINT32      mConfig;                                        // Image Loading Address
    UINT32      mSignature;                                     // Image Signature
} tBOOT_HDR, *ptBOOT_HDR;


typedef struct _tBOOT_INFO
{
    tBOOT_HDR   tHeader[E_CORE_TYPE_MAX][E_IMG_TYPE_MAX];
    tBOOT_IMG   tImage;    
    tBOOT_STRAP tStrap;
    tBOOT_CLK   tClock;

#ifdef __UART_ENABLE__    
    tBOOT_VER   tVer;
#endif    
} tBOOT_INFO, *ptBOOT_INFO;









/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/


#endif  /* __MAIN_H__ */


/* End Of File */

