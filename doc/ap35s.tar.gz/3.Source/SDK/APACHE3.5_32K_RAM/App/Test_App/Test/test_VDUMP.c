/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_VDUMP.c
*
*  @brief   :
*
*  @author  : alessio / TS Group / SoC SW Team
*
*  @date    : 2016.03.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"


#if ENABLE_IP_VDP


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define VDMP_SCACLER_MODE_ENABLE        0
#define VDMP_SEMIHOSTING_ENABLE         0


#define VDUMP_CH0_DDR_ADDRESS           0x08500000
#define VDUMP_CH1_DDR_ADDRESS           0x08600000
#define VDUMP_CH2_DDR_ADDRESS           0x08700000

#define VDUMP_CH0_DDR_ADDRESS_EX        0x08400000

//#define VDUMP_SIZE_CASE                 21  // FULL
//#define VDUMP_SIZE_CASE                 20  // 1280x960
#define VDUMP_SIZE_CASE                 13  // 1280x720


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

UINT8 cInputPath[MAX_OF_VDP_INPUT_PATH][20]=
{
    {"Pre-YEDGE Output"},
    {"DEFOG Output"    },
    {"HPF Output"      },
    {"OPD Grid Output" }
};

UINT8 cYUVParsing[MAX_OF_VDP_PARSING][20]=
{
    {"CR-CB- Y"},    // VDP_P_CRCBY_BGR
    {"CB-CR- Y"},    // VDP_P_CBCRY_GBR
    {"CR- Y-CB"},    // VDP_P_CRYCB_BRG
    {"CB- Y-CR"},    // VDP_P_CBYCR_GRB
    {" Y-CR-CB"},    // VDP_P_YCRCB_RBG
    {" Y-CB-CR"},    // VDP_P_YCBCR_RGB
};

UINT8 cRGBParsing[MAX_OF_VDP_PARSING][20]=
{
    {"B-G-R"},      // VDP_P_CRCBY_BGR
    {"G-B-R"},      // VDP_P_CBCRY_GBR
    {"B-R-G"},      // VDP_P_CRYCB_BRG
    {"G-R-B"},      // VDP_P_CBYCR_GRB
    {"R-B-G"},      // VDP_P_YCRCB_RBG
    {"R-G-B"},      // VDP_P_YCBCR_RGB
};

UINT8 cBurstMode[MAX_OF_VDP_WRITE_BURST]=
{
    1, 2, 4, 6, 8, 16, 32, 64, 128
};


UINT32 cOutputSize[VDUMP_SIZE_CASE][2]=
{
    //{1280, 1024},
    //{1280,  960},
    //{1280,  854},
    //{1280,  800},
    //{1280,  768},
    {1280,  720},
    //{1152,  864},
    //{1152,  768},
    //{1024,  768},
    {1024,  600},
    {1024,  576},
    { 854,  480},
    { 800,  600},
    { 800,  400},
    { 768,  576},
    { 640,  480},
    { 480,  320},
    { 384,  288},
    { 352,  288},
    { 320,  240},
    { 320,  200},
};


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

char destTextName[256];



/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

extern void APACHE_TEST_I2C_CMOS_AR0140AT_Initialize(void);
extern void APACHE_TEST_I2C_HDMI_Initialize(void);


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

void APACHE_TEST_VDUMP_SetMultiChannelDump_8Bit(UINT32 nMenu, UINT32 nChannel, eVDP_INPUT_FORMAT nInputFormat);
void APACHE_TEST_VDUMP_SetChannel0Dump_32Bit(UINT32 nMenu, eVDP_INPUT_FORMAT nInputFormat);
void APACHE_TEST_VDUMP_SetMultiChannelYUV4xxDump(UINT32 nMenu, UINT32 nChannel, eVDP_YUV_FORMAT nYUVFormat);

void APACHE_TEST_VDUMP_SetDebugMultiChannelDump(UINT32 nChannel, eVDP_INPUT_FORMAT nInputFormat);

void APACHE_TEST_VDUMP_FileWrite(tVDP_PARAM *vdp, UINT32 nMenu);


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

BOOL __MemoryClear(char *pSrc, UINT32 nLength)
{
    memset((char *)pSrc, 0, nLength);

    return 0;
}


BOOL __VdumpMemoryCompare8(eVDP_CH nChannel, char *pSrc, UINT32 nLength)
{
    UINT32 i, temp, temp2;
    BOOL nOk = 0;

    if(nChannel == VDP_CH0)
    {
        // Y, R 8Bit Data (0 ~ FF)

        for(i = 0; i < nLength; i++)
        {
            temp = (i%0x100);

            if(pSrc[i] != temp)
            {
                nOk = 1;
                DEBUGMSG(MSGINFO, "Memory Compare Fail 0x%08X, 0x%02X, 0x%02X\n", &pSrc[i], pSrc[i], temp);
                break;
            }
        }
    }
    else if(nChannel == VDP_CH1)
    {
        // Cb, G 8Bit Data (FF ~ 0)

        for(i = 0; i < nLength; i++)
        {
            temp = ((0x100 - (i%0x100))) & 0xFF;

            if(pSrc[i] != temp)
            {
                nOk = 1;
                DEBUGMSG(MSGINFO, "Memory Compare Fail 0x%08X, 0x%02X, 0x%02X\n", &pSrc[i], pSrc[i], temp);
                break;
            }
        }
    }
    else if(nChannel == VDP_CH2)
    {
        // Cr, B 8Bit Data (F ~ 0 / 0 ~ F)

        for(i = 0; i < nLength; i++)
        {
            temp = (i%0x10);
            temp2 = ((0x10 - (i%0x10))) & 0xF;

            temp |= (temp2<<4);

            if(pSrc[i] != temp)
            {
                nOk = 1;
                DEBUGMSG(MSGINFO, "Memory Compare Fail 0x%08X, 0x%02X, 0x%02X\n", &pSrc[i], pSrc[i], temp);
                break;
            }
        }
    }

    return nOk;
}


BOOL __VdumpMemoryCompare16(eVDP_CH nChannel, char *pSrc, UINT32 nLength)
{
    UINT32 i, j, temp, temp2;
    BOOL nOk = 0;

    if(nChannel == VDP_CH1)
    {
        // Cb, G 8Bit Data (FF ~ 0)

        for(i = 0; i < nLength; i++)
        {
            if(i%2) // 1, 3, 5, ...
            {
                j = (i/2);
                temp = ((0x100 - (j%0x100))) & 0xFF;

                if(pSrc[i] != temp)
                {
                    nOk = 1;
                    DEBUGMSG(MSGINFO, "Memory Compare Fail 0x%08X, 0x%02X, 0x%02X\n", &pSrc[i], pSrc[i], temp);
                    break;
                }
            }
            else    // 0, 2, 4, ...
            {
                j = (i/2);
                temp = (j%0x10);
                temp2 = ((0x10 - (j%0x10))) & 0xF;

                temp |= (temp2<<4);

                if(pSrc[i] != temp)
                {
                    nOk = 1;
                    DEBUGMSG(MSGINFO, "Memory Compare Fail 0x%08X, 0x%02X, 0x%02X\n", &pSrc[i], pSrc[i], temp);
                    break;
                }
            }
        }
    }

    return nOk;
}


INT32 APACHE_TEST_VDUMP_CUTMode(void)
{
    INT32 select;
    UINT32 i;
    UINT32 nChannel = 0;
    char buf[16];

    APACHE_TEST_I2C_CMOS_AR0140AT_Initialize();
    APACHE_TEST_I2C_HDMI_Initialize();

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - VDUMP                        \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> One Channel YUV444 Format Y,U,V 8Bit                   \n");
        DEBUGMSG(MSGINFO, " <2> One Channel RGB Format R,G,B 8Bit                      \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <3> Three Channel YUV444 Format Y,U,V 8Bit                 \n");
        DEBUGMSG(MSGINFO, " <4> Three Channel RGB Format R,G,B 8Bit                    \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <5> One Channel YUV422 Format YCb 16Bit                    \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <6> One Channel YUV444 YCbCr 32Bit                         \n");
        DEBUGMSG(MSGINFO, " <7> One Channel RGB 32Bit                                  \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <8> Two Channel YUV444 Ch0:Y-8Bit, Ch1:CbCr-16Bit          \n");
        DEBUGMSG(MSGINFO, " <9> Two Channel YUV422 Ch0:Y-8Bit, Ch1:CbCr-16Bit          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        //DEBUGMSG(MSGINFO, " <f> Debug Mode Three Channel 8Bit YUV422 Format            \n");
        //DEBUGMSG(MSGINFO, " <g> Debug Mode Three Channel 8Bit YUV422 Format            \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ...                        \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                for(i = VDP_CH0; i < MAX_OF_VDP_CH; i++)
                {
                    nChannel = (1<<i);
                    APACHE_TEST_VDUMP_SetMultiChannelDump_8Bit(1, nChannel, VDP_I_YUV_FORMAT);
                }
            break;

            case 2:
                for(i = VDP_CH0; i < MAX_OF_VDP_CH; i++)
                {
                    nChannel = (1<<i);
                    APACHE_TEST_VDUMP_SetMultiChannelDump_8Bit(2, nChannel, VDP_I_RGB_FORMAT);
                }
            break;

            case 3:
                nChannel = (1<<VDP_CH0) | (1<<VDP_CH1) | (1<<VDP_CH2);
                APACHE_TEST_VDUMP_SetMultiChannelDump_8Bit(3, nChannel, VDP_I_YUV_FORMAT);
            break;

            case 4:
                nChannel = (1<<VDP_CH0) | (1<<VDP_CH1) | (1<<VDP_CH2);
                APACHE_TEST_VDUMP_SetMultiChannelDump_8Bit(4, nChannel, VDP_I_RGB_FORMAT);
            break;

            case 5:
                nChannel = (1<<VDP_CH1); // up to 1280x720_(CH1-16Bit) Only
                APACHE_TEST_VDUMP_SetMultiChannelYUV4xxDump(5, nChannel, VDP_YUV422);
            break;

            case 6:
                // up to 1280x720_(CH0-32Bit) Only
                APACHE_TEST_VDUMP_SetChannel0Dump_32Bit(6, VDP_I_YUV_FORMAT);
            break;

            case 7:
                // up to 1280x720_(CH0-32Bit) Only
                APACHE_TEST_VDUMP_SetChannel0Dump_32Bit(7, VDP_I_RGB_FORMAT);
            break;

            case 8:
                // up to 1280x720_(CH0-8Bit / CH1-16Bit) Only
                // CH0 Y 8Bit
                // CH1 CbCr 16Bit
                nChannel = (1<<VDP_CH0) | (1<<VDP_CH1);
                APACHE_TEST_VDUMP_SetMultiChannelYUV4xxDump(8, nChannel, VDP_YUV444);
            break;

            case 9:
                // up to 1280x720_(CH0-8Bit / CH1-16Bit) Only
                // CH0 Y 8Bit
                // CH1 CbCr 16Bit
                nChannel = (1<<VDP_CH0) | (1<<VDP_CH1);
                APACHE_TEST_VDUMP_SetMultiChannelYUV4xxDump(9, nChannel, VDP_YUV422);
            break;

            case 15: // f
                    for(i = VDP_CH0; i < VDP_CH2; i++)
                    {
                        nChannel = (1<<i);
                        APACHE_TEST_VDUMP_SetDebugMultiChannelDump(nChannel, VDP_I_YUV_FORMAT);
                    }
            break;

            case 16: // g
                for(i = VDP_CH0; i < VDP_CH2; i++)
                {
                    nChannel = (1<<i);
                    APACHE_TEST_VDUMP_SetDebugMultiChannelDump(nChannel, VDP_I_RGB_FORMAT);
                }
            break;

            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto Vdump_Exit;
        }
    }

Vdump_Exit:

    return NC_SUCCESS;
}


void APACHE_TEST_VDUMP_SetMultiChannelDump_8Bit(UINT32 nMenu, UINT32 nChannel, eVDP_INPUT_FORMAT nInputFormat)
{
    tVDP_PARAM vdp;
    UINT32 nIntrDone, nOneFrmStt, nError;
    UINT32 nLineCount, nPixelCount;
    UINT32 nBSize0, nBSize1, nBSize2;
    UINT32 nEndAddress0, nEndAddress1, nEndAddress2;
    //INT32 ret = NC_SUCCESS;

    UINT32 nHSize = 640; // 640;
    UINT32 nVSize = 480; // 480;


    memset((char *)&vdp, 0, sizeof(tVDP_PARAM));

    vdp.InputH = 1280;
    vdp.InputV = 720;

#if VDMP_SCACLER_MODE_ENABLE
    vdp.ScaleEnable = 1;
#else
    vdp.ScaleEnable = 0;
#endif

    vdp.nDBGEnable = VDP_DBG_DISABLE;
    vdp.nFrameEdge = VDP_TYPE_FRAME_START;
    vdp.nInFormat  = nInputFormat;
    vdp.nYUVSelect = VDP_YUV444;

    //--------------------------------------------------------------------------
    // User variable setting ...
    //--------------------------------------------------------------------------
    vdp.OutputH = nHSize;
    vdp.OutputV = nVSize;

    //vdp.OutputHScale = nHScalerSize; // Image Output Horizontal Down Scaler Length
    //vdp.OutputVScale = nVScalerSize; // Image Output Vertical Down Scaler Length

    vdp.nInputPath = VDP_I_PRE_YEDGE_PATH;
    //--------------------------------------------------------------------------

    // channel 0 setting ...
    if(nChannel & (1<<VDP_CH0))
    {
        vdp.nIntr |= VDP_INTR_CH0_END;
        vdp.nDumpCh[VDP_CH0].nChEnable = TRUE;
        vdp.nDumpCh[VDP_CH0].nEndian = VDP_ENDIAN_LITTLE;

        vdp.nDumpCh[VDP_CH0].nParsing = VDP_P_CRCBY_BGR;
        vdp.nDumpCh[VDP_CH0].nBit = VDP_BIT_8;
        vdp.nDumpCh[VDP_CH0].nBurst = VDP_BURST_32_RESERVED;

        vdp.nDumpCh[VDP_CH0].nDumpAddress = VDUMP_CH0_DDR_ADDRESS;

        nBSize0 = (vdp.OutputH * vdp.OutputV * (1<<vdp.nDumpCh[VDP_CH0].nBit));
        nEndAddress0 = vdp.nDumpCh[VDP_CH0].nDumpAddress + nBSize0;

        __MemoryClear((char *)vdp.nDumpCh[VDP_CH0].nDumpAddress, nBSize0);
    }

    // channel 1 setting ...
    if(nChannel & (1<<VDP_CH1))
    {
        vdp.nIntr |= VDP_INTR_CH1_END;
        vdp.nDumpCh[VDP_CH1].nChEnable = TRUE;
        vdp.nDumpCh[VDP_CH1].nEndian = VDP_ENDIAN_LITTLE;

        vdp.nDumpCh[VDP_CH1].nParsing = VDP_P_CRYCB_BRG;
        vdp.nDumpCh[VDP_CH1].nBit = VDP_BIT_8;
        vdp.nDumpCh[VDP_CH1].nBurst = VDP_BURST_32_RESERVED;

        vdp.nDumpCh[VDP_CH1].nDumpAddress = VDUMP_CH1_DDR_ADDRESS;

        nBSize1 = (vdp.OutputH * vdp.OutputV * (1<<vdp.nDumpCh[VDP_CH1].nBit));
        nEndAddress1 = vdp.nDumpCh[VDP_CH1].nDumpAddress + nBSize1;

        __MemoryClear((char *)vdp.nDumpCh[VDP_CH1].nDumpAddress, nBSize1);
    }

    // channel 2 setting ...
    if(nChannel & (1<<VDP_CH2))
    {
        vdp.nIntr |= VDP_INTR_CH2_END;
        vdp.nDumpCh[VDP_CH2].nChEnable = TRUE;
        vdp.nDumpCh[VDP_CH2].nEndian = VDP_ENDIAN_LITTLE;

        vdp.nDumpCh[VDP_CH2].nParsing = VDP_P_CBYCR_GRB;
        vdp.nDumpCh[VDP_CH2].nBit = VDP_BIT_8;
        vdp.nDumpCh[VDP_CH2].nBurst = VDP_BURST_32_RESERVED;

        vdp.nDumpCh[VDP_CH2].nDumpAddress = VDUMP_CH2_DDR_ADDRESS;

        nBSize2 = (vdp.OutputH * vdp.OutputV * (1<<vdp.nDumpCh[VDP_CH2].nBit));
        nEndAddress2 = vdp.nDumpCh[VDP_CH2].nDumpAddress + nBSize2;

        __MemoryClear((char *)vdp.nDumpCh[VDP_CH2].nDumpAddress, nBSize2);
    }


    DEBUGMSG(MSGINFO, "=========================================================\n");
    DEBUGMSG(MSGINFO, "VDUMP Input %s Format Selected Start\n", nInputFormat == 0 ? "YUV" : "RGB");
    DEBUGMSG(MSGINFO, "Input %dx%d / Output %dx%d (up to 1280x720)\n", vdp.InputH, vdp.InputV, vdp.OutputH, vdp.OutputV);
    DEBUGMSG(MSGINFO, "Input Path %s\n\n", cInputPath[vdp.nInputPath]);
    if(vdp.nDumpCh[VDP_CH0].nChEnable)
    {
        DEBUGMSG(MSGINFO, ">>====================\n");
        DEBUGMSG(MSGINFO, "VDUMP Channel 0 Enable\n");
        if(nInputFormat == VDP_I_YUV_FORMAT)
        {
            DEBUGMSG(MSGINFO, "YUV444 Parsing %s, Bit %d, Burst %d\n",
                    cYUVParsing[vdp.nDumpCh[VDP_CH0].nParsing], (1<<vdp.nDumpCh[VDP_CH0].nBit)*8, cBurstMode[vdp.nDumpCh[VDP_CH0].nBurst]);
        }
        else
        {
            DEBUGMSG(MSGINFO, "RGB Parsing %s, Bit %d, Burst %d\n",
                    cRGBParsing[vdp.nDumpCh[VDP_CH0].nParsing], (1<<vdp.nDumpCh[VDP_CH0].nBit)*8, cBurstMode[vdp.nDumpCh[VDP_CH0].nBurst]);
        }
        DEBUGMSG(MSGINFO, "ch0 S:0x%08X, E:0x%08X address \n", vdp.nDumpCh[VDP_CH0].nDumpAddress, nEndAddress0);
    }
    if(vdp.nDumpCh[VDP_CH1].nChEnable)
    {
        DEBUGMSG(MSGINFO, ">>====================\n");
        DEBUGMSG(MSGINFO, "VDUMP Channel 1 Enable\n");
        if(nInputFormat == VDP_I_YUV_FORMAT)
        {
            DEBUGMSG(MSGINFO, "YUV444 Parsing %s, Bit %d, Burst %d\n",
                    cYUVParsing[vdp.nDumpCh[VDP_CH1].nParsing], (1<<vdp.nDumpCh[VDP_CH1].nBit)*8, cBurstMode[vdp.nDumpCh[VDP_CH1].nBurst]);
        }
        else
        {
            DEBUGMSG(MSGINFO, "RGB Parsing %s, Bit %d, Burst %d\n",
                    cRGBParsing[vdp.nDumpCh[VDP_CH1].nParsing], (1<<vdp.nDumpCh[VDP_CH1].nBit)*8, cBurstMode[vdp.nDumpCh[VDP_CH1].nBurst]);
        }
        DEBUGMSG(MSGINFO, "ch0 S:0x%08X, E:0x%08X address \n", vdp.nDumpCh[VDP_CH1].nDumpAddress, nEndAddress1);
    }
    if(vdp.nDumpCh[VDP_CH2].nChEnable)
    {
        DEBUGMSG(MSGINFO, ">>====================\n");
        DEBUGMSG(MSGINFO, "VDUMP Channel 2 Enable\n");
        if(nInputFormat == VDP_I_YUV_FORMAT)
        {
            DEBUGMSG(MSGINFO, "YUV444 Parsing %s, Bit %d, Burst %d\n",
                    cYUVParsing[vdp.nDumpCh[VDP_CH2].nParsing], (1<<vdp.nDumpCh[VDP_CH2].nBit)*8, cBurstMode[vdp.nDumpCh[VDP_CH2].nBurst]);
        }
        else
        {
            DEBUGMSG(MSGINFO, "RGB Parsing %s, Bit %d, Burst %d\n",
                    cRGBParsing[vdp.nDumpCh[VDP_CH2].nParsing], (1<<vdp.nDumpCh[VDP_CH2].nBit)*8, cBurstMode[vdp.nDumpCh[VDP_CH2].nBurst]);
        }
        DEBUGMSG(MSGINFO, "ch0 S:0x%08X, E:0x%08X address \n", vdp.nDumpCh[VDP_CH2].nDumpAddress, nEndAddress2);
    }
    DEBUGMSG(MSGINFO, "=========================================================\n");


    ncLib_VDP_Open();
    ncLib_VDP_Control(GCMD_VDP_INIT, &vdp, CMD_END);
    ncLib_VDP_Control(GCMD_VDP_CONNECT_ISR_HANDLER, CMD_END);

    DEBUGMSG(MSGINFO, "VDUMP Start Command\n");
    ncLib_VDP_Control(GCMD_VDP_START, &vdp, CMD_END);

    nIntrDone = 0;
    nOneFrmStt = 0;

    while(1)
    {
        APACHE_SYS_mDelay(2);

        nIntrDone = ncLib_VDP_Control(GCMD_VDP_INTR_DONE, CMD_END);

        nIntrDone &= vdp.nIntr;
        if(nIntrDone == vdp.nIntr)
        {
            DEBUGMSG(MSGINFO, "VDUMP Interrupt Status 0x%08X\n\n", nIntrDone);
            break;
        }

        nError = ncLib_VDP_Control(GCMD_VDP_CHK_ERROR, CMD_END);
        if(nError)
        {
            if(nError & VDP_ERR_DMA_BUFF_OVER)
            {
                DEBUGMSG(MSGINFO, "Error, VDUMP DMA Buffer Overflow\n\n");
            }

            if(nError & VDP_ERR_DUMP_TIME_OVER)
            {
                DEBUGMSG(MSGINFO, "Error, VDMP Dump Time Overflow\n\n");
            }

            break;
        }
    }

    APACHE_SYS_mDelay(100);

    if(vdp.nDumpCh[VDP_CH0].nChEnable)
    {
        nOneFrmStt = ncLib_VDP_Control(GCMD_VDP_GET_ONEFRMSTT, VDP_CH0, CMD_END);
        nLineCount = ncLib_VDP_Control(GCMD_VDP_GET_LINECNT, VDP_CH0, CMD_END);
        nPixelCount = ncLib_VDP_Control(GCMD_VDP_GET_PIXELCNT, VDP_CH0, CMD_END);

        DEBUGMSG(MSGINFO, "VDUMP Channel %d Output one frame status 0x%x\n", VDP_CH0, nOneFrmStt);
        DEBUGMSG(MSGINFO, "VDUMP Output line counter %d, pixel counter %d\n", nLineCount, nPixelCount);
        DEBUGMSG(MSGINFO, "VDUMP Output real total length %d\n", vdp.nDumpCh[VDP_CH0].nTotalLength);

        APACHE_TEST_VDUMP_FileWrite(&vdp, nMenu);
    }

    if(vdp.nDumpCh[VDP_CH1].nChEnable)
    {
        nOneFrmStt = ncLib_VDP_Control(GCMD_VDP_GET_ONEFRMSTT, VDP_CH1, CMD_END);
        nLineCount = ncLib_VDP_Control(GCMD_VDP_GET_LINECNT, VDP_CH1, CMD_END);
        nPixelCount = ncLib_VDP_Control(GCMD_VDP_GET_PIXELCNT, VDP_CH1, CMD_END);

        DEBUGMSG(MSGINFO, "VDUMP Channel %d Output one frame status 0x%x\n", VDP_CH1, nOneFrmStt);
        DEBUGMSG(MSGINFO, "VDUMP Output line counter %d, pixel counter %d\n", nLineCount, nPixelCount);
        DEBUGMSG(MSGINFO, "VDUMP Output real total length %d\n", vdp.nDumpCh[VDP_CH1].nTotalLength);

        APACHE_TEST_VDUMP_FileWrite(&vdp, nMenu);
    }

    if(vdp.nDumpCh[VDP_CH2].nChEnable)
    {
        nOneFrmStt = ncLib_VDP_Control(GCMD_VDP_GET_ONEFRMSTT, VDP_CH2, CMD_END);
        nLineCount = ncLib_VDP_Control(GCMD_VDP_GET_LINECNT, VDP_CH2, CMD_END);
        nPixelCount = ncLib_VDP_Control(GCMD_VDP_GET_PIXELCNT, VDP_CH2, CMD_END);

        DEBUGMSG(MSGINFO, "VDUMP Channel %d Output one frame status 0x%x\n", VDP_CH2, nOneFrmStt);
        DEBUGMSG(MSGINFO, "VDUMP Output line counter %d, pixel counter %d\n", nLineCount, nPixelCount);
        DEBUGMSG(MSGINFO, "VDUMP Output real total length %d\n", vdp.nDumpCh[VDP_CH2].nTotalLength);

        APACHE_TEST_VDUMP_FileWrite(&vdp, nMenu);
    }

    DEBUGMSG(MSGINFO, "\n");

    ncLib_VDP_Control(GCMD_VDP_DISCONNECT_ISR_HANDLER, CMD_END);
    ncLib_VDP_Control(GCMD_VDP_DEINIT, CMD_END);
    ncLib_VDP_Close();

    DEBUGMSG(MSGINFO, "VDUMP Format Selected End\n\n");
}


void APACHE_TEST_VDUMP_SetChannel0Dump_32Bit(UINT32 nMenu, eVDP_INPUT_FORMAT nInputFormat)
{
    tVDP_PARAM vdp;
    UINT32 nIntrDone, nOneFrmStt, nError;
    UINT32 nLineCount, nPixelCount;
    UINT32 nBSize0; // , nBSize1, nBSize2;
    UINT32 nEndAddress0; // , nEndAddress1, nEndAddress2;
    //INT32 ret = NC_SUCCESS;

    UINT32 nHSize = 640; // 640;
    UINT32 nVSize = 480;  // 480;


    memset((char *)&vdp, 0, sizeof(tVDP_PARAM));

    vdp.InputH = 1280;
    vdp.InputV = 720;

#if VDMP_SCACLER_MODE_ENABLE
    vdp.ScaleEnable = 1;
#else
    vdp.ScaleEnable = 0;
#endif

    vdp.nDBGEnable = VDP_DBG_DISABLE;
    vdp.nFrameEdge = VDP_TYPE_FRAME_START;
    vdp.nInFormat  = nInputFormat;
    vdp.nYUVSelect = VDP_YUV444;

    //--------------------------------------------------------------------------
    // User variable setting ...
    //--------------------------------------------------------------------------
    vdp.OutputH = nHSize;
    vdp.OutputV = nVSize;

    //vdp.OutputHScale = nHScalerSize; // Image Output Horizontal Down Scaler Length
    //vdp.OutputVScale = nVScalerSize; // Image Output Vertical Down Scaler Length

    vdp.nInputPath = VDP_I_PRE_YEDGE_PATH;
    //--------------------------------------------------------------------------

    // channel 0 setting ...
    vdp.nIntr |= VDP_INTR_CH0_END;
    vdp.nDumpCh[VDP_CH0].nChEnable = TRUE;
    vdp.nDumpCh[VDP_CH0].nEndian = VDP_ENDIAN_LITTLE;

    vdp.nDumpCh[VDP_CH0].nParsing = VDP_P_CRCBY_BGR;
    vdp.nDumpCh[VDP_CH0].nBit = VDP_BIT_32;
    vdp.nDumpCh[VDP_CH0].nBurst = VDP_BURST_32_RESERVED;

    vdp.nDumpCh[VDP_CH0].nDumpAddress = VDUMP_CH0_DDR_ADDRESS_EX;

    nBSize0 = (vdp.OutputH * vdp.OutputV * (1<<vdp.nDumpCh[VDP_CH0].nBit));
    nEndAddress0 = vdp.nDumpCh[VDP_CH0].nDumpAddress + nBSize0;

    __MemoryClear((char *)vdp.nDumpCh[VDP_CH0].nDumpAddress, nBSize0);


    DEBUGMSG(MSGINFO, "=========================================================\n");
    DEBUGMSG(MSGINFO, "VDUMP Input %s Format Selected Start\n", nInputFormat == 0 ? "YUV" : "RGB");
    DEBUGMSG(MSGINFO, "Input %dx%d / Output %dx%d (up to 1280x720)\n", vdp.InputH, vdp.InputV, vdp.OutputH, vdp.OutputV);
    DEBUGMSG(MSGINFO, "Input Path %s\n\n", cInputPath[vdp.nInputPath]);
    DEBUGMSG(MSGINFO, ">>====================\n");
    DEBUGMSG(MSGINFO, "VDUMP Channel 0 Enable\n");
    if(nInputFormat == VDP_I_YUV_FORMAT)
    {
        DEBUGMSG(MSGINFO, "YUV444 Parsing %s, Bit %d, Burst %d\n",
                cYUVParsing[vdp.nDumpCh[VDP_CH0].nParsing], (1<<vdp.nDumpCh[VDP_CH0].nBit)*8, cBurstMode[vdp.nDumpCh[VDP_CH0].nBurst]);
    }
    else
    {
        DEBUGMSG(MSGINFO, "RGB Parsing %s, Bit %d, Burst %d\n",
                cRGBParsing[vdp.nDumpCh[VDP_CH0].nParsing], (1<<vdp.nDumpCh[VDP_CH0].nBit)*8, cBurstMode[vdp.nDumpCh[VDP_CH0].nBurst]);
    }
    DEBUGMSG(MSGINFO, "ch0 S:0x%08X, E:0x%08X address \n", vdp.nDumpCh[VDP_CH0].nDumpAddress, nEndAddress0);
    DEBUGMSG(MSGINFO, "=========================================================\n");


    ncLib_VDP_Open();
    ncLib_VDP_Control(GCMD_VDP_INIT, &vdp, CMD_END);
    ncLib_VDP_Control(GCMD_VDP_CONNECT_ISR_HANDLER, CMD_END);

    DEBUGMSG(MSGINFO, "VDUMP Start Command\n");
    ncLib_VDP_Control(GCMD_VDP_START, &vdp, CMD_END);

    nIntrDone = 0;
    nOneFrmStt = 0;

    while(1)
    {
        APACHE_SYS_mDelay(2);

        nIntrDone = ncLib_VDP_Control(GCMD_VDP_INTR_DONE, CMD_END);

        nIntrDone &= vdp.nIntr;
        if(nIntrDone == vdp.nIntr)
        {
            DEBUGMSG(MSGINFO, "VDUMP Interrupt Status 0x%08X\n\n", nIntrDone);
            break;
        }

        nError = ncLib_VDP_Control(GCMD_VDP_CHK_ERROR, CMD_END);
        if(nError)
        {
            if(nError & VDP_ERR_DMA_BUFF_OVER)
            {
                DEBUGMSG(MSGINFO, "Error, VDUMP DMA Buffer Overflow\n\n");
            }

            if(nError & VDP_ERR_DUMP_TIME_OVER)
            {
                DEBUGMSG(MSGINFO, "Error, VDMP Dump Time Overflow\n\n");
            }

            break;
        }
    }

    APACHE_SYS_mDelay(100);

    nOneFrmStt = ncLib_VDP_Control(GCMD_VDP_GET_ONEFRMSTT, VDP_CH0, CMD_END);
    nLineCount = ncLib_VDP_Control(GCMD_VDP_GET_LINECNT, VDP_CH0, CMD_END);
    nPixelCount = ncLib_VDP_Control(GCMD_VDP_GET_PIXELCNT, VDP_CH0, CMD_END);

    DEBUGMSG(MSGINFO, "VDUMP Channel %d Output one frame status 0x%x\n", VDP_CH0, nOneFrmStt);
    DEBUGMSG(MSGINFO, "VDUMP Output line counter %d, pixel counter %d\n", nLineCount, nPixelCount);
    DEBUGMSG(MSGINFO, "VDUMP Output real total length %d\n", vdp.nDumpCh[VDP_CH0].nTotalLength);

    APACHE_TEST_VDUMP_FileWrite(&vdp, nMenu);

    DEBUGMSG(MSGINFO, "\n");

    ncLib_VDP_Control(GCMD_VDP_DISCONNECT_ISR_HANDLER, CMD_END);
    ncLib_VDP_Control(GCMD_VDP_DEINIT, CMD_END);
    ncLib_VDP_Close();

    DEBUGMSG(MSGINFO, "VDUMP Format Selected End\n\n");
}


void APACHE_TEST_VDUMP_SetMultiChannelYUV4xxDump(UINT32 nMenu, UINT32 nChannel, eVDP_YUV_FORMAT nYUVFormat)
{
    tVDP_PARAM vdp;
    UINT32 nIntrDone, nOneFrmStt, nError;
    UINT32 nLineCount, nPixelCount;
    UINT32 nBSize0, nBSize1;
    UINT32 nEndAddress0, nEndAddress1;
    //INT32 ret = NC_SUCCESS;

    UINT32 nHSize = 640;
    UINT32 nVSize = 480;


    memset((char *)&vdp, 0, sizeof(tVDP_PARAM));

    vdp.InputH = 1280;
    vdp.InputV = 720;

#if VDMP_SCACLER_MODE_ENABLE
    vdp.ScaleEnable = 1;
#else
    vdp.ScaleEnable = 0;
#endif

    vdp.nDBGEnable = VDP_DBG_DISABLE;
    vdp.nFrameEdge = VDP_TYPE_FRAME_START;
    vdp.nInFormat  = VDP_I_YUV_FORMAT;

    //--------------------------------------------------------------------------
    // User variable setting ...
    //--------------------------------------------------------------------------
    vdp.OutputH = nHSize;
    vdp.OutputV = nVSize;

    //vdp.OutputHScale = nHScalerSize; // Image Output Horizontal Down Scaler Length
    //vdp.OutputVScale = nVScalerSize; // Image Output Vertical Down Scaler Length

    vdp.nInputPath = VDP_I_PRE_YEDGE_PATH;
    vdp.nYUVSelect = nYUVFormat; // VDP_YUV444, VDP_YUV422
    //--------------------------------------------------------------------------

    // channel 0 setting ...
    if(nChannel & (1<<VDP_CH0))
    {
        vdp.nIntr |= VDP_INTR_CH0_END;
         vdp.nDumpCh[VDP_CH0].nChEnable = TRUE;
         vdp.nDumpCh[VDP_CH0].nEndian = VDP_ENDIAN_LITTLE;

         vdp.nDumpCh[VDP_CH0].nParsing = VDP_P_CRCBY_BGR;
         vdp.nDumpCh[VDP_CH0].nBit = VDP_BIT_8;
         vdp.nDumpCh[VDP_CH0].nBurst = VDP_BURST_32_RESERVED;

         vdp.nDumpCh[VDP_CH0].nDumpAddress = VDUMP_CH0_DDR_ADDRESS;

         nBSize0 = (vdp.OutputH * vdp.OutputV * (1<<vdp.nDumpCh[VDP_CH0].nBit));
         nEndAddress0 = vdp.nDumpCh[VDP_CH0].nDumpAddress + nBSize0;

         __MemoryClear((char *)vdp.nDumpCh[VDP_CH0].nDumpAddress, nBSize0);
    }

    // channel 1 setting ...
    if(nChannel & (1<<VDP_CH1))
    {
        vdp.nIntr |= VDP_INTR_CH1_END;
        vdp.nDumpCh[VDP_CH1].nChEnable = TRUE;
        vdp.nDumpCh[VDP_CH1].nEndian = VDP_ENDIAN_LITTLE;

        vdp.nDumpCh[VDP_CH1].nParsing = VDP_P_CRCBY_BGR;    // VDP_P_CRCBY_BGR, VDP_P_CBCRY_GBR, VDP_P_CRYCB_BRG, VDP_P_CBYCR_GRB
        vdp.nDumpCh[VDP_CH1].nBit = VDP_BIT_16;
        vdp.nDumpCh[VDP_CH1].nBurst = VDP_BURST_32_RESERVED;

        vdp.nDumpCh[VDP_CH1].nDumpAddress = VDUMP_CH1_DDR_ADDRESS;

        nBSize1 = (vdp.OutputH * vdp.OutputV * (1<<vdp.nDumpCh[VDP_CH1].nBit));
        nEndAddress1 = vdp.nDumpCh[VDP_CH1].nDumpAddress + nBSize1;

        __MemoryClear((char *)vdp.nDumpCh[VDP_CH1].nDumpAddress, nBSize1);
    }


    DEBUGMSG(MSGINFO, "=========================================================\n");
    DEBUGMSG(MSGINFO, "VDUMP Input YUV%s Format Selected Start\n", vdp.nYUVSelect == 0 ? "444" : "422");
    DEBUGMSG(MSGINFO, "Input %dx%d / Output %dx%d (up to 1280x720)\n", vdp.InputH, vdp.InputV, vdp.OutputH, vdp.OutputV);
    DEBUGMSG(MSGINFO, "Input Path %s\n\n", cInputPath[vdp.nInputPath]);

    if(vdp.nDumpCh[VDP_CH0].nChEnable)
    {
        DEBUGMSG(MSGINFO, ">>====================\n");
        DEBUGMSG(MSGINFO, "VDUMP Channel 0 Enable\n");
        DEBUGMSG(MSGINFO, "YUV4xx Parsing %s, Bit %d, Burst %d\n",
                cYUVParsing[vdp.nDumpCh[VDP_CH0].nParsing], (1<<vdp.nDumpCh[VDP_CH0].nBit)*8, cBurstMode[vdp.nDumpCh[VDP_CH0].nBurst]);
        DEBUGMSG(MSGINFO, "ch0 S:0x%08X, E:0x%08X address \n", vdp.nDumpCh[VDP_CH0].nDumpAddress, nEndAddress0);
    }

    if(vdp.nDumpCh[VDP_CH1].nChEnable)
    {
        DEBUGMSG(MSGINFO, ">>====================\n");
        DEBUGMSG(MSGINFO, "VDUMP Channel 1 Enable\n");
        DEBUGMSG(MSGINFO, "YUV4xx Parsing %s, Bit %d, Burst %d\n",
                cYUVParsing[vdp.nDumpCh[VDP_CH1].nParsing], (1<<vdp.nDumpCh[VDP_CH1].nBit)*8, cBurstMode[vdp.nDumpCh[VDP_CH1].nBurst]);
        DEBUGMSG(MSGINFO, "ch0 S:0x%08X, E:0x%08X address \n", vdp.nDumpCh[VDP_CH1].nDumpAddress, nEndAddress1);
    }

    DEBUGMSG(MSGINFO, "=========================================================\n");


    ncLib_VDP_Open();
    ncLib_VDP_Control(GCMD_VDP_INIT, &vdp, CMD_END);
    ncLib_VDP_Control(GCMD_VDP_CONNECT_ISR_HANDLER, CMD_END);

    DEBUGMSG(MSGINFO, "VDUMP Start Command\n");
    ncLib_VDP_Control(GCMD_VDP_START, &vdp, CMD_END);

    nIntrDone = 0;
    nOneFrmStt = 0;

    while(1)
    {
        APACHE_SYS_mDelay(2);

        nIntrDone = ncLib_VDP_Control(GCMD_VDP_INTR_DONE, CMD_END);

        nIntrDone &= vdp.nIntr;
        if(nIntrDone == vdp.nIntr)
        {
            DEBUGMSG(MSGINFO, "VDUMP Interrupt Status 0x%08X\n\n", nIntrDone);
            break;
        }

        nError = ncLib_VDP_Control(GCMD_VDP_CHK_ERROR, CMD_END);
        if(nError)
        {
            if(nError & VDP_ERR_DMA_BUFF_OVER)
            {
                DEBUGMSG(MSGINFO, "Error, VDUMP DMA Buffer Overflow\n\n");
            }

            if(nError & VDP_ERR_DUMP_TIME_OVER)
            {
                DEBUGMSG(MSGINFO, "Error, VDMP Dump Time Overflow\n\n");
            }

            break;
        }
    }

    APACHE_SYS_mDelay(100);

    if(vdp.nDumpCh[VDP_CH0].nChEnable)
    {
        nOneFrmStt = ncLib_VDP_Control(GCMD_VDP_GET_ONEFRMSTT, VDP_CH0, CMD_END);
        nLineCount = ncLib_VDP_Control(GCMD_VDP_GET_LINECNT, VDP_CH0, CMD_END);
        nPixelCount = ncLib_VDP_Control(GCMD_VDP_GET_PIXELCNT, VDP_CH0, CMD_END);

        DEBUGMSG(MSGINFO, "VDUMP Channel %d Output one frame status 0x%x\n", VDP_CH0, nOneFrmStt);
        DEBUGMSG(MSGINFO, "VDUMP Output line counter %d, pixel counter %d\n", nLineCount, nPixelCount);
        DEBUGMSG(MSGINFO, "VDUMP Output real total length %d\n", vdp.nDumpCh[VDP_CH0].nTotalLength);

        APACHE_TEST_VDUMP_FileWrite(&vdp, nMenu);
    }

    if(vdp.nDumpCh[VDP_CH1].nChEnable)
    {
        nOneFrmStt = ncLib_VDP_Control(GCMD_VDP_GET_ONEFRMSTT, VDP_CH1, CMD_END);
        nLineCount = ncLib_VDP_Control(GCMD_VDP_GET_LINECNT, VDP_CH1, CMD_END);
        nPixelCount = ncLib_VDP_Control(GCMD_VDP_GET_PIXELCNT, VDP_CH1, CMD_END);

        DEBUGMSG(MSGINFO, "VDUMP Channel %d Output one frame status 0x%x\n", VDP_CH1, nOneFrmStt);
        DEBUGMSG(MSGINFO, "VDUMP Output line counter %d, pixel counter %d\n", nLineCount, nPixelCount);
        DEBUGMSG(MSGINFO, "VDUMP Output real total length %d\n", vdp.nDumpCh[VDP_CH1].nTotalLength);

        APACHE_TEST_VDUMP_FileWrite(&vdp, nMenu);
    }

    if(vdp.nDumpCh[VDP_CH2].nChEnable)
    {
        nOneFrmStt = ncLib_VDP_Control(GCMD_VDP_GET_ONEFRMSTT, VDP_CH2, CMD_END);
        nLineCount = ncLib_VDP_Control(GCMD_VDP_GET_LINECNT, VDP_CH2, CMD_END);
        nPixelCount = ncLib_VDP_Control(GCMD_VDP_GET_PIXELCNT, VDP_CH2, CMD_END);

        DEBUGMSG(MSGINFO, "VDUMP Channel %d Output one frame status 0x%x\n", VDP_CH2, nOneFrmStt);
        DEBUGMSG(MSGINFO, "VDUMP Output line counter %d, pixel counter %d\n", nLineCount, nPixelCount);
        DEBUGMSG(MSGINFO, "VDUMP Output real total length %d\n", vdp.nDumpCh[VDP_CH2].nTotalLength);

        APACHE_TEST_VDUMP_FileWrite(&vdp, nMenu);
    }

    DEBUGMSG(MSGINFO, "\n");

    ncLib_VDP_Control(GCMD_VDP_DISCONNECT_ISR_HANDLER, CMD_END);
    ncLib_VDP_Control(GCMD_VDP_DEINIT, CMD_END);
    ncLib_VDP_Close();

    DEBUGMSG(MSGINFO, "VDUMP Format Selected End\n\n");
}


void APACHE_TEST_VDUMP_SetDebugMultiChannelDump(UINT32 nChannel, eVDP_INPUT_FORMAT nInputFormat)
{
#if 0
    tVDP_PARAM vdp;
    //eVDP_OUTPUT_FORMAT o;   // o = output format index
    UINT32 nIntrDone, nOneFrmStt, nError;
    UINT32 nLineCount, nPixelCount, nEndAddress;
    UINT32 nBSize0, nBSize1;
    UINT32 nEndAddress0, nEndAddress1;
    //UINT8 *pBuffer;
    //INT32 ret = NC_SUCCESS;

    DEBUGMSG(MSGINFO, "Input 1280x720 / Output 320x240\n");
    //DEBUGMSG(MSGINFO, "Ch0_Y_R, Ch1_Cb_G Ch1_Cr_B 8Bit Mode Test\n");
    DEBUGMSG(MSGINFO, "VDUMP Input %s Format Selected Start\n", nInputFormat == 0 ? "YUV" : "RGB");
    DEBUGMSG(MSGINFO, "=============================================\n");

    memset((char *)&vdp, 0, sizeof(tVDP_PARAM));

    vdp.InputH = 1280;
    vdp.InputV = 720;

    vdp.OutputH = 320;
    vdp.OutputV = 240;

    vdp.nFrameEdge = VDP_TYPE_FRAME_START;
    vdp.nInFormat = nInputFormat;

    vdp.nDBGEnable = VDP_DBG_ENABLE;

    // channel 0 setting ...
    if(nChannel & (1<<VDP_CH0))
    {
        DEBUGMSG(MSGINFO, "VDUMP Channel 0 Enable\n");

        vdp.nIntr |= VDP_INTR_CH0_END;

        vdp.nDumpCh[VDP_CH0].nChEnable = TRUE;
        vdp.nDumpCh[VDP_CH0].nEndian = VDP_ENDIAN_LITTLE;
        vdp.nDumpCh[VDP_CH0].nParsing = VDP_P_CRCBY_BGR;
        vdp.nDumpCh[VDP_CH0].nBit = VDP_BIT_8;
        vdp.nDumpCh[VDP_CH0].nBurst = VDP_BURST_32_RESERVED;

        vdp.nDumpCh[VDP_CH0].nDumpAddress = VDUMP_CH0_DDR_ADDRESS;

        nBSize0 = (vdp.OutputH * vdp.OutputV * (1<<vdp.nDumpCh[VDP_CH0].nBit));
        nEndAddress0 = vdp.nDumpCh[VDP_CH0].nDumpAddress + nBSize0;

        DEBUGMSG(MSGINFO, "ch0 S:0x%08X, E:0x%08X address \n", vdp.nDumpCh[VDP_CH0].nDumpAddress, nEndAddress0);

        __MemoryClear((char *)vdp.nDumpCh[VDP_CH0].nDumpAddress, nBSize0);
    }

    // channel 1 setting ...
    if(nChannel & (1<<VDP_CH1))
    {
        DEBUGMSG(MSGINFO, "VDUMP Channel 1 Enable\n");

        vdp.nIntr |= VDP_INTR_CH1_END;

        vdp.nDumpCh[VDP_CH1].nChEnable = TRUE;
        vdp.nDumpCh[VDP_CH1].nEndian = VDP_ENDIAN_LITTLE;
        vdp.nDumpCh[VDP_CH1].nParsing = VDP_P_YCBCR_RGB;
        vdp.nDumpCh[VDP_CH1].nBit = VDP_BIT_16;
        vdp.nDumpCh[VDP_CH1].nBurst = VDP_BURST_32_RESERVED;

        vdp.nDumpCh[VDP_CH1].nDumpAddress = VDUMP_CH1_DDR_ADDRESS;

        nBSize1 = (vdp.OutputH * vdp.OutputV * (1<<vdp.nDumpCh[VDP_CH1].nBit));
        nEndAddress1 = vdp.nDumpCh[VDP_CH1].nDumpAddress + nBSize1;

        DEBUGMSG(MSGINFO, "ch1 S:0x%08X, E:0x%08X address \n", vdp.nDumpCh[VDP_CH1].nDumpAddress, nEndAddress1);

        __MemoryClear((char *)vdp.nDumpCh[VDP_CH1].nDumpAddress, nBSize1);
    }

    // channel 2 setting ...
    if(nChannel & (1<<VDP_CH2))
    {
        DEBUGMSG(MSGINFO, "VDUMP Channel 2 Enable\n");

        vdp.nIntr |= VDP_INTR_CH2_END;

        vdp.nDumpCh[VDP_CH2].nChEnable = TRUE;
        vdp.nDumpCh[VDP_CH2].nEndian = VDP_ENDIAN_LITTLE;
        vdp.nDumpCh[VDP_CH2].nParsing = VDP_P_CBYCR_GRB;
        vdp.nDumpCh[VDP_CH2].nBit = VDP_BIT_8;
        vdp.nDumpCh[VDP_CH2].nBurst = VDP_BURST_32_RESERVED;

        vdp.nDumpCh[VDP_CH2].nDumpAddress = VDUMP_CH2_DDR_ADDRESS;

        nBSize1 = (vdp.OutputH * vdp.OutputV * (1<<vdp.nDumpCh[VDP_CH2].nBit));
        nEndAddress1 = vdp.nDumpCh[VDP_CH2].nDumpAddress + nBSize1;

        DEBUGMSG(MSGINFO, "ch2 S:0x%08X, E:0x%08X address \n", vdp.nDumpCh[VDP_CH2].nDumpAddress, nEndAddress1);

        __MemoryClear((char *)vdp.nDumpCh[VDP_CH2].nDumpAddress, nBSize1);
    }

    ncLib_VDP_Open();
    ncLib_VDP_Control(GCMD_VDP_INIT, &vdp, CMD_END);
    ncLib_VDP_Control(GCMD_VDP_CONNECT_ISR_HANDLER, CMD_END);

    DEBUGMSG(MSGINFO, "VDUMP Start Command\n");
    ncLib_VDP_Control(GCMD_VDP_DUMP_DBG_MODE_START, &vdp, CMD_END);

    nIntrDone = 0;
    nOneFrmStt = 0;

    while(1)
    {
        APACHE_SYS_mDelay(2);

        nIntrDone = ncLib_VDP_Control(GCMD_VDP_INTR_DONE, CMD_END);

        nIntrDone &= vdp.nIntr;
        if(nIntrDone == vdp.nIntr)
        {
            DEBUGMSG(MSGINFO, "VDUMP Interrupt Status 0x%08X\n\n", nIntrDone);
            break;
        }

        nError = ncLib_VDP_Control(GCMD_VDP_CHK_ERROR, CMD_END);
        if(nError)
        {
            if(nError & VDP_ERR_DMA_BUFF_OVER)
            {
                DEBUGMSG(MSGINFO, "Error, VDUMP DMA Buffer Overflow\n\n");
            }

            if(nError & VDP_ERR_DUMP_TIME_OVER)
            {
                DEBUGMSG(MSGINFO, "Error, VDMP Dump Time Overflow\n\n");
            }

            break;
        }
    }

    APACHE_SYS_mDelay(100);

    if(vdp.nDumpCh[VDP_CH0].nChEnable)
    {
        nOneFrmStt = ncLib_VDP_Control(GCMD_VDP_GET_ONEFRMSTT, VDP_CH0, CMD_END);
        nLineCount = ncLib_VDP_Control(GCMD_VDP_GET_LINECNT, VDP_CH0, CMD_END);
        nPixelCount = ncLib_VDP_Control(GCMD_VDP_GET_PIXELCNT, VDP_CH0, CMD_END);

        DEBUGMSG(MSGINFO, "VDUMP Channel %d Output one frame status 0x%x\n", VDP_CH0, nOneFrmStt);
        DEBUGMSG(MSGINFO, "VDUMP Output line counter %d, pixel counter %d\n", nLineCount, nPixelCount);
        DEBUGMSG(MSGINFO, "VDUMP Output total length %d\n", vdp.nDumpCh[VDP_CH0].nTotalLength);

        if(__VdumpMemoryCompare8(VDP_CH0, (char *)vdp.nDumpCh[VDP_CH0].nDumpAddress, vdp.nDumpCh[VDP_CH0].nTotalLength) == 0)
        {
            DEBUGMSG(MSGINFO, "VDUMP Channel 0 Memory Compare OK\n");
        }
    }

    if(vdp.nDumpCh[VDP_CH1].nChEnable)
    {
        nOneFrmStt = ncLib_VDP_Control(GCMD_VDP_GET_ONEFRMSTT, VDP_CH1, CMD_END);
        nLineCount = ncLib_VDP_Control(GCMD_VDP_GET_LINECNT, VDP_CH1, CMD_END);
        nPixelCount = ncLib_VDP_Control(GCMD_VDP_GET_PIXELCNT, VDP_CH1, CMD_END);

        DEBUGMSG(MSGINFO, "VDUMP Channel %d Output one frame status 0x%x\n", VDP_CH1, nOneFrmStt);
        DEBUGMSG(MSGINFO, "VDUMP Output line counter %d, pixel counter %d\n", nLineCount, nPixelCount);
        DEBUGMSG(MSGINFO, "VDUMP Output total length %d\n", vdp.nDumpCh[VDP_CH1].nTotalLength);

        if(__VdumpMemoryCompare16(VDP_CH1, (char *)vdp.nDumpCh[VDP_CH1].nDumpAddress, vdp.nDumpCh[VDP_CH1].nTotalLength) == 0)
        {
            DEBUGMSG(MSGINFO, "VDUMP Channel 1 Memory Compare OK\n");
        }
    }

    if(vdp.nDumpCh[VDP_CH2].nChEnable)
    {
        nOneFrmStt = ncLib_VDP_Control(GCMD_VDP_GET_ONEFRMSTT, VDP_CH2, CMD_END);
        nLineCount = ncLib_VDP_Control(GCMD_VDP_GET_LINECNT, VDP_CH2, CMD_END);
        nPixelCount = ncLib_VDP_Control(GCMD_VDP_GET_PIXELCNT, VDP_CH2, CMD_END);

        DEBUGMSG(MSGINFO, "VDUMP Channel %d Output one frame status 0x%x\n", VDP_CH2, nOneFrmStt);
        DEBUGMSG(MSGINFO, "VDUMP Output line counter %d, pixel counter %d\n", nLineCount, nPixelCount);
        DEBUGMSG(MSGINFO, "VDUMP Output total length %d\n", vdp.nDumpCh[VDP_CH2].nTotalLength);

        if(__VdumpMemoryCompare8(VDP_CH2, (char *)vdp.nDumpCh[VDP_CH2].nDumpAddress, vdp.nDumpCh[VDP_CH2].nTotalLength) == 0)
        {
            DEBUGMSG(MSGINFO, "VDUMP Channel 2 Memory Compare OK\n");
        }
    }

    DEBUGMSG(MSGINFO, "\n");

    ncLib_VDP_Control(GCMD_VDP_DISCONNECT_ISR_HANDLER, CMD_END);
    ncLib_VDP_Control(GCMD_VDP_DEINIT, CMD_END);
    ncLib_VDP_Close();

    DEBUGMSG(MSGINFO, "VDUMP Format Selected End\n");
    DEBUGMSG(MSGINFO, "=============================================\n");
#endif
}


void APACHE_TEST_VDUMP_FileWrite(tVDP_PARAM *vdp, UINT32 nMenu)
{
#if VDMP_SEMIHOSTING_ENABLE

    FILE *fVdump = NULL;
    UINT8 *pBuffer;
    UINT32 nBaseAddress, nLength;

    DEBUGMSG(MSGINFO, "VDUMP File Writing ...\n");

    //if(vdp->OutputHScale && vdp->OutputVScale)
    if(vdp->ScaleEnable)
    {
        switch(nMenu)
        {
            case 1:
            case 3:
                if(vdp->nDumpCh[VDP_CH0].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH0_Y_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
                else if(vdp->nDumpCh[VDP_CH1].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH1_Cb_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
                else if(vdp->nDumpCh[VDP_CH2].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH2_Cr_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
            break;

            case 2:
            case 4:
                if(vdp->nDumpCh[VDP_CH0].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH0_R_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
                else if(vdp->nDumpCh[VDP_CH1].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH1_G_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
                else if(vdp->nDumpCh[VDP_CH2].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH2_B_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
            break;

            case 5:
            case 8:
            case 9:
                if(vdp->nDumpCh[VDP_CH0].nChEnable)
                {
                    if(nMenu == 8) sprintf(destTextName, "D:\\VDUMP\\%d.CH0_YUV444_Y_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                    else if(nMenu == 9) sprintf(destTextName, "D:\\VDUMP\\%d.CH0_YUV422_Y_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
                else if(vdp->nDumpCh[VDP_CH1].nChEnable)
                {
                    if(nMenu == 8) sprintf(destTextName, "D:\\VDUMP\\%d.CH1_YUV444_CbCr_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                    else if(nMenu == 9) sprintf(destTextName, "D:\\VDUMP\\%d.CH1_YUV422_CbCr_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                    else sprintf(destTextName, "D:\\VDUMP\\%d.CH1_YUV422_YCb_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
            break;

            case 6:
                if(vdp->nDumpCh[VDP_CH0].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH0_YUV444_YCbCr_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
            break;

            case 7:
                if(vdp->nDumpCh[VDP_CH0].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH0_RGB_Scaler_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
            break;

            default :
            break;
        }
    }
    else
    {
        switch(nMenu)
        {
            case 1:
            case 3:
                if(vdp->nDumpCh[VDP_CH0].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH0_Y_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
                else if(vdp->nDumpCh[VDP_CH1].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH1_Cb_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
                else if(vdp->nDumpCh[VDP_CH2].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH2_Cr_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
            break;

            case 2:
            case 4:
                if(vdp->nDumpCh[VDP_CH0].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH0_R_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
                else if(vdp->nDumpCh[VDP_CH1].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH1_G_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
                else if(vdp->nDumpCh[VDP_CH2].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH2_B_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
            break;

            case 5:
            case 8:
            case 9:
                if(vdp->nDumpCh[VDP_CH0].nChEnable)
                {
                    if(nMenu == 8) sprintf(destTextName, "D:\\VDUMP\\%d.CH0_YUV444_Y_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                    else if(nMenu == 9) sprintf(destTextName, "D:\\VDUMP\\%d.CH0_YUV422_Y_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
                else if(vdp->nDumpCh[VDP_CH1].nChEnable)
                {
                    if(nMenu == 8) sprintf(destTextName, "D:\\VDUMP\\%d.CH1_YUV444_CbCr_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                    else if(nMenu == 9) sprintf(destTextName, "D:\\VDUMP\\%d.CH1_YUV422_CbCr_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                    else sprintf(destTextName, "D:\\VDUMP\\%d.CH1_YUV422_YCb_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
            break;

            case 6:
                if(vdp->nDumpCh[VDP_CH0].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH0_YUV444_YCbCr_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
            break;

            case 7:
                if(vdp->nDumpCh[VDP_CH0].nChEnable)
                {
                    sprintf(destTextName, "D:\\VDUMP\\%d.CH0_RGB_Crop_%dx%d.bin", nMenu, vdp->OutputH, vdp->OutputV);
                }
            break;

            default :
            break;
        }
    }

    if(vdp->nDumpCh[VDP_CH0].nChEnable)
    {
        vdp->nDumpCh[VDP_CH0].nChEnable = 0;
        nBaseAddress = vdp->nDumpCh[VDP_CH0].nDumpAddress;
        nLength = vdp->nDumpCh[VDP_CH0].nTotalLength;
    }
    else if(vdp->nDumpCh[VDP_CH1].nChEnable)
    {
        vdp->nDumpCh[VDP_CH1].nChEnable = 0;
        nBaseAddress = vdp->nDumpCh[VDP_CH1].nDumpAddress;
        nLength = vdp->nDumpCh[VDP_CH1].nTotalLength;
    }
    else if(vdp->nDumpCh[VDP_CH2].nChEnable)
    {
        vdp->nDumpCh[VDP_CH2].nChEnable = 0;
        nBaseAddress = vdp->nDumpCh[VDP_CH2].nDumpAddress;
        nLength = vdp->nDumpCh[VDP_CH2].nTotalLength;
    }

    pBuffer = (UINT8 *)nBaseAddress;

    fVdump = fopen(destTextName, "wb");

    fwrite((void*)pBuffer, nLength, 1, fVdump);

    if(fVdump == NULL)
    {
        DEBUGMSG(MSGINFO, "Error, VDUMP %s File Open Fail\n", destTextName);
    }

    fclose(fVdump);

#endif
}


#endif


/* End Of File */
