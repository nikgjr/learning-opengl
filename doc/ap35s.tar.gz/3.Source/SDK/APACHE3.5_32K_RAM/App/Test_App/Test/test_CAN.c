/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_CAN.c
*
*  @brief   :
*
*  @author  : alessio / TS Group / SoC SW Team
*
*  @date    : 2016.02.16
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"


#if ENABLE_IP_CAN


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


enum
{
    CAN_DEVICE_TEST_ID,
    CAN_DAC_TEST_ID,
    CAN_MOTION_SENSOR_ID,
    CAN_LIGHT_SENSOR_ID,
    CAN_GPIO_PORT_EXPANDER_ID,
    CAN_JOYSTICK_LED_ID,
    CAN_ADC_LCD_ID,
    CAN_TEMPERATURE_SENSOR_ID,
    MAX_OF_CAN_TX_ID_TYPE
};


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

tCAN_MSG gBasicCanIdList[MAX_OF_CAN_TX_ID_TYPE]=
{
    {   // CAN_DEVICE_TEST_ID
        0x1FF,
        0x08,
        {0x20, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_BASIC_MODE,
        CAN_FI_STANDARD_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_DAC_TEST_ID
        0x09,
        0x08,
        {0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_BASIC_MODE,
        CAN_FI_STANDARD_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_MOTION_SENSOR_ID
        0x1D,
        0x03,
        {0x00, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0x11},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_BASIC_MODE,
        CAN_FI_STANDARD_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_LIGHT_SENSOR_ID
        0x29,
        0x04,
        {0x40, 0x02, 0x03, 0x04, 0x00, 0x00, 0x00, 0x00},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_BASIC_MODE,
        CAN_FI_STANDARD_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_GPIO_PORT_EXPANDER_ID
        0x39,
        0x08,
        {0x00, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_BASIC_MODE,
        CAN_FI_STANDARD_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_JOYSTICK_LED_ID
        0x3A,
        0x05,
        {0x80, 0x02, 0x03, 0x04, 0x05, 0x00, 0x00, 0x00},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_BASIC_MODE,
        CAN_FI_STANDARD_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_ADC_LCD_ID
        0x42,
        0x08,
        {0x00, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_BASIC_MODE,
        CAN_FI_STANDARD_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_TEMPERATURE_SENSOR_ID
        0x4E,
        0x02,
        {0x20, 0x34, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_BASIC_MODE,
        CAN_FI_STANDARD_FORMAT,
        CAN_FI_DATA_FRAME,
    },
};


tCAN_MSG gPeriCanIdList[MAX_OF_CAN_TX_ID_TYPE]=
{
    {   // CAN_DEVICE_TEST_ID
        0x15555555,
        0x08,
        {0x20, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_PERI_MODE,
        CAN_FI_EXTENDED_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_DAC_TEST_ID
        0x09,
        0x08,
        {0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_PERI_MODE,
        CAN_FI_STANDARD_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_MOTION_SENSOR_ID
        0x1D,
        0x01, // 0x08,
        {0xaa, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0x11},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_PERI_MODE,
        CAN_FI_STANDARD_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_LIGHT_SENSOR_ID
        0x29,
        0x04,
        {0x40, 0x02, 0x03, 0x04, 0x00, 0x00, 0x00, 0x00},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_PERI_MODE,
        CAN_FI_EXTENDED_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_GPIO_PORT_EXPANDER_ID
        0x39,
        0x08,
        {0x00, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_PERI_MODE,
        CAN_FI_STANDARD_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_JOYSTICK_LED_ID
        0x3A,
        0x05,
        {0x80, 0x02, 0x03, 0x04, 0x05, 0x00, 0x00, 0x00},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_PERI_MODE,
        CAN_FI_EXTENDED_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_ADC_LCD_ID
        0x42,
        0x08,
        {0x00, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_PERI_MODE,
        CAN_FI_STANDARD_FORMAT,
        CAN_FI_DATA_FRAME,
    },

    {   // CAN_TEMPERATURE_SENSOR_ID
        0x4E,
        0x02,
        {0x20, 0x34, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        CAN_MSGOBJ_ACTIVE,
        CAN_CDR_PERI_MODE,
        CAN_FI_EXTENDED_FORMAT,
        CAN_FI_DATA_FRAME,
    },
};


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

tCAN_MSG gp_AppCanRxMsg[MAX_OF_CAN_CH];
tCAN_MSG gp_AppCanTxMsgBox[MAX_OF_CAN_CH][MAX_OF_CAN_TX_ID_TYPE];


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

void APACHE_TEST_CAN_PeriCAN_Send(void);
void APACHE_TEST_CAN_PeriCAN_Receive(void);
void APACHE_TEST_CAN_PeriCAN_Selftest(void);
void APACHE_TEST_CAN_PeriCAN_Variable_BusTiming(void);

void APACHE_TEST_CAN_BasicCAN_Send(void);
void APACHE_TEST_CAN_BasicCAN_Receive(void);
void APACHE_TEST_CAN_BasicCAN_Variable_BusTiming(void);

void ncLib_CAN_DebugTxPrint(eCAN_CH channel, tCAN_MSG txmsg);
BOOL ncLib_CAN_DebugRxPrint(eCAN_CH channel, tCAN_MSG rxmsg);


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 APACHE_TEST_CAN_CUTMode(void)
{
    INT32 select;
    char buf[16];

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - CAN                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " CAN Controller                                             \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> CAN PeriCAN Operation Mode - Send Test                 \n");
        DEBUGMSG(MSGINFO, " <2> CAN PeriCAN Operation Mode - Receive Loop Test         \n");
        DEBUGMSG(MSGINFO, " <3> CAN PeriCAN Self Test Mode - Send & Receive Test       \n");
        DEBUGMSG(MSGINFO, " <4> CAN PeriCAN Bus Timing Test                            \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <5> CAN BasicCAN Operation Mode - Send Test                \n");
        DEBUGMSG(MSGINFO, " <6> CAN BasicCAN Operation Mode - Receive Loop Test        \n");
        DEBUGMSG(MSGINFO, " <7> CAN BasicCAN Bus Timing Test                           \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ...                        \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_CAN_PeriCAN_Send();
            break;

            case 2:
                APACHE_TEST_CAN_PeriCAN_Receive();
            break;

            case 3:
                APACHE_TEST_CAN_PeriCAN_Selftest();
            break;

            case 4:
                APACHE_TEST_CAN_PeriCAN_Variable_BusTiming();
            break;

            case 5:
                APACHE_TEST_CAN_BasicCAN_Send();
            break;

            case 6:
                APACHE_TEST_CAN_BasicCAN_Receive();
            break;

            case 7:
                APACHE_TEST_CAN_BasicCAN_Variable_BusTiming();
            break;

            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto Can_Exit;
        }
    }

Can_Exit:

    return NC_SUCCESS;
}


void APACHE_TEST_CAN_PeriCAN_Send(void)
{
    tCAN_PARAM PeriCAN;
    tCAN_INFO canInfo;
    UINT32 i;

    canInfo.channel = CAN_CH0;
    canInfo.mode = CAN_CDR_PERI_MODE;
    canInfo.baudrate = CAN_BPS_125KBPS;

    /*
    * Komodo Total Phase CAN/I2C Activity Board Pro
    * 0x1D : Motion Sensor (x, y, z)
    * 0x29 : Light Sensor
    * 0x3A : LED Control (D201, D202, D203)
    * 0x4E : Temperature Sensor
    * 0xFF : ?? All Get ID
    */

    PeriCAN.acrId = 0xFF;
    PeriCAN.amrId = 0xFF;
    PeriCAN.baudrate = canInfo.baudrate;
    PeriCAN.info = canInfo;

    DEBUGMSG(MSGINFO, "PeriCAN channel %d Send Mode\n", canInfo.channel);
    DEBUGMSG(MSGINFO, "===================================================\n");

    ncLib_CAN_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_CAN, CMD_END));

    ncLib_CAN_Control(GCMD_CAN_CONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_INIT_CH, canInfo.channel, canInfo.mode, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_SETUP, canInfo.channel, &PeriCAN, CMD_END);


    for(i = 0; i < MAX_OF_CAN_TX_ID_TYPE; i++)
    {
        memcpy((void *)&gp_AppCanTxMsgBox[canInfo.channel][i], (void *)&gPeriCanIdList[i], sizeof(tCAN_MSG));

        ncLib_CAN_DebugTxPrint(canInfo.channel, gp_AppCanTxMsgBox[canInfo.channel][i]);

        ncLib_CAN_Control(GCMD_CAN_SEND, canInfo.channel, &gp_AppCanTxMsgBox[canInfo.channel][i], CMD_END);

        DEBUGMSG(MSGINFO, ".\n\n");
    }

    ncLib_CAN_Control(GCMD_CAN_DISCONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_DEINIT_CH, canInfo.channel, canInfo.mode, CMD_END);

    ncLib_CAN_Close();
}


void APACHE_TEST_CAN_PeriCAN_Receive(void)
{
    tCAN_PARAM PeriCAN;
    tCAN_INFO canInfo;
    INT32 ret = NC_SUCCESS;

    canInfo.channel = CAN_CH0;
    canInfo.mode = CAN_CDR_PERI_MODE;
    canInfo.baudrate = CAN_BPS_125KBPS;

    PeriCAN.acrId = 0xFF;
    PeriCAN.amrId = 0xFF;
    PeriCAN.baudrate = canInfo.baudrate;
    PeriCAN.info = canInfo;

    DEBUGMSG(MSGINFO, "PeriCAN channel %d Receive Mode\n", canInfo.channel);
    DEBUGMSG(MSGINFO, "===================================================\n");

    ncLib_CAN_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_CAN, CMD_END));

    ncLib_CAN_Control(GCMD_CAN_CONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_INIT_CH, canInfo.channel, canInfo.mode, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_SETUP, canInfo.channel, &PeriCAN, CMD_END);

    memset((UINT8 *)&gp_AppCanRxMsg[canInfo.channel], 0, sizeof(tCAN_MSG));

    while(1)
    {
        APACHE_SYS_mDelay(100);

        ret = ncLib_CAN_Control(GCMD_CAN_RECEIVE, canInfo.channel, &gp_AppCanRxMsg[canInfo.channel], CMD_END);

        if(ret == NC_SUCCESS)
        {
            ncLib_CAN_DebugRxPrint(canInfo.channel, gp_AppCanRxMsg[canInfo.channel]);
            ncLib_CAN_Control(GCMD_CAN_REMOTE_REQ, canInfo.channel, &gp_AppCanRxMsg[canInfo.channel], CMD_END);

            DEBUGMSG(MSGINFO, ".\n\n");
        }
    }

    ncLib_CAN_Control(GCMD_CAN_DISCONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_DEINIT_CH, canInfo.channel, canInfo.mode, CMD_END);

    ncLib_CAN_Close();
}


void APACHE_TEST_CAN_PeriCAN_Selftest(void)
{
    UINT32 i;
    tCAN_PARAM PeriCAN;
    tCAN_INFO canInfo;

    canInfo.channel = CAN_CH0;
    canInfo.mode = CAN_CDR_PERI_MODE;
    canInfo.baudrate = CAN_BPS_125KBPS;

    PeriCAN.acrId = 0xFF;
    PeriCAN.amrId = 0xFF;
    PeriCAN.baudrate = canInfo.baudrate;
    PeriCAN.info = canInfo;

    DEBUGMSG(MSGINFO, "PeriCAN channel %d SelfTest Mode\n", canInfo.channel);
    DEBUGMSG(MSGINFO, "===================================================\n");

    ncLib_CAN_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_CAN, CMD_END));

    ncLib_CAN_Control(GCMD_CAN_CONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_INIT_CH, canInfo.channel, canInfo.mode, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_PERI_SELFTEST_SETUP, canInfo.channel, &PeriCAN, CMD_END);

    memset((UINT8 *)&gp_AppCanRxMsg[canInfo.channel], 0, sizeof(tCAN_MSG));

    for(i = 0; i < MAX_OF_CAN_TX_ID_TYPE; i++)
    {
        memcpy((void *)&gp_AppCanTxMsgBox[canInfo.channel][i], (void *)&gPeriCanIdList[i], sizeof(tCAN_MSG));

        ncLib_CAN_DebugTxPrint(canInfo.channel, gp_AppCanTxMsgBox[canInfo.channel][i]);

        ncLib_CAN_Control(GCMD_CAN_PERI_SELFTEST_SEND, canInfo.channel, &gp_AppCanTxMsgBox[canInfo.channel][i], CMD_END);
        ncLib_CAN_Control(GCMD_CAN_RECEIVE, canInfo.channel, &gp_AppCanRxMsg[canInfo.channel], CMD_END);

        ncLib_CAN_DebugRxPrint(canInfo.channel, gp_AppCanRxMsg[canInfo.channel]);

        ncLib_CAN_Control(GCMD_CAN_REMOTE_REQ, canInfo.channel, &gp_AppCanRxMsg[canInfo.channel], CMD_END);

        DEBUGMSG(MSGINFO, ".\n\n");
    }

    ncLib_CAN_Control(GCMD_CAN_DISCONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_DEINIT_CH, canInfo.channel, canInfo.mode, CMD_END);

    ncLib_CAN_Close();
}


void APACHE_TEST_CAN_PeriCAN_Variable_BusTiming(void)
{
    UINT32 i;
    tCAN_PARAM PeriCAN;
    tCAN_INFO canInfo;
    INT32 ret = NC_SUCCESS;

    canInfo.channel = CAN_CH0;
    canInfo.mode = CAN_CDR_PERI_MODE;

    PeriCAN.acrId = 0xFF;
    PeriCAN.amrId = 0xFF;
    PeriCAN.info = canInfo;

    DEBUGMSG(MSGINFO, "PeriCAN channel %d Variable Bus Timing Test Mode\n", canInfo.channel);
    DEBUGMSG(MSGINFO, "10, 20, 50, 100, 125, 250, 500, 800, 1000kbps\n");
    DEBUGMSG(MSGINFO, "===================================================\n");

    ncLib_CAN_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_CAN, CMD_END));

    ncLib_CAN_Control(GCMD_CAN_CONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

#if 0
    typedef enum
    {
        CAN_BPS_10KBPS,     // 6.7km Class A max // Komodo not support
        CAN_BPS_20KBPS,     // 3.3km Class B     // Ok
        CAN_BPS_50KBPS,     // 1.3km Class B     // Ok
        CAN_BPS_100KBPS,    // 620m  Class B     // Ok
        CAN_BPS_125KBPS,    // 530m  Class B max // Ok
        CAN_BPS_250KBPS,    // 270m  Class C     // Ok
        CAN_BPS_500KBPS,    // 130m  Class C     // Ok
        CAN_BPS_800KBPS,    // 80m   Class C     // komodo not support
        CAN_BPS_1000KBPS,   // 40m   Class C max // Ok
        MAX_OF_CAN_BPS
    } eCAN_KBPS;
#endif

    for(i = CAN_BPS_20KBPS; i < MAX_OF_CAN_BPS; i++)
    {
        if(i != CAN_BPS_800KBPS)
        {
            canInfo.baudrate = (eCAN_KBPS)i;
            PeriCAN.baudrate = canInfo.baudrate;

            ncLib_CAN_Control(GCMD_CAN_INIT_CH, canInfo.channel, canInfo.mode, CMD_END);
            ncLib_CAN_Control(GCMD_CAN_SETUP, canInfo.channel, &PeriCAN, CMD_END);

            memset((UINT8 *)&gp_AppCanRxMsg[canInfo.channel], 0, sizeof(tCAN_MSG));

            while(1)
            {
                APACHE_SYS_mDelay(100);

                ret = ncLib_CAN_Control(GCMD_CAN_RECEIVE, canInfo.channel, &gp_AppCanRxMsg[canInfo.channel], CMD_END);

                if(ret == NC_SUCCESS)
                {
                    ncLib_CAN_DebugRxPrint(canInfo.channel, gp_AppCanRxMsg[canInfo.channel]);
                    ncLib_CAN_Control(GCMD_CAN_REMOTE_REQ, canInfo.channel, &gp_AppCanRxMsg[canInfo.channel], CMD_END);

                    DEBUGMSG(MSGINFO, ".\n\n");
                    break;
                }
            }

            ncLib_CAN_Control(GCMD_CAN_DEINIT_CH, canInfo.channel, canInfo.mode, CMD_END);
        }
    }


    ncLib_CAN_Control(GCMD_CAN_DISCONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

    ncLib_CAN_Close();
}


void APACHE_TEST_CAN_BasicCAN_Send(void)
{
    tCAN_PARAM BasicCAN;
    tCAN_INFO canInfo;
    UINT32 i;

    canInfo.channel = CAN_CH0;
    canInfo.mode = CAN_CDR_BASIC_MODE;
    canInfo.baudrate = CAN_BPS_125KBPS;

    /*
    * Komodo Total Phase CAN/I2C Activity Board Pro
    * 0x1D : Motion Sensor (x, y, z)
    * 0x29 : Light Sensor
    * 0x3A : LED Control (D201, D202, D203)
    * 0x4E : Temperature Sensor
    * 0xFF : ?? All Get ID
    */

    BasicCAN.acrId = 0xFF;
    BasicCAN.amrId = 0xFF;
    BasicCAN.baudrate = canInfo.baudrate;
    BasicCAN.info = canInfo;

    DEBUGMSG(MSGINFO, "BasicCAN channel %d Send Mode\n", canInfo.channel);
    DEBUGMSG(MSGINFO, "===================================================\n");

    ncLib_CAN_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_CAN, CMD_END));

    ncLib_CAN_Control(GCMD_CAN_CONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_INIT_CH, canInfo.channel, canInfo.mode, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_SETUP, canInfo.channel, &BasicCAN, CMD_END);


    for(i = 0; i < MAX_OF_CAN_TX_ID_TYPE; i++)
    {
        memcpy((void *)&gp_AppCanTxMsgBox[canInfo.channel][i], (void *)&gBasicCanIdList[i], sizeof(tCAN_MSG));

        ncLib_CAN_DebugTxPrint(canInfo.channel, gp_AppCanTxMsgBox[canInfo.channel][i]);

        ncLib_CAN_Control(GCMD_CAN_SEND, canInfo.channel, &gp_AppCanTxMsgBox[canInfo.channel][i], CMD_END);

        DEBUGMSG(MSGINFO, ".\n\n");
    }

    ncLib_CAN_Control(GCMD_CAN_DISCONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_DEINIT_CH, canInfo.channel, canInfo.mode, CMD_END);

    ncLib_CAN_Close();
}


void APACHE_TEST_CAN_BasicCAN_Receive(void)
{
    tCAN_PARAM BasicCAN;
    tCAN_INFO canInfo;
    INT32 ret = NC_SUCCESS;

    canInfo.channel = CAN_CH0;
    canInfo.mode = CAN_CDR_BASIC_MODE;
    canInfo.baudrate = CAN_BPS_125KBPS;

    BasicCAN.acrId = 0xFF;
    BasicCAN.amrId = 0xFF;
    BasicCAN.baudrate = canInfo.baudrate;
    BasicCAN.info = canInfo;

    DEBUGMSG(MSGINFO, "BasicCAN channel %d Receive Mode\n", canInfo.channel);
    DEBUGMSG(MSGINFO, "===================================================\n");

    ncLib_CAN_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_CAN, CMD_END));

    ncLib_CAN_Control(GCMD_CAN_CONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_INIT_CH, canInfo.channel, canInfo.mode, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_SETUP, canInfo.channel, &BasicCAN, CMD_END);

    memset((UINT8 *)&gp_AppCanRxMsg[canInfo.channel], 0, sizeof(tCAN_MSG));

    while(1)
    {
        APACHE_SYS_mDelay(100);

        ret = ncLib_CAN_Control(GCMD_CAN_RECEIVE, canInfo.channel, &gp_AppCanRxMsg[canInfo.channel], CMD_END);

        if(ret == NC_SUCCESS)
        {
            ncLib_CAN_DebugRxPrint(canInfo.channel, gp_AppCanRxMsg[canInfo.channel]);
            ncLib_CAN_Control(GCMD_CAN_REMOTE_REQ, canInfo.channel, &gp_AppCanRxMsg[canInfo.channel], CMD_END);

            DEBUGMSG(MSGINFO, ".\n\n");
        }
    }

    ncLib_CAN_Control(GCMD_CAN_DISCONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

    ncLib_CAN_Control(GCMD_CAN_DEINIT_CH, canInfo.channel, canInfo.mode, CMD_END);

    ncLib_CAN_Close();
}


void APACHE_TEST_CAN_BasicCAN_Variable_BusTiming(void)
{
    UINT32 i;
    tCAN_PARAM BasicCAN;
    tCAN_INFO canInfo;
    INT32 ret = NC_SUCCESS;

    canInfo.channel = CAN_CH0;
    canInfo.mode = CAN_CDR_BASIC_MODE;

    BasicCAN.acrId = 0xFF;
    BasicCAN.amrId = 0xFF;
    BasicCAN.info = canInfo;

    DEBUGMSG(MSGINFO, "BasicCAN channel %d Variable Bus Timing Test Mode\n", canInfo.channel);
    DEBUGMSG(MSGINFO, "10, 20, 50, 100, 125, 250, 500, 800, 1000kbps\n");
    DEBUGMSG(MSGINFO, "===================================================\n");

    ncLib_CAN_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_CAN, CMD_END));

    ncLib_CAN_Control(GCMD_CAN_CONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

#if 0
    typedef enum
    {
        CAN_BPS_10KBPS,     // 6.7km Class A max // Komodo not support
        CAN_BPS_20KBPS,     // 3.3km Class B     // Ok
        CAN_BPS_50KBPS,     // 1.3km Class B     // Ok
        CAN_BPS_100KBPS,    // 620m  Class B     // Ok
        CAN_BPS_125KBPS,    // 530m  Class B max // Ok
        CAN_BPS_250KBPS,    // 270m  Class C     // Ok
        CAN_BPS_500KBPS,    // 130m  Class C     // Ok
        CAN_BPS_800KBPS,    // 80m   Class C     // komodo not support
        CAN_BPS_1000KBPS,   // 40m   Class C max // Ok
        MAX_OF_CAN_BPS
    } eCAN_KBPS;
#endif

    for(i = CAN_BPS_20KBPS; i < MAX_OF_CAN_BPS; i++)
    {
        if(i != CAN_BPS_800KBPS)
        {
            canInfo.baudrate = (eCAN_KBPS)i;
            BasicCAN.baudrate = canInfo.baudrate;

            ncLib_CAN_Control(GCMD_CAN_INIT_CH, canInfo.channel, canInfo.mode, CMD_END);
            ncLib_CAN_Control(GCMD_CAN_SETUP, canInfo.channel, &BasicCAN, CMD_END);

            memset((UINT8 *)&gp_AppCanRxMsg[canInfo.channel], 0, sizeof(tCAN_MSG));

            while(1)
            {
                APACHE_SYS_mDelay(100);

                ret = ncLib_CAN_Control(GCMD_CAN_RECEIVE, canInfo.channel, &gp_AppCanRxMsg[canInfo.channel], CMD_END);

                if(ret == NC_SUCCESS)
                {
                    ncLib_CAN_DebugRxPrint(canInfo.channel, gp_AppCanRxMsg[canInfo.channel]);
                    ncLib_CAN_Control(GCMD_CAN_REMOTE_REQ, canInfo.channel, &gp_AppCanRxMsg[canInfo.channel], CMD_END);

                    DEBUGMSG(MSGINFO, ".\n\n");
                    break;
                }
            }

            ncLib_CAN_Control(GCMD_CAN_DEINIT_CH, canInfo.channel, canInfo.mode, CMD_END);
        }
    }


    ncLib_CAN_Control(GCMD_CAN_DISCONNECT_ISR_HANDLER, canInfo.channel, CMD_END);

    ncLib_CAN_Close();
}


void ncLib_CAN_DebugTxPrint(eCAN_CH channel, tCAN_MSG txmsg)
{
    UINT32 i;

    DEBUGMSG(MSGINFO, "CAN2.0B Tx Information...\n");

    DEBUGMSG(MSGINFO, "CAN-%d channel\n", channel);

    DEBUGMSG(MSGINFO, "CAN Tx mode : %s\n", txmsg.mode ? "PeriCAN" : "BasicCAN");
    DEBUGMSG(MSGINFO, "CAN Tx Frame Format : %s\n", txmsg.format ? "Extended Frame Format" : "Standard Frame Format");
    DEBUGMSG(MSGINFO, "CAN Tx Transmission Request : %s\n", txmsg.rtr ? "Remote Frame" : "Data Frame");

    DEBUGMSG(MSGINFO, "CAN Tx ID : 0x%X\n", txmsg.id);
    DEBUGMSG(MSGINFO, "CAN Tx Data Length : %d\n", txmsg.length);

    for(i = 0; i < txmsg.length; i++)
    {
        DEBUGMSG(MSGINFO, "CAN Tx Data[%d] : 0x%X\n", i, txmsg.data[i]);
    }

    DEBUGMSG(MSGINFO, "\n");
}


BOOL ncLib_CAN_DebugRxPrint(eCAN_CH channel, tCAN_MSG rxmsg)
{
    UINT32 i;
    BOOL fEnalbe = 1;

    if(rxmsg.mode == CAN_CDR_PERI_MODE)
    {
        DEBUGMSG(MSGINFO, "CAN2.0B PeriCAN Rx Information...\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, "CAN2.0A BasicCAN Rx Information...\n");
    }

    DEBUGMSG(MSGINFO, "CAN-%d channel\n", channel);

    DEBUGMSG(MSGINFO, "CAN Rx mode : %s\n", rxmsg.mode ? "PeriCAN" : "BasicCAN");
    DEBUGMSG(MSGINFO, "CAN Rx Frame Format : %s\n", rxmsg.format ? "Extended Frame Format" : "Standard Frame Format");
    DEBUGMSG(MSGINFO, "CAN Rx Transmission Request : %s\n", rxmsg.rtr ? "Remote Frame" : "Data Frame");

    DEBUGMSG(MSGINFO, "CAN Rx ID : 0x%X\n", rxmsg.id);
    DEBUGMSG(MSGINFO, "CAN Rx Data Length : %d\n", rxmsg.length);

    for(i = 0; i < rxmsg.length; i++)
    {
        DEBUGMSG(MSGINFO, "CAN Rx Data[%d] : 0x%X\n", i, rxmsg.data[i]);
    }

    DEBUGMSG(MSGINFO, "\n");

    return fEnalbe;
}


#endif


/* End Of File */
