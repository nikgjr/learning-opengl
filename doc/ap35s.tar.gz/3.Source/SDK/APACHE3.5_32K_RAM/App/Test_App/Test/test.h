/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Test.h
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __TEST_H__
#define __TEST_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Type.h"


/*
********************************************************************************
*                   	           DEFINES
********************************************************************************
*/

// IP Unit Test

#define ENABLE_IP_GIC           FALSE
#define ENABLE_IP_DMAC          FALSE
#define ENABLE_IP_SCU           FALSE
#define ENABLE_IP_WDT           FALSE
#define ENABLE_IP_TIMER         FALSE
#define ENABLE_IP_SYSTIME       FALSE
#define ENABLE_IP_TEMPS         FALSE
#define ENABLE_IP_DDR           FALSE
#define ENABLE_IP_I2C           TRUE
#define ENABLE_IP_GPIO          FALSE
#define ENABLE_IP_SPI           FALSE
#define ENABLE_IP_SF        	FALSE
#define ENABLE_IP_ISP           FALSE
#define ENABLE_IP_CAN           FALSE
#define ENABLE_IP_LUT           FALSE
#define ENABLE_IP_VDP           FALSE

// Scenario Integrated Test

#define ENABLE_ST_PREVIEW       FALSE










/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/* APCHE3.5 FPGA IP test list number */

enum
{
    FPGA_IP_TEST_QUIT = 0,      ///< 0 Quit

    // Unit Test

    FPGA_IP_TEST_GIC,           ///< 1 Generic Interrupt Controller
    FPGA_IP_TEST_2,             ///< 2 Reserved
    FPGA_IP_TEST_DMAC,          ///< 3 Direct Memory Access Controller
    FPGA_IP_TEST_SCU,           ///< 4 System Control Unit
    FPGA_IP_TEST_WDT,           ///< 5 Watchdog Timer
    FPGA_IP_TEST_TIMER,         ///< 6 Timer
    FPGA_IP_TEST_TEMPS,         ///< 7 Temperature Sensor
    FPGA_IP_TEST_DDR,           ///< 8 Low Poer DDR Memory Controller
    FPGA_IP_TEST_I2C,           ///< 9 Inter Integrated Circuit

    FPGA_IP_TEST_A,             ///< a Reserved
    FPGA_IP_TEST_GPIO,          ///< b General Purpose Input/Output
    FPGA_IP_TEST_SPI,           ///< c Serial Peri. Interface, Quad-SPI
    FPGA_IP_TEST_CAN,           ///< d CAN 2.0A, 2.0B
    FPGA_IP_TEST_VDUMP,         ///< e Video Dump

    FPGA_IP_TEST_F,             ///< f Reserved
    FPGA_IP_TEST_SYSTIME,       ///< g System Timer
    FPGA_IP_TEST_SF,            ///< h sFlash interface
    FPGA_IP_TEST_LUT,           ///< i LUT
    FPGA_IP_TEST_ISP,           ///< j ISP - DPGL
    FPGA_IP_TEST_OSG,           ///< k OSG
    FPGA_IP_TEST_L,             ///< l Reserved
    FPGA_IP_TEST_M,             ///< m Reserved
    FPGA_IP_TEST_N,             ///< n Reserved

    FPGA_IP_TEST_O,             ///< o Reserved
    FPGA_IP_TEST_P,             ///< p Reserved
    FPGA_IP_TEST_Q,             ///< q Reserved
    FPGA_IP_TEST_R,             ///< r Reserved
    FPGA_IP_TEST_S,             ///< s Reserved
    FPGA_IP_TEST_T,             ///< t Reserved
    FPGA_IP_TEST_U,             ///< u Reserved


    // Integrated Test

    FPGA_IP_TEST_V,             ///< v Reserved
    FPGA_IP_TEST_W,             ///< w Reserved
    FPGA_IP_TEST_X,             ///< x Reserved
    FPGA_IP_TEST_Y,             ///< y Reserved
    FPGA_SCENARIO_TEST_PREVIEW,             ///< z FPGA Preview Enable Scenario

    MAX_OF_FPGA_IP_TEST
};


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

/* Test Main */
extern INT32 APACHE_TEST_APP_Main(void);


#if ENABLE_IP_I2C
/* I2C Test Functions */
extern INT32 APACHE_TEST_I2C_CUTMode(void);
#endif

#if ENABLE_ST_PREVIEW
/* Preview Scenario Test Functions */
extern void APACHE_TEST_I2C_CMOS_AR0132AT_Initialize(void);
extern void APACHE_TEST_I2C_CMOS_AR0140AT_Initialize(void);
extern void APACHE_TEST_SSP_IMX244_LVDSInit(void);
extern void APACHE_TEST_I2C_HDMI_Initialize(void);
#endif

#if ENABLE_IP_SPI
/* SSP Test Functions */
extern INT32 APACHE_TEST_SSP_CUTMode(void);
#endif

#if ENABLE_IP_DDR
/* DDR Test Functions */
extern INT32 APACHE_TEST_DDR_CUTMode(void);
#endif

#if ENABLE_IP_TIMER
/* TIMER Functions */
extern INT32 APACHE_TEST_TIMER_CUTMode(void);
#endif

#if ENABLE_IP_SYSTIME
/* System Timer Functions */
extern INT32 APACHE_TEST_SYSTIME_CUTMode(void);
#endif

#if ENABLE_IP_SF
/* sFlash Functions */
extern INT32 APACHE_TEST_SF_CUIMode(void);
#endif


#if ENABLE_IP_ISP
/* ISP Test Functions */
extern INT32 APACHE_TEST_DPGL_CUTMode(void);
extern INT32 APACHE_TEST_OSG_CUTMode(void);
#endif


#if ENABLE_IP_DMAC
/* sFlash Functions */
extern INT32 APACHE_TEST_DMA_CUIMode(void);
#endif

#if ENABLE_IP_GPIO
/* GPIO Functions */
extern INT32 APACHE_TEST_GPIO_CUIMode(void);
#endif

#if ENABLE_IP_WDT
/* Watchdog Timer Functions */
extern INT32 APACHE_TEST_WDT_CUTMode(void);
#endif

#if ENABLE_IP_CAN
/* CAN Functions */
extern INT32 APACHE_TEST_CAN_CUTMode(void);
#endif

#if ENABLE_IP_VDP
/* VDUMP Functions */
extern INT32 APACHE_TEST_VDUMP_CUTMode(void);
#endif

#if ENABLE_IP_GIC
/* INTC Functions */
extern INT32 APACHE_TEST_GIC_CUTMode(void);
#endif

#endif  /* __TEST_H__ */


/* End Of File */
