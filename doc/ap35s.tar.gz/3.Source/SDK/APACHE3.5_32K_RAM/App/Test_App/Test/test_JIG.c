/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_JIG.c
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.11
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"


#if ENABLE_IP_JIG


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

void APACHE_TEST_JIG_Initialize(void);


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 APACHE_TEST_JIG_CUTMode(void)
{
    INT32 select;
    char buf[16];

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - UART                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " 2-Channel UART Controller                                  \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> JIG Uart Initialize & Run                              \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ...                        \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_JIG_Initialize();
            break;

            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto Jig_Exit;
        }
    }

Jig_Exit:

    return NC_SUCCESS;
}


void APACHE_TEST_JIG_Initialize(void)
{
    tUART_PARAM param;
    INT32 ret = NC_SUCCESS;

    DEBUGMSG(MSGINFO, "Initialize JIG Port ... ");

    param.uartClk = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_UART, CMD_END);
    param.baudRate = UT_BAUDRATE_38400;
    param.sps = UT_SPS_DIS;
    param.wlen = UT_DATA_8BIT;
    param.fen = UT_FIFO_ENA;
    param.stp2 = UT_STOP_1BIT;
    param.eps = UT_EPS_DIS;
    param.pen = UT_PARITY_DIS;
    param.brk = UT_BRK_DIS;

    ret = ncLib_JIG_Open(param.uartClk);
    ret |= ncLib_JIG_Control(GCMD_JIG_INIT, UART_CH1, &param, CMD_END);

    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "FAIL!\n");
    }
    else
    {
        /* Connect 50m second period timer handler to check JIG Interface   */

        DEBUGMSG(MSGINFO, "OK!\n");

        while(1)
        {
            APACHE_SYS_mDelay(15); // 50MHz case
            //APACHE_SYS_mDelay(20); // ??ms
            ncLib_JIG_Control(GCMD_JIG_DO_COMMAND, UART_CH1, CMD_END);
        }
    }

    ret = ncLib_JIG_Control(GCMD_JIG_DEINIT, UART_CH1, CMD_END);
    ret = ncLib_JIG_Close();
}


#endif


/* End Of File */




