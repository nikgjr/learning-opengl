/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_ISP.c
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"

#include "../../ncLib/SWC_ISP/Api/DPGL_Api.h"

#include "../../ncLib/SWC_ISP/Api/PGL_Api.h"

#include "../../ncLib/SWC_ISP/Api/Osg_Api.h"









#if ENABLE_IP_ISP


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 APACHE_TEST_DPGL_CUTMode(void)
{
#if 0
    INT32 select;
    char buf[16];

	char TestAlgel;
	char TestOnOff=1;
	 INT32 idx = 0;

	 
	 
	ncLib_DPgl_Control(DPGL_INIT,CMD_END);
	
	ncLib_Pgl_Control(PGL_INIT, CMD_END);
    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - UART                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " ISP Controller                                             \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> D-PGL angle -45                                        \n");         
        DEBUGMSG(MSGINFO, " <2> D-PGL angle 0                                          \n");
        DEBUGMSG(MSGINFO, " <3> D-PGL angle +45                                        \n");
        DEBUGMSG(MSGINFO, " <4> D-PGL Blue Gradation on                                \n"); 
        DEBUGMSG(MSGINFO, " <5> D-PGL Blue Gradation off                               \n");  
        DEBUGMSG(MSGINFO, " <6> D-PGL Auto                                             \n");  
        DEBUGMSG(MSGINFO, " <7> D-PGL angle Up                                         \n"); 
		DEBUGMSG(MSGINFO, " <8> D-PGL angle Down                                       \n"); 
		DEBUGMSG(MSGINFO, " <9> D-PGL On Off                                           \n"); 
		DEBUGMSG(MSGINFO, " <A> S-PGL On                                               \n"); 
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ...                        \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        
        switch(select)
        {
            case 1: 
				 ncLib_DPgl_Control(DPGL_SET_ANGEL,0,CMD_END);
                 break;
            case 2: 
				 ncLib_DPgl_Control(DPGL_SET_ANGEL,45,CMD_END);
                 break;
            case 3: 
				 ncLib_DPgl_Control(DPGL_SET_ANGEL,90,CMD_END);
                break;  
            case 4:
				 ncLib_DPgl_Control(DPGL_GRAD_ENABLE,1,CMD_END);
                 break;
            case 5:
                 ncLib_DPgl_Control(DPGL_GRAD_ENABLE,0,CMD_END);
                 break; 
            case 6:
				 for(idx=0; idx<90; idx++)
                 {
				 	TestAlgel = idx;
                     ncLib_DPgl_Control(DPGL_SET_ANGEL,TestAlgel,CMD_END);
                     APACHE_SYS_mDelay(6);
                 }
				  for(; idx>0; idx--)
                 {
				 	TestAlgel = idx;
                     ncLib_DPgl_Control(DPGL_SET_ANGEL,TestAlgel,CMD_END);
                     APACHE_SYS_mDelay(6);
                 }
                 break; 
			case 7:
				if(TestAlgel<90)
				{
					TestAlgel++;
                	ncLib_DPgl_Control(DPGL_SET_ANGEL,TestAlgel,CMD_END);
				}
                 break; 
			case 8:
				if(TestAlgel)
				{
					TestAlgel--;
            	     ncLib_DPgl_Control(DPGL_SET_ANGEL,TestAlgel,CMD_END);   
				}
                 break; 
            case 9:
				TestOnOff = !TestOnOff;
				 ncLib_DPgl_Control(DPGL_ENABLE,TestOnOff,CMD_END); 
                 break; 

			 case 0x0A:
			 	TestOnOff = !TestOnOff;
					if(TestOnOff)
					{
				 	ncLib_Pgl_Control(PGL_CMD_ON,CMD_END); 
					}
					else
					{
				 	ncLib_Pgl_Control(PGL_CMD_OFF,CMD_END); 
					}
						
                 break; 

            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto DPGL_Exit;
        }
    }

DPGL_Exit:
#endif

    return NC_SUCCESS;
}

#define ISP_OSG1_BASE                (APACHE_ISP_BASE + 0x2400)
#define ISP_OSG2_BASE                (APACHE_ISP_BASE + 0x2500)
#define ISP_OSG3_BASE                (APACHE_ISP_BASE + 0x2600)


void APACEH_TEST_OSG_APBMode(void)
{
#if 0
    UINT8 Reg;
    UINT32 Addr = 0x00080000;
    UINT32 Size = (5*KB);
    //UINT32 Cnt = 1;

    //while(Cnt++)
    {
        //DEBUGMSG(MSGINFO,"\r Quad SPI(OSG) APB Mode Test - 0x%08x", Cnt);

        for(Addr = 0x00080000; Addr< 0x00080000+((5*KB)*80); Addr+=(5*KB))
        {
            REGRW8(ISP_OSG1_BASE,0x00)=0x00;
            REGRW8(ISP_OSG1_BASE,0x01)=0x00;
            REGRW8(ISP_OSG1_BASE,0x02)=0x80;
            REGRW8(ISP_OSG1_BASE,0x03)=0x80;
            REGRW8(ISP_OSG1_BASE,0x16)=0xC0;
            REGRW8(ISP_OSG1_BASE,0x17)=0x04;
            REGRW8(ISP_OSG1_BASE,0x18)=0x00;
            REGRW8(ISP_OSG1_BASE,0x19)=0x00;
            REGRW8(ISP_OSG1_BASE,0x1E)=0x00;
            REGRW8(ISP_OSG1_BASE,0x1F)=0x00;
            REGRW8(ISP_OSG1_BASE,0x20)=0x08;
            REGRW8(ISP_OSG2_BASE,0xF1)=0x02;
            REGRW8(ISP_OSG2_BASE,0xF2)=0x03;
            REGRW8(ISP_OSG1_BASE,0x70)=0x01;
            REGRW8(ISP_OSG1_BASE,0x70)=0x00; 

            REGRW8(ISP_OSG3_BASE,0xF1)=0x10;
            REGRW8(ISP_OSG3_BASE,0xF0)=0xE4;



            while( !(REGRW32(ISP_OSG2_BASE,0xf4) & (1<<0)) );



            if( ncLib_SF_Control(SCMD_SF_OSG_READ_DATA, Addr, APACHE_OSG_BASE, Size, CMD_END) != 0 )
            {
            DEBUGMSG_SDK(MSGERR, "QSPI OSG Read Fail - Driec!\n");
            return;
            }



            Reg = REGRW8(ISP_OSG3_BASE,0xF1);
            REGRW8(ISP_OSG3_BASE,0xF1)= Reg|0x1;  
            REGRW8(ISP_OSG3_BASE,0xF1)= Reg|0x0;  

        }
    }
#endif
}







INT32 APACHE_TEST_OSG_CUTMode(void)
{
#if 0
    INT32 select;
    char buf[16];
    INT32 idx = 0;

    ncLib_Osg_Control(OSG_INIT,CMD_END);

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - ODG                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " ISP Controller                                             \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ...                        \n");
        DEBUGMSG(MSGINFO, " <1> SCMD_SF_OSG_READ_EN                                   \n");         
        DEBUGMSG(MSGINFO, " <2> OSG OFF                                    \n");         
        DEBUGMSG(MSGINFO, " <3> OSG ON ( LOGO,CAR )                                    \n");         
        DEBUGMSG(MSGINFO, " <4> OSG PGL                                     \n");        
        DEBUGMSG(MSGINFO, " <5> OSG L 0 Up                                     \n");        
        DEBUGMSG(MSGINFO, " <6> FROM Mr 6 quad_spi_set_pm                      \n");        
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);

        switch(select)
        {
            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto OSG_Exit;

            case 1: 
                ncLib_SF_Control(SCMD_SF_OSG_READ_EN, CMD_END);
            break;

            case 2: 
                ncLib_Osg_Control(OSG_DISPLAY_ALL_SET,0,CMD_END);
                ncLib_Osg_Control(OSG_REFRESH,CMD_END);
            break;
            case 3: 
               // ncLib_Osg_Control(OSG_INIT,CMD_END);
                ncLib_Osg_Control(OSG_DISPLAY_ALL_SET,1,CMD_END);
				
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER0,1,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER1,1,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER2,1,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER3,1,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER4,1,CMD_END); 
				ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER5,1,CMD_END); 


                ncLib_Osg_Control(OSG_LAYER_INDEX_SET,OSG_CMD_LAYER0,0,CMD_END); 
				ncLib_Osg_Control(OSG_LAYER_INDEX_SET,OSG_CMD_LAYER1,0,CMD_END); 
				ncLib_Osg_Control(OSG_LAYER_INDEX_SET,OSG_CMD_LAYER2,0,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_INDEX_SET,OSG_CMD_LAYER3,0,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_INDEX_SET,OSG_CMD_LAYER4,0,CMD_END); 
				ncLib_Osg_Control(OSG_LAYER_INDEX_SET,OSG_CMD_LAYER5,0,CMD_END); 
                ncLib_Osg_Control(OSG_REFRESH,CMD_END);
            break;

            case 4: 
                ncLib_Osg_Control(OSG_DISPLAY_ALL_SET,1,CMD_END);
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER0,0,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER1,0,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER2,0,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER3,0,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER4,0,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER5,1,CMD_END); 



                for(idx=0; idx<68; idx++)
                {
                    ncLib_Osg_Control(OSG_LAYER_INDEX_SET,OSG_CMD_LAYER5,idx,CMD_END); 
                    ncLib_Osg_Control(OSG_REFRESH,CMD_END);
                    APACHE_SYS_mDelay(6);
                }
                for(; idx>0; idx--)
                {
                    ncLib_Osg_Control(OSG_LAYER_INDEX_SET,OSG_CMD_LAYER5,idx,CMD_END); 
                    ncLib_Osg_Control(OSG_REFRESH,CMD_END);
                    APACHE_SYS_mDelay(6);
                }

            break;

            case 5: 	
                idx++;
                if(idx>57)
                {
                    idx=0;
                }
                ncLib_Osg_Control(OSG_DISPLAY_ALL_SET,1,CMD_END);
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER0,1,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER1,0,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER2,0,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER3,0,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER4,0,CMD_END); 
                ncLib_Osg_Control(OSG_LAYER_DISPLAY_SET,OSG_CMD_LAYER5,0,CMD_END); 

                ncLib_Osg_Control(OSG_LAYER_INDEX_SET,OSG_CMD_LAYER0,idx,CMD_END); 
                ncLib_Osg_Control(OSG_REFRESH,CMD_END);

            break;


            case 6: 	
                APACEH_TEST_OSG_APBMode();	
                
            break;



        }

    }

OSG_Exit:
#endif

    return NC_SUCCESS;
}


   




#endif


/* End Of File */





