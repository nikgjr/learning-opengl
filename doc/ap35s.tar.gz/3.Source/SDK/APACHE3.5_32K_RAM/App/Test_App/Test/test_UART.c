/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_UART.c
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.06
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"


#if ENABLE_IP_UART


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

// Test Control Register
#define UARTTCR             0x30A00080

#define TCR_SIRTEST             (1<<2)
#define TCR_TESTFIFO            (1<<1)
#define TCR_ITEN                (1<<0)


// Integration Test Input Read/Set Register
#define UARTITIP            0x30A00084

#define ITIP_UARTTXDMACLR       (1<<7)
#define ITIP_UARTRXDMACLR       (1<<6)
#define ITIP_NUARTTRI           (1<<5)
#define ITIP_NUARTDCD           (1<<4)
#define ITIP_NUARTCTS           (1<<3)
#define ITIP_NUARTDSR           (1<<2)
#define ITIP_SIRIN              (1<<1)
#define ITIP_UARTRXD            (1<<0)


// Integration Test Output Read/Set Register
#define UARTITOP            0x30A00088

#define ITIP_UARTTXDMASREQ      (1<<15)
#define ITIP_UARTTXDMABREQ      (1<<14)
#define ITIP_UARTRXDMASREQ      (1<<13)
#define ITIP_UARTRXDMABREQ      (1<<12)
#define ITIP_UARTMSINRT         (1<<11)
#define ITIP_UARTRXINTR         (1<<10)
#define ITIP_UARTTXINRT         (1<<9)
#define ITIP_UARTRTINTR         (1<<8)
#define ITIP_UARTEINTR          (1<<7)
#define ITIP_UARTINTR           (1<<6)
#define ITIP_NUARTTOUT2         (1<<5)
#define ITIP_NUARTTOUT1         (1<<4)
#define ITIP_NUARTRTS           (1<<3)
#define ITIP_NUARTDTR           (1<<2)
#define ITIP_NSIROUT            (1<<1)
#define ITIP_UARTTXD            (1<<0)


// Test Data Register
#define UARTTDR             0x30A0008C


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

void APACHE_TEST_UART_PeripheralID(void);
void APACHE_TEST_UART_PrimeCellID(void);
void APACHE_TEST_UART_ATPG(void);
void APACHE_TEST_UART_RxIntr(void);
void APACHE_TEST_UART_TxIntr(void);


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 APACHE_TEST_UART_CUTMode(void)
{
    INT32 select;
    char buf[16];

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - UART                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " 2-Channel UART Controller                                  \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> UART Peripheral Identification                         \n");
        DEBUGMSG(MSGINFO, " <2> UART PrimeCell Identification                          \n");
        DEBUGMSG(MSGINFO, " <3> UART Automatic Test Pattern Generation                 \n");
        //DEBUGMSG(MSGINFO, " <1> Interrupt Rx Test                                      \n");
        //DEBUGMSG(MSGINFO, " <2> Interrupt Tx Test                                      \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ...                        \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_UART_PeripheralID();
            break;

            case 2:
                APACHE_TEST_UART_PrimeCellID();
            break;

            case 3:
                APACHE_TEST_UART_ATPG();
            break;

            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto Uart_Exit;
        }
    }

Uart_Exit:

    return NC_SUCCESS;
}


void APACHE_TEST_UART_PeripheralID(void)
{
    UINT32 periID;

    DEBUGMSG(MSGINFO, "UART Channel 0 Peripheral Identification\n");
    DEBUGMSG(MSGINFO, "=============================================\n");

    //periID = ncLib_UART_Control(GCMD_UT_PERIID, UART_CH0, CMD_END);

    DEBUGMSG(MSGINFO, "UART periID = 0x%08X\n", periID);
    DEBUGMSG(MSGINFO, "=============================================\n");
    DEBUGMSG(MSGINFO, "Part number 0     : 0x%X\n", periID&0xFF);
    DEBUGMSG(MSGINFO, "Designer number 0 : 0x%X\n", (periID>>12)&0xF);
    DEBUGMSG(MSGINFO, "Part number 1     : 0x%X\n", (periID>>8)&0xF);
    DEBUGMSG(MSGINFO, "Revision number   : 0x%X\n", (periID>>20)&0xF);
    DEBUGMSG(MSGINFO, "Designer number 1 : 0x%X\n", (periID>>16)&0xF);
    DEBUGMSG(MSGINFO, "Configuration   : 0x%X\n", (periID>>24)&0xFF);
    DEBUGMSG(MSGINFO, "=============================================\n");

    ncLib_UART_Close();
}


void APACHE_TEST_UART_PrimeCellID(void)
{
    UINT32 primeCellID;

    DEBUGMSG(MSGINFO, "UART Channel 0 PrimeCell Identification\n");
    DEBUGMSG(MSGINFO, "=============================================\n");

    //primeCellID = ncLib_UART_Control(GCMD_UT_PRIMECELLID, UART_CH0, CMD_END);

    DEBUGMSG(MSGINFO, "UART periID = 0x%08X\n", primeCellID);
    DEBUGMSG(MSGINFO, "=============================================\n");

    ncLib_UART_Close();
}


void APACHE_TEST_UART_ATPG(void)
{
#if 0
    // Test Control Register
    REGRW32(0x30A00000, 0x0080)

    // Integration Test Input Read/Set Register
    REGRW32(0x30A00000, 0x0084)

    // Integration Test Output Read/Set Register
    REGRW32(0x30A00000, 0x0088)

    // Test Data Register
    REGRW32(0x30A00000, 0x008C)
#endif
}



void APACHE_TEST_UART_RxIntr(void)
{
#if  0
    tUART_PARAM param;
    INT32 ret = NC_SUCCESS;

    param.uartClk = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_UART, CMD_END);
    param.baudRate = UT_BAUDRATE_115200;
    param.sps = UT_SPS_DIS;
    param.wlen = UT_DATA_8BIT;
    param.fen = UT_FIFO_ENA;
    param.stp2 = UT_STOP_1BIT;
    param.eps = UT_EPS_DIS;
    param.pen = UT_PARITY_DIS;
    param.brk = UT_BRK_DIS;

    ret = ncLib_UART_Control(GCMD_UT_INIT_CH, UART_CH0, &param, CMD_END);
#endif
}


void APACHE_TEST_UART_TxIntr(void)
{
}



#endif


/* End Of File */




