/**
********************************************************************************
*
*  Copyright (C) 2013 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_Gpio.c
*
*  @brief   : This file is GPIO test code for NEXTCHIP standard library
*
*  @author  : Alessio / Automotive SoC Software Team
*
*  @date    : 2013.11.12
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 2013.11.12 - GPIO basic test code modified by Alessio
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"
#include "test.h"

#if ENABLE_IP_GPIO

/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/
#define __G_TOLOWER(c)              (((c) >= 'A' && (c) <= 'Z' ) ? (c)+('a'-'A') : (c))











/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/



/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
static INT32 __test_gpio_atoi(char *Str)
{
    UINT32    Val;
    INT32     Offset, c;
    char      *Sp;

    Val = 0;
    Sp = Str;

    if((*Sp == '0') && (*(Sp+1) == 'x'))
    {
        Offset = 16;
        Sp += 2;
    }
    else if(*Sp == '0')
    {
        Offset = 8;
        Sp++;
    }
    else
    {
        Offset = 10;
    }

    for(; (*Sp != 0); Sp++)
    {
        c = (*Sp > '9') ? (__G_TOLOWER(*Sp) - 'a' + 10) : (*Sp - '0');
        Val = (Val * Offset) + c;
    }

    return(Val);
}

UINT32 __test_gpio_display_inputvalue(UINT32 MinNum, UINT32 MaxNum, char *Str)
{
    char   buf[100];
    UINT32 InputNum;

    do
    {
        InputNum = 0;
        DEBUGMSG(MSGINFO, "-------------------------------------------------------------\n");	
        DEBUGMSG(MSGINFO, " [%s] input (%d ~ %d) >> ", Str, MinNum, MaxNum);
        DBGSCANF(buf);

        InputNum = __test_gpio_atoi(buf);
        if((InputNum < MinNum) || (InputNum > MaxNum))
            DEBUGMSG(MSGINFO, " input Fail : %d\n", InputNum);

    }while((InputNum < MinNum) || (InputNum > MaxNum));

    DEBUGMSG(MSGINFO, "\n input Ok : %d\n", InputNum);

    return InputNum;
}

void APACHE_TEST_GPIO_OutputMode(void)
{
    eGPIO_GROUP group;
    eGPIO_PORT  port;
    UINT32 level;
    UINT8  Min;
    UINT8  Max;


    DEBUGMSG(MSGINFO, "\nGPIO, Output Mode Test\n\n");


    //ncLib_GPIO_Open();


    group = (eGPIO_GROUP)__test_gpio_display_inputvalue(GPIO_GROUP_A, GPIO_GROUP_C, "GPIO Group Select Group_A[0], Group_B[1], Group_C[2],");

    if(group == GPIO_GROUP_C)
    {
        Min = 2;
        Max = 7;
    }
    else
    {
        Min = 0;
        Max = 31;  
    }
    
    port  = (eGPIO_PORT)__test_gpio_display_inputvalue(Min, Max, "GPIO Port Select");
    
    ncLib_GPIO_Control(GCMD_GPIO_ENA, group, port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, group, port, GPIO_DIR_OUT, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, group, port, GPIO_LOW, CMD_END);
    
    while(1)
    {
        level  = __test_gpio_display_inputvalue(0, 2, "LOW(0) or HIGH(1) or Stop(2)");

        if( level == 2 )
            break;
        
        if(level == 0)
        {
            DEBUGMSG(MSGINFO, " GPIO_%d[%02d] - LOW \n", group, port);
            ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, (eGPIO_GROUP)group, (eGPIO_PORT)port, GPIO_LOW, CMD_END);
        }
        else if (level == 1)
        {
            DEBUGMSG(MSGINFO, " GPIO_%d[%02d] - HIGH \n", group, port);
            ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, (eGPIO_GROUP)group, (eGPIO_PORT)port, GPIO_HIGH, CMD_END);
        }
    }

    if( ((group == GPIO_GROUP_B) && (port == GPIO_PORT14)) || ((group == GPIO_GROUP_B) && (port == GPIO_PORT15)) )
    {
        DEBUGMSG(MSGINFO, "Current Debug Port -> GPIO0/GPIO1 Port\n");
    }
    else
    {
        ncLib_GPIO_Control(GCMD_GPIO_DIS, (eGPIO_GROUP)group, (eGPIO_PORT)port, CMD_END);
    }



    //ncLib_GPIO_Close();

    DEBUGMSG(MSGINFO, "=================================\n");
}

void APACHE_TEST_GPIO_InputMode(void)
{
    eGPIO_GROUP group;
    eGPIO_PORT  port;
    UINT32 level;    
    UINT8  Min;
    UINT8  Max;
    UINT32 i;


    DEBUGMSG(MSGINFO, "\nGPIO, Output Mode Test\n\n");


    //ncLib_GPIO_Open();


    group = (eGPIO_GROUP)__test_gpio_display_inputvalue(GPIO_GROUP_A, GPIO_GROUP_C, "GPIO Group Select Group_A[0], Group_B[1], Group_C[2],");

    if(group == GPIO_GROUP_C)
    {
        Min = 2;
        Max = 7;
    }
    else
    {
        Min = 0;
        Max = 31;  
    }
    
    port  = (eGPIO_PORT)__test_gpio_display_inputvalue(Min, Max, "GPIO Port Select");
    
    ncLib_GPIO_Control(GCMD_GPIO_ENA, group, port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, group, port, GPIO_DIR_IN, CMD_END);
    
    for(i=0; i<4; i++)
    {
        ncLib_GPIO_Control(GCMD_GPIO_GET_DATA, (eGPIO_GROUP)group, (eGPIO_PORT)port, &level, CMD_END);
                    
        if(level == 0)
        {
            DEBUGMSG(MSGINFO, " GPIO_%d[%02d] - LOW \n", group, port);
        }
        else if (level == 1)
        {
            DEBUGMSG(MSGINFO, " GPIO_%d[%02d] - HIGH \n", group, port);
        }

        APACHE_SYS_mDelay(2000);
    }

    if( ((group == GPIO_GROUP_B) && (port == GPIO_PORT14)) || ((group == GPIO_GROUP_B) && (port == GPIO_PORT15)) )
    {
        DEBUGMSG(MSGINFO, "Current Debug Port -> GPIO0/GPIO1 Port\n");
    }
    else
    {
        ncLib_GPIO_Control(GCMD_GPIO_DIS, (eGPIO_GROUP)group, (eGPIO_PORT)port, CMD_END);
    }


    //ncLib_GPIO_Close();

    DEBUGMSG(MSGINFO, "=================================\n");
}


INT32 APACHE_TEST_GPIO_CUIMode(void)
{
    INT32 select;
    char buf[256];

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - GPIO                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " GPIO Controller                                            \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> GPIO Output Test                                       \n");
        DEBUGMSG(MSGINFO, " <2> GPIO Input Test                                        \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
            {
                APACHE_TEST_GPIO_OutputMode();
            }
            break;

            case 2:
            {
                APACHE_TEST_GPIO_InputMode();
            }
            break;

            case 0:
                DEBUGMSG(MSGINFO, "Move on to sub menu\n");
            goto Gpio_Exit;
        }
    }

Gpio_Exit:

    return NC_SUCCESS;
}

#endif /* #if ENABLE_IP_TC */

/* End Of File */
