/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_SysTimer.c
*
*  @brief   : This file is System timer test code for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.11.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note
*
*
*
*
********************************************************************************
*/

/*
********************************************************************************
*                                 INCLUDE
********************************************************************************
*/
#include "App.h"

#include "test.h"

#include <time.h>


#if ENABLE_IP_SYSTIME






/*
********************************************************************************
*                            LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*                        LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                             LOCAL TYPEDEF
********************************************************************************
*/

/*
********************************************************************************
*                       IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                        GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/
static UINT32 gTestCount = 0;

/*
********************************************************************************
*                       IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                         LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

/*
********************************************************************************
*                             FUNCTION DEFINITIONS
********************************************************************************
*/
void __conversion_time_to_systemtime(struct tm *ptSysTime, tTIME_VAL *ptTime )
{
	time_t rawtime;
	struct tm *ptm;

	rawtime = ptTime->tv_sec;
	ptm = localtime(&rawtime);

	if(ptm != NULL)
	{
		ptSysTime->tm_year		= ptm->tm_year;
		ptSysTime->tm_mon 		= ptm->tm_mon;
		ptSysTime->tm_mday		= ptm->tm_mday;
		ptSysTime->tm_hour		= ptm->tm_hour;
		ptSysTime->tm_min 		= ptm->tm_min;
		ptSysTime->tm_sec 		= ptm->tm_sec;
	}
}

void __conversion_systemtime_to_time(struct tm *ptSysTime, tTIME_VAL *ptTime )
{
	ptTime->tv_sec 	= (UINT32)mktime(ptSysTime);
	ptTime->tv_usec	= 0;
}

void APACHE_TEST_SYSTIME_EventHandler(void)
{
	++gTestCount;
	DEBUGMSG(MSGINFO, " EVENT  : %02d\n", gTestCount);
}

void APACHE_TEST_SYSTIME_Set_SysTime(void)
{
	INT32 ret;
	struct tm tSysTime;
	tTIME_VAL tTime;



	/*
	 * Initialize system time.
	 * System time has been counted in second from January 1, 1970
	 */
	memset(&tSysTime, 0, sizeof(struct tm));
	tSysTime.tm_year        = 2016-1900;
	tSysTime.tm_mon         = 1-1;
	tSysTime.tm_mday        = 1;
	tSysTime.tm_hour        = 0;
	tSysTime.tm_min         = 0;
	tSysTime.tm_sec         = 0;
	__conversion_systemtime_to_time(&tSysTime, &tTime);
	ret = ncLib_SYSTIME_Control(GCMD_ST_SET_SYSTIME, (UINT32)&tTime, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Set Error!\n");
	}



	/*
	 * Get System Timer
	 */
	ret = ncLib_SYSTIME_Control(GCMD_ST_GET_SYSTIME, (UINT32)&tTime, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Get Error!\n");
	}
	__conversion_time_to_systemtime(&tSysTime, &tTime);
	DEBUGMSG(MSGINFO, " Current  : [SYS TIME] %04d/%02d/%02d    %02d:%02d:%02d\n",
									tSysTime.tm_year+1900,
									tSysTime.tm_mon+1,
									tSysTime.tm_mday,
									tSysTime.tm_hour,
									tSysTime.tm_min,
									tSysTime.tm_sec);



	/*
	 * Delay System Timer
	 */
	DEBUGMSG(MSGINFO, " >> Wait 5sec\n");
	ret = ncLib_SYSTIME_Control(GCMD_ST_MDELAY, 5000, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Delay Error!\n");
	}




	/*
	 * Get System Timer
	 */
	ret = ncLib_SYSTIME_Control(GCMD_ST_GET_SYSTIME, (UINT32)&tTime, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Get Error!\n");
	}
	__conversion_time_to_systemtime(&tSysTime, &tTime);
	DEBUGMSG(MSGINFO, " Delay 5s : [SYS TIME] %04d/%02d/%02d    %02d:%02d:%02d\n",
									tSysTime.tm_year+1900,
									tSysTime.tm_mon+1,
									tSysTime.tm_mday,
									tSysTime.tm_hour,
									tSysTime.tm_min,
									tSysTime.tm_sec);

}

void APACHE_TEST_SYSTIME_Set_SysTimeDate(void)
{
	INT32 ret;
	struct tm tSysTime;



	/*
	 * Initialize system time.
	 * System time has been counted in second from January 1, 1970
	 */
	memset(&tSysTime, 0, sizeof(struct tm));
	tSysTime.tm_year        = 2016-1900;
	tSysTime.tm_mon         = 1-1;
	tSysTime.tm_mday        = 1;
	tSysTime.tm_hour        = 0;
	tSysTime.tm_min         = 0;
	tSysTime.tm_sec         = 0;
	ret = ncLib_SYSTIME_Control(GCMD_ST_SET_SYSTIME_DATE, (UINT32)&tSysTime, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Set Error!\n");
	}


	
	/*
	 * Get System Timer
	 */
	ret = ncLib_SYSTIME_Control(GCMD_ST_GET_SYSTIME_DATE, (UINT32)&tSysTime, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Get Error!\n");
	}
	DEBUGMSG(MSGINFO, " Current  : [SYS TIME] %04d/%02d/%02d    %02d:%02d:%02d\n",
									tSysTime.tm_year+1900,
									tSysTime.tm_mon+1,
									tSysTime.tm_mday,
									tSysTime.tm_hour,
									tSysTime.tm_min,
									tSysTime.tm_sec);



	/*
	 * Delay System Timer
	 */
	DEBUGMSG(MSGINFO, " >> Wait 5sec\n");
	ret = ncLib_SYSTIME_Control(GCMD_ST_MDELAY, 5000, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Delay Error!\n");
	}




	/*
	 * Get System Timer
	 */
	ret = ncLib_SYSTIME_Control(GCMD_ST_GET_SYSTIME_DATE, (UINT32)&tSysTime, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Get Error!\n");
	}
	DEBUGMSG(MSGINFO, " Delay 5s : [SYS TIME] %04d/%02d/%02d    %02d:%02d:%02d\n",
									tSysTime.tm_year+1900,
									tSysTime.tm_mon+1,
									tSysTime.tm_mday,
									tSysTime.tm_hour,
									tSysTime.tm_min,
									tSysTime.tm_sec);

}


void APACHE_TEST_SYSTIME_PeriodicTimeEvent(void)
{
	INT32 ret;
	struct tm tSysTime;


	/*
	 * Get System Timer
	 */
	ret = ncLib_SYSTIME_Control(GCMD_ST_GET_SYSTIME_DATE, (UINT32)&tSysTime, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Get Error!\n");
	}
	DEBUGMSG(MSGINFO, " Start    : [SYS TIME] %04d/%02d/%02d    %02d:%02d:%02d\n",
									tSysTime.tm_year+1900,
									tSysTime.tm_mon+1,
									tSysTime.tm_mday,
									tSysTime.tm_hour,
									tSysTime.tm_min,
									tSysTime.tm_sec);



	/*
	 * Delay System Timer
	 */
	DEBUGMSG(MSGINFO, " >> Wait 1sec\n");
	ret = ncLib_SYSTIME_Control(GCMD_ST_MDELAY, 1000, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Delay Error!\n");
	}



	/*
	 * Create Event Handler
	 */
	gTestCount = 0;
	ret = ncLib_SYSTIME_Control(GCMD_ST_CONNECT_PTE_HANDLER, ST_PTE_MSEC3, 1000, APACHE_TEST_SYSTIME_EventHandler, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Event Handler Create Error!\n");
	}



	/*
	 * Wait 5 seconds for test
	 */
	while(gTestCount < 10);



	/*
	 * Release Event Handler
	 */
	ret = ncLib_SYSTIME_Control(GCMD_ST_DISCONNECT_PTE_HANDLER, ST_PTE_MSEC3, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Event Handler Release Error!\n");
	}



	/*
	 * Delay System Timer
	 */
	DEBUGMSG(MSGINFO, " >> Wait 1sec\n");
	ret = ncLib_SYSTIME_Control(GCMD_ST_MDELAY, 1000, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Delay Error!\n");
	}



	/*
	 * Create Event Handler
	 */
	gTestCount = 0;
	ret = ncLib_SYSTIME_Control(GCMD_ST_CONNECT_PTE_HANDLER, ST_PTE_1SEC, NULL, APACHE_TEST_SYSTIME_EventHandler, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Event Handler Create Error!\n");
	}



	/*
	 * Wait 5 seconds for test
	 */
	while(gTestCount < 10);



	/*
	 * Release Event Handler
	 */
	ret = ncLib_SYSTIME_Control(GCMD_ST_DISCONNECT_PTE_HANDLER, ST_PTE_1SEC, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Event Handler Release Error!\n");
	}



	/*
	 * Get System Timer
	 */
	ret = ncLib_SYSTIME_Control(GCMD_ST_GET_SYSTIME_DATE, (UINT32)&tSysTime, CMD_END);
	if(ret == NC_FAILURE)
	{
		DEBUGMSG(MSGERR, "System Timer Get Error!\n");
	}
	DEBUGMSG(MSGINFO, " End      : [SYS TIME] %04d/%02d/%02d    %02d:%02d:%02d\n",
									tSysTime.tm_year+1900,
									tSysTime.tm_mon+1,
									tSysTime.tm_mday,
									tSysTime.tm_hour,
									tSysTime.tm_min,
									tSysTime.tm_sec);
}

INT32 APACHE_TEST_SYSTIME_CUTMode(void)
{
    INT32 select;
    char buf[16];


    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about Service - SYSTEM TIMER       	   \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " System Time Service                                        \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> Change System Timer                                    \n");
        DEBUGMSG(MSGINFO, " <2> Event  System Timer                                    \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
				APACHE_TEST_SYSTIME_Set_SysTimeDate();
            break;

            case 2:
				APACHE_TEST_SYSTIME_PeriodicTimeEvent();
            break;
			
            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto SYSTIME_Exit;
        }
    }

SYSTIME_Exit:

    return NC_SUCCESS;
}

#endif

/* End Of File */
