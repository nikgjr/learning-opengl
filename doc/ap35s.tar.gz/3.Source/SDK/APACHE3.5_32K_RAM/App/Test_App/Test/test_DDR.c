/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_DDR.c
*
*  @brief   :
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.01.14
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"
#if 0 // del_lib_func
#include <math.h>
#endif

#if ENABLE_IP_DDR

// defalut Winbond - W9464M2JG_6A
//#define __LPDDR_IS43LR32400E_6BL__




/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/
#define WRITE8(data, addr)              *((volatile unsigned char *)(addr))=data
#define READ8( addr )                   *((volatile unsigned char *)(addr))

#define WRITE16(data, addr)             *((volatile unsigned short *)(addr))=data
#define READ16( addr )                  *((volatile unsigned short *)(addr))

#define WRITE32(data, addr)             *((volatile unsigned int *)(addr))=data
#define READ32( addr )                  *((volatile unsigned int *)(addr))

#define TEST_MEM_BASE                   APACHE_DRAM_BASE
#define TEST_OFFSET                     0
#define TEST_MEM_SIZE                   APACHE_DRAM_SIZE



#define DDR_PHY_INIT                    (1<<0)
#define DDR_PHY_CLR                     (1<<1)
#define DDR_PHY_COMPLETE                (1<<4)
#define DDR_PHY_SUCCESS                 (1<<5)
#define DDR_PHY_DIS_CAL                 (1<<7)

#define DDR_PHY_CONFIG                  (APACHE_DDRC_BASE+0x00)
#define DDR_ADDR_SIZE                   (APACHE_DDRC_BASE+0x04)
#define DDR_TIMING_0                    (APACHE_DDRC_BASE+0x08)
#define DDR_TIMING_1                    (APACHE_DDRC_BASE+0x0c)
#define DDR_TIMING_2                    (APACHE_DDRC_BASE+0x10)
#define DDR_LMR_EXT_STD                 (APACHE_DDRC_BASE+0x14)
#define DDR_LMR_EXT_3_2                 (APACHE_DDRC_BASE+0x18)
#define DDR_DELAY_CONFIG                (APACHE_DDRC_BASE+0x24)









/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/
static UINT32 gDebug_DDRDisFlag = 0;











/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
static UINT32 __ceil(FP32 F)
{    
    FP32   X;
    UINT32 Y;

    X = F;
    Y = (UINT32)F; 

    X = X - (FP32)Y;

    if(X != 0.0) X = 1.0;

    X += F;
    
    return (UINT32)X;
}

void __ddr_test_delay(UINT32 value)
{
    while(value--);
}

void __ddr_test_clear_buff(UINT32 *pData, UINT32 size)
{
    UINT32 i;
    
    for(i=0;i<size/4;i++)
    {
        *pData++ = 0x00000000;
    }
}

void __ddr_test_regdump(void)
{
    UINT32 RegOffset;
    
    DEBUGMSG(MSGINFO, "------------------------------------------------------------");
    for(RegOffset = 0x00; RegOffset<0xD0; RegOffset+=4)
    {
        if(!(RegOffset%0x10)) DEBUGMSG(MSGINFO, "\n     0x%08x:", APACHE_DDRC_BASE+RegOffset);
        if(!(RegOffset%4)) DEBUGMSG(MSGINFO, " ");
        DEBUGMSG(MSGINFO, "%08x", READ32(APACHE_DDRC_BASE+RegOffset));	
    }
    DEBUGMSG(MSGINFO, "\n");
}

INT32 APACHE_TEST_DDR_DataBus(UINT32 Addr)
{  
    INT32 i;
    UINT32 Pattern;
    UINT32 rData;

    DEBUGMSG(MSGINFO, "\r1");

    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n************* Memory Test Data Bus_1 ~~!! **************\n");

    // b'00000000 00000000 00000000 00000001
    // b'00000000 00000000 00000000 00000010
    // b'00000000 00000000 00000000 00000100
    // b'00000000 00000000 00000000 00001000
    // ~~
    // ~~
    // b'00010000 00000000 00000000 00000000
    // b'00100000 00000000 00000000 00000000
    // b'01000000 00000000 00000000 00000000
    // b'10000000 00000000 00000000 00000000
    for(Pattern=1; Pattern!=0; Pattern<<=1)
    {
        // Write the test pattern.
        WRITE32(Pattern, Addr);
        rData = READ32(Addr);

        if(gDebug_DDRDisFlag)
        {
            DEBUGMSG(MSGINFO, "0x%08x:", Addr);
            for(i=31; i>=0; --i)
                DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
            DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);	
        }

        if(rData != Pattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr, rData, Pattern);	
            //if(READ32(Addr) != Pattern)
                return -1;
        }
    }


    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n************* Memory Test Data Bus_2 ~~!! **************\n");
    // b'00000000 00000000 00000000 00000001
    // b'00000000 00000000 00000000 00000011
    // b'00000000 00000000 00000000 00000111
    // b'00000000 00000000 00000000 00001111
    // ~~
    // ~~
    // b'00011111 11111111 11111111 11111111
    // b'00111111 11111111 11111111 11111111
    // b'01111111 11111111 11111111 11111111
    for(Pattern=1; Pattern!=0xFFFFFFFF; Pattern|=(Pattern<<1))
    {
        WRITE32(Pattern, Addr);
        rData = READ32(Addr);

        if(gDebug_DDRDisFlag)
        {
            DEBUGMSG(MSGINFO, "0x%08x:", Addr);
            for(i=31; i>=0; --i)
                DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
            DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);	
        }

        if(rData != Pattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr, rData, Pattern);	
            //if(READ32(Addr) != Pattern)
                return -1;
        }
    }


    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n************* Memory Test Data Bus_3 ~~!! **************\n");
    // b'11111111 11111111 11111111 11111111
    // b'11111111 11111111 11111111 11111110
    // b'11111111 11111111 11111111 11111100
    // b'11111111 11111111 11111111 11111000
    // ~~
    // ~~
    // b'11110000 00000000 00000000 00000000
    // b'11100000 00000000 00000000 00000000
    // b'11000000 00000000 00000000 00000000
    for(Pattern=0xFFFFFFFF; Pattern!=0; Pattern<<=1)
    {
        WRITE32(Pattern, Addr);
        rData = READ32(Addr);

        if(gDebug_DDRDisFlag)
        {
            DEBUGMSG(MSGINFO, "0x%08x:", Addr);
            for(i=31; i>=0; --i)
                DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
            DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);	
        }

        if(rData != Pattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr, rData, Pattern);	
            //if(READ32(Addr) != Pattern)
                return -1;
        }
    }

    return 0;
}

INT32 APACHE_TEST_DDR_AddrBus(UINT32 Addr, UINT32 Bytes)
{  
    INT32 i;
    UINT32 Offset;
    UINT32 TestOffset;
    UINT32 AddrMask     = (Bytes-1)>>2;
    UINT32 Pattern      = 0xAAAAAAAA;
    UINT32 AntiPattern  = 0x55555555;
    UINT32 rData;


    DEBUGMSG(MSGINFO, "\r2");

    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n************* Memory Test Addr Bus wait ~~!! ***********\n");
    // Write the default pattern at each of the power-of-two offsets.
    // Offset
    // 0x00000001 -> 0x00000002 -> 0x00000004 -> 0x00000008
    // 0x00000010 -> 0x00000020 -> 0x00000040 -> 0x00000080
    // 0x00000100 -> 0x00000200 -> 0x00000400 -> 0x00000800
    // 0x00001000 -> 0x00002000 -> 0x00004000 -> 0x00008000
    // 0x00010000 -> 0x00020000 -> 0x00040000 -> 0x00080000
    // 0x00100000 -> 0x00200000 -> 0x00400000 -> 0x00800000
    // 0x01000000 -> End

    // Memory Address
    // 0x00000004 -> 0x00000008 -> 0x00000010 -> 0x00000020
    // 0x00000040 -> 0x00000080 -> 0x00000100 -> 0x00000200
    // 0x00000400 -> 0x00000800 -> 0x00001000 -> 0x00002000
    // 0x00004000 -> 0x00008000 -> 0x00010000 -> 0x00020000
    // 0x00040000 -> 0x00080000 -> 0x00100000 -> 0x00200000
    // 0x00400000 -> 0x00800000 -> 0x01000000 -> 0x02000000
    // 0x04000000 -> End
    for(Offset=1; (Offset&AddrMask)!=0; Offset<<=1)
    {
        WRITE32(Pattern, Addr+(Offset*4));		
        if(gDebug_DDRDisFlag)
            DEBUGMSG(MSGINFO, "\rPattern Write - [ 0x%08x : 0x%08x ]", Addr+(Offset*4), Pattern);
    }

    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n************* Memory Test Addr Bus_1 ~~!! **************\n");	
    // Check for address bits stuck high.
    WRITE32(AntiPattern, Addr);	

    if(gDebug_DDRDisFlag)
    {
        rData = READ32(Addr);
        DEBUGMSG(MSGINFO, "0x%08x:", Addr);
        for(i=31; i>=0; --i)
            DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
        DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);	
    }

    for(Offset=1; (Offset&AddrMask)!=0; Offset<<=1)
    {
        rData = READ32(Addr+(Offset*4));

        if(gDebug_DDRDisFlag)    
        {
            DEBUGMSG(MSGINFO, "0x%08x:", Addr+(Offset*4));
            for(i=31; i>=0; --i)
                DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
            DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);	
        }

        if(rData != Pattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+(Offset*4), rData, Pattern);	
            //if(READ32(Addr+(Offset*4)) != Pattern)
                return -1;
        }
    }


    // Check for address bits stuck low or shorted.
    WRITE32(Pattern, Addr);

    for(TestOffset=1; (TestOffset&AddrMask)!=0; TestOffset<<=1)
    {
        if(gDebug_DDRDisFlag)
            DEBUGMSG(MSGINFO, "\n************* Memory Test Addr Bus_2 ~~!! **************\n");

        WRITE32(AntiPattern, Addr+(TestOffset*4));

        rData = READ32(Addr);

        if(gDebug_DDRDisFlag)
        {
            DEBUGMSG(MSGINFO, "0x%08x:", Addr);
            for(i=31; i>=0; --i)
                DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
            DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);	
        }

        if(rData != Pattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr, rData, Pattern);	
            //if(READ32(Addr) != Pattern)
                return -1;
        }

        for(Offset=1; (Offset&AddrMask)!=0; Offset<<=1)
        {
            rData = READ32(Addr+(Offset*4));

            if(gDebug_DDRDisFlag)
            {
                DEBUGMSG(MSGINFO, "0x%08x:", Addr+(Offset*4));
                for(i=31; i>=0; --i)
                    DEBUGMSG(MSGINFO, "%d", (rData>>i)&1);
                DEBUGMSG(MSGINFO, " : 0x%08x\n", rData);
            }

            if((rData!=Pattern)&&(Offset!=TestOffset))
            {
                DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+(Offset*4), rData, Pattern);	
                //if(READ32(Addr+(Offset*4))!=Pattern)
                    return -1;
            }
        } 
        WRITE32(Pattern, Addr+(TestOffset*4));
    } 


    return 0;
}

INT32 APACHE_TEST_DDR_08bit(UINT32 Addr, UINT32 Bytes)
{
    UINT32 Offset;
    UINT32 OffsetLimit = Bytes; 
    UINT32 Pattern;
    UINT32 Antipattern;
    UINT32 rData;

    DEBUGMSG(MSGINFO, "\r3");

    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n\n************* Memory Test (08bit)~~!! *********************************************\n");

    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset++)
    {
        WRITE8((Pattern&0xFF), Addr+Offset); 

        if(gDebug_DDRDisFlag)
        {
            if(!(Offset%0x1000) )
                DEBUGMSG(MSGINFO, "\rData Write - [ 0x%08x : 0x%02x ]", Addr+Offset, (Pattern&0xFF));
        }
    }


    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n************* Memory Test (08bit) 01 ~~!! *****************************************");

    // Check each location and invert it for the second pass.
    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset++)
    {
        rData = READ8(Addr+Offset);

        if(gDebug_DDRDisFlag)
        {
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            if(!(Offset%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%02x", rData);	
        }

        if((rData&0xFF) != (Pattern&0xFF))
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+Offset, rData, (Pattern&0xFF));	
            //if(READ8(Addr+Offset) != (UINT8)(Pattern&0xFF))
                return -1;
        }

        Antipattern = ~Pattern;
        WRITE8((Antipattern&0xFF), Addr+Offset);		
    } 

    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n************* Memory Test (08bit) 02 ~~!! *****************************************");

    // Check each location for the inverted pattern and zero it.
    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset++)
    {
        Antipattern = ~Pattern;
        rData = READ8(Addr+Offset);

        if(gDebug_DDRDisFlag)
        {
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            if(!(Offset%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%02x", rData);	
        }

        if((rData&0xFF) != (Antipattern&0xFF))
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+Offset, rData, (Antipattern&0xFF));	
            //if(READ8(Addr+Offset) != (UINT8)(Antipattern&0xFF))
                return -1;
        }
    } 

    return 0;
}

INT32 APACHE_TEST_DDR_16bit(UINT32 Addr, UINT32 Bytes)
{
    UINT32 Offset;
    UINT32 OffsetLimit = Bytes; 
    UINT32 Pattern;
    UINT32 Antipattern;
    UINT32 rData;

    DEBUGMSG(MSGINFO, "\r4");

    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n\n************* Memory Test (16bit)~~!! *********************************************\n");

    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset+=2)
    {
        WRITE16((Pattern&0xFFFF), Addr+Offset); 

        if(gDebug_DDRDisFlag)
        {
            if(!(Offset%0x1000) )
                DEBUGMSG(MSGINFO, "\rData Write - [ 0x%08x : 0x%04x ]", Addr+Offset, (Pattern&0xFFFF));
        }
    }


    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n************* Memory Test (16bit) 01 ~~!! *****************************************");

    // Check each location and invert it for the second pass.
    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset+=2)
    {
        rData = READ16(Addr+Offset);

        if(gDebug_DDRDisFlag)
        {
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            if(!(Offset%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%04x", rData);			
        }

        if((rData&0xFFFF) != (Pattern&0xFFFF))
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+Offset, rData, (Pattern&0xFFFF));	
            //if(READ16(Addr+Offset) != (UINT16)(Pattern&0xFFFF))
                return -1;
        }

        Antipattern = ~Pattern;
        WRITE16((Antipattern&0xFFFF), Addr+Offset);		
    } 


    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n************* Memory Test (16bit) 02 ~~!! *****************************************");

    // Check each location for the inverted pattern and zero it.
    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset+=2)
    {
        Antipattern = ~Pattern;
        rData = READ16(Addr+Offset);

        if(gDebug_DDRDisFlag)
        {
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            if(!(Offset%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%04x", rData);	
        }

        if((rData&0xFFFF) != (Antipattern&0xFFFF))
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+(Offset*2), rData, (Antipattern&0xFFFF));	
            //if(READ16(Addr+Offset) != (UINT16)(Antipattern&0xFFFF))
                return -1;
        }
    } 

    return 0;
}

INT32 APACHE_TEST_DDR_32bit(UINT32 Addr, UINT32 Bytes)
{
    UINT32 Offset;
    UINT32 OffsetLimit = Bytes; 
    UINT32 Pattern;
    UINT32 Antipattern;
    UINT32 rData;

    DEBUGMSG(MSGINFO, "\r5");

    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n\n************* Memory Test (32bit)~~!! *********************************************\n");

    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset+=4)
    {
        WRITE32(Pattern, Addr+Offset); 

        if(gDebug_DDRDisFlag)
        {
            if(!(Offset%0x1000) )
            DEBUGMSG(MSGINFO, "\rData Write - [ 0x%08x : 0x%04x ]", Addr+Offset, Pattern);
        }
    }


    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n************* Memory Test (32bit) 01 ~~!! *****************************************");

    // Check each location and invert it for the second pass.
    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset+=4)
    {
        rData = READ32(Addr+Offset);

        if(gDebug_DDRDisFlag)
        {
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            if(!(Offset%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%08x", rData);	
        }

        if(rData != Pattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+Offset, rData, Pattern);	
            //if(READ32(Addr+Offset) != Pattern)
                return -1;
        }

        Antipattern = ~Pattern;
        WRITE32(Antipattern, Addr+Offset);		
    } 

    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n************* Memory Test (32bit) 02 ~~!! *****************************************");

    // Check each location for the inverted pattern and zero it.
    for(Pattern=0, Offset=0; Offset<OffsetLimit; Pattern++, Offset+=4)
    {
        Antipattern = ~Pattern;
        rData = READ32(Addr+Offset);

        if(gDebug_DDRDisFlag)
        {
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            if(!(Offset%4)) DEBUGMSG(MSGINFO, " ");
            DEBUGMSG(MSGINFO, "%04x", rData);	
        }

        if(rData != Antipattern)
        {
            DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", Addr+Offset, rData, Antipattern);	
            //if(READ32(Addr+Offset) != Antipattern)
                return -1;
        }
    } 

    return 0;
}

#define PATTERN_MAX	64
INT32 APACHE_TEST_DDR_MemCopy(UINT32 StartAddr, UINT32 EndAddr)
{
    UINT32 i, j;
    UINT32 *pAddr;
    UINT32 Addr;
    UINT32 Size;
    UINT32 Pattern[PATTERN_MAX] ={  0xF2000000, 0xFFFF0001, 0xFFFF0010, 0xFFFF0100, 0xFFFF1000, 0xFFFF1110, 0x0001FFFF, 0x0010FFFF,
                                    0x11111111, 0x22222222, 0x33333333, 0x44444444, 0x55555555, 0x66666666, 0x77777777, 0x88888888,
                                    0x99999999, 0xAAAAAAAA, 0xBBBBBBBB, 0xCCCCCCCC, 0xDDDDDDDD, 0xEEEEEEEE, 0xFFFFFFFF, 0xFFFF0000,
                                    0x0000FFFF, 0xF0F0F0F0, 0x0F0F0F0F, 0xFF00FF00, 0x00FF00FF, 0x3C3C3C3C, 0xA5A5A5A5, 0x5A5A5A5A,
                                    0x80000000, 0xF8000000, 0xFF800000, 0xFFF80000, 0xFFFF8000, 0xFFFFF800, 0xFFFFFF80, 0xFFFFFFF8,
                                    0x40000000, 0xF4000000, 0xFF400000, 0xFFF40000, 0xFFFF4000, 0xFFFFF400, 0xFFFFFF40, 0xFFFFFFF4,
                                    0x20000000, 0xFFFF0000, 0xFF200000, 0xFFF20000, 0xFFFF2000, 0xFFFFF200, 0xFFFFFF20, 0xFFFFFFF2,
                                    0x10000000, 0xF1000000, 0xFF100000, 0xFFF10000, 0xFFFF1000, 0xFFFFF100, 0xFFFFFF10, 0xFFFFFFF1};

    DEBUGMSG(MSGINFO, "\r6");

    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n\n************* Memory_Test_MemCpy Wait~~!! *****************************************\n");

    Addr  = StartAddr;
    Size  = sizeof(Pattern);
    while((Addr+Size) <= EndAddr)
    {
        memcpy((void*)Addr, Pattern, Size);
        Addr+=Size;

        if(gDebug_DDRDisFlag)
        {
            if(!(Addr%0x1000) )
                DEBUGMSG(MSGINFO, "\rPattern Write - [ 0x%08x ]", Addr);
        }
    };


    if(gDebug_DDRDisFlag) 
        DEBUGMSG(MSGINFO, "\n************* Memory_Test_MemCpy 1~~!! ********************************************\n");	

    Addr  = StartAddr;
    pAddr = (UINT32*)StartAddr;
    while((Addr+Size) <= EndAddr)
    {

        if(gDebug_DDRDisFlag) 
        {
            if(!(Addr%0x1000) )
                DEBUGMSG(MSGINFO, "\rPattern Check - [ 0x%08x ]", pAddr);
        }

        for(i=0; i<PATTERN_MAX; i++)
        {
            if(*pAddr != Pattern[i])
            {
                DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", pAddr, *pAddr, Pattern[i]);	
                //if(*pAddr != Pattern[i])
                    return -1;
            }
            pAddr++;
        }
        Addr=(UINT32)pAddr;
    };

    if(gDebug_DDRDisFlag)
    {
        DEBUGMSG(MSGINFO, "\n***********************************************************************************");	

        pAddr-=Size;
        for(i=0; i<PATTERN_MAX; i++)
        {
            if(!(((UINT32)pAddr)%0x20)) 
                DEBUGMSG(MSGINFO, "\n0x%08x:", pAddr);
            DEBUGMSG(MSGINFO, " %08x", *pAddr++);
        }	
    }

    if(gDebug_DDRDisFlag)
        DEBUGMSG(MSGINFO, "\n\n************* Memory_Test_MemCpy 2~~!! *****************\n");	

    Size = (EndAddr-StartAddr)/16;
    for(i=0; i<PATTERN_MAX; i++)
    {
        pAddr = (UINT32*)StartAddr;
        for(j=0; j<Size ; j+=4)
            *pAddr++ = Pattern[i];

        if(gDebug_DDRDisFlag)
            DEBUGMSG(MSGINFO, " [%02d: 0x%08x ~ 0x%08x : 0x%08x]\n", i, StartAddr, pAddr, Pattern[i]);

        while((UINT32)(pAddr+(Size/4)) <= EndAddr)
        {
            if(gDebug_DDRDisFlag)
                DEBUGMSG(MSGINFO, " [%02d: 0x%08x ~ 0x%08x : 0x%08x]\n", i, pAddr, pAddr+(Size/4), Pattern[i]);

            memcpy(pAddr, (void*)StartAddr, Size);
            pAddr+=(Size/4);
        };

        pAddr = (UINT32*)StartAddr;
        while((UINT32)pAddr < EndAddr)
        {
            if(gDebug_DDRDisFlag)
            {
                if(!(((UINT32)pAddr)%0x1000) )
                    DEBUGMSG(MSGINFO, "\rPattern Check - [ 0x%08x ]", pAddr);
            }

            if(*pAddr != Pattern[i])
            {
                DEBUGMSG(MSGINFO, "\n   0x%08x: %08x vs %08x\n", pAddr, *pAddr, Pattern[i]);	
                //if(*pAddr != Pattern[i])
                    return -1;
            }
            pAddr++;
        };
        if(gDebug_DDRDisFlag)
            DEBUGMSG(MSGINFO, "\n");
    }

    return 0;
}

INT32 APACHE_TEST_DDR_Apache35_ErrorCase_01(UINT32 Addr, UINT32 OffsetLimit)
{
    UINT32 Offset;
    UINT32 rData;

    DEBUGMSG(MSGINFO, "\rc");

    if(gDebug_DDRDisFlag) 
        DEBUGMSG(MSGINFO, "\n\n************* Memory Test (Error Case 1)~~!! ***********\n");

    for(Offset=0; Offset<OffsetLimit; Offset+=8)
    {
        WRITE32(0x77777777, Addr+Offset); 
        WRITE32(0x88888888, Addr+Offset+4); 
    }

    if(gDebug_DDRDisFlag)
    {
        for(Offset=0; Offset<OffsetLimit; Offset+=4)
        {
            rData = READ32(Addr+Offset);
            if(!(Offset%0x20)) DEBUGMSG(MSGINFO, "\n0x%08x:", Addr+Offset);
            DEBUGMSG(MSGINFO, " %04x", rData);	
        } 
        DEBUGMSG(MSGINFO, "\n");	
    }

    for(Offset=0; Offset<OffsetLimit; Offset+=8)
    {
        rData = READ32(Addr+Offset);

        if(rData != 0x77777777)
        {
            DEBUGMSG(MSGINFO, "   0x%08x: %08x vs %08x\n", Addr+Offset, rData, 0x77777777);	
            //if(READ32(Addr+Offset) != 0x77777777)
                return -1;
        }
    } 

    return 0;
}

#define TEST_PATTERN_MAX    4
INT32 APACHE_TEST_DDR_Apache35_ErrorCase_02(UINT32 Addr, UINT32 Bytes)
{
    UINT32 i;
    UINT32 Offset;
    UINT32 rData;
    UINT32 Pattern[TEST_PATTERN_MAX] = { 0x00000000, 0xFFFEFDFC, 0x03020100, 0x00000000 };

    DEBUGMSG(MSGINFO, "\rd");
    
    //__ddr_test_clear_buff((UINT32*) Addr, Bytes);

    for(Offset = 0x00F8; Offset<(Bytes-0x0100); Offset += 0x0100)
    {
        for(i=0; i<TEST_PATTERN_MAX; i++)
        {
            REGRW32(Addr, Offset+(i*4)) = Pattern[i];
        }

        for(i=0; i<TEST_PATTERN_MAX; i++)
        {
            rData = REGRW32(Addr, Offset+(i*4));
            if(rData != Pattern[i])
            {
                DEBUGMSG(MSGINFO, "   0x%08x: %08x vs %08x\n", Addr+Offset+(i*4), rData, Pattern[i]);
                //if(REGRW32(Addr, Offset+(i*4)) != Pattern[i])
                    return -1; 
            }
        }
    }

    return 0;
}


void APACHE_TEST_DDR_Config(FP32 pClkMHz, BOOL OnOff)
{	
    //------------------------------------------------------------
    // [Offset:0x04] DDR Address Size Configuration
    UINT32 reg_DDRC_ADDR_SIZE;
        UINT32 ColumnAddressSize;
        UINT32 RowAddressSize;
        UINT32 BankAddressSize;
        UINT32 AddressAcccess;
        UINT32 isLPDDR;


    //------------------------------------------------------------
    // [Offset:0x08] DDR Timing Configuration 0
    UINT32 reg_DDRC_TIMING0;
        FP32 tRAS;
        FP32 tRFC;
        FP32 tRC;
        UINT32 tRASCycle;
        UINT32 tRFCCycle;
        UINT32 tRCCycle;


    //------------------------------------------------------------- 
    // [Offset:0x0C] DDR Timing Configuration 1
    UINT32 reg_DDRC_TIMING1;
        FP32 tRCD;
        FP32 tRP;
        FP32 tRRD;
        FP32 tWR;
        UINT32 tRCDCycle;
        UINT32 tRPCycle;
        UINT32 tRRDCycle;
        UINT32 tWRCycle;
        UINT32 tWTRCycle;
        UINT32 tMRDCycle;
        UINT32 tDQSSCycle;


    //------------------------------------------------------------- 
    // [Offset:0x10] DDR Timing Configuration 2
    UINT32 reg_DDRC_TIMING2;
        FP32 pRefrWindowHighPriority = 0.950;
        FP32 tREFI;
        FP32 tInitTime;
        UINT32 tREFICycle;
        UINT32 tInitTimeCycle;


    //------------------------------------------------------------
    // [Offset:0x14] DDR Standard and Extended Load Mode Registers
    UINT32 reg_DDRC_LMR_EXT_STD;
        UINT32 MRS_ModeRegisterSet;		
            UINT32 CAS;
            UINT32 BurstType;
            UINT32 BurstLength;
        UINT32 EMRS_ExtendedModeRegisterSet;
            UINT32 DriverStrength;
            UINT32 SelfRefreshCoverage;		



    //------------------------------------------------------------
    // [Offset:0x24] DDR Delay Register
    UINT32 reg_DDRC_DELAY_CONF;
        UINT32 ClkDelay;





    //===============================================================================================================
    /*
    * [Offset:0x04] DDR Address Size Configuration
    * 	[1:0]   : Column Size           -> 8+X 	[0:2^8,  1:2^9  ...]
    * 	[3:2]   : Row Size              -> 11+X	[0:2^11, 2:2^12 ...]
    *	[4]     : Bank Size             -> 2+X	[0:2^2,  2:2^3  ...]
    *	[5]     : Address Access        -> [0:Bank-Row-Column, 1:Row-Bank-Column]
    *	[7]     : Select DDR2 or LPDDR  -> [0:DDR2, 1:LPDDR]
    */
    ColumnAddressSize = 0; 	// 2^8
    RowAddressSize 	  = 0; 	// 2^11
    BankAddressSize   = 0; 	// 2^2
    AddressAcccess 	  = 1;	// Row-Bank-Column
    isLPDDR  	   	  = 1;	// Select LPDDR

    reg_DDRC_ADDR_SIZE = (isLPDDR<<7)|(AddressAcccess<<5)|(BankAddressSize<<4)|(RowAddressSize<<2)|ColumnAddressSize;	





    /*
    * [Offset:0x08] DDR Timing Configuration 0
    *	[4:0]	: Activate to Precharge cycle                       [tRAS * Frequency / 1000]
    *	[14:8]	: Refresh to Activate or Refresh interval cycle     [tRFC * Frequency / 1000]
    *	[20:16]	: Activate to Activate cycle                        [tRC  * Frequency / 1000]
    */
    tRAS = 42.0;  
    tRFC = 72.0; 
    tRC  = 60.0;  

#ifdef __LPDDR_IS43LR32400E_6BL__
    tRFC = 70.0; 
#endif

    tRASCycle = __ceil((tRAS * pClkMHz)/1000.0);
    tRFCCycle = __ceil((tRFC * pClkMHz)/1000.0);
    tRCCycle  = __ceil(( tRC * pClkMHz)/1000.0);
     
    reg_DDRC_TIMING0 = (tRCCycle<<16)|(tRFCCycle<<8)|tRASCycle;

#if 0 // del_lib_func
    if(    ( (UINT32)(ceil((tRAS * pClkMHz)/1000.0)) != (UINT32)(__ceil((tRAS * pClkMHz)/1000.0)) )
        || ( (UINT32)(ceil((tRFC * pClkMHz)/1000.0)) != (UINT32)(__ceil((tRFC * pClkMHz)/1000.0)) )
        || ( (UINT32)(ceil(( tRC * pClkMHz)/1000.0)) != (UINT32)(__ceil(( tRC * pClkMHz)/1000.0)) ) )
    {
        DEBUGMSG(MSGINFO, "FP32(%f), ceil(%g), _ceil(%d)\n", ((tRAS * pClkMHz)/1000.0), ceil((tRAS * pClkMHz)/1000.0), __ceil((tRAS * pClkMHz)/1000.0) );
        DEBUGMSG(MSGINFO, "FP32(%f), ceil(%g), _ceil(%d)\n", ((tRFC * pClkMHz)/1000.0), ceil((tRFC * pClkMHz)/1000.0), __ceil((tRFC * pClkMHz)/1000.0) );	
        DEBUGMSG(MSGINFO, "FP32(%f), ceil(%g), _ceil(%d)\n", (( tRC * pClkMHz)/1000.0), ceil(( tRC * pClkMHz)/1000.0), __ceil(( tRC * pClkMHz)/1000.0) );  
    }
#endif
    




    /*
    * [Offset:0x0C] DDR Timing Configuration 1
    *	[3:0]	: Activate to Read or WRITE delay cycle                 [tRCD * Frequency / 1000]
    *	[7:4]	: Precharge period cycle                                [tRP  * Frequency / 1000]
    *	[11:8]	: Activate to Activate delay different bank cycle       [tRRD * Frequency / 1000]
    *	[15:12]	: Write Recovery time cycle                             [tWR  * Frequency / 1000]
    *	[18:16]	: Interval Write to Read delay cycle                    [tWTR * Frequency / 1000]
    *	[21:20]	: LOAD MODE clcye time
    *	[23:22]	: Write command to first DQS latching transition cycle(only LPDDR)
    */
    tRCD = 18.0;
    tRP  = 18.0;
    tRRD = 12.0;
    tWR  = 15.0;

#ifdef __LPDDR_IS43LR32400E_6BL__
    tWR = 12.0; 
#endif

    tRCDCycle  = __ceil((tRCD * pClkMHz)/1000.0);
    tRPCycle   = __ceil(( tRP * pClkMHz)/1000.0);
    tRRDCycle  = __ceil((tRRD * pClkMHz)/1000.0);
    tWRCycle   = __ceil(( tWR * pClkMHz)/1000.0);
    tWTRCycle  = 2;
    tMRDCycle  = 2;
    tDQSSCycle = 1;

#ifdef __LPDDR_IS43LR32400E_6BL__
    tWTRCycle  = 1;
#endif

    reg_DDRC_TIMING1 = (tDQSSCycle<<22)|(tMRDCycle<<20)|(tWTRCycle<<16)|(tWRCycle<<12)|(tRRDCycle<<8)|(tRPCycle<<4)|(tRCDCycle);

#if 0 // del_lib_func
    if(    ( (UINT32)(ceil((tRCD * pClkMHz)/1000.0)) != (UINT32)(__ceil((tRCD * pClkMHz)/1000.0)) )
        || ( (UINT32)(ceil(( tRP * pClkMHz)/1000.0)) != (UINT32)(__ceil(( tRP * pClkMHz)/1000.0)) )
        || ( (UINT32)(ceil((tRRD * pClkMHz)/1000.0)) != (UINT32)(__ceil((tRRD * pClkMHz)/1000.0)) ) 
        || ( (UINT32)(ceil(( tWR * pClkMHz)/1000.0)) != (UINT32)(__ceil(( tWR * pClkMHz)/1000.0)) ) )
    {
        DEBUGMSG(MSGINFO, "FP32(%f), ceil(%g), _ceil(%d)\n", ((tRCD * pClkMHz)/1000.0), ceil((tRCD * pClkMHz)/1000.0), __ceil((tRCD * pClkMHz)/1000.0) );
        DEBUGMSG(MSGINFO, "FP32(%f), ceil(%g), _ceil(%d)\n", (( tRP * pClkMHz)/1000.0), ceil(( tRP * pClkMHz)/1000.0), __ceil(( tRP * pClkMHz)/1000.0) );	
        DEBUGMSG(MSGINFO, "FP32(%f), ceil(%g), _ceil(%d)\n", ((tRRD * pClkMHz)/1000.0), ceil((tRRD * pClkMHz)/1000.0), __ceil((tRRD * pClkMHz)/1000.0) );
        DEBUGMSG(MSGINFO, "FP32(%f), ceil(%g), _ceil(%d)\n", (( tWR * pClkMHz)/1000.0), ceil(( tWR * pClkMHz)/1000.0), __ceil(( tWR * pClkMHz)/1000.0) );    
    }
#endif





    /*
    * [Offset:0x10] DDR Timing Configuration 12
    *	[15:0]	: Average periodic refresh          [tREFI * Frequency / 1000]
    *	[31:16]	: Stable power-up and clock cycle
    */
    tREFI       =  15625.0;       // usec->nsec - 15.6us : -40 < T < 85
    tInitTime   = 200000.0;       // 200us

    tREFICycle     = __ceil((pRefrWindowHighPriority * tREFI * pClkMHz)/1000.0);
    tInitTimeCycle = __ceil((tInitTime * pClkMHz)/1000.0);

    reg_DDRC_TIMING2 = (tInitTimeCycle<<16)|tREFICycle;

#if 0 // del_lib_func
    if(    ( (UINT32)(ceil((pRefrWindowHighPriority * tREFI * pClkMHz)/1000.0)) != (UINT32)(__ceil((pRefrWindowHighPriority * tREFI * pClkMHz)/1000.0)) )
        || ( (UINT32)(ceil((tInitTime * pClkMHz)/1000.0)) != (UINT32)(__ceil((tInitTime * pClkMHz)/1000.0)) ) )
    {
        DEBUGMSG(MSGINFO, "FP32(%f), ceil(%g), _ceil(%d)\n", ((pRefrWindowHighPriority * tREFI * pClkMHz)/1000.0), ceil((pRefrWindowHighPriority * tREFI * pClkMHz)/1000.0), __ceil((pRefrWindowHighPriority * tREFI * pClkMHz)/1000.0) );
        DEBUGMSG(MSGINFO, "FP32(%f), ceil(%g), _ceil(%d)\n", ((tInitTime * pClkMHz)/1000.0),ceil((tInitTime * pClkMHz)/1000.0),__ceil((tInitTime * pClkMHz)/1000.0) );   
    }
#endif





    /*
    * [Offset:0x14] DDR Standard and Extended Load Mode Registers
    * 	[14:0]  : Mode Register
    * 	[30:16] : Extended Mode Register
    */ 
    BurstLength = 0x2;                                              // 4
    BurstType 	= 0x0;                                              // sequential
    CAS       	= 0x2;                                              // 2
    MRS_ModeRegisterSet = (CAS<<4)|(BurstType<<3)|BurstLength;

    SelfRefreshCoverage = 0x0;                                      // partial array self refresh   = Four Banks
    DriverStrength   	= 0x2;                                      // 0=100%, 1=50%, 2=25%, 3=12%  = 1/4 Strength
    EMRS_ExtendedModeRegisterSet = (DriverStrength<<5)|SelfRefreshCoverage;

    reg_DDRC_LMR_EXT_STD = (EMRS_ExtendedModeRegisterSet<<16)|MRS_ModeRegisterSet;





    /*
    * [Offset:0x24] DDR Delay Registers
    * 	[4:0]  : Delay Register
    */ 
    ClkDelay = 2;
#ifdef __LPDDR_IS43LR32400E_6BL__  
    ClkDelay = 0;
#endif
    reg_DDRC_DELAY_CONF = (ClkDelay&0x1f);   




    DEBUGMSG(MSGINFO, " >> Main Freq         = %f\n", pClkMHz);
    DEBUGMSG(MSGINFO, "     DDR_PHY_CONFIG   = 0x%08x                \n", READ32(DDR_PHY_CONFIG));
    DEBUGMSG(MSGINFO, "     DDR_ADDR_SIZE    = 0x%08x, 0x%08x, 0x%08x\n", READ32(DDR_ADDR_SIZE),   reg_DDRC_ADDR_SIZE	,READ32(DDR_ADDR_SIZE)^reg_DDRC_ADDR_SIZE);
    DEBUGMSG(MSGINFO, "     DDR_TIMING_0     = 0x%08x, 0x%08x, 0x%08x\n", READ32(DDR_TIMING_0),    reg_DDRC_TIMING0		,READ32(DDR_TIMING_0)^reg_DDRC_TIMING0);
    DEBUGMSG(MSGINFO, "     DDR_TIMING_1     = 0x%08x, 0x%08x, 0x%08x\n", READ32(DDR_TIMING_1),    reg_DDRC_TIMING1     ,READ32(DDR_TIMING_1)^reg_DDRC_TIMING1);
    DEBUGMSG(MSGINFO, "     DDR_TIMING_2     = 0x%08x, 0x%08x, 0x%08x\n", READ32(DDR_TIMING_2),    reg_DDRC_TIMING2     ,READ32(DDR_TIMING_2)^reg_DDRC_TIMING2);
    DEBUGMSG(MSGINFO, "     DDR_LMR_EXT_STD  = 0x%08x, 0x%08x, 0x%08x\n", READ32(DDR_LMR_EXT_STD), reg_DDRC_LMR_EXT_STD	,READ32(DDR_LMR_EXT_STD)^reg_DDRC_LMR_EXT_STD);
    DEBUGMSG(MSGINFO, "     DDR_DELAY_CONFIG = 0x%08x, 0x%08x, 0x%08x\n", READ32(DDR_DELAY_CONFIG),reg_DDRC_DELAY_CONF	,READ32(DDR_DELAY_CONFIG)^reg_DDRC_DELAY_CONF);




    if(OnOff)
    {
        WRITE32(reg_DDRC_ADDR_SIZE,     DDR_ADDR_SIZE);
        WRITE32(reg_DDRC_TIMING0,       DDR_TIMING_0);
        WRITE32(reg_DDRC_TIMING1,       DDR_TIMING_1);
        WRITE32(reg_DDRC_TIMING2,       DDR_TIMING_2);
        WRITE32(reg_DDRC_LMR_EXT_STD,   DDR_LMR_EXT_STD);
        WRITE32(reg_DDRC_DELAY_CONF,    DDR_DELAY_CONFIG);
    }
    
}

UINT32 APACHE_TEST_DDR_Start(void)
{
    UINT32 Reg;
    INT32 loop=0x100000;


    //__ddr_test_regdump();

    // PHY init Start    
    WRITE32(DDR_PHY_CLR|DDR_PHY_INIT, DDR_PHY_CONFIG);

    while(loop--)
    {
        Reg = READ32(DDR_PHY_CONFIG);

        // PHY init complete
        if(Reg & DDR_PHY_COMPLETE)
            break;
    }



    // PHY init result [1:success, 0:fail]
    DEBUGMSG(MSGINFO, " >> PHY Init - %s, Result - %s\n", loop<=0 ? "TimeOut":"Done", (Reg & DDR_PHY_SUCCESS) ? "Success":"Fail");
    //__ddr_test_regdump();

    return ((Reg & DDR_PHY_SUCCESS) ? TRUE:FALSE);
}

void APACHE_TEST_DDR_Default_Init(void)
{
    FP32 ClkMHz = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_DDR, CMD_END);

    if( !(READ32(DDR_PHY_CONFIG) & (DDR_PHY_SUCCESS|DDR_PHY_COMPLETE)) )
    {
        APACHE_TEST_DDR_Config( ClkMHz/MHZ, TRUE);
        APACHE_TEST_DDR_Start();
    }
}

void APACHE_TEST_DDR_DisplayConfig(void)
{
    FP32 ClkMHz = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_DDR, CMD_END);

    APACHE_TEST_DDR_Config( ClkMHz/MHZ, FALSE);   
    __ddr_test_regdump();    
}

INT32 APACHE_TEST_DDR_ClockDelay(void)
{
    UINT32 Addr = (TEST_MEM_BASE + TEST_OFFSET);
    UINT32 Size = (TEST_MEM_SIZE - TEST_OFFSET);
    UINT32 ClkDelay; 
    UINT32 i = 1;


    // DDR Memory Base Addr (0x08000000 or 0x00000000) Check
    if( ncLib_SCU_Control(GCMD_SCU_GET_DATA, 0x001C, CMD_END) & 0x01 )
    {
        DEBUGMSG(MSGERR, " DDR Remap Status - Memory Base 0x00000000\n");
        // 0x00000000 ~ 0x00040000      // Code ER_RO/ER_RW Zone
        // 0x00040000 ~ 0x00100000      // ER_ZI and Buff Zone
        // 0x00100000 ~ 0x00800000      // Buff Zone    
        Addr = 0x00000000 + (4*MB);
        Size = TEST_MEM_SIZE - (4*MB);
    }
    
    for(ClkDelay=0x00; ClkDelay<=0x1F; ClkDelay++)
    {
        DEBUGMSG(MSGINFO, "------------------------<0x%02x>------------------------\n", ClkDelay);
        WRITE32((ClkDelay&0x1f), DDR_DELAY_CONFIG);
        __ddr_test_delay(2000);

        for(i=1; i<=1000; i++)
        {
            if( (APACHE_TEST_DDR_Apache35_ErrorCase_01(Addr, Size) != 0) 
            || (APACHE_TEST_DDR_Apache35_ErrorCase_02(Addr, Size) != 0)
            || (APACHE_TEST_DDR_DataBus(Addr) != 0)
            || (APACHE_TEST_DDR_AddrBus(Addr, Size) != 0)
            || (APACHE_TEST_DDR_08bit(Addr, Size) != 0)
            || (APACHE_TEST_DDR_16bit(Addr, Size) != 0)
            || (APACHE_TEST_DDR_32bit(Addr, Size) != 0)
            || (APACHE_TEST_DDR_MemCopy(Addr, Addr+Size) != 0)
            )
            {
                DEBUGMSG(MSGINFO, "\n >> Memory Test Fail - %dth\n", i);
                break;
            }
            else
            {
                DEBUGMSG(MSGINFO, "\n >> Memory Test OK - %dth\n", i);
            }
        }
    }


    return NC_SUCCESS;
}

INT32 APACHE_TEST_DDR_CUTMode(void)
{
    INT32 ret;
    INT32 select;
    char buf[16];
    UINT32 Addr = (TEST_MEM_BASE + TEST_OFFSET);
    UINT32 Size = (TEST_MEM_SIZE - TEST_OFFSET);
    UINT32 i = 1;


    // DDR Memory Base Addr (0x08000000 or 0x00000000) Check
    if( ncLib_SCU_Control(GCMD_SCU_GET_DATA, 0x001C, CMD_END) & 0x01 )
    {
        DEBUGMSG(MSGERR, " DDR Remap Status - Memory Base 0x00000000\n");
        // 0x00000000 ~ 0x00040000      // Code ER_RO/ER_RW Zone
        // 0x00040000 ~ 0x00100000      // ER_ZI and Buff Zone
        // 0x00100000 ~ 0x00800000      // Buff Zone    
        Addr = 0x00000000 + (4*MB);
        Size = TEST_MEM_SIZE - (4*MB);
    }

    APACHE_TEST_DDR_Default_Init();


    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - DDR                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Memory Test                                                \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> Data Bus                                               \n");
        DEBUGMSG(MSGINFO, " <2> Address Bus                                            \n");
        DEBUGMSG(MSGINFO, " <3> 8bit Address                                           \n");
        DEBUGMSG(MSGINFO, " <4> 16bit Address                                          \n");
        DEBUGMSG(MSGINFO, " <5> 32bit Address                                          \n");
        DEBUGMSG(MSGINFO, " <6> Memory Copy                                            \n");
        DEBUGMSG(MSGINFO, " <7> DDR Config Display                                     \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <a> (1)~(6) Full Test (long time)                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <b> DDR Clock Delay Test (long Time)                       \n");
        DEBUGMSG(MSGINFO, " <c> Apache3.5 DDR Error Case -1 (Winbond)                  \n"); 
        DEBUGMSG(MSGINFO, " <d> Apache3.5 DDR Error Case -2 (Winbond)                  \n"); 
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");
        
        switch(select)
        {
            case 1:
                ret = APACHE_TEST_DDR_DataBus(Addr);
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;

            case 2:
                ret = APACHE_TEST_DDR_AddrBus(Addr, Size);
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;

            case 3:
                ret = APACHE_TEST_DDR_08bit(Addr, (0x100*1));			        // 256B
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;

            case 4:
                ret = APACHE_TEST_DDR_16bit(Addr, (0x10000*2));			        // 128KB
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;

            case 5:
                ret = APACHE_TEST_DDR_32bit(Addr, (0x10000*4));			        // 256KB
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;	

            case 6:
                ret = APACHE_TEST_DDR_MemCopy(Addr, Addr+0x80000);		        // 512KB
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;
            
            case 7:
                APACHE_TEST_DDR_DisplayConfig();
            break;	 
            
            case 10:
            {
                for(i=1; i<=1000; i++)
                {                    
                    if( 
                       (APACHE_TEST_DDR_Apache35_ErrorCase_01(Addr, Size) != 0)
                    || (APACHE_TEST_DDR_Apache35_ErrorCase_02(Addr, Size) != 0)
                    || (APACHE_TEST_DDR_DataBus(Addr) != 0)
                    || (APACHE_TEST_DDR_AddrBus(Addr, Size) != 0)
                    || (APACHE_TEST_DDR_08bit(Addr, Size) != 0)
                    || (APACHE_TEST_DDR_16bit(Addr, Size) != 0)
                    || (APACHE_TEST_DDR_32bit(Addr, Size) != 0)
                    || (APACHE_TEST_DDR_MemCopy(Addr, Addr+Size) != 0)
                    )
                    {
                        DEBUGMSG(MSGINFO, "\n >> Memory Test Fail - %dth\n", i);
                        break;
                    }
                    else
                    {
                        DEBUGMSG(MSGINFO, "\n >> Memory Test OK - %dth\n", i);
                    }
                }
            }
            break;	

            case 11:
                APACHE_TEST_DDR_ClockDelay();
            break;	

            case 12:
                ret = APACHE_TEST_DDR_Apache35_ErrorCase_01(Addr, (0x10000*4));    // 256KB
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;	

            case 13:
                ret = APACHE_TEST_DDR_Apache35_ErrorCase_02(Addr, (0x10000*4));    // 256KB
                if(ret!=0)
                    DEBUGMSG(MSGINFO, "\n >> Memory Test Fail\n");
                else
                    DEBUGMSG(MSGINFO, "\n >> Memory Test OK\n");
            break;

            case 35:    // z
                gDebug_DDRDisFlag = (gDebug_DDRDisFlag > 0 )?0:1;
            break;	
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto DDR_Exit;
        }
    }

    DDR_Exit:

    return NC_SUCCESS;
}



#endif


/* End Of File */





