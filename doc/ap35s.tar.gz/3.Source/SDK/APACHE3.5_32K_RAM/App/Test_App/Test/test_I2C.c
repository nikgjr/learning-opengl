/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_I2C.c
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.07
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"


#if ENABLE_IP_I2C


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

void APACHE_TEST_I2C_CMOS_CH0(void);
void APACHE_TEST_I2C_HDMI_CH1(void);
void APACHE_TEST_I2C_CMOS_AR0132AT_Initialize(void);
void APACHE_TEST_I2C_CMOS_AR0140AT_Initialize(void);
void APACHE_TEST_I2C_CMOS_OV10640_Initialize(void);
void APACHE_TEST_I2C_HDMI_Initialize(void);
void APACHE_TEST_I2C_CMOS_LOOP(void);

void APACHE_TEST_I2C_SlaveModeScenarioLoopback_M0_S1(void);
void APACHE_TEST_I2C_SlaveModeScenarioLoopback_M1_S0(void);


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
#if 0
INT32 APACHE_TEST_I2C_CUTMode(void)
{
    INT32 select;
    char buf[16];

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - UART                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " 2-Channel I2C Controller                                   \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> CMOS AR0132AT (MT9M024) I2C_0 Test                     \n");
        DEBUGMSG(MSGINFO, " <2> HDMI Sil9034 I2C_1 Test                                \n");
        DEBUGMSG(MSGINFO, " <3> CMOS AR0132AT Initialize I2C_0                         \n");
        DEBUGMSG(MSGINFO, " <4> HDMI Sil9034 Initialize I2C_1                          \n");
        DEBUGMSG(MSGINFO, " <5> CMOS AR0132AT (MT9M024) I2C_0 VID Loop Test            \n");
        DEBUGMSG(MSGINFO, " <6> CMOS AR0140AT Initialize I2C_0                         \n");
        DEBUGMSG(MSGINFO, " <7> I2C_0 Master, I2C_1 Slave Mode Test                    \n");
        DEBUGMSG(MSGINFO, " <8> I2C_1 Master, I2C_0 Slave Mode Test                    \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ...                        \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_I2C_CMOS_CH0();
            break;

            case 2:
                APACHE_TEST_I2C_HDMI_CH1();
            break;

            case 3:
                APACHE_TEST_I2C_CMOS_AR0132AT_Initialize();
            break;

            case 4:
                APACHE_TEST_I2C_HDMI_Initialize();
            break;

            case 5:
                APACHE_TEST_I2C_CMOS_LOOP();
            break;

            case 6:
                APACHE_TEST_I2C_CMOS_AR0140AT_Initialize();
            break;

            case 7:
            {
                APACHE_TEST_I2C_SlaveModeScenarioLoopback_M0_S1();
            }
            break;

            case 8:
            {
                APACHE_TEST_I2C_SlaveModeScenarioLoopback_M1_S0();
            }
            break;

            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto I2C_Exit;
        }
    }

I2C_Exit:

    return NC_SUCCESS;
}


void APACHE_TEST_I2C_CMOS_CH0(void)
{
    UINT32 DevId = 0;
    tI2C_INFO i2c;
    INT32 ret = NC_SUCCESS;

    DEBUGMSG(MSGINFO, "====================================================\n");
    DEBUGMSG(MSGINFO, "Test CMOS AR0132AT I2C_%d Interface Test!!!\n", I2C_CH0);
    DEBUGMSG(MSGINFO, "====================================================\n");

    i2c.channel = I2C_CH0;
    i2c.mode = I2C_OP_MODE_MASTER;
    i2c.byteOrder = I2C_LITTLE_ENDIAN;
    i2c.type = I2C_ADDR_16_DATA_16;
    i2c.master.id = AR0132AT_DEVICEID;
    i2c.master.clock = I2C_BITRATE_60KBPS;

    //ncLib_I2C_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_I2C, CMD_END));

    ret |= ncLib_I2C_Control(GCMD_I2C_INIT_CH, i2c.channel, &i2c, CMD_END);
    ret |= ncLib_I2C_Control(GCMD_I2C_SET_BITRATE, i2c.channel, i2c.master.clock, CMD_END);

    APACHE_SYS_mDelay(100);

    DEBUGMSG(MSGINFO, "CMOS I2C_%d ReadID\n", i2c.channel);

    // Check Device ID

    ret |= ncLib_I2C_Read(i2c.channel, i2c.master.id, 0x3000, (UINT8 *)&DevId, 1, i2c.type);
    DEBUGMSG(MSGINFO, "CMOS DEV_ID: DEV_ID ID read 0x%04X\n", DevId);
}


void APACHE_TEST_I2C_HDMI_CH1(void)
{
    UINT32 DevId = 0;
    UINT8 Temp[4];
    UINT32 i;
    tI2C_INFO i2c;
    INT32 ret = NC_SUCCESS;

    DEBUGMSG(MSGINFO, "====================================================\n");
    DEBUGMSG(MSGINFO, "Test HDMI SIL9034 I2C_%d Interface Test!!!\n", I2C_CH1);
    DEBUGMSG(MSGINFO, "====================================================\n");

    i2c.channel = I2C_CH1;
    i2c.mode = I2C_OP_MODE_MASTER;   // master mode
    i2c.byteOrder = I2C_LITTLE_ENDIAN;
    i2c.type = I2C_ADDR_8_DATA_8;
    i2c.master.id = 0x72;   // hdmi
    i2c.master.clock = I2C_BITRATE_30KBPS;

    //ncLib_I2C_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_I2C, CMD_END));

    ret |= ncLib_I2C_Control(GCMD_I2C_INIT_CH, i2c.channel, &i2c, CMD_END);
    ret |= ncLib_I2C_Control(GCMD_I2C_SET_BITRATE, i2c.channel, i2c.master.clock, CMD_END);

    APACHE_SYS_mDelay(100);

#if 1 // byte & multi-byte read
    for(i = 0; i < 4; i < i++)
    {
        ret |= ncLib_I2C_Read(i2c.channel, i2c.master.id, 0x00+i, (UINT8 *)&DevId, 1, i2c.type);

        APACHE_SYS_mDelay(1);

        Temp[i] = DevId & 0xFF;
    }

    DEBUGMSG(MSGINFO, "HDMI VND_ID ID read 0x%04X\n", Temp[1]<<8|Temp[0]);
    DEBUGMSG(MSGINFO, "HDMI DEV_ID ID read 0x%04X\n", Temp[3]<<8|Temp[2]);

    ret |= ncLib_I2C_Read(i2c.channel, i2c.master.id, 0x00, Temp, 4, i2c.type);

    DEBUGMSG(MSGINFO, "HDMI VND_ID ID Burst read 0x%04X\n", Temp[1]<<8|Temp[0]);
    DEBUGMSG(MSGINFO, "HDMI DEV_ID ID Burst read 0x%04X\n", Temp[3]<<8|Temp[2]);

#endif

#if 1 // mulit-byte write & read
    ret |= ncLib_I2C_Write(i2c.channel, i2c.master.id, 0x00, 0xAA, 1, i2c.type);

    Temp[0] = 0x6e;
    Temp[1] = 0x02;
    Temp[2] = 0x4c;
    Temp[3] = 0x04;

    DEBUGMSG(MSGINFO, "Temp Data 0x%08X\n", (UINT32*)&Temp[0]);

    ret |= ncLib_I2C_Write(i2c.channel, i2c.master.id, 0x40, (UINT32)Temp, 4, i2c.type);

    for(i = 0; i < 4; i++)
    {
        Temp[i] = 0;
    }

    ret |= ncLib_I2C_Read(i2c.channel, i2c.master.id, 0x40, Temp, 4, i2c.type);

    DEBUGMSG(MSGINFO, "HDMI Register Burst read (0x026e) 0x%04X\n", Temp[1]<<8|Temp[0]);
    DEBUGMSG(MSGINFO, "HDMI Register Burst read (0x044c) 0x%04X\n", Temp[3]<<8|Temp[2]);
#endif

    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "\nError, I2C channel 1 HDMI Write & Read Test failure\n\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, "\nI2C channel 1 HDMI Write & Read Test success\n\n");
    }

    //ret |= ncLib_I2C_Control(GCMD_I2C_DEINIT_CH, i2c.channel, CMD_END);
    //ncLib_I2C_Close(i2c.channel);

    DEBUGMSG(MSGINFO, "=================================\n");
}


void APACHE_TEST_I2C_CMOS_AR0132AT_Initialize(void)
{
    UINT32 DevId = 0;
    tI2C_INFO i2c;
    INT32 ret = NC_SUCCESS;

    DEBUGMSG(MSGINFO, "====================================================\n");
    DEBUGMSG(MSGINFO, "Test CMOS AR0132AT I2C_%d Initialize!!!\n", I2C_CH0);
    DEBUGMSG(MSGINFO, "====================================================\n");

    i2c.channel = I2C_CH0;
    i2c.mode = I2C_OP_MODE_MASTER;
    i2c.byteOrder = I2C_LITTLE_ENDIAN;
    i2c.type = I2C_ADDR_16_DATA_16;
    i2c.master.id = AR0132AT_DEVICEID;
    i2c.master.clock = I2C_BITRATE_60KBPS;

    //ncLib_I2C_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_I2C, CMD_END));

    ret |= ncLib_I2C_Control(GCMD_I2C_INIT_CH, i2c.channel, &i2c, CMD_END);
    ret |= ncLib_I2C_Control(GCMD_I2C_SET_BITRATE, i2c.channel, i2c.master.clock, CMD_END);

    APACHE_SYS_mDelay(100);

    DEBUGMSG(MSGINFO, "CMOS I2C_%d ReadID\n", i2c.channel);

    // Check Device ID

    ret |= ncLib_I2C_Read(i2c.channel, i2c.master.id, 0x3000, (UINT8 *)&DevId, 1, i2c.type);
    DEBUGMSG(MSGINFO, "CMOS DEV_ID: DEV_ID ID read 0x%04X\n", DevId);

    ret = APACHE_SYS_InitAR0132AT();

    if(ret == NC_SUCCESS)
    {
        DEBUGMSG(MSGINFO, "APACHE_SYS_InitAR0132AT Success!!!\n\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, "APACHE_SYS_InitAR0132AT Failure!!!\n\n");
    }
}

void APACHE_TEST_I2C_CMOS_OV10640_Initialize(void)
{
    UINT32 DevId = 0;
    tI2C_INFO i2c;
    INT32 ret = NC_SUCCESS;
    DEBUGMSG(MSGINFO, "====================================================\n");
    DEBUGMSG(MSGINFO, "Test CMOS OV10640 I2C_%d Initialize!!!\n", I2C_CH0);
    DEBUGMSG(MSGINFO, "====================================================\n");
    i2c.channel = I2C_CH0;
    i2c.mode = I2C_OP_MODE_MASTER;
    i2c.byteOrder = I2C_LITTLE_ENDIAN;
    i2c.type = I2C_ADDR_16_DATA_8;
    i2c.master.id = 0x60;
    i2c.master.clock = I2C_BITRATE_60KBPS;
    ret |= ncLib_I2C_Control(GCMD_I2C_INIT_CH, i2c.channel, &i2c, CMD_END);
    ret |= ncLib_I2C_Control(GCMD_I2C_SET_BITRATE, i2c.channel, i2c.master.clock, CMD_END);
    APACHE_SYS_mDelay(100);
    DEBUGMSG(MSGINFO, "CMOS I2C_%d ReadID\n", i2c.channel);
    ret |= ncLib_I2C_Read(i2c.channel, i2c.master.id, 0x300A, (UINT8 *)&DevId, 1, i2c.type);
    DEBUGMSG(MSGINFO, "CMOS DEV_ID: DEV_ID ID read 0x%04X\n", DevId);
    ret = APACHE_SYS_InitOV10640();
}

#endif
void APACHE_TEST_I2C_CMOS_AR0140AT_Initialize(void)
{
    UINT32 DevId = 0;
    tI2C_INFO i2c;
    INT32 ret = NC_SUCCESS;

    DEBUGMSG(MSGINFO, "====================================================\n");
    DEBUGMSG(MSGINFO, "Test CMOS AR0140AT I2C_%d Initialize!!!\n", I2C_CH0);
    DEBUGMSG(MSGINFO, "====================================================\n");

    i2c.channel = I2C_CH0;
    i2c.mode = I2C_OP_MODE_MASTER;
    i2c.byteOrder = I2C_LITTLE_ENDIAN;
    i2c.type = I2C_ADDR_16_DATA_16;
    i2c.master.id = AR0140AT_DEVICEID;
    i2c.master.clock = I2C_BITRATE_60KBPS;
	
	i2c.master.srcClock = ncDrv_SCU_GetSystemClock(SCU_CLK_ID_I2C);
	ncDrv_I2C_MasterInitialize(&i2c);
	ncDrv_I2C_SetClock(i2c.channel, i2c.master.srcClock, &i2c);

	//	ret |= ncLib_I2C_Control(GCMD_I2C_INIT_CH, i2c.channel, &i2c, CMD_END);
	//	ret |= ncLib_I2C_Control(GCMD_I2C_SET_BITRATE, i2c.channel, i2c.master.clock, CMD_END);
	



    APACHE_SYS_mDelay(100);

    DEBUGMSG(MSGINFO, "CMOS I2C_%d\n", i2c.channel);

    // Check Device ID

    ret |= ncLib_I2C_Read(i2c.channel, i2c.master.id, 0x3000, (UINT8 *)&DevId, 1, i2c.type);
    DEBUGMSG(MSGINFO, "CMOS DEV_ID: DEV_ID ID read 0x%04X\n", DevId);

    ret = APACHE_SYS_InitAR0140AT();

    if(ret == NC_SUCCESS)
    {
        DEBUGMSG(MSGINFO, "APACHE_SYS_InitAR0140AT Success!!!\n\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, "APACHE_SYS_InitAR0140AT Failure!!!\n\n");
    }
}


void APACHE_TEST_I2C_HDMI_Initialize(void)
{
    UINT32 DevId = 0;
    UINT8 Temp[4];
    UINT32 i;
    tI2C_INFO i2c;
    INT32 ret = NC_SUCCESS;

    DEBUGMSG(MSGINFO, "====================================================\n");
    DEBUGMSG(MSGINFO, "Test HDMI SIL9034 I2C_%d Initialize!!!\n", I2C_CH1);
    DEBUGMSG(MSGINFO, "====================================================\n");

    i2c.channel = I2C_CH1;
    i2c.mode = I2C_OP_MODE_MASTER;   // master mode
    i2c.byteOrder = I2C_LITTLE_ENDIAN;
    i2c.type = I2C_ADDR_8_DATA_8;

    i2c.master.id = 0x72;   // hdmi
    i2c.master.clock = I2C_BITRATE_30KBPS;

    //ncLib_I2C_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_I2C, CMD_END));

   // ret |= ncLib_I2C_Control(GCMD_I2C_INIT_CH, i2c.channel, &i2c, CMD_END);
//    ret |= ncLib_I2C_Control(GCMD_I2C_SET_BITRATE, i2c.channel, i2c.master.clock, CMD_END);

	i2c.master.srcClock = ncDrv_SCU_GetSystemClock(SCU_CLK_ID_I2C);
	ncDrv_I2C_MasterInitialize(&i2c);
	ncDrv_I2C_SetClock(i2c.channel, i2c.master.srcClock, &i2c);


    APACHE_SYS_mDelay(100);

    for(i = 0; i < 4; i < i++)
    {
        ret |= ncLib_I2C_Read(i2c.channel, i2c.master.id, 0x00+i, (UINT8 *)&DevId, 1, i2c.type);

        APACHE_SYS_mDelay(1);

        Temp[i] = DevId & 0xFF;
    }

    DEBUGMSG(MSGINFO, "HDMI VND_ID ID read 0x%04X\n", Temp[1]<<8|Temp[0]);
    DEBUGMSG(MSGINFO, "HDMI DEV_ID ID read 0x%04X\n", Temp[3]<<8|Temp[2]);

    ret = APACHE_SYS_InitSIL9034();

    if(ret == NC_SUCCESS)
    {
        DEBUGMSG(MSGINFO, "\nAPACHE_SYS_InitSIL9034 Success!!!\n\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, "\nAPACHE_SYS_InitSIL9034 Failure!!!\n\n");
    }
}

#endif

#if 0
void APACHE_TEST_I2C_CMOS_LOOP(void)
{
    UINT32 DevId = 0;
    tI2C_INFO i2c;
    INT32 ret = NC_SUCCESS;

    DEBUGMSG(MSGINFO, "====================================================\n");
    DEBUGMSG(MSGINFO, "Test CMOS AR0132AT I2C_%d Interface Test!!!\n", I2C_CH0);
    DEBUGMSG(MSGINFO, "====================================================\n");

    i2c.channel = I2C_CH0;
    i2c.mode = I2C_OP_MODE_MASTER;
    i2c.byteOrder = I2C_LITTLE_ENDIAN;
    i2c.type = I2C_ADDR_16_DATA_16;
    i2c.master.id = AR0132AT_DEVICEID;
    i2c.master.clock = I2C_BITRATE_60KBPS;

    //ncLib_I2C_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_I2C, CMD_END));

    ret |= ncLib_I2C_Control(GCMD_I2C_INIT_CH, i2c.channel, &i2c, CMD_END);
    ret |= ncLib_I2C_Control(GCMD_I2C_SET_BITRATE, i2c.channel, i2c.master.clock, CMD_END);

    APACHE_SYS_mDelay(1000);

    DEBUGMSG(MSGINFO, "CMOS I2C_%d ReadID\n", i2c.channel);

    // Check Device ID

    while(1)
    {
        ret |= ncLib_I2C_Read(i2c.channel, i2c.master.id, 0x3000, (UINT8 *)&DevId, 1, i2c.type);
        DEBUGMSG(MSGINFO, "CMOS DEV_ID: DEV_ID ID read 0x%04X\n", DevId);
        APACHE_SYS_mDelay(100);
    }
}


void APACHE_TEST_I2C_SlaveModeScenarioLoopback_M0_S1(void)
{
    UINT8 tx_buffer1[128] = { 0x01, 0x02, 0x03, 0x04 };
    UINT8 rx_buffer1[128] = { 0x00 };
    tI2C_INFO i2c0;
    tI2C_INFO i2c1;
    UINT32 i, Temp;
    INT32 ret = NC_SUCCESS;

    DEBUGMSG(MSGINFO, "\n--------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "DB 844-I6 only version\n");
    DEBUGMSG(MSGINFO, "--------------------------------------------------------\n");

    DEBUGMSG(MSGINFO, "\nI2C channel 0 Master Mode Scenario Test\n");
    DEBUGMSG(MSGINFO, "channel_0 master, channel_1 slave\n");

    i2c0.channel = I2C_CH0;
    i2c0.mode = I2C_OP_MODE_MASTER;
    i2c0.byteOrder = I2C_LITTLE_ENDIAN;
    i2c0.type = I2C_ADDR_8_DATA_8;
    i2c0.master.id = 0xC0;          // device id ???
    i2c0.master.clock = I2C_BITRATE_30KBPS;
    i2c0.master.txBuf = (UINT8 *)tx_buffer1;
    i2c0.slave.rxBuf = (UINT8 *)rx_buffer1;
    i2c0.master.txIdx = 0;
    i2c0.slave.rxIdx = 0;

    ret |= ncLib_I2C_Control(GCMD_I2C_INIT_CH, i2c0.channel, &i2c0, CMD_END);
    ret |= ncLib_I2C_Control(GCMD_I2C_SET_BITRATE, i2c0.channel, i2c0.master.clock, CMD_END);

    i2c1.channel = I2C_CH1;
    i2c1.mode = I2C_OP_MODE_SLAVE;
    i2c1.byteOrder = I2C_LITTLE_ENDIAN;
    i2c1.type = I2C_ADDR_8_DATA_8;
    i2c1.slave.id = 0xC0;           // device id ???
    i2c1.master.txBuf = (UINT8 *)tx_buffer1;
    i2c1.slave.rxBuf = (UINT8 *)rx_buffer1;
    i2c1.master.txIdx = 0;
    i2c1.slave.rxIdx = 0;

    ret |= ncLib_I2C_Control(GCMD_I2C_INIT_CH, i2c1.channel, &i2c1, CMD_END);
    ret |= ncLib_I2C_Control(GCMD_I2C_CONNECT_ISR_HANDLER, i2c1.channel, CMD_END);


#if 1 // master write and slave read
    DEBUGMSG(MSGINFO, "ch0 master write and ch1 slave read\n");

    i2c0.master.txBuf[0] = 0xc0;    // command
    i2c0.master.txBuf[1] = 0x80;    // address low
    i2c0.master.txBuf[2] = 0x01;    // address high
    i2c0.master.txBuf[3] = 0xaa;    // data low
    i2c0.master.txBuf[4] = 0x55;    // data high

    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Write(i2c0.channel, i2c0.master.id, 0x00, i2c0.master.txBuf[0], 1, i2c0.type); // cmd
    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Write(i2c0.channel, i2c0.master.id, 0x01, i2c0.master.txBuf[1], 1, i2c0.type); // adl
    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Write(i2c0.channel, i2c0.master.id, 0x02, i2c0.master.txBuf[2], 1, i2c0.type); // adh
    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Write(i2c0.channel, i2c0.master.id, 0x03, i2c0.master.txBuf[3], 1, i2c0.type); // dtl
    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Write(i2c0.channel, i2c0.master.id, 0x04, i2c0.master.txBuf[4], 1, i2c0.type); // dth

    //DEBUGMSG(MSGINFO, "W------------------\n");
#endif


#if 1 // master read and slave write
    DEBUGMSG(MSGINFO, "\nmaster read and slave write\n");

    for(i = 0; i < 128; i++)
    {
        i2c0.master.txBuf[i] = 0;
        i2c0.slave.rxBuf[i] = 0;
        i2c1.master.txBuf[i] = 0;
        i2c1.slave.rxBuf[i] = 0;
    }


    Temp = 0;
    i2c1.master.txBuf[0] = 0x55;
    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Read(i2c0.channel, i2c0.master.id, 0xC0, (UINT8 *)&Temp, 1, i2c0.type); // adl
    DEBUGMSG(MSGINFO, "ch0 read addr 0xC0, data 0x%02X\n", Temp);

    Temp = 0;
    i2c1.master.txBuf[0] = 0xAA;
    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Read(i2c0.channel, i2c0.master.id, 0xC1, (UINT8 *)&Temp, 1, i2c0.type); // cmd
    DEBUGMSG(MSGINFO, "ch0 read addr 0xC1, data 0x%02X\n", Temp);


    if(ret == NC_SUCCESS)
    {
        DEBUGMSG(MSGINFO, "Success, ch0 master read and ch1 slave write\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, "Failure, ch0 master read and ch1 slave write\n");
    }
#endif

    ret |= ncLib_I2C_Control(GCMD_I2C_DISCONNECT_ISR_HANDLER, i2c1.channel, CMD_END);

    ret |= ncLib_I2C_Control(GCMD_I2C_DEINIT_CH, i2c0.channel, CMD_END);
    ret |= ncLib_I2C_Control(GCMD_I2C_DEINIT_CH, i2c1.channel, CMD_END);

    DEBUGMSG(MSGINFO, "\nI2C channel 0 Master Mode Scenario Test End !!!\n");
}


void APACHE_TEST_I2C_SlaveModeScenarioLoopback_M1_S0(void)
{
    UINT8 tx_buffer0[128] = { 0x00 };
    UINT8 rx_buffer0[128] = { 0x00 };
    UINT8 tx_buffer1[128] = { 0x00 };
    UINT8 rx_buffer1[128] = { 0x00 };
    tI2C_INFO i2c0;
    tI2C_INFO i2c1;
    UINT32 i, Temp;
    INT32 ret = NC_SUCCESS;

    DEBUGMSG(MSGINFO, "\n--------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "DB 844-I6 only version\n");
    DEBUGMSG(MSGINFO, "--------------------------------------------------------\n");

    DEBUGMSG(MSGINFO, "\nI2C channel 1 Master Mode Scenario Test\n");
    DEBUGMSG(MSGINFO, "channel_1 master, channel_0 slave\n");

    i2c0.channel = I2C_CH0;
    i2c0.mode = I2C_OP_MODE_SLAVE;
    i2c0.byteOrder = I2C_LITTLE_ENDIAN;
    i2c0.type = I2C_ADDR_8_DATA_8;
    i2c0.slave.id = 0xC0;       // device id ???
    i2c0.master.txBuf = (UINT8 *)tx_buffer0;
    i2c0.slave.rxBuf = (UINT8 *)rx_buffer0;
    i2c0.master.txIdx = 0;
    i2c0.slave.rxIdx = 0;

    ret |= ncLib_I2C_Control(GCMD_I2C_INIT_CH, i2c0.channel, &i2c0, CMD_END);
    ret |= ncLib_I2C_Control(GCMD_I2C_CONNECT_ISR_HANDLER, i2c0.channel, CMD_END);


    i2c1.channel = I2C_CH1;
    i2c1.mode = I2C_OP_MODE_MASTER;
    i2c1.byteOrder = I2C_LITTLE_ENDIAN;
    i2c1.type = I2C_ADDR_8_DATA_8;
    i2c1.master.id = 0xC0;      // device id ???
    i2c1.master.clock = I2C_BITRATE_30KBPS;
    i2c1.master.txBuf = (UINT8 *)tx_buffer1;
    i2c1.slave.rxBuf = (UINT8 *)rx_buffer1;
    i2c1.master.txIdx = 0;
    i2c1.slave.rxIdx = 0;

    ret |= ncLib_I2C_Control(GCMD_I2C_INIT_CH, i2c1.channel, &i2c1, CMD_END);
    ret |= ncLib_I2C_Control(GCMD_I2C_SET_BITRATE, i2c1.channel, i2c1.master.clock, CMD_END);


#if 1 // master write and slave read
    DEBUGMSG(MSGINFO, "ch1 master write and ch0 slave read\n");

    i2c1.master.txBuf[0] = 0xc1;    // command
    i2c1.master.txBuf[1] = 0x90;    // address low
    i2c1.master.txBuf[2] = 0x04;    // address high
    i2c1.master.txBuf[3] = 0x55;    // data low
    i2c1.master.txBuf[4] = 0xaa;    // data high

    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Write(i2c1.channel, i2c1.master.id, 0x00, i2c1.master.txBuf[0], 1, i2c1.type); // cmd
    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Write(i2c1.channel, i2c1.master.id, 0x01, i2c1.master.txBuf[1], 1, i2c1.type); // adl
    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Write(i2c1.channel, i2c1.master.id, 0x02, i2c1.master.txBuf[2], 1, i2c1.type); // adh
    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Write(i2c1.channel, i2c1.master.id, 0x03, i2c1.master.txBuf[3], 1, i2c1.type); // dtl
    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Write(i2c1.channel, i2c1.master.id, 0x04, i2c1.master.txBuf[4], 1, i2c1.type); // dth
#endif

#if 1 // master read and slave write
    DEBUGMSG(MSGINFO, "\nmaster read and slave write\n");

    for(i = 0; i < 128; i++)
    {
        i2c0.master.txBuf[i] = 0;
        i2c0.slave.rxBuf[i] = 0;
        i2c1.master.txBuf[i] = 0;
        i2c1.slave.rxBuf[i] = 0;
    }


    Temp = 0;
    i2c0.master.txBuf[0] = 0xaa;
    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Read(i2c1.channel, i2c1.master.id, 0xC2, (UINT8 *)&Temp, 1, i2c1.type); // adl
    DEBUGMSG(MSGINFO, "ch1 read addr 0xC2, data 0x%02X\n", Temp);

    Temp = 0;
    i2c0.master.txBuf[0] = 0x55;
    DEBUGMSG(MSGINFO, "W------------------\n");
    ret |= ncLib_I2C_Read(i2c1.channel, i2c1.master.id, 0xC3, (UINT8 *)&Temp, 1, i2c1.type); // cmd
    DEBUGMSG(MSGINFO, "ch1 read addr 0xC3, data 0x%02X\n", Temp);


    if(ret == NC_SUCCESS)
    {
        DEBUGMSG(MSGINFO, "Success, ch1 master read and ch0 slave write\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, "Failure, ch1 master read and ch0 slave write\n");
    }
#endif

    ret |= ncLib_I2C_Control(GCMD_I2C_DISCONNECT_ISR_HANDLER, i2c0.channel, CMD_END);

    ret |= ncLib_I2C_Control(GCMD_I2C_DEINIT_CH, i2c0.channel, CMD_END);
    ret |= ncLib_I2C_Control(GCMD_I2C_DEINIT_CH, i2c1.channel, CMD_END);

    DEBUGMSG(MSGINFO, "\nI2C channel 1 Master Mode Scenario Test End !!!\n");
}


#endif


/* End Of File */




