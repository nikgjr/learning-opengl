/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_sFlash.c
*
*  @brief   :
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.01.19
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"


#if ENABLE_IP_SF

#define __SF_TEST_MEM_STACK__










/*
********************************************************************************
*                            LOCAL DEFINITIONS
********************************************************************************
*/
/* 
********************************************************************************
* FPGA DB Version
* r560-a1_2016_0126             SSP1
* r560-a8_2016_0131             SSP1
* r627-a1_2016_0204             SSP1
* r730-a1_2016_0222             SSP0
********************************************************************************
*/
#define FPGA_SF_CH              0











/*
********************************************************************************
*                        LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                             LOCAL TYPEDEF
********************************************************************************
*/
typedef struct _tSFTEST_FLAG
{
    BOOL        QuadMode;
    BOOL        DMAMode;
    SF_BITRATE  BitRate; 
} tSFEST_FLAG, *ptSFTEST_FLAG;










/*
********************************************************************************
*                       IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                        GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/
tSFEST_FLAG tSFTestFlag = { TRUE, TRUE, SF_BITRATE_5Mbps };


#ifndef __SF_TEST_MEM_STACK__
UINT8  gTestsFlashwBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
UINT8  gTestsFlashrBuff[SF_SECTOR_SIZE] __attribute__ ((aligned (8)));
#endif











/*
********************************************************************************
*                       IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                         LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

/*
********************************************************************************
*                             FUNCTION DEFINITIONS
********************************************************************************
*/
#define __TOLOWER(c)              (((c) >= 'A' && (c) <= 'Z' ) ? (c)+('a'-'A') : (c))

static INT32 __atoi(char *Str)
{
    UINT32    Val;
    INT32     Offset, c;
    char      *Sp;

    Val = 0;
    Sp = Str;

    if((*Sp == '0') && (*(Sp+1) == 'x'))
    {
        Offset = 16;
        Sp += 2;
    }
    else if(*Sp == '0')
    {
        Offset = 8;
        Sp++;
    }
    else
    {
        Offset = 10;
    }

    for(; (*Sp != 0); Sp++)
    {
        c = (*Sp > '9') ? (__TOLOWER(*Sp) - 'a' + 10) : (*Sp - '0');
        Val = (Val * Offset) + c;
    }

    return(Val);
}


UINT32 __test_sf_display_inputvalue(UINT32 MinNum, UINT32 MaxNum, char *Str)
{
    char   buf[100];
    UINT32 InputNum;

    do
    {
        InputNum = 0;
        DEBUGMSG(MSGINFO, "-------------------------------------------------------------\n");	
        DEBUGMSG(MSGINFO, " [%s] input (%d ~ %d) >> ", Str, MinNum, MaxNum);
        DBGSCANF(buf);

        InputNum = __atoi(buf);
        if((InputNum < MinNum) || (InputNum > MaxNum))
            DEBUGMSG(MSGINFO, " input Fail : %d\n", InputNum);

    }while((InputNum < MinNum) || (InputNum > MaxNum));

    DEBUGMSG(MSGINFO, "\n input Ok : %d\n", InputNum);

    return InputNum;
}

void __test_sf_display_buff( UINT8 *pBuff, UINT32 Size, UINT32 PageAddr)
{
    UINT32 i;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");	
    DEBUGMSG(MSGINFO, "\n>> PageAddr = 0x%08X", PageAddr);	
    for(i=0;i<Size;i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", PageAddr+i);	
        DEBUGMSG(MSGINFO, "%02X ", pBuff[i]);	
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");	
}

void __test_sf_buff_pageaddr_marking(UINT8 *pData, UINT32 PageAddr)
{
    pData[0] = (PageAddr>>24 & 0xFF);
    pData[1] = (PageAddr>>16 & 0xFF);
    pData[2] = (PageAddr>>8  & 0xFF);
    pData[3] = (PageAddr     & 0xFF);

    pData[SF_PAGE_SIZE-4] = (PageAddr>>24 & 0xFF);
    pData[SF_PAGE_SIZE-3] = (PageAddr>>16 & 0xFF);
    pData[SF_PAGE_SIZE-2] = (PageAddr>>8  & 0xFF);
    pData[SF_PAGE_SIZE-1] = (PageAddr     & 0xFF);
}

static UINT32 __test_sf_memory_size(UINT8 Capacity)
{
    UINT32 nChipSize = 64*KB;
    UINT32 i;

    for(i = MEMORY_CAPACITY_512Kb; i <= MEMORY_CAPACITY_128Mb; i++)
    {
        if(Capacity == i)
        {
            break;
        }
        else
        {
            nChipSize = nChipSize * 2;
        }
    }

    return nChipSize;
}

static void __test_sf_dumy_buff(UINT8 *pData, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        *pData++ = i;
    }
}

static void __test_sf_clear_buff(UINT8 *pData, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        *pData++ = 0x0;
    }
}

void APACHE_TEST_SF_Init(void)
{
    tSF_INIT_PARAM tsFlashParam;

    ncLib_SF_Open( ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_SSPI, CMD_END) );

    tsFlashParam.mChNum 	= FPGA_SF_CH;
    tsFlashParam.mDmaMode	= tSFTestFlag.DMAMode;
    tsFlashParam.mQuadMode	= tSFTestFlag.QuadMode;
    tsFlashParam.mBitRate	= tSFTestFlag.BitRate;
    ncLib_SF_Control(GCMD_SF_INIT, &tsFlashParam, CMD_END);

    DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, " Write [Standard SPI-%s Mode], Read [%s Mode]\n", (tSFTestFlag.DMAMode)?"DMA":"PIO", 
                                                            (tSFTestFlag.QuadMode)?"Quad SPI":(tSFTestFlag.DMAMode)?"Standard SPI-DMA":"Standard SPI-PIO");
}

void APACHE_TEST_SF_DeInit(void)
{
    ncLib_SF_Control(GCMD_SF_DEINIT, CMD_END);
    ncLib_SF_Close();
}

void APACHE_TEST_SF_ReadID(void)
{
    tSFLASH_ID tFlashID;



    DEBUGMSG(MSGINFO, "[SF_TEST] Read Identification\n");



    /* Open Serial Flash Library */
    APACHE_TEST_SF_Init();



    /* Get Chip Size from RDID */
    ncLib_SF_Control(GCMD_SF_READ_ID, &tFlashID, CMD_END);

    /* Display Test Result */
    DEBUGMSG(MSGINFO, " Spi-Flash >> \n");
    DEBUGMSG(MSGINFO, "  manufacturer ID : 0x%02X\n", tFlashID.mbManufacture);
    DEBUGMSG(MSGINFO, "  memory type     : 0x%02X\n", tFlashID.mbMemoryType);
    DEBUGMSG(MSGINFO, "  memory density  : 0x%02X\n", tFlashID.mbMemoryCapacity);
    DEBUGMSG(MSGINFO, "  memory size     : %d KB\n", (__test_sf_memory_size((tFlashID.mbMemoryCapacity&0xf))/KB));



    /* Close Serial Flash Library */
    APACHE_TEST_SF_DeInit();
}


void APACHE_TEST_SF_BlockErase(void)
{
    tSFLASH_ID tFlashID;

#ifdef __SF_TEST_MEM_STACK__
    UINT8  rBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* rBuff = (UINT8*)&gTestsFlashrBuff[0];
#endif

    UINT32 Addr;
    UINT32 i;
    UINT32 nErrCnt;
    UINT32 nChipSize;


    
    DEBUGMSG(MSGINFO, "\n[SF_TEST] Block Erase -> Read Page -> Check Data (0xFF)\n");



    /* Open Serial Flash Library */
    APACHE_TEST_SF_Init();



    /* Get Chip Size from RDID */
    ncLib_SF_Control(GCMD_SF_READ_ID, &tFlashID, CMD_END);
    nChipSize = __test_sf_memory_size((tFlashID.mbMemoryCapacity&0xf));
    DEBUGMSG(MSGINFO, " sFlash Size: %d KB\n", nChipSize / KB);



    /* Whole Chip Erase */
    for(Addr = 0; Addr < nChipSize; Addr += SF_BLOCK_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Block Erase : 0x%08x", Addr);
        ncLib_SF_Control(GCMD_SF_BLOCK_ERASE, Addr, CMD_END );
    }
    DEBUGMSG(MSGINFO, "\n");



    /* Page Read - Check Erased Chip(0xFF) */
    for(Addr = 0, nErrCnt = 0; Addr < nChipSize; Addr += SF_PAGE_SIZE)
    {
        __test_sf_clear_buff(rBuff, SF_PAGE_SIZE);	
        
        DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", Addr);
        ncLib_SF_Control(GCMD_SF_READ_PAGE, Addr, (UINT8 *)rBuff, CMD_END);

        for(i=0; i<SF_PAGE_SIZE; i++)
        {
            if(rBuff[i] != 0xFF)
            {
                nErrCnt++;

                __test_sf_display_buff(rBuff, SF_PAGE_SIZE, Addr);
                break;  
            }
        }
    }
    
    /* Display Test Result */
    if(nErrCnt == 0)
    {
        DEBUGMSG(MSGINFO, " - Success!\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, " - Fail! (%d)\n", nErrCnt);
    }



    /* Close Serial Flash Library */
    APACHE_TEST_SF_DeInit();
}

void APACHE_TEST_SF_PageRead(void)
{
    tSFLASH_ID tFlashID;

#ifdef __SF_TEST_MEM_STACK__
    UINT8  rBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* rBuff = (UINT8*)&gTestsFlashrBuff[0];
#endif

    UINT32 Addr = 0;    
    UINT32 nChipSize;



    DEBUGMSG(MSGINFO, "\n[SF_TEST] Read Page\n");



    /* Open Serial Flash Library */
    APACHE_TEST_SF_Init();



    /* Get Chip Size from RDID */
    ncLib_SF_Control(GCMD_SF_READ_ID, &tFlashID, CMD_END);
    nChipSize = __test_sf_memory_size((tFlashID.mbMemoryCapacity&0xf));
    DEBUGMSG(MSGINFO, " sFlash Size: %d KB\n", nChipSize / KB);



    /* Page Read  */
    __test_sf_clear_buff(rBuff, SF_PAGE_SIZE);	
    ncLib_SF_Control(GCMD_SF_READ_PAGE, Addr, (UINT8 *)rBuff, CMD_END);
    __test_sf_display_buff(rBuff, SF_PAGE_SIZE, Addr);



    /* Close Serial Flash Library */
    APACHE_TEST_SF_DeInit();
}

void APACHE_TEST_SF_PageWrite(void)
{
    tSFLASH_ID tFlashID;

#ifdef __SF_TEST_MEM_STACK__
    UINT8  wBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* wBuff = (UINT8*)&gTestsFlashwBuff[0];
#endif

    UINT32 Addr = 0;    
    UINT32 nChipSize;



    DEBUGMSG(MSGINFO, "\n[SF_TEST] Page Write\n");



    /* Open Serial Flash Library */
    APACHE_TEST_SF_Init();



    /* Get Chip Size from RDID */
    ncLib_SF_Control(GCMD_SF_READ_ID, &tFlashID, CMD_END);
    nChipSize = __test_sf_memory_size((tFlashID.mbMemoryCapacity&0xf));
    DEBUGMSG(MSGINFO, " sFlash Size: %d KB\n", nChipSize / KB);



    /* Page Write  */
    __test_sf_dumy_buff(wBuff, SF_PAGE_SIZE);
    ncLib_SF_Control(GCMD_SF_SECTOR_ERASE, Addr, CMD_END );    
    ncLib_SF_Control(GCMD_SF_WRITE_PAGE, Addr, (UINT8 *)wBuff, CMD_END);
    __test_sf_display_buff(wBuff, SF_PAGE_SIZE, Addr);



    /* Close Serial Flash Library */
    APACHE_TEST_SF_DeInit();
}

void APACHE_TEST_SF_SectorErase_DataWrite_DataRead_Compare(void)
{
    tSFLASH_ID tFlashID;

#ifdef __SF_TEST_MEM_STACK__
    UINT8  wBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
    UINT8  rBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* wBuff = (UINT8*)&gTestsFlashwBuff[0];
    UINT8* rBuff = (UINT8*)&gTestsFlashrBuff[0];
#endif
    
    UINT32 Addr = 0;  
    UINT32 Offset;    
    UINT32 i;
    UINT32 nErrCnt;    
    UINT32 nChipSize;



    DEBUGMSG(MSGINFO, "\n[SF_TEST] Write Data\n");



    /* Generate Write Data */	
    __test_sf_dumy_buff(wBuff, SF_PAGE_SIZE);



    /* Open Serial Flash Library */
    APACHE_TEST_SF_Init();



    /* Get Chip Size from RDID */
    ncLib_SF_Control(GCMD_SF_READ_ID, &tFlashID, CMD_END);
    nChipSize = __test_sf_memory_size((tFlashID.mbMemoryCapacity&0xf));
    DEBUGMSG(MSGINFO, " sFlash Size: %d KB\n", nChipSize / KB);


    /* Whole Chip Erase and Write Pattern */
    for(Addr = 0; Addr < SF_SECTOR_SIZE; Addr += SF_SECTOR_SIZE)
    {
        ncLib_SF_Control(GCMD_SF_SECTOR_ERASE, Addr, CMD_END );

        for(Offset = 0; Offset < SF_SECTOR_SIZE; Offset += SF_PAGE_SIZE)
        {
            DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", Addr+Offset);
            
            __test_sf_buff_pageaddr_marking(wBuff, Addr+Offset);  
            for(i=0; i<SF_PAGE_SIZE; i++)
            {
                ncLib_SF_Control(GCMD_SF_WRITE_DATA, Addr+Offset+i, (UINT8 *)(wBuff+i), 1, CMD_END);  
            }
        }
    }
    DEBUGMSG(MSGINFO, "\n");


    /* Page Read and Compare Data */
    for(Addr = 0, nErrCnt = 0; Addr < SF_SECTOR_SIZE; Addr += SF_PAGE_SIZE)
    {
        __test_sf_clear_buff(rBuff, SF_PAGE_SIZE);	
        __test_sf_buff_pageaddr_marking(wBuff, Addr);  
        
        DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", Addr);
        for(i=0; i<SF_PAGE_SIZE; i++)
        {
            ncLib_SF_Control(GCMD_SF_READ_DATA, Addr+i, (UINT8 *)(rBuff+i), 1, CMD_END);
        }

        for(i=0; i<SF_PAGE_SIZE; i++)
        {
            if(wBuff[i] != rBuff[i])
            {
                nErrCnt++;

                __test_sf_display_buff(rBuff, SF_PAGE_SIZE, Addr);
                break;  
            }
        }
    }
    
    /* Display Test Result */
    if(nErrCnt == 0)
    {
        DEBUGMSG(MSGINFO, " - Success!\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, " - Fail! (%d)\n", nErrCnt);
    }



    /* Close Serial Flash Library */
    APACHE_TEST_SF_DeInit();
}

void APACHE_TEST_SF_SectorErase_Write_Read_Compare(void)
{
    tSFLASH_ID tFlashID;
    
#ifdef __SF_TEST_MEM_STACK__
    UINT8  wBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
    UINT8  rBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* wBuff = (UINT8*)&gTestsFlashwBuff[0];
    UINT8* rBuff = (UINT8*)&gTestsFlashrBuff[0];
#endif

    UINT32 Addr;
    UINT32 Offset;
    UINT32 i;
    UINT32 nErrCnt;
    UINT32 nChipSize;



    DEBUGMSG(MSGINFO, "\n[SF_TEST] Sector Erase -> Program Page -> Read Page -> Compare\n");



    /* Generate Write Data */	
    __test_sf_dumy_buff(wBuff, SF_PAGE_SIZE);



    /* Open Serial Flash Library */
    APACHE_TEST_SF_Init();



    /* Get Chip Size from RDID */
    ncLib_SF_Control(GCMD_SF_READ_ID, &tFlashID, CMD_END);
    nChipSize = __test_sf_memory_size((tFlashID.mbMemoryCapacity&0xf));
    DEBUGMSG(MSGINFO, " sFlash Size: %d KB\n", nChipSize / KB);


    /* Whole Chip Erase and Write Pattern */
    for(Addr = 0; Addr < nChipSize; Addr += SF_SECTOR_SIZE)
    {
        ncLib_SF_Control(GCMD_SF_SECTOR_ERASE, Addr, CMD_END );

        for(Offset = 0; Offset < SF_SECTOR_SIZE; Offset += SF_PAGE_SIZE)
        {
            DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", Addr+Offset);
            
            __test_sf_buff_pageaddr_marking(wBuff, Addr+Offset);              
            ncLib_SF_Control(GCMD_SF_WRITE_PAGE, Addr+Offset, (UINT8 *)wBuff, CMD_END);
        }
    }
    DEBUGMSG(MSGINFO, "\n");


    /* Page Read and Compare Data */
    for(Addr = 0, nErrCnt = 0; Addr < nChipSize; Addr += SF_PAGE_SIZE)
    {
        __test_sf_clear_buff(rBuff, SF_PAGE_SIZE);	
        __test_sf_buff_pageaddr_marking(wBuff, Addr);  
        
        DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", Addr);
        ncLib_SF_Control(GCMD_SF_READ_PAGE, Addr, (UINT8 *)rBuff, CMD_END);

        for(i=0; i<SF_PAGE_SIZE; i++)
        {
            if(wBuff[i] != rBuff[i])
            {
                nErrCnt++;

                __test_sf_display_buff(rBuff, SF_PAGE_SIZE, Addr);
                break;  
            }
        }
    }
    
    /* Display Test Result */
    if(nErrCnt == 0)
    {
        DEBUGMSG(MSGINFO, " - Success!\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, " - Fail! (%d)\n", nErrCnt);
    }



    /* Close Serial Flash Library */
    APACHE_TEST_SF_DeInit();
}

void APACHE_TEST_SF_BlockErase_Write_Read_Compare(void)
{
    tSFLASH_ID tFlashID;
    
#ifdef __SF_TEST_MEM_STACK__
    UINT8  wBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
    UINT8  rBuff[SF_SECTOR_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* wBuff = (UINT8*)&gTestsFlashwBuff[0];
    UINT8* rBuff = (UINT8*)&gTestsFlashrBuff[0];
#endif

    UINT32 Addr, MakingAddr;
    UINT32 Offset;
    UINT32 i,j;
    UINT32 nErrCnt;
    UINT32 nChipSize;



    DEBUGMSG(MSGINFO, "\n[SF_TEST] Block Erase -> Program Page -> Read Data -> Compare\n");



    /* Generate Write Data */	
    __test_sf_dumy_buff(wBuff, SF_PAGE_SIZE);



    /* Open Serial Flash Library */
    APACHE_TEST_SF_Init();



    /* Get Chip Size from RDID */
    ncLib_SF_Control(GCMD_SF_READ_ID, &tFlashID, CMD_END);
    nChipSize = __test_sf_memory_size((tFlashID.mbMemoryCapacity&0xf));
    DEBUGMSG(MSGINFO, " sFlash Size: %d KB\n", nChipSize / KB);


    /* Whole Chip Erase and Write Pattern */
    for(Addr = 0; Addr < nChipSize; Addr += SF_BLOCK_SIZE)
    {
        ncLib_SF_Control(GCMD_SF_BLOCK_ERASE, Addr, CMD_END );

        for(Offset = 0; Offset < SF_BLOCK_SIZE; Offset += SF_PAGE_SIZE)
        {
            DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", Addr+Offset);

            __test_sf_buff_pageaddr_marking(wBuff, Addr+Offset);                
            ncLib_SF_Control(GCMD_SF_WRITE_PAGE, Addr+Offset, (UINT8 *)wBuff, CMD_END);
        }
    }
    DEBUGMSG(MSGINFO, "\n");


    /* Data Read and Compare Data */
    for(Addr = 0, nErrCnt = 0; Addr < nChipSize; Addr += SF_SECTOR_SIZE)
    {
        __test_sf_clear_buff(rBuff, SF_SECTOR_SIZE);	

        DEBUGMSG(MSGINFO, "\r  Data Read   : 0x%08x", Addr);
        ncLib_SF_Control(GCMD_SF_READ_DATA, Addr, (UINT8 *)rBuff, SF_SECTOR_SIZE, CMD_END);

        MakingAddr = Addr;        
        for(i=0, j=0; i<SF_SECTOR_SIZE; i++)
        {
            if(j >= SF_PAGE_SIZE)
            {
                j=0;
                MakingAddr+=SF_PAGE_SIZE;
            }

            if(j == 0)
                __test_sf_buff_pageaddr_marking(wBuff, MakingAddr); 

            if(wBuff[j++] != rBuff[i])
            {
                //DEBUGMSG(MSGINFO, "\n wBuff[%d]:%02x vs rBuff[%d]:%02x\n", j-1, wBuff[j-1], i, rBuff[i]);
                nErrCnt++;

                for(i=0; i<SF_SECTOR_SIZE; i+=SF_PAGE_SIZE)
                    __test_sf_display_buff(&rBuff[i], SF_PAGE_SIZE, Addr+i);
                break;
            }
        }
    }
    
    /* Display Test Result */
    if(nErrCnt == 0)
    {
        DEBUGMSG(MSGINFO, " - Success!\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, " - Fail! (%d)\n", nErrCnt);
    }



    /* Close Serial Flash Library */
    APACHE_TEST_SF_DeInit();
}

void APACHE_TEST_SF_Bitrate_Change(void)
{
    UINT32 nBitRate;
    tSFLASH_ID tFlashID;
    
#ifdef __SF_TEST_MEM_STACK__
    UINT8  wBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
    UINT8  rBuff[SF_SECTOR_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* wBuff = (UINT8*)&gTestsFlashwBuff[0];
    UINT8* rBuff = (UINT8*)&gTestsFlashrBuff[0];
#endif

    UINT32 Addr, MakingAddr;
    UINT32 Offset;
    UINT32 i,j;
    UINT32 nErrCnt;
    UINT32 nChipSize;



    DEBUGMSG(MSGINFO, "[SF_TEST] Bitrate Change\n");



    /* Generate Write Data */	
    __test_sf_dumy_buff(wBuff, SF_PAGE_SIZE);


    
    /* Open Serial Flash Library */
    APACHE_TEST_SF_Init();



    /* BitRate Change Start */	
    for(nBitRate = SF_BITRATE_1Mbps; nBitRate <= SF_BITRATE_12Mbps; nBitRate++)
    {
        /* Set BitRate */
        ncLib_SF_Control(GCMD_SF_SET_BITRATE, nBitRate, CMD_END);



        /* Get Chip Size from RDID */
        ncLib_SF_Control(GCMD_SF_READ_ID, &tFlashID, CMD_END);
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " >> BitRate   : %d-Mbps\n", nBitRate);
        DEBUGMSG(MSGINFO, " sFlash ID    : 0x%02x 0x%02x 0x%02x\n", tFlashID.mbManufacture,
                                                                    tFlashID.mbMemoryType,
                                                                    tFlashID.mbMemoryCapacity);
        nChipSize = __test_sf_memory_size((tFlashID.mbMemoryCapacity&0xf));
        DEBUGMSG(MSGINFO, " sFlash Size  : %d KB\n", nChipSize / KB);


        /* Whole Chip Erase and Write Pattern */
        for(Addr = 0; Addr < nChipSize; Addr += SF_BLOCK_SIZE)
        {
            ncLib_SF_Control(GCMD_SF_BLOCK_ERASE, Addr, CMD_END );

            for(Offset = 0; Offset < SF_BLOCK_SIZE; Offset += SF_PAGE_SIZE)
            {
                DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", Addr+Offset);
                
                 __test_sf_buff_pageaddr_marking(wBuff, Addr+Offset);    
                ncLib_SF_Control(GCMD_SF_WRITE_PAGE, Addr+Offset, (UINT8 *)wBuff, CMD_END);
            }
        }
        DEBUGMSG(MSGINFO, "\n");
        

        /* Page Read and Compare Data */
        for(Addr = 0, nErrCnt = 0; Addr < nChipSize; Addr += SF_PAGE_SIZE)
        {
            __test_sf_clear_buff(rBuff, SF_PAGE_SIZE);	
            __test_sf_buff_pageaddr_marking(wBuff, Addr); 
        
            DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", Addr);
            ncLib_SF_Control(GCMD_SF_READ_PAGE, Addr, (UINT8 *)rBuff, CMD_END);

            for(i=0; i<SF_PAGE_SIZE; i++)
            {	
                if(wBuff[i] != rBuff[i])
                {
                    nErrCnt++;
                    
                    //__test_sf_display_buff(rBuff, SF_PAGE_SIZE, Addr);
                    break;  
                }
            }
        }
    
        /* Display Test Result */
        if(nErrCnt == 0)
        {
            DEBUGMSG(MSGINFO, " - Success!\n");
        }
        else
        {
            DEBUGMSG(MSGINFO, " - Fail! (%d)\n", nErrCnt);
        }



        /* Data Read and Compare Data */
        for(Addr = 0, nErrCnt = 0; Addr < nChipSize; Addr += SF_SECTOR_SIZE)
        {
            __test_sf_clear_buff(rBuff, SF_SECTOR_SIZE);	

            DEBUGMSG(MSGINFO, "\r  Data Read   : 0x%08x", Addr);
            ncLib_SF_Control(GCMD_SF_READ_DATA, Addr, (UINT8 *)rBuff, SF_SECTOR_SIZE, CMD_END);

            MakingAddr = Addr;     
            for(i=0, j=0; i<SF_SECTOR_SIZE; i++)
            {
                if(j >= SF_PAGE_SIZE)
                {
                    j=0;
                    MakingAddr+=SF_PAGE_SIZE;
                }

                if(j == 0)
                    __test_sf_buff_pageaddr_marking(wBuff, MakingAddr); 

                if(wBuff[j++] != rBuff[i])
                {
                    //DEBUGMSG(MSGINFO, "\n wBuff[%d]:%02x vs rBuff[%d]:%02x\n", j-1, wBuff[j-1], i, rBuff[i]);
                    nErrCnt++;

                    //for(i=0; i<SF_SECTOR_SIZE; i+=SF_PAGE_SIZE)
                    //    __test_sf_display_buff(&rBuff[i], SF_PAGE_SIZE, Addr+i);
                    break;
                }
            }
        }
    
        /* Display Test Result */
        if(nErrCnt == 0)
        {
            DEBUGMSG(MSGINFO, " - Success!\n");
        }
        else
        {
            DEBUGMSG(MSGINFO, " - Fail! (%d)\n", nErrCnt);
        }
    }



    /* Close Serial Flash Library */
    APACHE_TEST_SF_DeInit();
}

INT32 APACHE_TEST_SF_CUIMode(void)
{
    INT32 	select;
    char 	buf[256];
 
    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - Serial Flash Interface       \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Standard SPI Controller : Read & Write Support             \n");
        DEBUGMSG(MSGINFO, " Quad     SPI Controller : Read Support                     \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> SF: Read Serial Flash ID							   \n");
        DEBUGMSG(MSGINFO, " <2> SF: Block Erase Test                                   \n");
        DEBUGMSG(MSGINFO, " <3> SF: Page Read Test                                     \n");
        DEBUGMSG(MSGINFO, " <4> SF: Page Write Test                                    \n"); 
        DEBUGMSG(MSGINFO, " <5> SF: Sector Erase -> Data Write -> Data Read -> Compare \n");          
        DEBUGMSG(MSGINFO, " <6> SF: Sector Erase -> Write Page -> Read Page -> Compare \n");
        DEBUGMSG(MSGINFO, " <7> SF: Block  Erase -> Write Page -> Read Data -> Compare \n");
        DEBUGMSG(MSGINFO, " <8> SF: Bit-rate Test                                      \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <A> SPI Mode Change     : %s SPI Mode                      \n", (tSFTestFlag.QuadMode)?"Quad":"Stardard"); 
        DEBUGMSG(MSGINFO, " <B> Tranfer Mode Change : %s Mode                          \n", (tSFTestFlag.DMAMode)?"DMA":"PIO");    
        DEBUGMSG(MSGINFO, " <C> BitRate Change      : %d Mbps                          \n", tSFTestFlag.BitRate);   
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");  
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_SF_ReadID();
            break;

            case 2:
                APACHE_TEST_SF_BlockErase();
            break;

            case 3:
                APACHE_TEST_SF_PageRead();
            break;

            case 4:
                APACHE_TEST_SF_PageWrite();
            break;
            
            case 5:
                APACHE_TEST_SF_SectorErase_DataWrite_DataRead_Compare();
            break;
            
            case 6:
                APACHE_TEST_SF_SectorErase_Write_Read_Compare();
            break;

            case 7:
                APACHE_TEST_SF_BlockErase_Write_Read_Compare();
            break;
            
            case 8:
                APACHE_TEST_SF_Bitrate_Change();
            break;

            case 10:
                tSFTestFlag.QuadMode = (tSFTestFlag.QuadMode == TRUE) ? FALSE : TRUE;
            break;

            case 11:
                tSFTestFlag.DMAMode = (tSFTestFlag.DMAMode == TRUE) ? FALSE : TRUE;
            break;

            case 12:
                tSFTestFlag.BitRate = (SF_BITRATE)__test_sf_display_inputvalue((UINT32)SF_BITRATE_1Mbps, (UINT32)SF_BITRATE_12Mbps, "Change BitRate");
            break;
                   
            case 0:
                DEBUGMSG(MSGINFO, "Move on to sub menu\n");
                goto SF_Exit;
            //break;
        }
    }
    
SF_Exit:

    return NC_SUCCESS;
}

#endif /* #if ENABLE_IP_SF */



/* End Of File */
