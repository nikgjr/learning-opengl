/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Test_IP.c
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 APACHE_TEST_APP_Main(void)
{
    INT32   select;
    char    buf[256];
    INT32 ret = NC_SUCCESS;


    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "     Detail Description about FPGA IP                       \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, "     IP-List     Address      Description                   \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> GIC         0x%08X   Generic Interrupt Controller      \n", APACHE_PL390_0_BASE);
        //DEBUGMSG(MSGINFO, " <2> CR4F        0x%08X   Cortex-R4F                        \n", APACHE_R4CONFIG_BASE);
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <3> DMAC        0x%08X   Direct Memory Access Controller   \n", APACHE_DMA_0_BASE);
        DEBUGMSG(MSGINFO, " <4> SCU         0x%08X   System Control Unit               \n", APACHE_SYSCON_BASE);
        DEBUGMSG(MSGINFO, " <5> Watchdog    0x%08X   Watchdog Timer                    \n", APACHE_WDT_BASE);
        DEBUGMSG(MSGINFO, " <6> TIMER       0x%08X   Timer                             \n", APACHE_TIMER_BASE);
        DEBUGMSG(MSGINFO, " <7> Temperature 0x%08X   Temperature Sensor                \n", APACHE_TEMP_BASE);
        DEBUGMSG(MSGINFO, " <8> DDR         0x%08X   Low Poer DDR Memory Controller    \n", APACHE_DDRC_BASE);
        DEBUGMSG(MSGINFO, " <9> I2C         0x%08X   Inter Integrated Circuit          \n", APACHE_I2C_0_BASE);
        //DEBUGMSG(MSGINFO, " <a> UART        0x%08X   Universal Asyn. Rx/Tx             \n", APACHE_UART_0_BASE);
        DEBUGMSG(MSGINFO, " <b> GPIO        0x%08X   General Purpose Input/Output      \n", APACHE_GPIO_BASE);
        DEBUGMSG(MSGINFO, " <c> SPI         0x%08X   Serial Peri. Interface            \n", APACHE_SPI_0_BASE);
        DEBUGMSG(MSGINFO, " <d> CAN         0x%08X   BasicCAN(2.0A), PeriCAN(2.0B)     \n", APACHE_CAN_BASE);
        DEBUGMSG(MSGINFO, " <e> VDUMP       0x%08X   Video Dump                        \n", APACHE_VDUMP_BASE);
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        //DEBUGMSG(MSGINFO, " <f> JIG                      for Nextune                   \n");
        DEBUGMSG(MSGINFO, " <g> System Timer             Service layer                 \n");
        DEBUGMSG(MSGINFO, " <h> sFlash Interface         Service layer                 \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <i> LUT Test                                               \n");
        DEBUGMSG(MSGINFO, " <j> D-PGL Test                                             \n");
        DEBUGMSG(MSGINFO, " <k> OSG Test                                               \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, "     Scenario Test                                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <z> FPGA Camera Preview (CMOS + ISP + HDMI)                \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main exit ...                        \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        //select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            /* IP Unit Test */

            case FPGA_IP_TEST_GIC:
#if ENABLE_IP_GIC
                APACHE_TEST_GIC_CUTMode();
#else
                DEBUGMSG(MSGWARN, "GIC is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_DMAC:
#if ENABLE_IP_DMAC
                APACHE_TEST_DMA_CUIMode();
#else
                DEBUGMSG(MSGWARN, "DMAC is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_SCU:
#if ENABLE_IP_SCU
#else
                DEBUGMSG(MSGWARN, "SCU is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_WDT:
#if ENABLE_IP_WDT
                APACHE_TEST_WDT_CUTMode();
#else
                DEBUGMSG(MSGWARN, "Watchdog is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_TIMER:
#if ENABLE_IP_TIMER
                APACHE_TEST_TIMER_CUTMode();
#else
                DEBUGMSG(MSGWARN, "Timer is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_TEMPS:
#if ENABLE_IP_TEMPS
#else
                DEBUGMSG(MSGWARN, "Temperature Sensor is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_DDR:
#if ENABLE_IP_DDR
                APACHE_TEST_DDR_CUTMode();
#else
                DEBUGMSG(MSGWARN, "LPDDR is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_I2C:
#if ENABLE_IP_I2C
                //APACHE_TEST_I2C_CUTMode();
#else
                DEBUGMSG(MSGWARN, "I2C is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_GPIO:
#if ENABLE_IP_GPIO
                APACHE_TEST_GPIO_CUIMode();
#else
                DEBUGMSG(MSGWARN, "GPIO is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_SPI:
#if ENABLE_IP_SPI
                APACHE_SYS_DeInitsFlash();
                APACHE_TEST_SSP_CUTMode();
                APACHE_SYS_InitsFlash();
#else
                DEBUGMSG(MSGWARN, "SPI is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_CAN:
#if ENABLE_IP_CAN
                APACHE_TEST_CAN_CUTMode();
#else
                DEBUGMSG(MSGWARN, "CAN is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_SYSTIME:
#if ENABLE_IP_SYSTIME
                APACHE_TEST_SYSTIME_CUTMode();
#else
                DEBUGMSG(MSGWARN, "SYSTIME is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_SF:
#if ENABLE_IP_SF
                APACHE_SYS_DeInitsFlash();
                APACHE_TEST_SF_CUIMode();
                APACHE_SYS_InitsFlash();                
#else
                DEBUGMSG(MSGWARN, "SF is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_ISP:
#if ENABLE_IP_ISP
                APACHE_TEST_DPGL_CUTMode();
#else
                DEBUGMSG(MSGWARN, "ISP is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_OSG:
#if ENABLE_IP_ISP
                APACHE_TEST_OSG_CUTMode();
#else
                DEBUGMSG(MSGWARN, "ISP is disable!\n");
#endif
            break;

            case FPGA_IP_TEST_VDUMP:
#if ENABLE_IP_VDP
                APACHE_TEST_VDUMP_CUTMode();
#else
                DEBUGMSG(MSGWARN, "VDUMP is disable!\n");
#endif
            break;


            /* Scenario Integrated Test */
            
            case FPGA_SCENARIO_TEST_PREVIEW:
#if ENABLE_ST_PREVIEW
                APACHE_TEST_I2C_CMOS_AR0140AT_Initialize();
				//APACHE_TEST_I2C_CMOS_OV10640_Initialize();
                APACHE_TEST_I2C_HDMI_Initialize();              
                ncLib_ISP_Control(GCMD_ISP_FUNCTION_INIT, CMD_END);
#else
                DEBUGMSG(MSGWARN, "Scenario CMOS + ISP + HDMI preview is disable!\n");
#endif
            break;
          
            case FPGA_IP_TEST_QUIT:
                DEBUGMSG(MSGWARN, "Move on to main exit\n");
            goto IpCheck_Exit;
        }
    }

IpCheck_Exit:

    return ret;
}


/* End Of File */
