/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_WDT.c
*
*  @brief   :
*
*  @author  : alessio / TS Group / SoC SW Team
*
*  @date    : 2016.02.12
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"


#if ENABLE_IP_WDT


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

void APACHE_TEST_WDT_PeripheralID(void);
void APACHE_TEST_WDT_PrimeCellID(void);
void APACHE_TEST_WDT_InterruptRun(void);
void APACHE_TEST_WDT_ResetRun(void);
void APACHE_TEST_WDT_IntegrationTest(void);


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 APACHE_TEST_WDT_CUTMode(void)
{
    INT32 select;
    char buf[16];

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - WDT                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> WDT Peripheral Identification                          \n");
        DEBUGMSG(MSGINFO, " <2> WDT PrimeCell Identification                           \n");
        DEBUGMSG(MSGINFO, " <3> WDT Interrupt Enable & Run Test                        \n");
        DEBUGMSG(MSGINFO, " <4> WDT Reset Enable & Run Test                            \n");
        //DEBUGMSG(MSGINFO, " <5> WDT Integration Test Control Test                      \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ...                        \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_WDT_PeripheralID();
            break;

            case 2:
                APACHE_TEST_WDT_PrimeCellID();
            break;

            case 3:
                APACHE_TEST_WDT_InterruptRun();
            break;

            case 4:
                APACHE_TEST_WDT_ResetRun();
            break;

            case 5:
                //APACHE_TEST_WDT_IntegrationTest();
            break;

            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto Wdt_Exit;
        }
    }

Wdt_Exit:

    return NC_SUCCESS;
}


void APACHE_TEST_WDT_PeripheralID(void)
{
    UINT32 periID;

    DEBUGMSG(MSGINFO, "WDT Peripheral Identification\n");
    DEBUGMSG(MSGINFO, "=============================================\n");

    ncLib_WDT_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_WDT, CMD_END));

    //ncLib_WDT_Control(GCMD_WDT_INIT, CMD_END);

    //periID = ncLib_WDT_Control(GCMD_WDT_PERIID, CMD_END);

    ncLib_WDT_Control(GCMD_WDT_DEINIT, CMD_END);

    DEBUGMSG(MSGINFO, "WDT periID = 0x%08X\n", periID);
    DEBUGMSG(MSGINFO, "=============================================\n");
    DEBUGMSG(MSGINFO, "Part number     : 0x%X\n", periID&0xFFF);
    DEBUGMSG(MSGINFO, "Designer number : 0x%X\n", (periID>>12)&0xFF);
    DEBUGMSG(MSGINFO, "Revision number : 0x%X\n", (periID>>20)&0xF);
    DEBUGMSG(MSGINFO, "Configuration   : 0x%X\n", (periID>>24)&0xFF);
    DEBUGMSG(MSGINFO, "=============================================\n");

    ncLib_WDT_Close();
}


void APACHE_TEST_WDT_PrimeCellID(void)
{
    UINT32 primeCellID;

    DEBUGMSG(MSGINFO, "WDT PrimeCell Identification\n");
    DEBUGMSG(MSGINFO, "=============================================\n");

    ncLib_WDT_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_WDT, CMD_END));

    //ncLib_WDT_Control(GCMD_WDT_INIT, CMD_END);

    //primeCellID = ncLib_WDT_Control(GCMD_WDT_PRIMECELLID, CMD_END);

    ncLib_WDT_Control(GCMD_WDT_DEINIT, CMD_END);

    DEBUGMSG(MSGINFO, "WDT periID = 0x%08X\n", primeCellID);
    DEBUGMSG(MSGINFO, "=============================================\n");

    ncLib_WDT_Close();
}


void APACHE_TEST_WDT_InterruptRun(void)
{
    tWDT_PARAM wdt;
    UINT32 i;

    DEBUGMSG(MSGINFO, "WDT Timer Mode Test\n");
    DEBUGMSG(MSGINFO, "=============================================\n");

    ncLib_WDT_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_WDT, CMD_END));

    wdt.mode = WDT_TIMER;
    wdt.mSec = 1000;    // 1000mS -> 1Sec

    ncLib_WDT_Control(GCMD_WDT_CONNECT_ISR_HANDLER, CMD_END);

    DEBUGMSG(MSGINFO, "Watch-Dog timer mode 10Sec counting...\n\n");
    DEBUGMSG(MSGINFO, "Watch-Dog timer mode 0Sec\n");

    ncLib_WDT_Control(GCMD_WDT_INIT, &wdt, CMD_END);
    ncLib_WDT_Control(GCMD_WDT_RUN, &wdt, CMD_END);

    for(i = 0; i < 10; i++)
    {
        while(1)
        {
            if(ncLib_WDT_Control(GCMD_WDT_INTR_DONE, CMD_END) == 1)
            {
                ncLib_WDT_Control(GCMD_WDT_INTR_CLR, CMD_END);
                DEBUGMSG(MSGINFO, "Watch-Dog timer mode %dSec\n", i+1);
                break;
            }
        }
    }

    ncLib_WDT_Control(GCMD_WDT_DISCONNECT_ISR_HANDLER, CMD_END);

    ncLib_WDT_Control(GCMD_WDT_DEINIT, CMD_END);

    DEBUGMSG(MSGINFO, "=============================================\n");

    ncLib_WDT_Close();
}


void APACHE_TEST_WDT_ResetRun(void)
{
    tWDT_PARAM wdt;
    UINT32 i;

    DEBUGMSG(MSGINFO, "WDT Reset Mode Test\n");
    DEBUGMSG(MSGINFO, "=============================================\n");

    ncLib_WDT_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_WDT, CMD_END));

    wdt.mode = WDT_RESET;
    wdt.mSec = 5000;    // 1000mS -> 1Sec

    ncLib_WDT_Control(GCMD_WDT_CONNECT_ISR_HANDLER, CMD_END);

    ncLib_WDT_Control(GCMD_WDT_INIT, &wdt, CMD_END);
    ncLib_WDT_Control(GCMD_WDT_RUN, &wdt, CMD_END);

    while(1)
    {
        for(i = 0; i < 5; i++)
        {
            APACHE_SYS_mDelay(1000);
            ncLib_WDT_Control(GCMD_WDT_REFRESH, CMD_END);
            DEBUGMSG(MSGINFO, "Watch-Dog test count %d\n", i+1);
        }

        DEBUGMSG(MSGINFO, "Watch-Dog reset mode waiting ...\n\n");

        while(1)
        {
        }
    }

    ncLib_WDT_Control(GCMD_WDT_DISCONNECT_ISR_HANDLER, CMD_END);

    ncLib_WDT_Control(GCMD_WDT_DEINIT, CMD_END);

    DEBUGMSG(MSGINFO, "=============================================\n");

    ncLib_WDT_Close();
}


void APACHE_TEST_WDT_IntegrationTest(void)
{
#if 0
    tWDT_PARAM wdt;
    //UINT32 i;

    DEBUGMSG(MSGINFO, "WDT Integration Test Control Test\n");
    DEBUGMSG(MSGINFO, "=============================================\n");

    ncLib_WDT_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_WDT, CMD_END));

    wdt.mode = WDT_RESET;
    wdt.mSec = 3000;    // 1000mS -> 1Sec

    ncLib_WDT_Control(GCMD_WDT_CONNECT_ISR_HANDLER, CMD_END);


    ncLib_WDT_Control(GCMD_WDT_INIT, &wdt, CMD_END);

    //ncLib_WDT_Control(GCMD_WDT_RUN, &wdt, CMD_END);
    //ncLib_WDT_Control(GCMD_WDT_REFRESH, CMD_END);

    REGRW32(0x30400000, 0x0F00) = 1;
    REGRW32(0x30400000, 0x0F04) = 1<<1;
    //REGRW32(0x30400000, 0x0F04) = 1<<0;

    while(1)
    {
    }

    ncLib_WDT_Control(GCMD_WDT_DEINIT, CMD_END);

    DEBUGMSG(MSGINFO, "=============================================\n");

    ncLib_WDT_Close();
#endif
}


#endif


/* End Of File */
