/**
********************************************************************************
*
*  Copyright (C) 2013 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_TS.c
*
*  @brief   : This file is Temperature test code for NEXTCHIP standard library
*
*  @author  : Joy / SoC Software Group / parkjy@nextchip.com
*
*  @date    : 2016.02.25
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"
#include "test.h"


#if ENABLE_IP_TEMPS









/*
********************************************************************************
*                            LOCAL DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                        LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                             LOCAL TYPEDEF
********************************************************************************
*/

/*
********************************************************************************
*                       IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                        GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                       IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                         LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

/*
********************************************************************************
*                             FUNCTION DEFINITIONS
********************************************************************************
*/
void APACHE_TEST_TemperatureSensor(void)
{
    INT32   ret;
    INT32   i;
    FP32    data;
    FP32    min, max;



    DEBUGMSG(MSGINFO, "\n\nStart APACHE_TEST_TemperatureSensor()\n");



    /*
     * Open TS (temperature sensor)
     */
    ret = ncLib_TS_Open();
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "TS Open Error!\n");
    }



    /*
     * Init temperature sensor
     */
    ret = ncLib_TS_Control( GCMD_TS_INIT, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "GCMD_TS_INIT Error!\n");
    }


    DEBUGMSG(MSGINFO, "=================================================\n");
    DEBUGMSG(MSGINFO, "Cur        Min        Max        Diff\n");
    DEBUGMSG(MSGINFO, "=================================================\n");

    min = 0;
    max = 0;
    for(i = 0; i<10; i++)
    {
        /*
         * Get temperature
         */
        ret = ncLib_TS_Control(GCMD_TS_GET_DATA, &data, CMD_END);
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "GCMD_TS_GET_DATA Error!\n");
            return;
        }

        if(max == 0)
        {
            max = data;
            min = data;
        }
        else
        {
            if(data > max)
            {
                max = data;
            }

            if(data < min)
            {
                min = data;
            }
        }

        DEBUGMSG(MSGINFO, "%.2f      %.2f      %.2f      %.2f\n", data, min, max, max-min);
    }



    /*
     * DeInit temperature sensor
     */
    ret = ncLib_TS_Control(GCMD_TS_DEINIT, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "GCMD_TS_DEINIT Error!\n");
        return;
    }



    /*
     * Close TS (temperature sensor)
     */
    ret = ncLib_TS_Close();
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "VS Close Error!\n");
    }



    DEBUGMSG(MSGINFO, "End   APACHE_TEST_TemperatureSensor()\n");
}


#endif /* #if ENABLE_IP_TEMPS */





