/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_GIC.c
*
*  @brief   :
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.06.23
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"


#if ENABLE_IP_GIC


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/
UINT32  gTestCnt;

/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

static void __test_timer_handler(void)
{
    UINT32 IrqNum;

    IrqNum = gTestCnt++%IRQ_NUM_SGI_MAX;
    ncLib_INTC_Control(GCMD_INTC_SGI_TRIGGER, IrqNum, CMD_END); 
  
    DEBUGMSG(MSGINFO, " SGI_%d Trigger ->", IrqNum);    
}

static void __test_timer_stop(void)
{
    ncLib_TIMER_Control( GCMD_TC_STOP, TC_CH1, CMD_END );
    ncLib_TIMER_Control( GCMD_TC_DISCONNECT_USER_HANDLER, TC_CH1, CMD_END ); 
}

static void __test_timer_start(void)
{
    tTC_INIT_PARAM tTimerParam;

    tTimerParam.mMode	   = TC_MODE_PERIOD;
    tTimerParam.mPrescaler = 1;
    tTimerParam.mPeriod1   = 1000000;
    ncLib_TIMER_Control( GCMD_TC_INIT_CH, TC_CH1, &tTimerParam, CMD_END );
    ncLib_TIMER_Control( GCMD_TC_CONNECT_USER_HANDLER, TC_CH1, __test_timer_handler, CMD_END );
    ncLib_TIMER_Control( GCMD_TC_START, TC_CH1, CMD_END );    

}

void APACHE_TEST_GIC_SGI_Handler0(void *param)
{   
    DEBUGMSG(MSGINFO, " Call [IRQ_NUM_SGI_%d] Register Function\n", (UINT32)param);
}
    
void APACHE_TEST_GIC_SGI_Mode( void )
{
    INT32 ret;
    UINT32 IrqNum;



    /*
    * Register Software Generated Interrupt
    */	
    for(IrqNum=0; IrqNum<IRQ_NUM_SGI_MAX; IrqNum++)
    {
        ret = ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IrqNum, (PrHandler)APACHE_TEST_GIC_SGI_Handler0, CMD_END);
        if( ret != NC_SUCCESS )
        {
        	DEBUGMSG(MSGERR, "SGI_%d Isr Register Error\n", IrqNum);
        }
    }



    /*
    * Wait 10 sec
    */	
    gTestCnt = 0;
    __test_timer_start();
    while(gTestCnt < 10);
    __test_timer_stop();




    /*
    * UnRegister Software Generated Interrupt
    */	
    ret = ncLib_INTC_Control(GCMD_INTC_CLR_RAISED_INT, CMD_END);
    if( ret != NC_SUCCESS )
    {
    	DEBUGMSG(MSGERR, "Isr Clear\n", IrqNum);
    }    

    for(IrqNum=0; IrqNum<IRQ_NUM_SGI_MAX; IrqNum++)
    {
        ret = ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT, IrqNum, CMD_END);
        if( ret != NC_SUCCESS )
        {
        	DEBUGMSG(MSGERR, "SGI_%d Isr UnRegister Error\n", IrqNum);
        } 
    }
}

INT32 APACHE_TEST_GIC_CUTMode(void)
{
    INT32 select;
    char buf[16];


    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - GIC       				   \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> SGI (Software Generated Interrupt) Test                \n");   
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_GIC_SGI_Mode();
            break;

            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto GIC_Exit;
        }
    }

GIC_Exit:

    return NC_SUCCESS;
}


#endif


/* End Of File */





