/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_DMA.c
*
*  @brief   : This file is MDA test code for NEXTCHIP standard library
*
*  @author  : Alessio / Automotive SoC Software Team
*
*  @date    : 2016.01.25
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 2016.01.25 - DMA basic test code modified by Alessio
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"
#include "test.h"

#if ENABLE_IP_DMAC

#define __DMA_TEST_MEM_STACK__










/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/
#define TEST_DMA_BUFF_SIZE              1024










/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/
typedef struct _tDMATEST_FLAG
{
    BOOL        Wait;
    eUART_CH    eUARTCh;

} tDMATEST_FLAG, *ptDMATEST_FLAG;










/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/
#ifndef __DMA_TEST_MEM_STACK__ 
UINT8 gTestDMASrcBuff[TEST_DMA_BUFF_SIZE] __attribute__ ((aligned (8)));
UINT8 gTestDMADstBuff[TEST_DMA_BUFF_SIZE] __attribute__ ((aligned (8)));
UINT8 gTestDMAInstBuff[DMA_INST_BUFF_SIZE] __attribute__ ((aligned (8)));
#endif










/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
void __test_DBGMSG(eUART_CH eUARTCh, const char *fmt, ...)
{
    va_list args;
    char buffer[512];

    va_start(args, fmt);

    vsnprintf(buffer, sizeof(buffer), fmt, args);

    va_end(args);

    ncLib_UART_Control(GCMD_UT_PRINT_STRING, eUARTCh, buffer, CMD_END);
}

void __test_dma_byte_display_buff(UINT8 *String, UINT8 *pBuff, UINT32 Size)
{
    UINT32 i;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");	
    DEBUGMSG(MSGINFO, "\n >> %s BuffAddr = 0x%08X", String, pBuff);	
    for(i=0;i<Size;i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", i);	
        DEBUGMSG(MSGINFO, "%02X ", pBuff[i]);	
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");	
}

void __test_dma_dword_display_buff(UINT8 *String, UINT8 *pBuff, UINT32 Size)
{
    UINT32 i;
    UINT32 *pTemp = (UINT32*) pBuff;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");	
    DEBUGMSG(MSGINFO, "\n>> %s BuffAddr = 0x%08X", String, pTemp);	
    for(i=0;i<(Size/4);i++)
    {
        if(!(i%4))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", (i*4));	
        DEBUGMSG(MSGINFO, "%08X ", pTemp[i]);	
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");	
}

void __test_dma_display_info(ptDMA_INFO ptDMAInfo, UINT32 Full)
{
    if(Full)
    {
        DEBUGMSG(MSGINFO, "-------------------------------------------------------------\n");    
        DEBUGMSG(MSGINFO, ">> DMA Info\n");  
        DEBUGMSG(MSGINFO, "    Channel           : DMA_CH%d\n",         ptDMAInfo->dmaCh);	
        DEBUGMSG(MSGINFO, "    burstLen          : DMA_BL_%dXFER\n",    ptDMAInfo->burstLen);	
        DEBUGMSG(MSGINFO, "    burstSize         : DMA_BS_%dB\n",       1<<ptDMAInfo->burstSize);	
        DEBUGMSG(MSGINFO, "    reqType           : DMA_%s\n",           (ptDMAInfo->reqType==DMA_MEM_TO_MEM)?"MEM_TO_MEM":(ptDMAInfo->reqType==DMA_MEM_TO_DEV)?"MEM_TO_DEV":"DEV_TO_MEM");	
        DEBUGMSG(MSGINFO, "    periNum           : %d\n",               ptDMAInfo->periNum);	
        DEBUGMSG(MSGINFO, "    srcAddr           : 0x%08x\n",           ptDMAInfo->srcAddr);	
        DEBUGMSG(MSGINFO, "    dstAddr           : 0x%08x\n",           ptDMAInfo->dstAddr);	
        DEBUGMSG(MSGINFO, "    instBase          : 0x%08x\n",           ptDMAInfo->instBase);	        
        DEBUGMSG(MSGINFO, "    xferBytes         : %d Byte\n",          ptDMAInfo->xferBytes);	
    }
    else
    {
        DEBUGMSG(MSGINFO, "\r >> DMA_CH%d, DMA_BL_%02dXFER, DMA_BS_%dB, DataSize(0x%06x)", ptDMAInfo->dmaCh, ptDMAInfo->burstLen, 1<<ptDMAInfo->burstSize, ptDMAInfo->xferBytes);
    }
}

UINT32 __test_dma_compare_buff(UINT8 *pSrc, UINT8* pDes, UINT32 size)
{
    UINT32 i;
    UINT32 nErrCnt = 0;

    for(i=0; i<size; i++)
    {
        if(*pSrc++ != *pDes++)
        {
            nErrCnt++;
        }
    }

    if(nErrCnt)
        DEBUGMSG(MSGERR, " >> DMA Compare Error Count - %d!\n", nErrCnt);

    return nErrCnt;
}

void __test_dma_dumy_buff_marking(UINT8 *pData, UINT32 data)
{
    pData[0] = (data>>24 & 0xFF);
    pData[1] = (data>>16 & 0xFF);
    pData[2] = (data>>8  & 0xFF);
    pData[3] = (data     & 0xFF);
}

void __test_dma_dumy_buff(UINT8 *pData, UINT32 size, UINT8 data)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        *pData++ = i+data;
    }
}

static void __test_dma_clear_buff(UINT8 *pData, UINT32 size, UINT32 data)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        *pData++ = data;
    }
}

static UINT32 __test_dma_align_size(UINT32 X, UINT32 N)
{
    if( X % N )
        X = (X + (N - (X % N)));

    return X;
}

void APACHE_TEST_DMA_DeviceToMemory_UARTRx_BurstCtrl(BOOL bWaitInsideLib, eUART_CH eUARTCh)
{
    INT32 ret;

    tDMA_INFO tDMAParm;  
    eDMA_CH Channel = DMA_CH0;
    
    UINT32 DataSize;
#ifdef __DMA_TEST_MEM_STACK__ 
    UINT8 DstBuff[TEST_DMA_BUFF_SIZE] __attribute__ ((aligned (8)));
    UINT8 InstBuff[DMA_INST_BUFF_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* DstBuff = (UINT8*)&gTestDMADstBuff[0];
    UINT8* InstBuff = (UINT8*)&gTestDMAInstBuff[0];    
#endif
    
    eDMA_BURST_SIZE BurstSize = DMA_BS_1B;    
    eDMA_BURST_LEN  BurstLength = DMA_BL_1XFER;    

    
#if 0
    /*
    * Open DMA Controller
    */
    ret = ncLib_DMA_Open();
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Open Error!\n");
        return;
    }
#endif


    __test_dma_clear_buff(DstBuff, TEST_DMA_BUFF_SIZE, 0);


    for(Channel=DMA_CH0; Channel<MAX_OF_DMA_CH; Channel++)
    {
        /* Init DMA Channel */
        ret = ncLib_DMA_Control(GCMD_DMA_INIT_CH, Channel, CMD_END);
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "DMA Channel Init Error!\n");
            return;
        }
    }



    // UARTDMACR : DMA Control Register - RxFIFO enable
    ncLib_UART_Control(GCMD_UT_EN_DMA_MODE, eUARTCh, UT_DMAE_RX, CMD_END);
    
    for(Channel=DMA_CH0; Channel<MAX_OF_DMA_CH; Channel++)
    {   
        for(BurstSize=DMA_BS_1B; BurstSize<MAX_OF_DMA_BURST_SIZE; BurstSize++)  
        {
            for(BurstLength=DMA_BL_1XFER; BurstLength<MAX_OF_DMA_BURST_LEN; BurstLength++)  
            {
                DataSize = (BurstLength*(1<<BurstSize));

                tDMAParm.burstLen   = BurstLength;
                tDMAParm.burstSize  = BurstSize;   
                tDMAParm.dmaCh      = Channel;
                tDMAParm.reqType    = DMA_DEV_TO_MEM;
                tDMAParm.xferBytes  = DataSize;
                tDMAParm.dstAddr    = (UINT32)&DstBuff[0];
                tDMAParm.instBase   = (UINT32)&InstBuff[0]; 
                if(eUARTCh == UART_CH0)
                {
                    tDMAParm.periNum    = DMA_UART0_SPI0_RX;
                    tDMAParm.srcAddr    = (UINT32)(APACHE_UART_0_BASE);     
                }
                else
                {
                    tDMAParm.periNum    = DMA_UART1_SPI1_RX;
                    tDMAParm.srcAddr    = (UINT32)(APACHE_UART_1_BASE);    
                }
                __test_dma_display_info(&tDMAParm, 0);
                __test_dma_clear_buff(DstBuff, DataSize, 0); 
                __test_DBGMSG(eUARTCh, "\n Press the Keyboard (%d byte) : ", DataSize);  

                
                if(bWaitInsideLib)
                {
                    ret = ncLib_DMA_Control(GCMD_DMA_TRANSFER, &tDMAParm, CMD_END);
                    if(ret == NC_FAILURE)
                    {
                        DEBUGMSG(MSGERR, "DMA Transfer Error!\n");
                        return;
                    }
                }
                else
                {
                    ret = ncLib_DMA_Control(GCMD_DMA_START, &tDMAParm, CMD_END);
                    if(ret == NC_FAILURE)
                    {
                        DEBUGMSG(MSGERR, "DMA Start Error!\n");
                        return;
                    } 
                    
                    while(ncLib_DMA_Control(GCMD_DMA_DONE, Channel, CMD_END) == NC_FAILURE);
                }
                
                __test_dma_byte_display_buff("DST", DstBuff, DataSize);
            }
        }
    }


    // UARTDMACR : DMA Control Register - RxFIFO Disable
    ncLib_UART_Control(GCMD_UT_DIS_DMA_MODE, eUARTCh, UT_DMAE_RX, CMD_END);



    for(Channel=DMA_CH0; Channel<MAX_OF_DMA_CH; Channel++)
    { 
        /* DeInit DMA Channel */
        ret = ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, Channel, CMD_END);
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "DMA Channel DeInit Error!\n");
            return;
        }
    }



#if 0 
    /*
    * Close DMA Controller
    */
    ret = ncLib_DMA_Close();    
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Close Error!\n");
        return;
    }
#endif
}

void APACHE_TEST_DMA_DeviceToMemory_UARTRx_Basic(BOOL bWaitInsideLib, eUART_CH eUARTCh)
{
    INT32 ret;

    tDMA_INFO tDMAParm;  
    eDMA_CH Channel = DMA_CH0;
    
    UINT32 DataSize;
    UINT32 TestMaxSize = 10;    // 1~10  
#ifdef __DMA_TEST_MEM_STACK__ 
    UINT8 DstBuff[TEST_DMA_BUFF_SIZE] __attribute__ ((aligned (8)));
    UINT8 InstBuff[DMA_INST_BUFF_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* DstBuff = (UINT8*)&gTestDMADstBuff[0];
    UINT8* InstBuff = (UINT8*)&gTestDMAInstBuff[0];    
#endif

#if 0
    /*
    * Open DMA Controller
    */
    ret = ncLib_DMA_Open();
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Open Error!\n");
        return;
    }
#endif


    __test_dma_clear_buff(DstBuff, TEST_DMA_BUFF_SIZE, 0);


    /* Init DMA Channel */
    ret = ncLib_DMA_Control(GCMD_DMA_INIT_CH, Channel, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel Init Error!\n");
        return;
    }



    // UARTDMACR : DMA Control Register - RxFIFO enable
    ncLib_UART_Control(GCMD_UT_EN_DMA_MODE, eUARTCh, UT_DMAE_RX, CMD_END);
    

    for(DataSize=1; DataSize<=TestMaxSize; DataSize++)
    {
        tDMAParm.burstLen   = DMA_BL_1XFER;
        tDMAParm.burstSize  = DMA_BS_1B;
        tDMAParm.dmaCh      = Channel;
        tDMAParm.reqType    = DMA_DEV_TO_MEM;
        tDMAParm.xferBytes  = DataSize;
        tDMAParm.dstAddr    = (UINT32)&DstBuff[0];
        tDMAParm.instBase   = (UINT32)&InstBuff[0]; 
        if(eUARTCh == UART_CH0)
        {
            tDMAParm.periNum    = DMA_UART0_SPI0_RX;
            tDMAParm.srcAddr    = (UINT32)(APACHE_UART_0_BASE);
        }
        else
        {
            tDMAParm.periNum    = DMA_UART1_SPI1_RX;
            tDMAParm.srcAddr    = (UINT32)(APACHE_UART_1_BASE);
        }
        __test_dma_display_info(&tDMAParm, 0);
        __test_dma_clear_buff(DstBuff, DataSize, 0); 
        __test_DBGMSG(eUARTCh, "\n Press the Keyboard (%d byte) : ", DataSize); 

        
        if(bWaitInsideLib)
        {
            ret = ncLib_DMA_Control(GCMD_DMA_TRANSFER, &tDMAParm, CMD_END);
            if(ret == NC_FAILURE)
            {
                DEBUGMSG(MSGERR, "DMA Transfer Error!\n");
                return;
            }
        }
        else
        {
            ret = ncLib_DMA_Control(GCMD_DMA_START, &tDMAParm, CMD_END);
            if(ret == NC_FAILURE)
            {
                DEBUGMSG(MSGERR, "DMA Start Error!\n");
                return;
            } 
            
            while(ncLib_DMA_Control(GCMD_DMA_DONE, Channel, CMD_END) == NC_FAILURE);
        }
        
        __test_dma_byte_display_buff("DST", DstBuff, DataSize);
    }


    // UARTDMACR : DMA Control Register - RxFIFO Disable
    ncLib_UART_Control(GCMD_UT_DIS_DMA_MODE, eUARTCh, UT_DMAE_RX, CMD_END);



    /* DeInit DMA Channel */
    ret = ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, Channel, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel DeInit Error!\n");
        return;
    }



#if 0 
    /*
    * Close DMA Controller
    */
    ret = ncLib_DMA_Close();    
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Close Error!\n");
        return;
    }
#endif
}


void APACHE_TEST_DMA_MemoryToDevice_UARTTx_BurstCtrl(BOOL bWaitInsideLib, eUART_CH eUARTCh)
{
    INT32 ret;

    tDMA_INFO tDMAParm;  
    eDMA_CH Channel = DMA_CH0; 
    
    UINT32 DataSize;
    UINT32 TestMaxSize = 26;    // A~Z
    UINT32 AlignDataSize;
#ifdef __DMA_TEST_MEM_STACK__ 
    UINT8 SrcBuff[TEST_DMA_BUFF_SIZE] __attribute__ ((aligned (8)));
    UINT8 InstBuff[DMA_INST_BUFF_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* SrcBuff = (UINT8*)&gTestDMASrcBuff[0];
    UINT8* InstBuff = (UINT8*)&gTestDMAInstBuff[0];    
#endif

    eDMA_BURST_SIZE BurstSize = DMA_BS_1B;     
    eDMA_BURST_LEN  BurstLength = DMA_BL_1XFER;     

    
#if 0
    /*
    * Open DMA Controller
    */
    ret = ncLib_DMA_Open();
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Open Error!\n");
        return;
    }
#endif


    __test_dma_clear_buff(SrcBuff, TEST_DMA_BUFF_SIZE, '0');
    __test_dma_dumy_buff(SrcBuff, TestMaxSize, 'A');



    for(Channel=DMA_CH0; Channel<MAX_OF_DMA_CH; Channel++)
    {
        /* Init DMA Channel */
        ret = ncLib_DMA_Control(GCMD_DMA_INIT_CH, Channel, CMD_END);
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "DMA Channel Init Error!\n");
            return;
        }
    }


    // UARTDMACR : DMA Control Register - TxFIFO enable
    ncLib_UART_Control(GCMD_UT_EN_DMA_MODE, eUARTCh, UT_DMAE_TX, CMD_END);
    
    for(Channel=DMA_CH0; Channel<MAX_OF_DMA_CH; Channel++)
    {   
        for(BurstSize=DMA_BS_1B; BurstSize<MAX_OF_DMA_BURST_SIZE; BurstSize++)  
        {
            for(BurstLength=DMA_BL_1XFER; BurstLength<MAX_OF_DMA_BURST_LEN; BurstLength++)  
            {   
                DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");    
                AlignDataSize = __test_dma_align_size(TestMaxSize, (BurstLength*(1<<BurstSize)));
                for(DataSize=(BurstLength*(1<<BurstSize)); DataSize<=AlignDataSize; DataSize+=(BurstLength*(1<<BurstSize)))
                {
                    tDMAParm.burstLen   = BurstLength;
                    tDMAParm.burstSize  = BurstSize;
                    tDMAParm.dmaCh      = Channel;
                    tDMAParm.reqType    = DMA_MEM_TO_DEV;
                    tDMAParm.xferBytes  = DataSize;
                    tDMAParm.srcAddr    = (UINT32)&SrcBuff[0];
                    tDMAParm.instBase   = (UINT32)&InstBuff[0];    
                    if(eUARTCh == UART_CH0)
                    {
                        tDMAParm.periNum = DMA_UART0_SPI0_TX;
                        tDMAParm.dstAddr = (UINT32)(APACHE_UART_0_BASE);
                    }
                    else
                    {
                        tDMAParm.periNum = DMA_UART1_SPI1_TX;
                        tDMAParm.dstAddr = (UINT32)(APACHE_UART_1_BASE);
                    }
                    __test_dma_display_info(&tDMAParm ,0);
                    __test_DBGMSG(eUARTCh, "\n    UART%d Tx >> ", eUARTCh);

                    
                    if(bWaitInsideLib)
                    {
                        ret = ncLib_DMA_Control(GCMD_DMA_TRANSFER, &tDMAParm, CMD_END);
                        if(ret == NC_FAILURE)
                        {
                            DEBUGMSG(MSGERR, "DMA Transfer Error!\n");
                            return;
                        }
                    }
                    else
                    {
                        ret = ncLib_DMA_Control(GCMD_DMA_START, &tDMAParm, CMD_END);
                        if(ret == NC_FAILURE)
                        {
                            DEBUGMSG(MSGERR, "DMA Start Error!\n");
                            return;
                        } 
                        
                        while(ncLib_DMA_Control(GCMD_DMA_DONE, Channel, CMD_END) == NC_FAILURE);
                    }
                    
                    if(eUARTCh == UART_CH0)
                        DEBUGMSG(MSGINFO, "\n");
                    APACHE_SYS_mDelay(10);
                }
            }
        }
    }

    // UARTDMACR : DMA Control Register - TxFIFO Disable
    ncLib_UART_Control(GCMD_UT_DIS_DMA_MODE, eUARTCh, UT_DMAE_TX, CMD_END);



    for(Channel=DMA_CH0; Channel<MAX_OF_DMA_CH; Channel++)
    {      
        /* DeInit DMA Channel */
        ret = ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, Channel, CMD_END);
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "DMA Channel DeInit Error!\n");
            return;
        }
    }



#if 0 
    /*
    * Close DMA Controller
    */
    ret = ncLib_DMA_Close();    
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Close Error!\n");
        return;
    }
#endif
}

void APACHE_TEST_DMA_MemoryToDevice_UARTTx_Basic(BOOL bWaitInsideLib, eUART_CH eUARTCh)
{
    INT32 ret;

    tDMA_INFO tDMAParm;  
    eDMA_CH Channel = DMA_CH0;
    
    UINT32 DataSize;
    UINT32 TestMaxSize = 26;    // A~Z    
#ifdef __DMA_TEST_MEM_STACK__ 
    UINT8 SrcBuff[TEST_DMA_BUFF_SIZE] __attribute__ ((aligned (8)));
    UINT8 InstBuff[DMA_INST_BUFF_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* SrcBuff = (UINT8*)&gTestDMASrcBuff[0];
    UINT8* InstBuff = (UINT8*)&gTestDMAInstBuff[0];    
#endif


#if 0
    /*
    * Open DMA Controller
    */
    ret = ncLib_DMA_Open();
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Open Error!\n");
        return;
    }
#endif


    __test_dma_clear_buff(SrcBuff, TEST_DMA_BUFF_SIZE, '0');
    __test_dma_dumy_buff(SrcBuff, TestMaxSize, 'A');



    /* Init DMA Channel */
    ret = ncLib_DMA_Control(GCMD_DMA_INIT_CH, Channel, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel Init Error!\n");
        return;
    }


    // UARTDMACR : DMA Control Register - TxFIFO enable
    ncLib_UART_Control(GCMD_UT_EN_DMA_MODE, eUARTCh, UT_DMAE_TX, CMD_END);
    

    for(DataSize=1; DataSize<=TestMaxSize; DataSize++)
    {
        tDMAParm.burstLen   = DMA_BL_1XFER;
        tDMAParm.burstSize  = DMA_BS_1B;
        tDMAParm.dmaCh      = Channel;
        tDMAParm.reqType    = DMA_MEM_TO_DEV;
        tDMAParm.xferBytes  = DataSize;
        tDMAParm.srcAddr    = (UINT32)&SrcBuff[0];
        tDMAParm.instBase   = (UINT32)&InstBuff[0];            
        if(eUARTCh == UART_CH0)
        {
            tDMAParm.periNum    = DMA_UART0_SPI0_TX;
            tDMAParm.dstAddr    = (UINT32)(APACHE_UART_0_BASE);
        }
        else
        {
            tDMAParm.periNum    = DMA_UART1_SPI1_TX;
            tDMAParm.dstAddr    = (UINT32)(APACHE_UART_1_BASE); 
        }
        __test_dma_display_info(&tDMAParm, 0);
        __test_DBGMSG(eUARTCh, "\n    UART%d Tx >> ", eUARTCh);

        
        if(bWaitInsideLib)
        {
            ret = ncLib_DMA_Control(GCMD_DMA_TRANSFER, &tDMAParm, CMD_END);
            if(ret == NC_FAILURE)
            {
                DEBUGMSG(MSGERR, "DMA Transfer Error!\n");
                return;
            }
        }
        else
        {
            ret = ncLib_DMA_Control(GCMD_DMA_START, &tDMAParm, CMD_END);
            if(ret == NC_FAILURE)
            {
                DEBUGMSG(MSGERR, "DMA Start Error!\n");
                return;
            } 
            
            while(ncLib_DMA_Control(GCMD_DMA_DONE, Channel, CMD_END) == NC_FAILURE);
        }

        if(eUARTCh == UART_CH0)
            DEBUGMSG(MSGINFO, "\n");
        APACHE_SYS_mDelay(10);
    }


    // UARTDMACR : DMA Control Register - TxFIFO Disable
    ncLib_UART_Control(GCMD_UT_DIS_DMA_MODE, eUARTCh, UT_DMAE_TX, CMD_END);


     
    /* DeInit DMA Channel */
    ret = ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, Channel, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel DeInit Error!\n");
        return;
    }



#if 0 
    /*
    * Close DMA Controller
    */
    ret = ncLib_DMA_Close();    
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Close Error!\n");
        return;
    }
#endif
}

void APACHE_TEST_DMA_MemoryToMemory_Full(BOOL bWaitInsideLib)
{
    INT32 ret;   

    tDMA_INFO tDMAParm;
    eDMA_CH Channel = DMA_CH0;
    eDMA_BURST_LEN BurstLength = DMA_BL_1XFER;    
    eDMA_BURST_SIZE BurstSize = DMA_BS_1B;     
    
    UINT32 DataSize;
    UINT32 TestMaxSize = (3*MB);
    UINT8 *SrcBuff  = (UINT8*)(APACHE_DRAM_BASE+(1*MB));
    UINT8 *DstBuff  = (UINT8*)(APACHE_DRAM_BASE+(4*MB));
    UINT8 *InstBuff = (UINT8*)(APACHE_DRAM_BASE+(7*MB));


    // DDR Init Check.
    if( !(ncLib_SCU_Control(GCMD_SCU_GET_DATA, 0x000C, CMD_END) & 0x03) )
    {
        DEBUGMSG(MSGERR, "Please DDR Initialize\n");
        return;
    }


    // DDR Memory Base Addr (0x08000000 or 0x00000000) Check
    if( ncLib_SCU_Control(GCMD_SCU_GET_DATA, 0x001C, CMD_END) & 0x01 )
    {
        DEBUGMSG(MSGERR, " DDR Remap Status - Memory Base 0x00000000\n");
        // 0x00000000 ~ 0x00040000      // Code ER_RO/ER_RW Zone
        // 0x00040000 ~ 0x00100000      // ER_ZI and Buff Zone
        // 0x00100000 ~ 0x00800000      // Buff Zone
        SrcBuff  = (UINT8*)(1*MB);      // 0x00100000
        DstBuff  = (UINT8*)(4*MB);      // 0x00400000
        InstBuff = (UINT8*)(7*MB);      // 0x00700000
    }

    
#if 0
    ret = ncLib_DMA_Open();
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Open Error!\n");
        return;
    }
#endif


    for(Channel=DMA_CH0; Channel<MAX_OF_DMA_CH; Channel++)
    {
        ret = ncLib_DMA_Control(GCMD_DMA_INIT_CH, Channel, CMD_END);
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "DMA Channel Init Error!\n");
            return;
        }


        __test_dma_dumy_buff(SrcBuff, (3*MB), Channel);


        for(BurstSize=DMA_BS_1B; BurstSize<MAX_OF_DMA_BURST_SIZE; BurstSize++)  
        {
            for(BurstLength=DMA_BL_1XFER; BurstLength<MAX_OF_DMA_BURST_LEN; BurstLength++)
            {  
                for(DataSize=(BurstLength*(1<<BurstSize)); DataSize<=TestMaxSize; DataSize+=(BurstLength*(1<<BurstSize))) 
                {
                    __test_dma_dumy_buff_marking(SrcBuff, (BurstLength*(1<<BurstSize)*DataSize));
                    //__test_dma_byte_display_buff("SRC", SrcBuff, 0x100);
                
                    tDMAParm.burstLen   = BurstLength;
                    tDMAParm.burstSize  = BurstSize; 
                    tDMAParm.dmaCh      = Channel;
                    tDMAParm.reqType    = DMA_MEM_TO_MEM;
                    tDMAParm.periNum    = (eDMA_PERI_NUM)NULL;          // don't care for memory to memory
                    tDMAParm.xferBytes  = DataSize; 
                    tDMAParm.srcAddr    = (UINT32)&SrcBuff[0];
                    tDMAParm.dstAddr    = (UINT32)&DstBuff[0];
                    tDMAParm.instBase   = (UINT32)&InstBuff[0];    
                    __test_dma_display_info(&tDMAParm ,0);

                    if(bWaitInsideLib)
                    {
                        ret = ncLib_DMA_Control(GCMD_DMA_TRANSFER, &tDMAParm, CMD_END);
                        if(ret == NC_FAILURE)
                        {
                            DEBUGMSG(MSGERR, "DMA Transfer Error!\n");
                            return;
                        }
                    }
                    else
                    {
                        ret = ncLib_DMA_Control(GCMD_DMA_START, &tDMAParm, CMD_END);
                        if(ret == NC_FAILURE)
                        {
                            DEBUGMSG(MSGERR, "DMA Start Error!\n");
                            return;
                        } 
                        
                        while(ncLib_DMA_Control(GCMD_DMA_DONE, Channel, CMD_END) == NC_FAILURE);
                    }


                    __test_dma_compare_buff(SrcBuff, DstBuff, DataSize);
                    //__test_dma_byte_display_buff("DST", DstBuff, 0x100);
                }
            }
        }



        ret = ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, Channel, CMD_END);
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "DMA Channel DeInit Error!\n");
            return;
        }
    }


#if 0
    ret = ncLib_DMA_Close();    
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Close Error!\n");
        return;
    }
#endif
}

void APACHE_TEST_DMA_MemoryToMemory_BurstCtrl(BOOL bWaitInsideLib)
{
    INT32 ret;   

    tDMA_INFO tDMAParm;
    eDMA_CH Channel = DMA_CH0;
    eDMA_BURST_LEN BurstLength = DMA_BL_1XFER;    
    eDMA_BURST_SIZE BurstSize = DMA_BS_1B;     
    
    UINT32 DataSize;
    UINT32 TestMaxSize = TEST_DMA_BUFF_SIZE;
#ifdef __DMA_TEST_MEM_STACK__ 
    UINT8 SrcBuff[TEST_DMA_BUFF_SIZE] __attribute__ ((aligned (8)));
    UINT8 DstBuff[TEST_DMA_BUFF_SIZE] __attribute__ ((aligned (8)));
    UINT8 InstBuff[DMA_INST_BUFF_SIZE] __attribute__ ((aligned (8)));
#else
    UINT8* SrcBuff = (UINT8*)&gTestDMASrcBuff[0];
    UINT8* DstBuff = (UINT8*)&gTestDMADstBuff[0];
    UINT8* InstBuff = (UINT8*)&gTestDMAInstBuff[0];    
#endif


#if 0
    ret = ncLib_DMA_Open();
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Open Error!\n");
        return;
    }
#endif

        
    ret = ncLib_DMA_Control(GCMD_DMA_INIT_CH, Channel, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel Init Error!\n");
        return;
    }



    for(BurstSize=DMA_BS_1B; BurstSize<MAX_OF_DMA_BURST_SIZE; BurstSize++)  
    {
        for(BurstLength=DMA_BL_1XFER; BurstLength<MAX_OF_DMA_BURST_LEN; BurstLength++)
        {  
            for(DataSize=(BurstLength*(1<<BurstSize)); DataSize<=TestMaxSize; DataSize+=(BurstLength*(1<<BurstSize)))    
            {
                //__test_dma_clear_buff(SrcBuff, 0x100, 0x00);
                //__test_dma_clear_buff(DstBuff, 0x100, 0x00);
                
                __test_dma_dumy_buff(SrcBuff, DataSize, BurstLength*(1<<BurstSize));
                //__test_dma_byte_display_buff("SRC", SrcBuff, 0x100);
                
                tDMAParm.burstLen   = BurstLength;
                tDMAParm.burstSize  = BurstSize; 
                tDMAParm.dmaCh      = Channel;
                tDMAParm.reqType    = DMA_MEM_TO_MEM;
                tDMAParm.periNum    = (eDMA_PERI_NUM)NULL;          // don't care for memory to memory
                tDMAParm.xferBytes  = DataSize; 
                tDMAParm.srcAddr    = (UINT32)&SrcBuff[0];
                tDMAParm.dstAddr    = (UINT32)&DstBuff[0];
                tDMAParm.instBase   = (UINT32)&InstBuff[0];    
                __test_dma_display_info(&tDMAParm ,0);

                if(bWaitInsideLib)
                {
                    ret = ncLib_DMA_Control(GCMD_DMA_TRANSFER, &tDMAParm, CMD_END);
                    if(ret == NC_FAILURE)
                    {
                        DEBUGMSG(MSGERR, "DMA Transfer Error!\n");
                        return;
                    }
                }
                else
                {
                    ret = ncLib_DMA_Control(GCMD_DMA_START, &tDMAParm, CMD_END);
                    if(ret == NC_FAILURE)
                    {
                        DEBUGMSG(MSGERR, "DMA Start Error!\n");
                        return;
                    } 
                    
                    while(ncLib_DMA_Control(GCMD_DMA_DONE, Channel, CMD_END) == NC_FAILURE);
                }


                __test_dma_compare_buff(SrcBuff, DstBuff, DataSize);
                //__test_dma_byte_display_buff("DST", DstBuff, 0x100);
            }
        }
    }



    ret = ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, Channel, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel DeInit Error!\n");
        return;
    }


#if 0
    ret = ncLib_DMA_Close();    
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Close Error!\n");
        return;
    }
#endif
}

void APACHE_TEST_DMA_MemoryToMemory_Basic(BOOL bWaitInsideLib)
{
    INT32 ret;   

    tDMA_INFO tDMAParm;  
    eDMA_CH Channel = DMA_CH0;
    UINT32 DataSize = TEST_DMA_BUFF_SIZE;
#ifdef __DMA_TEST_MEM_STACK__ 
    UINT8 SrcBuff[TEST_DMA_BUFF_SIZE] __attribute__ ((aligned (8)));
    UINT8 DstBuff[TEST_DMA_BUFF_SIZE] __attribute__ ((aligned (8)));
    UINT8 InstBuff[DMA_INST_BUFF_SIZE] __attribute__ ((aligned (8)));    
#else
    UINT8* SrcBuff = (UINT8*)&gTestDMASrcBuff[0];
    UINT8* DstBuff = (UINT8*)&gTestDMADstBuff[0];
    UINT8* InstBuff = (UINT8*)&gTestDMAInstBuff[0];      
#endif


#if 0
    /*
    * Open DMA Controller
    */
    ret = ncLib_DMA_Open();
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Open Error!\n");
        return;
    }
#endif


    /*
    * Init DMA Channel
    */
    ret = ncLib_DMA_Control(GCMD_DMA_INIT_CH, Channel, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel Init Error!\n");
        return;
    }



    __test_dma_dumy_buff(SrcBuff, DataSize, Channel);
    //__test_dma_byte_display_buff("SRC", SrcBuff, 0x100);
    __test_dma_clear_buff(DstBuff, DataSize, 0);


    tDMAParm.burstLen   = DMA_BL_1XFER;
    tDMAParm.burstSize  = DMA_BS_1B; 
    tDMAParm.dmaCh      = Channel;
    tDMAParm.reqType    = DMA_MEM_TO_MEM;
    tDMAParm.periNum    = (eDMA_PERI_NUM)NULL;          // don't care for memory to memory
    tDMAParm.xferBytes  = DataSize;    
    tDMAParm.srcAddr    = (UINT32)&SrcBuff[0];
    tDMAParm.dstAddr    = (UINT32)&DstBuff[0];
    tDMAParm.instBase   = (UINT32)&InstBuff[0];    
    __test_dma_display_info(&tDMAParm ,1);

    if(bWaitInsideLib)
    {
        ret = ncLib_DMA_Control(GCMD_DMA_TRANSFER, &tDMAParm, CMD_END);
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "DMA Transfer Error!\n");
            return;
        }
    }
    else
    {
        ret = ncLib_DMA_Control(GCMD_DMA_START, &tDMAParm, CMD_END);
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "DMA Start Error!\n");
            return;
        } 
        
        while(ncLib_DMA_Control(GCMD_DMA_DONE, Channel, CMD_END) == NC_FAILURE);
    }


    __test_dma_compare_buff(SrcBuff, DstBuff, DataSize);
    //__test_dma_byte_display_buff("DST", DstBuff, 0x100);




    /*
    * DeInit DMA Channel
    */
    ret = ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, Channel, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel DeInit Error!\n");
        return;
    }


#if 0 
    /*
    * Close DMA Controller
    */
    ret = ncLib_DMA_Close();    
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Close Error!\n");
        return;
    }
#endif
}


INT32 APACHE_TEST_DMA_CUIMode(void)
{
    tDMATEST_FLAG tDMATestFlag = { FALSE, UART_CH0 };    
    INT32 select;
    char buf[256];

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - DMA                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " DMA Controller                                             \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");    
        DEBUGMSG(MSGINFO, " Memory To Memory                                           \n");        
        DEBUGMSG(MSGINFO, " <1> MemCopy Basic                                          \n");
        DEBUGMSG(MSGINFO, " <2> MemCopy BurstSize, BurstLen Change Test                \n");
        DEBUGMSG(MSGINFO, " <3> MemCopy Full Test (long Time)                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Memory To Device                                           \n");  
        DEBUGMSG(MSGINFO, " <4> UART%d Tx Basic                                        \n", tDMATestFlag.eUARTCh);
        DEBUGMSG(MSGINFO, " <5> UART%d Tx BurstSize Change Test                        \n", tDMATestFlag.eUARTCh);
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Device To Memory                                           \n");  
        DEBUGMSG(MSGINFO, " <6> UART%d Rx Basic                                        \n", tDMATestFlag.eUARTCh);
        DEBUGMSG(MSGINFO, " <7> UART%d Rx BurstSize Test                               \n", tDMATestFlag.eUARTCh);      
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <8> DMA Wait Mode Change : %sLib Mode                      \n", (tDMATestFlag.Wait)?"InSide":"OutSide"); 
        DEBUGMSG(MSGINFO, " <9> UART Port Change     : UART%d                          \n", tDMATestFlag.eUARTCh);         
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_DMA_MemoryToMemory_Basic(tDMATestFlag.Wait);
            break;

            case 2:
                APACHE_TEST_DMA_MemoryToMemory_BurstCtrl(tDMATestFlag.Wait);
            break;

            case 3:
                APACHE_TEST_DMA_MemoryToMemory_Full(tDMATestFlag.Wait);
            break;

            case 4:
                APACHE_TEST_DMA_MemoryToDevice_UARTTx_Basic(tDMATestFlag.Wait, tDMATestFlag.eUARTCh);
            break;

            case 5:
                APACHE_TEST_DMA_MemoryToDevice_UARTTx_BurstCtrl(tDMATestFlag.Wait, tDMATestFlag.eUARTCh);
            break;

            case 6:
                APACHE_TEST_DMA_DeviceToMemory_UARTRx_Basic(tDMATestFlag.Wait, tDMATestFlag.eUARTCh);
            break;

            case 7:
                APACHE_TEST_DMA_DeviceToMemory_UARTRx_BurstCtrl(tDMATestFlag.Wait, tDMATestFlag.eUARTCh);
            break;
            
            case 8:
                tDMATestFlag.Wait = (tDMATestFlag.Wait == FALSE) ? TRUE : FALSE;
            break;
            
            case 9:
                tDMATestFlag.eUARTCh = (tDMATestFlag.eUARTCh == UART_CH0) ? UART_CH1 : UART_CH0;
            break;
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to sub menu\n");
            goto DMA_Exit;
        }
    }

DMA_Exit:

    return NC_SUCCESS;
}



#endif /* ENABLE_IP_DMA */

/* End Of File */
