/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_SSP.c
*
*  @brief   :
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"


#if ENABLE_IP_SPI


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

/* 
********************************************************************************
* FPGA DB Version
* r560-a1_2016_0126             SSP1
* r560-a8_2016_0131             SSP1
* r627-a1_2016_0204             SSP1
* r730-a1_2016_0222             SSP0
********************************************************************************
*/
#define FPGA_SSP_CH             0










/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/
#define TEST_CMD_sFlash_PAGE_PROGRAM				0x02
#define TEST_CMD_sFlash_RD_DATA						0x03
#define TEST_CMD_sFlash_WR_DS						0x04
#define TEST_CMD_sFlash_RD_STS						0x05
#define TEST_CMD_sFlash_WR_EN						0x06
#define TEST_CMD_sFlash_SECTOR_ERASE				0x20
#define TESTCMD_sFlash_BLOCK_ERASE					0xD8
#define TEST_CMD_sFlash_RD_IDENTIFICATION			0x9F

#define TEST_STS_WIP								(0x1<<0)
#define TEST_STS_WEL								(0x1<<1)

#define TEST_sFlash_BLOCK_SIZE						(64*KB)
#define TEST_sFlash_SECTOR_SIZE						(4*KB)
#define TEST_sFlash_PAGE_SIZE						(256)










/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
UINT8 __reverse_byte(UINT8 byte)
{
    UINT8 i;
    UINT8 byte_rev   = 0x0;
    const UINT8 BIT8[8]    = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
    const UINT8 BIT8REV[8] = {0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01};

    for(i=0;i<8;i++)
    {
        if(byte&BIT8[i]) byte_rev |= BIT8REV[i];
    }

    return byte_rev;
}

void __test_imx_write(UINT32 nChNum, UINT8 ChipID, UINT8 Addr, UINT8 Data)
{
    UINT8 Command[3];
    
    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, nChNum, CMD_END);	

    Command[0] = __reverse_byte(ChipID);
    Command[1] = __reverse_byte(Addr);
    Command[2] = __reverse_byte(Data);
    ncLib_SSP_Write(nChNum, Command, 3);

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, nChNum, CMD_END);	
}

UINT8 __test_imx_read(UINT32 nChNum, UINT8 ChipID, UINT8 Addr)
{
    UINT8 Command[2];    
    UINT8 Data;
    
    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, nChNum, CMD_END);	

    Command[0] = __reverse_byte(((1<<7)|ChipID));
    Command[1] = __reverse_byte(Addr);
    ncLib_SSP_Write(nChNum, Command, 2);
    ncLib_SSP_Read(nChNum, &Data, 1);    

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, nChNum, CMD_END);	

    return __reverse_byte(Data);
}

void __test_imx_hwreset(void)
{
    eGPIO_GROUP group = GPIO_GROUP_A;
    eGPIO_PORT  port  = GPIO_PORT20;

    // Set GPIO OUTPUT
    ncLib_GPIO_Control(GCMD_GPIO_ENA, group, port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, group, port, GPIO_DIR_OUT, CMD_END);

    // HIGH
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, group, port, GPIO_HIGH, CMD_END);
    APACHE_SYS_mDelay(100);

    // LOW
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, group, port, GPIO_LOW, CMD_END);
    APACHE_SYS_mDelay(100);

    // HIGH
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, group, port, GPIO_HIGH, CMD_END);
    APACHE_SYS_mDelay(100);
}


void __test_imx_regdump(UINT32 nChNum, UINT8  ChipID)
{
    UINT8  Addr;
    
    for(Addr=0; Addr<0xFF; Addr++)
    {
        DEBUGMSG(MSGINFO, " IMX_Bank%d : Addr[0x%02X] Reg[0x%02X]\n", ChipID, Addr, __test_imx_read(nChNum, ChipID, Addr));
    }
}

void __test_sflash_display_buff( UINT8 *pBuff, UINT32 Size, UINT32 PageAddr)
{
    UINT32 i;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");	
    DEBUGMSG(MSGINFO, "\n>> PageAddr = 0x%08X", PageAddr);	
    for(i=0;i<Size;i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", i);	
        DEBUGMSG(MSGINFO, "%02X ", pBuff[i]);	
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");	
}


UINT32 __test_sflash_compare_buff(UINT8 *pSrc, UINT8* pDes, UINT32 size)
{
    UINT32 i;
    UINT32 nErrCnt = 0;

    for(i=0; i<size; i++)
    {
        if(*pSrc++ != *pDes++)
        {
            nErrCnt++;
        }
    }

    if(nErrCnt)
        DEBUGMSG(MSGERR, " >> Compare Error Count - %d!\n", nErrCnt);	

    return nErrCnt;
}

static UINT32 __test_sflash_memory_size(UINT8 Capacity)
{
    UINT32 nChipSize = 64*KB;
    UINT32 i;

    for(i = 0; i <= 8; i++)
    {
        if(Capacity == i)
        {
            break;
        }
        else
        {
            nChipSize = nChipSize * 2;
        }
    }

    return nChipSize;
}

void __test_sflash_dumy_buff(UINT8 *pData, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        *pData++ = i;
    }
}

void __test_sflash_buff_pageaddr_marking(UINT8 *pData, UINT32 PageAddr)
{
    pData[0] = (PageAddr>>24 & 0xFF);
    pData[1] = (PageAddr>>16 & 0xFF);
    pData[2] = (PageAddr>>8  & 0xFF);
    pData[3] = (PageAddr     & 0xFF);
}

void __test_sflash_clear_buff(UINT8 *pData, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        *pData++ = 0;
    }
}

UINT8 __test_sflash_readstatus(UINT32 nChNum)
{
    UINT8 Command;
    UINT8 Status;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, nChNum, CMD_END);	

    Command = TEST_CMD_sFlash_RD_STS;
    ncLib_SSP_Write(nChNum, &Command, 1);	
    ncLib_SSP_Read(nChNum, &Status, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, nChNum, CMD_END);	

    return Status;
}

void __test_sflash_writedisable(UINT32 nChNum)
{
    UINT8 Command;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, nChNum, CMD_END);	

    Command = TEST_CMD_sFlash_WR_DS;
    ncLib_SSP_Write(nChNum, &Command, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, nChNum, CMD_END);	
}

void __test_sflash_writeenable(UINT32 nChNum)
{
    UINT8 Command;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, nChNum, CMD_END);	

    Command = TEST_CMD_sFlash_WR_EN;
    ncLib_SSP_Write(nChNum, &Command, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, nChNum, CMD_END);	

    while( (__test_sflash_readstatus(nChNum) & TEST_STS_WEL) != TEST_STS_WEL ) ;
}

void __test_sflash_waitwip(UINT32 nChNum)
{
    while(__test_sflash_readstatus(nChNum) & TEST_STS_WIP) ;
}

void __test_sflash_readid(UINT32 nChNum, UINT8 *pBuff)
{
    UINT8 Command;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, nChNum, CMD_END);	

    Command = TEST_CMD_sFlash_RD_IDENTIFICATION;
    ncLib_SSP_Write(nChNum, &Command, 1);	
    ncLib_SSP_Read(nChNum, pBuff, 3);		

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, nChNum, CMD_END);		
}

void __test_sflash_sectorerase(UINT32 nChNum, UINT32 SectorAddr)
{
    UINT8 Command[4];

    __test_sflash_waitwip(nChNum);
    __test_sflash_writeenable(nChNum);


    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, nChNum, CMD_END);	

    Command[0] = TEST_CMD_sFlash_SECTOR_ERASE;
    Command[1] = (SectorAddr>>16 & 0xFF);
    Command[2] = (SectorAddr>>8  & 0xFF);
    Command[3] = (SectorAddr     & 0xFF);
    ncLib_SSP_Write(nChNum, Command, 4);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, nChNum, CMD_END);	


    __test_sflash_waitwip(nChNum);
    __test_sflash_writedisable(nChNum);
}

void __test_sflash_blockerase(UINT32 nChNum, UINT32 BlockAddr)
{
    UINT8 Command[4];

    __test_sflash_waitwip(nChNum);
    __test_sflash_writeenable(nChNum);


    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, nChNum, CMD_END);	

    Command[0] = TESTCMD_sFlash_BLOCK_ERASE;
    Command[1] = (BlockAddr>>16 & 0xFF);
    Command[2] = (BlockAddr>>8  & 0xFF);
    Command[3] = (BlockAddr     & 0xFF);
    ncLib_SSP_Write(nChNum, Command, 4);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, nChNum, CMD_END);	


    __test_sflash_waitwip(nChNum);
    __test_sflash_writedisable(nChNum);
}

void __test_sflash_writepage(UINT32 nChNum, UINT32 PageAddr, UINT8 *pBuff)
{
    UINT8 Command[4];

    __test_sflash_waitwip(nChNum);
    __test_sflash_writeenable(nChNum);


    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, nChNum, CMD_END);	

    Command[0] = TEST_CMD_sFlash_PAGE_PROGRAM;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);
    ncLib_SSP_Write(nChNum, Command, 4);	
    ncLib_SSP_Write(nChNum, pBuff, TEST_sFlash_PAGE_SIZE);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, nChNum, CMD_END);	


    __test_sflash_waitwip(nChNum);
    __test_sflash_writedisable(nChNum);


}

void __test_sflash_readpage(UINT32 nChNum, UINT32 PageAddr, UINT8 *pBuff)
{
    UINT8 Command[4];

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, nChNum, CMD_END);	

    Command[0] = TEST_CMD_sFlash_RD_DATA;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);
    ncLib_SSP_Write(nChNum, Command, 4);		
    ncLib_SSP_Read(nChNum, pBuff, TEST_sFlash_PAGE_SIZE);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, nChNum, CMD_END);	
}

void APACHE_TEST_SSP_Init(UINT32 nChNum)
{
    INT32 ret;
    tSSP_INIT_PARAM tSSPParam;


    /*
    * Open Synchronous Serial Port Interface.
    */
    ret = ncLib_SSP_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_SSPI, CMD_END));	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "SSP Open Error!\n");
    }


    /*
    * Init SSP Channel
    */
    tSSPParam.mFormat       = SSP_FMT_SPI;
    tSSPParam.mMode         = SSP_MODE_MASTER;
    tSSPParam.mDataWidth    = SSP_DS_8BIT;
    tSSPParam.mBitRate      = 1;
    tSSPParam.mTxIntEn      = FALSE; 
    tSSPParam.mRxIntEn      = FALSE;
    tSSPParam.mSPO          = SSP_SPO_HIGH;
    tSSPParam.mSPH          = SSP_SPH_HIGH;	
    ret = ncLib_SSP_Control(GCMD_SSP_INIT_CH, nChNum, &tSSPParam, CMD_END);	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "SSP Init Error!\n");
    } 
}

void APACHE_TEST_SSP_DeInit(UINT32 nChNum)
{
    INT32 ret;


    /*
    * Deinit SSP Channel
    */
    ret = ncLib_SSP_Control(GCMD_SSP_DEINIT_CH, nChNum, CMD_END);	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "SSP DeInit Error!\n");
    } 


    /*
    * Close Synchronous Serial Port Interface.
    */
    ret = ncLib_SSP_Close();	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "SSP Close Error!\n");
    }
}

void APACHE_TEST_SSP_IMX136_LVDSInit(void)
{
    //// 1080p F-HD 30p Serial 4CH LVDS Setting
    const UINT8 IMX136_ID02_1[35] = {
        0x01,0x00,0x01,0x00,0x10,0x01,0x00,0x10,0x10,0x01,0x00,0x00,0x00,0x20,0x01,0x01,	//0 4Ch LVDS
        0x01,0x00,0xF0,0x00,0x00,0x00,0x08,0x00,0x65,0x04,0x00,0x98,0x08,0x26,0X02,0x00,	//1 30p set
        0x00,0x00,0x00																		                                //2
    };

    const UINT8 IMX136_ID02_2[18] = {
        0x3C,0x00,0x50,0x04,0x00,0x00,0x9C,0x07,	//3
        0x00,0x00,0x00,0x00,0xE1,0x01,0x00,0x08,0x13,0x0A								                	//4
    };

    const UINT8 IMX136_ID02_3[1] = {
        0x63
    };

    const UINT8 IMX136_ID02_4[5] = {
        0x00,0x30,0x04,0x30,0x04 // 5
    };

    UINT32 i;
    UINT32 Addr;
    UINT32 nChNum = 1;   // LVDS Board (SSP1) 
    UINT8  ChipID;
    
    
    
    DEBUGMSG(MSGINFO, " >> IMX136 Init\n");


    
    
    // Sensor Reset
    __test_imx_hwreset();


    
    // Init SSP Channel
    APACHE_TEST_SSP_Init(nChNum);




    //============================================================================================
    //--------------------------------------------------------------------------------------------
    // IMX136_1080p_30p_4CH_LVDS.txt (2016.02.29, ???)
    //--------------------------------------------------------------------------------------------
    ChipID = 0x02;
    __test_imx_write(nChNum, ChipID, 0x03, 0x01);   // RESET=1
    APACHE_SYS_mDelay(1);
    __test_imx_write(nChNum, ChipID, 0x03, 0x00);   // RESET=0
    __test_imx_write(nChNum, ChipID, 0x02, 0x01);   // XMSTA=1
    APACHE_SYS_mDelay(10);



    ChipID = 0x02;
	for(i = 0; i< 35; i++)
	{
		Addr = i;
		if(i != 0x02)
         __test_imx_write(nChNum, ChipID, Addr, IMX136_ID02_1[i]);	
	}

	for(i = 0; i< 18; i++)
	{
		Addr = 0x38 + i;
         __test_imx_write(nChNum, ChipID, Addr, IMX136_ID02_2[i]);	
	}

	for(i = 0; i< 1; i++)
	{
		Addr = 0x54 + i;
         __test_imx_write(nChNum, ChipID, Addr, IMX136_ID02_3[i]);	
	}

	for(i = 0; i< 5; i++)
	{
		Addr = 0x5B + i;
         __test_imx_write(nChNum, ChipID, Addr, IMX136_ID02_4[i]);	
	}

    
    ChipID = 0x03;
    __test_imx_write(nChNum, ChipID, 0x0F, 0x0E);
    __test_imx_write(nChNum, ChipID, 0x16, 0x02);    
    ChipID = 0x04; 
    __test_imx_write(nChNum, ChipID, 0x36, 0x71);
    __test_imx_write(nChNum, ChipID, 0x39, 0xF1);
    __test_imx_write(nChNum, ChipID, 0x41, 0xF2);
    __test_imx_write(nChNum, ChipID, 0x42, 0x21);
    __test_imx_write(nChNum, ChipID, 0x43, 0x21);
    __test_imx_write(nChNum, ChipID, 0x48, 0xF2);
    __test_imx_write(nChNum, ChipID, 0x49, 0x21);
    __test_imx_write(nChNum, ChipID, 0x4A, 0x21);
    __test_imx_write(nChNum, ChipID, 0x52, 0x01);
    __test_imx_write(nChNum, ChipID, 0x54, 0xB1);



    //--------------------------------------------------------------------------------------------
    // Operation Start
    //-------------------------------------------------------------------------------------------- 
    ChipID = 0x02;
    APACHE_SYS_mDelay(1);
    __test_imx_write(nChNum, ChipID, 0x00, 0x00);   // Operation Mode Setting
    APACHE_SYS_mDelay(5);
    __test_imx_write(nChNum, ChipID, 0x02, 0x00);   // Master Mode Operation Start

    
    //============================================================================================


#if 0 // debug
    __test_imx_regdump(nChNum, 0x02);    
    __test_imx_regdump(nChNum, 0x03);    
    __test_imx_regdump(nChNum, 0x04);        
#endif


    // Deinit SSP Channel
    APACHE_TEST_SSP_DeInit(nChNum);

}

void APACHE_TEST_SSP_IMX244_LVDSInit(void)
{
    UINT32 nChNum = 1;   // LVDS Board (SSP1) 
    UINT8  ChipID;




    DEBUGMSG(MSGINFO, " >> IMX244 Init\n");



    // Sensor Reset
    __test_imx_hwreset();



    // Init SSP Channel
    APACHE_TEST_SSP_Init(nChNum);


    ChipID = 0x02;	
    __test_imx_write(nChNum, ChipID, 0x03, 0x01);	//RESET=1
    APACHE_SYS_mDelay(10);
    __test_imx_write(nChNum, ChipID, 0x03, 0x00);	//RESET=0
    __test_imx_write(nChNum, ChipID, 0x02, 0x01);	//XMSTA=1
    APACHE_SYS_mDelay(10);

    __test_imx_write(nChNum, ChipID, 0x00, 0x01);
    __test_imx_write(nChNum, ChipID, 0x01, 0x00);

    __test_imx_write(nChNum, ChipID, 0x05, 0x01);
    __test_imx_write(nChNum, ChipID, 0x44, 0xE1);   // LVDS 4ch Output // Number of Output bit Setting
    __test_imx_write(nChNum, ChipID, 0x06, 0x00); //Drive Mode : Fixed to ��0h��
    __test_imx_write(nChNum, ChipID, 0x07, 0x10); //Window mode : HD Mode(720p)
    __test_imx_write(nChNum, ChipID, 0x0C, 0x00); //WDMODE : Normal Mode // WDSEL : Normal	

    __test_imx_write(nChNum, ChipID, 0x09, 0x01); 		


    __test_imx_write(nChNum, ChipID, 0x1B, 0xE4); // 
    __test_imx_write(nChNum, ChipID, 0x1C, 0x0C); // 

    __test_imx_write(nChNum, ChipID, 0x18, 0xEE); // VMAX : 2EEh
    __test_imx_write(nChNum, ChipID, 0x19, 0x02); // 




    ////////////////// INCK Setting //////////////////
    //#ifdef 37.125Mhz
    __test_imx_write(nChNum, ChipID, 0x5C, 0x20);
    __test_imx_write(nChNum, ChipID, 0x5D, 0x00);
    __test_imx_write(nChNum, ChipID, 0x5E, 0x20);
    __test_imx_write(nChNum, ChipID, 0x5F, 0x00);


    __test_imx_write(nChNum, ChipID, 0x0A, 0x00); // Black Level : F0h	


    __test_imx_write(nChNum, ChipID, 0x43, 0x01); // DOLSCDEN : Pattern2 // DOLSYDINFOEN/HINFOEN : Identification Code Setting

    ChipID = 0x03;			
    __test_imx_write(nChNum, ChipID, 0x44, 0x07); // CMOS / LVDS Output
    __test_imx_write(nChNum, ChipID, 0x08, 0x00); // XVS / XHS output subsampling specified


    __test_imx_write(nChNum, ChipID, 0x0A, 0x00); // DOLHBFIXEN

    __test_imx_write(nChNum, ChipID, 0x54, 0x00); // DOL Mode

    ChipID = 0x02;		
    __test_imx_write(nChNum, ChipID, 0x0F, 0x00);
    __test_imx_write(nChNum, ChipID, 0x12, 0x2C);
    __test_imx_write(nChNum, ChipID, 0x13, 0x01);
    __test_imx_write(nChNum, ChipID, 0x16, 0x09);
    __test_imx_write(nChNum, ChipID, 0x1D, 0xC2);
    __test_imx_write(nChNum, ChipID, 0x70, 0x02);
    __test_imx_write(nChNum, ChipID, 0x71, 0x01);
    __test_imx_write(nChNum, ChipID, 0x9E, 0x22);
    __test_imx_write(nChNum, ChipID, 0xA5, 0xFB);
    __test_imx_write(nChNum, ChipID, 0xA6, 0x02);
    __test_imx_write(nChNum, ChipID, 0xB3, 0xFF);
    __test_imx_write(nChNum, ChipID, 0xB4, 0x01);
    __test_imx_write(nChNum, ChipID, 0xB5, 0x42);
    __test_imx_write(nChNum, ChipID, 0xB8, 0x10);
    __test_imx_write(nChNum, ChipID, 0xC2, 0x01);
    ////////////////// Chip ID = 03h //////////////////////

    ChipID = 0x03;
    __test_imx_write(nChNum, ChipID, 0x0F, 0x0F);
    __test_imx_write(nChNum, ChipID, 0x10, 0x0E);
    __test_imx_write(nChNum, ChipID, 0x11, 0xE7);
    __test_imx_write(nChNum, ChipID, 0x12, 0x9C);
    __test_imx_write(nChNum, ChipID, 0x13, 0x83);
    __test_imx_write(nChNum, ChipID, 0x14, 0x10);
    __test_imx_write(nChNum, ChipID, 0x15, 0x42);
    __test_imx_write(nChNum, ChipID, 0x28, 0x1E);
    __test_imx_write(nChNum, ChipID, 0xED, 0x38);
    ////////////////// Chip ID = 04h //////////////////////??? 

    ChipID = 0x04;
    __test_imx_write(nChNum, ChipID, 0x0C, 0xCF);
    __test_imx_write(nChNum, ChipID, 0x4C, 0x40);
    __test_imx_write(nChNum, ChipID, 0x4D, 0x03);
    __test_imx_write(nChNum, ChipID, 0x61, 0xE0);
    __test_imx_write(nChNum, ChipID, 0x62, 0x02);
    __test_imx_write(nChNum, ChipID, 0x6E, 0x2F);
    __test_imx_write(nChNum, ChipID, 0x6F, 0x30);
    __test_imx_write(nChNum, ChipID, 0x70, 0x03);
    __test_imx_write(nChNum, ChipID, 0x98, 0x00);
    __test_imx_write(nChNum, ChipID, 0x9A, 0x12);
    __test_imx_write(nChNum, ChipID, 0x9B, 0xE1);
    __test_imx_write(nChNum, ChipID, 0x9C, 0x0C);
    // Operation Start
    ////////////////// Chip ID = 02 //////////////////////??? 
    APACHE_SYS_mDelay(100);
    ChipID = 0x02;
    __test_imx_write(nChNum, ChipID, 0x00, 0x00); // Operation Mode Setting

    APACHE_SYS_mDelay(100);
    ChipID = 0x02;
    __test_imx_write(nChNum, ChipID, 0x02, 0x00); // Master Mode Operation Start


    // SENSOR SHUTTER
    __test_imx_write(nChNum, ChipID, 0x21, 0x00); 
    __test_imx_write(nChNum, ChipID, 0x20, 0xA0); 
    // SENSOR ANALOG GAIN
    __test_imx_write(nChNum, ChipID, 0x14, 0x00); 


#if 0 // debug
    __test_imx_regdump(nChNum, 0x02);    
    __test_imx_regdump(nChNum, 0x03);    
    __test_imx_regdump(nChNum, 0x04);    
    __test_imx_regdump(nChNum, 0x05);        
#endif


    // Deinit SSP Channel
    APACHE_TEST_SSP_DeInit(nChNum);

}

void APACHE_TEST_SSP_sFlash_ReadID(UINT32 nChNum)
{
    UINT8 rRDID[3];


    DEBUGMSG(MSGINFO, "[SSP_TEST] Read Identification\n");



    /*
    * Init SSP Channel
    */
    APACHE_TEST_SSP_Init(nChNum);


    /*
    * Read ID
    */	
    __test_sflash_readid(nChNum, rRDID);


    /*
    * Display Spi-Flash ID
    */
    DEBUGMSG(MSGINFO, " Spi-Flash >> \n");
    DEBUGMSG(MSGINFO, "  manufacturer ID : 0x%02X\n", rRDID[0]);
    DEBUGMSG(MSGINFO, "  memory type     : 0x%02X\n", rRDID[1]);
    DEBUGMSG(MSGINFO, "  memory density  : 0x%02X\n", rRDID[2]);
    DEBUGMSG(MSGINFO, "  memory size     : %d KB\n", (__test_sflash_memory_size((rRDID[2]&0xf))/KB));


    /*
    * Deinit SSP Channel
    */
    APACHE_TEST_SSP_DeInit(nChNum);

}


void APACHE_TEST_SSP_sFlash_SectorErase(UINT32 nChNum)
{
    UINT8  rRDID[3];
    UINT8  rBuff[TEST_sFlash_PAGE_SIZE];
    UINT32 i;
    UINT32 Addr;
    UINT32 nChipSize;
    UINT32 nErrCnt;



    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Sector Erase -> Read Page -> Check Data (0xFF)\n");


    /*
    * Init SSP Channel
    */
    APACHE_TEST_SSP_Init(nChNum);


    /*
    * Read ID
    */	
    __test_sflash_readid(nChNum, rRDID);
    nChipSize = __test_sflash_memory_size((rRDID[2]&0xf));
    DEBUGMSG(MSGINFO, " sFlash memory size     : %d KB\n", nChipSize/KB);


    /*
    * Spi-Flash Block Erase
    */
    for(Addr = 0; Addr < nChipSize; Addr += TEST_sFlash_SECTOR_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Sector Erase  : 0x%08x", Addr);
        __test_sflash_sectorerase(nChNum, Addr);
    }
    DEBUGMSG(MSGINFO, "\n");


    /*
    * Check Erased Chip 
    */
    for(Addr = 0, nErrCnt = 0; Addr < nChipSize; Addr += TEST_sFlash_PAGE_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Page Read     : 0x%08x", Addr);
        __test_sflash_readpage(nChNum, Addr, rBuff);

        for(i=0; i<TEST_sFlash_PAGE_SIZE; i++)
        {
            if(rBuff[i] != 0xFF)
            {
                nErrCnt++;
            }
        }
    }
    DEBUGMSG(MSGINFO, "\n");


    /* Display Test Result */
    if(nErrCnt == 0)
    {
        DEBUGMSG(MSGINFO, " Erase Test Success!\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, " Erase Test Fail! (%d)\n", nErrCnt);
    }


    /*
    * Deinit SSP Channel
    */
    APACHE_TEST_SSP_DeInit(nChNum);

}

void APACHE_TEST_SSP_sFlash_BlockErase(UINT32 nChNum)
{
    UINT8  rRDID[3];
    UINT8  rBuff[TEST_sFlash_PAGE_SIZE];
    UINT32 i;
    UINT32 Addr;
    UINT32 nChipSize;
    UINT32 nErrCnt;



    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Block Erase -> Read Page -> Check Data (0xFF)\n");


    /*
    * Init SSP Channel
    */
    APACHE_TEST_SSP_Init(nChNum);


    /*
    * Read ID
    */	
    __test_sflash_readid(nChNum, rRDID);
    nChipSize = __test_sflash_memory_size((rRDID[2]&0xf));
    DEBUGMSG(MSGINFO, " sFlash memory size     : %d KB\n", nChipSize/KB);


    /*
    * Spi-Flash Block Erase
    */
    for(Addr = 0; Addr < nChipSize; Addr += TEST_sFlash_BLOCK_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Block Erase : 0x%08x", Addr);
        __test_sflash_blockerase(nChNum, Addr);
    }
    DEBUGMSG(MSGINFO, "\n");


    /*
    * Check Erased Chip 
    */
    for(Addr = 0, nErrCnt = 0; Addr < nChipSize; Addr += TEST_sFlash_PAGE_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", Addr);
        __test_sflash_readpage(nChNum, Addr, rBuff);

        for(i=0; i<TEST_sFlash_PAGE_SIZE; i++)
        {
            if(rBuff[i] != 0xFF)
            {
                nErrCnt++;
            }
        }
    }
    DEBUGMSG(MSGINFO, "\n");


    /* Display Test Result */
    if(nErrCnt == 0)
    {
        DEBUGMSG(MSGINFO, " Erase Test Success!\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, " Erase Test Fail! (%d)\n", nErrCnt);
    }


    /*
    * Deinit SSP Channel
    */
    APACHE_TEST_SSP_DeInit(nChNum);

}

void APACHE_TEST_SSP_sFlash_WritePage(UINT32 nChNum)
{
    UINT32 PageAddr = 0;
    UINT8  wBuff[TEST_sFlash_PAGE_SIZE];



    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Page Write\n");



    /*
    * Init SSP Channel
    */
    APACHE_TEST_SSP_Init(nChNum);


    /*
    * Generate Write Data
    */	
    __test_sflash_dumy_buff(wBuff, TEST_sFlash_PAGE_SIZE);
    __test_sflash_buff_pageaddr_marking(wBuff, PageAddr);


    /*
    * Spi-Flash Page Write
    */
    __test_sflash_writepage(nChNum, PageAddr, wBuff);


    /*
    * Display Data
    */
    __test_sflash_display_buff(wBuff, TEST_sFlash_PAGE_SIZE, PageAddr);

    /*
    * Deinit SSP Channel
    */
    APACHE_TEST_SSP_DeInit(nChNum);
}

void APACHE_TEST_SSP_sFlash_ReadPage(UINT32 nChNum)
{
    UINT8 rBuff[TEST_sFlash_PAGE_SIZE];
    UINT32 PageAddr = 0;



    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Page Read\n");



    /*
    * Init SSP Channel
    */
    APACHE_TEST_SSP_Init(nChNum);


    /*
    * Spi-Flash Page Read
    */
    __test_sflash_readpage(nChNum, PageAddr, rBuff);


    /*
    * Display Data
    */
    __test_sflash_display_buff(rBuff, TEST_sFlash_PAGE_SIZE, PageAddr);


    /*
    * Deinit SSP Channel
    */
    APACHE_TEST_SSP_DeInit(nChNum);
}

void APACHE_TEST_SSP_sFlash_SectorErase_WritePage_ReadPage_Compare(UINT32 nChNum)
{
    UINT8 rRDID[3];
    UINT8 wBuff[TEST_sFlash_PAGE_SIZE];
    UINT8 rBuff[TEST_sFlash_PAGE_SIZE];
    UINT32 PageAddr = 0;
    UINT32 Offset;
    UINT32 nChipSize;
    UINT32 nErrCnt = 0;



    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Sector Erase -> Program Page -> Read Page -> Compare\n");


    /*
    * Init SSP Channel
    */
    APACHE_TEST_SSP_Init(nChNum);



    /*
    * Generate Write Data
    */	
    __test_sflash_dumy_buff(wBuff, TEST_sFlash_PAGE_SIZE);
    __test_sflash_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);


    /*
    * Read ID
    */	
    __test_sflash_readid(nChNum, rRDID);
    nChipSize = __test_sflash_memory_size((rRDID[2]&0xf));
    DEBUGMSG(MSGINFO, " sFlash memory size     : %d KB\n", nChipSize/KB);


    /*
    * Sector Erase->Page Write
    */	
    for(PageAddr = 0; PageAddr < nChipSize; PageAddr += TEST_sFlash_SECTOR_SIZE)
    {
        __test_sflash_sectorerase(nChNum, PageAddr);

        for(Offset = 0; Offset < TEST_sFlash_SECTOR_SIZE; Offset += TEST_sFlash_PAGE_SIZE)
        {
            DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", PageAddr+Offset);
            __test_sflash_buff_pageaddr_marking(wBuff,PageAddr+Offset);
            __test_sflash_writepage(nChNum, PageAddr+Offset, wBuff);
        }
    }
    DEBUGMSG(MSGINFO, "\n");

    /*
    * Page Read->Compare
    */		
    for(PageAddr = 0; PageAddr < nChipSize; PageAddr += TEST_sFlash_PAGE_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", PageAddr);
        __test_sflash_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);	
        __test_sflash_readpage(nChNum, PageAddr, rBuff);

        __test_sflash_buff_pageaddr_marking(wBuff, PageAddr);
        nErrCnt+=__test_sflash_compare_buff(rBuff, wBuff, TEST_sFlash_PAGE_SIZE);
    }
    DEBUGMSG(MSGINFO, "\n");


    /*
    * Display Data
    */
    __test_sflash_display_buff(rBuff, TEST_sFlash_PAGE_SIZE, (PageAddr-TEST_sFlash_PAGE_SIZE));	
    if(!nErrCnt)
    {
        DEBUGMSG(MSGERR, " >> Data Compare Success\n");		
    }


    /*
    * Deinit SSP Channel
    */
    APACHE_TEST_SSP_DeInit(nChNum);
}

void APACHE_TEST_SSP_sFlash_BlockErase_WritePage_ReadPage_Compare(UINT32 nChNum)
{
    UINT8 rRDID[3];
    UINT8 wBuff[TEST_sFlash_PAGE_SIZE];
    UINT8 rBuff[TEST_sFlash_PAGE_SIZE];
    UINT32 PageAddr = 0;
    UINT32 Offset;
    UINT32 nChipSize;
    UINT32 nErrCnt = 0;



    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Block Erase -> Program Page -> Read Page -> Compare\n");



    /*
    * Init SSP Channel
    */
    APACHE_TEST_SSP_Init(nChNum);



    /*
    * Generate Write Data
    */	
    __test_sflash_dumy_buff(wBuff, TEST_sFlash_PAGE_SIZE);
    __test_sflash_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);


    /*
    * Read ID
    */	
    __test_sflash_readid(nChNum, rRDID);
    nChipSize = __test_sflash_memory_size((rRDID[2]&0xf));
    DEBUGMSG(MSGINFO, " sFlash memory size     : %d KB\n", nChipSize/KB);


    /*
    * Block Erase->Page Write
    */	
    for(PageAddr = 0; PageAddr < nChipSize; PageAddr += TEST_sFlash_BLOCK_SIZE)
    {
        __test_sflash_blockerase(nChNum, PageAddr);

        for(Offset = 0; Offset < TEST_sFlash_BLOCK_SIZE; Offset += TEST_sFlash_PAGE_SIZE)
        {
            DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", PageAddr+Offset);
            __test_sflash_buff_pageaddr_marking(wBuff,PageAddr+Offset);
            __test_sflash_writepage(nChNum, PageAddr+Offset, wBuff);
        }
    }
    DEBUGMSG(MSGINFO, "\n");



    /*
    * Page Read->Compare
    */		
    for(PageAddr = 0; PageAddr < nChipSize; PageAddr += TEST_sFlash_PAGE_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", PageAddr);
        __test_sflash_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);	
        __test_sflash_readpage(nChNum, PageAddr, rBuff);

        __test_sflash_buff_pageaddr_marking(wBuff, PageAddr);
        nErrCnt+=__test_sflash_compare_buff(rBuff, wBuff, TEST_sFlash_PAGE_SIZE);
    }
    DEBUGMSG(MSGINFO, "\n");


    /*
    * Display Data
    */
    __test_sflash_display_buff(rBuff, TEST_sFlash_PAGE_SIZE, (PageAddr-TEST_sFlash_PAGE_SIZE));	
    if(!nErrCnt)
    {
        DEBUGMSG(MSGERR, " >> Data Compare Success\n");		
    }


    /*
    * Deinit SSP Channel
    */
    APACHE_TEST_SSP_DeInit(nChNum);
}

void APACHE_TEST_SSP_sFlash_BitRateChange(UINT32 nChNum)
{
    UINT32 nMbps;

    UINT8 rRDID[3];
    UINT8 wBuff[TEST_sFlash_PAGE_SIZE];
    UINT8 rBuff[TEST_sFlash_PAGE_SIZE];
    UINT32 PageAddr = 0;
    UINT32 Offset;
    UINT32 nChipSize;
    UINT32 nErrCnt = 0;




    DEBUGMSG(MSGINFO, "[SSP_TEST] Bitrate Change\n");



    /*
    * Init SSP Channel
    */
    APACHE_TEST_SSP_Init(nChNum);


    /*
    * Generate Write Data
    */	
    __test_sflash_dumy_buff(wBuff, TEST_sFlash_PAGE_SIZE);
    __test_sflash_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);



    for(nMbps = 1; nMbps<=12; nMbps++)
    {	
        ncLib_SSP_Control(GCMD_SSP_SET_BITRATE_CH, nChNum, nMbps, CMD_END);		
        __test_sflash_readid(nChNum, rRDID);

        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " sFlash ID (%02dMbps) : 0x%02x 0x%02x 0x%02x\n", nMbps, rRDID[0], rRDID[1], rRDID[2]);
        nChipSize = __test_sflash_memory_size((rRDID[2]&0xf));
        DEBUGMSG(MSGINFO, " sFlash memory size : %d KB\n", nChipSize/KB);


        /*
        * Block Erase->Page Write
        */	
        for(PageAddr = 0; PageAddr < nChipSize; PageAddr += TEST_sFlash_BLOCK_SIZE)
        {
            __test_sflash_blockerase(nChNum, PageAddr);

            for(Offset = 0; Offset < TEST_sFlash_BLOCK_SIZE; Offset += TEST_sFlash_PAGE_SIZE)
            {
                DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", PageAddr+Offset);
                __test_sflash_buff_pageaddr_marking(wBuff,PageAddr+Offset);
                __test_sflash_writepage(nChNum, PageAddr+Offset, wBuff);
            }
        }
        DEBUGMSG(MSGINFO, "\n");



        /*
        * Page Read->Compare
        */		
        for(PageAddr = 0; PageAddr < nChipSize; PageAddr += TEST_sFlash_PAGE_SIZE)
        {
            DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", PageAddr);
            __test_sflash_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);	
            __test_sflash_readpage(nChNum, PageAddr, rBuff);

            __test_sflash_buff_pageaddr_marking(wBuff, PageAddr);
            nErrCnt+=__test_sflash_compare_buff(rBuff, wBuff, TEST_sFlash_PAGE_SIZE);
        }
        DEBUGMSG(MSGINFO, "\n");

        if(!nErrCnt)
        {
            DEBUGMSG(MSGERR, " >> Data Compare Success\n");		
        }
    }


    /*
    * Deinit SSP Channel
    */
    APACHE_TEST_SSP_DeInit(nChNum);	
}


INT32 APACHE_TEST_SSP_CUTMode(void)
{
    UINT32 nChNum = FPGA_SSP_CH;
    INT32 select;
    char buf[16];


    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - SSP       				   \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Standard SPI Controller : Read & Write Support             \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> SSP: Read Serial Flash ID						       \n");
        DEBUGMSG(MSGINFO, " <2> SSP: Sector Erase Test                                 \n");
        DEBUGMSG(MSGINFO, " <3> SSP: Block Erase Test                                  \n");
        DEBUGMSG(MSGINFO, " <4> SSP: Page Write Test                                   \n");
        DEBUGMSG(MSGINFO, " <5> SSP: Page Read Test                                    \n");		
        DEBUGMSG(MSGINFO, " <6> SSP: Sector Erase -> Write Page -> Read Page -> Compare\n");
        DEBUGMSG(MSGINFO, " <7> SSP: Block  Erase -> Write Page -> Read Page -> Compare\n");
        DEBUGMSG(MSGINFO, " <8> SSP: Bit-rate change Test                              \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <A> SSP  : LVDS IMX136 Init                                \n"); 
        DEBUGMSG(MSGINFO, " <B> SSP  : LVDS IMX244 Init                                \n"); 
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_SSP_sFlash_ReadID(nChNum);
            break;

            case 2:
                APACHE_TEST_SSP_sFlash_SectorErase(nChNum);
            break;

            case 3:
                APACHE_TEST_SSP_sFlash_BlockErase(nChNum);
            break;

            case 4:
                APACHE_TEST_SSP_sFlash_WritePage(nChNum);
            break;

            case 5:
                APACHE_TEST_SSP_sFlash_ReadPage(nChNum);
            break;

            case 6:
                APACHE_TEST_SSP_sFlash_SectorErase_WritePage_ReadPage_Compare(nChNum);
            break;	

            case 7:
                APACHE_TEST_SSP_sFlash_BlockErase_WritePage_ReadPage_Compare(nChNum);
            break;	

            case 8:
                APACHE_TEST_SSP_sFlash_BitRateChange(nChNum);
            break;

            case 10:
                APACHE_TEST_SSP_IMX136_LVDSInit();
            break;
            
            case 11:
                APACHE_TEST_SSP_IMX244_LVDSInit();
            break;

            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto SSP_Exit;
        }
    }

SSP_Exit:

    return NC_SUCCESS;
}


#endif


/* End Of File */




