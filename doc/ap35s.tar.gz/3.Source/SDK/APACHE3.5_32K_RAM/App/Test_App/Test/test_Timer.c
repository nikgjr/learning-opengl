/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : test_Timer.c
*
*  @brief   :
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.01.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "test.h"


#if ENABLE_IP_TIMER


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/
typedef struct _tTIMERTEST_FLAG
{
    eGPIO_GROUP     Group;    
    eGPIO_PORT      Port;
    UINT32          TestCount;
} tTIMERTEST_FLAG, *ptTIMERTEST_FLAG;











/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/
tTIMERTEST_FLAG tTIMERTestFlag = { GPIO_GROUP_A, GPIO_PORT14, 0 };











/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
static void __test_timer_gpio_init(void)
{
    ncLib_GPIO_Control(GCMD_GPIO_ENA, tTIMERTestFlag.Group, tTIMERTestFlag.Port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, tTIMERTestFlag.Group, tTIMERTestFlag.Port, GPIO_DIR_OUT, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, tTIMERTestFlag.Group, tTIMERTestFlag.Port, GPIO_HIGH, CMD_END); 
}

static void __test_timer_gpio_deinit(void)
{
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, tTIMERTestFlag.Group, tTIMERTestFlag.Port, GPIO_LOW, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_DIS, tTIMERTestFlag.Group, tTIMERTestFlag.Port, CMD_END);
}

void APACHE_TEST_TIMER_UserInterruptHandler( void )
{
    ++tTIMERTestFlag.TestCount;	

    DEBUGMSG(MSGINFO, " ISR  : %02d\n", tTIMERTestFlag.TestCount);
    if(tTIMERTestFlag.TestCount%2)
    {
        ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, tTIMERTestFlag.Group, tTIMERTestFlag.Port, GPIO_LOW, CMD_END);
    }
    else
    {
        ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, tTIMERTestFlag.Group, tTIMERTestFlag.Port, GPIO_HIGH, CMD_END);
    }    
}

void APACHE_TEST_TIMER_PWMMode( void )
{
    INT32 ret;
    TIMER_CH Channel = TC_CH2;    
    tTC_INIT_PARAM tTimerParam;


    __test_timer_gpio_init();


#if 0
    /*
    * Open Timer (all timer channel : 0 ~ 1)
    */
    ret = ncLib_TIMER_Open( ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_TIMER, CMD_END) );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Open Error!\n");
    }
#endif


    /*
    * Init Timer Channel
    */	
    tTimerParam.mMode			= TC_MODE_PWM;
    tTimerParam.mPrescaler		= 0;
    tTimerParam.mPeriod1 		= 1500;
    ret = ncLib_TIMER_Control( GCMD_TC_INIT_CH, Channel, &tTimerParam, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Init Error!\n");
    }


    /*
    * Connect User Handler
    */
    ret = ncLib_TIMER_Control( GCMD_TC_CONNECT_USER_HANDLER, Channel, APACHE_TEST_TIMER_UserInterruptHandler, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer User ISR register Error!\n");
    }


    /*
    * Start Timer
    */
    tTIMERTestFlag.TestCount = 0;
    ret = ncLib_TIMER_Control( GCMD_TC_START, Channel, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Start Error!\n");
    }


    /*
    * Wait 10 seconds for test
    */
    while(tTIMERTestFlag.TestCount < 4000);



    /*
    * Stop timer
    */
    ret = ncLib_TIMER_Control( GCMD_TC_STOP, Channel, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Stop Error!\n");
    }



    /*
    * Disconnect User Handler
    */
    ret = ncLib_TIMER_Control( GCMD_TC_DISCONNECT_USER_HANDLER, Channel, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer User ISR register Error!\n");
    }


#if 0	
    /*
    * Close Timer
    */
    ret = ncLib_TIMER_Close();
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Close Error!\n");
    }
#endif


    __test_timer_gpio_deinit();
}

void APACHE_TEST_TIMER_OneShotMode( void )
{
    INT32 ret;
    TIMER_CH Channel = TC_CH1;    
    tTC_INIT_PARAM 	tTimerParam;


#if 0
    /*
    * Open Timer (all timer channel : 0 ~ 1)
    */
    ret = ncLib_TIMER_Open( ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_TIMER, CMD_END) );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Open Error!\n");
    }
#endif


    for(tTIMERTestFlag.TestCount=1; tTIMERTestFlag.TestCount<=10; tTIMERTestFlag.TestCount++)
    {
        /*
        * Initialize system timer with oneshot mode.
        * Timer0 is reserved as system Timer in Library
        */
        tTimerParam.mPrescaler		= 1;
        tTimerParam.mMode			= TC_MODE_ONESHOT;
        tTimerParam.mPeriod1 		= 1000000;
        ret = ncLib_TIMER_Control( GCMD_TC_INIT_CH, Channel, &tTimerParam, CMD_END );
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "Timer Init Error!\n");
        }


        /*
        * Start Oneshot Timer
        */
        ret = ncLib_TIMER_Control( GCMD_TC_START, Channel, CMD_END );
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "Timer Start Error!\n");
        }


        /*
        * Wait 2 seconds for test
        */
        while( !ncLib_TIMER_Control(GCMD_TC_CHK_ONESHOT_DONE, Channel, CMD_END) );
        DEBUGMSG(MSGINFO, " Done : %02d\n", tTIMERTestFlag.TestCount);


        /*
        * Stop timer
        */
        ret = ncLib_TIMER_Control( GCMD_TC_STOP, Channel, CMD_END );
        if(ret == NC_FAILURE)
        {
            DEBUGMSG(MSGERR, "Timer Stop Error!\n");
        }
    }


#if 0
    /*
    * Close Timer
    */
    ret = ncLib_TIMER_Close();
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Close Error!\n");
    }
#endif	
}

void APACHE_TEST_TIMER_PeriodMode( void )
{
    INT32 ret;
    TIMER_CH Channel = TC_CH1;    
    tTC_INIT_PARAM tTimerParam;


    __test_timer_gpio_init();


#if 0
    /*
    * Open Timer (all timer channel : 0 ~ 1)
    */
    ret = ncLib_TIMER_Open( ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_TIMER, CMD_END) );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Open Error!\n");
    }
#endif

    /*
    * Init Timer Channel
    */	
    tTimerParam.mMode			= TC_MODE_PERIOD;
    tTimerParam.mPrescaler		= 1;
    tTimerParam.mPeriod1 		= 1000000;
    ret = ncLib_TIMER_Control( GCMD_TC_INIT_CH, Channel, &tTimerParam, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Init Error!\n");
    }


    /*
    * Connect User Handler
    */
    ret = ncLib_TIMER_Control( GCMD_TC_CONNECT_USER_HANDLER, Channel, APACHE_TEST_TIMER_UserInterruptHandler, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer User ISR register Error!\n");
    }


    /*
    * Start Timer
    */
    tTIMERTestFlag.TestCount = 0;
    ret = ncLib_TIMER_Control( GCMD_TC_START, Channel, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Start Error!\n");
    }


    /*
    * Wait 10 seconds for test
    */
    while(tTIMERTestFlag.TestCount < 10);



    /*
    * Stop timer
    */
    ret = ncLib_TIMER_Control( GCMD_TC_STOP, Channel, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Stop Error!\n");
    }



    /*
    * Disconnect User Handler
    */
    ret = ncLib_TIMER_Control( GCMD_TC_DISCONNECT_USER_HANDLER, Channel, CMD_END );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer User ISR register Error!\n");
    }


#if 0	
    /*
    * Close Timer
    */
    ret = ncLib_TIMER_Close();
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Close Error!\n");
    }
#endif

    __test_timer_gpio_deinit();
}

INT32 APACHE_TEST_TIMER_CUTMode(void)
{
    INT32 select;
    char buf[16];


    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - TIMER       				   \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " 2-Channel Timer Controller                                 \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> Period Mode Test                                       \n");
        DEBUGMSG(MSGINFO, " <2> OneShot Mode Test                                      \n");
        DEBUGMSG(MSGINFO, " <3> PWM Mode Test                                          \n");     
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_SYS_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_TIMER_PeriodMode();
            break;

            case 2:
                APACHE_TEST_TIMER_OneShotMode();
            break;

            case 3:
                APACHE_TEST_TIMER_PWMMode();
            break;

            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto TIMER_Exit;
        }
    }

TIMER_Exit:

    return NC_SUCCESS;
}


#endif


/* End Of File */





