/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.c
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "App.h"

#include "./Test/test.h"

/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************
********************************************************************************
*/
#include "../../ncLib\SWC_Peripheral\Drv\UART\Uart_Drv.h"
#include "../../ncLib\SWC_Peripheral\Drv\SCU\SCU_Drv.h"

#include "../../ncLib\Include\INTC_Lib.h"
#include "../../ncLib\Include\Uart_Lib.h"


#include "../../ncLib\SWC_ISP\Svc\JIG_Svc.h"

#include "../../ncLib\SWC_ISP\Drv\System_Drv.h"
#include "../../ncLib\SWC_ISP\Drv\Category_Drv.h"

#include "../../ncLib\SWC_ISP\Drv\BackLight_Drv.h"





void APACHE_APP_InitJigPort(void)
{
    tUART_PARAM param;

    param.uartClk   = ncDrv_SCU_GetSystemClock(SCU_CLK_ID_UART);
    param.baudRate  = UT_BAUDRATE_38400;
    param.sps       = UT_SPS_DIS;
    param.wlen      = UT_DATA_8BIT;
    param.fen       = UT_FIFO_ENA;
    param.stp2      = UT_STOP_1BIT;
    param.eps       = UT_EPS_DIS;
    param.pen       = UT_PARITY_DIS;
    param.brk       = UT_BRK_DIS;

    ncLib_JIG_Open(param.uartClk);

	ncDrv_UART_Initialize(UART1, (ptUART_PARAM)&param);

	ncLib_INTC_RegisterHandler(IRQ_NUM_UART1, (PrHandler)ncDrv_UART_IRQ_Handler1);
	
	ncDrv_GIC_EnableIrq(IRQ_NUM_UART1);

}



void APACHE_TEST_InitInterface(void)
{
    ncLib_SCU_Open();
	
    ncLib_INTC_Open();
    ncLib_UART_Open(ncDrv_SCU_GetSystemClock(SCU_CLK_ID_UART));
    ncLib_GPIO_Open();
    ncLib_I2C_Open(ncDrv_SCU_GetSystemClock(SCU_CLK_ID_I2C));

	APACHE_APP_InitJigPort();
}


void APACHE_TEST_Initialize(void)
{
    APACHE_TEST_InitInterface();
    APACHE_SYS_InitsFlash();

    ncLib_ISP_Open();
	ncDrv_ISP_FlashMemory_AllLoad(1);
}

INT32 main(void)
{
    APACHE_TEST_Initialize();
	
    APACHE_TEST_I2C_CMOS_AR0140AT_Initialize();
	
    APACHE_TEST_I2C_HDMI_Initialize();
	
	ncDrv_VariableInitialize_Boot_Set();
	
	//ncDrv_CategoryFunc_Init();
	ncDrv_Backlight_Mode_Set();

    while(1)
	{
		ncSvc_JIG_CommandMain(UART_CH1);
    }

    return TRUE;
}


/* End Of File */
