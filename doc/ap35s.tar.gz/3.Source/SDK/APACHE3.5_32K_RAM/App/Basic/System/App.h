/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : App.h
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __APP_H__
#define __APP_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

/* ARM Standard Library */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Apache35.h"
#include "FlashMemoryMap.h"


/* Common Header File */
#include "Type.h"
#include "Uart_Lib.h"
#include "INTC_Lib.h"
#include "I2C_Lib.h"
#include "ISP_Lib.h"
#include "JIG_Lib.h"
#include "SWReg_Lib.h"
#include "Task_Lib.h"
#include "Debug_Lib.h"
#include "SSP_Lib.h"
#include "Timer_Lib.h"
#include "SysTime_Lib.h"
#include "sFlash_Lib.h"
#include "DMA_Lib.h"
#include "SCU_Lib.h"
#include "GPIO_Lib.h"
#include "WDT_Lib.h"
#include "CAN_Lib.h"
#include "TS_Lib.h"
#include "VDUMP_Lib.h"


/* Basic Application Header File */
#include "Config.h"
#include "System.h"
#include "SIL9034.h"
#include "AR0132AT.h"
#include "AR0140AT.h"
#include "OV10640.h"

/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/


#endif  /* __APP_H__ */


/* End Of File */
