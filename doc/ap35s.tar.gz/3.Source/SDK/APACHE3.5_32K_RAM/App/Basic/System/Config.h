/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Config.h
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __CONFIG_H__
#define __CONFIG_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

/* APACHE3.5 FPGA Version ID */

#define APACHE35_FPGA_MPW1          0
#define APACHE35_FPGA_MPW2          1
#define APACHE35_FPGA_SINGLE        2


/* APACHE3.5 ES Chip Version ID */

#define APACHE35_ES_MPW1            10
#define APACHE35_ES_MPW2            11
#define APACHE35_ES_SINGLE          12


/* Sensor Type Selection */

#define CMOS_AR0132AT               0
#define CMOS_AR0140AT               1
#define CMOS_OV10640                2


/* Sensor Mode Selection */

#define CMOS_MODE_LINEAR            0
#define CMOS_MODE_WDR               1


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               USER SELECTION AREA
********************************************************************************
*/

/* H/W Configuration */

#define APACHE35_BOARD_TYPE             APACHE35_FPGA_MPW1

#define CMOS_SENSOR_TYPE                CMOS_AR0140AT

#define CMOS_SENSOR_MODE_TYPE           CMOS_MODE_LINEAR


/* System Configuration */

#define APACHE35_SYSTEM_TIMER_ON        FALSE


/* Application Version Configuration */

#define APP_VER_MAJOR                   0
#define APP_VER_MINOR1                  4
#define APP_VER_MINOR2                  0

#define APP_BUILD_DATE                  __DATE__
#define APP_BUILD_TIME                  __TIME__


#endif  /* __CONFIG_H__ */


/* End Of File */
