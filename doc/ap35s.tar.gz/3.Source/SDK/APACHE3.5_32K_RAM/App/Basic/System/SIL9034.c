/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SIM9034.c
*
*  @brief   : HDMI frame controller test application source file
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.08
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "SIL9034.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define HDMI_SIL9034_ROM_TABLE_USE  0


#define SIL9034_DEVICEID_V          0x72
#define SIL9034_DEVICEID_A          0x7A


//////////////////////////
/* First Device Address */

#define TX_SLV0             (0x72) //(0x39)
#define SLAVE0              0

/* provides unique vendor identification */
#define VND_IDL             (0x00)
#define VND_IDH             (0x01)

/* provides unique device type identification */
#define DEV_IDL             (0x02)
#define DEV_IDH             (0x03)

/* provides revision info */
#define DEV_REV             (0x04) 

/* Software reset register */
#define TX_SWRST_ADDR       (0x05) 

/* System control register #1 */
#define TX_SYS_CTRL1_ADDR   (0x08) 

/* System status register */
#define TX_STAT_ADDR        (0x09) 

/* System contorl register */
#define TX_SYS_CTRL4_ADDR   (0x0C)

/* BKSV register : 5 bytes, Read only (RO), receiver KSV */
#define DDC_BKSV_ADDR       (0x00) 

/* AN register : 8 bytes, write only (WO) */
#define DDC_AN_ADDR         (0x18) 

/* AKSV register : 5 bytes, write only (WO) */
#define DDC_AKSV_ADDR       (0x10)

/* RI register : 2 bytes, read only (R0), Ack from receiver R) */
#define DDC_RI_ADDR         (0x08)

/* DDC fifo register : 1 bytes */
#define DDC_BCAPS_ADDR      (0x40)

/* HDCP control register */
#define HDCP_CTRL_ADDR      (0x0F)
#define HDCP_RX_SLAVE       (0x74)

/* Data control register */
#define DCTL_ADDR           (0x0D)

/* Hdcp RI register */
#define HDCP_RI1            (0x22)
#define HDCP_RI2            (0x23)
#define HDCP_RI128_COMP     (0x24)

/* Hdcp BKSV register */
#define HDCP_BKSV1_ADDR     (0x10)
#define HDCP_BKSV2_ADDR     (0x11)
#define HDCP_BKSV3_ADDR     (0x12)
#define HDCP_BKSV4_ADDR     (0x13)
#define HDCP_BKSV5_ADDR     (0x14) 

/* Hdcp AN register */
#define HDCP_AN1_ADDR       (0x15)
#define HDCP_AN2_ADDR       (0x16)
#define HDCP_AN3_ADDR       (0x17)
#define HDCP_AN4_ADDR       (0x18)
#define HDCP_AN5_ADDR       (0x19)
#define HDCP_AN6_ADDR       (0x1A)
#define HDCP_AN7_ADDR       (0x1B)
#define HDCP_AN8_ADDR       (0x1C) 

/* Hdcp AKSV register */
#define HDCP_AKSV1_ADDR     (0x1D)
#define HDCP_AKSV2_ADDR     (0x1E)
#define HDCP_AKSV3_ADDR     (0x1F)
#define HDCP_AKSV4_ADDR     (0x20)
#define HDCP_AKSV5_ADDR     (0x21)

/* Rom command */
#define KEY_COMMAND_ADDR    (0xFA)

/* Hdcp master command */
#define MASTER_CMD_ABORT    (0x0f)

// Command Codes
#define MASTER_CMD_CLEAR_FIFO   (0x09)
#define MASTER_CMD_CLOCK        (0x0a)
#define MASTER_CMD_CUR_RD       (0x00)
#define MASTER_CMD_SEQ_RD       (0x02)
#define MASTER_CMD_ENH_RD       (0x04)
#define MASTER_CMD_SEQ_WR       (0x06) 
#define MASTER_FIFO_WR_USE      (0x01)
#define MASTER_FIFO_RD_USE      (0x02)
#define MASTER_FIFO_EMPTY       (0x04)
#define MASTER_FIFO_FULL        (0x08)
#define MASTER_DDC_BUSY         (0x10)
#define MASTER_DDC_NOACK        (0x20)
#define MASTER_DDC_STUCK        (0x40)
#define MASTER_DDC_RSVD         (0x80) 
#define BIT_MDDC_ST_IN_PROGR    (0x10)
#define BIT_MDDC_ST_I2C_LOW     (0x40)
#define BIT_MDDC_ST_NO_ACK      (0x20)

/* Video Hbit to HSYNC register */
#define HBIT_2HSYNC1        (0x40)
#define HBIT_2HSYNC2        (0x41)

/* Video field Hsync offset register */
#define FIELD2_HSYNC_OFFSETL_ADDR   (0x42)
#define FIELD2_HSYNC_OFFSETH_ADDR   (0x43) 

/* Interrupt state Register */
#define INT_STATE_ADDR      (0x70) 

/* Interrupt source register */
#define INT_SOURCE1_ADDR    (0x71)
#define INT_SOURCE2_ADDR    (0x72)
#define INT_SOURCE3_ADDR    (0x73)

/* Interrupt unmask register */
#define HDMI_INT1_MASK      (0x75)
#define HDMI_INT2_MASK      (0x76)
#define HDMI_INT3_MASK      (0x77)

// Ri error interrupts masks & DDC FIFO interrupts mask
#define BIT_INT3_RI_ERR_3_MASK  (0x80)  

// Enable(1) / disable(0-default) ri err #3 interrupt 
/* Interrupt control register */
#define INT_CNTRL_ADDR      (0x79)

/* TMDS control register */
#define TX_TMDS_CCTRL_ADDR  (0x80)
#define TX_TMDS_CTRL_ADDR   (0x82)
#define TX_TMDS_CTRL2_ADDR  (0x83)
#define TX_TMDS_CTRL3_ADDR  (0x84)
#define TX_TMDS_CTRL4_ADDR  (0x85)

/* Video DE delay register */
#define DE_DELAY_ADDR       (0x32) 

/* Video DE control register */
#define DE_CTRL_ADDR        (0x33) 

/* Video DE top register */
#define DE_TOP_ADDR         (0x34) 

/* Video DE count register */
#define DE_CNTL_ADDR        (0x36)
#define DE_CNTH_ADDR        (0x37)

/* Video DE line register */
#define DEL_L_ADDR          (0x38)
#define DEL_H_ADDR          (0x39)

/* Video resolution register */
#define HRES_L_ADDR         0x3A
#define HRES_H_ADDR         0x3B 

/* Video refresh register */
#define VRES_L_ADDR         0x3C
#define VRES_H_ADDR         0x3D

/* Video interlace adjustment register */
#define INTERLACE_ADJ_MODE  (0x3E)

/* Video SYNC polarity detection register */
#define POL_DETECT_ADDR     (0x3F)

/* Video Hbit to HSYNC register */
#define HBIT_TO_HSYNC_ADDR1 (0x40) 

/* Video Hbit to HSYNC register */
#define HBIT_TO_HSYNC_ADDR2 (0x41) 

/* Video Field2 HSYNC Hight offset register */
#define FIELD2_HSYNC_OFFSETL_ADDR   (0x42) 

/* Video Filed2 HSYNC Low offset register */
#define FIELD2_HSYNC_OFFSETH_ADDR   (0x43) 

/* Video HSYNC Length register */
#define HLENGTH1_ADDR       (0x44)
#define HLENGTH2_ADDR       (0x45) 

/* Video Vbit to VSYNC register */
#define VBIT_TO_VSYNC_ADDR  (0x46)

/* Video VSYNC Length register */
#define VLENGTH_ADDR        (0x47)

/* Video control register */
#define TX_VID_CTRL_ADDR    (0x48)

/* Video action enable register */
#define TX_VID_ACEN_ADDR    (0x49)

/* Video mode register */
#define TX_VID_MODE_ADDR    (0x4A)

/* DDC i2c manual register */
#define DDC_MAN_ADDR        (0xEC)
#define DDC_ADDR            (0xED)
#define DDC_SEGM_ADDR       (0xEE)
#define DDC_OFFSET_ADDR     (0xEF)
#define DDC_CNT1_ADDR       (0xF0)
#define DDC_CNT2_ADDR       (0xF1)
#define DDC_STATUS_ADDR     (0xF2)
#define DDC_CMD_ADDR        (0xF3)
#define DDC_DATA_ADDR       (0xF4)
#define DDC_FIFOCNT_ADDR    (0xF5)


///////////////////////////
/* Second Device Address */

#define TX_SLV1             (0x7A) //(0x3D)
#define SLAVE1              1

/* ACR control register */
#define ACR_CTRL_ADDR       (0x01)

/* ACR audio frequency register */
#define FREQ_SVAL_ADDR      (0x02)

/* ACR N software value register */
#define N_SVAL1_ADDR        (0x03)
#define N_SVAL2_ADDR        (0x04)
#define N_SVAL3_ADDR        (0x05)

/* Audio IN mode control register */
#define AUD_MODE_ADDR       (0x14)

/* Ri status register */
#define RI_STAT_ADDR        (0x26)

/* RI COMMAND */
#define RI_CMD_ADDR         (0x27)

/* RI Line start register */
#define RI_LINE_START_ADDR  (0x28)

/* RI RX register */
#define RI_RX_L_ADDR        (0x29)
#define RI_RX_H_ADDR        (0x2A)

/* HDMI control register */
#define HDMI_CTRL_ADDR      (0x2F)

/* Diagnostic power down register */
#define DIAG_PD_ADDR        (0x3D)

/* CEA-861 Info Frame register #1*/
#define INF_CTRL1           (0x3E)

/* CEA-861 Info Frame register #2*/
#define INF_CTRL2           (0x3F)

/* General control packet register */
#define GCP_BYTE1           (0xDF)
#define AVI_IF_ADDR         0x40
#define SPD_IF_ADDR         0x60
#define AUD_IF_ADDR         0x80
#define MPEG_IF_ADDR        0xA0
#define GENERIC1_IF_ADDR    0xC0
#define GENERIC2_IF_ADDR    0xE0
#define CP_IF_ADDR          0xDF

// Contain Protect 1- byte Frame Info Frame
#define BIT_CP_AVI_MUTE_SET     0x01
#define BIT_CP_AVI_MUTE_CLEAR   0x10 
#define GEN_RPT             (1<<0)
#define EN_EN               (1<<1)
#define GCP_RPT             (1<<2)
#define GCP_EN              (1<<3)
#define GEN2_RPT            (1<<4)
#define GEN2_EN             (1<<5)
#define CLR_AVMUTE          0x10
#define SET_AVMUTE          0x01
#define SET_AVMUTE          0x01


///////////////////
/* value defined */

//#define ENABLE              1
//#define TRUE                1
//#define DISABLE             0
//#define FALSE               0

#define INT_ENABLE          (0x1)
#define BIT_TX_SW_RST       (0x01)
#define BIT_TX_FIFO_RST     (0x02)
#define BIT_AVI_REPEAT      (0x01)
#define BIT_AVI_ENABLE      (0x02)
#define BIT_SPD_REPEAT      (0x04)
#define BIT_SPD_ENABLE      (0x08)
#define BIT_AUD_REPEAT      (0x10)
#define BIT_AUD_ENABLE      (0x20)
#define BIT_MPEG_REPEAT     (0x40)
#define BIT_MPEG_ENABLE     (0x80)
#define BIT_GENERIC_REPEAT  (0x01)
#define BIT_GENERIC_ENABLE  (0x02)
#define BIT_CP_REPEAT       (0x04)
#define BIT_CP_ENABLE       (0x08) 
#define AUDIO_IFOFRAMES_EN_RPT  (0x30)

/* HDMI Interface */
#define DO_NOTHING          0
#define SWITCH_480P         1
#define SWITCH_720P         2
#define SWITCH_1080I        3
#define HDCP_EXCHANGE       4
#define SHOW_REGISTER       5

/* WORK QUEUE */
#define HDCP_ENABLE         6
#define HDCP_DISABLE        7
#define HDCP_RI_STATUS      8
#define EVENT_NOTIFY        9

/* BIT FIELD */
#define SET_FIFORTS         (1<<1)
#define SET_SWRST           (1<<0)
#define SET_VSYNC           (1<<6)
#define SET_VEN             (1<<5)
#define SET_HEN             (1<<4)
#define SET_BSEL            (1<<2)
#define SET_EDGE            (1<<1)
#define SET_PD              (1<<0)
#define SET_VLOW            (1<<7)
#define SET_RSEN            (1<<2)
#define SET_HPD             (1<<1)
#define P_STABLE            (1<<0)

#define SET_PLLF_80UA       (0xf<<1)
#define SET_PLLF_45UA       (0x8<<1)
#define SET_PLLF_40UA       (0x7<<1)
#define SET_PLLF_25UA       (0x4<<1)
#define SET_PLLF_15UA       (0x2<<1)
#define SET_PLLF_10UA       (0x1<<1)
#define SET_PLLF_5UA        (0x0)
#define PFEN_ENABLE         (0x1)
#define SET_VID_BLANK       (1<<2)
#define SET_AUD_MUTE        (1<<1)
#define BKSV_ERR            (1<<5)
#define RX_RPTR_ENABLE      (1<<4)
#define TX_ANSTOP           (1<<3)
#define SET_CP_RESTN        (1<<2)
#define SET_ENC_EN          (1<<0)
#define BCAP_ENABLE         (1<<1)
#define SET_RI_ENABLE       (1<<0)
#define SET_RI_DBG_TRASH    (1<<7)
#define SET_RI_DBG_HOLD     (1<<6)
#define DE_GEN_ENABLE       (1<<6)
#define SET_VS_POL_NEG      (1<<5)
#define SET_HS_POL_NEG      (1<<4)
#define SET_IFPOL_INVERT    (1<<7)
#define SET_EXTN_12BIT      (1<<5)
#define SET_EXTN_8BIT       ~(1<<5)
#define CSCSEL_BT709        (1<<4)
#define CSCSEL_BT601        ~(1<<4)
#define PIXEL_REP_4         (0x3)
#define PIXEL_REP_1         (0x1)
#define PIXEL_NO_REP        (0x0)
#define SET_WIDE_BUS_12BITS     (0x2<<7)
#define SET_WIDE_BUS_10BITS     (0x1<<7)
#define SET_WIDE_BUS_0BITS      (0x0)
#define CLIP_CS_ID_YCBCR    (1<<4)
#define CLIP_CS_ID_RGB      ~(1<<4)
#define RANGE_CLIP_ENABLE   (1<<3)
#define RGB2YCBCR_ENABLE    (1<<2)
#define RANGE_CMPS_ENABLE   (1<<1)
#define DOWN_SMPL_ENABLE    (1<<0)
#define DITHER_ENABLE       (1<<5)
#define RANGE_ENABLE        (1<<4)
#define CSC_ENABLE          (1<<3)
#define UPSMP_ENABLE        (1<<2)
#define DEMUX_ENABLE        (1<<1)
#define SYNCEXT_ENABLE      (1<<0)
#define INTR1_SOFT          (1<<7)
#define INTR1_HPD           (1<<6)
#define INTR1_RSEN          (1<<5)
#define INTR1_DROP_SAMPLE   (1<<4)
#define INTR1_BI_PHASE_ERR  (1<<3)
#define INTR1_RI_128        (1<<2)
#define INTR1_OVER_RUN      (1<<1)
#define INTR1_UNDER_RUN     (1<<0)
#define INTR2_BCAP_DONE     (1<<7)
#define INTR2_SPDIF_PAR     (1<<6)
#define INTR2_ENC_DIS       (1<<5)
#define INTR2_PREAM_ERR     (1<<4)
#define INTR2_CTS_CHG       (1<<3)
#define INTR2_ACR_OVR       (1<<2)
#define INTR2_TCLK_STBL     (1<<1)
#define INTR2_VSYNC_REC     (1<<0)
#define SOFT_INTR_CLEAR     ~(1<<3)
#define SET_SOFT_INTR       (1<<3)
#define OPEN_DRAIN_ENABLE   (1<<2)
#define SET_POLARITY_LOW    (1<<1)
#define SET_TCLKSEL_40      (0x3<<6)
#define SET_TCLKSEL_20      (0x2<<6)
#define SET_TCLKSEL_10      (0x1<<6)
#define SET_TCLKSEL_05      (0x0<<6)
#define LVBIAS_ENABLE       (1<<2)
#define STERM_ENABLE        (1<<0)
#define SD3_ENABLE          (1<<7)
#define SD2_ENABLE          (1<<6)
#define SD1_ENABLE          (1<<5)
#define SD0_ENABLE          (1<<4)
#define DSD_ENABLE          (1<<3)
#define SPDIF_ENABLE        (1<<1)
#define AUD_ENABLE          (1<<0)
#define PDIDCK_NORMAL       (1<<2)
#define PDOSC_NORMAL        (1<<1)
#define PDTOT_NORMAL        (1<<0)
#define MPEG_ENABLE         (1<<7)
#define MPEG_RPT_ENABLE     (1<<6)
#define CEA861_AUD_ENABLE   (1<<5)
#define AUD_RPT_ENABLE      (1<<4)
#define SPD_ENABLE          (1<<3)
#define SPD_RPT_ENABLE      (1<<2)
#define AVI_ENABLE          (1<<1)
#define AVI_RPT_ENABLE      (1<<0)
#define HDMI_LAYOUT0        ~(1<<1)
#define HDMI_LAYOUT1        (1<<1)
#define HDMI_MODE_ENABLE    (1<<0)
#define SET_MAN_OVR         (1<<7)
#define SET_MAN_SDA         (1<<5)
#define SET_MAN_SCL         (1<<4)
#define HDCP_ACC            20
#define SET_CP_RESTN        (1<<2)
#define NCTSPKT_ENABLE      (1<<1)
#define CTS_SEL             (1<<0)
#define BIT_AVI_EN_REPEAT   0x0003
#define LD_KSV              (1<<5)
#define DDC_BIT_REPEATER    (0x40)
#define DDC_BIT_FIFO_READY  (0x20)
#define DDC_BIT_FAST_I2C    (0x10)
#define DDC_BSTATUS_ADDR    (0x41) 
#define DDC_BSTATUS_1_ADDR  (0x41)
#define DDC_BSTATUS_2_ADDR  (0x42)
#define DDC_BIT_HDMI_MODE   (0x10)
#define DDC_KSV_FIFO_ADDR   (0x43) 


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

UINT32 position[4] = {0x01680025, 0x01180025, 0x00C00014, 0x00C00029};


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 sil9034_write(UINT8 slave, UINT8 reg, UINT8 value)
{
    UINT32 RdData = 0;
    INT32 Result = NC_SUCCESS;

    APACHE_SYS_mDelay(2);

    DEBUGMSG(MSGINFO, ".");

    if(slave == SLAVE0)
        Result = ncLib_I2C_Write(I2C_CH1, TX_SLV0, reg, value, 1, I2C_ADDR_8_DATA_8);
    else
        Result = ncLib_I2C_Write(I2C_CH1, TX_SLV1, reg, value, 1, I2C_ADDR_8_DATA_8);

#if 1
    APACHE_SYS_mDelay(10);

    RdData = 0;

    if(slave == SLAVE0)
        Result |= ncLib_I2C_Read(I2C_CH1, TX_SLV0, reg, &RdData, 1, I2C_ADDR_8_DATA_8);
    else
        Result |= ncLib_I2C_Read(I2C_CH1, TX_SLV1, reg, &RdData, 1, I2C_ADDR_8_DATA_8);

    if(value != RdData)
    {
        if(slave == SLAVE0)
        {
            if(reg == TX_SWRST_ADDR)
            {
                /* 0x72, 0x05, 0xFC != 0x00 : bit 5 Audio Enable */
            }
            else
            {
                DEBUGMSG(MSGWARN, "\nWarning, SIL9034 - DeviceID[0x%02X] RegAdd[0x%04X] WD[0x%02X] != RD[0x%02X]\n", TX_SLV0, reg, value, RdData);
            }
        }
        else
        {
            if(reg == INF_CTRL1)
            {
                /* 0x7A, 0x3E, 0x31 != 0x11 : bit 5 Audio Enable */
            }
            else
            {
                DEBUGMSG(MSGWARN, "\nWarning, SIL9034 - DeviceID[0x%02X] RegAdd[0x%04X] WD[0x%02X] != RD[0x%02X]\n", TX_SLV1, reg, value, RdData);
            }
        }
    }
#endif

    return Result;
}


INT32 sil9034_cea861InfoFrameControl1(UINT8 enable)
{
    INT32 Result = NC_SUCCESS;

    /* enable the avi repeat transmission */

    if(enable)
        Result |= sil9034_write(SLAVE1, INF_CTRL1, (BIT_AVI_REPEAT |BIT_AUD_ENABLE |BIT_AUD_REPEAT));
    else
        Result |= sil9034_write(SLAVE1, INF_CTRL1, 0);

    return Result;
}


INT32 sil9034_cea861InfoFrameSetting(void)
{
    UINT8 avi_info_addr;
    INT32 Result = NC_SUCCESS;

    /* set the info frame type according to CEA-861 datasheet */
    avi_info_addr = AVI_IF_ADDR;

    /* AVI type */
    Result |= sil9034_write(SLAVE1, avi_info_addr++, 0x82);

    /* AVI version */
    Result |= sil9034_write(SLAVE1, avi_info_addr++, 0x02);

    /* AVI length */
    Result |= sil9034_write(SLAVE1, avi_info_addr++, 0x0D);

    /* AVI CRC */
    Result |= sil9034_write(SLAVE1, avi_info_addr++, (0x82 + 0x02 + 0x0D + 0x3D));

    /* AVI DATA BYTE , according to Sil FAE, 3 byte is enought. page 102 */
    /* 0 | Y1 | Y0 | A0 | B1 | B0 | S1 | S0 */
    Result |= sil9034_write(SLAVE1, avi_info_addr++, 0x3D);

    /* C1 | C0 | M1 | M0 | R3 | R2 | R1 | R0 */
    Result |= sil9034_write(SLAVE1, avi_info_addr++, 0x68);

    /* 0 | 0 | 0 | 0 | 0 | 0 | SC1 | SC0 */
    Result |= sil9034_write(SLAVE1, avi_info_addr++, 0x03);

    return Result;
}


INT32 sil9034_powerDown(UINT8 enable)
{
    INT32 Result = NC_SUCCESS;

    /* power down internal oscillator
    disable internal read of HDCP keys and KSV
    disable master DDC block
    page 4,50,113 */

    if(enable)
    {
        Result |= sil9034_write(SLAVE1, DIAG_PD_ADDR, ~(0x7));
        Result |= sil9034_write(SLAVE0, TX_SYS_CTRL1_ADDR, 0x34 & ~0x1);
    }
    else
    {
        Result |= sil9034_write(SLAVE1, DIAG_PD_ADDR, 0x7);
        Result |= sil9034_write(SLAVE0, TX_SYS_CTRL1_ADDR, (0x34 | 0x1));
    }

    return Result;
}


INT32 sil9034_swReset(void)
{
    INT32 Result = NC_SUCCESS;

    /* audio fifo reset enable software reset enable */

    Result |= sil9034_write(SLAVE0, TX_SWRST_ADDR, (BIT_TX_SW_RST|BIT_TX_FIFO_RST));

    APACHE_SYS_mDelay(2);

    Result |= sil9034_write(SLAVE0, TX_SWRST_ADDR, ~(BIT_TX_SW_RST|BIT_TX_FIFO_RST));

    return Result;
}


INT32 sil9034_hdmiOutputConfig(void)
{
    /* HDMI control register, enable HDMI, disable DVI */

    return (sil9034_write(SLAVE1, HDMI_CTRL_ADDR, (0x1)));
}


INT32 sil9034_hdmiTmdsConfig(void)
{
    /* TMDS control register FPLL is 1.0*IDCK.
    Internal source termination enabled.
    Driver level shifter bias enabled.
    page 27 */

    return (sil9034_write(SLAVE0, TX_TMDS_CTRL_ADDR, 0x25|0x5));
}


INT32 sil9034_hdmiHdcpConfig(UINT8 enable)
{
    /* HDMI HDCP configuration */

    return (sil9034_write(SLAVE0, HDCP_CTRL_ADDR, (enable)));
}


INT32 sil9034_videoInputConfig(void)
{
    UINT16 de_delay, top_delay;
    INT32 Result = NC_SUCCESS;

    //DEBUGMSG(MSGINFO, "\nSIL9034 - YCbCr4:2:2_HDp\n");

    de_delay = position[3]>>16;	// 0x00C0
    top_delay = position[3]&0xffff;	// 0x0029

    //if(ncLib_SWR_Control(GCMD_SWR_GET_DATA, SWR_ID_DISPLAY_MODE, CMD_END))
    if(1)   // HDMI Mode
    {
        Result |= sil9034_write(SLAVE0, DE_CTRL_ADDR, 0x00|(de_delay>>8));	// de_delay=0x00

        /* Video DE delay register */
        Result |= sil9034_write(SLAVE0, DE_DELAY_ADDR, de_delay&0xff);	// de_delay=0xC0

        /* Video DE top register, DE_TOP 6:0=0x29 */
        Result |= sil9034_write(SLAVE0, DE_TOP_ADDR+0, top_delay&0xff);	// top_delay=0x29
        Result |= sil9034_write(SLAVE0, DE_TOP_ADDR+1, top_delay>>8);	// top_delay=0x00

        /* Video DE cnt high byte register, DE_CNT 3:0=0x7 */
        Result |= sil9034_write(SLAVE0, DE_CNTH_ADDR, 0x7);

        /* Video DE cnt low byte register, DE_CNT 7:0=0x80 */
        Result |= sil9034_write(SLAVE0, DE_CNTL_ADDR, 0x80);

        /* Video DE line high byte register, DE_LIN 2:0=0x4 */
        Result |= sil9034_write(SLAVE0, DEL_H_ADDR, 0x4);

        /* Video DE line low byte register, DE_LIN 7:0=0x38 */
        Result |= sil9034_write(SLAVE0, DEL_L_ADDR, 0x38);
    }
    else		
    {
        Result |= sil9034_write(SLAVE0, 0x33, 0x30);  // slave-0 De_ctrl
        Result |= sil9034_write(SLAVE0, 0x32, 0xC0);  // slave-0 de_delay
        Result |= sil9034_write(SLAVE0, 0x34, 0x29);  //	slave-0, de_top_L
        Result |= sil9034_write(SLAVE0, 0x35, 0x00);  //	slave-0, de_top_H
        Result |= sil9034_write(SLAVE0, 0x36, 0x80);  //slave-0, DE_CNT_L
        Result |= sil9034_write(SLAVE0, 0x37, 0x07);  //slave-0, DE_CNT_H
        Result |= sil9034_write(SLAVE0, 0x38, 0x00);  //slave-0, DEL_L
        Result |= sil9034_write(SLAVE0, 0x39, 0x00);  //slave-0, DEL_H	
    }

    //if(ncLib_SWR_Control(GCMD_SWR_GET_DATA, SWR_ID_DISPLAY_MODE, CMD_END))
    if(1)   // HDMI Mode
    {
        // 720p YCbCr 4:2:2 Embedded sync input
        Result |= sil9034_write(SLAVE0, 0x41, 0x00);
        Result |= sil9034_write(SLAVE0, 0x40, 0x6e);
        Result |= sil9034_write(SLAVE0, 0x43, 0x04);
        Result |= sil9034_write(SLAVE0, 0x42, 0x4c);
        Result |= sil9034_write(SLAVE0, 0x45, 0x00);
        Result |= sil9034_write(SLAVE0, 0x44, 0x28);
        Result |= sil9034_write(SLAVE0, 0x46, 0x05);
        Result |= sil9034_write(SLAVE0, 0x47, 0x05);

        /* Video control register , ICLK = 00 EXTN = 1 */
        Result |= sil9034_write(SLAVE0, TX_VID_CTRL_ADDR, 0x30);

        /* Video mode register , SYNCEXT=0 DEMUX=0 UPSMP=0 CSC=0 DITHER = 0 */

        //YCbCr 4:2:2 Embedded sync input, FRC FPGA B/D
        //if ((OUTPUT_FORMATTER == BT1120)||(OUTPUT_FORMATTER == BT656))
        Result |= sil9034_write(SLAVE0, TX_VID_MODE_ADDR, 0x2D);

        //DEBUGMSG(MSGINFO, "SIL9034 [Embedded Sync] --> HalfBoard [BT1120 or BT656] --> HDMI\n");
    }
    else
    {
        Result |= sil9034_write(SLAVE0, 0x41, 0x00);	
        Result |= sil9034_write(SLAVE0, 0x40, 0x10);
        Result |= sil9034_write(SLAVE0, 0x43, 0x01);
        Result |= sil9034_write(SLAVE0, 0x42, 0xad);
        Result |= sil9034_write(SLAVE0, 0x45, 0x00);
        Result |= sil9034_write(SLAVE0, 0x44, 0x3e);
        Result |= sil9034_write(SLAVE0, 0x46, 0x09);
        Result |= sil9034_write(SLAVE0, 0x47, 0x06);

        //DEBUGMSG(MSGINFO, "SIL9034 [Embedded Sync] --> HalfBoard [BT1120 or BT656] --> CVBS\n");
    }

    //YCbCr 4:2:2 Separate sync input
    //sil9034_write(SLAVE0, TX_VID_MODE_ADDR, 0x3C);
    //DEBUGMSG(MSGINFO, "SIL9034 [Seperated Sync] --> HalfBoard [YC16] --> HDMI\n");

    return Result;
}


INT32 sil9034_unmaskInterruptStatus(void)
{
    INT32 Result = NC_SUCCESS;

    Result |= sil9034_write(SLAVE0, HDMI_INT1_MASK, 0xff);
    Result |= sil9034_write(SLAVE0, HDMI_INT2_MASK, 0xff);
    Result |= sil9034_write(SLAVE0, HDMI_INT3_MASK, 0xff);

    return Result;
}


INT32 sil9034_clearInterruptStatus(void)
{
    INT32 Result = NC_SUCCESS;

    Result |= sil9034_write(SLAVE0, INT_SOURCE1_ADDR, 0xFF);
    Result |= sil9034_write(SLAVE0, INT_SOURCE2_ADDR, 0xFF);
    Result |= sil9034_write(SLAVE0, INT_SOURCE3_ADDR, 0xFF);

    return Result;
}


INT32 APACHE_SYS_InitSIL9034(void)
{
    INT32 Result = NC_SUCCESS;

    //DEBUGMSG(MSGINFO, "\n");

    /* power down occilator */
    Result |= sil9034_powerDown(ENABLE);

    /* Tune the video input table according to DM320 hardware spec */
    Result |= sil9034_videoInputConfig();

    /* software reset */
    Result |= sil9034_swReset();

    /* power up occilator */
    Result |= sil9034_powerDown(DISABLE);

    /* unmask the interrupt status */
    Result |= sil9034_unmaskInterruptStatus();

    /* Hdmi output setting */
    Result |= sil9034_hdmiOutputConfig();

    /* TMDS control register */
    Result |= sil9034_hdmiTmdsConfig();

    /* HDCP control handshaking */
    Result |= sil9034_hdmiHdcpConfig(DISABLE);

    /* enable the avi repeat transmission */
    Result |= sil9034_cea861InfoFrameControl1(ENABLE);

    /* CEA-861 Info Frame control setting */
    Result |= sil9034_cea861InfoFrameSetting();

    return Result;
}


/* End Of File */
