/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : AR0132AT.c
*
*  @brief   : CMOS camera sensor controller test application source file
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.07
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "AR0132AT.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define RESOLUTION_720                      720
#define RESOLUTION_960                      960

#define FRAME_30                            30
#define FRAME_45                            45
#define FRAME_60                            60

#define AR0132AT_RESOLUTION                 RESOLUTION_720
#define AR0132AT_FRAME_LENGTH               FRAME_30


#define CMOS_MODE                           CMOS_MODE_LINEAR


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

typedef struct
{
    UINT16 Addr;
    UINT16 Data;
} AR0132AT_DATA;


#if (CMOS_MODE == CMOS_MODE_LINEAR)

AR0132AT_DATA gAR0132AT_Table[] =
{
    ///////////////////////////////////////////////////////////
    // 1280x960 30fps 
    // 

    //0x2700 0x0000
    //0x0000 0x0000
    //0x0020 0x0003
    //0x1000 0x1000

    //H/W Reset
    0x301A, 0x0001,  //RESET_REGISTER
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,
    0x301A, 0x10D8,  //RESET_REGISTER

    //DELAY= 200
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,

    //A-1000 Hidy and linear sequencer no hold time August 3 2012
    0x3088, 0x8000,  //SEQ_CTRL_PORT
    0x3086, 0x0025,  //SEQ_DATA_PORT
    0x3086, 0x5050,  //SEQ_DATA_PORT
    0x3086, 0x2D26,  //SEQ_DATA_PORT
    0x3086, 0x0828,  //SEQ_DATA_PORT
    0x3086, 0x0D17,  //SEQ_DATA_PORT
    0x3086, 0x0926,  //SEQ_DATA_PORT
    0x3086, 0x0028,  //SEQ_DATA_PORT
    0x3086, 0x0526,  //SEQ_DATA_PORT
    0x3086, 0xA728,  //SEQ_DATA_PORT
    0x3086, 0x0725,  //SEQ_DATA_PORT
    0x3086, 0x8080,  //SEQ_DATA_PORT
    0x3086, 0x2925,  //SEQ_DATA_PORT
    0x3086, 0x0040,  //SEQ_DATA_PORT
    0x3086, 0x2700,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x2700,  //SEQ_DATA_PORT
    0x3086, 0x1F17,  //SEQ_DATA_PORT
    0x3086, 0x3626,  //SEQ_DATA_PORT
    0x3086, 0xA617,  //SEQ_DATA_PORT
    0x3086, 0x0326,  //SEQ_DATA_PORT
    0x3086, 0xA417,  //SEQ_DATA_PORT
    0x3086, 0x1F28,  //SEQ_DATA_PORT
    0x3086, 0x0526,  //SEQ_DATA_PORT
    0x3086, 0x2028,  //SEQ_DATA_PORT
    0x3086, 0x0425,  //SEQ_DATA_PORT
    0x3086, 0x2020,  //SEQ_DATA_PORT
    0x3086, 0x2700,  //SEQ_DATA_PORT
    0x3086, 0x171D,  //SEQ_DATA_PORT
    0x3086, 0x2500,  //SEQ_DATA_PORT
    0x3086, 0x2017,  //SEQ_DATA_PORT
    0x3086, 0x1219,  //SEQ_DATA_PORT
    0x3086, 0x1703,  //SEQ_DATA_PORT
    0x3086, 0x2700,  //SEQ_DATA_PORT
    0x3086, 0x1728,  //SEQ_DATA_PORT
    0x3086, 0x2805,  //SEQ_DATA_PORT
    0x3086, 0x1710,  //SEQ_DATA_PORT
    0x3086, 0x2706,  //SEQ_DATA_PORT
    0x3086, 0x1708,  //SEQ_DATA_PORT
    0x3086, 0x2660,  //SEQ_DATA_PORT
    0x3086, 0x175A,  //SEQ_DATA_PORT
    0x3086, 0x2317,  //SEQ_DATA_PORT
    0x3086, 0x1122,  //SEQ_DATA_PORT
    0x3086, 0x1741,  //SEQ_DATA_PORT
    0x3086, 0x2500,  //SEQ_DATA_PORT
    0x3086, 0x9027,  //SEQ_DATA_PORT
    0x3086, 0x0026,  //SEQ_DATA_PORT
    0x3086, 0x1828,  //SEQ_DATA_PORT
    0x3086, 0x002E,  //SEQ_DATA_PORT
    0x3086, 0x2A28,  //SEQ_DATA_PORT
    0x3086, 0x081C,  //SEQ_DATA_PORT
    0x3086, 0x1470,  //SEQ_DATA_PORT
    0x3086, 0x7003,  //SEQ_DATA_PORT
    0x3086, 0x1470,  //SEQ_DATA_PORT
    0x3086, 0x7004,  //SEQ_DATA_PORT
    0x3086, 0x1470,  //SEQ_DATA_PORT
    0x3086, 0x7005,  //SEQ_DATA_PORT
    0x3086, 0x1470,  //SEQ_DATA_PORT
    0x3086, 0x7009,  //SEQ_DATA_PORT
    0x3086, 0x170C,  //SEQ_DATA_PORT
    0x3086, 0x0014,  //SEQ_DATA_PORT
    0x3086, 0x0020,  //SEQ_DATA_PORT
    0x3086, 0x0014,  //SEQ_DATA_PORT
    0x3086, 0x0050,  //SEQ_DATA_PORT
    0x3086, 0x0314,  //SEQ_DATA_PORT
    0x3086, 0x0020,  //SEQ_DATA_PORT
    0x3086, 0x0314,  //SEQ_DATA_PORT
    0x3086, 0x0050,  //SEQ_DATA_PORT
    0x3086, 0x0414,  //SEQ_DATA_PORT
    0x3086, 0x0020,  //SEQ_DATA_PORT
    0x3086, 0x0414,  //SEQ_DATA_PORT
    0x3086, 0x0050,  //SEQ_DATA_PORT
    0x3086, 0x0514,  //SEQ_DATA_PORT
    0x3086, 0x0020,  //SEQ_DATA_PORT
    0x3086, 0x2405,  //SEQ_DATA_PORT
    0x3086, 0x1400,  //SEQ_DATA_PORT
    0x3086, 0x5001,  //SEQ_DATA_PORT
    0x3086, 0x2550,  //SEQ_DATA_PORT
    0x3086, 0x502D,  //SEQ_DATA_PORT
    0x3086, 0x2608,  //SEQ_DATA_PORT
    0x3086, 0x280D,  //SEQ_DATA_PORT
    0x3086, 0x1709,  //SEQ_DATA_PORT
    0x3086, 0x2600,  //SEQ_DATA_PORT
    0x3086, 0x2805,  //SEQ_DATA_PORT
    0x3086, 0x26A7,  //SEQ_DATA_PORT
    0x3086, 0x2807,  //SEQ_DATA_PORT
    0x3086, 0x2580,  //SEQ_DATA_PORT
    0x3086, 0x8029,  //SEQ_DATA_PORT
    0x3086, 0x2500,  //SEQ_DATA_PORT
    0x3086, 0x4027,  //SEQ_DATA_PORT
    0x3086, 0x0016,  //SEQ_DATA_PORT
    0x3086, 0x1627,  //SEQ_DATA_PORT
    0x3086, 0x0020,  //SEQ_DATA_PORT
    0x3086, 0x1736,  //SEQ_DATA_PORT
    0x3086, 0x26A6,  //SEQ_DATA_PORT
    0x3086, 0x1703,  //SEQ_DATA_PORT
    0x3086, 0x26A4,  //SEQ_DATA_PORT
    0x3086, 0x171F,  //SEQ_DATA_PORT
    0x3086, 0x2805,  //SEQ_DATA_PORT
    0x3086, 0x2620,  //SEQ_DATA_PORT
    0x3086, 0x2804,  //SEQ_DATA_PORT
    0x3086, 0x2520,  //SEQ_DATA_PORT
    0x3086, 0x2027,  //SEQ_DATA_PORT
    0x3086, 0x0017,  //SEQ_DATA_PORT
    0x3086, 0x1D25,  //SEQ_DATA_PORT
    0x3086, 0x0020,  //SEQ_DATA_PORT
    0x3086, 0x1712,  //SEQ_DATA_PORT
    0x3086, 0x1A17,  //SEQ_DATA_PORT
    0x3086, 0x0327,  //SEQ_DATA_PORT
    0x3086, 0x0017,  //SEQ_DATA_PORT
    0x3086, 0x2828,  //SEQ_DATA_PORT
    0x3086, 0x0517,  //SEQ_DATA_PORT
    0x3086, 0x1027,  //SEQ_DATA_PORT
    0x3086, 0x0617,  //SEQ_DATA_PORT
    0x3086, 0x0826,  //SEQ_DATA_PORT
    0x3086, 0x6017,  //SEQ_DATA_PORT
    0x3086, 0x9827,  //SEQ_DATA_PORT
    0x3086, 0x0017,  //SEQ_DATA_PORT
    0x3086, 0x1525,  //SEQ_DATA_PORT
    0x3086, 0x0090,  //SEQ_DATA_PORT
    0x3086, 0x2700,  //SEQ_DATA_PORT
    0x3086, 0x2618,  //SEQ_DATA_PORT
    0x3086, 0x2800,  //SEQ_DATA_PORT
    0x3086, 0x2E2A,  //SEQ_DATA_PORT
    0x3086, 0x2808,  //SEQ_DATA_PORT
    0x3086, 0x1D05,  //SEQ_DATA_PORT
    0x3086, 0x1470,  //SEQ_DATA_PORT
    0x3086, 0x7009,  //SEQ_DATA_PORT
    0x3086, 0x1720,  //SEQ_DATA_PORT
    0x3086, 0x1400,  //SEQ_DATA_PORT
    0x3086, 0x2024,  //SEQ_DATA_PORT
    0x3086, 0x1400,  //SEQ_DATA_PORT
    0x3086, 0x5002,  //SEQ_DATA_PORT
    0x3086, 0x2550,  //SEQ_DATA_PORT
    0x3086, 0x502D,  //SEQ_DATA_PORT
    0x3086, 0x2608,  //SEQ_DATA_PORT
    0x3086, 0x280D,  //SEQ_DATA_PORT
    0x3086, 0x1709,  //SEQ_DATA_PORT
    0x3086, 0x2600,  //SEQ_DATA_PORT
    0x3086, 0x2805,  //SEQ_DATA_PORT
    0x3086, 0x26A7,  //SEQ_DATA_PORT
    0x3086, 0x2807,  //SEQ_DATA_PORT
    0x3086, 0x2580,  //SEQ_DATA_PORT
    0x3086, 0x8029,  //SEQ_DATA_PORT
    0x3086, 0x2500,  //SEQ_DATA_PORT
    0x3086, 0x4027,  //SEQ_DATA_PORT
    0x3086, 0x0016,  //SEQ_DATA_PORT
    0x3086, 0x1627,  //SEQ_DATA_PORT
    0x3086, 0x0017,  //SEQ_DATA_PORT
    0x3086, 0x3626,  //SEQ_DATA_PORT
    0x3086, 0xA617,  //SEQ_DATA_PORT
    0x3086, 0x0326,  //SEQ_DATA_PORT
    0x3086, 0xA417,  //SEQ_DATA_PORT
    0x3086, 0x1F28,  //SEQ_DATA_PORT
    0x3086, 0x0526,  //SEQ_DATA_PORT
    0x3086, 0x2028,  //SEQ_DATA_PORT
    0x3086, 0x0425,  //SEQ_DATA_PORT
    0x3086, 0x2020,  //SEQ_DATA_PORT
    0x3086, 0x2700,  //SEQ_DATA_PORT
    0x3086, 0x171D,  //SEQ_DATA_PORT
    0x3086, 0x2500,  //SEQ_DATA_PORT
    0x3086, 0x2021,  //SEQ_DATA_PORT
    0x3086, 0x1712,  //SEQ_DATA_PORT
    0x3086, 0x1B17,  //SEQ_DATA_PORT
    0x3086, 0x0327,  //SEQ_DATA_PORT
    0x3086, 0x0017,  //SEQ_DATA_PORT
    0x3086, 0x2828,  //SEQ_DATA_PORT
    0x3086, 0x0517,  //SEQ_DATA_PORT
    0x3086, 0x1027,  //SEQ_DATA_PORT
    0x3086, 0x0617,  //SEQ_DATA_PORT
    0x3086, 0x0826,  //SEQ_DATA_PORT
    0x3086, 0x6017,  //SEQ_DATA_PORT
    0x3086, 0x9827,  //SEQ_DATA_PORT
    0x3086, 0x0017,  //SEQ_DATA_PORT
    0x3086, 0x1525,  //SEQ_DATA_PORT
    0x3086, 0x0090,  //SEQ_DATA_PORT
    0x3086, 0x2700,  //SEQ_DATA_PORT
    0x3086, 0x2618,  //SEQ_DATA_PORT
    0x3086, 0x2800,  //SEQ_DATA_PORT
    0x3086, 0x2E2A,  //SEQ_DATA_PORT
    0x3086, 0x2808,  //SEQ_DATA_PORT
    0x3086, 0x1E17,  //SEQ_DATA_PORT
    0x3086, 0x0A05,  //SEQ_DATA_PORT
    0x3086, 0x1470,  //SEQ_DATA_PORT
    0x3086, 0x7009,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x1614,  //SEQ_DATA_PORT
    0x3086, 0x0020,  //SEQ_DATA_PORT
    0x3086, 0x2414,  //SEQ_DATA_PORT
    0x3086, 0x0050,  //SEQ_DATA_PORT
    0x3086, 0x2B2B,  //SEQ_DATA_PORT
    0x3086, 0x2C2C,  //SEQ_DATA_PORT
    0x3086, 0x2C2C,  //SEQ_DATA_PORT
    0x3086, 0x2C00,  //SEQ_DATA_PORT
    0x3086, 0x0225,  //SEQ_DATA_PORT
    0x3086, 0x5050,  //SEQ_DATA_PORT
    0x3086, 0x2D26,  //SEQ_DATA_PORT
    0x3086, 0x0828,  //SEQ_DATA_PORT
    0x3086, 0x0D17,  //SEQ_DATA_PORT
    0x3086, 0x0926,  //SEQ_DATA_PORT
    0x3086, 0x0028,  //SEQ_DATA_PORT
    0x3086, 0x0526,  //SEQ_DATA_PORT
    0x3086, 0xA728,  //SEQ_DATA_PORT
    0x3086, 0x0725,  //SEQ_DATA_PORT
    0x3086, 0x8080,  //SEQ_DATA_PORT
    0x3086, 0x2917,  //SEQ_DATA_PORT
    0x3086, 0x0525,  //SEQ_DATA_PORT
    0x3086, 0x0040,  //SEQ_DATA_PORT
    0x3086, 0x2700,  //SEQ_DATA_PORT
    0x3086, 0x1616,  //SEQ_DATA_PORT
    0x3086, 0x2700,  //SEQ_DATA_PORT
    0x3086, 0x1736,  //SEQ_DATA_PORT
    0x3086, 0x26A6,  //SEQ_DATA_PORT
    0x3086, 0x1703,  //SEQ_DATA_PORT
    0x3086, 0x26A4,  //SEQ_DATA_PORT
    0x3086, 0x171F,  //SEQ_DATA_PORT
    0x3086, 0x2805,  //SEQ_DATA_PORT
    0x3086, 0x2620,  //SEQ_DATA_PORT
    0x3086, 0x2804,  //SEQ_DATA_PORT
    0x3086, 0x2520,  //SEQ_DATA_PORT
    0x3086, 0x2027,  //SEQ_DATA_PORT
    0x3086, 0x0017,  //SEQ_DATA_PORT
    0x3086, 0x1E25,  //SEQ_DATA_PORT
    0x3086, 0x0020,  //SEQ_DATA_PORT
    0x3086, 0x2117,  //SEQ_DATA_PORT
    0x3086, 0x121B,  //SEQ_DATA_PORT
    0x3086, 0x1703,  //SEQ_DATA_PORT
    0x3086, 0x2700,  //SEQ_DATA_PORT
    0x3086, 0x1728,  //SEQ_DATA_PORT
    0x3086, 0x2805,  //SEQ_DATA_PORT
    0x3086, 0x1710,  //SEQ_DATA_PORT
    0x3086, 0x2706,  //SEQ_DATA_PORT
    0x3086, 0x1708,  //SEQ_DATA_PORT
    0x3086, 0x2660,  //SEQ_DATA_PORT
    0x3086, 0x1798,  //SEQ_DATA_PORT
    0x3086, 0x2700,  //SEQ_DATA_PORT
    0x3086, 0x1715,  //SEQ_DATA_PORT
    0x3086, 0x2500,  //SEQ_DATA_PORT
    0x3086, 0x9027,  //SEQ_DATA_PORT
    0x3086, 0x0026,  //SEQ_DATA_PORT
    0x3086, 0x1828,  //SEQ_DATA_PORT
    0x3086, 0x002E,  //SEQ_DATA_PORT
    0x3086, 0x2A28,  //SEQ_DATA_PORT
    0x3086, 0x081E,  //SEQ_DATA_PORT
    0x3086, 0x0831,  //SEQ_DATA_PORT
    0x3086, 0x1440,  //SEQ_DATA_PORT
    0x3086, 0x4014,  //SEQ_DATA_PORT
    0x3086, 0x2020,  //SEQ_DATA_PORT
    0x3086, 0x1410,  //SEQ_DATA_PORT
    0x3086, 0x1034,  //SEQ_DATA_PORT
    0x3086, 0x1400,  //SEQ_DATA_PORT
    0x3086, 0x1014,  //SEQ_DATA_PORT
    0x3086, 0x0020,  //SEQ_DATA_PORT
    0x3086, 0x1400,  //SEQ_DATA_PORT
    0x3086, 0x4013,  //SEQ_DATA_PORT
    0x3086, 0x1802,  //SEQ_DATA_PORT
    0x3086, 0x1470,  //SEQ_DATA_PORT
    0x3086, 0x7004,  //SEQ_DATA_PORT
    0x3086, 0x1470,  //SEQ_DATA_PORT
    0x3086, 0x7003,  //SEQ_DATA_PORT
    0x3086, 0x1470,  //SEQ_DATA_PORT
    0x3086, 0x7017,  //SEQ_DATA_PORT
    0x3086, 0x2002,  //SEQ_DATA_PORT
    0x3086, 0x1400,  //SEQ_DATA_PORT
    0x3086, 0x2002,  //SEQ_DATA_PORT
    0x3086, 0x1400,  //SEQ_DATA_PORT
    0x3086, 0x5004,  //SEQ_DATA_PORT
    0x3086, 0x1400,  //SEQ_DATA_PORT
    0x3086, 0x2004,  //SEQ_DATA_PORT
    0x3086, 0x1400,  //SEQ_DATA_PORT
    0x3086, 0x5022,  //SEQ_DATA_PORT
    0x3086, 0x0314,  //SEQ_DATA_PORT
    0x3086, 0x0020,  //SEQ_DATA_PORT
    0x3086, 0x0314,  //SEQ_DATA_PORT
    0x3086, 0x0050,  //SEQ_DATA_PORT
    0x3086, 0x2C2C,  //SEQ_DATA_PORT
    0x3086, 0x2C2C,  //SEQ_DATA_PORT
    0x309E, 0x019A,  //set start address for linear seq

    //A-1000ERS Optimized setting  no hold time May 5 2012
    0x301E, 0x0000,  //   ); //C8  //DATA_PEDESTAL
    0x3EDA, 0x0F03,  //DAC_LD_14_15
    0x3EDE, 0xC005,  //DAC_LD_18_19
    0x3ED8, 0x09DF,  //DAC_LD_12_13
    0x3EE2, 0xA46B,  //DAC_LD_22_23
    0x3EE0, 0x067D,  //DAC_LD_20_21
    0x3EDC, 0x0070,  //DAC_LD_16_17
    0x3044, 0x1604,  //   ); //0404 ); //DARK_CONTROL
    0x3EE6, 0x8303,  //DAC_LD_26_27
    0x3EE4, 0xD208,  //DAC_LD_24_25
    0x3ED6, 0x00BB,  //DAC_LD_10_11
    0x30E4, 0x6372,  //ADC_BITS_6_7
    0x30E2, 0x7253,  //ADC_BITS_4_5
    0x30E0, 0x5470,  //ADC_BITS_2_3
    0x30E6, 0xC4CC,  //ADC_CONFIG1
    0x30E8, 0x8050,  //ADC_CONFIG2

    //DELAY= 200
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,

    //Linear Parallel Full Resolution
    //[Linear Mode Setup]
    0x301A, 0x10D8,  //RESET_REGISTER
    0x3082, 0x0029,  //OPERATION_MODE_CTRL

    //Column Retriggering at start up
    0x30B0, 0x1300,  //DIGITAL_TEST
    0x30D4, 0xE007,  //COLUMN_CORRECTION
    0x30BA, 0x0008,  //DIGITAL_CTRL
    0x301A, 0x10D8,  //RESET_REGISTER

    //DELAY=200
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,
    0x301A, 0x10D8,  //RESET_REGISTER

    //DELAY=200
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,

    //Linear Mode Devware Color Setup  
    0x3058, 0x003F,  //BLUE_GAIN
    0x3012, 0x02A0,  //COARSE_INTEGRATION_TIME

    //[Full Resolution 30fps Setup]
    //0x3032, 0x0000,  //DIGITAL_BINNING
    //0x3040, 0x8000,   //READ_MODE = 49152     // TEMP
    //0x3002, 0x0002,  //Y_ADDR_START
    //0x3004, 0x0000,  //X_ADDR_START
    //0x3006, 0x03C5,  //Y_ADDR_END
    //0x3008, 0x0503,  //X_ADDR_END
    //0x300A, 0x03E2,  //FRAME_LENGTH_LINES
    //0x300C, 0x08D7,  //LINE_LENGTH_PCK

    0x3032, 0x0000,  //DIGITAL_BINNING
    0x3040, 0x8000, //READ_MODE = 49152     // TEMP
    0x3002, 0x0002,  //Y_ADDR_START
    0x3004, 0x0000,  //X_ADDR_START
    0x3006, 0x03C1,  //Y_ADDR_END
    0x3008, 0x04FF,  //X_ADDR_END
    0x300A, 0x03DE,  //FRAME_LENGTH_LINES
    0x300C, 0x09C4,  //LINE_LENGTH_PCK

    //[Enable Parallel Mode]
    0x301A, 0x10D8,  //RESET_REGISTER
    0x31D0, 0x0001,  //HDR_COMP

    //PLL Enabled 27Mhz to 67.50Mhz
    //0x302C, 0x0001,  //0x0001  VT_SYS_CLK_DIV
    //0x302A, 0x0008,  //0x0008 VT_PIX_CLK_DIV
    //0x302E, 0x0002,  //0x0002 PRE_PLL_CLK_DIV
    //0x3030, 0x0028,  //0x0028 PLL_MULTIPLIER
    //0x30B0, 0x1300,  //DIGITAL_TEST

    //PLL Enabled 27Mhz to 74.25Mhz
    0x302C, 0x0002,  //0x0001  VT_SYS_CLK_DIV
    0x302A, 0x0004,  //0x0008 VT_PIX_CLK_DIV
    0x302E, 0x0002,  //0x0002 PRE_PLL_CLK_DIV
    0x3030, 0x002C,  //0x0028 PLL_MULTIPLIER
    0x30B0, 0x1300,  //DIGITAL_TEST

    //DELAY=100
    0xFEF0, 0x1000,
    0x301A, 0x10D8,  //RESET_REGISTER

    //[Enable AE and Load Optimized Settings For Linear Mode]
    //Disable Embedded Data and Stats
    0x3064, 0x1902,  //EMBEDDED_DATA_CTRL
    0x3064, 0x1802,  //EMBEDDED_DATA_CTRL

    //Linear Mode Devware Color Setup
    0x3058, 0x003F,  //BLUE_GAIN
    0x3100, 0x0000,  // 1B  //AE_CTRL_REG
    0x3112, 0x029F,  //AE_DCG_EXPOSURE_HIGH_REG
    0x3114, 0x008C,  //AE_DCG_EXPOSURE_LOW_REG
    0x3116, 0x02C0,  //AE_DCG_GAIN_FACTOR_REG
    0x3118, 0x005B,  //AE_DCG_GAIN_FACTOR_INV_REG
    0x3102, 0x0384,  //AE_LUMA_TARGET_REG
    0x3104, 0x1000,  //AE_HIST_TARGET_REG
    0x3126, 0x0080,  //AE_ALPHA_V1_REG
    0x311C, 0x03DD,  //AE_MAX_EXPOSURE_REG
    0x311E, 0x0002,  //AE_MIN_EXPOSURE_REG

    0x301A, 0x10DC,  //RESET_REGISTER
};


#elif (CMOS_MODE == CMOS_MODE_WDR)

AR0132AT_DATA gAR0132AT_Table[] =
{
    ///////////////////////////////////////////////////////////
    // 1280x960 30fps 
    // 

    //0x2620, 0x0000,
    //0x0000, 0x0001,       // WDR mode
    //0x0020, 0x0003,
    //0x1000, 0x1000,

    //[Demo Initialization HiDy 16x Mode Full Resolution 30fps]
    //[Reset]
    0x301A, 0x0001,     // RESET_REGISTER
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,
    0x301A, 0x10D8,     // RESET_REGISTER

    //DELAY = 200
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,
    0xFEF0, 0x1000,

    //[A-1000 Hidy and linear sequencer load August 2 2011]
    //fixes fixes hidy color issue from CR32919
    0x3088, 0x8000,     // SEQ_CTRL_PORT
    0x3086, 0x0025,     // SEQ_DATA_PORT
    0x3086, 0x5050,     // SEQ_DATA_PORT
    0x3086, 0x2D26,     // SEQ_DATA_PORT
    0x3086, 0x0828,     // SEQ_DATA_PORT
    0x3086, 0x0D17,     // SEQ_DATA_PORT
    0x3086, 0x0926,     // SEQ_DATA_PORT
    0x3086, 0x0028,     // SEQ_DATA_PORT
    0x3086, 0x0526,     // SEQ_DATA_PORT
    0x3086, 0xA728,     // SEQ_DATA_PORT
    0x3086, 0x0725,     // SEQ_DATA_PORT
    0x3086, 0x8080,     // SEQ_DATA_PORT
    0x3086, 0x2925,     // SEQ_DATA_PORT
    0x3086, 0x0040,     // SEQ_DATA_PORT
    0x3086, 0x2702,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x2706,     // SEQ_DATA_PORT
    0x3086, 0x1F17,     // SEQ_DATA_PORT
    0x3086, 0x3626,     // SEQ_DATA_PORT
    0x3086, 0xA617,     // SEQ_DATA_PORT
    0x3086, 0x0326,     // SEQ_DATA_PORT
    0x3086, 0xA417,     // SEQ_DATA_PORT
    0x3086, 0x1F28,     // SEQ_DATA_PORT
    0x3086, 0x0526,     // SEQ_DATA_PORT
    0x3086, 0x2028,     // SEQ_DATA_PORT
    0x3086, 0x0425,     // SEQ_DATA_PORT
    0x3086, 0x2020,     // SEQ_DATA_PORT
    0x3086, 0x2700,     // SEQ_DATA_PORT
    0x3086, 0x171D,     // SEQ_DATA_PORT
    0x3086, 0x2500,     // SEQ_DATA_PORT
    0x3086, 0x2017,     // SEQ_DATA_PORT
    0x3086, 0x1219,     // SEQ_DATA_PORT
    0x3086, 0x1703,     // SEQ_DATA_PORT
    0x3086, 0x2706,     // SEQ_DATA_PORT
    0x3086, 0x1728,     // SEQ_DATA_PORT
    0x3086, 0x2805,     // SEQ_DATA_PORT
    0x3086, 0x171A,     // SEQ_DATA_PORT
    0x3086, 0x2660,     // SEQ_DATA_PORT
    0x3086, 0x175A,     // SEQ_DATA_PORT
    0x3086, 0x2317,     // SEQ_DATA_PORT
    0x3086, 0x1122,     // SEQ_DATA_PORT
    0x3086, 0x1741,     // SEQ_DATA_PORT
    0x3086, 0x2500,     // SEQ_DATA_PORT
    0x3086, 0x9027,     // SEQ_DATA_PORT
    0x3086, 0x0026,     // SEQ_DATA_PORT
    0x3086, 0x1828,     // SEQ_DATA_PORT
    0x3086, 0x002E,     // SEQ_DATA_PORT
    0x3086, 0x2A28,     // SEQ_DATA_PORT
    0x3086, 0x081C,     // SEQ_DATA_PORT
    0x3086, 0x1470,     // SEQ_DATA_PORT
    0x3086, 0x7003,     // SEQ_DATA_PORT
    0x3086, 0x1470,     // SEQ_DATA_PORT
    0x3086, 0x7004,     // SEQ_DATA_PORT
    0x3086, 0x1470,     // SEQ_DATA_PORT
    0x3086, 0x7005,     // SEQ_DATA_PORT
    0x3086, 0x1470,     // SEQ_DATA_PORT
    0x3086, 0x7009,     // SEQ_DATA_PORT
    0x3086, 0x170C,     // SEQ_DATA_PORT
    0x3086, 0x0014,     // SEQ_DATA_PORT
    0x3086, 0x0020,     // SEQ_DATA_PORT
    0x3086, 0x0014,     // SEQ_DATA_PORT
    0x3086, 0x0050,     // SEQ_DATA_PORT
    0x3086, 0x0314,     // SEQ_DATA_PORT
    0x3086, 0x0020,     // SEQ_DATA_PORT
    0x3086, 0x0314,     // SEQ_DATA_PORT
    0x3086, 0x0050,     // SEQ_DATA_PORT
    0x3086, 0x0414,     // SEQ_DATA_PORT
    0x3086, 0x0020,     // SEQ_DATA_PORT
    0x3086, 0x0414,     // SEQ_DATA_PORT
    0x3086, 0x0050,     // SEQ_DATA_PORT
    0x3086, 0x0514,     // SEQ_DATA_PORT
    0x3086, 0x0020,     // SEQ_DATA_PORT
    0x3086, 0x2405,     // SEQ_DATA_PORT
    0x3086, 0x1400,     // SEQ_DATA_PORT
    0x3086, 0x5001,     // SEQ_DATA_PORT
    0x3086, 0x2550,     // SEQ_DATA_PORT
    0x3086, 0x502D,     // SEQ_DATA_PORT
    0x3086, 0x2608,     // SEQ_DATA_PORT
    0x3086, 0x280D,     // SEQ_DATA_PORT
    0x3086, 0x1709,     // SEQ_DATA_PORT
    0x3086, 0x2600,     // SEQ_DATA_PORT
    0x3086, 0x2805,     // SEQ_DATA_PORT
    0x3086, 0x26A7,     // SEQ_DATA_PORT
    0x3086, 0x2807,     // SEQ_DATA_PORT
    0x3086, 0x2580,     // SEQ_DATA_PORT
    0x3086, 0x8029,     // SEQ_DATA_PORT
    0x3086, 0x2500,     // SEQ_DATA_PORT
    0x3086, 0x4027,     // SEQ_DATA_PORT
    0x3086, 0x0216,     // SEQ_DATA_PORT
    0x3086, 0x1627,     // SEQ_DATA_PORT
    0x3086, 0x0620,     // SEQ_DATA_PORT
    0x3086, 0x1736,     // SEQ_DATA_PORT
    0x3086, 0x26A6,     // SEQ_DATA_PORT
    0x3086, 0x1703,     // SEQ_DATA_PORT
    0x3086, 0x26A4,     // SEQ_DATA_PORT
    0x3086, 0x171F,     // SEQ_DATA_PORT
    0x3086, 0x2805,     // SEQ_DATA_PORT
    0x3086, 0x2620,     // SEQ_DATA_PORT
    0x3086, 0x2804,     // SEQ_DATA_PORT
    0x3086, 0x2520,     // SEQ_DATA_PORT
    0x3086, 0x2027,     // SEQ_DATA_PORT
    0x3086, 0x0017,     // SEQ_DATA_PORT
    0x3086, 0x1D25,     // SEQ_DATA_PORT
    0x3086, 0x0020,     // SEQ_DATA_PORT
    0x3086, 0x1712,     // SEQ_DATA_PORT
    0x3086, 0x1A17,     // SEQ_DATA_PORT
    0x3086, 0x0327,     // SEQ_DATA_PORT
    0x3086, 0x0617,     // SEQ_DATA_PORT
    0x3086, 0x2828,     // SEQ_DATA_PORT
    0x3086, 0x0517,     // SEQ_DATA_PORT
    0x3086, 0x1A26,     // SEQ_DATA_PORT
    0x3086, 0x6017,     // SEQ_DATA_PORT
    0x3086, 0xAE25,     // SEQ_DATA_PORT
    0x3086, 0x0090,     // SEQ_DATA_PORT
    0x3086, 0x2700,     // SEQ_DATA_PORT
    0x3086, 0x2618,     // SEQ_DATA_PORT
    0x3086, 0x2800,     // SEQ_DATA_PORT
    0x3086, 0x2E2A,     // SEQ_DATA_PORT
    0x3086, 0x2808,     // SEQ_DATA_PORT
    0x3086, 0x1D05,     // SEQ_DATA_PORT
    0x3086, 0x1470,     // SEQ_DATA_PORT
    0x3086, 0x7009,     // SEQ_DATA_PORT
    0x3086, 0x1720,     // SEQ_DATA_PORT
    0x3086, 0x1400,     // SEQ_DATA_PORT
    0x3086, 0x2024,     // SEQ_DATA_PORT
    0x3086, 0x1400,     // SEQ_DATA_PORT
    0x3086, 0x5002,     // SEQ_DATA_PORT
    0x3086, 0x2550,     // SEQ_DATA_PORT
    0x3086, 0x502D,     // SEQ_DATA_PORT
    0x3086, 0x2608,     // SEQ_DATA_PORT
    0x3086, 0x280D,     // SEQ_DATA_PORT
    0x3086, 0x1709,     // SEQ_DATA_PORT
    0x3086, 0x2600,     // SEQ_DATA_PORT
    0x3086, 0x2805,     // SEQ_DATA_PORT
    0x3086, 0x26A7,     // SEQ_DATA_PORT
    0x3086, 0x2807,     // SEQ_DATA_PORT
    0x3086, 0x2580,     // SEQ_DATA_PORT
    0x3086, 0x8029,     // SEQ_DATA_PORT
    0x3086, 0x2500,     // SEQ_DATA_PORT
    0x3086, 0x4027,     // SEQ_DATA_PORT
    0x3086, 0x0216,     // SEQ_DATA_PORT
    0x3086, 0x1627,     // SEQ_DATA_PORT
    0x3086, 0x0617,     // SEQ_DATA_PORT
    0x3086, 0x3626,     // SEQ_DATA_PORT
    0x3086, 0xA617,     // SEQ_DATA_PORT
    0x3086, 0x0326,     // SEQ_DATA_PORT
    0x3086, 0xA417,     // SEQ_DATA_PORT
    0x3086, 0x1F28,     // SEQ_DATA_PORT
    0x3086, 0x0526,     // SEQ_DATA_PORT
    0x3086, 0x2028,     // SEQ_DATA_PORT
    0x3086, 0x0425,     // SEQ_DATA_PORT
    0x3086, 0x2020,     // SEQ_DATA_PORT
    0x3086, 0x2700,     // SEQ_DATA_PORT
    0x3086, 0x171D,     // SEQ_DATA_PORT
    0x3086, 0x2500,     // SEQ_DATA_PORT
    0x3086, 0x2021,     // SEQ_DATA_PORT
    0x3086, 0x1712,     // SEQ_DATA_PORT
    0x3086, 0x1B17,     // SEQ_DATA_PORT
    0x3086, 0x0327,     // SEQ_DATA_PORT
    0x3086, 0x0617,     // SEQ_DATA_PORT
    0x3086, 0x2828,     // SEQ_DATA_PORT
    0x3086, 0x0517,     // SEQ_DATA_PORT
    0x3086, 0x1A26,     // SEQ_DATA_PORT
    0x3086, 0x6017,     // SEQ_DATA_PORT
    0x3086, 0xAE25,     // SEQ_DATA_PORT
    0x3086, 0x0090,     // SEQ_DATA_PORT
    0x3086, 0x2700,     // SEQ_DATA_PORT
    0x3086, 0x2618,     // SEQ_DATA_PORT
    0x3086, 0x2800,     // SEQ_DATA_PORT
    0x3086, 0x2E2A,     // SEQ_DATA_PORT
    0x3086, 0x2808,     // SEQ_DATA_PORT
    0x3086, 0x1E17,     // SEQ_DATA_PORT
    0x3086, 0x0A05,     // SEQ_DATA_PORT
    0x3086, 0x1470,     // SEQ_DATA_PORT
    0x3086, 0x7009,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x1614,     // SEQ_DATA_PORT
    0x3086, 0x0020,     // SEQ_DATA_PORT
    0x3086, 0x2414,     // SEQ_DATA_PORT
    0x3086, 0x0050,     // SEQ_DATA_PORT
    0x3086, 0x2B2B,     // SEQ_DATA_PORT
    0x3086, 0x2C2C,     // SEQ_DATA_PORT
    0x3086, 0x2C2C,     // SEQ_DATA_PORT
    0x3086, 0x2C00,     // SEQ_DATA_PORT
    0x3086, 0x0225,     // SEQ_DATA_PORT
    0x3086, 0x5050,     // SEQ_DATA_PORT
    0x3086, 0x2D26,     // SEQ_DATA_PORT
    0x3086, 0x0828,     // SEQ_DATA_PORT
    0x3086, 0x0D17,     // SEQ_DATA_PORT
    0x3086, 0x0926,     // SEQ_DATA_PORT
    0x3086, 0x0028,     // SEQ_DATA_PORT
    0x3086, 0x0526,     // SEQ_DATA_PORT
    0x3086, 0xA728,     // SEQ_DATA_PORT
    0x3086, 0x0725,     // SEQ_DATA_PORT
    0x3086, 0x8080,     // SEQ_DATA_PORT
    0x3086, 0x2917,     // SEQ_DATA_PORT
    0x3086, 0x0525,     // SEQ_DATA_PORT
    0x3086, 0x0040,     // SEQ_DATA_PORT
    0x3086, 0x2702,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x2706,     // SEQ_DATA_PORT
    0x3086, 0x1736,     // SEQ_DATA_PORT
    0x3086, 0x26A6,     // SEQ_DATA_PORT
    0x3086, 0x1703,     // SEQ_DATA_PORT
    0x3086, 0x26A4,     // SEQ_DATA_PORT
    0x3086, 0x171F,     // SEQ_DATA_PORT
    0x3086, 0x2805,     // SEQ_DATA_PORT
    0x3086, 0x2620,     // SEQ_DATA_PORT
    0x3086, 0x2804,     // SEQ_DATA_PORT
    0x3086, 0x2520,     // SEQ_DATA_PORT
    0x3086, 0x2027,     // SEQ_DATA_PORT
    0x3086, 0x0017,     // SEQ_DATA_PORT
    0x3086, 0x1E25,     // SEQ_DATA_PORT
    0x3086, 0x0020,     // SEQ_DATA_PORT
    0x3086, 0x2117,     // SEQ_DATA_PORT
    0x3086, 0x1028,     // SEQ_DATA_PORT
    0x3086, 0x051B,     // SEQ_DATA_PORT
    0x3086, 0x1703,     // SEQ_DATA_PORT
    0x3086, 0x2706,     // SEQ_DATA_PORT
    0x3086, 0x1703,     // SEQ_DATA_PORT
    0x3086, 0x1747,     // SEQ_DATA_PORT
    0x3086, 0x2660,     // SEQ_DATA_PORT
    0x3086, 0x17AE,     // SEQ_DATA_PORT
    0x3086, 0x2500,     // SEQ_DATA_PORT
    0x3086, 0x9027,     // SEQ_DATA_PORT
    0x3086, 0x0026,     // SEQ_DATA_PORT
    0x3086, 0x1828,     // SEQ_DATA_PORT
    0x3086, 0x002E,     // SEQ_DATA_PORT
    0x3086, 0x2A28,     // SEQ_DATA_PORT
    0x3086, 0x081E,     // SEQ_DATA_PORT
    0x3086, 0x0831,     // SEQ_DATA_PORT
    0x3086, 0x1440,     // SEQ_DATA_PORT
    0x3086, 0x4014,     // SEQ_DATA_PORT
    0x3086, 0x2020,     // SEQ_DATA_PORT
    0x3086, 0x1410,     // SEQ_DATA_PORT
    0x3086, 0x1034,     // SEQ_DATA_PORT
    0x3086, 0x1400,     // SEQ_DATA_PORT
    0x3086, 0x1014,     // SEQ_DATA_PORT
    0x3086, 0x0020,     // SEQ_DATA_PORT
    0x3086, 0x1400,     // SEQ_DATA_PORT
    0x3086, 0x4013,     // SEQ_DATA_PORT
    0x3086, 0x1802,     // SEQ_DATA_PORT
    0x3086, 0x1470,     // SEQ_DATA_PORT
    0x3086, 0x7004,     // SEQ_DATA_PORT
    0x3086, 0x1470,     // SEQ_DATA_PORT
    0x3086, 0x7003,     // SEQ_DATA_PORT
    0x3086, 0x1470,     // SEQ_DATA_PORT
    0x3086, 0x7017,     // SEQ_DATA_PORT
    0x3086, 0x2002,     // SEQ_DATA_PORT
    0x3086, 0x1400,     // SEQ_DATA_PORT
    0x3086, 0x2002,     // SEQ_DATA_PORT
    0x3086, 0x1400,     // SEQ_DATA_PORT
    0x3086, 0x5004,     // SEQ_DATA_PORT
    0x3086, 0x1400,     // SEQ_DATA_PORT
    0x3086, 0x2004,     // SEQ_DATA_PORT
    0x3086, 0x1400,     // SEQ_DATA_PORT
    0x3086, 0x5022,     // SEQ_DATA_PORT
    0x3086, 0x0314,     // SEQ_DATA_PORT
    0x3086, 0x0020,     // SEQ_DATA_PORT
    0x3086, 0x0314,     // SEQ_DATA_PORT
    0x3086, 0x0050,     // SEQ_DATA_PORT
    0x3086, 0x2C2C,     // SEQ_DATA_PORT
    0x3086, 0x2C2C,     // SEQ_DATA_PORT
    0x309E, 0x0186,     // ERS_PROG_START_ADDR

    //DELAY = 200
    0xFEF0, 0x1000,

    //[HDR Mode Setup]
    0x301A, 0x10D8,     // RESET_REGISTER
    //0x3082, 0x0028,   // OPERATION_MODE_CTRL
    0x3082, 0x0008,     // OPERATION_MODE_CTRL

    //A-1000ERS Optimized settings August 2 2011
    //improves anti eclipse performance
    0x301E, 0x0000,     // DATA_PEDESTAL
    0x3EDA, 0x0F03,     // DAC_LD_14_15
    0x3EDE, 0xC005,     // DAC_LD_18_19
    0x3ED8, 0x09EF,     // DAC_LD_12_13
    0x3EE2, 0xA46B,     // DAC_LD_22_23
    0x3EE0, 0x067D,     // DAC_LD_20_21
    0x3EDC, 0x0070,     // DAC_LD_16_17
    0x3044, 0x0404,     // DARK_CONTROL
    0x3EE6, 0x8303,     // DAC_LD_26_27
    0x3EE4, 0xD208,     // DAC_LD_24_25
    0x3ED6, 0x00BD,     // DAC_LD_10_11

    //ADC settings to improve noise performance
    0x30E4, 0x6372,     // ADC_BITS_6_7
    0x30E2, 0x7253,     // ADC_BITS_4_5
    0x30E0, 0x5470,     // ADC_BITS_2_3
    0x30E6, 0xC4CC,     // ADC_CONFIG1
    0x30E8, 0x8050,     // ADC_CONFIG2

    //Column Retriggering at start up
    0x30B0, 0x1300,     // DIGITAL_TEST
    0x30D4, 0xE007,     // COLUMN_CORRECTION
    0x30BA, 0x0008,     // DIGITAL_CTRL
    0x301A, 0x10DC,     // RESET_REGISTER

    //DELAY = 200
    0xFEF0, 0x1000,
    0x301A, 0x10D8,     // RESET_REGISTER

    //DELAY = 200
    0xFEF0, 0x1000,
    0x3012, 0x02A0,     // COARSE_INTEGRATION_TIME

#if 1   // jerome_20141202: for test
#if (AR0132AT_RESOLUTION == RESOLUTION_720)
    0x3032, 0x0000,     // DIGITAL_BINNING
    0x3002, 0x0002,     // Y_ADDR_START
    0x3004, 0x0000,     // X_ADDR_START
    0x3006, 0x02D1,     // Y_ADDR_END
    0x3008, 0x04FF,     // X_ADDR_END
#if (AR0132AT_FRAME_LENGTH == FRAME_30)
    0x300A, 0x02EE,     // FRAME_LENGTH_LINES
    0x300C, 0x0CE4,     // LINE_LENGTH_PCK
#elif (AR0132AT_FRAME_LENGTH == FRAME_45)
    0x300A, 0x03DE,     // FRAME_LENGTH_LINES
    0x300C, 0x09C4,     // LINE_LENGTH_PCK
#elif (AR0132AT_FRAME_LENGTH == FRAME_60)
    0x300A, 0x02EF,     // FRAME_LENGTH_LINES
    0x300C, 0x0672,     // LINE_LENGTH_PCK
#endif

#elif (AR0132AT_RESOLUTION == RESOLUTION_960)
    0x3032, 0x0000,     // DIGITAL_BINNING
    0x3002, 0x0002,     // Y_ADDR_START
    0x3004, 0x0000,     // X_ADDR_START
    0x3006, 0x03C1,     // Y_ADDR_END
    0x3008, 0x04FF,     // X_ADDR_END

#if (AR0132AT_FRAME_LENGTH == FRAME_30)
    0x300A, 0x03DE,     // FRAME_LENGTH_LINES
    0x300C, 0x09C4,     // LINE_LENGTH_PCK
#elif (AR0132AT_FRAME_LENGTH == FRAME_60)
    0x300A, 0x02EF,     // FRAME_LENGTH_LINES
    0x300C, 0x0672,     // LINE_LENGTH_PCK
#endif
#endif

#else
    //[Full Resolution Setup]
    0x3032, 0x0000,     // DIGITAL_BINNING
    0x3002, 0x0002,     // Y_ADDR_START
    0x3004, 0x0000,     // X_ADDR_START
    0x3006, 0x03C1,     // Y_ADDR_END
    0x3008, 0x04FF,     // X_ADDR_END
    0x300A, 0x03DE,     // FRAME_LENGTH_LINES
    0x300C, 0x09C4,     // LINE_LENGTH_PCK
#endif

    //[Enable Parallel Mode]
    0x301A, 0x10D8,     // RESET_REGISTER
    0x31D0, 0x0001,     // HDR_COMP

    //PLL Enabled 27Mhz to 74.25Mhz
    0x302C, 0x0002,     // VT_SYS_CLK_DIV
    0x302A, 0x0004,     // VT_PIX_CLK_DIV
    0x302E, 0x0002,     // PRE_PLL_CLK_DIV
    0x3030, 0x002C,     // PLL_MULTIPLIER
    0x30B0, 0x1300,     // DIGITAL_TEST

    0x3040, 0x8000,       // READ_MODE

    //[Enable AE and Load Optimized Settings For HDR 16x Mode]
    //Enable Embedded Data and Stats
    0x3064, 0x1982,     // EMBEDDED_DATA_CTRL
    0x3064, 0x1982,     // EMBEDDED_DATA_CTRL
    0x3100, 0x0000,     // AE_CTRL_REG
    0x3112, 0x029F,     // AE_DCG_EXPOSURE_HIGH_REG
    0x3114, 0x008C,     // AE_DCG_EXPOSURE_LOW_REG
    0x3116, 0x02C0,     // AE_DCG_GAIN_FACTOR_REG
    0x3118, 0x005B,     // AE_DCG_GAIN_FACTOR_INV_REG
    0x3102, 0x0708,     // AE_LUMA_TARGET_REG
    0x3104, 0x1000,     // AE_HIST_TARGET_REG
    0x3126, 0x0064,     // AE_ALPHA_V1_REG
    0x311C, 0x02A0,     // AE_MAX_EXPOSURE_REG
    0x311E, 0x0080,     // AE_MIN_EXPOSURE_REG

    // Smoothing Function
    0x318A, 0x0FA0,     //
    0x318E, 0x0320,     //
    0x3192, 0x0800,     //

    // 2-dimensional motion compensation (2D-MC)
    0x318C, 0xC300,     //
    //0x318E, 0x0320,   //

    // Digital Lateral Overflow(DLO)
    //0x3190, 0x0BA0,   //

    0x3190, 0x6BA0,     // ////// by hclee enable DLO noise filtering in DLO
    0x3194, 0x0BB8,     //
    0x3196, 0x0DAC,     //
    0x3198, 0x0FA0,     //
    0x319E, 0x5040,     //
    0x31A2, 0x0BB8,     //

    0x301A, 0x10DC,     // RESET_REGISTER
};

#endif


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

UINT32 APACHE_CMOS_AR0132AT_Init(void)
{
    UINT32 Size, i, rdData;
    INT32 ret = NC_SUCCESS;

    Size = sizeof(gAR0132AT_Table)/sizeof(AR0132AT_DATA);

    for(i = 0; i < Size; i++)
    {
        DEBUGMSG(MSGINFO, ".");
        //DEBUGMSG(MSGINFO, "@0x%04X 0x%04X\n", gAR0132AT_Table[i].Addr, gAR0132AT_Table[i].Data);

        if(gAR0132AT_Table[i].Addr == 0xFEF0)
        {
            APACHE_SYS_mDelay(100);
            //APACHE_SYS_mDelay(gAR0132AT_Table[i].Data);
        }
        else
        {
            //DEBUGMSG(MSGINFO, "[W]0x%04x, 0x%04x, 0x%04x\n", AR0132AT_DEVICEID, gAR0132AT_Table[i].Addr, gAR0132AT_Table[i].Data);
            ret |= ncLib_I2C_Write(I2C_CH0, AR0132AT_DEVICEID, gAR0132AT_Table[i].Addr, gAR0132AT_Table[i].Data, 1, I2C_ADDR_16_DATA_16);

#if 1
            if(i)
            {
                APACHE_SYS_mDelay(2);

                ret |= ncLib_I2C_Read(I2C_CH0, AR0132AT_DEVICEID, gAR0132AT_Table[i].Addr, (UINT8 *)&rdData, 1, I2C_ADDR_16_DATA_16);
                //DEBUGMSG(MSGINFO, "[R]0x%04x, 0x%04x, 0x%04x\n", AR0132AT_DEVICEID, gAR0132AT_Table[i].Addr, rdData);

                if(gAR0132AT_Table[i].Data != rdData)
                {
                    if(gAR0132AT_Table[i].Addr != 0x3086)
                    {
                        ret = NC_FAILURE;
                        DEBUGMSG(MSGINFO, "\n");
                        DEBUGMSG(MSGWARN, "Warning, %d [W]0x%04x, 0x%04x, 0x%04x\n", i, AR0132AT_DEVICEID, gAR0132AT_Table[i].Addr, gAR0132AT_Table[i].Data);
                        DEBUGMSG(MSGWARN, "Warning, %d [R]0x%04x, 0x%04x, 0x%04x\n", i, AR0132AT_DEVICEID, gAR0132AT_Table[i].Addr, rdData);
                    }
                }
            }
#endif
        }
    }

    DEBUGMSG(MSGINFO, "\n");

    return ret;
}


INT32 APACHE_SYS_InitAR0132AT(void)
{
    INT32 ret = NC_SUCCESS;

    APACHE_SYS_mDelay(100);

    ret = APACHE_CMOS_AR0132AT_Init();

    APACHE_SYS_mDelay(100);

    return ret;
}


/* End Of File */
