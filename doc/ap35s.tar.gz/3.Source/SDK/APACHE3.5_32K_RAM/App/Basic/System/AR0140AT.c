/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : AR0140AT.c
*
*  @brief   : CMOS camera sensor controller test application source file
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.20
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"

#include "AR0140AT.h"
#include "sFlash_Lib.h"
//#include "IspFlash_Drv.h"

/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define RESOLUTION_720                      720
#define RESOLUTION_960                      960

#define FRAME_30                            30
#define FRAME_45                            45
#define FRAME_60                            60

#define AR0140AT_RESOLUTION                 RESOLUTION_720
#define AR0140AT_FRAME_LENGTH               FRAME_30


#define CMOS_MODE                           CMOS_MODE_LINEAR //CMOS_MODE_WDR


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

#ifndef tAR0140AT_DATA
#define tAR0140AT_DATA
typedef struct
{
    UINT16 Addr;
    UINT16 Data;
} AR0140AT_DATA;
#endif



#if (SENSOR_SELECT == SENSOR_COMMON)
#else

#if (CMOS_MODE == CMOS_MODE_LINEAR)

AR0140AT_DATA gAR0140AT_Table[] =
{
    //[Nextchip Linear (Parallel) 720p30 - Pclk:37Mhz]

    //0x2700, 0x0000,   // NVP2620
    //0x0001, 0x0000,  // AR0140  Normal Mode
    //0x0020, 0x0003,  // I2C SlaveAddr = 0x02  2Byte Address  1byte Data
    //0x1000, 0x1000,  // Low Delay = 0x80  High Delay = 0x100 ( for reset time)

    //[Reset]
    0x301A, 0x0001,     // RESET_REGISTER
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
    0x301A, 0x10D8,     // RESET_REGISTER
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2


    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
    //[sequencer_ers_0828_AR0140.i]
    0x3088, 0x8000,     // SEQ_CTRL_PORT
    0x3086, 0x4558,     // SEQ_DATA_PORT
    0x3086, 0x6E9B,     // SEQ_DATA_PORT
    0x3086, 0x4A31,     // SEQ_DATA_PORT
    0x3086, 0x4342,     // SEQ_DATA_PORT
    0x3086, 0x8E03,     // SEQ_DATA_PORT
    0x3086, 0x2714,     // SEQ_DATA_PORT
    0x3086, 0x4578,     // SEQ_DATA_PORT
    0x3086, 0x7B3D,     // SEQ_DATA_PORT
    0x3086, 0xFF3D,     // SEQ_DATA_PORT
    0x3086, 0xFF3D,     // SEQ_DATA_PORT
    0x3086, 0xEA27,     // SEQ_DATA_PORT
    0x3086, 0x043D,     // SEQ_DATA_PORT
    0x3086, 0x1027,     // SEQ_DATA_PORT
    0x3086, 0x0527,     // SEQ_DATA_PORT
    0x3086, 0x1535,     // SEQ_DATA_PORT
    0x3086, 0x2705,     // SEQ_DATA_PORT
    0x3086, 0x3D10,     // SEQ_DATA_PORT
    0x3086, 0x4558,     // SEQ_DATA_PORT
    0x3086, 0x2704,     // SEQ_DATA_PORT
    0x3086, 0x2714,     // SEQ_DATA_PORT
    0x3086, 0x3DFF,     // SEQ_DATA_PORT
    0x3086, 0x3DFF,     // SEQ_DATA_PORT
    0x3086, 0x3DEA,     // SEQ_DATA_PORT
    0x3086, 0x2704,     // SEQ_DATA_PORT
    0x3086, 0x6227,     // SEQ_DATA_PORT
    0x3086, 0x288E,     // SEQ_DATA_PORT
    0x3086, 0x0036,     // SEQ_DATA_PORT
    0x3086, 0x2708,     // SEQ_DATA_PORT
    0x3086, 0x3D64,     // SEQ_DATA_PORT
    0x3086, 0x7A3D,     // SEQ_DATA_PORT
    0x3086, 0x0444,     // SEQ_DATA_PORT
    0x3086, 0x2C4B,     // SEQ_DATA_PORT
    0x3086, 0x8F01,     // SEQ_DATA_PORT
    0x3086, 0x4372,     // SEQ_DATA_PORT
    0x3086, 0x719F,     // SEQ_DATA_PORT
    0x3086, 0x4643,     // SEQ_DATA_PORT
    0x3086, 0x166F,     // SEQ_DATA_PORT
    0x3086, 0x9F92,     // SEQ_DATA_PORT
    0x3086, 0x1244,     // SEQ_DATA_PORT
    0x3086, 0x1646,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x9326,     // SEQ_DATA_PORT
    0x3086, 0x0426,     // SEQ_DATA_PORT
    0x3086, 0x848E,     // SEQ_DATA_PORT
    0x3086, 0x0327,     // SEQ_DATA_PORT
    0x3086, 0xFC5C,     // SEQ_DATA_PORT
    0x3086, 0x0D57,     // SEQ_DATA_PORT
    0x3086, 0x5417,     // SEQ_DATA_PORT
    0x3086, 0x0955,     // SEQ_DATA_PORT
    0x3086, 0x5649,     // SEQ_DATA_PORT
    0x3086, 0x5F53,     // SEQ_DATA_PORT
    0x3086, 0x0553,     // SEQ_DATA_PORT
    0x3086, 0x0728,     // SEQ_DATA_PORT
    0x3086, 0x6C4C,     // SEQ_DATA_PORT
    0x3086, 0x0928,     // SEQ_DATA_PORT
    0x3086, 0x2C72,     // SEQ_DATA_PORT
    0x3086, 0xA37C,     // SEQ_DATA_PORT
    0x3086, 0x9728,     // SEQ_DATA_PORT
    0x3086, 0xA879,     // SEQ_DATA_PORT
    0x3086, 0x6026,     // SEQ_DATA_PORT
    0x3086, 0x9C5C,     // SEQ_DATA_PORT
    0x3086, 0x1B45,     // SEQ_DATA_PORT
    0x3086, 0x4845,     // SEQ_DATA_PORT
    0x3086, 0x0845,     // SEQ_DATA_PORT
    0x3086, 0x8826,     // SEQ_DATA_PORT
    0x3086, 0xBE8E,     // SEQ_DATA_PORT
    0x3086, 0x0127,     // SEQ_DATA_PORT
    0x3086, 0xF817,     // SEQ_DATA_PORT
    0x3086, 0x0227,     // SEQ_DATA_PORT
    0x3086, 0xFA17,     // SEQ_DATA_PORT
    0x3086, 0x095C,     // SEQ_DATA_PORT
    0x3086, 0x0B17,     // SEQ_DATA_PORT
    0x3086, 0x1026,     // SEQ_DATA_PORT
    0x3086, 0xBA5C,     // SEQ_DATA_PORT
    0x3086, 0x0317,     // SEQ_DATA_PORT
    0x3086, 0x1026,     // SEQ_DATA_PORT
    0x3086, 0xB217,     // SEQ_DATA_PORT
    0x3086, 0x065F,     // SEQ_DATA_PORT
    0x3086, 0x2888,     // SEQ_DATA_PORT
    0x3086, 0x9060,     // SEQ_DATA_PORT
    0x3086, 0x27F2,     // SEQ_DATA_PORT
    0x3086, 0x1710,     // SEQ_DATA_PORT
    0x3086, 0x26A2,     // SEQ_DATA_PORT
    0x3086, 0x26A3,     // SEQ_DATA_PORT
    0x3086, 0x5F4D,     // SEQ_DATA_PORT
    0x3086, 0x2808,     // SEQ_DATA_PORT
    0x3086, 0x1A27,     // SEQ_DATA_PORT
    0x3086, 0xFA84,     // SEQ_DATA_PORT
    0x3086, 0x69A0,     // SEQ_DATA_PORT
    0x3086, 0x785D,     // SEQ_DATA_PORT
    0x3086, 0x2888,     // SEQ_DATA_PORT
    0x3086, 0x8710,     // SEQ_DATA_PORT
    0x3086, 0x8C82,     // SEQ_DATA_PORT
    0x3086, 0x8926,     // SEQ_DATA_PORT
    0x3086, 0xB217,     // SEQ_DATA_PORT
    0x3086, 0x036B,     // SEQ_DATA_PORT
    0x3086, 0x9C60,     // SEQ_DATA_PORT
    0x3086, 0x9417,     // SEQ_DATA_PORT
    0x3086, 0x2926,     // SEQ_DATA_PORT
    0x3086, 0x8345,     // SEQ_DATA_PORT
    0x3086, 0xA817,     // SEQ_DATA_PORT
    0x3086, 0x0727,     // SEQ_DATA_PORT
    0x3086, 0xFB17,     // SEQ_DATA_PORT
    0x3086, 0x2945,     // SEQ_DATA_PORT
    0x3086, 0x8820,     // SEQ_DATA_PORT
    0x3086, 0x1708,     // SEQ_DATA_PORT
    0x3086, 0x27FA,     // SEQ_DATA_PORT
    0x3086, 0x5D87,     // SEQ_DATA_PORT
    0x3086, 0x108C,     // SEQ_DATA_PORT
    0x3086, 0x8289,     // SEQ_DATA_PORT
    0x3086, 0x170E,     // SEQ_DATA_PORT
    0x3086, 0x4826,     // SEQ_DATA_PORT
    0x3086, 0x9A28,     // SEQ_DATA_PORT
    0x3086, 0x884C,     // SEQ_DATA_PORT
    0x3086, 0x0B79,     // SEQ_DATA_PORT
    0x3086, 0x1730,     // SEQ_DATA_PORT
    0x3086, 0x2692,     // SEQ_DATA_PORT
    0x3086, 0x1709,     // SEQ_DATA_PORT
    0x3086, 0x9160,     // SEQ_DATA_PORT
    0x3086, 0x27F2,     // SEQ_DATA_PORT
    0x3086, 0x1710,     // SEQ_DATA_PORT
    0x3086, 0x2682,     // SEQ_DATA_PORT
    0x3086, 0x2683,     // SEQ_DATA_PORT
    0x3086, 0x5F4D,     // SEQ_DATA_PORT
    0x3086, 0x2808,     // SEQ_DATA_PORT
    0x3086, 0x1A27,     // SEQ_DATA_PORT
    0x3086, 0xFA84,     // SEQ_DATA_PORT
    0x3086, 0x69A1,     // SEQ_DATA_PORT
    0x3086, 0x785D,     // SEQ_DATA_PORT
    0x3086, 0x2888,     // SEQ_DATA_PORT
    0x3086, 0x8710,     // SEQ_DATA_PORT
    0x3086, 0x8C80,     // SEQ_DATA_PORT
    0x3086, 0x8A26,     // SEQ_DATA_PORT
    0x3086, 0x9217,     // SEQ_DATA_PORT
    0x3086, 0x036B,     // SEQ_DATA_PORT
    0x3086, 0x9D95,     // SEQ_DATA_PORT
    0x3086, 0x2603,     // SEQ_DATA_PORT
    0x3086, 0x5C01,     // SEQ_DATA_PORT
    0x3086, 0x4558,     // SEQ_DATA_PORT
    0x3086, 0x8E00,     // SEQ_DATA_PORT
    0x3086, 0x2798,     // SEQ_DATA_PORT
    0x3086, 0x170A,     // SEQ_DATA_PORT
    0x3086, 0x4A0A,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x0B43,     // SEQ_DATA_PORT
    0x3086, 0x5B43,     // SEQ_DATA_PORT
    0x3086, 0x1659,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x8E03,     // SEQ_DATA_PORT
    0x3086, 0x279C,     // SEQ_DATA_PORT
    0x3086, 0x4578,     // SEQ_DATA_PORT
    0x3086, 0x1707,     // SEQ_DATA_PORT
    0x3086, 0x279D,     // SEQ_DATA_PORT
    0x3086, 0x1722,     // SEQ_DATA_PORT
    0x3086, 0x5D87,     // SEQ_DATA_PORT
    0x3086, 0x1028,     // SEQ_DATA_PORT
    0x3086, 0x0853,     // SEQ_DATA_PORT
    0x3086, 0x0D8C,     // SEQ_DATA_PORT
    0x3086, 0x808A,     // SEQ_DATA_PORT
    0x3086, 0x4558,     // SEQ_DATA_PORT
    0x3086, 0x1708,     // SEQ_DATA_PORT
    0x3086, 0x8E01,     // SEQ_DATA_PORT
    0x3086, 0x2798,     // SEQ_DATA_PORT
    0x3086, 0x8E00,     // SEQ_DATA_PORT
    0x3086, 0x76A2,     // SEQ_DATA_PORT
    0x3086, 0x77A2,     // SEQ_DATA_PORT
    0x3086, 0x4644,     // SEQ_DATA_PORT
    0x3086, 0x1616,     // SEQ_DATA_PORT
    0x3086, 0x967A,     // SEQ_DATA_PORT
    0x3086, 0x2644,     // SEQ_DATA_PORT
    0x3086, 0x5C05,     // SEQ_DATA_PORT
    0x3086, 0x1244,     // SEQ_DATA_PORT
    0x3086, 0x4B71,     // SEQ_DATA_PORT
    0x3086, 0x759E,     // SEQ_DATA_PORT
    0x3086, 0x8B86,     // SEQ_DATA_PORT
    0x3086, 0x184A,     // SEQ_DATA_PORT
    0x3086, 0x0343,     // SEQ_DATA_PORT
    0x3086, 0x1606,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x0743,     // SEQ_DATA_PORT
    0x3086, 0x1604,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x5843,     // SEQ_DATA_PORT
    0x3086, 0x165A,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x4558,     // SEQ_DATA_PORT
    0x3086, 0x8E03,     // SEQ_DATA_PORT
    0x3086, 0x279C,     // SEQ_DATA_PORT
    0x3086, 0x4578,     // SEQ_DATA_PORT
    0x3086, 0x7B17,     // SEQ_DATA_PORT
    0x3086, 0x0727,     // SEQ_DATA_PORT
    0x3086, 0x9D17,     // SEQ_DATA_PORT
    0x3086, 0x2245,     // SEQ_DATA_PORT
    0x3086, 0x5822,     // SEQ_DATA_PORT
    0x3086, 0x1710,     // SEQ_DATA_PORT
    0x3086, 0x8E01,     // SEQ_DATA_PORT
    0x3086, 0x2798,     // SEQ_DATA_PORT
    0x3086, 0x8E00,     // SEQ_DATA_PORT
    0x3086, 0x1710,     // SEQ_DATA_PORT
    0x3086, 0x1244,     // SEQ_DATA_PORT
    0x3086, 0x4B8D,     // SEQ_DATA_PORT
    0x3086, 0x602C,     // SEQ_DATA_PORT
    0x3086, 0x2C2C,     // SEQ_DATA_PORT
    0x3086, 0x2C00,     // SEQ_DATA_PORT

    //[PLL_configuration_Parallel]
    //Mclk:27Mhz Pclk:37Mhz
    //0x302A 0x0006     // VT_PIX_CLK_DIV
    //0x302C 0x0002     // VT_SYS_CLK_DIV
    //0x302E 0x0009     // PRE_PLL_CLK_DIV
    //0x3030 0x0094     // PLL_MULTIPLIER
    //0x3036 0x000C     // OP_PIX_CLK_DIV
    //0x3038 0x0004     // OP_SYS_CLK_DIV

    //Mclk:27Mhz Pclk:74.25Mhz
    0x302A, 0x0006,     // VT_PIX_CLK_DIV
    0x302C, 0x0001,     // VT_SYS_CLK_DIV
    0x302E, 0x0004,     // PRE_PLL_CLK_DIV
    0x3030, 0x0042,     // PLL_MULTIPLIER
    0x3036, 0x000C,     // OP_PIX_CLK_DIV
    0x3038, 0x0002,     // OP_SYS_CLK_DIV

    //[720P30fps_configuration]
    //0x3004 0x001C     // X_ADDR_START
    //0x3002 0x003C     // Y_ADDR_START
    //0x3008 0x0523     // X_ADDR_END
    //0x3006 0x0313     // Y_ADDR_END
    //0x300A 0x02E5     // FRAME_LENGTH_LINES
    //0x300C 0x0680     // LINE_LENGTH_PCK
    //0x3012 0x02E4     // COARSE_INTEGRATION_TIME
    //0x30A2 0x0001     // X_ODD_INC
    //0x30A6 0x0001     // Y_ODD_INC
    //0x3040 0x0000     // READ_MODE
    
#if 1
	//[720P60fps_configuration]
	0x3004, 0x001C,	// X_ADDR_START
	0x3002, 0x003C,	// Y_ADDR_START
	0x3008, 0x0523,	// X_ADDR_END
	0x3006, 0x0313,	// Y_ADDR_END
	0x300A, 0x02EE,	// FRAME_LENGTH_LINES  //VTOTAL
	0x300C, 0x0672,	// LINE_LENGTH_PCK     //HTOTAL
	0x3012, 0x02ED, // COARSE_INTEGRATION_TIME  VTOTAL-1 // SHUTTER MAX
#else
	//[720P60fps_configuration]
	0x3004, 0x001C,	// X_ADDR_START
	0x3002, 0x003C,	// Y_ADDR_START
	0x3008, 0x0523,	// X_ADDR_END
	0x3006, 0x0313,	// Y_ADDR_END
	0x300A, 0x02E5,	// FRAME_LENGTH_LINES
	0x300C, 0x0680,	// LINE_LENGTH_PCK
	0x3012, 0x02E4,// COARSE_INTEGRATION_TIME
#endif

    0x30A2, 0x0001,     // X_ODD_INC
    0x30A6, 0x0001,     // Y_ODD_INC
    0x3040, 0x0000,     // READ_MODE

    //[AR0140 Rev2 Optimized Settings]
    0x3044, 0x0400,     // DARK_CONTROL
    0x3052, 0xA134,     // OTPM_CFG
    0x3054, 0x0400,     // OTPM_EXPR
    0x3092, 0x010F,     // ROW_NOISE_CONTROL
    0x30FE, 0x0080,     // NOISE_PEDESTAL
    0x3ECE, 0x40FF,     // DAC_LD_2_3
    0x3ED0, 0xFF40,     // DAC_LD_4_5
    0x3ED2, 0xA906,     // DAC_LD_6_7
    0x3ED4, 0x001F,     // DAC_LD_8_9
    0x3ED6, 0x637F,     // DAC_LD_10_11
    0x3ED8, 0xAA99,     // DAC_LD_12_13
    0x3EDA, 0x0C88,     // DAC_LD_14_15
    0x3EDE, 0x8878,     // DAC_LD_18_19
    0x3EE0, 0x7755,     // DAC_LD_20_21
    0x3EE2, 0x5563,     // DAC_LD_22_23
    0x3EE4, 0xAAF0,     // DAC_LD_24_25
    0x3EE6, 0x1400,     // DAC_LD_26_27
    0x3EEA, 0xA4FF,     // DAC_LD_30_31
    0x3EEC, 0x80F0,     // DAC_LD_32_33
    0x3EEE, 0x0000,     // DAC_LD_34_35
    0x3EF0, 0x721F,     // DAC_LD_36_37
    0x3EF2, 0x000F,     // DAC_LD_38_39
    0x3EF4, 0x000C,     // DAC_LD_40_41
    0x3F30, 0x0060,     // ROW_NOISE_CONTROL2
    0x31E0, 0x1701,     // PIX_DEF_ID
    0x301E, 0x0000,     // PEDESTAL

    //[Linear Mode Setup]
    0x3082, 0x0009,     // OPERATION_MODE_CTRL
    0x305E, 0x00B0,     // GLOBAL_GAIN

    //Motion Compensation Off
    0x318C, 0x0000,     // HDR_MC_CTRL2

    //ADACD Disabled
    0x3200, 0x0000,     // ADACD_CONTROL

    //Companding_disabled
    0x31D0, 0x0000,     // COMPANDING

    //Disable Embedded Data and Stats
    0x3064, 0x1902,     // SMIA_TEST
    0x3064, 0x1802,     // SMIA_TEST

    //Linear Mode Devware Color Setup
    //Enable DevWare Colorpipe CCM and AWB settings

#if 1 // test
    0x3040, 0xC000,     // READ_MODE
    0x3060, 0x0016,
    0x30B6, 0x0B40,     // spare register for tempsens calibration value...
    0x30B8, 0x3386,     // spare register for tempsens calibration value...
#endif

    0x30B0, 0x0000,     // DIGITAL_TEST
    0x30BA, 0x012C,     // DIGITAL_CTRL
    0x31AC, 0x0C0C,     // DATA_FORMAT_BITS
    0x31AE, 0x0301,     // SERIAL_FORMAT
    0x301A, 0x10DC,     // RESET_REGISTER

    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
};


#elif (CMOS_MODE == CMOS_MODE_WDR)

AR0140AT_DATA gAR0140AT_Table[] =
{

    //[Nextchip HDR (Parallel) 720p30 ] 37.125 MHz
    //0x2620, 0x0000,   // NVP2620
    //0x0001, 0x0001,  // AR0140  WDR Mode
    //0x0020, 0x0003,  // I2C SlaveAddr = 0x02  2Byte Address  1byte Data
    //0x1000, 0x1000,  // Low Delay = 0x80  High Delay = 0x100 ( for reset time)

    //[Reset]
    0x301A, 0x0001,     // RESET_REGISTER
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
    0x301A, 0x10D8,     // RESET_REGISTER
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2

    //[sequencer_hidy_0828_AR0140.i]
    0x3088, 0x8000,     // SEQ_CTRL_PORT
    0x3086, 0x4558,     // SEQ_DATA_PORT
    0x3086, 0x6E9B,     // SEQ_DATA_PORT
    0x3086, 0x4A31,     // SEQ_DATA_PORT
    0x3086, 0x4342,     // SEQ_DATA_PORT
    0x3086, 0x8E03,     // SEQ_DATA_PORT
    0x3086, 0x2714,     // SEQ_DATA_PORT
    0x3086, 0x4578,     // SEQ_DATA_PORT
    0x3086, 0x7B3D,     // SEQ_DATA_PORT
    0x3086, 0xFF3D,     // SEQ_DATA_PORT
    0x3086, 0xFF3D,     // SEQ_DATA_PORT
    0x3086, 0xEA27,     // SEQ_DATA_PORT
    0x3086, 0x043D,     // SEQ_DATA_PORT
    0x3086, 0x1027,     // SEQ_DATA_PORT
    0x3086, 0x0527,     // SEQ_DATA_PORT
    0x3086, 0x1535,     // SEQ_DATA_PORT
    0x3086, 0x2705,     // SEQ_DATA_PORT
    0x3086, 0x3D10,     // SEQ_DATA_PORT
    0x3086, 0x4558,     // SEQ_DATA_PORT
    0x3086, 0x2704,     // SEQ_DATA_PORT
    0x3086, 0x2714,     // SEQ_DATA_PORT
    0x3086, 0x3DFF,     // SEQ_DATA_PORT
    0x3086, 0x3DFF,     // SEQ_DATA_PORT
    0x3086, 0x3DEA,     // SEQ_DATA_PORT
    0x3086, 0x2704,     // SEQ_DATA_PORT
    0x3086, 0x6227,     // SEQ_DATA_PORT
    0x3086, 0x288E,     // SEQ_DATA_PORT
    0x3086, 0x0036,     // SEQ_DATA_PORT
    0x3086, 0x2708,     // SEQ_DATA_PORT
    0x3086, 0x3D64,     // SEQ_DATA_PORT
    0x3086, 0x7A3D,     // SEQ_DATA_PORT
    0x3086, 0x0444,     // SEQ_DATA_PORT
    0x3086, 0x2C4B,     // SEQ_DATA_PORT
    0x3086, 0x8F00,     // SEQ_DATA_PORT
    0x3086, 0x4372,     // SEQ_DATA_PORT
    0x3086, 0x719F,     // SEQ_DATA_PORT
    0x3086, 0x6343,     // SEQ_DATA_PORT
    0x3086, 0x166F,     // SEQ_DATA_PORT
    0x3086, 0x9F92,     // SEQ_DATA_PORT
    0x3086, 0x1244,     // SEQ_DATA_PORT
    0x3086, 0x1663,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x9326,     // SEQ_DATA_PORT
    0x3086, 0x0426,     // SEQ_DATA_PORT
    0x3086, 0x848E,     // SEQ_DATA_PORT
    0x3086, 0x0327,     // SEQ_DATA_PORT
    0x3086, 0xFC5C,     // SEQ_DATA_PORT
    0x3086, 0x0D57,     // SEQ_DATA_PORT
    0x3086, 0x5417,     // SEQ_DATA_PORT
    0x3086, 0x0955,     // SEQ_DATA_PORT
    0x3086, 0x5649,     // SEQ_DATA_PORT
    0x3086, 0x5F53,     // SEQ_DATA_PORT
    0x3086, 0x0553,     // SEQ_DATA_PORT
    0x3086, 0x0728,     // SEQ_DATA_PORT
    0x3086, 0x6C4C,     // SEQ_DATA_PORT
    0x3086, 0x0928,     // SEQ_DATA_PORT
    0x3086, 0x2C72,     // SEQ_DATA_PORT
    0x3086, 0xAD7C,     // SEQ_DATA_PORT
    0x3086, 0xA928,     // SEQ_DATA_PORT
    0x3086, 0xA879,     // SEQ_DATA_PORT
    0x3086, 0x6026,     // SEQ_DATA_PORT
    0x3086, 0x9C5C,     // SEQ_DATA_PORT
    0x3086, 0x1B45,     // SEQ_DATA_PORT
    0x3086, 0x4845,     // SEQ_DATA_PORT
    0x3086, 0x0845,     // SEQ_DATA_PORT
    0x3086, 0x8826,     // SEQ_DATA_PORT
    0x3086, 0xBE8E,     // SEQ_DATA_PORT
    0x3086, 0x0127,     // SEQ_DATA_PORT
    0x3086, 0xF817,     // SEQ_DATA_PORT
    0x3086, 0x0227,     // SEQ_DATA_PORT
    0x3086, 0xFA17,     // SEQ_DATA_PORT
    0x3086, 0x095C,     // SEQ_DATA_PORT
    0x3086, 0x0B17,     // SEQ_DATA_PORT
    0x3086, 0x1026,     // SEQ_DATA_PORT
    0x3086, 0xBA5C,     // SEQ_DATA_PORT
    0x3086, 0x0317,     // SEQ_DATA_PORT
    0x3086, 0x1026,     // SEQ_DATA_PORT
    0x3086, 0xB217,     // SEQ_DATA_PORT
    0x3086, 0x065F,     // SEQ_DATA_PORT
    0x3086, 0x2888,     // SEQ_DATA_PORT
    0x3086, 0x9060,     // SEQ_DATA_PORT
    0x3086, 0x27F2,     // SEQ_DATA_PORT
    0x3086, 0x1710,     // SEQ_DATA_PORT
    0x3086, 0x26A2,     // SEQ_DATA_PORT
    0x3086, 0x26A3,     // SEQ_DATA_PORT
    0x3086, 0x5F4D,     // SEQ_DATA_PORT
    0x3086, 0x2808,     // SEQ_DATA_PORT
    0x3086, 0x1927,     // SEQ_DATA_PORT
    0x3086, 0xFA84,     // SEQ_DATA_PORT
    0x3086, 0x69A0,     // SEQ_DATA_PORT
    0x3086, 0x785D,     // SEQ_DATA_PORT
    0x3086, 0x2888,     // SEQ_DATA_PORT
    0x3086, 0x8710,     // SEQ_DATA_PORT
    0x3086, 0x8C82,     // SEQ_DATA_PORT
    0x3086, 0x8926,     // SEQ_DATA_PORT
    0x3086, 0xB217,     // SEQ_DATA_PORT
    0x3086, 0x036B,     // SEQ_DATA_PORT
    0x3086, 0x9C60,     // SEQ_DATA_PORT
    0x3086, 0x9417,     // SEQ_DATA_PORT
    0x3086, 0x2926,     // SEQ_DATA_PORT
    0x3086, 0x8345,     // SEQ_DATA_PORT
    0x3086, 0xA817,     // SEQ_DATA_PORT
    0x3086, 0x0727,     // SEQ_DATA_PORT
    0x3086, 0xFB17,     // SEQ_DATA_PORT
    0x3086, 0x2945,     // SEQ_DATA_PORT
    0x3086, 0x881F,     // SEQ_DATA_PORT
    0x3086, 0x1708,     // SEQ_DATA_PORT
    0x3086, 0x27FA,     // SEQ_DATA_PORT
    0x3086, 0x5D87,     // SEQ_DATA_PORT
    0x3086, 0x108C,     // SEQ_DATA_PORT
    0x3086, 0x8289,     // SEQ_DATA_PORT
    0x3086, 0x170E,     // SEQ_DATA_PORT
    0x3086, 0x4826,     // SEQ_DATA_PORT
    0x3086, 0x9A28,     // SEQ_DATA_PORT
    0x3086, 0x884C,     // SEQ_DATA_PORT
    0x3086, 0x0B79,     // SEQ_DATA_PORT
    0x3086, 0x1730,     // SEQ_DATA_PORT
    0x3086, 0x2692,     // SEQ_DATA_PORT
    0x3086, 0x1709,     // SEQ_DATA_PORT
    0x3086, 0x9160,     // SEQ_DATA_PORT
    0x3086, 0x27F2,     // SEQ_DATA_PORT
    0x3086, 0x1710,     // SEQ_DATA_PORT
    0x3086, 0x2682,     // SEQ_DATA_PORT
    0x3086, 0x2683,     // SEQ_DATA_PORT
    0x3086, 0x5F4D,     // SEQ_DATA_PORT
    0x3086, 0x2808,     // SEQ_DATA_PORT
    0x3086, 0x1927,     // SEQ_DATA_PORT
    0x3086, 0xFA84,     // SEQ_DATA_PORT
    0x3086, 0x69A1,     // SEQ_DATA_PORT
    0x3086, 0x785D,     // SEQ_DATA_PORT
    0x3086, 0x2888,     // SEQ_DATA_PORT
    0x3086, 0x8710,     // SEQ_DATA_PORT
    0x3086, 0x8C80,     // SEQ_DATA_PORT
    0x3086, 0x8A26,     // SEQ_DATA_PORT
    0x3086, 0x9217,     // SEQ_DATA_PORT
    0x3086, 0x036B,     // SEQ_DATA_PORT
    0x3086, 0x9D95,     // SEQ_DATA_PORT
    0x3086, 0x2603,     // SEQ_DATA_PORT
    0x3086, 0x5C01,     // SEQ_DATA_PORT
    0x3086, 0x4558,     // SEQ_DATA_PORT
    0x3086, 0x8E00,     // SEQ_DATA_PORT
    0x3086, 0x2798,     // SEQ_DATA_PORT
    0x3086, 0x170A,     // SEQ_DATA_PORT
    0x3086, 0x4A65,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x6643,     // SEQ_DATA_PORT
    0x3086, 0x165B,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x5943,     // SEQ_DATA_PORT
    0x3086, 0x168E,     // SEQ_DATA_PORT
    0x3086, 0x0327,     // SEQ_DATA_PORT
    0x3086, 0x9C45,     // SEQ_DATA_PORT
    0x3086, 0x7817,     // SEQ_DATA_PORT
    0x3086, 0x0727,     // SEQ_DATA_PORT
    0x3086, 0x9D17,     // SEQ_DATA_PORT
    0x3086, 0x225D,     // SEQ_DATA_PORT
    0x3086, 0x8710,     // SEQ_DATA_PORT
    0x3086, 0x2808,     // SEQ_DATA_PORT
    0x3086, 0x530D,     // SEQ_DATA_PORT
    0x3086, 0x8C80,     // SEQ_DATA_PORT
    0x3086, 0x8A45,     // SEQ_DATA_PORT
    0x3086, 0x5823,     // SEQ_DATA_PORT
    0x3086, 0x1708,     // SEQ_DATA_PORT
    0x3086, 0x8E01,     // SEQ_DATA_PORT
    0x3086, 0x2798,     // SEQ_DATA_PORT
    0x3086, 0x8E00,     // SEQ_DATA_PORT
    0x3086, 0x2644,     // SEQ_DATA_PORT
    0x3086, 0x5C05,     // SEQ_DATA_PORT
    0x3086, 0x1244,     // SEQ_DATA_PORT
    0x3086, 0x4B71,     // SEQ_DATA_PORT
    0x3086, 0x759E,     // SEQ_DATA_PORT
    0x3086, 0x8B85,     // SEQ_DATA_PORT
    0x3086, 0x0143,     // SEQ_DATA_PORT
    0x3086, 0x7271,     // SEQ_DATA_PORT
    0x3086, 0xA346,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x6FA3,     // SEQ_DATA_PORT
    0x3086, 0x9612,     // SEQ_DATA_PORT
    0x3086, 0x4416,     // SEQ_DATA_PORT
    0x3086, 0x4643,     // SEQ_DATA_PORT
    0x3086, 0x1697,     // SEQ_DATA_PORT
    0x3086, 0x2604,     // SEQ_DATA_PORT
    0x3086, 0x2684,     // SEQ_DATA_PORT
    0x3086, 0x8E03,     // SEQ_DATA_PORT
    0x3086, 0x27FC,     // SEQ_DATA_PORT
    0x3086, 0x5C0D,     // SEQ_DATA_PORT
    0x3086, 0x5754,     // SEQ_DATA_PORT
    0x3086, 0x1709,     // SEQ_DATA_PORT
    0x3086, 0x5556,     // SEQ_DATA_PORT
    0x3086, 0x495F,     // SEQ_DATA_PORT
    0x3086, 0x5305,     // SEQ_DATA_PORT
    0x3086, 0x5307,     // SEQ_DATA_PORT
    0x3086, 0x286C,     // SEQ_DATA_PORT
    0x3086, 0x4C09,     // SEQ_DATA_PORT
    0x3086, 0x282C,     // SEQ_DATA_PORT
    0x3086, 0x72AE,     // SEQ_DATA_PORT
    0x3086, 0x7CAA,     // SEQ_DATA_PORT
    0x3086, 0x28A8,     // SEQ_DATA_PORT
    0x3086, 0x7960,     // SEQ_DATA_PORT
    0x3086, 0x269C,     // SEQ_DATA_PORT
    0x3086, 0x5C1B,     // SEQ_DATA_PORT
    0x3086, 0x4548,     // SEQ_DATA_PORT
    0x3086, 0x4508,     // SEQ_DATA_PORT
    0x3086, 0x4588,     // SEQ_DATA_PORT
    0x3086, 0x26BE,     // SEQ_DATA_PORT
    0x3086, 0x8E01,     // SEQ_DATA_PORT
    0x3086, 0x27F8,     // SEQ_DATA_PORT
    0x3086, 0x1702,     // SEQ_DATA_PORT
    0x3086, 0x27FA,     // SEQ_DATA_PORT
    0x3086, 0x1709,     // SEQ_DATA_PORT
    0x3086, 0x5C0B,     // SEQ_DATA_PORT
    0x3086, 0x1710,     // SEQ_DATA_PORT
    0x3086, 0x26BA,     // SEQ_DATA_PORT
    0x3086, 0x5C03,     // SEQ_DATA_PORT
    0x3086, 0x1710,     // SEQ_DATA_PORT
    0x3086, 0x26B2,     // SEQ_DATA_PORT
    0x3086, 0x1706,     // SEQ_DATA_PORT
    0x3086, 0x5F28,     // SEQ_DATA_PORT
    0x3086, 0x8898,     // SEQ_DATA_PORT
    0x3086, 0x6027,     // SEQ_DATA_PORT
    0x3086, 0xF217,     // SEQ_DATA_PORT
    0x3086, 0x1026,     // SEQ_DATA_PORT
    0x3086, 0xA226,     // SEQ_DATA_PORT
    0x3086, 0xA35F,     // SEQ_DATA_PORT
    0x3086, 0x4D28,     // SEQ_DATA_PORT
    0x3086, 0x081A,     // SEQ_DATA_PORT
    0x3086, 0x27FA,     // SEQ_DATA_PORT
    0x3086, 0x8469,     // SEQ_DATA_PORT
    0x3086, 0xA578,     // SEQ_DATA_PORT
    0x3086, 0x5D28,     // SEQ_DATA_PORT
    0x3086, 0x8887,     // SEQ_DATA_PORT
    0x3086, 0x108C,     // SEQ_DATA_PORT
    0x3086, 0x8289,     // SEQ_DATA_PORT
    0x3086, 0x26B2,     // SEQ_DATA_PORT
    0x3086, 0x1703,     // SEQ_DATA_PORT
    0x3086, 0x6BA4,     // SEQ_DATA_PORT
    0x3086, 0x6099,     // SEQ_DATA_PORT
    0x3086, 0x1729,     // SEQ_DATA_PORT
    0x3086, 0x2683,     // SEQ_DATA_PORT
    0x3086, 0x45A8,     // SEQ_DATA_PORT
    0x3086, 0x1707,     // SEQ_DATA_PORT
    0x3086, 0x27FB,     // SEQ_DATA_PORT
    0x3086, 0x1729,     // SEQ_DATA_PORT
    0x3086, 0x4588,     // SEQ_DATA_PORT
    0x3086, 0x2017,     // SEQ_DATA_PORT
    0x3086, 0x0827,     // SEQ_DATA_PORT
    0x3086, 0xFA5D,     // SEQ_DATA_PORT
    0x3086, 0x8710,     // SEQ_DATA_PORT
    0x3086, 0x8C82,     // SEQ_DATA_PORT
    0x3086, 0x8917,     // SEQ_DATA_PORT
    0x3086, 0x0E48,     // SEQ_DATA_PORT
    0x3086, 0x269A,     // SEQ_DATA_PORT
    0x3086, 0x2888,     // SEQ_DATA_PORT
    0x3086, 0x4C0B,     // SEQ_DATA_PORT
    0x3086, 0x7917,     // SEQ_DATA_PORT
    0x3086, 0x3026,     // SEQ_DATA_PORT
    0x3086, 0x9217,     // SEQ_DATA_PORT
    0x3086, 0x099A,     // SEQ_DATA_PORT
    0x3086, 0x6027,     // SEQ_DATA_PORT
    0x3086, 0xF217,     // SEQ_DATA_PORT
    0x3086, 0x1026,     // SEQ_DATA_PORT
    0x3086, 0x8226,     // SEQ_DATA_PORT
    0x3086, 0x835F,     // SEQ_DATA_PORT
    0x3086, 0x4D28,     // SEQ_DATA_PORT
    0x3086, 0x081A,     // SEQ_DATA_PORT
    0x3086, 0x27FA,     // SEQ_DATA_PORT
    0x3086, 0x8469,     // SEQ_DATA_PORT
    0x3086, 0xAB78,     // SEQ_DATA_PORT
    0x3086, 0x5D28,     // SEQ_DATA_PORT
    0x3086, 0x8887,     // SEQ_DATA_PORT
    0x3086, 0x108C,     // SEQ_DATA_PORT
    0x3086, 0x808A,     // SEQ_DATA_PORT
    0x3086, 0x2692,     // SEQ_DATA_PORT
    0x3086, 0x1703,     // SEQ_DATA_PORT
    0x3086, 0x6BA6,     // SEQ_DATA_PORT
    0x3086, 0xA726,     // SEQ_DATA_PORT
    0x3086, 0x035C,     // SEQ_DATA_PORT
    0x3086, 0x0145,     // SEQ_DATA_PORT
    0x3086, 0x588E,     // SEQ_DATA_PORT
    0x3086, 0x0027,     // SEQ_DATA_PORT
    0x3086, 0x9817,     // SEQ_DATA_PORT
    0x3086, 0x0A4A,     // SEQ_DATA_PORT
    0x3086, 0x0A43,     // SEQ_DATA_PORT
    0x3086, 0x160B,     // SEQ_DATA_PORT
    0x3086, 0x438E,     // SEQ_DATA_PORT
    0x3086, 0x0327,     // SEQ_DATA_PORT
    0x3086, 0x9C45,     // SEQ_DATA_PORT
    0x3086, 0x7817,     // SEQ_DATA_PORT
    0x3086, 0x0727,     // SEQ_DATA_PORT
    0x3086, 0x9D17,     // SEQ_DATA_PORT
    0x3086, 0x225D,     // SEQ_DATA_PORT
    0x3086, 0x8710,     // SEQ_DATA_PORT
    0x3086, 0x2808,     // SEQ_DATA_PORT
    0x3086, 0x530D,     // SEQ_DATA_PORT
    0x3086, 0x8C80,     // SEQ_DATA_PORT
    0x3086, 0x8A45,     // SEQ_DATA_PORT
    0x3086, 0x5817,     // SEQ_DATA_PORT
    0x3086, 0x088E,     // SEQ_DATA_PORT
    0x3086, 0x0127,     // SEQ_DATA_PORT
    0x3086, 0x988E,     // SEQ_DATA_PORT
    0x3086, 0x0076,     // SEQ_DATA_PORT
    0x3086, 0xAC77,     // SEQ_DATA_PORT
    0x3086, 0xAC46,     // SEQ_DATA_PORT
    0x3086, 0x4416,     // SEQ_DATA_PORT
    0x3086, 0x16A8,     // SEQ_DATA_PORT
    0x3086, 0x7A26,     // SEQ_DATA_PORT
    0x3086, 0x445C,     // SEQ_DATA_PORT
    0x3086, 0x0512,     // SEQ_DATA_PORT
    0x3086, 0x444B,     // SEQ_DATA_PORT
    0x3086, 0x7175,     // SEQ_DATA_PORT
    0x3086, 0xA24A,     // SEQ_DATA_PORT
    0x3086, 0x0343,     // SEQ_DATA_PORT
    0x3086, 0x1604,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x5843,     // SEQ_DATA_PORT
    0x3086, 0x165A,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x0643,     // SEQ_DATA_PORT
    0x3086, 0x1607,     // SEQ_DATA_PORT
    0x3086, 0x4316,     // SEQ_DATA_PORT
    0x3086, 0x8E03,     // SEQ_DATA_PORT
    0x3086, 0x279C,     // SEQ_DATA_PORT
    0x3086, 0x4578,     // SEQ_DATA_PORT
    0x3086, 0x7B17,     // SEQ_DATA_PORT
    0x3086, 0x078B,     // SEQ_DATA_PORT
    0x3086, 0x8627,     // SEQ_DATA_PORT
    0x3086, 0x9D17,     // SEQ_DATA_PORT
    0x3086, 0x2345,     // SEQ_DATA_PORT
    0x3086, 0x5822,     // SEQ_DATA_PORT
    0x3086, 0x1708,     // SEQ_DATA_PORT
    0x3086, 0x8E01,     // SEQ_DATA_PORT
    0x3086, 0x2798,     // SEQ_DATA_PORT
    0x3086, 0x8E00,     // SEQ_DATA_PORT
    0x3086, 0x2644,     // SEQ_DATA_PORT
    0x3086, 0x5C05,     // SEQ_DATA_PORT
    0x3086, 0x1244,     // SEQ_DATA_PORT
    0x3086, 0x4B8D,     // SEQ_DATA_PORT
    0x3086, 0x602C,     // SEQ_DATA_PORT
    0x3086, 0x2C2C,     // SEQ_DATA_PORT
    0x3086, 0x2C00,     // SEQ_DATA_PORT

    //[720P30fps_configuration]
    //0x3004, 0x001C,   // X_ADDR_START
    //0x3002, 0x003C,   // Y_ADDR_START
    //0x3008, 0x0523,   // X_ADDR_END
    //0x3006, 0x0313,   // Y_ADDR_END
    //0x300A, 0x02EE,   // FRAME_LENGTH_LINES
    //0x300C, 0x0672,   // LINE_LENGTH_PCK
    //0x3012, 0x02B9,   // COARSE_INTEGRATION_TIME
    //0x30A2, 0x0001,   // X_ODD_INC
    //0x30A6, 0x0001,   // Y_ODD_INC
    //0x3040, 0x0000,   // READ_MODE

    //[PLL_configuration_Parallel]
    //Mclk:27Mhz Pclk:37Mhz
    //0x302A, 0x0006,   // VT_PIX_CLK_DIV
    //0x302C, 0x0002,   // VT_SYS_CLK_DIV
    //0x302E, 0x0009,   // PRE_PLL_CLK_DIV
    //0x3030, 0x0094,   // PLL_MULTIPLIER
    //0x3036, 0x000C,   // OP_PIX_CLK_DIV
    //0x3038, 0x0004,   // OP_SYS_CLK_DIV

    //Mclk:27Mhz Pclk:74.25Mhz
    0x302A, 0x0006,     // VT_PIX_CLK_DIV
    0x302C, 0x0001,     // VT_SYS_CLK_DIV
    0x302E, 0x0004,     // PRE_PLL_CLK_DIV
    0x3030, 0x0042,     // PLL_MULTIPLIER
    0x3036, 0x000C,     // OP_PIX_CLK_DIV
    0x3038, 0x0002,     // OP_SYS_CLK_DIV


#if 1
	//[720P60fps_configuration]
	0x3004, 0x001C,	// X_ADDR_START
	0x3002, 0x003C,	// Y_ADDR_START
	0x3008, 0x0523,	// X_ADDR_END
	0x3006, 0x0313,	// Y_ADDR_END
	0x300A, 0x02EE,	// FRAME_LENGTH_LINES  //VTOTAL
	0x300C, 0x0672,	// LINE_LENGTH_PCK     //HTOTAL
	0x3012, 0x02C6, // COARSE_INTEGRATION_TIME  VTOTAL-1 // SHUTTER MAX
#else
    //[720P60fps_configuration]
	0x3004, 0x001C,	// X_ADDR_START
	0x3002, 0x003C,	// Y_ADDR_START
	0x3008, 0x0523,	// X_ADDR_END
	0x3006, 0x0313,	// Y_ADDR_END
	0x300A, 0x02E5,	// FRAME_LENGTH_LINES
	0x300C, 0x0680,	// LINE_LENGTH_PCK
	0x3012, 0x02E4,// COARSE_INTEGRATION_TIME
#endif

    0x30A2, 0x0001,     // X_ODD_INC
    0x30A6, 0x0001,     // Y_ODD_INC
    0x3040, 0x0000,     // READ_MODE

    //[AR0140 Rev2 Optimized Settings]
    0x3044, 0x0400,     // DARK_CONTROL
    0x3052, 0xA134,     // OTPM_CFG
    0x3054, 0x0400,     // OTPM_EXPR
    0x3092, 0x010F,     // ROW_NOISE_CONTROL
    0x30FE, 0x0080,     // NOISE_PEDESTAL
    0x3ECE, 0x40FF,     // DAC_LD_2_3
    0x3ED0, 0xFF40,     // DAC_LD_4_5
    0x3ED2, 0xA906,     // DAC_LD_6_7
    0x3ED4, 0x001F,     // DAC_LD_8_9
    0x3ED6, 0x637F,     // DAC_LD_10_11
    0x3ED8, 0xAA99,     // DAC_LD_12_13
    0x3EDA, 0x0C88,     // DAC_LD_14_15
    0x3EDE, 0x8878,     // DAC_LD_18_19
    0x3EE0, 0x7755,     // DAC_LD_20_21
    0x3EE2, 0x5563,     // DAC_LD_22_23
    0x3EE4, 0xAAF0,     // DAC_LD_24_25
    0x3EE6, 0x1400,     // DAC_LD_26_27
    0x3EEA, 0xA4FF,     // DAC_LD_30_31
    0x3EEC, 0x80F0,     // DAC_LD_32_33
    0x3EEE, 0x0000,     // DAC_LD_34_35
    0x3EF0, 0x721F,     // DAC_LD_36_37
    0x3EF2, 0x000F,     // DAC_LD_38_39
    0x3EF4, 0x000C,     // DAC_LD_40_41
    0x3F30, 0x0060,     // ROW_NOISE_CONTROL2
    0x31E0, 0x1701,     // PIX_DEF_ID
    0x301E, 0x0000,     // PEDESTAL

    //[HDR Mode 16x Setup]
    0x3082, 0x0008,     // OPERATION_MODE_CTRL
    0x305E, 0x0080,     // GLOBAL_GAIN
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
    0x3082, 0x0008,     // OPERATION_MODE_CTRL

    //Motion Compensation On
    0x318C, 0xC000,     // HDR_MC_CTRL2

    //ADACD Enabled
    0x320A, 0x0080,     // ADACD_PEDESTAL
    0x3206, 0x0A06,     // ADACD_NOISE_FLOOR1
    0x3206, 0x0A06,     // ADACD_NOISE_FLOOR1
    0x3208, 0x1A12,     // ADACD_NOISE_FLOOR2
    0x3208, 0x1A12,     // ADACD_NOISE_FLOOR2
    0x3202, 0x00A0,     // ADACD_NOISE_MODEL1
    0x3200, 0x0002,     // ADACD_CONTROL

    //Companding_enabled_16to12
    0x31AC, 0x100C,     // DATA_FORMAT_BITS
    0x31D0, 0x0001,     // COMPANDING

    0x318A, 0x0E74,     // HDR_MC_CTRL1
    0x3192, 0x0400,     // HDR_MC_CTRL5
    0x3198, 0x183C,     // HDR_MC_CTRL8
    0x318E, 0x0800,     // HDR_MC_CTRL3
    0x3194, 0x0BB8,     // HDR_MC_CTRL6
    0x3196, 0x0E74,     // HDR_MC_CTRL7

    //Disable Embedded Data and Stats
    0x3064, 0x1902,     // SMIA_TEST
    0x3064, 0x1802,     // SMIA_TEST

    //Enable DevWare Colorpipe CCM and AWB settings
    //[Companding_enabled_16to12]
    0x31AC, 0x100C,     // DATA_FORMAT_BITS
    0x31D0, 0x0001,     // COMPANDING

#if 1 // test,
    0x3040, 0xC000,     // READ_MODE
    0x3060, 0x0016,
    0x30B6, 0x0B40,     // spare register for tempsens calibration value...
    0x30B8, 0x3386,     // spare register for tempsens calibration value...
#endif

    0x30B0, 0x0000,     // DIGITAL_TEST
    0x30BA, 0x012C,     // DIGITAL_CTRL
    0x31AE, 0x0301,     // SERIAL_FORMAT
    0x301A, 0x10DC,     // RESET_REGISTER
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
};

#endif
#endif


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

UINT32 APACHE_CMOS_AR0140AT_Init(void)
{
#if (SENSOR_SELECT == SENSOR_COMMON)
	return NC_SUCCESS;
#else

    UINT32 Size, i, rdData;
    INT32 ret = NC_SUCCESS;

    Size = sizeof(gAR0140AT_Table)/sizeof(AR0140AT_DATA);

    for(i = 0; i < Size; i++)
    {
        DEBUGMSG(MSGINFO, ".");
        //DEBUGMSG(MSGINFO, "@0x%04X 0x%04X\n", gAR0140AT_Table[i].Addr, gAR0140AT_Table[i].Data);

        if(gAR0140AT_Table[i].Addr == 0xFEF0)
        {
            APACHE_SYS_mDelay(100);
            //APACHE_SYS_mDelay(gAR0140AT_Table[i].Data);
        }
        else
        {
            //DEBUGMSG(MSGINFO, "[W]0x%04x, 0x%04x, 0x%04x\n", AR0140AT_DEVICEID, gAR0140AT_Table[i].Addr, gAR0140AT_Table[i].Data);
            ret |= ncLib_I2C_Write(I2C_CH0, AR0140AT_DEVICEID, gAR0140AT_Table[i].Addr, gAR0140AT_Table[i].Data, 1, I2C_ADDR_16_DATA_16);

#if 1
            if(i)
            {
                APACHE_SYS_mDelay(2);

                ret |= ncLib_I2C_Read(I2C_CH0, AR0140AT_DEVICEID, gAR0140AT_Table[i].Addr, (UINT8 *)&rdData, 1, I2C_ADDR_16_DATA_16);
                //DEBUGMSG(MSGINFO, "[R]0x%04x, 0x%04x, 0x%04x\n", AR0140AT_DEVICEID, gAR0140AT_Table[i].Addr, rdData);

                if(gAR0140AT_Table[i].Data != rdData)
                {
                    if(gAR0140AT_Table[i].Addr != 0x3086)
                    {
                        ret = NC_FAILURE;
                        DEBUGMSG(MSGINFO, "\n");
                        DEBUGMSG(MSGWARN, "Warning, %d [W]0x%04x, 0x%04x, 0x%04x\n", i, AR0140AT_DEVICEID, gAR0140AT_Table[i].Addr, gAR0140AT_Table[i].Data);
                        DEBUGMSG(MSGWARN, "Warning, %d [R]0x%04x, 0x%04x, 0x%04x\n", i, AR0140AT_DEVICEID, gAR0140AT_Table[i].Addr, rdData);
                    }
                }
            }
#endif
        }
    }

    DEBUGMSG(MSGINFO, "\n");

    return ret;
#endif
}


INT32 APACHE_SYS_InitAR0140AT(void)
{
    INT32 ret = NC_SUCCESS;

#if (SENSOR_SELECT == SENSOR_COMMON)
#else

    APACHE_SYS_mDelay(100);

    ret = APACHE_CMOS_AR0140AT_Init();

    APACHE_SYS_mDelay(100);
#endif
	
   return ret;
}


/* End Of File */




