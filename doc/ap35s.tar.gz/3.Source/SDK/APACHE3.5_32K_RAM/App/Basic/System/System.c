/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : System.c
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#include "App.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

void APACHE3_SYS_30msecHandler(void);
void APACHE3_SYS_50msecHandler(void);


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void APACHE_SYS_InitDebugPort(UINT32 nDbgZone_APP, UINT32 nDbgZone_SDK)
{
    tUART_PARAM param;
    INT32 ret = NC_SUCCESS;
    
    param.uartClk = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_UART, CMD_END);
    param.baudRate = UT_BAUDRATE_115200;
    param.sps = UT_SPS_DIS;
    param.wlen = UT_DATA_8BIT;
    param.fen = UT_FIFO_ENA;
    param.stp2 = UT_STOP_1BIT;
    param.eps = UT_EPS_DIS;
    param.pen = UT_PARITY_DIS;
    param.brk = UT_BRK_DIS;

    ret = ncLib_DEBUG_Open(param.uartClk);
    ret = ncLib_DEBUG_Control(GCMD_DBG_INIT, UART_CH0, &param, CMD_END);

    /* APP Debug Zone */
    ncLib_DEBUG_Control(GCMD_DBG_APP_LOG_ZONE, nDbgZone_APP, ON, CMD_END);

    /* SDK Debug Zone */
    ncLib_DEBUG_Control(GCMD_DBG_SDK_LOG_ZONE, nDbgZone_SDK, ON, CMD_END);

    if(ret == NC_SUCCESS)
    {
        DEBUGMSG(MSGINFO, "Initialize Debug Port ... OK!\n");
    }
}


void APACHE_SYS_InitSysTimer(void)
{
    struct tm tSysTime;
    INT32 ret;


    DEBUGMSG(MSGINFO, "Initialize System Time ... ");

    /*
     * Open all Timer (Timer 0 ~ 1)
     */
    ret = ncLib_TIMER_Open( ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_TIMER, CMD_END) );
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "Timer Open Error!\n");
    }

    /*
     * Open System Timer with T/C Channel 0
     */
    ncLib_SYSTIME_Open(TC_CH0);


    /*
     * Start System Timer
     */
    ncLib_SYSTIME_Control(GCMD_ST_START_SYSTIME, CMD_END);



    /*
     * Initialize system time.
     * System time has been counted in second from January 1, 1970
     */
    memset(&tSysTime, 0, sizeof(struct tm));
    tSysTime.tm_year    = 2016-1900;
    tSysTime.tm_mon     = 1-1;
    tSysTime.tm_mday    = 1;
    tSysTime.tm_hour    = 0;
    tSysTime.tm_min     = 0;
    tSysTime.tm_sec     = 0;
    ncLib_SYSTIME_Control(GCMD_ST_SET_SYSTIME_DATE, (UINT32)&tSysTime, CMD_END);

    DEBUGMSG(MSGINFO, "OK!\n");
}


void APACHE_SYS_InitJigPort(void)
{
    tUART_PARAM param;
    INT32 ret = NC_SUCCESS;

    DEBUGMSG(MSGINFO, "Initialize JIG Port ... ");

    param.uartClk   = ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_UART, CMD_END);
    param.baudRate  = UT_BAUDRATE_38400;
    param.sps       = UT_SPS_DIS;
    param.wlen      = UT_DATA_8BIT;
    param.fen       = UT_FIFO_ENA;
    param.stp2      = UT_STOP_1BIT;
    param.eps       = UT_EPS_DIS;
    param.pen       = UT_PARITY_DIS;
    param.brk       = UT_BRK_DIS;

    ret = ncLib_JIG_Open(param.uartClk);
    ret |= ncLib_JIG_Control(GCMD_JIG_INIT, UART_CH1, &param, CMD_END);

    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "FAIL!\n");
    }
    else
    {
        /* Connect 50m second period timer handler to check JIG Interface   */
        ncLib_SYSTIME_Control(GCMD_ST_CONNECT_PTE_HANDLER, ST_PTE_MSEC1, 30, APACHE3_SYS_30msecHandler, CMD_END);

        DEBUGMSG(MSGINFO, "OK!\n");
    }
}


void APACHE_SYS_InitsFlash(void)
{
    tSF_INIT_PARAM tsFlashParam;
    tSFLASH_ID tFlashID;
    
    ncLib_SF_Open( ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_SSPI, CMD_END) );


    // FPGA DB Version
    // - r560-a1_2016_0126  SSP1
    // - r560-a8_2016_0131  SSP1
    // - r627-a1_2016_0204  SSP1
    // - r730-a1_2016_0222          SSP0

    tsFlashParam.mChNum     = 0;                    // SSP Contorler Number
    tsFlashParam.mDmaMode   = TRUE;                 // TRUE(1): DMA Mode   FALSE(0): PIO Mode
    tsFlashParam.mQuadMode  = TRUE;                 // TRUE(1): Quad SPI   FALSE(0): Standard SPI
    tsFlashParam.mBitRate   = SF_BITRATE_2Mbps;
//    ncLib_SF_Control(GCMD_SF_INIT, &tsFlashParam, CMD_END);
 	ncSvc_SF_Init((ptSF_INIT_PARAM)&tsFlashParam);

    /* Get Chip Size from RDID */
    //ncLib_SF_Control(GCMD_SF_READ_ID, &tFlashID, CMD_END);
	ncSvc_SF_ReadDeviceIdentification( (tSFLASH_ID *) &tFlashID);
	
    /* Display Test Result */
    DEBUGMSG(MSGINFO, "sFlash ID : 0x%02x 0x%02x 0x%02x\n", tFlashID.mbManufacture,
                                                            tFlashID.mbMemoryType,
                                                            tFlashID.mbMemoryCapacity);

    if(tFlashID.mbManufacture != 0xFF)
    {
        DEBUGMSG(MSGINFO, "Initialize sFlash Interface ... OK!\n"); 
    }
}


void APACHE_SYS_DeInitsFlash(void)
{
    ncLib_SF_Control(GCMD_SF_DEINIT, CMD_END);
    ncLib_SF_Close();
}


void APACHE3_SYS_30msecHandler(void)
{
    // Jig Command Callback

    ncLib_JIG_Control(GCMD_JIG_DO_COMMAND, UART_CH1, CMD_END);
}


void APACHE3_SYS_50msecHandler(void)
{
    // Key Scan Callback
}


void APACHE_SYS_mDelay(UINT32 mSec)
{
#if APACHE35_SYSTEM_TIMER_ON
    ncLib_SYSTIME_Control(GCMD_ST_MDELAY, mSec, CMD_END);
#else
    UINT32 i, j;

    for(i = 0; i < mSec; i++)
    {
        for(j = 0; j < 1000; j++);
        //for(j = 0; j < 1000; j++);
    }
#endif
}


INT32 APACHE_SYS_Asc2Int(char ch)
{
    if     ((ch>='0') && (ch<='9')) return  (ch-'0');
    else if((ch>='A') && (ch<='Z')) return ((ch-'A')+10 );
    else if((ch>='a') && (ch<='z')) return ((ch-'a')+10 );

    return -1;
}


/* End Of File */
