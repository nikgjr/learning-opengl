/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __KEY_SVC__
#define __KEY_SVC__


#define KEY_SYSTEM_EMPTY    0x1F
#define KEY_SYSTEM_SET      0x0F
#define KEY_SYSTEM_LEFT     0x1E
#define KEY_SYSTEM_RIGHT    0x1D
#define KEY_SYSTEM_UP       0x1B
#define KEY_SYSTEM_DOWN     0x17



typedef struct
{
	volatile UCHAR keyValue;
} STRUCT_RS485;

typedef struct
{
	volatile UCHAR	Value;
	UCHAR	Set;
	UCHAR	Cnt;

#ifdef KEY_GPIO
	union
	{
		UCHAR	D8;
		struct
		{
			UCHAR	Left:		1;
			UCHAR	Right:		1;
			UCHAR	Up: 		1;
			UCHAR	Down:		1;
			UCHAR	Set:		1;
			UCHAR	Etc1:		1;
			UCHAR	Etc2:		1;
			UCHAR	Etc3:		1;		
		}Bit8;		
	}Gpio;
#endif
	UCHAR ADCRmtKey;
	UCHAR HotKeyLong;
} STRUCT_KEY;

extern STRUCT_KEY	sAppKey;


/*=============================================================================
	Function Declaration
=============================================================================*/

UCHAR* ncSvc_KeyValue_Get(void);
void ncSvc_KeyValue_Set(UCHAR value);

UCHAR* ncSvc_KeyHotKeyLong_Get(void);
void ncSvc_KeyHotKeyLong_Set(UCHAR value);


/********************************************************************************
* Function Name : ncSvc_KeyInitialize_Set()
* Description: Key Interface Init.
*              this driver can support polling mode or interrupt mode
********************************************************************************/
void ncSvc_KeyInitialize_Set(void);




/********************************************************************************
* Function Name : ncSvc_Key_Get() 
* Description: GPIO & ADC & PalcoD/P Key
********************************************************************************/
void ncSvc_Key_Get(void);





/********************************************************************************
* Function Name : ncSvc_RegKey_Get()
* Description: Register Key Get.
********************************************************************************/
void ncSvc_RegKey_Get(void);  /* [2015/03/02] Park Min : [STD]-01 */

#endif

