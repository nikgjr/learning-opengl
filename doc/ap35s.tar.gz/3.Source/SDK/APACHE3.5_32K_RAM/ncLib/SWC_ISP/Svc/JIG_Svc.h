/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : JIG_Svc.h
*
*  @brief   : This file is JIG controller application support package hearder
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __JIG_SVC_H__
#define __JIG_SVC_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Uart_Lib.h"

//#include "ISP_Drv.h"


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/
#define APACHE2p8_JIG

#define UART_POLLING_TYPE                   0
#define UART_INTERRUPT_TYPE                 1

#define APACHE_NEXTUNE_JIG_RECIEVE_TYPE    UART_INTERRUPT_TYPE


#define JIG_RX_BUF_SIZE         256
#define NICP_CMD_SIZE           7

#define	JIG_DEBUG_CMD           0x00
#define	JIG_NICP_CMD            0x01

#define JIG_FLASH_OPEN          0x00
#define JIG_FLASH_CLOSE         0x01


/*
* 16BIT JIG Command String Value
*/

#define JIG_ADDR_16BIT              2

#define JIG_CMD_ISP_R               "ISPR?"
#define JIG_CMD_ISP_R_CMP_SIZE      5

#define JIG_CMD_ISP_W               "ISPW="
#define JIG_CMD_ISP_W_CMP_SIZE      5

#define JIG_CMD_ISP_RL              "ISPRL?"
#define JIG_CMD_ISP_RL_CMP_SIZE     6

#define JIG_CMD_ISP_WL              "ISPWL="
#define JIG_CMD_ISP_WL_CMP_SIZE     6


/*
* 32BIT JIG Command String Value
*/

#define JIG_ADDR_32BIT              4

#define JIG_CMD_ISP_R2              "ISPR2?"
#define JIG_CMD_ISP_R2_CMP_SIZE     6

#define JIG_CMD_ISP_W2              "ISPW2="
#define JIG_CMD_ISP_W2_CMP_SIZE     6


/*
* Common Command String Value
*/

#define JIG_CMD_SENSOR_R            "SENSORR?"
#define JIG_CMD_SENSOR_R_CMP_SIZE   8

#define JIG_CMD_SENSOR_W            "SENSORW="
#define JIG_CMD_SENSOR_W_CMP_SIZE   8

#define JIG_CMD_HDMI_R              "HDMI?"
#define JIG_CMD_HDMI_R_CMP_SIZE     5

#define JIG_CMD_HDMI_W              "HDMI="
#define JIG_CMD_HDMI_W_CMP_SIZE     5

#define JIG_CMD_FPORT               "FPORT="
#define JIG_CMD_FPORT_CMP_SIZE      6

#define JIG_CMD_EEPSAVE             "EEPSAVE"
#define JIG_CMD_EEPSAVE_CMP_SIZE    7

#define JIG_CMD_EEPLOAD             "EEPLOAD"
#define JIG_CMD_EEPLOAD_CMP_SIZE    7

#define JIG_CMD_PRODUCT             "PRODUCT"
#define JIG_CMD_PRODUCT_CMP_SIZE    7

#define JIG_CMD_FIRMWARE            "FIRMWARE"
#define JIG_CMD_FIRMWARE_CMP_SIZE   8

#define JIG_CMD_BAUDTEST            "TX"
#define JIG_CMD_BAUDTEST_CMP_SIZE   2


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT8 CmdInFlag;
    UINT8 SubCmdFlag;

    UINT8 RxCmdFlag;
    UINT8 RxBuffer[256];

    UINT8 BufferPutCount;
    UINT8 BufferGetCount;
    UINT8 Baudrate;

} UARTInfo_ST, *ptUARTInfo_ST;


typedef struct
{
    UINT8 KeyValue;
    
    UINT8 UARTInCmd[64];
    UINT8 CmdGetPointer;

    UINT8 JigData[64];
    UINT8 JigCommand[20];

    union{

        UCHAR D8;

        struct
        {
            UCHAR One:      1;
            UCHAR Two:      1; // AEDebug (Printfs or PutString)
            UCHAR Three:    1;
            UCHAR Four:     1;
            UCHAR Five:     1;
            UCHAR Six:      1;
            UCHAR Seven:    1;
            UCHAR Eight:    1;
        } B8;
    }Cmd0;

    union{

        UCHAR D8;

        struct
        {
            UCHAR One:      1; // AWBDebug (Printfs or PutString)
            UCHAR Two:      1; // OPD CIExy Read Mode(0: All OPD Data , 1: Average of OPD     Data)
            UCHAR Three:    1; // AWBCIESEND TYPE(OPD CIExy Read Mode is "0" :  Data "    Read All" or "�Ϻθ� Read")
            UCHAR Four:     1;
            UCHAR Five:     1;
            UCHAR Six:      1;
            UCHAR Seven:    1;
            UCHAR Eight:    1;
        } B8;
    }Cmd1;

    union{

        UCHAR D8;

        struct
        {
            UCHAR One:      1;
            UCHAR Two:      1;
            UCHAR Three:    1;
            UCHAR Four:     1;
            UCHAR Five:     1;
            UCHAR Six:      1;
            UCHAR Seven:    1;
            UCHAR Eight:    1;
        } B8;
    }Cmd2;

    union{

        UCHAR D8;

        struct
        {
            UCHAR One:      1;
            UCHAR Two:      1;
            UCHAR Three:    1;
            UCHAR Four:     1;
            UCHAR Five:     1;
            UCHAR Six:      1;
            UCHAR Seven:    1;
            UCHAR Eight:    1;
        } B8;
    }Cmd3;

} JIGInfo_ST, *ptJIGInfo_ST;
extern JIGInfo_ST stJigInfo;

#ifdef APACHE2p8_JIG

#define	RX_BUF_SIZE	256 //128

typedef struct
{
    UCHAR 	RxPointer;
	UCHAR 	RxRealBuffer[RX_BUF_SIZE];
	UCHAR 	RxTempBuffer[RX_BUF_SIZE];	
	UCHAR	Protocol;                       // 2bit
	UCHAR 	RxInputCount;
	UCHAR	Command;                        // 1bit
	UCHAR	RxStart;
	UCHAR 	Mode;
	UCHAR	CmdProcess;
} STRUCT_HAL_UART;

#endif

/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/
extern void  ncSvc_JIG_RxISR(UINT32 nIrqNum);
extern INT32 ncSvc_JIG_CommandMain(eUART_CH channel);
extern INT32 ncSvc_JIG_RxRead(eUART_CH channel);
extern INT32 ncSvc_JIG_GetCommand(void);

extern INT32 ncSvc_JIG_Command_Parser(void);
extern INT32 ncSvc_JIG_Command_Compare(UINT8 *cmp_data, UINT8 cmp_cnt);
extern UINT8 ncSvc_JIG_Command_Read(void);

//extern UINT8 ncSvc_JIG_StatusReg_Write(UINT8 MSBAddr, UINT8 LSBAddr, UINT8 Wdata);
extern UINT8 ncSvc_JIG_StatusReg_Write(UINT32 Addr, UINT32 Wdata);
extern UINT8 ncSvc_JIG_StatusReg_Read(UINT32 Addr);

extern UINT8 ncSvc_JIG_1byteAsciiToHex(UINT8 data);
extern UINT8 ncSvc_JIG_2byteAsciiToHex(UINT8 data_h, UINT8 data_l);

extern void  ncSvc_JIG_FPORT_Open(void);
extern void  ncSvc_JIG_FPORT_Close(void);
extern void  ncSvc_JIG_InitJigInfo(void);

#ifdef APACHE2p8_JIG
extern INT32 ncSvc_Jig_Task(void);
extern UCHAR Ascii_To_Hex_2byte(UCHAR data_h, UCHAR data_l);
extern UCHAR Ascii_To_Hex_1byte(UCHAR data);
extern BOOL Parser_NC(void);
extern CHAR Read_Command(void);
extern CHAR Cmd_Compare(UCHAR *cmp_data, UCHAR cmp_cnt);
extern void UART_Common(void);
#endif

#endif  /* __JIG_SVC_H__ */


/* End Of File */
