
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APACHE2.8
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
		2016.01.26      M.Y Sung    0.0     platform change
********************************************************************************/


#ifndef __SVC_NICP_H__
#define __SVC_NICP_H__

typedef enum
{
    ePROCESSING         = 0xF0,
    eSUCCESS            = 0xF1,
    eFAIL_PACKET_LENGTH = 0xF2,
    eFAIL_COMMAND       = 0xF3,
    eFAIL_ADDRESS       = 0xF4,
    eFAIL_DATA_COUNT    = 0xF5,
    eFAIL_CHECKSUM      = 0xF6,
}eNICP_RESPONSE_TYPE;

typedef enum
{
    eRxBUFF_PACKET_LENGTH = 0,
    eRxBUFF_COMMAND,
    eRxBUFF_CONTROL,    /* COMMAND CONTROL VALUE(DATA COUNT) */
    eRxBUFF_ADDR_MSB,
    eRxBUFF_ADDR_LSB,
    eRxBUFF_DATA_1ST,
    eRxBUFF_DATA_2ND,
 }eNICP_BUFFER_IDX_COMMON_TYPE;

typedef enum
{
    eRxBUFF_OSD_POSITION_Y = 3,
    eRxBUFF_OSD_POSITION_X,
    eRxBUFF_OSD_OPTION,
    eRxBUFF_OSD_DATA,
}eNICP_BUFFER_IDX_OSD_TYPE;


typedef enum
{
    eNICPCMD_RESERVED,
    eNICPCMD_ISP_READ,
    eNICPCMD_ISP_WRITE,
    eNICPCMD_SENSOR_READ,
    eNICPCMD_SENSOR_WRITE,
    eNICPCMD_OSD_WRITE,
    eNICPCMD_OSD_CLEAR,
    eNICPCMD_MAX,
}eNICP_COMMAND_INDEX;

typedef enum
{
    eTxBUFF_PACKET_LENGTH   = 0,
    eTxBUFF_RESPONSE_CODE   = 1,
    eTxBUFF_CHECKSUM        = 2,
    eTxBuFF_DEFAULT_COUNT,
}eNICP_BUFFER_TX_TYPE;

typedef struct{
	eNICP_RESPONSE_TYPE(* Func)(UCHAR Control);
} STRUCT_NICP_COMMAND;


typedef struct
{
	UCHAR KeyValue;
	UCHAR RxCheckSum;
	UCHAR RxBuffer[128];
}STRUCT_MW_NICP;
extern STRUCT_MW_NICP	sMwNICP;


/*
********************************************************************************
*              Debug FUNCTION DECLARATIONS 
********************************************************************************
*/
extern void ncSvc_NICP_Set(void);

#endif


