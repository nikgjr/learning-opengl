/********************************************************************************
*				Copyright (C) 2014 NEXTCHIP Inc. All Rights Reserved.
*********************************************************************************
*	
*	Contents	: Br8051 Init
*	File Path	: \source\3_cfile\2_middleware 
*	File Name 	: mw_wdr_imx136.c 
*	Enviroment	: IAR Imbedded WorkBench6.0 for 8051[8.10]
*	Description	: 
*	
*********************************************************************************
*	History      : 
		CreationDate		Modifier		Ver		Description
		-------------------------------------------------------
		 2015.6.2	        JWLee	        1.00    Newly Generated
*********************************************************************************/

#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "WDRLib_Svc.h"
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"

#if (OPTION_WDR_TYPE == WDRTYPE_DCOMP_AR||OPTION_WDR_TYPE == WDRTYPE_SENSER)

#if (SENSOR_SELECT == SENSOR_COMMON)
extern void SENSOR_WDR_On(void);
extern void SENSOR_WDR_Off(void);
#endif

typedef struct
{
    UINT16 Addr;
    UINT16 Data;
} AR0140AT_DATA1;

AR0140AT_DATA1 gAR0140AT_WDR_ON_Table[] =
{


     //Mclk:27Mhz Pclk:74.25Mhz
    0x302A, 0x0006,     // VT_PIX_CLK_DIV
    0x302C, 0x0001,     // VT_SYS_CLK_DIV
    0x302E, 0x0004,     // PRE_PLL_CLK_DIV
    0x3030, 0x0042,     // PLL_MULTIPLIER
    0x3036, 0x000C,     // OP_PIX_CLK_DIV
    0x3038, 0x0002,     // OP_SYS_CLK_DIV
  
    //[720P60fps_configuration]
    0x3004, 0x001C,	// X_ADDR_START
    0x3002, 0x003C,	// Y_ADDR_START
    0x3008, 0x0523,	// X_ADDR_END
    0x3006, 0x0313,	// Y_ADDR_END
    0x300A, 0x02EE,	// FRAME_LENGTH_LINES  //VTOTAL
    0x300C, 0x0672,	// LINE_LENGTH_PCK     //H TOTAL
    0x3012, 0x02ED,   // COARSE_INTEGRATION_TIME  VTOTAL-1 // SHUTTER MAX
    0x30A2, 0x0001,	// X_ODD_INC
    0x30A6, 0x0001,	// Y_ODD_INC
    0x3040, 0x0000,	// READ_MODE


    //[HDR Mode 16x Setup]
    0x3082, 0x0008,     // OPERATION_MODE_CTRL
    0x305E, 0x0080,     // GLOBAL_GAIN
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
    0xFEF0, 0x4000,     //HAL_NOP_Delay(700 //DELAY= 2
    0x3082, 0x0008,     // OPERATION_MODE_CTRL 

    //Motion Compensation On
    0x318C, 0xC000,     // HDR_MC_CTRL2

    //ADACD Enabled
    0x320A, 0x0080,     // ADACD_PEDESTAL
    0x3206, 0x0A06,     // ADACD_NOISE_FLOOR1
    0x3206, 0x0A06,     // ADACD_NOISE_FLOOR1
    0x3208, 0x1A12,     // ADACD_NOISE_FLOOR2
    0x3208, 0x1A12,     // ADACD_NOISE_FLOOR2
    0x3202, 0x00A0,     // ADACD_NOISE_MODEL1
    0x3200, 0x0002,     // ADACD_CONTROL

    //Companding_enabled_16to12
    0x31AC, 0x100C,     // DATA_FORMAT_BITS
    0x31D0, 0x0001,     // COMPANDING

    0x318A, 0x0E74,     // HDR_MC_CTRL1
    0x3192, 0x0400,     // HDR_MC_CTRL5
    0x3198, 0x183C,     // HDR_MC_CTRL8
    0x318E, 0x0800,     // HDR_MC_CTRL3
    0x3194, 0x0BB8,     // HDR_MC_CTRL6
    0x3196, 0x0E74,     // HDR_MC_CTRL7
    
    //Disable Embedded Data and Stats
    0x3064, 0x1902,     // SMIA_TEST
    0x3064, 0x1802,     // SMIA_TEST
    //Companding_enabled_16to12
    0x31AC, 0x100C,     // DATA_FORMAT_BITS
    0x31D0, 0x0001,     // COMPANDING  
 
};

AR0140AT_DATA1 gAR0140AT_WDR_OFF_Table[] =
{
	//[720P60fps_configuration]
	0x3004, 0x001C,	// X_ADDR_START
	0x3002, 0x003C,	// Y_ADDR_START
	0x3008, 0x0523,	// X_ADDR_END
	0x3006, 0x0313,	// Y_ADDR_END
	0x300A, 0x02EE,	// FRAME_LENGTH_LINES
	0x300C, 0x0672,	// LINE_LENGTH_PCK
	0x3012, 0x02BA,   // COARSE_INTEGRATION_TIME  VTOTAL-8 // SHUTTER MAX

	0x30A2, 0x0001,	// X_ODD_INC
	0x30A6, 0x0001,	// Y_ODD_INC
	0x3040, 0x0000,	// READ_MODE


    //[Linear Mode Setup]
    0x3082, 0x0009,     // OPERATION_MODE_CTRL
    0x305E, 0x0080,     // GLOBAL_GAIN //b0
    0x3082, 0x0009,     // OPERATION_MODE_CTRL 

    //Motion Compensation Off
    0x318C, 0x0000,     // HDR_MC_CTRL2

    //ADACD Disabled
    0x3200, 0x0000,     // ADACD_CONTROL

    //Companding_disabled
    0x31D0, 0x0000,     // COMPANDING
    
    //Disable Embedded Data and Stats
    0x3064, 0x1902,     // SMIA_TEST
    0x3064, 0x1802,     // SMIA_TEST
};

void WDR_AUTO_TUNE_FUNC(void){
#if 0
/*
    LONG GAIN : GAIN1, GAIN4 
    MIDDLE GAIN : GAIN3
    SHORT GAIN : GAIN2
*/
    UCHAR tblAGC1[3] = {0x00, 0x40, 0xA0}; 
    UCHAR tblAGC2[3] = {0x00, 0x60, 0xD0};

/*LONG GAIN*/
	UCHAR GAIN_L1[WDR_LEVEL_MAX][3] = {
/* WDR LEVEL 0*/      {0x10, 0x0C, 0x08},
/* WDR LEVEL 1*/      {0x1D, 0x12, 0x08},
/* WDR LEVEL 2*/      {0x2A, 0x19, 0x08},
/* WDR LEVEL 3*/      {0x35, 0x1E, 0x08},

    };

	UCHAR GAIN_L4[WDR_LEVEL_MAX][3] = {
/* WDR LEVEL 0*/      {0x10, 0x0c, 0x08},
/* WDR LEVEL 1*/      {0x18, 0x10, 0x08},
/* WDR LEVEL 2*/      {0x20, 0x14, 0x08},
/* WDR LEVEL 3*/      {0x2A, 0x19, 0x08},
    };    
    
    UCHAR GAIN_M3[3] = {0x20, 0x18, 0x10};
    
    UCHAR GAIN_S2[3] = {0x3A, 0x27, 0x15};         
    BOOL  UseGainStep = (etAGC_MODE)sScr.Category.WDR.Reg.WDR_AGC_MODE;   
    
    if(UseGainStep < 11){
        rBank08.Byte.Reg_0xC811.B8.WDR_GAIN_01 = MW_InterpTbl08(rIP_CURRENT_AGC, &tblAGC1[0], &GAIN_L1[2][0], 3U);  
        rBank08.Byte.Reg_0xC814.B8.WDR_GAIN_04 = MW_InterpTbl08(rIP_CURRENT_AGC, &tblAGC1[0], &GAIN_L4[2][0], 3U);          
        rBank08.Byte.Reg_0xC813.B8.WDR_GAIN_03 = MW_InterpTbl08(rIP_CURRENT_AGC, &tblAGC1[0], &GAIN_M3[0], 3U); 
        rBank08.Byte.Reg_0xC812.B8.WDR_GAIN_02 = MW_InterpTbl08(rIP_CURRENT_AGC, &tblAGC1[0], &GAIN_S2[0], 3U); 

    }
    else
    {
        rBank08.Byte.Reg_0xC811.B8.WDR_GAIN_01 = MW_InterpTbl08(rIP_CURRENT_AGC, &tblAGC2[0], &GAIN_L1[2][0], 3U);  
        rBank08.Byte.Reg_0xC814.B8.WDR_GAIN_04 = MW_InterpTbl08(rIP_CURRENT_AGC, &tblAGC2[0], &GAIN_L4[2][0], 3U);         
        rBank08.Byte.Reg_0xC813.B8.WDR_GAIN_03 = MW_InterpTbl08(rIP_CURRENT_AGC, &tblAGC2[0], &GAIN_M3[0], 3U);         
        rBank08.Byte.Reg_0xC812.B8.WDR_GAIN_02 = MW_InterpTbl08(rIP_CURRENT_AGC, &tblAGC2[0], &GAIN_S2[0], 3U); 
    }   
#endif
    
    if(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER == 13)
    {
        APP_OSDPrint_String(9, 1, (UCHAR*)"SG/LG");
        APP_OSDPrint_Hex(9, 20, (UCHAR)rIP_WDR_GAIN_02);    
        APP_OSDPrint_Hex(9, 23, (UCHAR)rIP_WDR_GAIN_01);   
        APP_OSDPrint_Hex(9, 26, (UCHAR)rIP_WDR_GAIN_04);   
   }    


}

UINT32 WDR_On_Set(void)
{
#if 0
#if (OPTION_WDR_TYPE == WDRTYPE_DCOMP_AR)
    UINT32 Size, i;
    INT32 ret = NC_SUCCESS;

    Size = sizeof(gAR0140AT_WDR_ON_Table)/sizeof(AR0140AT_DATA1);
    for(i = 0; i < Size; i++)
    {
        if(gAR0140AT_WDR_ON_Table[i].Addr == 0xFEF0)
        {
            APACHE_SYS_mDelay(100);       
        }
        else
        {
            DEBUGMSG(MSGINFO, "[W] 0x%04x, 0x%04x\n",  gAR0140AT_WDR_ON_Table[i].Addr, gAR0140AT_WDR_ON_Table[i].Data);
            ret |= ncLib_I2C_Write(I2C_CH0, I2C_DEVICE_ID, gAR0140AT_WDR_ON_Table[i].Addr, gAR0140AT_WDR_ON_Table[i].Data, 1, I2C_ADDR_16_DATA_16);

        }
     }
     return ret;

#elif (OPTION_WDR_TYPE == WDRTYPE_SENSER)
	SENSOR_WDR_On();
	return 0;
#endif
#endif
#if (SENSOR_SELECT == SENSOR_COMMON)
	//SENSOR_Initial_Set();
#else
    ncDrv_SENSOR_Initial_Set();  
#endif
    
}

UINT32 WDR_Off_Set(void)
{
#if 0
#if (OPTION_WDR_TYPE == WDRTYPE_DCOMP_AR)
    UINT32 Size, i;
    INT32 ret = NC_SUCCESS;

    Size = sizeof(gAR0140AT_WDR_OFF_Table)/sizeof(AR0140AT_DATA1);

    for(i = 0; i < Size; i++)
    {
        if(gAR0140AT_WDR_OFF_Table[i].Addr == 0xFEF0)
        {
            APACHE_SYS_mDelay(100);        
        }
        else
        {
            DEBUGMSG(MSGINFO, "[W]0x%04x, 0x%04x, 0x%04x\n", I2C_DEVICE_ID, gAR0140AT_WDR_OFF_Table[i].Addr, gAR0140AT_WDR_OFF_Table[i].Data);
            ret |= ncLib_I2C_Write(I2C_CH0, I2C_DEVICE_ID, gAR0140AT_WDR_OFF_Table[i].Addr, gAR0140AT_WDR_OFF_Table[i].Data, 1, I2C_ADDR_16_DATA_16);
        }
    }
    return ret;    
#elif (OPTION_WDR_TYPE == WDRTYPE_SENSER)
	SENSOR_WDR_Off();
	return 0;
#endif
#endif

#if (SENSOR_SELECT == SENSOR_COMMON)
	//SENSOR_Initial_Set();
#else
    ncDrv_SENSOR_Initial_Set();  
#endif
}

void WDR_AE_Init(void)
{

/* 
 APACHE2.8
*/
    sMwAeWDR.Tracking.Long.TrackingEn = STATE_ON;
    
    /* Long */
    sMwAeWDR.Tracking.Long.SV           = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT];
	sMwAeWDR.Tracking.Long.SVActiveMax  = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT] * SENSOR_VTOTAL_DEFAULT[INPUT_SIZE]/SENSOR_EXPOSURE_MIN;
    sMwAeWDR.Tracking.Long.SVActiveMin  = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT];
 
    sMwAeWDR.Tracking.Long.GV = AE_GAIN_1X; //GAIN_VALUE_MIN;
    sMwAeWDR.Tracking.Step = eWDR_AE_STEP_SHUT;

    sWdr.Ctrl.B8.OpdToggleMode == eWDR_OPD_TOGGLE_OFF;
}

void Debug_Viewer_WDR_AE(void)
{
#if 0
    APP_OSDPrint_String(8, 11, (UCHAR*)"EL");
    APP_OSDPrint_Dec(8, 23, (USHORT)sMwAeWDR.Tracking.Long.ExposureLine);
    APP_OSDPrint_String(12, 11, (UCHAR*)"GV");
    APP_OSDPrint_Dec(12, 23, (USHORT)sMwAeWDR.Tracking.Long.GV);
#endif
    /* Information for customer. */
    APP_OSDPrint_String(2, 1, (UCHAR*)"TY/CY");
  //  APP_OSDPrint_Hex(2, 7, (UCHAR)sMwAe.Tracking.BoundaryStatus | sMwAe.Tracking.TrackingSet);        
    APP_OSDPrint_Hex(2, 10, (UCHAR)sMwAeWDR.Tracking.Long.TargetY);
    APP_OSDPrint_String(2, 12, (UCHAR*)"/");
    APP_OSDPrint_Hex(2, 13, (UCHAR)sMwAeWDR.Tracking.Long.CurrY);

    APP_OSDPrint_String(4, 1, (UCHAR*)"SHUTTER   1/");
    APP_OSDPrint_Dec(4, 13,(USHORT)sMwAeWDR.Tracking.Long.Shutter);    
    APP_OSDPrint_String(5, 1, (UCHAR*)"AGC/RTO");
    APP_OSDPrint_Hex(5, 10, (UCHAR)sMwAe.Agc.Level);
    APP_OSDPrint_String(5, 12, (UCHAR*)"/");
    APP_OSDPrint_Hex(5, 13, (UCHAR)sMwAe.Agc.Ratio); 

    /* Information for developers. */
    APP_OSDPrint_String(11, 1, (UCHAR*)"STEP");
    APP_OSDPrint_Hex(11, 10, sMwAeWDR.Tracking.Step);
    APP_OSDPrint_String(12, 1, (UCHAR*)"TL");
    APP_OSDPrint_Dec(12, 10, (USHORT)sMwAeWDR.Tracking.Long.SVActiveMax);
    APP_OSDPrint_String(13, 1, (UCHAR*)"EL");
    APP_OSDPrint_Dec(13, 10, (USHORT)sMwAeWDR.Tracking.Long.ExposureLine);
    APP_OSDPrint_String(14, 1, (UCHAR*)"TG");
    APP_OSDPrint_Hex2(14, 10, (USHORT)sMwAeWDR.Tracking.Long.GV);
    APP_OSDPrint_String(15, 1, (UCHAR*)"SG");
    APP_OSDPrint_Hex2(15, 10, (USHORT)sMwAeWDR.Tracking.Long.GVCompSG);
    APP_OSDPrint_String(16, 1, (UCHAR*)"LG");
    APP_OSDPrint_Hex2(16, 10, (USHORT)sMwAeWDR.Tracking.Long.GVCompHS);

    //APP_OSDPrint_Hex2(16, 15, (USHORT)GetShort(aIP_ADJ_GAIN_7_0));    
}

void ncDrv_SENSOR_WDR_Exposure_Set(UCHAR WDR_Ch)
{
#define AE_GAIN_1X 0x0080
#define AE_GAIN_2X 0x0100
#define AE_GAIN_4X 0x0200
#define AE_GAIN_8X 0x0400
#define AE_GAIN_16X 0x0800

#define GAIN_VALUE_MIN      AE_GAIN_1X
#define GAIN_VALUE_MAX      AE_GAIN_128X

	USHORT	SensorGain = sMwAeWDR.Tracking.Long.GV;
	USHORT	IspDgainAlpha = GAIN_VALUE_MIN; 		//Sensor ISP Digital Gain(u9.7)
	USHORT	SensorAGain; 
    static USHORT preGVLineCompL;
    
	ULONG rdData1, rdData2, rdData3;
	
//	USHORT ISPGain	   = GAIN_VALUE_MIN;  
	if(sMwAeWDR.Tracking.Long.ExposureLine >= (SENSOR_VTOTAL_DEFAULT[OUTPUT_SIZE]-52)) sMwAeWDR.Tracking.Long.ExposureLine = SENSOR_VTOTAL_DEFAULT[OUTPUT_SIZE]-52;  

	if(sMwAeWDR.Tracking.Long.ExposureLine < 5) sMwAeWDR.Tracking.Long.ExposureLine = 4; 

//=======================================================================================
//	Seonsor Gain
//=======================================================================================
	//DEBUGMSG(MSGWARN, "AE_Gain_Set!\n");

	if (SensorGain >= AE_GAIN_16X) 
	{
		
		SensorGain = 0x0080; //SensorGain>>3;
		SensorAGain = 0x0040;		 // x16
		IspDgainAlpha = sMwAeWDR.Tracking.Long.GV>>4;
	}
	else if (SensorGain >= AE_GAIN_8X)
	{
		SensorGain = SensorGain>>3;  //SensorGain = SensorGain/8;
		SensorAGain = 0x0030;		 // x8
		IspDgainAlpha = GAIN_VALUE_MIN;
	}
	else if (SensorGain >= AE_GAIN_4X)
	{
		SensorGain = SensorGain>>2;
		SensorAGain = 0x0020;		 // x4
		IspDgainAlpha = GAIN_VALUE_MIN;
	}			
	else if (SensorGain >= AE_GAIN_2X)
	{
		SensorGain = SensorGain>>1;
		SensorAGain = 0x0010;		 // x2
		IspDgainAlpha = GAIN_VALUE_MIN;
	}			
	else 
	{
		SensorGain = sMwAeWDR.Tracking.Long.GV;
		SensorAGain = 0x0000;		 // x1
		IspDgainAlpha = GAIN_VALUE_MIN;
	}
    
//=======================================================================================
//      ISP & SENSOR Value Write
//=======================================================================================
	// SENSUP
	
	// SENSOR SHUTTER
	ncLib_I2C_Write(I2C_CH0, I2C_DEVICE_ID, 0x3012, sMwAeWDR.Tracking.Long.ExposureLine, 1, I2C_ADDR_16_DATA_16);
	// SENSOR GAIN
	ncLib_I2C_Write(I2C_CH0, I2C_DEVICE_ID, 0x3060, (SensorAGain|0x0b), 1, I2C_ADDR_16_DATA_16);
	ncLib_I2C_Write(I2C_CH0, I2C_DEVICE_ID, 0x305E, SensorGain, 1, I2C_ADDR_16_DATA_16);	
#if 0
	SENSOR.Write(0x3012, sMwAeWDR.Tracking.Long.ExposureLine);
	SENSOR.Write(0x3060, (SensorAGain|0x0b));      /* APACHE3.5 */
	SENSOR.Write(0x305E, SensorGain);
#endif

//=======================================================================================
    WDR_AE_IspDGainAlphaSet(IspDgainAlpha);      /* APACHE3.5 */   

}
#endif

