/********************************************************************************
*				Copyright (C) 2014 NEXTCHIP Inc. All Rights Reserved.
*********************************************************************************
*	
*	Contents	: Br8051 Init
*	File Path	: \Source\2_Hfile\2_Middleware 
*	File Name 	: MW_Wdr.h 
*	Enviroment	: IAR Imbedded WorkBench6.0 for 8051[8.10]
*	Description	: 
*	
*********************************************************************************
*	History      : 
		CreationDate		Modifier		Ver		Description
		-------------------------------------------------------
		 2015.6.4		    JWLee		    1.0     Newly Generated
*********************************************************************************/

#ifndef __SVC_WDR_H__
#define __SVC_WDR_H__

#include "AELib_Svc.h"

#define WDRTYPE_OFF         0   /* OFF (or NOT Support) */
/*------------------------------------*/
#define WDRTYPE_DFRAME_1M   1   /* ISP WDR */
#define WDRTYPE_DFRAME_2M   2   /* ISP WDR */
/*------------------------------------*/
#define WDRTYPE_DOL2        3   /* SENSOR WDR */
#define WDRTYPE_DOL3        4   /* SENSOR WDR */
#define WDRTYPE_DOL3to2     5   /* SENSOR WDR */
#define WDRTYPE_LWDR2       6   /* SENSOR WDR */
#define WDRTYPE_LWDR3       7   /* SENSOR WDR */
#define WDRTYPE_DCOMP_OV    8   /* SENSOR WDR */
#define WDRTYPE_DCOMP_AR    9   /* SENSOR WDR */
#define WDRTYPE_SENSER      11  /* SENSOR WDR */
#define WDRTYPE_MAX         10


typedef enum{
    eWDRTYPE_OFF        = WDRTYPE_OFF,       /* OFF (or NOT Support) */
/*------------------------------------*/
    eWDRTYPE_DFRAME_1M  = WDRTYPE_DFRAME_1M, /* ISP WDR */
    eWDRTYPE_DFRAME_2M  = WDRTYPE_DFRAME_2M, /* ISP WDR */
/*------------------------------------*/
    eWDRTYPE_DOL2       = WDRTYPE_DOL2,      /* SENSOR WDR */
    eWDRTYPE_DOL3       = WDRTYPE_DOL3,      /* SENSOR WDR */
    eWDRTYPE_DOL3to2    = WDRTYPE_DOL3to2,   /* SENSOR WDR */
    eWDRTYPE_LWDR2      = WDRTYPE_LWDR2,     /* SENSOR WDR */
    eWDRTYPE_LWDR3      = WDRTYPE_LWDR3,     /* SENSOR WDR */
    eWDRTYPE_DCOMP_OV   = WDRTYPE_DCOMP_OV,  /* SENSOR WDR */
    eWDRTYPE_DCOMP_AR   = WDRTYPE_DCOMP_AR,  /* SENSOR WDR */
    eWDRTYPE_MAX        = WDRTYPE_MAX,
}etWDR_TYPE_TYPE;

typedef enum{
    DFWDR_LONG = 0,
    DFWDR_SHORT
}etWDR_MODE_SW;

typedef enum{
    eWDR_OPD_TOGGLE_ON = 0,
    eWDR_OPD_TOGGLE_OFF,
}etWDR_OPD_SWITCH_TYPE;

typedef enum{
    eWDR_OPD_SHORT = 0,
    eWDR_OPD_MIDDLE,
}etWDR_OPD_SEL_TYPE;

typedef enum{
	eWDR_AE_STEP_SHUT = 0,
	eWDR_AE_STEP_GAIN,
}etWDR_AE_TRACKING_STEP;

typedef enum{
	eWDR_AWB_STOP = 0,
	eWDR_AWB_RUN,
}etWDR_AWB_STEP;

typedef struct
{
    BOOL Mode;                  /* WDR MODE : ON/OFF */
    etWDR_TYPE_TYPE Type;
    union
    {
        UCHAR D8;
        struct
        {
            etWDR_OPD_SWITCH_TYPE   OpdToggleMode:  1;  //Switching MIDDLE/SHORT OPD data every single VD
            etWDR_OPD_SEL_TYPE      OpdSel:         1;  //Current OPD Block Data
            BOOL                    TransitState:   1;  //WDR OFF->ON status
            UCHAR                   Reserved:       5;
        }B8;
    }Ctrl;
}STRUCT_WDR_TYPE;
extern STRUCT_WDR_TYPE sWdr;

typedef struct
{
    USHORT	GVTotal;            /* IspDGainLineComp x IspDGainTotal */
	USHORT	GVCompHS;           /* Compensation gain for Line Count */
	USHORT	GVCompSG;	        /* Compensation gain for Senser Gain */
}dtAE_ISP_GAIN_TYPE;

typedef struct
{
	BOOL	TrackingEn;         /* Tracking condition */
	UCHAR	CurrY;              /* Current Brightness */
	UCHAR	TargetY;            /* Target Brightness */
    UCHAR   Bright;             /* Current Brightness Level (Extern) */

	/*__________ Shutter Value ___________________________*/
	UCHAR	SVSpeed;            /* SV Tracking Speed */    
	ULONG   SV;				    /* Main Shutter Value (Frame count per sec * 4sec * 256) */
	ULONG   SVActiveMin;        /* SV Active Range Min */
	ULONG   SVActiveMax;        /* SV Active Range Max */

	/*____________ Gain Value ___________________________*/
	UCHAR	GVSpeed;             /* SV Tracking Speed */    
	GAIN_VALUE_TYPE	GV;			 /* Main Gain Value(128 = x1, 16384 = x128), (Dgain + Again) */
	GAIN_VALUE_TYPE	GVActiveMin; /* GAIN lower limit : Default=x1(128) */
	GAIN_VALUE_TYPE	GVActiveMax; /* GAIN upper limit : depand on AGC MODE */

	/*__________ ISP Value _____________________________*/
    USHORT	GVTotal;            /* IspDGainLineComp x IspDGainTotal */
	USHORT	GVCompHS;           /* Compensation gain for Line Gap (High Shutter) */
	USHORT	GVCompSG;	        /* Compensation gain for Senser Gain */

    USHORT  Shutter;             /* Shutter Speed = SV/1024 (reference) */
    USHORT  GainLineComp;
    USHORT  ExposureLine;
}dtWDR_AE_INFO_TYPE;

typedef struct
{
    etWDR_AE_TRACKING_STEP  Step;
    dtWDR_AE_INFO_TYPE  Long;
    dtWDR_AE_INFO_TYPE  Middle;
    dtWDR_AE_INFO_TYPE  Short;
}dtAE_TRACKING_WDR_TYPE;

typedef struct
{	
	/*__________ Tracking Variables ____________________*/
	dtAE_TRACKING_WDR_TYPE  Tracking;

	/*__________ AGC References ________________________*/
	dtAE_AGC_VALUE_TYPE Agc;

}STRUCT_MW_AE_WDR;
extern STRUCT_MW_AE_WDR		sMwAeWDR;


typedef enum{
    eIN_AGC = 0,
    eIN_LONG_Y,
    eIN_MIDDLE_Y,
    eIN_SHORT_Y,
    eIN_LONG_EXP_LINE,
    eIN_MIDDLE_EXP_LINE,
    eIN_SHORT_EXP_LINE,
    eIN_RESERVED_01,
    eIN_RESERVED_02,
    eIN_RESERVED_03,
    eIN_RESERVED_04,
    eIN_RESERVED_05,
    eIN_RESERVED_06,
    eIN_RESERVED_07,
    eIN_RESERVED_08,        
    eIN_MAX,
}etWDR_IN_TYPE;

typedef enum{
    eOUT_GIAN_00 = 0,
    eOUT_GIAN_01,
    eOUT_GIAN_02,
    eOUT_GIAN_03,
    eOUT_GIAN_04,
    eOUT_GIAN_05,
    eOUT_GIAN_06,
    eOUT_GIAN_07,
    eOUT_MAX,
}etWDR_OUT_TYPE;

typedef enum{
    eGRPH_00 = 0,
    eGRPH_01, 
    eGRPH_02,
    eGRPH_03, 
    eGRPH_04,
    eGRPH_MAX,
}etWDR_GRPH_TYPE;

extern void ncSvc_WDR_Mode_Set(UCHAR WDRMode);
extern void ncSvc_WDR_AE_AGC_Set(void);
extern void ncSvc_WDR_CLKPath_Set(void);
extern void ncSvc_WDR_DFrame_Set(void);
extern void ncSvc_WDR_Task(void);
extern void ncSvc_WDR_Set(void);


#endif  // __SVC_WDR__


