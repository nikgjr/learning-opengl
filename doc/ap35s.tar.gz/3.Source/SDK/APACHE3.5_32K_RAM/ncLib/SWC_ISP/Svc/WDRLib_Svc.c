/********************************************************************************
*				Copyright (C) 2014 NEXTCHIP Inc. All Rights Reserved.
*********************************************************************************
*	
*	Contents	: Br8051 Init
*	File Path	: \Source\3_Cfile\2_Middleware 
*	File Name 	: MW_Wdr.c 
*	Enviroment	: IAR Imbedded WorkBench6.0 for 8051[8.10]
*	Description	: 
*	
*********************************************************************************
*	History      : 
		CreationDate		Modifier		Ver		Description
		-------------------------------------------------------
		 2015.6.4		    JWLee		    1.0     Newly Generated
*********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Drv_GlobalHeader.h"
#include "ISP_Drv.h"

#include "Sensor_Default_Drv.h"
#include "System_Drv.h"
STRUCT_MW_AE_WDR		sMwAeWDR;
STRUCT_WDR_TYPE sWdr;

#if(OPTION_WDR_TYPE == WDRTYPE_OFF)
void Debug_Viewer_WDR_AE(void){}
void ncSvc_WDR_DFrame_Set(void){}
void ncSvc_WDR_AE_AGC_Set(void){}
void ncSvc_WDR_Mode_Set(UCHAR WDRMode){  rSWReg.Category.WDR.Reg.WDR_MODE = STATE_OFF; }
void ncSvc_WDR_Task(void){}
void ncSvc_WDR_Init(void){}
#else
extern void ncDrv_SENSOR_Initial_Set(void);
extern void AE_ConvertGVtoAgcLevel(USHORT ExpGValue);
/*--------------------------------------------------------------------------------
/   Function of specific sensors
---------------------------------------------------------------------------------*/
extern void WDR_AE_Init(void);
extern void WDR_AUTO_TUNE_FUNC(void);
extern void WDR_On_Set(void);
extern void WDR_Off_Set(void);
extern void WDR_Register_Set(void);
/*--------------------------------------------------------------------------------
/  Common Functions
---------------------------------------------------------------------------------*/

enum{
    DIR_NORMAL = 0,
    DIR_INVERSE,
};

enum{
    WDR_TARGETMODE_AUTO = 0,
    WDR_TARGETMODE_MANUAL,
    WDR_TARGETMODE_TEST1,
};

void WDR_AE_Y_Avg(void);
void WDR_AE_Targeting(void);
void WDR_AE_Tracking(void);
void WDR_Type_Set(void);
void ncSvc_WDR_DFrame_Set(void);
void WDR_AE_IspDGainAlphaSet(USHORT IspDigitalGain);
void WDR_AE_SetIspDigitalGain(void);

/*-------------------------------------------------------------------------------*/


ULONG WDR_AE_TrackingValueCalculate(etWDR_AE_TRACKING_STEP Step, dtWDR_AE_INFO_TYPE *pTrack, UCHAR Dir)
{
    UCHAR   Speed;
    ULONG   CurrVal;
    ULONG   CalMin, CalMax;
    ULONG   CalcValue;
    FLOAT   DiffYRatio;
    FLOAT   DiffYRatioCal;
    FLOAT   AlphaValue;
    
    /* _____________________ PREPARE TO CALCULATE ___________________ */
    if(Step == eWDR_AE_STEP_GAIN)
    {
        CurrVal = pTrack->GV;
        CalMin = pTrack->GVActiveMin;
        CalMax = pTrack->GVActiveMax;
        Speed = pTrack->GVSpeed;
    }
    else
    {
        CurrVal = pTrack->SV;
        CalMin = pTrack->SVActiveMin;
        CalMax = pTrack->SVActiveMax;
        Speed = pTrack->SVSpeed;
    }

    if(Speed == 0)  return CurrVal;
    
    if(Dir == DIR_NORMAL)   DiffYRatio = (FLOAT)pTrack->CurrY/(FLOAT)pTrack->TargetY;
    else                    DiffYRatio = (FLOAT)pTrack->TargetY/(FLOAT)pTrack->CurrY;

    /* _____________________ CALCULATE ALPHA _______________________ */
    
    if (DiffYRatio > 1) DiffYRatioCal = DiffYRatio - 1;
    else                DiffYRatioCal = 1 - DiffYRatio;

    AlphaValue = (DiffYRatioCal * Speed) / 1024.0;

    if (DiffYRatio > 1) AlphaValue = AlphaValue + 1;
    else                AlphaValue = 1 - (AlphaValue * 4.0);

    /* _____________________ CALCULATE FINAL VALUE _________________ */
    
    CalcValue = (ULONG)(CurrVal * AlphaValue);

    if (CalcValue > CalMax)     CalcValue = CalMax;
    if (CalcValue < CalMin)     CalcValue = CalMin;

    return CalcValue;
 
}

void WDR_AE_Y_Avg(void)
{
#define ACC_CNT 10

    static BUFFER_AVERAGE_TYPE YBuff={0};
    static BUFFER_AVERAGE_TYPE YBuffM={0};
    static BUFFER_AVERAGE_TYPE YBuffS={0};


    static UCHAR preWDR_TARGET_MODE = 0xAA;

    if(preWDR_TARGET_MODE != rSWReg.Category.WDR.Reg.WDR_TARGET_MODE)
    {
        YBuff.BuffCntInit = 0;
        YBuff.BuffIdx = 0;
        YBuff.AccValue = 0;

        YBuff.BuffCntInit = 0;
        YBuff.BuffIdx = 0;
        YBuff.AccValue = 0;

        YBuffS.BuffCntInit = 0;
        YBuffS.BuffIdx = 0;
        YBuffS.AccValue = 0;

        preWDR_TARGET_MODE = rSWReg.Category.WDR.Reg.WDR_TARGET_MODE 
                            + rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_M
                            + rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S;    
    }

    if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE == WDR_TARGETMODE_AUTO)
        sMwAeWDR.Tracking.Long.CurrY = ncDrv_BufferAvg_Get(&YBuff, ACC_CNT, sMwOpd.Histogram.WeightY);
    else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE == WDR_TARGETMODE_MANUAL)
        sMwAeWDR.Tracking.Long.CurrY = ncDrv_BufferAvg_Get(&YBuff, ACC_CNT, sMwOpd.Data.AvgY);
    else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE == WDR_TARGETMODE_TEST1)
        sMwAeWDR.Tracking.Long.CurrY = ncDrv_BufferAvg_Get(&YBuff, ACC_CNT, sMwOpd.Data.WeightedY);
    else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE == 3)
        sMwAeWDR.Tracking.Long.CurrY = ncDrv_BufferAvg_Get(&YBuff, ACC_CNT, sMwOpd.Data.AvgY);
        
    if(sWdr.Ctrl.B8.OpdToggleMode == eWDR_OPD_TOGGLE_ON)
    {
        if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_MIDDLE)
        {
            sMwAeWDR.Tracking.Middle.CurrY = ncDrv_BufferAvg_Get(&YBuffM, ACC_CNT, rIP_OPD_Y_BLOCK_AVG_M);
        }
        else if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_SHORT)
        {
            if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_AUTO)
                sMwAeWDR.Tracking.Short.CurrY = ncDrv_BufferAvg_Get(&YBuffS, ACC_CNT, sMwOpd.HistogramS.WeightY);
            else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_MANUAL)
                sMwAeWDR.Tracking.Short.CurrY = ncDrv_BufferAvg_Get(&YBuffS, ACC_CNT, sMwOpd.DataS.AvgY);
            else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_TEST1)
                sMwAeWDR.Tracking.Short.CurrY = ncDrv_BufferAvg_Get(&YBuffS, ACC_CNT, sMwOpd.HistogramS.WeightY);
        }
    }
    else
    {
        sMwAeWDR.Tracking.Middle.CurrY = ncDrv_BufferAvg_Get(&YBuffM, ACC_CNT, rIP_OPD_Y_BLOCK_AVG_M);

        if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_AUTO)
            sMwAeWDR.Tracking.Short.CurrY  = ncDrv_BufferAvg_Get(&YBuffS, ACC_CNT, sMwOpd.HistogramS.WeightY);
        else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_MANUAL)
            sMwAeWDR.Tracking.Short.CurrY  = ncDrv_BufferAvg_Get(&YBuffS, ACC_CNT, sMwOpd.DataS.AvgY);
        else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_TEST1)
            sMwAeWDR.Tracking.Short.CurrY  = ncDrv_BufferAvg_Get(&YBuffS, ACC_CNT, sMwOpd.HistogramS.WeightY);
    }
}

void WDR_AE_Targeting(void)
{
    UCHAR OpdY = rIP_OPD_Y_BLOCK_AVG_L;
    UCHAR DiffYM = _abs(sMwOpd.DataS.AvgY, sMwOpd.Data.AvgY);
    USHORT OffsetM = (DiffYM * rSWReg.Category.WDR.Reg.WDR_TARGET_M_RATIO)/100;
    UCHAR TargetM = sMwOpd.DataS.AvgY + (UCHAR)OffsetM;

    if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE == WDR_TARGETMODE_AUTO)            sMwAeWDR.Tracking.Long.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET;
    else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE == WDR_TARGETMODE_MANUAL)     sMwAeWDR.Tracking.Long.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET;
    else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE == WDR_TARGETMODE_TEST1)      sMwAeWDR.Tracking.Long.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET;
    
    if(sWdr.Ctrl.B8.OpdToggleMode == eWDR_OPD_TOGGLE_ON)
    {
        if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_MIDDLE)
        {
            if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_M == WDR_TARGETMODE_AUTO)          sMwAeWDR.Tracking.Middle.TargetY = TargetM;
            else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_M == WDR_TARGETMODE_MANUAL)   sMwAeWDR.Tracking.Middle.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET_M;
            else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_M == WDR_TARGETMODE_TEST1)    sMwAeWDR.Tracking.Middle.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET_M;
        }

        if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_SHORT)
        {
            if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_AUTO)          sMwAeWDR.Tracking.Short.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET_S;
            else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_MANUAL)   sMwAeWDR.Tracking.Short.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET_S;
            else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_TEST1)    sMwAeWDR.Tracking.Short.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET_S;
        }
    }
    else
    {
        if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_M == WDR_TARGETMODE_AUTO)              sMwAeWDR.Tracking.Middle.TargetY = TargetM;
        else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_M == WDR_TARGETMODE_MANUAL)       sMwAeWDR.Tracking.Middle.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET_M;
        else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_M == WDR_TARGETMODE_TEST1)        sMwAeWDR.Tracking.Middle.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET_M;

        if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_AUTO)          	   sMwAeWDR.Tracking.Short.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET_S;
        else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_MANUAL)       sMwAeWDR.Tracking.Short.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET_S;
        else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_TEST1)        sMwAeWDR.Tracking.Short.TargetY = rSWReg.Category.WDR.Reg.WDR_TARGET_S;
    }
}

void WDR_AE_Tracking(void)
{
#define WDR_IN_LEVEL 4

    UCHAR DiffY;
    UCHAR CurrY = sMwAeWDR.Tracking.Long.CurrY;
    UCHAR TargetY = sMwAeWDR.Tracking.Long.TargetY;
    BOOL  UseGainStep = (etAGC_MODE)rSWReg.Category.WDR.Reg.WDR_AGC_MODE;


    DiffY = _abs(sMwAeWDR.Tracking.Long.CurrY, sMwAeWDR.Tracking.Long.TargetY);
    if(DiffY == 0)          sMwAeWDR.Tracking.Long.TrackingEn = STATE_OFF;
    else if(DiffY >= 3)     sMwAeWDR.Tracking.Long.TrackingEn = STATE_ON;

    DiffY = _abs(sMwAeWDR.Tracking.Middle.CurrY, sMwAeWDR.Tracking.Middle.TargetY);
    if(DiffY == 0)          sMwAeWDR.Tracking.Middle.TrackingEn = STATE_OFF;
    else if(DiffY >= 2)     sMwAeWDR.Tracking.Middle.TrackingEn = STATE_ON;

    DiffY = _abs(sMwAeWDR.Tracking.Short.CurrY, sMwAeWDR.Tracking.Short.TargetY);
    if(DiffY == 0)          sMwAeWDR.Tracking.Short.TrackingEn = STATE_OFF;
    else if(DiffY >= 2)     sMwAeWDR.Tracking.Short.TrackingEn = STATE_ON;

    sMwAeWDR.Tracking.Long.SVSpeed = rSWReg.Category.WDR.Reg.WDR_SPEED;
    sMwAeWDR.Tracking.Middle.SVSpeed = rSWReg.Category.WDR.Reg.WDR_SPEED_M;
    sMwAeWDR.Tracking.Short.SVSpeed = rSWReg.Category.WDR.Reg.WDR_SPEED_S;
    sMwAeWDR.Tracking.Long.GVSpeed = rSWReg.Category.WDR.Reg.WDR_SPEED_AGC;

    switch(sMwAeWDR.Tracking.Step)
    {
        case eWDR_AE_STEP_SHUT:
            if(sMwAeWDR.Tracking.Long.TrackingEn == STATE_ON)
            {
                if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE == WDR_TARGETMODE_AUTO)
                    sMwAeWDR.Tracking.Long.SV = WDR_AE_TrackingValueCalculate(sMwAeWDR.Tracking.Step, &sMwAeWDR.Tracking.Long, DIR_NORMAL);
                else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE == WDR_TARGETMODE_MANUAL)
                    sMwAeWDR.Tracking.Long.SV = WDR_AE_TrackingValueCalculate(sMwAeWDR.Tracking.Step, &sMwAeWDR.Tracking.Long, DIR_NORMAL);
                else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE == WDR_TARGETMODE_TEST1)
                    sMwAeWDR.Tracking.Long.SV = WDR_AE_TrackingValueCalculate(sMwAeWDR.Tracking.Step, &sMwAeWDR.Tracking.Long, DIR_NORMAL);
                else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE == 3)
                    sMwAeWDR.Tracking.Long.SV = WDR_AE_TrackingValueCalculate(sMwAeWDR.Tracking.Step, &sMwAeWDR.Tracking.Long, DIR_NORMAL);
            }

            if((UseGainStep)&&(sMwAeWDR.Tracking.Long.SV <= sMwAeWDR.Tracking.Long.SVActiveMin) && (CurrY < TargetY))
                sMwAeWDR.Tracking.Step = eWDR_AE_STEP_GAIN;
            break;
            
        case eWDR_AE_STEP_GAIN:
            if(UseGainStep)
            {
                sMwAeWDR.Tracking.Long.GV = (GAIN_VALUE_TYPE)WDR_AE_TrackingValueCalculate(eWDR_AE_STEP_GAIN, &sMwAeWDR.Tracking.Long, DIR_INVERSE);
   
                if((sMwAeWDR.Tracking.Long.GV <= GAIN_VALUE_MIN) && (CurrY > TargetY))
                    sMwAeWDR.Tracking.Step = eWDR_AE_STEP_SHUT;
            }
            else
            {
                sMwAeWDR.Tracking.Long.GV = GAIN_VALUE_MIN;
                sMwAeWDR.Tracking.Step = eWDR_AE_STEP_SHUT;
            }
            break;
    }

    if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_MIDDLE)
    {
        if(sMwAeWDR.Tracking.Middle.TrackingEn)
        {
            if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_M == WDR_TARGETMODE_AUTO)
                sMwAeWDR.Tracking.Middle.SV = WDR_AE_TrackingValueCalculate(eWDR_AE_STEP_SHUT, &sMwAeWDR.Tracking.Middle, DIR_NORMAL);
            else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_M == WDR_TARGETMODE_MANUAL)                
                sMwAeWDR.Tracking.Middle.SV = WDR_AE_TrackingValueCalculate(eWDR_AE_STEP_SHUT, &sMwAeWDR.Tracking.Middle, DIR_NORMAL);
            else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_M == WDR_TARGETMODE_TEST1)
                sMwAeWDR.Tracking.Middle.SV = sMwAeWDR.Tracking.Short.SV / rSWReg.Category.WDR.Reg.WDR_TARGET_M_RATIO;
        }                
    }

    if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_SHORT)
    {
        if(sMwAeWDR.Tracking.Short.TrackingEn == STATE_ON)
        {
            if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_AUTO)
                sMwAeWDR.Tracking.Short.SV = WDR_AE_TrackingValueCalculate(eWDR_AE_STEP_SHUT, &sMwAeWDR.Tracking.Short, DIR_NORMAL);
            else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_MANUAL)
                sMwAeWDR.Tracking.Short.SV = WDR_AE_TrackingValueCalculate(eWDR_AE_STEP_SHUT, &sMwAeWDR.Tracking.Short, DIR_NORMAL);    
            else if(rSWReg.Category.WDR.Reg.WDR_TARGET_MODE_S == WDR_TARGETMODE_TEST1)
                sMwAeWDR.Tracking.Short.SV = WDR_AE_TrackingValueCalculate(eWDR_AE_STEP_SHUT, &sMwAeWDR.Tracking.Short, DIR_NORMAL);
        }
    }

}
void WDR_AE_IspDGainAlphaSet(USHORT IspDigitalGain)
{
    static USHORT GVCompSGBuf;

    if(IspDigitalGain < GAIN_VALUE_MIN) IspDigitalGain = GAIN_VALUE_MIN;

    sMwAeWDR.Tracking.Long.GVCompSG = GVCompSGBuf;

    GVCompSGBuf = IspDigitalGain;

}

void WDR_AE_SetIspDigitalGain(void)
{
    static USHORT GVCompHSBuf;      //1VD Dealy buffer
//=======================================================================================
//  ISP Digital Gain * Sensor Digital gain(ISP)
//=======================================================================================
    sMwAeWDR.Tracking.Long.GVTotal = (USHORT)(((ULONG)(sMwAeWDR.Tracking.Long.GVCompSG) * (ULONG)(GVCompHSBuf)) >> 7);
//    sMwAe.Isp.GVTotal = (USHORT)(((ULONG)(sMwAe.Isp.GVCompSG) * (ULONG)(GVCompHSBuf)) >> 7);

//=======================================================================================
//  ISP Digital gain Set
//=======================================================================================

#if(SENSOR_SELECT == OMNIVISION_OV10640 && OPTION_WDR_TYPE == WDRTYPE_DCOMP_OV)
    if(sWdr.Mode)
    {
    	rIP_ADJ_GAIN_14_8 = 0x00;
    	rIP_ADJ_GAIN_7_0 = 0x80;
    }
    else
    {

        rIP_ADJ_GAIN_14_8 = ((sMwAeWDR.Tracking.Long.GVTotal>>8) & 0x7F);
        rIP_ADJ_GAIN_7_0 = (sMwAeWDR.Tracking.Long.GVTotal & 0xFF);
    }
#else
    rIP_ADJ_GAIN_14_8 = ((sMwAeWDR.Tracking.Long.GVTotal>>8) & 0x7F);
    rIP_ADJ_GAIN_7_0 = (sMwAeWDR.Tracking.Long.GVTotal & 0xFF);
  
#endif   
    GVCompHSBuf = sMwAeWDR.Tracking.Long.GVCompHS;

}

void WDR_AE_Converting(void)
{
    UCHAR idx;
    ULONG LineEx;
    ULONG FlkShutter;
    ULONG SVTotalMax;
    ULONG SVTotalMin;
    USHORT GVLineComp;
    
    if(sWdr.Type == eWDRTYPE_DOL3)      /* 15frame WDR */
    {
        SVTotalMax = (LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT]) * (SENSOR_VTOTAL_DEFAULT[OUTPUT_SIZE]*4);        /* 30->15FPS*/
        SVTotalMin = (LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT]);
    }
    else
    {
#if(SENSOR_SELECT == OMNIVISION_OV10640 && OPTION_WDR_TYPE == WDRTYPE_DCOMP_OV)
    if(sWdr.Mode)
    	SVTotalMax = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT] * WDR_SENSOR_VTOTAL_DEFAULT[OUTPUT_SIZE];		 /* 30->15FPS*/
    else
#endif
		SVTotalMax = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT] * SENSOR_VTOTAL_DEFAULT[OUTPUT_SIZE];		 /* 30->15FPS*/
        SVTotalMin = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT];
    }
        
    if((sMwAeWDR.Tracking.Long.SV >= SVTotalMin) && (rSWReg.Category.WDR.Reg.WDR_AE_SHUT_MODE == eSHUT_MODE_FLK))
    {
        for (idx = 0; idx <= e30P_MANUAL_FLK; idx++)
        {
            FlkShutter = (SVTotalMin << idx);
            if (FlkShutter >= sMwAeWDR.Tracking.Long.SV)
                break;
            else
                FlkShutter = sMwAeWDR.Tracking.Long.SV;
        }
        sMwAeWDR.Tracking.Long.ExposureLine = (USHORT)(SVTotalMax / FlkShutter);
        sMwAeWDR.Tracking.Long.Shutter = FlkShutter>>10;
    }
    else
    {
        sMwAeWDR.Tracking.Long.ExposureLine = (USHORT)(SVTotalMax / sMwAeWDR.Tracking.Long.SV);
        sMwAeWDR.Tracking.Long.Shutter = sMwAeWDR.Tracking.Long.SV>>10;
    }

    sMwAeWDR.Tracking.Short.ExposureLine = (USHORT)(SVTotalMax / sMwAeWDR.Tracking.Short.SV);
    sMwAeWDR.Tracking.Short.Shutter = sMwAeWDR.Tracking.Short.SV>>10;

    sMwAeWDR.Tracking.Middle.ExposureLine = (USHORT)(SVTotalMax / sMwAeWDR.Tracking.Middle.SV);
    sMwAeWDR.Tracking.Middle.Shutter = sMwAeWDR.Tracking.Middle.SV>>10;

    /* LONG GAIN between line and line */
    LineEx = (ULONG)(SVTotalMax / sMwAeWDR.Tracking.Long.ExposureLine);
#if(SENSOR_SELECT == OMNIVISION_OV10640 && OPTION_WDR_TYPE == WDRTYPE_DCOMP_OV)
    if(sWdr.Mode)
    GVLineComp = (USHORT)(LineEx/(sMwAeWDR.Tracking.Long.SV>>8));
    else
#endif
    GVLineComp = (USHORT)(LineEx/(sMwAeWDR.Tracking.Long.SV>>7));
    sMwAeWDR.Tracking.Long.GVCompHS = (GVLineComp < GAIN_VALUE_MIN) ? (GAIN_VALUE_MIN) : (GVLineComp);

    /* MIDDLE GAIN between line and line */
    LineEx = (ULONG)(SVTotalMax / sMwAeWDR.Tracking.Middle.ExposureLine);
    GVLineComp = (USHORT)(LineEx/(sMwAeWDR.Tracking.Middle.SV>>7));
    sMwAeWDR.Tracking.Long.GVCompHS = (GVLineComp < GAIN_VALUE_MIN) ? (GAIN_VALUE_MIN) : (GVLineComp);
    
    /* SHORT GAIN between line and line */
    LineEx = (ULONG)(SVTotalMax / sMwAeWDR.Tracking.Short.ExposureLine);
    GVLineComp = (USHORT)(LineEx/(sMwAeWDR.Tracking.Short.SV>>7));
    sMwAeWDR.Tracking.Long.GVCompHS = (GVLineComp < GAIN_VALUE_MIN) ? (GAIN_VALUE_MIN) : (GVLineComp);

    AE_ConvertGVtoAgcLevel(sMwAeWDR.Tracking.Long.GV);
    
}

void WDR_AE_Task(void)
{

    WDR_AE_Y_Avg();
    WDR_AE_Targeting();
    WDR_AE_Tracking();
    WDR_AE_Converting();
   
    if(sWdr.Type > eWDRTYPE_DFRAME_2M)  
    {
#if (SENSOR_SELECT == SENSOR_COMMON)
#else
        ncDrv_SENSOR_WDR_Exposure_Set(rIP_WDR_DEFINED_IMG);    
#endif
    }
    WDR_AE_SetIspDigitalGain();
}



void WDR_Type_Set(void)
{
    rIP_O_OSD_CLR_EN = STATE_ON;
    
    ncLib_DEBUG_Printf(1, "WDR : ");

    switch(sWdr.Type)
    {
        case eWDRTYPE_DFRAME_1M:
        case eWDRTYPE_DFRAME_2M:    ncLib_DEBUG_Printf(1, "DFRAME\n");
        
            sWdr.Ctrl.B8.TransitState = STATE_ON;            
            sWdr.Ctrl.B8.OpdToggleMode = eWDR_OPD_TOGGLE_OFF;
            rIP_OPD_DOL_SEL = eWDR_OPD_SHORT;
            
            break;
            
        case eWDRTYPE_DOL2:         ncLib_DEBUG_Printf(1, "DOL2\n");
        
            rIP_WDR_EN = 1;
            rIP_WDR_DOL_MODE = 1;
            rIP_WDR_DOL_EN = 0;
            rIP_WDR_ACE_SEL = 1;
    	
        	WDR_On_Set();
            break;

        case eWDRTYPE_DOL3:         ncLib_DEBUG_Printf(1, "DOL3\n");      
            sWdr.Ctrl.B8.OpdToggleMode = eWDR_OPD_TOGGLE_ON;
            WDR_On_Set();
            break;

        case eWDRTYPE_LWDR2:        ncLib_DEBUG_Printf(1, "LWDR2\n");
#if (SENSOR_SELECT == SENSOR_COMMON)
			//SENSOR_Initial_Set();
#else
		    ncDrv_SENSOR_Initial_Set();  
#endif
            rIP_WDR_EN = 1;
            rIP_WDR_DOL_MODE = 1;
            rIP_WDR_DOL_EN = 1;
            rIP_WDR_ACE_SEL = 1;
			
			rIP_IIF_LWDR_CH_SEQ = 0x00;
			rIP_IIF_LWDR_EN = 1;
			rIP_IIF_LWDR_CH = 1;
				
            break;

        case eWDRTYPE_LWDR3:        ncLib_DEBUG_Printf(1, "WDR LWDR3\n");
            
            rIP_H_SWAP_GL = STATE_ON;
            rIP_V_SWAP_GL = STATE_ON;
            
#if (SENSOR_SELECT == SENSOR_COMMON)
			//SENSOR_Initial_Set();
#else
		    ncDrv_SENSOR_Initial_Set();  
#endif
			ncDrv_MONITOR_SENSOR_Type_Set(&sGco.OutputSize);
            
			rIP_WDR_EN = 1;
            rIP_WDR_DOL_MODE = 1;
            rIP_WDR_DOL_EN = 1;
            rIP_WDR_ACE_SEL = 1;

            rIP_IIF_LWDR_CH_SEQ = 0x00;
			rIP_IIF_LWDR_EN = 1;
			rIP_IIF_LWDR_CH = 1;
			
            break;

        case eWDRTYPE_DCOMP_OV:     ncLib_DEBUG_Printf(1, "DCOMP OV\n");
	            
            rIP_H_SWAP_GL = STATE_OFF;
            rIP_V_SWAP_GL = STATE_OFF; 
#if (SENSOR_SELECT == SENSOR_COMMON)
			//SENSOR_Initial_Set();
#else
		    ncDrv_SENSOR_Initial_Set();  
#endif            
			ncDrv_MONITOR_SENSOR_Type_Set(&sGco.OutputSize);
			rIP_WDR_EN = 1;
            rIP_WDR_DOL_MODE = 0;
            rIP_WDR_DOL_EN = 0;
            rIP_WDR_ACE_SEL = 1;

            rIP_IIF_LWDR_CH_SEQ = 0x00;
			rIP_IIF_LWDR_EN = 0;
			rIP_IIF_LWDR_CH = 0;
            break;

        case eWDRTYPE_DCOMP_AR:  ncLib_DEBUG_Printf(1, "DCOMP AR\n");
		
		    rIP_H_SWAP_GL = STATE_OFF;
            rIP_V_SWAP_GL = STATE_OFF; 
			WDR_On_Set();
			
			//ncDrv_MONITOR_SENSOR_Type_Set(&sGco.OutputSize);
			rIP_WDR_EN = 1;
			rIP_WDR_DOL_MODE = 0;
            rIP_WDR_DOL_EN = 0;
			rIP_WDR_ACE_SEL = 1;
			
            rIP_IIF_LWDR_CH_SEQ = 0x00;
			rIP_IIF_LWDR_EN = 0;
			rIP_IIF_LWDR_CH = 0;
            break;
            
        case eWDRTYPE_OFF:            
        default:                ncLib_DEBUG_Printf(1, "OFF\n");
            rIP_WDR_EN = 0;
            WDR_Off_Set();
            break;
    }

/*
    ncDrv_OutputFormat_Set();

    MONITOR_INPUT_HTOTAL_Set();
    ncDrv_DDRMemory_Address_Set();    
    if(sWdr.Mode == STATE_OFF)   ncSvc_AE_Init();
    else                         WDR_AE_Init();   

    ncSvc_WDR_AE_AGC_Set();
    ncSvc_WDR_Set();
    ncSvc_WB_INIT();
    ncDrv_BlackLevelCompensation_Set();
    ncDrv_Gamma_Set(); // GAMMA Commands
    ncDrv_Sharpness_Set(); // SHARPNESS Commands   
    ncDrv_Chroma_C_Hue_Set(); // CHROMA Commands
*/
}

void ncSvc_WDR_DFrame_Set(void)
{
typedef enum{
    TRANSIT_STEP1 = 0,
    TRANSIT_STEP2,
    TRANSIT_STEP3,
    TRANSIT_STEP4,
    TRANSIT_STEP5,
    TRANSIT_STEP6,
    TRANSIT_STEP7,
    TRANSIT_STEP_MAX
}etWDR_TRANSIT_STEP;

    static etWDR_TRANSIT_STEP TransitStep = TRANSIT_STEP_MAX;
    static UCHAR preTransitState = 0xAA;

    if(!IsInRage(sWdr.Type, eWDRTYPE_DFRAME_1M, eWDRTYPE_DFRAME_2M))    return;

    if(sWdr.Ctrl.B8.TransitState == STATE_OFF)
    {
        if(sMwSystem.Control.Run.AE)
        {
#if (SENSOR_SELECT == SENSOR_COMMON)
#else
            ncDrv_SENSOR_WDR_Exposure_Set(rIP_WDR_DEFINED_IMG);    
#endif
        }
    }
    else
    {
        if(preTransitState != STATE_ON)    TransitStep = TRANSIT_STEP1;

        switch(TransitStep)
        {
            case TRANSIT_STEP1:
                TransitStep = TRANSIT_STEP2;
                ncDrv_DDRMemory_Address_Set();
                rIP_WDR_ACE_SEL = 1;
                rIP_WDR_EN = 1;
                //rBank1A.Byte.Reg_0xDA00.B8.OF_YLEVEL_SCALE = 0x00;
                break;
                
            case TRANSIT_STEP2:
                TransitStep = TRANSIT_STEP3;        
                rIP_WDR_DEFINE_IMG = 0x02;   // Long
                rIP_WDR_AUTO_IMG_SEL = 1;
                break;
                
            case TRANSIT_STEP3:
                rIP_WDR_DEFINE_IMG = 0x00;   //
                TransitStep = TRANSIT_STEP4;        
                break;
                
            case TRANSIT_STEP4:
                TransitStep = TRANSIT_STEP5;
                break;
                
            case TRANSIT_STEP5:
                TransitStep = TRANSIT_STEP6;
                break;
                
            case TRANSIT_STEP6:
                TransitStep = TRANSIT_STEP7;
                break;      
                
            case TRANSIT_STEP7:
                TransitStep = TRANSIT_STEP_MAX;
                break;

            case TRANSIT_STEP_MAX:
            default:
                sWdr.Ctrl.B8.TransitState = STATE_OFF;
                break;
        }
    }

    preTransitState = sWdr.Ctrl.B8.TransitState;
}

/******************************************************************************************************
* Function Name : AE_SetAgcMode
* Argument      : void
* Return        : void
* Description   : set GVRangeMax by AGC MODE
                : Reset GV in case of GV > GVRangeMax
*******************************************************************************************************/
void ncSvc_WDR_AE_AGC_Set(void)
{
    static etAGC_MODE preAGCMode = AGC_MODE_INIT;

    //=======================================================================================   
    //  MAX Limit Setting
    //=======================================================================================
    sMwAeWDR.Tracking.Long.GVActiveMin = (GAIN_VALUE_TYPE)GAIN_VALUE_MIN;
    sMwAeWDR.Tracking.Long.GVActiveMax = (GAIN_VALUE_TYPE)(LutAGCMode[0][rSWReg.Category.WDR.Reg.WDR_AGC_MODE] * GAIN_VALUE_MIN);

    if(preAGCMode != rSWReg.Category.WDR.Reg.WDR_AGC_MODE)
    {
        if(sMwAeWDR.Tracking.Step == eWDR_AE_STEP_GAIN)
        {
            // Sensup ���� ���¿��� AGC_MODE ���� �� ���� ���� ���� : Added by shpark[20140125]
            // ���� ���� : AGC_MODE���� ���ȴٰ� �ٽ� �ø���� AGC�������� ����
            if(sMwAeWDR.Tracking.Long.GV >= sMwAeWDR.Tracking.Long.GVActiveMax)
            {
               sMwAeWDR.Tracking.Long.SV = sMwAeWDR.Tracking.Long.SVActiveMin;
               sMwAeWDR.Tracking.Long.GV = sMwAeWDR.Tracking.Long.GVActiveMax;
            }
        }
        sMwAeWDR.Tracking.Step = eWDR_AE_STEP_GAIN; 
        sMwAeWDR.Tracking.Long.TrackingEn = STATE_ON;
    }
    
    preAGCMode = (etAGC_MODE)rSWReg.Category.WDR.Reg.WDR_AGC_MODE;
}

void ncSvc_WDR_Mode_Set(UCHAR WDRMode)
{
    static UCHAR preWdrMode = 0xFF;

    if(preWdrMode != WDRMode)
    {
        sWdr.Mode = (BOOL)WDRMode;

        if(WDRMode == STATE_ON)
        {     
            if(OPTION_WDR_TYPE == eWDRTYPE_DFRAME_1M || OPTION_WDR_TYPE == eWDRTYPE_DFRAME_2M)
            {
                if((etFRAME_SIZE)OUTPUT_SIZE == eSIZE_1280_720) sWdr.Type = (etWDR_TYPE_TYPE)eWDRTYPE_DFRAME_1M;
                else                                            sWdr.Type = (etWDR_TYPE_TYPE)eWDRTYPE_DFRAME_2M;
            }
            else
                sWdr.Type = (etWDR_TYPE_TYPE)OPTION_WDR_TYPE;
        }
        else
        {
              sWdr.Type = (etWDR_TYPE_TYPE)eWDRTYPE_OFF;
        }
        rSWReg.Category.WDR.Reg.WDR_TYPE = sWdr.Type;  

    	WDR_Type_Set();
    }

   	preWdrMode = WDRMode;
}
void WDR_TUNE_INIT_SET(UCHAR grph_num)
{ 
    UCHAR Y_sel=0;
    
    switch(grph_num)
    {
        case eGRPH_00: break;
        case eGRPH_01: Y_sel = rSWReg.Category.WDR.Reg.WDR_TUNE_GRPH01_Y_SEL;  break;
        case eGRPH_02: Y_sel = rSWReg.Category.WDR.Reg.WDR_TUNE_GRPH02_Y_SEL;  break;
        case eGRPH_03: Y_sel = rSWReg.Category.WDR.Reg.WDR_TUNE_GRPH03_Y_SEL;  break;
        case eGRPH_04: Y_sel = rSWReg.Category.WDR.Reg.WDR_TUNE_GRPH04_Y_SEL;  break;
        default: break;
    }
    switch(Y_sel)
    {

        case eOUT_GIAN_00: rIP_WDR_GAIN_00 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_00;   break;
        case eOUT_GIAN_01: rIP_WDR_GAIN_01 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_01;   break;
        case eOUT_GIAN_02: rIP_WDR_GAIN_02 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_02;   break;
        case eOUT_GIAN_03: rIP_WDR_GAIN_03 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_03;   break;        
        case eOUT_GIAN_04: rIP_WDR_GAIN_04 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_04;   break;
        case eOUT_GIAN_05: rIP_WDR_GAIN_05 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_05;   break;
        case eOUT_GIAN_06: rIP_WDR_GAIN_06 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_06;   break;  
        case eOUT_GIAN_07: rIP_WDR_GAIN_07 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_07;   break;  
        default: break;
    }    
}

void WDR_TUNE_GRPH_SET(UCHAR grph_num)
{

#define GRPH_OFFSET 10U
typedef struct{
    union{
        UCHAR D8;
        struct{
            UCHAR Y_sel: 4;
            UCHAR X_sel: 4;
        }B8;
    }Param;
    USHORT lutXAxis[3U];
    UCHAR lutYAxis[3U];
}TUNE_GRPH_TYPE;

    TUNE_GRPH_TYPE * TuneGrph;
   
    UCHAR Yout;
    USHORT Xin;
    
    TuneGrph =  (TUNE_GRPH_TYPE*)(ADDR_WDR_TUNE_GRPH01_X_SEL + (GRPH_OFFSET * (grph_num-1)));
    
    switch(TuneGrph->Param.B8.X_sel)
    {   
        case eIN_AGC:              Xin = rIP_AGC_LEVEL_7_0;                             break;
        case eIN_LONG_Y:           Xin = sMwAeWDR.Tracking.Long.CurrY;                  break;
        case eIN_MIDDLE_Y:         Xin = sMwAeWDR.Tracking.Middle.CurrY;                break;            
        case eIN_SHORT_Y:          Xin = sMwAeWDR.Tracking.Short.CurrY;                 break; 
        case eIN_LONG_EXP_LINE:    Xin = sMwAeWDR.Tracking.Long.ExposureLine;           break; 
        case eIN_MIDDLE_EXP_LINE:  Xin = sMwAeWDR.Tracking.Middle.ExposureLine;         break; 
        case eIN_SHORT_EXP_LINE:   Xin = sMwAeWDR.Tracking.Middle.ExposureLine;         break; 
        case eIN_RESERVED_01:      Xin = sMwOpd.HistogramS.WeightRatio;                 break;  /*DOL3 only*/
        case eIN_RESERVED_02:      Xin = sMwOpd.HistogramM.WeightRatio;                 break;  /*DOL3 only*/
        default: break;
    }    

    Yout = (UCHAR)ncDrv_InterpTbl16to8(Xin, TuneGrph->lutXAxis, TuneGrph->lutYAxis, 3U);

    switch(TuneGrph->Param.B8.Y_sel)
    {
       case eOUT_GIAN_00: rIP_WDR_GAIN_00 = Yout; break;
       case eOUT_GIAN_01: rIP_WDR_GAIN_01 = Yout; break;
       case eOUT_GIAN_02: rIP_WDR_GAIN_02 = Yout; break;
       case eOUT_GIAN_03: rIP_WDR_GAIN_03 = Yout; break;        
       case eOUT_GIAN_04: rIP_WDR_GAIN_04 = Yout; break;
       case eOUT_GIAN_05: rIP_WDR_GAIN_05 = Yout; break;
       case eOUT_GIAN_06: rIP_WDR_GAIN_06 = Yout; break;  
       case eOUT_GIAN_07: rIP_WDR_GAIN_07 = Yout; break;  
       default: break;
    }      


}


void ncSvc_WDR_Set(void){

    rIP_WDR_GAIN_00 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_00;  
    rIP_WDR_GAIN_01 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_01;  
    rIP_WDR_GAIN_02 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_02; 
    rIP_WDR_GAIN_03 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_03;      
    rIP_WDR_GAIN_04 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_04;  
    rIP_WDR_GAIN_05 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_05;  
    rIP_WDR_GAIN_06 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_06;  
    rIP_WDR_GAIN_07 = rSWReg.Category.WDR.Reg.WDR_GAIN_DEFAULT_07;   
}
void ncSvc_WDR_Task(void)
{   
    WDR_AE_Task();

    if(rSWReg.Category.WDR.Reg.WDR_TUNE_GRPH01_EN) WDR_TUNE_GRPH_SET(eGRPH_01);
    if(rSWReg.Category.WDR.Reg.WDR_TUNE_GRPH02_EN) WDR_TUNE_GRPH_SET(eGRPH_02);
    if(rSWReg.Category.WDR.Reg.WDR_TUNE_GRPH03_EN) WDR_TUNE_GRPH_SET(eGRPH_03);
    if(rSWReg.Category.WDR.Reg.WDR_TUNE_GRPH04_EN) WDR_TUNE_GRPH_SET(eGRPH_04);

    if(rSWReg.Category.WDR.Reg.WDR_AUTO_TUNE_EN)
    {
        WDR_AUTO_TUNE_FUNC();  /*Only FW tuning*/
    } 
}   


#endif
void ncSvc_WDR_CLKPath_Set(void)
{
    typedef union{	
        UCHAR D8;
        struct{
            UCHAR DIV1: 1;
        	UCHAR DIV2: 1;
        	UCHAR DIV3: 1;
        	UCHAR SEL_CKO: 2;
        	UCHAR X2DIV1: 1;
        	UCHAR X2DIV2: 1;
        	UCHAR X2DIV3: 1;
        }B8;
    }STRUCT_CLK_DIV_TYPE;

    /* refer to "ISP_ClockPath_Guide.xls" */
    STRUCT_CLK_DIV_TYPE CLK_DIV[5] = { 0xD7, 0x07, 0xD6, 0x06, 0x08 };    
    STRUCT_CLK_DIV_TYPE ClkDivSet;
    
    if(INPUT_SIZE == eSIZE_1280_720)
    {
        switch(sWdr.Type)
        {
            case eWDRTYPE_OFF:
            case eWDRTYPE_DCOMP_OV:
                if(sGco.InputFrame.Rate == eFRAME_RATE_30)
                    ClkDivSet = CLK_DIV[0];
                else if(sGco.InputFrame.Rate == eFRAME_RATE_60)
                    ClkDivSet = CLK_DIV[1];
                break;
                
            case eWDRTYPE_DFRAME_1M:
                if(sGco.InputFrame.Rate == eFRAME_RATE_60)
                    ClkDivSet = CLK_DIV[0];
                else if(sGco.InputFrame.Rate == eFRAME_RATE_120)
                    ClkDivSet = CLK_DIV[3];
                break;

            case eWDRTYPE_DOL2:         
                ClkDivSet = CLK_DIV[3];     
                break;

            case eWDRTYPE_DOL3:
                if(sGco.OutputFrame.Rate == eFRAME_RATE_30)
                    ClkDivSet = CLK_DIV[2];
                else if(sGco.OutputFrame.Rate == eFRAME_RATE_60)
                    ClkDivSet = CLK_DIV[3];
                break;

            default:                    ClkDivSet = CLK_DIV[0];     break;
        }
    }
    else
    {
        switch(sWdr.Type)
        {
            case eWDRTYPE_OFF: 
                if(sGco.InputFrame.Rate == eFRAME_RATE_30)
                    ClkDivSet = CLK_DIV[1];
                else if(sGco.InputFrame.Rate == eFRAME_RATE_60)
                    ClkDivSet = CLK_DIV[4];
                break;

            case eWDRTYPE_DFRAME_2M:    ClkDivSet = CLK_DIV[3];     break;
            default:                    ClkDivSet = CLK_DIV[0];     break;
        }
    }

#if 0
    rIP_SEL_CKO = ClkDivSet.B8.SEL_CKO;
    rIP_SEL_ISP_DIV1 = ClkDivSet.B8.DIV1;
    rIP_SEL_ISP_DIV2 = ClkDivSet.B8.DIV2;
    rIP_SEL_ISP_DIV3 = ClkDivSet.B8.DIV3;
    rIP_SEL_ISP_2XDIV1 = ClkDivSet.B8.X2DIV1;
    rIP_SEL_ISP_2XDIV2 = ClkDivSet.B8.X2DIV2;
    rIP_SEL_ISP_2XDIV3 = ClkDivSet.B8.X2DIV3;
#endif

}



