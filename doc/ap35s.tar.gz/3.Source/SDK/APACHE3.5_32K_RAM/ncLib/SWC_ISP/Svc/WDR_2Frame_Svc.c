/********************************************************************************
*				Copyright (C) 2014 NEXTCHIP Inc. All Rights Reserved.
*********************************************************************************
*	
*	Contents	: Br8051 Init
*	File Path	: \source\3_cfile\2_middleware 
*	File Name 	: mw_wdr_imx136.c 
*	Enviroment	: IAR Imbedded WorkBench6.0 for 8051[8.10]
*	Description	: 
*	
*********************************************************************************
*	History      : 
		CreationDate		Modifier		Ver		Description
		-------------------------------------------------------
		 2015.6.2	        JWLee	        1.00    Newly Generated
*********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "WDRLib_Svc.h"


#if((OPTION_WDR_TYPE == WDRTYPE_DFRAME_1M)||(OPTION_WDR_TYPE==WDRTYPE_DFRAME_2M))

void Debug_Viewer_WDR_AE(void)
{
#if 0
    /* Long Information for customer.                                       */
    // Long
    APP_OSDPrint_String(1, 4, (UCHAR*)"T/C");
    APP_OSDPrint_String(1, 10, (UCHAR*)"ST");
    APP_OSDPrint_String(1, 18, (UCHAR*)"A/R");
    APP_OSDPrint_String(1, 25, (UCHAR*)"IRIS    PWM");

    APP_OSDPrint_String(2, 1, (UCHAR*)"L");
    APP_OSDPrint_Hex(2, 3, (UCHAR)sMwAeWDR.Tracking.Long.TargetY);
    APP_OSDPrint_String(2, 5, (UCHAR*)"/");
    APP_OSDPrint_Hex(2, 6, (UCHAR)sMwAeWDR.Tracking.Long.CurrY);
    APP_OSDPrint_String(2, 9, (UCHAR*)"1/");
    APP_OSDPrint_Dec(2, 11,(USHORT)sMwAeWDR.Tracking.Long.Shutter);    

    APP_OSDPrint_Hex(2, 17, (UCHAR)sMwAe.Agc.Level);
    APP_OSDPrint_String(2, 19, (UCHAR*)"/");
    APP_OSDPrint_Hex(2, 20, (UCHAR)sMwAe.Agc.Ratio);

    // Short
    APP_OSDPrint_String(11, 1, (UCHAR*)"S");
    APP_OSDPrint_Hex(11, 3, (UCHAR)sMwAeWDR.Tracking.Short.TargetY);
    APP_OSDPrint_String(11, 5, (UCHAR*)"/");
    APP_OSDPrint_Hex(11, 6, (UCHAR)sMwAeWDR.Tracking.Short.CurrY);
    APP_OSDPrint_String(11, 9, (UCHAR*)"1/");
    APP_OSDPrint_Dec(11, 11,(USHORT)sMwAeWDR.Tracking.Short.Shutter);
    /*-----------------------------------------------------------------*/
    
    /* Information for developers. */
    // Long
    APP_OSDPrint_Hex2(2, 23, (USHORT)0x0000);       /* First IRIS */
    APP_OSDPrint_String(2, 27, (UCHAR*)"/");    
    APP_OSDPrint_Hex2(2, 28, (USHORT)0x0000);       /* Second IRIS*/
    APP_OSDPrint_String(2, 32, (UCHAR*)"/");
    APP_OSDPrint_Hex2(2, 33, (USHORT)0x0000);       /* PWM BASE   */

    APP_OSDPrint_Dec(3, 9, (USHORT)sMwAeWDR.Tracking.Long.ExposureLine);

	APP_OSDPrint_Hex2(4, 9, (USHORT)(sMwAeWDR.Tracking.Long.SV>>16));
	APP_OSDPrint_Hex2(5, 9, (USHORT)(sMwAeWDR.Tracking.Long.SV&0xFFFF));
	
    // Short
    APP_OSDPrint_Dec(12, 9, (USHORT)sMwAeWDR.Tracking.Short.ExposureLine);
	APP_OSDPrint_Hex2(13, 9, (USHORT)(sMwAeWDR.Tracking.Short.SV>>16));
	APP_OSDPrint_Hex2(14, 9, (USHORT)(sMwAeWDR.Tracking.Short.SV&0xFFFF));
    /*-----------------------------------------------------------------*/
#endif
}

void WDR_AE_Init(void)
{
    sMwAeWDR.Tracking.Long.TrackingEn = STATE_ON;
    sMwAeWDR.Tracking.Middle.TrackingEn = STATE_OFF;
    sMwAeWDR.Tracking.Short.TrackingEn = STATE_ON;

    /* Long */
    sMwAeWDR.Tracking.Long.SV           = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT];

    sMwAeWDR.Tracking.Long.SVActiveMax  = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT] * SENSOR_VTOTAL_DEFAULT[INPUT_SIZE]/SENSOR_EXPOSURE_MIN;
    sMwAeWDR.Tracking.Long.SVActiveMin  = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT];

    /* Middle */
    sMwAeWDR.Tracking.Middle.SV          = 0;
    
    sMwAeWDR.Tracking.Middle.SVSpeed     = 0;
    sMwAeWDR.Tracking.Middle.SVActiveMax = 0;
    sMwAeWDR.Tracking.Middle.SVActiveMin = 0;
    
    /* Short */
    sMwAeWDR.Tracking.Short.SV          = sMwAeWDR.Tracking.Long.SV;

    sMwAeWDR.Tracking.Short.SVActiveMax = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT] * SENSOR_VTOTAL_DEFAULT[INPUT_SIZE]/SENSOR_EXPOSURE_MIN;
    sMwAeWDR.Tracking.Short.SVActiveMin = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT];

    sMwAeWDR.Tracking.Long.GV = AE_GAIN_1X;//GAIN_VALUE_MIN;
    sMwAeWDR.Tracking.Step = eWDR_AE_STEP_SHUT;
}

UINT32 WDR_Off_Set(void)
{
    INT32 ret = NC_SUCCESS;
    return ret;
}

UINT32 WDR_Register_Set(void)
{
    INT32 ret = NC_SUCCESS;
    return ret;
}

UINT32 WDR_On_Set(void)
{
    INT32 ret = NC_SUCCESS;
    return ret;
}


#endif

