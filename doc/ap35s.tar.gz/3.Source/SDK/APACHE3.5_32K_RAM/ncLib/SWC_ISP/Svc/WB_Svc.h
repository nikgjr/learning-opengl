
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APACHE2.8
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
		2016.01.26      M.Y Sung    0.0     platform change
********************************************************************************/


#ifndef __SVC_WB_H__
#define __SVC_WB_H__

typedef enum{
	TRACKING_OFF = 0,
	TRACKING_RUN
}ATW_GAIN_TRACKING;

typedef enum{
	LIMIT_OFF = 0,
	LIMIT_AGC,
	LIMIT_ALWAYS
}ATW_GAIN_LIMIT;

#define CIEXYZ_RSET(r)		ISPSET08(aIP_CIE_R_VALUE, (r))
#define CIEXYZ_GSET(g)		ISPSET08(aIP_CIE_G_VALUE, (g))
#define CIEXYZ_BSET(b)		ISPSET08(aIP_CIE_B_VALUE, (b))

#define USABLE_RANGE		24 	// The available range
#define AWB_IN_BOUNDARY	    ((ISPGET08(ADDR_WB_IN_BOUNDARY) & 0x78) >>3)
#define AWB_OUT_BOUNDARY	(AWB_IN_BOUNDARY * 3)
#define OPDNUM				64

typedef struct
{
	USHORT 	XMax;
  	USHORT 	XMin;
	USHORT 	YMax;
  	USHORT 	YMin;
}STRUCT_CIE_RECT;

typedef struct
{
	UCHAR*	AddrRGain;
	USHORT	RGain;
	BOOL    RStable;

	UCHAR*	AddrBGain;
	USHORT	BGain;
	BOOL    BStable;
}STRUCT_GAIN_TRACKING_TYPE;

typedef struct
{
    STRUCT_CIE_RECT Rect[USABLE_RANGE];
}STRUCT_CIE;

typedef struct
{
	UCHAR R;
	UCHAR G;
	UCHAR B;	
}STRUCT_OPD_RGB;

typedef struct
{
	USHORT Xpos;
	USHORT Ypos;
}STRUCT_CIE_XY;

typedef struct
{
	USHORT Xpos;
	USHORT Ypos;
}STRUCT_AVERAGE_CIEXY;

typedef struct
{
    STRUCT_CIE * Cie;

	UCHAR 	Data1;	
	UCHAR 	Data2;	
	UCHAR 	Data3;		

	UCHAR 	ModeRun;
	UCHAR	preMode;
	
	UCHAR	JigData[12];

    STRUCT_GAIN_TRACKING_TYPE Target;
    STRUCT_GAIN_TRACKING_TYPE TargetM;
    STRUCT_GAIN_TRACKING_TYPE TargetS;

    STRUCT_AVERAGE_CIEXY AveCIE;
}STRUCT_MW_AWB;

extern STRUCT_MW_AWB	sMwAwb;

/*
********************************************************************************
*              Cal FUNCTION DECLARATIONS 
********************************************************************************
*/
void ncSvc_WB_ZigControl_Set(void);
void CIExy_Get(STRUCT_OPD_RGB * Opd, STRUCT_CIE_XY * CieXY);
void ZigControl_CIExy_Set(UCHAR status);

/*
********************************************************************************
*              API FUNCTION DECLARATIONS 
********************************************************************************
*/
void ncSvc_WB_INIT(void);
void ncSvc_WB_MODE_SET(void);
void ncSvc_WB_Task(void);
void ncSvc_AWB_Deinitialize(void);

/*
********************************************************************************
*              Algorithm FUNCTION DECLARATIONS 
********************************************************************************
*/
BOOL ATW_ColorException_State(void);
void ATW_TargetRB_Adjust(void);
UCHAR ATW_TrackingGain_GET(void);
UCHAR ATW_TrackingMGain_GET(void);
UCHAR ATW_TrackingSGain_GET(void);
UCHAR ATW_Gain_Tracking(STRUCT_GAIN_TRACKING_TYPE* Target);
void AWC_Gain_Tracking(void);
UCHAR AWB_TargetRB_SET(void);
UCHAR ncSvc_WBRect_Status(void);

/*
********************************************************************************
*              Debug FUNCTION DECLARATIONS 
********************************************************************************
*/
void Debug_Viewer_WB1(void);
void Debug_Viewer_WB(void);

#endif


