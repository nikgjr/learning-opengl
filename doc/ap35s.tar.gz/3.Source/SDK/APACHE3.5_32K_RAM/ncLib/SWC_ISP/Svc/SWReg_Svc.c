/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SoftRegister.c
*
*  @brief   : SWR (SoftWare Register) service source file
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>

#include "APACHE35.h"
#include "SWReg_Lib.h"

#include "SWReg_Svc.h"
#include "Debug_Lib.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

UINT8 ncSvc_SWR_GetData(eSWR_ID_NUM nID)
{
    UINT8 nValue;

    switch(nID)
    {
        /* Application Commands */

        case SWR_ID_SENSOR_SLAVEID:
        break;

        case SWR_ID_SENSOR_SELECT:
        break;

        case SWR_ID_SENSOR_MODE:
        break;

        case SWR_ID_SENSOR_PROTOCOL:
        break;

        case SWR_ID_AVB_CHANNEL:
        break;

        case SWR_ID_DISPLAY_MODE:
        break;

        case SWR_ID_SDPC_LOAD:
        break;

        case SWR_ID_SDPC_SAVE:
        break;

        case SWR_ID_ENC_MODE:
        break;

        case SWR_ID_ENC_QP:
        break;

        case SWR_ID_ENC_BITRATE:
        break;

        case SWR_ID_PGL_INDEX:
        break;

        case SWR_ID_VIEWMODE_INDEX:
        break;

        default :
        break;
    }

    return nValue;
}


void ncSvc_SWR_SetData(eSWR_ID_NUM nID, UINT8 nData)
{
    switch(nID)
    {
        /* Application Commands */

        case SWR_ID_SENSOR_SLAVEID:
        break;

        case SWR_ID_SENSOR_PROTOCOL:
        break;

        case SWR_ID_AVB_CHANNEL:
        break;

        case SWR_ID_DISPLAY_MODE:
        break;

        case SWR_ID_SDPC_LOAD:
        break;

        case SWR_ID_SDPC_SAVE:
        break;

        case SWR_ID_ENC_MODE:
        break;

        case SWR_ID_ENC_QP:
        break;

        case SWR_ID_ENC_BITRATE:
        break;

        case SWR_ID_PGL_INDEX:
        break;

        case SWR_ID_VIEWMODE_INDEX:
        break;

        default :
        break;
    }
}


/* End Of File */
