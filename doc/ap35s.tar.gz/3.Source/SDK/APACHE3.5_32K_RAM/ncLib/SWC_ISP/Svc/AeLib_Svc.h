
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __SVC_AE_LIB__
#define __SVC_AE_LIB__

#define PIRIS_VAL_BUF	    10

#define IRIS_OPEN_VALUE     0x00
#define IRIS_CLOSE_VALUE    0x3FFF
#define IRIS_ADC_REF_HIGH   0x64+0x50   // 1.8V
#define IRIS_ADC_REF_LOW    0x42+0x50   // 1.5V
#define IRIS_STABLE_ZONE    0x05

#define AGC_LIMIT_MODE      4L          // x128, x256, x384, x512
#define AGC_MAX_DB          43L         // 0dB~42dB
#define LUT_DB2GAIN_CNT     55L         // 0dB~54dB
#define LUT_DB2GAIN_MAX     LUT_DB2GAIN_CNT

/*********************** COMMON DATA TYPE DEFINITION ******************************/
#ifndef tDN_STATUS
#define tDN_STATUS
    typedef enum
    {
    	DN_STATUS_BW = 0,
    	DN_STATUS_COLOR,
    	DN_STATUS_MAX,
    }DN_STATUS;
#endif

#ifndef tDN_MODE_TYPE
#define tDN_MODE_TYPE
    typedef enum{
    	eDN_AUTO = 0,
    	eDN_COLOR,
    	eDN_BW,
    	eDN_EXT,
    	eDN_MAX,
    }etDN_MODE_TYPE;
#endif

#ifndef tCVBS_OUTPUT_FORMAT
#define tCVBS_OUTPUT_FORMAT
    typedef enum{
    	eCVBS_PAL = 0,
    	eCVBS_NTSC,
    	eCVBS_FORMAT,
    }etCVBS_OUTPUT_FORMAT;
#endif

#ifndef tLEVEL3_TYPE
#define tLEVEL3_TYPE
    typedef enum{
    	eLEVEL3_LOW = 0,
    	eLEVEL3_MIDDLE,
    	eLEVEL3_HIGH
    }etLEVEL3_TYPE;
#endif

#ifndef tBACKLIGHT_MODE_TYPE
#define tBACKLIGHT_MODE_TYPE
    typedef enum{
    	eBACKLIGHT_OFF = 0,
    	eBACKLIGHT_BLC,
    	eBACKLIGHT_HSBLC,
        eBACKLIGHT_WDR,
        eBACKLIGHT_MAX,    
    }etBACKLIGHT_MODE_TYPE;
#endif

#ifndef tFUNCTION_MODE_TYPE
#define tFUNCTION_MODE_TYPE
    typedef enum{
    	eMODE_OFF = 0,
    	eMODE_ON,
    	eMODE_AUTO
    } etFUNCTION_MODE_TYPE;
#endif

#ifndef tAGC_MODE
#define tAGC_MODE
    typedef enum{
    	eAGC_MODE_OFF = 0,
    	eAGC_MODE_15 = 15,
    	eAGC_MODE_MAX,
    }etAGC_MODE;
#define AGC_MODE_INIT  eAGC_MODE_MAX
#endif

#ifndef tFRAME_RATE
#define tFRAME_RATE
    typedef enum{
        eFRAME_RATE_30 = 0,
    	eFRAME_RATE_60,
    	eFRAME_RATE_120,
    	eFRAME_RATE_MAX,
    }etFRAME_RATE;
#define eFRAME_RATE_INIT	eFRAME_RATE_MAX
#endif

#ifndef tLENS_MODE
#define tLENS_MODE
    typedef enum{
        eLENS_MODE_DC = 0,
        eLENS_MODE_MANUAL,
        eLENS_MODE_PIRIS,
        eLENS_MODE_DC_MANUAL,
        eLENS_MODE_MAX,
    }etLENS_MODE;
    #define LENS_MODE_INIT  eLENS_MODE_MAX
#endif

#ifndef tDC_LENS_MODE
#define tDC_LENS_MODE
    typedef enum{
        eDC_INDOOR = 0,
        eDC_OUTDOOR,
    }eDC_LENS_MODE;
#endif

#ifndef tAE_SHUT_MODE
#define tAE_SHUT_MODE
    typedef enum{
        eSHUT_MODE_NORMAL = 0,
        eSHUT_MODE_FLK
    }etAE_SHUT_MODE;
#endif

#ifndef tAE_OPD_WEIGHT_MODE
#define tAE_OPD_WEIGHT_MODE
typedef enum{
	eOPDWEIGHT_NORMAL = 0,
	eOPDWEIGHT_BLC,
	eOPDWEIGHT_IRSMART,
	eOPDWEIGHT_MAX,
}etAE_OPD_WEIGHT_MODE;
#endif

#ifndef tMANUAL_SHUT_TYPE
#define tMANUAL_SHUT_TYPE
    typedef enum{
/*  00  */ 	e60P_MANUAL_AUTO = 0,
/*  01  */  e60P_MANUAL_1_60s,
/*  02  */  e60P_MANUAL_FLK,	
/*  03  */  e60P_MANUAL_1_250s,
/*  04  */  e60P_MANUAL_1_500s,
/*  05  */  e60P_MANUAL_1_1000s,
/*  06  */  e60P_MANUAL_1_2000s,
/*  07  */  e60P_MANUAL_1_5000s,
/*  08  */  e60P_MANUAL_1_10000s,
/*  09  */  e60P_MANUAL_1_50000s,
/*  10  */  e60P_MANUAL_x02,
/*  11  */  e60P_MANUAL_x04,
/*  12  */  e60P_MANUAL_x06,
/*  13  */  e60P_MANUAL_x08,
/*  14  */  e60P_MANUAL_x10,
/*  15  */  e60P_MANUAL_x15,
/*  16  */  e60P_MANUAL_x20,
/*  17  */  e60P_MANUAL_x25,
/*  18  */  e60P_MANUAL_x30,
/*  19  */  e60P_MANUAL_Max,
    } et60P_MANUAL_SHUT_TYPE;

    typedef enum{
/*  00  */  e30P_MANUAL_AUTO = 0,
/*  01  */  e30P_MANUAL_1_30s,	
/*  02  */  e30P_MANUAL_1_60s,
/*  03  */  e30P_MANUAL_FLK,	
/*  04  */  e30P_MANUAL_1_250s,
/*  05  */  e30P_MANUAL_1_500s,
/*  06  */  e30P_MANUAL_1_1000s,
/*  07  */  e30P_MANUAL_1_2000s,
/*  08  */  e30P_MANUAL_1_5000s,
/*  09  */  e30P_MANUAL_1_10000s,
/*  10  */  e30P_MANUAL_1_50000s,
/*  11  */  e30P_MANUAL_x02,
/*  12  */  e30P_MANUAL_x04,
/*  13  */  e30P_MANUAL_x06,
/*  14  */  e30P_MANUAL_x08,
/*  15  */  e30P_MANUAL_x10,
/*  16  */  e30P_MANUAL_x15,
/*  17  */  e30P_MANUAL_x20,
/*  18  */  e30P_MANUAL_x25,
/*  19  */  e30P_MANUAL_x30,
/*  20  */  e30P_MANUAL_Max,
    } et30P_MANUAL_SHUT_TYPE;
    #define SHUT_MODE_INIT		    e30P_MANUAL_Max	    /* RESET CODE */
    #define SHUT_MODE_AUTO		    e30P_MANUAL_AUTO    /* = e60P_MANUAL_AUTO */
    #define SHUT_MODE_DEFAULT	    e30P_MANUAL_1_30s	/* 30P=1/30, 60P=1/60 */
    #define SENSUP_START_IDX_30P    e30P_MANUAL_x02
    #define SENSUP_START_IDX_60P    (et30P_MANUAL_SHUT_TYPE)e60P_MANUAL_x02
#endif

/*********************** LOCAL DATA TYPE DEFINITION ******************************/
typedef enum{
	eAE_STEP_IRIS = 1,
	eAE_STEP_SHUT,
	eAE_STEP_GAIN,
	eAE_STEP_SENSUP
}etAE_TRACKING_STEP;

typedef enum{
	eSENSUP_OFF = 0,
	eSENSUP_AUTO
}etSENSUP_MODE;

typedef enum{
	eSENSUP_INC_LINEAR = 0,
	eSENSUP_INC_FRAME,
	eSENSUP_INC_MAX,
}etSENSUP_INC_MODE;

typedef enum{
	eSTEP_GAIN_DISABLE = 0,
	eSTEP_GAIN_ENABLE
}etLOWLIGHT_STATE_MODE;

/* [2015/03/06] JWLee : [STD]-01 */
typedef enum{
	eAE_TRACKING_IDLE = 0,
	eAE_TRACKING_ON,
}etAE_TRACKING_TYPE;

/* [2015/04/09] JWLee : [STD]-01 */
typedef enum{
	eAE_BOUNDARY_IN = 0,
	eAE_BOUNDARY_OUT,
}etAE_BOUNDARY_TYPE;

typedef enum
{
    CALC_SV,
    CALC_GV,
}etCALCULATE_TYPE;

enum{
	P_TOMRON,
	P_DAIWON
};
#define PIRIS_STEP_TOMRON	120	//  1-2phase
#define PIRIS_STEP_DAIWON	185	//  1-2phase

enum{
	P_NEXTCHIP,
	P_USER
};

typedef enum{
	PIRIS_MANUAL,
	PIRIS_AUTO
}PIRIS_MODE;

enum{
	P_OPEN,
	P_CLOSE,
	P_STOP
};

typedef enum{
	PIRIS_FULL_CLOSE,
	PIRIS_FULL_OPEN,
	PIRIS_RETURN,
	PIRIS_MAX
}PIRIS_LEVEL_MODE;

typedef enum{
    AE_GAIN_1X = 	0x0080,
    AE_GAIN_2X = 	0x0100,
    AE_GAIN_3X = 	0x0180,
    AE_GAIN_4X = 	0x0200,
    AE_GAIN_5X = 	0x0280,
    AE_GAIN_6X = 	0x0300,
    AE_GAIN_7X = 	0x0380,
    AE_GAIN_8X = 	0x0400,
    AE_GAIN_9X = 	0x0480,
    AE_GAIN_10X = 	0x0500,
    AE_GAIN_11X = 	0x0580,
    AE_GAIN_12X = 	0x0600,
    AE_GAIN_24X = 	0x0C00,
    AE_GAIN_32X = 	0x1000,
    AE_GAIN_48X = 	0x1800,
    AE_GAIN_64X = 	0x2000,
    AE_GAIN_128X = 	0x4000,
    AE_GAIN_512X = 	0xFFFF,
}GAIN_VALUE_TYPE;

#define GAIN_VALUE_MIN      AE_GAIN_1X
#define GAIN_VALUE_MAX      AE_GAIN_128X

typedef struct
{
	/*__________ Tracking Variables ____________________*/
	USHORT	CurrY;              /* Current Brightness */
	UCHAR 	TargetY;            /* Target Brightness */
    etAE_BOUNDARY_TYPE  BoundaryStatus;
	etAE_TRACKING_TYPE	TrackingSet;
	etAE_TRACKING_STEP  Step;

	etLOWLIGHT_STATE_MODE   LowLightState;
	etAE_OPD_WEIGHT_MODE	OPDWeightMode;
	etFRAME_RATE 	SensorFrameRate;
	
	/*__________ Shutter Value ___________________________*/
    USHORT  Shutter;            /* Shutter Speed = SV/1024 (reference) */
	ULONG	SV;				    /* Main Shutter Value (Frame count per sec * 4sec * 256) */
	ULONG   SVRangeMin;         /* SV lower limit */
	ULONG   SVRangeMax;         /* SV upper limit */
    ULONG   SVDefault;          /* Reference Value for default SV : (FPS x 4sec x 256) */
    
	/*__________ Gain Value (ISP+SENSOR) ______________*/	
	GAIN_VALUE_TYPE	GV;			/* Main Gain Value(128 = x1, 16384 = x128), (Dgain + Again) */
	GAIN_VALUE_TYPE	GVRangeMin; /* GAIN lower limit : Default=x1(128) */
	GAIN_VALUE_TYPE	GVRangeMax; /* GAIN upper limit : depand on AGC MODE */
}dtAE_TRACKING_TYPE;

typedef struct
{
	USHORT	VTotalLine;		    /* Sensor Total Line Count(Sens-up) */
	USHORT	ExposureLIne;		/* Sensor Exposure Line Count */
}dtAE_SENSOR_VALUE_TYPE;

typedef struct
{
    USHORT	GVTotal;            /* IspDGainLineComp x IspDGainTotal */
	USHORT	GVCompHS;           /* Compensation gain for Line Gap (High Shutter) */
	USHORT	GVCompSG;	        /* Compensation gain for Senser Gain */
}dtAE_ISP_VALUE_TYPE;

typedef struct
{
	UCHAR	Level;			    /* AGC_LEVEL (0x00~0xFF) */
	UCHAR	Ratio;		        /* AGC MODE �� LIMIT �� MAX �� �� ���� AgcLevel �� ���� :: 0x00 ~ 0xFF */
}dtAE_AGC_VALUE_TYPE;

typedef struct
{
	USHORT 	GainLevel;
	USHORT 	FirstGainLevel;	
	USHORT	RefLevel;
}dtAE_IRIS_VALUE_TYPE;

typedef struct
{
	UCHAR TargetDet;
	UCHAR Flag;
	UCHAR PositionWrite;
	UCHAR PulseDuty;
	UCHAR DegreeStep;
	USHORT SaveWaitTime;
	USHORT StepCnt;
	USHORT MaxLimitPos;
	USHORT InitPirisWaitCnt;
	USHORT StepLvl;
	UCHAR ManualAct;
	UCHAR AEShtCtl;
	UCHAR AESpeed;
	UCHAR AETgtValue;
	UCHAR AECurValue;
	UCHAR WaitCnt;
	UCHAR CalCnt;
	UCHAR InitPosiFlag;
	UCHAR Init;
	UCHAR Val[PIRIS_VAL_BUF];
	USHORT CalVal;
	UCHAR Stanby;
	ULONG ShtMinVal;
	ULONG ShtMaxVal;
	UCHAR Dpc;
	USHORT StepLvlBuf;
	UCHAR  ModeBuf;
	USHORT StepMax;
}dtAE_PIRIS_VALUE_TYPE;

typedef struct
{	
	/*__________ Tracking Variables ____________________*/
	dtAE_TRACKING_TYPE  Tracking;

    /*__________ Sensor Value __________________________*/
	dtAE_SENSOR_VALUE_TYPE Sensor;
	
	/*__________ ISP Value _____________________________*/
	dtAE_ISP_VALUE_TYPE Isp;

	/*__________ AGC References ________________________*/
	dtAE_AGC_VALUE_TYPE Agc;

	/*__________ IRIS Variables ________________________*/
	dtAE_IRIS_VALUE_TYPE    Iris;

	/*__________ P-IRIS Variables ______________________*/
	dtAE_PIRIS_VALUE_TYPE   PIris;	

}STRUCT_MW_AE;
extern STRUCT_MW_AE		sMwAe;

#if (SENSOR_SELECT == SENSOR_COMMON) 
#else
extern const UCHAR    SENSOR_DIFF_LIMIT;      /* 1 Frame dealy if (prevExposureLine-ExposureLine) > SENSOR_DIFF_LIMIT */
extern const UCHAR    SENSOR_EXPOSURE_MIN;    /* Mininum Exposure line count */
extern const USHORT   SENSOR_VTOTAL_DEFAULT[eSIZE_MAX]; /* Default value of Vertical Total line count*/
#endif

/********************************************************************************
* Function Name 	: ncSvc_AE_SensorFPSSet()
* Description		: AE Process
* Refer to			: API Document
* Argument			:	
										 
* Return			: The return value does not exist.
********************************************************************************/
void ncSvc_AE_SensorFPSSet(etFRAME_RATE SensorFrameRate);
/********************************************************************************
* Function Name 	: ncSvc_AE_Reset()
* Description		: AE Variables Initialization
* Refer to			: API Document
* Argument			:	
										 
* Return			: The return value does not exist.
********************************************************************************/
void ncSvc_AE_Reset(void);

/********************************************************************************
* Function Name 	: ncSvc_AE_Init()
* Description		: AE Parameters Initialization
* Refer to			: API Document
* Argument			:	
										 
* Return			: The return value does not exist.
********************************************************************************/
void ncSvc_AE_Init(void);

/********************************************************************************
* Function Name 	: ncSvc_AE_Task()
* Description		: AE Process
* Refer to			: API Document
* Argument			:	
										 
* Return			: The return value does not exist.
********************************************************************************/
void ncSvc_AE_Task(void);

/********************************************************************************
* Function Name 	: ncSvc_AE_IspDGainAlphaSet()
* Description		: AE Process
* Refer to			: API Document
* Argument			:	
										 
* Return			: The return value does not exist.
********************************************************************************/
void ncSvc_AE_IspDGainAlphaSet(USHORT IspDigitalGain);

/********************************************************************************
* Function Name 	: ncSvc_AE_ConvertGainTodB()
* Description		: AE Process
* Refer to			: API Document
* Argument			:	
										 
* Return			: The return dB value
********************************************************************************/
FLOAT ncSvc_AE_ConvertGainTodB(GAIN_VALUE_TYPE GainValue);

extern ULONG LutManulSV[eCVBS_FORMAT][eFRAME_RATE_MAX][e30P_MANUAL_Max];
extern const USHORT  LutdBtoGain[LUT_DB2GAIN_CNT];
extern const USHORT LutAGCMode[AGC_LIMIT_MODE][eAGC_MODE_MAX];

#endif  // __MW_AE_LIB__

