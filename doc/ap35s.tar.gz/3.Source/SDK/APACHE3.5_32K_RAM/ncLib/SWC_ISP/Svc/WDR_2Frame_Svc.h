/********************************************************************************
*				Copyright (C) 2014 NEXTCHIP Inc. All Rights Reserved.
*********************************************************************************
*	
*	Contents	: Br8051 Init
*	File Path	: \Source\2_Hfile\2_Middleware 
*	File Name 	: MW_Wdr_IMX136.h 
*	Enviroment	: IAR Imbedded WorkBench6.0 for 8051[8.10]
*	Description	: 
*	
*********************************************************************************
*	History      : 
		CreationDate		Modifier		Ver		Description
		-------------------------------------------------------
		 2015.6.2	        JWLee		    1.00    Newly generated
*********************************************************************************/

