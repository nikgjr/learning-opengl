
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "APACHE35.h"
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Api_GlobalHeader.h"


#if (SENSOR_SELECT == SENSOR_COMMON)

SENSOR_HEADER SenHeader __attribute__ ((aligned (8)));
SENSOR_DATA SenData __attribute__ ((aligned (8)));
tI2C_INFO i2c;


void SENSOR_Write(void)
{
	//static UCHAR OldOp = 0xFF;

	USHORT ReadTmpVal=0;

	ncLib_I2C_Write(I2C_CH0,
		SenHeader.Byte.DeviceID, 
		SenData.Byte.Addr, 
		SenData.Byte.Value, 
		1, 
		SenData.Byte.Option-1);//I2C_ADDR_16_DATA_16

#if 0
		 APACHE_SYS_mDelay(2);
		 
		ncLib_I2C_Read(I2C_CH0, SenHeader.Byte.DeviceID, SenData.Byte.Addr, (UINT8 *)&ReadTmpVal, 1, I2C_ADDR_16_DATA_16);
		DEBUGMSG(MSGWARN, "wr3 0x%04X, 0x%04X, 0x%04X ", SenData.Byte.Addr, SenData.Byte.Value,ReadTmpVal);

		if(SenData.Byte.Value != ReadTmpVal)
		{
			DEBUGMSG(MSGINFO, "!!!! \r\n");
		}
		else
			DEBUGMSG(MSGINFO, "\r\n");
#endif
		
#if 0
	DEBUGMSG(MSGINFO, "@%02X ",SenData.Byte.Option);
	DEBUGMSG(MSGINFO, "0x%04X ",SenData.Byte.Addr);
	DEBUGMSG(MSGINFO, "0x%04X \r\n",SenData.Byte.Value);
#endif
}

void SENSOR_Info_Load(void)
{
	UINT32 DevId = 0;
	
	USHORT Idx;
	
	if(ncLib_SF_Control(GCMD_SF_READ_DATA, SENSOR_HEADER_ADDR, (UINT8*)&SenHeader, SENSOR_HEADER_SIZE, CMD_END) != 0 )
	{
		return;
	}

#if 0
	for(Idx = 0; Idx<0x40; Idx++)
	{
		if(Idx%0x10==0)
			DEBUGMSG(MSGINFO, "\r\n");
		DEBUGMSG(MSGINFO, "%02X_",SenHeader.Category[Idx]);
		
	}
	DEBUGMSG(MSGINFO, "\r\n");
#endif
	
	if((SenHeader.Byte.Name|0xFF000000) != 0xFF454E53)
	{
		DEBUGMSG(MSGINFO, "SENSOR_Info_Load Fail %x \r\n",SenHeader.Byte.Name);
		return;
	}
	//MW_Sensor_Reset();
	
	i2c.channel = I2C_CH0;
	i2c.byteOrder = I2C_LITTLE_ENDIAN;
    i2c.master.clock = I2C_BITRATE_60KBPS;

	i2c.master.id = SenHeader.Byte.DeviceID;
	i2c.mode = SenHeader.Byte.Info.B16.Slave;
	
	rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = SenHeader.Byte.Info.B16.MaxFps;
	rSWReg.Category.MONITOR.Reg.ISP_INPUT_SIZE 	= SenHeader.Byte.Info.B16.MaxSize;
	rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_SIZE	= SenHeader.Byte.Info.B16.MaxSize;
	

	//sExtComm.SPI.Sensor.Bit.MSmode 	  			= SenHeader.Byte.Info.B16.SpiMsMode;
	//sExtComm.SPI.Sensor.Bit.DataDirection 		= SenHeader.Byte.Info.B16.SpiCommDir;
    i2c.type = I2C_ADDR_16_DATA_16;

	
//	ncLib_I2C_Control(GCMD_I2C_INIT_CH, i2c.channel, &i2c, CMD_END);
//    ncLib_I2C_Control(GCMD_I2C_SET_BITRATE, i2c.channel, i2c.master.clock, CMD_END);


#if 0
	MW_Sensor_GPIO_Init();
	MW_ClockInitialize_Set();
	if(SenHeader.Byte.Info.B16.CommType==SENSOR_COMM_SPI)
		MW_SPI_Initialize();
	else
		MW_I2C_Initialize();
	MW_Sensor_Communication_Set();
#endif

	ncLib_I2C_Read(i2c.channel, i2c.master.id, 0x3000, (UINT8 *)&DevId, 1, i2c.type);

#if 0

	DEBUGMSG(MSGINFO, "\r\nCMOS DEV_ID: DEV_ID ID read 0x%04X\n", DevId);
	DEBUGMSG(MSGINFO, "nSensor AcpID %x , %x\r\n",SenHeader.Byte.AcpID,SenHeader.Byte.WdrType1);



	DEBUGMSG(MSGINFO, "0x%04X 0x%04X 0x%04X 0x%04X\n", SENSOR_DIFF_LIMIT,SENSOR_EXPOSURE_MIN,SENSOR_VTOTAL_DEFAULT[0],SENSOR_VTOTAL_DEFAULT[1]);


	DEBUGMSG(MSGINFO, "0x%04X 0x%04X \n", SENSOR_INTERFACE_DATA.F_PORCH_START[0][0][0], SENSOR_INTERFACE_DATA.F_PORCH_START[0][0][1]);
	DEBUGMSG(MSGINFO, "0x%04X 0x%04X \n", SENSOR_INTERFACE_DATA.F_PORCH_START[0][1][0], SENSOR_INTERFACE_DATA.F_PORCH_START[0][1][1]);
	DEBUGMSG(MSGINFO, "0x%04X 0x%04X \n", SENSOR_INTERFACE_DATA.F_PORCH_START[1][0][0], SENSOR_INTERFACE_DATA.F_PORCH_START[1][0][1]);
	DEBUGMSG(MSGINFO, "0x%04X 0x%04X \n\n", SENSOR_INTERFACE_DATA.F_PORCH_START[1][1][0], SENSOR_INTERFACE_DATA.F_PORCH_START[1][1][1]);

	DEBUGMSG(MSGINFO, "0x%04X 0x%04X \n", SENSOR_INTERFACE_DATA.INPUT_H_TOTAL[0][0][0], SENSOR_INTERFACE_DATA.INPUT_H_TOTAL[0][0][1]);
	DEBUGMSG(MSGINFO, "0x%04X 0x%04X \n", SENSOR_INTERFACE_DATA.INPUT_H_TOTAL[0][1][0], SENSOR_INTERFACE_DATA.INPUT_H_TOTAL[0][1][1]);
	DEBUGMSG(MSGINFO, "0x%04X 0x%04X \n", SENSOR_INTERFACE_DATA.INPUT_H_TOTAL[1][0][0], SENSOR_INTERFACE_DATA.INPUT_H_TOTAL[1][0][1]);
	DEBUGMSG(MSGINFO, "0x%04X 0x%04X \n", SENSOR_INTERFACE_DATA.INPUT_H_TOTAL[1][1][0], SENSOR_INTERFACE_DATA.INPUT_H_TOTAL[1][1][1]);
	

#endif


	
	SenHeader.Byte.UseWdrType = SenHeader.Byte.WdrType1&0x0F;
}




void SENSOR_Set(USHORT StartIdx, USHORT EndIdx, UCHAR CheckOption)
{
	USHORT Idx;
	USHORT ReadTmpVal=0;
	UCHAR  WrPassOn=0;
	UINT8  Recv[5];

	if(ncLib_SF_Control(GCMD_SF_READ_DATA, SENSOR_DATA_ADDR+(StartIdx*SENSOR_DATA_SIZE), (UINT8*)&SenData, SENSOR_DATA_SIZE, CMD_END) != 0 )
	{
		return;
	}

	//DEBUGMSG(MSGINFO, "SENSOR_Set %X %X %X %X\r\n",StartIdx,EndIdx, CheckOption,SenData.Byte.Option);

	if(CheckOption && (SenData.Byte.Option&0xF0) != (CheckOption&0xF0) ) 
	{
		return;
	}
	
	for(Idx = StartIdx; Idx<EndIdx; Idx++)
	{
		if(ncLib_SF_Control(GCMD_SF_READ_DATA, SENSOR_DATA_ADDR+(Idx*SENSOR_DATA_SIZE), (UINT8*)&Recv, SENSOR_DATA_SIZE, CMD_END) != 0 )
		{
			continue;
		}

#if 0
		DEBUGMSG(MSGINFO, "%02X_",Recv[0]);
		DEBUGMSG(MSGINFO, "%02X_",Recv[1]);
		DEBUGMSG(MSGINFO, "%02X_",Recv[2]);
		DEBUGMSG(MSGINFO, "%02X_",Recv[3]);
		DEBUGMSG(MSGINFO, "%02X_",Recv[4]);
#endif
#if 1
		SenData.Byte.Option = Recv[0];
		SenData.Byte.Addr  = MAKEWORD(Recv[2],Recv[1]);
		SenData.Byte.Value = MAKEWORD(Recv[4],Recv[3]);
#endif
#if 0
		DEBUGMSG(MSGINFO, "@%02X ",SenData.Byte.Option);
		DEBUGMSG(MSGINFO, "0x%04X ",SenData.Byte.Addr);
		DEBUGMSG(MSGINFO, "0x%04X \r\n",SenData.Byte.Value);
#endif
	
		if(SenData.Byte.Option <= 0x0F&& !WrPassOn )
		{
			SENSOR_Write();
		} 
		else if(SenData.Byte.Option == SENSOR_OPTION_DELAY)
		{
			APACHE_SYS_mDelay(SenData.Byte.Value);
		}
		else if(SenData.Byte.Option == SENSOR_OPTION_READ || WrPassOn==2)
		{
			if(WrPassOn==2)
			{
				SenData.Byte.Value = SenData.Byte.Value|ReadTmpVal;
				SENSOR_Write();
				ReadTmpVal=0;
				WrPassOn=0;
			}
			else if(WrPassOn==0)
			{
				ncLib_I2C_Read(I2C_CH0,
					SenHeader.Byte.DeviceID, 
					SenData.Byte.Addr, 
					&ReadTmpVal, 
					1, 
					SenData.Byte.Option+1);
				
				//ReadTmpVal = SENSOR.Read(SenData.Byte.Addr) ;
				ReadTmpVal = ReadTmpVal & SenData.Byte.Value;
				WrPassOn=2;
			}
		}
		else if(CheckOption && (SenData.Byte.Option>=(CheckOption&0xF0))&&(SenData.Byte.Option<=(CheckOption|0x0F)) )
		{
			//DEBUGMSG(MSGINFO, "%X : ",Idx);
			if(SenData.Byte.Option==CheckOption)
			{
				WrPassOn=0;
				//DEBUGMSG(MSGINFO, "My Type %X \r\n",SenData.Byte.Option);
			}
			else
			{
				WrPassOn=1;
				//DEBUGMSG(MSGINFO, "WrPassOn %X \r\n",SenData.Byte.Option);
			}
		}
		else if(SenData.Byte.Option == SENSOR_OPTION_END)
		{
			WrPassOn=0;
		}
	}
	
}



void SENSOR_Initial_Set(void)
{
	SENSOR_Set(SenHeader.Byte.AddrInit, SenHeader.Byte.DataCount, 0x00);
}

void SENSOR_WDR_Off(void)
{
	SENSOR_Set(SenHeader.Byte.AddrLinear, SenHeader.Byte.DataCount,  SENSOR_OPTION_LINEAR);
}

void SENSOR_WDR_On(void)
{
	USHORT Idx;
	UCHAR  WdrTpye = (SENSOR_OPTION_LINEAR|(SenHeader.Byte.UseWdrType&0x0F));

	if(WdrTpye == SenHeader.Byte.WdrType1)
		Idx = SenHeader.Byte.AddrWDR1;	
	else if( WdrTpye == SenHeader.Byte.WdrType2)
		Idx = SenHeader.Byte.AddrWDR2;	
	else if( WdrTpye == SenHeader.Byte.WdrType3)
		Idx = SenHeader.Byte.AddrWDR3;	
	else if( WdrTpye == SenHeader.Byte.WdrType4)
		Idx = SenHeader.Byte.AddrWDR4;	
	else
		return;

	SENSOR_Set(Idx, SenHeader.Byte.DataCount, (SENSOR_OPTION_LINEAR|sWdr.Type));
}



void SENSOR_FPS_Set(void)
{
	USHORT Idx;
	UCHAR  FpsNum=0;

	Idx = SenHeader.Byte.AddrFrame;

	if(ncLib_SF_Control(GCMD_SF_READ_DATA, SENSOR_DATA_ADDR+(Idx*SENSOR_DATA_SIZE), (UINT8*)&SenData, SENSOR_DATA_SIZE, CMD_END) != 0 )
	{
		return;
	}
	

	if( SenData.Byte.Option!=SENSOR_OPTION_FREAM )
	{
		return;
	}
	//DEBUGMSG(MSGINFO, "SENSOR_FPS_Set %X \r\n",sGco.InputFrame.Rate);
	switch(sGco.InputFrame.Rate)
	{
		case eFRAME_RATE_30 :  FpsNum = SENSOR_OPTION_FREAM|0x1; break;
		case eFRAME_RATE_60 :  FpsNum = SENSOR_OPTION_FREAM|0x3; break;
		case eFRAME_RATE_120 : FpsNum = SENSOR_OPTION_FREAM|0x5; break;
	}
	
#if 0
	if(sWdr.Mode==STATE_ON && sWdr.Type == eWDRTYPE_DOL3)
	{
		FpsNum = SENSOR_OPTION_FREAM|0x5;
	}
#endif

	if(CVBS_FORMAT==eCVBS_NTSC)
		FpsNum ++;

	SENSOR_Set(SenHeader.Byte.AddrFrame, SenHeader.Byte.AddrInit, FpsNum);

}


void SENSOR_Mirror_Set(UCHAR Mode)
{
	switch(Mode)
	{
		case eFLIP_OFF:			
			SENSOR_Set(SenHeader.Byte.AddrFrame, SenHeader.Byte.AddrInit, SENSOR_OPTION_FLIP_OFF); 
			break;
		case eFLIP_MIRROR:		
			SENSOR_Set(SenHeader.Byte.AddrFrame, SenHeader.Byte.AddrInit, SENSOR_OPTION_FLIP_OFF); 
			SENSOR_Set(SenHeader.Byte.AddrFrame, SenHeader.Byte.AddrInit, SENSOR_OPTION_FLIP_H);
			break;
		case eFLIP_V:			
			SENSOR_Set(SenHeader.Byte.AddrFrame, SenHeader.Byte.AddrInit, SENSOR_OPTION_FLIP_OFF); 
			SENSOR_Set(SenHeader.Byte.AddrFrame, SenHeader.Byte.AddrInit, SENSOR_OPTION_FLIP_V);
			break;
		case eFLIP_ROTATE:		
			SENSOR_Set(SenHeader.Byte.AddrFrame, SenHeader.Byte.AddrInit, SENSOR_OPTION_FLIP_H);
			SENSOR_Set(SenHeader.Byte.AddrFrame, SenHeader.Byte.AddrInit, SENSOR_OPTION_FLIP_V);
			break;
	}

}


extern void ncDrv_SENSOR_Exposure_Set_AR0140(STRUCT_AE_SET_TYPE * AeSet);


void SENSOR_Exposure_Set(STRUCT_AE_SET_TYPE * AeSet) //OMNIVISION_OV10640
{

#if 1
	switch(SenHeader.Byte.AcpID)
	{
		case 0x0302: ncDrv_SENSOR_Exposure_Set_AR0140(AeSet);break;
		//case 0x0205: SENSOR_Exposure_OV10640(AeSet);break;
		//case 0x0104: SENSOR_Exposure_Set_IMX224(AeSet);break;
	}
#endif
	
}


#if (OPTION_WDR_TYPE == WDRTYPE_SENSER)

extern UINT32 WDR_Off_Set_AR0140(void);
extern UINT32 WDR_On_Set_AR0140(void);
extern void WDR_AE_Init_AR0140(void);
extern void Debug_Viewer_WDR_AE_AR0140(void);
extern void ncDrv_SENSOR_WDR_Exposure_Set_AR0140(void);


UINT32 WDR_Off_Set(void)
{
	switch(SenHeader.Byte.AcpID)
	{
		case 0x0302: WDR_Off_Set_AR0140();break;
		
	}
	return NC_SUCCESS;
}
UINT32 WDR_On_Set(void)
{
	switch(sWdr.Type)
	{
		case eWDRTYPE_DCOMP_AR: WDR_On_Set_AR0140();break;
	}
	return NC_SUCCESS;
}

void WDR_AE_Init(void)
{
	switch(sWdr.Type)
	{
		case eWDRTYPE_DCOMP_AR: WDR_AE_Init_AR0140();break;
	}
}
void Debug_Viewer_WDR_AE(void)
{
	switch(sWdr.Type)
	{
		case eWDRTYPE_DCOMP_AR: Debug_Viewer_WDR_AE_AR0140();break;
	}
}

void ncDrv_SENSOR_WDR_Exposure_Set(UCHAR WDR_Ch)
{
	switch(sWdr.Type)
	{
		case eWDRTYPE_DCOMP_AR: ncDrv_SENSOR_WDR_Exposure_Set_AR0140();break;
	}
}


#endif//WDRTYPE_SENSER


void ncDrv_SENSOR_Initial_Set(void)
{
	SENSOR_Info_Load();
    SENSOR_Initial_Set();
    SENSOR_WDR_Off();
}


#endif//SENSOR_COMMON

