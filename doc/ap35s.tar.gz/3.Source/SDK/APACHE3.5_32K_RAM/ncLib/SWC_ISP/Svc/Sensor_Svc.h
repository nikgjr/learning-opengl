
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __SVC_SENSOR_LIB__
#define __SVC_SENSOR_LIB__

#include "Sensor_IMX224_Drv.h"
#include "Sensor_AR0140_Drv.h"
#include "Sensor_OV10640_Drv.h"

/*___________________________ Sensor Input Interface Parameter ________________________*/

typedef enum
{
    READ_PREVIOUS,
    READ_CURRENT,
}FRC_READ_TYPE;

typedef struct{
    UCHAR F_PORCH_START[eSIZE_MAX][2][2];  /* [H,V SYNC], [ON,OFF] */
    USHORT INPUT_H_TOTAL[2][eSIZE_MAX][eCVBS_FORMAT];
} STRUCT_SENSOR_INTERFACE_TYPE;
#define DONT_CARE   (FRC_READ_TYPE)0
extern const STRUCT_SENSOR_INTERFACE_TYPE sSensorInterface;

/*___________________________ Auto Exposure Parameter __________________________________*/
typedef struct{	
    USHORT  VTotalDefault;      /* SENSOR_VTOTAL_DEFAULT[current]] */
    USHORT  VTotalLine;         /* Vertical Total Line(Sens-up) */
    USHORT  ExposureLine;       /* Exposure Line */
    USHORT  TotalGain;          /* Mian Gain Value, (Dgain + Again) */
    USHORT  SensorGain;         /* Mian Gain Value, (Dgain + Again) */
}STRUCT_AE_SET_TYPE;
#if (SENSOR_SELECT == SENSOR_COMMON) 
#else
extern const UCHAR    SENSOR_DIFF_LIMIT;      /* 1 Frame dealy if (prevExposureLine-ExposureLine) > SENSOR_DIFF_LIMIT */
extern const UCHAR    SENSOR_EXPOSURE_MIN;    /* Mininum Exposure line count */
extern const USHORT   SENSOR_VTOTAL_DEFAULT[eSIZE_MAX]; /* Default value of Vertical Total line count*/
#if(SENSOR_SELECT == OMNIVISION_OV10640 && OPTION_WDR_TYPE == WDRTYPE_DCOMP_OV)
extern const USHORT   WDR_SENSOR_VTOTAL_DEFAULT[eSIZE_MAX]; /* Default value of Vertical Total line count*/
#endif
#endif
#if(SENSOR_SELECT == SENSOR_COMMON)

#define OPTION_WDR_TYPE 				WDRTYPE_SENSER


typedef struct{
    UCHAR F_PORCH_START[2][2][2];  /* [H,V SYNC], [ON,OFF] */
    USHORT INPUT_H_TOTAL[2][2][2];
} STRUCT_SENSOR_INTERFACE;


typedef union
{
	UCHAR Category[0x40];
	struct
	{
	ULONG	Name;
	USHORT	AcpID;
	USHORT	DataCount;
	
	UCHAR	AeType;
	UCHAR	UseWdrType;
	union {
		USHORT D16;
		struct {
			UCHAR Interface:	2;
			UCHAR Slave:		2;
			UCHAR MaxFps:		2;
			UCHAR MaxSize:		2;
			
			UCHAR InClk:		2;
			UCHAR CommType:		2;
			UCHAR SpiWireCnt:	1;
			UCHAR SpiAddrBankEn:1;
			UCHAR SpiMsMode:	1;
			UCHAR SpiCommDir:	1;
		} B16;
	} Info;
	UCHAR	WdrType1;
	UCHAR	WdrType2;
	UCHAR	WdrType3;
	UCHAR	WdrType4;


	USHORT	AddrInfo;
	USHORT	AddrInit;
	USHORT	AddrFrame;
	USHORT	AddrLinear;
	USHORT	AddrWDR1;
	USHORT	AddrWDR2;
	USHORT	AddrWDR3;
	USHORT	AddrWDR4;


	
	
	UCHAR	DeviceID;
	UCHAR	RESERVE1;
	
	UCHAR	DiffLimit;
	UCHAR	ExposureMin;
	USHORT  VTotDefault[2]	 ;

	STRUCT_SENSOR_INTERFACE sInterface;
	
	}Byte;
}SENSOR_HEADER;
typedef union
{
	UCHAR Category[0x5];
	struct
	{
	UCHAR	Option;
	USHORT	Addr;
	USHORT	Value;
	}Byte;
}SENSOR_DATA;

extern SENSOR_HEADER SenHeader __attribute__ ((aligned (8)));
//extern SENSOR_DATA SenData;

#define SENSOR_INTERFACE_DATA	SenHeader.Byte.sInterface
#define SENSOR_DIFF_LIMIT		SenHeader.Byte.DiffLimit
#define SENSOR_EXPOSURE_MIN		SenHeader.Byte.ExposureMin
#define SENSOR_VTOTAL_DEFAULT	SenHeader.Byte.VTotDefault
	

void SENSOR_Write(void);
void SENSOR_Info_Load(void);
void SENSOR_Initial_Set(void);
void SENSOR_WDR_Off(void);
void SENSOR_WDR_On(void);
void SENSOR_FPS_Set(void);
void SENSOR_Mirror_Set(UCHAR Mode);





#define SENSOR_HEADER_ADDR 0x53000 // ~0x54FFF
#define SENSOR_HEADER_SIZE		0x40
#define SENSOR_DATA_ADDR (SENSOR_HEADER_ADDR+SENSOR_HEADER_SIZE)
#define SENSOR_DATA_SIZE		0x5

#define SENSOR_OPTION_RESET 0xF1
#define SENSOR_OPTION_DELAY 0xF2
#define SENSOR_OPTION_WAIT 0xF3
#define SENSOR_OPTION_READ 0xF4



#define SENSOR_OPTION_END 0xFF

#define SENSOR_OPTION_INFO        0x10
#define SENSOR_OPTION_INFO2       0x20
#define SENSOR_OPTION_AE	      0x30
#define SENSOR_OPTION_FREAM       0x40

#define SENSOR_OPTION_FLIP_OFF    0x4D
#define SENSOR_OPTION_FLIP_H	  0x4E
#define SENSOR_OPTION_FLIP_V      0x4F

#define SENSOR_OPTION_LINEAR  	  0x60
#define SENSOR_OPTION_DFRAME_1M   0x61
#define SENSOR_OPTION_DFRAME_2M   0x62
#define SENSOR_OPTION_DOL2   	  0x63
#define SENSOR_OPTION_DOL3   	  0x64
#define SENSOR_OPTION_DOL3to2     0x65
#define SENSOR_OPTION_LWDR2   	  0x66
#define SENSOR_OPTION_LWDR3       0x67
#define SENSOR_OPTION_DCOMP_OV    0x68
#define SENSOR_OPTION_DCOMP_AR    0x69
#endif

#if (SENSOR_SELECT == SENSOR_DEFAULT) 
    /* 1. SENSOR COMMON INTERFACE */

    #define SENSOR_INTERFACE                INPUT_PARALLEL      /* INPUT_PARALLEL | INPUT_LVDS          (Video Transfer Type) */
    #define SENSOR_SLAVE                    NO                  /* YES | NO                             (HD,VD Sync generation from sensor) */
    #define SENSOR_MAX_FPS                  FPS_MAX_30P         /* FPS_MAX_30P | FPS_MAX_60P            (Sensor max frame rate) */
    #define SENSOR_MAX_SIZE                 SIZE_MAX_720        /* SIZE_MAX_720 | SIZE_MAX_1080         (Sensor max frame size) */
    #define SENSOR_ICLK                     SENSOR_ICLK_27M     /* SENSOR_ICLK_27M | SENSOR_ICLK_37p12M (Sensor input clock) */
    #define SENSOR_COMM_TYPE                SENSOR_COMM_I2C     /* SENSOR_COMM_I2C | SENSOR_COMM_SPI    (Sensor communication type) */
    #define SENSOR_ACP_ID                   0x0000              /* Refer to A-CP_Camera_Manufacture_SensorInfor.xls */

    /* 2. SENSOR_COMM_TYPE = SENSOR_COMM_I2C */
    #define I2C_DEVICE_ID                   0x6C                /* Refer to sensor datasheet            (SENSOR DEVICE ID) */
    #define I2C_ADDRESS_SIZE                SIZE_2_BYTE         /* SIZE_1_BYTE | SIZE_2_BYTE            (ADDR SIZE) */
    #define I2C_DATA_SIZE                   SIZE_1_BYTE         /* SIZE_1_BYTE | SIZE_2_BYTE            (DATA SIZE) */

    /* 3. SENSOR_COMM_TYPE = SENSOR_COMM_SPI */
    #define SPI_WIRE_COUNT                  SPI_WIRE_4LANE      /* SPI_WIRE_3LANE | SPI_WIRE_4LANE      (SPI interconnection type) */
	#define SPI_ADDRESS_BANK_EN             YES				    /* YES | NO                             (Mostly SONY Sensors: BANK|ADDR) */
    #define SPI_ADDRESS_SIZE                SIZE_1_BYTE		    /* SIZE_1_BYTE | SIZE_2_BYTE            (ADDR SIZE) */
    #define SPI_DATA_SIZE                   SIZE_1_BYTE         /* SIZE_1_BYTE | SIZE_2_BYTE            (DATA SIZE) */
    #define SPI_MS_MODE                     SPI_MODE_MASTER     /* SPI_MODE_MASTER | SPI_MODE_LSAVE                 */
    #define SPI_COMM_DIRECTION              COMM_LSB_FIRST      /* COMMMSB_FIRST | COMM_LSB_FIRST                   */

    /* 4. SENSOR MISCELLANEOUSE OPTIONS */
    #define OPTION_LDC_EN                   NO
    #define OPTION_WDR_TYPE                 WDRTYPE_OFF
#endif

#endif  // __MW_SENSOR_LIB__

