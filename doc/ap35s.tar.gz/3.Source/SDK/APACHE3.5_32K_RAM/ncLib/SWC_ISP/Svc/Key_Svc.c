/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Key_Svc.h"
#include "Jig_Svc.h"
#include "NICP_Svc.h"
#include "System_Drv.h"
#include "OSD_Drv.h"




/*******************************************************************************
*	Define parameter
*******************************************************************************/
//-------------------------------------------------------------------------
//	Key Input Status 
//-------------------------------------------------------------------------

STRUCT_KEY	    sAppKey;
STRUCT_RS485	sRS485;

enum{
	MENU_START = 0,
	MENU_SET
};

#define KEY_COAX_EMPTY      0x1F
#define KEY_COAX_SET        0x0F
#define KEY_COAX_LEFT       0x1E
#define KEY_COAX_RIGHT      0x1D
#define KEY_COAX_UP         0x1B
#define KEY_COAX_DOWN       0x17



/********************************************************************************
* Function Name : APP_GPIOKey_Get()
* Description: Function Run
********************************************************************************/
#ifdef KEY_GPIO
void APP_GPIOKey_Get(void);
#endif

/********************************************************************************
* Function Name :  ncSvc_Key_CVBS_CoaxialKey_Get()
* Description: Function Run
********************************************************************************/
void  ncSvc_Key_CVBS_CoaxialKey_Get(void);

/********************************************************************************
* Function Name :  ncSvc_Key_AHD_CoaxialKey_Get()
* Description: Function Run
********************************************************************************/
void  ncSvc_Key_AHD_CoaxialKey_Get(void);

/********************************************************************************
* Function Name :  ncSvc_Key_ADCKey_Get()
* Description: Function Run
********************************************************************************/
void  ncSvc_Key_ADCKey_Get(void);


UCHAR* ncSvc_KeyValue_Get(void)
{
	return (UCHAR*)&sAppKey.Value;
}
void ncSvc_KeyValue_Set(UCHAR value)
{
	sAppKey.Value = value;
}

UCHAR* ncSvc_KeyHotKeyLong_Get(void)
{
	return (UCHAR*)&sAppKey.HotKeyLong;
}
void ncSvc_KeyHotKeyLong_Set(UCHAR value)
{
	sAppKey.HotKeyLong = value;
}


void ncSvc_KeyInitialize_Set(void)
{
	sAppKey.Value           = KEY_DEF;
	sAppKey.ADCRmtKey	    = KEY_DEF;
	sRS485.keyValue 	    = KEY_DEF;
	sMwNICP.KeyValue        = KEY_DEF;
	
	sAppKey.Set             = MENU_START;
	sAppKey.Cnt             = 0;
	stJigInfo.KeyValue    = KEY_DEF;
		
	#ifdef KEY_GPIO
	sAppKey.Gpio.D8         = KEY_DEF;
	#endif

	#ifdef KEY_COAXIAL
	sHalCoax.CoaxKey        = KEY_DEF;
	#endif

}

#ifdef KEY_GPIO
void APP_GPIOKey_Get(void)
{
	if(sScr.Byte.Reg_0xE1FB.B8.GPIOKeyEnable==1)
	{
		sAppKey.Gpio.Bit8.Left 	= HAL_GPIO_Get(sHalGpio.LeftKeyInput) >> 3;
		sAppKey.Gpio.Bit8.Right = HAL_GPIO_Get(sHalGpio.RightKeyInput) >> 3;
		sAppKey.Gpio.Bit8.Up 	= HAL_GPIO_Get(sHalGpio.UpKeyInput) >> 3;
		sAppKey.Gpio.Bit8.Down 	= HAL_GPIO_Get(sHalGpio.DownKeyInput) >> 3;
		sAppKey.Gpio.Bit8.Set 	= HAL_GPIO_Get(sHalGpio.SetKeyInput) >> 3;
	}
	else sAppKey.Gpio.D8 = KEY_DEF;
}
#endif

void  ncSvc_Key_AHD_CoaxialKey_Get(void)
{
	UCHAR CountA, CountB;
	UCHAR InputData = KEY_COAX_EMPTY;
    UCHAR Data00, Data01, Data02, Data10, Data11, Data12;
	// Start Line
	//[DATA0] [DATA1] [DATA2] [DATA3] [DATA4] [DATA5]
	//   0x92      0x49     SetKey      ---         ---        ---  

	// Start Line + 1
	//[DATA0] [DATA1] [DATA2] [DATA3] [DATA4] [DATA5]
	//   0x92   UpDown  LeftRight    ---         ---        ---  

	Data00 = sHalCoax.Data[0][0];
	Data01 = sHalCoax.Data[0][1];
	Data02 = sHalCoax.Data[0][2];
	Data10 = sHalCoax.Data[1][0];
	Data11 = sHalCoax.Data[1][1];
	Data12 = sHalCoax.Data[1][2];
	
	if(Data00 == 0x92 && Data10 == 0x92)
	{
		if(Data01 == 0x49 & Data02 == 0x34)		    InputData = KEY_COAX_SET;
		else if(Data11 == 0x4D & Data12 == 0x24)	InputData = KEY_COAX_UP;
		else if(Data11 == 0x69 & Data12 == 0x24)	InputData = KEY_COAX_DOWN;
		else if(Data11 == 0x49 & Data12 == 0xA4)	InputData = KEY_COAX_LEFT;
		else if(Data11 == 0x49 & Data12 == 0x34)	InputData = KEY_COAX_RIGHT;
		else										InputData = KEY_COAX_EMPTY;
	}
	else 
	{
		if(Data00 == 0xDB && Data01 == 0x6D && Data10 == 0xDB)
		{
			if((Data02 == 0xB6) &(Data11 == 0x6F) &(Data12 == 0xB6))		InputData = KEY_COAX_UP;
			else if((Data02 == 0xB6) &(Data11 == 0x7D) & (Data12 == 0xB6))	InputData = KEY_COAX_DOWN;
			else if((Data02 == 0xB6) &(Data11 == 0x6D) & (Data12 == 0xF6))	InputData = KEY_COAX_LEFT;
			else if((Data02 == 0xB6) &(Data11 == 0x6D) & (Data12 == 0xBE))	InputData = KEY_COAX_RIGHT;
			else if((Data02 == 0xBE) &(Data11 == 0x6D) & (Data12 == 0xB6))	InputData = KEY_COAX_SET;
			else															InputData = KEY_COAX_EMPTY;
		}
		else
		{
			if((Data00 == 0xAA) &(Data01 == 0xAA) & (Data10 == 0xAA)&(Data11 == 0xEA))		InputData = KEY_COAX_UP;
			else if((Data00 == 0xAA) &(Data01 == 0xAA) & (Data10 == 0xAB)&(Data11 == 0xAA))	InputData = KEY_COAX_DOWN;
			else if((Data00 == 0xAA) &(Data01 == 0xAA) & (Data10 == 0xAA)&(Data11 == 0xBA))	InputData = KEY_COAX_LEFT;
			else if((Data00 == 0xAA) &(Data01 == 0xAA) & (Data10 == 0xAA)&(Data11 == 0xAE))	InputData = KEY_COAX_RIGHT;
			else if((Data00 == 0xAA) &(Data01 == 0xAE) & (Data10 == 0xAA)&(Data11 == 0xAA))	InputData = KEY_COAX_SET;

			/* [2015/01/15] Jong-Hyun, Choi : STD-1 */
			//{
			else if((Data00 == 0xAA) &(Data01 == 0xAA) & (Data10 == 0xAA)&(Data11 == 0xD5))	InputData = KEY_COAX_UP;
			else if((Data00 == 0xAA) &(Data01 == 0xAA) & (Data10 == 0xAB)&(Data11 == 0x55))	InputData = KEY_COAX_DOWN;
			else if((Data00 == 0xAA) &(Data01 == 0xAA) & (Data10 == 0xAA)&(Data11 == 0xB5))	InputData = KEY_COAX_LEFT;
			else if((Data00 == 0xAA) &(Data01 == 0xAA) & (Data10 == 0xAA)&(Data11 == 0xAD))	InputData = KEY_COAX_RIGHT;
			else if((Data00 == 0xAA) &(Data01 == 0xAD) & (Data10 == 0xAA)&(Data11 == 0xAA))	InputData = KEY_COAX_SET;			
			//}
			else																			InputData = KEY_COAX_EMPTY;
		}
	}

	if(rSWReg.Category.PROTOCOL.Reg.COAX_OSD_VIEWER)
	{
		for(CountA=0; CountA<6; CountA++)
		{
		    APP_OSDPrint_Hex(14, 3*CountA+1, sHalCoax.Data[0][CountA]);
		    APP_OSDPrint_Hex(15, 3*CountA+1, sHalCoax.Data[1][CountA]);
		}
	}
			
	sHalCoax.CoaxKey = InputData & sHalCoax.CoaxPreKey;

	//Coax Buffer Clear
	for(CountA=0; CountA< 4; CountA++)
	{
		for(CountB=0; CountB< 6; CountB++)
		{
			sHalCoax.Data[CountA][CountB] =0;
		}
	}

	sHalCoax.CoaxPreKey = InputData;	
}


/* [2014/12/24] Jong-Hyun, Choi : STD-1 */
void  ncSvc_Key_CVBS_CoaxialKey_Get(void)
{
	// MSB First Task....
	UCHAR CountA, CountB;
	UCHAR InputData;
	UCHAR Data00, Data01, Data02, Data03, Data04, Data05;
	
	if(sHalCoax.Data[0][0] == 0x00)
	{
		 /* [2014/8/27] hyundong : 1-1 */
		//{	
		 sHalCoax.Data[0][0] = sHalCoax.Data[2][0];
		 sHalCoax.Data[0][1] = sHalCoax.Data[2][1];
		 sHalCoax.Data[0][2] = sHalCoax.Data[2][2];
		 sHalCoax.Data[0][3] = sHalCoax.Data[2][3];
		 sHalCoax.Data[0][4] = sHalCoax.Data[2][4];
		 sHalCoax.Data[0][5] = sHalCoax.Data[2][5];
		 //}
	}

	InputData = KEY_COAX_EMPTY;

	Data00 = sHalCoax.Data[0][0];
	Data01 = sHalCoax.Data[0][1];
	Data02 = sHalCoax.Data[0][2];
	Data03 = sHalCoax.Data[0][3];
	Data04 = sHalCoax.Data[0][4];
	Data05 = sHalCoax.Data[0][5];
	
	if(Data00 == 0x92)
	{
		if(Data01 == 0x49 && Data03 == 0x92)
		{
			//Intrix
			if((Data02 == 0x24) && (Data04 == 0x49) && (Data05 == 0xA0))			InputData = KEY_COAX_LEFT;
			else if((Data02 == 0x24) && (Data04 == 0x49) && (Data05 == 0x30))		InputData = KEY_COAX_RIGHT;
			else if((Data02 == 0x24) && (Data04 == 0x4D) && (Data05 == 0x20))		InputData = KEY_COAX_UP;
			else if((Data02 == 0x24) && (Data04 == 0x69) && (Data05 == 0x20))		InputData = KEY_COAX_DOWN;
			else if((Data02 == 0x34) && (Data04 == 0x49) && (Data05 == 0x20))		InputData = KEY_COAX_SET;
			else if((Data02 == 0x24) && (Data04 == 0x49) && (Data05 == 0x20))		InputData = KEY_COAX_EMPTY;
			//DongYang
			else if((Data02 == 0x24) && (Data04 == 0x49) && (Data05 == 0xA4))		InputData = KEY_COAX_LEFT;
			else if((Data02 == 0x24) && (Data04 == 0x49) && (Data05 == 0x34))		InputData = KEY_COAX_RIGHT;
			else if((Data02 == 0x24) && (Data04 == 0x4D) && (Data05 == 0x24))		InputData = KEY_COAX_UP;
			else if((Data02 == 0x24) && (Data04 == 0x69) && (Data05 == 0x24))		InputData = KEY_COAX_DOWN;
			else if((Data02 == 0x34) && (Data04 == 0x49) && (Data05 == 0x24))		InputData = KEY_COAX_SET;
			//Default
			else							                                        InputData = KEY_COAX_EMPTY;

		}

		//RJ
  		if(InputData == KEY_COAX_EMPTY)
		{
			if(Data01 == 0x49 && Data02 == 0x24 && Data03 == 0x92 && Data04 == 0x5D && Data05 == 0x24)		InputData = KEY_COAX_UP;
			else if(Data01 == 0x49 && Data02 == 0x24 && Data03 == 0x92 && Data04 == 0x5A && Data05 == 0x48)	InputData = KEY_COAX_UP;
			else if(Data01 == 0x49 && Data02 == 0x25 && Data03 == 0x24 && Data04 == 0xD2 && Data05 == 0x48)	InputData = KEY_COAX_DOWN;
			else if(Data01 == 0x49 && Data02 == 0x24 && Data03 == 0x92 && Data04 == 0x59 && Data05 == 0xA4)	InputData = KEY_COAX_LEFT;
			else if(Data01 == 0x49 && Data02 == 0x24 && Data03 == 0x92 && Data04 == 0x53 && Data05 == 0x48)	InputData = KEY_COAX_LEFT;
			else if(Data01 == 0x49 && Data02 == 0x24 && Data03 == 0x92 && Data04 == 0x59 && Data05 == 0x34)	InputData = KEY_COAX_RIGHT;
			else if(Data01 == 0x49 && Data02 == 0x24 && Data03 == 0x92 && Data04 == 0x52 && Data05 == 0x68)	InputData = KEY_COAX_RIGHT;
			else if(Data01 == 0x59 && Data02 == 0x35 && Data03 == 0x92 && Data04 == 0x49 && Data05 == 0x24)	InputData = KEY_COAX_SET;
			else if(Data01 == 0x52 && Data02 == 0x6A && Data03 == 0x49 && Data04 == 0x24 && Data05 == 0x90)	InputData = KEY_COAX_SET;
			else																							InputData = KEY_COAX_EMPTY;
		}
	}
	else
	{
			if(Data00 == 0xB6 && Data01 == 0xDB && Data02 == 0x6D && Data03 == 0xB6 && Data04 == 0xDC && Data05 == 0xD8)		InputData = KEY_COAX_UP;
			else if(Data00 == 0xB6 && Data01 == 0xDB && Data02 == 0x6D && Data03 == 0x6D && Data04 == 0xE6 && Data05 == 0xD8)	InputData = KEY_COAX_DOWN;
			else if(Data00 == 0xB6 && Data01 == 0xDB && Data02 == 0x6D && Data03 == 0xB6 && Data04 == 0xD7 && Data05 == 0x98)	InputData = KEY_COAX_LEFT;
			else if(Data00 == 0xB6 && Data01 == 0xDB && Data02 == 0x6D && Data03 == 0xB6 && Data04 == 0xD6 && Data05 == 0xF0)	InputData = KEY_COAX_RIGHT;
			else if(Data00 == 0xB6 && Data01 == 0xD6 && Data02 == 0xF2 && Data03 == 0xDB && Data04 == 0x6D && Data05 == 0xB0)	InputData = KEY_COAX_SET;
			else																												InputData = KEY_COAX_EMPTY;
	}
	
	if(rSWReg.Category.PROTOCOL.Reg.COAX_OSD_VIEWER)
	{
		for(CountA=0; CountA<6; CountA++)
		{
		    APP_OSDPrint_Hex(14, 3*CountA+1, sHalCoax.Data[0][CountA]);
		    APP_OSDPrint_Hex(15, 3*CountA+1, sHalCoax.Data[1][CountA]);
		}
 	}

	sHalCoax.CoaxKey = InputData & sHalCoax.CoaxPreKey;

	//Coax Buffer Clear
	for(CountA=0; CountA< 4; CountA++)
	{
		for(CountB=0; CountB< 6; CountB++)
		{
			sHalCoax.Data[CountA][CountB] =0;
		}
	}

	sHalCoax.CoaxPreKey = InputData;	
}

#define ADC_CHANNEL_KEY  eADC_CH_0
void  ncSvc_Key_ADCKey_Get(void)
{
    UCHAR   AdcKeyMargine = rSWReg.Category.KEYINPUT.Reg.ADC_KEY_VALUE_MARGINE;
	USHORT	AdcKeyValue = 	ncDrv_ADCValue_Get(ADC_CHANNEL_KEY);
	UCHAR	AdcKeyDiff;
	static USHORT	prevAdcKeyValue=0xAA;
	static UCHAR	InputCnt=0;
	
	if(rSWReg.Category.KEYINPUT.Reg.ADC_EN==1)
	{
		if(rSWReg.Category.KEYINPUT.Reg.ADC_TEST_VIEW)
		{	
#if 0
			APP_OSDPrint_Hex(1, 3, sMwSystem.ADCValue[0]);	//AD Key Input Value
			APP_OSDPrint_Hex(1, 6, sMwSystem.ADCValue[1]);// CDS Input Value
			APP_OSDPrint_Hex(1, 9, sMwSystem.ADCValue[2]);
			APP_OSDPrint_Hex(1, 12, sMwSystem.ADCValue[3]);

			APP_OSDPrint_Dec(1, 23, _abs(sMwSystem.ADCValue[1],0xFF));
			APP_OSDPrint_String(1, 20, (UCHAR*)"C0 /");
			APP_OSDPrint_Dec(2, 23, sMwSystem.ADCValue[1]);
			APP_OSDPrint_String(2, 20, (UCHAR*)"C1 /");
#endif
		}
		
		if(AdcKeyValue >= rSWReg.Category.KEYINPUT.Reg.ADC_DEFAULT_VALUE)
		{
			sAppKey.ADCRmtKey = KEY_DEF;
			return;
		}

		if(rSWReg.Category.KEYINPUT.Reg.ADC_SET_KEY_MODE == ON)
		{
		    AdcKeyDiff = _abs(AdcKeyValue, prevAdcKeyValue);
			
			prevAdcKeyValue = AdcKeyValue;
			
			if(AdcKeyDiff > 15)	AdcKeyValue = 0xFF;

			if(AdcKeyValue < AdcKeyMargine)
			{	
			    if(IsInRage(AdcKeyValue, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_SET, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_SET+AdcKeyMargine))              sAppKey.ADCRmtKey=PORT_BIT4;
				else if(IsInRage(AdcKeyValue, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_UP, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_UP+AdcKeyMargine))			sAppKey.ADCRmtKey=PORT_BIT2;
				else if(IsInRage(AdcKeyValue, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_DOWN, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_DOWN+AdcKeyMargine))		sAppKey.ADCRmtKey=PORT_BIT3;
				else if(IsInRage(AdcKeyValue, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_LEFT, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_LEFT+AdcKeyMargine))		sAppKey.ADCRmtKey=PORT_BIT0;
				else if(IsInRage(AdcKeyValue, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_RIGHT, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_RIGHT+AdcKeyMargine))	    sAppKey.ADCRmtKey=PORT_BIT1;
				else sAppKey.ADCRmtKey = KEY_DEF;
			}	

			else if(IsInRage(AdcKeyValue, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_SET-AdcKeyMargine, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_SET+AdcKeyMargine))		sAppKey.ADCRmtKey=PORT_BIT4;
			else if(IsInRage(AdcKeyValue, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_UP-AdcKeyMargine, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_UP+AdcKeyMargine))			sAppKey.ADCRmtKey=PORT_BIT2;
			else if(IsInRage(AdcKeyValue, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_DOWN-AdcKeyMargine, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_DOWN+AdcKeyMargine))	    sAppKey.ADCRmtKey=PORT_BIT3;
			else if(IsInRage(AdcKeyValue, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_LEFT-AdcKeyMargine, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_LEFT+AdcKeyMargine))		sAppKey.ADCRmtKey=PORT_BIT0;
			else if(IsInRage(AdcKeyValue, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_RIGHT-AdcKeyMargine, rSWReg.Category.KEYINPUT.Reg.ADC_KEY_RIGHT+AdcKeyMargine))	sAppKey.ADCRmtKey=PORT_BIT1;
			else    sAppKey.ADCRmtKey = KEY_DEF;		
		}
		else
		{
			sMwMenu.PosX = sMwOsd.CenterPosX;
			sMwMenu.PosY = sMwOsd.CenterPosY;
			sMwMenu.Style = 2;
			sMwMenu.Color = 2;
			sMwMenu.StringNum = MAXCHAR_NUM;

			APACHE_SYS_mDelay(1000);
			
			switch(InputCnt)
			{
#if 0
				case 0:
					rSWReg.Category.KEYINPUT.Reg.ADC_KEY_LEFT = AdcKeyValue;
					sMwMenu.FontIndex = F_RIGHT_CURSOR_CHAR;
					break;
				case 1:
					rSWReg.Category.KEYINPUT.Reg.ADC_KEY_RIGHT = AdcKeyValue;
					sMwMenu.FontIndex = F_UP_CURSOR_CHAR;;
					break;
				case 2:
					rSWReg.Category.KEYINPUT.Reg.ADC_KEY_UP = AdcKeyValue;
					sMwMenu.FontIndex = F_DOWN_CURSOR_CHAR;;
					break;
				case 3:
					rSWReg.Category.KEYINPUT.Reg.ADC_KEY_DOWN = AdcKeyValue;
					sMwMenu.FontIndex = F_ENTER_CURSOR_CHAR;
					break;
				case 4:
					rSWReg.Category.KEYINPUT.Reg.ADC_KEY_SET = AdcKeyValue;

					sMwMenu.PosX = sMwOsd.CenterPosX-5;
					sMwMenu.FontIndex=F_WAIT_CHAR;
					ncDrv_OSDClear_Set();
					break;
#endif
			}

			ncDrv_OSDString_Set();
			
			while(1)
			{   
				AdcKeyValue = ncDrv_ADCValue_Get(ADC_CHANNEL_KEY);
				if(AdcKeyValue>=rSWReg.Category.KEYINPUT.Reg.ADC_DEFAULT_VALUE)	break;
			}

			if(InputCnt==4)
			{
				InputCnt=0;
				rSWReg.Category.KEYINPUT.Reg.ADC_SET_KEY_MODE = 0;
//				MW_Register_Save(ISP_USER_AREA);

				ncDrv_OSDClear_Set();
			}
			else
			{
				InputCnt++;
			}
		}
	}
	else
	{
		sAppKey.ADCRmtKey = KEY_DEF;
	}
}

void ncSvc_Key_Get(void)
{
	//UCHAR Setkey = KEY_DEF;
	UCHAR InputKeyTmp = 0x00;

	static UCHAR OldKeyData;
	static UCHAR OldKeyData1;
	static UCHAR KeyCount1;
	static UCHAR KeyCount;
	static UCHAR KeySpeed;
	
	#ifdef KEY_GPIO
	APP_GPIOKey_Get();
	#endif
	 ncSvc_Key_ADCKey_Get();

#ifdef KEY_COAXIAL
	/* [2015/01/16] JWLee : [STD]-01 */
    if(sGco.MonitorOutput == eMONITOR_AHD)   ncSvc_Key_AHD_CoaxialKey_Get();
	else								     ncSvc_Key_CVBS_CoaxialKey_Get();
#endif

	InputKeyTmp = sRS485.keyValue & sAppKey.ADCRmtKey & sHalCoax.CoaxKey & stJigInfo.KeyValue & sMwNICP.KeyValue & KEY_DEF;

	sRS485.keyValue = KEY_DEF;
	stJigInfo.KeyValue  = KEY_DEF;	
	sMwNICP.KeyValue = KEY_DEF;
	sAppKey.ADCRmtKey = KEY_DEF;
	
    sAppKey.HotKeyLong = InputKeyTmp;

	if(OldKeyData1 == InputKeyTmp)
	{
		KeyCount1 += 1;
		if((KeyCount1 % 5)==0)	{if(KeySpeed>0)	KeySpeed-= 5;}
	}
	else
	{
		KeyCount1 = 0;
		KeySpeed = rSWReg.Category.KEYINPUT.Reg.LONG_KEY_SPEED;
		OldKeyData1 = InputKeyTmp;
	}

	if(OldKeyData == InputKeyTmp)
	{
		KeyCount += 1;
		if(KeyCount > KeySpeed)
		{
			if(KEY_SYSTEM_SET != InputKeyTmp)	OldKeyData = (~InputKeyTmp);
		}
		sAppKey.Value = KEY_EMPTY;
		return;
	}
	else
	{
		KeyCount = 0;
		OldKeyData = InputKeyTmp;

		switch(InputKeyTmp)
		{
			case KEY_SYSTEM_SET: 	sAppKey.Value = KEY_SET; 		break;
			case KEY_SYSTEM_UP:		sAppKey.Value = KEY_UP;			break;
			case KEY_SYSTEM_DOWN:	sAppKey.Value = KEY_DOWN;		break;
			case KEY_SYSTEM_LEFT:	sAppKey.Value = KEY_LEFT;		break;
			case KEY_SYSTEM_RIGHT:	sAppKey.Value = KEY_RIGHT;		break;
			default:				sAppKey.Value = KEY_EMPTY;	break;
		}
	}
	return;
}


void ncSvc_RegKey_Get(void)
{
    switch(rSWReg.Category.KEYINPUT.Reg.KEY_VALUE)
    {
    	case KEY_SET: 	sMwNICP.KeyValue = KEY_SYSTEM_SET;		break;
    	case KEY_UP:	sMwNICP.KeyValue = KEY_SYSTEM_UP;		break;   
    	case KEY_DOWN: 	sMwNICP.KeyValue = KEY_SYSTEM_DOWN;		break;
    	case KEY_LEFT:	sMwNICP.KeyValue = KEY_SYSTEM_LEFT;		break;
    	case KEY_RIGHT: sMwNICP.KeyValue = KEY_SYSTEM_RIGHT;	break;
        default :		sMwNICP.KeyValue = KEY_DEF;				break; 
    }
}
