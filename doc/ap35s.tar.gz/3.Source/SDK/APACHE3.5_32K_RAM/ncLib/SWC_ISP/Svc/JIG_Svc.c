/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : JIG_Svc.c
*
*  @brief   : This file is JIG controller application support package source
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Drv_GlobalHeader.h"
#include "ISP_Drv.h"
#include "Category_Drv.h"
#include "System_Drv.h"

#include "../../SWC_Peripheral\Drv\UART\Uart_Drv.h"



#if 0

#include "APACHE35.h"
#include "FlashMemoryMap.h"

#include "Intc_Lib.h"
#include "Uart_Lib.h"
#include "Debug_Lib.h"
#include "ISP_Lib.h"
#include "JIG_Lib.h"
#include "SWReg_Lib.h"

#include "JIG_Svc.h"

#include "I2C_Lib.h"
#endif



/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define PRODUCT_NAME            "#APACHE.5\r"
#define FIRMWARE_VERISON        "#APACHE.5\r"

#define VERISON            "#32K_RAM\r"


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

UARTInfo_ST stUartInfo;
JIGInfo_ST stJigInfo;

UINT8 RdBuffer[40];
UINT8 WrBuffer[40];

#ifdef APACHE2p8_JIG

STRUCT_HAL_UART sHalUart;

UCHAR cmd[20];
UCHAR rdata[60];
UCHAR ISP_R[5]			= "ISPR?";
UCHAR ISP_W[5]			= "ISPW=";
UCHAR ISP_RL[6]			= "ISPRL?";
UCHAR ISP_WL[6]			= "ISPWL=";

UCHAR ISP_R2[6]			= "ISPR2?";
UCHAR ISP_W2[6]			= "ISPW2=";

UCHAR SENSOR_R[8]		= "SENSORR?";
UCHAR SENSOR_W[8]		= "SENSORW=";

UCHAR HDMI_R[6]			= "HDMIR?";
UCHAR HDMI_W[6]		= "HDMIW=";

/*
UCHAR SERIALIZER_R[12]	= "SERIALIZERR?";
UCHAR SERIALIZER_W[12]	= "SERIALIZERW=";
*/

UCHAR CCMOPD[8]		= "CCMOPDR?";
UCHAR GCMOPD[8]		= "GCMOPDR?";

UCHAR FIRMWARE[8]		= "FIRMWARE";
UCHAR PRODUCT[7]		= "PRODUCT";

UCHAR OSDKEY[4] 		= "OKC=";

UCHAR DEBUG[5]			= "DEBUG";

//UCHAR LVDS[4]			= "LVDS";

UCHAR AFDATA[6]			= "AFDATA";

UCHAR DOWN_LOAD[9]	    = "DOWNLOAD=";

UCHAR RAWSTILL[9]		= "RAWSTILL=";/* [2014/09/23] sky : [STD]-01 */

UCHAR OPDBOX[8]			= "OPDBOXR?";	/* CCMOPDR */
UCHAR CSCMR[6]			= "CSCMR?";		/* CSC MATRIX */
UCHAR CSCMW[6]			= "CSCMW=";		/* CSC MATRIX */

UCHAR DDR_W[5]			= "DDRW=";
UCHAR DDR_R[5]			= "DDRR?";

UCHAR FPORT_EN[6]		= "FPORT=";
UCHAR SYSTEM[7]		= "SYSTEM=";

UCHAR ISP_RESET[4]		= "RST=";

UCHAR BAUDTEST[2]		= "TX";


//UCHAR FRL[4]				= "FRL?";

//UCHAR MEMORYCALC[10]	= "MEMORYCALC";
#endif


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
void DataRead_AE(void);
void DataRead_AWB(void);

void UART_Common(void)
{
	UCHAR InputData = 0;

	InputData = (UINT8)ncDrv_UART_getchar(UART1);

	if(sHalUart.RxStart  == 0)
	{
		if(InputData == '#')
		{
			sHalUart.CmdProcess = 1;
			sHalUart.RxStart = 1;
			sHalUart.RxInputCount = 0;
			sHalUart.RxTempBuffer[sHalUart.RxInputCount] = InputData ;
			sHalUart.RxInputCount++;
			sHalUart.Command=0;
		}
	}
	else
	{
		if(InputData != 0xFF)
		{
			sHalUart.RxTempBuffer[sHalUart.RxInputCount] = InputData ;
			sHalUart.RxInputCount++;

			if( InputData == '\r' )
			{
				sHalUart.RxStart = 0;
				sHalUart.Command  = TRUE;
			}
		}
	}

}


INT32 ncSvc_JIG_CommandMain(eUART_CH channel)
{
    int ret = NC_SUCCESS;

	if(sHalUart.Command)
    {
        ncSvc_Jig_Task();
        sHalUart.Command = 0;
    }

    return ret;
}


INT32 ncSvc_Jig_Task(void)
{
	UCHAR 	uc_data1, uc_data2, uc_data3, i, j, isp_rw_reg[20];
	USHORT	Address = 0;
	

	if(Cmd_Compare((UCHAR *)ISP_R, 5))
	{
		uc_data1 = Ascii_To_Hex_2byte(sHalUart.RxTempBuffer[6], sHalUart.RxTempBuffer[7]);	// bank
		uc_data2 = Ascii_To_Hex_2byte(sHalUart.RxTempBuffer[8], sHalUart.RxTempBuffer[9]);	// addr

		Address = (uc_data1 << 8) | uc_data2;

        if((uc_data1 >> 4) == 0x08)
		{
			Address = Address - STATUS_REG_BASE;

			uc_data3 = ncLib_SWR_Read(Address);
		}
		else // ETC...
		{
			Address = uc_data1;
			Address = (Address << 8) | uc_data2;

			uc_data3 = REGRW8(APACHE_ISP_BASE, Address);
		}

        //ncLib_JIG_Printf("#data=%02x\r", uc_data3);
        ncDrv_UART_print_string(UART1, (char *)"#data=");// 00\r");
        ncDrv_UART_printhex(UART1 , uc_data3);
		ncDrv_UART_print_string(UART1, (char *)"\r");
	}
	else if(Cmd_Compare((UCHAR *)ISP_RL, 6))
	{
		uc_data1 = Ascii_To_Hex_2byte(sHalUart.RxTempBuffer[7], sHalUart.RxTempBuffer[8]);	// addr
		uc_data2 = Ascii_To_Hex_2byte(sHalUart.RxTempBuffer[9], sHalUart.RxTempBuffer[10]);	// addr

        Address = (uc_data1 << 8) | uc_data2;

        if((uc_data1 >> 4) == 0x08)
		{
			Address = Address - STATUS_REG_BASE;

			for(i=0; i<16; i++)
			{
				isp_rw_reg[i] = ncSvc_JIG_StatusReg_Read(Address+i);
			}
		}
		else
		{
			for(i=0; i<16; i++)
			{	
				isp_rw_reg[i] = REGRW8(APACHE_ISP_BASE, Address + i);
			}
		}

		isp_rw_reg[16] = 0;

		 ncDrv_UART_print_string(UART1, (char *)"#data=");// 00\r");
		
		for(i=0; i<16; i++)
		{
			 ncDrv_UART_printhex(UART1 , isp_rw_reg[i]);
			isp_rw_reg[16] += isp_rw_reg[i];	// checksum
		}
		
		ncDrv_UART_print_string(UART1, (char *)"\r");
	}
	
	else if(Cmd_Compare((UCHAR *)ISP_W, 5))
	{
		uc_data1 = Ascii_To_Hex_2byte(sHalUart.RxTempBuffer[6], sHalUart.RxTempBuffer[7]);	// addr
		uc_data2 = Ascii_To_Hex_2byte(sHalUart.RxTempBuffer[8], sHalUart.RxTempBuffer[9]);	// addr					
		uc_data3 = Ascii_To_Hex_2byte(sHalUart.RxTempBuffer[10], sHalUart.RxTempBuffer[11]);	// data

        Address = (uc_data1 << 8) | uc_data2;

		if((uc_data1 >> 4) == 0x08)
		{
			Address = Address - STATUS_REG_BASE;
			ncLib_SWR_Write(Address, uc_data3);
			ISPSET08(ADDC_STATUS_REG_START+Address, uc_data3);
    	}
		else
		{
			Address = uc_data1;
			Address = ((Address << 8) | uc_data2);
			REGRW8(APACHE_ISP_BASE, Address) = uc_data3;
		}
		ncDrv_UART_print_string(UART1, (char *)"#OK\r");
	}
	else if(Cmd_Compare(FIRMWARE,8))
	{
		ncDrv_UART_print_string(UART1, (char *)VERISON);
	}
	else if(Cmd_Compare(PRODUCT,7))
	{
		ncDrv_UART_print_string(UART1, (char *)PRODUCT_NAME);
	}
  	else if(Cmd_Compare(BAUDTEST,2))
	{
		ncDrv_UART_print_string(UART1, (char *)"#RX\r");
	}
	return NC_SUCCESS;
}

UINT8 ncSvc_JIG_StatusReg_Read(UINT32 Addr)
{
    return ncLib_SWR_Read(Addr);
}


UINT8 ncSvc_JIG_StatusReg_Write(UINT32 Addr, UINT32 Wdata)
{
    ncLib_SWR_Write(Addr, Wdata);
    return Wdata;
}

BOOL Parser_NC(void)	// test
{
	return 0;
}

CHAR Cmd_Compare(UCHAR *cmp_data, UCHAR cmp_cnt)	// test
{
	UCHAR cmd_cnt=0;
	UCHAR cmd_signe=TRUE;

	UCHAR tmp1, tmp2;

	while(cmd_cnt < cmp_cnt)
	{
		tmp1 = sHalUart.RxTempBuffer[1+cmd_cnt];
		tmp2 = cmp_data[cmd_cnt];

		if(tmp1 != tmp2)
		{
			cmd_signe = FALSE;
			break;
		}
		else cmd_cnt++;
	}
	
	return cmd_signe;
}


CHAR Read_Command(void)
{ 
	CHAR r_data;

	r_data = (CHAR)sHalUart.RxRealBuffer[sHalUart.RxPointer];
	
	sHalUart.RxPointer++;
	
	if(sHalUart.RxPointer >= RX_BUF_SIZE) 	sHalUart.RxPointer = RX_BUF_SIZE-1;
	
	return r_data;
}



UCHAR Ascii_To_Hex_2byte(UCHAR data_h, UCHAR data_l)	// test
{
	UCHAR tmp, tmp1=0;
	
	if((data_h>='a')&&(data_h<='f')) data_h = data_h - 32;
	if((data_l>='a')&&(data_l<='f')) data_l = data_l - 32;
		
	if((data_h>='A')&&(data_h<='F'))		tmp = (data_h-'A'+10) << 4;
	else if((data_h>='0')&&(data_h<='9'))	tmp = (data_h-'0') << 4;
	else tmp1 = 1;
	
	if((data_l>='A')&&(data_l<='F'))		tmp |= (data_l-'A'+10) & 0x0F;	
	else if((data_l>='0')&&(data_l<='9'))	tmp |= (data_l-'0') & 0x0F;
	else tmp1 = 1;
	
	if(tmp1 < 1)	return tmp;
	else			return FALSE;
}

UCHAR Ascii_To_Hex_1byte(UCHAR data)	// test
{
    UCHAR tmp, tmp1 = 0;

    if((data >= 'a') && (data <= 'z'))	data = (data - 32);

    if((data >= '0') && (data <= '9'))	tmp = (data - '0');
	else if((data >= 'A') && (data <= 'Z'))	tmp = (data - 'A') + 10;
    else tmp1 = 1;

	if(tmp1 < 1)	return tmp;
	else			return FALSE;
}

void ncSvc_JIG_FPORT_Open(void)
{
}


void ncSvc_JIG_FPORT_Close(void)
{
}


void ncSvc_JIG_InitJigInfo(void)
{
    stJigInfo.CmdGetPointer = 0;
}


/* End Of File */
