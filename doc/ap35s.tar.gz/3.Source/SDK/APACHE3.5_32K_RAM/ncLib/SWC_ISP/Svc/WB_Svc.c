
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
        2016.01.26      M.Y Sung    0.0     platform change
********************************************************************************/
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Api_GlobalHeader.h"

#define __ATWGAINSET_OSDDEBUG
#define AWB_G_GAIN_1x   6400L   /* (0x40 * 100)*/

STRUCT_MW_AWB	sMwAwb;

//============================================================================
//      Function
//============================================================================
void ncSvc_ISP_AWB_Deinitialize(void)
{

}

void ncSvc_WB_MODE_SET(void)
{
    switch(rSWReg.Category.AWB.Reg.WB_MODE)
	{
		case eWHITBAL_ATW:
		case eWHITBAL_AWC:
		case eWHITBAL_INDOOR:
		case eWHITBAL_OUTDOOR:
		case eWHITBAL_MANUAL:
    		rSWReg.Category.AWB.Reg.ATW_INCLUDE_BOX_EN = STATE_ON;
    		rSWReg.Category.AWB.Reg.ATW_EXCLUDE_BOX_EN = STATE_ON;
		    break;

		case eWHITBAL_AWB:
    		rSWReg.Category.AWB.Reg.ATW_INCLUDE_BOX_EN = STATE_OFF;
    		rSWReg.Category.AWB.Reg.ATW_EXCLUDE_BOX_EN = STATE_OFF;
			break;
	}
}
void ncSvc_WB_INIT(void)
{
	sMwAwb.Data1 = 0;
	sMwAwb.Data2 = 0;
	sMwAwb.Data3 = 0;
	sMwAwb.ModeRun =0;
	
    //sMwAwb.Cie = (STRUCT_CIE *)aIP_OPD_RECT_INC_XTH0_MAX_7_0;    

    sMwAwb.Target.AddrRGain = aIP_AWB_R_GAIN_7_0;
    sMwAwb.Target.AddrBGain = aIP_AWB_B_GAIN_7_0;

    sMwAwb.TargetM.AddrRGain = aIP_AWB_R_GAIN_M_7_0;
    sMwAwb.TargetM.AddrBGain = aIP_AWB_B_GAIN_M_7_0;

    sMwAwb.TargetS.AddrRGain = aIP_AWB_R_GAIN_S_7_0;
    sMwAwb.TargetS.AddrBGain = aIP_AWB_B_GAIN_S_7_0;

	memset(sMwAwb.JigData, 0, (10*sizeof(UCHAR)));

	sMwAwb.AveCIE.Xpos = 0x00;
	sMwAwb.AveCIE.Ypos = 0x00;
	
	rIP_CIE_Z_B_GAIN_10_8	= 0x05;
	rIP_CIE_Z_B_GAIN_7_0	= 0x98;
	rIP_CIE_Z_G_GAIN_10_8	= 0x00;
	rIP_CIE_Z_G_GAIN_7_0	= 0x0E;
	rIP_CIE_Z_R_GAIN_10_8 	= 0x00;
	rIP_CIE_Z_R_GAIN_7_0 	= 0x00;
	
	rIP_CIE_Y_B_GAIN_10_8 	= 0x00;
	rIP_CIE_Y_B_GAIN_7_0 	= 0x0F;
	rIP_CIE_Y_G_GAIN_10_8 	= 0x04;
	rIP_CIE_Y_G_GAIN_7_0 	= 0x97;
	rIP_CIE_Y_R_GAIN_10_8 	= 0x01;
	rIP_CIE_Y_R_GAIN_7_0 	= 0x00;
	
	rIP_CIE_X_B_GAIN_10_8 	= 0x01;
	rIP_CIE_X_B_GAIN_7_0 	= 0x21;
	rIP_CIE_X_G_GAIN_10_8 	= 0x01;
	rIP_CIE_X_G_GAIN_7_0 	= 0xC0;
	rIP_CIE_X_R_GAIN_10_8 	= 0x02;
	rIP_CIE_X_R_GAIN_7_0 	= 0xC4;

    /* [2015/5/18] JWLee : WDR SET */
    rIP_AWB_H_SWAP = rIP_AWB_H_SWAP_M = rIP_AWB_H_SWAP_S;
    rIP_AWB_V_SWAP = rIP_AWB_V_SWAP_M = rIP_AWB_V_SWAP_S;    

    ISPSET16(aIP_AWB_R_GAIN_M_7_0, ISPGET16(aIP_AWB_R_GAIN_7_0));
    ISPSET16(aIP_AWB_G_GAIN_M_7_0, ISPGET16(aIP_AWB_G_GAIN_7_0));
    ISPSET16(aIP_AWB_B_GAIN_M_7_0, ISPGET16(aIP_AWB_B_GAIN_7_0));

    ISPSET16(aIP_AWB_R_GAIN_S_7_0, ISPGET16(aIP_AWB_R_GAIN_7_0));
    ISPSET16(aIP_AWB_G_GAIN_S_7_0, ISPGET16(aIP_AWB_G_GAIN_7_0));    
    ISPSET16(aIP_AWB_B_GAIN_S_7_0, ISPGET16(aIP_AWB_B_GAIN_7_0));

    ncSvc_WB_MODE_SET();
}

UCHAR ncSvc_WBRect_Status(void)
{
    return rSWReg.Category.AWB.Reg.ATW_INCLUDE_BOX_EN;
}

void Debug_Viewer_WB1(void)
{
#if 0
    UCHAR i,j;
    for(i = 0; i<3; i++)//y
    {
        for(j = 0; j<8; j++)//x
        {
            APP_OSDPrint_Hex(2+i, (2+(j*3)), REGRW8(APACHE_ISP_BASE, aIP_OPD_INC_CNT0+j+(8*i)));
        }
    }

    for(i = 0; i<8; i++)//y
    {
        for(j = 0; j<8; j++)//x
        {
            APP_OSDPrint_Hex(12+i, (2+(j*3)), REGRW8(APACHE_ISP_BASE, aIP_OPD_INC_IDX0+j+(8*i)));
        }
    }   
#endif
}

void Debug_Viewer_WB(void)
{
#if 0
	
	/* Normal & Long */
	APP_OSDPrint_String(2, 1, (UCHAR*)"TR");    /* Target R */
	APP_OSDPrint_Hex2(2, 5, (USHORT)sMwAwb.Target.RGain);
	APP_OSDPrint_String(3, 1, (UCHAR*)"CR");    /* Current R */
	APP_OSDPrint_Hex2(3, 5, (USHORT)REGRW16(APACHE_ISP_BASE, aIP_AWB_R_GAIN_7_0));
	APP_OSDPrint_String(4, 1, (UCHAR*)"TB");    /* Target B */
	APP_OSDPrint_Hex2(4, 5, (USHORT)sMwAwb.Target.BGain);
	APP_OSDPrint_String(5, 1, (UCHAR*)"CB");    /* Current B */
	APP_OSDPrint_Hex2(5, 5, (USHORT)REGRW16(APACHE_ISP_BASE, aIP_AWB_B_GAIN_7_0));
	APP_OSDPrint_String(6, 1, (UCHAR*)"VD");    /* OPD valid number  */
	APP_OSDPrint_Hex(6, 5,  (UCHAR)sMwOpd.Data.VALID_CNT);

	APP_OSDPrint_String(7, 1, (UCHAR*)"RT");    /* The ratio of the number of excluded OPD. */
	APP_OSDPrint_Hex(7, 5,  (UCHAR)rSWReg.Category.AWB.Reg.COLOREXCEPT_RATIO);
    APP_OSDPrint_String(8, 1, (UCHAR*)"X");    /* Average CIE x */
	APP_OSDPrint_Hex2(8, 5,  (USHORT)sMwAwb.AveCIE.Xpos);
    APP_OSDPrint_String(9, 1, (UCHAR*)"Y");    /* Average CIE y */
	APP_OSDPrint_Hex2(9, 5,  (USHORT)sMwAwb.AveCIE.Ypos);
    
#endif
#if 0
    if(sWdr.Mode == STATE_ON)
    {
    	/* Middle */
    	APP_OSDPrint_Hex2(2, 10, (USHORT)sMwAwb.TargetM.RGain);
    	APP_OSDPrint_Hex2(3, 10, (USHORT)REGRW16(APACHE_ISP_BASE, aIP_AWB_R_GAIN_M_7_0));
    	APP_OSDPrint_Hex2(4, 10, (USHORT)sMwAwb.TargetM.BGain);
    	APP_OSDPrint_Hex2(5, 10, (USHORT)REGRW16(APACHE_ISP_BASE, aIP_AWB_B_GAIN_M_7_0));
        APP_OSDPrint_Hex(6, 10, (UCHAR)sMwOpd.DataM.VALID_CNT);
        
        /* Short */
    	APP_OSDPrint_Hex2(2, 15, (USHORT)sMwAwb.TargetS.RGain);
    	APP_OSDPrint_Hex2(3, 15, (USHORT)REGRW16(APACHE_ISP_BASE, aIP_AWB_R_GAIN_S_7_0));
    	APP_OSDPrint_Hex2(4, 15, (USHORT)sMwAwb.TargetS.BGain);
    	APP_OSDPrint_Hex2(5, 15, (USHORT)REGRW16(APACHE_ISP_BASE, aIP_AWB_B_GAIN_S_7_0));
        APP_OSDPrint_Hex(6, 15, (UCHAR)sMwOpd.DataS.VALID_CNT);
    }
#endif
}

void CIExy_Get(STRUCT_OPD_RGB * Opd, STRUCT_CIE_XY * CieXY)
{
    CIEXYZ_RSET(Opd->R);
	CIEXYZ_GSET(Opd->G);
	CIEXYZ_BSET(Opd->B);
	
    ncDrv_Delay_Set(1);
    
    CieXY->Xpos = ISPGET16(aIP_CHROMATICITY_X_7_0);
	CieXY->Ypos = ISPGET16(aIP_CHROMATICITY_Y_7_0);
}

void ZigControl_CIExy_Set(UCHAR status)
{
    STRUCT_CIE_XY CieXY;
    STRUCT_OPD_RGB Opd;
	UCHAR idx=0;
	UCHAR num=0;
	
#if 1
	
	//if(sMwJig.Flag.Cmd1.Bit.Two == 0)
	//{
		for(idx =0; idx<4; idx++)
		{	
			num = (status << 2)+idx;
			
            if(num >= sMwOpd.Size.Total)
            {
				JIGMSG("%04X", 0xFFFF);	
				JIGMSG("%04X", 0xFFFF);
				continue;
            }
			
            if(rIP_OPD_USE_CIEXY == STATE_ON)
            {
    			JIGMSG("%04X", (USHORT)ISPGET08(aIP_OPD_BLOCK_R + num)<<8);	
    			JIGMSG("%04X", (USHORT)ISPGET08(aIP_OPD_BLOCK_B + num)<<8);
            }
            else
            {
                if(rSWReg.Category.SYSTEM.Reg.OPD_READ_SEL == 0x00)  /* OPD LONG */
                {
                    if(OPD_Validation_Check(num)) //
                    {
            			Opd.R = ISPGET08(aIP_OPD_BLOCK_R + num);
                        Opd.G = ISPGET08(aIP_OPD_BLOCK_G + num);
                        Opd.B = ISPGET08(aIP_OPD_BLOCK_B + num);
                        CIExy_Get(&Opd, &CieXY);
                    }
                    else
                    {
                        CieXY.Xpos = 0xFFFF;
                        CieXY.Ypos = 0xFFFF;
                    }
    			}
    			else
    			{
                    if(OPD_Validation_CheckS(num))
                    {
            			Opd.R = ISPGET08(aIP_OPD_BLOCKs_R + num);
                        Opd.G = ISPGET08(aIP_OPD_BLOCKs_G + num);
                        Opd.B = ISPGET08(aIP_OPD_BLOCKs_B + num);
                        CIExy_Get(&Opd, &CieXY);
                    }
                    else
                    {
                        CieXY.Xpos = 0xFFFF;
                        CieXY.Ypos = 0xFFFF;
                    }
    			}
				
                ncDrv_Delay_Set(1);

    			JIGMSG("%04X", CieXY.Xpos);
    			JIGMSG("%04X", CieXY.Ypos);

    	    }
		}
	//}
#endif
}

void ncSvc_WB_ZigControl_Set(void)
{
	UCHAR data = sMwAwb.JigData[1];
	
	switch(sMwAwb.JigData[0])
	{
		case 0x00://Debug Mode ON/OFF Control [JIG To Mcu]
            sMwSystem.Control.Run.AWB = !data;
    		break;

		case 0x01://OPD CIE x,y send  [Mcu To JIG]
		    OPD_RECT_INCLUDE_EN(STATE_OFF);
            OPD_RECT_EXCLUDE_EN(STATE_OFF);
		
			ZigControl_CIExy_Set(data);
			
		    OPD_RECT_INCLUDE_EN(rSWReg.Category.AWB.Reg.ATW_INCLUDE_BOX_EN);
            OPD_RECT_EXCLUDE_EN(rSWReg.Category.AWB.Reg.ATW_EXCLUDE_BOX_EN);
    		break;

		case 0x03://Weight Box
    		break;

		case 0x04://range status & range cnt  [Mcu To JIG]
			//while(!sHalInt.Flag.Bit.Isp0);
			//sHalInt.Flag.Bit.Isp0 = FALSE;
			JIGMSG("%02X", sMwAwb.Data1);	//Start
			JIGMSG("%02X", sMwAwb.Data2);	//End
			JIGMSG("%02X", sMwAwb.Data3); //Count Num
    		break;

		case 0x05://IndoorWB[JIG To Mcu]
			sMwAwb.preMode = rSWReg.Category.AWB.Reg.WB_MODE;
			rSWReg.Category.AWB.Reg.WB_MODE = eWHITBAL_INDOOR;
			sMwAwb.ModeRun = TRUE;
    		break;

		case 0x06://OutdoorWB[JIG To Mcu]
			sMwAwb.preMode = rSWReg.Category.AWB.Reg.WB_MODE;
			rSWReg.Category.AWB.Reg.WB_MODE = eWHITBAL_OUTDOOR;
			sMwAwb.ModeRun = TRUE;
    		break;

		case 0x07://awb speed control
			if(data == 0)
			{
				JIGMSG("%02X", rSWReg.Category.AWB.Reg.ATW_SPEED);	
			}
			else
			{
				rSWReg.Category.AWB.Reg.ATW_SPEED = sMwAwb.JigData[2];
			}
		    break;	

		case 0x10:// AWB OPD Range Write [JIG To Mcu]
#if 0
            if(data == 0x00)
            {
    		    OPD_RECT_INCLUDE_EN(STATE_OFF);
                OPD_RECT_EXCLUDE_EN(STATE_OFF);
            }
#endif      
			ISPSET16((aIP_OPD_RECT_INC_XTH0_MIN_7_0+(data<< 3)),(sMwAwb.JigData[2] <<8)|(sMwAwb.JigData[3]));
			ISPSET16((aIP_OPD_RECT_INC_XTH0_MAX_7_0+(data<< 3)),(sMwAwb.JigData[4] <<8)|(sMwAwb.JigData[5]));
			ISPSET16((aIP_OPD_RECT_INC_YTH0_MIN_7_0+(data<< 3)),(sMwAwb.JigData[6] <<8)|(sMwAwb.JigData[7]));
			ISPSET16((aIP_OPD_RECT_INC_YTH0_MAX_7_0+(data<< 3)),(sMwAwb.JigData[8] <<8)|(sMwAwb.JigData[9]));			
#if 0
            if(data == 0x1F)
            {
    		    OPD_RECT_INCLUDE_EN(rSWReg.Category.AWB.Reg.ATW_INCLUDE_BOX_EN);
                OPD_RECT_EXCLUDE_EN(rSWReg.Category.AWB.Reg.ATW_EXCLUDE_BOX_EN);
            }
#endif
    		break;

		case 0x11:// AWB OPD Range Read [Mcu To JIG]
			JIGMSG("%04X", ISPGET16((aIP_OPD_RECT_INC_XTH0_MIN_7_0+(data<< 3))));
			JIGMSG("%04X", ISPGET16((aIP_OPD_RECT_INC_XTH0_MAX_7_0+(data<< 3))));
			JIGMSG("%04X", ISPGET16((aIP_OPD_RECT_INC_YTH0_MIN_7_0+(data<< 3))));
			JIGMSG("%04X", ISPGET16((aIP_OPD_RECT_INC_YTH0_MAX_7_0+(data<< 3))));
    		break;

		case 0x12:
			if(data == 0)
			{
				JIGMSG("%02X%02X", ISPGET16(ADDR_ATW_COLOREXCEPT_CIE_X_7_0));
				JIGMSG("%02X%02X", ISPGET16(ADDR_ATW_COLOREXCEPT_CIE_Y_7_0));
				//JIGMSG("%02X%02X", rSWReg.Category.AWB.Byte[13L], rSWReg.Category.AWB.Byte[12L]);
				//JIGMSG("%02X%02X", rSWReg.Category.AWB.Byte[15L], rSWReg.Category.AWB.Byte[14L]);
			}
			else
			{
                ISPSET16(ADDR_ATW_COLOREXCEPT_CIE_X_7_0, ((sMwAwb.JigData[2]<<8)|sMwAwb.JigData[3]));
                ISPSET16(ADDR_ATW_COLOREXCEPT_CIE_Y_7_0, ((sMwAwb.JigData[4]<<8)|sMwAwb.JigData[5]));
			}
    		break;

		case 0x20:	// AWB OPD Include/Exclude On/Off [JIG To MCU]
/* [2015/12/29] jwlee7 */ 
//    		    rSWReg.Category.AWB.Reg.ATW_INCLUDE_BOX_EN = (data>>4)&0x01;
//                rSWReg.Category.AWB.Reg.ATW_EXCLUDE_BOX_EN = data&0x01;
//    
//    		    OPD_RECT_INCLUDE_EN(rSWReg.Category.AWB.Reg.ATW_INCLUDE_BOX_EN);
//                OPD_RECT_EXCLUDE_EN(rSWReg.Category.AWB.Reg.ATW_EXCLUDE_BOX_EN);
            break;
            
		case 0x21:	// AWB OPD Exception BOX Enable Read [Mcu To JIG]
			JIGMSG("%02X", ISPGET08(ADDR_ATW_INCLUDE_BOX_EN));
    		break;

		case 0x22:	// AWB OPD Exception BOX Write [JIG To MCU]
			ISPSET16((aIP_OPD_RECT_EXC_XTH0_MIN_7_0 + (data<< 3)), ((sMwAwb.JigData[2]<<8)|sMwAwb.JigData[3]));
			ISPSET16((aIP_OPD_RECT_EXC_XTH0_MAX_7_0 + (data<< 3)), ((sMwAwb.JigData[4]<<8)|sMwAwb.JigData[5]));
			ISPSET16((aIP_OPD_RECT_EXC_YTH0_MIN_7_0 + (data<< 3)), ((sMwAwb.JigData[6]<<8)|sMwAwb.JigData[7]));
			ISPSET16((aIP_OPD_RECT_EXC_YTH0_MAX_7_0 + (data<< 3)), ((sMwAwb.JigData[8]<<8)|sMwAwb.JigData[9]));
    		break;

		case 0x23:	// AWB OPD Exception BOX Read [Mcu To JIG]
			JIGMSG("%04X", ISPGET16(aIP_OPD_RECT_EXC_XTH0_MIN_7_0 + (data<< 3)));
			JIGMSG("%04X", ISPGET16(aIP_OPD_RECT_EXC_XTH0_MAX_7_0 + (data<< 3)));
			JIGMSG("%04X", ISPGET16(aIP_OPD_RECT_EXC_YTH0_MIN_7_0 + (data<< 3)));
			JIGMSG("%04X", ISPGET16(aIP_OPD_RECT_EXC_YTH0_MAX_7_0 + (data<< 3)));
    		break;
	}
}

BOOL ATW_ColorException_State(void)
{
#define SINGLE_RATIO_BOUNDARY  3L
#define AVG_BUFFER_CNT          16L

	UCHAR ColorExceptRatio=0;
    static BOOL ColorExceptState = STATE_OFF;
	static BUFFER_AVERAGE_TYPE ColorExceptBuff=0;

    if(rSWReg.Category.AWB.Reg.ATW_COLOREXCEPT_EN == STATE_OFF)   return STATE_OFF;

    if(_abs(sMwOpd.Data.VALID_CNT, sMwOpd.Data.ExcludeColor_CNT) == 0)
    {
        rSWReg.Category.AWB.Reg.COLOREXCEPT_RATIO = 100;// 100%

        return STATE_OFF;
    }
    
/*___________________________________ Color Exception State decision ___________________________________*/
/*    Will not use Exception area R/B opd data until ColorExceptRatio > ATW_COLOREXCEPT_RATIO           */

    ColorExceptRatio = (sMwOpd.Data.ExcludeColor_CNT * 100) / sMwOpd.Data.VALID_CNT;  
    ColorExceptRatio = ncDrv_BufferAvg_Get(&ColorExceptBuff, AVG_BUFFER_CNT, ColorExceptRatio);    

    rSWReg.Category.AWB.Reg.COLOREXCEPT_RATIO = ColorExceptRatio;
    
    if(_abs(ColorExceptRatio, rSWReg.Category.AWB.Reg.ATW_COLOREXCEPT_RATIO) >= SINGLE_RATIO_BOUNDARY)
    {
        if(ColorExceptRatio > rSWReg.Category.AWB.Reg.ATW_COLOREXCEPT_RATIO)   
        {
            ColorExceptState = STATE_OFF;   /* Use exception area R/B data (All Area) */
        }
        else
        {
            ColorExceptState = STATE_ON;    /* Not Use exception area R/B data (RBRatio) */
        }
    }

    return ColorExceptState;
}

void ATW_TargetRB_Adjust(void)
{
    USHORT RGainMax = 0x1FF, BGainMax = 0x1FF;
    USHORT RGainMin = 0x1FF, BGainMin = 0x1FF;
    
	if(sMwAwb.Target.RGain >= 0x1FF)	sMwAwb.Target.RGain = 0x1FF;
	if(sMwAwb.Target.BGain >= 0x1FF)	sMwAwb.Target.BGain = 0x1FF;

	if(rSWReg.Category.AWB.Reg.ATW_RGAIN_SIGN)	sMwAwb.Target.RGain += rSWReg.Category.AWB.Reg.ATW_RGAIN_OFFSET;
	else								        sMwAwb.Target.RGain -= rSWReg.Category.AWB.Reg.ATW_RGAIN_OFFSET;

	if(rSWReg.Category.AWB.Reg.ATW_BGAIN_SIGN)	sMwAwb.Target.BGain += rSWReg.Category.AWB.Reg.ATW_BGAIN_OFFSET;
	else								        sMwAwb.Target.BGain -= rSWReg.Category.AWB.Reg.ATW_BGAIN_OFFSET;

	if(rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_MODE !=  LIMIT_OFF)
	{
	    RGainMax = (USHORT)rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_RGAIN_MAX<<1;
	    BGainMax = (USHORT)rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_BGAIN_MAX<<1;
	    RGainMin = (USHORT)rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_RGAIN_MIN<<1;
	    BGainMin = (USHORT)rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_BGAIN_MIN<<1;

        if(rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_MODE ==  LIMIT_AGC)
        {
    		if(rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_AGC <= rIP_AGC_LEVEL_7_0)
    		{
    			if(rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_RGAIN_MAX == 0)			    rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_RGAIN_MAX = 0xFF;
    			if(rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_BGAIN_MAX == 0)			    rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_BGAIN_MAX = 0xFF;
    			if(rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_RGAIN_MIN == 0xFF)		    rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_RGAIN_MIN = 0;
    			if(rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_BGAIN_MIN == 0xFF)		    rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_BGAIN_MIN = 0;

    			if(sMwAwb.Target.RGain > RGainMax)	sMwAwb.Target.RGain= RGainMax;
    			if(sMwAwb.Target.RGain <= RGainMin)	sMwAwb.Target.RGain= RGainMin;
    			if(sMwAwb.Target.BGain > BGainMax)	sMwAwb.Target.BGain= BGainMax;
    			if(sMwAwb.Target.BGain <= BGainMin)	sMwAwb.Target.BGain= BGainMin;
    		}
        }
        else if(rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_MODE ==  LIMIT_ALWAYS)
        {
    		if(rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_RGAIN_MAX == 0)			    rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_RGAIN_MAX = 0xFF;
    		if(rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_BGAIN_MAX == 0)			    rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_BGAIN_MAX = 0xFF;
    		if(rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_RGAIN_MIN == 0xFF)		    rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_RGAIN_MIN = 0;
    		if(rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_BGAIN_MIN == 0xFF)		    rSWReg.Category.AWB.Reg.ATW_GAIN_LIMITED_BGAIN_MIN = 0;

			if(sMwAwb.Target.RGain > RGainMax)	sMwAwb.Target.RGain= RGainMax;
			if(sMwAwb.Target.RGain <= RGainMin)	sMwAwb.Target.RGain= RGainMin;
			if(sMwAwb.Target.BGain > BGainMax)	sMwAwb.Target.BGain= BGainMax;
			if(sMwAwb.Target.BGain <= BGainMin)	sMwAwb.Target.BGain= BGainMin;
        }
    }
}

UCHAR ATW_TrackingGain_GET(void)
{
#define OPD_COUNT_MIN           5L
#define AVG_BUFFER_CNT          16L

	USHORT CtrlR, CtrlB;
	USHORT CIEx, CIEy;
	static UCHAR preWBMode = 0xFF;

    static BUFFER_AVERAGE_16BIT_TYPE TargetRGainBuff;
    static BUFFER_AVERAGE_16BIT_TYPE TargetBGainBuff;
    static BUFFER_AVERAGE_16BIT_TYPE CIExBuff;
    static BUFFER_AVERAGE_16BIT_TYPE CIEyBuff;
    
    if(sMwOpd.Data.VALID_CNT < OPD_COUNT_MIN)   return TRACKING_OFF;

    if(rSWReg.Category.AWB.Reg.WB_MODE != preWBMode)
    {
        TargetRGainBuff.BuffCntInit = 0;
        TargetRGainBuff.BuffIdx     = 0;
        TargetRGainBuff.AccValue    = 0;

        TargetBGainBuff.BuffCntInit = 0;
        TargetBGainBuff.BuffIdx     = 0;
        TargetBGainBuff.AccValue    = 0;

        CIExBuff.BuffCntInit = 0;
        CIExBuff.BuffIdx     = 0;
        CIExBuff.AccValue    = 0;

        CIEyBuff.BuffCntInit = 0;
        CIEyBuff.BuffIdx     = 0;
        CIEyBuff.AccValue    = 0;
        
        preWBMode = rSWReg.Category.AWB.Reg.WB_MODE;
    }
    
    if(ATW_ColorException_State())
    {
        /* White balance calculations of areas unmentioned */
        CtrlR = AWB_G_GAIN_1x / sMwOpd.Data.Ratio.UnmentionedArea_R;
		CtrlB = AWB_G_GAIN_1x / sMwOpd.Data.Ratio.UnmentionedArea_B;

    	CIEx = sMwOpd.Data.Cie.UnmentionedArea_Xpos;
    	CIEy = sMwOpd.Data.Cie.UnmentionedArea_Ypos;		
    }
	else
	{
	    /* White balance calculations of all areas */
    	CtrlR = AWB_G_GAIN_1x / sMwOpd.Data.Ratio.R;
    	CtrlB = AWB_G_GAIN_1x / sMwOpd.Data.Ratio.B;

    	CIEx = sMwOpd.Data.Cie.Xpos;
    	CIEy = sMwOpd.Data.Cie.Ypos;
	}


	CtrlR = ncDrv_BufferAvg_Get16(&TargetRGainBuff, AVG_BUFFER_CNT, CtrlR);
	CtrlB = ncDrv_BufferAvg_Get16(&TargetBGainBuff, AVG_BUFFER_CNT, CtrlB);

	sMwAwb.AveCIE.Xpos = ncDrv_BufferAvg_Get16(&CIExBuff, AVG_BUFFER_CNT, CIEx);
	sMwAwb.AveCIE.Ypos = ncDrv_BufferAvg_Get16(&CIEyBuff, AVG_BUFFER_CNT, CIEy);
	
	if(CtrlR < 0x30)    sMwAwb.Target.RGain = ((sMwAwb.Target.RGain * 6) + (CtrlR << 2))/ 10;
    else                sMwAwb.Target.RGain = CtrlR;

    if(CtrlB < 0x30)    sMwAwb.Target.BGain = ((sMwAwb.Target.BGain * 6) + (CtrlB << 2))/ 10;
    else                sMwAwb.Target.BGain = CtrlB;

    ATW_TargetRB_Adjust();

    return TRACKING_RUN;
}

UCHAR ATW_TrackingMGain_GET(void)
{
#define OPD_MCOUNT_MIN           5L

	USHORT CtrlR, CtrlB;

    if(rSWReg.Category.WDR.Reg.WDR_WB_MODE_M == 0)
    {
        if(sMwOpd.DataM.VALID_CNT < OPD_MCOUNT_MIN)   return TRACKING_OFF;

    	CtrlR = AWB_G_GAIN_1x / sMwOpd.DataM.Ratio.R;
    	CtrlB = AWB_G_GAIN_1x / sMwOpd.DataM.Ratio.B;

    	if(CtrlR < 0x30)   sMwAwb.TargetM.RGain = ((sMwAwb.TargetM.RGain * 6) + (CtrlR << 2))/ 10;
        else               sMwAwb.TargetM.RGain = CtrlR;

        if(CtrlB < 0x30)   sMwAwb.TargetM.BGain = ((sMwAwb.TargetM.BGain * 6) + (CtrlB << 2))/ 10;
        else               sMwAwb.TargetM.BGain = CtrlB;
    }
    else if(rSWReg.Category.WDR.Reg.WDR_WB_MODE_M == 1)
    {
        sMwAwb.TargetM.RGain = sMwAwb.Target.RGain;
        sMwAwb.TargetM.BGain = sMwAwb.Target.BGain;
    }
    else if(rSWReg.Category.WDR.Reg.WDR_WB_MODE_M == 2)
    {
        sMwAwb.TargetM.RGain = sMwAwb.TargetS.RGain;
        sMwAwb.TargetM.BGain = sMwAwb.TargetS.BGain;
    }
    return TRACKING_RUN;
}

UCHAR ATW_TrackingSGain_GET(void)
{
#define OPD_SCOUNT_MIN           5L

	USHORT CtrlR, CtrlB;

    if(sMwOpd.DataS.VALID_CNT < OPD_SCOUNT_MIN)   return TRACKING_OFF;

    if(rSWReg.Category.WDR.Reg.WDR_WB_MODE_S == 0)
    {
    	CtrlR = AWB_G_GAIN_1x / sMwOpd.DataS.Ratio.R;
    	CtrlB = AWB_G_GAIN_1x / sMwOpd.DataS.Ratio.B;

    	if(CtrlR < 0x30)   sMwAwb.TargetS.RGain = ((sMwAwb.TargetS.RGain * 6) + (CtrlR << 2))/ 10;
        else               sMwAwb.TargetS.RGain = CtrlR;

        if(CtrlB < 0x30)   sMwAwb.TargetS.BGain = ((sMwAwb.TargetS.BGain * 6) + (CtrlB << 2))/ 10;
        else               sMwAwb.TargetS.BGain = CtrlB;
    }
    else
    {
        sMwAwb.TargetS.RGain = sMwAwb.Target.RGain;
        sMwAwb.TargetS.BGain = sMwAwb.Target.BGain;
    }
    
    return TRACKING_RUN;
}

UCHAR ATW_Gain_Tracking(STRUCT_GAIN_TRACKING_TYPE* Target)
{ 	
	USHORT TargetRGain = Target->RGain;
	USHORT TargetBGain = Target->BGain;
	USHORT CurGain_R = ISPGET16(Target->AddrRGain);
	USHORT CurGain_B = ISPGET16(Target->AddrBGain);
	UCHAR AwbSpeed;
	UCHAR R_RangeIN = FALSE, B_RangeIN = FALSE;

	//CurGain_R = rIP_AWB_R_GAIN_8;
	//CurGain_R = (CurGain_R << 8) | rIP_AWB_R_GAIN_7_0;

	//CurGain_B = rIP_AWB_B_GAIN_8;
	//CurGain_B = (CurGain_B << 8) | rIP_AWB_B_GAIN_7_0;
	
	if(rSWReg.Category.AWB.Reg.ATW_SPEED > 15)	rSWReg.Category.AWB.Reg.ATW_SPEED = 15;
	
	AwbSpeed = 16 - rSWReg.Category.AWB.Reg.ATW_SPEED;
	
	if(CurGain_R > (TargetRGain + AWB_IN_BOUNDARY))
	{
		Target->RStable = STATE_OFF;
		R_RangeIN = TRUE;
		
		if(CurGain_R > (TargetRGain + AWB_OUT_BOUNDARY))
		{
			if(((CurGain_R - TargetRGain)/AwbSpeed) > 1)
				TargetRGain = CurGain_R - ((CurGain_R - TargetRGain)/AwbSpeed);
			else
				TargetRGain = CurGain_R - 1;
		}
		else
		{
			TargetRGain = CurGain_R - 1;
		}
	}	
	else if(CurGain_R < (TargetRGain - AWB_IN_BOUNDARY))
	{
		Target->RStable = STATE_OFF;
		R_RangeIN = TRUE;
		
		if(CurGain_R < (TargetRGain - AWB_OUT_BOUNDARY))
		{
			if(((TargetRGain - CurGain_R)/AwbSpeed) > 1)
				TargetRGain = CurGain_R + ((TargetRGain - CurGain_R)/AwbSpeed);
			else
				TargetRGain = CurGain_R + 1;
		}
		else
		{
			TargetRGain = CurGain_R + 1;
		}
	}
	else
	{
		if(Target->RStable == STATE_OFF)
		{
    		ISPSET16(Target->AddrRGain, TargetRGain);
    		//rIP_AWB_R_GAIN_8 = (TargetRGain>>8)&0x01;
			//rIP_AWB_R_GAIN_7_0 = TargetRGain&0xFF;
		
			Target->RStable = STATE_ON;
		}
	}

	if(CurGain_B > (TargetBGain + AWB_IN_BOUNDARY))
	{
		Target->BStable = STATE_OFF;

		B_RangeIN = TRUE;
		
		if(CurGain_B > (TargetBGain + AWB_OUT_BOUNDARY))
		{
			if(((CurGain_B - TargetBGain)/AwbSpeed) > 1)
				TargetBGain = CurGain_B - ((CurGain_B - TargetBGain)/AwbSpeed);
			else
				TargetBGain = CurGain_B - 1;
		}
		else
		{
			TargetBGain = CurGain_B - 1;
		}
	}
	else if(CurGain_B < (TargetBGain - AWB_IN_BOUNDARY))
	{
		Target->BStable = STATE_OFF;

		B_RangeIN = TRUE;
		
		if(CurGain_B < (TargetBGain - AWB_OUT_BOUNDARY))
		{
			if(((TargetBGain - CurGain_B)/AwbSpeed) > 1)
				TargetBGain = CurGain_B + ((TargetBGain - CurGain_B)/AwbSpeed);
			else
				TargetBGain = CurGain_B + 1;
		}
		else
		{
			TargetBGain = CurGain_B + 1;
		}
	}
	else
	{
		if(Target->BStable == STATE_OFF)
		{
            ISPSET16(Target->AddrBGain, TargetBGain);
	        //rIP_AWB_B_GAIN_8 = (TargetBGain>>8)&0x01;
			//rIP_AWB_B_GAIN_7_0 = TargetBGain&0xFF;
			Target->BStable = STATE_ON;
		}	
	}
		
	if(R_RangeIN)
	{
		ISPSET16(Target->AddrRGain, TargetRGain);
	}
	
	if(B_RangeIN)
	{
		ISPSET16(Target->AddrBGain, TargetBGain);
	}
	
	return 1;
}

void AWC_Gain_Tracking(void)
{
	if(sMwAwb.Target.RGain >= 255)	sMwAwb.Target.RGain = 255;
	if(sMwAwb.Target.BGain >= 255)	sMwAwb.Target.BGain = 255;
			
	if(rSWReg.Category.AWB.Reg.WB_MODE == eWHITBAL_INDOOR)
	{
		rSWReg.Category.AWB.Reg.WB_INDOOR_RGAIN = (UCHAR)sMwAwb.Target.RGain;
		rSWReg.Category.AWB.Reg.WB_INDOOR_BGAIN = (UCHAR)sMwAwb.Target.BGain;
	}
	else if(rSWReg.Category.AWB.Reg.WB_MODE == eWHITBAL_OUTDOOR)
	{
		rSWReg.Category.AWB.Reg.WB_OUTDOOR_RGAIN = (UCHAR)sMwAwb.Target.RGain;
		rSWReg.Category.AWB.Reg.WB_OUTDOOR_BGAIN = (UCHAR)sMwAwb.Target.BGain;
	}
	else if(rSWReg.Category.AWB.Reg.WB_MODE == eWHITBAL_AWC)
	{
		rSWReg.Category.AWB.Reg.WB_AWC_RGAIN = (UCHAR)sMwAwb.Target.RGain;
		rSWReg.Category.AWB.Reg.WB_AWC_BGAIN = (UCHAR)sMwAwb.Target.BGain;
	}
}

UCHAR AWB_TargetRB_SET(void)
{
	sMwAwb.Target.RGain = AWB_G_GAIN_1x / sMwOpd.Data.Ratio.R;
	sMwAwb.Target.BGain = AWB_G_GAIN_1x / sMwOpd.Data.Ratio.B;
	return TRUE;
}

void ncSvc_WB_Task(void)
{
	if(sMwSystem.Control.Run.AWB)
	{
		switch(rSWReg.Category.AWB.Reg.WB_MODE)
		{
			case eWHITBAL_ATW:
			case eWHITBAL_AWB:
			    if(ATW_TrackingGain_GET())
			    {
                    ATW_Gain_Tracking(&sMwAwb.Target);
			    }

                if(sWdr.Type == eWDRTYPE_DCOMP_OV || sWdr.Type == eWDRTYPE_DCOMP_AR){

                    ISPSET16(aIP_AWB_R_GAIN_S_7_0, ISPGET16(aIP_AWB_R_GAIN_7_0));
                    ISPSET16(aIP_AWB_G_GAIN_S_7_0, ISPGET16(aIP_AWB_G_GAIN_7_0));    
                    ISPSET16(aIP_AWB_B_GAIN_S_7_0, ISPGET16(aIP_AWB_B_GAIN_7_0));

                    return;
                }

			    if((sWdr.Mode == STATE_ON)&&(sWdr.Ctrl.B8.TransitState == STATE_OFF))
			    {
    			    if(ATW_TrackingMGain_GET())
    			    {
                        ATW_Gain_Tracking(&sMwAwb.TargetM);
    			    }

    			    if(ATW_TrackingSGain_GET())
    			    {
                        ATW_Gain_Tracking(&sMwAwb.TargetS);
    			    }
			    }
    		    break;
            case eWHITBAL_MANUAL:
                ISPSET16(aIP_AWB_R_GAIN_7_0, (USHORT)(rSWReg.Category.AWB.Reg.WB_MANUAL_RGAIN*2.55));
                ISPSET16(aIP_AWB_B_GAIN_7_0, (USHORT)(rSWReg.Category.AWB.Reg.WB_MANUAL_BGAIN*2.55));
			    break;

			case eWHITBAL_AWC:
			case eWHITBAL_INDOOR:
			case eWHITBAL_OUTDOOR:
			    if(sMwAwb.ModeRun == TRUE)
			    {
    			    if(ATW_TrackingGain_GET())
    			    {
                        AWB_TargetRB_SET();
                        AWC_Gain_Tracking();
                        
    					sMwAwb.ModeRun = FALSE;
    					rSWReg.Category.AWB.Reg.WB_MODE = sMwAwb.preMode;
                        
                		rSWReg.Category.AWB.Reg.ATW_INCLUDE_BOX_EN = STATE_ON;
                		rSWReg.Category.AWB.Reg.ATW_EXCLUDE_BOX_EN = STATE_ON;
                        OPD_RECT_INCLUDE_EN(rSWReg.Category.AWB.Reg.ATW_INCLUDE_BOX_EN);
                        OPD_RECT_EXCLUDE_EN(rSWReg.Category.AWB.Reg.ATW_EXCLUDE_BOX_EN);                		
    			    }
    			    else
    			    {
                		rSWReg.Category.AWB.Reg.ATW_INCLUDE_BOX_EN = STATE_OFF;
                		rSWReg.Category.AWB.Reg.ATW_EXCLUDE_BOX_EN = STATE_OFF;
                        OPD_RECT_INCLUDE_EN(rSWReg.Category.AWB.Reg.ATW_INCLUDE_BOX_EN);
                        OPD_RECT_EXCLUDE_EN(rSWReg.Category.AWB.Reg.ATW_EXCLUDE_BOX_EN);
    			    }
                }
                else
                {
					if(rSWReg.Category.AWB.Reg.WB_MODE == eWHITBAL_INDOOR)
					{
						ISPSET16(aIP_AWB_R_GAIN_7_0, rSWReg.Category.AWB.Reg.WB_INDOOR_RGAIN);
						ISPSET16(aIP_AWB_B_GAIN_7_0, rSWReg.Category.AWB.Reg.WB_INDOOR_BGAIN);
					}
					else if(rSWReg.Category.AWB.Reg.WB_MODE == eWHITBAL_OUTDOOR)
					{
                        ISPSET16(aIP_AWB_R_GAIN_7_0, rSWReg.Category.AWB.Reg.WB_OUTDOOR_RGAIN);
						ISPSET16(aIP_AWB_B_GAIN_7_0, rSWReg.Category.AWB.Reg.WB_OUTDOOR_BGAIN);					
					}
					else if(rSWReg.Category.AWB.Reg.WB_MODE == eWHITBAL_AWC)
					{
						ISPSET16(aIP_AWB_R_GAIN_7_0, rSWReg.Category.AWB.Reg.WB_AWC_RGAIN);
						ISPSET16(aIP_AWB_B_GAIN_7_0, rSWReg.Category.AWB.Reg.WB_AWC_BGAIN);
					}
				}			    
    			break;
		}
	}
}


