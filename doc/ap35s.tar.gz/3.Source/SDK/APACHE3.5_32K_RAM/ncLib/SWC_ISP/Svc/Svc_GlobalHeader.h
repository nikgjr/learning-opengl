/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/



#ifndef __SVC_GLOBALHEADER__
#define __SVC_GLOBALHEADER__

/*=============================================================================
	All Middleware file Include
=============================================================================*/
#include "Drv_GlobalHeader.h"

#include "JIG_Svc.h"
#include "SWReg_Svc.h"
#include "AeLib_Svc.h"
#include "WB_Svc.h"
#include "Viewmode_Svc.h"
#include "WDRLib_Svc.h"
#include "Key_Svc.h"
#include "Sensor_Svc.h"
#include "WDR_AR0140_Svc.h"

#endif


