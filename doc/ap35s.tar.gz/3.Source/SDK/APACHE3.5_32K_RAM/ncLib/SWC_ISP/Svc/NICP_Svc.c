
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
        2016.01.26      M.Y Sung    0.0     platform change
********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "ISP_Drv.h"
#include "NICP_Svc.h"
#include "OSD_Drv.h"
#include "Category_Drv.h"

#define SIZE_2_BYTE 1
#define SENSOR_DEVICE_ID    0x20    //AR0140AT_DEVICEID
void NICP_OSDPrint_Set(STRUCT_MW_OSDSET *OsdSet)
{    
    INT32 Font_pos;
    UCHAR i;            
    UCHAR PosX = OsdSet->PosX; 
    UCHAR PosY = OsdSet->PosY; 
    UCHAR Style = OsdSet->Style; 
    UCHAR Color = OsdSet->Color; 
    UCHAR Option = 0;
    UCHAR FontIndex;

    UCHAR *TempIndex;
    

#if 0
    for(i=0; i<OsdSet->WriteCount; i++)
    {

        TempIndex = (OsdSet->CharList + i);

        FontIndex = *TempIndex;

        Font_pos = PosY * sMwOsd.NumX + PosX;

        rXSFR_BANK      = 0x00;
        *(SFR16)0xFF00  = 0x00;                                                                         // isp async mode
        *(SFR16)0xFF01  = (0x80 | (0x07 & (Font_pos >> 7)));                                            // bank set
                
        *(SFR16)0xFF02  = ((0xff & (Font_pos << 1)) | 0x01);                                            // address set  (MSB)
        Option = ((Style & 0x07) << 5) | ((Color & 0x07) << 2) | ((FontIndex >> 8) & 0x03);                       // wdata        (MSB)
        *(SFR16)0xFF03  = Option;
        *(SFR16)0xFF03  = Option;
        *(SFR16)0xFF03  = Option;
                
        *(SFR16)0xFF02  = (0xff & (Font_pos << 1));                                                         // address set  (LSB)     
        *(SFR16)0xFF03  = FontIndex & 0xFF;                                                                 // wdata        (LSB)
        *(SFR16)0xFF03  = FontIndex & 0xFF;                                                                 // wdata        (LSB)
        *(SFR16)0xFF03  = FontIndex & 0xFF;

		PosX++;
		
	}
#endif
}


static eNICP_RESPONSE_TYPE CMD_RESERVED(UCHAR Control)
{
	return eFAIL_COMMAND;
}

static eNICP_RESPONSE_TYPE CMD_ISP_READ(UCHAR Control)
{
    USHORT Address = (sMwNICP.RxBuffer[eRxBUFF_ADDR_MSB]<<8L)|sMwNICP.RxBuffer[eRxBUFF_ADDR_LSB];   /* Register Address */
    UCHAR DataCount = Control;
    UCHAR CheckSum = eSUCCESS;
    UCHAR i;
    
    /* Packet Length Error Check */
    if(sMwNICP.RxBuffer[eRxBUFF_PACKET_LENGTH] > PACKET_LENGTH_REG_READ)
    {
        return eFAIL_PACKET_LENGTH;
    }

    /* DataCount Error Check */
    if(!IsInRage(DataCount, 1, 125))
    {
        return eFAIL_DATA_COUNT;
    }

    /* Address Error Check */
    if(!IsInRage(Address, ADDC_STATUS_REG_START, ADDC_STATUS_REG_END) && /* Status Register */
       !IsInRage((Address+ISP_ADDRESS_START), ISP_ADDRESS_START, ISP_ADDRESS_END)) /* ISP Register */
    {
        return eFAIL_ADDRESS;
    }
    
    if(IsInRage((Address+ISP_ADDRESS_START), ISP_ADDRESS_START, ISP_ADDRESS_END)) /* ISP Register */
        Address += ISP_ADDRESS_START;

    /* Return Data */
    for(i=0; i<DataCount; i++)
    {
        rBank10->Byte.ExtMCUBuffer[i+2] = GetChar(Address+i);
    }

    for(i=0; i<rBank10->Byte.ExtMCUBuffer[eTxBUFF_PACKET_LENGTH]-1; i++)
    {
        CheckSum += rBank10->Byte.ExtMCUBuffer[i];
    }

    rBank10->Byte.ExtMCUBuffer[eTxBUFF_PACKET_LENGTH] = eTxBuFF_DEFAULT_COUNT + DataCount;
    rBank10->Byte.ExtMCUBuffer[eTxBUFF_RESPONSE_CODE] = eSUCCESS;
    rBank10->Byte.ExtMCUBuffer[(eTxBuFF_DEFAULT_COUNT + DataCount)-1L] = CheckSum;
    
	return eSUCCESS;
}

static eNICP_RESPONSE_TYPE CMD_ISP_WRITE(UCHAR Control)
{
    USHORT Address = (sMwNICP.RxBuffer[eRxBUFF_ADDR_MSB]<<8L)|sMwNICP.RxBuffer[eRxBUFF_ADDR_LSB];   /* Register Address */
    UCHAR DataCount = Control;
    UCHAR i;
    UCHAR StartIndex;
    UCHAR EndIndex;

    ULONG CategorySetFlag = 0x01;
    
    /* Packet Length Error Check */
    if(sMwNICP.RxBuffer[eRxBUFF_PACKET_LENGTH] > 128)
    {
        return eFAIL_PACKET_LENGTH;
    }

    /* DataCount Error Check */
    if(!IsInRage(DataCount, 1, 122))
    {
        return eFAIL_DATA_COUNT;
    }

    if(IsInRage(Address, ADDC_STATUS_REG_START, ADDC_STATUS_REG_END)) /* Status Register */
    {
        for(i=0; i < DataCount; i++)
        {
        	MW_StatusRegister_LinkFunction_Set(Address+i, sMwNICP.RxBuffer[eRxBUFF_DATA_1ST+i]);
		}

        StartIndex = MW_CategoryIndex_Get(Address);
        EndIndex = MW_CategoryIndex_Get(Address+DataCount);
        
        for(i=StartIndex; i<=EndIndex; i++)
        {
            sMwCategoryFlag.Category.D32 |= (CategorySetFlag << i);
		}
    }      
    else
    {
        Address += ISP_ADDRESS_START;
        
        for(i=0; i < DataCount; i++)
            SetChar(Address+i, sMwNICP.RxBuffer[eRxBUFF_DATA_1ST+i]);

        /* [2014/11/21] ktsyann : [STD]1-1 */
        if(IsInRage(Address,(USHORT)ADDF_AF_START, (USHORT)ADDF_AF_END))
            MW_AfWindow_Display_Set();
    }

 	return eSUCCESS;
}

static eNICP_RESPONSE_TYPE CMD_SENSOR_READ(UCHAR Control)
{   
    USHORT Address = (sMwNICP.RxBuffer[eRxBUFF_ADDR_MSB]<<8L)|sMwNICP.RxBuffer[eRxBUFF_ADDR_LSB];   /* Register Address */
    UCHAR DataCount = Control;
    UCHAR CheckSum = eSUCCESS;
    UCHAR i;
    UINT32 rdData;    
    
    /* Packet Length Error Check */
    if(sMwNICP.RxBuffer[eRxBUFF_PACKET_LENGTH] > PACKET_LENGTH_REG_READ)
    {
        return eFAIL_PACKET_LENGTH;
    }

    /* DataCount Error Check */
    if(!IsInRage(DataCount, 1, 63))
    {
        return eFAIL_DATA_COUNT;
    }

    /* Return Data */
    for(i=0; i < DataCount; i++)
    {
        ncLib_I2C_Read(I2C_CH0, SENSOR_DEVICE_ID, (Address + i), (UINT32 *)&rdData, 1, I2C_ADDR_16_DATA_16);

        rBank10->Byte.ExtMCUBuffer[(i * SIZE_2_BYTE) + 2] = rdData >> 8L;
        rBank10->Byte.ExtMCUBuffer[(i * SIZE_2_BYTE) + 3] = rdData & 0xFF;
        CheckSum += rdData >> 8L;
        CheckSum += rdData & 0xFF;
    }

    rBank10->Byte.ExtMCUBuffer[eTxBUFF_PACKET_LENGTH] = eTxBuFF_DEFAULT_COUNT + (DataCount*SIZE_2_BYTE);
    rBank10->Byte.ExtMCUBuffer[eTxBUFF_RESPONSE_CODE] = eSUCCESS;
    rBank10->Byte.ExtMCUBuffer[(eTxBuFF_DEFAULT_COUNT + (DataCount*SIZE_2_BYTE))-1L] = CheckSum;

	return eSUCCESS;
}

static eNICP_RESPONSE_TYPE CMD_SENSOR_WRITE(UCHAR Control)
{
    USHORT Address = (sMwNICP.RxBuffer[eRxBUFF_ADDR_MSB]<<8L)|sMwNICP.RxBuffer[eRxBUFF_ADDR_LSB];   /* Register Address */
    UCHAR DataCount = Control;
    USHORT TempData;
    UCHAR i;

    /* Packet Length Error Check */
    if(sMwNICP.RxBuffer[eRxBUFF_PACKET_LENGTH] > 128)
    {
        return eFAIL_PACKET_LENGTH;
    }

    /* DataCount Error Check */
    if(!IsInRage(DataCount, 1, 61))
    {
        return eFAIL_DATA_COUNT;
    }

    for(i=0; i < DataCount; i++)
    {
        TempData = sMwNICP.RxBuffer[eRxBUFF_DATA_1ST + (i*SIZE_2_BYTE)];
        TempData = (TempData << 8) | sMwNICP.RxBuffer[eRxBUFF_DATA_2ND + (i*SIZE_2_BYTE)];

        ncLib_I2C_Write(I2C_CH0, SENSOR_DEVICE_ID, (Address+i), TempData, 1, I2C_ADDR_16_DATA_16);        
    }
	return eSUCCESS;
}

static eNICP_RESPONSE_TYPE CMD_OSD_WRITE(UCHAR Control)
{   
    STRUCT_MW_OSDSET OsdSet;
   
    /* Packet Length Error Check */
    if(sMwNICP.RxBuffer[eRxBUFF_PACKET_LENGTH] > 128)
    {
        return eFAIL_PACKET_LENGTH;
    }

    /* DataCount Error Check */
    if(sMwNICP.RxBuffer[eRxBUFF_CONTROL] > 36)
    {
        return eFAIL_DATA_COUNT;
    }

    OsdSet.WriteCount = sMwNICP.RxBuffer[eRxBUFF_CONTROL];
    OsdSet.PosY = sMwNICP.RxBuffer[eRxBUFF_OSD_POSITION_Y];
    OsdSet.PosX = sMwNICP.RxBuffer[eRxBUFF_OSD_POSITION_X];
    OsdSet.Style = (sMwNICP.RxBuffer[eRxBUFF_OSD_OPTION] & 0xF0) >> 4;
    OsdSet.Color = (sMwNICP.RxBuffer[eRxBUFF_OSD_OPTION] & 0x0F);
    OsdSet.CharList = &sMwNICP.RxBuffer[eRxBUFF_OSD_DATA];
   
    MW_OSDClear_Set();
    NICP_OSDPrint_Set(&OsdSet);
    
    return eSUCCESS;
}

static eNICP_RESPONSE_TYPE CMD_OSD_CLEAR(UCHAR Control)
{
    /* Packet Length Error Check */
    if(sMwNICP.RxBuffer[eRxBUFF_PACKET_LENGTH] > 128)
    {
        return eFAIL_PACKET_LENGTH;
    }

    MW_OSDClear_Set();

    rBank10->Byte.ExtMCUBuffer[eRxBUFF_CONTROL]=0xFF; //Set Reset Value after OSDClear function

    return eSUCCESS;
}

void NICP_Task(void)
{
    STRUCT_NICP_COMMAND pNICP_CMD[eNICPCMD_MAX]=
    {
    	/* 00 [0x00] */ CMD_RESERVED,
    	/* 01 [0x01] */ CMD_ISP_READ,
    	/* 02 [0x02] */ CMD_ISP_WRITE,    	
    	/* 03 [0x03] */ CMD_SENSOR_READ,
    	/* 04 [0x04] */ CMD_SENSOR_WRITE,
    	/* 05 [0x05] */ CMD_OSD_WRITE,
    	/* 06 [0x06] */ CMD_OSD_CLEAR,
    };

    eNICP_RESPONSE_TYPE ResponseCode = eSUCCESS;
    UCHAR PacketLength  = sMwNICP.RxBuffer[eRxBUFF_PACKET_LENGTH];
    UCHAR Command = sMwNICP.RxBuffer[eRxBUFF_COMMAND];
    
    /* CheckSum Error Check */
    if(sMwNICP.RxCheckSum != sMwNICP.RxBuffer[PacketLength-1])
    {
        ResponseCode = eFAIL_CHECKSUM;
    }

    /* Command List Count Check */
    if(Command >= eNICPCMD_MAX)
    {
        ResponseCode = eFAIL_COMMAND;
    }

    /* Execute Command Protocol */
    if(ResponseCode == eSUCCESS) 
    {
        ResponseCode = pNICP_CMD[Command].Func(sMwNICP.RxBuffer[eRxBUFF_CONTROL]);
    }

    if(ResponseCode == eSUCCESS)
    {
        if((Command != eNICPCMD_ISP_READ) || (Command != eNICPCMD_SENSOR_READ))
        {
            rBank10->Byte.ExtMCUBuffer[eTxBUFF_PACKET_LENGTH] = TxPACKET_LENGTH_DEFAULT;
            rBank10->Byte.ExtMCUBuffer[eTxBUFF_RESPONSE_CODE] = eSUCCESS;
            rBank10->Byte.ExtMCUBuffer[eTxBUFF_CHECKSUM] = (TxPACKET_LENGTH_DEFAULT+eSUCCESS);
        }
    }
    else
    {
        rBank10->Byte.ExtMCUBuffer[eTxBUFF_PACKET_LENGTH] = TxPACKET_LENGTH_DEFAULT;
        rBank10->Byte.ExtMCUBuffer[eTxBUFF_RESPONSE_CODE] = ResponseCode;
        rBank10->Byte.ExtMCUBuffer[eTxBUFF_CHECKSUM] = (TxPACKET_LENGTH_DEFAULT+ResponseCode);
    }

    return;
}

void ncSvc_NICP_Set(void)
{
	UCHAR	PacketLength;
	UCHAR	Count;

	memset(sMwNICP.RxBuffer, 0, (128*sizeof(UCHAR)));	//Buffer Init
	sMwNICP.RxCheckSum = 0;								// CheckSum

	PacketLength = rBank10->Byte.ExtMCUBuffer[0];
	for(Count = 0; Count < PacketLength; Count++)
	{
		sMwNICP.RxBuffer[Count] = rBank10->Byte.ExtMCUBuffer[Count];
		rBank10->Byte.ExtMCUBuffer[Count] = 0xF0;// Buffer Reset
		if(Count<(PacketLength-1)) sMwNICP.RxCheckSum += sMwNICP.RxBuffer[Count];
	}
	
	NICP_Task(); /* [2015/03/02] Park Min : [STD]-01 */
}

