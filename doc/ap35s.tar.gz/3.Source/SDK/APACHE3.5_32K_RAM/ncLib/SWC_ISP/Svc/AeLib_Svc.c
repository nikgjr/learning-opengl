
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "APACHE35.h"
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Api_GlobalHeader.h"

//============================================================================
//      Define
//============================================================================
#define __MW_AE_DEBUG_OSD_
//#define __MW_AE_DEBUG_PRINTF_

//============================================================================
//      AE Normal(Only Long) Function Prototype
//============================================================================
USHORT AE_CalculateY(void);
UCHAR AE_CalculateYWeight(void);
void AE_SetAgcMode(void);
void AE_SetSensUpMode(void);
void AE_SetLensModeShutter(void);
void AE_SetIspDigitalGain(void);
void AE_RefreshShutterMode(void);
void AE_ConvertSVtoSensorValue(ULONG ExpSValue);
void AE_ConvertGVtoAgcLevel(USHORT ExpGValue);
ULONG AE_TrackingValueCalculate(etCALCULATE_TYPE CalType, dtAE_TRACKING_TYPE *pTrack, UCHAR Speed);
void AE_YAveraging(void);
void AE_Set(void);
void AE_Targeting(UCHAR CurrY);
void AE_Tracking(USHORT CurrY, USHORT TargetY);
void AE_Convert(void);

void AE_Iris_Open(void);
void AE_Iris_Close(void);
void AE_IrisScan_Set(void);
USHORT AE_Iris_Control(USHORT CurrY, USHORT TargetY);
void AE_Iris_stable_Control(USHORT CurrY, USHORT TargetY);
UCHAR AE_IrisAutoModeCheck(USHORT tCurrY, USHORT tTargetY, ULONG *tAShutMin, ULONG *tAShutMax);
void AE_Iris_Lens_Change(USHORT CurrY, USHORT TargetY);

void APP_AE_Init(void);

#define GPIOF1	            14
#define GPIOF2	            13
#define GPIOF3	            12
#define GPIOF4	            11
#define PIRIS_MAX_CNT		70
#define PIRIS_MIN_CNT		0
#define PIRIS_WAIT_MAX_CNT	10
#define PIRIS_WAIT_MIN_CNT	0

#define EXP_SV_NOT_USE      0
#define EXP_SV_60FPS_PAL    51200   /* [STD] MIN SV : 1/50(PAL) = 50fps x 4 sec x 256 */
#define EXP_SV_60FPS_NTSC   61440   /* [STD] MIN SV : 1/60(NTSC)= 60fps x 4 sec x 256 */
#define EXP_SV_30FPS_PAL    25600   /* [STD] MIN SV : 1/25(PAL) = 25fps x 4 sec x 256 */
#define EXP_SV_30FPS_NTSC   30720   /* [STD] MIN SV : 1/30(NTSC)= 30fps x 4 sec x 256 */

STRUCT_MW_AE		sMwAe;

/* [2014/9/3] JWLee : [STD]-01 */
ULONG LutManulSV[eCVBS_FORMAT][eFRAME_RATE_MAX][e30P_MANUAL_Max]= // x1024
{
/*=== Normal Shutter SV calculation (ex: 1/200) ===*/
/*           200 * 4 * 256 = 204800                */

/*=== LowShutter SV calcalation (ex: x8) ==========*/
/*         x8 = (1/60) * 8                         */
/*         60 * (4 * 256) / 8                      */
/*         61440 / 8 = 7680                        */

/* 30 FPS: Auto, 1/25, 1/50, Flicker(1/120), 1/200, 1/400, 1/1000, 1/2000, 1/5000, 1/10000, 1/50000, x2, x4, x6, x8, x10, x15, x20, x25, x30 */
/* 60 FPS: Auto, 1/50, Flicker(1/120), 1/200, 1/400, 1/1000, 1/2000, 1/5000, 1/10000, 1/50000, x2, x4, x6, x8, x10, x15, x20, x25, x30, NOT USE */

/* PAL 30 FPS */    {{   EXP_SV_30FPS_PAL, EXP_SV_30FPS_PAL, EXP_SV_60FPS_PAL,
            /* FLK */   122880, 204800, 409600, 1024000, 2048000, 5120000, 10240000, 51200000,
            /* x2  */   12800, 6400, 4266, 3200, 2560, 1706, 1280, 1024, 853},
            
/* PAL 60 FPS */    {  EXP_SV_60FPS_PAL, EXP_SV_60FPS_PAL, 
            /* FLK */   122880, 204800, 409600, 1024000, 2048000, 5120000, 10240000, 51200000, 
            /* x2  */   EXP_SV_30FPS_PAL, 12800, 8533, 6400, 5120, 3413, 2560, 2048, 1706, EXP_SV_NOT_USE}},

/* NTSC 30 FPS */   {{   EXP_SV_30FPS_NTSC, EXP_SV_30FPS_NTSC, EXP_SV_60FPS_NTSC,
            /* FLK */   102400, 245760,  491520, 1024000, 2048000, 5120000, 10240000, 51200000,
            /* x2  */   15360, 7680, 5120, 3840, 3072, 2048, 1536, 1228, 1024},
            
/* NTSC 60 FPS */   {  EXP_SV_60FPS_NTSC,  EXP_SV_60FPS_NTSC,      
            /* FLK */   102400, 245760, 491520, 1024000, 2048000, 5120000, 10240000, 51200000,
            /* x2  */   EXP_SV_30FPS_NTSC, 15360, 10240, 7680, 6144, 4096, 3072, 2457, 2048, EXP_SV_NOT_USE}}
};

const USHORT  LutdBtoGain[LUT_DB2GAIN_CNT] = {
/* 00~09db */     128,    144,    161,    181,    203,    228,    256,    287,    323,    362,
/* 10~19db */     406,    456,    512,    575,    645,    724,    813,    912,   1024,   1149,
/* 20~29db */    1290,   1448,   1625,   1825,   2048,   2299,   2580,   2896,   3251,   3649,
/* 30~29db */    4096,   4598,   5161,   5793,   6502,   7298,   8192,   9195,  10321,  11585,
/* 40~49db */   13004,  14596,  16384,  18180,  20406,  22905,  25710,  28858,  32392,  36359,
/* 50~54db */   40811,  45809,  51419,  57716,  65535,    };

const USHORT LutAGCMode[AGC_LIMIT_MODE][eAGC_MODE_MAX] = {  /* Referenced from WDRLib */
/*    AGC MODE    0  1  2  3  4   5   6   7   8   9  10   11  12    13   14   15 */
/* LIMIT x128 */{ 1, 2, 3, 4, 6,  8, 12, 16, 22, 30, 40,  48, 60,   78,  96, 128 }, 
/* LIMIT x256 */{ 1, 2, 3, 4, 6,  8, 12, 18, 24, 40, 56,  72, 96,  128, 172, 256 }, 
/* LIMIT x384 */{ 1, 2, 3, 5, 8, 12, 18, 26, 36, 62, 96, 128, 168, 256, 320, 384 }, 
/* LIMIT x512 */{ 1, 2, 3, 5, 8, 12, 18, 26, 36, 62, 96, 128, 168, 256, 384, 512 }};

STRUCT_AE_SET_TYPE sAppAeSet;

void Debug_Viewer_AELib(void)
{
#if 1
    /* Information for customer. */
    APP_OSDPrint_String(2, 1, (UCHAR*)"TY/CY");
    APP_OSDPrint_Hex(2, 7, (UCHAR)sMwAe.Tracking.BoundaryStatus | sMwAe.Tracking.TrackingSet);        
    APP_OSDPrint_Hex(2, 10, (UCHAR)sMwAe.Tracking.TargetY);
    APP_OSDPrint_String(2, 12, (UCHAR*)"/");
    APP_OSDPrint_Hex(2, 13, (UCHAR)sMwAe.Tracking.CurrY);

    APP_OSDPrint_String(4, 1, (UCHAR*)"SHUTTER   1/");
    APP_OSDPrint_Dec(4, 13,(USHORT)sMwAe.Tracking.Shutter);
    APP_OSDPrint_String(5, 1, (UCHAR*)"AGC/RTO");
    APP_OSDPrint_Hex(5, 10, (UCHAR)sMwAe.Agc.Level);
    APP_OSDPrint_String(5, 12, (UCHAR*)"/");
    APP_OSDPrint_Hex(5, 13, (UCHAR)sMwAe.Agc.Ratio); 

    APP_OSDPrint_String(7, 1, (UCHAR*)"F IRIS");
    APP_OSDPrint_Hex2(7, 10, (USHORT)0x0000);
    APP_OSDPrint_String(8, 1, (UCHAR*)"S IRIS");
    APP_OSDPrint_Hex2(8, 10, (USHORT)0x0000);
    APP_OSDPrint_String(9, 1, (UCHAR*)"B PWM");
    APP_OSDPrint_Hex2(9, 10, (USHORT)0x0000);

    /* Information for developers. */
    APP_OSDPrint_String(11, 1, (UCHAR*)"STEP");
    APP_OSDPrint_Hex(11, 10, (UCHAR)sMwAe.Tracking.Step);
    APP_OSDPrint_String(12, 1, (UCHAR*)"TL");
    APP_OSDPrint_Dec(12, 10, (USHORT)sAppAeSet.VTotalLine);
    APP_OSDPrint_String(13, 1, (UCHAR*)"EL");
    APP_OSDPrint_Dec(13, 10,(USHORT)sAppAeSet.ExposureLine);
    APP_OSDPrint_String(14, 1, (UCHAR*)"TG");
    APP_OSDPrint_Hex2(14, 10, (USHORT)sAppAeSet.TotalGain);
    APP_OSDPrint_String(15, 1, (UCHAR*)"SG");
    APP_OSDPrint_Hex2(15, 10, (USHORT)sAppAeSet.SensorGain);
    APP_OSDPrint_String(16, 1, (UCHAR*)"IG");
    APP_OSDPrint_Hex2(16, 10, (USHORT)sMwAe.Isp.GVTotal);
#endif
}


void ncSvc_AE_Reset(void)
{
    sMwAe.Tracking.SVDefault = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT];
    sMwAe.Tracking.SV = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT];
    sMwAe.Tracking.GV = GAIN_VALUE_MIN;
    sMwAe.Tracking.GVRangeMin = GAIN_VALUE_MIN;
    sMwAe.Sensor.VTotalLine = SENSOR_VTOTAL_DEFAULT[INPUT_SIZE];
    sMwAe.Isp.GVCompSG = GAIN_VALUE_MIN; 
    sMwAe.Isp.GVTotal = GAIN_VALUE_MIN;

    if(rSWReg.Category.AE.Reg.LENS_MODE == eLENS_MODE_MANUAL)
	{
        AE_Iris_Open();
        sMwAe.Tracking.Step = eAE_STEP_SHUT;
    }
	else
	{
        sMwAe.Tracking.Step = eAE_STEP_IRIS;
    }

	sMwAe.Tracking.Step = eAE_STEP_SHUT;
      
    sMwAe.Tracking.TrackingSet = eAE_TRACKING_ON;
}

void ncSvc_AE_Init(void)
{
    ncSvc_AE_Reset();

    sMwSystem.Control.Run.AE = STATE_ON;   // AE Process Enable

    /* [2014/2/25] sky : NTSC/PAL ������� Target�� �ʱ�ȭ �Ѵ�. */
    if(rSWReg.Category.AE.Reg.BRIGHTNESS_NTSC == 0L)  rSWReg.Category.AE.Reg.BRIGHTNESS_NTSC = 1L;
    if(rSWReg.Category.AE.Reg.BRIGHTNESS_PAL == 0L)   rSWReg.Category.AE.Reg.BRIGHTNESS_PAL = 1L;
    
    rIP_ADJ_EN          = STATE_ON;
    rIP_ADJ_GAIN_14_8   = sMwAe.Isp.GVTotal >> 8;
    rIP_ADJ_GAIN_7_0    = sMwAe.Isp.GVTotal;
        
    // Shutter Menu Init
    AE_SetLensModeShutter();
    AE_SetAgcMode();

    // IRIS Init
    sMwAe.Iris.GainLevel  = IRIS_CLOSE_VALUE;
    sMwAe.Iris.RefLevel  = 0x00;

#if 0
    
    rIP_IRIS_2ND_AGCLEVEL_13_8    = ((sMwAe.Iris.GainLevel >> 8) & 0xFF);
    rIP_IRIS_2ND_AGCLEVEL_7_0 = (sMwAe.Iris.GainLevel & 0xFF);         

    // IRIS Control Fix Value/////////////////////////////////////////////////////
    rIP_IRIS_PWM_BASE_MAX_15_8 = 0xFF;
    rIP_IRIS_PWM_BASE_MAX_7_0  = 0xFF;

    rIP_IRIS_PWM_MAX_15_8 = 0x04;
    rIP_IRIS_PWM_MAX_7_0  = 0x00;     

    rIP_IRIS_PWM_ACC_EN   = STATE_ON; 

    rIP_IRIS_PWM_ACC_SHIFT    = 0x08;
    
    rIP_IRIS_1ND_AGCLEVEL_13_8 = ((0x80>> 8) & 0xFF);
    rIP_IRIS_1ND_AGCLEVEL_7_0 = (0x80 & 0xFF);            
#endif
    
    ///////////////////////////////////////////////////////////////////
    //AE_IrisScan_Set();
    /////////////////////////////////////////////////////////////////// 

    // Uart Command�� ó���� ���� ������ AE ���� ����. 
#if 0
    sHalUart.CmdProcess = 0;
#endif

}

/* [2015/03/06] JWLee : [STD]-02 */
FLOAT ncSvc_AE_ConvertGainTodB(GAIN_VALUE_TYPE GainValue)
{
    UCHAR i;
    USHORT GainDiff;
    USHORT dBStep;
    FLOAT ConvDB;
    
    for (i=0; i <= LUT_DB2GAIN_CNT; i++)
    {
        if (GainValue <= LutdBtoGain[i]) break;
    }

    GainDiff = GainValue - LutdBtoGain[i-1];
    dBStep = LutdBtoGain[i] - LutdBtoGain[i-1];

    ConvDB = i-1;                                       /* Integer */
    ConvDB += (FLOAT)((FLOAT)GainDiff / (FLOAT)dBStep); /* Float   */

    return ConvDB;
}

void ncSvc_AE_SensorFPSSet(etFRAME_RATE SensorFrameRate)
{
    if(sMwAe.Tracking.SensorFrameRate != SensorFrameRate && sMwAe.Tracking.SensorFrameRate != eFRAME_RATE_INIT)
    {
        if(SensorFrameRate == eFRAME_RATE_60)           // 30P->60P
        {
            if(rSWReg.Category.AE.Reg.DC_LENS_INDOOR_SHUT > SHUT_MODE_DEFAULT)    rSWReg.Category.AE.Reg.DC_LENS_INDOOR_SHUT -= 1;
            if(rSWReg.Category.AE.Reg.DC_LENS_OUTDOOR_SHUT > SHUT_MODE_DEFAULT)   rSWReg.Category.AE.Reg.DC_LENS_OUTDOOR_SHUT -= 1;
            if(rSWReg.Category.AE.Reg.MANUAL_LENS_SHUT > SHUT_MODE_DEFAULT)       rSWReg.Category.AE.Reg.MANUAL_LENS_SHUT -= 1;
        }
        else if(sMwAe.Tracking.SensorFrameRate == eFRAME_RATE_30)    // 60P->30P
        {
            if(rSWReg.Category.AE.Reg.DC_LENS_INDOOR_SHUT > SHUT_MODE_DEFAULT)    rSWReg.Category.AE.Reg.DC_LENS_INDOOR_SHUT += 1;
            if(rSWReg.Category.AE.Reg.DC_LENS_OUTDOOR_SHUT > SHUT_MODE_DEFAULT)   rSWReg.Category.AE.Reg.DC_LENS_OUTDOOR_SHUT += 1;
            if(rSWReg.Category.AE.Reg.MANUAL_LENS_SHUT > SHUT_MODE_DEFAULT)       rSWReg.Category.AE.Reg.MANUAL_LENS_SHUT += 1;
        }
    }

    sMwAe.Tracking.SensorFrameRate = SensorFrameRate;
    sMwAe.Tracking.SVDefault = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SHUT_MODE_DEFAULT];

    AE_SetLensModeShutter();
}

void ncSvc_AE_IspDGainAlphaSet(USHORT IspDigitalGain)
{
    static USHORT GVCompSGBuf;

    if(IspDigitalGain < GAIN_VALUE_MIN) IspDigitalGain = GAIN_VALUE_MIN;

    sMwAe.Isp.GVCompSG = GVCompSGBuf;

    GVCompSGBuf = IspDigitalGain;
}

void ncSvc_AE_Task(void)
{ 
    if(sWdr.Mode == STATE_OFF)    AE_YAveraging();

    if(sMwSystem.Control.Run.AE)
    {   
        if(sWdr.Mode == STATE_OFF)
        {
            AE_Targeting(sMwAe.Tracking.CurrY);
            AE_Tracking(sMwAe.Tracking.CurrY, sMwAe.Tracking.TargetY);
            AE_Convert(); 
            AE_Set();
        }
        else
        {             
            ncSvc_WDR_Task();
           
        }
    }

    if(rSWReg.Category.AE.Reg.AE_OSD_VIEW)
    {
        APP_OSDPrint_String(3, 3, (UCHAR*)"TargetY");
        APP_OSDPrint_Dec(3, 11, (USHORT)sMwAe.Tracking.TargetY);
        
        APP_OSDPrint_String(4, 3, (UCHAR*)"Curr L Y");
        APP_OSDPrint_Dec(4, 11, (USHORT)rIP_OPD_Y_BLOCK_AVG_L);

        APP_OSDPrint_String(5, 3, (UCHAR*)"Curr M Y");
        APP_OSDPrint_Dec(5, 11,  (USHORT)rIP_OPD_Y_BLOCK_AVG_M);               

        APP_OSDPrint_String(6, 3, (UCHAR*)"Curr S Y");
        APP_OSDPrint_Dec(6, 11,  (USHORT)rIP_OPD_Y_BLOCK_AVG_S);               

        APP_OSDPrint_String(7, 3, (UCHAR*)"SenELC");
        APP_OSDPrint_Dec(7, 11,(USHORT)sMwAe.Sensor.ExposureLIne);
        APP_OSDPrint_String(8, 3, (UCHAR*)"AGC/RTO");
        APP_OSDPrint_Hex(8, 11, (USHORT)sMwAe.Agc.Level);     
        APP_OSDPrint_String(9, 13, (UCHAR*)"/");        
        APP_OSDPrint_Hex(9, 14, (UCHAR)sMwAe.Agc.Ratio); 
        APP_OSDPrint_String(10, 3, (UCHAR*)"IRIS1ST");
        APP_OSDPrint_Dec(10, 11,  (USHORT)sMwAe.Iris.FirstGainLevel);        
        APP_OSDPrint_String(11, 3, (UCHAR*)"IRIS2ND");
        APP_OSDPrint_Dec(11, 11,  (USHORT)sMwAe.Iris.GainLevel);               
    }
}

void AE_RefreshShutterMode(void)
{
    static et30P_MANUAL_SHUT_TYPE preShutterMode = SHUT_MODE_INIT;

    if(preShutterMode != rSWReg.Category.AE.Reg.SHUTTER)
    {
        AE_Iris_Open();
        sMwAe.Tracking.SV = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][rSWReg.Category.AE.Reg.SHUTTER];
        sMwAe.Tracking.TrackingSet = eAE_TRACKING_ON;
    }

    preShutterMode = (et30P_MANUAL_SHUT_TYPE)rSWReg.Category.AE.Reg.SHUTTER;
}

void AE_SetLensModeShutter(void)
{
    static etLENS_MODE preLensMode = LENS_MODE_INIT;
    
    switch(rSWReg.Category.AE.Reg.LENS_MODE)
    {
        case eLENS_MODE_DC:
            if(rSWReg.Category.AE.Reg.DC_LENS_MODE == eDC_INDOOR)
                rSWReg.Category.AE.Reg.SHUTTER = rSWReg.Category.AE.Reg.DC_LENS_INDOOR_SHUT;            
            else if(rSWReg.Category.AE.Reg.DC_LENS_MODE == eDC_OUTDOOR)
                rSWReg.Category.AE.Reg.SHUTTER = rSWReg.Category.AE.Reg.DC_LENS_OUTDOOR_SHUT;           
            break;
        case eLENS_MODE_MANUAL:
            rSWReg.Category.AE.Reg.SHUTTER = rSWReg.Category.AE.Reg.MANUAL_LENS_SHUT;
            break;
        case eLENS_MODE_PIRIS:
            break;      
    }

    if(preLensMode != rSWReg.Category.AE.Reg.LENS_MODE)
    {
        if(rSWReg.Category.AE.Reg.LENS_MODE == eLENS_MODE_MANUAL)
        {
            AE_Iris_Open();
            sMwAe.Tracking.Step = eAE_STEP_SHUT;
        }
        else
        {   
            sMwAe.Tracking.Step = eAE_STEP_IRIS;
        }

        if(sMwAe.Tracking.Step >= eAE_STEP_GAIN)
        {   
            sMwAe.Tracking.SV = sMwAe.Tracking.SVDefault;
            sMwAe.Tracking.GV = GAIN_VALUE_MIN;
        }

        sMwAe.Tracking.TrackingSet = eAE_TRACKING_ON;
    }

    preLensMode = (etLENS_MODE)rSWReg.Category.AE.Reg.LENS_MODE;

    AE_RefreshShutterMode();
}

/******************************************************************************************************
* Function Name : AE_SetAgcMode
* Argument      : void
* Return        : void
* Description   : set GVRangeMax by AGC MODE
                : Reset GV in case of GV > GVRangeMax
*******************************************************************************************************/
void AE_SetAgcMode(void)
{
    static etAGC_MODE preAGCMode = AGC_MODE_INIT;
    static UCHAR preAGCLimit = 0xAA;

    sMwAe.Tracking.GVRangeMax = (GAIN_VALUE_TYPE)(LutAGCMode[rSWReg.Category.AE.Reg.AGC_LIMIT][rSWReg.Category.AE.Reg.AGC_MODE] * GAIN_VALUE_MIN);
    if(sMwAe.Tracking.GVRangeMax == 0x0000)   sMwAe.Tracking.GVRangeMax = AE_GAIN_512X;  //Overflow 52dB: 65536GV

    if((preAGCMode != rSWReg.Category.AE.Reg.AGC_MODE)||(preAGCLimit !=rSWReg.Category.AE.Reg.AGC_LIMIT))
    {
        if (sMwAe.Tracking.Step >= eAE_STEP_GAIN)
        {
            // Sensup ���� ���¿��� AGC_MODE ���� �� ���� ���� ���� : Added by shpark[20140125]
            // ���� ���� : AGC_MODE���� ���ȴٰ� �ٽ� �ø���� AGC�������� ����
            if(sMwAe.Tracking.GV >= sMwAe.Tracking.GVRangeMax)
            {
               sMwAe.Tracking.SV = sMwAe.Tracking.SVDefault;
               sMwAe.Tracking.GV = sMwAe.Tracking.GVRangeMax;
            }
        }

        if(sMwAe.Tracking.Step == eAE_STEP_GAIN || sMwAe.Tracking.Step == eAE_STEP_SENSUP)
        {
            sMwAe.Tracking.Step = eAE_STEP_GAIN; 
            sMwAe.Tracking.TrackingSet = eAE_TRACKING_ON;
        }
    }
    preAGCMode = (etAGC_MODE)rSWReg.Category.AE.Reg.AGC_MODE;
    preAGCLimit = rSWReg.Category.AE.Reg.AGC_LIMIT;
}

void AE_SetSensUpMode(void)
{
    et30P_MANUAL_SHUT_TYPE  SensUpStartIdx = (et30P_MANUAL_SHUT_TYPE)(sMwAe.Tracking.SensorFrameRate ? (UCHAR)SENSUP_START_IDX_60P : (UCHAR)SENSUP_START_IDX_30P);
    ULONG SVRangeMin = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SensUpStartIdx + rSWReg.Category.AE.Reg.SENS_UP];
    
    if(sMwAe.Tracking.Step >= eAE_STEP_GAIN)
    {
        if(rSWReg.Category.AE.Reg.SENS_UP_MODE == eSENSUP_OFF) 
        {
            sMwAe.Tracking.Step = eAE_STEP_GAIN; 
            sMwAe.Tracking.SV = sMwAe.Tracking.SVDefault;
        }
        else
        {
            if(sMwAe.Tracking.SV < SVRangeMin)
                sMwAe.Tracking.SV = SVRangeMin;
        }
        
    }
    sMwAe.Tracking.TrackingSet = eAE_TRACKING_ON;    
}

/******************************************************************************************************
* Function Name : AE_SetIspDigitalGain
* Argument      : void
* Return        : void
* Description   : Write Isp.GVTotal to ISP ADJ_Gain Register
                : Isp.GVTotal = sMwAe.Isp.GVCompSG x sMwAe.Isp.GVCompHS
*******************************************************************************************************/
void AE_SetIspDigitalGain(void)
{
    static USHORT GVCompHSBuf;      //1VD Dealy buffer
//=======================================================================================
//  ISP Digital Gain * Sensor Digital gain(ISP)
//=======================================================================================
    
    sMwAe.Isp.GVTotal = (USHORT)(((ULONG)(sMwAe.Isp.GVCompSG) * (ULONG)(GVCompHSBuf)) >> 7);

//=======================================================================================
//  ISP Digital gain Set
//=======================================================================================
    rIP_ADJ_GAIN_14_8 = ((sMwAe.Isp.GVTotal>>8) & 0x0F);
    rIP_ADJ_GAIN_7_0 = (sMwAe.Isp.GVTotal & 0xFF);

    GVCompHSBuf = sMwAe.Isp.GVCompHS;
}

USHORT AE_CalculateY(void)
{
    UCHAR   i;
    USHORT  Avg_Y_Value;
    UCHAR   HistoRatio0, HistoRatio15;
    FLOAT   HistoNum;
    FLOAT   HistoTotNum = 0;
    FLOAT   HistoWeightNum;
    FLOAT   HistoWeightVal;
    FLOAT   HistoWeightTotNum = 0;
    FLOAT   AlphaValue;

    if(ncDrv_TdnStatus_Get() == DN_STATUS_BW && rSWReg.Category.TDN.Reg.BW_IR_SMART == eMODE_ON)
        sMwAe.Tracking.OPDWeightMode = eOPDWEIGHT_IRSMART;
    else if(rSWReg.Category.BACKLIGHT.Reg.BACKLIGHT_MODE == eBACKLIGHT_BLC)
        sMwAe.Tracking.OPDWeightMode = eOPDWEIGHT_BLC;
    else
        sMwAe.Tracking.OPDWeightMode = eOPDWEIGHT_NORMAL;

    if((sMwAe.Tracking.OPDWeightMode == eOPDWEIGHT_BLC)||(sMwAe.Tracking.OPDWeightMode == eOPDWEIGHT_IRSMART))
    {
        Avg_Y_Value = AE_CalculateYWeight();
    }
    else
    {
        //MW_DelayMs_Set(1); /* [2014/4/22] SWG : ���� ���� ����! ������ ���ù߻�. */
        if(rSWReg.Category.AE.Reg.WEIGHT_MODE)
        {
            for(i=0; i<16; i++)
            {
                HistoNum            = ISPGET08(aIP_OPD_HISTO_RATIO0_7_0 + i);
                HistoWeightVal      = ISPGET08(ADDR_OPD_HISTO_WEIGHT0 + i);
                HistoWeightNum      = HistoNum * ((HistoWeightVal+1)/(FLOAT)0x20);

                HistoTotNum        += HistoNum;
                HistoWeightTotNum  += HistoWeightNum;
            }

            ////////////////////////////////////////////////////////////////////////////////////////
            // Histogram Ratio�� �Ǵ��ؼ� �����ο���� ��������������� AGC���� �����ؼ�      //
            // �ְ� �������� ������ �����ʰ�, �Ͻ� ������ ��������� ��ȭ�Ǵ� ������ ���̱� ����  //
            ////////////////////////////////////////////////////////////////////////////////////////
            HistoRatio0 = rIP_OPD_HISTO_RATIO0_7_0;
            HistoRatio15 = rIP_OPD_HISTO_RATIO15_7_0;

            AlphaValue = ncDrv_Transition((HistoRatio0+HistoRatio15)*(FLOAT)sMwAe.Agc.Level, 0, 0x7FFF, 0, 1) + 1;
            Avg_Y_Value = (USHORT)((FLOAT)rIP_OPD_Y_BLOCK_AVG_L * ((HistoWeightTotNum*AlphaValue)/HistoTotNum));
        }
        else
        {
            Avg_Y_Value = rIP_OPD_Y_BLOCK_AVG_L;        
        }
    }

    Avg_Y_Value = (Avg_Y_Value == 0 ? 1 : Avg_Y_Value);
    
    return Avg_Y_Value;
}

//#define aIP_OPD_BLOCK_Y 0x0AC0

UCHAR AE_CalculateYWeight(void)
{
    USHORT  Area_Weight_Num=0, nArea_Weight_Num=0;
    UCHAR OpdIdx;
    FLOAT   Area_Y_Value=0, nArea_Y_Value=0;
    FLOAT   Avg_Y_Value_Temp=0;
    USHORT  NormalY, WeightY;
    UCHAR GridXStart, GridXEnd, GridYStart, GridYEnd;
/* [2015/01/29] SJH : STD-01 */
	if(sMwAe.Tracking.OPDWeightMode == eOPDWEIGHT_BLC)
   {
	   GridXStart = rSWReg.Category.BACKLIGHT.Reg.BLC_POSITION_X;
	   GridXEnd = rSWReg.Category.BACKLIGHT.Reg.BLC_POSITION_X + rSWReg.Category.BACKLIGHT.Reg.BLC_SIZE_X;
	   GridYStart = rSWReg.Category.BACKLIGHT.Reg.BLC_POSITION_Y;
	   GridYEnd = rSWReg.Category.BACKLIGHT.Reg.BLC_POSITION_Y + rSWReg.Category.BACKLIGHT.Reg.BLC_SIZE_Y;
   }
   else    //eOPDWEIGHT_IRSMART
   {
	   GridXStart = rSWReg.Category.TDN.Reg.BW_IR_SMART_POS_X;
	   GridXEnd = rSWReg.Category.TDN.Reg.BW_IR_SMART_POS_X + rSWReg.Category.TDN.Reg.BW_IR_SMART_SIZE_X;
	   GridYStart = rSWReg.Category.TDN.Reg.BW_IR_SMART_POS_Y;
	   GridYEnd = rSWReg.Category.TDN.Reg.BW_IR_SMART_POS_Y + rSWReg.Category.TDN.Reg.BW_IR_SMART_SIZE_Y;
   }

    for(OpdIdx=0; OpdIdx<sMwOpd.Size.Total; OpdIdx++)
    {
        if(
            (((OpdIdx%sMwOpd.Size.Width) >= GridXStart) && ((OpdIdx%sMwOpd.Size.Width) < GridXEnd))
            &&
            (((OpdIdx/sMwOpd.Size.Width) >= GridYStart) && ((OpdIdx/sMwOpd.Size.Width) < GridYEnd))
        )
        {
            Area_Y_Value += ISPGET08(aIP_OPD_BLOCK_Y + OpdIdx);
            Area_Weight_Num++;
        }
        else
        {
            nArea_Y_Value += ISPGET08(aIP_OPD_BLOCK_Y + OpdIdx);
            nArea_Weight_Num++;
        }
    }

    if(Area_Weight_Num == 0)     Area_Weight_Num = 1;
    if(nArea_Weight_Num == 0)    nArea_Weight_Num = 1;
    
    if(sMwAe.Tracking.OPDWeightMode == eOPDWEIGHT_BLC)
    {
        if(rSWReg.Category.BACKLIGHT.Reg.BLC_GAIN == eLEVEL3_LOW)
        {
            Area_Y_Value = Area_Y_Value * 0.6;
            nArea_Y_Value = nArea_Y_Value * 0.4;
        }
        else if(rSWReg.Category.BACKLIGHT.Reg.BLC_GAIN == eLEVEL3_MIDDLE)
        {
            Area_Y_Value = Area_Y_Value * 0.79;
            nArea_Y_Value = nArea_Y_Value * 0.21;
        }
		else// if(rSWReg.Category.BACKLIGHT.Reg.BLC_GAIN == eLEVEL3_HIGH)
        {
            Area_Y_Value = Area_Y_Value * 0.99;
            nArea_Y_Value = nArea_Y_Value * 0.01;
        }
        
        NormalY = (USHORT)(Area_Y_Value/Area_Weight_Num);
        WeightY = (USHORT)(nArea_Y_Value/nArea_Weight_Num);
        Avg_Y_Value_Temp = NormalY + WeightY;       
    }
    else    //eOPDWEIGHT_IRSMART
    {
        Area_Y_Value = Area_Y_Value * (0.5 + (0.03*(rSWReg.Category.TDN.Reg.BW_IR_SMART_LEVEL+1)));
        nArea_Y_Value = nArea_Y_Value * (0.5 - (0.03*(rSWReg.Category.TDN.Reg.BW_IR_SMART_LEVEL+1)));

        Avg_Y_Value_Temp =  (((FLOAT)(Area_Y_Value/Area_Weight_Num) + (FLOAT)(nArea_Y_Value/nArea_Weight_Num)))  
                            *  (FLOAT)(1+(FLOAT)(rSWReg.Category.TDN.Reg.BW_IR_SMART_LEVEL*0.14));
    }
    
    if(Avg_Y_Value_Temp > 255)  Avg_Y_Value_Temp = 255;
    
    return (UCHAR)Avg_Y_Value_Temp;    
}

/******************************************************************************************************
* Function Name : AE_YAveraging
* Argument      : void
* Return        : void
* Description   : 
*******************************************************************************************************/
void AE_YAveraging(void)
{
    static UCHAR preY_AVG_ACC_FRAME_COUNT;
   // static BUFFER_AVERAGE_16BIT_TYPE CurrYBuff;

    if(preY_AVG_ACC_FRAME_COUNT != rSWReg.Category.AE.Reg.Y_AVG_ACC_FRAME_COUNT)
    {
#if 0
        CurrYBuff.BuffCntInit = 0;
        CurrYBuff.BuffIdx = 0;
        CurrYBuff.AccValue = 0;
#endif

        preY_AVG_ACC_FRAME_COUNT = rSWReg.Category.AE.Reg.Y_AVG_ACC_FRAME_COUNT;    
    }

    sMwAe.Tracking.CurrY = AE_CalculateY();
    //sMwAe.Tracking.CurrY = ncLib_Standard_Control(eSTD_BUFFER_AVG_16BIT, (rSWReg.Category.AE.Reg.Y_AVG_ACC_FRAME_COUNT+1), AE_CalculateY(), CMD_END); //&CurrYBuff, 
}

/******************************************************************************************************
* Function Name : AE_Targeting
* Argument      : UCHAR CurrY
* Return        : void
* Description   : 1. choose AE target between BRIGHTNESS(NTSC/PAL) & LOW_LIGHT_TARGET
                : 2. Decide weather use eAE_STEP_GAIN & AE_STEP_SENS_UP
                : Lower value is used for lowlight target between BRIGHTNESS(NTSC/PAL) & LOW_LIGHT_TARGET
*******************************************************************************************************/
void AE_Targeting(UCHAR CurrY)
{
/* [2015/04/06] JWLee : [STD]-01 */
/* [2015/02/13] SJH : [STD]-01 */
    static BOOL preLowLightMode = STATE_ON;
    UCHAR NormalTarget =  CVBS_FORMAT ? rSWReg.Category.AE.Reg.BRIGHTNESS_NTSC : rSWReg.Category.AE.Reg.BRIGHTNESS_PAL;
    UCHAR LowerTarget = _min(rSWReg.Category.AE.Reg.LOW_LIGHT_TARGET, NormalTarget);

    if(rSWReg.Category.AE.Reg.LOW_LIGHT_MODE == STATE_ON)
    {
        if(NormalTarget < rSWReg.Category.AE.Reg.LOW_LIGHT_TARGET)	 sMwAe.Tracking.TargetY = NormalTarget;

        if(CurrY < LowerTarget)
        {
            sMwAe.Tracking.LowLightState = eSTEP_GAIN_ENABLE;
            sMwAe.Tracking.TargetY = LowerTarget;          
        }
        else
        {
            if(sMwAe.Tracking.Step <= eAE_STEP_SHUT)
            {
                sMwAe.Tracking.LowLightState = eSTEP_GAIN_DISABLE;
                sMwAe.Tracking.TargetY = NormalTarget;
            }
        }

        if(CurrY > LowerTarget && preLowLightMode == STATE_OFF)
        {   /* mode change from LL OFF -> LL ON */
            sMwAe.Tracking.LowLightState = eSTEP_GAIN_DISABLE;
            sMwAe.Tracking.TargetY = NormalTarget;
        }
    }
    else
    {
        sMwAe.Tracking.LowLightState = eSTEP_GAIN_ENABLE;
        sMwAe.Tracking.TargetY = NormalTarget;
    }

    preLowLightMode = rSWReg.Category.AE.Reg.LOW_LIGHT_MODE;

}

ULONG AE_TrackingValueCalculate(etCALCULATE_TYPE CalType, dtAE_TRACKING_TYPE *pTrack, UCHAR Speed)
{
    ULONG   CurrVal;
    ULONG   CalMin, CalMax;
    ULONG   CalcValue;
    FLOAT   DiffYRatio;
    FLOAT   DiffYRatioCal;
    FLOAT   AlphaValue;

    /* _____________________ PREPARE TO CALCULATE ___________________ */
    if(CalType == CALC_SV)
    {
        CurrVal = pTrack->SV;
        CalMin = pTrack->SVRangeMin;
        CalMax = pTrack->SVRangeMax;
        DiffYRatio = (FLOAT)pTrack->CurrY/(FLOAT)pTrack->TargetY;
    }
    else
    {
        CurrVal = pTrack->GV;
        CalMin = pTrack->GVRangeMin;
        CalMax = pTrack->GVRangeMax;
        DiffYRatio = (FLOAT)pTrack->TargetY/(FLOAT)pTrack->CurrY;
    }

    if(Speed == 0)  return CurrVal;
    
    /* _____________________ CALCULATE ALPHA _______________________ */
    
    if (DiffYRatio > 1) DiffYRatioCal = DiffYRatio - 1;
    else                DiffYRatioCal = 1 - DiffYRatio;

    AlphaValue = (DiffYRatioCal * Speed) / 1024.0;

    if (DiffYRatio > 1) AlphaValue = AlphaValue + 1;
    else                AlphaValue = 1 - (AlphaValue * 4.0);    

    /* _____________________ CALCULATE FINAL VALUE _________________ */
    
    CalcValue = (ULONG)(CurrVal * AlphaValue);
    
    if (CalcValue > CalMax)     CalcValue = CalMax;
    if (CalcValue < CalMin)     CalcValue = CalMin;

    return CalcValue;
}


void AE_Tracking(USHORT CurrY, USHORT TargetY)
{   
    typedef struct {
        PIRIS_MODE              PIrisMode;
        etLENS_MODE             LensMode;
        et30P_MANUAL_SHUT_TYPE  Shutter;
        UCHAR                   ShutterControlSpeed;
        etAGC_MODE              AgcMode;
        UCHAR                   AgcControlSpeed;
        etSENSUP_MODE           SensUpMode;
        UCHAR                   SensUpLevel;
        //BOOL                    SensUpInternalMode;
        //UCHAR                   SensUpInternalAgc;
        //UCHAR                   SensUpInternal;
    }TRACKING_REG_TYPE;
    TRACKING_REG_TYPE sAeSwReg;

    BOOL    UseGainStep;
   // BOOL    UseSensUpStep;
    
    //et30P_MANUAL_SHUT_TYPE  SensUpStartIdx = (et30P_MANUAL_SHUT_TYPE)(sMwAe.Tracking.SensorFrameRate ? (UCHAR)SENSUP_START_IDX_60P : (UCHAR)SENSUP_START_IDX_30P);

    UCHAR DiffY;
    UCHAR DiffBoundary;
    ULONG TempSV;
    ULONG ExpSVMax = ((ULONG)(SENSOR_VTOTAL_DEFAULT[INPUT_SIZE])*sMwAe.Tracking.SVDefault) /SENSOR_EXPOSURE_MIN; 

    sAeSwReg.PIrisMode = (PIRIS_MODE)rSWReg.Category.AE.Reg.PIRIS_MODE;
    sAeSwReg.LensMode = (etLENS_MODE)rSWReg.Category.AE.Reg.LENS_MODE;
    sAeSwReg.Shutter = (et30P_MANUAL_SHUT_TYPE)rSWReg.Category.AE.Reg.SHUTTER;
    sAeSwReg.ShutterControlSpeed = rSWReg.Category.AE.Reg.SHUTTER_CONTROL_SPEED;
    sAeSwReg.AgcMode = (etAGC_MODE)rSWReg.Category.AE.Reg.AGC_MODE;
    sAeSwReg.AgcControlSpeed = rSWReg.Category.AE.Reg.AGC_CONTROL_SPEED;
    sAeSwReg.SensUpMode = (etSENSUP_MODE)rSWReg.Category.AE.Reg.SENS_UP_MODE;
    sAeSwReg.SensUpLevel = rSWReg.Category.AE.Reg.SENS_UP;
    //sAeSwReg.SensUpInternalMode = rSWReg.Category.AE.Reg.SENS_UP_INTERNAL_MODE;
    //sAeSwReg.SensUpInternalAgc = rSWReg.Category.AE.Reg.SENS_UP_INTERNAL_AGC;
    //sAeSwReg.SensUpInternal = rSWReg.Category.AE.Reg.SENS_UP_INTERNAL;

    UseGainStep = (etAGC_MODE)rSWReg.Category.AE.Reg.AGC_MODE;
    UseGainStep = UseGainStep & sMwAe.Tracking.LowLightState;

    //UseSensUpStep = UseGainStep;
	
#if 0
    if((sAeSwReg.SensUpMode == eSENSUP_AUTO)&&(sAeSwReg.Shutter<=SHUT_MODE_DEFAULT)&&(UseGainStep))
            UseSensUpStep = STATE_ON;
    else    UseSensUpStep = STATE_OFF;
#endif

    //if(sAeSwReg.LensMode == eLENS_MODE_DC)    AE_Iris_Lens_Change(CurrY, TargetY);

    DiffY = _abs(CurrY, TargetY);
    
    /***********************************************************************************************
    * Low Shutter�� ���� High Shutter�� ���� Target Boundary�� �ٸ��� �����Ѵ�.
    * SV ���� (1/1000s)���� ������ Gap�� "1", 1/8000 ���� ũ�� Gap�� "5", �� ������ ���� Linear Gap
    * GV ���� 256(x1)~12800(x50) �� �������� target boundary�� 1~3���� �ٸ��� ���Ѵ�.
    ***********************************************************************************************/

    if(sMwAe.Tracking.Step >= eAE_STEP_GAIN)
        DiffBoundary = ncDrv_Interp(sMwAe.Agc.Level, 80L, 180L, 1L, 3L);
    else
        DiffBoundary = ncDrv_Interp((sMwAe.Tracking.SV>>10), 1000, 8000, 1, 5);    /* 1/1000s ~ 1/8000 */
        
    if(DiffY > DiffBoundary)   
        sMwAe.Tracking.BoundaryStatus = eAE_BOUNDARY_OUT;    
    else
    {
        if(sMwAe.Tracking.Step == eAE_STEP_SENSUP)
        {
            if(DiffY <= DiffBoundary)   sMwAe.Tracking.BoundaryStatus = eAE_BOUNDARY_IN;
        }
        else
        {
            if(DiffY == 0)              sMwAe.Tracking.BoundaryStatus = eAE_BOUNDARY_IN;
        }
    }

    if(sMwAe.Tracking.BoundaryStatus == eAE_BOUNDARY_OUT   /* CurrY is out of boundary */
       || sMwAe.Tracking.TrackingSet == eAE_TRACKING_ON)   /* External force to tracking */ 
    {
        sMwAe.Tracking.TrackingSet = eAE_TRACKING_IDLE;

        switch(sMwAe.Tracking.Step)
        {
#if 0
            case eAE_STEP_IRIS:
                if(AE_IrisAutoModeCheck(CurrY, TargetY, &sMwAe.Tracking.SVRangeMin, &sMwAe.Tracking.SVRangeMax) == 1)
                {               
                    sMwAe.Tracking.SV = AE_TrackingValueCalculate(CALC_SV, &sMwAe.Tracking, sAeSwReg.ShutterControlSpeed);

                    if((sMwAe.Tracking.SV == sMwAe.Tracking.SVRangeMin)&&(CurrY < TargetY) &&(UseGainStep))
                        sMwAe.Tracking.Step = eAE_STEP_GAIN;
                }
                else
                {
                    if(sAeSwReg.LensMode == eLENS_MODE_PIRIS){
                        if(PIris_Task(CurrY, TargetY)){
                            if(sAeSwReg.Shutter > e30P_MANUAL_1_50000s){
                                //sMwAe.IrisGain = 0;
                            }

                            if(sAeSwReg.PIrisMode == PIRIS_AUTO){
                                if(sMwAe.PIris.StepCnt <= PIRIS_MIN_CNT){
                                    if((sMwAe.Tracking.SV == sMwAe.Tracking.SVRangeMin)&&(CurrY < TargetY)&&(UseGainStep)){
                                        sMwAe.Tracking.Step = eAE_STEP_GAIN;
                                    }
                                }
                            }
                            else{
                                sMwAe.Tracking.Step = eAE_STEP_IRIS;
                                sMwAe.PIris.AEShtCtl = TRUE;

                                sMwAe.Tracking.SVRangeMax = sMwAe.PIris.ShtMaxVal;
                                sMwAe.Tracking.SVRangeMin = sMwAe.PIris.ShtMinVal;
                                sMwAe.Tracking.SV = AE_TrackingValueCalculate(CALC_SV, &sMwAe.Tracking, sAeSwReg.ShutterControlSpeed);

                                if((sMwAe.Tracking.SV == sMwAe.Tracking.SVRangeMin)&&(CurrY < TargetY)&&(UseGainStep)){
                                    sMwAe.Tracking.Step = eAE_STEP_GAIN;
                                }
                            }   
                        }
                        else{
                            sMwAe.Tracking.Step = eAE_STEP_IRIS;
                        }
                    }
                    else
                    {
                        AE_Iris_stable_Control(CurrY, TargetY);
                    }
                }
                break;
                
#endif
            case eAE_STEP_SHUT:
                if(sAeSwReg.Shutter == SHUT_MODE_AUTO)
                {
                    sMwAe.Tracking.SVRangeMin = sMwAe.Tracking.SVDefault;
                    sMwAe.Tracking.SVRangeMax = ExpSVMax;
                    sMwAe.Tracking.SV = AE_TrackingValueCalculate(CALC_SV, &sMwAe.Tracking, sAeSwReg.ShutterControlSpeed);
                    
                    if((UseGainStep)&&(sMwAe.Tracking.SV <= sMwAe.Tracking.SVRangeMin) && (CurrY < TargetY))
                    { 
                        sMwAe.Tracking.Step = eAE_STEP_GAIN;
                    }
                }
                else
                {
                    if(UseGainStep)     sMwAe.Tracking.Step = eAE_STEP_GAIN;
                }
                break;
                
            case eAE_STEP_GAIN:
                if(UseGainStep)
                {
                    if(sAeSwReg.LensMode == eLENS_MODE_DC)      AE_Iris_Open();
                    
                    sMwAe.Tracking.GV = (GAIN_VALUE_TYPE)AE_TrackingValueCalculate(CALC_GV, &sMwAe.Tracking, sAeSwReg.AgcControlSpeed);
                    
                    if((sMwAe.Tracking.GV <= GAIN_VALUE_MIN) && (CurrY > TargetY))
                    {
                        sMwAe.Tracking.Step = (sAeSwReg.LensMode == eLENS_MODE_MANUAL ? eAE_STEP_SHUT : eAE_STEP_IRIS);
                    }
                    else if((sMwAe.Tracking.GV >= sMwAe.Tracking.GVRangeMax)&&(CurrY < TargetY)&&(sAeSwReg.SensUpMode == eSENSUP_AUTO)&&(sAeSwReg.Shutter <= SHUT_MODE_DEFAULT))
                    {
                        sMwAe.Tracking.Step = eAE_STEP_SENSUP; 
                    }                       
                }
                else
                {
                    sMwAe.Tracking.GV = GAIN_VALUE_MIN;
                    sMwAe.Tracking.Step = (sAeSwReg.LensMode == eLENS_MODE_MANUAL ? eAE_STEP_SHUT : eAE_STEP_IRIS);
                }
                break;
                
#if 0
            case eAE_STEP_SENSUP:
                if(UseSensUpStep)
                {
                    sMwAe.Tracking.SVRangeMin = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][SensUpStartIdx + sAeSwReg.SensUpLevel];
                    sMwAe.Tracking.SVRangeMax = sMwAe.Tracking.SVDefault;
                    sMwAe.Tracking.SV = AE_TrackingValueCalculate(CALC_SV, &sMwAe.Tracking, sAeSwReg.ShutterControlSpeed);

                    if((sMwAe.Tracking.SV >= sMwAe.Tracking.SVRangeMax)&&(CurrY > TargetY))
                    {
                        if(UseGainStep) sMwAe.Tracking.Step = eAE_STEP_GAIN; 
                        else            sMwAe.Tracking.Step = (sAeSwReg.LensMode == eLENS_MODE_MANUAL ? eAE_STEP_SHUT : eAE_STEP_IRIS);
                    }
                }
                else
                { 
                    if(UseGainStep)
                    {
                        sMwAe.Tracking.Step = eAE_STEP_GAIN;
                        sMwAe.Tracking.GV = sMwAe.Tracking.GVRangeMax;
                        sMwAe.Tracking.SV = sMwAe.Tracking.SVRangeMin;
                    }
                    else
                    {
                        sMwAe.Tracking.Step = (sAeSwReg.LensMode == eLENS_MODE_MANUAL ? eAE_STEP_SHUT : eAE_STEP_IRIS);
                        sMwAe.Tracking.GV = sMwAe.Tracking.GVRangeMin;
                        sMwAe.Tracking.SV = sMwAe.Tracking.SVRangeMax;
                    }
                }
                break;
#endif

            default:
                break;
        }
    }
#if 0
    else
    {
        if(sMwAe.Tracking.Step == eAE_STEP_IRIS)
        {
            if(AE_IrisAutoModeCheck(CurrY, TargetY, &sMwAe.Tracking.SVRangeMin, &sMwAe.Tracking.SVRangeMax) == 0)
            {
                AE_Iris_stable_Control(CurrY, TargetY);
            }
        }
    }
#endif
	
    /* ������ SV���� ���ص� SHUTTER MODE �� AUTO �� �ƴϸ� ������ MANUAL ������ ȯ�� */
    if(sAeSwReg.Shutter > SHUT_MODE_DEFAULT)
    {
        TempSV = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][rSWReg.Category.AE.Reg.SHUTTER];
        sMwAe.Tracking.SV = TempSV > ExpSVMax ? ExpSVMax : TempSV;
    }
}   

/******************************************************************************************************
* Function Name : AE_ConvertSVtoSensorValue
* Argument      : ULONG SValue
* Return        : void
* Description   : Convert SV to Sensor setting value & addition compensation ISP digital gain
                : Sensor Setting value = SensorELC, SensorTLC
                : SensorTLC = sensor Total Line Count, same as Sensor ELC in SensUp mode, normally 1frame Vline
                : SensorELC = sensor Exposure Line Count
                : GVCompHS = compensation digital gain between sensor line and line normally high speed
*******************************************************************************************************/
void AE_ConvertSVtoSensorValue(ULONG ShutterValue)
 {
    UCHAR   MaxFlk;
    UCHAR   i;
    //UCHAR   Multiplier;
    USHORT  ExposureLine, VTotalLine;
    USHORT  GVLineComp;
    ULONG   LineEx;
    ULONG   FlkShutter;
    ULONG   VMaxLineBase = SENSOR_VTOTAL_DEFAULT[INPUT_SIZE];
    ULONG   SVMin = sMwAe.Tracking.SVDefault;
    ULONG   SVMax = VMaxLineBase * SVMin;

    static BOOL  SkipNextVD;
    static USHORT preExposureLine;
    static USHORT preGVLineComp;    

    // FLKERLESS MODE    
    if((ShutterValue >= SVMin) && ((rSWReg.Category.AE.Reg.AE_SHUT_MODE == eSHUT_MODE_FLK) || (sWdr.Type == eWDRTYPE_DCOMP_AR && 
         rSWReg.Category.WDR.Reg.WDR_AE_SHUT_MODE == eSHUT_MODE_FLK)))
    {
        if (sMwAe.Tracking.SensorFrameRate == eFRAME_RATE_30)   MaxFlk = e30P_MANUAL_FLK;
        else                                                    MaxFlk = e60P_MANUAL_FLK;
        
        for (i = 0; i <= MaxFlk; i++)
        {
            FlkShutter = (SVMin << i);
            if (FlkShutter >= ShutterValue)
                break;
            else
                FlkShutter = ShutterValue;
        }
        ExposureLine = (USHORT)(SVMax / FlkShutter);
        sMwAe.Tracking.Shutter = FlkShutter>>10;
    }
    else if(ShutterValue < SVMin && rSWReg.Category.AE.Reg.SENS_UP_INC_MODE == eSENSUP_INC_FRAME)
    {
#if 0
        sMwAe.Tracking.Shutter = ShutterValue>>10;
        ExposureLine = (USHORT)(SVMax / ShutterValue);
        Multiplier = (ExposureLine % VMaxLineBase) ? 1 : 0;
        Multiplier += (ExposureLine / VMaxLineBase);
        VTotalLine = VMaxLineBase * Multiplier;
#endif
    }
    else
    {
        sMwAe.Tracking.Shutter = ShutterValue>>10;
        ExposureLine = (USHORT)(SVMax / ShutterValue);
        VTotalLine = ExposureLine;
    }

    ExposureLine = (ExposureLine == 0) ? (1) : (ExposureLine);
    
    /*________________ Sensor Exposure Line compensation by ISP Digital Gain _________________*/

    LineEx = (ULONG)(SVMax / ExposureLine);
    GVLineComp = (USHORT)(LineEx/(ShutterValue>>7));
    GVLineComp = (GVLineComp < GAIN_VALUE_MIN) ? (GAIN_VALUE_MIN) : (GVLineComp);

    if(SkipNextVD == TRUE)
    {
        SkipNextVD = FALSE;
        ExposureLine = preExposureLine;
        GVLineComp = preGVLineComp;
    }

    /*________________ Converted Value from ExpLV _________________*/ 

    sMwAe.Sensor.VTotalLine = (ShutterValue < sMwAe.Tracking.SVDefault) ? VTotalLine : VMaxLineBase;
    sMwAe.Sensor.ExposureLIne = ExposureLine;
    sMwAe.Isp.GVCompHS = GVLineComp;    

    /*________________ Calculate Next VD Value ____________________*/ 

    if(SENSOR_DIFF_LIMIT != 0 && _abs(ExposureLine, preExposureLine)> SENSOR_DIFF_LIMIT)
    {
        SkipNextVD = TRUE;                  //use same value at next VD
    }        

    preExposureLine = ExposureLine;
    preGVLineComp = GVLineComp;


}
		
/******************************************************************************************************
* Function Name : AE_ConvertGVtoAgcLevel
* Argument      : void
* Return        : void
* Description   : calculate rIP_AGC_LEVEL_7_0, sMwAe.AgcLevel, sMwAe.AgcRatioLevel
                : rIP_AGC_LEVEL_7_0 = sMwAe.AgcLevel : 0 ~ sMwAe.GainCtrlLimit (max:255)
                : sMwAe.AgcRatioLevel = ratio(255%) of sMwAe.AgcLevel between 0 ~ sMwAe.GainCtrlLimit
*******************************************************************************************************/
void AE_ConvertGVtoAgcLevel(USHORT ExpGValue)
{
    USHORT  AgcLevel;
    UCHAR   LutAgcInfo[2][AGC_LIMIT_MODE] = {
                    {42, 48, 52, 54},  /* Max dB*/
                    {60, 53, 49, 47}}; /* 255(AGC MAX Level) / 42, 48, 52, 54(dB) x 10 */
    UCHAR   AgcLimitdB = LutAgcInfo[0][rSWReg.Category.AE.Reg.AGC_LIMIT];
    UCHAR   AgcStep = LutAgcInfo[1][rSWReg.Category.AE.Reg.AGC_LIMIT];
    UCHAR   LutIdx;

    if(rSWReg.Category.AE.Reg.AGC_MODE == eAGC_MODE_OFF)
    {
        rIP_AGC_LEVEL_7_0 = sMwAe.Agc.Ratio = sMwAe.Agc.Level = 0L;
        return;
    }
   
    for(LutIdx = 0L; LutIdx <= AgcLimitdB; LutIdx++)
    {
        if(ExpGValue <= LutdBtoGain[LutIdx])     break;
    }

    if(LutIdx < AgcLimitdB){
        AgcLevel = (LutIdx * AgcStep) + ncDrv_Interp(ExpGValue, LutdBtoGain[LutIdx], LutdBtoGain[LutIdx+1], 0L, AgcStep);
        sMwAe.Agc.Level = AgcLevel/10;
	}else{
        sMwAe.Agc.Level = 0xFF;
	}
	
	rIP_AGC_LEVEL_7_0 = sMwAe.Agc.Level;

	sMwAe.Agc.Ratio = (UCHAR)ncDrv_Interp(ExpGValue, GAIN_VALUE_MIN, sMwAe.Tracking.GVRangeMax, 0x00, 0xFF);

}

void AE_Convert(void)
{
    USHORT  SensorLineVal;
    ULONG   ExpLVMax = ((ULONG)(SENSOR_VTOTAL_DEFAULT[INPUT_SIZE])*sMwAe.Tracking.SVDefault); 

    AE_ConvertGVtoAgcLevel(sMwAe.Tracking.GV);
    AE_ConvertSVtoSensorValue(sMwAe.Tracking.SV);

    SensorLineVal = (USHORT)((ExpLVMax / sMwAe.Sensor.ExposureLIne)>>10);
 
    rSWReg.Category.AE.Reg.SHUTTER_DATA_15_8 = (UCHAR)((SensorLineVal>>8)&0xFF);
    rSWReg.Category.AE.Reg.SHUTTER_DATA_7_0 = (UCHAR)(SensorLineVal&0xFF);
}

void AE_Set(void)
{
    sAppAeSet.VTotalDefault = (USHORT)SENSOR_VTOTAL_DEFAULT[INPUT_SIZE];    
    sAppAeSet.VTotalLine = sMwAe.Sensor.VTotalLine;
    sAppAeSet.ExposureLine = sMwAe.Sensor.ExposureLIne;   
    sAppAeSet.TotalGain = sMwAe.Tracking.GV;

#if (SENSOR_SELECT == SENSOR_COMMON)
	SENSOR_Exposure_Set((STRUCT_AE_SET_TYPE *)&sAppAeSet);   
#else
    ncDrv_SENSOR_Exposure_Set((STRUCT_AE_SET_TYPE *)&sAppAeSet);   
#endif
	
	AE_SetIspDigitalGain();
}

void AE_Iris_Open(void)
{
#if 0
    if((rSWReg.Category.AE.Reg.LENS_MODE == eLENS_MODE_PIRIS)&&(rSWReg.Category.DPC.Reg.WDPC_SCAN_STATE == TRUE)){
        Piris_LevelSet(PIRIS_FULL_OPEN);
        ncDrv_DelayMs_Set(30);
        Piris_LevelSet(PIRIS_RETURN);
    }

    // Iris Open
    sMwAe.Iris.FirstGainLevel = IRIS_OPEN_VALUE;
    sMwAe.Iris.GainLevel = IRIS_OPEN_VALUE;

    rIP_IRIS_1ND_AGCLEVEL_13_8 = ((sMwAe.Iris.FirstGainLevel>> 8) & 0xFF);
    rIP_IRIS_1ND_AGCLEVEL_7_0 = (sMwAe.Iris.FirstGainLevel & 0xFF);          
    
    rIP_IRIS_2ND_AGCLEVEL_13_8 = ((sMwAe.Iris.GainLevel >> 8) & 0xFF);
    rIP_IRIS_2ND_AGCLEVEL_7_0 = (sMwAe.Iris.GainLevel & 0xFF); 

    // PWM ��ȣ�� �缳���ϴ� ���
    // Added by shpark[20170728]
    rIP_IRIS_PWM_TRIGER_EN = 0;
#endif
}

void AE_Iris_Close(void)
{
#if 0
    sMwAe.Iris.FirstGainLevel = IRIS_CLOSE_VALUE;
    sMwAe.Iris.GainLevel = IRIS_CLOSE_VALUE;

    rIP_IRIS_1ND_AGCLEVEL_13_8 = ((sMwAe.Iris.FirstGainLevel>> 8) & 0xFF);
    rIP_IRIS_1ND_AGCLEVEL_7_0 = (sMwAe.Iris.FirstGainLevel & 0xFF);          
    
    rIP_IRIS_2ND_AGCLEVEL_13_8 = ((sMwAe.Iris.GainLevel >> 8) & 0xFF);
    rIP_IRIS_2ND_AGCLEVEL_7_0 = (sMwAe.Iris.GainLevel & 0xFF);     

    // PWM ��ȣ�� �缳���ϴ� ���
    // Added by shpark[20170728]
    rIP_IRIS_PWM_TRIGER_EN = 1;
#endif
}

/* [2014/10/09] jonghyun : IRIS Port Change */
USHORT AE_Iris_Control(USHORT CurrY, USHORT TargetY)
{
#if 0
//  #define IRIS_DEBUG_VIEW
    /* [2014/10/09] jonghyun : IRIS Port Change */
    UCHAR   DiffY;
    UCHAR   DiffFlag;
    USHORT  CompensationNormalValue;        
    USHORT  CompensationFastValue;
    USHORT  CompensationTotalValue;

    USHORT  CompensationNormalValueMax;
    USHORT  CompensationFastValueMax;
    static  UCHAR   Iris2ndGainValueSetDelayRef = 0;
    static  UCHAR   Iris2ndGainValueSetDelay = 0;   
    UCHAR   DelayRefMax;    
    
#ifdef  IRIS_DEBUG_VIEW 
    UCHAR   OSDPositionValue;
#endif  

    rIP_IRIS_PWM_BASE_HIGHVAL_15_8= ((sMwAe.Iris.RefLevel>> 8) & 0xFF);
    rIP_IRIS_PWM_BASE_HIGHVAL_7_0  = (sMwAe.Iris.RefLevel & 0xFF);         

//  if(CompensationNormalValue>0x40)    CompensationNormalValue = 0x40;
//  if(CompensationFastValue>0x40)  CompensationFastValue = 0x40;
    DiffY = _abs(CurrY, TargetY);
    
    if(sGco.OutputFrame.Rate == eFRAME_RATE_30)        //30,25P
    {
        /* [2014/10/09] jonghyun : IRIS Port Change */
        CompensationNormalValueMax = ncLib_Standard_Control(eSTD_INTERP, rSWReg.Category.AE.Reg.DC_LENS_CONTROL_SPEED, 0x00, 0x0F, 0x80, 0x180, CMD_END);
        CompensationFastValueMax = ncLib_Standard_Control(eSTD_INTERP, rSWReg.Category.AE.Reg.DC_LENS_CONTROL_SPEED, 0x00, 0x0F, 0x180, 0x280, CMD_END);
        CompensationNormalValue = ncLib_Standard_Control(eSTD_INTERP, DiffY, 0x00, 0x20, 0x01, CompensationNormalValueMax, CMD_END);
        CompensationFastValue = ncLib_Standard_Control(eSTD_INTERP, DiffY, 0x20, 0x100, 0x00, CompensationFastValueMax, CMD_END);
        DelayRefMax = ncLib_Standard_Control(eSTD_INTERP, rSWReg.Category.AE.Reg.DC_LENS_CONTROL_SPEED, 0x00, 0x0F, 0x02, 0x00, CMD_END);

        if(DiffY <= IRIS_STABLE_ZONE)   Iris2ndGainValueSetDelayRef = ncLib_Standard_Control(eSTD_INTERP, DiffY, 0x00,IRIS_STABLE_ZONE, DelayRefMax+2, DelayRefMax, CMD_END);
        else                            Iris2ndGainValueSetDelayRef = ncLib_Standard_Control(eSTD_INTERP, DiffY, IRIS_STABLE_ZONE, 0x80, DelayRefMax+1, DelayRefMax, CMD_END);

        rIP_IRIS_1ND_OFFSET_10_8  = 0x00;
        rIP_IRIS_1ND_OFFSET_7_0   = 0x20;
    }
    else                            //60,50P
    {
        /* [2014/10/09] jonghyun : IRIS Port Change */
        CompensationNormalValueMax = ncLib_Standard_Control(eSTD_INTERP, rSWReg.Category.AE.Reg.DC_LENS_CONTROL_SPEED, 0x00, 0x0F, 0x40, 0x100, CMD_END);
        CompensationFastValueMax = ncLib_Standard_Control(eSTD_INTERP, rSWReg.Category.AE.Reg.DC_LENS_CONTROL_SPEED, 0x00, 0x0F, 0x100, 0x200, CMD_END);
        CompensationNormalValue = ncLib_Standard_Control(eSTD_INTERP, DiffY, 0x00, 0x20, 0x01, CompensationNormalValueMax, CMD_END);
        CompensationFastValue = ncLib_Standard_Control(eSTD_INTERP, DiffY, 0x20, 0x100, 0x00, CompensationFastValueMax, CMD_END);
        DelayRefMax = ncLib_Standard_Control(eSTD_INTERP, rSWReg.Category.AE.Reg.DC_LENS_CONTROL_SPEED, 0x00, 0x0F, 0x04, 0x02, CMD_END);    //60,50P

        if(DiffY <= IRIS_STABLE_ZONE)   Iris2ndGainValueSetDelayRef = ncLib_Standard_Control(eSTD_INTERP, DiffY, 0x00,IRIS_STABLE_ZONE, DelayRefMax+2, DelayRefMax, CMD_END);
        else                            Iris2ndGainValueSetDelayRef = ncLib_Standard_Control(eSTD_INTERP, DiffY, IRIS_STABLE_ZONE, 0x80, DelayRefMax+1, DelayRefMax-2, CMD_END);

        rIP_IRIS_1ND_OFFSET_10_8  = 0x00;
        rIP_IRIS_1ND_OFFSET_7_0   = 0x00;
    }

    CompensationTotalValue = CompensationNormalValue+CompensationFastValue;
    
    if(CurrY > TargetY)     // Bright
    {
        DiffFlag = 1;

        if((Iris2ndGainValueSetDelay>=Iris2ndGainValueSetDelayRef)&&(DiffFlag ==1))
        {
            Iris2ndGainValueSetDelay = 0;
            if((sMwAe.Iris.GainLevel+CompensationTotalValue)<IRIS_CLOSE_VALUE)   sMwAe.Iris.GainLevel += CompensationTotalValue;
            else                                                                sMwAe.Iris.GainLevel  = IRIS_CLOSE_VALUE;
        }
        else Iris2ndGainValueSetDelay++;
        
    }
    else if(CurrY < TargetY)    // Dark
    {
        DiffFlag = 2;   

        if((Iris2ndGainValueSetDelay>=Iris2ndGainValueSetDelayRef)&&(DiffFlag ==2))
        {
            Iris2ndGainValueSetDelay = 0;
            if(sMwAe.Iris.GainLevel<CompensationTotalValue)  sMwAe.Iris.GainLevel  = IRIS_OPEN_VALUE;
            else                                            sMwAe.Iris.GainLevel -= CompensationTotalValue;
        }
        else Iris2ndGainValueSetDelay++;
    }
    else                        // same
    {
        DiffFlag = 0;
        CompensationFastValue = 0;
    }   

//  if(Iris1stGainValueSetDelay>Iris1stGainValueSetDelayRef)
//  {
//      Iris1stGainValueSetDelay = 0;
//      Iris1stGainValueSetDelayRef =  MW_YGapInterp(0x00, 0x20, 0x08, 0x00);
        sMwAe.Iris.FirstGainLevel = ncLib_Standard_Control(eSTD_INTERP, sMwAe.Iris.GainLevel, 0x100, 0x3FFF, 0x00, 0x3FFF, CMD_END);       
//  }
//  else    
//  {
//      Iris1stGainValueSetDelay++;
//  }

    rIP_IRIS_2ND_AGCLEVEL_13_8    = ((sMwAe.Iris.GainLevel >> 8) & 0xFF);
    rIP_IRIS_2ND_AGCLEVEL_7_0 = (sMwAe.Iris.GainLevel & 0xFF);     

    rIP_IRIS_1ND_AGCLEVEL_13_8 = ((sMwAe.Iris.FirstGainLevel>> 8) & 0xFF);
    rIP_IRIS_1ND_AGCLEVEL_7_0 = (sMwAe.Iris.FirstGainLevel & 0xFF);          
    

#ifdef  0 //__IRIS_DEBUG__
    OSDPositionValue = 2;
    APP_OSDPrint_Hex(1, OSDPositionValue, CurrY);        OSDPositionValue += 3;
    APP_OSDPrint_Hex(1, OSDPositionValue, TargetY);  OSDPositionValue += 3;
    APP_OSDPrint_Hex(1, OSDPositionValue, DiffY ); OSDPositionValue += 3;  
    
    OSDPositionValue = 2;
    APP_OSDPrint_Hex(2, OSDPositionValue, DiffFlag);                 OSDPositionValue += 3;
    APP_OSDPrint_Hex(2, OSDPositionValue, CompensationNormalValueMax);   OSDPositionValue += 3;
    APP_OSDPrint_Hex(2, OSDPositionValue, CompensationNormalValue);  OSDPositionValue += 3;  
    APP_OSDPrint_Hex(2, OSDPositionValue, CompensationFastValue);    OSDPositionValue += 3;
    APP_OSDPrint_Hex(2, OSDPositionValue, CompensationTotalValue);   OSDPositionValue += 3;

    OSDPositionValue = 2;
    APP_OSDPrint_Hex(3, OSDPositionValue, rIP_IRIS_1ND_AGCLEVEL_13_8 );    OSDPositionValue += 2;  
    APP_OSDPrint_Hex(3, OSDPositionValue, rIP_IRIS_1ND_AGCLEVEL_7_0 ); OSDPositionValue += 3;  
    
    APP_OSDPrint_Hex(3, OSDPositionValue, rIP_IRIS_2ND_AGCLEVEL_13_8);      OSDPositionValue += 2;  
    APP_OSDPrint_Hex(3, OSDPositionValue, rIP_IRIS_2ND_AGCLEVEL_7_0);           OSDPositionValue += 3;  
    
    APP_OSDPrint_Hex(3, OSDPositionValue, rIP_IRIS_PWM_BASE_HIGHVAL_15_8 );    OSDPositionValue += 2;  
    APP_OSDPrint_Hex(3, OSDPositionValue, rIP_IRIS_PWM_BASE_HIGHVAL_7_0 ); OSDPositionValue += 3;  

    OSDPositionValue = 2;
    APP_OSDPrint_Hex(4, OSDPositionValue, Iris1stGainValueSetDelayRef);      OSDPositionValue += 3;
#endif
    
#endif
    return sMwAe.Iris.GainLevel;

}

/* [2014/10/09] jonghyun : IRIS Port Change */
void AE_Iris_stable_Control(USHORT CurrY, USHORT TargetY)
{
#if 0
    if(sMwAe.Tracking.SV < sMwAe.Tracking.SVDefault)
        AE_Iris_Open();
    else
    {
        if(AE_Iris_Control(CurrY, TargetY) == 0)
        {
            if((rSWReg.Category.AE.Reg.SHUTTER != SHUT_MODE_AUTO) &&(sMwAe.Tracking.LowLightState==1))
                sMwAe.Tracking.Step = eAE_STEP_GAIN;
        }
    }
#endif
}

/* [2014/8/29] jonghyun : 1-1 */
void AE_IrisScan_Set(void)
{
#if 0
//	#define	__IRIS_TEST_PRITF__
    USHORT  CheckCount;
    
    USHORT  IrisValidCount;
    ULONG   IrisValidSum;
    //UCHAR BreakFlag;
    UCHAR   IrisValue[4];
    /* [2014/10/09] jonghyun : IRIS Port Change */
    USHORT  IrisValueAvg, TotalY;
    FLOAT   Comp1;
    static UCHAR IrisValueBeforeAvg;
//    UCHAR DayNightStatusBackup;

	MW_TdnColor_Set();
#if 0
    DayNightStatusBackup = rSWReg.Category.TDN.Reg.DAYNIGHT_MODE;
    rSWReg.Category.TDN.Reg.DAYNIGHT_MODE = eDN_COLOR;
    APP_TDN_Auto();
#endif

/*IRIS_SCAN:*/
    sMwAe.Iris.FirstGainLevel = 0x400;
    sMwAe.Iris.GainLevel = 0x1800;
    sMwAe.Iris.RefLevel = 0x0000;

    rIP_IRIS_PWM_ACC_EN = STATE_OFF;

    rIP_IRIS_1ND_AGCLEVEL_13_8 = ((sMwAe.Iris.FirstGainLevel>> 8) & 0xFF);
    rIP_IRIS_1ND_AGCLEVEL_7_0 = (sMwAe.Iris.FirstGainLevel & 0xFF);
    
    rIP_IRIS_2ND_AGCLEVEL_13_8    = ((sMwAe.Iris.GainLevel >> 8) & 0xFF);
    rIP_IRIS_2ND_AGCLEVEL_7_0 = (sMwAe.Iris.GainLevel & 0xFF);

    rIP_IRIS_PWM_BASE_HIGHVAL_15_8 = ((0x4000>>8)&0xFF);
    rIP_IRIS_PWM_BASE_HIGHVAL_7_0 = (0x4000&0xFF);

    ncDrv_DelayMs_Set(50);
    
    IrisValidCount = 0;
    IrisValidSum = 0;
    for(CheckCount= 0x5000;CheckCount <0x8000;CheckCount+=0x40)
    {
        rIP_IRIS_PWM_BASE_HIGHVAL_15_8 = ((CheckCount>>8)&0xFF);
        rIP_IRIS_PWM_BASE_HIGHVAL_7_0 = (CheckCount&0xFF);
        
        /* [2014/10/09] jonghyun : IRIS Port Change */      
        ncDrv_DelayMs_Set(1);
        ncLib_OPD_Task();
        TotalY = AE_CalculateY();
        Comp1 = (FLOAT)TotalY/16;
#if 0        
        IrisValue[0] = ISPGET08(aIP_ADC_CH0_DATA);
        IrisValue[1] = (UCHAR)(((FLOAT)IrisValue[0]*Comp1)/1.6);

        IrisValueAvg = IrisValue[0] +IrisValue[1] ;
        IrisValueAvg = (IrisValueAvg+IrisValueBeforeAvg)>>1;
#else
		IrisValueAvg = ISPGET08(aIP_ADC_CH0_DATA);
#endif
        if((IrisValueAvg<=IRIS_ADC_REF_HIGH)&(IrisValueAvg>=IRIS_ADC_REF_LOW))  // IRIS_PWM_BASE : 1.55V~1.75V/AVG 1.65V ///  ADC Input : 2.00~2.3.00V
        {
            IrisValidCount++;
            IrisValidSum+=CheckCount;           
        }

        IrisValueBeforeAvg = IrisValueAvg;
#if 0

        ncLib_DEBUG_Printf(1, (UCHAR *)"TotalY : 0x%S    ", TotalY);
        ncLib_DEBUG_Printf(1, (UCHAR *)"IrisValue0 : 0x%S    ", IrisValue[0]);
        ncLib_DEBUG_Printf(1, (UCHAR *)"IrisValue1 : 0x%S    ", IrisValue[1]);
        ncLib_DEBUG_Printf(1, (UCHAR *)"IrisValueAvg : 0x%S    ", IrisValueAvg);
        ncLib_DEBUG_Printf(1, (UCHAR *)"CheckCount : 0x%S", CheckCount);                          
        ncLib_DEBUG_Printf(1, (UCHAR *)"Count : 0x%S    ", IrisValidCount);
        ncLib_DEBUG_Printf(1, (UCHAR *)"SUM : %S\n ", IrisValidSum);                         
#endif
    }

    sMwAe.Iris.RefLevel = IrisValidSum/IrisValidCount;   //Cal. AVG
/* [2014/10/09] jonghyun : IRIS Port Change */
    if(sMwAe.Iris.RefLevel>0xF000)   sMwAe.Iris.RefLevel = 0x5000;
#if 1
    else
    {
        if(sMwAe.Iris.RefLevel>0x5000)   sMwAe.Iris.RefLevel = ((sMwAe.Iris.RefLevel-0x5000)/2)+0x5000;
        else                            sMwAe.Iris.RefLevel = 0x5000;
    }
#endif
    
    rIP_IRIS_PWM_BASE_HIGHVAL_15_8= ((sMwAe.Iris.RefLevel>> 8) & 0xFF);
    rIP_IRIS_PWM_BASE_HIGHVAL_7_0  = (sMwAe.Iris.RefLevel & 0xFF);
    rIP_IRIS_PWM_ACC_EN   = STATE_ON;

    rIP_IRIS_1ND_OFFSET_10_8      = 0;
    rIP_IRIS_1ND_OFFSET_7_0       = 0;

    rIP_IRIS_1ND_AGCLEVEL_13_8= 0;
    rIP_IRIS_1ND_AGCLEVEL_7_0= 0;

    rIP_IRIS_2ND_AGCLEVEL_13_8 = 0;
    rIP_IRIS_2ND_AGCLEVEL_7_0     = 0;

	sMwAe.Iris.FirstGainLevel = 0x00;
	sMwAe.Iris.GainLevel = 0x00;


	if(MW_TdnStatus_Get() == DN_STATUS_COLOR)	MW_TdnColor_Set();
	else										MW_TdnBw_Set();
#endif

}

/* [2014/10/09] jonghyun : IRIS Port Change */
UCHAR AE_IrisAutoModeCheck(USHORT tCurrY, USHORT tTargetY, ULONG *tAShutMin, ULONG *tAShutMax)
{
#if 0
#define DCLENS_MAX_SHUTTER_OFFSET   2

    ULONG ShutterMax_SV = ((ULONG)(SENSOR_VTOTAL_DEFAULT[INPUT_SIZE])*sMwAe.Tracking.SVDefault)/SENSOR_EXPOSURE_MIN; 
    et30P_MANUAL_SHUT_TYPE ShutterIdx;
    ULONG AShutMin = sMwAe.Tracking.SVDefault;
    ULONG AShutMax;

    if(sMwAe.Tracking.SensorFrameRate == eFRAME_RATE_30) 
            ShutterIdx=SENSUP_START_IDX_30P ;
    else    ShutterIdx=SENSUP_START_IDX_60P;
    
    if(rSWReg.Category.AE.Reg.LENS_MODE == eLENS_MODE_PIRIS)
    {
        AShutMax = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][ShutterIdx-1];
        
        sMwAe.PIris.ShtMinVal = AShutMin;
        sMwAe.PIris.ShtMaxVal = AShutMax;
    }
    else
    {
        /* [2014/09/22] sky : [STD]-01 */
        if(rSWReg.Category.AE.Reg.DC_LENS_MODE == eDC_INDOOR)
            AShutMax = ShutterMax_SV;
        else
        {
            AShutMax = LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][rSWReg.Category.AE.Reg.DC_LENS_ASHUT_MAX+DCLENS_MAX_SHUTTER_OFFSET];

            if(AShutMax > ShutterMax_SV)    AShutMax = ShutterMax_SV;   /* [2015/09/11] JWLee : LIMIT : SENSOR_MAX_LMT */
        }
    }
    
    *tAShutMin = AShutMin;
    *tAShutMax = AShutMax;

    /* [2014/8/8] jonghyun : IRIS Modify */
    if(
        (
            ((tCurrY > tTargetY)&&(sMwAe.Iris.GainLevel == IRIS_OPEN_VALUE)&&(sMwAe.Tracking.SV != AShutMax))  // Bright Condition
                ||
            ((tCurrY < tTargetY)&&(sMwAe.Iris.GainLevel == IRIS_OPEN_VALUE)&&(sMwAe.Tracking.SV >= AShutMin))  // Dark Condition
        )
        &&(rSWReg.Category.AE.Reg.SHUTTER == SHUT_MODE_AUTO)    
    )
        return 1;   //  Shutter Mode (First)
    else
        return 0;   // Iris Mode

#undef DCLENS_MAX_SHUTTER_OFFSET
#endif
		return 0;	// �Լ� ��� �� ����
}

void AE_Iris_Lens_Change(USHORT CurrY, USHORT TargetY)
{
#if 0
    static  USHORT  IrisBootCheckCount = 0;
    static  USHORT  IrisBootCheckCurryUpCount = 0,IrisBootCheckCurryDownCount = 0;
    static  UCHAR   LensChageStep = 0, LensChageUnitStep = 0;
    static  UCHAR   LensSatbleZoneCount = FALSE, LensConnectCount = 0;
    static  UCHAR   CurrentYBigCountCheckFlag = FALSE;
    static  UCHAR   CurrentYSmallCountCheckFlag = FALSE;
    static  USHORT  CurrentYBigCount = 0x8000;
    static  USHORT  CurrentYSmallCount = 0x8000;

    UCHAR   OneSecondData;
    #ifdef __IRIS_DEBUG__
    UCHAR   OSDPositionValue = 2;
    #endif

	return;
	
    ////////__IRIS Remove Check__ ////////////////////////////////////////////////////
    ////////__IRIS Shutter_Chagne_Check__ ////////////////////////////////////////////
    /* [2014/8/8] jonghyun : IRIS Modify */

        if(sMwAe.Tracking.SensorFrameRate == eFRAME_RATE_60)  // 60P
        {
            if(CVBS_FORMAT == eCVBS_NTSC)   OneSecondData = 60;
            else                            OneSecondData = 50;
        }
        else                                        // 30P
        {
            if(CVBS_FORMAT == eCVBS_NTSC)   OneSecondData = 30;
            else                            OneSecondData = 25;     
        }

        if(IrisBootCheckCount < (OneSecondData<< 1))
        {
            IrisBootCheckCount ++;
            if((CurrY>3))
            {
                IrisBootCheckCurryUpCount++;
            }
            else if((CurrY<3))
            {
                IrisBootCheckCurryDownCount++;
            }
        }
        else
        {
            if(LensChageStep == 0)
            {
                if(CurrentYBigCountCheckFlag == FALSE)
                {
                    if((CurrY>(TargetY+(TargetY>>1)))&&(LensChageStep == 0)&&(sMwAe.Iris.GainLevel  == 0x3FFF))   CurrentYBigCount++;
                    else                                                                                        CurrentYBigCount = 0;

                    if(CurrentYBigCount>(OneSecondData>>1))  LensChageUnitStep = 1;

                    if(LensChageUnitStep == 1)
                    {
                        if(CurrY<(TargetY-(TargetY/10)))
                        {
                            CurrentYBigCountCheckFlag = TRUE; 
                            CurrentYSmallCountCheckFlag = TRUE;
                            LensChageUnitStep = 0;
                            LensChageStep = 1;
                        }
                    }
                }
            }
            else if(LensChageStep == 1)
            {
                if(CurrentYSmallCountCheckFlag == TRUE)
                {
                    if(CurrY<(TargetY-(TargetY>>1))) CurrentYSmallCount++;                                   // Lens Chagne Case
                    else                                CurrentYSmallCount = 0;
                    
                    if(CurrentYSmallCount>(OneSecondData*3))
                    {

                        sMwAe.Iris.FirstGainLevel = 0x0000;
                        sMwAe.Iris.GainLevel = 0x0000;
                        sMwAe.Iris.RefLevel = 0x0000;

                        rIP_IRIS_1ND_AGCLEVEL_13_8 = 0;
                        rIP_IRIS_1ND_AGCLEVEL_7_0 = 0;            
                        
                        rIP_IRIS_2ND_AGCLEVEL_13_8    = 0;
                        rIP_IRIS_2ND_AGCLEVEL_7_0 = 0;        

                        rIP_IRIS_PWM_BASE_HIGHVAL_15_8 = 0;
                        rIP_IRIS_PWM_BASE_HIGHVAL_7_0 = 0;
                        
                        LensChageStep = 2;
                        CurrentYBigCountCheckFlag = FALSE;
                        CurrentYSmallCountCheckFlag = FALSE;
                        CurrentYBigCount = 0;
                        CurrentYSmallCount = 0;
                    }
                }
            
            }
            else if(LensChageStep == 2)
            {
                if(CurrY>(TargetY-(TargetY>>1)))
                {
                    LensConnectCount++;
                    if(LensConnectCount>OneSecondData)
                    {
                        LensConnectCount = 0;
                        LensChageStep = 0;
                        IrisBootCheckCount = 0;
                        ncLib_DEBUG_Printf(1, "IRIS Re Scan!\n");
                        ncSvc_AE_Init();
                    }
                }
                else
                {
                    LensConnectCount = 0;
                }
            }

            if((CurrY>(TargetY-(TargetY>>1)))&&(CurrY<(TargetY+(TargetY>>1))))            
            {
                LensSatbleZoneCount++;
                if(LensSatbleZoneCount>(OneSecondData<< 1))
                {
                    LensSatbleZoneCount = 0;
                    LensChageStep = 0;
                    IrisBootCheckCount = 0;
                    CurrentYBigCountCheckFlag = 0;
                    CurrentYSmallCountCheckFlag = 0;
                    CurrentYBigCount = 0;
                    CurrentYSmallCount = 0;
                }           
            }
        }

#ifdef 0 //__IRIS_DEBUG__
    OSDPositionValue = 2;
    APP_OSDPrint_Hex(1, OSDPositionValue, TargetY);                  OSDPositionValue += 3;
    APP_OSDPrint_Hex(1, OSDPositionValue, CurrY);                        OSDPositionValue += 3;
    APP_OSDPrint_Hex(1, OSDPositionValue, IrisBootCheckCount);           OSDPositionValue += 3;

    APP_OSDPrint_Hex(1, OSDPositionValue, sMwAe.Iris.GainLevel>>8);           OSDPositionValue += 2;
    APP_OSDPrint_Hex(1, OSDPositionValue, sMwAe.Iris.GainLevel);          OSDPositionValue += 3;

    OSDPositionValue = 2;
    APP_OSDPrint_Hex(2, OSDPositionValue, LensChageStep);                OSDPositionValue += 3;
    APP_OSDPrint_Hex(2, OSDPositionValue, LensConnectCount);         OSDPositionValue += 3;

    OSDPositionValue = 2;   
    APP_OSDPrint_Hex(3, OSDPositionValue, CurrentYBigCountCheckFlag);    OSDPositionValue += 3;
    APP_OSDPrint_Hex(3, OSDPositionValue, CurrentYBigCount);             OSDPositionValue += 3;

    OSDPositionValue = 2;
    APP_OSDPrint_Hex(4, OSDPositionValue, CurrentYSmallCountCheckFlag);  OSDPositionValue += 3;
    APP_OSDPrint_Hex(4, OSDPositionValue, CurrentYSmallCount);           OSDPositionValue += 3;

    OSDPositionValue = 2;
    APP_OSDPrint_Hex(5, OSDPositionValue, CurrentYBetweenCount);     OSDPositionValue += 3;
#endif
#endif

}


