/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/



#ifndef __LIB_GLOBALHEADER__
#define __LIB_GLOBALHEADER__

/*=============================================================================
	All Middleware file Include
=============================================================================*/

#include "ISP_Lib.h"
#include "Debug_Lib.h"
#include "Intc_Lib.h"
#include "JIG_LIb.h"
#include "SWReg_Lib.h"
#include "GPIO_Lib.h"
#include "sFlash_Lib.h"
#include "I2C_Lib.h"
#include "Task_Lib.h"
#include "SysTime_Lib.h"
#endif


