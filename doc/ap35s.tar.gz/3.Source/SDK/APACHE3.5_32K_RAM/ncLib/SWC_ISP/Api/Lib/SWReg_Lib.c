/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SoftRegister_Lib.c
*
*  @brief   : This file is SWR (SoftWare Register) API for standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.08
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>

#include "APACHE35.h"
#include "SWReg_Lib.h"

#include "Debug_Lib.h"
#include "SWReg_Lib.h"

#include "SWReg_Svc.h"

#include "ISP_Drv.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

BOOL gbSWROpen = 0;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncLib_SWR_Open(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbSWROpen == TRUE)
    {
        gbSWROpen = FALSE;

        ret = NC_FAILURE;
    }
    else
    {
        gbSWROpen = TRUE;
    }

    if(ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, "Error, SWR %s\n", LOG_ERR_OPEN);
    }

    return ret;
}


INT32 ncLib_SWR_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbSWROpen == TRUE)
    {
        gbSWROpen = FALSE;
    }
    else
    {
        gbSWROpen = FALSE;

        ret = NC_FAILURE;
    }

    if(ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, "Error, SWR %s\n", LOG_ERR_CLOSE);
    }

    return ret;
}


UINT8 ncLib_SWR_Read(UINT32 nOffset)
{
	//DEBUGMSG_SDK(MSGINFO, "3 READ #offset=%08X data=%04X\n", nOffset, rSWReg.BYTE[nOffset]);
	return rSWReg.BYTE[nOffset];
    //return sStatusRegister.Category[nOffset];
}


void ncLib_SWR_Write(UINT32 nOffset, UINT8 nData)
{
	rSWReg.BYTE[nOffset] = nData;
	//sStatusRegister.Category[nOffset] = nData;
}


UINT32 ncLib_SWR_Control(eSWR_CMD Cmd, ...)
{
    UINT32 count = 0;
    UINT32 argData[10];
    va_list vlist;
    BOOL bEndCmd = FALSE;
    UINT32 Value = 0;
    INT32 ret = NC_SUCCESS;

    if(gbSWROpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vlist, Cmd);

        for(count = 0; count < 10; count++)
        {
            argData[count] = va_arg(vlist, UINT32);

            if(argData[count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vlist);


        if(bEndCmd == FALSE)
        {
            ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case GCMD_SWR_INIT:
                break;

                case GCMD_SWR_DEINIT:
                break;

                case GCMD_SWR_GET_DATA:
                    Value = ncSvc_SWR_GetData((eSWR_ID_NUM)argData[0]);
                break;

                case GCMD_SWR_SET_DATA:
                    ncSvc_SWR_SetData((eSWR_ID_NUM)argData[0], (UINT8)argData[1]);
                break;

                default :
                    ret = NC_FAILURE;
                break;
            }
        }
    }

    if(ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, "Error, SWC %s\n", LOG_ERR_CONTROL);
    }

    return Value;
}


/* End Of File */
