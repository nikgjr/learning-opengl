/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	File	: WB_Api.c		
*	Brief	: This file is NR API for NEXTCHIP standard library
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2016.01.26		M.Y Sung	1.0		Initial  Revision
********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Drv_GlobalHeader.h"

/*
********************************************************************************
*                              LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*                         LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                               LOCAL TYPEDEF
********************************************************************************
*/

/*
********************************************************************************
*                       IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                        GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/
#ifdef API_FUNCTION_CALL 
BOOL gbMONITOROpen = FALSE;
#endif
/*
********************************************************************************
*                       IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                         LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/
#ifdef API_FUNCTION_CALL 
INT32 ncLib_Monitor_Open(void)
{
	INT32  ret = NC_SUCCESS;

	if(gbMONITOROpen == FALSE)
	{
		gbMONITOROpen = TRUE;
	}
	else
	{
		//ncLib_DEBUG_Printf(1, "\n\r This Module is already Opened \r\n");
		ret = NC_FAILURE;
	}

	return ret;
}		

INT32 ncLib_Monitor_Close(void)
{
	INT32  ret = NC_SUCCESS;

	if(gbMONITOROpen == TRUE)
	{
		gbMONITOROpen = FALSE;
	}
	else
	{
		//ncLib_DEBUG_Printf(1, "\n\r This Module is already Opened \r\n");
		ret = NC_FAILURE;
	}

	return ret;
}

INT32 ncLib_Monitor_Read(void)
{
	INT32  ret = NC_SUCCESS;    
	//ncLib_DEBUG_Printf(1, "\n\r Not Support This Function \r\n");
    return ret;
}

INT32 ncLib_Monitor_Write(void)
{
	INT32  ret = NC_SUCCESS;    
	//ncLib_DEBUG_Printf(1, "\n\r Not Support This Function \r\n");
    return ret;
}
#endif

INT32 ncLib_Monitor_Control(eMONITOR_CMD Cmd, ...)
{
	UCHAR count = 0;
    UINT32 argData[10];
	va_list vlist;
    BOOL bEndCmd = FALSE;
    INT32 ret = NC_SUCCESS;

#ifdef API_FUNCTION_CALL 	
	if(gbMONITOROpen)
	{
#endif		
		/*
         * Parsing Variable Argument
         */

        va_start(vlist, Cmd);

        for(count = 0; count < 10; count++)
        {
            argData[count] = va_arg(vlist, UINT32);

            if(argData[count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vlist);

		if(bEndCmd == FALSE)
        {
            //DEBUGMSG_SDK(MSGERR, "Error, ISP no CMD_END!\n");
            ret = NC_FAILURE;
        }
		else
		{
			switch(Cmd)
			{
				case GCMD_MONITOR_SET:
					ncDrv_OutputFormat_Set();
				break;
				case GCMD_MONITOR_SENSOR_TYPE_SET:
				    ncDrv_MONITOR_SENSOR_Type_Set((stIMAGE_SIZE_INFO *) argData[0]);
				break;
				case GCMD_MONITOR_IIF_POSITION_SET:
				    ncDrv_MONITOR_IIF_POSITION_Set();
				break;
				default:
				break;	
			}
		}
#ifdef API_FUNCTION_CALL 		
	}
	else
	{
		ret = NC_FAILURE;
		//ncLib_DEBUG_Printf(1, "\n\r Error,  MONITOR is not opened \r\n");
	}
#endif	

	return ret; 
}

