/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : JIG_Lib.c
*
*  @brief   : This file is JIG controller application support package source
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#include "APACHE35.h"

#include "Intc_Lib.h"
#include "Uart_Lib.h"
#include "Debug_Lib.h"
#include "JIG_Lib.h"

#include "JIG_Svc.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

BOOL gbJIGOpen;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncLib_JIG_Open(UINT32 nInputClk)
{
    INT32 ret = NC_SUCCESS;

    if(gbJIGOpen == TRUE)
    {
        gbJIGOpen = FALSE;

        ret = NC_FAILURE;
    }
    else
    {
        gbJIGOpen = TRUE;

        //ret = ncLib_UART_Open(nInputClk);
    }

    if(ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, "Error, Jig %s\n", LOG_ERR_OPEN);
    }

    return ret;
}


INT32 ncLib_JIG_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbJIGOpen == TRUE)
    {
        gbJIGOpen = FALSE;

        //ret = ncLib_UART_Close();
    }
    else
    {
        gbJIGOpen = FALSE;

        ret = NC_FAILURE;
    }

    if(ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, "Error, Jig %s\n", LOG_ERR_CLOSE);
    }

    return ret;
}


INT32 ncLib_JIG_Write(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_JIG_Read(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_JIG_Control(eJIG_CMD Cmd,  ...)
{
    UINT32 count = 0;
    UINT32 argData[10];
    eUART_CH channel;
    va_list vlist;
    BOOL bEndCmd = FALSE;
    INT32 ret = NC_SUCCESS;

    if(gbJIGOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vlist, Cmd);

        for(count = 0; count < 10; count++)
        {
            argData[count] = va_arg(vlist, UINT32);

            if(argData[count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vlist);

        if(bEndCmd == FALSE)
        {
            ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

			channel = (eUART_CH)argData[0];

            switch(Cmd)
            {
#if 0

                case GCMD_JIG_INIT:
                    

#if (APACHE_NEXTUNE_JIG_RECIEVE_TYPE == UART_INTERRUPT_TYPE)
                    ret |= ncLib_UART_Control(GCMD_UT_CONNECT_ISR_HANDLER, channel, CMD_END);

			#ifdef APACHE2p8_JIG
					ret |= ncLib_UART_Control(GCMD_UT_CONNECT_USER_HANDLER, channel, UART_Common, CMD_END);
			#else
                    ret |= ncLib_UART_Control(GCMD_UT_CONNECT_USER_HANDLER, channel, ncSvc_JIG_RxISR, CMD_END);
			#endif
#endif
                break;


                case GCMD_JIG_DEINIT:
                    ncLib_UART_Control(GCMD_UT_DEINIT_CH, channel, (ptUART_PARAM)argData[1]);
                break;

                case GCMD_JIG_SET_BAUDRATE:
                {
                    ret = ncLib_UART_Control(GCMD_UT_SET_BAUDRATE, channel, argData[1]);
                }
                break;
#endif

                case GCMD_JIG_DO_COMMAND:
                {
                   ret = ncSvc_JIG_CommandMain(channel);
                }
                break;

                default:
                {
                    ret = NC_FAILURE;
                }
                break;
            }
        }
    }

    if(ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, "Error, JIG %s\n", LOG_ERR_CONTROL);
    }

    return ret;
}


void ncLib_JIG_Printf(const char *fmt, ...)
{
#if 0
    va_list args;
    char buffer[512];

    if(gbJIGOpen == TRUE)
    {
        va_start(args, fmt);

        vsnprintf(buffer, sizeof(buffer), fmt, args);

        va_end(args);

        ncLib_UART_Control(GCMD_UT_PRINT_STRING, JIG_PORT, buffer, CMD_END);
    }
#endif
}


UINT32 ncLib_JIG_Scanf(char *buf)
{
 
    return 0;
}


/* End Of File */
