/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	File	: WB_Api.h		
*	Brief	: This file is NR controller API for NEXTCHIP standard library
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2016.01.26		M.Y Sung	1.0		Initial  Revision
********************************************************************************/

#ifndef MONITOR_API_H__
#define MONITOR_API_H__

typedef enum
{
	GCMD_MONITOR_SET = 0,
	GCMD_MONITOR_SENSOR_TYPE_SET,
	GCMD_MONITOR_IIF_POSITION_SET,
}eMONITOR_CMD;

#ifdef API_FUNCTION_CALL 
extern INT32 ncLib_Monitor_Open(void);
extern INT32 ncLib_Monitor_Close(void);
extern INT32 ncLib_Monitor_Read(void);
extern INT32 ncLib_Monitor_Write(void);
#endif
extern INT32 ncLib_Monitor_Control(eMONITOR_CMD Cmd, ...);

#endif /* MONITOR_API_H__ */

/* End Of File */

