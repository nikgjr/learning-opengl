/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : ISP_Lib.c
*
*  @brief   : This file is ISP controller API for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>
#include <stdio.h>

#include "APACHE35.h"
#include "Debug_Lib.h"
#include "Task_Lib.h"
#include "Api_GlobalHeader.h"
#include "Drv_GlobalHeader.h"
/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/
#ifdef API_FUNCTION_CALL
BOOL gbTaskOpen= FALSE;
#endif

/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

#ifdef API_FUNCTION_CALL
INT32 ncLib_Task_Open(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbTaskOpen == FALSE)
    {
       

       // if(ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_ISP0, (PrHandler)ncDrv_ISP_IRQ_Handler0, CMD_END) != NC_SUCCESS)
       // {
       //     ret = NC_FAILURE;
       // }

        gbTaskOpen = TRUE;
    }

 //   if(ret == NC_FAILURE)

 //   {
 //      DEBUGMSG_SDK(MSGERR, "Error, ISP %s\n", LOG_ERR_OPEN);
 //   }

    return ret;
}

INT32 ncLib_Task_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbTaskOpen == TRUE)
    {
        gbTaskOpen = FALSE;
    }
    else
    {
        gbTaskOpen = FALSE;

        ret = NC_FAILURE;
    }

    if(ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, "Error, Task %s\n", LOG_ERR_CLOSE);
    }

    return ret;
}

INT32 ncLib_Task_Read(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}

INT32 ncLib_Task_Write(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}
#endif

INT32 ncLib_Task_Control(etISP_TASK_CMD_TYPE Cmd, ...)
{
    UCHAR count = 0;
    UINT32 argData[10];
    va_list vlist;
    BOOL bEndCmd = FALSE;
    INT32 ret = NC_SUCCESS;

#ifdef API_FUNCTION_CALL
    if(gbTaskOpen == TRUE)
    {
#endif		
        /*
         * Parsing Variable Argument
         */

        va_start(vlist, Cmd);

        for(count = 0; count < 10; count++)
        {
            argData[count] = va_arg(vlist, UINT32);

            if(argData[count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vlist);


        if(bEndCmd == FALSE)
        {
            ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case eTASK_INIT:   
                    break;
                    
                /*** 3A LIB***/
                case eTASK_OPD:
                    ncLib_OPD_Task();
                    break;

                case eTASK_AE:
                    ncSvc_AE_Task();
                    break;
    
                case eTASK_WB:
                    ncSvc_WB_Task();
                    break;

                case eTASK_WDR:
                    ncSvc_WDR_Task();
                    break;
                    
                /*** AUTO FUNCTION***/
                case eTASK_IMAGE_TUNE:                                                       
					/* CHROMA Commands */
                    ncDrv_Chroma_CSCMatrix_Auto();
                    ncDrv_Chroma_CSCRGBAlpha_Auto();

                    /* NR Commands  */
                    ncDrv_NR_FNR2D_Auto();
                    ncDrv_NR_CI_FLAT_Auto();
                   
                    /* GAMMA Commands */
				    ncDrv_Gamma_Y_Auto();
				    ncDrv_Gamma_Alpha_Auto();

                    /* SHARPNESS Commands */
                    ncDrv_Sharpness_Y_Auto();
                    ncDrv_Sharpness_RGB_Auto();
                    ncDrv_Sharpness_MainHPF_Auto();
                    ncDrv_Sharpness_YHPF_Y0_Auto(); 

					/* CVBS Memory Commands */
				    ncDrv_CVBS_HPF_Auto();
				    ncDrv_CVBS_DS_LPF_Y_Auto();
				    
					/* LUMA Commands  */
                    ncDrv_LUMA_IBLUR_INT3_Auto();
                    ncDrv_LUMA_Y_Offset_Auto();
                    break;

				case eTASK_LSC:
					ncDrv_LSC_Auto();
					break;

				case eTASK_NR:
					ncDrv_NR_Auto();
					break;
					     
                case eTASK_BLC:
                    ncDrv_BlackLevelCompensation_Auto();
                    break; 

				case eTASK_DWDR:
                    ncDrv_DWDR_Auto();
                    break; 

				case eTASK_DEFOG:
				    ncDrv_Defog_Auto();
                    break;

				case eTASK_DPC:
                    ncDrv_LiveDPC_Auto();
                    break; 
                    
                /*** SUB FUNCTION***/                    
				case eTASK_VIEWMODE:
					if(sMwSystem.Control.Run.AFT)
				    {
					    ncSvc_ViewMode_Task();	
                    }
					break;
					
				case eTASK_FLICKER:
				    if(sMwSystem.Control.Run.AFT) 
				    {
				        ncDrv_Flicker_Task();
				    }
				 	break;

                case eTASK_CATEGORY:
                    ncDrv_CategoryFunc_Exec();
	 	            break;
	 	            
                default :
                    ret = NC_FAILURE;
                break;
            }
        }
#ifdef API_FUNCTION_CALL		
	}
	else
	{
		ret = NC_FAILURE;
	}
#endif	
	
	return ret;
}

/* End Of File */

