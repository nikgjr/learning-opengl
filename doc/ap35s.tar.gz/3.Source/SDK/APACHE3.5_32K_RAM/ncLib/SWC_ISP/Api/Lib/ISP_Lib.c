/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : ISP_Lib.c
*
*  @brief   : This file is ISP controller API for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>
#include <stdio.h>

#include "APACHE35.h"
#include "FlashMemoryMap.h"
#include "Lib_GlobalHeader.h"

#include "ISP_Drv.h"
#include "IspFlash_Drv.h"


#include "Api_GlobalHeader.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

BOOL gbISPOpen = FALSE;
//UINT32 gnISPInClock;


volatile STRUCT_SW_CONTROL_REGISTER     rSWReg;

/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/
INT32 ncLib_ISP_Open(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbISPOpen == FALSE)
    {
        ncDrv_ISP_RegisterOpen();
	
#if 0
        ncLib_OPD_Open();
		ncLib_AELib_Open();
		ncLib_WB_Open();
        ncLib_Task_Open();
        ncLib_Standard_Open();
		ncLib_Sensor_Open();
		ncLib_TDN_Open();
		//ncLib_FLICKER_Open();
		ncLib_WDR_Open();
		ncLib_Monitor_Open();
		ncLib_BackLight_Open();
		//ncLib_OSD_Open();
		ncLib_ImageAdjust_Open();
		ncLib_Category_Open();
		ncLib_System_Open();
	//	ncLib_DPC_Open();
		//ncLib_MD_Open();	
		ncLib_LSC_Open();
		ncLib_NR_Open();
		ncLib_BlackLevel_Open();
#endif
		
#if 0

        if(ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_ISP0, (PrHandler)ncDrv_ISP_IRQ_Handler, CMD_END) != NC_SUCCESS)
        {
            ret = NC_FAILURE;
        }
#endif

        gbISPOpen = TRUE;
    }

 //   if(ret == NC_FAILURE)

 //   {
 //      DEBUGMSG_SDK(MSGERR, "Error, ISP %s\n", LOG_ERR_OPEN);
 //   }

    return ret;
}


INT32 ncLib_ISP_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbISPOpen == TRUE)
    {
        gbISPOpen = FALSE;
        ncDrv_ISP_RegisterClose();
    }
    else
    {
        gbISPOpen = FALSE;

        ret = NC_FAILURE;
    }

    if(ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, "Error, ISP %s\n", LOG_ERR_CLOSE);
    }

    return ret;
}


INT32 ncLib_ISP_Read(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_ISP_Write(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_ISP_Control(eISP_CMD Cmd, ...)
{
    UINT32 count = 0;
    UINT32 argData[10];
    va_list vlist;
    BOOL bEndCmd = FALSE;
    INT32 ret = NC_SUCCESS;

	if(gbISPOpen == TRUE)
    {
        /*
         * Parsing Variable Argument
         */

        va_start(vlist, Cmd);

        for(count = 0; count < 10; count++)
        {
            argData[count] = va_arg(vlist, UINT32);

            if(argData[count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vlist);


        if(bEndCmd == FALSE)
        {
            ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case GCMD_ISP_SYS_INIT:
                break;

                case GCMD_ISP_FUNCTION_INIT: 
					ncDrv_VariableInitialize_Boot_Set();
		
                    ncDrv_CategoryFunc_Init();
					
                    //ncSvc_AE_Init();
                    //ncSvc_WB_INIT();
					//ncSvc_WDR_Set();
					//ncDrv_Flicker_Initialize();
					
					//ncDrv_OSDBin_Get();
					//ncDrv_DPGL_Initialize();
					//ncDrv_PGL_Initialize();
					//ncSvc_ViewMode_Initialize();
					//ncDrv_Osg_Initialize_Set();

                break;

                case GCMD_ISP_ALL_LOAD:
                    ncDrv_ISP_FlashMemory_AllLoad((UINT8)argData[0]);
                break;
            }
        }
    }
#if 0

                case GCMD_ISP_2A_FUNTION:
                     ncLib_Task_Control(eTASK_OPD, CMD_END);
                     ncLib_Task_Control(eTASK_AE, CMD_END);             
                     ncLib_Task_Control(eTASK_WB, CMD_END);   
                     ncLib_Task_Control(eTASK_FLICKER, CMD_END);

                break;

                case GCMD_ISP_SUB_FUNCTION:
                    ncLib_Task_Control(eTASK_CATEGORY, CMD_END);

        			ncLib_Task_Control(eTASK_LSC, CMD_END);
        			ncLib_Task_Control(eTASK_NR, CMD_END);
        			ncLib_Task_Control(eTASK_DEFOG, CMD_END);
        			ncLib_Task_Control(eTASK_DWDR, CMD_END);
        		    ncLib_Task_Control(eTASK_BLC, CMD_END);

                    ncLib_Task_Control(eTASK_IMAGE_TUNE, CMD_END);
                    
                break;


                case GCMD_ISP_APPLICATION:
                    ncLib_Task_Control(eTASK_VIEWMODE, CMD_END);
                    
                break;

                case GCMD_ISP_DEINIT:
                break;

                /* ISP Flash Memory Commands */
                case GCMD_ISP_ALL_SAVE:
                    ncDrv_ISP_FlashMemory_AllSave((UINT8)argData[0]);
                break;

                case GCMD_ISP_SR_SAVE:                    
                    ncDrv_ISP_FlashMemory_StatusSave(argData[0]);
                    break;

                case GCMD_ISP_SR_LOAD:
                    ncDrv_ISP_FlashMemory_StatusLoad(argData[0]);
                break;

                case GCMD_ISP_Default_LOAD:
                     ncDrv_ISP_Flashmemory_Default_Load(argData[0]);

                /* ISP System Commands */
                case GCMD_ISP_RESET:
                break;
#if 0

                case GCMD_ISP_CONNECT_ISR_HANDLER:
                break;

                case GCMD_ISP_DISCONNECT_ISR_HANDLER:
                break;
#endif
                case GCMD_ISP_GET_INTR_VSYNC:
                {
                     UINT8 *Vsync = (UINT8 *)argData[1];
                     *Vsync = ncDrv_ISP_GetInterruptVsync((eISP_INTR_NUM)argData[0]);
                }
                break;
                
                case GCMD_ISP_CLR_INTR_VSYNC:
                     ncDrv_ISP_ClearInterruptVsync((eISP_INTR_NUM)argData[0]);
                break;  

				case GCMD_ISP_SENSOR_SVC_INIT:
					ncDrv_SENSOR_Initial_Set();  
				break;	

                default :
                    ret = NC_FAILURE;
                break;
            }
        }
    }

    if(ret == NC_FAILURE)
    {
        DEBUGMSG_SDK(MSGERR, "Error, ISP %s\n", LOG_ERR_CONTROL);
    }
#endif
    return ret;
}


/* End Of File */
