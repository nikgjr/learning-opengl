
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __DRV_TDN__
#define __DRV_TDN__

#ifndef tDN_STATUS
#define tDN_STATUS
    typedef enum
    {
    	DN_STATUS_BW = 0,
    	DN_STATUS_COLOR,
    	DN_STATUS_MAX,
    }DN_STATUS;
#endif

/* DETECTION TYPE at DN_AUTO MODE */
typedef enum
{
	DN_DET_AGC_ONLY = 0,
	DN_DET_CDS_ONLY,
	DN_DET_AGCCDS_AND,
	DN_DET_AGCCDS_OR,
	DN_DET_MAX_TYPE,
}DN_AUTO_DETECT_TYPE;

typedef struct
{
	UCHAR	DayNightCount;
	BOOL	DayNightCountOn;
	UCHAR	DayNightSwitchCount;
	BOOL	DayNightSwitchCountOn;

	UCHAR	CurrentTdnStatus;
	UCHAR	DayNightSwitchDelay;
} STRUCT_MW_Tdn;
extern STRUCT_MW_Tdn sMwTdn;


//////////////////////////////////////////
//////////////////////////////////////////
//////////////////////////////////////////
//////////////////////////////////////////
//////////////////////////////////////////

#define IRED_PWM_LEVEL		rT2DAT0
#define IRED_PWM_DEFAULT	0x9B

#define DN_SW_EXE_C2B	1L
#define DN_SW_EXE_B2C	3L
typedef enum
{
	DN_FILTER_DC = 0,
	DN_FILTER_STEP,
	DN_FILTER_MAX,
}DN_FILTER_TYPE;

typedef enum
{
	DN_FILTER_MAINTAIN_OFF = 0,
	DN_FILTER_MAINTAIN_ON,
	DN_FILTER_SWTICH_MAX,
}DN_FILTER_SWITCH_TYPE;

/********************************************************************************
* Function Name 	: MW_TdnStatus_Get()
* Description		: Read DayNight Current Status
* Refer to		: API Document
* Argument		: void
* Return			:
					@ [0x0]	: DN_STATUS_BW
					@ [0x1]	: DN_STATUS_COLOR
********************************************************************************/
void ncDrv_TdnColor_Set(void);
void ncDrv_TdnBw_Set(void);
UCHAR ncDrv_TdnStatus_Get(void);
void ncDrv_IrSmart_Set(void);

void ncDrv_TDN_STATUS_Set(void); 
void ncDrv_TDN_Auto(void);
UCHAR ncDrv_TdnAuto_AgcLimit_Get(UCHAR AGCMODE); 

#endif

