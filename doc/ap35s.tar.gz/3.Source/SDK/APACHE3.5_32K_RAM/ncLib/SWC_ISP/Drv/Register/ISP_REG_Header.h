/*
********************************************************************************
*
*  Copyright (C) 2013 NEXTCHIP Inc. All rights reserved.
*
*  @file    : ISP_REG_Header.h
*
*  @brief   : Apache2.8 ISP Register file header file
*
*  @author  : CamSW / Sung
*
*  @date    : 2016.01.28
*
*  @version : Version 0.0.1
*
*
********************************************************************************
*/

#ifndef __ISP_REG_HEADER_H__
#define __ISP_REG_HEADER_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/
#include "HAL_bank00.h"
#include "HAL_bank01.h"
#include "HAL_bank02.h"
#include "HAL_bank03.h"
#include "HAL_bank04.h"
#include "HAL_bank05.h"
#include "HAL_bank06.h"
#include "HAL_bank07.h"
#include "HAL_bank08.h"
#include "HAL_bank09.h"

#include "HAL_bank0D.h"
#include "HAL_bank0E.h"
#include "HAL_bank0F.h"

//#include "HAL_bank10.h"
#include "HAL_bank11.h"
#include "HAL_bank12.h"
#include "HAL_bank13.h"
#include "HAL_bank14.h"
#include "HAL_bank15.h"
#include "HAL_bank16.h"
#include "HAL_bank17.h"
#include "HAL_bank18.h"
#include "HAL_bank19.h"
#include "HAL_bank1A.h"
#include "HAL_bank1B.h"
#include "HAL_bank1C.h"
#include "HAL_bank1D.h"

#include "HAL_bank20.h"
#include "HAL_bank21.h"
#include "HAL_bank22.h"
#include "HAL_bank23.h"
#include "HAL_bank24.h"
#include "HAL_bank25.h"
#include "HAL_bank26.h"
#include "HAL_bank27.h"
#include "HAL_bank28.h"
#include "HAL_bank29.h"
#include "HAL_bank2A.h"
#include "HAL_bank2B.h"
#include "HAL_bank2C.h"
#include "HAL_bank2D.h"
#include "HAL_bank2E.h"
#include "HAL_bank2F.h"



/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/


#endif  /* __ISP_REG_HEADER_H__ */


/* End Of File */
