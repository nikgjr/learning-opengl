
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Drv_GlobalHeader.h"
//#include "NR_Drv.h"

#include "Sensor_Default_Drv.h"

STRUCT_MW_MCU	sMwMCU;

void ncDrv_MONITOR_SENSOR_Type_Set(stIMAGE_SIZE_INFO * SetSize);

void ncDrv_DNR_IMG_Set(stIMAGE_SIZE_INFO * SetSize);
/*===============================================================================
    Definitions for Options
===============================================================================*/

#define YC16                0x00
#define BT1120              0x11
#define BT656               0x44
#define RGB24               0x55

#define SYSTEM_RESET(r)     (*(volatile UCHAR *)(0xFE8F)) = (r)


/*==============================================================================
     STANDARD VIDEO TIMING SPECIFICATION (Refer to "video timing spec.xlsx")     
================================================================================*/


    const stIMAGE_SIZE_INFO lutStdCVBS[eCVBS_H_MAX][eCVBS_FORMAT] = {
                         /*   HTotal, VTotal, HActive, VActive */
    /* eCVBS_H_720H  PAL  */    {{ 864,   625,   720,   576},
    /* eCVBS_H_720H  NTSC */     { 858,   525,   720,   486}},
    /* eCVBS_H_960H  PAL  */    {{1152,   625,   960,   576},
    /* eCVBS_H_960H  NTSC */     {1144,   525,   960,   486}},
    /* eCVBS_H_1280H PAL  */    {{1536,   625,  1280,   576},
    /* eCVBS_H_1200H NTSC */     {1430,   525,  1200,   486}},
    /* eCVBS_H_1440H PAL  */    {{1728,   625,  1440,   576},
    /* eCVBS_H_1440H NTSC */     {1716,   525,  1440,   486}},
    /* eCVBS_H_1920H PAL  */    {{2304,   625,  1920,   576},
    /* eCVBS_H_1920H NTSC */     {2288,   525,  1920,   486}}, 
    };

#if 1//CHIP_MODE
    const stIMAGE_SIZE_INFO lutStdHD[eSIZE_MAX][eCVBS_FORMAT] = {
                          /*   HTotal, VTotal, HActive, VActive */
    /* eSIZE_1280_720  25/50P */ {{1980,   750,   1280,    720},
    /* eSIZE_1280_720  30/60P */  {1650,   750,   1280,    720}},
    /* eSIZE_1920_1080 25/50P */ {{2640,  1125,   1920,   1080},
    /* eSIZE_1920_1080 30/60P */  {2200,  1125,   1920,   1080}},
    };
#endif

#if 0//FPGA_MODE //LDC OFF
    const stIMAGE_SIZE_INFO lutStdHD[eSIZE_MAX][eCVBS_FORMAT] = {
                          /*   HTotal, VTotal, HActive, VActive */
    /* eSIZE_1280_720  25/50P */ {{1980,   750,   1288,    720},
    /* eSIZE_1280_720  30/60P */  {1650,   750,   1288,    720}},
    /* eSIZE_1920_1080 25/50P */ {{2640,  1125,   1920,   1080},
    /* eSIZE_1920_1080 30/60P */  {2200,  1125,   1920,   1080}},
    }; 
#endif 

    /* ONLY USE FOR AHD+720+30P */
    const stIMAGE_SIZE_INFO lutStdAHD[eCVBS_FORMAT] = { 
                          /*   HTotal, VTotal, HActive, VActive */
    /* eSIZE_1280_720  25P */  {1920,   750,   1280,    720},
    /* eSIZE_1280_720  30P */  {1600,   750,   1280,    720}
    };


/*===============================================================================
    Internal Function Prototype
===============================================================================*/
void MONITOR_CLKPath_SensorInput_Set(void);
void MW_SFlashSector1_Control(UCHAR wMode, UCHAR* Parm);
void MCU_CLKPath_Set(etFRAME_SIZE OutputSize, etMONITOR_OUT_MODE MonitorOutMode);
void MONITOR_AHD_Control(void);
void MONITOR_FrameSize_Control(etMONITOR_OUT_MODE OutputMode);

/*===============================================================================
    Function Define
===============================================================================*/




void MCU_SWReset_Off(void)
{
#if 0
    // OISP off
    // BUS off
    // SDRAM off
    rIP_SWRESET_OISP      = 1;
    ncDrv_Delay_Set(1);
    rIP_SWRESET_MCU_BUS   = 1;
    ncLib_Standard_Control(eSTD_DELAY, 1, CMD_END);
    ISPSET08(aIP_SWRESET_SEN, 0xFF);
    rIP_SWRESET_OSD = 1;
    ncLib_Standard_Control(eSTD_DELAY, 1, CMD_END);
#endif
}

void MCU_SWReset_On(void)
{
#if 0
    // SDRAM on
    // BUS on
    // OISP on
    rIP_SWRESET_FDDR      = 0;
    ncDrv_DelayMs_Set(5);   // wait to initialize DDR Controller (24Ms)
    rIP_SWRESET_MCU_BUS   = 0;
    ncDrv_Delay_Set(1);
    rIP_SWRESET_OISP      = 0;
    ncLib_Standard_Control(eSTD_DELAY, 1, CMD_END);
    ISPSET08(aIP_SWRESET_SEN, 0x00);

    rIP_SWRESET_OSD = 0;
#endif
}

void MW_SwReset_Set(void)
{
    // sw-reset
    //MCU_SWReset_Off();
    //MCU_SWReset_On();   
    //MW_Delay_Set(30);    
}

void MONITOR_AHD_FORMAT_SET(void)
{
/*===============================================================
 Refer to "AHD_CVI_TVI_Setting.xlsx"                              
=================================================================*/
typedef enum
{
    FORMAT_AHD = 0,
    FORMAT_CVI,
    FORMAT_TVI,
    FORMAT_MAX,
}AHD_format;

typedef enum
{
    OUTPUT_720_30P = 0,
    OUTPUT_720_60P,
    OUTPUT_1080_30P,
    OUTPUT_MAX,
}type_OutputMode;

typedef struct
{
    UCHAR   Data[OUTPUT_MAX][eCVBS_FORMAT];
} AHD_FORMAT_SET_TYPE;

    AHD_FORMAT_SET_TYPE FormatData[FORMAT_MAX][3]={
    /*       720_30p     720_60p     1080_30p    */
    /*       PAL, NTSC,  PAL, NTSC,  PAL, NTSC,  */    
/* AHD */ {{ 0x21,0x20,  0x23,0x22,  0x31,0x30 },     /* 0xE004 */
           { 0x73,0x73,  0x71,0x71,  0x71,0x71 },     /* 0xE03E */
           { 0x19,0x19,  0x19,0x19,  0x19,0x19 }},    /* 0xE052 */
                                            
/* CVI */ {{ 0x22,0x22,  0x22,0x22,  0x32,0x32 },
           { 0x73,0x73,  0x71,0x71,  0x71,0x71 },
           { 0x0A,0x0A,  0x0A,0x0A,  0x0A,0x0A }},
                                            
/* TVI */ {{ 0x24,0x23,  0x26,0x25,  0x34,0x33 },
           { 0x73,0x73,  0x71,0x71,  0x71,0x71 },
           { 0x04,0x04,  0x04,0x04,  0x03,0x03 }}};
           
    UCHAR FormatData1[13][FORMAT_MAX]={
                    /* AHD  TVI,  CVI */
        /* 0x2005 */ {0x1C, 0x9C, 0x9C},
        /* 0x2018 */ {0x01, 0x01, 0x00},
        /* 0x2040 */ {0x3F, 0x3F, 0x3C},
        /* 0x2041 */ {0x3B, 0x3B, 0x38},
        /* 0x2043 */ {0x01, 0x03, 0x01},
        /* 0x2051 */ {0x06, 0xFE, 0xFF},
        /* 0x2053 */ {0x04, 0x0A, 0x01},
        /* 0x2054 */ {0x00, 0x60, 0x40},
        /* 0x2055 */ {0x00, 0x00, 0x40},
        /* 0x2056 */ {0x00, 0x00, 0x21},
        /* 0x2057 */ {0x00, 0x00, 0x31},
        /* 0x2058 */ {0x00, 0x00, 0x6F},
        /* 0x2059 */ {0x00, 0x00, 0x67},};
        
    UCHAR OutFormat = rSWReg.Category.AHD.Reg.AHD_FORMAT_TYPE;    /* AHD, CVI, TVI */
    UCHAR idxOutput;

    if(sGco.OutputFrame.Size == eSIZE_1920_1080)
    {
        idxOutput = OUTPUT_1080_30P;
    }
    else if(sGco.OutputFrame.Size == eSIZE_1280_720)
    {
        if(sGco.OutputFrame.Rate == eFRAME_RATE_60)     idxOutput = OUTPUT_720_60P;
        else                                            idxOutput = OUTPUT_720_30P;
    }

    ISPSET08(aIP_AHD_FORMAT, FormatData[OutFormat][0].Data[idxOutput][CVBS_FORMAT]);
    ISPSET08(aIP_AHD_SAMPLING_MODE,  FormatData[OutFormat][1].Data[idxOutput][CVBS_FORMAT]);
    ISPSET08(aIP_AHD_TEST_SIGNAL_OFFSET,  FormatData[OutFormat][2].Data[idxOutput][CVBS_FORMAT]);

    ISPSET08(aIP_AHD_PIXEL_SW_RST,  FormatData1[0][OutFormat]);
    ISPSET08(aIP_AHD_CSC_MODE,  FormatData1[1][OutFormat]); 
    ISPSET08(aIP_AHD_BLANK_LEVEL,  FormatData1[2][OutFormat]);
    ISPSET08(aIP_AHD_SYNC_AMPLITUDE,  FormatData1[3][OutFormat]);
    ISPSET08(aIP_AHD_BURST_PHASE,  FormatData1[4][OutFormat]);
    ISPSET08(aIP_AHD_TEST_SIGNAL_TYPE,  FormatData1[5][OutFormat]);
    ISPSET08(aIP_AHD_TEST_SIGNAL_WIDTH,  FormatData1[6][OutFormat]);
    ISPSET08(aIP_AHD_TEST_SIGNAL_REF_LEVEL,  FormatData1[7][OutFormat]);
    ISPSET08(aIP_AHD_TEST_SIGNAL_REF_SCALE,  FormatData1[8][OutFormat]);
    ISPSET08(aIP_AHD_TEST_SIGNAL_REF_PN_VALUE_7_0,  FormatData1[9][OutFormat]);
    ISPSET08(aIP_AHD_TEST_SIGNAL_REF_PN_VALUE_15_8,  FormatData1[10][OutFormat]);
    ISPSET08(aIP_AHD_TEST_SIGNAL_REF_PN_VALUE_23_16,  FormatData1[11][OutFormat]);
    ISPSET08(aIP_AHD_TEST_SIGNAL_REF_PN_VALUE_31_24,  FormatData1[12][OutFormat]);

    ISPSET08(aIP_AHD_C_FILTER_TYPE, 0x0A);
    ISPSET08(aIP_AHD_Y_WR_PTR, 0x33);
}

void MONITOR_AHD_Control(void)
{
#if 0
    MW_AHD_Gain_Set();
#endif
    MONITOR_AHD_FORMAT_SET();
#if 0
    MCU_AHD_PN_Set();
#endif
}

/* [2014/11/10] JWLee : [STD]-01 */
void MONITOR_CVBS_FORMAT_SET(eCVBS_OUTPUT_SIZE output_size)
{
UCHAR aryOUTSIZE[eCVBS_OUTSIZE_MAX][29]={
 /*					  0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x10*/
 /*eCVBS_1920x576*/  {0x05,0x00,0x00,0x50,0x43,0x57,0x68,0x73,0x76,0x01,0x00,0x06,0xCA,0xE1,0x07,0x00,0x10},
 /*eCVBS_1920x480*/  {0x05,0x00,0x47,0x35,0x43,0x51,0x5B,0x62,0x66,0x01,0x01,0x45,0x17,0x5D,0x06,0x00,0x0D},
 /*eCVBS_1440x576*/  {0x04,0x00,0x00,0x50,0x43,0x57,0x68,0x73,0x76,0x01,0x00,0xB2,0x62,0x82,0x0A,0x00,0x15},
 /*eCVBS_1440x480*/  {0x04,0x00,0x47,0x35,0x43,0x51,0x5B,0x62,0x66,0x01,0x01,0x07,0x1F,0x7C,0x08,0x00,0x11},
 /*eCVBS_1280x576*/  {0x03,0x00,0x00,0x50,0x43,0x57,0x68,0x73,0x76,0x01,0x01,0x09,0xAF,0xD2,0x0B,0x00,0x18},
 /*eCVBS_1200x480*/  {0x02,0x00,0x47,0x35,0x43,0x51,0x5B,0x62,0x66,0x01,0x01,0xA2,0x8B,0x2E,0x0A,0x00,0x14},
 /*eCVBS_960x576*/   {0x01,0x00,0x00,0x00,0x4D,0x5A,0x7A,0x92,0x9A,0x01,0x00,0x0C,0x94,0xC3,0x0F,0x00,0x20},
 /*eCVBS_960x480*/   {0x01,0x00,0x00,0x42,0x48,0x53,0x70,0x73,0x80,0x01,0x01,0x8B,0x2E,0xBA,0x0C,0x00,0x19},
 /*eCVBS_720x576*/   {0x00,0x00,0x00,0x00,0x00,0x5A,0x87,0xB9,0xCC,0x01,0x00,0x65,0xC5,0x04,0x15,0x00,0x2A},
 /*eCVBS_720x480*/   {0x00,0x00,0x00,0x00,0x43,0x58,0x7D,0x98,0xA0,0x01,0x01,0x0F,0x3E,0xF8,0x10,0x00,0x22},
};

/* [2015/01/26] SJH : STD-01 */
//{
UCHAR aryStandard[eCVBS_OUTSIZE_MAX][7]={
/*				     0x00,0x01,0x02,0x03,0x04,0x05,0x06 */
/*eCVBS_1920x576*/  {0x01,0x31,0x00,0x00,0x76,0x0A,0x0A},
/*eCVBS_1920x480*/  {0x02,0x15,0x00,0x00,0x45,0x0A,0x09},
/*eCVBS_1440x576*/  {0x01,0x25,0x00,0x00,0x56,0x0A,0x0A},
/*eCVBS_1440x480*/  {0x02,0x10,0x00,0x00,0x32,0x0A,0x09},
/*eCVBS_1280x576*/  {0x01,0x22,0xF8,0x05,0x4B,0x0A,0x0A},
/*eCVBS_1200x480*/  {0x02,0x0E,0x8E,0x05,0x28,0x0A,0x0A},
/*eCVBS_960x576*/   {0x08,0x18,0x00,0x00,0x3F,0x0A,0x00},   /*SMY 2016.04.04*/
/*eCVBS_960x480*/   {0x08,0x13,0x00,0x00,0x27,0x00,0x00},   /*SMY 2016.04.04*/
/*eCVBS_720x576*/   {0x08,0x12,0x00,0x00,0x20,0x00,0x00},   /*SMY 2016.04.04*/
/*eCVBS_720x480*/   {0x08,0x13,0x00,0x00,0x14,0x00,0x00},   /*SMY 2016.04.04*/
};

UCHAR aryNonstandard[eCVBS_OUTSIZE_MAX][7]={
/*				     0x00,0x01,0x02,0x03,0x04,0x05,0x06 */
/*eCVBS_1920x576*/  {0x02,0x20,0xF2,0x08,0x52,0x0A,0x00},
/*eCVBS_1920x480*/  {0x03,0x17,0xE3,0x08,0x35,0x0B,0x00},
/*eCVBS_1440x576*/  {0x01,0x19,0xB5,0x06,0x3A,0x0B,0x00},
/*eCVBS_1440x480*/  {0x03,0x12,0xAA,0x06,0x14,0x1E,0x15},
/*eCVBS_1280x576*/  {0x03,0x19,0xF7,0x05,0x36,0x07,0x00},
/*eCVBS_1200x480*/  {0x02,0x0F,0x8E,0x05,0x17,0x12,0x0A},
/*eCVBS_960x576*/   {0x00,0x10,0xF8,0x08,0x27,0x05,0x00},
/*eCVBS_960x480*/   {0x01,0x0C,0x72,0x04,0x16,0x0A,0x04},  
/*eCVBS_720x576*/   {0x00,0x12,0x57,0x03,0x30,0x00,0x00},  /*SMY 2016.04.11 */
/*eCVBS_720x480*/   {0x00,0x08,0x55,0x03,0x14,0x00,0x00},  /*SMY 2016.04.11 */
};
//}

    if(CVBS_FORMAT == eCVBS_PAL)
    {
        rIP_LIN_FIL_INTERLACE_SEL_C  = 0x0C;
//      rIP_CVBS_FIELD_INV           = 0x00;       /* [2015/5/20] Request from KJW */
        rIP_CVBS_ENC_CLIP_C_HVAL     = 0xFF;
    }
    else
    {
        rIP_LIN_FIL_INTERLACE_SEL_C  = 0x07;
//      rIP_CVBS_FIELD_INV           = 0x01;       /* [2015/5/20] Request from KJW */
        rIP_CVBS_ENC_CLIP_C_HVAL     = 0xEB;
    }

    rIP_CVBS_ADDR_UPD_TIME_7_0   = 0x00;
    rIP_CVBS_ADDR_UPD_TIME_11_8  = 0x00;
    rIP_CVBS_FRC_INV_FLD         = 0x00;    /* [2015/9/09] */
    rIP_CVBS_DPCM_EN             = 0x01;
    rIP_ENABLE_CVBS_FRC          = 0x01;    /* [2016/04/01] SMY 0*/
    rIP_CVBS_WR_FAST             = 0x00;
    rIP_CVBS_ENC_CLIP_C_EN       = 0x01;
    rIP_CVBS_ENC_CLIP_Y_EN       = 0x01;
    //rIP_CVBS_ENC_CLIP_C_HVAL     = 0xEB;
    rIP_CVBS_IN_DATA_BOUNDARY    = 0x00;
    rIP_CVBS_LPF_CB_EN           = 0x01;
    rIP_CVBS_LPF_CR_EN           = 0x01;
    rIP_CVBS_FSC_RST_NT          = 0x01;
    rIP_CVBS_ENC_RANGE_7_0       = 0x50;    /* [2015/8/01] */
    rIP_CVBS_ENC_RANGE_9_8       = 0x03;    /* [2015/8/01] */
    rIP_CVBS_Y_CLIP_7_0          = 0xFF;
    rIP_CVBS_Y_CLIP_9_8          = 0x03;
    rIP_CVBS_C_HCLIP_7_0         = 0xFF;
    rIP_CVBS_C_HCLIP_8           = 0x01;
    rIP_CVBS_COMET = rSWReg.Category.CVBS.Reg.CVBS_COMET_EN;;

    rIP_CVBS_PAL                     = !CVBS_FORMAT;
    rIP_CVBS_H_MODE                  = aryOUTSIZE[output_size][0];
    rIP_CVBS_LPF_C_COEF2_7_0         = aryOUTSIZE[output_size][1];
    rIP_CVBS_LPF_C_COEF3_7_0         = aryOUTSIZE[output_size][2];
    rIP_CVBS_LPF_C_COEF4_7_0         = aryOUTSIZE[output_size][3];
    rIP_CVBS_LPF_C_COEF5_7_0         = aryOUTSIZE[output_size][4];
    rIP_CVBS_LPF_C_COEF6_7_0         = aryOUTSIZE[output_size][5];
    rIP_CVBS_LPF_C_COEF7_7_0         = aryOUTSIZE[output_size][6];
    rIP_CVBS_LPF_C_COEF8_7_0         = aryOUTSIZE[output_size][7];
    rIP_CVBS_LPF_C_COEF9_7_0         = aryOUTSIZE[output_size][8];

    /* [2015/04/02] Jong-Hyun, Choi : APACHE28-1 */
    rIP_CVBS_ENC_SAMPLING_MODE       = aryOUTSIZE[output_size][9];    

	if((output_size == eCVBS_960x480)||(output_size == eCVBS_960x576))
	{
		rIP_CVBS_ENC_SAMPLING_MODE = 1;
	}
	else if(output_size == eCVBS_1280x576)
	{
		rIP_CVBS_ENC_SAMPLING_MODE = 0;
	}
	else if(output_size == eCVBS_1200x480)
	{
		rIP_CVBS_ENC_SAMPLING_MODE = 0;
	}

    rIP_CVBS_PN_OFST                 = aryOUTSIZE[output_size][10];  
    rIP_CVBS_ENC_PN_USER_VALUE_7_0   = aryOUTSIZE[output_size][11];
    rIP_CVBS_ENC_PN_USER_VALUE_15_8  = aryOUTSIZE[output_size][12];
    rIP_CVBS_ENC_PN_USER_VALUE_23_16 = aryOUTSIZE[output_size][13];
    rIP_CVBS_ENC_PN_USER_VALUE_31_24 = aryOUTSIZE[output_size][14];
    rIP_CVBS_ENC_PN_USER_INTNUM_7_0  = aryOUTSIZE[output_size][15];
    rIP_CVBS_ENC_PN_USER_INTNUM_8    = aryOUTSIZE[output_size][16];

    /* [2015/01/26] SJH : STD-01 */
    //{
    if(rSWReg.Category.CVBS.Reg.CVBS_NON_STANDARD)
    {
        rIP_CVBS_ENC_BURST_LEN   = aryNonstandard[output_size][0]; 
        rIP_CVBS_ENC_BURST_DLY   = aryNonstandard[output_size][1];
        rIP_CVBS_ENC_H_OFST_7_0  = aryNonstandard[output_size][2];
        rIP_CVBS_ENC_H_OFST_11_8 = aryNonstandard[output_size][3];   
        rIP_CVBS_ENC_HS_SIZE     = aryNonstandard[output_size][4];       
        rIP_CVBS_ENC_HBLK_OFST   = aryNonstandard[output_size][5]; 
        rIP_CVBS_ENC_HE_SIZE     = aryNonstandard[output_size][6];   
    }else
    {
        rIP_CVBS_ENC_BURST_LEN   = aryStandard[output_size][0];
        rIP_CVBS_ENC_BURST_DLY   = aryStandard[output_size][1];
        rIP_CVBS_ENC_H_OFST_7_0  = aryStandard[output_size][2];
        rIP_CVBS_ENC_H_OFST_11_8 = aryStandard[output_size][3];  
        rIP_CVBS_ENC_HS_SIZE     = aryStandard[output_size][4];      
        rIP_CVBS_ENC_HBLK_OFST   = aryStandard[output_size][5];    
        rIP_CVBS_ENC_HE_SIZE     = aryStandard[output_size][6];  
    }
    //}
}
   
void MONITOR_CVBS_Control(void)
{

    
    switch((etCVBS_H_MODE)rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE)
    {
        case eCVBS_H_720H:  MONITOR_CVBS_FORMAT_SET((eCVBS_OUTPUT_SIZE)CVBS_FORMAT ? eCVBS_720x480  : eCVBS_720x576  );    break;
        case eCVBS_H_960H:  MONITOR_CVBS_FORMAT_SET((eCVBS_OUTPUT_SIZE)CVBS_FORMAT ? eCVBS_960x480  : eCVBS_960x576  );    break;
        case eCVBS_H_1280H: MONITOR_CVBS_FORMAT_SET((eCVBS_OUTPUT_SIZE)CVBS_FORMAT ? eCVBS_1200x480 : eCVBS_1280x576 );    break;
        case eCVBS_H_1440H: MONITOR_CVBS_FORMAT_SET((eCVBS_OUTPUT_SIZE)CVBS_FORMAT ? eCVBS_1440x480 : eCVBS_1440x576 );    break;
        case eCVBS_H_1920H: MONITOR_CVBS_FORMAT_SET((eCVBS_OUTPUT_SIZE)CVBS_FORMAT ? eCVBS_1920x480 : eCVBS_1920x576 );    break;
        default:            MONITOR_CVBS_FORMAT_SET((eCVBS_OUTPUT_SIZE)CVBS_FORMAT ? eCVBS_960x480  : eCVBS_960x576  );    break;
    }
    ncDrv_CVBS_Set(); // CVBS Memory Commands

}

BOOL MONITOR_OperationSize_Control(void)
{
    sGco.InputFrame.Size = (etFRAME_SIZE)rSWReg.Category.MONITOR.Reg.ISP_INPUT_SIZE;
    sGco.OutputFrame.Size = (etFRAME_SIZE)rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_SIZE;

    return TRUE;
}

BOOL MONITOR_OperationFPS_Control(void)
{
typedef enum{
    eFPS_1M_LINEAR_30_30 = 0,
    eFPS_1M_LINEAR_60_60,
    eFPS_2M_LINEAR_30_30,
    eFPS_2M_LINEAR_60_60,
}eFPS_LINEAR_Type;

typedef enum{
    eFPS_1M_2FRAME_60_30 = 0,
    eFPS_1M_2FRAME_120_60,
    eFPS_2M_2FRAME_60_30,
    eFPS_1M_DOL2_60_60,
    eFPS_1M_DOL3_30_30,
    eFPS_1M_DOL3_30_60,
    eFPS_1M_OVDCOMP_30_30,
    eFPS_1M_OVDCOMP_60_60,    
}eFPS_WDR_Type;

#if 0
FRAME RATE (LINEAR MODE)
0x00 : [0720P] INPUT 30FPS, OUTPUT 30FPS  
0x01 : [0720P] INPUT 60FPS, OUTPUT 60FPS
0x02 : [1080P] INPUT 30FPS, OUTPUT 30FPS
0x03 : [1080P] INPUT 60FPS, OUTPUT 60FPS

FRAME RATE (WDR MODE)
0x00 : [0720P / 2 FRAME] INPUT 60FPS, OUTPUT 30FPS
0x01 : [0720P / 2 FRAME] INPUT 120FPS, OUTPUT 60FPS
0x02 : [1080P / 2 FRAME] INPUT 60FPS, OUTPUT 30FPS
0x03 : [0720P / SONY DOL2] INPUT 60FPS, OUTPUT 60FPS
0x04 : [0720P / SONY DOL3] INPUT 30FPS, OUTPUT 30FPS
0x05 : [0720P / SONY DOL3] INPUT 30FPS, OUTPUT 60FPS
0x06 : [0720P / OV Dcomp] INPUT 30FPS, OUTPUT 30FPS
0x07 : [0720P / OV Dcomp] INPUT 60FPS, OUTPUT 60FPS
#endif


#if 1
    UCHAR FPSIdx = (sWdr.Type==eWDRTYPE_OFF) ? rSWReg.Category.MONITOR.Reg.LINEAR_FRAME: rSWReg.Category.MONITOR.Reg.WDR_FRAME;

    switch((etWDR_TYPE_TYPE)sWdr.Type)
    {
        case eWDRTYPE_OFF:
            if(INPUT_SIZE == eSIZE_1280_720)
            {
                if(FPSIdx == eFPS_1M_LINEAR_30_30)
                {
                    rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_30;
                    rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_30;
                }
                else if(FPSIdx == eFPS_1M_LINEAR_60_60)
                {
                    rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_60;
                    rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_60;
                }
            }
            else
            {
                if(FPSIdx == eFPS_2M_LINEAR_30_30)
                {
                    rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_30;
                    rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_30;
                }
                else if(FPSIdx == eFPS_2M_LINEAR_60_60)
                {
                    rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_60;
                    rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_60;
                }
            }

            break;

        case eWDRTYPE_DFRAME_1M:
            if(FPSIdx == eFPS_1M_2FRAME_60_30)
            {
                rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_60;
                rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_30;
            }
            else if(FPSIdx == eFPS_1M_2FRAME_120_60)
            {
                rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_120;
                rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_60;
            }
            
        case eWDRTYPE_DFRAME_2M:
            if(FPSIdx == eFPS_2M_2FRAME_60_30)
            {
                rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_60;
                rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_30;
            }            
            break;

        case eWDRTYPE_DOL2:     /* SENSOR Operation[120P] -> Output[60P] */
            if(FPSIdx == eFPS_1M_DOL2_60_60)
            {
                rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_60;
                rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_30;
            }            
            break;

        case eWDRTYPE_DOL3:     /* SENSOR Operation[120P] -> Output[30P] */
            if(FPSIdx == eFPS_1M_DOL3_30_30)
            {
                rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_30;
                rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_30;
            }            
            else if(FPSIdx == eFPS_1M_DOL3_30_60)
            {
                rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_30;
                rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_60;
            }            

            break;

        case eWDRTYPE_DCOMP_OV: 
            if(FPSIdx == eFPS_1M_OVDCOMP_30_30)
            {
                rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_30;
                rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_30;
            }            
            else if(FPSIdx == eFPS_1M_OVDCOMP_60_60)
            {
                rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_60;
                rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_60;
            }            

            break;

		 case eWDRTYPE_DCOMP_AR: 
            if(FPSIdx == eFPS_1M_OVDCOMP_30_30)
            {
                rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_30;
                rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_30;
            }            
            else if(FPSIdx == eFPS_1M_OVDCOMP_60_60)
            {
                rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_60;
                rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME = eFRAME_RATE_60;
            }            

            break;
    }
#endif

    sGco.InputFrame.Rate = (etFRAME_RATE)rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME;
    sGco.OutputFrame.Rate = (etFRAME_RATE)rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME;

    return TRUE;
}


void MONITOR_FrameRate_Control(void)
{
#if (SENSOR_SELECT == SENSOR_COMMON)
	SENSOR_FPS_Set();
#else
    ncDrv_SENSOR_FPS_Set();  
#endif
    ncSvc_AE_SensorFPSSet(sGco.InputFrame.Rate);
}


void MCU_CLKPath_Set(etFRAME_SIZE OutputSize, etMONITOR_OUT_MODE MonitorOutMode)
{
    //rIP_CLK_CVBS_EN = 0x01;

    switch(MonitorOutMode)
    {
        case eMONITOR_CVBS:
            //rIP_SEL_CKO = 0x01;
            //rIP_SEL_ENC_SRC = 0x00;

			if(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE == eCVBS_H_720H)
			{
    			//rIP_SEL_ENC_FRC_SRC = 0x01;
	            //rIP_CLK_CVBS_1280   = 0x02;
			}
			else if(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE == eCVBS_H_960H)
			{
	            //rIP_SEL_ENC_FRC_SRC = 0x01;
	            //rIP_CLK_CVBS_1280   = 0x03;
			}
			else if(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE == eCVBS_H_1280H)
			{
				//rIP_SEL_ENC_FRC_SRC   = 0x01;
				//if(CVBS_FORMAT == eCVBS_NTSC)	rIP_CLK_CVBS_1280   = 0x00;
				//else					        rIP_CLK_CVBS_1280   = 0x01;
			}

            //rIP_SEL_ISP_DIV1 = 0x00; 
            //rIP_SEL_ISP_DIV2 = 0x00; 
            //rIP_SEL_ISP_DIV3 = 0x00; 

            break;

        case eMONITOR_HDSDI:
            //rIP_SEL_ISP_CK        = 0x00; 

#if (PRODUCT_ISP == PJT_NVP2450H_SECURITY)	
    //if(rSWReg.Category.SYSTEM.Reg.EXT_TW6872_EN == STATE_ON) 
    //    rIP_SEL_ISP_CK = 0x04;	// EXT_CLK0 74.25Mhz
#elif(PRODUCT_ISP == PJT_NVP2630_AUTOMOTIVE)
#endif            

			if(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE == eCVBS_H_720H)
			{
    			//rIP_SEL_ENC_FRC_SRC = 0x01;
	            //rIP_CLK_CVBS_1280   = 0x02;
			}
			else if(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE == eCVBS_H_960H)
			{
	            //rIP_SEL_ENC_FRC_SRC = 0x01;
	            //rIP_CLK_CVBS_1280   = 0x03;
	            rIP_W_BURST_CTRL_CVBS_FRC   = 0x08;	            
			}
			else if(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE == eCVBS_H_1280H)
			{
				//rIP_SEL_ENC_FRC_SRC   = 0x01;

				//if(CVBS_FORMAT == eCVBS_NTSC)	rIP_CLK_CVBS_1280   = 0x00;
				//else					        rIP_CLK_CVBS_1280   = 0x01;
				rIP_W_BURST_CTRL_CVBS_FRC   = 0x06;	            				
			}

            ncSvc_WDR_CLKPath_Set();
            break;
            
        case eMONITOR_AHD:
            if(OutputSize == eSIZE_1920_1080)
            {
                /* PLL0 (148.5Mhz) */ 
                //rIP_SEL_ISP_CK        = 0x00; /* 148.5Mhz (PLL0) */
                //rIP_SEL_ENC_SRC       = 0x01; /* 148.5Mhz (PLL0) */
                //rIP_SEL_ENC_FRC_SRC   = 0x00; /* 74.25Mhz (PLL0) */
            }
            else
            {
                if(rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME == eFRAME_RATE_30)
                {
                    /* [2016/1/12] Leo.Sim : 30p */
                    //rIP_SEL_ISP_CK        = 0x01; /*   FPGA */
                    //rIP_SEL_ENC_SRC       = 0x00; /*   144Mhz (PLL1) */
                    //rIP_SEL_ENC_FRC_SRC   = 0x01; /*    FPGA */
                }
                else if(rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME == eFRAME_RATE_60)
                {
                    /* [2016/01/12] Leo.Sim : 60p */
                    //rIP_SEL_ISP_CK        = 0x00; /*   FPGA */
                    //rIP_SEL_ENC_SRC       = 0x01; /*   144Mhz (PLL1) */
                    //rIP_SEL_ENC_FRC_SRC   = 0x00; /*    FPGA */
                }
            }

            ncSvc_WDR_CLKPath_Set();

            break;
    }
}

void MONITOR_ClockInitialize_Set(void)
{
    MCU_PLL_Set();
    //MONITOR_CLKPath_SensorInput_Set();
    MCU_CLKPath_Set((etFRAME_SIZE)OUTPUT_SIZE, (etMONITOR_OUT_MODE)sGco.MonitorOutput);
    //MW_SwReset_Set();
}

void MONITOR_MonitorOutput_Control(void)
{
    //rIP_DAC_CVBS_PWDN = 0x00;

    switch(sGco.MonitorOutput)
    {
        case eMONITOR_CVBS:
            rIP_CVBS_OUT_SEL = 0;
            MONITOR_CVBS_Control();
            break;
            
        case eMONITOR_HDSDI:
            rIP_CVBS_OUT_SEL = 0;
            MONITOR_CVBS_Control();
            //APP_Tw6872Mode_Set();
            break;

        case eMONITOR_AHD:
            rIP_CVBS_OUT_SEL = 1;
            MONITOR_AHD_Control();
            ncDrv_MainFRC_Reset();
            break;
    }
}

void MONITOR_DigitalFormat_Control(void)
{
    UCHAR i;
    UCHAR Format = 0;
    static UCHAR OutputFormat = 0xFF;
    
    if(OutputFormat != rSWReg.Category.MONITOR.Reg.MONITOR_FORMAT)
    {
        OutputFormat = rSWReg.Category.MONITOR.Reg.MONITOR_FORMAT;

#if 0
        if(OutputFormat == 2)// BT656
            rIP_CLK_HD656_EN = 1;
        else
            rIP_CLK_HD656_EN = 0;
#endif
        
        if(OutputFormat == 0)       Format = YC16;      // YC16
        else if(OutputFormat == 1)  Format = BT1120;    // BT1120
        else if(OutputFormat == 2)  Format = BT656;     // BT656
        else if(OutputFormat == 3)  Format = RGB24;     // RGB24
        else                        Format = BT1120;    // BT1120

        //rBank18.Byte.Reg_0xD895.B8.GPMODE43 = Format; // HACT_O, TOUT2

	    if(sGco.MonitorOutput == eMONITOR_HDSDI && rSWReg.Category.SYSTEM.Reg.EXT_TW6872_EN != 1) 
		{
		    for(i = 0x96; i <= 0x9F; i++)	ISPSET08((aIP_GPMODE_RESERVED + i), Format);
		}
		else
		{
			for(i = 0x97; i <= 0x9F; i++)	ISPSET08((aIP_GPMODE_RESERVED + i), Format);

            #if (BOARD_TYPE == FPGA)
			if(sGco.MonitorOutput == eMONITOR_AHD)
			{
                rIP_GPMODE44 = 0xB;
                rIP_GPMODE45 = 0x3;
			}
			#endif
        }
        
    }
}

void ncDrv_OutputFormat_Set_Flicker(void)
{
	MONITOR_OperationSize_Control();
    MONITOR_OperationFPS_Control();
#if (SENSOR_SELECT == SENSOR_COMMON)
	SENSOR_FPS_Set();
#else
    ncDrv_SENSOR_FPS_Set();  
#endif
	
}

void ncDrv_OutputFormat_Set(void)
{
    static etFRAME_SIZE preOutputSize = eSIZE_MAX;

    UCHAR * FrameSize[eSIZE_MAX] = {"720", "1080"};
    UCHAR * FrameRate[eFRAME_RATE_MAX] = {"30", "60", "120"};

    MONITOR_OperationSize_Control();
    MONITOR_OperationFPS_Control();

    
    DEBUGMSG(MSGINFO, "# SENSOR: ");
    DEBUGMSG(MSGINFO, FrameSize[sGco.InputFrame.Size]);
    DEBUGMSG(MSGINFO, " / ");
    DEBUGMSG(MSGINFO, FrameRate[sGco.InputFrame.Rate]);
    DEBUGMSG(MSGINFO, " #\n");

    DEBUGMSG(MSGINFO, "#    ISP: ");
    DEBUGMSG(MSGINFO, FrameSize[sGco.OutputFrame.Size]);
    DEBUGMSG(MSGINFO, " / ");
    DEBUGMSG(MSGINFO, FrameRate[sGco.OutputFrame.Rate]);
    DEBUGMSG(MSGINFO, " #\n");

    
#if 0
    if(sGco.MonitorOutput == eMONITOR_HDSDI)
    {
        if(OUTPUT_SIZE == eSIZE_1920_1080)  rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE = eCVBS_H_1280H;
        else                                rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE = eCVBS_H_960H;
    }
#endif

#if CHIP_MODE
    MONITOR_ClockInitialize_Set();
    MONITOR_FrameRate_Control();
#endif 


    MONITOR_DigitalFormat_Control();
    MONITOR_FrameSize_Control((etMONITOR_OUT_MODE)sGco.MonitorOutput);
    MONITOR_MonitorOutput_Control();

#if (SENSOR_SELECT == SENSOR_COMMON)
	SENSOR_FPS_Set();
#else
    ncDrv_SENSOR_FPS_Set();  
#endif
		
#if 1
    if(preOutputSize != OUTPUT_SIZE)
    {
        ncDrv_MD_ReSize();
        ncDrv_Defog_ReSize();
        ncDrv_HSBLC_ReSize();
        ncDrv_DPC_ReSize();
    }

	sMwCategorySubFlag.Category.B32.SUB_FLAG_OSD_POS = STATE_ON;
	sMwCategorySubFlag.Category.B32.SUB_FLAG_OSD_PATH = STATE_ON;
    pCategory_Func[CtgIdx_OSD].Func(0x00);

	//rIP_CVBS_DS_IN_SIZE_CUSTOM = 0;
	//rIP_CVBS_DS_IN_SIZE_CUSTOM = 1;
	
    preOutputSize = OUTPUT_SIZE;
#endif
}

void MONITOR_CLKPath_SensorInput_Set(void)
{
#if 0
    switch(SENSOR_ICLK)
    {
        case SENSOR_ICLK_37p125M :
            rIP_SEL_PMCLK        = 0x01;         // Source Clock : PLL0
            rIP_SEL_PMCLK_DIV    = 0x02;         // PLL0/4 = 148.5/4 = 37.125Mhz
            break;
        case SENSOR_ICLK_27M:           
        default : 
            rIP_SEL_PMCLK         = 0x00;     // Source Clock : MCU Clock
            rIP_SEL_PMCLK_DIV     = 0x01;     // MCU Clock/2 = 54/2 = 27Mhz
            break;
    }
#endif
}


void MONITOR_INPUT_CROP_Set(stIMAGE_SIZE_INFO * SetSize)
{
    USHORT HPos = (sGco.InputSize.Active.SizeH - SetSize->Active.SizeH) >> 1;
    USHORT VPos = (sGco.InputSize.Active.SizeV - SetSize->Active.SizeV) >> 1;

    ISPSET16(aIP_INPUT_CROP_H_POS_7_0, HPos);
    ISPSET16(aIP_INPUT_CROP_V_POS_7_0, VPos);

    ISPSET16(aIP_INPUT_CROP_H_SIZE_7_0, (SetSize->Active.SizeH + H_ACTIVE_OFFSET));
    ISPSET16(aIP_INPUT_CROP_V_SIZE_7_0, SetSize->Active.SizeV);

    rIP_INPUT_CROP_SYNC_EN = STATE_ON;
//    rIP_INPUT_CROP_VSYNC_EN = STATE_ON;   /* IF ON  = CVBS NOT WORKING */
}

void MONITOR_YBLUR_SIZE_Set(stIMAGE_SIZE_INFO * SetSize)
{
    ISPSET16(aIP_YBLUR_V_SIZE_7_0, SetSize->Active.SizeV);
    ISPSET16(aIP_YBLUR_H_SIZE_7_0, (SetSize->Active.SizeH + H_ACTIVE_OFFSET));

    rIP_YBLUR_V_END_MUL = 16 - (ISPGET16(aIP_YBLUR_V_SIZE_7_0) % 16);
    rIP_YBLUR_H_END_MUL = 16 - (ISPGET16(aIP_YBLUR_H_SIZE_7_0) % 16);
}

void MONITOR_FRC_IMG_Set(stIMAGE_SIZE_INFO * SetSize)
{
/*==================================================================
   PRODUCT   OUTPUT SIZE        HPIXEL  VLINE   WLINE(WLINE CAL)     
--------------------------------------------------------------------
    2450H   1280x720            1288    720     1472 (VLINE+16)*2    
            1920x1080           1928    1080    2192 (VLINE+16)*2    
====================================================================*/
    USHORT wline;

	if(rSWReg.Category.SYSTEM.Reg.MEMORY_MAP >=5)
		wline = (SetSize->Active.SizeV + 4) << 1;          /* (Active V Size + 16) x 2 */
	else
	    wline = (SetSize->Active.SizeV + 16) << 1;          /* (Active V Size + 16) x 2 */

    ISPSET16(aIP_FRC_IMG_HPIXEL_7_0, (SetSize->Active.SizeH + H_ACTIVE_OFFSET));
    ISPSET16(aIP_FRC_IMG_VLINE_7_0, SetSize->Active.SizeV);
    ISPSET16(aIP_FRC_IMG_WLINE_7_0, wline);
}

void MONITOR_FRC_SIZE_Set(stIMAGE_SIZE_INFO * SetSize)
{
/*===============================================================
 Blank_Pixel = Total Size - Active Size                           
 Blank_Num = Total Size - Active Size                             
=================================================================*/

    switch(sGco.MonitorOutput)
    {
        case eMONITOR_CVBS:     
                rIP_FRC_SYNC_MODE = STATE_OFF;      
                break;
        case eMONITOR_HDSDI:
        case eMONITOR_AHD:
                rIP_FRC_SYNC_MODE = STATE_ON;
                rIP_FRC_READ_MODE = (sGco.InputFrame.Rate > sGco.OutputFrame.Rate) ? READ_CURRENT : READ_PREVIOUS;
                break;
    }

	ncDrv_DNR_WB_WRAP_Set(rIP_FRC_SYNC_MODE);
    
    ISPSET16(aIP_FRC_HACT_PIXEL_7_0, (SetSize->Active.SizeH + H_ACTIVE_OFFSET));
    ISPSET16(aIP_FRC_HBLANK_PIXEL_7_0, (SetSize->Total.SizeH - SetSize->Active.SizeH - H_ACTIVE_OFFSET));
    ISPSET16(aIP_FRC_VSYNC_NUM_7_0, SetSize->Active.SizeV+V_ACTIVE_OFFSET);
    ISPSET16(aIP_FRC_VBLANK_NUM_7_0, (SetSize->Total.SizeV - SetSize->Active.SizeV));
}

void MONITOR_YC_CROP_Set(stIMAGE_SIZE_INFO * SetSize)
{
#if 1
    ISPSET16(aIP_YC_CROP_VACT_POS_7_0, 0x00); // Modify by pychan!
    ISPSET16(aIP_YC_CROP_HACT_POS_7_0, 0x00); // Modify by pychan!
    ISPSET16(aIP_YC_CROP_VACT_CROP_SIZE_7_0, SetSize->Active.SizeV+V_ACTIVE_OFFSET);
    ISPSET16(aIP_YC_CROP_HACT_CROP_SIZE_7_0, (SetSize->Active.SizeH + H_ACTIVE_OFFSET));
#endif
}

void ncDrv_MONITOR_IIF_POSITION_Set(void)
{
    UCHAR MirrorMode = rSWReg.Category.DEFFECT.Reg.MIRROR_MODE;
    UCHAR VStart, HStart;

#if (SENSOR_SELECT == SENSOR_COMMON)
	HStart = SENSOR_INTERFACE_DATA.F_PORCH_START[OUTPUT_SIZE][0][MirrorMode & 0x1];
   	VStart = SENSOR_INTERFACE_DATA.F_PORCH_START[OUTPUT_SIZE][1][(MirrorMode>>1) & 0x1];
#else
    HStart = sSensorInterface.F_PORCH_START[OUTPUT_SIZE][0][MirrorMode & 0x1];
    VStart = sSensorInterface.F_PORCH_START[OUTPUT_SIZE][1][(MirrorMode>>1) & 0x1];
#endif
    rIP_IIF_IS_INPUT_HACT = STATE_OFF;

//    SetChar((aIP_IIF_HACT_F_PORCH_VSYNC_7_0+1), (USHORT)0);
    ISPSET08(aIP_IIF_HACT_F_PORCH_VSYNC_7_0, (USHORT)VStart);
//    SetChar((aIP_IIF_HACT_F_PORCH_HSYNC_7_0+1), (USHORT)0);
    ISPSET08(aIP_IIF_HACT_F_PORCH_HSYNC_7_0, (USHORT)HStart);
}

void MONITOR_IIF_SIZE_Set(stIMAGE_SIZE_INFO * SetSize)
{
	USHORT ActiveWidth = SetSize->Active.SizeH + H_ACTIVE_OFFSET;

#if (SENSOR_SELECT == SENSOR_COMMON)
	FLOAT LVDSdiv;
	if(SenHeader.Byte.Info.B16.Interface == INPUT_LVDS)
	{
		LVDSdiv = (FLOAT)((FLOAT)rIP_LD_NUM_READ_DATA / 2);
		LVDSdiv = (FLOAT)LVDSdiv / rIP_LD_NUM_LVDS_HEIGHT_BLOCK;
		ActiveWidth *= LVDSdiv;
	}
#else
#if (SENSOR_INTERFACE == INPUT_LVDS)
	FLOAT LVDSdiv = (FLOAT)((FLOAT)rIP_LD_NUM_READ_DATA / 2);
	LVDSdiv = (FLOAT)LVDSdiv / rIP_LD_NUM_LVDS_HEIGHT_BLOCK;
	ActiveWidth *= LVDSdiv;
#endif    
#endif
    ISPSET16(aIP_IIF_HACT_WIDTH_7_0, ActiveWidth);
    ISPSET16(aIP_IIF_HACT_HEIGHT_7_0, SetSize->Active.SizeV);

    ncDrv_MONITOR_IIF_POSITION_Set();

    ISPSET08(aIP_ICDC_FR_HACT_HEIGHT, 0xFF);
}

void MONITOR_ITP_SIZE_Set(stIMAGE_SIZE_INFO * SetSize)
{
    ISPSET16(aIP_ITP_HACT_SIZE_7_0, (SetSize->Active.SizeH + H_ACTIVE_OFFSET));
    ISPSET16(aIP_ITP_VACT_SIZE_7_0, SetSize->Active.SizeV);
}

void MONITOR_ICDC_SIZE_Set(stIMAGE_SIZE_INFO * SetSize)
{
	ISPSET16(aIP_ICDC_HACT_WIDTH_7_0, (SetSize->Active.SizeH + H_ACTIVE_OFFSET));
	ISPSET16(aIP_ICDC_HACT_HEIGHT_7_0, SetSize->Active.SizeV);
}

void MONITOR_CVBS_CROP_Set(stIMAGE_SIZE_INFO * SetSize)
{
    USHORT h_margin = 0;
    USHORT v_margin = 0;

  	//*ap35	REGRW16(APACHE_ISP_BASE, aIP_CVBS_CROP_V_ACT_IN_7_0) = REGRW16(APACHE_ISP_BASE, aIP_FRC_VSYNC_NUM_7_0);  //CVBS_CROP_V_ACT_IN_7_0
    //*ap35	REGRW16(APACHE_ISP_BASE, aIP_CVBS_CROP_H_ACT_IN_7_0) = REGRW16(APACHE_ISP_BASE, aIP_FRC_HACT_PIXEL_7_0);	//CVBS_CROP_H_ACT_IN_7_0

    if(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_PATH == ePATH_HDS_VDS)
    {
        ISPSET16(aIP_CVBS_CROP_H_ACT_7_0, sGco.InputSize.Active.SizeH);
        ISPSET16(aIP_CVBS_CROP_V_ACT_7_0, sGco.InputSize.Active.SizeV);        
    }
    else if(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_PATH == ePATH_HCR_VDS)
    {
        ISPSET16(aIP_CVBS_CROP_H_ACT_7_0, SetSize->Active.SizeH);
        ISPSET16(aIP_CVBS_CROP_V_ACT_7_0, sGco.InputSize.Active.SizeV);
        
        h_margin = (sGco.InputSize.Active.SizeH - SetSize->Active.SizeH) >> 1;
    }
    else
    {
        ISPSET16(aIP_CVBS_CROP_H_ACT_7_0, SetSize->Active.SizeH);
        ISPSET16(aIP_CVBS_CROP_V_ACT_7_0, SetSize->Active.SizeV);

        h_margin = (sGco.InputSize.Active.SizeH - SetSize->Active.SizeH) >> 1;
        v_margin = (sGco.InputSize.Active.SizeV - SetSize->Active.SizeV) >> 1;        
    }

    h_margin += (H_ACTIVE_OFFSET >> 1);

    ISPSET16(aIP_CVBS_CROP_H_POS_7_0, h_margin);
    ISPSET16(aIP_CVBS_CROP_V_POS_7_0, v_margin);
    
    rIP_CVBS_CROP_HACT_LOCK_EN = STATE_ON;
    rIP_CVBS_CROP_HEN = STATE_ON; 
    rIP_CVBS_CROP_VEN = STATE_ON; 

    rIP_CVBS_CROP_REG_CHG = 1;   //SMYCB
    
}

void MONITOR_CVBS_DSCALE_Set(stIMAGE_SIZE_INFO * SetSize)
{
#define DTO_1X      0x4000
#define ADDR_CVBS_DS_REG_CHG  0x30f01B97

    INT32 h_dto = DTO_1X;
    INT32 v_dto = DTO_1X;

    USHORT  in_hact_size = ISPGET16(aIP_CVBS_CROP_H_ACT_7_0);
    USHORT  in_vact_size = ISPGET16(aIP_CVBS_CROP_V_ACT_7_0);    

    if(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_PATH == ePATH_HDS_VDS)
    {
        h_dto = (unsigned long)in_hact_size * DTO_1X / SetSize->Active.SizeH;
        v_dto = (unsigned long)in_vact_size * DTO_1X / SetSize->Active.SizeV;
    }
    else if(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_PATH == ePATH_HCR_VDS)
    {
        v_dto = (unsigned long)in_vact_size * DTO_1X / SetSize->Active.SizeV;
    }

    rIP_CVBS_DS_BICUBIC_TABLE_C = 1;
    rIP_CVBS_DS_BICUBIC_TABLE_Y = 1;
    
    rIP_CVBS_DS_SEL_METHOD_C = 1;
    rIP_CVBS_DS_SEL_METHOD_Y = 1;

    /* DownScale Input Size = Crop size */
    ISPSET16(aIP_CVBS_DS_IN_HACT_SIZE_7_0, in_hact_size);
    ISPSET16(aIP_CVBS_DS_IN_VACT_SIZE_7_0, in_vact_size);
    ISPSET16(aIP_CVBS_DS_IN_HBLK_SIZE_7_0, (sGco.InputSize.Total.SizeH - sGco.InputSize.Active.SizeH));

    /* DownScale Output Size */
    ISPSET16(aIP_CVBS_DS_H_DTO_7_0, h_dto);
    ISPSET16(aIP_CVBS_DS_V_DTO_7_0, v_dto);
    ISPSET16(aIP_CVBS_DS_OUT_HACT_SIZE_7_0, SetSize->Active.SizeH);
    ISPSET16(aIP_CVBS_DS_OUT_VACT_SIZE_7_0, SetSize->Active.SizeV);

    ISPSET08(ADDR_CVBS_DS_REG_CHG,(ISPGET08(ADDR_CVBS_DS_REG_CHG) | (0<<7)));   
    ISPSET08(ADDR_CVBS_DS_REG_CHG,(ISPGET08(ADDR_CVBS_DS_REG_CHG) | (1<<6)));   


#undef  DTO_1X    
}


void MONITOR_CVBS_OUTPUT_Set(stIMAGE_SIZE_INFO * SetSize)
{
    typedef struct{
        USHORT EVEN;
        USHORT ODD;
    }VERTICAL_WIDTH_TYPE;

    VERTICAL_WIDTH_TYPE VerticalWidth[eCVBS_FORMAT] = {
/* PAL  */  {24, 25},
/* NTSC */  {19, 20},
    };
    
    ISPSET16(aIP_CVBS_VACT_7_0, (SetSize->Active.SizeV >> 1));
    ISPSET16(aIP_CVBS_HACT_7_0, SetSize->Active.SizeH);
    ISPSET16(aIP_CVBS_VSW1_7_0, VerticalWidth[CVBS_FORMAT].EVEN); 
    ISPSET16(aIP_CVBS_VSW2_7_0, VerticalWidth[CVBS_FORMAT].ODD); 
    ISPSET16(aIP_CVBS_HSW_7_0, (SetSize->Total.SizeH - SetSize->Active.SizeH)); 


    rIP_CVBS_FRAME_MODE =1;  //SMYCB
}


void MONITOR_OPD_BLOCK_Set(stIMAGE_SIZE_INFO * SetSize)
{
#define OPD_BLOCK_COUNT_X   8L
#define OPD_BLOCK_COUNT_Y   8L

    USHORT OpdBlockSizeX, OpdBlockSizeY;

    rIP_OPD_BLOCK_NUM_X = OPD_BLOCK_COUNT_X-1L;
    rIP_OPD_BLOCK_NUM_Y = OPD_BLOCK_COUNT_Y-1L;

    switch(sGco.MonitorOutput)
    {
        case eMONITOR_CVBS:
           if(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_PATH == ePATH_HDS_VDS)
            {
                OpdBlockSizeX = sGco.InputSize.Active.SizeH / OPD_BLOCK_COUNT_X;
                OpdBlockSizeY = sGco.InputSize.Active.SizeV / OPD_BLOCK_COUNT_Y;
            }
            else if(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_PATH == ePATH_HCR_VDS)
            {
                OpdBlockSizeX = SetSize->Active.SizeH / OPD_BLOCK_COUNT_X;
                OpdBlockSizeY = sGco.InputSize.Active.SizeV / OPD_BLOCK_COUNT_Y;
            }
            else
            {
                OpdBlockSizeX = SetSize->Active.SizeH / OPD_BLOCK_COUNT_X;
                OpdBlockSizeY = SetSize->Active.SizeV / OPD_BLOCK_COUNT_Y;
            }

            ISPSET16(aIP_OPD_START_X_7_0, ISPGET16(aIP_CVBS_CROP_H_POS_7_0));
            ISPSET16(aIP_OPD_START_Y_7_0, ISPGET16(aIP_CVBS_CROP_V_POS_7_0));
            ISPSET08(aIP_OPD_BLOCK_LENGTH_X_7_0, OpdBlockSizeX);
            ISPSET08(aIP_OPD_BLOCK_LENGTH_Y_7_0, OpdBlockSizeY);
            break;
            
        case eMONITOR_HDSDI:
        case eMONITOR_AHD:
#if CHIP_MODE
            ISPSET16(aIP_OPD_START_X_7_0, (0L + (H_ACTIVE_OFFSET >> 1)));
            ISPSET16(aIP_OPD_START_Y_7_0, 0L);
            ISPSET08(aIP_OPD_BLOCK_LENGTH_X_7_0, (SetSize->Active.SizeH / OPD_BLOCK_COUNT_X));
            ISPSET08(aIP_OPD_BLOCK_LENGTH_Y_7_0, (SetSize->Active.SizeV / OPD_BLOCK_COUNT_Y));
#endif

#if FPGA_MODE
            ISPSET16(aIP_OPD_START_X_7_0, 0x0071);
            ISPSET16(aIP_OPD_START_Y_7_0, 0x003E);
            ISPSET08(aIP_OPD_BLOCK_LENGTH_X_7_0, 0x87);
            ISPSET08(aIP_OPD_BLOCK_LENGTH_Y_7_0, 0x4D);
#endif

            break;
    }
}

void MONITOR_OTP_SIZE_Set(stIMAGE_SIZE_INFO * SetSize)
{
    ISPSET16(aIP_OTP_HACT_SIZE_7_0, SetSize->Active.SizeH);
    ISPSET16(aIP_OTP_V1ACT_SIZE_7_0, SetSize->Active.SizeV);
}

void MONITOR_OUT_FORMATTER_Set(stIMAGE_SIZE_INFO * SetSize)
{
    rIP_OF_CROP_VEN = 0x01;
    ISPSET16(aIP_OF_CROP_HPOS_7_0, ((rIP_LDC_EN == 0)? 0x04 : 0x00));
    ISPSET16(aIP_OF_CROP_VPOS_7_0, 0);
    ISPSET16(aIP_OF_CROP_HSIZE_7_0, SetSize->Active.SizeH);
    ISPSET16(aIP_OF_CROP_VSIZE_7_0, SetSize->Active.SizeV);
    
    ISPSET16(aIP_OF_REGEN_HSYN_SY_7_0, (SetSize->Total.SizeH - SetSize->Active.SizeH));
    ISPSET16(aIP_OF_REGEN_VSYN_SY_7_0, (SetSize->Total.SizeV - SetSize->Active.SizeV));
}

void MONITOR_WDR_SIZE_Set(stIMAGE_SIZE_INFO * SetSize)
{
    ISPSET16(aIP_WDR_V_SIZE_7_0, SetSize->Active.SizeV);
    ISPSET16(aIP_WDR_H_SIZE_7_0, SetSize->Active.SizeH);
}

void MONITOR_LBFRC_SIZE_Set(stIMAGE_SIZE_INFO * SetSize)
{
	USHORT HBLANK_PIXEL[eWDRTYPE_MAX]     = { 0x00, 0x16A, 0x110, 0x16A, 0x16A, 0x16A, 0x142, 0x142, 0x16A, 0x16A };
	UCHAR VBLANK_NUM[eWDRTYPE_MAX]        = { 0x00, 0x1E, 0x2D, 0x1E, 0x1E, 0x1E, 0x1E, 0x1E, 0x1E, 0x1E };
	UCHAR VBLANK_NUM_FREE[eWDRTYPE_MAX]  = { 0x00, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14, 0x14 };
	UCHAR BPORCH_NUM[eWDRTYPE_MAX]        = { 0x00, 0x0A, 0x00, 0x02, 0x80, 0x80, 0x00, 0x00, 0x00, 0x00 };
	UCHAR FPORCH_NUM[eWDRTYPE_MAX]        = { 0x00, 0x04, 0x04, 0x04, 0x04, 0x04, 0x0C, 0x04, 0x04, 0x04 };

    ISPSET16(aIP_LBFRC_VSYNC_NUM_7_0, SetSize->Active.SizeV);
    ISPSET16(aIP_LBFRC_HSYNC_PIXEL_7_0, (SetSize->Active.SizeH + H_ACTIVE_OFFSET));

    ISPSET16(aIP_LBFRC_HBLANK_PIXEL_7_0, HBLANK_PIXEL[sWdr.Type]);
    ISPSET16(aIP_LBFRC_VBLANK_NUM_7_0,  (USHORT)VBLANK_NUM[sWdr.Type]);
    ISPSET16(aIP_LBFRC_VBLANK_NUM_FREE_7_0, (USHORT)VBLANK_NUM_FREE[sWdr.Type]);
    ISPSET16(aIP_LBFRC_FPORCH_NUM_7_0, (USHORT)FPORCH_NUM[sWdr.Type]);
    ISPSET16(aIP_LBFRC_BPORCH_NUM_7_0, (USHORT)BPORCH_NUM[sWdr.Type]);


}

void MONITOR_INPUT_HTOTAL_Set(void)
{
    UCHAR WdrMode;

    if(sWdr.Type == eWDRTYPE_OFF)   WdrMode = STATE_OFF;
    else                            WdrMode = STATE_ON;
#if (SENSOR_SELECT == SENSOR_COMMON)
    switch((etMONITOR_OUT_MODE)sGco.MonitorOutput)
    {
        case eMONITOR_CVBS:
            ISPSET16(aIP_INPUT_H_TOTAL_7_0, SENSOR_INTERFACE_DATA.INPUT_H_TOTAL[WdrMode][INPUT_SIZE][CVBS_FORMAT]);
            break;
        case eMONITOR_HDSDI:
            ISPSET16(aIP_INPUT_H_TOTAL_7_0, SENSOR_INTERFACE_DATA.INPUT_H_TOTAL[WdrMode][INPUT_SIZE][CVBS_FORMAT]);
            break;
        case eMONITOR_AHD:
            ISPSET16(aIP_INPUT_H_TOTAL_7_0, SENSOR_INTERFACE_DATA.INPUT_H_TOTAL[WdrMode][INPUT_SIZE][CVBS_FORMAT]);
            break;
    }
#else
    switch((etMONITOR_OUT_MODE)sGco.MonitorOutput)
    {
        case eMONITOR_CVBS:
            ISPSET16(aIP_INPUT_H_TOTAL_7_0, sSensorInterface.INPUT_H_TOTAL[WdrMode][INPUT_SIZE][CVBS_FORMAT]);
            break;
        case eMONITOR_HDSDI:
            ISPSET16(aIP_INPUT_H_TOTAL_7_0, sSensorInterface.INPUT_H_TOTAL[WdrMode][INPUT_SIZE][CVBS_FORMAT]);
            break;
        case eMONITOR_AHD:
            ISPSET16(aIP_INPUT_H_TOTAL_7_0, sSensorInterface.INPUT_H_TOTAL[WdrMode][INPUT_SIZE][CVBS_FORMAT]);
            break;
    }
#endif

    ISPSET16(aIP_INPUT_H_TOTAL_RISE_7_0, ISPGET16(aIP_INPUT_H_TOTAL_7_0));
}

void ncDrv_MONITOR_SENSOR_Type_Set(stIMAGE_SIZE_INFO * SetSize)
{

#if (SENSOR_SELECT == OMNIVISION_OV10640)
	USHORT ActiveWidth = (USHORT)SetSize->Active.SizeH + H_ACTIVE_OFFSET;
    USHORT HPos = (sGco.InputSize.Active.SizeH - SetSize->Active.SizeH) >> 1;
    USHORT VPos = (sGco.InputSize.Active.SizeV - SetSize->Active.SizeV) >> 1;

	if(sWdr.Type == eWDRTYPE_LWDR3)
	{

		ncLib_DEBUG_Printf(1, "__WDR LWDR3\n");

		ActiveWidth = ActiveWidth*3;

	/* IIF */
	    ISPSET16(aIP_IIF_HACT_WIDTH_7_0, ActiveWidth);
	    ISPSET16(aIP_IIF_HACT_HEIGHT_7_0, (SetSize->Active.SizeV+4));

	    //MONITOR_IIF_POSITION_Set();
	    ncDrv_MONITOR_IIF_POSITION_Set();

	/* ICDC */
		ISPSET16(aIP_ICDC_HACT_WIDTH_7_0, ActiveWidth);
		ISPSET16(aIP_ICDC_HACT_HEIGHT_7_0, (SetSize->Active.SizeV+4));

	/* INPUT CROP */
	    ISPSET16(aIP_INPUT_CROP_H_POS_7_0, HPos);
	    ISPSET16(aIP_INPUT_CROP_V_POS_7_0, VPos);

	    ISPSET16(aIP_INPUT_CROP_H_SIZE_7_0, ActiveWidth);
	    ISPSET16(aIP_INPUT_CROP_V_SIZE_7_0, (SetSize->Active.SizeV+4));
	}

    rIP_INPUT_CROP_SYNC_EN = STATE_ON;
#else



#endif

}

void MONITOR_FrameSize_Get(void)
{
    sGco.FrameSize = lutStdHD[INPUT_SIZE][CVBS_FORMAT].Active;
    
    switch(sGco.MonitorOutput)
    {
        case eMONITOR_CVBS:
            sGco.InputSize = lutStdHD[INPUT_SIZE][CVBS_FORMAT];
            sGco.OutputSize = lutStdCVBS[(etCVBS_H_MODE)rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE][CVBS_FORMAT];
            break;
            
        case eMONITOR_HDSDI:
            sGco.InputSize = lutStdHD[INPUT_SIZE][CVBS_FORMAT];
            sGco.OutputSize = lutStdHD[(etFRAME_SIZE)OUTPUT_SIZE][CVBS_FORMAT];
            break;
            
        case eMONITOR_AHD:
            sGco.InputSize = lutStdHD[INPUT_SIZE][CVBS_FORMAT];
            sGco.OutputSize = lutStdHD[(etFRAME_SIZE)OUTPUT_SIZE][CVBS_FORMAT];

            if((sGco.OutputFrame.Size == eSIZE_1280_720) && (sGco.OutputFrame.Rate == eFRAME_RATE_30))
                sGco.OutputSize = lutStdAHD[CVBS_FORMAT];

            break;
    }
    sGco.CVBSSize = lutStdCVBS[(etCVBS_H_MODE)rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE][CVBS_FORMAT];
}

void MONITOR_FrameSize_Control(etMONITOR_OUT_MODE OutputMode)
{
#define SIZE_CONTROL_COUNT  18L

    typedef struct {
        void(* Func)(stIMAGE_SIZE_INFO * SetSize);
        stIMAGE_SIZE_INFO * CVBS_SET;
        stIMAGE_SIZE_INFO * DIGITAL_SET;
    } pFUNC_SIZE_SET_TYPE;

    UCHAR i;

    pFUNC_SIZE_SET_TYPE SizeControl[SIZE_CONTROL_COUNT] = {
        /*  Function                      CVBS                  HD(HD-SDI,AHD)  */
/* 00 */ { MONITOR_IIF_SIZE_Set,          &sGco.InputSize,     &sGco.InputSize  },
/* 01 */ { MONITOR_ICDC_SIZE_Set,         &sGco.InputSize,     &sGco.InputSize  },
/* 02 */ { MONITOR_ITP_SIZE_Set,          &sGco.InputSize,     &sGco.OutputSize },
/* 03 */ { MONITOR_INPUT_CROP_Set,        &sGco.InputSize,     &sGco.OutputSize },
/* 04 */ { MONITOR_LBFRC_SIZE_Set,        &sGco.InputSize,     &sGco.OutputSize },
/* 05 */ { MONITOR_WDR_SIZE_Set,          &sGco.InputSize,     &sGco.OutputSize },
/* 06 */ { ncDrv_DNR_IMG_Set,             &sGco.InputSize,     &sGco.OutputSize },
/* 07 */ { MONITOR_FRC_IMG_Set,           &sGco.InputSize,     &sGco.OutputSize },
/* 08 */ { MONITOR_FRC_SIZE_Set,          &sGco.InputSize,     &sGco.OutputSize },
/* 09 */ { MONITOR_YC_CROP_Set, 		  &sGco.InputSize,	   &sGco.OutputSize },
/* 10 */ { MONITOR_YBLUR_SIZE_Set,        &sGco.InputSize,     &sGco.OutputSize },
/* 11 */ { MONITOR_OPD_BLOCK_Set,         &sGco.OutputSize,    &sGco.OutputSize },
/* 12 */ { MONITOR_OUT_FORMATTER_Set,     &sGco.OutputSize,    &sGco.OutputSize },
/* 13 */ { MONITOR_OTP_SIZE_Set,          &sGco.OutputSize,    &sGco.OutputSize },

        /* CVBS SIZE SET */
/* 14 */ { MONITOR_CVBS_CROP_Set,         &sGco.OutputSize,    &sGco.CVBSSize },
/* 15 */ { MONITOR_CVBS_DSCALE_Set,       &sGco.OutputSize,    &sGco.CVBSSize },
/* 16 */ { MONITOR_CVBS_OUTPUT_Set,       &sGco.OutputSize,    &sGco.CVBSSize },

        /* MISC CONTROL (SENSOR) */
/* 17 */ { ncDrv_MONITOR_SENSOR_Type_Set,       &sGco.OutputSize,    &sGco.OutputSize },
    };

    MONITOR_FrameSize_Get();
    MONITOR_INPUT_HTOTAL_Set();
   
    switch(OutputMode)
    {
        case eMONITOR_CVBS:
            for(i=0; i<SIZE_CONTROL_COUNT; i++)   SizeControl[i].Func(SizeControl[i].CVBS_SET);
            break;
        case eMONITOR_HDSDI:
        case eMONITOR_AHD:
            for(i=0; i<SIZE_CONTROL_COUNT; i++)   SizeControl[i].Func(SizeControl[i].DIGITAL_SET);
            break;
    }
}





