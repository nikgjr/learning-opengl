
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "APACHE35.h"
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Api_GlobalHeader.h"

//============================================================================
//      Function
//============================================================================
void ncDrv_DWDR_Set(void)
{
	if(rSWReg.Category.WDR.Reg.DWDR_MODE == eMODE_OFF)
	{
		rIP_LTM_SLOPE_GAIN = rSWReg.Category.WDR.Reg.DWDR_GAIN<<4;
		rIP_LTM_EN = eMODE_OFF;	
	}
	else
	{
		if(rSWReg.Category.WDR.Reg.DWDR_MODE < eMODE_AUTO)
			rIP_LTM_EN = rSWReg.Category.WDR.Reg.DWDR_MODE;
		
		rIP_LTM_SLOPE_GAIN = rSWReg.Category.WDR.Reg.DWDR_GAIN<<4;		
	}
}

void ncDrv_DWDR_Auto(void)
{
	UCHAR DwdrAutoGain;

	if(rSWReg.Category.WDR.Reg.DWDR_MODE == eMODE_OFF) return;
	 /* [2015/03/05] SJH : [STD]-01 */
	 /* [2014/2/19] JWLee : AGC_LEVEL �� DWDR_AGC_LEVEL �̻��̸� LTM OFF */
	if(rSWReg.Category.WDR.Reg.DWDR_MODE == eMODE_AUTO)
	{
		DwdrAutoGain = ncDrv_InterpAGC(rSWReg.Category.WDR.Reg.DWDR_AGC_LEVEL, 	// Start AGC Level
										(rSWReg.Category.WDR.Reg.DWDR_AGC_LEVEL+0x20), 	// End AGC Level 
										rSWReg.Category.WDR.Reg.DWDR_GAIN<<4, // ��°� Start 
										0); 						//��°�  End 
							
		rIP_LTM_SLOPE_GAIN = DwdrAutoGain;

		//DEBUGMSG(MSGINFO, "rIP_LTM_SLOPE_GAIN = %02X \n", rIP_LTM_SLOPE_GAIN);
				
		if(DwdrAutoGain == 0)
			rIP_LTM_EN = STATE_OFF;
		else
			rIP_LTM_EN = STATE_ON;
	}
	else
	{
		rIP_LTM_SLOPE_GAIN = rSWReg.Category.WDR.Reg.DWDR_GAIN<<4;	

		//DEBUGMSG(MSGINFO, "Manual rIP_LTM_SLOPE_GAIN = %02X \n", rIP_LTM_SLOPE_GAIN);
	}	
}

