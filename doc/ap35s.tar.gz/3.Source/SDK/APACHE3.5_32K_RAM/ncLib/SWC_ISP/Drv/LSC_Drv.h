/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	File	: LSC_Drv.h		
*	Brief	: This file is LSC DRV for NEXTCHIP standard library
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2016.01.26		ktsyann	    1.0		Initial  Revision
********************************************************************************/

#ifndef __LSC_DRV_H__
#define __LSC_DRV_H__

void ncDrv_LSC_Set(void);
void ncDrv_LSC_Auto(void);

#endif /* __LSC_DRV_H__ */


/* End Of File */
