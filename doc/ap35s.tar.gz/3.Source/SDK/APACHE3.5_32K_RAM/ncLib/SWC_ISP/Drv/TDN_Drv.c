
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Drv_GlobalHeader.h"
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"

STRUCT_MW_Tdn sMwTdn;

/*********************************************
*       LOCAL FUNCTION                         
***********************************************/
UCHAR TdnExtern_Task(void);
void TDN_Status_Set(BOOL Status);


//#define __MW_TDN_DEBUG_OSD_
UCHAR ncDrv_TdnStatus_Get(void)
{
	return sMwTdn.CurrentTdnStatus;
}

void ncDrv_TdnColor_Set(void)
{   
    UCHAR Port = rSWReg.Category.GPIO.Reg.GPO_IR_PWM;
    
	if(sMwTdn.DayNightSwitchDelay == 3L)
	{
		rIP_AWB_EN = STATE_ON;
	}
	else if(sMwTdn.DayNightSwitchDelay <= 1L)
	{
		if(sMwTdn.DayNightSwitchDelay == 0L) /* [2014/4/10] sky : Boot Up�� �� ������. */
		{
			if(rIP_AWB_EN != STATE_ON)	rIP_AWB_EN = STATE_ON;
		}
		
		//SATURATION GAIN (AWB_EN On and after several VD, C_SAT_BLACK Off
		rIP_C_SAT_BLACK = STATE_OFF;

		// BURST CONTROL
		if(rIP_CVBS_BURST_OFF == STATE_ON)
		{
			rIP_CVBS_BURST_OFF = STATE_OFF;
			ncDrv_AHD_Gain_Set(); // AHD Commands
		}
		
		//CVBS OUTPUT
		rIP_CVBS_COLOR_OFF = STATE_OFF;
	}
}

void ncDrv_TdnBw_Set(void)
{
	 //CVBS OUTPUT
	rIP_CVBS_COLOR_OFF = STATE_ON;

	// BURST CONTROL(CVBS & AHD)
	rIP_CVBS_BURST_OFF = !rSWReg.Category.TDN.Reg.BW_BURST;
	if(rSWReg.Category.TDN.Reg.BW_BURST)
	{
		ncDrv_AHD_Gain_Set(); // AHD Commands
	}
	else
	{
	    switch(sGco.MonitorOutput)
	    {
            case eMONITOR_HDSDI:
            case eMONITOR_CVBS:
    			rIP_CVBS_BURST_OFF = 1;
    			rIP_CVBS_COLOR_OFF = 1;
                break;
            case eMONITOR_AHD:
				rIP_AHD_CB_SCALE  = 0x00;
				rIP_AHD_CR_SCALE  = 0x00;
				//rIP_AHD_BURST_SCALE = 0xB0;
				rIP_AHD_SYNC_EXPANDER_MODE = 0x01;
				rIP_AHD_BURST_PHASE = 0x00;

                break;
	    }
	}


	/* [2015/1/28] SJH : [STD]-01 */
	//{
		if(rIP_CVBS_BURST_OFF == 1)
		{	
			if(rSWReg.Category.TDN.Reg.DAYNIGHT_MODE == eDN_BW)
				rIP_AHD_BURST_SCALE = 0x00;
			else
                rIP_AHD_BURST_SCALE = rSWReg.Category.AHD.Reg.AHD_BURST_GAIN;
		}
		else
		{
            rIP_AHD_BURST_SCALE = rSWReg.Category.AHD.Reg.AHD_BURST_GAIN;		
        }
	//}		

	//SATURATION GAIN
	rIP_C_SAT_BLACK = STATE_ON;
	rIP_AWB_EN = STATE_OFF;

}



void ncDrv_IrSmart_Set(void)
{
	if(sMwTdn.CurrentTdnStatus == DN_STATUS_BW)
	{
	   ncLib_OpdGrid_Set(
                         rSWReg.Category.TDN.Reg.BW_IR_SMART_GRID_VIEW, 
					     rSWReg.Category.TDN.Reg.BW_IR_SMART_POS_X, 
					     rSWReg.Category.TDN.Reg.BW_IR_SMART_POS_Y, 
					     rSWReg.Category.TDN.Reg.BW_IR_SMART_SIZE_X,
					     rSWReg.Category.TDN.Reg.BW_IR_SMART_SIZE_Y); 
	}
}


void TDN_Status_Set(BOOL Status)
{
	static BOOL PrevDnStatus = DN_STATUS_BW;

	sMwTdn.DayNightCount = 0L;
	sMwTdn.DayNightCountOn = STATE_OFF;

	/* [2014/8/18] sky : 1-1 */
	sMwTdn.DayNightSwitchCount = 0;
	sMwTdn.DayNightSwitchCountOn = STATE_OFF;
	
	sMwTdn.CurrentTdnStatus = Status;
	
	if(rSWReg.Category.TDN.Reg.DC_FILTER_SWITCH_MODE == DN_FILTER_MAINTAIN_OFF)			
		sMwTdn.DayNightSwitchCountOn = STATE_ON;

	// MISCELLANEOUS
	if(Status == DN_STATUS_BW)			ncDrv_TdnBw_Set();
	else if(Status == DN_STATUS_COLOR)	ncDrv_TdnColor_Set();

	if(sMwTdn.DayNightSwitchDelay) 	sMwTdn.DayNightSwitchDelay --;

	PrevDnStatus = Status;
	
}

BOOL TdnAuto_Task(UCHAR DnAutoType)
{
	UCHAR D2NAgc = rSWReg.Category.TDN.Reg.AUTO_D2N_AGC;
	UCHAR N2DAgc = rSWReg.Category.TDN.Reg.AUTO_N2D_AGC;	
	UCHAR D2NCds = 0;
	UCHAR N2DCds = 0;
	UCHAR CDSLevel = 0;//sMwSystem.ADCValue[1];
	/* [2015/1/9] SJH :  STD-01*/
	//UCHAR AGCLevel = sMwAe.Agc.Ratio;
	UCHAR AGCLevel = ISPGET08(aIP_AGC_LEVEL_7_0);
			
	BOOL NextDnStatus = sMwTdn.CurrentTdnStatus;

	if(rSWReg.Category.TDN.Reg.DAYNIGHT_MODE == eDN_EXT)
	{
		D2NCds = rSWReg.Category.TDN.Reg.EXT_D2N_CDS;
		N2DCds = rSWReg.Category.TDN.Reg.EXT_N2D_CDS;
	}
	else
	{
		D2NCds = rSWReg.Category.TDN.Reg.AUTO_D2N_CDS;
		N2DCds = rSWReg.Category.TDN.Reg.AUTO_N2D_CDS;
	}
	
	if(rSWReg.Category.TDN.Reg.CDS_INPUT_SELECT == 0)		CDSLevel = 0xFF - CDSLevel;
			
	switch(DnAutoType)
	{
		case DN_DET_AGC_ONLY:
			if(sMwTdn.CurrentTdnStatus == DN_STATUS_COLOR && AGCLevel >= D2NAgc)
			{
				NextDnStatus = DN_STATUS_BW;
			}
			else if(sMwTdn.CurrentTdnStatus == DN_STATUS_BW && AGCLevel <= N2DAgc)
			{
				NextDnStatus = DN_STATUS_COLOR;
			}
			break;
		
		case DN_DET_CDS_ONLY:
			if(sMwTdn.CurrentTdnStatus == DN_STATUS_COLOR && CDSLevel >= D2NCds)
			{
				NextDnStatus = DN_STATUS_BW;
			}
			else if(sMwTdn.CurrentTdnStatus == DN_STATUS_BW && CDSLevel <= N2DCds)
			{
				NextDnStatus = DN_STATUS_COLOR;
			}
			break;

		case DN_DET_AGCCDS_AND:
			if(sMwTdn.CurrentTdnStatus == DN_STATUS_COLOR && (AGCLevel >= D2NAgc && CDSLevel >= D2NCds))/* [2014/8/13] sky : 1-1 */
			{
				NextDnStatus = DN_STATUS_BW;
			}
			else if(sMwTdn.CurrentTdnStatus == DN_STATUS_BW && (AGCLevel <= N2DAgc && CDSLevel <= N2DCds))/* [2014/8/13] sky : 1-1 */
			{
				NextDnStatus = DN_STATUS_COLOR;
			}
			break;

		 /* DN_DET_AGCCDS_OR = DAY->NIGHT : AGC �� �Ǵ�, NIGHT->DAY : CDS �� �Ǵ�, TDN FILTER ���� ���� */
		case DN_DET_AGCCDS_OR:
			if(sMwTdn.CurrentTdnStatus == DN_STATUS_COLOR && AGCLevel >= D2NAgc)
			{
				NextDnStatus = DN_STATUS_BW;
			}
			else if(sMwTdn.CurrentTdnStatus == DN_STATUS_BW && CDSLevel <= N2DCds)/* [2014/8/13] sky : 1-1 */
			{
				NextDnStatus = DN_STATUS_COLOR;
			}
			break;

		default:
			break;
	}

	if(sMwTdn.CurrentTdnStatus !=  (UCHAR)NextDnStatus)	sMwTdn.DayNightCountOn = STATE_ON;
	else											    sMwTdn.DayNightCountOn = STATE_OFF;

	return NextDnStatus;
}

UCHAR TdnExtern_Task(void)
{
	static UCHAR PreExtInSignal = 0;
	UCHAR NextDnStatus = 0;
	UCHAR ExtInSignal = 0;

#if 0
	ExtInSignal = (HAL_GPIO_Get(rSWReg.Category.GPIO.Reg.GPI_DN_EXT) >> 3);
	
	ExtInSignal = rSWReg.Category.GPIO.Reg.GPI_DN_EXT_ACTIVE ? (ExtInSignal) : (!ExtInSignal);
#endif
	
	if(ExtInSignal != PreExtInSignal)
	{
		NextDnStatus = ExtInSignal;
		PreExtInSignal = ExtInSignal;
	}
	else
	{
		NextDnStatus = PreExtInSignal;
	}

	if(sMwTdn.CurrentTdnStatus != (UCHAR)NextDnStatus)	sMwTdn.DayNightCountOn = STATE_ON;
	else												sMwTdn.DayNightCountOn = STATE_OFF;

	return NextDnStatus;
}

void ncDrv_TDN_STATUS_Set(void)
{
	sMwTdn.DayNightSwitchDelay = DN_SW_EXE_B2C;
	TDN_Status_Set(sMwTdn.CurrentTdnStatus);

	return;
}


void ncDrv_TDN_Auto(void)
{
	BOOL NextDnStatus = sMwTdn.CurrentTdnStatus;
	UCHAR FilterSwitchDelay = 0; 
		
	FilterSwitchDelay = rSWReg.Category.TDN.Reg.DC_FILTER_SWITCH_DELAY;
	
#if 0	
#ifdef __MW_TDN_DEBUG_OSD_
	APP_OSDPrint_Hex(1, 1, rIP_CURRENT_AGC);
	APP_OSDPrint_Hex(1, 4, sMwAe.Agc.Ratio);
	
	APP_OSDPrint_Hex(2, 1, sMwTdn.CurrentTdnStatus);
	APP_OSDPrint_Hex(2, 4, sMwTdn.DayNightCount);

	APP_OSDPrint_Hex(3, 1, FilterSwitchDelay);
	APP_OSDPrint_Hex(3, 4, sMwTdn.DayNightSwitchCount);
#endif
#endif

	switch(rSWReg.Category.TDN.Reg.DAYNIGHT_MODE)
	{
		case eDN_AUTO:
			if(sMwTdn.DayNightSwitchDelay == 0L)	// not on the way to changing day/night
				NextDnStatus = TdnAuto_Task(rSWReg.Category.TDN.Reg.AUTO_DETECT_TYPE);

			if(sMwTdn.DayNightCountOn == STATE_ON)
			{
				if(sMwTdn.CurrentTdnStatus == DN_STATUS_COLOR && sMwTdn.DayNightCount >= rSWReg.Category.TDN.Reg.AUTO_D2N_DELAY)
				{
					sMwTdn.DayNightSwitchDelay = DN_SW_EXE_C2B;
				}
				else if(sMwTdn.CurrentTdnStatus == DN_STATUS_BW && sMwTdn.DayNightCount >= rSWReg.Category.TDN.Reg.AUTO_N2D_DELAY)
				{
					sMwTdn.DayNightSwitchDelay = DN_SW_EXE_B2C;
				}
			}	
			if(sMwTdn.DayNightSwitchDelay)	TDN_Status_Set(NextDnStatus);
			break;
			
		case eDN_COLOR:
			if(sMwTdn.CurrentTdnStatus != DN_STATUS_COLOR)
			{
				NextDnStatus = DN_STATUS_COLOR;
				sMwTdn.DayNightSwitchDelay = DN_SW_EXE_B2C;
			}
			if(sMwTdn.DayNightSwitchDelay)	TDN_Status_Set(NextDnStatus);
			break;
			
		case eDN_BW:
			if(sMwTdn.CurrentTdnStatus !=  DN_STATUS_BW)		
			{
				NextDnStatus = DN_STATUS_BW;
				sMwTdn.DayNightSwitchDelay = DN_SW_EXE_C2B;
			}
			if(sMwTdn.DayNightSwitchDelay)	TDN_Status_Set(NextDnStatus);
			break;
			
		case eDN_EXT:
			if(rSWReg.Category.TDN.Reg.EXT_INPUT_MODE == 0)
			{
				if(sMwTdn.DayNightSwitchDelay == 0L)	// not on the way to changing day/night
					NextDnStatus = TdnExtern_Task();
			}
			else
			{
				if(sMwTdn.DayNightSwitchDelay == 0L)	// not on the way to changing day/night
					NextDnStatus = TdnAuto_Task(DN_DET_CDS_ONLY);
			}
			
			if(sMwTdn.DayNightCountOn == STATE_ON)
			{
	    			if(sMwTdn.CurrentTdnStatus == DN_STATUS_COLOR && sMwTdn.DayNightCount >= rSWReg.Category.TDN.Reg.EXT_D2N_DELAY)
	    			{
	    				sMwTdn.DayNightSwitchDelay = DN_SW_EXE_C2B;
	    			}
	    			else if(sMwTdn.CurrentTdnStatus == DN_STATUS_BW && sMwTdn.DayNightCount >= rSWReg.Category.TDN.Reg.EXT_N2D_DELAY)
	    			{
	    				sMwTdn.DayNightSwitchDelay = DN_SW_EXE_B2C;
	    			}
    			}
			if(sMwTdn.DayNightSwitchDelay)	TDN_Status_Set(NextDnStatus);
			break;

		default:
			break;
	};

	if(sMwTdn.DayNightSwitchCount > FilterSwitchDelay)
	{
		sMwTdn.DayNightSwitchCount = 0L;
		sMwTdn.DayNightSwitchCountOn = STATE_OFF;
	}

	return;
}


UCHAR ncDrv_TdnAuto_AgcLimit_Get(UCHAR AGCMODE)
{
	/* [2015/1/9] SJH :  STD-01*/
	UCHAR  TdnMaxAgcLevel[16] = {18,18,36,54,72,84,102,120,138,156,168,186,204,222,240,255};

	return TdnMaxAgcLevel[AGCMODE];
}
