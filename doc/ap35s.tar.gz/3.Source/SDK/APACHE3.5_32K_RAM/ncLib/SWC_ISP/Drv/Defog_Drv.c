
/********************************************************************************
*   Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*   Enviroment    : IAR Embedded Workbench IDE
*   Project       : APC28_EGT3 
********************************************************************************
*   History      : 
        CreationDate    Modify      Ver     Description
        -------------------------------------------------------
        2010.08.13      kysim       0.2     Initial  Revision
        2014.12.02      JWLee       1.0     Newly Generated     
        2015.04.01      jhchoi      1.1     NCFW Platform Revision
********************************************************************************/
#include "Drv_GlobalHeader.h"
#include "Lib_GlobalHeader.h"
#include "API_GlobalHeader.h"
#include "ISP_Drv.h"
#include "Defog_Drv.h"
#include "System_Drv.h"


//#define __MW_DEFOG_DEBUG__

// 100% = 1000
//#define MAX_Y 995 // 99.5%
//#define MIN_Y 5   // 0.5%
//#define MAX_R 995 // 99.5%
//#define MIN_R 5   // 0.5%
//#define MAX_G 995 // 99.5%
//#define MIN_G 5   // 0.5%
//#define MAX_B 995 // 99.5%
//#define MIN_B 5   // 0.5%

//============================================================================
//      Extern Function Prototype
//============================================================================


//============================================================================
//      Function Prototype
//============================================================================
void Defog_Grid(void);
//============================================================================
//      Function
//============================================================================
void ncDrv_Defog_Mirror(void)
{
    USHORT sPosX = 0, ePosX = 0;
    
    rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_POS_X = (sGco.OutputSize.Active.SizeH / DEFOGBLOCK_SIZE) - rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_POS_X - rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_SIZE_X;
    sPosX = (rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_POS_X * DEFOGBLOCK_SIZE);
    ePosX = (sPosX + (rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_SIZE_X * DEFOGBLOCK_SIZE) - 1);


	rIP_GRID_BOX1_S_X_10_8 = ((sPosX>>8) & 0xFF);
	rIP_GRID_BOX1_S_X_7_0 = (sPosX & 0xFF);
	rIP_GRID_BOX1_E_X_10_8 = ((ePosX>>8) & 0xFF);
	rIP_GRID_BOX1_E_X_7_0 = (ePosX & 0xFF);
        
    rIP_ZONE_HPOS = rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_POS_X;
}

void ncDrv_Defog_Flip(void)
{
    USHORT sPoxY = 0, ePoxY = 0;
    
    rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_POS_Y = (sGco.OutputSize.Active.SizeV / DEFOGBLOCK_SIZE) - rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_POS_Y - rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_SIZE_Y;
    sPoxY = (rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_POS_Y * DEFOGBLOCK_SIZE);
    ePoxY = (sPoxY + (rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_SIZE_Y * DEFOGBLOCK_SIZE) - 1);
	
    rIP_GRID_BOX1_S_Y_10_8 = ((sPoxY>>8) & 0xFF);
    rIP_GRID_BOX1_S_Y_7_0 = (sPoxY & 0xFF);
    rIP_GRID_BOX1_E_Y_10_8 = ((ePoxY>>8) & 0xFF);
    rIP_GRID_BOX1_E_Y_7_0 = (ePoxY & 0xFF);

    rIP_ZONE_VPOS = rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_POS_Y;
}

void Defog_Grid(void)
{
    USHORT sPosX = 0, sPoxY = 0, ePosX = 0, ePoxY = 0;

	sPosX = (rIP_ZONE_HPOS * DEFOGBLOCK_SIZE);
	
	if(sPosX==0) //isp input : 1288
    	sPosX = (rIP_ZONE_HPOS * DEFOGBLOCK_SIZE) + (H_ACTIVE_OFFSET>>1);
	
    sPoxY = (rIP_ZONE_VPOS * DEFOGBLOCK_SIZE);
    ePosX = (sPosX + (rIP_ZONE_HLEN * DEFOGBLOCK_SIZE) - 1);
    ePoxY = (sPoxY + (rIP_ZONE_VLEN * DEFOGBLOCK_SIZE) - 1);

    rIP_GRID_BOX1_EN = rSWReg.Category.DEFOG.Reg.DEFOG_GIRD_VIEW;

    rIP_GRID_BOX1_S_X_10_8  = ((sPosX>>8) & 0xFF);
    rIP_GRID_BOX1_S_X_7_0 = (sPosX & 0xFF);  
    rIP_GRID_BOX1_E_X_10_8 = ((ePosX>>8) & 0xFF);
    rIP_GRID_BOX1_E_X_7_0 = (ePosX & 0xFF);

    rIP_GRID_BOX1_S_Y_10_8 = ((sPoxY>>8) & 0xFF);
    rIP_GRID_BOX1_S_Y_7_0 = (sPoxY & 0xFF);
    rIP_GRID_BOX1_E_Y_10_8 = ((ePoxY>>8) & 0xFF);
    rIP_GRID_BOX1_E_Y_7_0 = (ePoxY & 0xFF);
}

void ncDrv_Defog_Auto(void)
{
    static UCHAR DefogEn = FALSE;
    UCHAR PresentYMax = 0xFF, PresentYMin = 0, DiffY = 0, MaxMinYDiffY = 0;
    static UCHAR PastYMax = 0xFF, PastYMin = 0x00;
    UCHAR PresentRMax = 0xFF, PresentRMin = 0, DiffR = 0, MaxMinRDiffY = 0;
    static UCHAR PastRMax = 0xFF, PastRMin = 0x00;
    UCHAR PresentGMax = 0xFF, PresentGMin = 0, DiffG = 0, MaxMinGDiffY = 0;
    static UCHAR PastGMax = 0xFF, PastGMin = 0x00;
    UCHAR PresentBMax = 0xFF, PresentBMin = 0, DiffB = 0, MaxMinBDiffY = 0;
    static UCHAR PastBMax = 0xFF, PastBMin = 0x00;
    UCHAR RangeMin = 0 , RangeMax = 0;

    if(rSWReg.Category.DEFOG.Reg.DEFOG_MODE == eMODE_ON)
    {
        /********************************************************
         DNP���� ���� ���� ���ο� ���� ��� ��ȭ�� ����.
         Streching �� ��  RGB Streching ���� ���� ��.
         Streching�� ���� �� �� ��Ʋ������ �����ϱ� ����.
         Added by shpark[20140724]
        ********************************************************/
        rIP_DEFOG_MIX_Y = 1;
		
		MaxMinYDiffY = rIP_FOG_HS_IY;
        MaxMinRDiffY = rIP_FOG_HS_IR;
        MaxMinGDiffY = rIP_FOG_HS_IG;
        MaxMinBDiffY = rIP_FOG_HS_IB;
        
        RangeMax = rSWReg.Category.DEFOG.Reg.DEFOG_START_TH + 8;
        RangeMin = rSWReg.Category.DEFOG.Reg.DEFOG_START_TH;

        if((MaxMinYDiffY < RangeMin) || (MaxMinRDiffY < RangeMin) || (MaxMinGDiffY < RangeMin) || (MaxMinBDiffY < RangeMin))
        {
            DefogEn = TRUE;
        }
        else if((MaxMinYDiffY > RangeMax) && (MaxMinRDiffY > RangeMax) && (MaxMinGDiffY > RangeMax) && (MaxMinBDiffY > RangeMax))
        {
            DefogEn = FALSE;
        }
    
        if(DefogEn == TRUE)
        {
			PresentYMax = rIP_FOG_HS_IMAX_Y;
            PresentYMin = rIP_FOG_HS_IMIN_Y;
            PresentRMax = rIP_FOG_HS_IMAX_R;
            PresentRMin = rIP_FOG_HS_IMIN_R;
            PresentGMax = rIP_FOG_HS_IMAX_G;
            PresentGMin = rIP_FOG_HS_IMIN_G;
            PresentBMax = rIP_FOG_HS_IMAX_B;
            PresentBMin = rIP_FOG_HS_IMIN_B;
            
            DiffY = _abs(PresentYMax, PastYMax);
            DiffR = _abs(PresentRMax, PastRMax);
            DiffG = _abs(PresentGMax, PastGMax);
            DiffB = _abs(PresentBMax, PastBMax);
            
            if(DiffY > rSWReg.Category.DEFOG.Reg.DEFOG_ANTI_ROLLING)
            {
                if(PresentYMax < PastYMax)  PastYMax--;
                else                        PastYMax++;
            }
            if(DiffR > rSWReg.Category.DEFOG.Reg.DEFOG_ANTI_ROLLING)
            {
                if(PresentRMax < PastRMax)  PastRMax--;
                else                        PastRMax++;
            }
            if(DiffG > rSWReg.Category.DEFOG.Reg.DEFOG_ANTI_ROLLING)
            {
                if(PresentGMax < PastGMax)  PastGMax--;
                else                        PastGMax++;
            }
            if(DiffB > rSWReg.Category.DEFOG.Reg.DEFOG_ANTI_ROLLING)
            {
                if(PresentBMax < PastBMax)  PastBMax--;
                else                        PastBMax++;
            }

            rIP_DEFOG_IMAX_Y = PastYMax;
            rIP_DEFOG_IMAX_R = PastRMax;
            rIP_DEFOG_IMAX_G = PastGMax;
            rIP_DEFOG_IMAX_B = PastBMax;
            
            DiffY = _abs(PresentYMin, PastYMin);
            DiffR = _abs(PresentRMin, PastRMin);
            DiffG = _abs(PresentGMin, PastGMin);
            DiffB = _abs(PresentBMin, PastBMin);
			
            if(DiffY > rSWReg.Category.DEFOG.Reg.DEFOG_ANTI_ROLLING)
            {
                if(PresentYMin > PastYMin)  PastYMin++;
                else                        PastYMin--;
            }
            if(DiffR > rSWReg.Category.DEFOG.Reg.DEFOG_ANTI_ROLLING)
            {
                if(PresentRMin > PastRMin)  PastRMin++;
                else                        PastRMin--;
            }
            if(DiffG > rSWReg.Category.DEFOG.Reg.DEFOG_ANTI_ROLLING)
            {
                if(PresentGMin > PastGMin)  PastGMin++;
                else                        PastGMin--;
            }
            if(DiffB > rSWReg.Category.DEFOG.Reg.DEFOG_ANTI_ROLLING)
            {
                if(PresentBMin > PastBMin)  PastBMin++;
                else                        PastBMin--;
            }
            
            rIP_DEFOG_IMIN_Y = PastYMin;
            rIP_DEFOG_IMIN_R = PastRMin;
            rIP_DEFOG_IMIN_G = PastGMin;
            rIP_DEFOG_IMIN_B = PastBMin;
            
            rIP_DEFOG_ON = eMODE_ON;
        }
        else
        {
            PastYMax = rIP_DEFOG_IMAX_Y;
            PastYMin = rIP_DEFOG_IMIN_Y;
            PastRMax = rIP_DEFOG_IMAX_R;
            PastRMin = rIP_DEFOG_IMIN_R;
            PastGMax = rIP_DEFOG_IMAX_G;
            PastGMin = rIP_DEFOG_IMIN_G;
            PastBMax = rIP_DEFOG_IMAX_B;
            PastBMin = rIP_DEFOG_IMIN_B;

            if(PastYMax < 0xFF) PastYMax++;
            if(PastYMin > 0)    PastYMin--;
            if(PastRMax < 0xFF) PastRMax++;
            if(PastRMin > 0)    PastRMin--;
            if(PastGMax < 0xFF) PastGMax++;
            if(PastGMin > 0)    PastGMin--;
            if(PastBMax < 0xFF) PastBMax++;
            if(PastBMin > 0)    PastBMin--;
            
            rIP_DEFOG_IMAX_Y = PastYMax;
            rIP_DEFOG_IMIN_Y = PastYMin;
            rIP_DEFOG_IMAX_R = PastRMax;
            rIP_DEFOG_IMIN_R = PastRMin;
            rIP_DEFOG_IMAX_G = PastGMax;
            rIP_DEFOG_IMIN_G = PastGMin;
            rIP_DEFOG_IMAX_B = PastBMax;
            rIP_DEFOG_IMIN_B = PastBMin;

            if(((PastYMin == 0)&&(PastYMax == 0xFF))&&((PastRMin == 0)&&(PastRMax == 0xFF))&&((PastGMin == 0)&&(PastGMax == 0xFF))&&((PastBMin == 0)&&(PastBMax == 0xFF)))
            {
                rIP_DEFOG_ON = eMODE_OFF;
            }
        }
    }
    else
    {
        if(rSWReg.Category.DEFOG.Reg.DEFOG_MANUAL == eMODE_OFF)
        {
            rIP_DEFOG_ON = eMODE_OFF;
            return;
        }

        /********************************************************
         DNP���� ���� ���� ���ο� ���� ��� ��ȭ�� ����.
         Streching �� ��  RGB Streching ���� ���� ���� ����
         Added by shpark[20140724]
        ********************************************************/
        rIP_DEFOG_MIX_Y = 0;
        
        rIP_ZONE_HPOS = 0x00;
        rIP_ZONE_VPOS = 0x00;
        rIP_ZONE_HLEN = sGco.FrameSize.SizeH>>3;
        rIP_ZONE_VLEN = sGco.FrameSize.SizeV>>3;
        
        rIP_ZONE_MODE = 0x00;
        rIP_ZONE_SDIR = 0x0F;

         /* [2014/4/24] SWG : Input Source, Y Control, RGB Bypass */
        if(rIP_FOG_HS_IMAX_Y > 0xE0) 
        {
            rIP_DEFOG_IMAX_Y     = rIP_FOG_HS_IMAX_Y;
        }
        else
        {
			rIP_DEFOG_IMAX_Y     = 0xE0;
        }

		rIP_DEFOG_IMIN_Y = 0x00;
        rIP_DEFOG_IMAX_R = 0xFF;
        rIP_DEFOG_IMIN_R = 0x00;
        rIP_DEFOG_IMAX_G = 0xFF;
        rIP_DEFOG_IMIN_G = 0x00;
        rIP_DEFOG_IMAX_B = 0xFF;
        rIP_DEFOG_IMIN_B = 0x00;

         /* [2014/4/24] SWG : Output Target */
        rIP_DEFOG_HS_SMAX_Y = 0xFF;
        rIP_DEFOG_HS_SMAX_Y = 0x00;
        rIP_DEFOG_HS_SMAX_R = 0xFF;
        rIP_DEFOG_HS_SMIN_R = 0x00;
        rIP_DEFOG_HS_SMAX_G = 0xFF;
        rIP_DEFOG_HS_SMIN_G = 0x00;
        rIP_DEFOG_HS_SMAX_B = 0xFF;
        rIP_DEFOG_HS_SMIN_B = 0x00;
        
        rIP_DEFOG_ON = eMODE_ON;	
    }
}
void ncDrv_Defog_ReSize(void)
{
	if(OUTPUT_SIZE == INPUT_SIZE)
    {
        rIP_ZONE_HPOS = rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_POS_X;
        rIP_ZONE_VPOS = rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_POS_Y;
        rIP_ZONE_HLEN = rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_SIZE_X;
        rIP_ZONE_VLEN = rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_SIZE_Y;
    }
    else
    {
        rIP_ZONE_HPOS = (UCHAR)((FLOAT)rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_POS_X / 1.5);
        rIP_ZONE_VPOS = (UCHAR)((FLOAT)rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_POS_Y / 1.5);
        rIP_ZONE_HLEN = (UCHAR)((FLOAT)rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_SIZE_X / 1.5);
        rIP_ZONE_VLEN = (UCHAR)((FLOAT)rSWReg.Category.DEFOG.Reg.DEFOG_ZONE_SIZE_Y / 1.5);
    }

    Defog_Grid();
}

void ncDrv_Defog_Set(void)
{
#define MAX_L       0
#define MAX_M       1
#define MAX_H       2
#define MIN_L       3
#define MIN_M       4
#define MIN_H       5

    UINT32 Max = 0, Min = 0;
    UINT32 TotalPixel = 0;
    UCHAR i = 0;

    //OSD ON/OFF�� �����Ÿ� ����. OFF�� �ϵ� ON�� ���� �ʴ´�.
    if(rSWReg.Category.DEFOG.Reg.DEFOG_MODE == eMODE_OFF) rIP_DEFOG_ON = eMODE_OFF;													

    rIP_ZONE_MODE    = rSWReg.Category.DEFOG.Reg.DEFOG_GRADATION;
    rIP_ZONE_SDIR    = rSWReg.Category.DEFOG.Reg.DEFOG_DIRECTION;  

    rIP_DEFOG_HS_SMAX_Y  = rSWReg.Category.DEFOG.Reg.DEFOG_HIGH_INTENSITY_LIMIT;
    rIP_DEFOG_HS_SMIN_Y  = rSWReg.Category.DEFOG.Reg.DEFOG_LOW_INTENSITY_LIMIT;
    rIP_DEFOG_HS_SMAX_R  = rSWReg.Category.DEFOG.Reg.DEFOG_HIGH_INTENSITY_LIMIT;
    rIP_DEFOG_HS_SMIN_R  = rSWReg.Category.DEFOG.Reg.DEFOG_LOW_INTENSITY_LIMIT;
    rIP_DEFOG_HS_SMAX_G  = rSWReg.Category.DEFOG.Reg.DEFOG_HIGH_INTENSITY_LIMIT;
    rIP_DEFOG_HS_SMIN_G  = rSWReg.Category.DEFOG.Reg.DEFOG_LOW_INTENSITY_LIMIT;
    rIP_DEFOG_HS_SMAX_B  = rSWReg.Category.DEFOG.Reg.DEFOG_HIGH_INTENSITY_LIMIT;
    rIP_DEFOG_HS_SMIN_B  = rSWReg.Category.DEFOG.Reg.DEFOG_LOW_INTENSITY_LIMIT;

    rIP_DEFOG_MIX_Y  = 0;/* [2014/8/25] sky : 1-1 */

    ncDrv_Defog_ReSize();
        
    // * ((UINT32)rBank11->Byte.Reg_0xD18F.B8.ZONE_VLEN * DEFOGBLOCK_SIZE));
    
    TotalPixel = ((UINT32)rIP_ZONE_HLEN * DEFOGBLOCK_SIZE);
    TotalPixel = TotalPixel * ((UINT32)rIP_ZONE_VLEN * DEFOGBLOCK_SIZE);
    
    Max = (TotalPixel * rSWReg.Category.DEFOG.Reg.DEFOG_HIGH_INTENSITY) / 100;
    Min = (TotalPixel * rSWReg.Category.DEFOG.Reg.DEFOG_LOW_INTENSITY) / 100;

    for(i = 0L; i < 4L; i++)         /* [2014/2/19] JWLee : HS_Y, R, G, B �� ��� ���� */
    {
        ISPSET08((aIP_DEFOG_HS_MAX_Y_7_0 + MAX_L + (i * 6L)), (Max>>0L));
        ISPSET08((aIP_DEFOG_HS_MAX_Y_7_0 + MAX_M + (i * 6L)), (Max>>8L));
        ISPSET08((aIP_DEFOG_HS_MAX_Y_7_0 + MAX_H + (i * 6L)), (Max>>16L));
        ISPSET08((aIP_DEFOG_HS_MAX_Y_7_0 + MIN_L + (i * 6L)), (Min>>0L));
        ISPSET08((aIP_DEFOG_HS_MAX_Y_7_0 + MIN_M + (i * 6L)), (Min>>8L));
        ISPSET08((aIP_DEFOG_HS_MAX_Y_7_0 + MIN_H + (i * 6L)), (Min>>16L));
    }   

#undef  MAX_L   
#undef  MAX_M   
#undef  MAX_H   
#undef  MIN_L
#undef  MIN_M
#undef  MIN_H   
}

