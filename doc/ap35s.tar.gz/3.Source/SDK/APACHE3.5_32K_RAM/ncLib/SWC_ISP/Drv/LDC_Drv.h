
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __MW_LDC__
#define __MW_LDC__

#define DDR_FIX_MODE  1

typedef enum{
	LUT_TYPE_720P_8 =0  ,
	LUT_TYPE_720P_16    ,
	LUT_TYPE_1080P_32	,
	PIP_TYPE_640_360_8	,
	PIP_TYPE_480_270_8	,
	PIP_TYPE_432_240_8	,
	PIP_TYPE_426_240_8	,
	PIP_TYPE_320_180_8	,
	PIP_TYPE_216_120_8	,
	PIP_TYPE_160_90_8	,
	WRAP_TYPE_720P_8,
	LUT_TYPE_MAX        ,
}LUT_TYPE_INDEX;

typedef enum
{
	eLDC_INIT = 0,
	eLDC_SET	,
	eLDC_TASK,
	eLDC_DEINIT,
	eLDC_SIZE_UPDATE,
	eLDC_MAX
}etLDC_CMD_TYPE;


typedef enum
{
	eLDC_LUT_BASEADDR= 0,
	eLDC_LUT_LOAD_FLASH,

	eLDC_MAIN_EN,
	eLDC_PIP_EN,

	eLDC_MAIN_NUM0,
	eLDC_MAIN_NUM1,
	eLDC_PIP_NUM0,
	eLDC_PIP_NUM1,

	eLDC_MORPHING_MAIN_EN,
	eLDC_MORPHING_PIP_EN,
	eLDC_MAIN_MORPHING_RATIO,
	eLDC_PIP_MORPHING_RATIO,

	eLDC_PIP_POS_X,
	eLDC_PIP_POS_Y,
	
	eLDC_WRITE_MAX,
}etLDC_WRITE_TYPE;

typedef enum
{
	eLDC_LUT_WRAP_LEVEL=0,
	eLDC_MAINSIZE_H,
	eLDC_MAINSIZE_V,
	eLDC_PIPSIZE_H,
	eLDC_PIPSIZE_V,
	
	eLDC_READ_MAX,
}etLDC_READ_TYPE;

#define LUT_TYPE_LIST  		0x0F
#define LUT_TYPE_MAIN_MIN   LUT_TYPE_720P_8
#define LUT_TYPE_MAIN_MAX   LUT_TYPE_1080P_32
#define LUT_TYPE_PIP_MIN    PIP_TYPE_640_360_8
#define LUT_TYPE_PIP_MAX    PIP_TYPE_160_90_8
#define LUT_TYPE_WRAP   	WRAP_TYPE_720P_8

#define LUT_LIST_SIZE_720P_8	58
#define LUT_LIST_SIZE_720P_16   16
#define LUT_LIST_SIZE_1080P_32  9
#define PIP_LIST_SIZE_640_360_8 16
#define PIP_LIST_SIZE_480_270_8 2
#define PIP_LIST_SIZE_432_240_8 7
#define PIP_LIST_SIZE_426_240_8 7
#define PIP_LIST_SIZE_320_180_8 5
#define PIP_LIST_SIZE_216_120_8 2
#define PIP_LIST_SIZE_160_90_8  2
#define WRAP_LIST_SIZE_160_90_8 58


void ncDrv_Lut_Init(void);
void ncDrv_Ldc_SetSpiAddr(UCHAR Mode);
UCHAR ncDrv_Ldc_GetLutWrapLevel(void);

/*  About LDC Func*/
void ncDrv_Ldc_Off(void);
void ncDrv_Ldc_SetMode(void);
void ncDrv_LutPip_SetEtc(void);

/*  About LUT/PIP Func*/
void ncDrv_Lut_Pip_SetSize(void);
void HVDS_Set(UINT32 hmode);
	
/*  About LUT Func*/
//void ncDrv_Lut_SetSize(void);

/*  About PIP Func*/
//void ncDrv_Pip_SetSize(void);

void ncDrv_Ldc_Set_LutBaseAddr(ULONG Addr);

UCHAR ncDrv_Ldc_Get_WrapLevel(void);

void ncDrv_Ldc_SetMainEnable(BOOL En);
void ncDrv_Ldc_SetPipEnable(BOOL En);
void ncDrv_Ldc_SetMorphingMainEnable(BOOL En);
void ncDrv_Ldc_SetMorphingPipEnable(BOOL En);
void ncDrv_Ldc_SetMainNum0(UCHAR pMainNum);
void ncDrv_Ldc_SetMainNum1(UCHAR pMainNum);
void ncDrv_Ldc_SetPipNum0(UCHAR pPipNum);
void ncDrv_Ldc_SetPipNum1(UCHAR pPipNum);
void ncDrv_Ldc_SetMorphingMainRatio(UCHAR Ratio);
void ncDrv_Ldc_SetMorphingPipRatio(UCHAR Ratio);
void ncDrv_Ldc_SetPipPosX(USHORT posX);
void ncDrv_Ldc_SetPipPosY(USHORT posY);


USHORT ncDrv_Ldc_GetP_MainSizeH(void);
USHORT ncDrv_Ldc_GetP_MainSizeV(void);
USHORT ncDrv_Ldc_GetP_PipSizeH(void);
USHORT ncDrv_Ldc_GetP_PipSizeV(void);

void ncDrv_Ldc_SetDdrFix_LutLoad(UCHAR Taget, UCHAR Index, UCHAR Mode);

extern INT32 ncLib_Ldc_Control(etLDC_CMD_TYPE Cmd);
extern INT32 ncLib_Ldc_Write(etLDC_WRITE_TYPE Cmd,INT32 value);
extern INT32 ncLib_Ldc_Read(etLDC_READ_TYPE Cmd);
#endif


