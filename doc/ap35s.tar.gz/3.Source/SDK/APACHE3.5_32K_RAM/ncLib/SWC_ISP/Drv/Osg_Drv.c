/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2015.08.31	Park Min		0.1		Initial  Revision
********************************************************************************/
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Api_GlobalHeader.h"

#include "Apache35.h"
#include "Debug_Lib.h"


#define OSG_TYPE_LIST   0x0F
#define OSG_ADDR(A)   (UCHAR*)(APACHE_ISP_BASE|A)

typedef union
{
	UINT16  D8;
	struct
	{
		UCHAR L0 	: 1;
		UCHAR L1 	: 1;
		UCHAR L2 	: 1;
		UCHAR L3 	: 1;
		UCHAR L4 	: 1;
		UCHAR L5 	: 1;
		UCHAR L5A 	: 1;
		UCHAR L6 	: 1;
		UCHAR L6A 	: 1;
		UCHAR RESERVED 	: 7;
	}B8;
} OSG_UPDATE;
OSG_UPDATE OsgUpdate;

typedef struct STRUCT_OSG
{
	UCHAR  Type ;
	USHORT addr ;
}STRUCT_OSG __attribute__ ((aligned (2)));

typedef struct OSG_REG_ADDR
{
volatile	UCHAR* IndexSw ;
volatile	UCHAR* Enable ;
volatile	UCHAR* IndexIp ;
volatile	UCHAR* DisplayIp ;

volatile	UCHAR* BaseAddr ;
volatile	UCHAR* FSize ;
volatile	UCHAR* ReLoad ;
volatile	UCHAR* oEnd ;

}OSG_REG_ADDR __attribute__ ((aligned (4)));

STRUCT_OSG sOsg[OSG_LAYER_MAX];

const OSG_REG_ADDR sOsgReg[OSG_LAYER_MAX]=
{
#if 0
{ADDR_OSG_LAYER_0_INDEX_L_7_0, aIP_OSG_LAYER_0_ENABLE,		aIP_OSG_LAYER_0_INDEX_7_0, aIP_OSG_LAYER_0_ON, 		aIP_OSG_LAYER_0_BASEADDR_7_0		aIP_OSG_LAYER_0_FSIZE, 		aIP_OSG_LAYER_0_RELOAD},
{ADDR_OSG_LAYER_1_INDEX_L_7_0, aIP_OSG_LAYER_1_ENABLE,		aIP_OSG_LAYER_1_INDEX_7_0, aIP_OSG_LAYER_1_ON, 		aIP_OSG_LAYER_1_BASEADDR_7_0		aIP_OSG_LAYER_1_FSIZE, 		aIP_OSG_LAYER_1_RELOAD},
{ADDR_OSG_LAYER_2_INDEX_L_7_0, aIP_OSG_LAYER_2_ENABLE,		aIP_OSG_LAYER_2_INDEX_7_0, aIP_OSG_LAYER_2_ON, 		aIP_OSG_LAYER_2_BASEADDR_7_0		aIP_OSG_LAYER_2_FSIZE,		aIP_OSG_LAYER_2_RELOAD},
{ADDR_OSG_LAYER_3_INDEX_L_7_0, aIP_OSG_LAYER_3_ENABLE,		aIP_OSG_LAYER_3_INDEX_7_0, aIP_OSG_LAYER_3_ON, 		aIP_OSG_LAYER_3_BASEADDR_7_0		aIP_OSG_LAYER_3_FSIZE, 		aIP_OSG_LAYER_3_RELOAD},
{ADDR_OSG_LAYER_4_INDEX_L_7_0, aIP_OSG_LAYER_4_ENABLE,		aIP_OSG_LAYER_4_INDEX_7_0, aIP_OSG_LAYER_4_ON, 		aIP_OSG_LAYER_4_BASEADDR_7_0		aIP_OSG_LAYER_4_FSIZE, 		aIP_OSG_LAYER_4_RELOAD},
{ADDR_OSG_LAYER_5_INDEX_L_7_0, aIP_OSG_LAYER_5_ENABLE,		aIP_OSG_LAYER_5_INDEX_7_0, aIP_OSG_LAYER_5_ON, 		aIP_OSG_LAYER_5_BASEADDR_7_0		aIP_OSG_LAYER_5_FSIZE, 		aIP_OSG_LAYER_5_RELOAD},
{ADDR_OSG_LAYER_5_INDEX_L_7_0, aIP_OSG_LAYER_5_GRA_ENABLE,	aIP_OSG_LAYER_5_INDEX_7_0, aIP_OSG_LAYER_5_GRA_ON,	aIP_OSG_LAYER_5_GRA_BASEADDR_7_0	aIP_OSG_LAYER_5_FSIZE_GRA,  aIP_OSG_LAYER_5_RELOAD},
{ADDR_OSG_LAYER_6_INDEX_L_7_0, aIP_OSG_LAYER_6_ENABLE,		aIP_OSG_LAYER_6_INDEX_7_0, aIP_OSG_LAYER_6_ON,		aIP_OSG_LAYER_6_BASEADDR_7_0		aIP_OSG_LAYER_6_FSIZE, 		aIP_OSG_LAYER_6_RELOAD},
{ADDR_OSG_LAYER_6_INDEX_L_7_0, aIP_OSG_LAYER_6_GRA_ENABLE,	aIP_OSG_LAYER_6_INDEX_7_0, aIP_OSG_LAYER_6_GRA_ON,	aIP_OSG_LAYER_6_GRA_BASEADDR_7_0	aIP_OSG_LAYER_6_FSIZE_GRA,  aIP_OSG_LAYER_6_RELOAD},
#endif
//IndexSw						//ENABLE		//INDEX_7_0		//LAYER_0_ON	 //BASEADDR_7_0		//FSIZE			//RELOAD		//O_END0
{&rSWReg.Category.OSG.Byte[1L],  OSG_ADDR(0x2416),OSG_ADDR(0x2418),OSG_ADDR(0x2416),OSG_ADDR(0x241E),OSG_ADDR(0x2417),OSG_ADDR(0x2470),OSG_ADDR(0x25E2)},
{&rSWReg.Category.OSG.Byte[3L],  OSG_ADDR(0x2472),OSG_ADDR(0x2474),OSG_ADDR(0x2472),OSG_ADDR(0x247A),OSG_ADDR(0x2473),OSG_ADDR(0x24CC),OSG_ADDR(0x25E5)},
{&rSWReg.Category.OSG.Byte[5L],  OSG_ADDR(0x24CE),OSG_ADDR(0x24D0),OSG_ADDR(0x24CE),OSG_ADDR(0x24D6),OSG_ADDR(0x24CF),OSG_ADDR(0x2528),OSG_ADDR(0x25E8)},
{&rSWReg.Category.OSG.Byte[7L],  OSG_ADDR(0x252A),OSG_ADDR(0x252C),OSG_ADDR(0x252A),OSG_ADDR(0x2532),OSG_ADDR(0x252B),OSG_ADDR(0x2584),OSG_ADDR(0x25EB)},
{&rSWReg.Category.OSG.Byte[9L],  OSG_ADDR(0x2586),OSG_ADDR(0x2588),OSG_ADDR(0x2586),OSG_ADDR(0x258E),OSG_ADDR(0x2587),OSG_ADDR(0x25E0),OSG_ADDR(0x25EE)},
{&rSWReg.Category.OSG.Byte[11L], OSG_ADDR(0x2616),OSG_ADDR(0x2619),OSG_ADDR(0x2616),OSG_ADDR(0x261F),OSG_ADDR(0x2618),OSG_ADDR(0x2674),OSG_ADDR(0x26D7)},
{&rSWReg.Category.OSG.Byte[11L], OSG_ADDR(0x2617),OSG_ADDR(0x2619),OSG_ADDR(0x2617),OSG_ADDR(0x2622),OSG_ADDR(0x2618),OSG_ADDR(0x2674),OSG_ADDR(0x26D7)},
{&rSWReg.Category.OSG.Byte[13L], OSG_ADDR(0x2676),OSG_ADDR(0x2679),OSG_ADDR(0x2676),OSG_ADDR(0x267F),OSG_ADDR(0x2678),OSG_ADDR(0x26D4),OSG_ADDR(0x26DA)},
{&rSWReg.Category.OSG.Byte[13L], OSG_ADDR(0x2677),OSG_ADDR(0x2679),OSG_ADDR(0x2677),OSG_ADDR(0x2682),OSG_ADDR(0x2678),OSG_ADDR(0x26D4),OSG_ADDR(0x26DA)},
};

#define DisplaySw   ADDR_OSG_ON

void ncDrv_Osg_Initialize_Set(void)
{
	#define GET_STR_LONGVAL(A)		(*(ULONG*)A)
	#define FLASH_INFO_HEADER_OFFSET	0x10
	UINT32 Layer = 0;  
	OSG_LUT_HEADER HeaderTmp ;
	ULONG HeaderAddr = FLASHMEMORY_OSG_LDC_HEADER_AREA_ADDRESS;
	const UCHAR STR_IRLE[4]	= "IRLE";
	const UCHAR STR_IRLA[4] = "IRLA";

	OsgUpdate.D8=0;
	
	for(Layer=0;Layer<OSG_LAYER_MAX;Layer++)
	{
		HeaderAddr+=FLASH_INFO_HEADER_OFFSET;
		memset( (void*)&HeaderTmp.B8[0],  0x00,	 sizeof(OSG_LUT_HEADER) );	

		if(ncLib_SF_Control(GCMD_SF_READ_DATA, HeaderAddr, (UINT8*)&HeaderTmp.B8[0], 0x10, CMD_END) != 0 )
		{
			continue;
		}

#if 0//OSG_DBG_PRINFF
		DEBUGMSG(MSGINFO,"OSG_HEADER %x : ",HeaderAddr);  
		for(j=0;j<0x10;j++)
		{
			DEBUGMSG(MSGINFO," %02X ",HeaderTmp.B8[j]);  
		}
		DEBUGMSG(MSGINFO,"\n");  
#endif
		if(HeaderTmp.Common.NAME== GET_STR_LONGVAL(STR_IRLE)||
			HeaderTmp.Common.NAME== GET_STR_LONGVAL(STR_IRLA))
		{
			if(Layer==OSG_LAYER5A)
				ISPSET08(sOsgReg[Layer].Enable , BitSet(REGRW8(sOsgReg[Layer].Enable,0),1) );
			else 
				ISPSET08(sOsgReg[Layer].Enable , BitSet(REGRW8(sOsgReg[Layer].Enable,0),7));
			
			sOsg[Layer].addr = MAKEWORD(HeaderTmp.B8[8], HeaderTmp.B8[9]);
			sOsg[Layer].Type = HeaderTmp.Common.Type&0xF;
			
			ncDrv_Osg_ListSet(Layer);
#if 0//OSG_DBG_PRINFF
			DEBUGMSG(MSGINFO, "Init OSG_L %X : ",Layer);  
			DEBUGMSG(MSGINFO," %X ",((USHORT)sOsg[Layer].addr)*0x400);  
			DEBUGMSG(MSGINFO," %X \n",sOsg[Layer].Type);  
#endif
		}
		else
		{
			if(Layer==OSG_LAYER5A)
				ISPSET08(sOsgReg[Layer].Enable , BitClear(REGRW8(sOsgReg[Layer].Enable,0),1));
			else 
				ISPSET08(sOsgReg[Layer].Enable , BitClear(REGRW8(sOsgReg[Layer].Enable,0),7));
		}
	}

	rIP_OSG_04_BLACK_Y =0x10;
	rIP_OSG_04_BLACK_CB=0x80;
	rIP_OSG_04_BLACK_CR=0x80;

	rIP_OSG_56_BLACK_Y =0x10;
	rIP_OSG_56_BLACK_CB=0x80;
	rIP_OSG_56_BLACK_CR=0x80;

	
#if 0
	rIP_OSG_LAYER_3_VPOS_10_8 = 1;
	rIP_OSG_LAYER_4_VPOS_10_8 = 1;

	rIP_OSG_LAYER_1_VPOS_7_0 = 0xA0;
	rIP_OSG_LAYER_2_VPOS_7_0 = 0xA0;
	rIP_OSG_LAYER_1_HPOS_7_0 = 0xB0;
#endif
	
	ncDrv_Osg_DisplayAll(ON);
}



void ncDrv_WaitBusyBit(UINT8 Layer )//rIP_O_END0  aIP_O_END0
{
	ULONG TimeOut = 0x6FFFF;
	while( !(REGRW8(sOsgReg[Layer].oEnd,0) & (0x01<<5)))
	{
		TimeOut--;
		if(!TimeOut)
		{
			DEBUGMSG_SDK(MSGERR, "TimeOut %x \n",Layer);
			return ;
		}
	}
}


void ncDrv_GetOsgTypeAddr(UCHAR Layer,USHORT Index, UCHAR* Type ,USHORT* addr)
{
	UINT8 data[2]  ;
	if(ncLib_SF_Control(GCMD_SF_READ_DATA, FLASHMEMORY_OSG_LDC_HEADER_AREA_ADDRESS+(0x300+(0x400*Layer))+(0x2*(ULONG)Index), (UINT8*)&data[0], 0x2,  CMD_END) == 0 )
	{
		*Type = (data[0]>>4)&0x0F;
		*addr = MAKEWORD(data[0]&0x0F,data[1]);
	}
}




void ncDrv_Osg_ListSet(UCHAR Layer)
{
	UCHAR FSizeNew;
	UCHAR SizeTmp;
	USHORT AddrTmp;
	
	ncDrv_GetOsgTypeAddr(Layer,ISPGET16(sOsgReg[Layer].IndexSw),&SizeTmp,&AddrTmp);
	sOsg[Layer].Type = SizeTmp;
	sOsg[Layer].addr = AddrTmp;
	
	if(Layer==OSG_LAYER5A||Layer==OSG_LAYER6A)
		FSizeNew = (REGRW8(sOsgReg[Layer].FSize,0)&0x70) | (sOsg[Layer].Type&0x0F);		
	else if(Layer==OSG_LAYER5||Layer==OSG_LAYER6)
		FSizeNew = (sOsg[Layer].Type<<4&0x70) | (REGRW8(sOsgReg[Layer].FSize,0)&0x0F);		
	else
		FSizeNew = sOsg[Layer].Type;

	ISPSET16(sOsgReg[Layer].IndexIp,0);
	ISPSET08(sOsgReg[Layer].FSize, FSizeNew);
	ISPSET08(sOsgReg[Layer].BaseAddr,   GET_LSB((ULONG)sOsg[Layer].addr*0x400));
	ISPSET08(sOsgReg[Layer].BaseAddr+1, GET_MSB((ULONG)sOsg[Layer].addr*0x400));
	ISPSET08(sOsgReg[Layer].BaseAddr+2, GET_HSB((ULONG)sOsg[Layer].addr*0x400));

	BitSet(OsgUpdate.D8,Layer);
}


void ncDrv_Osg_LayerDisplaySet(UCHAR Layer,UCHAR OnOff)
{
	#if 0//OSG_DBG_PRINFF
	DEBUGMSG_SDK(MSGERR, "ncDrv_Osg_DisplaySet %X ",Layer);
	DEBUGMSG_SDK(MSGERR, "  %X\n",OnOff);
	#endif

	if(OnOff)
		ISPSET08(DisplaySw , BitSet  (ISPGET08(DisplaySw), (6-Layer)));
	else
		ISPSET08(DisplaySw , BitClear(ISPGET08(DisplaySw), (6-Layer)));

	if(Layer==OSG_LAYER5||Layer==OSG_LAYER6)
	{
		if(OnOff)
			ISPSET08(DisplaySw , BitSet  (ISPGET08(DisplaySw), (6-Layer+1)));
		else
			ISPSET08(DisplaySw , BitClear(ISPGET08(DisplaySw), (6-Layer+1)));
	}
	
	ncDrv_Osg_Refresh();
}


void ncDrv_Osg_LayerIndexSet(UCHAR Layer,USHORT Idx)
{
#if 0//OSG_DBG_PRINFF
	DEBUGMSG_SDK(MSGERR, "ncDrv_Osg_LayerIndexSet %X ",Layer);
	DEBUGMSG_SDK(MSGERR, "  %X\n",Idx);
#endif	
	ISPSET16(sOsgReg[Layer].IndexSw,Idx); 

	ncDrv_Osg_ListSet(Layer);
	if(Layer==OSG_LAYER5||Layer==OSG_LAYER6)
		ncDrv_Osg_ListSet(Layer+1);

	ncDrv_Osg_Refresh();
}


void ncDrv_Osg_DisplayAll(UCHAR OnOff)
{
	rSWReg.Category.OSG.Reg.OSG_ON= OnOff;
	ncDrv_Osg_Refresh();
}



void ncDrv_Osg_Refresh(void)
{	
	UINT32 Layer = 0;  

	if(!sMwSystem.Control.Run.AFT)
		return;
	
	if(!rSWReg.Category.OSG.Reg.OSG_ON)
	{
		for(Layer=0;Layer<OSG_LAYER_MAX;Layer++)
		{
			if(Layer==OSG_LAYER5A||Layer==OSG_LAYER6A)
				ISPSET08(sOsgReg[Layer].DisplayIp , BitClear(REGRW8(sOsgReg[Layer].DisplayIp,0), 0));
			else 
				ISPSET08(sOsgReg[Layer].DisplayIp , BitClear(REGRW8(sOsgReg[Layer].DisplayIp,0), 6));
		}
		return;
	}

	for(Layer=0;Layer<OSG_LAYER5;Layer++)
	{
		ISPSET08(sOsgReg[Layer].DisplayIp , (REGRW8(sOsgReg[Layer].DisplayIp,0)&0xBF)| BitCheck(REGRW8(DisplaySw,0),(6-Layer))<<6    );
	}
	
	ISPSET08(sOsgReg[OSG_LAYER5].DisplayIp ,  (REGRW8(sOsgReg[OSG_LAYER5].DisplayIp,0)&0xBF) | BitCheck(REGRW8(DisplaySw,0),(6-OSG_LAYER5))<<6);
	ISPSET08(sOsgReg[OSG_LAYER5A].DisplayIp , (REGRW8(sOsgReg[OSG_LAYER5A].DisplayIp,0)&0xFE)| BitCheck(REGRW8(DisplaySw,0),(6-OSG_LAYER5))	  );
	ISPSET08(sOsgReg[OSG_LAYER6].DisplayIp ,  (REGRW8(sOsgReg[OSG_LAYER6].DisplayIp,0)&0xFE) | BitCheck(REGRW8(DisplaySw,0),(6-OSG_LAYER6))<<6);
	ISPSET08(sOsgReg[OSG_LAYER6A].DisplayIp , (REGRW8(sOsgReg[OSG_LAYER5A].DisplayIp,0)&0xFE)| BitCheck(REGRW8(DisplaySw,0),(6-OSG_LAYER6))<<6);

	if(!OsgUpdate.D8 )
		return;

	if( ncLib_SF_Control(SCMD_SF_OSG_READ_EN, CMD_END) != 0 )
	{
		DEBUGMSG_SDK(MSGERR, "Faled OSG QSPI OPEN!\n");
		return;
	}
	rIP_O_OSG_SPI_SEL = 2;
	
	//DEBUGMSG_SDK(MSGERR, "OSG Refresh %X\n",OsgUpdate.D8);
	
#if 1
	rIP_WDONE_FORCE_04 =1;
	rIP_WDONE_FORCE_04 =0;
	rIP_I_OSG_WDONE =1;
	rIP_I_OSG_WDONE =0;
	rIP_WDONE_FORCE_56 =1;
	rIP_WDONE_FORCE_56 =0;
#endif

	for(Layer=0;Layer<OSG_LAYER_MAX;Layer++)
	{
		if( Layer==OSG_LAYER5A && BitCheck(REGRW8(sOsgReg[Layer].Enable,0),1) && BitCheck(OsgUpdate.D8,Layer))
		{
			rIP_OSG_ALPHA_LAYER_REQ 	  = 0x01; 
			rIP_OSG_ALPHA_LAYER_REQ 	  = 0x00; 
			ISPSET08(sOsgReg[Layer].ReLoad, BitSet  ( REGRW8(sOsgReg[Layer].ReLoad,0),0));
			ISPSET08(sOsgReg[Layer].ReLoad, BitClear( REGRW8(sOsgReg[Layer].ReLoad,0),0));
			ncDrv_WaitBusyBit(Layer);
		}
		else if( Layer==OSG_LAYER6A && BitCheck(REGRW8(sOsgReg[Layer].Enable,0),7) && BitCheck(OsgUpdate.D8,Layer))
		{
			rIP_OSG_ALPHA_LAYER_REQ 	  = 0x01; 
			rIP_OSG_ALPHA_LAYER_REQ 	  = 0x00; 
			ISPSET08(sOsgReg[Layer].ReLoad, BitSet  ( REGRW8(sOsgReg[Layer].ReLoad,0),0));
			ISPSET08(sOsgReg[Layer].ReLoad, BitClear( REGRW8(sOsgReg[Layer].ReLoad,0),0));
			ncDrv_WaitBusyBit(Layer);
		}
		else if( BitCheck(REGRW8(sOsgReg[Layer].Enable,0),7) && BitCheck(OsgUpdate.D8,Layer))
		{
			ISPSET08(sOsgReg[Layer].ReLoad, BitSet  ( REGRW8(sOsgReg[Layer].ReLoad,0),0));
			ISPSET08(sOsgReg[Layer].ReLoad, BitClear( REGRW8(sOsgReg[Layer].ReLoad,0),0));
			ncDrv_WaitBusyBit(Layer);
		}		
		
	}	
	ncLib_SF_Control(SCMD_SF_OSG_READ_DS, CMD_END);
	OsgUpdate.D8=0;
}


void ncDrv_Osg_QSpiOpen(void)
{
	if( ncLib_SF_Control(SCMD_SF_OSG_READ_EN, CMD_END) != 0 )
	{
		DEBUGMSG_SDK(MSGERR, "Faled OSG QSPI OPEN!\n");
		return;
	}
	rIP_O_OSG_SPI_SEL = 2;
}


