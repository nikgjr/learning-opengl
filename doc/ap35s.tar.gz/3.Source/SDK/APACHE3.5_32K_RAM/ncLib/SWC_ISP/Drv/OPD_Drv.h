
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#ifndef __MW_OPD__
#define __MW_OPD__

#define aIP_OPD_BLOCK_R         0x30F00A00
#define aIP_OPD_BLOCK_G         0x30F00A40
#define aIP_OPD_BLOCK_B         0x30F00A80
#define aIP_OPD_BLOCK_Y         0x30F00AC0
#define aIP_OPD_BLOCK_RATIO     0x30F00C00
#define aIP_OPD_BLOCKs_R        0x30F00B00
#define aIP_OPD_BLOCKs_G        0x30F00B40
#define aIP_OPD_BLOCKs_B        0x30F00B80
#define aIP_OPD_BLOCKs_Y        0x30F00BC0
#define aIP_OPD_BLOCKs_RATIO    0x30F00C40

#define OPD_GRID_CNT_X  8
#define OPD_GRID_CNT_Y  8
#define OPD_GRID_CNT    ((OPD_GRID_CNT_X) * (OPD_GRID_CNT_Y))
#define OPD_GRID_VALIDTION_SET(n,v)     BitSetVal(sMwOpd.Data.VALID_GRID[(n)/OPD_GRID_CNT_Y], (n)%OPD_GRID_CNT_X, (v))
#define OPD_GRID_VALIDTION_CHECK(n)     BitCheck(sMwOpd.Data.VALID_GRID[(n)/OPD_GRID_CNT_Y], (n)%OPD_GRID_CNT_X)
#define OPD_GRID_VALIDTION_SETs(n,v)     BitSetVal(sMwOpd.DataS.VALID_GRID[(n)/OPD_GRID_CNT_Y], (n)%OPD_GRID_CNT_X, (v))
#define OPD_GRID_VALIDTION_CHECKs(n)     BitCheck(sMwOpd.DataS.VALID_GRID[(n)/OPD_GRID_CNT_Y], (n)%OPD_GRID_CNT_X)


#define OPD_RECT_INCLUDE_EN(state)                \
do {                                              \
    if(state){                                    \
    	ISPSET08(aIP_OPD_RECT_INC_XY_EN0,  0xFF); \
    	ISPSET08(aIP_OPD_RECT_INC_XY_EN8,  0xFF); \
    	ISPSET08(aIP_OPD_RECT_INC_XY_EN16, 0xFF); \
    }else{                                        \
    	ISPSET08(aIP_OPD_RECT_INC_XY_EN0, 0x00);  \
    	ISPSET08(aIP_OPD_RECT_INC_XY_EN8, 0x00);  \
    	ISPSET08(aIP_OPD_RECT_INC_XY_EN16, 0x00); \
    }                                             \
} while(0);

#define OPD_RECT_EXCLUDE_EN(state)                       \
do {                                                     \
    if(state)   ISPSET08(aIP_OPD_RECT_EXC_XY_EN0, 0xFF); \
    else        ISPSET08(aIP_OPD_RECT_EXC_XY_EN0, 0x00); \
} while(0);


typedef enum{
    eHISTOGRAM_IDX_00 = 0,
    eHISTOGRAM_IDX_01,
    eHISTOGRAM_IDX_02,
    eHISTOGRAM_IDX_03,
    eHISTOGRAM_IDX_04,
    eHISTOGRAM_IDX_05,
    eHISTOGRAM_IDX_06,
    eHISTOGRAM_IDX_07,
    eHISTOGRAM_IDX_08,
    eHISTOGRAM_IDX_09,
    eHISTOGRAM_IDX_10,
    eHISTOGRAM_IDX_11,
    eHISTOGRAM_IDX_12,
    eHISTOGRAM_IDX_13,
    eHISTOGRAM_IDX_14,
    eHISTOGRAM_IDX_15,
    eHISTOGRAM_IDX_MAX,
}eHISTOGRAM_INDEX_TYPE;
#define OPD_HISTROGRAM_CNT  eHISTOGRAM_IDX_MAX

typedef struct{
    USHORT Xpos;
    USHORT Ypos;
    
    USHORT UnmentionedArea_Xpos;
    USHORT UnmentionedArea_Ypos;    
}STRUCT_OPD_CIE_TYPE;

typedef struct{
    USHORT R;
    USHORT B;

    USHORT UnmentionedArea_R;
    USHORT UnmentionedArea_B;    
}STRUCT_OPD_RATIO_TYPE;

typedef struct
{
    UCHAR   ExcludeColor_CNT; // Except Count
    
    UCHAR   VALID_CNT;
    UCHAR   VALID_GRID[OPD_GRID_CNT_Y];

    UCHAR   AvgY;
    UCHAR   NormalAvgY;
    UCHAR   WeightedY;

    STRUCT_OPD_RATIO_TYPE Ratio;
    STRUCT_OPD_CIE_TYPE Cie;
}STRUCT_OPD_DATA_TYPE;

typedef struct
{
    UCHAR   Height;
    UCHAR   Width;
    UCHAR   Total;
}STRUCT_OPD_SIZE_TYPE;

typedef struct
{
    UCHAR   WeightY;
    UCHAR   WeightRatio;
    UCHAR   Ratio[OPD_HISTROGRAM_CNT];
    UCHAR   Accumulate[OPD_HISTROGRAM_CNT];
    UCHAR   Highlight;
    //UCHAR   SectionY[OPD_HISTROGRAM_CNT];   /* Y�� �������� �� �� ������ ���� */
}STRUCT_HISTOGRAM_TYPE;

typedef struct
{
    STRUCT_OPD_SIZE_TYPE Size;

    STRUCT_OPD_DATA_TYPE Data;
    STRUCT_OPD_DATA_TYPE DataM;
    STRUCT_OPD_DATA_TYPE DataS;

    STRUCT_HISTOGRAM_TYPE Histogram;
    STRUCT_HISTOGRAM_TYPE HistogramM;
    STRUCT_HISTOGRAM_TYPE HistogramS;

	UCHAR	OpdYCnt;
}STRUCT_MW_OPD;	

extern STRUCT_MW_OPD		sMwOpd;
void ncLib_OpdGrid_Set(UCHAR Grid, UCHAR PositionX, UCHAR PositionY, UCHAR BlcSizeX, UCHAR BlcSizeY);

/********************************************************************************
* Function Name 	: ncLib_OPD_Task()
* Description		: OPD L_R, L_G, L_B, L_Y Get , "sMwOpd" value Update
* Refer to		: API Document
* Argument		:	
										 
* Return			: The return value does not exist.
********************************************************************************/
void ncLib_OPD_Task(void);
BOOL OPD_Validation_Check(UCHAR OpdNum);
BOOL OPD_Validation_CheckS(UCHAR OpdNum);

#endif

