
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __DRV_STANDARD__
#define __DRV_STANDARD__

#define ADC_BUFFER_MAX      16

#define BUFF_CNT_B08    32
typedef struct{
    UCHAR BuffCntInit;
    UCHAR BuffIdx;
    UCHAR Buffer[BUFF_CNT_B08];
    USHORT AccValue;
}BUFFER_AVERAGE_TYPE;

#define BUFF_CNT_B16    16
typedef struct{
    UCHAR BuffCntInit;
    UCHAR BuffIdx;
    USHORT Buffer[BUFF_CNT_B16];
    INT32 AccValue;
}BUFFER_AVERAGE_16BIT_TYPE;

UCHAR ncDrv_BufferAvg_Get(BUFFER_AVERAGE_TYPE * BuffInfo, UCHAR BufferCnt, UCHAR Value);

USHORT ncDrv_BufferAvg_Get16(BUFFER_AVERAGE_16BIT_TYPE * BuffInfo, UCHAR BufferCnt, USHORT Value);

volatile void ncDrv_Delay_Set(INT32 Delay);
volatile void ncDrv_DelayMs_Set(INT32 Ms);
FLOAT ncDrv_ConvertHex2Float(USHORT usHex);
FLOAT ncDrv_Transition( FLOAT InputF, FLOAT StartInX,FLOAT EndInX, FLOAT StartOutX,FLOAT EndOutY );
USHORT ncDrv_Interp(USHORT X_In, USHORT x0, USHORT x1, USHORT y0, USHORT y1);
USHORT ncDrv_InterpAGC(USHORT x0, USHORT x1, USHORT y0, USHORT y1);
UCHAR ncDrv_InterpTbl08(UCHAR X_in,  UCHAR * pLutX, UCHAR * pLutY, UCHAR nSizeLut);
USHORT ncDrv_InterpTbl16(USHORT X_in,  USHORT * pLutX, USHORT * pLutY, UCHAR nSizeLut);
UCHAR ncDrv_InterpTbl16to8(USHORT X_in,  USHORT * pLutX, UCHAR * pLutY, UCHAR nSizeLut);
USHORT ncDrv_Divider(USHORT dividend, USHORT divisor);

#endif

