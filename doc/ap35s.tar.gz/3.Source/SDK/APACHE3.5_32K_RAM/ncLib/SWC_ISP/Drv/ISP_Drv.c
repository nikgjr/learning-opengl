/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : ISP_Drv.c
*
*  @brief   : ISP module driver source file
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "ISP_Drv.h"

/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

PrVoid ncDrv_ISP_UserHandler = NULL;


volatile HAL_BANK00_CONTROL_REGISTER    *rBank00;
volatile HAL_BANK01_CONTROL_REGISTER    *rBank01;
volatile HAL_BANK02_CONTROL_REGISTER    *rBank02;
volatile HAL_BANK03_CONTROL_REGISTER    *rBank03;
volatile HAL_BANK04_CONTROL_REGISTER    *rBank04;
volatile HAL_BANK05_CONTROL_REGISTER    *rBank05;
volatile HAL_BANK06_CONTROL_REGISTER    *rBank06;
volatile HAL_BANK07_CONTROL_REGISTER    *rBank07;
volatile HAL_BANK08_CONTROL_REGISTER    *rBank08;
volatile HAL_BANK09_CONTROL_REGISTER    *rBank09;

volatile HAL_BANK0D_CONTROL_REGISTER    *rBank0D;
volatile HAL_BANK0E_CONTROL_REGISTER    *rBank0E;
volatile HAL_BANK0F_CONTROL_REGISTER    *rBank0F;

//volatile HAL_BANK10_CONTROL_REGISTER    *rBank10;
volatile HAL_BANK11_CONTROL_REGISTER    *rBank11;
volatile HAL_BANK12_CONTROL_REGISTER    *rBank12;
volatile HAL_BANK13_CONTROL_REGISTER    *rBank13;
volatile HAL_BANK14_CONTROL_REGISTER    *rBank14;
volatile HAL_BANK15_CONTROL_REGISTER    *rBank15;
volatile HAL_BANK16_CONTROL_REGISTER    *rBank16;
volatile HAL_BANK17_CONTROL_REGISTER    *rBank17;
volatile HAL_BANK18_CONTROL_REGISTER    *rBank18;
volatile HAL_BANK19_CONTROL_REGISTER    *rBank19;
volatile HAL_BANK1A_CONTROL_REGISTER    *rBank1A;
volatile HAL_BANK1B_CONTROL_REGISTER    *rBank1B;
volatile HAL_BANK1C_CONTROL_REGISTER    *rBank1C;
volatile HAL_BANK1D_CONTROL_REGISTER    *rBank1D;

volatile HAL_BANK20_CONTROL_REGISTER    *rBank20;
volatile HAL_BANK21_CONTROL_REGISTER    *rBank21;
volatile HAL_BANK22_CONTROL_REGISTER    *rBank22;
volatile HAL_BANK23_CONTROL_REGISTER    *rBank23;
volatile HAL_BANK24_CONTROL_REGISTER    *rBank24;
volatile HAL_BANK25_CONTROL_REGISTER    *rBank25;
volatile HAL_BANK26_CONTROL_REGISTER    *rBank26;
volatile HAL_BANK27_CONTROL_REGISTER    *rBank27;
volatile HAL_BANK28_CONTROL_REGISTER    *rBank28;
volatile HAL_BANK29_CONTROL_REGISTER    *rBank29;
volatile HAL_BANK2A_CONTROL_REGISTER    *rBank2A;
volatile HAL_BANK2B_CONTROL_REGISTER    *rBank2B;
volatile HAL_BANK2C_CONTROL_REGISTER    *rBank2C;
volatile HAL_BANK2D_CONTROL_REGISTER    *rBank2D;
volatile HAL_BANK2E_CONTROL_REGISTER    *rBank2E;
/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
tISP_INTR_FLAG_TYPE sSyncIntr;
void ncDrv_ISP_RegisterOpen(void)
{
    INT32 ret = NC_SUCCESS;
    INT32 IntrCheck = NC_SUCCESS;
    
    rBank00 = (HAL_BANK00_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK00_START_ADDRESS); 
    rBank01 = (HAL_BANK01_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK01_START_ADDRESS); 
    rBank02 = (HAL_BANK02_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK02_START_ADDRESS); 
    rBank03 = (HAL_BANK03_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK03_START_ADDRESS); 
    rBank04 = (HAL_BANK04_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK04_START_ADDRESS); 
    rBank05 = (HAL_BANK05_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK05_START_ADDRESS); 
    rBank06 = (HAL_BANK06_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK06_START_ADDRESS); 
    rBank07 = (HAL_BANK07_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK07_START_ADDRESS); 
    rBank08 = (HAL_BANK08_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK08_START_ADDRESS); 
    rBank09 = (HAL_BANK09_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK09_START_ADDRESS); 

    rBank0D = (HAL_BANK0D_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK0D_START_ADDRESS); 
    rBank0E = (HAL_BANK0E_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK0E_START_ADDRESS); 
    rBank0F = (HAL_BANK0F_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK0F_START_ADDRESS); 

    //rBank10 = (HAL_BANK10_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK10_START_ADDRESS); 
    rBank11 = (HAL_BANK11_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK11_START_ADDRESS); 
    rBank12 = (HAL_BANK12_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK12_START_ADDRESS); 
    rBank13 = (HAL_BANK13_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK13_START_ADDRESS); 
    rBank14 = (HAL_BANK14_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK14_START_ADDRESS); 
    rBank15 = (HAL_BANK15_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK15_START_ADDRESS); 
    rBank16 = (HAL_BANK16_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK16_START_ADDRESS); 
    rBank17 = (HAL_BANK17_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK17_START_ADDRESS); 
    rBank18 = (HAL_BANK18_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK18_START_ADDRESS); 
    rBank19 = (HAL_BANK19_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK19_START_ADDRESS); 
    rBank1A = (HAL_BANK1A_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK1A_START_ADDRESS);
    rBank1B = (HAL_BANK1B_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK1B_START_ADDRESS);
    rBank1C = (HAL_BANK1C_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK1C_START_ADDRESS);
    rBank1D = (HAL_BANK1D_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK1D_START_ADDRESS); 
                                                                                  
    rBank20 = (HAL_BANK20_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK20_START_ADDRESS); 
    rBank21 = (HAL_BANK21_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK21_START_ADDRESS); 
    rBank22 = (HAL_BANK22_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK22_START_ADDRESS); 
    rBank23 = (HAL_BANK23_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK23_START_ADDRESS); 
    rBank24 = (HAL_BANK24_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK24_START_ADDRESS); 
    rBank25 = (HAL_BANK25_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK25_START_ADDRESS); 
    rBank26 = (HAL_BANK26_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK26_START_ADDRESS); 
    rBank27 = (HAL_BANK27_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK27_START_ADDRESS); 
    rBank28 = (HAL_BANK28_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK28_START_ADDRESS); 
    rBank29 = (HAL_BANK29_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK29_START_ADDRESS); 
    rBank2A = (HAL_BANK2A_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK2A_START_ADDRESS);
    rBank2B = (HAL_BANK2B_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK2B_START_ADDRESS);
    rBank2C = (HAL_BANK2C_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK2C_START_ADDRESS);
    rBank2D = (HAL_BANK2D_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK2D_START_ADDRESS);  
    rBank2E = (HAL_BANK2E_CONTROL_REGISTER *)(APACHE_ISP_BASE|BANK2E_START_ADDRESS);  


	rIP_SEL_ISP_INT1 = 0x03;
	rIP_SEL_ISP_INT0 = 0x02;

	rIP_SEL_ISP_INT3 = 0x05;                             
	rIP_SEL_ISP_INT2 = 0x04;                          
    
    IntrCheck  = ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_ISP0, (PrHandler)ncDrv_ISP_IRQ_Handler, CMD_END);
    IntrCheck += ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_ISP1, (PrHandler)ncDrv_ISP_IRQ_Handler, CMD_END);
    IntrCheck += ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_ISP2, (PrHandler)ncDrv_ISP_IRQ_Handler, CMD_END);
    IntrCheck += ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_ISP3, (PrHandler)ncDrv_ISP_IRQ_Handler, CMD_END);
    //IntrCheck += ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_ISP4, (PrHandler)ncDrv_ISP_IRQ_Handler, CMD_END);

	if(IntrCheck != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGERR, "Error, ISP ISR Connection Failure!\n");
        ret = NC_FAILURE;
    }
    else
    {
        DEBUGMSG_SDK(MSGWARN, "Warning, ISP is already open!\n");
        ret = NC_FAILURE;
    }
}

void ncDrv_ISP_RegisterClose(void)
{
        rBank00 = NULL;   
        rBank01 = NULL;   
        rBank02 = NULL;   
        rBank03 = NULL;   
        rBank04 = NULL;   
        rBank05 = NULL;   
        rBank06 = NULL;   
        rBank07 = NULL;   
        rBank08 = NULL;   
        rBank09 = NULL;   
        
        rBank0D = NULL;   
        rBank0E = NULL;   
        rBank0F = NULL;  
        
        //rBank10 = NULL;   
        rBank11 = NULL;   
        rBank12 = NULL;   
        rBank13 = NULL;   
        rBank14 = NULL;   
        rBank15 = NULL;   
        rBank16 = NULL;   
        rBank17 = NULL;   
        rBank18 = NULL;   
        rBank19 = NULL;   
        rBank1A = NULL;   
        rBank1B = NULL;   
        rBank1C = NULL;   
        rBank1D = NULL;  
        
        rBank20 = NULL;   
        rBank21 = NULL;   
        rBank22 = NULL;   
        rBank23 = NULL;   
        rBank24 = NULL;   
        rBank25 = NULL;   
        rBank26 = NULL;   
        rBank27 = NULL;   
        rBank28 = NULL;   
        rBank29 = NULL; 
        rBank2A = NULL;   
        rBank2B = NULL;   
        rBank2C = NULL;         
        rBank2D = NULL;  
        rBank2E = NULL;  

}


void ncDrv_ISP_IRQ_Handler(UINT32 nIrqNum)
{
    switch(nIrqNum)
    {
        case IRQ_NUM_ISP0:
            sSyncIntr.SyncInPosFlag = 1; 
			sHalDelay.VSIPSkip++;			
            break;
            
        case IRQ_NUM_ISP1:
            sSyncIntr.SyncInNegFlag = 1;
            sHalDelay.VSINSkip++;
            break;
            
        case IRQ_NUM_ISP2:
            sSyncIntr.SyncOutPosFlag = 1;
			sHalDelay.VSOPSkip++;
            break;
            
        case IRQ_NUM_ISP3:
            sSyncIntr.SyncOutNegFlag = 1;
            break;
            
        case IRQ_NUM_ISP4:
            sSyncIntr.DPCScanDoneFlag = 1;
            break;
            
        case IRQ_NUM_ISP5:
        case IRQ_NUM_ISP6:
        case IRQ_NUM_ISP7:
        case IRQ_NUM_ISP8:
        default:
            break;
    }
}


INT32 ncDrv_ISP_ConnectUserHandler(PrVoid UserHandler)
{
    INT32 ret = NC_SUCCESS;

    ncDrv_ISP_UserHandler = (PrVoid) UserHandler;

    return ret;
}


INT32 ncDrv_ISP_DisConnectUserHandler(void)
{
    INT32 ret = NC_SUCCESS;

    ncDrv_ISP_UserHandler = (PrVoid) NULL;

    return ret;
}



void ncDrv_ISP_SWReset(void)
{
#if 0
    volatile unsigned int i;

    SDRAM_REG.R0x0A99.B8.FDATA_INIT = 1;
	for(i = 0; i < 50; i++){}

    SDRAM_REG.R0x0A99.B8.FDATA_INIT = 0;
	for(i = 0; i < 50; i++){}

    APACHE3_CLEAR_BIT(0xF0000000, 4);
	for(i = 0; i < 300; i++){}

    APACHE3_SET_BIT(0xF0000000, 4);
#endif
}


void ncDrv_ISP_CheckInterruptDone(eISP_INTR_NUM nIntrNum)
{
    switch(nIntrNum)
    {
        case ISP_INTR_DPCSCAN:
            ncDrv_ISP_CheckStaticDPCScanInterrupt();
            break;

        case ISP_INTR_IN_VSYNCPOS:
            ncDrv_ISP_CheckInVsyncPosInterrupt();
            break;

        case ISP_INTR_IN_VSYNCNEG:
            ncDrv_ISP_CheckInVsyncNegInterrupt();
            break;

        case ISP_INTR_OUT_VSYNCPOS:
            ncDrv_ISP_CheckOutVsyncPosInterrupt();
            break;

        case ISP_INTR_OUT_VSYNCNEG:
            ncDrv_ISP_CheckOutVsyncNegInterrupt();
            break;

        default :
            DEBUGMSG_SDK(MSGERR, "Error, ISP check interrupt number %d\n", nIntrNum);
            break;
    }
}


void ncDrv_ISP_CheckStaticDPCScanInterrupt(void)
{
    UINT32 timeover = 10000000;

    do
    {
        if(sSyncIntr.DPCScanDoneFlag)
        {
            sSyncIntr.DPCScanDoneFlag = 0;
            break;
        }

        timeover--;
        if(!timeover)
        {
            DEBUGMSG_SDK(MSGERR, "Error, SyncScanIntFlag wait timeout\n");
            break;
        }
    }while(timeover);
}


void ncDrv_ISP_CheckInVsyncPosInterrupt(void)
{
    UINT32 timeover = 10000000;

    do
    {
        if(sSyncIntr.SyncInPosFlag)
        {
            sSyncIntr.SyncInPosFlag = 0;
            break;
        }

        timeover--;
        if(!timeover)
        {
            DEBUGMSG_SDK(MSGERR, "Error, SyncInPosFlag wait timeout\n");
            break;
        }
    }while(timeover);
}


void ncDrv_ISP_CheckInVsyncNegInterrupt(void)
{
    UINT32 timeover = 10000000;

    do
    {
        if(sSyncIntr.SyncInNegFlag)
        {
            sSyncIntr.SyncInNegFlag = 0;
            break;
        }

        timeover--;
        if(!timeover)
        {
            DEBUGMSG_SDK(MSGERR, "Error, SyncInNegFlag wait timeout\n");
            break;
        }
    }while(timeover);
}


void ncDrv_ISP_CheckOutVsyncPosInterrupt(void)
{
    UINT32 timeover = 10000000;

    do
    {
        if(sSyncIntr.SyncOutPosFlag)
        {
            sSyncIntr.SyncOutPosFlag = 0;
            break;
        }

        timeover--;
        if(!timeover)
        {
            DEBUGMSG_SDK(MSGERR, "Error, SyncOutPosFlag wait timeout\n");
            break;
        }
    }while(timeover);
}


void ncDrv_ISP_CheckOutVsyncNegInterrupt(void)
{
    UINT32 timeover = 10000000;

    do
    {
        if(sSyncIntr.SyncOutNegFlag)
        {
            sSyncIntr.SyncOutNegFlag = 0;
            break;
        }

        timeover--;
        if(!timeover)
        {
            DEBUGMSG_SDK(MSGERR, "Error, SyncOutNegFlag wait timeout\n");
            break;
        }
    }while(timeover);
}


UINT8 ncDrv_ISP_GetInterruptVsync(eISP_INTR_NUM nIntrNum)
{
    UINT8 nVsync = 0;

    switch(nIntrNum)
    {
        case ISP_INTR_IN_VSYNCPOS:
            nVsync = ncDrv_ISP_GetInPosSync();
            break;

        case ISP_INTR_IN_VSYNCNEG:
            nVsync = ncDrv_ISP_GetInNegSync();
            break;

        case ISP_INTR_OUT_VSYNCPOS:
            nVsync = ncDrv_ISP_GetOutPosSync();
            break;

        case ISP_INTR_OUT_VSYNCNEG:
            nVsync = ncDrv_ISP_GetOutNegSync();
            break;

        default :
            DEBUGMSG_SDK(MSGERR, "Error, ISP get interrupt number %d\n", nIntrNum);
            break;
    }

    return nVsync;
}


void ncDrv_ISP_ClearInterruptVsync(eISP_INTR_NUM nIntrNum)
{
    switch(nIntrNum)
    {
        case ISP_INTR_IN_VSYNCPOS:
            ncDrv_ISP_ClearInPosSync();
            break;

        case ISP_INTR_IN_VSYNCNEG:
            ncDrv_ISP_ClearInNegSync();
            break;

        case ISP_INTR_OUT_VSYNCPOS:
            ncDrv_ISP_ClearOutPosSync();
            break;

        case ISP_INTR_OUT_VSYNCNEG:
            ncDrv_ISP_ClearOutNegSync();
            break;

        default :
            DEBUGMSG_SDK(MSGERR, "Error, ISP clear interrupt number %d\n", nIntrNum);
            break;
    }
}


UINT8 ncDrv_ISP_GetInPosSync(void)
{
    return sSyncIntr.SyncInPosFlag;
}


void ncDrv_ISP_ClearInPosSync(void)
{
    sSyncIntr.SyncInPosFlag = 0;
}


UINT8 ncDrv_ISP_GetInNegSync(void)
{
    return sSyncIntr.SyncInNegFlag;
}


void ncDrv_ISP_ClearInNegSync(void)
{
    sSyncIntr.SyncInNegFlag = 0;
}


UINT8 ncDrv_ISP_GetOutPosSync(void)
{
    return sSyncIntr.SyncOutPosFlag;
}


void ncDrv_ISP_ClearOutPosSync(void)
{
    sSyncIntr.SyncOutPosFlag = 0;
}


UINT8 ncDrv_ISP_GetOutNegSync(void)
{
    return sSyncIntr.SyncOutNegFlag;
}


void ncDrv_ISP_ClearOutNegSync(void)
{
    sSyncIntr.SyncOutNegFlag = 0;
}


void ncDrv_ISP_InPosSync_Wait(void)
{
    USHORT cnt = 0;

    sSyncIntr.SyncInPosFlag = OFF;

    while(sSyncIntr.SyncInPosFlag == OFF)
    {
        cnt++;
        if(cnt > 20000)
        {
            DEBUGMSG_SDK(MSGERR, "Error, SyncInPosFlag wait timeout\n");
            break;
        }
    }
}


void ncDrv_ISP_InNegSync_Wait(void)
{
    USHORT cnt = 0;

    sSyncIntr.SyncInNegFlag = OFF;

    while(sSyncIntr.SyncInNegFlag == OFF)
    {
        cnt++;
        if(cnt > 20000)
        {
            DEBUGMSG_SDK(MSGERR, "Error, SyncInNegFlag wait timeout\n");
            break;
        }
    }
}


void ncDrv_ISP_OutPosSync_Wait(void)
{
    USHORT cnt = 0;

    sSyncIntr.SyncOutPosFlag = OFF;

    while(sSyncIntr.SyncOutPosFlag == OFF)
    {
        cnt++;
        if(cnt > 20000)
        {
            DEBUGMSG_SDK(MSGERR, "Error, SyncOutPosFlag wait timeout\n");
            break;
        }
    }
}


void ncDrv_ISP_OutNegSync_Wait(void)
{
    USHORT cnt = 0;

    sSyncIntr.SyncOutNegFlag = OFF;

    while(sSyncIntr.SyncOutNegFlag == OFF)
    {
        cnt++;
        if(cnt > 20000)
        {
            DEBUGMSG_SDK(MSGERR, "Error, UpDate SyncOutNegFlag wait timeout\n");
            break;
        }
    }
}


/* End Of File */
