
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "APACHE35.h"
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"

#include "ISP_Drv.h"
#include "System_Drv.h"
//#include "NR_Drv.h"

//============================================================================
//      Extern Function Prototype
//============================================================================

#define 	NR_SW_REG_ADDR_DNR2			ADDR_DNR2_L_X0
#define 	NR_SW_REG_ADDR_DNR3			ADDR_DNR3_L_TBL0
#define 	NR_SW_REG_ADDR_DNR3_YTH	    ADDR_DNR3_YTH_L_TBL0

void ncDrv_NR_Set3D_Debug(void);

void ncDrv_DNR_IMG_Set(stIMAGE_SIZE_INFO * SetSize)
{
/*===============================================================
   PRODUCT	 OUTPUT SIZE	    HPIXEL	VLINE	WLINE(WLINE CAL)  
-----------------------------------------------------------------
    2450H	1280x720		    1288	720	    1472 (VLINE+16)*2
	        1920x1080		    1928	1080	2192 (VLINE+16)*2
=================================================================*/

    USHORT wline;

	if(rSWReg.Category.SYSTEM.Reg.MEMORY_MAP >=5)
		wline = (SetSize->Active.SizeV + 4) << 1;          /* (Active V Size + 16) x 2 */
	else
	    wline = (SetSize->Active.SizeV + 16) << 1;          /* (Active V Size + 16) x 2 */

    /* RB */
    ISPSET16(aIP_DNR_RB_IMG_HPIXEL_7_0, (SetSize->Active.SizeH + H_ACTIVE_OFFSET));
    ISPSET16(aIP_DNR_RB_IMG_VLINE_7_0,  SetSize->Active.SizeV);
    ISPSET16(aIP_DNR_RB_IMG_WLINE_7_0, wline);

    /* WB */ 
    ISPSET16(aIP_DNR_WB_IMG_HPIXEL_7_0, (SetSize->Active.SizeH + H_ACTIVE_OFFSET));
    ISPSET16(aIP_DNR_WB_IMG_VLINE_7_0, SetSize->Active.SizeV);
    ISPSET16(aIP_DNR_WB_IMG_WLINE_7_0, wline);
}

void ncDrv_DNR_WB_WRAP_Set(BOOL ModeSet)
{
    rIP_DNR_WB_WRAP_EN = ModeSet;
}

void ncDrv_NR_Set(void)
{
	int i = 0;
	UCHAR DNR3_MODE_OFFSET = 0;

	//____2DNR_____
	if(rSWReg.Category.NR.Reg.DNR2_MODE == eLEVEL4_OFF)
	{
		rIP_NR2DB_RSTR	= 0;
		rIP_NR2DB_GSTR	= 0;
		rIP_NR2DB_BSTR	= 0;
		rIP_NR2DB_EN	= STATE_OFF;
	}
	else
		rIP_NR2DB_EN	= STATE_ON;

	//____3DNR_____

	DNR3_MODE_OFFSET = ((rSWReg.Category.NR.Reg.DNR3_MODE - eLEVEL4_LOW) << 3);

	if(rSWReg.Category.NR.Reg.DNR3_MODE == eLEVEL4_OFF)	
	{
	    rIP_DNR_EN = STATE_OFF;
    }
	else	
	{
		rIP_DNR_EN = STATE_ON;
		//memcpy((void *)aIP_DNR_IIR_PARAM0_7_0, (void *)(NR_SW_REG_ADDR_DNR3 + DNR3_MODE_OFFSET), (8L * sizeof(UCHAR))); //0x0960 0x82CE

		rIP_DNR_IIR_PARAM0_7_0 = ISPGET08(ADDR_DNR3_L_TBL0 + DNR3_MODE_OFFSET);
		rIP_DNR_IIR_PARAM1_7_0 = ISPGET08(ADDR_DNR3_L_TBL1 + DNR3_MODE_OFFSET);
		rIP_DNR_IIR_PARAM2_7_0 = ISPGET08(ADDR_DNR3_L_TBL2 + DNR3_MODE_OFFSET);
		rIP_DNR_IIR_PARAM3_7_0 = ISPGET08(ADDR_DNR3_L_TBL3 + DNR3_MODE_OFFSET);
		rIP_DNR_IIR_PARAM4_7_0 = ISPGET08(ADDR_DNR3_L_TBL4 + DNR3_MODE_OFFSET);
		rIP_DNR_IIR_PARAM5_7_0 = ISPGET08(ADDR_DNR3_L_TBL5 + DNR3_MODE_OFFSET);
		rIP_DNR_IIR_PARAM6_7_0 = ISPGET08(ADDR_DNR3_L_TBL6 + DNR3_MODE_OFFSET);
		rIP_DNR_IIR_PARAM7_7_0 = ISPGET08(ADDR_DNR3_L_TBL7 + DNR3_MODE_OFFSET);

		//{/* [2014/10/23] shpark : 1-1 */
		// 3DNR YTH Register Add
		for(i=0; i<8; i++)
		{
			ISPSET08((aIP_DNR_YTH_PARAM0_7_0+(i<< 1)), ISPGET08(NR_SW_REG_ADDR_DNR3_YTH+DNR3_MODE_OFFSET+i));
		}
	}	

/*======================================================================================
    1. DNR_RB_ENABLE  is following 3DNR state                                            
    2. DNR_WB_WRAP_EN is following FRC state : MW_DNR_WB_WRAP_Set()                      
    3. DNR_WB_ENABLE  is following both of [3DNR] and FRC state [FRC_SYNC_MODE]          
       if one of them is ON, DNR_WB_ENABLE is ON                                         
========================================================================================*/
    rIP_DNR_RB_ENABLE = rIP_DNR_EN;
    //rIP_DNR_WB_ENABLE = rIP_DNR_RB_ENABLE | rIP_DNR_WB_WRAP_EN;
}

void NR_Set2D(void)
{
#define TBL_X0		0
#define TBL_X1		1
#define TBL_Y0		2
#define TBL_Y1		3
#define NR2DB_GSTR_OFFSET   4

	UCHAR DNR2_MODE_OFFSET = 0;	
	UCHAR DNR2_AGC0 = 0;
	UCHAR DNR2_X0, DNR2_X1, DNR2_Y0, DNR2_Y1 = 0;

	if(rSWReg.Category.NR.Reg.DNR2_MODE != STATE_OFF)
	{
		DNR2_MODE_OFFSET = (rSWReg.Category.NR.Reg.DNR2_MODE - 1L) * 4L;// Offset 0, 5, 10

		DNR2_X0 	= ISPGET08(NR_SW_REG_ADDR_DNR2 + TBL_X0 + DNR2_MODE_OFFSET);
		DNR2_X1 	= ISPGET08(NR_SW_REG_ADDR_DNR2 + TBL_X1 + DNR2_MODE_OFFSET);
		DNR2_Y0 	= ISPGET08(NR_SW_REG_ADDR_DNR2 + TBL_Y0 + DNR2_MODE_OFFSET) & 0x1F;// 5bit ??
		DNR2_Y1 	= ISPGET08(NR_SW_REG_ADDR_DNR2 + TBL_Y1+ DNR2_MODE_OFFSET) & 0x1F;// 5bit ??

		rIP_NR2DB_GSTR = ncDrv_InterpAGC(DNR2_X0, DNR2_X1, DNR2_Y0, DNR2_Y1); //0x0F90
        //rIP_NR2DB_GSTR = ncLib_Standard_Control(eSTD_INTERP_AGC, DNR2_X0, DNR2_X1, DNR2_Y0, DNR2_Y1, CMD_END);
	}
	rIP_NR2DB_YSTR = rIP_NR2DB_GSTR;
	
	// DNR2_LEVEL Range(0x0 ~ 0xE), 0x0 : Mode Off
	if(rIP_NR2DB_GSTR == 0)
	{
		rIP_NR2DB_EN = STATE_OFF;		
	}
	else
	{
		rIP_NR2DB_EN = STATE_ON;
	}

	if((rIP_NR2DB_GSTR + NR2DB_GSTR_OFFSET) > 0x1F)
	{
		rIP_NR2DB_RSTR = 0x1F;
		rIP_NR2DB_BSTR = 0x1F;
	}
	else
	{
		rIP_NR2DB_RSTR = rIP_NR2DB_GSTR + NR2DB_GSTR_OFFSET;
		rIP_NR2DB_BSTR = rIP_NR2DB_GSTR + NR2DB_GSTR_OFFSET;
	}
	
#undef TBL_X0
#undef TBL_X1
#undef TBL_Y0
#undef TBL_Y1
}

void ncDrv_NR_Set3D_Debug(void)
{
#define DNR3D_IMAGE         0x00    // 3dnr output image
#define DNR3D_INTENSITY     0x01    // 3dnr ??
#define DNR3D_Y_MOTION      0x02    // number of Y motion pixels
#define DNR3D_R_MOTION      0x03    // number of R motion pixels
#define DNR3D_G_MOTION      0x04    // number of G motion pixels
#define DNR3D_B_MOTION      0x05    // number of B motion pixels

    static UCHAR SelQSPIClk = 0;
    static UCHAR DnrWbWrapEn;
    static UCHAR Init = FALSE;
    ULONG DNR_WB_WRITE_ADDR, DNR_WB_IMG_HPIXEL, DNR_WB_IMG_VLINE, Address;
    
    if(rSWReg.Category.NR.Reg.DNR3_DEBUG_MODE == eMODE_ON)
    {        
        DnrWbWrapEn = rIP_DNR_WB_WRAP_EN;
        
        DNR_WB_WRITE_ADDR   = ISPGET32(aIP_DNR_WB_WRITE_ADDR_7_0);      
        DNR_WB_IMG_HPIXEL   = ISPGET16(aIP_DNR_WB_IMG_HPIXEL_7_0);
        DNR_WB_IMG_VLINE    = ISPGET16(aIP_DNR_WB_IMG_VLINE_7_0);
        
        Address = DNR_WB_WRITE_ADDR + (DNR_WB_IMG_HPIXEL * DNR_WB_IMG_VLINE);
   
        rIP_DNR_WB_WRAP_EN = FALSE;
        rIP_DNR_WB_DEBUG_ENABLE  = TRUE;
        rIP_DNR_WB_DEBUG_DPCM_EN = TRUE;
        rIP_DNR_WB_DEBUG_MEM_SEL = TRUE;
        rIP_FRC_NR3D_NOSYNC      = TRUE;
        rIP_DNR_WB_DEBUG_BURST_CTRL_3_0 = rIP_DNR_WB_BURST_CTRL_3_0;
        
        ISPSET32(aIP_DNR_WB_DEBUG_WRITE_ADDR_7_0, Address);
        ISPSET32(aIP_FRC_START_ADDR_7_0, Address);
		
        ISPSET16(aIP_DNR_WB_DEBUG_IMG_HPIXEL_7_0, DNR_WB_IMG_HPIXEL);
        ISPSET16(aIP_DNR_WB_DEBUG_IMG_VLINE_7_0, DNR_WB_IMG_VLINE);
        ISPSET16(aIP_DNR_WB_DEBUG_IMG_WLINE_7_0, DNR_WB_IMG_VLINE);

        switch(rSWReg.Category.NR.Reg.DNR3_DEBUG_CH)
        {
            case DNR3D_IMAGE:       rIP_DNR_DSP_MODE = 0x00;     break;
            case DNR3D_INTENSITY:   rIP_DNR_DSP_MODE = 0x12;     break;
            case DNR3D_Y_MOTION:    rIP_DNR_DSP_MODE = 0x0C;     break;
            case DNR3D_R_MOTION:    rIP_DNR_DSP_MODE = 0x0D;     break;
            case DNR3D_G_MOTION:    rIP_DNR_DSP_MODE = 0x0E;     break;
            case DNR3D_B_MOTION:    rIP_DNR_DSP_MODE = 0x0F;     break;
        }

        //SelQSPIClk = rIP_SEL_QSPI_CLK;
        //rIP_SEL_QSPI_CLK = 0;
        Init = TRUE;
    }
    else
    {
        if(Init)
        { 
            rIP_DNR_WB_WRAP_EN = DnrWbWrapEn;
            //rIP_SEL_QSPI_CLK = SelQSPIClk;
        }
        
        rIP_DNR_DSP_MODE         = FALSE;
        rIP_DNR_WB_DEBUG_ENABLE  = FALSE;
        rIP_DNR_WB_DEBUG_DPCM_EN = FALSE;
        rIP_DNR_WB_DEBUG_MEM_SEL = FALSE;
        rIP_FRC_NR3D_NOSYNC      = FALSE;
    }
}

void ncDrv_NR_Auto(void)
{
	if(rSWReg.Category.NR.Reg.DNR2_MODE != eLEVEL4_OFF)		NR_Set2D();
}


