
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Drv_GlobalHeader.h"
#include "sFlash_Lib.h"
#include "ISP_Drv.h"
#include "LDC_Drv.h"
#include "FlashMemoryMap.h"

const ULONG Coefficient[10][9]=
{
	{//	Lab_1280x720_r5_z0.14.txt
	0x0007F837,0x1000B268,0x00000000,
	0x0000B268,0x0007F837,0x00000000,
	0x00000000,0x00000000,0x00080000,
	},
	{//	Lab_1280x720_r5.txt
	0x0007F837,0x1000B268,0x00000000,
	0x0000B268,0x0007F837,0x00000000,
	0x00000000,0x00000000,0x00080000,
	},
	{//	Lab_1280x720_RightSide		
	0x00080000,0x00000000,0x16400000,
	0x00000000,0x00080000,0x00000000,
	0x10000106,0x00000000,0x00080000,
	},
	{//	Lab_1280x720_UPSide		
	0x00080000,0x00000000,0x00000000,
	0x00000000,0x00080000,0x04100000,
	0x00000000,0x0000020C,0x00080000,
	},
	{//	Hyundai_test		
	0x0007EF19,0x1000AA15,0x00EAEE9A,
	0x0000B5AB,0x0007F49F,0x003D20E0,
	0x10000008,0x10000019,0x0007F590,
	},
	{//	Rotation_r10		
	0x0007E0EB,0x00016374,0x00000000,
	0x10016374,0x0007E0EB,0x00000000,
	0x00000000,0x00000000,0x00080000,
	},
	{//	Rotation_r15		
	0x0007BA49,0x000211CD,0x00000000,
	0x100211CD,0x0007BA49,0x00000000,
	0x00000000,0x00000000,0x00080000,
	},
	{//	Rotation_r20		
	0x0007849D,0x0002BC1E,0x00000000,
	0x1002BC1E,0x0007849D,0x00000000,
	0x00000000,0x00000000,0x00080000,
	},
	{//	Matrix_9		
	0x00079FF3,0x100248E9,0x05EA76FD,
	0x000129C7,0x000485F0,0x02C5CFDF,
	0x00000034,0x10000069,0x00080000,
	},
	{//	Matrix_10		
	0x000A2162,0x000064C3,0x012A73EB,
	0x00018AA6,0x00082FEC,0x10936979,
	0x00000069,0x10000069,0x00080000,
	},

};	



#define IS_WRAP (rSWReg.Category.SYSTEM.Reg.MEMORY_MAP ==4)
#define IS_FHD_Size (rSWReg.Category.SYSTEM.Reg.MEMORY_MAP >=5)

typedef struct LUTTYPE
{
	UCHAR Sampling;
	UCHAR Size;
}LUT_TYPE;
const LUT_TYPE LutTypeArr[LUT_TYPE_MAX]=
{
{ 8, LUT_LIST_SIZE_720P_8   , },
{16, LUT_LIST_SIZE_720P_16  , },
{32, LUT_LIST_SIZE_1080P_32 , },
{ 8, PIP_LIST_SIZE_640_360_8, },
{ 8, PIP_LIST_SIZE_480_270_8, },
{ 8, PIP_LIST_SIZE_432_240_8, },
{ 8, PIP_LIST_SIZE_426_240_8, },
{ 8, PIP_LIST_SIZE_320_180_8, },
{ 8, PIP_LIST_SIZE_216_120_8, },
{ 8, PIP_LIST_SIZE_160_90_8 , },
{ 8, WRAP_LIST_SIZE_160_90_8, },
};
#define LutSampling LutTypeArr[LdcSet.sLutType].Sampling
#define PipSampling LutTypeArr[LdcSet.sPipType].Sampling
#define LutSize 	(ULONG)LutTypeArr[LdcSet.sLutType].Size
#define PipSize 	(ULONG)LutTypeArr[LdcSet.sPipType].Size


typedef struct{	
    USHORT	sH_ACTIVE  ; 
	USHORT	sV_ACTIVE  ; 
	USHORT	sH_BLANK   ; 
	USHORT	sV_BLANK   ; 

	USHORT sPipOutWidth ; 
	USHORT sPipOutHeight;

	UCHAR  sLutType;
	UCHAR  sPipType;
	
	ULONG LutBaseAddr;
	UCHAR WrapLevel;

	BOOL bMainEnable;
	BOOL bPipEnable;
	BOOL bMorphingMainEnable;
	BOOL bMorphingPipEnable;

	UCHAR MainNum0;
	UCHAR MainNum1;
	UCHAR PipNum0;
	UCHAR PipNum1;
	
	UCHAR MorphingMainRatio;
	UCHAR MorphingPipRatio;
	
	USHORT PipXpos ; 
	USHORT PipYpos;

}STRUCT_LDC;
STRUCT_LDC LdcSet;


void ncDrv_GetLutTypeAddr(UCHAR Number, UCHAR* Type ,ULONG* addr)
{
	UCHAR D8[0x02];
	if( ncLib_SF_Control(GCMD_SF_READ_DATA, FLASHMEMORY_OSG_LDC_HEADER_AREA_ADDRESS+0x100+(0x2*(ULONG)Number), (UCHAR*)&D8[0], 0x2, CMD_END) == 0 )
	{
		*Type = (D8[0]&0xF0)>>4;
		*addr = MAKEWORD((D8[0]&0x0F),D8[1]);
	}
}

void ncDrv_Ldc_SetMainEnable(BOOL En)
{
	LdcSet.bMainEnable=En;
	ncDrv_Ldc_SetMode();
}

void ncDrv_Ldc_SetPipEnable(BOOL En)
{
	LdcSet.bPipEnable=En;
	ncDrv_Ldc_SetMode();
}

void ncDrv_Ldc_SetMorphingMainEnable(BOOL En)
{
	LdcSet.bMorphingMainEnable=En;
	if(LdcSet.bMorphingMainEnable)
		rIP_LDC_LUT_RATIO = LdcSet.MorphingMainRatio;
	else
		rIP_LDC_LUT_RATIO = 0;
}

void ncDrv_Ldc_SetMorphingPipEnable(BOOL En)
{
	LdcSet.bMorphingPipEnable=En;
	if(LdcSet.bMorphingPipEnable)
		rIP_PIP_RATIO	= LdcSet.MorphingPipRatio;
	else
		rIP_PIP_RATIO	= 0;
}


void ncDrv_Ldc_SetMainNum0(UCHAR pMainNum)
{
	UCHAR getType;
	ULONG getaddr;
	ULONG Lut1Addr=0;
	
	if(LdcSet.MainNum0==pMainNum)
		return;
	LdcSet.MainNum0 = pMainNum;

	ncDrv_GetLutTypeAddr(LdcSet.MainNum0,&getType,&getaddr);
	
	if(getType<=LUT_TYPE_MAIN_MAX||getType==LUT_TYPE_WRAP)
	{
#if DDR_FIX_MODE	
		Lut1Addr = LdcSet.LutBaseAddr;
		ncDrv_Ldc_SetDdrFix_LutLoad(0, LdcSet.MainNum0, 0xFF);
#else		
		Lut1Addr = LdcSet.LutBaseAddr + ((ULONG)getaddr*0x400) ;
#endif
		LdcSet.sLutType = getType;
		ncDrv_Ldc_GetLutWrapLevel();
	}

	ISPSET32(aIP_LDC_LUT_BASE_ADDR0_7_0, Lut1Addr);
	//DEBUGMSG(MSGINFO, "Lut1Addr %x ",Lut1Addr); 
	//DEBUGMSG(MSGINFO, "sLutType %x \n",LdcSet.sLutType); 

}

void ncDrv_Ldc_SetMainNum1(UCHAR pMainNum)
{
	UCHAR getType;
	ULONG getaddr;
	ULONG Lut2Addr=0;

	if(LdcSet.MainNum1==pMainNum)
		return;
	LdcSet.MainNum1=pMainNum;

	ncDrv_GetLutTypeAddr(LdcSet.MainNum1,&getType,&getaddr);
	
	if(getType<=LUT_TYPE_MAIN_MAX||getType==LUT_TYPE_WRAP)
	{
#if DDR_FIX_MODE	
		Lut2Addr = LdcSet.LutBaseAddr +(LutSize*0x400) ;
		ncDrv_Ldc_SetDdrFix_LutLoad( 1, LdcSet.MainNum1, 0xFF );
#else
		Lut2Addr = LdcSet.LutBaseAddr +((ULONG)getaddr*0x400) ;	
#endif
		LdcSet.sLutType = getType;
		ncDrv_Ldc_GetLutWrapLevel();

	}

	ISPSET32(aIP_LDC_LUT_BASE_ADDR1_7_0,Lut2Addr);
	//DEBUGMSG(MSGINFO, "Lut2Addr %x ",Lut2Addr); 
	//DEBUGMSG(MSGINFO, "sLutType %x \n",LdcSet.sLutType); 
}

void ncDrv_Ldc_SetPipNum0(UCHAR pPipNum)
{
	UCHAR getType;
	ULONG getaddr;
	ULONG Pip1Addr=0;

	if(LdcSet.PipNum0==pPipNum)
		return;
	LdcSet.PipNum0=pPipNum;

	ncDrv_GetLutTypeAddr(LdcSet.PipNum0,&getType,&getaddr);
	if(getType>=LUT_TYPE_PIP_MIN && getType<=LUT_TYPE_PIP_MAX)
	{
#if DDR_FIX_MODE	
		Pip1Addr = LdcSet.LutBaseAddr + (LutSize*0x400*2);
		ncDrv_Ldc_SetDdrFix_LutLoad( 2, LdcSet.PipNum0, 0xFF );
#else
		Pip1Addr = LdcSet.LutBaseAddr + ((ULONG)getaddr*0x400) ;
#endif
		LdcSet.sPipType = getType;
	}

	ISPSET32(aIP_PIP_LUT_BASE_ADDR0_7_0, Pip1Addr);
	//DEBUGMSG(MSGINFO, "Pip1Addr %x ",Pip1Addr); 
	//DEBUGMSG(MSGINFO, "sPipType %x \n",LdcSet.sPipType); 
}
void ncDrv_Ldc_SetPipNum1(UCHAR pPipNum)
{
	UCHAR getType;
	ULONG getaddr;
	ULONG Pip2Addr=0;

	if(LdcSet.PipNum1==pPipNum)
		return;
	LdcSet.PipNum1=pPipNum;
	
	ncDrv_GetLutTypeAddr(LdcSet.PipNum1,&getType,&getaddr);
	if(getType>=LUT_TYPE_PIP_MIN && getType<=LUT_TYPE_PIP_MAX)
	{
#if DDR_FIX_MODE	
		Pip2Addr = LdcSet.LutBaseAddr + (LutSize*0x400*2) +(PipSize*0x400) ;
		ncDrv_Ldc_SetDdrFix_LutLoad( 3, LdcSet.PipNum1, 0xFF );
#else
		Pip2Addr = LdcSet.LutBaseAddr + ((ULONG)getaddr*0x400) ;	
#endif
		LdcSet.sPipType = getType;
	}

	ISPSET32(aIP_PIP_LUT_BASE_ADDR1_7_0, Pip2Addr);
	//DEBUGMSG(MSGINFO, "Pip2Addr %x ",Pip2Addr); 
	//DEBUGMSG(MSGINFO, "sPipType %x \n",LdcSet.sPipType); 
}


void ncDrv_Ldc_SetMorphingMainRatio(UCHAR Ratio)
{
	rIP_LDC_LUT_RATIO = LdcSet.MorphingMainRatio = Ratio;
}
void ncDrv_Ldc_SetMorphingPipRatio(UCHAR Ratio)
{
	rIP_PIP_RATIO	 = LdcSet.MorphingPipRatio   = Ratio;
}
void ncDrv_Ldc_SetPipPosX(USHORT posX)
{
	rIP_PIP_XST_7_0	 = LOBYTE(posX);
	rIP_PIP_XST_10_8 = HIBYTE(posX);

}
void ncDrv_Ldc_SetPipPosY(USHORT posY)
{
	rIP_PIP_YST_7_0  = LOBYTE(posY);
	rIP_PIP_YST_10_8 = HIBYTE(posY);
}

void ncDrv_Ldc_Set_LutBaseAddr(ULONG Addr)
{	
	LdcSet.LutBaseAddr = Addr;
}


UCHAR ncDrv_Ldc_Get_WrapLevel(void)
{
	return LdcSet.WrapLevel;
}

USHORT ncDrv_Ldc_GetP_MainSizeH(void)
{
	return LdcSet.sH_ACTIVE;
}

USHORT ncDrv_Ldc_GetP_MainSizeV(void)
{
	return LdcSet.sV_ACTIVE;
}

USHORT ncDrv_Ldc_GetP_PipSizeH(void)
{
	return LdcSet.sPipOutWidth;
}

USHORT ncDrv_Ldc_GetP_PipSizeV(void)
{
	return LdcSet.sPipOutHeight;
}

void ncDrv_Ldc_SetSpiAddr(UCHAR Mode)
{
	#define GET_STR_LONGVAL(A)		(*(ULONG*)A)
	
	UINT32 LutFileAddr;
	OSG_LUT_HEADER HeaderTmp ;
	UINT32 j = 0; 
	UINT32 length;
	UINT32 PmAddr;

	const UCHAR STR_LUT[4]		= "LUT ";

#if DDR_FIX_MODE
	ncDrv_Ldc_SetDdrFix_LutLoad(0, LdcSet.MainNum0,Mode);
	ncDrv_Ldc_SetDdrFix_LutLoad(1, LdcSet.MainNum1,Mode);
	ncDrv_Ldc_SetDdrFix_LutLoad(2, LdcSet.PipNum0 ,Mode);
	ncDrv_Ldc_SetDdrFix_LutLoad(3, LdcSet.PipNum1 ,Mode);
	return;
#endif

	if( ncLib_SF_Control(GCMD_SF_READ_DATA, FLASHMEMORY_OSG_LDC_HEADER_AREA_ADDRESS, (UINT8*)&HeaderTmp.B8[0], 0x10, CMD_END) != 0 )
	{
		return;
	}
		
#if 0
	DEBUGMSG(MSGINFO,"LUT_HEADER %x : ",FLASHMEMORY_OSG_LDC_HEADER_AREA_ADDRESS);  
	for(j=0;j<0x10;j++)
	{
		DEBUGMSG(MSGINFO," %02X ",HeaderTmp.B8[j]);  
	}
	DEBUGMSG(MSGINFO,"\n");  

#endif
	if(HeaderTmp.Common.NAME== GET_STR_LONGVAL(STR_LUT) )
	{
		LutFileAddr = (ULONG)MAKEWORD(HeaderTmp.B8[8], HeaderTmp.B8[9])*0x400;
	
		ncDrv_DDRMemory_Address_Set();//Recv pbuffer

		length = FLASHMEMORY_LDC_END_AREA_ADDRESS - LutFileAddr + 1; //0x1A8FFF - 0xD5400 + 1
		
		if(Mode==0)
		{
			REGRW32(APACHE_QSPI_BASE,0x34) = 0x00000000;
		}
		else if(Mode<=10)
		{
			REGRW32(APACHE_QSPI_BASE,0x34) = 0xA2D00500;
			PmAddr = APACHE_QSPI_BASE+0x38; 
			REGRW32(PmAddr,0)=Coefficient[Mode-1][0];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][1];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][2];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][3];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][4];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][5];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][6];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][7];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][8];
		}

		for(j = 0; j < length; j += SF_PAGE_SIZE)
   		{
			if(Mode)
				REGRW32(APACHE_QSPI_BASE,0x34) = 0xA2D00500;
			ncLib_SF_Control(SCMD_SF_LUT_READ_DATA, (LutFileAddr+j), ((UINT8 *)LdcSet.LutBaseAddr+j), SF_PAGE_SIZE, CMD_END); //0xD4000
		}
		REGRW32(APACHE_QSPI_BASE,0x34) = 0x00000000;
	}

	
	
}


void ncDrv_Ldc_SetDdrFix_LutLoad(UCHAR Taget, UCHAR Index, UCHAR Mode)
{
#if DDR_FIX_MODE	
	#define GET_STR_LONGVAL(A)		(*(ULONG*)A)

	UINT32 LutBaseAddr;
	UINT32 LutFileAddr;
	UCHAR getType;
	ULONG getaddr;
	
	OSG_LUT_HEADER HeaderTmp ;
	UINT32 j = 0; 
	UINT32 length;
	UINT32 PmAddr;

	const UCHAR STR_LUT[4]		= "LUT ";

	//DEBUGMSG(MSGINFO,"ncDrv_Ldc_SetDdrFix_LutLoad  %02X ",Taget);  
	//DEBUGMSG(MSGINFO,"  %02X ",Index);  
	//DEBUGMSG(MSGINFO,"  %02X ",Mode);  

	if( ncLib_SF_Control(GCMD_SF_READ_DATA, FLASHMEMORY_OSG_LDC_HEADER_AREA_ADDRESS, (UINT8*)&HeaderTmp.B8[0], 0x10, CMD_END) != 0 )
	{
		return;
	}
	if(HeaderTmp.Common.NAME== GET_STR_LONGVAL(STR_LUT) )
	{
		ncDrv_DDRMemory_Address_Set();

		LutFileAddr = (ULONG)MAKEWORD(HeaderTmp.B8[8], HeaderTmp.B8[9])*0x400;
		
		if(Taget==0)
		{
			LutBaseAddr = LdcSet.LutBaseAddr;
			ncDrv_GetLutTypeAddr(LdcSet.MainNum0,&getType,&getaddr);
			length = LutSize*0x400;
		}
		else if(Taget==1)
		{
			LutBaseAddr = LdcSet.LutBaseAddr + (LutSize*0x400);
			ncDrv_GetLutTypeAddr(LdcSet.MainNum1,&getType,&getaddr);
			length = LutSize*0x400;
		}
		else if(Taget==2)
		{
			LutBaseAddr = LdcSet.LutBaseAddr + ((LutSize*0x400)*2);
			ncDrv_GetLutTypeAddr(LdcSet.PipNum0,&getType,&getaddr);
			length = PipSize*0x400;
		}
		else if(Taget==3)
		{
			LutBaseAddr = LdcSet.LutBaseAddr + (((LutSize*0x400)*2) + (PipSize*0x400));
			ncDrv_GetLutTypeAddr(LdcSet.PipNum1,&getType,&getaddr);
			length = PipSize*0x400;
		}
		
		
		LutFileAddr += ((ULONG)getaddr*0x400) ;

#if 0
	DEBUGMSG(MSGINFO, "LutBaseAddr %x ",LutBaseAddr); 
	DEBUGMSG(MSGINFO, "LutFileAddr %x ",LutFileAddr); 
	DEBUGMSG(MSGINFO, "length %x ",length); 	
#endif

		if(Mode==0)
			REGRW32(APACHE_QSPI_BASE,0x34) = 0x00000000;
		else if(Mode<=10)
		{
			REGRW32(APACHE_QSPI_BASE,0x34) = 0xA2D00500;
			PmAddr = APACHE_QSPI_BASE+0x38; 
			REGRW32(PmAddr,0)=Coefficient[Mode-1][0];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][1];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][2];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][3];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][4];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][5];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][6];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][7];PmAddr +=4;
			REGRW32(PmAddr,0)=Coefficient[Mode-1][8];
		}

		for(j = 0; j < length; j += SF_PAGE_SIZE)
   		{
			if(Mode)
				REGRW32(APACHE_QSPI_BASE,0x34) = 0xA2D00500;
			ncLib_SF_Control(SCMD_SF_LUT_READ_DATA, (LutFileAddr+j), ((UINT8 *)LutBaseAddr+j), SF_PAGE_SIZE, CMD_END); //0xD4000
		}
		REGRW32(APACHE_QSPI_BASE,0x34) = 0x00000000;
	}
	//DEBUGMSG(MSGINFO,"  END \n");  
	
#endif	
}




void ncDrv_Lut_Init(void)
{
	LdcSet.sH_ACTIVE = 0;
	LdcSet.sV_ACTIVE = 0;
	LdcSet.sH_BLANK  = 0;//2020
	LdcSet.sV_BLANK  = 0;

	LdcSet.sPipOutWidth  = 0;
	LdcSet.sPipOutHeight = 0;

	LdcSet.bMainEnable=0;
	LdcSet.bPipEnable=0;
	LdcSet.bMorphingMainEnable=0;
	LdcSet.bMorphingPipEnable=0;

	LdcSet.MainNum0=0xFF;
	LdcSet.MainNum1=0xFF;
	LdcSet.PipNum0=0xFF;
	LdcSet.PipNum1=0xFF;

	
	LdcSet.MorphingMainRatio=0;
	LdcSet.MorphingPipRatio=0;

	LdcSet.PipXpos =0;
	LdcSet.PipYpos =0;

	if(IS_FHD_Size)
		LdcSet.sLutType = LUT_TYPE_1080P_32;
	else
		LdcSet.sLutType = LUT_TYPE_720P_8;
	
	LdcSet.sPipType = PIP_TYPE_320_180_8;

	LdcSet.WrapLevel = 0;
		
	ncDrv_Ldc_GetLutWrapLevel();

	rIP_LDC_EN = 0;
	rIP_LDC_RMAIN_EN = 1;          			     
	rIP_LDC_RAMIN_READ_MODE = 1; 

	rIP_LDC_BYPASS_EN = 0;    
	rIP_LDC_LUT_RATIO = 0;      

	rIP_LDC_MODE = 0;       
	rIP_LDC_XSCALE_DOWN = 0;       			
	rIP_LDC_YSCALE_DOWN = 0;   
	rIP_PIP_XSCALE_DOWN = 0;       	
	rIP_PIP_YSCALE_DOWN = 0; 

	rIP_LDC_WMAIN_PRI_SET = 0;    	
	rIP_LDC_WMAIN_PRI_MODE = 0;    	
	rIP_LDC_RMAIN_PRI_MODE = 0;   	
	rIP_LDC_RMAIN_PRI_SET = 0; 


	rIP_LDC_PRE_VSYNC_DELAY = 10;
	rIP_LDC_WMAIN_BURST_CTRL = 0x07;	
	rIP_LDC_LUT_RMAIN_EN = 0x01;


	rIP_PIP_RMAIN_BURST_CTRL = 0x04;
	rIP_PIP_REG_UPDATE_SEL = 0x01;

	rIP_LDC_OUT_DITHER_EN = 1;      	


	rIP_LDC_SOFFSET = 0;                   	
	rIP_LDC_TOFFSET = 0;     
	rIP_LDC_YHBLUR_SEL = 0;       			
	rIP_LDC_CHBLUR_SEL = 0;  

	rIP_LDC_LUT_HPOS_7_0  = 0;
	rIP_LDC_LUT_HPOS_11_8 = 0;
	rIP_LDC_LUT_VPOS_7_0  = 0;
	rIP_LDC_LUT_VPOS_11_8 = 0;

	rIP_LDC_LUT_PRI_MODE = 0;      		
	rIP_LDC_LUT_PRI_SET  = 0;  

	rIP_PIP_YHBLUR_SEL = 0;         	
	rIP_PIP_CHBLUR_SEL = 0; 

	rIP_PIP_LUT_HPOS_7_0  = 0;                    	 
	rIP_PIP_LUT_HPOS_10_8 = 0;          	 
	rIP_PIP_LUT_VPOS_7_0  = 0;                  	 
	rIP_PIP_LUT_VPOS_10_8 = 0;  

	rIP_PIP_SOFFSET = 0;                   
	rIP_PIP_TOFFSET = 0; 

	rIP_PIP_WMAIN_EN = 1;           					
	rIP_PIP_LUT_RMAIN_EN = 1;  
	rIP_PIP_WMAIN_PRI_MODE = 0;     		
	rIP_PIP_WMAIN_PRI_SET = 0;   
	rIP_PIP_LUT_PRI_MODE = 0;      				
	rIP_PIP_LUT_PRI_SET = 0;   
	rIP_PIP_RMAIN_PRI_MODE = 0;     		
	rIP_PIP_RMAIN_PRI_SET  = 0; 
	rIP_PIP_RMAIN_EN = 1;         					
	rIP_PIP_RMAIN_READ_MODE = 0;   
	rIP_PIP_RMAIN_BURST_CTRL = 5;


	rIP_LDC_LUT_RATIO=0;
	rIP_PIP_RATIO=0;
	rIP_LDC_LUT_RATIO=0;
	rIP_LDC_LUT_RATIO=0;

	rIP_LDC_WMAIN_WRAP_INIT_EN =1;
	
}

UCHAR ncDrv_Ldc_GetLutWrapLevel(void)
{
	return 0;
#if 0
#if ( (OPTION_WDR_TYPE == WDRTYPE_DOL2) || (OPTION_WDR_TYPE == WDRTYPE_DCOMP_OV) || (OPTION_WDR_TYPE == WDRTYPE_DCOMP_AR) || (OPTION_WDR_TYPE == WDRTYPE_LWDR2)  )
	if(LdcSet.sLutType == LUT_TYPE_WRAP && LdcSet.bMainEnable)
		LdcSet.WrapLevel = 1;
	else
		LdcSet.WrapLevel = 0;
	return LdcSet.WrapLevel;
#else
	return 0;
#endif
#endif
}


void ncDrv_Lut_Pip_SetSize(void)
{
	USHORT sPipMemHeight; 
	USHORT sPipMemWidth ;  
	
	//HVDS_Set(0);
	
    //==========================================================================
    // LDC Setting
    //==========================================================================
#if 1
    if(0)
	{
		LdcSet.sH_ACTIVE = 1920 ; 
		LdcSet.sV_ACTIVE = 1080 ; 
		LdcSet.sH_BLANK  = 264 ; 
		LdcSet.sV_BLANK  = 45 ; 
	}
	else
	{
		LdcSet.sH_ACTIVE = 1280;
		LdcSet.sV_ACTIVE = 720;
		LdcSet.sH_BLANK  = 0x172;//2020
		LdcSet.sV_BLANK  = 30;
	}
	
#endif
   	rIP_LDC_IN_HWIDTH_7_0 = LdcSet.sH_ACTIVE;                   
    rIP_LDC_IN_HWIDTH_10_8 = LdcSet.sH_ACTIVE >> 8;             
    rIP_LDC_MEM_HWIDTH_7_0 = LdcSet.sH_ACTIVE;                 
    rIP_LDC_MEM_HWIDTH_10_8 = LdcSet.sH_ACTIVE >> 8;           
    rIP_LDC_OUT_HWIDTH_7_0 = LdcSet.sH_ACTIVE;                 
    rIP_LDC_OUT_HWIDTH_10_8 = LdcSet.sH_ACTIVE >> 8;           
    rIP_LDC_OUT_HBLANK_7_0 = LdcSet.sH_BLANK;                 
    rIP_LDC_OUT_HBLANK_15_8 = LdcSet.sH_BLANK >> 8;           

	rIP_LDC_WMAIN_HPIXEL_7_0  = LdcSet.sH_ACTIVE;               		
    rIP_LDC_WMAIN_HPIXEL_10_8 = LdcSet.sH_ACTIVE >> 8;        		 
    rIP_LDC_WMAIN_VLINE_7_0   = LdcSet.sV_ACTIVE;            
    rIP_LDC_WMAIN_VLINE_10_8  = LdcSet.sV_ACTIVE >> 8;      

    rIP_LDC_RMAIN_HPIXEL_7_0  = LdcSet.sH_ACTIVE;          
    rIP_LDC_RMAIN_HPIXEL_10_8 = LdcSet.sH_ACTIVE >> 8;    
    rIP_LDC_RMAIN_VLINE_7_0   = LdcSet.sV_ACTIVE;            
    rIP_LDC_RMAIN_VLINE_10_8  = LdcSet.sV_ACTIVE >> 8;      
        	
    rIP_LDC_IN_VHEIGHT_7_0   = LdcSet.sV_ACTIVE;        
    rIP_LDC_IN_VHEIGHT_10_8  = LdcSet.sV_ACTIVE >> 8;            
    rIP_LDC_MEM_VHEIGHT_7_0  = LdcSet.sV_ACTIVE;                
    rIP_LDC_MEM_VHEIGHT_10_8 = LdcSet.sV_ACTIVE >> 8;          
    rIP_LDC_OUT_VHEIGHT_7_0  = LdcSet.sV_ACTIVE;                
    rIP_LDC_OUT_VHEIGHT_10_8 = LdcSet.sV_ACTIVE >> 8;    

	rIP_LDC_HSCL_MAIN_WR_DTO_7_0  = ((256 * LdcSet.sH_ACTIVE) / LdcSet.sH_ACTIVE);          
    rIP_LDC_HSCL_MAIN_WR_DTO_12_8 = ((256 * LdcSet.sH_ACTIVE) / LdcSet.sH_ACTIVE) >> 8;    
    rIP_LDC_VSCL_MAIN_WR_DTO_7_0  = ((256 * LdcSet.sV_ACTIVE) / LdcSet.sV_ACTIVE);          
    rIP_LDC_VSCL_MAIN_WR_DTO_12_8 = ((256 * LdcSet.sV_ACTIVE) / LdcSet.sV_ACTIVE) >> 8;    
    rIP_LDC_HSCL_MAIN_RD_DTO_7_0  = ((256 * LdcSet.sH_ACTIVE) / LdcSet.sH_ACTIVE);          
    rIP_LDC_HSCL_MAIN_RD_DTO_12_8 = ((256 * LdcSet.sH_ACTIVE) / LdcSet.sH_ACTIVE) >> 8;    
    rIP_LDC_VSCL_MAIN_RD_DTO_7_0  = ((256 * LdcSet.sV_ACTIVE) / LdcSet.sV_ACTIVE);          
    rIP_LDC_VSCL_MAIN_RD_DTO_12_8 = ((256 * LdcSet.sV_ACTIVE) / LdcSet.sV_ACTIVE) >> 8;    
		
    rIP_LDC_TXCNT   = ((LdcSet.sH_ACTIVE + 2*LutSampling - 1) / (2*LutSampling)) * 2 + 1;   // horizontal samples count : ceil(WIDTH/2/DSTW)*2+1     
    rIP_LDC_TYCNT_1 = ((LdcSet.sV_ACTIVE + 2*LutSampling - 1) / (2*LutSampling)) * 2;      // vertical samples count - 1 : ceil(HEIGHT/2/DSTW)*2
    
    rIP_LDC_DSTW_1 = LutSampling - 1;                       
    rIP_LDC_DSTH_1 = LutSampling - 1;
	
    rIP_LDC_INCRW_7_0  = (0x8000 / LutSampling);                     
    rIP_LDC_INCRW_15_8 = (0x8000 / LutSampling) >> 8;               
    rIP_LDC_INCRH_7_0  = (0x8000 / LutSampling);                     
    rIP_LDC_INCRH_15_8 = (0x8000 / LutSampling) >> 8;               

    rIP_LDC_LUT_BURST_CTRL = LutSampling -1;  			
     			
    rIP_LDC_OUT_VBLANK_7_0   = (LdcSet.sV_BLANK - rIP_LDC_PRE_VSYNC_DELAY);                  
    rIP_LDC_OUT_VBLANK_15_8  = (LdcSet.sV_BLANK - rIP_LDC_PRE_VSYNC_DELAY) >> 8;            


    //==========================================================================
    // PIP Setting
    //==========================================================================

	switch(LdcSet.sPipType)
	{
		case PIP_TYPE_640_360_8 : LdcSet.sPipOutWidth = 640; LdcSet.sPipOutHeight = 360;	sPipMemWidth = 640 ; sPipMemHeight = 360 ;		break;
		case PIP_TYPE_480_270_8 : LdcSet.sPipOutWidth = 480; LdcSet.sPipOutHeight = 270;	sPipMemWidth = 640 ; sPipMemHeight = 360 ;		break;
		case PIP_TYPE_432_240_8 : LdcSet.sPipOutWidth = 432; LdcSet.sPipOutHeight = 240;	sPipMemWidth = 640 ; sPipMemHeight = 360 ;		break;
		case PIP_TYPE_426_240_8 : LdcSet.sPipOutWidth = 426; LdcSet.sPipOutHeight = 240;	sPipMemWidth = 640 ; sPipMemHeight = 360 ;		break;
		case PIP_TYPE_320_180_8 : LdcSet.sPipOutWidth = 320; LdcSet.sPipOutHeight = 180;	sPipMemWidth = 640 ; sPipMemHeight = 360 ;		break;
		case PIP_TYPE_216_120_8 : LdcSet.sPipOutWidth = 216; LdcSet.sPipOutHeight = 120;	sPipMemWidth = 640 ; sPipMemHeight = 360 ;		break;
		case PIP_TYPE_160_90_8  : LdcSet.sPipOutWidth = 160; LdcSet.sPipOutHeight = 90 ;	sPipMemWidth = 320 ; sPipMemHeight = 180 ;		break;
	}

	rIP_PIP_MEM_HWIDTH_7_0 = sPipMemWidth;         
    rIP_PIP_MEM_HWIDTH_9_8 = sPipMemWidth >> 8;    
    rIP_PIP_OUT_HWIDTH_7_0 = LdcSet.sPipOutWidth;         
    rIP_PIP_OUT_HWIDTH_9_8 = LdcSet.sPipOutWidth >> 8;    

    rIP_PIP_TXCNT   = ((LdcSet.sPipOutWidth  + 2*PipSampling - 1) / (2*PipSampling)) * 2 + 1;           
    rIP_PIP_TYCNT_1 = ((LdcSet.sPipOutHeight + 2*PipSampling - 1) / (2*PipSampling)) * 2;                  
                      
    rIP_PIP_DSTW_1  =  PipSampling - 1;                     
    rIP_PIP_DSTH_1  =  PipSampling - 1;                     
	
    rIP_PIP_INCRW_7_0  = (0x8000 / PipSampling);                   
    rIP_PIP_INCRW_15_8 = (0x8000 / PipSampling) >> 8;             
    rIP_PIP_INCRH_7_0  = (0x8000 / PipSampling);                   
    rIP_PIP_INCRH_15_8 = (0x8000 / PipSampling) >> 8;    
       				 
    rIP_PIP_HSCL_PIP_WR_DTO_7_0  = ((256 * LdcSet.sH_ACTIVE) / sPipMemWidth);               
    rIP_PIP_HSCL_PIP_WR_DTO_12_8 = ((256 * LdcSet.sH_ACTIVE) / sPipMemWidth) >> 8;         
    rIP_PIP_VSCL_PIP_WR_DTO_7_0  = ((256 * LdcSet.sV_ACTIVE) / sPipMemHeight);               
    rIP_PIP_VSCL_PIP_WR_DTO_12_8 = ((256 * LdcSet.sV_ACTIVE) / sPipMemHeight) >> 8;         
    rIP_PIP_HSCL_PIP_RD_DTO_7_0  = ((256 * sPipMemWidth) / LdcSet.sPipOutWidth);               
    rIP_PIP_HSCL_PIP_RD_DTO_12_8 = ((256 * sPipMemWidth) / LdcSet.sPipOutWidth) >> 8;         
    rIP_PIP_VSCL_PIP_RD_DTO_7_0  = ((256 * sPipMemHeight) / LdcSet.sPipOutHeight);               
    rIP_PIP_VSCL_PIP_RD_DTO_12_8 = ((256 * sPipMemHeight) / LdcSet.sPipOutHeight) >> 8;   
	      
    rIP_PIP_LUT_BURST_CTRL = PipSampling - 1;
 
    rIP_PIP_WMAIN_HPIXEL_7_0 = sPipMemWidth;                
    rIP_PIP_WMAIN_HPIXEL_9_8 = sPipMemWidth >> 8;         
    rIP_PIP_WMAIN_VLINE_7_0  = sPipMemHeight;                
    rIP_PIP_WMAIN_VLINE_9_8  = sPipMemHeight >> 8;           
    rIP_PIP_WMAIN_WLINE_7_0  = (sPipMemHeight * 2 + 16);                
    rIP_PIP_WMAIN_WLINE_11_8 = (sPipMemHeight * 2 + 16) >> 8;          
    rIP_PIP_RMAIN_HPIXEL_7_0 = sPipMemWidth;              
    rIP_PIP_RMAIN_HPIXEL_9_8 = sPipMemWidth >> 8;         
    rIP_PIP_RMAIN_VLINE_7_0  = sPipMemHeight;                
    rIP_PIP_RMAIN_VLINE_9_8  = sPipMemHeight >> 8;           
    rIP_PIP_RMAIN_WLINE_7_0  = (sPipMemHeight * 2 + 16);                
    rIP_PIP_RMAIN_WLINE_11_8 = (sPipMemHeight * 2 + 16) >> 8;          
    rIP_PIP_WMAIN_BURST_CTRL = PipSampling - 1;      
 
  	rIP_PIP_MEM_VHEIGHT_7_0 = sPipMemHeight;                
    rIP_PIP_MEM_VHEIGHT_9_8 = sPipMemHeight >> 8;           
    rIP_PIP_OUT_VHEIGHT_7_0 = LdcSet.sPipOutHeight;                
    rIP_PIP_OUT_VHEIGHT_9_8 = LdcSet.sPipOutHeight >> 8;           

    rIP_PIP_REG_UPDATE = 1;                          

	ncDrv_LutPip_SetEtc();
}

void ncDrv_LutPip_SetEtc(void)
{
#if 1
	UCHAR  cTmp	;
	USHORT sTmp ;
	USHORT sOotLineDelay;
	USHORT sPipStartY   ; 

	rIP_PIP_WMAIN_WRAP_INIT_EN = 0x01;

	if(IS_FHD_Size)
		rIP_PIP_WMAIN_WRAP_EN = 0x00;
	else
		rIP_PIP_WMAIN_WRAP_EN = 0x01;
		
	if(IS_WRAP)
	{
		rIP_LDC_OUT_LINE_DELAY_7_0	=	0x50;
		rIP_LDC_OUT_LINE_DELAY_15_8	=	0x00;
		rIP_LDC_WMAIN_WRAP_EN = 0x01;
		sTmp = LdcSet.sV_ACTIVE*2+32;
	}
	else
	{
		rIP_LDC_OUT_LINE_DELAY_7_0	=	0x50;
		rIP_LDC_OUT_LINE_DELAY_15_8	=	0x01;
		rIP_LDC_WMAIN_WRAP_EN = 0x00;
		sTmp = LdcSet.sV_ACTIVE;
	}

	rIP_LDC_IBUF_OVERFLOW =1;
	rIP_LDC_WMAIN_EN =1;

	rIP_LDC_RMAIN_BURST_CTRL = 0x05;
	rIP_LDC_WMAIN_BURST_CTRL = 0x07;
	
	rIP_LDC_WMAIN_WLINE_7_0		=	LOBYTE(sTmp);	
	rIP_LDC_WMAIN_WLINE_12_8 	=	HIBYTE(sTmp);
	rIP_LDC_RMAIN_WLINE_7_0		=	LOBYTE(sTmp);
	rIP_LDC_RMAIN_WLINE_12_8 	=	HIBYTE(sTmp);

	cTmp 		= rIP_PIP_YST_7_0;
	sPipStartY	= MAKEWORD(rIP_PIP_YST_10_8, cTmp);
	
	cTmp			=		   rIP_LDC_OUT_LINE_DELAY_7_0;
	sOotLineDelay	= MAKEWORD(rIP_LDC_OUT_LINE_DELAY_15_8 , cTmp );
	
	if( (sOotLineDelay + rIP_LDC_PRE_VSYNC_DELAY + sPipStartY + LdcSet.sPipOutHeight) < (LdcSet.sV_ACTIVE))
	{
		rIP_PIP_RMAIN_READ_MODE	= 0x00;
	}
	else
	{
		rIP_PIP_RMAIN_READ_MODE	= 0x01;
	}
#endif
}



void ncDrv_Ldc_Off(void)
{
	rIP_LDC_EN				=	0x00;
	rIP_LDC_READ_SYNC_MODE	=	0x00;
	rIP_YC_CROP_EN			=	0x00;
}

void ncDrv_Ldc_SetMode(void)
{
	switch(LdcSet.bMainEnable)
	{
		case eLDC_TYPE_OFF: 				
			rIP_LDC_BYPASS_EN = 0x01;	 
			break;	
		case eLDC_TYPE_NORMAL_LDC_ON: 		
			rIP_LDC_BYPASS_EN =	0x00;	 
			break;
	}
	
	rIP_LDC_MODE = 0x00;

	switch(LdcSet.bPipEnable)
	{
		case eLDC_TYPE_OFF: 				
			rIP_PIP_EN=	0x00;
			rIP_PIP_BYPASS_EN	=	0x00;	
			break;	
		case eLDC_TYPE_NORMAL_LDC_ON:		
			rIP_PIP_EN		=	0x01;
			rIP_PIP_BYPASS_EN	=	0x00;
			break;	
	}
		
	if(LdcSet.bMainEnable||LdcSet.bPipEnable)
	{
		rIP_YC_CROP_EN = 0x01;
		rIP_LDC_WMAIN_EN = 0x01;
		rIP_LDC_READ_SYNC_MODE=1;
		rIP_LDC_EN = 0x01;

		rIP_ENABLE_CVBS_FRC = 1;
	}
	else
	{
		rIP_LDC_EN = 0x00;
		rIP_LDC_READ_SYNC_MODE = 0x00;
		rIP_YC_CROP_EN = 0x00;
	}
}

INT32 ncLib_Ldc_Read(etLDC_READ_TYPE Cmd)
{
	const INT32 (*Read_func[eLDC_READ_MAX])(void)=
	{
		ncDrv_Ldc_Get_WrapLevel,
		ncDrv_Ldc_GetP_MainSizeH,
		ncDrv_Ldc_GetP_MainSizeV,
		ncDrv_Ldc_GetP_PipSizeH,
		ncDrv_Ldc_GetP_PipSizeV,
	};
	
	if(Cmd<eLDC_READ_MAX&&Read_func[Cmd]!=NULL)
		return Read_func[Cmd]();
	return NC_FAILURE;
}

INT32 ncLib_Ldc_Write(etLDC_WRITE_TYPE Cmd,INT32 value)
{
	const void (*Write_func[eLDC_WRITE_MAX])(INT32 val)=
	{
		ncDrv_Ldc_Set_LutBaseAddr,
		ncDrv_Ldc_SetSpiAddr,
		ncDrv_Ldc_SetMainEnable,
		ncDrv_Ldc_SetPipEnable,
		ncDrv_Ldc_SetMainNum0,
		ncDrv_Ldc_SetMainNum1,
		ncDrv_Ldc_SetPipNum0,
		ncDrv_Ldc_SetPipNum1,
		ncDrv_Ldc_SetMorphingMainEnable,
		ncDrv_Ldc_SetMorphingPipEnable,
		ncDrv_Ldc_SetMorphingMainRatio,
		ncDrv_Ldc_SetMorphingPipRatio,
		ncDrv_Ldc_SetPipPosX,
		ncDrv_Ldc_SetPipPosY,
	};

	if(Cmd<eLDC_WRITE_MAX&&Write_func[Cmd]!=NULL)
	{	
		Write_func[Cmd](value);
		return NC_SUCCESS;
	}
	return NC_FAILURE;
}

INT32 ncLib_Ldc_Control(etLDC_CMD_TYPE Cmd)
{
	const void (*Cmd_func[eLDC_MAX])(void)=
	{
		ncDrv_Lut_Init,
		NULL,//eLDC_SET
		NULL,//eLDC_TASK
		ncDrv_Ldc_Off,
		ncDrv_Lut_Pip_SetSize,
	};
	
	if(Cmd<eLDC_MAX&&Cmd_func[Cmd]!=NULL)
	{	
		Cmd_func[Cmd]();
		return NC_SUCCESS;
	}
	return NC_FAILURE;
}




