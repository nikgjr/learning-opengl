
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	File	: LSC_Drv.c		
*	Brief	: This file is LSC DRV for NEXTCHIP standard library
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2016.01.26		ktsyann	    1.0		Initial  Revision
********************************************************************************/
#include "API_GlobalHeader.h"
#include "Drv_GlobalHeader.h"

#define LSC_ON      0x01
#define LSC_OFF     0x00

//============================================================================
//      Function
//============================================================================
void ncDrv_LSC_Set(void)
{
	rIP_LSC_EN = rSWReg.Category.LSC.Reg.LSC_MODE ? LSC_ON : LSC_OFF;
}

void ncDrv_LSC_Auto(void)
{
    UCHAR AgcX0 = rSWReg.Category.LSC.Reg.LSC_AGC_X0;
    UCHAR AgcX1 = rSWReg.Category.LSC.Reg.LSC_AGC_X1;

    if(rSWReg.Category.LSC.Reg.LSC_MODE == STATE_OFF)  return;

    rIP_LSC_GR_GAIN = ncDrv_InterpAGC(AgcX0, AgcX1, rSWReg.Category.LSC.Reg.LSC_G_GAIN_Y0, rSWReg.Category.LSC.Reg.LSC_G_GAIN_Y1);
    rIP_LSC_R_GAIN  = ncDrv_InterpAGC(AgcX0, AgcX1, rSWReg.Category.LSC.Reg.LSC_R_GAIN_Y0, rSWReg.Category.LSC.Reg.LSC_R_GAIN_Y1);
    rIP_LSC_B_GAIN  = ncDrv_InterpAGC(AgcX0, AgcX1, rSWReg.Category.LSC.Reg.LSC_B_GAIN_Y0, rSWReg.Category.LSC.Reg.LSC_B_GAIN_Y1);
    rIP_LSC_GB_GAIN = ncDrv_InterpAGC(AgcX0, AgcX1, rSWReg.Category.LSC.Reg.LSC_G_GAIN_Y0, rSWReg.Category.LSC.Reg.LSC_G_GAIN_Y1); 
}

