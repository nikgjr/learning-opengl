
/********************************************************************************
*   Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*   Enviroment    : IAR Embedded Workbench IDE
*   Project       : APC28_EGT3 
********************************************************************************
*   History      : 
        CreationDate    Modify      Ver     Description
        -------------------------------------------------------
        2010.08.13      kysim       0.2     Initial  Revision
        2014.12.02      JWLee       1.0     Newly Generated     
        2015.04.01      jhchoi      1.1     NCFW Platform Revision
********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "API_GlobalHeader.h"
#include "SVC_GlobalHeader.h"
#include "Drv_GlobalHeader.h"
#include "ISP_Drv.h"
#include "BackLight_Drv.h"


//============================================================================
//      Extern Function Prototype
//============================================================================

//============================================================================
//      Function Prototype
//============================================================================
void Blc_Mirror(void);
void Blc_Flip(void);
void Hsblc_Mirror(void);
void Hsblc_Flip(void);

#define HLC_AREA_COUNT			4L
#define HLC_SW_AREA_START		ADDR_HSBLC_AREA1_X_7_0
#define HLC_SW_AREA_OFFSET	    8L
#define HLC_IP_AREA_OFFSET		9L

void Blc_Common(void)
{
	if(sMwAe.Tracking.OPDWeightMode == 2)
	{
		rIP_OPD_HL_START_X = rSWReg.Category.TDN.Reg.BW_IR_SMART_POS_X;
		rIP_OPD_HL_START_Y = rSWReg.Category.TDN.Reg.BW_IR_SMART_POS_Y;
	}
	else
	{
		rIP_OPD_HL_START_X = rSWReg.Category.BACKLIGHT.Reg.BLC_POSITION_X;
		rIP_OPD_HL_START_Y = rSWReg.Category.BACKLIGHT.Reg.BLC_POSITION_Y;
	}
}
//============================================================================
//      Function
//============================================================================
void ncDrv_Blc_Mirror(void)
{
	rSWReg.Category.TDN.Reg.BW_IR_SMART_POS_X = sMwOpd.Size.Width - rSWReg.Category.TDN.Reg.BW_IR_SMART_POS_X - rSWReg.Category.TDN.Reg.BW_IR_SMART_SIZE_X;
	rSWReg.Category.BACKLIGHT.Reg.BLC_POSITION_X = sMwOpd.Size.Width - rSWReg.Category.BACKLIGHT.Reg.BLC_POSITION_X - rSWReg.Category.BACKLIGHT.Reg.BLC_SIZE_X;

	Blc_Common();
}

void ncDrv_Blc_Flip(void)
{
	rSWReg.Category.TDN.Reg.BW_IR_SMART_POS_Y = sMwOpd.Size.Height - rSWReg.Category.TDN.Reg.BW_IR_SMART_POS_Y - rSWReg.Category.TDN.Reg.BW_IR_SMART_SIZE_Y;
	rSWReg.Category.BACKLIGHT.Reg.BLC_POSITION_Y = sMwOpd.Size.Height - rSWReg.Category.BACKLIGHT.Reg.BLC_POSITION_Y - rSWReg.Category.BACKLIGHT.Reg.BLC_SIZE_Y;

	Blc_Common();
}

void ncDrv_Hsblc_Mirror(void)
{
	USHORT XPos = 0, Width = 0;
	USHORT Mirror_XPos = 0;
	UCHAR Area = 0;
	USHORT SWAddrPosX, SWAddrSizeX;

	for(Area=0; Area<HLC_AREA_COUNT; Area++)
	{
		SWAddrPosX = ADDR_HSBLC_AREA1_X_7_0 + Area * HLC_SW_AREA_OFFSET;
		SWAddrSizeX = ADDR_HSBLC_AREA1_W_7_0 + Area * HLC_SW_AREA_OFFSET;
		
		XPos = ISPGET16(SWAddrPosX); 
		Width = ISPGET16(SWAddrSizeX); 

		Mirror_XPos = sGco.FrameSize.SizeH - XPos - Width;			

        ISPSET16(SWAddrPosX, Mirror_XPos); 
	}	
	
    ncDrv_HSBLC_ReSize();	
}

void ncDrv_Hsblc_Flip(void)
{
	USHORT YPos = 0, Height = 0;
	USHORT Flip_YPos = 0;
	UCHAR Area = 0;
	USHORT SWAddrPosY, SWAddrSizeY;

	for(Area=0; Area<HLC_AREA_COUNT; Area++)
	{
		SWAddrPosY = ADDR_HSBLC_AREA1_Y_7_0 + Area * HLC_SW_AREA_OFFSET;
		SWAddrSizeY = ADDR_HSBLC_AREA1_H_7_0 + Area * HLC_SW_AREA_OFFSET;

		YPos = ISPGET16(SWAddrPosY);
		Height = ISPGET16(SWAddrSizeY);

		Flip_YPos = sGco.FrameSize.SizeV - YPos - Height;			

		ISPSET16(SWAddrPosY, Flip_YPos);
	}
	
	ncDrv_HSBLC_ReSize();
}

void ncDrv_HSBLC_ReSize(void)
{
    typedef union{
        USHORT SIZE[4];
        struct{
            USHORT XPOS         :11;
            USHORT X0_RESERVE   :5;
            USHORT YPOS         :11;
            USHORT X1_RESERVE   :5;
            USHORT XSIZE        :11;
            USHORT Y0_RESERVE   :5;
            USHORT YSIZE        :11;
            USHORT Y1_RESERVE   :5;
        }Info;
    } STRUCT_HSBLC_SIZE;
    
    STRUCT_HSBLC_SIZE* HSBLCSize;
	UCHAR Area;
	BOOL AreaStatus = 0L;
	USHORT SizeX, SizeY;
	
	for(Area=0; Area<HLC_AREA_COUNT; Area++)
	{
        HSBLCSize = (STRUCT_HSBLC_SIZE*)(ADDR_HSBLC_AREA1_X_7_0 + (Area * HLC_SW_AREA_OFFSET));
        
		AreaStatus = BitCheck(rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN, Area);

		/* [2014/2/19] JWLee : AREA �켱������ ���� ��ġ�� ���� �������� ��������. OFF �� ������ SIZE '0' */
		if(AreaStatus)
		{
			SizeX = (OUTPUT_SIZE == INPUT_SIZE)? HSBLCSize->Info.XSIZE: (USHORT)((FLOAT)HSBLCSize->Info.XSIZE/1.5);
			SizeY = (OUTPUT_SIZE == INPUT_SIZE)? HSBLCSize->Info.YSIZE: (USHORT)((FLOAT)HSBLCSize->Info.YSIZE/1.5);
		}
		else
		{
			SizeX = 0;
			SizeY = 0;
		}

		ISPSET16((aIP_HLC_X0_START_7_0 + (Area * HLC_IP_AREA_OFFSET)), ((OUTPUT_SIZE == INPUT_SIZE)? (HSBLCSize->Info.XPOS + (H_ACTIVE_OFFSET>>1)) : (USHORT)((FLOAT)(HSBLCSize->Info.XPOS + (H_ACTIVE_OFFSET>>1))/1.5)));
        ISPSET16((aIP_HLC_Y0_START_7_0 + (Area * HLC_IP_AREA_OFFSET)), ((OUTPUT_SIZE == INPUT_SIZE)? HSBLCSize->Info.YPOS : (USHORT)((FLOAT)HSBLCSize->Info.YPOS/1.5)));
        ISPSET16((aIP_HLC_X0_WIDTH_7_0 + (Area * HLC_IP_AREA_OFFSET)), SizeX);
        ISPSET16((aIP_HLC_Y0_HEIGHT_7_0 + (Area * HLC_IP_AREA_OFFSET)), SizeY);
	}
}

void ncDrv_Backlight_Mode_Set(void)
{
#define BLC_AREA_MIN		1L
#define HLC_ATTR_DEFAULT	0x03
#define HLC_AREA1		0x1
#define HLC_AREA2		0x2
#define HLC_AREA3		0x4
#define HLC_AREA4		0x8


	UCHAR MaskBlack = 0L;

	//_____BLC OFF __________________
	if(rSWReg.Category.BACKLIGHT.Reg.BACKLIGHT_MODE != eBACKLIGHT_BLC)
	{
		if(rIP_OPD_GRID_EN == STATE_ON)
		{
			rIP_OPD_GRID_EN= STATE_OFF;
			rSWReg.Category.BACKLIGHT.Reg.BLC_GRID_EN = STATE_OFF;		//FOR OSD. JIG? Hmm.....
		}
	}

	//_____HSBLC OFF __________________
	if(rSWReg.Category.BACKLIGHT.Reg.BACKLIGHT_MODE != eBACKLIGHT_HSBLC)
	{
		rIP_HLC_MIX_EN = STATE_OFF;
	}
	//_____WDR OFF __________________
	if(rSWReg.Category.BACKLIGHT.Reg.BACKLIGHT_MODE != eBACKLIGHT_WDR)
	{
		rSWReg.Category.WDR.Reg.WDR_MODE = STATE_OFF;
	}

	//_____BLC or HSBLC == ON __________________
	if(rSWReg.Category.BACKLIGHT.Reg.BACKLIGHT_MODE == eBACKLIGHT_BLC)
	{
		/* [2014/2/19] JWLee : IR SMART �� BLC ���û�� �Ұ�(OSD '---' ǥ��) */
		if(ncDrv_TdnStatus_Get() == DN_STATUS_BW && rSWReg.Category.TDN.Reg.BW_IR_SMART == STATE_ON)  return;
        ncLib_OpdGrid_Set(
                        rSWReg.Category.BACKLIGHT.Reg.BLC_GRID_EN,
						rSWReg.Category.BACKLIGHT.Reg.BLC_POSITION_X,
						rSWReg.Category.BACKLIGHT.Reg.BLC_POSITION_Y,
						rSWReg.Category.BACKLIGHT.Reg.BLC_SIZE_X,
						rSWReg.Category.BACKLIGHT.Reg.BLC_SIZE_Y);
	}
	else if(rSWReg.Category.BACKLIGHT.Reg.BACKLIGHT_MODE == eBACKLIGHT_HSBLC)
	{
		rIP_HLC_MIX_EN = STATE_ON;

		rIP_HLC_MIX_VISUAL_EN  = rSWReg.Category.BACKLIGHT.Reg.HSBLC_MASK_EN;

		if(rSWReg.Category.BACKLIGHT.Reg.HSBLC_MODE == eHSBLCMODE_ALLDAY || rSWReg.Category.AE.Reg.AGC_MODE == eAGC_MODE_OFF)
			MaskBlack = 0x03;		 /* [2014/2/19] JWLee : pBACKLIGHT->Byte.HSBLC_MODE == eHSBLCMODE_ALLDAY : ON/OFF ��ȯ�� ������ ���� */
		else
			MaskBlack = 0x02;

		rIP_HLC_PIX_TH = (UCHAR)((float)rSWReg.Category.BACKLIGHT.Reg.HSBLC_LEVEL * 2.55);

		if((rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN & HLC_AREA1) == HLC_AREA1)
			rIP_HLC_ATTR0 = MaskBlack | (rSWReg.Category.BACKLIGHT.Reg.HSBLC_GRID_EN<<2L);
		else		rIP_HLC_ATTR0 = 0x02;

		if((rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN & HLC_AREA2) == HLC_AREA2)
			rIP_HLC_ATTR1 = MaskBlack | (rSWReg.Category.BACKLIGHT.Reg.HSBLC_GRID_EN<<2L);
		else		rIP_HLC_ATTR1 = 0x02;

		if((rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN & HLC_AREA3) == HLC_AREA3)
			rIP_HLC_ATTR2 = MaskBlack | (rSWReg.Category.BACKLIGHT.Reg.HSBLC_GRID_EN<<2L);
		else		rIP_HLC_ATTR2 = 0x02;

		if((rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN & HLC_AREA4) == HLC_AREA4)
			rIP_HLC_ATTR3 = MaskBlack | (rSWReg.Category.BACKLIGHT.Reg.HSBLC_GRID_EN<<2L);
		else		rIP_HLC_ATTR3 = 0x02;

		switch(rSWReg.Category.BACKLIGHT.Reg.HSBLC_SEL_AREA)
		{
			case 0:	rIP_HLC_ATTR0 |= 0x08;		break;
			case 1:	rIP_HLC_ATTR1 |= 0x08;		break;
			case 2:	rIP_HLC_ATTR2 |= 0x08;		break;
			case 3:	rIP_HLC_ATTR3 |= 0x08;		break;
		}

		ncDrv_HSBLC_ReSize();
	}
	else if(rSWReg.Category.BACKLIGHT.Reg.BACKLIGHT_MODE == eBACKLIGHT_WDR)
	{
	    rSWReg.Category.WDR.Reg.WDR_MODE = STATE_ON;
	}

	ncSvc_WDR_Mode_Set(rSWReg.Category.WDR.Reg.WDR_MODE);

	return;
	
}

void ncDrv_HSBLC_Auto(void)
{
	/* [2014/1/6] JWLee:  HLC_MIX_VISUAL_EN �� on/off �ϸ� �ȵȴ�. 
	HLC_MIX_VISUAL_EN �� masking black �� �ƴ϶� outline �� off ���� ������ ������ osd �� ���ýÿ� outline�� �������� �� ���� */

	if(rSWReg.Category.BACKLIGHT.Reg.BACKLIGHT_MODE != eBACKLIGHT_HSBLC)	return;
	
	if(rSWReg.Category.BACKLIGHT.Reg.HSBLC_MODE == eHSBLCMODE_ALLDAY || rSWReg.Category.AE.Reg.AGC_MODE == eAGC_MODE_OFF)	 /* [2014/2/24] JWLee : AGC_MODE�� '0'�̸� ������ ALL DAY MODE */
	{
		BitCheck(rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN, 0L) ? BitSet(rBank05->Byte.Reg_0x054B.D8, 0L) : BitClear(rBank05->Byte.Reg_0x054B.D8, 0L);
		BitCheck(rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN, 1L) ? BitSet(rBank05->Byte.Reg_0x0554.D8, 0L) : BitClear(rBank05->Byte.Reg_0x0554.D8, 0L);
		BitCheck(rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN, 2L) ? BitSet(rBank05->Byte.Reg_0x055D.D8, 0L) : BitClear(rBank05->Byte.Reg_0x055D.D8, 0L);
		BitCheck(rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN, 3L) ? BitSet(rBank05->Byte.Reg_0x0566.D8, 0L) : BitClear(rBank05->Byte.Reg_0x0566.D8, 0L);			
	}
	else		 /* [2014/2/19] JWLee : eHSBLCMODE_NIGHT */
	{
		if(rIP_AGC_LEVEL_7_0 >= rSWReg.Category.BACKLIGHT.Reg.HSBLC_MODE_AGC_TH)
		{
			BitCheck(rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN, 0L) ? BitSet(rBank05->Byte.Reg_0x054B.D8, 0L) : BitClear(rBank05->Byte.Reg_0x054B.D8, 0L);
			BitCheck(rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN, 1L) ? BitSet(rBank05->Byte.Reg_0x0554.D8, 0L) : BitClear(rBank05->Byte.Reg_0x0554.D8, 0L);
			BitCheck(rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN, 2L) ? BitSet(rBank05->Byte.Reg_0x055D.D8, 0L) : BitClear(rBank05->Byte.Reg_0x055D.D8, 0L);
			BitCheck(rSWReg.Category.BACKLIGHT.Reg.HSBLC_DISPLAY_EN, 3L) ? BitSet(rBank05->Byte.Reg_0x0566.D8, 0L) : BitClear(rBank05->Byte.Reg_0x0566.D8, 0L);
		}
		else												
		{
			BitClear(rBank05->Byte.Reg_0x054B.D8, 0);
			BitClear(rBank05->Byte.Reg_0x0554.D8, 0);
			BitClear(rBank05->Byte.Reg_0x055D.D8, 0);
			BitClear(rBank05->Byte.Reg_0x0566.D8, 0);				
		}
	}
}


