
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Drv_GlobalHeader.h"
//#include "ISP_Drv.h"
//#include "Opd_Drv.h"

#if 0
#define aIP_OPD_BLOCK_R         0x0A00
#define aIP_OPD_BLOCK_G         0x0A40
#define aIP_OPD_BLOCK_B         0x0A80
#define aIP_OPD_BLOCK_Y         0x0AC0
#define aIP_OPD_BLOCK_RATIO     0x0C00
#define aIP_OPD_BLOCKs_R        0x0B00
#define aIP_OPD_BLOCKs_G        0x0B40
#define aIP_OPD_BLOCKs_B        0x0B80
#define aIP_OPD_BLOCKs_Y        0x0BC0
#define aIP_OPD_BLOCKs_RATIO    0x0C40
#endif
STRUCT_MW_OPD		sMwOpd;

extern void CIExy_Get(STRUCT_OPD_RGB * Opd, STRUCT_CIE_XY * CieXY);
//============================================================================
//      Function Prototype
//============================================================================
extern void Debug_Viewer_WB1(void);
extern void Debug_Viewer_WB(void);
extern void Debug_Viewer_AELib(void);
extern void Debug_Viewer_WDR_AE(void);
//============================================================================
//      Function
//============================================================================
void ncLib_OpdGrid_Set(UCHAR Grid, UCHAR PositionX, UCHAR PositionY, UCHAR BlcSizeX, UCHAR BlcSizeY)
{
	rIP_OPD_GRID_EN = Grid;

	rIP_OPD_HL_START_X	= PositionX;
	rIP_OPD_HL_START_Y	= PositionY;
	rIP_OPD_HL_WIDTH_X	= BlcSizeX;
	rIP_OPD_HL_HEIGHT_Y	= BlcSizeY;
}

BOOL OPD_Validation_Check(UCHAR OpdNum)
{
#define OPD_COUNT_LINE  8L

    UCHAR BitIdx = OpdNum % OPD_COUNT_LINE;
    UCHAR AddrOffset = OpdNum / OPD_COUNT_LINE;
    UCHAR RectStatus = ISPGET08(aIP_OPD_DIV_ZERO_MAP_7_0 + AddrOffset);
    UCHAR ValidYMap = ISPGET08(aIP_OPD_BLOCK_CNT_VALID_7_0 + AddrOffset);

    if(BitCheck(ValidYMap, BitIdx))
    {
        if(BitCheck(RectStatus, BitIdx)) 
                return FALSE; 
        else    return TRUE;
    }
    else
        return FALSE;

#undef OPD_COUNT_LINE
}

BOOL OPD_Validation_CheckS(UCHAR OpdNum)
{
#define OPD_COUNT_LINE  8L

    UCHAR BitIdx = OpdNum % OPD_COUNT_LINE;
    UCHAR AddrOffset = OpdNum / OPD_COUNT_LINE;
    UCHAR RectStatus = ISPGET08(aIP_OPD_DIV_ZERO_MAP_S_7_0 + AddrOffset);
    UCHAR ValidYMap = ISPGET08(aIP_OPD_BLOCK_CNT_VALID_S_7_0 + AddrOffset);

    if(BitCheck(ValidYMap, BitIdx))
    {
        if(BitCheck(RectStatus, BitIdx)) 
                return FALSE; 
        else    return TRUE;
    }
    else
        return FALSE;

#undef OPD_COUNT_LINE
}


void OPD_Get_RGBY(void)
{

#define RECT_CNT_LIMIT      3L

    STRUCT_OPD_RGB Opd;
    STRUCT_CIE_XY CIExy;

	UCHAR OpdNum;
	UCHAR OpdY;
	UCHAR ValidCnt=0;
    USHORT SumY=0;
    USHORT SumRatioR=0, SumRatioB=0, AllSumRatioR=0, AllSumRatioB=0;
    ULONG SumCIEx = 0, SumCIEy = 0, AllSumCIEx = 0, AllSumCIEy = 0;
	USHORT ColorExcept_X = ISPGET16(ADDR_ATW_COLOREXCEPT_CIE_X_7_0);
						   //REGRW16(APACHE_ISP_BASE, ADDR_ATW_COLOREXCEPT_CIE_X_7_0);
	USHORT ColorExcept_Y = ISPGET16(ADDR_ATW_COLOREXCEPT_CIE_Y_7_0);
						   //REGRW16(APACHE_ISP_BASE, ADDR_ATW_COLOREXCEPT_CIE_Y_7_0);
    UCHAR ExcludeColorCnt=0;
    UCHAR RectNumber = 0;
    UCHAR RectCnt = 0;
    UCHAR OpdRatioR, OpdRatioB;
    USHORT AllSumCIExMSB = 0, AllSumCIExLSB = 0;
    USHORT AllSumCIEyMSB = 0, AllSumCIEyLSB = 0;
    USHORT SumCIExMSB = 0, SumCIExLSB = 0;
    USHORT SumCIEyMSB = 0, SumCIEyLSB = 0;
    
	sMwOpd.OpdYCnt = 0;

	for(OpdNum=0; OpdNum<sMwOpd.Size.Total; OpdNum++)
	{
	    SumY += OpdY = ISPGET08(aIP_OPD_BLOCK_Y + OpdNum);
        Opd.R = ISPGET08(aIP_OPD_BLOCK_R + OpdNum);
        Opd.G = ISPGET08(aIP_OPD_BLOCK_G + OpdNum);
        Opd.B = ISPGET08(aIP_OPD_BLOCK_B + OpdNum);
        
        if(OPD_Validation_Check(OpdNum))
	    {
	        RectNumber = ISPGET08(aIP_OPD_INC_IDX0 + OpdNum);
	        RectCnt = ISPGET08(aIP_OPD_INC_CNT0 + RectNumber);

            if((RectCnt > RECT_CNT_LIMIT) || (ncSvc_WBRect_Status() == STATE_OFF))
            {
                ISPSET16(aIP_DIVIDEND_7_0, (Opd.R*100));
            	ISPSET16(aIP_DIVISOR_7_0, Opd.G);
            	OpdRatioR = ISPGET16(aIP_DIV_QUOTIENT_7_0);

                ISPSET16(aIP_DIVIDEND_7_0, (Opd.B*100));
            	ISPSET16(aIP_DIVISOR_7_0, Opd.G);
                OpdRatioB = ISPGET16(aIP_DIV_QUOTIENT_7_0);
        
                CIExy_Get(&Opd, &CIExy);
                
    	        ValidCnt++;
                AllSumRatioR += OpdRatioR;
                AllSumRatioB += OpdRatioB;
                
                AllSumCIExMSB += (CIExy.Xpos>>8);
                AllSumCIExLSB += (CIExy.Xpos&0xFF);
                AllSumCIEyMSB += (CIExy.Ypos>>8);
                AllSumCIEyLSB += (CIExy.Ypos&0xFF);
                
    			if((CIExy.Xpos > ColorExcept_X)&&(CIExy.Ypos > ColorExcept_Y))  /* Exclude Color Area */
    			{
    				ExcludeColorCnt++;
    			}
    			else
    			{
    			    /* White balance calculations of areas unmentioned */	
                    SumRatioR += OpdRatioR;
                    SumRatioB += OpdRatioB;

                    SumCIExMSB += (CIExy.Xpos>>8);
                    SumCIExLSB += (CIExy.Xpos&0xFF);
                    SumCIEyMSB += (CIExy.Ypos>>8);
                    SumCIEyLSB += (CIExy.Ypos&0xFF);				
    			}
            }
	    }
	    
		if(OpdY <= rSWReg.Category.GAMMA.Reg.Y_GAMMA_ALPHA_TH)    sMwOpd.OpdYCnt++;
	}

	AllSumCIEx = AllSumCIExMSB;
	AllSumCIEx = (AllSumCIEx << 8) + AllSumCIExLSB;
	AllSumCIEy = AllSumCIEyMSB;
	AllSumCIEy = (AllSumCIEy << 8) + AllSumCIEyLSB;

	SumCIEx = SumCIExMSB;
	SumCIEx = (SumCIEx << 8) + SumCIExLSB;
	SumCIEy = SumCIEyMSB;
	SumCIEy = (SumCIEy << 8) + SumCIEyLSB;

    #if 0
	ncLib_DEBUG_Printf(1, "[0x%s",  (USHORT)(AllSumCIEx>>16)  );
	ncLib_DEBUG_Printf(1, "%s, ",  (USHORT)(AllSumCIEx&0xFFFF)  );
	ncLib_DEBUG_Printf(1, "0x%s",  (USHORT)(Test1>>16)  );
	ncLib_DEBUG_Printf(1, "%s], ",  (USHORT)(Test1&0xFFFF)  );

	ncLib_DEBUG_Printf(1, "[0x%s",  (USHORT)(AllSumCIEy>>16)  );
	ncLib_DEBUG_Printf(1, "%s, ",  (USHORT)(AllSumCIEy&0xFFFF)  );
	ncLib_DEBUG_Printf(1, "0x%s",  (USHORT)(Test2>>16)  );
	ncLib_DEBUG_Printf(1, "%s], ",  (USHORT)(Test2&0xFFFF)  );
	
	ncLib_DEBUG_Printf(1, "[0x%s",  (USHORT)(SumCIEx>>16)  );
	ncLib_DEBUG_Printf(1, "%s, ",  (USHORT)(SumCIEx&0xFFFF)  );
	ncLib_DEBUG_Printf(1, "0x%s",  (USHORT)(Test3>>16)  );
	ncLib_DEBUG_Printf(1, "%s], ",  (USHORT)(Test3&0xFFFF)  );

	ncLib_DEBUG_Printf(1, "[0x%s",  (USHORT)(SumCIEy>>16)  );
	ncLib_DEBUG_Printf(1, "%s, ",  (USHORT)(SumCIEy&0xFFFF)  );
	ncLib_DEBUG_Printf(1, "0x%s",  (USHORT)(Test4>>16)  );
	ncLib_DEBUG_Printf(1, "%s] \n",  (USHORT)(Test4&0xFFFF)  );
    #endif
    #if(SENSOR_SELECT == OMNIVISION_OV10640 && OPTION_WDR_TYPE == WDRTYPE_DCOMP_OV)
    if(sWdr.Mode)
	sMwOpd.Data.NormalAvgY = ncDrv_Divider(SumY , OPD_GRID_CNT);
    else
	sMwOpd.Data.AvgY = ncDrv_Divider(SumY , OPD_GRID_CNT);
    #else
	sMwOpd.Data.AvgY = ncDrv_Divider(SumY , OPD_GRID_CNT);    
	#endif
	
    sMwOpd.Data.VALID_CNT = ValidCnt;
    sMwOpd.Data.Ratio.R   = ncDrv_Divider(AllSumRatioR, ValidCnt);
    sMwOpd.Data.Ratio.B   = ncDrv_Divider(AllSumRatioB, ValidCnt);
    sMwOpd.Data.Cie.Xpos  = AllSumCIEx / ValidCnt;
    sMwOpd.Data.Cie.Ypos  = AllSumCIEy / ValidCnt;

    /* Color Exception Area Count*/
    sMwOpd.Data.ExcludeColor_CNT = ExcludeColorCnt;

    /* White balance calculations of areas unmentioned */
    sMwOpd.Data.Ratio.UnmentionedArea_R  = ncDrv_Divider(SumRatioR, (ValidCnt - ExcludeColorCnt));
    sMwOpd.Data.Ratio.UnmentionedArea_B  = ncDrv_Divider(SumRatioB, (ValidCnt - ExcludeColorCnt));
    sMwOpd.Data.Cie.UnmentionedArea_Xpos = SumCIEx / (ValidCnt - ExcludeColorCnt);
    sMwOpd.Data.Cie.UnmentionedArea_Ypos = SumCIEy / (ValidCnt - ExcludeColorCnt);
}

void OPD_Get_RGBYm(void)
{

	UCHAR OpdNum;
	UCHAR OpdY, OpdR, OpdG, OpdB;
	UCHAR ValidCnt=0;
    USHORT SumY=0;
    USHORT SumRatioR=0, SumRatioB=0;
	
	for(OpdNum=0; OpdNum<sMwOpd.Size.Total; OpdNum++)
	{
	    OpdY = ISPGET08(aIP_OPD_BLOCKs_Y + OpdNum);
        OpdR = ISPGET08(aIP_OPD_BLOCKs_R + OpdNum);
        OpdG = ISPGET08(aIP_OPD_BLOCKs_G + OpdNum);
        OpdB = ISPGET08(aIP_OPD_BLOCKs_B + OpdNum);

	    OPD_GRID_VALIDTION_SETs(OpdNum, OPD_Validation_CheckS(OpdNum));
	    
	    if(OPD_GRID_VALIDTION_CHECKs(OpdNum))
	    {
	        ValidCnt++;
            SumRatioR += ncDrv_Divider(((USHORT)OpdR*100), OpdG);
            SumRatioB += ncDrv_Divider(((USHORT)OpdB*100), OpdG);
	    }
        SumY += OpdY;
	}

    sMwOpd.DataM.VALID_CNT = ValidCnt;
	sMwOpd.DataM.AvgY = SumY / OPD_GRID_CNT;
    sMwOpd.DataM.Ratio.R = SumRatioR / ValidCnt;
    sMwOpd.DataM.Ratio.B = SumRatioB / ValidCnt;
}

void OPD_Get_RGBYs(void)
{
	UCHAR OpdNum;
	UCHAR OpdY, OpdR, OpdG, OpdB;
	UCHAR ValidCnt=0;
    USHORT SumY=0;
    USHORT SumRatioR=0, SumRatioB=0;

    UCHAR HistoUpperBound = rSWReg.Category.WDR.Reg.WDR_WEIGHT_START_S;
    USHORT HistoUpperAcc=0;
    UCHAR HistoUpperCnt=0;
    USHORT HistoUpperAvg=0;
    UCHAR WeightYs=100; 
    USHORT CurrYs=0;
    
	for(OpdNum=0; OpdNum<sMwOpd.Size.Total; OpdNum++)
	{
	    OpdY = ISPGET08(aIP_OPD_BLOCKs_Y + OpdNum);
        OpdR = ISPGET08(aIP_OPD_BLOCKs_R + OpdNum);
        OpdG = ISPGET08(aIP_OPD_BLOCKs_G + OpdNum);
        OpdB = ISPGET08(aIP_OPD_BLOCKs_B + OpdNum);

        if(OpdY >= HistoUpperBound)
        {
            HistoUpperAcc+=OpdY;
            HistoUpperCnt++;
        }

	    OPD_GRID_VALIDTION_SETs(OpdNum, OPD_Validation_CheckS(OpdNum));

	    if(OPD_GRID_VALIDTION_CHECKs(OpdNum))
	    {
	        ValidCnt++;
            SumRatioR += ncDrv_Divider((USHORT)(OpdR*100), OpdG);
            SumRatioB += ncDrv_Divider((USHORT)(OpdB*100), OpdG);
	    }
        SumY += OpdY;
	}

    sMwOpd.DataS.VALID_CNT = ValidCnt;
	sMwOpd.DataS.AvgY = SumY / OPD_GRID_CNT;
    sMwOpd.DataS.Ratio.R = (SumRatioR / ValidCnt);
    sMwOpd.DataS.Ratio.B = (SumRatioB / ValidCnt);

    if(HistoUpperCnt !=0)   HistoUpperAvg = HistoUpperAcc / HistoUpperCnt;
    else                    HistoUpperAvg = HistoUpperBound;

    WeightYs += ncDrv_Interp(HistoUpperAvg, HistoUpperBound, 0xFF, 0, 90);

    CurrYs = (sMwOpd.DataS.AvgY * WeightYs)/100;

//    sMwOpd.HistogramS.WeightY = (CurrYs > 0xFF) ? 0xFF : CurrYs;
    
    if(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER == 13)    
    {
/* [2015/8/25] JWLee */ 
//            APP_OSDPrint_Dec(19, 21, HistoUpperAcc);
//            APP_OSDPrint_Dec(19, 26, HistoUpperCnt);
//            APP_OSDPrint_Hex(20, 21, HistoUpperBound);
//            APP_OSDPrint_Hex(20, 26, HistoUpperAvg);
//            APP_OSDPrint_Hex(21, 21, sMwOpd.DataS.AvgY);
//            APP_OSDPrint_Hex(21, 26, sMwOpd.HistogramS.WeightY);
//            APP_OSDPrint_Dec(21, 31, WeightYs);    
    }
}

void OPD_Get_WeightedYs(void)
{
    static BUFFER_AVERAGE_TYPE WeightBuffs={0U,};
    static BUFFER_AVERAGE_TYPE WeightBuffm={0U,};    
    USHORT CurrYs=0;
    USHORT CurrYm=0;
    UCHAR HistoWeight=100;
    UCHAR WeightYs; 
    UCHAR WeightYm;     
    UCHAR Weight1=0,Weight2=0,Weight3=0,Weight4=0,Weight5=0;
                                
    if(ISPGET08(aIP_OPD_HISTO_AVG0_S_7_0+15)!=0)    Weight1 = ncDrv_Interp(ISPGET08(aIP_OPD_HISTO_AVG0_S_7_0+15), 0xF0, 0xFF, 1, 30);
    if(ISPGET08(aIP_OPD_HISTO_AVG0_S_7_0+14)!=0)    Weight2 = ncDrv_Interp(ISPGET08(aIP_OPD_HISTO_AVG0_S_7_0+14), 0xE0, 0xEF, 1, 20);
    if(ISPGET08(aIP_OPD_HISTO_AVG0_S_7_0+13)!=0)    Weight3 = ncDrv_Interp(ISPGET08(aIP_OPD_HISTO_AVG0_S_7_0+13), 0xD0, 0xDF, 1, 15);
    if(ISPGET08(aIP_OPD_HISTO_AVG0_S_7_0+12)!=0)    Weight4 = ncDrv_Interp(ISPGET08(aIP_OPD_HISTO_AVG0_S_7_0+12), 0xC0, 0xCF, 1, 10);
    if(ISPGET08(aIP_OPD_HISTO_AVG0_S_7_0+11)!=0)    Weight5 = ncDrv_Interp(ISPGET08(aIP_OPD_HISTO_AVG0_S_7_0+11), 0xB0, 0xBF, 1, 5);

    HistoWeight += Weight1+Weight2+Weight3+Weight4+Weight5;

    if(sWdr.Ctrl.B8.OpdToggleMode == eWDR_OPD_TOGGLE_ON)
    {
        if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_SHORT)
        {
            WeightYs = ncDrv_BufferAvg_Get(&WeightBuffs, 16U, HistoWeight);
            CurrYs = (sMwOpd.DataS.AvgY * WeightYs)/100;
            sMwOpd.HistogramS.WeightY = (CurrYs > 0xFF) ? 0xFF : CurrYs; 
            sMwOpd.HistogramS.WeightRatio = WeightYs;
        }
        else 
        {
            WeightYm = ncDrv_BufferAvg_Get(&WeightBuffm, 16U, HistoWeight);
            CurrYm = (sMwOpd.DataM.AvgY * WeightYm)/100;
            sMwOpd.HistogramM.WeightY = (CurrYm > 0xFF) ? 0xFF : CurrYm;
            sMwOpd.HistogramM.WeightRatio = WeightYm; 
        }
    }
    
    if(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER == 13U)
    {
        APP_OSDPrint_Hex(20, 21, Weight5);
        APP_OSDPrint_Hex(20, 24, Weight4);
        APP_OSDPrint_Hex(20, 27, Weight3);
        APP_OSDPrint_Hex(20, 30, Weight2);
        APP_OSDPrint_Hex(20, 33, Weight1);    

        APP_OSDPrint_Hex(21, 21, sMwOpd.DataS.AvgY);
        APP_OSDPrint_Hex(21, 24, sMwOpd.HistogramS.WeightY);
        APP_OSDPrint_Dec(21, 27, WeightYs);
        APP_OSDPrint_Dec(21, 32, HistoWeight);
    }
}

void OPD_Histogram_Accumlate(void)
{
#define HISTMAXCNT 256
    UCHAR HistoIdx;
    UCHAR HistoRatioL = 0, HistoRatioS = 0;
    UCHAR Percentage = 0;
    UCHAR SpotArea = 0, HistoLowArea = 0, HistoMidArea = 0, HistoHighArea = 0, HistoAreaDiff = 0;
    UCHAR SpotAreaS = 0, HistoLowAreaS = 0, HistoMidAreaS = 0, HistoHighAreaS = 0;
    UCHAR HistWeight[3] = {1, 1, 1}, Weight;
    UCHAR WeightPeriod[3] = {0, 10, 14};
    USHORT TempSum = 0;
    ULONG Sum = 0, CntSum = 0, AvrY;
    FLOAT WeightY = 0;
                            // x1,    x2,    x3,    x4,    x5,    x6,    x7,    x8,    x9,   x10
    FLOAT WeightMax[10] = {1.000, 0.500, 0.333, 0.250, 0.200, 0.166, 0x142, 0.125, 0.111, 0.100};

	for(HistoIdx=0; HistoIdx < OPD_HISTROGRAM_CNT ; HistoIdx++)
	{
#if(SENSOR_SELECT == OMNIVISION_OV10640 && OPTION_WDR_TYPE == WDRTYPE_DCOMP_OV)
    if(sWdr.Mode)
    {
		TempSum = ISPGET08(aIP_OPD_HISTO_RATIO0_7_0 + HistoIdx);
		Weight = ncDrv_InterpTbl08(HistoIdx, WeightPeriod, HistWeight, 3L);
		//CntSum += (ULONG)(Weight* TempSum);
		Sum += (ULONG)(Weight * TempSum * (16*(HistoIdx + 1)));
    }
    else    
    {
	    HistoRatioL = ISPGET08(aIP_OPD_HISTO_RATIO0_7_0 + HistoIdx);
        Percentage = ncDrv_Divider((USHORT)(HistoRatioL*100), 255);

        if(HistoIdx < eHISTOGRAM_IDX_02)        HistoLowArea += Percentage;
        else if(HistoIdx > eHISTOGRAM_IDX_13)   HistoHighArea += Percentage;
        else                                    HistoMidArea += Percentage;
        
        if(HistoIdx > eHISTOGRAM_IDX_11)       SpotArea += Percentage;
    }
#else
	    HistoRatioL = ISPGET08(aIP_OPD_HISTO_RATIO0_7_0 + HistoIdx);
        Percentage = ncDrv_Divider((USHORT)(HistoRatioL*100), 255);


        if(HistoIdx < eHISTOGRAM_IDX_02)        HistoLowArea += Percentage;
        else if(HistoIdx > eHISTOGRAM_IDX_13)   HistoHighArea += Percentage;
        else                                    HistoMidArea += Percentage;
        
        if(HistoIdx > eHISTOGRAM_IDX_11)       SpotArea += Percentage;    
#endif
    }

#if(SENSOR_SELECT == OMNIVISION_OV10640 && OPTION_WDR_TYPE == WDRTYPE_DCOMP_OV)
	AvrY = (ULONG)Sum/HISTMAXCNT;
	sMwOpd.Data.AvgY = (AvrY>0xFF) ? 0xFF : AvrY;
#endif
    HistoAreaDiff = HistoLowArea + HistoHighArea;
	
    WeightY = ncDrv_Transition(HistoAreaDiff, 
                rSWReg.Category.WDR.Reg.WDR_WEIGHT_START_L,
                rSWReg.Category.WDR.Reg.WDR_WEIGHT_END_L, 
                1.00,  
                WeightMax[rSWReg.Category.WDR.Reg.WDR_WEIGHT_LIMIT_L]);

    sMwOpd.Histogram.WeightY = (UCHAR)((FLOAT)sMwOpd.Data.AvgY * WeightY);
    
    if(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER == 13)    
    {

        APP_OSDPrint_Dec(18, 1, (USHORT)HistoLowArea);
        APP_OSDPrint_Dec(18, 6, (USHORT)HistoMidArea);
        APP_OSDPrint_Dec(18, 11, (USHORT)HistoHighArea);
        
        APP_OSDPrint_Dec(19, 1, (USHORT)HistoAreaDiff);
        APP_OSDPrint_Dec(19, 6, (USHORT)(WeightY*100));
        APP_OSDPrint_Dec(19, 11, (USHORT)SpotArea);
        
        APP_OSDPrint_Hex(20, 1, (USHORT)sMwOpd.Data.AvgY);
        APP_OSDPrint_Hex(20, 6, (USHORT)sMwOpd.Histogram.WeightY);

    }

    if(sWdr.Mode == STATE_ON)
    {
        sMwOpd.Histogram.Highlight = 0;
        sMwOpd.Histogram.Highlight += ISPGET08(aIP_OPD_HISTO_RATIO0_7_0+12);
        sMwOpd.Histogram.Highlight += ISPGET08(aIP_OPD_HISTO_RATIO0_7_0+13);
        sMwOpd.Histogram.Highlight += ISPGET08(aIP_OPD_HISTO_RATIO0_7_0+14);
        sMwOpd.Histogram.Highlight += ISPGET08(aIP_OPD_HISTO_RATIO0_7_0+15);

        if(sWdr.Ctrl.B8.OpdToggleMode == eWDR_OPD_TOGGLE_ON)
        {
            if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_SHORT)
            {
            	for(HistoIdx=0; HistoIdx < OPD_HISTROGRAM_CNT ; HistoIdx++)
            	{
                    HistoRatioS = ISPGET08(aIP_OPD_HISTO_RATIO0_S_7_0 + HistoIdx);

                    Percentage = ncDrv_Divider((USHORT)(HistoRatioS*100), 255);

                    if(HistoIdx < eHISTOGRAM_IDX_02)        HistoLowAreaS += Percentage;
                    else if(HistoIdx > eHISTOGRAM_IDX_13)   HistoHighAreaS += Percentage;
                    else                                    HistoMidAreaS += Percentage;

                    if(HistoIdx == eHISTOGRAM_IDX_15)       SpotAreaS += Percentage;
                }
                sMwOpd.HistogramS.Highlight = 0;
                sMwOpd.HistogramS.Highlight += ISPGET08(aIP_OPD_HISTO_RATIO0_S_7_0+12);
                sMwOpd.HistogramS.Highlight += ISPGET08(aIP_OPD_HISTO_RATIO0_S_7_0+13);
                sMwOpd.HistogramS.Highlight += ISPGET08(aIP_OPD_HISTO_RATIO0_S_7_0+14);
                sMwOpd.HistogramS.Highlight += ISPGET08(aIP_OPD_HISTO_RATIO0_S_7_0+15);
            }
        }
        else
        {
        	for(HistoIdx=0; HistoIdx < OPD_HISTROGRAM_CNT ; HistoIdx++)
        	{
                HistoRatioS = ISPGET08(aIP_OPD_HISTO_RATIO0_S_7_0 + HistoIdx);

                Percentage = ncDrv_Divider((USHORT)(HistoRatioS*100), 255);

                if(HistoIdx < eHISTOGRAM_IDX_02)        HistoLowAreaS += Percentage;
                else if(HistoIdx > eHISTOGRAM_IDX_13)   HistoHighAreaS += Percentage;
                else                                    HistoMidAreaS += Percentage;

                if(HistoIdx == eHISTOGRAM_IDX_15)       SpotAreaS += Percentage;
            }
        }

        if(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER == 13)    
        {
            if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_SHORT)
            {
                APP_OSDPrint_Dec(18, 21, (USHORT)HistoLowAreaS);
                APP_OSDPrint_Dec(18, 26, (USHORT)HistoMidAreaS);
                APP_OSDPrint_Dec(18, 31, (USHORT)HistoHighAreaS);
                APP_OSDPrint_Dec(18, 36, (USHORT)SpotAreaS);
                
                APP_OSDPrint_Hex(20, 21, (USHORT)sMwOpd.DataS.AvgY);
                APP_OSDPrint_Hex(20, 26, (USHORT)sMwOpd.HistogramS.WeightY);
            }
        }
    }
/********************************************************************/
}

void Debug_Viewer_Histogram(void)
{
    CHAR YOffset;
    UCHAR IdxX, IdxY;
    UINT32 StartAddr=0;
    USHORT SumVal=0;

    for(IdxY = 0; IdxY < 6; IdxY++)
    {
        switch(IdxY){
            case 0:  StartAddr = (UINT32)aIP_OPD_HISTO_RATIO0_7_0;    break;
            case 1:  StartAddr = (UINT32)aIP_OPD_HISTO_RATIO0_7_0;    break;         
            case 2:  StartAddr = (UINT32)aIP_OPD_HISTO_AVG0_7_0;      break;
            case 3:  StartAddr = (UINT32)aIP_OPD_HISTO_RATIO0_S_7_0;  break;
            case 4:  StartAddr = (UINT32)aIP_OPD_HISTO_RATIO0_S_7_0;  break;    
            case 5:  StartAddr = (UINT32)aIP_OPD_HISTO_AVG0_S_7_0;    break;
        }

        YOffset = 2 + (IdxY << 1);

        if((IdxY == 1)||(IdxY == 4))        //Accumulation
        {
            for(IdxX = 0; IdxX < 16; IdxX++)
            {
                SumVal += ISPGET08(StartAddr+IdxX);
				
                if(SumVal >= 0xFF) SumVal = 0xFF;

#if 0
                if(IdxX < 8)    APP_OSDPrint_Hex(YOffset+(IdxY), (IdxX*3)+5, (UCHAR)SumVal);
                else            APP_OSDPrint_Hex(YOffset+(IdxY+1), (IdxX*3)-19, (UCHAR)SumVal);
#endif
            }
            SumVal = 0;
        }
        else
        {
            for(IdxX = 0; IdxX < 16; IdxX++)
            {
#if 0
                if(IdxX < 8)    APP_OSDPrint_Hex(YOffset+(IdxY), (IdxX*3)+5, (UCHAR)ISPGET08(StartAddr+IdxX));
                else            APP_OSDPrint_Hex(YOffset+(IdxY+1), (IdxX*3)-19, (UCHAR)ISPGET08(StartAddr+IdxX));
#endif
            }
        }
    }

/* [2015/7/11] JWLee */ 
#if 0
        APP_OSDPrint_String(2, 1, (UCHAR*)"HLR"); 
        APP_OSDPrint_String(8, 1, (UCHAR*)"HLA"); 
        APP_OSDPrint_String(11, 1, (UCHAR*)"HSR"); 
        APP_OSDPrint_String(17, 1, (UCHAR*)"HSA"); 
#endif
}

void Debug_Viewer(void)
{
#define OPD_LINE_OFFSET     8
    
    UCHAR Xpos = 5;
    CHAR YOffset;
    UCHAR IdxX, IdxY;
    UINT32 StartAddr=0;
    USHORT LineOffset;

	if(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER == 0) return;
	
    if(IsInRage(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER, 1, 10))	
    {
        switch(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER)
        {			
            case 1: StartAddr = (UINT32)aIP_OPD_BLOCK_Y;        break;
            case 2: StartAddr = (UINT32)aIP_OPD_BLOCK_R;        break;
            case 3: StartAddr = (UINT32)aIP_OPD_BLOCK_G;        break;
            case 4: StartAddr = (UINT32)aIP_OPD_BLOCK_B;        break;
            case 5: StartAddr = (UINT32)aIP_OPD_BLOCK_RATIO;    break;

            case 6: StartAddr = (UINT32)aIP_OPD_BLOCKs_Y;       break;
            case 7: StartAddr = (UINT32)aIP_OPD_BLOCKs_R;       break;
            case 8: StartAddr = (UINT32)aIP_OPD_BLOCKs_G;       break;
            case 9: StartAddr = (UINT32)aIP_OPD_BLOCKs_B;       break;
            case 10: StartAddr = (UINT32)aIP_OPD_BLOCKs_RATIO;  break;
        }

        if(IsInRage(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER, 1, 5))
        {
            for(IdxY = 0; IdxY < 8; IdxY++)
            {
                if(IdxY < 2)        YOffset = 1;
                else if(IdxY <= 5)  YOffset = 0;
                else if(IdxY == 6)  YOffset = 0;
                else if(IdxY == 7)  YOffset = -2;

                for(IdxX = 0; IdxX < 8; IdxX++)
                {
                    LineOffset = (OPD_LINE_OFFSET*IdxY);
                    APP_OSDPrint_Hex(YOffset+(IdxY*3), 2+(IdxX*Xpos), ISPGET08(StartAddr+IdxX+LineOffset));

                    if(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER != 1)
                    APP_OSDPrint_String(YOffset+(IdxY*3), 4+(IdxX*Xpos), OPD_Validation_Check(LineOffset+IdxX) ? (UCHAR*)" " : (UCHAR*)"x");
                }
            }
        }
        else
        {
            if((sWdr.Ctrl.B8.OpdToggleMode == eWDR_OPD_TOGGLE_ON)&&(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_MIDDLE)) 
                goto SKIP_OPD_MIDDLE;

            for(IdxY = 0; IdxY < 8; IdxY++)
            {
                if(IdxY < 2)        YOffset = 1;
                else if(IdxY <= 5)  YOffset = 0;
                else if(IdxY == 6)  YOffset = 0;
                else if(IdxY == 7)  YOffset = -2;

                for(IdxX = 0; IdxX < 8; IdxX++)
                {
                    LineOffset = (OPD_LINE_OFFSET*IdxY);

                    APP_OSDPrint_Hex(YOffset+(IdxY*3), 2+(IdxX*Xpos), ISPGET08(StartAddr+IdxX+LineOffset));
                    if(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER != 6)
                    APP_OSDPrint_String(YOffset+(IdxY*3), 4+(IdxX*Xpos), OPD_Validation_CheckS(LineOffset+IdxX) ? (UCHAR*)" " : (UCHAR*)"x");
                }
            }
        } 

        SKIP_OPD_MIDDLE:{}
    }
    else if(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER == 11)
    {
        if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_SHORT)
            Debug_Viewer_Histogram();
    }
    else if(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER == 12)
    {
        Debug_Viewer_WB();
    }
    else if(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER == 13)
    {
        if(sWdr.Mode == STATE_OFF)      Debug_Viewer_AELib();
        else                            Debug_Viewer_WDR_AE();
    }
    else if(rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER == 14)
    {
        Debug_Viewer_WB1();
    }

#if 0
    if((rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER >= 1) && (rSWReg.Category.SYSTEM.Reg.DEBUG_VIEWER < 12))
    {
        APP_OSDPrint_Hex(21, 1, (UCHAR)rIP_OPD_Y_BLOCK_AVG_L);
        APP_OSDPrint_Hex(21, 4, (UCHAR)rIP_OPD_Y_BLOCK_AVG_WEIGHT_L);
        APP_OSDPrint_String(21, 6, (UCHAR*)"/"); 

        if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_MIDDLE)
        {
            APP_OSDPrint_Hex(21, 7, (UCHAR)rIP_OPD_Y_BLOCK_AVG_M);
            APP_OSDPrint_Hex(21, 10, (UCHAR)rIP_OPD_Y_BLOCK_AVG_WEIGHT_M);
        }
		
        APP_OSDPrint_String(21, 12, (UCHAR*)"/"); 
		
        if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_SHORT)
        {
            APP_OSDPrint_Hex(21, 13, (UCHAR)rIP_OPD_Y_BLOCK_AVG_S);
            APP_OSDPrint_Hex(21, 16, (UCHAR)rIP_OPD_Y_BLOCK_AVG_WEIGHT_S);
        }
    }
#endif
}

void OPD_WDR_Channel_Set(void)
{
    if(sWdr.Mode == STATE_ON)
    {
    	if(sWdr.Ctrl.B8.OpdToggleMode == eWDR_OPD_TOGGLE_ON)   
    	{  // DOL3
	        rIP_OPD_DOL_SEL = !rIP_OPD_DOL_SEL;
	        sWdr.Ctrl.B8.OpdSel = (etWDR_OPD_SEL_TYPE)!rIP_OPD_DOL_SEL;
	    }
	    else
	    {  
            sWdr.Ctrl.B8.OpdSel = (etWDR_OPD_SEL_TYPE)rIP_OPD_DOL_SEL;
	    }
    }
    else
    {
        sWdr.Ctrl.B8.OpdSel = (etWDR_OPD_SEL_TYPE)rIP_OPD_DOL_SEL;
    }

/********************** GPIO TEST CODE FOR OPD_DOL_SEL WORKING***********************/
//        HAL_GPIO_Control(38, GPO_FUNC);
//        HAL_GPIO_Set(38, sWdr.Ctrl.B8.OpdSel); 
//        FPGA CN13 PIN:1
/************************************************************************************/

}

void OPD_Histogram_Ratio(void)
{
    memcpy((void*)sMwOpd.Histogram.Ratio, (void*)(aIP_OPD_HISTO_RATIO0_7_0), OPD_HISTROGRAM_CNT);

    if(sWdr.Mode == STATE_ON)
    {
        if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_SHORT)
        {
            memcpy((void*)sMwOpd.HistogramS.Ratio, (void*)(aIP_OPD_HISTO_RATIO0_S_7_0), OPD_HISTROGRAM_CNT);
        }
        else
        {
            memcpy((void*)sMwOpd.HistogramM.Ratio, (void*)(aIP_OPD_HISTO_RATIO0_S_7_0), OPD_HISTROGRAM_CNT);
        }
    }
}

void ncLib_OPD_Task(void)
{    
    OPD_WDR_Channel_Set();
    OPD_Get_RGBY();

    if(sWdr.Mode == STATE_ON)
    {
        if(sWdr.Ctrl.B8.OpdSel == eWDR_OPD_SHORT)   
        {
            OPD_Get_RGBYs();
            OPD_Get_WeightedYs();
        }
        else
        {
            OPD_Get_RGBYm();
            OPD_Get_WeightedYs();            
        }
    }
    OPD_Histogram_Accumlate();

  	Debug_Viewer();
}


