
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __DIGITALEFFECT_DRV_H__
#define __DIGITALEFFECT_DRV_H__

#define	BACKGROUNDOFF		0
#define	BACKGROUNDBLACK		1
#define	BACKGROUNDCOLORBAR	2

typedef struct
{
	UCHAR MirrorMode;
}STRUCT_MW_DEFFECT;

extern STRUCT_MW_DEFFECT	sMwDEffect;
//GLOBALVAR	__xdata STRUCT_MW_DEFFECT	sMwDEffect;

/********************************************************************************
* Function Name 	: ncDrv_Mirror_Set()
* Description		: Mirror Control(Off, Mirror, V-Flip, Rotate)
* Refer to		: API Document
* Argument		:	@ [Mode]		: API Reference Guide
										 
* Return			: 
					@ [TRUE]		: Success
					@ [Error Code]	: Fail (API Reference Guide)
********************************************************************************/
void ncDrv_Mirror_Set(void);

/********************************************************************************
* Function Name 	: ncDrv_Negative_Set()
* Description		: Negative Mode controller
* Refer to		: API Document
* Argument		:	
										 
* Return			: 
					@ [TRUE]		: Success
					@ [Error Code]	: Fail (API Reference Guide)
********************************************************************************/
void ncDrv_Negative_Set(void);

/********************************************************************************
* Function Name 	: ncDrv_Freeze_Set()
* Description		: Freeze Mode controller 
* Refer to		: API Document
* Argument		:	
					
* Return			: 
					@ [TRUE]		: Success
					@ [Error Code]	: Fail (API Reference Guide)
********************************************************************************/
void ncDrv_Freeze_Set(UCHAR Mode);

void ncDrv_BackGround_Set(UCHAR Mode);


#endif

