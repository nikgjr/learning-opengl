
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "ISP_Drv.h"
#include "BlackLevel_Drv.h"

//============================================================================
//      Extern Function Prototype
//============================================================================


void ncDrv_BlackLevelCompensation_Auto(void)
{
	USHORT BLC_G_OFFSET_Y0, BLC_R_OFFSET_Y0, BLC_B_OFFSET_Y0;// Start Blc B Offset Alpha Level
	USHORT BLC_G_OFFSET_Y1, BLC_R_OFFSET_Y1, BLC_B_OFFSET_Y1;// End Blc B Offset Alpha Level
	USHORT BlcGOffsetAlpha = 0, BlcROffsetAlpha = 0, BlcBOffsetAlpha = 0;

	if(((rSWReg.Category.BLACKLEVEL.Reg.BLC_MODE == MODE_MANUAL) || (rSWReg.Category.BLACKLEVEL.Reg.BLC_MODE == MODE_AUTOandMANUAL)) && (rSWReg.Category.BLACKLEVEL.Reg.BLC_OFFSET_AGC_EN == 1))
	{
		BLC_G_OFFSET_Y0 = (USHORT)((rSWReg.Category.BLACKLEVEL.Reg.BLC_G_OFFSET_Y0_11_8 << 8) | rSWReg.Category.BLACKLEVEL.Reg.BLC_G_OFFSET_Y0_7_0);
		BLC_R_OFFSET_Y0 = (USHORT)((rSWReg.Category.BLACKLEVEL.Reg.BLC_R_OFFSET_Y0_11_8 << 8) | rSWReg.Category.BLACKLEVEL.Reg.BLC_R_OFFSET_Y0_7_0);
		BLC_B_OFFSET_Y0 = (USHORT)((rSWReg.Category.BLACKLEVEL.Reg.BLC_B_OFFSET_Y0_11_8 << 8) | rSWReg.Category.BLACKLEVEL.Reg.BLC_B_OFFSET_Y0_7_0);

		BLC_G_OFFSET_Y1 = (USHORT)((rSWReg.Category.BLACKLEVEL.Reg.BLC_G_OFFSET_Y1_11_8 << 8) | rSWReg.Category.BLACKLEVEL.Reg.BLC_G_OFFSET_Y1_7_0);
		BLC_R_OFFSET_Y1 = (USHORT)((rSWReg.Category.BLACKLEVEL.Reg.BLC_R_OFFSET_Y1_11_8 << 8) | rSWReg.Category.BLACKLEVEL.Reg.BLC_R_OFFSET_Y1_7_0);
		BLC_B_OFFSET_Y1 = (USHORT)((rSWReg.Category.BLACKLEVEL.Reg.BLC_B_OFFSET_Y1_11_8 << 8) | rSWReg.Category.BLACKLEVEL.Reg.BLC_B_OFFSET_Y1_7_0);

		BlcGOffsetAlpha = ncDrv_InterpAGC(rSWReg.Category.BLACKLEVEL.Reg.BLC_AGC_X0, 	// Start AGC Level
						                rSWReg.Category.BLACKLEVEL.Reg.BLC_AGC_X1, 	// End AGC Level
						                BLC_G_OFFSET_Y0, 							// Start Blc G Offset Alpha Level
						                BLC_G_OFFSET_Y1);							// End Blc G Offset Alpha Level

		BlcROffsetAlpha = ncDrv_InterpAGC(rSWReg.Category.BLACKLEVEL.Reg.BLC_AGC_X0, 	// Start AGC Level 
                                        rSWReg.Category.BLACKLEVEL.Reg.BLC_AGC_X1, 	// End AGC Level 
                                        BLC_R_OFFSET_Y0, 							// Start Blc R Offset Alpha Level 
                                        BLC_R_OFFSET_Y1);							// End Blc R Offset Alpha Level
               
		BlcBOffsetAlpha = ncDrv_InterpAGC(rSWReg.Category.BLACKLEVEL.Reg.BLC_AGC_X0, 	// Start AGC Level
                                        rSWReg.Category.BLACKLEVEL.Reg.BLC_AGC_X1, 	// End AGC Level
                                        BLC_B_OFFSET_Y0,					 		// Start Blc B Offset Alpha Level
                                        BLC_B_OFFSET_Y1);							// End Blc B Offset Alpha Level
                                                                             
    	rIP_BLC_GR_OFFSET_11_8 	= ((BlcGOffsetAlpha >> 8) & 0xFF);
    	rIP_BLC_GR_OFFSET_7_0 	= (BlcGOffsetAlpha & 0xFF);
    	rIP_BLC_R_OFFSET_11_8 	= ((BlcROffsetAlpha >> 8) & 0xFF);
    	rIP_BLC_R_OFFSET_7_0 	= (BlcROffsetAlpha & 0xFF);
    	rIP_BLC_B_OFFSET_11_8 	= ((BlcBOffsetAlpha >> 8) & 0xFF);
    	rIP_BLC_B_OFFSET_7_0 	= (BlcBOffsetAlpha & 0xFF);
    	rIP_BLC_GB_OFFSET_11_8 = ((BlcGOffsetAlpha >> 8) & 0xFF);
    	rIP_BLC_GB_OFFSET_7_0 	= (BlcGOffsetAlpha & 0xFF);

    }
}

void ncDrv_BlackLevelCompensation_Set(void)
{
    switch(rSWReg.Category.BLACKLEVEL.Reg.BLC_MODE)
	{
		case MODE_OFF:
			rIP_BLC_EN 			= 0x0;
			rIP_BLC_OFFSET_EN 	= 0x0;
			break;
		case MODE_MANUAL:
			rIP_BLC_EN 			= 0x0;
			rIP_BLC_OFFSET_EN 	= 0x1;
			break;
		case MODE_AUTO:
			rIP_BLC_EN 			= 0x1;
			rIP_BLC_OFFSET_EN 	= 0x0;
			break;
		case MODE_AUTOandMANUAL:
			rIP_BLC_EN 			= 0x1;
			rIP_BLC_OFFSET_EN 	= 0x1;
			break;
		default:				break;
	}

	//[refer. Modify by sky00-BLC Gr/R/B/Gb Offset] : MW_BlackLevelCompensation_Auto()
    ISPSET16(aIP_BLC_GR_OFFSET_7_0, ISPGET16(ADDR_BLC_G_OFFSET_7_0));
    ISPSET16(aIP_BLC_R_OFFSET_7_0,  ISPGET16(ADDR_BLC_R_OFFSET_7_0));
    ISPSET16(aIP_BLC_B_OFFSET_7_0,  ISPGET16(ADDR_BLC_B_OFFSET_7_0));
    ISPSET16(aIP_BLC_GB_OFFSET_7_0, ISPGET16(ADDR_BLC_G_OFFSET_7_0));

}
