
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __MW_GLOBALVAR__
#define __MW_GLOBALVAR__

#include "APACHE35.h"


/*=============================================================================
    Function Mode 
=============================================================================*/

#ifndef tAGC_MODE
#define tAGC_MODE
    typedef enum{
    	eAGC_MODE_OFF = 0,
    	eAGC_MODE_15 = 15,
    	eAGC_MODE_MAX,
    }etAGC_MODE;
#define AGC_MODE_INIT  eAGC_MODE_MAX
#endif

typedef enum{
    eRET = 0,
    eEND    
}eReturn;

#ifndef tCVBS_OUTPUT_FORMAT
#define tCVBS_OUTPUT_FORMAT
    typedef enum{
    	eCVBS_PAL = 0,
    	eCVBS_NTSC,
    	eCVBS_FORMAT,
    }etCVBS_OUTPUT_FORMAT;
#endif


#ifndef tFRAME_RATE
#define tFRAME_RATE
    typedef enum{
        eFRAME_RATE_30 = 0,
    	eFRAME_RATE_60,
    	eFRAME_RATE_120,
    	eFRAME_RATE_MAX,
    }etFRAME_RATE;
#define eFRAME_RATE_INIT	eFRAME_RATE_MAX
#endif


#ifndef tLENS_MODE
#define tLENS_MODE
    typedef enum{
        eLENS_MODE_DC = 0,
        eLENS_MODE_MANUAL,
        eLENS_MODE_PIRIS,
        eLENS_MODE_DC_MANUAL,
        eLENS_MODE_MAX,
    }etLENS_MODE;
    #define LENS_MODE_INIT  eLENS_MODE_MAX
#endif


#define eMONITOR_OUT_MODE
typedef enum{
    eMONITOR_CVBS =0,
    eMONITOR_HDSDI,      /* [2014/8/25] JWLee : 31/31H ������ RESERVED */
    eMONITOR_AHD,
    eMONITOR_MAX,
}etMONITOR_OUT_MODE;

#ifndef tMANUAL_SHUT_TYPE
#define tMANUAL_SHUT_TYPE
typedef enum{
/*  00  */  e60P_MANUAL_AUTO = 0,
/*  01  */  e60P_MANUAL_1_60s,
/*  02  */  e60P_MANUAL_FLK,    
/*  03  */  e60P_MANUAL_1_250s,
/*  04  */  e60P_MANUAL_1_500s,
/*  05  */  e60P_MANUAL_1_1000s,
/*  06  */  e60P_MANUAL_1_2000s,
/*  07  */  e60P_MANUAL_1_5000s,
/*  08  */  e60P_MANUAL_1_10000s,
/*  09  */  e60P_MANUAL_1_50000s,
/*  10  */  e60P_MANUAL_x02,
/*  11  */  e60P_MANUAL_x04,
/*  12  */  e60P_MANUAL_x06,
/*  13  */  e60P_MANUAL_x08,
/*  14  */  e60P_MANUAL_x10,
/*  15  */  e60P_MANUAL_x15,
/*  16  */  e60P_MANUAL_x20,
/*  17  */  e60P_MANUAL_x25,
/*  18  */  e60P_MANUAL_x30,
/*  19  */  e60P_MANUAL_Max,
} et60P_MANUAL_SHUT_TYPE;


typedef enum{
/*  00  */  e30P_MANUAL_AUTO = 0,
/*  01  */  e30P_MANUAL_1_30s,  
/*  02  */  e30P_MANUAL_1_60s,
/*  03  */  e30P_MANUAL_FLK,    
/*  04  */  e30P_MANUAL_1_250s,
/*  05  */  e30P_MANUAL_1_500s,
/*  06  */  e30P_MANUAL_1_1000s,
/*  07  */  e30P_MANUAL_1_2000s,
/*  08  */  e30P_MANUAL_1_5000s,
/*  09  */  e30P_MANUAL_1_10000s,
/*  10  */  e30P_MANUAL_1_50000s,
/*  11  */  e30P_MANUAL_x02,
/*  12  */  e30P_MANUAL_x04,
/*  13  */  e30P_MANUAL_x06,
/*  14  */  e30P_MANUAL_x08,
/*  15  */  e30P_MANUAL_x10,
/*  16  */  e30P_MANUAL_x15,
/*  17  */  e30P_MANUAL_x20,
/*  18  */  e30P_MANUAL_x25,
/*  19  */  e30P_MANUAL_x30,
/*  20  */  e30P_MANUAL_Max,
} et30P_MANUAL_SHUT_TYPE;
#define SHUT_MODE_INIT          e30P_MANUAL_Max     /* RESET CODE */
#define SHUT_MODE_AUTO          e30P_MANUAL_AUTO    /* = e60P_MANUAL_AUTO */
#define SHUT_MODE_DEFAULT       e30P_MANUAL_1_30s   /* 30P=1/30, 60P=1/60 */
#define SENSUP_START_IDX_30P    e30P_MANUAL_x02
#define SENSUP_START_IDX_60P    (et30P_MANUAL_SHUT_TYPE)e60P_MANUAL_x02
#endif 

#ifndef tLEVEL4_TYPE
#define tLEVEL4_TYPE
typedef enum{
    eLEVEL4_OFF = 0,
    eLEVEL4_LOW,
    eLEVEL4_MIDDLE,
    eLEVEL4_HIGH,
    eLEVEL4_MAX
} eLevel;
#endif 

#ifndef tLEVEL3_TYPE
#define tLEVEL3_TYPE
typedef enum{
    eLEVEL3_LOW = 0,
    eLEVEL3_MIDDLE,
    eLEVEL3_HIGH,
    eLEVEL3_MAX,
}etLEVEL3_TYPE;
#endif 

#ifndef tFRAME_SIZE
#define tFRAME_SIZE
typedef enum{
    eSIZE_1280_720 = 0,
    eSIZE_1920_1080,
    eSIZE_MAX,
}etFRAME_SIZE;
#endif

#ifndef tDN_STATUS
#define tDN_STATUS
    typedef enum
    {
    	DN_STATUS_BW = 0,
    	DN_STATUS_COLOR,
    	DN_STATUS_MAX,
    }DN_STATUS;
#endif

#ifndef tDN_MODE_TYPE
#define tDN_MODE_TYPE
    typedef enum{
    	eDN_AUTO = 0,
    	eDN_COLOR,
    	eDN_BW,
    	eDN_EXT,
    	eDN_MAX,
    }etDN_MODE_TYPE;
#endif

#ifndef tBACKLIGHT_MODE_TYPE
#define tBACKLIGHT_MODE_TYPE
typedef enum{
    eBACKLIGHT_OFF = 0,
    eBACKLIGHT_BLC,
    eBACKLIGHT_HSBLC,
    eBACKLIGHT_WDR,
    eBACKLIGHT_MAX,    
}etBACKLIGHT_MODE_TYPE;
#endif

#ifndef tFUNCTION_MODE_TYPE
#define tFUNCTION_MODE_TYPE
typedef enum{
    eMODE_OFF = 0,
    eMODE_ON,
    eMODE_AUTO
} etFUNCTION_MODE_TYPE;
#endif

/* [2014/11/10] JWLee : [STD]-01 */
typedef enum{
    eCVBS_H_720H = 0,
    eCVBS_H_960H,
    eCVBS_H_1280H,
    eCVBS_H_1440H,
    eCVBS_H_1920H,
    eCVBS_H_MAX,
}etCVBS_H_MODE;

typedef enum{
    ePATH_HDS_VDS = 0,  /* H - DOWNSCALE, V - DOWNSCALE */
    ePATH_HCR_VDS,      /* H - CROP, V - DOWNSCALE */
    ePATH_HCR_VCR,      /* H - CROP, V - CROP */
    ePATH_MAX,
}etCVBS_PATH_MODE;

enum{
    OPD_UPDATE_ON = 0,
    OPD_UPDATE_OFF = 1,
};

typedef enum{
    eHSBLCMODE_ALLDAY = 0,
    eHSBLCMODE_NIGHT
}eHSBLCMODE;

typedef enum{
    eWHITBAL_ATW = 0,
    eWHITBAL_AWC,
    eWHITBAL_INDOOR,
    eWHITBAL_OUTDOOR,
    eWHITBAL_MANUAL,
    eWHITBAL_AWB
}eWHITBAL;

typedef enum{
    eFLIP_OFF =0,   
    eFLIP_MIRROR,       //eFLIP_H
    eFLIP_V,            //eFLIP_V
    eFLIP_ROTATE,       //eFLIP_HV
    eFLIP_MAX
}eFLIP;

typedef enum{
    eSHARPNESS_MODE_OFF =0,
    eSHARPNESS_MODE_AUTO
}eSHARPNESS_MODE;

/* [2014/11/10] JWLee : [STD]-01 */
typedef enum{
    eCVBS_1920x576 = 0,
    eCVBS_1920x480,
    eCVBS_1440x576,
    eCVBS_1440x480,
    eCVBS_1280x576,
    eCVBS_1200x480,
    eCVBS_960x576,
    eCVBS_960x480,
    eCVBS_720x576,
    eCVBS_720x480,
    eCVBS_OUTSIZE_MAX,
}eCVBS_OUTPUT_SIZE;

typedef enum{
    eAHD_CLK_60MHZ =0,
    eAHD_CLK_72MHZ,
    eAHD_CLK_120MHZ,
    eAHD_CLK_144MHZ
}eAHD_CLK_FORMAT;

typedef enum{
    eLDC_TYPE_OFF   		  = 0,
	eLDC_TYPE_NORMAL_LDC_ON   = 1,
	eLDC_TYPE_NORMAL_BYPASS   = 2,
    eLDC_TYPE_PANORAMA_LDC_ON = 3,
}etLDC_TYPE;

typedef enum{
    eDPC_SCANVIEW_OFF = 0,
    eDPC_SCANVIEW_WDPC,
    eDPC_SCANVIEW_BDPC,
}etDPC_SCANVIEW_TYPE;

typedef enum{
    eDPC_GRID_OFF = 0,
    eDPC_GRID_WDPC,
    eDPC_GRID_BDPC,
}etDPC_GRID_SEL_TYPE;

typedef enum{
    eCSC_MANUAL = 0,
	eCSC_AUTO
}etCSC_MODE;

/*=============================================================================
    Middle Global Variable  
=============================================================================*/

/*=============================================================================
    Special Status Register Aress
=============================================================================*/

#define ADDF_WDPC_START		        ADDR_WDPC_MODE
#define ADDF_WDPC_END			    ADDR_WDPC_GRID_CR_9_8
#define ADDF_BDPC_START		        ADDR_BDPC_MODE
#define ADDF_BDPC_END			    ADDR_BDPC_GRID_CR_9_8
#define ADDF_LDPC_START		        ADDR_LIVE_WDPC_MODE
#define ADDF_LDPC_END			    ADDR_LIVE_WDPC_AUTO_Y1

#define ADDF_COAXCIAL_START         ADDR_COAX_OSD_VIEWER
#define ADDF_COAXCIAL_END           ADDR_COAX_USER_RX_DLY_PAL
#define ADDF_LENS_SHUT_START        ADDR_LENS_BOUNDARY
#define ADDF_LENS_SHUT_END          ADDR_MANUAL_LENS_SHUT

#define ADDF_TDN_DELAY_START        ADDR_AUTO_D2N_AGC
#define ADDF_TDN_DELAY_END          ADDR_AUTO_GAP_CDS
#define ADDF_IR_SMART_START         ADDR_BW_IR_SMART
#define ADDF_IR_SMART_END           ADDR_BW_IR_SMART_SIZE_Y
#define ADDF_EXT_START              ADDR_EXT_GAP_CDS
#define ADDF_EXT_END                ADDR_EXT_N2D_CDS

#define ADDF_LBDPC_START		    ADDR_LIVE_BDPC_AUTO_X0	/* [2014/12/08] SJH : [STD]-01 */
#define ADDF_LBDPC_END			    ADDR_LIVE_BDPC_AUTO_Y1	/* [2014/12/08] SJH : [STD]-01 */

#define ADDF_BLC_START              ADDR_BLC_GRID_EN
#define ADDF_BLC_END                ADDR_BLC_SIZE_X

#define ADDF_HSBLC_START            ADDR_HSBLC_MODE_AGC_TH
#define ADDF_HSBLC_END              ADDR_HSBLC_AREA4_H_7_0

#define ADDF_DEFOG_START            ADDR_DEFOG_GIRD_VIEW
#define ADDF_DEFOG_END              ADDR_DEFOG_MANUAL

#define ADDF_PRIVACY_START          ADDR_PM_SEL_EN
#define ADDF_PRIVACY_END            ADDR_COLOR_USER_CR

#define ADDF_MOTION_START           ADDR_MD_SEL_EN
#define ADDF_MOTION_END             ADDR_OSD_Y_HDSDI

#define ADDF_OSD_POS_START          ADDR_MENU_DIGITAL_POS_X
#define ADDF_OSD_POS_END            ADDR_MENU_MAIN_SUB_INTERVAL

#define ADDF_OSD_ATTR_START         ADDR_MENU_TITLE_FONT_TRANS
#define ADDF_OSD_ATTR_END           ADDR_MENU_FOCUS_BG_COLOR

#define ADDF_OSD_BOX_START          ADDR_BOX_1_EN
#define ADDF_OSD_BOX_END            ADDR_BOX_0_EN

#define ADDF_WDPC_STATE_START       ADDR_WDPC_STATE
#define ADDF_WDPC_STATE_END         ADDR_WDPC_SCAN_STATE

#define ADDF_BDPC_STATE_START       ADDR_BDPC_STATE
#define ADDF_BDPC_STATE_END         ADDR_BDPC_SCAN_STATE

#define ADDF_MENU_STATE_START       ADDR_MENU_STATE
#define ADDF_MENU_STATE_END         ADDR_MENU_STATE

#define ADDF_AE_INFO_START          ADDR_SHUTTER_DATA_15_8
#define ADDF_AE_INFO_END            ADDR_SHUTTER

#define ADDF_SENSOR_INFO_START      ADDR_SENSOR_SYSTEM
#define ADDF_SENSOR_INFO_END        ADDR_SENSOR_SYSTEM

#define ADDF_SFLASH_INFO_START      ADDR_FLASH_TYPE
#define ADDF_SFLASH_INFO_END        ADDR_FLASH_TYPE

#define ADDF_CVBS1_BUGAIN_START     ADDR_CVBS_ENC_U_BURST_NTSC_9_8
#define ADDF_CVBS1_BUGAIN_END       ADDR_CVBS_ENC_SYNC_PAL

#define ADDF_CVBS1_YCBCRGAIN_START  ADDR_CVBS_ENC_GAIN_Y_NTSC
#define ADDF_CVBS1_YCBCRGAIN_END    ADDR_CVBS_ENC_GAIN_CR_PAL

#define ADDF_SENSUP_START           ADDR_SENS_UP_MODE
#define ADDF_SENSUP_END             ADDR_SENS_UP_MODE

#define ADDF_DWDR_BW_START          ADDR_DWDR_GAIN_BW
#define ADDF_DWDR_BW_END            ADDR_DWDR_MODE_BW

#define ADDF_RS485_ID_START         ADDR_RS485_CAM_ID_DISPLAY
#define ADDF_RS485_ID_END           ADDR_RS485_CAM_ID_POS_7_0

#define ADDF_DNR3_YTH_START         ADDR_DNR3_YTH_L_TBL0
#define ADDF_DNR3_YTH_END           ADDR_DNR3_YTH_H_TBL7

#define ADDF_FRC_RESET_DELAY_NTSC_START    ADDR_FRC_RESET_DELAY_NTSC_7_0
#define ADDF_FRC_RESET_DELAY_NTSC_END      ADDR_FRC_RESET_DELAY_NTSC_19_16
#define ADDF_FRC_RESET_DELAY_PAL_START     ADDR_FRC_RESET_DELAY_PAL_7_0
#define ADDF_FRC_RESET_DELAY_PAL_END       ADDR_FRC_RESET_DELAY_PAL_19_16

/*=============================================================================
    Special ISP Register Address
=============================================================================*/

#define ADDF_AF_START               aIP_I_HI_TH_1_7_0
#define ADDF_AF_END                 aIP_Y_HEIGHT_3_12_8

/*=============================================================================
    Middle Global Define  (Common References)
=============================================================================*/

#define CVBS_FORMAT     (etCVBS_OUTPUT_FORMAT)rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_TYPE     //eCVBS_PAL, eCVBS_NTSC
#define INPUT_SIZE      sGco.InputFrame.Size
#define OUTPUT_SIZE     sGco.OutputFrame.Size



/*=============================================================================
    HAL_GlobalVariable.h
=============================================================================*/
#define RS485RESET		60 // 33.3ms * 60 = 1998ms = 2s

/*========================================	
	HAL Global Interrupt Flag Define
========================================*/
typedef struct{
	union{
		UCHAR D8[3];
		struct{
			UCHAR	Spi0:		1;
			UCHAR	Spi1:		1;
			UCHAR	Spi2:		1;
			UCHAR	Uart0:		1;
			
			UCHAR	Uart1:		1;
			UCHAR	Timer0:		1;
			UCHAR	Timer1:		1;
			UCHAR	Timer2:		1;

			UCHAR	Isp0:		1;
			UCHAR	Isp1:		1;
			UCHAR	Isp2:		1;
			UCHAR	Isp3:		1;
			
			UCHAR	Isp4:		1;
			UCHAR	Isp5:		1;
			UCHAR	Isp6:		1;
			UCHAR	Isp7:		1;
			
			UCHAR	Isp8:		1;
			UCHAR	I2c0:		1;
			UCHAR	I2c1:		1;
            UCHAR   SfrBank:    1;  /* [2015/07/09] Leo.Sim : [STD]-01 */
            
			UCHAR	REVERED:	4;
		} Bit;
	}Flag;	
}STRUCT_HAL_INTERRUPT;
extern STRUCT_HAL_INTERRUPT	sHalInt;

typedef struct
{
	volatile UCHAR	VSIPSkip;
	volatile UCHAR	VSINSkip;
	volatile UCHAR	VSOPSkip;

    volatile UCHAR	VSIPCnt;
	volatile UCHAR	VSINCnt;
	volatile UCHAR	VSOPCnt;
	
	UCHAR	Time;
	UCHAR	Mode;
}STRUCT_HAL_DELAY;
extern STRUCT_HAL_DELAY	sHalDelay;

typedef union{
	USHORT D16;
	struct {
		UCHAR	MSmode:				1;
		UCHAR   SizeAddr:           1;
		UCHAR   SizeData:           1;
		UCHAR	DataDirection:		1;

		UCHAR	OperationMode:		1;
		UCHAR	WireCount:			1;
        UCHAR   Reserved_2bit:      2;
        
		UCHAR	BaudRate:			4;
        UCHAR   Reserved_4bit:      4;
	}Bit;
} STRUCT_SPI_CONTROL;

typedef struct
{
	UCHAR 	StartAddress_07_00;
	UCHAR 	StartAddress_15_08;
	UCHAR 	StartAddress_23_16;

	UCHAR 	EndAddress_07_00;
	UCHAR 	EndAddress_15_08;
	UCHAR 	EndAddress_23_16;

	UCHAR 	MIAddress_07_00;
	UCHAR 	MIAddress_15_08;
	UCHAR 	MIAddress_23_16;
	UCHAR 	MIAddress_31_24;
}STRUCT_QSPI_CONTROL;

typedef union{
	UCHAR D8[2];
	struct{
		UCHAR	ParityMode:		3;
		UCHAR	WordLength:		2;
		UCHAR	StopBit:		1;
		UCHAR	Reserved:		2;
		UCHAR	BaudRate:		8;
	} Bit;
} STRUCT_UART_CONTROL;

typedef	union{
	UCHAR D8[3];
	struct{
		UCHAR	MSmode:			1;
		UCHAR   SizeAddr:       1;
		UCHAR   SizeData:       1;

		UCHAR	Reserved:		5;

		UCHAR	DeviceID:	    8;
		UCHAR	BaudRate:		8;
	} Bit;
}STRUCT_I2C_CONTROL;

typedef	union{
	UCHAR D8;
	struct{
		UCHAR	Coefficient:	8;
	} Bit;
}STRUCT_TIMER_CONTROL;

typedef union{
	UCHAR D8[16];
	struct{
		STRUCT_UART_CONTROL Uart;
		STRUCT_I2C_CONTROL I2c0;
        STRUCT_I2C_CONTROL I2c1;
		STRUCT_SPI_CONTROL Spi0;
		STRUCT_SPI_CONTROL Spi1_1;
		STRUCT_SPI_CONTROL Spi1_2;
		STRUCT_QSPI_CONTROL QSpi;
        STRUCT_TIMER_CONTROL Timer0;
        STRUCT_TIMER_CONTROL Timer1;
        STRUCT_TIMER_CONTROL Timer2;        
	}Control;
}
STRUCT_HAL_CONTROL;
extern STRUCT_HAL_CONTROL	sHalCon;

typedef struct
{
	UCHAR 	Data[4][6];
	UCHAR	CoaxKey;
	UCHAR	CoaxPreKey;

	UCHAR 	RegisterControlData[4][6];		
	UCHAR	Register1LineData;
	UCHAR	Register2LineData;	
	UCHAR	Register3LineData;
	UCHAR	Register4LineData;	
	UCHAR	AhdCoaxMode;

	UCHAR 	DecoderCtl_Add;
	UCHAR 	DecoderCtl_Data;
	UCHAR 	CommandReadWrite_Check;

	/* [2015/07/22] Jong-Hyun, Choi : ACP */
	UCHAR 	AcpWatermarkCount;
}STRUCT_HAL_COAX;
extern	STRUCT_HAL_COAX	sHalCoax;

/* [2014/12/29] Jong-Hyun, Choi : STD-1 */
//{
typedef struct
{
	UCHAR 	SubVideoChangeMode;
}STRUCT_HAL_SYSTEM;
extern STRUCT_HAL_SYSTEM	sHalSystem;
//}



#endif



