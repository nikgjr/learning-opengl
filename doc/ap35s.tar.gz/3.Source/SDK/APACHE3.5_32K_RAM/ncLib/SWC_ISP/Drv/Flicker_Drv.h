
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __FLICKER_DRV__
#define __FLICKER_DRV__









void ncDrv_Flicker_Initialize(void);
void ncDrv_Flicker_Task(void);

void ncDrv_Flicker_Win_Get(UCHAR FrameNum);
void ncDrv_Flicker_WinData_Compare(UCHAR mode);

void ncDrv_Flicker_ChangeOutputFormat(void);
void ncDrv_Flicker_SetCvbsFormat(UCHAR mode);

void ncDrv_Flicker_Time_OPD_VIEW(UCHAR mode);
void ncDrv_Flicker_Area_OPD_VIEW(void);

void ncDrv_Flicker_Auto_TimeStateWait(void);
void ncDrv_Flicker_Auto_TimeStateCheck(void);
void ncDrv_Flicker_Auto_Time_Task(void);



#endif

