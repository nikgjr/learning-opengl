
#if(SENSOR_SELECT == OMNIVISION_OV10640)

    /* 1. SENSOR COMMON INTERFACE */
    #define SENSOR_INTERFACE                INPUT_PARALLEL
    #define SENSOR_SLAVE                    NO
    #define SENSOR_MAX_FPS                  FPS_MAX_30P    
    #define SENSOR_MAX_SIZE                 SIZE_MAX_720	
    #define SENSOR_ICLK                     SENSOR_ICLK_27M    
    #define SENSOR_COMM_TYPE                SENSOR_COMM_I2C
    #define SENSOR_ACP_ID                   0x0205
    
    /* 2. SENSOR_COMM_TYPE = SENSOR_COMM_I2C */
    #define I2C_DEVICE_ID                   0x60
    #define I2C_ADDRESS_SIZE                SIZE_2_BYTE
    #define I2C_DATA_SIZE                   SIZE_1_BYTE

    /* 3. SENSOR_COMM_TYPE = SENSOR_COMM_SPI */
    #define SPI_WIRE_COUNT                  NOT_USE
	#define SPI_ADDRESS_BANK_EN             NOT_USE
    #define SPI_ADDRESS_SIZE                NOT_USE
    #define SPI_DATA_SIZE                   NOT_USE
    #define SPI_MS_MODE                     NOT_USE
    #define SPI_COMM_DIRECTION              NOT_USE

    /* 4. SENSOR MISCELLANEOUSE OPTIONS */
    #define OPTION_LDC_EN                   YES
    #define OPTION_WDR_TYPE                 WDRTYPE_DCOMP_OV

extern void ncDrv_SENSOR_FPS_Set(void);
#endif

