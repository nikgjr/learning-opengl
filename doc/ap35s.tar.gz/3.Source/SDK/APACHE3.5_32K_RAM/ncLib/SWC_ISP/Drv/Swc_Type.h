

/*
********************************************************************************
*               ISP PART
********************************************************************************
*/


#define YES                         1
#define NO                          0

#define NOT_USE                     0

#define SPI_MODE_MASTER     0
#define SPI_MODE_SLAVE      1

#define STATE_ON                    1
#define STATE_OFF                   0

#define SENSOR_COMM_I2C             0
#define SENSOR_COMM_SPI             1

#define SENSOR_ICLK_27M             0
#define SENSOR_ICLK_37p125M         1

#define SPI_WIRE_3LANE              0
#define SPI_WIRE_4LANE              1

#define FPS_MAX_30P                 0
#define FPS_MAX_60P                 1

#define SIZE_MAX_720                0
#define SIZE_MAX_1080               1

#define SIZE_1_BYTE                 0
#define SIZE_2_BYTE                 1

#define COMM_MSB_FIRST              0
#define COMM_LSB_FIRST              1

#define INPUT_PARALLEL              0
#define INPUT_LVDS                  1

#define H_ACTIVE_OFFSET             8
#define V_ACTIVE_OFFSET             0

















//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
/*==============================================================================
    0. CUSTOMER
================================================================================*/

#define	NEXTCHIP					0x00
#define	CH_XM						0x01
#define	CH_HIKVISION				0x02
#define	CH_TVT						0x03
#define	KR_HDPRO					0x04
#define	KR_VISIONHITECH				0x05
#define	KR_HUVIRON					0x06
#define	KR_HITRON					0x07
#define	KR_SAMSUNG_TECHWIN			0x08
#define	KR_CNB						0x09
#define	KR_CPRO						0x0A
#define	KR_EYEHAWK					0x0B
#define	KR_KCE						0x0C
#define	KR_KTNC						0x0D
#define	KR_NADATEL					0x0E
#define	KR_NEOCOM					0x0F
#define	KR_POWERTECH				0x10
#define	KR_PST						0x11
#define	KR_RONIX					0x12
#define	KR_SNM						0x13
#define	KR_KICC						0x14
#define	KR_CKSYSTEM					0x15
#define	KR_NEOVISIONTECH			0x16
#define	KR_SHINDEHANNETWORKS		0x17
#define	KR_HANTECH					0x18


#define MANUFACTURER_ID               NEXTCHIP		//CUSTOMIZING OR STANDARD

/*==============================================================================
    1. Product ISP Select
================================================================================    
        1. APACHE28[BGA, 2D/3DNR]
            [Main Pass Type]
            - AHD Mode      ("AHD" or "HDSDI & CVBS" Output)
            - HDSDI Mode    ("HDSDI & CVBS" Output)
            - CVBS Mode     (CVBS Output)
            
        2. PJT_NVP2630_AUTOMOTIVE[QFN, 2DNR]
            [Main Pass Type]
            - AHD Mode      ("AHD" or "HDSDI & CVBS" Output)
            - CVBS Mode     (CVBS Output)
==============================================================================*/
#define PJT_NVP2450H_SECURITY				1
#define PJT_NVP2630_AUTOMOTIVE				2

#define PRODUCT_ISP							PJT_NVP2630_AUTOMOTIVE

/*==============================================================================
    2. Main Pass Output Select
================================================================================*/

/*=============================================================================
    3. Sensor Select
        0         : Default Sensor
        1   ~ 20  : SONY
        21  ~ 40  : PANASONIC
        41  ~ 60  : APNINA
        61  ~ 80  : OMNIVISION
        81  ~ 100 : PIXART
        101 ~ 120 : PIXEL PLUS
        121 ~ 130 : SMARTSENS
        131 ~ 140 : SILCON OPTRONICS
        150 ~     : MISCELLANEOUS (ETC)
=============================================================================*/

#define SENSOR_DEFAULT                      0
/*____________ 1   ~ 20  : SONY __________________________ */
#define SONY_IMX136LQJ                      1
#define SONY_IMX224MQR       				2
#define SONY_IMX290LQR                      3
#define SONY_IMX291LQR                      4

#define SENSOR_SONY_START					SONY_IMX136LQJ
#define SENSOR_SONY_END						SONY_IMX291LQR

/*____________ 21  ~ 40  : PANASONIC _____________________ */
#define PANASONIC_MN34229                   21

#define SENSOR_PANASONIC_START				PANASONIC_MN34229
#define SENSOR_PANASONIC_END				PANASONIC_MN34229

/*____________ 41  ~ 60  : APNINA ________________________ */
#define APTINA_AR0331         				41
#define APTINA_AR0140						42		


#define SENSOR_APTINA_START				    APTINA_AR0331
#define SENSOR_APTINA_END				    APTINA_AR0140

/*____________ 61  ~ 80  : OMNIVISION_____________________ */
#define OMNIVISION_OV10635  				61
#define OMNIVISION_OV10640  				62

#define SENSOR_OMNIVISION_START				OMNIVISION_OV10635
#define SENSOR_OMNIVISION_END				OMNIVISION_OV10640

/*____________ 81  ~ 100 : PIXART ________________________ */


/*____________ 101 ~ 120 : PIXEL PLUS ____________________ */


/*____________ 121 ~ 130 : SMARTSENS _____________________ */


/*____________ 131 ~ 140 : SILCON OPTRONICS ______________ */


/*____________ 150 ~     : MISCELLANEOUS (ETC) ___________ */
#define SENSOR_COMMON  				99


/*=============================================================================
    4. PRE DEFINE FOR RELEASE
=============================================================================*/
#if defined(SENSOR_T_DEFAULT)
    #define SENSOR_SELECT                       SENSOR_DEFAULT
#elif defined(SENSOR_T_IMX136)
    #define SENSOR_SELECT                       SONY_IMX136LQJ
#elif defined(SENSOR_T_IMX224)
    #define SENSOR_SELECT                       SONY_IMX224MQR
#elif defined(SENSOR_T_IMX290)
    #define SENSOR_SELECT                       SONY_IMX290LQR
#elif defined(SENSOR_T_IMX291)
    #define SENSOR_SELECT                       SONY_IMX291LQR
#elif defined(SENSOR_T_MN34229)
    #define SENSOR_SELECT                       PANASONIC_MN34229
#elif defined(SENSOR_T_AR0331)
    #define SENSOR_SELECT                       APTINA_AR0331
#elif defined(SENSOR_T_AR0140)
    #define SENSOR_SELECT                       APTINA_AR0140
#elif defined(SENSOR_T_OV10635)
    #define SENSOR_SELECT                       OMNIVISION_OV10635
#elif defined(SENSOR_T_OV10640)
    #define SENSOR_SELECT                       OMNIVISION_OV10640
#else
/*=============================================================================
    3-1. Consumer Sensor Select
=============================================================================*/

#define SENSOR_SELECT                           APTINA_AR0140
#endif


#define FPGA_MODE  TRUE
#define CHIP_MODE  FALSE
//#define API_FUNCTION_CALL 
