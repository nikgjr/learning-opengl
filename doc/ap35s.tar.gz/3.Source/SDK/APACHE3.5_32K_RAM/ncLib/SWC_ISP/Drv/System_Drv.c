
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Drv_GlobalHeader.h"
#include "System_Drv.h"

#include "Sensor_Default_Drv.h"
#include "ISP_Drv.h"
#include "LDC_Drv.h"
//#include "Drv_GlobalHeader.h"

STRUCT_MW_SYSTEM	sMwSystem;
STRUCT_HAL_DELAY	sHalDelay;
STRUCT_HAL_INTERRUPT	sHalInt;
STRUCT_GLOBAL_CONSUMER_OPTION   sGco;
void ncDrv_Delay_Cnt(UINT32 mCnt)
{
    while(mCnt--){};
}


void ncDrv_VSIN_Skip(UCHAR Skip)   /* V Sync Input Negative Skip */
{
    sHalDelay.VSINSkip = 0;
    while(sHalDelay.VSINSkip < Skip);
}

void ncDrv_VSIP_Skip(UCHAR Skip)   /* V Sync Input Postive Skip */
{
    sHalDelay.VSIPSkip = 0;

	while(sHalDelay.VSIPSkip < Skip);

#if 0
	while(sHalDelay.VSIPSkip < Skip)
    {
        if(rSWReg.Category.SYSTEM.Reg.SENSOR_SYSTEM == 0)   break;
    }
#endif
}

void ncDrv_VSOP_Skip(UCHAR Skip)   /* V Sync Output Postive Skip */
{
    sHalDelay.VSOPSkip = 0;
    while(sHalDelay.VSOPSkip < Skip);
}

UCHAR ncDrv_ADCValue_Get(etADC_CHANNEL_TYPE Channel)
{
    return ISPGET08(aIP_ADC_CH0_DATA + Channel);

}

void ncDrv_ADCAverage_Task(void)
{
    sMwSystem.ADCValue[eADC_CH_0] = ISPGET08(aIP_ADC_CH0_DATA + eADC_CH_0);
    sMwSystem.ADCValue[eADC_CH_1] = ISPGET08(aIP_ADC_CH0_DATA + eADC_CH_1);
    sMwSystem.ADCValue[eADC_CH_2] = ISPGET08(aIP_ADC_CH0_DATA + eADC_CH_2);
    sMwSystem.ADCValue[eADC_CH_3] = ISPGET08(aIP_ADC_CH0_DATA + eADC_CH_3);
}

void ncDrv_StatusRegister_LinkFunction_Set(UINT32 waddr, UCHAR wdata)
{
#if 1
#define BIT_MENU_STATE		0x01

	UCHAR wdataOrig = ISPGET08(waddr);
	BOOL wdataCheck = TRUE;
	UCHAR preOsdView = rSWReg.Category.AE.Reg.AE_OSD_VIEW;/* [2014/09/04] sky : [STD]-01 */
	//UCHAR aLensMode = 0, aLensBoundary = 0;/* [2014/11/27] sky : [STD]-01 */

	/* [2014/2/20] JWLee : Address ���� ���ɿ��� üũ */
	if(IsInRage(waddr, ADDF_WDPC_STATE_START, ADDF_WDPC_STATE_END))	return;
	if(IsInRage(waddr, ADDF_BDPC_STATE_START, ADDF_BDPC_STATE_END)) 	return;
	if(IsInRage(waddr, ADDF_AE_INFO_START, ADDF_AE_INFO_END)) 			return;
	if(IsInRage(waddr, ADDF_SENSOR_INFO_START, ADDF_SENSOR_INFO_END))	return;
	if(IsInRage(waddr, ADDF_SFLASH_INFO_START, ADDF_SFLASH_INFO_END)) 	return;

	/* [2014/3/12] hyundong : Don`t Save Data for the Read Only Register (MENU_STATE)    */
	if(IsInRage(waddr, ADDF_MENU_STATE_START, ADDF_MENU_STATE_END))
	{
		wdata = wdata & (~BIT_MENU_STATE);
		wdata = wdata | (wdataOrig & BIT_MENU_STATE);
	}
    else if(IsInRage(waddr, ADDC_VM_START, ADDC_VM_END))
	{
		ncSvc_ViewMode_Update(1);
		if(IsInRage(waddr, ADDR_MORPHING_LUT_EN, ADDR_MORPHING_PIP_RATIO))
		{
			ncSvc_ViewMode_Update(2);
		}
		else if(IsInRage(waddr, ADDR_VIEW_MODE, ADDR_VIEW_MODE))
		{
			ncSvc_ViewMode_Update(3);
		}
		else if(IsInRage(waddr, ADDR_VM_1_LUT_INDEX, ADDR_VM_15_ETC))
		{
			ncSvc_ViewMode_Update(3);
		}

	}
	else if(IsInRage(waddr, ADDR_OSG_ON, ADDR_OSG_LAYER_6_DISPLAY_EN))					{ISPSET08(waddr, wdata);ncDrv_Osg_Refresh();}
	else if(IsInRage(waddr, ADDR_OSG_LAYER_0_INDEX_L_7_0, ADDR_OSG_LAYER_0_INDEX_H_9_8)){ncDrv_Osg_LayerIndexSet(OSG_LAYER0,wdata);}
	else if(IsInRage(waddr, ADDR_OSG_LAYER_1_INDEX_L_7_0, ADDR_OSG_LAYER_1_INDEX_H_9_8)){ncDrv_Osg_LayerIndexSet(OSG_LAYER1,wdata);}
	else if(IsInRage(waddr, ADDR_OSG_LAYER_2_INDEX_L_7_0, ADDR_OSG_LAYER_2_INDEX_H_9_8)){ncDrv_Osg_LayerIndexSet(OSG_LAYER2,wdata);}
	else if(IsInRage(waddr, ADDR_OSG_LAYER_3_INDEX_L_7_0, ADDR_OSG_LAYER_3_INDEX_H_9_8)){ncDrv_Osg_LayerIndexSet(OSG_LAYER3,wdata);}
	else if(IsInRage(waddr, ADDR_OSG_LAYER_4_INDEX_L_7_0, ADDR_OSG_LAYER_4_INDEX_H_9_8)){ncDrv_Osg_LayerIndexSet(OSG_LAYER4,wdata);}
	else if(IsInRage(waddr, ADDR_OSG_LAYER_5_INDEX_L_7_0, ADDR_OSG_LAYER_5_INDEX_H_9_8)){ncDrv_Osg_LayerIndexSet(OSG_LAYER5,wdata);}
	else if(IsInRage(waddr, ADDR_OSG_LAYER_6_INDEX_L_7_0, ADDR_OSG_LAYER_6_INDEX_H_9_8)){ncDrv_Osg_LayerIndexSet(OSG_LAYER6,wdata);}

	else if(IsInRage(waddr, ADDR_DPGL_EN_MODE, ADDR_DPGL_EN_MODE)){ISPSET08(waddr, wdata);ncDrv_DPGL_Enable(wdata);}
	else if(IsInRage(waddr, ADDR_DPGL_INDEX, ADDR_DPGL_INDEX))    {ISPSET08(waddr, wdata);ncDrv_DPGL_Set_Angel(wdata);}

	/* [2014/2/20] JWLee : ������   */
	ISPSET08(waddr, wdata);

	if(IsInRage(waddr, ADDR_LDC_LUT_LOAD_MODE, ADDR_LDC_LUT_LOAD_MODE))
	{
		ncLib_Ldc_Write(eLDC_LUT_LOAD_FLASH,wdata);
		ISPSET08(waddr, 0);
	}

	/* [2014/09/04] sky : [STD]-01 */
	if(preOsdView != rSWReg.Category.AE.Reg.AE_OSD_VIEW)	return;

	 /* [2014/2/20] JWLee : data ���Ἲ üũ */
	if(IsInRage(waddr, ADDC_TDN_START, ADDC_TDN_END))
	{
    	if(rSWReg.Category.TDN.Reg.GAP_INTEGRITY_CHECK == STATE_ON)
        {
    		if((waddr == ADDR_AUTO_D2N_AGC)||(waddr == ADDR_AUTO_N2D_AGC)||(waddr == ADDR_AUTO_GAP_AGC))
    			wdataCheck = IntegrityCheck(rSWReg.Category.TDN.Reg.AUTO_D2N_AGC, rSWReg.Category.TDN.Reg.AUTO_N2D_AGC, rSWReg.Category.TDN.Reg.AUTO_GAP_AGC);
    		else if((waddr == ADDR_AUTO_D2N_CDS)||(waddr == ADDR_AUTO_N2D_CDS)||(waddr == ADDR_AUTO_GAP_CDS))
    			wdataCheck = IntegrityCheck(rSWReg.Category.TDN.Reg.AUTO_D2N_CDS, rSWReg.Category.TDN.Reg.AUTO_N2D_CDS, rSWReg.Category.TDN.Reg.AUTO_GAP_CDS);
    		else if(IsInRage(waddr, ADDF_EXT_START, ADDF_EXT_END))
    			wdataCheck = IntegrityCheck(rSWReg.Category.TDN.Reg.EXT_D2N_CDS, rSWReg.Category.TDN.Reg.EXT_N2D_CDS, rSWReg.Category.TDN.Reg.EXT_GAP_CDS);
        }
	}
    else if(waddr == ADDR_ISP_INPUT_SIZE)
    {
        if(rSWReg.Category.MONITOR.Reg.MONITOR_OUTPUT == eMONITOR_AHD)
        {   /* AHD does not support 1080/60p mode */
            if((rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_SIZE == eSIZE_1920_1080) && (rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME >= eFRAME_RATE_60))
                wdataCheck = FALSE;
        }
    }

	/* [2014/2/20] JWLee : ����� */
	if(wdataCheck == FALSE)	{		ISPSET08(waddr, wdataOrig);		return;	}

	/* CALL CATEGORY FUNCTION */
    ncDrv_CategorySubCheck_Set(waddr);

#undef BIT_MENU_STATE
#endif

}

void ncDrv_MCU_Peripherals_Initialize_Set(void)
{

//    GlobalIntEnable;

    DEBUGMSG(MSGINFO, "n\r[ Copyright (C) 2012 NEXTCHIP Inc. ]\r\n");
//    ncDrv_IspVersion_Set();
//    ncDrv_Product_Set();

    ncDrv_DDRMemory_Address_Set();

    /*
    Sensor�Է� Clock�� ISP���� �ִ� �ý��ۿ��� ������ Ŭ���� �����
    ���޵��� �ʾ� �߰���.
    Added by shpark[20141009]
    */
//    ncDrv_ClockInitialize_Set();
}

void ncDrv_VariableInitialize_Boot_Set(void)
{

// 	ncDrv_Register_Load(USER_ALL_LOAD);
 	
//    ncDrv_PadMode_Set();
    
    rIP_MASK_SYSTEM_AREA_EN = 0;// ���� ����.
    
    sHalInt.Flag.D8[0] = 0x00;
    sHalInt.Flag.D8[1] = 0x00;
    sHalInt.Flag.D8[2] = 0x00;

//  System Control Init
    sMwSystem.Control.Run.AE = STATE_ON;
    sMwSystem.Control.Run.AWB = STATE_ON;
    sMwSystem.Control.Run.AFT = STATE_ON;
    sMwSystem.Control.Run.SpiEnable = STATE_ON;
	
	//ncLib_Ldc_Control(eLDC_DEINIT);

	sMwOpd.Size.Width = rIP_OPD_BLOCK_NUM_X + 1;
	sMwOpd.Size.Height = rIP_OPD_BLOCK_NUM_Y + 1;
	sMwOpd.Size.Total = sMwOpd.Size.Height*sMwOpd.Size.Width;

    sWdr.Ctrl.B8.TransitState = STATE_OFF;
    sWdr.Ctrl.B8.OpdToggleMode = eWDR_OPD_TOGGLE_OFF;
    
	sMwTdn.DayNightCount=0L;
	sMwTdn.DayNightCountOn=STATE_OFF;

	sMwTdn.DayNightSwitchCount = 0L;
	sMwTdn.DayNightSwitchCountOn= STATE_OFF;

	sMwTdn.CurrentTdnStatus = DN_STATUS_COLOR;
	sMwTdn.DayNightSwitchDelay = 0;
	
}

void ncDrv_SDR_Phase_Search(void)
{
    //rIP_SDR0_CLK_DLY  = 0x00;
}


void ncDrv_MCU_Synchronization_Task(void)
{
#if 0

    //-----------------------------------------------------------
    //  Clock Con Setting
    //-----------------------------------------------------------
    // Reset On
    rBank00.Byte.Reg_0xC0DE.D8 = 0xFF;  // SWRESET
    rBank00.Byte.Reg_0xC0DF.D8 = 0xEF;  // Dont't touch MCU Peri register
    rBank19.Byte.Reg_0xD9D5.B8.FDDR_RST_DQ_DIR = 0x00;

    rBank00.Byte.Reg_0xC010.D8 = 0x00;  // {SEL_LOGIC_TEST[7]=0, SEL_PLL_IN[6]=0, SEL_PLL2[5:4]=0, SEL_PLL1[3:2]=0, SEL_PLL0[1:0]=0}
    rBank00.Byte.Reg_0xC011.D8 = 0x00;  // {1'b0, SEL_ENC_SRC[6]=0, SEL_SENSOR_CLK[5]=1, SEL_SENSOR[4]=0, SEL_SENP_INV[3]=0, ADC_CLK_INV[2]=0, CKO_INV[1]=0, SEL_LVDS_INV[0]=0}
    rBank00.Byte.Reg_0xC012.D8 = 0x59;  // {2'h0, SEL_PMCLK[5:4]=1, SEL_TGCLK[3]=1, SEL_CLK_ADC[0]=1}

    #if (MCU_CLK == CLK_27MHZ)// MCU 27Mhz
    rBank00.Byte.Reg_0xC013.D8 = 0x10;
    #elif (MCU_CLK == CLK_13_5MHZ)// MCU 13.5Mhz
    rBank00.Byte.Reg_0xC013.D8 = 0x20;
    #elif (MCU_CLK == CLK_6_75MHZ)// MCU 6.75Mhz
    rBank00.Byte.Reg_0xC013.D8 = 0x30;
    #else// MCU 54Mhz
    rBank00.Byte.Reg_0xC013.D8 = 0x00;
    #endif

    rBank00.Byte.Reg_0xC014.D8 = 0xF7;  // CLK_EN, {CLK_SEN_EN[7], CLK_ISP_EN[6], CLK_BUS_EN[5], CLK_TG_EN[4], CLK_CVBS_EN[3], CLK_HD656_EN[2], CLK_FDDR_EN[1], CLK_SDDR_EN[0]}
    rBank00.Byte.Reg_0xC019.D8 = 0xFF;  // CLK_EN, {CLK_ISP_VBI_EN[7], CLK_ISP_WDR_EN[6], CLK_ISP_ZOOM_EN[5], CLK_ISP_DIS_EN[4], CLK_ISP_MOTION_EN[3], CLK_ADC_EN[2], CLK_MCUS0_EN[1], CLK_MCUS1_EN[0]}
    rBank00.Byte.Reg_0xC01A.D8 = 0x38;  // {SEL_CKO[7:6]=0, SEL_ISP_DIV3[5]=1, SEL_ISP_DIV2[4]=1, SEL_ISP_DIV1[3]=1, SEL_ISP_CK[2:0]=0}
    rBank00.Byte.Reg_0xC030.D8 = 0x00;  // DAC_CLK_INV[4], INVERT_IRIS[3], INVERT_CVBS[2], DAC_IRIS_PWDN[1], DAC_CVBS_PWDN[0]
    rBank19.Byte.Reg_0xD9D5.B8.FDDR_RST_DQ_DIR = 0x01;
#endif
}

void ncDrv_Sensor_Communication_Set(void)
{
#if 0
#if(SENSOR_COMM_TYPE == SENSOR_COMM_I2C)
	HAL_I2C_Open(I2C0, &sExtComm.I2C.Sensor);
	SENSOR.Write = ncDrv_I2c0_Write;
	SENSOR.Read = ncDrv_I2c0_Read;
#else
    HAL_SPI_Open(SPI0, &sExtComm.SPI.Sensor);
	SENSOR.Write = ncDrv_Spi0_Write;
	SENSOR.Read = ncDrv_Spi0_Read;
#endif
#endif

}

void ncDrv_Sensor_Reset(void)
{
    UCHAR i;

    rIP_GPMODE69 = 0x03;

    // FPGA Total 10ms Delay
    for( i = 0; i < 25; i++)
    {
       ncDrv_Delay_Set(100);
    }

    rIP_GPMODE69 = 0x0B;
}

void  ncDrv_DDRMemory_Set(INT32 Add, UCHAR Data[64])
{   // DDR Memory Write (64byte), waddr : 0x000000 ~ 0xFFFFFF
#if 0
    UCHAR   i, j;
    UCHAR   Area = 0;
    UCHAR   tBANK_H;
    UCHAR   tBANK_M;
    UCHAR   tBANK;

    sHalInt.Flag.Bit.SfrBank = TRUE;    /* [2015/07/09] Leo.Sim : [STD]-01 */

    //save current bank address
    tBANK_H     = rXSFR_BANK_H;
    tBANK_M     = rXSFR_BANK_M;
    tBANK       = rXSFR_BANK;

    Area    = (Add >> 24) & 0xFF;
    if(Area == 0x80)    rXSFR_BANK_H = 0x80;    // memory area0
    else                rXSFR_BANK_H = 0x81;    // memory area1

    rXSFR_BANK_M    = (Add >> 16) & 0xFF;
    rXSFR_BANK      = ((Add >> 8)& 0xFF);

    i = 0;
    j = Add & 0xC0;
    while(i<64)
    {
        (*(UCHAR *)(0xFF00+(j))) = (Data[i]);
        //HAL_XSFR_Set(j, Data[i]);
        i++;
        j++;
    }

    sHalInt.Flag.Bit.SfrBank = FALSE;   /* [2015/07/09] Leo.Sim : [STD]-01 */

#ifdef __MW_MCU_DEBUG__
	ncLib_DEBUG_Printf(1, "DDRWrite ");
	ncLib_DEBUG_Printf(1, "0x%x", rXSFR_BANK_H);
	ncLib_DEBUG_Printf(1, "%x", rXSFR_BANK_M);
	ncLib_DEBUG_Printf(1, "%x", rXSFR_BANK);
	ncLib_DEBUG_Printf(1, "%x : ", (Add & 0xC0));
	i = 0;
	while(i<64)
	{
		ncLib_DEBUG_Printf(1, "%x", Data[i]);
		i++;
	}

	ncLib_DEBUG_Printf(1, "\r\n");
#endif

    //restore current bank address
    rXSFR_BANK_H    = tBANK_H;
    rXSFR_BANK_M    = tBANK_M;
    rXSFR_BANK      = tBANK;

#endif
}

void  ncDrv_DDRMemory_Get(INT32 Add, UCHAR * Data)
{   // DDR Memory Read (64byte), waddr : 0x0000 ~ 0xFFFF
#if 0
    UCHAR   i, j;
    UCHAR   Area = 0;
    UCHAR   tBANK_H;
    UCHAR   tBANK_M;
    UCHAR   tBANK;

    sHalInt.Flag.Bit.SfrBank = TRUE;    /* [2015/07/09] Leo.Sim : [STD]-01 */

    //save current bank address
    tBANK_H     = rXSFR_BANK_H;
    tBANK_M     = rXSFR_BANK_M;
    tBANK       = rXSFR_BANK;

    Area = (Add >> 24) & 0xFF;
    if(Area == 0x80)    rXSFR_BANK_H = 0x80;    // memory area0
    else                rXSFR_BANK_H = 0x81;    // memory area1
    rXSFR_BANK_M = (Add >> 16) & 0xFF;
    rXSFR_BANK = ((Add >> 8) & 0xFF);

    i = 0;
    j = Add & 0xC0;
    while(i<64)
    {
        //Data[i] = HAL_XSFR_Get(j);
        Data[i] = *(SFR16)(0xFF00+(j));
        i++;
        j++;
    }

    sHalInt.Flag.Bit.SfrBank = FALSE;   /* [2015/07/09] Leo.Sim : [STD]-01 */

#ifdef __MW_MCU_DEBUG__
    ncLib_DEBUG_Printf(1, "DDRRead ");
    ncLib_DEBUG_Printf(1, "0x%x", rXSFR_BANK_H);
    ncLib_DEBUG_Printf(1, "%x", rXSFR_BANK_M);
    ncLib_DEBUG_Printf(1, "%x", rXSFR_BANK);
    ncLib_DEBUG_Printf(1, "%x : ", (Add & 0xC0));
    i = 0;
    while(i<64)
    {
        ncLib_DEBUG_Printf(1, "%x", Data[i]);
        i++;
    }
    ncLib_DEBUG_Printf(1, "\r\n");
#endif

    //restore current bank address
    rXSFR_BANK_H    = tBANK_H;
    rXSFR_BANK_M    = tBANK_M;
    rXSFR_BANK      = tBANK;
#endif
}


void MCU_PLL_CLK_Set(etPLL_CHANNEL PLLNum, etPLL_CLOCK PLLClk)
{
    typedef struct
    {
        UCHAR KDIV;
        UCHAR NDIV;
        UCHAR MDIV;
    }tPLL_DIV;

    tPLL_DIV PLLClockDivider[PLL_CLK_MAX] =
    {
  /* PLL_CLK_27M */       {0x03, 0x1F, 0x0F},
  /* PLL_CLK_36M */       {0x03, 0x1F, 0x0B},
  /* PLL_CLK_37p125M */   {0x03, 0x2B, 0x0F},
  /* PLL_CLK_45M */       {0x03, 0x27, 0x0B},
  /* PLL_CLK_48M */       {0x02, 0x1F, 0x0B},
  /* PLL_CLK_54M */       {0x03, 0x1F, 0x07},
  /* PLL_CLK_72M */       {0x03, 0x1F, 0x05},
  /* PLL_CLK_74p25M */    {0x03, 0x2B, 0x07},
  /* PLL_CLK_90M */       {0x03, 0x27, 0x05},
  /* PLL_CLK_96M */       {0x02, 0x1F, 0x05},
  /* PLL_CLK_108M */      {0x03, 0x1F, 0x03},
  /* PLL_CLK_120M */      {0x02, 0x27, 0x05},
  /* PLL_CLK_144M */      {0x02, 0x1F, 0x03},
  /* PLL_CLK_148p5M */    {0x03, 0x2B, 0x03},
  /* PLL_CLK_166p5M */    {0x05, 0x24, 0x01},
  /* PLL_CLK_333M */      {0x05, 0x24, 0x00},
  /* PLL_CLK_MAX */       /* CLOCK (MHz) = 54MHz / (KDIV+1) * (NDIV+1) / (MDIV+1) */
    };

    switch(PLLNum)
    {
        case PLL_CH0:
#if 0
            rIP_PLL0_EN = STATE_OFF;
            ncDrv_Delay_Cnt(1);
            rIP_PLL0_NF = 1;
            rIP_PLL0_NB = 1;
        	rIP_PLL0_OD = PLLClockDivider[PLLClk].KDIV;
        	rIP_PLL0_NR = PLLClockDivider[PLLClk].MDIV;
        	rIP_PLL0_NF = PLLClockDivider[PLLClk].NDIV;
        	rIP_PLL0_NB = PLLClockDivider[PLLClk].NDIV;
            ncDrv_Delay_Cnt(1);
            rIP_PLL0_INTFB  = STATE_ON;
            rIP_PLL0_TEST   = STATE_OFF;
            rIP_PLL0_EN     = STATE_ON;
            ncDrv_Delay_Cnt(1);
#endif
            break;

        case PLL_CH1:
#if 0
            rIP_PLL1_EN = STATE_OFF;
            ncDrv_Delay_Cnt(1);
            rIP_PLL1_NF = 1;
            rIP_PLL1_NB = 1;
        	rIP_PLL1_OD = PLLClockDivider[PLLClk].KDIV;
        	rIP_PLL1_NR = PLLClockDivider[PLLClk].MDIV;
  	        rIP_PLL1_NF = PLLClockDivider[PLLClk].NDIV;
        	rIP_PLL1_NB = PLLClockDivider[PLLClk].NDIV;
            ncDrv_Delay_Cnt(1);
            rIP_PLL1_INTFB   = STATE_ON;
            rIP_PLL1_TEST    = STATE_OFF;
            rIP_PLL1_EN      = STATE_ON;
            ncDrv_Delay_Cnt(1);
#endif
            break;

        case PLL_CH2:
#if 0
            rIP_PLL2_EN = STATE_OFF;
            ncDrv_Delay_Cnt(1);
            rIP_PLL2_NF = 1;
            rIP_PLL2_NB = 1;
        	rIP_PLL2_OD = 0x00;//PLLClockDivider[PLLClk].KDIV;
        	rIP_PLL2_NR = 0x05;//PLLClockDivider[PLLClk].MDIV;
        	rIP_PLL2_NF = 0x24;//PLLClockDivider[PLLClk].NDIV;
        	rIP_PLL2_NB = 0x24;//PLLClockDivider[PLLClk].NDIV;
            ncDrv_Delay_Cnt(1);
            rIP_PLL2_INTFB   = STATE_ON;
            rIP_PLL2_TEST    = STATE_OFF;
            rIP_PLL2_EN      = STATE_ON;
            ncDrv_Delay_Cnt(1);
#endif
            break;
    }
}


void MCU_PLL_Set(void)
{
/*========================================================================================
CVBS    PLL0 :       = 74.25 Mhz
        PLL1 :  960H = 72 Mhz
               1200H = 90 Mhz
               1280H = 96 Mhz
               1440H = 108 Mhz
               1920H = 144 Mhz
        PLL2 :       = 333 Mhz
------------------------------------------------------------------------------------------
HDSDI   PLL0 :       = 74.25 Mhz
        PLL1 :  960H = 72 Mhz
               1200H = 90 Mhz
               1280H = 96 Mhz
               1440H = 108 Mhz
               1920H = 144 Mhz
        PLL2 :       = 333 Mhz
------------------------------------------------------------------------------------------
AHD     PLL0 :       = 148.5 Mhz
        PLL1 :  960H = 72 Mhz
               1200H = 90 Mhz
               1280H = 96 Mhz
               1440H = 108 Mhz
               1920H = 144 Mhz
        PLL2 :       = 333 Mhz
==========================================================================================*/

etPLL_CLOCK PLL1_MAP[eCVBS_H_MAX]  = {PLL_CLK_54M, PLL_CLK_72M, PLL_CLK_90M, PLL_CLK_90M};

/*_________________________________ PLL0 (ISP)______________________________________*/
    MCU_PLL_CLK_Set(PLL_CH0, PLL_CLK_148p5M);

/*_________________________________ PLL1 (CVBS)_____________________________________*/
    MCU_PLL_CLK_Set(PLL_CH1, PLL1_MAP[(etCVBS_H_MODE)rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE]);

    if((etCVBS_H_MODE)rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE == eCVBS_H_1280H)
    {
        if(CVBS_FORMAT == eCVBS_PAL)
            MCU_PLL_CLK_Set(PLL_CH1, PLL_CLK_96M);
    }

    if((etMONITOR_OUT_MODE)sGco.MonitorOutput == eMONITOR_AHD)
    {
        if((etFRAME_SIZE)OUTPUT_SIZE == eSIZE_1280_720)
            MCU_PLL_CLK_Set(PLL_CH1, PLL_CLK_144M);
    }

/*_________________________________ PLL2 (SDRAM)____________________________________*/
    MCU_PLL_CLK_Set(PLL_CH2, PLL_CLK_333M);
}

/********************************************************************************
* Function Name : MCU_AHD_PN_Set
* Description   : HIDDEN VALUE FOR AHD (LIBRARY)
* Refer to      : API Document
* Argument      :
* Return        :
*********************************************************************************/
void MCU_AHD_PN_Set(void)
{
    rIP_AHD_FSC_EXT_PN_EN = STATE_OFF;

    rIP_AHD_BURST_PHASE = 1;

    rIP_AHD_FSC_EXT_PN_VALUE_31_24  = 0x00;
    rIP_AHD_FSC_EXT_PN_VALUE_23_16 = 0x00;
    rIP_AHD_FSC_EXT_PN_VALUE_15_8  = 0x00;
    rIP_AHD_FSC_EXT_PN_VALUE_7_0 = 0x00;
}


UCHAR SYSTEM_MemoryMap_Idx_Get(void)
{
    UCHAR MapIdx;
	UCHAR Panorama;

    if(OUTPUT_SIZE == eSIZE_1280_720)
    {
        rIP_ENABLE_CVBS_FRC = 1;

        if(OPTION_WDR_TYPE == eWDRTYPE_DOL3)
        {
            if(rSWReg.Category.MONITOR.Reg.MONITOR_OUTPUT == eMONITOR_CVBS){
                MapIdx = 1;
            }else{
                MapIdx = 0;
                rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE = eCVBS_H_720H;
		    }
        }
        else
        {
			Panorama = ncLib_Ldc_Read(eLDC_LUT_WRAP_LEVEL);
            if(Panorama != 0)
            {
                MapIdx = 4;
                rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE = eCVBS_H_720H;
            }
			else
            {
                if(rSWReg.Category.MONITOR.Reg.MONITOR_OUTPUT == eMONITOR_CVBS)
                {
                    MapIdx = 3;
                }
                else
                {
                    MapIdx = 2;
                    rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE = eCVBS_H_720H;
                }
            }
        }
    }
    else
    {
        if(rIP_LDC_EN)
        {
            rIP_ENABLE_CVBS_FRC = 0;
            MapIdx = 6;
        }
        else
        {
           	MapIdx = 5;
            rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE = eCVBS_H_720H;
        }
    }

	rSWReg.Category.SYSTEM.Reg.MEMORY_MAP = MapIdx;

    return MapIdx;

}

void SYSTEM_LBIC_Set(void)
{
#define ADDR_SET_COUNT  10
    UCHAR idx;
/*
    0: eWDRTYPE_OFF
    1: eWDRTYPE_DFRAME_1M
    2: eWDRTYPE_DFRAME_2M
    3: eWDRTYPE_DOL2
    4: eWDRTYPE_DOL3
    5: eWDRTYPE_DOL3to2
    6: eWDRTYPE_LWDR2
    7: eWDRTYPE_LWDR3
    8: eWDRTYPE_DCOMP_OV
    9: eWDRTYPE_DCOMP_AR
*/
    UCHAR LIBC_Set[5][eWDRTYPE_MAX] = {
/*          WDR TYPE :     0    1     2    3   4    5    6    7    8    9 */
/* LBIC_DPCM_MODE   */  { 0x0, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x0, 0x0 },
/* LBIC_DPCM_ENABLE */  { 0x0, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x0, 0x0 },
/* LBIC_INPUT_BIT   */  { 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0 },
/* LBIC_OUTPUT_SHFT */  { 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0 },
/* LBIC_OUTPUT_BIT  */  { 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x3, 0x0 },
    };

    USHORT Address[10][eWDRTYPE_MAX] = {
/*          WDR TYPE :     0        1       2       3       4       5       6       7       8       9 */
                        {0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000},
                        {0x0B40, 0x05A0, 0x05A0, 0x0B40, 0x02D0, 0x02D0, 0x05A0, 0x02D0, 0x0000, 0x05A0},
                        {0x0B40, 0x05A0, 0x05A0, 0x0B40, 0x02D0, 0x02D0, 0x0B40, 0x05A0, 0x0000, 0x05A0},
                        {0x0B40, 0x05A0, 0x05A0, 0x0B40, 0x05A0, 0x05A0, 0x0B40, 0x0870, 0x0000, 0x0B40},
                        {0x0B40, 0x05A0, 0x05A0, 0x0B40, 0x05A0, 0x05A0, 0x0B40, 0x0B40, 0x0000, 0x0B40},
                        {0x0000, 0x05A0, 0x05A0, 0x0000, 0x05A0, 0x05A0, 0x0000, 0x0000, 0x0000, 0x0000},
                        {0x0B40, 0x0B40, 0x0B40, 0x0B40, 0x0870, 0x0870, 0x05A0, 0x02D0, 0x0000, 0x05A0},
                        {0x0B40, 0x0B40, 0x0B40, 0x0B40, 0x0870, 0x0870, 0x0B40, 0x05A0, 0x0000, 0x05A0},
                        {0x0B40, 0x0B40, 0x0B40, 0x0B40, 0x0B40, 0x0B40, 0x0B40, 0x0870, 0x0000, 0x0B40},
                        {0x0B40, 0x0B40, 0x0B40, 0x0B40, 0x0B40, 0x0B40, 0x0B40, 0x0B40, 0x0000, 0x0B40}
    };

    rIP_LBIC_DPCM_MODE = LIBC_Set[0][sWdr.Type];
    rIP_LBIC_DPCM_ENABLE = LIBC_Set[1][sWdr.Type];
    rIP_LBIC_INPUT_BIT = LIBC_Set[2][sWdr.Type];
    rIP_LBIC_OUTPUT_SHFT = LIBC_Set[3][sWdr.Type];
    rIP_LBIC_OUTPUT_BIT = LIBC_Set[4][sWdr.Type];

    for(idx=0; idx< ADDR_SET_COUNT; idx++)
        ISPSET16((aIP_LBIC_MEM0_WADDR_E_7_0+(idx*2)), Address[idx][sWdr.Type]);

#undef ADDR_SET_COUNT
}



void SYSTEM_LBFRC_Set(void)
{
/*
    0: eWDRTYPE_OFF
    1: eWDRTYPE_DFRAME_1M
    2: eWDRTYPE_DFRAME_2M
    3: eWDRTYPE_DOL2
    4: eWDRTYPE_DOL3
    5: eWDRTYPE_DOL3to2
    6: eWDRTYPE_LWDR2
    7: eWDRTYPE_LWDR3
    8: eWDRTYPE_DCOMP_OV
    9: eWDRTYPE_DCOMP_AR
*/
    BOOL LBFRC_BitSet[15][eWDRTYPE_MAX] = {
/*                      WDR TYPE :   0  1  2  3  4  5  6  7  8  9 */
/* [00] LBFRC_BPORCH_EN         */ { 0, 0, 0, 1, 1, 1, 0, 0, 0, 0 },
/* [01] LBFRC_FPORCH_EN         */ { 0, 0, 1, 1, 1, 1, 0, 1, 0, 0 },
/* [02] LBFRC_FREERUN_EN        */ { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
/* [03] LBFRC_ENABLE            */ { 0, 1, 1, 1, 1, 1, 1, 1, 0, 0 },
/* [04] LBFRC_MEM_SEL           */ { 0, 1, 1, 0, 1, 1, 0, 0, 0, 0 },
/* [05] LBFRC_SEL_SRC           */ { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
/* [06] LBFRC_LWDR_CH_SEQ       */ { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
/* [07] LBFRC_LWDR_CH           */ { 0, 0, 0, 0, 0, 0, 0, 1, 0, 0 },
/* [08] LBFRC_LWDR_MODE         */ { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1 },
/* [09] LBFRC_LWDR_EN           */ { 0, 0, 0, 0, 0, 0, 1, 1, 0, 0 },
/* [10] LBFRC_WDR_DOL_MODE      */ { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
/* [11] LBFRC_WDR_DOL_MODE_CHG  */ { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
/* [12] LBFRC_WDR_ON_CHECK      */ { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
/* [13] LBFRC_WDR_FSKIP_LONG    */ { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
/* [14] LBFRC_WDR_FSKIP_SHORT   */ { 0, 1, 1, 0, 0, 0, 0, 0, 0, 0 }};

    rIP_LBFRC_BPORCH_EN = LBFRC_BitSet[0][sWdr.Type];
    rIP_LBFRC_FPORCH_EN = LBFRC_BitSet[1][sWdr.Type];
    rIP_LBFRC_FREERUN_EN = LBFRC_BitSet[2][sWdr.Type];
    rIP_LBFRC_ENABLE = LBFRC_BitSet[3][sWdr.Type];
    rIP_LBFRC_MEM_SEL = LBFRC_BitSet[4][sWdr.Type];
    rIP_LBFRC_SEL_SRC = LBFRC_BitSet[5][sWdr.Type];
    rIP_LBFRC_LWDR_CH_SEQ = LBFRC_BitSet[6][sWdr.Type];
    rIP_LBFRC_LWDR_CH = LBFRC_BitSet[7][sWdr.Type];
    rIP_LBFRC_LWDR_MODE = LBFRC_BitSet[8][sWdr.Type];
    rIP_LBFRC_LWDR_EN = LBFRC_BitSet[9][sWdr.Type];
    rIP_LBFRC_WDR_DOL_MODE = LBFRC_BitSet[10][sWdr.Type];
    rIP_LBFRC_WDR_DOL_MODE_CHG = LBFRC_BitSet[11][sWdr.Type];
    rIP_LBFRC_WDR_ON_CHECK = LBFRC_BitSet[12][sWdr.Type];
    rIP_LBFRC_WDR_FSKIP_LONG = LBFRC_BitSet[13][sWdr.Type];
    rIP_LBFRC_WDR_FSKIP_SHORT = LBFRC_BitSet[14][sWdr.Type];


    rIP_LBFRC_RBURST_CTRL = 0x04;
    rIP_LBFRC_WBURST_CTRL = 0x04;

    MONITOR_LBFRC_SIZE_Set(&sGco.OutputSize);
}


void SYSTEM_DECOMP_Set(void)
{
#define ADDR_SET_COUNT  5

    UCHAR idx;
	const UCHAR Address[eWDRTYPE_MAX][ADDR_SET_COUNT] = {
/* eWDR_OFF */      {0x00, 0x00, 0x00, 0x00, 0x00},
/* eWDR_DFRAME_1M */{0x00, 0x00, 0x00, 0x00, 0x00},
/* eWDR_DFRAME_2M */{0x00, 0x00, 0x00, 0x00, 0x00},
/* eWDR_DOL2 */     {0x00, 0x00, 0x00, 0x00, 0x00},
/* eWDR_DOL3 */     {0x00, 0x00, 0x00, 0x00, 0x00},
/* eWDR_DOL3to2 */  {0x00, 0x00, 0x00, 0x00, 0x00},
/* eWDR_LWDR2 */    {0x00, 0x00, 0x00, 0x00, 0x00},
/* eWDR_LWDR3 */    {0x00, 0x00, 0x00, 0x00, 0x00},
/* eWDR_DCOMP_OV */ {0x10, 0x20, 0x12, 0x20, 0x71},	// 14 -> 12
/* eWDR_DCOMP_AP */ {0x10, 0x20, 0x13, 0x20, 0x11},   /* APACHE3.5 */
    };

	const UCHAR DPCOMP_SET[eWDRTYPE_MAX][19] = {
/* eWDR_OFF */      {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
/* eWDR_DFRAME_1M */{0x00, 0x02, 0x00, 0xE8, 0xFF, 0x80, 0x05, 0x00, 0xE8, 0xFE, 0x80, 0x08, 0x00, 0x00, 0xF0, 0x02, 0x04, 0x06, 0x09},
/* eWDR_DFRAME_2M */{0x00, 0x02, 0x00, 0xE8, 0xFF, 0x80, 0x05, 0x00, 0xE8, 0xFE, 0x80, 0x08, 0x00, 0x00, 0xF0, 0x02, 0x04, 0x06, 0x09},
/* eWDR_DOL2 */     {0x00, 0x02, 0x00, 0xE8, 0xFF, 0x80, 0x05, 0x00, 0xE8, 0xFE, 0x80, 0x08, 0x00, 0x00, 0xF0, 0x02, 0x04, 0x06, 0x09},
/* eWDR_DOL3 */     {0x00, 0x02, 0x00, 0xE8, 0xFF, 0x80, 0x05, 0x00, 0xE8, 0xFE, 0x80, 0x08, 0x00, 0x00, 0xF0, 0x02, 0x04, 0x06, 0x09},
/* eWDR_DOL3to2 */  {0x00, 0x02, 0x00, 0xE8, 0xFF, 0x80, 0x05, 0x00, 0xE8, 0xFE, 0x80, 0x08, 0x00, 0x00, 0xF0, 0x02, 0x04, 0x06, 0x09},
/* eWDR_LWDR2 */    {0x00, 0x02, 0x00, 0xE8, 0xFF, 0x80, 0x05, 0x00, 0xE8, 0xFE, 0x80, 0x08, 0x00, 0x00, 0xF0, 0x02, 0x04, 0x06, 0x09},
/* eWDR_LWDR3 */    {0x00, 0x02, 0x00, 0xE8, 0xFF, 0x80, 0x05, 0x00, 0xE8, 0xFE, 0x80, 0x08, 0x00, 0x00, 0xF0, 0x02, 0x04, 0x06, 0x09},
/* eWDR_DCOMP_OV */ {0x00, 0x02, 0x00, 0xE8, 0xFF, 0x80, 0x05, 0x00, 0xE8, 0xFE, 0x80, 0x08, 0x00, 0x00, 0xF0, 0x02, 0x04, 0x06, 0x09},
/* eWDR_DCOMP_AP */ {0x00, 0x04, 0x00, 0xFC, 0xFF, 0x00, 0x0A, 0x00, 0xD0, 0xFE, 0x80, 0x0D, 0x00, 0x20, 0xFD, 0x00, 0x01, 0x05, 0x06}, //2016_03_23
    };


    for(idx=0; idx< ADDR_SET_COUNT; idx++)
    {
        ISPSET08((aIP_DECOMP_ISP_SHIFT_IN+idx), (Address[sWdr.Type][idx]&0xFF));
    }

    for(idx=0; idx< 19; idx++)
    {
        ISPSET08((aIP_DECOMP_X0_7_0+idx), DPCOMP_SET[sWdr.Type][idx]);
    }

#undef ADDR_SET_COUNT
}

void SYSTEM_OVERAY_MUX_Set(UCHAR AddrMapIdx)
{
#if 0
    if(AddrMapIdx == 1 || AddrMapIdx == 3)
    {   /* DIGITAL OUTPUT OFF */
        rIP_OVLY_MUX_CVBS_CROP_ORDER = 0;
        rIP_OVLY_MUX_BMD_YC444_ORDER = 2;
        rIP_OVLY_MUX_BOX_GRID_ORDER	 = 1;
        rIP_OVLY_MUX_OSG_ORI_ORDER	 = 5;
        rIP_OVLY_MUX_OTP_ORDER	     = 4;
        rIP_OVLY_MUX_OSG_ORDER	     = 7;
        rIP_OVLY_MUX_PGL_ORDER	     = 6;
        rIP_OVLY_MUX_OF_ORDER	     = 9;
        rIP_OVLY_MUX_OSD_ORDER	     = 8;
    }
    else
    {
        rIP_OVLY_MUX_BOX_GRID_ORDER	 = 0;
        rIP_OVLY_MUX_BMD_YC444_ORDER = 0;
        rIP_OVLY_MUX_OTP_ORDER	     = 0;
        rIP_OVLY_MUX_OSG_ORI_ORDER	 = 0;
        rIP_OVLY_MUX_PGL_ORDER	     = 0;
        rIP_OVLY_MUX_OSG_ORDER	     = 0;
        rIP_OVLY_MUX_OF_ORDER	     = 0;
        rIP_OVLY_MUX_CVBS_CROP_ORDER = 0;
        rIP_OVLY_MUX_OSD_ORDER	     = 0;
    }
#endif
	// ����ȣ (�ؽ�ƮĨ/������/ASIC�׷�/SOC��)
	rIP_OVLY_MUX_BOX_GRID_ORDER  	= 1;
	rIP_OVLY_MUX_BMD_YC444_ORDER 	= 2;
	rIP_OVLY_MUX_OTP_ORDER 	 		= 3;
	rIP_OVLY_MUX_OSG_ORI_ORDER  	= 7;
	rIP_OVLY_MUX_PGL_ORDER 	 		= 5;
	rIP_OVLY_MUX_OSG_ORDER 	 		= 6;
	rIP_OVLY_MUX_DPGL_ORDER	  		= 8;
	rIP_OVLY_MUX_OSD_ORDER 			= 0xB;
	rIP_OVLY_MUX_OF_ORDER			= 9;
	rIP_OVLY_MUX_CVBS_CROP_ORDER 	= 9;
}

void ncDrv_DDRMemory_Address_Set(void)
{
 	UCHAR idx;
    UCHAR IdxMapBuf[18]={0};
    UCHAR MemIdx = SYSTEM_MemoryMap_Idx_Get();


#if 0

	INT32 MemoryAddress[19] = {
		/* 00 */ { 0x08080000 }, //[2] CVBS1
		/* 01 */ { 0x080FE900 }, //[3] CVBS2
		/* 02 */ { 0x08080000 },  //[4][5]
		/* 03 */ { 0x0817D400 },  //[6]
		/* 04 */ { 0x0849A000 },
		/* 05 */ { 0x083EF400 },
		/* 06 */ { 0x083FAC00 },
		/* 07 */ { 0x0823A000 },
		/* 08 */ { 0x08239EC0 },  //[7]
		/* 09 */ { 0x08298560 },
		/* 10 */ { 0x084CEC00 },
		/* 11 */ { 0x0850D800 },
		/* 12 */ { 0x08519000 },
		/* 13 */ { 0x08298800 },
		/* 14 */ { 0x084D3C00 },
		/* 15 */ { 0x086AE400 },
		/* 16 */ { 0x08298800 },
		/* 17 */ { 0x087CC800 },
		/* 18 */ { 0x084B8800 }, };  //[0][1] DPC


    UCHAR IdxMap[18][5] = { /* Refer to APACHE2.8_Application_Setting_Guide.xlsx */
/* [00] 0x0745	DPC_R_READ_ADDR           */  { 18, 18, 18, 18, 15, },
/* [01] 0x074A	DPC_W_WRITE_ADDR          */  { 18, 18, 18, 18, 15, },
/* [02] 0x1C6D	CVBS_ADDR_1               */  {  0,  0,  0,  0,  0, },
/* [03] 0x1C71	CVBS_ADDR_2               */  {  1,  1,  1,  1,  1, },
/* [04] 0x09B3	DNR_RB_READ_ADDR          */  {  2,  2,  2,  2,  2, },
/* [05] 0x09C7	DNR_WB_WRITE_ADDR         */  {  2,  2,  2,  2,  2, },
/* [06] 0x2AA0	LBFRC_SDRAM0_ADDR_E       */  {  3,  3,  3,  3,  2, },
/* [07] 0x2AA4	LBFRC_SDRAM0_ADDR_O       */  {  8,  8,  8,  9,  2, },
/* [08] 0x2AA8	LBFRC_SDRAM1_ADDR_E       */  {  7,  7,  7,  3,  2, },
/* [09] 0x2AAC	LBFRC_SDRAM1_ADDR_O       */  {  9,  9,  9,  9,  2, },
/* [10] 0x2AB0	LBFRC_SDRAM_ADDR_MAX      */  {  9,  9,  9,  9,  2, },
/* [11] 0x280D	LDC_WMAIN_START_ADDR      */  { 13, 13, 13, 13,  7, },
/* [12] 0x2838	LDC_PIP_WMAIN_START_ADDR  */  { 13, 16, 16, 16, 14, },
/* [13] 0x2824	LDC_LUT_BASE_ADDR0        */  { 13,  4,  4,  9,  3, },
/* [14] 0x2828	LDC_LUT_BASE_ADDR1        */  { 13, 14, 14, 10,  4, },
/* [15] 0x282C	LDC_PIP_LUT_BASE_ADDR0    */  { 13, 11, 11, 11,  5, },
/* [16] 0x2830	LDC_PIP_LUT_BASE_ADDR1    */  { 13, 12, 12, 12,  6, },
/* [17] 0x1DD0	OSD_BUS_BASEADDR          */  { 13, 17, 17, 17, 15, }, };
#endif

	INT32 MemoryAddress[23] = {
	/* 00 */ { 0x08080000 },     //0x8080000	  //CVBS 1
	/* 01 */ { 0x0814A800 },     //0x8117E00    //CVBS 2

	/* 02 */ { 0x08215000 },	 //0x81AFC00    //DNR

	/* 03 */ { 0x083E4000 },     //0x837BC00    //LBFRC E
	/* 04 */ { 0x084A0AC0 },     //0x83B5800    //LBFRC O
	/* 05 */ { 0x084A0C00 },     //0x83EF400    //LBFRC E
	/* 06 */ { 0x084FF160 },	 //0x83FAC00    //LBFRC O

	/* 07 */ { 0x08409400 },     //0x8406400
	/* 08 */ { 0x0843B6C0 },     //0x8437400
	/* 09 */ { 0x0843B800 },     //0x8495000
	/* 10 */ { 0x08499C20 },	 //0x84CEC00
	/* 11 */ { 0x08499D60 },     //0x8508800
	/* 12 */ { 0x082CB000 },     //0x8514000


	/* 13 */ { 0x08401000 },     //0x851F800
	/* 14 */ { 0x085C3000 },	 //0x85C8400
	/* 15 */ { 0x083E4000 },     //0x86AE400
	/* 16 */ { 0x083F2800 },	 //0x86E1800
	/* 17 */ { 0x08401000 },     //0x87C7800
	/* 18 */ { 0x086B1400 },	 //0x87E7800


	/* 19 */ { 0x084FF400 },
	/* 20 */ { 0x085C3000 },

	/* 21 */ { 0x086C4000 },      //DPC
	/* 22 */ { 0x08600400 },};    //DPC


    UCHAR IdxMap[18][5] = { /* Refer to APACHE2.8_Application_Setting_Guide.xlsx */
	/* [00] 0x0745	DPC_R_READ_ADDR           */  { 22, 21, 21, 21, 18, },
	/* [01] 0x074A	DPC_W_WRITE_ADDR          */  { 22, 21, 21, 21, 18, },

	/* [02] 0x1C6D	CVBS_ADDR_1               */  {  0,  0,  0,  0,  0, },
	/* [03] 0x1C71	CVBS_ADDR_2               */  {  1,  1,  1,  1,  1, },

	/* [04] 0x09B3	DNR_RB_READ_ADDR          */  {  2,  2,  2,  2,  2, },
	/* [05] 0x09C7	DNR_WB_WRITE_ADDR         */  {  2,  2,  2,  2,  2, },

	/* [06] 0x2AA0	LBFRC_SDRAM0_ADDR_E       */  {  3,  3,  2,  2,  2, },
	/* [07] 0x2AA4	LBFRC_SDRAM0_ADDR_O       */  {  4,  8,  2,  2,  2, },
	/* [08] 0x2AA8	LBFRC_SDRAM1_ADDR_E       */  {  5,  9,  2,  2,  2, },
	/* [09] 0x2AAC	LBFRC_SDRAM1_ADDR_O       */  {  6, 11,  2,  2,  2, },
	/* [10] 0x2AB0	LBFRC_SDRAM_ADDR_MAX      */  {  6, 11,  2,  2,  2, },

	/* [11] 0x280D	LDC_WMAIN_START_ADDR      */  { 19, 16, 13, 13,  7, },
	/* [12] 0x2838	LDC_PIP_WMAIN_START_ADDR  */  { 19, 19, 14, 14, 17, },
	/* [13] 0x2824	LDC_LUT_BASE_ADDR0        */  { 19, 12, 15, 15,  3, },
	/* [14] 0x2828	LDC_LUT_BASE_ADDR1        */  { 19, 13, 16, 16,  4, },
	/* [15] 0x282C	LDC_PIP_LUT_BASE_ADDR0    */  { 19, 14, 17, 17,  5, },
	/* [16] 0x2830	LDC_PIP_LUT_BASE_ADDR1    */  { 19, 15, 17, 17,  6, },

	/* [17] 0x1DD0	OSD_BUS_BASEADDR          */  { 19, 20, 20, 20, 18, } };


    //DEBUGMSG(MSGINFO,"MemIdx = %d\n",MemIdx);

    for(idx=0; idx<18; idx++)   IdxMapBuf[idx] = IdxMap[idx][MemIdx];

    /* DPC */

    ISPSET32(aIP_DPC_R_READ_ADDR_7_0, MemoryAddress[IdxMapBuf[0]]);
    ISPSET32(aIP_DPC_W_WRITE_ADDR_7_0, MemoryAddress[IdxMapBuf[1]]);

    sGco.DDRADDDPC1 = MemoryAddress[IdxMapBuf[0]];
    sGco.DDRADDDPC2 = sGco.DDRADDDPC1 + 0x2000; //0x1000;

    /* CVBS */

    ISPSET32(aIP_CVBS_ADDR_1_7_0, MemoryAddress[IdxMapBuf[2]]);
    ISPSET32(aIP_CVBS_ADDR_2_7_0, MemoryAddress[IdxMapBuf[3]]);

    /* DNR */

    ISPSET32(aIP_DNR_RB_READ_ADDR_7_0, MemoryAddress[IdxMapBuf[4]]);
    ISPSET32(aIP_DNR_WB_WRITE_ADDR_7_0, MemoryAddress[IdxMapBuf[5]]);

    /* LBFRC */

    ISPSET32(aIP_LBFRC_SDRAM0_ADDR_E_7_0, MemoryAddress[IdxMapBuf[6]]);
    ISPSET32(aIP_LBFRC_SDRAM0_ADDR_O_7_0, MemoryAddress[IdxMapBuf[7]]);
    ISPSET32(aIP_LBFRC_SDRAM1_ADDR_E_7_0, MemoryAddress[IdxMapBuf[8]]);
    ISPSET32(aIP_LBFRC_SDRAM1_ADDR_O_7_0, MemoryAddress[IdxMapBuf[9]]);
    ISPSET32(aIP_LBFRC_SDRAM_ADDR_MAX_7_0, MemoryAddress[IdxMapBuf[10]]);

    /* LDC */
	ISPSET32(aIP_LDC_WMAIN_START_ADDR_7_0, MemoryAddress[IdxMapBuf[11]]);

    ISPSET32(aIP_PIP_WMAIN_START_ADDR_7_0, MemoryAddress[IdxMapBuf[12]]);

	//DEBUGMSG(MSGINFO, "LDC_WMAIN_START_ADDR %x \n",MemoryAddress[IdxMapBuf[11]]);
	//DEBUGMSG(MSGINFO, "PIP_WMAIN_START_ADDR %x \n",MemoryAddress[IdxMapBuf[12]]);

	ncLib_Ldc_Write(eLDC_LUT_BASEADDR, MemoryAddress[IdxMapBuf[13]]);

	//DEBUGMSG(MSGINFO, "LDC_WMAIN_START_ADDR %X  ", MemoryAddress[IdxMapBuf[11]]);
	//DEBUGMSG(MSGINFO, "PIP_WMAIN_START_ADDR %X  ", MemoryAddress[IdxMapBuf[12]]);
	//DEBUGMSG(MSGINFO, "LUT_BASEADDR %X\n", MemoryAddress[IdxMapBuf[13]]);

    /* OSD */

    ISPSET32(aIP_O_OSD_BUS_BASEADDR_7_0, MemoryAddress[IdxMapBuf[17]]);

    sGco.DDRADDOSD = MemoryAddress[IdxMapBuf[17]];

    SYSTEM_LBFRC_Set();
    SYSTEM_LBIC_Set();
    SYSTEM_DECOMP_Set();

    SYSTEM_OVERAY_MUX_Set(MemIdx);
}

void ncDrv_FWSys_Reset(void)
{
    UCHAR sFlashISP[3] = {0,};

#if 0
    MW_SFlashData_Erase_Set(SFLASH_MODE_INFOR_ADDR);

    sFlashISP[0] = rSWReg.Category.MONITOR.Reg.MONITOR_OUTPUT;
    sFlashISP[1] = REGRW8(APACHE_ISP_BASE, ADDR_MONITOR_OUTPUT_AHD);
    sFlashISP[2] = rSWReg.Category.MONITOR.Reg.MONITOR_OUTPUT;

    MW_SFlashData_Set(SFLASH_MODE_INFOR_ADDR,3L,&sFlashISP[0]);
#endif

    ncDrv_FWIsp_Reset();
}

void ncDrv_FWIsp_Reset(void)
{
#if 0
    HAL_Timer_Close(TIMER2);
    HAL_Timer_Open(TIMER_RESET);
    SYSTEM_RESET(TRUE);
#endif
}

void ncDrv_FWSys_ChangeMode_Reset(UCHAR Mode)
{
#if 0
    UCHAR sFlashISP[3] = {0,};

    rSWReg.Category.MONITOR.Reg.MONITOR_OUTPUT = Mode;

    MW_SFlashData_Erase_Set(SFLASH_MODE_INFOR_ADDR);

    sFlashISP[0] = rSWReg.Category.MONITOR.Reg.MONITOR_OUTPUT;
    sFlashISP[1] = REGRW8(APACHE_ISP_BASE, ADDR_MONITOR_OUTPUT_AHD);
    sFlashISP[2] = sHalSystem.SubVideoChangeMode;

    MW_SFlashData_Set(SFLASH_MODE_INFOR_ADDR,3L,&sFlashISP[0]);

    HAL_Timer_Close(TIMER2);
    HAL_Timer_Open(TIMER_RESET);

    //rCLK_EN2 = 1;

    SYSTEM_RESET(TRUE);
#endif
}
//}


void ncDrv_MainFRC_Reset(void)
{
    if(sGco.MonitorOutput == eMONITOR_AHD)
    {
#if 0
        GlobalIntEnable;

		ncDrv_VSIP_Skip(1);
        //MW_VSIP_Skip(1);
#endif
        sGco.FrcResetFlag  = TRUE;
    }
}


void ncDrv_MainFRC_Reset_Control(void)
{
    UCHAR DealyCntMSB = CVBS_FORMAT ? rSWReg.Category.SYSTEM.Reg.FRC_RESET_DELAY_NTSC_19_16 : rSWReg.Category.SYSTEM.Reg.FRC_RESET_DELAY_PAL_19_16;
    USHORT DealyCnt = ISPGET16(CVBS_FORMAT ? ADDR_FRC_RESET_DELAY_NTSC_7_0 : ADDR_FRC_RESET_DELAY_PAL_7_0);

    rIP_FRC_SYNC_MODE  = STATE_OFF;       // Main FRC Off
    //rIP_SWRESET_MISP = STATE_ON;

    do{
        while(DealyCnt--);
    }while(DealyCntMSB--);

    //rIP_SWRESET_MISP = STATE_OFF;
    rIP_FRC_SYNC_MODE  = STATE_ON;        // Main FRC On
}

