
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __NR_DRV_H__
#define __NR_DRV_H__

/********************************************************************************
* Function Name 	: ncDrv_NR_Set()
* Description		: 
					- Edge preserving 2D NR & Motion adaptive 3D NR
					- 2D / 3D NR : OFF / LOW / MIDDLE / HIGH
					- 2D / 3D NR : OFF / LOW / MIDDLE / HIGH
* Refer to		: API Document
* Argument		:	
										 
* Return			: 
					@ [TRUE]		: Success
					@ [Error Code]	: Fail (API Reference Guide)
********************************************************************************/
void ncDrv_NR_Set(void);

/********************************************************************************
* Function Name 	: MW_Nr_Auto()
* Description		: 2DNR & 3DNR Auto Control
* Refer to		: API Document
* Argument		:	
										 
* Return			: 
					@ [TRUE]		: Success
					@ [Error Code]	: Fail (API Reference Guide)
********************************************************************************/
void ncDrv_NR_Auto(void);
void ncDrv_DNR_WB_WRAP_Set(BOOL ModeSet);

//void ncDrv_DNR_IMG_Set(stIMAGE_SIZE_INFO * SetSize);
//void NR_Set2D(void);
//void ncDrv_NR_Set3D_Debug(void);


#endif

