
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2015.08.03		pychan		1.0		NCFW Platform Revision
********************************************************************************/


#ifndef __SVC_VIEW_MODE__
#define __SVC_VIEW_MODE__

typedef union
{
	UCHAR D8[0x03];
	
	struct
	{
		UCHAR LUT_INDEX: 8;
		UCHAR PIP_INDEX: 8;
		UCHAR ETC: 2;
	 	UCHAR PIP_MARGIN: 2;
		UCHAR PIP_POSITION: 4;
	}B8;
	
}PSTRUCT_VM_ATTR;

typedef union
{
	UCHAR D8[0x02];

	struct
	{
		UCHAR TYPE: 4;
		UCHAR ADDR_11_8: 4;
		UCHAR ADDR_7_0: 8;
	}B8;
	
}OSG_LUT_HEADER_LIST __attribute__ ((aligned (8)));

typedef union
{
	UCHAR B8[0x10];
	struct
	{
		ULONG  NAME 		: 32;// 0 1 2 3
		UCHAR  Type 		: 8; // 4 
		USHORT	reserved	: 16;// 5 6
		UCHAR  Index		: 8; // 7
		USHORT StartAddr	: 16;// 8 9
		USHORT Size 		: 16;// A B
		ULONG  LIST_ADDR	: 32;// C D E F
	}Common;

	struct
	{
		USHORT reserved1		: 16;
		USHORT reserved2		: 16;			
		UCHAR  reserved3		: 8;		
		USHORT	Cnt 			: 16;
		USHORT reserved4		: 16;			
		USHORT reserved5		: 16;
		USHORT reserved6		: 16;
		USHORT reserved7		: 16;			
		USHORT reserved8		: 8;			
	}OsgData;

	struct
	{
		USHORT reserved1		: 16;
		USHORT reserved2		: 16;			
		UCHAR  reserved3		: 8;		
		UCHAR  ModelType		: 8;
		UCHAR  Cnt				: 8;		
		USHORT reserved4		: 16;			
		USHORT reserved5		: 16;
		USHORT reserved6		: 16;
		USHORT reserved7		: 16;			
		USHORT reserved8		: 8;			
	}LutData;

}OSG_LUT_HEADER __attribute__ ((aligned (8)));

void ncSvc_ViewMode_Initialize(void);
void ncSvc_ViewMode_Task(void);
void ncSvc_ViewMode_ChangeViewMode(void);

void ncSvc_ViewMode_Update(UCHAR mode);



#endif

