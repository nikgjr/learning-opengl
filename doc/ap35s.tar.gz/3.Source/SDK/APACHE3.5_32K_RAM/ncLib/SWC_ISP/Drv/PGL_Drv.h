
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __PGL_DRV__
#define __PGL_DRV__

typedef enum
{
	PGL_INIT = 0,
	
	PGL_UP,      			
	PGL_DOWN,      			
	
	PGL_HLTOP,
	PGL_HLBTM,
	PGL_HRTOP,
	PGL_HRBTM,

	PGL_VTOP,
	PGL_VBTM,

	PGL_COLORV1,
	PGL_COLORV2,
	PGL_COLORV3,
	PGL_COLORV4,

	PGL_ALPHAV1,
	PGL_ALPHAV2,
	PGL_ALPHAV3,
	PGL_ALPHAV4,

	
	PGL_CMD_ON,
	PGL_CMD_OFF,

	PGL_VAL_CHECK,
	
}ePGL_CMD;


void ncDrv_PGL_Initialize(void);
void ncDrv_PGL_Onoff(UCHAR OnOff);

void ncDrv_PGL_HLTOP(UCHAR UpDown);
void ncDrv_PGL_HLBTM(UCHAR UpDown);
void ncDrv_PGL_HRTOP(UCHAR UpDown);
void ncDrv_PGL_HRBTM(UCHAR UpDown);

void ncDrv_PGL_VTOP(UCHAR UpDown);
void ncDrv_PGL_VBTM(UCHAR UpDown);

void ncDrv_PGL_ColorV1(UCHAR UpDown);
void ncDrv_PGL_ColorV2(UCHAR UpDown);
void ncDrv_PGL_ColorV3(UCHAR UpDown);
void ncDrv_PGL_ColorV4(UCHAR UpDown);

void ncDrv_PGL_AlphaV1(UCHAR UpDown);
void ncDrv_PGL_AlphaV2(UCHAR UpDown);
void ncDrv_PGL_AlphaV3(UCHAR UpDown);
void ncDrv_PGL_AlphaV4(UCHAR UpDown);

void ncDrv_ValCheck(USHORT	Address);



#endif

