
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Api_GlobalHeader.h"

#define DETECT_MODE_PAL	 1
#define DETECT_MODE_STSC 2
#define DETECT_MODE_ALL	 3
#define DETECT_MODE_DIFF 7



#define FLK_50hz	50
#define FLK_60hz	60

#define FLK_ACC_WIN_NUM     32
#define FPS_NUM			    8


#define DETEC_DELAY_AFTER_SET 		30
#define DETEC_DELAY_AFTER_GET_50 	2
#define DETEC_DELAY_AFTER_GET_60 	1

#define DETEC_TTIME_SET_50HZ 	5			    
#define DETEC_TTIME_GET_50HZ_1 	DETEC_TTIME_SET_50HZ  + DETEC_DELAY_AFTER_SET
#define DETEC_TTIME_GET_50HZ_2 	DETEC_TTIME_GET_50HZ_1+ DETEC_DELAY_AFTER_GET_50
#define DETEC_TTIME_GET_50HZ_3 	DETEC_TTIME_GET_50HZ_2+ DETEC_DELAY_AFTER_GET_50
#define DETEC_TTIME_GET_50HZ_4 	DETEC_TTIME_GET_50HZ_3+ DETEC_DELAY_AFTER_GET_50

#define DETEC_TTIME_SET_60HZ 	DETEC_TTIME_GET_50HZ_4+ DETEC_DELAY_AFTER_GET_50
#define DETEC_TTIME_GET_60HZ_1 	DETEC_TTIME_SET_60HZ  + DETEC_DELAY_AFTER_SET
#define DETEC_TTIME_GET_60HZ_2 	DETEC_TTIME_GET_60HZ_1+ DETEC_DELAY_AFTER_GET_60
#define DETEC_TTIME_GET_60HZ_3 	DETEC_TTIME_GET_60HZ_2+ DETEC_DELAY_AFTER_GET_60
#define DETEC_TTIME_GET_60HZ_4 	DETEC_TTIME_GET_60HZ_3+ DETEC_DELAY_AFTER_GET_60

#define DETEC_TTIME_DETEC_50 		DETEC_TTIME_GET_50HZ_4+ 1
#define DETEC_TTIME_DETEC_60 		DETEC_TTIME_GET_60HZ_4+ 1
#define DETEC_TTIME_DETEC_END 		DETEC_TTIME_DETEC_60 + 30




#define IS_CURR_50Hz (DetecFlickerHz==50)
#define IS_CURR_60Hz (DetecFlickerHz==60)

#define FLK_MODE1 rSWReg.Category.USER.Reg.FLK_MODE1
#define FLK_MODE2 rSWReg.Category.USER.Reg.FLK_MODE2
#define FLK_MODE3 rSWReg.Category.USER.Reg.FLK_MODE3
#define FLK_MODE4 rSWReg.Category.USER.Reg.FLK_MODE4
#define FLK_MODE5 rSWReg.Category.USER.Reg.FLK_MODE5
#define FLK_MODE6 rSWReg.Category.USER.Reg.FLK_MODE6


#define FLK_MODE_AUTO_TIME 1
#define FLK_MODE_AUTO_AREA 2
#define FLK_MODE_MANUAL_50 3
#define FLK_MODE_MANUAL_60 4

#define DETEC_STATE_WAIT 0
#define DETEC_STATE_CHECK 1

#define DETEC_NT2PAL_TH 0x8000
#define DETEC_PAL2NT_TH 0x8600
#define DETEC_LOW_CNT_TH 15





USHORT FLKWinOpdBuff[FPS_NUM][FLK_ACC_WIN_NUM];
USHORT FrameDiffBuff[2][FLK_ACC_WIN_NUM];

UINT32 FrameDiffBuffAvr[2];
USHORT FrameDiffBuffmax[2];
USHORT FrameDiffBuffmin[2];
UINT32 FrameDiffBuffAvr2;

USHORT CntLow[2];


UCHAR FrameCnt = 0x00;
UCHAR detecState = 0x00;
UCHAR DetecFlickerHz = 0x00;
USHORT TH=0;
UCHAR WaitCnt=0;
UCHAR Disp=0;




void ncDrv_Flicker_Initialize(void)
{
	USHORT IMAGE_WIDTH  =1280;
	USHORT IMAGE_HEIGHT =720;

	rIP_FLK_HSTART = (IMAGE_WIDTH * 10 / 100) / 2;   // ���� Size�� 10%�� Blank�� �Ѵ�.
	rIP_FLK_VSTART = IMAGE_HEIGHT / (FLK_ACC_WIN_NUM + 2);
	
	rIP_FLK_HWIDTH_7_0  = (IMAGE_WIDTH - (rIP_FLK_HSTART * 2));
	rIP_FLK_HWIDTH_12_8 = (IMAGE_WIDTH - (rIP_FLK_HSTART * 2))>>8;
	
	rIP_FLK_VHEIGHT = rIP_FLK_VSTART;

	rIP_FLK_RANGE = 0x03;
	
	FLK_MODE1 = OFF;
	FLK_MODE2 = 1;
	rIP_FLK_MODE = 0x01;
	
	DetecFlickerHz = FLK_60hz;
	detecState = DETEC_STATE_CHECK;
	Disp=0;
	
	ncDrv_MD_SetFlicker();
}

void ncDrv_Flicker_Task(void)
{
	static UCHAR oldMode =0xff;

	if(oldMode != FLK_MODE1)
	{
		oldMode = FLK_MODE1;
		ncDrv_OSDClear_Set();
		FrameCnt = 0;
		ncDrv_Flicker_ChangeOutputFormat();
	}

	if(FLK_MODE2==3)
	{
		FLK_MODE2=1;
		detecState = DETEC_STATE_CHECK;
		FrameCnt = 0;
	}
	else if(FLK_MODE2==2)
	{
		FLK_MODE2=0;
		detecState = DETEC_STATE_CHECK;
		FrameCnt = 0;
	}
	else if(FLK_MODE2==6)
	{
		FLK_MODE2=0;
		Disp = !Disp;
	}

	
	switch(FLK_MODE1)
	{
		case FLK_MODE_AUTO_TIME: ncDrv_Flicker_Auto_Time_Task(); break;
		//case FLK_MODE_AUTO_AREA: ncDrv_Flicker_Area_OPD_VIEW(); break;
		case FLK_MODE_MANUAL_50: rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_TYPE = 0;  break;
		case FLK_MODE_MANUAL_60: rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_TYPE = 1;  break;
	}

	FrameCnt++;

//OSD OUT
#if 0
	if(Disp)
	{
		APP_OSDPrint_Dec(1, 33,FrameCnt);
		
		switch(detecState)
		{
			case DETEC_STATE_WAIT	: APP_OSDPrint_String(1,28,"WAIT "); break;
			case DETEC_STATE_CHECK	: 
				if(FrameCnt > DETEC_TTIME_DETEC_60)
					APP_OSDPrint_String(1,28,"C END"); 
				else
					APP_OSDPrint_String(1,28,"CHECK"); 
				break;
		}
		
		if(CVBS_FORMAT == eCVBS_PAL)
		{
			APP_OSDPrint_String(0,15,"        ");	
			APP_OSDPrint_String(0,1,"PAL ");	
			APP_OSDPrint_Dec(0, 5,(USHORT)((sMwAe.Tracking.SV)>>10));	
			
			APP_OSDPrint_Hex2(18, 7,  FrameDiffBuffAvr2 );
			APP_OSDPrint_String(18, 21,  "        " );

			//APP_OSDPrint_Hex2(19, 1,  FrameDiffBuffmin[0] );
			//APP_OSDPrint_Hex2(19, 7,  FrameDiffBuffmax[0] );

			APP_OSDPrint_Hex2(19, 7,  TH );
			
			APP_OSDPrint_Dec(20, 1,CntLow[0]);
		}
		else
		{
			APP_OSDPrint_String(0,1,"        ");
			APP_OSDPrint_String(0,15,"NT ");
			APP_OSDPrint_Dec(0, 18,(USHORT)((sMwAe.Tracking.SV)>>10));	
			
			APP_OSDPrint_Hex2(18, 21,  FrameDiffBuffAvr2 );
			APP_OSDPrint_String(18, 7,  "     " );

			//APP_OSDPrint_Hex2(19, 15,  FrameDiffBuffmin[1] );
			//APP_OSDPrint_Hex2(19, 21,  FrameDiffBuffmax[1] );

			APP_OSDPrint_Hex2(19, 21,  TH );
			APP_OSDPrint_Dec(20, 15,CntLow[1]);
		}
	}
	else
	{
		if(CVBS_FORMAT == eCVBS_PAL)
		{
			APP_OSDPrint_String(0,15,"        ");	
			APP_OSDPrint_String(0,1,"PAL ");	
		}
		else
		{
			APP_OSDPrint_String(0,1,"        ");
			APP_OSDPrint_String(0,1,"NT ");
		}
	}
#endif


}


void ncDrv_Flicker_Win_Get(UCHAR FrameNum)
{
    UCHAR WinNum = 0;
    UCHAR Offset = 0;

#if 1
	UINT16 OpdVal = 0;

    for(WinNum = 0; WinNum < FLK_ACC_WIN_NUM/2; WinNum++)
    {
		Offset = (WinNum * 2);
		OpdVal = MAKEWORD( REGRW8(aIP_FLK_ACC_WIN0_15_8,Offset) , REGRW8(aIP_FLK_ACC_WIN0_7_0,Offset) );
	    FLKWinOpdBuff[FrameNum][WinNum]    = OpdVal;
		OpdVal = MAKEWORD( REGRW8(aIP_FLK_ACC_WIN16_15_8,Offset) , REGRW8(aIP_FLK_ACC_WIN16_7_0,Offset) );
		FLKWinOpdBuff[FrameNum][16+WinNum] = OpdVal;
	}
#endif
}



void ncDrv_Flicker_WinData_Compare(UCHAR mode)
{
	UCHAR FrameNum=0;
	UCHAR WinNum=0;
	USHORT WinMin=0xffff;
	USHORT WinMax=0;

	if(mode&1)
	{
		FrameDiffBuffAvr[0]  = 0;		
		FrameDiffBuffmax[0]	= 0;
		FrameDiffBuffmin[0]	= 0xffff;
		
		for(WinNum = 0; WinNum < FLK_ACC_WIN_NUM; WinNum++)
		{
			WinMin=0xffff;	WinMax=0;
			for(FrameNum = 0; FrameNum < (FPS_NUM/2); FrameNum++)
			{
				if(WinMin > FLKWinOpdBuff[FrameNum][WinNum])
					WinMin = FLKWinOpdBuff[FrameNum][WinNum];
				if(WinMax < FLKWinOpdBuff[FrameNum][WinNum])
					WinMax = FLKWinOpdBuff[FrameNum][WinNum];
			}
			FrameDiffBuff[0][WinNum] = WinMax - WinMin;
			FrameDiffBuffAvr[0] += FrameDiffBuff[0][WinNum];

			if(FrameDiffBuffmin[0] > FrameDiffBuff[0][WinNum])
				FrameDiffBuffmin[0] = FrameDiffBuff[0][WinNum];
			if(FrameDiffBuffmax[0] < FrameDiffBuff[0][WinNum])
				FrameDiffBuffmax[0] = FrameDiffBuff[0][WinNum];
		}	
		FrameDiffBuffAvr[0] = FrameDiffBuffAvr[0] - FrameDiffBuffmin[0] - FrameDiffBuffmax[0];
		FrameDiffBuffAvr[0]  = FrameDiffBuffAvr[0]/(FLK_ACC_WIN_NUM-2);
	}
	
	if(mode&2)
	{
		FrameDiffBuffAvr[1] = 0;		
		FrameDiffBuffmax[1] = 0;
		FrameDiffBuffmin[1] = 0xffff;
		
		for(WinNum = 0; WinNum < FLK_ACC_WIN_NUM; WinNum++)
		{
			WinMin=0xffff;	WinMax=0;
			for(FrameNum = (FPS_NUM/2); FrameNum < FPS_NUM; FrameNum++)
			{
				if(WinMin > FLKWinOpdBuff[FrameNum][WinNum])
					WinMin = FLKWinOpdBuff[FrameNum][WinNum];

				if(WinMax < FLKWinOpdBuff[FrameNum][WinNum])
					WinMax = FLKWinOpdBuff[FrameNum][WinNum];
			}
			FrameDiffBuff[1][WinNum] = WinMax - WinMin;
			FrameDiffBuffAvr[1] += FrameDiffBuff[1][WinNum];

			if(FrameDiffBuffmin[1] > FrameDiffBuff[1][WinNum])
				FrameDiffBuffmin[1] = FrameDiffBuff[1][WinNum];
			if(FrameDiffBuffmax[1] < FrameDiffBuff[1][WinNum])
				FrameDiffBuffmax[1] = FrameDiffBuff[1][WinNum];

		}
		FrameDiffBuffAvr[1] = FrameDiffBuffAvr[1] - FrameDiffBuffmin[1] - FrameDiffBuffmax[1];
		FrameDiffBuffAvr[1] = FrameDiffBuffAvr[1]/(FLK_ACC_WIN_NUM-2);
	}		
	
	if(mode&4)
	{
		CntLow[0]=CntLow[1]=0;
		for(WinNum = 0; WinNum < FLK_ACC_WIN_NUM; WinNum++)
		{
			if(FrameDiffBuff[0][WinNum] < FrameDiffBuff[1][WinNum])
				CntLow[0]++;
			else if(FrameDiffBuff[0][WinNum] > FrameDiffBuff[1][WinNum])
				CntLow[1]++;
		}

	}	
		
}





void ncDrv_Flicker_ChangeOutputFormat(void)
{
#if 1
	static UCHAR CVBS = 0;
	if(CVBS != CVBS_FORMAT)
	{
		CVBS = CVBS_FORMAT;
		ncDrv_OutputFormat_Set_Flicker(); 
	}
#endif
}

void ncDrv_Flicker_SetCvbsFormat(UCHAR mode)
{
	if(mode==eCVBS_PAL)
	{
		rSWReg.Category.AE.Reg.SHUTTER = rSWReg.Category.AE.Reg.MANUAL_LENS_SHUT=3;
		//3 is anti shut
		//use PAL shut
	}
	else if(mode==eCVBS_NTSC)
	{
		rSWReg.Category.AE.Reg.SHUTTER = rSWReg.Category.AE.Reg.MANUAL_LENS_SHUT=3;
		//3 is anti shut
		//use NT shut
	}
	
	rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_TYPE  = mode;
	ncDrv_OutputFormat_Set_Flicker(); 
}


void ncDrv_Flicker_Time_OPD_VIEW(UCHAR mode)
{
#if 0
	UCHAR WinNum = 0;
	for(WinNum = 0; WinNum < 16; WinNum++)
	{
		APP_OSDPrint_Hex2(1+WinNum, 1,  FrameDiffBuff[0][WinNum] );
		if(mode)
			APP_OSDPrint_Hex2(1+WinNum, 15,  FrameDiffBuff[1][WinNum] );
		DEBUGMSG(MSGWARN, "%04x, ", FrameDiffBuff[0][WinNum]);
	}
	for(WinNum = 0; WinNum < 16; WinNum++)
	{
		APP_OSDPrint_Hex2(1+WinNum, 7,  FrameDiffBuff[0][16+WinNum] );
		if(mode)
			APP_OSDPrint_Hex2(1+WinNum, 21,  FrameDiffBuff[1][16+WinNum] );
		DEBUGMSG(MSGWARN, "%04x, ", FrameDiffBuff[0][16+WinNum]);
	}
		DEBUGMSG(MSGWARN, "\n");
#endif	
	if(Disp)
	{
	APP_OSDPrint_Hex2(18, 1,	FrameDiffBuffAvr[0] );
	if(mode)
		APP_OSDPrint_Hex2(18, 15,  FrameDiffBuffAvr[1] );
	}



}

void ncDrv_Flicker_Area_OPD_VIEW(void)
{
#if 0
	UCHAR WinNum = 0;

	rIP_FLK_MODE = 0x00;
	rIP_FLK_DIFF_TH = 0x20;

	switch(FrameCnt)
	{
		case 1	: ncDrv_Flicker_Win_Get(0); 	break;
		case 2	: ncDrv_Flicker_Win_Get(1); 	break;

		case 3	:
			for(WinNum = 0; WinNum < 16; WinNum++)
			{
				APP_OSDPrint_Hex2(1+WinNum, 1,  FLKWinOpdBuff[0][WinNum] );
			}
			
			for(WinNum = 0; WinNum < 16; WinNum++)
			{
				APP_OSDPrint_Hex2(1+WinNum, 7,  FLKWinOpdBuff[0][16+WinNum] );
			}
		break;

		case 4	:
			for(WinNum = 0; WinNum < 16; WinNum++)
			{
				if(FLKWinOpdBuff[1][WinNum] > FLKWinOpdBuff[0][WinNum])
					APP_OSDPrint_Hex2(1+WinNum, 15,  FLKWinOpdBuff[1][WinNum]-FLKWinOpdBuff[0][WinNum] );
				else
					APP_OSDPrint_Hex2(1+WinNum, 15,  FLKWinOpdBuff[0][WinNum]-FLKWinOpdBuff[1][WinNum] );
			}
			
			for(WinNum = 0; WinNum < 16; WinNum++)
			{
				if(FLKWinOpdBuff[1][16+WinNum] > FLKWinOpdBuff[0][16+WinNum])
					APP_OSDPrint_Hex2(1+WinNum, 21,  FLKWinOpdBuff[1][16+WinNum]-FLKWinOpdBuff[0][16+WinNum] );
				else
					APP_OSDPrint_Hex2(1+WinNum, 21,  FLKWinOpdBuff[0][16+WinNum]-FLKWinOpdBuff[1][16+WinNum] );
			}

		break;


		case 5	:
			for(WinNum = 0; WinNum < FLK_ACC_WIN_NUM; WinNum++)
			{
				DEBUGMSG(MSGWARN, "%04x, ", FLKWinOpdBuff[0][WinNum]);
			}
			DEBUGMSG(MSGWARN, "\n");

			FrameCnt=0;
		break;

			
	}
	
	
#endif
}



void ncDrv_Flicker_Auto_TimeStateWait(void)
{
	UCHAR FPSNum = 0;
	UINT32 *BuffAvr;

	

	static UCHAR AvrCnt = 0x00;
	static UINT16 SumDiffarr[6];

	UINT16 SumDiffarrOld =0;
		
	UINT16 MdBox1=ISPGET16(aIP_BMD_MD0_WIN0_THCNT_7_0);
	UINT16 MdBox2=ISPGET16(aIP_BMD_MD0_WIN1_THCNT_7_0);
	UINT16 MdBox3=ISPGET16(aIP_BMD_MD1_WIN0_THCNT_7_0);
	
	UINT16 MdCheckOK=1;

#if 1
	if(MdBox3>0x5 &&(FrameCnt>=1&&FrameCnt<=4))
	{
		detecState = DETEC_STATE_WAIT;
		FrameCnt=0;
		//APP_OSDPrint_String(1,28,"MD   ");
		if(Disp)
		{
			APP_OSDPrint_Hex2(3, 28,  MdBox1  );
			APP_OSDPrint_Hex2(4, 28,  MdBox2  );
			APP_OSDPrint_Hex2(5, 28,  MdBox3  );
		}
		else
			APP_OSDPrint_String(2,1,"MOTION");
		//DEBUGMSG(MSGWARN, "MD return\n");
		
		return;
	}
	if(!Disp)
		APP_OSDPrint_String(2,1,"      ");
#endif
	
	if(CVBS_FORMAT == eCVBS_PAL)
	{	
		FPSNum = 0;
		BuffAvr = &FrameDiffBuffAvr[0];
		TH = DETEC_PAL2NT_TH;
		TH = TH + (FLK_MODE3*0x100);
	}									  
	else
	{	
		FPSNum = 4;
		BuffAvr = &FrameDiffBuffAvr[1];
		TH = DETEC_NT2PAL_TH;
		TH = TH + (FLK_MODE4*0x100);
	}
	
#if 0
	if( ((sMwAe.Tracking.SV)>>10) < 70 )
	{
		TH = TH - 0x1000;
	}
#endif
		
	switch(FrameCnt)
	{
		case 0	: 
			WaitCnt=0;
			AvrCnt = 0;
			SumDiffarr[0]=SumDiffarr[1]=SumDiffarr[2]=SumDiffarr[3]=SumDiffarr[4]=SumDiffarr[5]=0;
			FrameDiffBuffAvr2=0;
			break;
		case 1	: ncDrv_Flicker_Win_Get(FPSNum+0);	break;
		case 2	: ncDrv_Flicker_Win_Get(FPSNum+1);	break;
		case 3	: ncDrv_Flicker_Win_Get(FPSNum+2);	break;
		case 4	: ncDrv_Flicker_Win_Get(FPSNum+3);	break;
		case 5	: 
			if(WaitCnt<0x20);
				WaitCnt++;
				
			FrameCnt=1;
			ncDrv_Flicker_WinData_Compare(DETECT_MODE_DIFF); 	

			ncDrv_Flicker_Time_OPD_VIEW(1);
						
			SumDiffarr[AvrCnt] = (UINT16)*BuffAvr;
			SumDiffarrOld = FrameDiffBuffAvr2;
			FrameDiffBuffAvr2 = (SumDiffarr[0]+SumDiffarr[1]+SumDiffarr[2]+SumDiffarr[3]+SumDiffarr[4]+SumDiffarr[5])/6;

		if(Disp)
		{
		APP_OSDPrint_Hex2(3, 28,  MdBox1  );
		APP_OSDPrint_Hex2(4, 28,  MdBox2  );
		APP_OSDPrint_Hex2(5, 28,  MdBox3  );
		}

		
#if 0
			0x50 //  43%/B9 MdBoxFull 1/120
			0x74 //  62%/B9 MdBoxFull 1/240
			0x80 //  69%/B9 MdBoxFull 1/480
#endif

			if(_abs(MdBox1,MdBox2)>0x80 )
				MdCheckOK=0;

			if(MdCheckOK && FLK_MODE2==1)
			{
				WaitCnt=1;

				if ( CVBS_FORMAT == eCVBS_NTSC && FrameDiffBuffAvr2 > TH )
				{


					SumDiffarr[0]=SumDiffarr[1]=SumDiffarr[2]=SumDiffarr[3]=SumDiffarr[4]=SumDiffarr[5]=0;
					FrameDiffBuffAvr2=0;
					ncDrv_Flicker_SetCvbsFormat(eCVBS_PAL);
					rSWReg.Category.AE.Reg.SHUTTER = rSWReg.Category.AE.Reg.MANUAL_LENS_SHUT=1;
					//ncSvc_AE_Reset();
					FrameCnt =210;
				}
				
				else if( CVBS_FORMAT == eCVBS_PAL && (( WaitCnt>=0x18&&(FrameDiffBuffAvr2)>SumDiffarrOld+0x1000)||FrameDiffBuffAvr2 > TH) )
				{

					SumDiffarr[0]=SumDiffarr[1]=SumDiffarr[2]=SumDiffarr[3]=SumDiffarr[4]=SumDiffarr[5]=0;
					FrameDiffBuffAvr2=0;
					ncDrv_Flicker_SetCvbsFormat(eCVBS_NTSC);
					rSWReg.Category.AE.Reg.SHUTTER = rSWReg.Category.AE.Reg.MANUAL_LENS_SHUT=1;
					//ncSvc_AE_Reset();
					FrameCnt =210;
					
				}
				
				
			}

			AvrCnt++;
			if(AvrCnt>5)
				AvrCnt = 0;			
			break;
	}

}


void ncDrv_Flicker_Auto_TimeStateCheck(void)
{
	 UCHAR WinNum = 0;

	ULONG AvrDiff=0;
	ULONG WinDiff=0;

	UINT16 MdBox3=ISPGET16(aIP_BMD_MD1_WIN0_THCNT_7_0);
#if 1

	if(MdBox3>0x5 && ( (FrameCnt>=10&&FrameCnt<=13)|| (FrameCnt>=24&&FrameCnt<=27) )	)
	{
		detecState = DETEC_STATE_CHECK;
		FrameCnt=0;
		//APP_OSDPrint_String(1,28,"MD_CK ");

		//APP_OSDPrint_Hex2(5, 28,  MdBox3  );
		
		//DEBUGMSG(MSGWARN, "MD_CHECK return\n");
		return;
	}
#endif

	rIP_FLK_MODE = 0x01;
	switch(FrameCnt)
	{
		case DETEC_TTIME_SET_50HZ	:  ncDrv_Flicker_SetCvbsFormat(eCVBS_PAL); break;
		case DETEC_TTIME_GET_50HZ_1	:  ncDrv_Flicker_Win_Get(0);		 break;
		case DETEC_TTIME_GET_50HZ_2	:  ncDrv_Flicker_Win_Get(1);		 break;
		case DETEC_TTIME_GET_50HZ_3	:  ncDrv_Flicker_Win_Get(2);		 break;
		case DETEC_TTIME_GET_50HZ_4	:  ncDrv_Flicker_Win_Get(3);		 break;

		case DETEC_TTIME_SET_60HZ 	:  ncDrv_Flicker_SetCvbsFormat(eCVBS_NTSC); break;
		case DETEC_TTIME_GET_60HZ_1	:  ncDrv_Flicker_Win_Get(4); 		 break;
		case DETEC_TTIME_GET_60HZ_2	:  ncDrv_Flicker_Win_Get(5); 		 break;
		case DETEC_TTIME_GET_60HZ_3	:  ncDrv_Flicker_Win_Get(6); 		 break;
		case DETEC_TTIME_GET_60HZ_4	:  ncDrv_Flicker_Win_Get(7); 		 break;

		case DETEC_TTIME_DETEC_60	: 
			
			
			ncDrv_Flicker_WinData_Compare(DETECT_MODE_DIFF);
			ncDrv_Flicker_Time_OPD_VIEW(1);


#if 0
			AvrDiff = _abs(FrameDiffBuffAvr[0], FrameDiffBuffAvr[1]);

			for(WinNum = 0; WinNum < FLK_ACC_WIN_NUM; WinNum++)
			{
				if(FrameDiffBuff[0][WinNum] > FrameDiffBuff[1][WinNum])
				{
					WinDiff = FrameDiffBuff[0][WinNum] - FrameDiffBuff[1][WinNum];
					
					if(WinDiff > AvrDiff)
						CntLow[1]++;
				}
				else if(FrameDiffBuff[1][WinNum] > FrameDiffBuff[0][WinNum])
				{
					
					WinDiff = FrameDiffBuff[1][WinNum] - FrameDiffBuff[0][WinNum];
					
					if(WinDiff > AvrDiff)
						CntLow[0]++;
				}
			}
#endif
			AvrDiff = _abs(CntLow[0] , CntLow[1]);

			 if(CntLow[0] < CntLow[1] && CntLow[1]>=DETEC_LOW_CNT_TH&&AvrDiff>5)
				DetecFlickerHz = FLK_60hz;
			 else if(CntLow[0] >= CntLow[1] || CntLow[0] >= 0x16/*&& CntLow[0]>=DETEC_LOW_CNT_TH&&AvrDiff>5*/)
				 DetecFlickerHz = FLK_50hz;
			 else if(FrameDiffBuffAvr[1]>DETEC_NT2PAL_TH)
					DetecFlickerHz = FLK_50hz;
				

#if 0
			if(Disp)
			{
			APP_OSDPrint_Dec(20, 7,CntLow[0]);
			APP_OSDPrint_Dec(20, 21,CntLow[1]);
			}
#endif
			
			if(IS_CURR_50Hz)
			{	
				ncDrv_Flicker_SetCvbsFormat(eCVBS_PAL);
			}
			
			rSWReg.Category.AE.Reg.SHUTTER = rSWReg.Category.AE.Reg.MANUAL_LENS_SHUT=1;
		
			break;	 
			
			case DETEC_TTIME_DETEC_END	: 
				FrameCnt=0;
				detecState = DETEC_STATE_WAIT; 
			break;	 
	}
		


	
}

void ncDrv_Flicker_Auto_Time_Task(void)
{
  	switch(detecState)
	{
		case DETEC_STATE_WAIT	: ncDrv_Flicker_Auto_TimeStateWait();  break;
		case DETEC_STATE_CHECK	: ncDrv_Flicker_Auto_TimeStateCheck(); break;
	}
}






