/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Drv_GlobalHeader.h"
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Sensor_Default_Drv.h"

#if (SENSOR_SELECT == SENSOR_DEFAULT)

void ncDrv_SENSOR_Initial_Set(void)
{
#define REG_NUM	10L
const USHORT SensorInit[REG_NUM][2]={
	{0x0000, 0x00},
	{0x0001, 0x00},
	{0x0002, 0x00},
	{0x0003, 0x00},
	{0x0004, 0x00},
	{0x0005, 0x00},
	{0x0006, 0x00},
	{0x0007, 0x00},
	{0x0008, 0x00},
	{0x0009, 0x00},	
};
	UCHAR RegIdx;

/*______________________SENSOR COMMUNICATION SETTING_______________________________*/
    //MW_Sensor_Reset();
	//ncDrv_DelayMs_Set(10);	
	
    
/*_________________________________________________________________________________*/

	for(RegIdx=0; RegIdx<REG_NUM; RegIdx++)
	{
		//SENSOR.Write(SensorInit[RegIdx][0],SensorInit[RegIdx][1]);
	}

	ncLib_DEBUG_Printf(1, "#Default Sensor Type:Sensor#\r\n");
}

const STRUCT_SENSOR_INTERFACE_TYPE sSensorInterface = {
/* [IIF H/V PORCH]         */
/*       720P HFLIP OFF,ON */    {{{ 0x00, 0x00 },                /* NOT TUNED */
/*            VFLIP OFF,ON */      { 0x00, 0x00 }},               /* NOT TUNED */
/*      1080P HFLIP OFF,ON */     {{ 0x00, 0x1A },                /* [2015/10/16] Jwlee */
/*            VFLIP OFF,ON */      { 0x0B, 0x23 }}},              /* [2015/10/16] Jwlee */
/* [INPUT H TOTAL]         */
/* WDR OFF  720P PAL, NTSC */  {{{ 0x0A4C, 0x10AA },
/* WDR OFF 1080P PAL, NTSC */    { 0x0A4C, 0x898  }},
/* WDR ON   720P PAL, NTSC */   {{ 0x0A4C, 0x10AA },
/* WDR ON  1080P PAL, NTSC */    { 0x0A4C, 0x898  }}},
               };

void ncDrv_SENSOR_FPS_Set(void)
{
#define SENSOR_H_TOTAL_NTSC     2400L
#define SENSOR_H_TOTAL_PAL      2880L
#define SENSOR_H_START_NTSC     0xB0
#define SENSOR_H_START_PAL      0xB2

    USHORT HTotalSize = CVBS_FORMAT ? SENSOR_H_TOTAL_NTSC : SENSOR_H_TOTAL_PAL;
    USHORT HStartPos =  CVBS_FORMAT ? SENSOR_H_START_NTSC : SENSOR_H_START_PAL;
     
#undef SENSOR_H_TOTAL_NTSC
#undef SENSOR_H_TOTAL_PAL
#undef SENSOR_H_START_NTSC
#undef SENSOR_H_START_PAL

}

void ncDrv_SENSOR_Mirror_Set(UCHAR Mode)
{
	switch(Mode)
	{
		case eFLIP_OFF:			break;
		case eFLIP_MIRROR:		break;
		case eFLIP_V:			break;
		case eFLIP_ROTATE:		break;
	}
}

const UCHAR SENSOR_DIFF_LIMIT = 0;
const UCHAR SENSOR_EXPOSURE_MIN = 1;
const USHORT SENSOR_VTOTAL_DEFAULT[eSIZE_MAX] = {750, 1125};
    
void ncDrv_SENSOR_Exposure_Set(STRUCT_AE_SET_TYPE * AeSet)
{

}

#if((OPTION_WDR_TYPE == WDRTYPE_DFRAME_1M)||(OPTION_WDR_TYPE==WDRTYPE_DFRAME_2M))

void ncDrv_SENSOR_WDR_Exposure_Set(UCHAR WDR_Ch)
{

}
#endif

#endif




