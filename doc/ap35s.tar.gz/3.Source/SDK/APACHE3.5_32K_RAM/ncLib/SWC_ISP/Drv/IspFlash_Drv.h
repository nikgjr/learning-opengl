/*
********************************************************************************
*
*  Copyright (C) 2013 NEXTCHIP Inc. All rights reserved.
*
*  @file    : IspFlash_Drv.h
*
*  @brief   : APACHE ISP flash memory module driver header file
*
*  @author  : Alessio / Automotive SoC Software Team
*
*  @date    : 2013.12.23
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 2013.12.23 - ISP flash memory basic driver modified by Alessio
*
********************************************************************************
*/

#ifndef __ISPFLASH_DRV_H__
#define __ISPFLASH_DRV_H__
#include "FlashMemoryMap.h"

/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


 /* 1. sFlash ISP Area Load Select */
#define USER_ALL_LOAD					0x00 /* USER ALL(ISP & Status) Default Load*/
#define BUFFER_ALL_LOAD					0x01 /* BUFFER ALL(ISP & Status) Default Load*/
#define FACTORY_ALL_LOAD				0x02 /* Factory ALL(ISP & Status) Default Load */
 
/* 2. sFlash Factory Default Load Select */
#define FACTORY_STATUS_BLC_LOAD			0x10 /* Status BLC Default Load */
#define FACTORY_STATUS_HSBLC_LOAD		0x11 /* Status HSBLC Default Load */
#define FACTORY_STATUS_MOTION_LOAD		0x12 /* Status MOTION Default Load */
#define FACTORY_STATUS_PRIVACY_LOAD		0x13 /* Status PRIVACY Default Load */
#define FACTORY_STATUS_DEFOG_LOAD		0x14 /* Status DEFOG Default Load */
#define	FACTORY_STATUS_RESERVED_LOAD	0x15 /* Status RESERVED */


#define USER_ISP_SAVE 					0x01
#define BUFFER_ISP_SAVE 				0x02
#define FACTORY_ISP_SAVE 				0x04


#define ISP_USER_AREA		1
#define ISP_BUFFER_AREA		2
#define ISP_FACTORY_AREA	3

/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern int ncDrv_ISP_FlashMemory_AllSave(UINT8 area);
extern int ncDrv_ISP_FlashMemory_AllLoad(UINT8 area);
extern int ncDrv_ISP_FlashMemory_CategorySave(UINT32 address, UINT32 length, UINT8 *buffer);
extern int ncDrv_ISP_FlashMemory_CategoryLoad(UINT32 address, UINT32 length, UINT8 *buffer);
extern int ncDrv_ISP_FlashMemory_StatusLoad(UINT8 area);
extern int ncDrv_ISP_FlashMemory_StatusSave(UINT8 area);
extern int ncDrv_ISP_FlashMemory_SCULoad(UINT8 area);
extern int ncDrv_ISP_FlashMemory_SCUSave(UINT8 area);
extern void ncDrv_ISP_Flashmemory_Default_Load(UCHAR LoadArea);

extern int ncDrv_ISP_FlashMemory_Lut_Load(UINT8 area);

ULONG ISP_FlashAddress_StartPoint_Get(UCHAR Load) ;
ULONG ISP_FlashAddress_CheckSumAddr_Get(UCHAR Load);

#endif  /* __ISPFLASH_DRV_H__ */


/* End Of File */
