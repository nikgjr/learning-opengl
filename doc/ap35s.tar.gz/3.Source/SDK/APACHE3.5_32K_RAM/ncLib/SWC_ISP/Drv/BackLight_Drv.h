
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __BACKLIGHT_DRV__
#define __BACKLIGHT_DRV__

void ncDrv_Blc_Mirror(void);
void ncDrv_Blc_Flip(void);
void ncDrv_Hsblc_Mirror(void);
void ncDrv_Hsblc_Flip(void);

void ncDrv_HSBLC_Auto(void);
void ncDrv_Backlight_Mode_Set(void);
void ncDrv_HSBLC_ReSize(void);

#endif

