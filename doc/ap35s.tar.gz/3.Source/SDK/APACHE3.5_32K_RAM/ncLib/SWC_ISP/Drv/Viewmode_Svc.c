

/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2015.08.03		pychan		1.0		NCFW Platform Revision
********************************************************************************/
#include "APACHE35.h"
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Api_GlobalHeader.h"
//extern void MONITOR_FrameSize_Control(etMONITOR_OUT_MODE OutputMode);

typedef struct VMATTR
{
	UCHAR Update;
	
}VM_ATTR;

VM_ATTR VmAttr;

PSTRUCT_VM_ATTR VmAttrCurr;

UCHAR  old_Viewmode 	= 0xFF;
UCHAR  MorphingING_lut	= 0;
UCHAR  MorphingING_pip	= 0;
USHORT MorphingCnt		= 0;
USHORT AutoViewModeCnt	= 0;

#define VM_INDEX rSWReg.Category.VM.Reg.VIEW_MODE


void ncSvc_ViewMode_Update(UCHAR mode)
{
	VmAttr.Update = mode;
}

void ncSvc_ViewMode_Initialize(void)
{
	rSWReg.Category.MONITOR.Reg.LINEAR_FRAME=0;
		
	VmAttr.Update = 0;
	ncLib_Ldc_Control(eLDC_INIT);

	ncLib_Ldc_Write(eLDC_MAIN_NUM1, rSWReg.Category.VM.Reg.LUT_NUM1);
	ncLib_Ldc_Write(eLDC_PIP_NUM0,  rSWReg.Category.VM.Reg.PIP_NUM0);
	ncLib_Ldc_Write(eLDC_PIP_NUM1,  rSWReg.Category.VM.Reg.PIP_NUM1);
	ncLib_Ldc_Write(eLDC_MAIN_NUM0, rSWReg.Category.VM.Reg.LUT_NUM0);
	
	ncLib_Ldc_Write(eLDC_LUT_LOAD_FLASH,0);
}

void ncSvc_ViewMode_PipPosSet(void)
{
	USHORT sH_ACTIVE  =0; 
	USHORT sV_ACTIVE =0; 
	USHORT sPipOutWidth =0; 
	USHORT sPipOutHeight=0;
	
	USHORT X,Y, offset;

	USHORT X2 = (sH_ACTIVE>>2) - (sPipOutWidth>>1);
	USHORT X3 = (sH_ACTIVE>>1) - (sPipOutWidth>>1);
	USHORT X4 = (sH_ACTIVE>>1) + (sH_ACTIVE>>2) - (sPipOutWidth>>1);
	USHORT X5 = (sH_ACTIVE) 	  - (sPipOutWidth);
	USHORT Y2 = (sV_ACTIVE>>1) - (sPipOutHeight>>1);
	USHORT Y3 = (sV_ACTIVE)    - (sPipOutHeight);
	
	sH_ACTIVE     = ncLib_Ldc_Read(eLDC_MAINSIZE_H);
	sV_ACTIVE     = ncLib_Ldc_Read(eLDC_MAINSIZE_V);
	sPipOutWidth  = ncLib_Ldc_Read(eLDC_PIPSIZE_H );
	sPipOutHeight = ncLib_Ldc_Read(eLDC_PIPSIZE_V );

	X2 = (sH_ACTIVE>>2) - (sPipOutWidth>>1);
	X3 = (sH_ACTIVE>>1) - (sPipOutWidth>>1);
	X4 = (sH_ACTIVE>>1) + (sH_ACTIVE>>2) - (sPipOutWidth>>1);
	X5 = (sH_ACTIVE) 	- (sPipOutWidth);
	Y2 = (sV_ACTIVE>>1) - (sPipOutHeight>>1);
	Y3 = (sV_ACTIVE)    - (sPipOutHeight);

	offset = (USHORT)VmAttrCurr.B8.PIP_MARGIN<<3;
	
	switch(VmAttrCurr.B8.PIP_POSITION)
	{
		case 0x01: X = 0+offset;	Y = 0+offset;	break;
		case 0x02: X = X2;			Y = 0+offset;	break;
		case 0x03: X = X3;			Y = 0+offset;	break;
		case 0x04: X = X4;			Y = 0+offset;	break;
		case 0x05: X = X5-offset;	Y = 0+offset;	break;
				
		case 0x06: X = 0+offset;	Y = Y2;			break;
		case 0x07: X = X2;			Y = Y2;			break;
		case 0x08: X = X3;			Y = Y2;			break;
		case 0x09: X = X4;			Y = Y2;			break;
		case 0x0A: X = X5-offset;	Y = Y2;			break;
			
		case 0x0B: X = 0+offset;	Y = Y3-offset;	break;
		case 0x0C: X = X2;			Y = Y3-offset;	break;
		case 0x0D: X = X3;			Y = Y3-offset;	break;
		case 0x0E: X = X4;			Y = Y3-offset;	break;
		case 0x0F: X = X5-offset;	Y = Y3-offset;	break;
	}
	
	rSWReg.Category.VM.Reg.PIP_START_POS_X_L_7_0  = LOBYTE(X);
	rSWReg.Category.VM.Reg.PIP_START_POS_X_H_10_8 = HIBYTE(X);
	rSWReg.Category.VM.Reg.PIP_START_POS_Y_L_7_0  = LOBYTE(Y);
	rSWReg.Category.VM.Reg.PIP_START_POS_Y_H_10_8 = HIBYTE(Y);

}

void ncSvc_ViewMode_AutoFunc(void)
{
	USHORT sTmp;
	
	if(rSWReg.Category.VM.Reg.AUTO_VIEW_MODE_EN && !MorphingING_lut && !MorphingING_pip)
	{
		AutoViewModeCnt++;
		sTmp = rSWReg.Category.VM.Reg.AUTO_VIEW_MODE_TIME;
		sTmp = sTmp<<6;
		if(sTmp<AutoViewModeCnt)
		{
			if(rSWReg.Category.VM.Reg.VIEW_MODE_MAX > VM_INDEX)
				VM_INDEX++;
			else
				VM_INDEX = rSWReg.Category.VM.Reg.VIEW_MODE_MIN;
			
			AutoViewModeCnt = 0;
		}
	}	
}

void ncSvc_ViewMode_Morphing(void)
{
	USHORT sTmp;
	
	if(MorphingING_lut || MorphingING_pip)
	{
		sTmp = MorphingCnt+(1+rSWReg.Category.VM.Reg.MORPHING_SPEED);

		if(sTmp>0xFF&&MorphingCnt<0xFF)
			MorphingCnt = 0xFF;
		else if(sTmp<0xFF)
			MorphingCnt = sTmp;
		else
			MorphingCnt++;

		if(MorphingCnt>=0xFF || old_Viewmode != VM_INDEX)
		{
			rSWReg.Category.VM.Reg.MORPHING_LUT_RATIO = 0xFF;
			rSWReg.Category.VM.Reg.MORPHING_PIP_RATIO = 0xFF;

			if(MorphingCnt>=0x102)
			{
				rSWReg.Category.VM.Reg.MORPHING_LUT_RATIO = 0;
				rSWReg.Category.VM.Reg.MORPHING_PIP_RATIO = 0;
				MorphingCnt=MorphingING_lut=MorphingING_pip = 0;
			}
			else if(MorphingCnt>=0x101)
			{
			//	VmAttr.Update =1;
				
				rSWReg.Category.VM.Reg.LUT_NUM0 = VmAttrCurr.B8.LUT_INDEX-1;
				rSWReg.Category.VM.Reg.PIP_NUM0 = VmAttrCurr.B8.PIP_INDEX-1;
			}
		}
		else 
		{
			if(MorphingING_lut)	{rSWReg.Category.VM.Reg.MORPHING_LUT_RATIO = MorphingCnt;}
			if(MorphingING_pip)	{rSWReg.Category.VM.Reg.MORPHING_PIP_RATIO = MorphingCnt;}
		}

		ncLib_Ldc_Write(eLDC_MAIN_NUM1, rSWReg.Category.VM.Reg.LUT_NUM1);
		ncLib_Ldc_Write(eLDC_PIP_NUM0,  rSWReg.Category.VM.Reg.PIP_NUM0);
		ncLib_Ldc_Write(eLDC_PIP_NUM1,  rSWReg.Category.VM.Reg.PIP_NUM1);
		ncLib_Ldc_Write(eLDC_MAIN_NUM0, rSWReg.Category.VM.Reg.LUT_NUM0);
		
		ncLib_Ldc_Write(eLDC_MAIN_MORPHING_RATIO, rSWReg.Category.VM.Reg.MORPHING_LUT_RATIO);
		ncLib_Ldc_Write(eLDC_PIP_MORPHING_RATIO, rSWReg.Category.VM.Reg.MORPHING_PIP_RATIO);
	}
}

void ncSvc_ViewMode_LdcWrapCheck(void)
{
#if 0
	
#if ( (OPTION_WDR_TYPE == WDRTYPE_DOL2) || (OPTION_WDR_TYPE == WDRTYPE_DCOMP_OV) || (OPTION_WDR_TYPE == WDRTYPE_DCOMP_AR) || (OPTION_WDR_TYPE == WDRTYPE_LWDR2)  )
	UCHAR Panorama;
	static UCHAR OldMode=0x00;

	
	Panorama = ncLib_Ldc_Read(eLDC_LUT_WRAP_LEVEL);
	
	if(OldMode != Panorama&& rSWReg.Category.VM.Reg.LUT_MODE)
	{
		ncSvc_ViewMode_MainMorphingRatio(0);
		MorphingING_lut = OFF;
		MorphingING_pip = OFF;
		ncLib_Ldc_Control(eLDC_DEINIT);

		ncSvc_ViewMode_SetMainIdx0(rSWReg.Category.VM.Reg.LUT_NUM1);
		
		ncLib_Ldc_Write(eLDC_LUT_LOAD_FLASH,0);
		ncDrv_OSDBin_Get();
		OldMode = Panorama;
	}
#endif
#endif

}
void ncSvc_ViewMode_ChangeViewMode(void)
{
	MorphingING_lut = OFF;
	if(VM_INDEX >= rSWReg.Category.VM.Reg.VIEW_MODE_MIN && VM_INDEX <=rSWReg.Category.VM.Reg.VIEW_MODE_MAX)
	{
		VmAttrCurr.D8[0] = ISPGET08(ADDR_VM_1_LUT_INDEX +((VM_INDEX-1)*3)   ); 
		VmAttrCurr.D8[1] = ISPGET08(ADDR_VM_1_LUT_INDEX +((VM_INDEX-1)*3) +1); 
		VmAttrCurr.D8[2] = ISPGET08(ADDR_VM_1_LUT_INDEX +((VM_INDEX-1)*3) +2); 
	}
	else
	{
		VmAttrCurr.D8[0] = 0;
		VmAttrCurr.D8[1] = 0;
		VmAttrCurr.D8[2] = 0;
	}

		
	if(VmAttrCurr.B8.LUT_INDEX)
	{
		if(rSWReg.Category.VM.Reg.MORPHING_LUT_EN && rSWReg.Category.VM.Reg.LUT_MODE)
			MorphingING_lut = ON;
		else
		{
			rSWReg.Category.VM.Reg.LUT_NUM0 = VmAttrCurr.B8.LUT_INDEX-1;
			rSWReg.Category.VM.Reg.MORPHING_LUT_RATIO = 0;
		}
		rSWReg.Category.VM.Reg.LUT_NUM1 = VmAttrCurr.B8.LUT_INDEX-1;
		rSWReg.Category.VM.Reg.LUT_MODE = ON;
	}
	else
	{
		rSWReg.Category.VM.Reg.LUT_MODE = OFF;
		rSWReg.Category.VM.Reg.LUT_NUM0 = 0;
		rSWReg.Category.VM.Reg.LUT_NUM1 = 0;
	}

	if(VmAttrCurr.B8.PIP_INDEX)
	{
		if(rSWReg.Category.VM.Reg.MORPHING_PIP_EN&&rSWReg.Category.VM.Reg.PIP_MODE)
			MorphingING_pip = ON;
		else
		{
			rSWReg.Category.VM.Reg.PIP_NUM0 = VmAttrCurr.B8.PIP_INDEX-1;
			rSWReg.Category.VM.Reg.MORPHING_PIP_RATIO = 0;
		}
		rSWReg.Category.VM.Reg.PIP_NUM1 = VmAttrCurr.B8.PIP_INDEX-1;
		rSWReg.Category.VM.Reg.PIP_MODE = ON;
		ncSvc_ViewMode_PipPosSet();
	}
	else
	{
		rSWReg.Category.VM.Reg.PIP_MODE = OFF;
		rSWReg.Category.VM.Reg.PIP_NUM0 = 0;
		rSWReg.Category.VM.Reg.PIP_NUM1 = 0;
	}

	old_Viewmode = VM_INDEX;
	VmAttr.Update =1;
}

void ncSvc_ViewMode_Task(void)
{
	ncSvc_ViewMode_AutoFunc();
	ncSvc_ViewMode_Morphing();

	if(VmAttr.Update ==2)
	{
		ncLib_Ldc_Write(eLDC_MAIN_MORPHING_RATIO, rSWReg.Category.VM.Reg.MORPHING_LUT_RATIO);
		ncLib_Ldc_Write(eLDC_PIP_MORPHING_RATIO, rSWReg.Category.VM.Reg.MORPHING_PIP_RATIO);
		VmAttr.Update =0;
		return;
	}
	
	//return check;
	if((old_Viewmode == VM_INDEX && VmAttr.Update==0) 
		|| (rSWReg.Category.VM.Reg.VIEW_MODE_MAX<VM_INDEX)
		|| (MorphingING_lut)
		|| (MorphingING_pip) )
		return;

//	DEBUGMSG(MSGINFO, "ncSvc_ViewMode_Task %X, ", VM_INDEX);DEBUGMSG(MSGINFO, "%X, \n", VmAttr.Update);

	//View Mode Change;
#if 1
	if(old_Viewmode != VM_INDEX || VmAttr.Update ==3 )
	{
		ncSvc_ViewMode_ChangeViewMode();
	}
#endif
	
	
	ncLib_Ldc_Write(eLDC_MAIN_NUM1, rSWReg.Category.VM.Reg.LUT_NUM1);
	ncLib_Ldc_Write(eLDC_PIP_NUM0,  rSWReg.Category.VM.Reg.PIP_NUM0);
	ncLib_Ldc_Write(eLDC_PIP_NUM1,  rSWReg.Category.VM.Reg.PIP_NUM1);
	ncLib_Ldc_Write(eLDC_MAIN_NUM0, rSWReg.Category.VM.Reg.LUT_NUM0);
	
	//ncSvc_ViewMode_LdcWrapCheck();

	ncLib_Ldc_Control(eLDC_SIZE_UPDATE);
	
	ncLib_Ldc_Write(eLDC_PIP_POS_X,MAKEWORD(rSWReg.Category.VM.Reg.PIP_START_POS_X_H_10_8,rSWReg.Category.VM.Reg.PIP_START_POS_X_L_7_0));
	ncLib_Ldc_Write(eLDC_PIP_POS_Y,MAKEWORD(rSWReg.Category.VM.Reg.PIP_START_POS_Y_H_10_8,rSWReg.Category.VM.Reg.PIP_START_POS_Y_L_7_0));
	ncLib_Ldc_Write(eLDC_MORPHING_MAIN_EN,rSWReg.Category.VM.Reg.MORPHING_LUT_EN);
	ncLib_Ldc_Write(eLDC_MORPHING_PIP_EN, rSWReg.Category.VM.Reg.MORPHING_PIP_EN);
	ncLib_Ldc_Write(eLDC_MAIN_MORPHING_RATIO, rSWReg.Category.VM.Reg.MORPHING_LUT_RATIO);
	ncLib_Ldc_Write(eLDC_PIP_MORPHING_RATIO, rSWReg.Category.VM.Reg.MORPHING_PIP_RATIO);

	ncLib_Ldc_Write(eLDC_MAIN_EN,(BOOL)rSWReg.Category.VM.Reg.LUT_MODE);
	ncLib_Ldc_Write(eLDC_PIP_EN, (BOOL)rSWReg.Category.VM.Reg.PIP_MODE);

	VmAttr.Update =0;
}



