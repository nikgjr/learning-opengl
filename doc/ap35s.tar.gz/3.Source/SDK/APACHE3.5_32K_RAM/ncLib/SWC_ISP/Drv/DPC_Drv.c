
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Drv_GlobalHeader.h"

#if 0
#include "ISP_Drv.h"
#include "OSD_Drv.h"
#include "System_Drv.h"
#include "Dpc_Drv.h"
#include "Monitor_Drv.h"
#endif

#include "GlobalMenu.h"

//#define __MW_DEFECT_DEBUG__
//#define __MW_B_DEFECT_DEBUG__

#define MEMSETVALUE	0xFF

#define __DPCBLACK_DEBUG
#define DPCBLACK_NUM		128
#define BankCount			64
#define DDR_3DNR_IIR 		0x28008

#define OSD_REF_LIMIT		100
#define OSD_TH_LIMIT		100

#define BANK_WDPC		0x90		//0x90
#define BANK_BDPC		0xA0		//0xB0

#define GRID_MIN_SIZE	255L

#define GRID_LINE_WIDTH  5

STRUCT_MW_DPC	sMwDpc;

/* [2014/9/3] JWLee : [STD]-01 */
extern UINT32 LutManulSV[eCVBS_FORMAT][eFRAME_RATE_MAX][e30P_MANUAL_Max];

//============================================================================
//      Global Variable
//============================================================================
void ncDrv_DPC_ScanView(void);
/* [2014/11/24] ktsyann : [STD]1-2 */
UCHAR DPC_FlashWrite_CVBStoAHD(void);
//============================================================================
//      Extern Function Prototype
//============================================================================

extern void AE_ConvertSVtoSensorValue(UINT32 ExpSValue);
extern void AE_Iris_Open(void);
extern void AE_Iris_Close(void);
 /* [2014/11/24] ktsyann : [STD]1-2 */
//extern void SENSOR_Mirror_Set(UCHAR Mode);
extern void MW_Mirror_Set(void);
//------------------------------------------------------------------------------------------

void ncDrv_DPC_ScanView(void)
{
#if (FLASH_MEMORY_MAP_VERSION == VERSION_160409_TEST)
/* DPC SCAN_VIEW	      WDPC		      BDPC	       */
/* 	                    ON | OFF	    ON | OFF       */
/*-----------------------------------------------------*/
/* DPC_STATIC_EN	     1	WDPC_MODE	0	WDPC_MODE  */
/* DPC_BLACK_STATIC_EN	 0	BDPC_MODE	1	BDPC_MODE  */
/* DPC_TEST	             1	   0	    1	   0       */
/* DPC_WHITE	         0	   1	    0	   1       */
/* DPC_BLACK	         0	   1	    0	   1       */

/*   3DNR */	static BOOL preNR3D_Mode = STATE_OFF;
/* W_LIVE */	static UCHAR preDM_H_EN = STATE_OFF;
/* B_LIVE */	static UCHAR preDM_C_EN = STATE_OFF;
	
    /************* Force SCANVIEW_OFF in W/B DPC OFF mode **************/
    if(rSWReg.Category.DPC.Reg.DPC_SCAN_VIEW == eDPC_SCANVIEW_WDPC)
    {
        if(rSWReg.Category.DPC.Reg.WDPC_MODE == STATE_OFF)
           rSWReg.Category.DPC.Reg.DPC_SCAN_VIEW = eDPC_SCANVIEW_OFF;
    }

    if(rSWReg.Category.DPC.Reg.DPC_SCAN_VIEW == eDPC_SCANVIEW_BDPC)    
    {
        if(rSWReg.Category.DPC.Reg.BDPC_MODE == STATE_OFF)
           rSWReg.Category.DPC.Reg.DPC_SCAN_VIEW = eDPC_SCANVIEW_OFF;
    }


    /************* Set VIEW MODE mode **************/
    if(rSWReg.Category.DPC.Reg.DPC_SCAN_VIEW == eDPC_SCANVIEW_OFF)
    {
		rIP_DPC_STATIC_EN = rSWReg.Category.DPC.Reg.WDPC_MODE;
		rIP_DPC_BLACK_STATIC_EN = rSWReg.Category.DPC.Reg.BDPC_MODE;

		rIP_DPC_TEST = STATE_OFF;
		rIP_DPC_WHITE = STATE_ON;
		rIP_DPC_BLACK = STATE_ON;

        if(preNR3D_Mode == STATE_ON)
        {
            preNR3D_Mode = STATE_OFF;
            rIP_DNR_EN = STATE_ON;
        }

        if(preDM_H_EN == STATE_ON)
        {
            preDM_H_EN = STATE_OFF;
            rIP_DPC_DM_H_EN = preDM_H_EN;
        }
        
        if(preDM_C_EN == STATE_ON)
        {
            preDM_C_EN = STATE_OFF;
            rIP_DPC_DM_C_EN = preDM_C_EN;
        }
    }
    else 
    {
        preNR3D_Mode = rIP_DNR_EN;
        preDM_H_EN   = rIP_DPC_DM_H_EN;
        preDM_C_EN   = rIP_DPC_DM_C_EN;
        
        if(rIP_DNR_EN != STATE_OFF)        rIP_DNR_EN = STATE_OFF;
        if(rIP_DPC_DM_H_EN != STATE_OFF)     rIP_DPC_DM_H_EN = STATE_OFF;
        if(rIP_DPC_DM_C_EN != STATE_OFF)     rIP_DPC_DM_C_EN = STATE_OFF;

        if(rSWReg.Category.DPC.Reg.DPC_SCAN_VIEW == eDPC_SCANVIEW_WDPC)
        {
    		rIP_DPC_STATIC_EN = STATE_ON;		
	    	rIP_DPC_BLACK_STATIC_EN = STATE_OFF;
		}
		else if(rSWReg.Category.DPC.Reg.DPC_SCAN_VIEW == eDPC_SCANVIEW_BDPC)	
        {
        	rIP_DPC_STATIC_EN = STATE_OFF;
		    rIP_DPC_BLACK_STATIC_EN = STATE_ON;
        }
        
		rIP_DPC_TEST = STATE_ON;
		rIP_DPC_WHITE = STATE_OFF;
		rIP_DPC_BLACK = STATE_OFF;
    }
#endif	
}

void ncDrv_DPC_Grid_Set(void)
{
#if (FLASH_MEMORY_MAP_VERSION == VERSION_160409_TEST)	
//#define WDPC_SW_GRID_COLOR	ADDR_WDPC_GRID_Y_7_0
//#define BDPC_SW_GRID_COLOR	ADDR_BDPC_GRID_Y_7_0

    /*_________________ GRID ON/OFF ____________________________________*/
    if(rSWReg.Category.DPC.Reg.DPC_GRID_SEL == eDPC_GRID_OFF)
    {
        rIP_GRID_BOX0_EN = STATE_OFF;
        return;
    }

    rIP_GRID_BOX0_EN = STATE_ON;

    /*_________________ GRID SIZE SET __________________________________*/
    ncDrv_DPC_ReSize();


    /*_________________ GRID COLOR SET _________________________________*/
	if(rSWReg.Category.DPC.Reg.DPC_GRID_SEL == eDPC_GRID_WDPC)
	{
		rIP_GRID_BOX0_COLOR_Y_7_0 = rSWReg.Category.DPC.Reg.WDPC_GRID_Y_7_0;
		rIP_GRID_BOX0_COLOR_Y_9_8 = rSWReg.Category.DPC.Reg.WDPC_GRID_Y_9_8;
		rIP_GRID_BOX0_COLOR_CB_7_0 = rSWReg.Category.DPC.Reg.WDPC_GRID_CB_7_0;
		rIP_GRID_BOX0_COLOR_CB_9_8 = rSWReg.Category.DPC.Reg.WDPC_GRID_CB_9_8;
		rIP_GRID_BOX0_COLOR_CR_7_0 = rSWReg.Category.DPC.Reg.WDPC_GRID_CR_7_0;
		rIP_GRID_BOX0_COLOR_CR_9_8 = rSWReg.Category.DPC.Reg.WDPC_GRID_CR_9_8;
		
		//memcpy((void*)(aIP_GRID_BOX0_COLOR_Y_7_0), (void*)(WDPC_SW_GRID_COLOR), (6L * sizeof(UCHAR)));	//DEST, SCOURC, SIZE
	}
	else
	{
		rIP_GRID_BOX0_COLOR_Y_7_0 = rSWReg.Category.DPC.Reg.BDPC_GRID_Y_7_0;
		rIP_GRID_BOX0_COLOR_Y_9_8 = rSWReg.Category.DPC.Reg.BDPC_GRID_Y_9_8;
		rIP_GRID_BOX0_COLOR_CB_7_0 = rSWReg.Category.DPC.Reg.BDPC_GRID_CB_7_0;
		rIP_GRID_BOX0_COLOR_CB_9_8 = rSWReg.Category.DPC.Reg.BDPC_GRID_CB_9_8;
		rIP_GRID_BOX0_COLOR_CR_7_0 = rSWReg.Category.DPC.Reg.BDPC_GRID_CR_7_0;
		rIP_GRID_BOX0_COLOR_CR_9_8 = rSWReg.Category.DPC.Reg.BDPC_GRID_CR_9_8;
		
		//memcpy((void*)(aIP_GRID_BOX0_COLOR_Y_7_0), (void*)(BDPC_SW_GRID_COLOR), (6L * sizeof(UCHAR)));	//DEST, SCOURC, SIZE
	}
#endif	
}


void ncDrv_DPC_ReSize(void)
{
#if (FLASH_MEMORY_MAP_VERSION == VERSION_160409_TEST)	
#define WDPC_SW_GRID_AREA		ADDR_WDPC_GRID_SX_7_0
#define BDPC_SW_GRID_AREA		ADDR_BDPC_GRID_SX_7_0

    typedef union{
        USHORT SIZE[4];
        struct{
            USHORT X0           :11;
            USHORT X0_RESERVE   :5;
            USHORT X1           :11;
            USHORT X1_RESERVE   :5;
            USHORT Y0           :11;
            USHORT Y0_RESERVE   :5;
            USHORT Y1           :11;
            USHORT Y1_RESERVE   :5;
        }Info;
    } STRUCT_WDPC_SIZE;
    
    STRUCT_WDPC_SIZE* DPCSize;

    if(rSWReg.Category.DPC.Reg.DPC_GRID_SEL == eDPC_GRID_WDPC)    DPCSize = (STRUCT_WDPC_SIZE*)WDPC_SW_GRID_AREA;
    else                                                          DPCSize = (STRUCT_WDPC_SIZE*)BDPC_SW_GRID_AREA;

    ISPSET16((aIP_GRID_BOX0_S_X_7_0+0), ((OUTPUT_SIZE==INPUT_SIZE) ? (DPCSize->Info.X0 + (H_ACTIVE_OFFSET>>1)) : (USHORT)((FLOAT)(DPCSize->Info.X0 + (H_ACTIVE_OFFSET>>1))/1.5)));
    ISPSET16((aIP_GRID_BOX0_S_X_7_0+2), ((OUTPUT_SIZE==INPUT_SIZE) ? DPCSize->Info.X1 : (USHORT)((FLOAT)DPCSize->Info.X1/1.5)));
    ISPSET16((aIP_GRID_BOX0_S_X_7_0+4), ((OUTPUT_SIZE==INPUT_SIZE) ? DPCSize->Info.Y0 : (USHORT)((FLOAT)DPCSize->Info.Y0/1.5)));
    ISPSET16((aIP_GRID_BOX0_S_X_7_0+6), ((OUTPUT_SIZE==INPUT_SIZE) ? DPCSize->Info.Y1 : (USHORT)((FLOAT)DPCSize->Info.Y1/1.5)));
#endif	
}

UCHAR WhiteDPC_Ready(void)
{
#if (FLASH_MEMORY_MAP_VERSION == VERSION_160409_TEST)	
	USHORT Threshold = 0;

	Threshold = (USHORT)rSWReg.Category.DPC.Reg.WDPC_TH * 17;

	rIP_DPC_TH_INIT_9_8 = ((Threshold>>8)&0x03);
	rIP_DPC_TH_INIT_7_0 = (Threshold & 0x00FF);

	sMwSystem.Control.Run.AE = FALSE; // AE Stop

#if 0
	//AE_Iris_Close();
	
	// CLOSE THE IRIS THEN PRESS ENTER KEY
	sMwMenu.PosX = sMwOsd.CenterPosX-7;
	sMwMenu.PosY = sMwOsd.CenterPosY-2;
	sMwMenu.Style = 1;
	sMwMenu.Color = 1;
	sMwMenu.FontIndex = F_DEFECT_CLOSETHE_CHAR;
	sMwMenu.StringNum = MAXCHAR_NUM;
	ncDrv_OSDString_Set();
	
	sMwMenu.PosX = sMwOsd.CenterPosX+3;
	sMwMenu.PosY = sMwOsd.CenterPosY-2;
	sMwMenu.Style = 1;
	sMwMenu.Color = 1;
	sMwMenu.FontIndex = F_DEFECT_IRIS_CHAR;	
	sMwMenu.StringNum = MAXCHAR_NUM;
	ncDrv_OSDString_Set();
	
	sMwMenu.PosX = sMwOsd.CenterPosX-2;
	sMwMenu.PosY = sMwOsd.CenterPosY;
	sMwMenu.Style = 1;
	sMwMenu.Color = 1;
	sMwMenu.FontIndex = F_DEFECT_THEN_CHAR;
	sMwMenu.StringNum = MAXCHAR_NUM;
	ncDrv_OSDString_Set();
	
	sMwMenu.PosX = sMwOsd.CenterPosX-6;
	sMwMenu.PosY = sMwOsd.CenterPosY+2;
	sMwMenu.Style = 1;
	sMwMenu.Color = 1;
	sMwMenu.FontIndex = F_DEFECT_PRESSENTER_CHAR;
	sMwMenu.StringNum = MAXCHAR_NUM;
	ncDrv_OSDString_Set();
#endif

    ISPSET16(aIP_DPC_SCAN_W_AREA_ST_X_7_0, (ISPGET16(aIP_GRID_BOX0_S_X_7_0) + GRID_LINE_WIDTH));
    ISPSET16(aIP_DPC_SCAN_W_AREA_ED_X_7_0, (ISPGET16(aIP_GRID_BOX0_E_X_7_0) - (GRID_LINE_WIDTH+2)));
    ISPSET16(aIP_DPC_SCAN_W_AREA_ST_Y_7_0, (ISPGET16(aIP_GRID_BOX0_S_Y_7_0) + GRID_LINE_WIDTH));	
    ISPSET16(aIP_DPC_SCAN_W_AREA_ED_Y_7_0, (ISPGET16(aIP_GRID_BOX0_E_Y_7_0) - (GRID_LINE_WIDTH+2)));

	return TRUE;	
#endif	
}

void WhiteDPC_AE_Control(UCHAR mode)
{	
#if (FLASH_MEMORY_MAP_VERSION == VERSION_160409_TEST)	
    et30P_MANUAL_SHUT_TYPE  SensUpStartIdx = (et30P_MANUAL_SHUT_TYPE)(sMwAe.Tracking.SensorFrameRate ? (UCHAR)SENSUP_START_IDX_60P : (UCHAR)SENSUP_START_IDX_30P);
	STRUCT_AE_SET_TYPE sAppAeSet;
	
	if(mode == 1)
	{
		AE_ConvertSVtoSensorValue(LutManulSV[CVBS_FORMAT][sMwAe.Tracking.SensorFrameRate][rSWReg.Category.DPC.Reg.WDPC_SENSUP+SensUpStartIdx]);

		if(rSWReg.Category.DPC.Reg.WDPC_AGC > 14) rSWReg.Category.DPC.Reg.WDPC_AGC = 14; /* [2015/2/5] SJH : [STD]-01 */
		sMwAe.Tracking.GV = (GAIN_VALUE_TYPE)LutdBtoGain[rSWReg.Category.DPC.Reg.WDPC_AGC * 3];
		
		sMwSystem.Control.Run.AE = TRUE; // AE Start

        sAppAeSet.TotalGain = sMwAe.Tracking.GV;
        sAppAeSet.VTotalLine = sMwAe.Sensor.VTotalLine;
        sAppAeSet.ExposureLine = sMwAe.Sensor.ExposureLIne;   
#if (SENSOR_SELECT == SENSOR_COMMON)
    	SENSOR_Exposure_Set((STRUCT_AE_SET_TYPE *)&sAppAeSet);   
#else
        ncDrv_SENSOR_Exposure_Set((STRUCT_AE_SET_TYPE *)&sAppAeSet);   
#endif
		sMwSystem.Control.Run.AE = FALSE; // AE Stop

		ncDrv_VSIP_Skip(2);
	}
	else
	{
		/* [2014/9/22] mkchoi [STD]-01*/ 
		/* [2015/01/06] ktsyann : [STD]-1 */
		/* [2015/01/09] JWLee : [STD]-01 */
        ncSvc_AE_Reset();
		sMwSystem.Control.Run.AE = TRUE; // AE Start
	}
#endif	
}

void ncDrv_StaticDPCWhite_Cancel(void)
{
#if (FLASH_MEMORY_MAP_VERSION == VERSION_160409_TEST)	
	sMwSystem.Control.Run.AE = TRUE; // AE Run
	//AE_Iris_Open();
	rSWReg.Category.DPC.Reg.WDPC_SCAN_STATE = FALSE;
#endif	
}

#define DPCTOTLANUM	2045
void WhiteDPC_Viewer_Set(UCHAR Mode)		//SDRAM
{
#if (FLASH_MEMORY_MAP_VERSION == VERSION_160409_TEST)	
	// Static DPC Display Enable
	// Static DPC Mode On,Off
	
	if(rSWReg.Category.DPC.Reg.WDPC_MODE == TRUE)
	{
		rIP_DPC_STATIC_EN	= TRUE;
	}
	else
	{
		rIP_DPC_STATIC_EN	= Mode;
	}
	
	rIP_DPC_TEST 		= Mode;	
#endif	
}
/* [2014/11/24] ktsyann : [STD]1-2 */
USHORT ncDrv_StaticDPCWhite_Scan(UCHAR Mode)
{
#if (FLASH_MEMORY_MAP_VERSION == VERSION_160409_TEST)	
	UCHAR	Cnt = 0;
	UINT32	Address = 0, Address1 = 0;
	USHORT	ScanNum[2] = {0,0};
	USHORT	ScanCnt[2] = {0,0};
	UCHAR	Coordinate[2][64];
	UINT32	BuffSize[2] = {0,0};
	UINT32	Size = 0;
	USHORT	x1 = 0, y1 = 0, x2 = 0, y2 = 0;
	USHORT	idxData1 = 0, idxData2 = 0;
	UINT32	Data1 = 0, Data2 = 0;
	UCHAR	Refresh1 = TRUE, Refresh2 = TRUE, DDRRefresh1 = TRUE, DDRRefresh2 = TRUE;
	UINT32	FlashDPCAddr = 0;
	UINT32	FlashDPCAddrback = 0;
	UCHAR	DPCBuff[5];
	USHORT	DPCCnt = 0;
	UCHAR	Stop	= FALSE;
	UCHAR	LiveMode = FALSE;
	UCHAR	BlackDPC = 0;
	#ifdef __MW_DEFECT_DEBUG__
	UCHAR	a = 0, b=0;
	#endif
	USHORT 	ret = 0;
	UCHAR   bFlipMode;
	UCHAR	j=0;
	UCHAR   bCurFlipMode;
	UCHAR	DpcCompCnt=0;
	UINT32	bFlsahAddr=0;
	UINT32	bFlsahAddrInfo=0;
	//static UCHAR   PreNR3DBMode = 0;
	UCHAR	i = 0;
	
	ncDrv_OSDClear_Set();
	
	if(Mode == SCAN_READY)
	{
		rSWReg.Category.DPC.Reg.WDPC_SCAN_STATE = TRUE;
		ret = WhiteDPC_Ready();
	}
	else if(Mode == SCAN_START)
	{
		//----------------------------------------------------------------------
		ncDrv_BackGround_Set(BACKGROUNDBLACK);

		//Live DPC Set ----------------------------------------------------------------------
		rIP_DPC_DM_H_EN = LiveMode; // Off
		rIP_DPC_DM_C_EN = LiveMode;/* [2014/12/08] SJH : [STD]-01 */

		ncDrv_VSIP_Skip(2);
		
		WhiteDPC_AE_Control(1);
		
		sMwMenu.PosX = sMwOsd.CenterPosX-4;
		sMwMenu.PosY = sMwOsd.CenterPosY;
		sMwMenu.Style = 1;
		sMwMenu.Color = 1;
		sMwMenu.FontIndex = F_WAIT_CHAR;	
		sMwMenu.StringNum = MAXCHAR_NUM;
		ncDrv_OSDString_Set();
		
		BlackDPC = rIP_DPC_BLACK;
		rIP_DPC_BLACK = FALSE;
		rIP_DPC_STATIC_EN = FALSE;
		
		/////////////////////////////////////////////////////////////////////
		// FLIP MODE CHECK!!
		bFlipMode = rSWReg.Category.DEFFECT.Reg.MIRROR_MODE;
		
		switch(bFlipMode){
			case eFLIP_MIRROR 	: 	bCurFlipMode = rSWReg.Category.DPC.Reg.WDPC_FLIP_H;
									rSWReg.Category.DPC.Reg.WDPC_FLIP_H = 1;	
			break;
			case eFLIP_V 		: 	bCurFlipMode = rSWReg.Category.DPC.Reg.WDPC_FLIP_V;
									rSWReg.Category.DPC.Reg.WDPC_FLIP_V = 1;	
			break;
			case eFLIP_ROTATE	: 	bCurFlipMode = rSWReg.Category.DPC.Reg.WDPC_FLIP_R;
									rSWReg.Category.DPC.Reg.WDPC_FLIP_R = 1;	
			break;
		}
		
		/////////////////////////////////////////////////////////////////////
		// DPC COMP COUNT CHECK!!
		DpcCompCnt = rSWReg.Category.DPC.Reg.WDPC_FLIP_H + rSWReg.Category.DPC.Reg.WDPC_FLIP_V + rSWReg.Category.DPC.Reg.WDPC_FLIP_R + 1;
		
		for(j=0; j<DpcCompCnt; j++)
		{
			Data1 = 0, Data2 = 0;
			Refresh1 = TRUE, Refresh2 = TRUE, DDRRefresh1 = TRUE, DDRRefresh2 = TRUE;
			DPCCnt = 0;
			Stop = FALSE;
			
			if(rSWReg.Category.MONITOR.Reg.MONITOR_OUTPUT == 0)	//CVBS
			{
				switch(j){
					case 0 : FlashDPCAddrback = FLASHMEMORY_WDPC_POS_ADDRESS;
							 FlashDPCAddr = FLASHMEMORY_WDPC_POS_ADDRESS;
							 rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_OFF;
					break;
					case 1 : 
							 if(rSWReg.Category.DPC.Reg.WDPC_FLIP_H == 1){
							 	FlashDPCAddrback = FLASHMEMORY_WDPC_POS_ADDRESS_H_FLIP;
							 	FlashDPCAddr = FLASHMEMORY_WDPC_POS_ADDRESS_H_FLIP;
							 	rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_MIRROR;
							 }
							 else if(rSWReg.Category.DPC.Reg.WDPC_FLIP_V == 1){
							 	FlashDPCAddrback = FLASHMEMORY_WDPC_POS_ADDRESS_V_FLIP;
							 	FlashDPCAddr = FLASHMEMORY_WDPC_POS_ADDRESS_V_FLIP;
							 	rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_V;
							 }
							 else{
							 	FlashDPCAddrback = FLASHMEMORY_WDPC_POS_ADDRESS_R_FLIP;
							 	FlashDPCAddr = FLASHMEMORY_WDPC_POS_ADDRESS_R_FLIP;
							 	rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_ROTATE;
							 }
					break;
					case 2 : 
							 if(rSWReg.Category.DPC.Reg.WDPC_FLIP_V == 1){
							 	FlashDPCAddrback = FLASHMEMORY_WDPC_POS_ADDRESS_V_FLIP;
							 	FlashDPCAddr = FLASHMEMORY_WDPC_POS_ADDRESS_V_FLIP;
							 	rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_V;
							 }
							 else{
							 	FlashDPCAddrback = FLASHMEMORY_WDPC_POS_ADDRESS_R_FLIP;
							 	FlashDPCAddr = FLASHMEMORY_WDPC_POS_ADDRESS_R_FLIP;
							 	rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_ROTATE;
							 }
					break;
					case 3 : FlashDPCAddrback = FLASHMEMORY_WDPC_POS_ADDRESS_R_FLIP;
							 FlashDPCAddr = FLASHMEMORY_WDPC_POS_ADDRESS_R_FLIP;
							 rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_ROTATE;
					break;
				}
			}
			else		//AHD
			{
				switch(j){
					case 0 : FlashDPCAddrback = FLASHMEMORY_WDPC_AHD_POS_ADDRESS;
							 FlashDPCAddr = FLASHMEMORY_WDPC_AHD_POS_ADDRESS;
							 rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_OFF;
					break;
					case 1 : 
							 if(rSWReg.Category.DPC.Reg.WDPC_FLIP_H == 1){
							 	FlashDPCAddrback = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_H_FLIP;
							 	FlashDPCAddr = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_H_FLIP;
							 	rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_MIRROR;
							 }
							 else if(rSWReg.Category.DPC.Reg.WDPC_FLIP_V == 1){
							 	FlashDPCAddrback = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_V_FLIP;
							 	FlashDPCAddr = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_V_FLIP;
							 	rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_V;
							 }
							 else{
							 	FlashDPCAddrback = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_R_FLIP;
							 	FlashDPCAddr = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_R_FLIP;
							 	rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_ROTATE;
							 }
					break;
					case 2 : 
							 if(rSWReg.Category.DPC.Reg.WDPC_FLIP_V == 1){
							 	FlashDPCAddrback = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_V_FLIP;
							 	FlashDPCAddr = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_V_FLIP;
							 	rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_V;
							 }
							 else{
							 	FlashDPCAddrback = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_R_FLIP;
							 	FlashDPCAddr = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_R_FLIP;
							 	rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_ROTATE;
							 }
					break;
					case 3 : FlashDPCAddrback = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_R_FLIP;
							 FlashDPCAddr = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_R_FLIP;
							 rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = eFLIP_ROTATE;
					break;
				}
			}
			
			bFlsahAddr = FlashDPCAddr;
			
			switch(bFlsahAddr){
				case FLASHMEMORY_WDPC_POS_ADDRESS 				: bFlsahAddrInfo = FLASHMEMORY_WDPC_INFO_ADDRESS;				break;
				case FLASHMEMORY_WDPC_POS_ADDRESS_H_FLIP 		: bFlsahAddrInfo = FLASHMEMORY_WDPC_INFO_ADDRESS_H_FLIP;		break;
				case FLASHMEMORY_WDPC_POS_ADDRESS_V_FLIP 		: bFlsahAddrInfo = FLASHMEMORY_WDPC_INFO_ADDRESS_V_FLIP;		break;
				case FLASHMEMORY_WDPC_POS_ADDRESS_R_FLIP		: bFlsahAddrInfo = FLASHMEMORY_WDPC_INFO_ADDRESS_R_FLIP;		break;
				case FLASHMEMORY_WDPC_AHD_POS_ADDRESS			: bFlsahAddrInfo = FLASHMEMORY_WDPC_AHD_INFO_ADDRESS;			break;
				case FLASHMEMORY_WDPC_POS_AHD_ADDRESS_H_FLIP	: bFlsahAddrInfo = FLASHMEMORY_WDPC_INFO_AHD_ADDRESS_H_FLIP;	break;
				case FLASHMEMORY_WDPC_POS_AHD_ADDRESS_V_FLIP	: bFlsahAddrInfo = FLASHMEMORY_WDPC_INFO_AHD_ADDRESS_V_FLIP;	break;
				case FLASHMEMORY_WDPC_POS_AHD_ADDRESS_R_FLIP	: bFlsahAddrInfo = FLASHMEMORY_WDPC_INFO_AHD_ADDRESS_R_FLIP;	break;
			}

			/////////////////////////////////////////////////////////////////////
			// FLIP MODE CHANGE!!
#if (SENSOR_SELECT == SENSOR_COMMON)
	        SENSOR_Mirror_Set(rSWReg.Category.DEFFECT.Reg.MIRROR_MODE); 
#else
            ncDrv_SENSOR_Mirror_Set(rSWReg.Category.DEFFECT.Reg.MIRROR_MODE);    
#endif

			ncDrv_VSIP_Skip(2);
			
			/////////////////////////////////////////////////////////////////////
			// FLASH ERASE!!
			for(Cnt = 0; Cnt < 2; Cnt++)// Static DPC Flash Area 8kbyte Erase!
			{
				ncLib_SF_Control(GCMD_SF_SECTOR_ERASE, FlashDPCAddrback, CMD_END );
				FlashDPCAddrback += (UINT32)0x1000;
			}

			// Static DPC Total SCAN NUM Set[0x07FD(h) = 2045]
			rIP_DPC_TH_NUM_15_8 = (DPCTOTLANUM >> 8);
			rIP_DPC_TH_NUM_7_0 = (DPCTOTLANUM & 0xFF);

			for(Cnt = 0; Cnt < 2; Cnt++)// DDR Buffer0, Buffer1 DPC  
			{
				if(Cnt == 0)	Address = sGco.DDRADDDPC1;
				else			Address = sGco.DDRADDDPC2;

				// Static DPC DDR Write Address Set
				rIP_DPC_W_WRITE_ADDR_31_24 = (Address>>24)& 0xFF;
				rIP_DPC_W_WRITE_ADDR_23_16 = (Address>>16)& 0xFF;
				rIP_DPC_W_WRITE_ADDR_15_8 = (Address>>8)& 0xFF;
				rIP_DPC_W_WRITE_ADDR_7_0 = (Address& 0xFF);
				// Static DPC DDR Write Enable Set
				rIP_DPC_W_ENABLE = TRUE;
				// Static DPC SCAN Start!
				rIP_DPC_STATIC_SCAN= TRUE;
				
				// DPC END INT Wait
				ncDrv_VSIP_Skip(4);

				// Static DPC SCAN End!
				rIP_DPC_STATIC_SCAN= FALSE;

				// DPC END INT Wait
				ncDrv_VSIP_Skip(2);
				
				// SCAN DPC Total Num Get!
				ScanNum[Cnt] = rIP_DPC_SCAN_NUM_15_8;
				ScanNum[Cnt] = (ScanNum[Cnt] << 8) |rIP_DPC_SCAN_NUM_7_0;

				Size = ScanNum[Cnt] << 2;// 
				BuffSize[Cnt] = ((Size + 63) >> 6) << 6;	//((fsize + 63) / 64) * 64;	// Totla Size
				ScanCnt[Cnt] = ScanNum[Cnt];

				// DPC END INT Wait
				ncDrv_VSIP_Skip(3);
				
				#ifdef __MW_DEFECT_DEBUG__
					ncLib_DEBUG_Printf(1, "%x DPCBuf. ", Cnt);
					ncLib_DEBUG_Printf(1, "[0x%s]pixel ,	", ScanNum[Cnt]);
					ncLib_DEBUG_Printf(1, "[0x%s]Size \r\n", Size);
				#endif
			}
			// Static DPC DDR Write Disable Set
			rIP_DPC_W_ENABLE = FALSE;

			Address = sGco.DDRADDDPC1;// DDR DPC 1Buffer Address
			Address1 = sGco.DDRADDDPC2;// DDR DPC 2Buffer Address
			while(((BuffSize[0] != 0)||(BuffSize[1] != 0))&&(Stop == FALSE))
			{
				if((BuffSize[0] != 0)&&(DDRRefresh1 == TRUE))
				{
					// read 64Byte data from DPC1 DDR memroy
					#if 0
						ncDrv_DDRMemory_Get(Address, &Coordinate[0][0]);
					#else
						for(i=0; i<64; i++)
						{
							Coordinate[0][i] = *(UINT8*)(Address+i);
						}
					#endif
					
					BuffSize[0]-=64;
					Address+=64;
					DDRRefresh1 = FALSE;
					idxData1 = 0;

					if(ScanCnt[0] < 16)
						memset(&Coordinate[0][ScanCnt[0]<< 2], MEMSETVALUE, (64 - (ScanCnt[0]<< 2)) * sizeof(UCHAR));
					else
						ScanCnt[0] -= 16;
					
					#ifdef __MW_DEFECT_DEBUG__
					for(a=0; a<64; a++)
					{
						ncLib_DEBUG_Printf(1, "%x", Coordinate[0][a]);
						b++;
						if(b == 4){
							ncLib_DEBUG_Printf(1, "\r\n");
							b = 0;
						}
					}
					ncLib_DEBUG_Printf(1, "1.OK\r\n");
					#endif
				}
				
				if((BuffSize[1] != 0)&&(DDRRefresh2 == TRUE))
				{
					// read 64Byte data from DPC2 DDR memroy
					#if 0
                   		ncDrv_DDRMemory_Get(Address1, &Coordinate[0][0]);
					#else
						for(i=0; i<64; i++)
						{
							Coordinate[1][i] = *(UINT8*)(Address1+i);
						}
					#endif
					
					BuffSize[1]-=64;
					Address1+=64;
					DDRRefresh2 = FALSE;
					idxData2 = 0;

					if(ScanCnt[1] < 16)
						memset(&Coordinate[1][ScanCnt[1]<< 2], MEMSETVALUE, (64 - (ScanCnt[1]<< 2)) * sizeof(UCHAR));
					else
						ScanCnt[1] -= 16;
					
					#ifdef __MW_DEFECT_DEBUG__
					b=0;
					for(a=0; a<64; a++)
					{
						ncLib_DEBUG_Printf(1, "%x", Coordinate[1][a]);
						b++;
						if(b == 4){
							ncLib_DEBUG_Printf(1, "\r\n");
							b = 0;
						}
					}
					ncLib_DEBUG_Printf(1, "2.OK\r\n");
					#endif
				}

				while(1)
				{
					if((Refresh1 == TRUE)&&(idxData1 <= 60))
					{
						Data1 = Coordinate[0][idxData1+3];
						Data1 = (Data1 << 8) | Coordinate[0][idxData1+2];
						Data1 = (Data1 << 8) | Coordinate[0][idxData1+1];
						Data1 = (Data1 << 8) | Coordinate[0][idxData1];
						x1 = ((Data1 >> 11) & 0x000007FF);
						y1 = (Data1 & 0x000007FF);
						Refresh1 = FALSE;
					}
					
					if((Refresh2 == TRUE)&&(idxData2 <= 60))
					{
						Data2 = Coordinate[1][idxData2+3];
						Data2 = (Data2 << 8) | Coordinate[1][idxData2+2];
						Data2 = (Data2 << 8) | Coordinate[1][idxData2+1];
						Data2 = (Data2 << 8) | Coordinate[1][idxData2];

						x2 = ((Data2 >> 11) & 0x000007FF);
						y2 = (Data2 & 0x000007FF);
						Refresh2 = FALSE;
					}
					
					if(y1 == y2)
					{
						if(x1 == x2)
						{
							idxData1 = idxData1 +4;
							idxData2 = idxData2 +4;
							Refresh1 = TRUE;
							Refresh2 = TRUE;

							DPCBuff[3] = (Data1 >> 24)& 0xFF;
							DPCBuff[2] = (Data1 >> 16)& 0xFF;
							DPCBuff[1] = (Data1 >> 8)& 0xFF;
							DPCBuff[0] = (Data1 & 0xFF);					
						}
						else if(x1 < x2)
						{
							idxData1 = idxData1 +4;
							Refresh1 = TRUE;

							DPCBuff[3]= (Data1 >> 24)& 0xFF;
							DPCBuff[2] = (Data1 >> 16)& 0xFF;
							DPCBuff[1] = (Data1 >> 8)& 0xFF;
							DPCBuff[0] = (Data1 & 0xFF);
						}
						else
						{
							idxData2 = idxData2 +4;
							Refresh2 = TRUE;

							DPCBuff[3] = (Data2 >> 24)& 0xFF;
							DPCBuff[2] = (Data2 >> 16)& 0xFF;
							DPCBuff[1] = (Data2 >> 8)& 0xFF;
							DPCBuff[0] = (Data2 & 0xFF);
						}
					}
					else if(y1 < y2)
					{
						idxData1 = idxData1 +4;
						Refresh1 = TRUE;

						DPCBuff[3] = (Data1 >> 24)& 0xFF;
						DPCBuff[2] = (Data1 >> 16)& 0xFF;
						DPCBuff[1] = (Data1 >> 8)& 0xFF;
						DPCBuff[0] = (Data1 & 0xFF);
					}
					else
					{
						idxData2 = idxData2 +4;
						Refresh2 = TRUE;

						DPCBuff[3] = (Data2 >> 24)& 0xFF;
						DPCBuff[2] = (Data2 >> 16)& 0xFF;
						DPCBuff[1] = (Data2 >> 8)& 0xFF;
						DPCBuff[0] = (Data2 & 0xFF);
					}

                    ret = ncLib_SF_Control(GCMD_SF_WRITE_DATA, FlashDPCAddr, (UINT8 *)(&DPCBuff[0]), 4, CMD_END);
					
					#ifdef __MW_DEFECT_DEBUG__
					//ncLib_DEBUG_Printf(1, "[0x%s	,", x1);
					//ncLib_DEBUG_Printf(1, "0x%s],	", y1);
					//ncLib_DEBUG_Printf(1, "[0x%s	,", x2);
					//ncLib_DEBUG_Printf(1, "0x%s]\r\n", y2);
					
					for(a=0; a<4; a++)
					{
						ncLib_DEBUG_Printf(1, "%x", DPCBuff[a]);
						if(a == 3){
							ncLib_DEBUG_Printf(1, "\r\n");
						}
					}
					ncLib_DEBUG_Printf(1, "3.OK\r\n");
					#endif
					
					FlashDPCAddr += 4;

					if(DPCBuff[3] != 0xFF)	DPCCnt++;

					if(DPCCnt == DPCTOTLANUM)
					{
						Stop = TRUE;
						break;
					}
					
					if((idxData1 > 60)||(idxData2 > 60))
					{
						if(idxData1 > 60)	DDRRefresh1 = TRUE;
						if(idxData2 > 60)	DDRRefresh2 = TRUE;
						
						break;	
					}
				}
				#ifdef __MW_DEFECT_DEBUG__
				ncLib_DEBUG_Printf(1, "%s	,", BuffSize[0]);
				ncLib_DEBUG_Printf(1, "%s	:	", idxData1);
				
				ncLib_DEBUG_Printf(1, "%s	,", BuffSize[1]);
				ncLib_DEBUG_Printf(1, "%s	\r\n", idxData2);
				#endif
				
				if((BuffSize[0] == 0)&&(idxData1 > 60))
				{
					if(idxData2 <= 60)
					{
                        ret = ncLib_SF_Control(GCMD_SF_WRITE_DATA, FlashDPCAddr, (UINT8 *)(&Coordinate[1][idxData2]), (64-idxData2), CMD_END);
						FlashDPCAddr += (64-idxData2);
						idxData2 = 0;
					}
						
					while(1)
					{
						if(BuffSize[1] != 0)
						{
							memset(Coordinate, MEMSETVALUE, 128 * sizeof(UCHAR));
							// read 64Byte data from DPC2 DDR memroy
							#if 0
								ncDrv_DDRMemory_Get(Address1, &Coordinate[0][0]);
							#else
								for(i=0; i<64; i++)
								{
									Coordinate[1][i] = *(UINT8*)(Address1+i);
								}
							#endif

							if(ScanCnt[1] < 16)
								memset(&Coordinate[1][ScanCnt[1]<< 2], MEMSETVALUE, (64 - (ScanCnt[1]<< 2)) * sizeof(UCHAR));
							else
								ScanCnt[1] -= 16;	
							
							ret = ncLib_SF_Control(GCMD_SF_WRITE_DATA, FlashDPCAddr, (UINT8 *)(&Coordinate[1][0]), 64, CMD_END);
							FlashDPCAddr += 64;
						
							BuffSize[1]-=64;
							Address1+=64;				
						}
						else
						{
							break;
						}
					}	
				}

				if((BuffSize[1] == 0)&&(idxData2 > 60))
				{
					if(idxData1 <= 60)
					{
                        ret = ncLib_SF_Control(GCMD_SF_WRITE_DATA, FlashDPCAddr, (UINT8 *)(&Coordinate[0][idxData1]), (64-idxData1), CMD_END);						
						FlashDPCAddr += (64-idxData1);
						idxData1 = 0;
					}

					while(1)
					{
						if(BuffSize[0] != 0)
						{
							memset(Coordinate, MEMSETVALUE, 128 * sizeof(UCHAR));
							// read 64Byte data from DPC2 DDR memroy
							#if 0
								ncDrv_DDRMemory_Get(Address, &Coordinate[0][0]);
							#else
								for(i=0; i<64; i++)
								{
									Coordinate[0][i] = *(UINT8*)(Address+i);
								}
							#endif

							if(ScanCnt[0] < 16)
								memset(&Coordinate[0][ScanCnt[0]<< 2], MEMSETVALUE, (64 - (ScanCnt[0]<< 2)) * sizeof(UCHAR));
							else
								ScanCnt[0] -= 16;	
							
                            ret = ncLib_SF_Control(GCMD_SF_WRITE_DATA, FlashDPCAddr, (UINT8 *)(&Coordinate[0][0]), 64, CMD_END);							
							FlashDPCAddr += 64;
						
							BuffSize[0]-=64;
							Address+=64;
						}
						else
						{
							break;
						}
					}			
				}		
			}

#if 0
		    APP_OSDPrint_Dec(1, 1, (USHORT)DPCCnt);
#endif
			DPCBuff[0] = (DPCCnt >> 8) & 0xFF;		 /* Scan Pixel Num Msb */
			DPCBuff[1] = DPCCnt & 0xFF;			 /* Scan Pixel Num Lsb */
			DPCBuff[2] = ((DPCCnt<< 2) >> 8) & 0xFF;	 /* Scan Pixel Size Msb(Byte/Pixel) */
			DPCBuff[3] = (DPCCnt<< 2) & 0xFF;		 /* Scan Pixel Size Lsb(Byte/Pixel) */
			DPCBuff[4] = 0x0A;					 /* BDPC_STATE, 0x0A MEANS BDPC SCAN HAS BEEN RUN ONCE. */

            ret = ncLib_SF_Control(GCMD_SF_WRITE_DATA, bFlsahAddrInfo, (UINT8 *)(&DPCBuff[0]), 5, CMD_END);			
			rSWReg.Category.DPC.Reg.WDPC_STATE = TRUE;
		
			//ncLib_DEBUG_Printf(1, "[NEW DPC END] SCAN NUM = 0x%s	\r\n", DPCCnt);

			ncLib_SF_Control(GCMD_SF_READ_DATA, bFlsahAddr, sGco.DDRADDDPC1, (DPCCnt<< 2)+3, CMD_END);
			//MW_SFlashToDDR_Set(bFlsahAddr, (DPCCnt<< 2)+3, sGco.DDRADDDPC1);
			
			#ifdef __MW_DEFECT_DEBUG__
			ncLib_DEBUG_Printf(1, "OK\r\n");
			#endif
		}

		DPC_FlashWrite_CVBStoAHD();

		/////////////////////////////////////////////////////////////////////
		// FLIP MODE BACK CHECK!!
		/* [2014/8/22] ktsyann : 1-1 */
		switch(bFlipMode){
			case eFLIP_MIRROR 	: 	rSWReg.Category.DPC.Reg.WDPC_FLIP_H = bCurFlipMode;	break;
			case eFLIP_V 		: 	rSWReg.Category.DPC.Reg.WDPC_FLIP_V = bCurFlipMode;	break;
			case eFLIP_ROTATE	: 	rSWReg.Category.DPC.Reg.WDPC_FLIP_R = bCurFlipMode;	break;
		}
		
		rSWReg.Category.DEFFECT.Reg.MIRROR_MODE = bFlipMode;
		ncDrv_Mirror_Set();
		//MW_Mirror_Set();
		/////////////////////////////////////////////////////////////////////
		
		if(rSWReg.Category.DPC.Reg.WDPC_VIEW_TIME)
		{
			ncDrv_BackGround_Set(BACKGROUNDOFF);

			WhiteDPC_Viewer_Set(1);

			sHalDelay.Mode = FALSE;
			
			//while(1)
			//{
				//if(sHalDelay.Time > rSWReg.Category.DPC.Reg.WDPC_VIEW_TIME)
				//{
					ncDrv_BackGround_Set(BACKGROUNDBLACK);
					ncDrv_VSIP_Skip(rSWReg.Category.DPC.Reg.WDPC_VIEW_TIME);
					//MW_BackGround_Set(BACKGROUNDBLACK);
					//break;
				//}
			//}
			
			sHalDelay.Mode = TRUE;
		}

		ncDrv_VSIP_Skip(2);
		
		// Static DPC Display Disable
		rIP_DPC_STATIC_EN	= rSWReg.Category.DPC.Reg.WDPC_MODE;
		rIP_DPC_TEST 		= FALSE;
		ncDrv_VSIP_Skip(2);

		//Live DPC Set ----------------------------------------------------------------------
		/* [2014/12/08] SJH : [STD]-01 */

		if(rSWReg.Category.DPC.Reg.LIVE_WDPC_MODE  == TRUE)	LiveMode = 0xFF;
		else									            LiveMode = FALSE;
		
		rIP_DPC_DM_H_EN = LiveMode;

		if(rSWReg.Category.DPC.Reg.LIVE_WDPC_MODE  == TRUE)	LiveMode = 0x9F;
		else									            LiveMode = FALSE;
		rIP_DPC_DM_C_EN = LiveMode;

		rIP_DPC_BLACK = BlackDPC;

		// AE CHECK!!
		//AE_Iris_Open();
		WhiteDPC_AE_Control(0);
		
		rSWReg.Category.DPC.Reg.WDPC_SCAN_STATE 		= FALSE;

		ncDrv_BackGround_Set(BACKGROUNDOFF);
		ncDrv_OSDClear_Set();

		ret = DPCCnt;	
	}
	
	return ret;
#endif	
}
/* [2014/11/24] ktsyann : [STD]1-2 */
UCHAR ncDrv_StaticDPCWhite_Set(UCHAR tMode)
{
#if (FLASH_MEMORY_MAP_VERSION == VERSION_160409_TEST)	
	USHORT TotalNum = 0;
	USHORT TotalSize = 0;
	UCHAR	rData[4]={0,0,0,0};
	UINT32 tADDR = 0;
	UINT32 tADDR_Info = 0;

	if(rSWReg.Category.MONITOR.Reg.MONITOR_OUTPUT == 0)	//CVBS
	{
		switch(tMode){
			case eFLIP_OFF		:	tADDR = FLASHMEMORY_WDPC_POS_ADDRESS;
									tADDR_Info = FLASHMEMORY_WDPC_INFO_ADDRESS;			break;
			case eFLIP_MIRROR	: 	tADDR = FLASHMEMORY_WDPC_POS_ADDRESS_H_FLIP;
									tADDR_Info = FLASHMEMORY_WDPC_INFO_ADDRESS_H_FLIP;	break;
			case eFLIP_V		: 	tADDR = FLASHMEMORY_WDPC_POS_ADDRESS_V_FLIP;
									tADDR_Info = FLASHMEMORY_WDPC_INFO_ADDRESS_V_FLIP;	break;
			case eFLIP_ROTATE	: 	tADDR = FLASHMEMORY_WDPC_POS_ADDRESS_R_FLIP;
									tADDR_Info = FLASHMEMORY_WDPC_INFO_ADDRESS_R_FLIP;	break;
		}
	}
	else	//AHD
	{
		switch(tMode){
			case eFLIP_OFF		:	tADDR = FLASHMEMORY_WDPC_AHD_POS_ADDRESS;
									tADDR_Info = FLASHMEMORY_WDPC_AHD_INFO_ADDRESS;			break;
			case eFLIP_MIRROR	: 	tADDR = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_H_FLIP;
									tADDR_Info = FLASHMEMORY_WDPC_INFO_AHD_ADDRESS_H_FLIP;	break;
			case eFLIP_V		: 	tADDR = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_V_FLIP;
									tADDR_Info = FLASHMEMORY_WDPC_INFO_AHD_ADDRESS_V_FLIP;	break;
			case eFLIP_ROTATE	: 	tADDR = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_R_FLIP;
									tADDR_Info = FLASHMEMORY_WDPC_INFO_AHD_ADDRESS_R_FLIP;	break;
		}
	}
	
	ncLib_SF_Control(GCMD_SF_READ_DATA, (tADDR_Info + 4L), (UINT8 *)(&rData[0]), 1, CMD_END);

	if(rData[0] != 0x0A){
		sMwDpc.Bit.WDPCInit = STATE_OFF;
		rSWReg.Category.DPC.Reg.WDPC_STATE = FALSE;
	}
	
	rIP_DPC_STATIC_SRAM = FALSE;
	rIP_DPC_STATIC_MCU = FALSE;

	ncDrv_VSIP_Skip(3);
	
	if(rSWReg.Category.DPC.Reg.WDPC_MODE == TRUE)// Enable
	{
		if((sMwDpc.Bit.WDPCInit == STATE_ON)&&(rSWReg.Category.DPC.Reg.WDPC_STATE))
		{
        	ncLib_SF_Control(GCMD_SF_READ_DATA, (tADDR_Info), (UINT8 *)(&rData[0]), 4, CMD_END);

			TotalNum = rData[0];
			TotalNum = (TotalNum << 8) | rData[1];
			TotalSize = rData[2];
			TotalSize = (TotalSize << 8) | rData[3];

			if(TotalNum <= DPCTOTLANUM)
			{				
				ncLib_SF_Control(GCMD_SF_READ_DATA, tADDR, sGco.DDRADDDPC1, TotalSize+3, CMD_END);  
				//MW_SFlashToDDR_Set(tADDR, TotalSize+3, sGco.DDRADDDPC1);
			}

			sMwDpc.Bit.WDPCInit = STATE_OFF;
			ncDrv_DDRMemory_Address_Set();
		}	
	}

	rIP_DPC_R_ENABLE = TRUE;
	
	// Static DPC Mode On,Off
	rIP_DPC_STATIC_EN = rSWReg.Category.DPC.Reg.WDPC_MODE;

	return TRUE;
#endif	
}


void BlackDPC_Viewer_Set(UCHAR Mode)
{
#if 0
	// Static DPC Display Enable
	// Static DPC Mode On,Off
	if(rSWReg.Category.DPC.Reg.BDPC_MODE == TRUE)
	{
		rIP_DPC_BLACK_STATIC_EN	= TRUE;
	}
	else
	{
		rIP_DPC_BLACK_STATIC_EN	= Mode;
	}
	
	rIP_DPC_TEST 		= Mode;	
#endif	
}

void ncDrv_StaticDPCBlack_Cancel(void)
{
#if 0	
	sMwSystem.Control.Run.AE = TRUE; // AE Run

	rSWReg.Category.DPC.Reg.BDPC_SCAN_STATE 		= FALSE;
#endif	
}

UCHAR ncDrv_StaticDPCBlack_Scan(UCHAR Mode)
{	
#if 0	
	USHORT 	pos = 0;
	UCHAR	RetVal = 0;
	//UCHAR 	AH, AM, AL = 0;
	UCHAR	BlackDPCCnt = 0;
	UCHAR	DPCBuff[516];	
	USHORT	DiffTh = 0;

	//backup
	UCHAR DpcBLACK = STATE_OFF;
	UCHAR DpcWHITE = STATE_OFF;
	UCHAR DpcTEST = STATE_OFF;
	UCHAR DpcSTATIC_EN = STATE_OFF;

	// BLACK DPC SEQUENCE	
	// _1. SCAN AREA SET 
	// _2. REF, TH SET
	// _3. DPC REGISTERS ALL OFF (EXCEPT "DPC_EN")
	// _4. BLACK_STATIC_EN_OFF
	// _5. SCAN RUN, VIEW ON (BLACK_STATIC_SCAN = ON, DPC_STATIC_VIEW = ON)
	//     SCAN END
	// _6. CHECK DEFECT COUNTS (DPC_BLACK_STATIC_NUM)
	// _7. SAVE SCANED DEFECTS (XSFR 0xB000~0xB1FF)

	ncDrv_OSDClear_Set();
	
	if(Mode == SCAN_READY)
	{		
		rSWReg.Category.DPC.Reg.BDPC_SCAN_STATE  = TRUE;
		sMwSystem.Control.Run.AE = FALSE; // AE Stop

		/* [2013/11/28] JWLee: DISPALY "PRESS ENTER" ON THE SCREEN */
		sMwMenu.PosX = sMwOsd.CenterPosX-6L;
		sMwMenu.PosY = sMwOsd.CenterPosY;
		sMwMenu.Style = 1L;
		sMwMenu.Color = 1L;
		sMwMenu.FontIndex = F_DEFECT_PRESSENTER_CHAR;
		sMwMenu.StringNum = MAXCHAR_NUM;
		ncDrv_OSDString_Set();

		/* _____________________________________________________ */

		 /* [2014/2/19] JWLee : REFERENCE = ��淹�� (������ �̻��) */
		rIP_DPC_BLACK_STATIC_REF_9_8 = 0x3;
		rIP_DPC_BLACK_STATIC_REF_7_0 = 0xFF;

		 /* [2014/2/19] JWLee : BDPC = pixel <THRESHOLD  */
		DiffTh = _min(rSWReg.Category.DPC.Reg.BDPC_TH, OSD_TH_LIMIT);
		DiffTh = ncDrv_Interp(DiffTh, 0L, OSD_TH_LIMIT, 0x0, 0xFF);	
		//DiffTh = ncLib_Standard_Control(eSTD_INTERP, DiffTh, 0L, OSD_TH_LIMIT, 0x0, 0xFF, CMD_END);

		rIP_DPC_BLACK_STATIC_TH_9_8 = 0L;
		rIP_DPC_BLACK_STATIC_TH_7_0 = DiffTh;

		// _1. SCAN AREA SET 
        ISPSET16(aIP_DPC_SCAN_B_AREA_ST_X_7_0, (ISPGET16(aIP_GRID_BOX0_S_X_7_0) + GRID_LINE_WIDTH));
        ISPSET16(aIP_DPC_SCAN_B_AREA_ED_X_7_0, (ISPGET16(aIP_GRID_BOX0_E_X_7_0) - (GRID_LINE_WIDTH+2)));
        ISPSET16(aIP_DPC_SCAN_B_AREA_ST_Y_7_0, (ISPGET16(aIP_GRID_BOX0_S_Y_7_0) + GRID_LINE_WIDTH));
        ISPSET16(aIP_DPC_SCAN_B_AREA_ED_Y_7_0, (ISPGET16(aIP_GRID_BOX0_E_Y_7_0) - (GRID_LINE_WIDTH+2)));

		RetVal = TRUE;
	}
	else if(Mode == SCAN_START)
	{
		memset(DPCBuff, MEMSETVALUE, 516 * sizeof(UCHAR)); // Init

		// SET BY OSD or NEXTUNE
		rIP_DPC_STATIC_SRAM = TRUE;
		rIP_DPC_STATIC_MCU = FALSE;

		// _3. DPC REGISTERS ALL OFF :0x0210 (EXCEPT "DPC_EN")

		DpcBLACK =      rIP_DPC_BLACK;
		DpcWHITE =      rIP_DPC_WHITE;
		DpcTEST =       rIP_DPC_TEST;
		DpcSTATIC_EN =  rIP_DPC_STATIC_EN;
		
		rIP_DPC_EN = STATE_ON;
		rIP_DPC_BLACK = STATE_OFF;
		rIP_DPC_WHITE = STATE_OFF;
		rIP_DPC_TEST = STATE_OFF;
		rIP_DPC_STATIC_EN = STATE_OFF;
		
		// _4. BLACK_STATIC_EN_OFF
		rIP_DPC_BLACK_STATIC_EN = STATE_OFF;	
		
		// _5. SCAN RUN, VIEW ON (BLACK_STATIC_SCAN = ON, DPC_STATIC_VIEW = ON)
		rIP_DPC_BLACK_STATIC_SCAN = STATE_ON;
		rIP_DPC_STATIC_VIEW = STATE_ON;
		
		ncDrv_VSIP_Skip(4L);
		
		// SCAN END
		rIP_DPC_BLACK_STATIC_SCAN = STATE_OFF;
		rIP_DPC_STATIC_VIEW = STATE_OFF;
		
		ncDrv_VSIP_Skip(2L);

		// _6. CHECK DEFECT COUNTS (DPC_BLACK_STATIC_NUM)
		RetVal = BlackDPCCnt = rIP_DPC_BLACK_STATIC_NUM_7_0;

		//_____________ SAVE SCAN BDPC COUNT____________//
		DPCBuff[0] = BlackDPCCnt;
		DPCBuff[2] = 0x0A; /* BDPC_STATE, 0x0A MEANS BDPC SCAN HAS BEEN RUN ONCE. */
		rSWReg.Category.DPC.Reg.BDPC_STATE = TRUE;
		
		#ifdef __MW_B_DEFECT_DEBUG__
		ncLib_DEBUG_Printf(1, "BDPC Scan Num[%d]\r\n", BlackDPCCnt);
		#endif

		// DPC END INT Wait
		ncDrv_VSIP_Skip(3L);
			
		// Scan Data Read!
		//SFR_BANK_SELECT(0x00);

		for(pos=0; pos<(BlackDPCCnt<< 2); pos++)
		{
			// _7. READ SCAND POSITION (XSFR 0xB000~0xB1FF)
			rIP_IND_XSFR_BANK = (BANK_BDPC | (0x01 & (pos >> 8)));
			rIP_IND_XSFR_ADDR = pos;
			DPCBuff[4 + pos] = rIP_IND_XSFR_RWDATA_ISP;

			 #ifdef __MW_B_DEFECT_DEBUG__
			ncLib_DEBUG_Printf(1, "0x%x \r\n",  (USHORT)DPCBuff[4 + pos]);	
			#endif
		}

		// _8. SAVE SCANED DEFECTS 
		//MW_SFlashSector1_Control(2, &DPCBuff[0]);

		ncDrv_VSIP_Skip(1L);

		rIP_DPC_STATIC_SRAM = TRUE;
		rIP_DPC_STATIC_MCU = FALSE;
				
		if(rSWReg.Category.DPC.Reg.WDPC_VIEW_TIME)
		{
			BlackDPC_Viewer_Set(1L);
			
			sHalDelay.Mode = FALSE;
			
			//while(1)
			//{
			//	if(sHalDelay.Time > rSWReg.Category.DPC.Reg.WDPC_VIEW_TIME)	break;
			//}
			
			ncDrv_VSIP_Skip(rSWReg.Category.DPC.Reg.WDPC_VIEW_TIME);
		
			sHalDelay.Mode = TRUE;
		}

		ncDrv_VSIP_Skip(2L);

		// Static DPC Display Disable
		rIP_DPC_BLACK_STATIC_EN = rSWReg.Category.DPC.Reg.BDPC_MODE;
		rIP_DPC_TEST 		= FALSE;
		ncDrv_VSIP_Skip(2L);

		//Restore Original Status
		rIP_DPC_BLACK = DpcBLACK;
		rIP_DPC_WHITE = DpcWHITE;
		rIP_DPC_TEST = DpcTEST;
		rIP_DPC_STATIC_EN = DpcSTATIC_EN;
		
		sMwSystem.Control.Run.AE = TRUE; // AE Start
		rSWReg.Category.DPC.Reg.BDPC_SCAN_STATE  = FALSE;
	}	

	return RetVal;
#endif	
}

void ncDrv_StaticDPCBlack_Set(void)
{
#if 0	
	static UCHAR	Init = 0xFF;
	UCHAR	rData[4]={0};
	USHORT	BDpcCnt = 0;
	USHORT 	pos = 0;

	rIP_DPC_BLACK_STATIC_EN = STATE_OFF;		//OFF BEFORE READ
	
	rIP_DPC_STATIC_MCU = FALSE;
	
	if((Init == 0xFF) && (rSWReg.Category.DPC.Reg.BDPC_STATE))
	{
        ncLib_SF_Control(GCMD_SF_READ_DATA, (FLASHMEMORY_BDPC_INFO_ADDRESS), (UINT8 *)(&rData[0]), 4, CMD_END);		
		BDpcCnt = rData[0];

		#ifdef __MW_B_DEFECT_DEBUG__
			ncLib_DEBUG_Printf(1, "BdpcCnt %d\r\n",  (USHORT)BDpcCnt);
		#endif

		ncDrv_VSIP_Skip(1);
		//MW_VSIP_Skip(1);	
		
		for(pos=0L; pos<(BDpcCnt << 2); pos++)
		{
            ncLib_SF_Control(GCMD_SF_READ_DATA, (FLASHMEMORY_BDPC_POS_ADDRESS+pos), (UINT8 *)(&rData[0]), 1, CMD_END);	
			
			rIP_IND_XSFR_BANK	= (BANK_BDPC | (0x01 & (pos >> 8)));
			rIP_IND_XSFR_ADDR	= (0xFF & pos);
			rIP_IND_XSFR_RWDATA_ISP = rData[0];

		#ifdef __MW_B_DEFECT_DEBUG__
			ncLib_DEBUG_Printf(1, "%X ",  (USHORT)rData[0]);
			if((pos+1L) % 4L == 0)
				ncLib_DEBUG_Printf(1, "\r\n [%s] ",  (USHORT)pos+1L);
		#endif
		}

		Init = 0x00;
	}
	
	// Static DPC Mode On,Off
	rIP_DPC_BLACK_STATIC_EN = rSWReg.Category.DPC.Reg.BDPC_MODE;	
#endif	
}

void ncDrv_LiveDPC_Auto(void)
{
	USHORT 	StartLevel, EndLevel;
	USHORT 	LiveDpcTh = 0;
	
	if(rSWReg.Category.DPC.Reg.LIVE_WDPC_MODE == eAuto)
	{
		StartLevel = (USHORT)((float)rSWReg.Category.DPC.Reg.LIVE_WDPC_AUTO_Y0*10.23);
		EndLevel = (USHORT)((float)rSWReg.Category.DPC.Reg.LIVE_WDPC_AUTO_Y1*10.23);
		
		if(rIP_AGC_LEVEL_7_0 < rSWReg.Category.DPC.Reg.LIVE_WDPC_AUTO_X0)
		{
			rIP_DPC_DM_H_EN = eMODE_OFF;
		}
		else
		{
			LiveDpcTh = ncDrv_InterpAGC(rSWReg.Category.DPC.Reg.LIVE_WDPC_AUTO_X0, rSWReg.Category.DPC.Reg.LIVE_WDPC_AUTO_X1, StartLevel, EndLevel);
			rIP_DPC_DM_H_EN = 0xFF;
		}
		
		rIP_DPC_TH_H_P_9_8= ((LiveDpcTh>>8)&0x03);
		rIP_DPC_TH_H_P_7_0 = (LiveDpcTh & 0x00FF);
	}
	else
	{
        rIP_DPC_DM_H_EN = eMODE_OFF;
	}

	if(rSWReg.Category.DPC.Reg.LIVE_BDPC_MODE == eAuto)
	{
		StartLevel = (USHORT)((float)rSWReg.Category.DPC.Reg.LIVE_BDPC_AUTO_Y0*10.23);
		EndLevel = (USHORT)((float)rSWReg.Category.DPC.Reg.LIVE_BDPC_AUTO_Y1*10.23);
		
		if(rIP_AGC_LEVEL_7_0 < rSWReg.Category.DPC.Reg.LIVE_BDPC_AUTO_X0)
		{
			rIP_DPC_DM_C_EN = eMODE_OFF;	
		}
		else
		{
			LiveDpcTh = ncDrv_InterpAGC(rSWReg.Category.DPC.Reg.LIVE_BDPC_AUTO_X0, rSWReg.Category.DPC.Reg.LIVE_BDPC_AUTO_X1, StartLevel, EndLevel);
			rIP_DPC_DM_C_EN = 0x9F;
		}
		
		rIP_DPC_TH_C_P_9_8 = ((LiveDpcTh>>8)&0x03);
		rIP_DPC_TH_C_P_7_0= (LiveDpcTh & 0x00FF); 
	}
	else
	{
        rIP_DPC_DM_C_EN = eMODE_OFF;	
	}
}

void ncDrv_ManualDPC_Set(void)
{
#if 0	
#define MDPC_COUNT		32L
    ncLib_SF_Control(GCMD_SF_READ_DATA, (FLASHMEMORY_MDPC_POS_ADDRESS), (UINT8 *)aIP_DPC_MANUAL_X01_7_0, (MDPC_COUNT << 2), CMD_END);
#undef MDPC_COUNT
#endif
}

/* [2014/11/24] ktsyann : [STD]1-2 */
UCHAR DPC_FlashWrite_CVBStoAHD(void)
{
#if (FLASH_MEMORY_MAP_VERSION == VERSION_160409_TEST)	
	/* [2014/11/25] ktsyann : [STD]1-1 */
	INT32 ret = NC_SUCCESS;
	UCHAR i,k;
	UINT32 j;
	UINT32 cADDR,aADDR;
	UINT32 cADDR_Info,aADDR_Info;
	UINT32 StartAddress, NextAddress, TargetAddress;
	UCHAR cInfoChk=FALSE, aInfoChk=FALSE;
	UCHAR rData[6]={0,0,0,0,0,0};
	USHORT cTotalNum = 0, aTotalNum = 0;
	UINT32 FlashDPCAddrback;

	for(i=0; i<4; i++)
	{
		switch(i){
			case 0 : cADDR = FLASHMEMORY_WDPC_POS_ADDRESS;
					 cADDR_Info = FLASHMEMORY_WDPC_INFO_ADDRESS;
					 aADDR = FLASHMEMORY_WDPC_AHD_POS_ADDRESS;
					 aADDR_Info = FLASHMEMORY_WDPC_AHD_INFO_ADDRESS;	
			break;
			case 1 : cADDR = FLASHMEMORY_WDPC_POS_ADDRESS_H_FLIP;
					 cADDR_Info = FLASHMEMORY_WDPC_INFO_ADDRESS_H_FLIP;
					 aADDR = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_H_FLIP;
					 aADDR_Info = FLASHMEMORY_WDPC_INFO_AHD_ADDRESS_H_FLIP;
			break;
			case 2 : cADDR = FLASHMEMORY_WDPC_POS_ADDRESS_V_FLIP;
					 cADDR_Info = FLASHMEMORY_WDPC_INFO_ADDRESS_V_FLIP;
					 aADDR = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_V_FLIP;
					 aADDR_Info = FLASHMEMORY_WDPC_INFO_AHD_ADDRESS_V_FLIP;
			break;
			case 3 : cADDR = FLASHMEMORY_WDPC_POS_ADDRESS_R_FLIP;
					 cADDR_Info = FLASHMEMORY_WDPC_INFO_ADDRESS_R_FLIP;
					 aADDR = FLASHMEMORY_WDPC_POS_AHD_ADDRESS_R_FLIP;
					 aADDR_Info = FLASHMEMORY_WDPC_INFO_AHD_ADDRESS_R_FLIP;
			break;
		}

        ncLib_SF_Control(GCMD_SF_READ_DATA, (aADDR_Info), (UINT8 *)(&rData[0]), 5, CMD_END);
        ncDrv_Delay_Set(3);
		if(rData[4] != 0x0A)
		{
			aInfoChk = FALSE;
		}
		else
		{
			aInfoChk = TRUE;
			aTotalNum = rData[0];
			aTotalNum = (aTotalNum << 8) | rData[1];
		}
        ncLib_SF_Control(GCMD_SF_READ_DATA, (aADDR_Info), (UINT8 *)(&rData[0]), 5, CMD_END);		
        ncDrv_Delay_Set(3);
		if(rData[4] != 0x0A)
		{
			cInfoChk = FALSE;
		}
		else
		{
			cInfoChk = TRUE;
			cTotalNum = rData[0];
			cTotalNum = (cTotalNum << 8) | rData[1];
		}
		
		if(rSWReg.Category.MONITOR.Reg.MONITOR_OUTPUT == 0)	//CVBS
		{
			if((cInfoChk == TRUE)&&(aInfoChk == FALSE))
			{
				/////////////////////////////////////////////////////////////////////
				// FLASH ERASE!!
				FlashDPCAddrback = aADDR;
				/* [2014/11/25] ktsyann : [STD]1-1 */
				for(k=0; k<2; k++)// Static DPC Flash Area 8kbyte Erase!
				{
                    ncLib_SF_Control(GCMD_SF_SECTOR_ERASE, FlashDPCAddrback, CMD_END );
					FlashDPCAddrback += (UINT32)0x1000;
				}
			
				NextAddress = 0;
                ncLib_SF_Control(GCMD_SF_READ_DATA, (cADDR_Info), (UINT8 *)(&rData[0]), 5, CMD_END);				
                ncDrv_Delay_Set(3);
				ret = ncLib_SF_Control(GCMD_SF_WRITE_DATA, aADDR_Info, (UINT8 *)(&rData[0]), 5, CMD_END);
				for(j=0; j<cTotalNum; j++)
				{
					StartAddress = cADDR+NextAddress;
                    ncLib_SF_Control(GCMD_SF_READ_DATA, (StartAddress), (UINT8 *)(&rData[0]), 4, CMD_END);
                
					TargetAddress = aADDR+NextAddress;
    				ret = ncLib_SF_Control(GCMD_SF_WRITE_DATA, TargetAddress, (UINT8 *)(&rData[0]), 4, CMD_END);					
					NextAddress += 4;
				}
			}
		}
		else	//AHD
		{
			if((aInfoChk == TRUE)&&(cInfoChk == FALSE))
			{
				/////////////////////////////////////////////////////////////////////
				// FLASH ERASE!!
				FlashDPCAddrback = cADDR;
				/* [2014/11/25] ktsyann : [STD]1-1 */
				for(k=0; k<2; k++)// Static DPC Flash Area 8kbyte Erase!
				{
					ncLib_SF_Control(GCMD_SF_SECTOR_ERASE, FlashDPCAddrback, CMD_END );
					FlashDPCAddrback += (UINT32)0x1000;
				}
				
				NextAddress = 0;
				ncLib_SF_Control(GCMD_SF_READ_DATA, (aADDR_Info), (UINT8 *)(&rData[0]), 5, CMD_END);
                ncDrv_Delay_Set(3);
   				ret = ncLib_SF_Control(GCMD_SF_WRITE_DATA, cADDR_Info, (UINT8 *)(&rData[0]), 5, CMD_END);
				for(j=0; j<aTotalNum; j++)
				{
					StartAddress = aADDR+NextAddress;
					ncLib_SF_Control(GCMD_SF_READ_DATA, (StartAddress), (UINT8 *)(&rData[0]), 4, CMD_END);

					TargetAddress = cADDR+NextAddress;
       				ret = ncLib_SF_Control(GCMD_SF_WRITE_DATA, TargetAddress, (UINT8 *)(&rData[0]), 4, CMD_END);
					NextAddress += 4;
				}
			}
		}
	}	

	return TRUE;
#endif	
}

