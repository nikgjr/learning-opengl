
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Drv_GlobalHeader.h"
#include "ISP_Drv.h"
#include "Category_Drv.h"


STRUCT_MW_CATEGORY_PROCESS_FLAG	sMwCategoryFlag;
STRUCT_MW_CATEGORY_PROCESS_SUBFLAG	sMwCategorySubFlag;


extern void AE_SetAgcMode(void);
extern void AE_SetSensUpMode(void);
extern void AE_SetLensModeShutter(void);
extern UCHAR PIris_Motor_Set(void);
extern void AE_RefreshShutterMode(void);
extern ULONG AE_TrackingValueCalculate(etCALCULATE_TYPE CalType, dtAE_TRACKING_TYPE *pTrack, UCHAR Speed);
extern void NR_Set3D_Debug(void);

static void Category_SYSTEM(USHORT waddr)
{
#if 1
#define OSD_ALL_CLEAR   1

	if(rSWReg.Category.SYSTEM.Reg.ISP_SAVE)
	{
    	rSWReg.Category.SYSTEM.Reg.ISP_SAVE = STATE_OFF;
    	//ncLib_DEBUG_Printf(1, "ISP SAVE \n");
    	
//		MW_Register_Save(rSWReg.Category.SYSTEM.Reg.ISP_SAVE);
	}
    rIP_O_OSD_CLR_EN = OSD_ALL_CLEAR;

	if(sMwCategorySubFlag.Category.B32.SUB_FLAG_ETC)
	{
	    ncLib_DEBUG_Printf(1, "FRC reset %x \n"  );
	    
//		MW_MainFRC_Reset();	
		sMwCategorySubFlag.Category.B32.SUB_FLAG_ETC = FALSE;
	}

#if SECURITY_MODE
	static UCHAR LongBuf;
	if(sGco.MonitorOutput == eMONITOR_HDSDI)
	{
		if((rSWReg.Category.SYSTEM.Reg.EXT_TW6872_EN == 1) && (rSWReg.Category.SYSTEM.Reg.EXT_POWERDOWN_MODE != 1))
		{
			if(sHalTimer2.DiracCount<8) 
			{
				if(LongBuf != rSWReg.Category.SYSTEM.Reg.EXT_LONG_DISTANCE)
					rSWReg.Category.SYSTEM.Reg.EXT_LONG_DISTANCE = LongBuf;
				
				return;
			}
			
			HAL_I2C_Open(I2C1, &sExtComm.I2C.TW6872);		
			APP_Tw6872Initialize_Set(rSWReg.Category.SYSTEM.Reg.EXT_LONG_DISTANCE);
			HAL_I2C_Close(I2C1);
			
			LongBuf = rSWReg.Category.SYSTEM.Reg.EXT_LONG_DISTANCE;

			sHalTimer2.DiracCount = 0;
		}
	}
#endif
#endif

	return;
}

static void Category_BLACKLEVEL(USHORT waddr)
{
    ncDrv_BlackLevelCompensation_Set();
	return;
}

static void Category_LSC(USHORT waddr)
{
	ncDrv_LSC_Set();
	return;
}

static void Category_AE(USHORT waddr)
{
	rSWReg.Category.AE.Reg.DC_LENS_ASHUT_MIN = 0; // Min Shutter Fix

	switch(rSWReg.Category.AE.Reg.LENS_BOUNDARY)
	{
		case eLENS_MODE_DC:
		case eLENS_MODE_MANUAL:
		case eLENS_MODE_PIRIS:
			rSWReg.Category.AE.Reg.LENS_MODE = rSWReg.Category.AE.Reg.LENS_BOUNDARY;
			break;
		case eLENS_MODE_DC_MANUAL:
			if(rSWReg.Category.AE.Reg.LENS_MODE == eLENS_MODE_PIRIS)	rSWReg.Category.AE.Reg.LENS_MODE = eLENS_MODE_MANUAL;
			break;
		//default:		return;
	}

	AE_SetLensModeShutter();
	AE_RefreshShutterMode();

    AE_SetSensUpMode();
	AE_SetAgcMode();

#ifdef SECURITY_MODE
	if(sMwCategorySubFlag.Category.B32.SUB_FLAG_PIRIS_LENS_SET)
	{
		PIris_Motor_Set();
		sMwCategorySubFlag.Category.B32.SUB_FLAG_PIRIS_LENS_SET = FALSE;
	}


	if(sMwCategorySubFlag.Category.B32.SUB_FLAG_PIRIS_STEP)
	{
		sMwAe.Tracking.Step = eAE_STEP_IRIS;
		AE_RefreshShutterMode();

		if(rSWReg.Category.AE.Reg.PIRIS_CONTROL == P_NEXTCHIP){
			sMwAe.PIris.MaxLimitPos = (GetShort(ADDR_PIRIS_STEP_USE_LIMIT_L)&0x3FF);
		}
		else{
			sMwAe.PIris.MaxLimitPos = (GetShort(ADDR_PIRIS_STEP_USE_LIMIT_L)&0x3FF);
		}
		if(rSWReg.Category.AE.Reg.PIRIS_MODE == PIRIS_MANUAL){
			sMwAe.PIris.StepLvl = sMwAe.PIris.MaxLimitPos;
			sMwAe.PIris.ManualAct = TRUE;
			if(sMwAe.Agc.Level > 0){
                sMwAe.Tracking.GVRangeMin = (GAIN_VALUE_TYPE)500;
				sMwAe.Tracking.GV = (GAIN_VALUE_TYPE)AE_TrackingValueCalculate(CALC_GV, &sMwAe.Tracking, rSWReg.Category.AE.Reg.AGC_CONTROL_SPEED);
			}
		}
		sMwCategorySubFlag.Category.B32.SUB_FLAG_PIRIS_STEP = FALSE;
	}
#endif

	return;
}

static void Category_AWB(USHORT waddr)
{

	if(rSWReg.Category.AWB.Reg.AWC_SET == TRUE)
	{
		sMwAwb.preMode = rSWReg.Category.AWB.Reg.WB_MODE;
		rSWReg.Category.AWB.Reg.WB_MODE = eWHITBAL_AWC;
		sMwAwb.ModeRun = TRUE;

		rSWReg.Category.AWB.Reg.AWC_SET = FALSE;
	}

    ncSvc_WB_MODE_SET();

    OPD_RECT_INCLUDE_EN(rSWReg.Category.AWB.Reg.ATW_INCLUDE_BOX_EN);
    OPD_RECT_EXCLUDE_EN(rSWReg.Category.AWB.Reg.ATW_EXCLUDE_BOX_EN);

	return;
}

static void Category_WDR(USHORT waddr)
{
    ncSvc_WDR_AE_AGC_Set();
    ncDrv_Gamma_Set(); // GAMMA Commands
    ncDrv_Sharpness_Set(); // SHARPNESS Commands
	ncDrv_Chroma_C_Hue_Set(); // CHROMA Commands
	ncDrv_DWDR_Set();
	ncSvc_WDR_Set();
//  ncSvc_WDR_DFrame_Set();
    return;
}

static void Category_BACKLIGHT(USHORT waddr)
{
    ncDrv_Backlight_Mode_Set();
    return;
}

static void Category_DPC(USHORT waddr)
{
#if (FLASH_MEMORY_MAP_VERSION == VERSION_160409_TEST)

	if(sMwCategorySubFlag.Category.B32.SUB_FLAG_WDPC)
	{
		ncDrv_StaticDPCWhite_Scan(rSWReg.Category.DPC.Reg.WDPC_SCAN_START);
		rSWReg.Category.DPC.Reg.WDPC_SCAN_START = FALSE;
		sMwCategorySubFlag.Category.B32.SUB_FLAG_WDPC = FALSE;
	}

#if 0
	if(sMwCategorySubFlag.Category.B32.SUB_FLAG_BDPC)
	{
		ncDrv_StaticDPCBlack_Scan(rSWReg.Category.DPC.Reg.BDPC_SCAN_START);
		rSWReg.Category.DPC.Reg.BDPC_SCAN_START = FALSE;
		sMwCategorySubFlag.Category.B32.SUB_FLAG_BDPC = FALSE;
	}
#endif

	ncDrv_StaticDPCWhite_Set(rSWReg.Category.DEFFECT.Reg.MIRROR_MODE);
	//ncLib_DPC_Control(DPC_BLACK_SET, CMD_END);

	ncDrv_DPC_Grid_Set();
	ncDrv_DPC_ScanView();
#endif

	return;
}


static void Category_SUPPRESS(USHORT waddr)
{
	return;
}

static void Category_LUMA(USHORT waddr)
{
	return;
}

static void Category_CHROMA(USHORT waddr)
{
	ncDrv_Chroma_Set(); // CHROMA Commands
	return;
}

static void Category_GAMMA(USHORT waddr)
{
    ncDrv_Gamma_Set(); // GAMMA Commands
	return;
}

static void Category_NR(USHORT waddr)
{
	ncDrv_NR_Set();
    //if(sGco.Initializing == STATE_OFF)    ncDrv_NR_Set3D_Debug();
	return;
}

static void Category_SHARPNESS(USHORT waddr)
{
	ncDrv_Sharpness_Set(); // SHARPNESS Commands
	return;
}

static void Category_DEFOG(USHORT waddr)
{
    ncDrv_Defog_Set();
	return;
}

static void Category_MD(USHORT waddr)
{
	//MW_Motion_Set();
	return;
}

static void Category_PM(USHORT waddr)
{
#if 0
	MW_Privacy_Set();
#endif

	return;
}

static void Category_DEFFECT(USHORT waddr)
{
	ncDrv_Freeze_Set(rSWReg.Category.DEFFECT.Reg.FREEZE_MODE);
	ncDrv_Negative_Set();
	ncDrv_Mirror_Set();
	return;
}

static void Category_TDN(USHORT waddr)
{
#ifdef SECURITY_MODE
	MW_IrSmart_Set();

	APP_TDN_Set();
#endif

	return;
}

static void Category_OSD(USHORT waddr)
{
#if 0
	MW_OSDFont_Set();

	if(sMwCategorySubFlag.Category.B32.SUB_FLAG_LANGUAGE)
	{
		if(rSWReg.Category.OSD.Reg.MENU_STATE)	MW_OSDClear_Set();

		APP_OSD_Wait();
		MW_OSDBin_Get();
		MW_OSDClear_Set();

		if(rSWReg.Category.OSD.Reg.MENU_STATE)	APP_NCM_Refresh();

		sMwCategorySubFlag.Category.B32.SUB_FLAG_LANGUAGE= FALSE;
	}

	if(sMwCategorySubFlag.Category.B32.SUB_FLAG_OSD_PATH)
	{
    	MW_OSDClear_Set();
		APP_OSD_Wait();
		MW_OSDPath_Set();
		MW_OSDBin_Get();
		MW_OSDClear_Set();
		sMwCategorySubFlag.Category.B32.SUB_FLAG_OSD_PATH = FALSE;
	}

	if(sMwCategorySubFlag.Category.B32.SUB_FLAG_OSD_POS)
	{
    	MW_OSDClear_Set();
		MW_OSD_MenuPosition_Set();
		sMwCategorySubFlag.Category.B32.SUB_FLAG_OSD_POS = FALSE;
	}

	if(rSWReg.Category.OSD.Reg.MENU_STATE)    APP_NCM_Refresh();
#endif
	return;
}

static void Category_CAMTITLE(USHORT waddr)
{
#ifdef SECURITY_MODE
	if(rSWReg.Category.OSD.Reg.MENU_STATE == STATE_OFF)
	{
		MW_OSDClear_Set();
		APP_OSD_CamTitle_Mode(rSWReg.Category.CAMTITLE.Reg.CAM_TITLE_MODE);
		APP_OSD_RS485_CamID_Mode(rSWReg.Category.PROTOCOL.Reg.RS485_CAM_ID_DISPLAY);
	}
#endif
    return;
}


static void Category_AF(USHORT waddr)
{
#ifdef SECURITY_MODE
	MW_AfWindow_Display_Set();
#endif

	return;
}


static void Category_CVBS(USHORT waddr)
{
	if(rSWReg.Category.OSD.Reg.MENU_STATE)
		 ncDrv_OSDClear_Set();

	//if(sMwCategorySubFlag.Category.B32.SUB_FLAG_CVBS)
	//{
		ncDrv_OutputFormat_Set();
		ncSvc_AE_Reset();
		sMwCategorySubFlag.Category.B32.SUB_FLAG_CVBS=FALSE;
	//}

    ncDrv_OSDBin_Get();

    if(waddr == ADDR_CVBS_OUTPUT_SIZE)    ncDrv_DDRMemory_Address_Set();

    ncDrv_CVBS_Set(); // CVBS Memory Commands

#ifdef SECURITY_MODE
	if(rSWReg.Category.OSD.Reg.MENU_STATE)   APP_NCM_Refresh();
#endif
	return;
}


static void Category_AHD(USHORT waddr)
{
#if 0
	MW_AHD_Gain_Set();
#endif

	return;
}

static void Category_MONITOR(USHORT waddr)
{
    sGco.InputFrame.Size = (etFRAME_SIZE)rSWReg.Category.MONITOR.Reg.ISP_INPUT_SIZE;
    sGco.InputFrame.Rate = (etFRAME_RATE)rSWReg.Category.MONITOR.Reg.ISP_INPUT_FRAME;
    sGco.OutputFrame.Size = (etFRAME_SIZE)rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_SIZE;
    sGco.OutputFrame.Rate = (etFRAME_RATE)rSWReg.Category.MONITOR.Reg.ISP_OUTPUT_FRAME;

    ncSvc_AE_Reset();

	//if(sMwCategorySubFlag.Category.B32.SUB_FLAG_MONITOR)
	//{
		ncDrv_OutputFormat_Set();
		//sMwCategorySubFlag.Category.B32.SUB_FLAG_MONITOR = FALSE;
	//}
    return;
}

static void Category_PROTOCOL(USHORT waddr)
{
#ifdef SECURITY_MODE
	MW_CoaxialInitialize_Set();

	if(rSWReg.Category.OSD.Reg.MENU_STATE == STATE_OFF)
	{
		MW_OSDClear_Set();
		APP_OSD_CamTitle_Mode(rSWReg.Category.CAMTITLE.Reg.CAM_TITLE_MODE);
		APP_OSD_RS485_CamID_Mode(rSWReg.Category.PROTOCOL.Reg.RS485_CAM_ID_DISPLAY);
	}
#endif

	return;
}

static void Category_KEYINPUT(USHORT waddr)
{
#ifdef SECURITY_MODE
	if(sMwCategorySubFlag.Category.B32.SUB_FLAG_REGKEY_INPUT)
	{
    	APP_RegKey_Get();
    	sMwCategorySubFlag.Category.B32.SUB_FLAG_REGKEY_INPUT = FALSE;
    }

	if(rSWReg.Category.KEYINPUT.Reg.ADC_EN == STATE_ON && rSWReg.Category.KEYINPUT.Reg.ADC_SET_KEY_MODE == STATE_ON)
	{
		rSWReg.Category.KEYINPUT.Reg.ADC_DEFAULT_VALUE = sMwSystem.ADCValue[0]- rSWReg.Category.KEYINPUT.Reg.ADC_KEY_VALUE_MARGINE;
		if(rSWReg.Category.OSD.Reg.MENU_STATE == HIGH) APP_OSD_Exit();

		sMwMenu.PosX = sMwOsd.CenterPosX-4;
		sMwMenu.PosY = sMwOsd.CenterPosY-2;

		sMwMenu.Style = 2;
		sMwMenu.Color = 2;

		sMwMenu.FontIndex = F_PRESSKEY_CHAR;
		sMwMenu.StringNum = MAXCHAR_NUM;
		MW_OSDString_Set();

		sMwMenu.PosX = sMwOsd.CenterPosX;
		sMwMenu.PosY = sMwOsd.CenterPosY;
		sMwMenu.FontIndex = F_LEFT_CURSOR_CHAR;
		sMwMenu.StringNum = MAXCHAR_NUM;
		MW_OSDString_Set();

	}
#endif

	return;
}

static void Category_GPIO(USHORT waddr)
{
	return;
}

static void Category_OSG(USHORT waddr)
{
	return;
}

static void Category_PGL(USHORT waddr)
{
	return;
}

static void Category_VM(USHORT waddr)
{
	return;
}

static void Category_USER(USHORT waddr)
{
	return;
}


static void Category_Empty(USHORT waddr)
{
    return;

}


const CATEGORY_pFNC_TYPE pCategory_Func[CATEGORY_FUNC_CNT]=
{
	{/* 00 [0x00] */ 20L,		Category_Empty},
	{/* 01 [0x01] */ 45L,		Category_Empty},
	{/* 02 [0x02] */ 55L,		Category_Empty},
	{/* 03 [0x03] */ 110L,		Category_Empty},
	{/* 04 [0x04] */ 140L,		Category_Empty},
	{/* 05 [0x05] */ 360L,		Category_Empty},
	{/* 06 [0x06] */ 405L,		Category_BACKLIGHT},
	{/* 07 [0x07] */ 465L,		Category_Empty},
	{/* 08 [0x08] */ 475L,		Category_Empty},
	{/* 09 [0x09] */ 485L,		Category_Empty},
	{/* 10 [0x0A] */ 555L,		Category_Empty},
	{/* 11 [0x0B] */ 705L,		Category_Empty},
	{/* 12 [0x0C] */ 775L,		Category_Empty},
	{/* 13 [0x0D] */ 885L,		Category_Empty},
	{/* 14 [0x0E] */ 900L,		Category_Empty},
	{/* 15 [0x0F] */ 935L,		Category_Empty},
	{/* 16 [0x10] */ 1035L,		Category_Empty},
	{/* 17 [0x11] */ 1051L,		Category_Empty},
	{/* 18 [0x12] */ 1081L,		Category_Empty},
	{/* 19 [0x13] */ 1151L,		Category_Empty},
	{/* 20 [0x14] */ 1171L,		Category_Empty},
	{/* 21 [0x15] */ 1176L,		Category_Empty},
	{/* 22 [0x16] */ 1226L,		Category_Empty},
	{/* 23 [0x17] */ 1241L,		Category_Empty},
	{/* 24 [0x18] */ 1251L,		Category_Empty},
	{/* 25 [0x19] */ 1281L,		Category_Empty},
	{/* 26 [0x1A] */ 1296L,		Category_Empty},
	{/* 27 [0x1B] */ 1321L,		Category_Empty},
	{/* 28 [0x1C] */ 1341L,		Category_Empty},
	{/* 29 [0x1D] */ 1361L,		Category_Empty},
	{/* 30 [0x1E] */ 1421L,		Category_Empty},
	{/* 31 [0x1F] */ 1440L,		Category_Empty},

};

#if 0
void ncDrv_CategoryFunction_Set(USHORT waddr)
{
	UCHAR i = 0;

	/* Category Function Call */
	for(i = 0; i < CATEGORY_FUNC_CNT; i++)
	{
		if((waddr & 0x7FF) < pCategory_Func[i].Index)
		{
			pCategory_Func[i].Func(waddr);
			//DEBUGMSG(MSGINFO, "Categroy func: 0x%2X \r\n", i);
			break;
		}
	}

	return;
}
#endif

UCHAR ncDrv_CategoryIndex_Get(USHORT Address)
{
    UCHAR i;
    ULONG CategorySetFlag = 0x01;


	for(i = 0; i < CATEGORY_FUNC_CNT; i++)
	{
		if((Address & 0x7FF) < pCategory_Func[i].Index)
		{
		    sMwCategoryFlag.Category.D32 |= (CategorySetFlag << i);
            return 0;
        }
	}

	return 0xFF;
}

void ncDrv_CategoryFunc_Exec(void)
{
	UCHAR i;

	ULONG CategorySetFlag = 0x01;

    for(i=0; i<CATEGORY_FUNC_CNT; i++)
    {
        if(BitCheck(sMwCategoryFlag.Category.D32, i))
	    {
	        pCategory_Func[i].Func(0x00);
	        sMwCategoryFlag.Category.D32 &= (~(CategorySetFlag << i));
	    }
	}
}

void ncDrv_CategoryFunc_Init(void)
{
    UCHAR Idx;
    ULONG CategorySetFlag=0x01;

    sMwCategorySubFlag.Category.B32.SUB_FLAG_MONITOR = STATE_ON;
    sMwCategoryFlag.Category.D32 = 0xFFFFFFFF;
    for(Idx=0; Idx<CATEGORY_FUNC_CNT; Idx++)
    {
        if(BitCheck(sMwCategoryFlag.Category.D32, Idx))
	    {
	        pCategory_Func[Idx].Func(0x00);
	        //DEBUGMSG(MSGINFO, "Func 0x%2X\r", Idx);
	        sMwCategoryFlag.Category.D32 &= (~(CategorySetFlag << Idx));
	    }
	}
}

void ncDrv_CategorySubCheck_Set(UINT32 Address)
{
	if((Address == ADDR_CVBS_OUTPUT_SIZE) || (Address == ADDR_CVBS_NON_STANDARD))
	{
		sMwCategorySubFlag.Category.B32.SUB_FLAG_CVBS = TRUE;
	}

	else if(Address == ADDR_WDPC_SCAN_START)
		sMwCategorySubFlag.Category.B32.SUB_FLAG_WDPC = TRUE;

	else if(Address == ADDR_BDPC_SCAN_START)
		sMwCategorySubFlag.Category.B32.SUB_FLAG_BDPC = TRUE;

	else if(Address == ADDR_ISP_INPUT_SIZE || Address == ADDR_LINEAR_FRAME)
		sMwCategorySubFlag.Category.B32.SUB_FLAG_MONITOR = TRUE;

	else if(Address == ADDR_MONITOR_OUTPUT)
		sMwCategorySubFlag.Category.B32.SUB_FLAG_MONITOR_OUTPUT = TRUE;

	else if(Address == ADDR_PIRIS_LENS_SET)
		sMwCategorySubFlag.Category.B32.SUB_FLAG_PIRIS_LENS_SET = TRUE;

	else if( (Address >= ADDR_PIRIS_STEP_MAX_LIMIT_L)&& (Address <= ADDR_PIRIS_STEP_USE_LIMIT_H))
		sMwCategorySubFlag.Category.B32.SUB_FLAG_PIRIS_STEP = TRUE;

	else if(IsInRage(Address, ADDF_FRC_RESET_DELAY_NTSC_START, ADDF_FRC_RESET_DELAY_PAL_END))
		sMwCategorySubFlag.Category.B32.SUB_FLAG_ETC = TRUE;

	else if (Address == ADDR_KEY_VALUE )
		sMwCategorySubFlag.Category.B32.SUB_FLAG_REGKEY_INPUT = TRUE;

	else if(IsInRage(Address,ADDF_OSD_POS_START, ADDF_OSD_POS_END) || IsInRage(Address,ADDF_OSD_BOX_START, ADDF_OSD_BOX_END))
		sMwCategorySubFlag.Category.B32.SUB_FLAG_OSD_POS = TRUE;

	else if(Address == ADDR_OSD_PATH || Address == ADDR_FONT_SPACE)
		sMwCategorySubFlag.Category.B32.SUB_FLAG_OSD_PATH = TRUE;

	else if(Address == ADDR_LANGUAGE)
		sMwCategorySubFlag.Category.B32.SUB_FLAG_LANGUAGE = TRUE;

}




