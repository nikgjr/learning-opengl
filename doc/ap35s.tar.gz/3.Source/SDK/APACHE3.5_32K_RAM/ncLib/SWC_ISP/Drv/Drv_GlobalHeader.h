/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/



#ifndef __DRV_GLOBALHEADER__
#define __DRV_GLOBALHEADER__

/*=============================================================================
	All Middleware file Include
=============================================================================*/
#include "ISP_REG_Header.h"

#include "Swc_Type.h"



#include "Defog_Drv.h"
#include "DPC_Drv.h"
#include "ISP_Drv.h"
#include "IspFlash_Drv.h"
#include "LDC_Drv.h"
#include "LSC_Drv.h"
#include "MD_Drv.h"
#include "OPD_Drv.h"
#include "OSD_Drv.h"
#include "PGL_Drv.h"
#include "DPGL_Drv.h"

#include "Standard_Drv.h"
#include "System_Drv.h"
#include "ImageAdjust_Drv.h"
#include "TDN_Drv.h"
#include "Flicker_Drv.h"
#include "OSG_Drv.h"


#include "ISP_Drv.h"
#include "System_Drv.h"


#include "Monitor_Drv.h"
#include "BackLight_Drv.h"

#include "BlackLevel_Drv.h"

#include "DigitalEffect_Drv.h"
#include "NR_Drv.h"

#include "Dwdr_Drv.h"
#include "Category_Drv.h"
#endif


