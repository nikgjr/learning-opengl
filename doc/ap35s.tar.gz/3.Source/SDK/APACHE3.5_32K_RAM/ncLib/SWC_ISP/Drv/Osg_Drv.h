
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2015.08.31	Park Min		0.1		Initial  Revision
********************************************************************************/


#ifndef __OSG_DRV__
#define __OSG_DRV__


#define OSG_DBG_PRINFF  1

typedef enum{
    OSG_LAYER0   = 0 ,
	OSG_LAYER1   ,
	OSG_LAYER2   ,
	OSG_LAYER3   ,
	OSG_LAYER4   ,
	OSG_LAYER5   ,
	OSG_LAYER5A  ,
	OSG_LAYER6   ,
	OSG_LAYER6A  ,
	OSG_LAYER_MAX  ,
}OSG_LAYER;




void ncDrv_Osg_Initialize_Set(void);
void ncDrv_Osg_DisplayAll(UCHAR OnOff);
void ncDrv_Osg_LayerDisplaySet(UCHAR Layer,UCHAR OnOff);
void ncDrv_Osg_LayerIndexSet(UCHAR Layer,USHORT Idx);
void ncDrv_Osg_Refresh(void);
void ncDrv_Osg_QSpiOpen(void);

void ncDrv_Osg_ListSet(UCHAR Layer);
	
#endif

