/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : ISP_Drv.h
*
*  @brief   : ISP module driver header file
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __ISP_DRV_H__
#define __ISP_DRV_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/
#include "Lib_GlobalHeader.h"
#include "ISP_REG_Header.h"



/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum
{
    ISP_IRQ0,
    ISP_IRQ1,
    ISP_IRQ2,
    ISP_IRQ3,
    ISP_IRQ4,
    ISP_IRQ5,
    ISP_IRQ6,
    ISP_IRQ7,
    ISP_IRQ8,

    MAX_OF_ISP_IRQ_NUM
} eISP_IRQ_NUM;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/
extern volatile HAL_BANK00_CONTROL_REGISTER    *rBank00;
extern volatile HAL_BANK01_CONTROL_REGISTER    *rBank01;
extern volatile HAL_BANK02_CONTROL_REGISTER    *rBank02;
extern volatile HAL_BANK03_CONTROL_REGISTER    *rBank03;
extern volatile HAL_BANK04_CONTROL_REGISTER    *rBank04;
extern volatile HAL_BANK05_CONTROL_REGISTER    *rBank05;
extern volatile HAL_BANK06_CONTROL_REGISTER    *rBank06;
extern volatile HAL_BANK07_CONTROL_REGISTER    *rBank07;
extern volatile HAL_BANK08_CONTROL_REGISTER    *rBank08;
extern volatile HAL_BANK09_CONTROL_REGISTER    *rBank09;
                                                       
extern volatile HAL_BANK0D_CONTROL_REGISTER    *rBank0D;
extern volatile HAL_BANK0E_CONTROL_REGISTER    *rBank0E;
extern volatile HAL_BANK0F_CONTROL_REGISTER    *rBank0F;
                                                       
//extern volatile HAL_BANK10_CONTROL_REGISTER    *rBank10;
extern volatile HAL_BANK11_CONTROL_REGISTER    *rBank11;
extern volatile HAL_BANK12_CONTROL_REGISTER    *rBank12;
extern volatile HAL_BANK13_CONTROL_REGISTER    *rBank13;
extern volatile HAL_BANK14_CONTROL_REGISTER    *rBank14;
extern volatile HAL_BANK15_CONTROL_REGISTER    *rBank15;
extern volatile HAL_BANK16_CONTROL_REGISTER    *rBank16;
extern volatile HAL_BANK17_CONTROL_REGISTER    *rBank17;
extern volatile HAL_BANK18_CONTROL_REGISTER    *rBank18;
extern volatile HAL_BANK19_CONTROL_REGISTER    *rBank19;
extern volatile HAL_BANK1A_CONTROL_REGISTER    *rBank1A;
extern volatile HAL_BANK1B_CONTROL_REGISTER    *rBank1B;
extern volatile HAL_BANK1C_CONTROL_REGISTER    *rBank1C;
extern volatile HAL_BANK1D_CONTROL_REGISTER    *rBank1D;
                                                       
extern volatile HAL_BANK20_CONTROL_REGISTER    *rBank20;
extern volatile HAL_BANK21_CONTROL_REGISTER    *rBank21;
extern volatile HAL_BANK22_CONTROL_REGISTER    *rBank22;
extern volatile HAL_BANK23_CONTROL_REGISTER    *rBank23;
extern volatile HAL_BANK24_CONTROL_REGISTER    *rBank24;
extern volatile HAL_BANK25_CONTROL_REGISTER    *rBank25;
extern volatile HAL_BANK26_CONTROL_REGISTER    *rBank26;
extern volatile HAL_BANK27_CONTROL_REGISTER    *rBank27;
extern volatile HAL_BANK28_CONTROL_REGISTER    *rBank28;
extern volatile HAL_BANK29_CONTROL_REGISTER    *rBank29;
extern volatile HAL_BANK2A_CONTROL_REGISTER    *rBank2A;
extern volatile HAL_BANK2B_CONTROL_REGISTER    *rBank2B;
extern volatile HAL_BANK2C_CONTROL_REGISTER    *rBank2C;
extern volatile HAL_BANK2D_CONTROL_REGISTER    *rBank2D;
extern volatile HAL_BANK2E_CONTROL_REGISTER    *rBank2E;                                                       

typedef struct
{
    UINT32 SyncInPosFlag        :1;
    UINT32 SyncInNegFlag        :1;
    UINT32 SyncOutPosFlag       :1;
    UINT32 SyncOutNegFlag       :1;
    
    UINT32 DPCScanDoneFlag      :1;
    UINT32 mReserved1           :27;
} tISP_INTR_FLAG_TYPE;


//extern UINT32 gnISPInClock;
extern tISP_INTR_FLAG_TYPE sSyncIntr;

/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern void ncDrv_ISP_RegisterOpen(void);
extern void ncDrv_ISP_RegisterClose(void);
extern void ncDrv_ISP_IRQ_Handler(UINT32 nIrqNum);
extern void ncDrv_ISP_ISR_Handler(void);

extern INT32 ncDrv_ISP_ConnectUserHandler(PrVoid UserHandler);
extern INT32 ncDrv_ISP_DisConnectUserHandler(void);

extern void ncDrv_ISP_SWReset(void);
extern UINT8 ncDrv_ISP_GetInputMode(void);

extern void ncDrv_ISP_CheckInterruptDone(eISP_INTR_NUM nIntrNum);
extern void ncDrv_ISP_CheckStaticDPCScanInterrupt(void);
extern void ncDrv_ISP_CheckInVsyncPosInterrupt(void);
extern void ncDrv_ISP_CheckInVsyncNegInterrupt(void);
extern void ncDrv_ISP_CheckOutVsyncPosInterrupt(void);
extern void ncDrv_ISP_CheckOutVsyncNegInterrupt(void);

extern UINT8 ncDrv_ISP_GetInterruptVsync(eISP_INTR_NUM nIntrNum);
extern void ncDrv_ISP_ClearInterruptVsync(eISP_INTR_NUM nIntrNum);
extern UINT8 ncDrv_ISP_GetInPosSync(void);
extern void ncDrv_ISP_ClearInPosSync(void);
extern UINT8 ncDrv_ISP_GetInNegSync(void);
extern void ncDrv_ISP_ClearInNegSync(void);
extern UINT8 ncDrv_ISP_GetOutPosSync(void);
extern void ncDrv_ISP_ClearOutPosSync(void);
extern UINT8 ncDrv_ISP_GetOutNegSync(void);
extern void ncDrv_ISP_ClearOutNegSync(void);

extern void ncDrv_ISP_InPosSync_Wait(void);
extern void ncDrv_ISP_InNegSync_Wait(void);
extern void ncDrv_ISP_OutPosSync_Wait(void);
extern void ncDrv_ISP_OutNegSync_Wait(void);
extern void ncDrv_ISP_UpDateInNegSync_Wait(void);
extern void ncDrv_ISP_UpDateOutNegSync_Wait(void);

extern void ncDrv_ISP_SetUpDateIn(void);
extern void ncDrv_ISP_SetUpDateOut(void);

extern INT16 ncDrv_ISP_Transition(INT16 InputF, INT16 StartInX, INT16 EndInX, INT16 StartOutX, INT16 EndOutY);
extern void ncDrv_ISP_GAMM_Adaptive_Gamma_Corr(void);
extern void ncDrv_ISP_Fog_Set(void);
//kbh
extern void ncDrv_ISP_EDGE_Set(void);

#endif  /* __ISP_DRV_H__ */


/* End Of File */
