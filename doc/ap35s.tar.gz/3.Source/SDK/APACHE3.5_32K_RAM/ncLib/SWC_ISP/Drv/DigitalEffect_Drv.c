
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "APACHE35.h"
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Api_GlobalHeader.h"


//============================================================================
//      Extern Function Prototype
//============================================================================
//extern void SENSOR_Mirror_Set(UCHAR Mode);
//extern void ncDrv_Defog_Mirror(void);
//extern void ncDrv_Defog_Flip(void);
//extern void ncDrv_Blc_Mirror(void);
//extern void ncDrv_Blc_Flip(void);
//extern void ncDrv_Hsblc_Mirror(void);
//extern void ncDrv_Hsblc_Flip(void);
//============================================================================
//      Function
//============================================================================

STRUCT_MW_DEFFECT	sMwDEffect;

void Mirror_Pos_Set(UCHAR Mode)
{
	BOOL MirrorOn = 0, FlipOn = 0;

	switch(sMwDEffect.MirrorMode)		
	{
		case eFLIP_OFF:
			if(Mode == eFLIP_MIRROR)			{MirrorOn = 1;	FlipOn = 0;}
			else if(Mode == eFLIP_V)			{MirrorOn = 0;	FlipOn = 1;}
			else if(Mode == eFLIP_ROTATE)		{MirrorOn = 1;	FlipOn = 1;}
			else								{MirrorOn = 0;	FlipOn = 0;}
			break;
		case eFLIP_MIRROR:
			if(Mode == eFLIP_OFF)				{MirrorOn = 1;	FlipOn = 0;}
			else if(Mode == eFLIP_V)			{MirrorOn = 1;	FlipOn = 1;}
			else if(Mode == eFLIP_ROTATE)		{MirrorOn = 0;	FlipOn = 1;}
			else								{MirrorOn = 0;	FlipOn = 0;}				
			break;
		case eFLIP_V:
			if(Mode == eFLIP_OFF)				{MirrorOn = 0;	FlipOn = 1;}
			else if(Mode == eFLIP_MIRROR)		{MirrorOn = 1;	FlipOn = 1;}
			else if(Mode == eFLIP_ROTATE)		{MirrorOn = 1;	FlipOn = 0;}
			else								{MirrorOn = 0;	FlipOn = 0;}				
			break;
		case eFLIP_ROTATE:
			if(Mode == eFLIP_OFF)				{MirrorOn = 1;	FlipOn = 1;}
			else if(Mode == eFLIP_MIRROR)		{MirrorOn = 0;	FlipOn = 1;}
			else if(Mode == eFLIP_V)			{MirrorOn = 1;	FlipOn = 0;}
			else								{MirrorOn = 0;	FlipOn = 0;}				
			break;
	}
	
	if(MirrorOn)
	{
		ncDrv_MD_Mirror();
		ncDrv_Defog_Mirror();
		ncDrv_Blc_Mirror();
		ncDrv_Hsblc_Mirror();
	}
	
	if(FlipOn)
	{
        ncDrv_MD_Flip();
		ncDrv_Defog_Flip();
		ncDrv_Blc_Flip();
		ncDrv_Hsblc_Flip();
	}
}

void ncDrv_BackGround_Set(UCHAR Mode)
{
	if(Mode == BACKGROUNDCOLORBAR)	rIP_OTP_TST_PAT = 0x18; // SMPTE RP198 Alternate (HD-SDI Pathological Stress Pattern)
	else							rIP_OTP_TST_PAT = 0x0E; // Black Plane
	
	if(Mode)		rIP_OTP_EN = 0x1;	// Output Test Pattern Enable
	else			
	{
		rIP_OTP_EN = 0x0;	// Output Test Pattern Disable
		rIP_CVBS_BLANK_BG_ON = 0;
	}
}

/* [2014/11/24] ktsyann : [STD]1-2 */ 
void ncDrv_Mirror_Set(void)
{
#define FREEZE_OFF      0x00
#define FREEZE_ON       0x01

	ncDrv_Freeze_Set(FREEZE_ON);

	ncDrv_VSIP_Skip(1);

#if (SENSOR_SELECT == SENSOR_COMMON)
	SENSOR_Mirror_Set(rSWReg.Category.DEFFECT.Reg.MIRROR_MODE); 
#else
    ncDrv_SENSOR_Mirror_Set(rSWReg.Category.DEFFECT.Reg.MIRROR_MODE);    
#endif
	ncDrv_MONITOR_IIF_POSITION_Set();

	ncDrv_VSIP_Skip(1);
	ncDrv_Freeze_Set(rSWReg.Category.DEFFECT.Reg.FREEZE_MODE);
    
	if(sMwDEffect.MirrorMode != rSWReg.Category.DEFFECT.Reg.MIRROR_MODE)		Mirror_Pos_Set(rSWReg.Category.DEFFECT.Reg.MIRROR_MODE);

	// "sMwDEffect.MirrorMode" Register�� Boot Up & Factory�� �ʱ�ȭ �ʿ���.
	sMwDEffect.MirrorMode = rSWReg.Category.DEFFECT.Reg.MIRROR_MODE;

	/* [2014/11/24] ktsyann : [STD]1-2 */ 
	rSWReg.Category.DPC.Reg.WDPC_STATE = TRUE;
	sMwDpc.Bit.WDPCInit = STATE_ON;
	ncDrv_StaticDPCWhite_Set(rSWReg.Category.DEFFECT.Reg.MIRROR_MODE);
	
}

void ncDrv_Negative_Set(void)
{
	rIP_NEGA_EN = rSWReg.Category.DEFFECT.Reg.NEGATIVE_MODE;
}

void ncDrv_Freeze_Set(UCHAR Mode)
{
	if(sGco.MonitorOutput == eMONITOR_CVBS)
	{
		rIP_FREEZE_CVBS_FRC = Mode;
	}
	else// HDSDI or AHD
	{
		rIP_DNR_WB_ENABLE = !Mode;
	}
}

