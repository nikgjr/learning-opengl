
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __DRV_IMAGE_ADJUST__
#define __DRV_IMAGE_ADJUST__
//============================================================================
//      Global Variable
//============================================================================
//============================================================================
//      Function
//============================================================================

#define GAMMA_TBL_CNT	64L

//============================================================================
//      ncDrv_ADH_Gain_set 
//============================================================================
void ncDrv_AHD_Gain_Set(void);


//============================================================================
//      ncDrv_CVBS_set  / Auto 
//============================================================================
void ncDrv_CVBS_Set(void);
void ncDrv_CVBS_HPF_Auto(void);
void ncDrv_CVBS_DS_LPF_Y_Auto(void);



//============================================================================
//      ncDrv_Gamma_set  / Auto 
//============================================================================
void ncDrv_Gamma_Set(void);
void ncDrv_Gamma_Adaptive_Set(void);
void ncDrv_Gamma_Y_Auto(void);
void ncDrv_Gamma_Alpha_Auto(void);



//============================================================================
//      ncDrv_Chroma_set  / Auto 
//============================================================================
void ncDrv_Chroma_Set(void);
void ncDrv_Chroma_CSCMatrix_Auto(void);
void ncDrv_Chroma_CSCRGBAlpha_Auto(void);
void ncDrv_Chroma_C_Hue_Set(void);


//============================================================================
//      ncDrv_Sharpness_set  / Auto 
//============================================================================
void ncDrv_Sharpness_Set(void);
void ncDrv_Sharpness_Y_Auto(void);
void ncDrv_Sharpness_RGB_Auto(void);
void ncDrv_Sharpness_YHPF_Y0_Auto(void);
void ncDrv_Sharpness_MainHPF_Auto(void);



//============================================================================
//      ncDrv_LUMA_set  / Auto 
//============================================================================

void ncDrv_LUMA_Y_Offset_Auto(void);
void ncDrv_LUMA_IBLUR_INT3_Auto(void);


//============================================================================
//      ncDrv_NR_set  / Auto 
//============================================================================

void ncDrv_NR_FNR2D_Auto(void);
void ncDrv_NR_CI_FLAT_Auto(void);

#endif

