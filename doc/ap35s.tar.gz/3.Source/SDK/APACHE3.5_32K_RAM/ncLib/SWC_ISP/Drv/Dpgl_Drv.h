
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __DPGL_DRV__
#define __DPGL_DRV__


/********************************************************************************
* Function Name 	: ncDrv_DPGL_Initialize()
* Description		: ncDrv_DPGL_Initialize
* Refer to		: Drv Document
* Argument		:
										 
* Return		:	@ [TRUE]		: Success
				@ [Error Code]	: Fail (API Reference Guide)
********************************************************************************/
void ncDrv_DPGL_Initialize(void);

void ncDrv_DPGL_Enable(UCHAR enable);
void ncDrv_DPGL_Set_Angel(UCHAR Angel);
void ncDrv_DPGL_Set_Grad_Enable(UCHAR enable);




#endif


