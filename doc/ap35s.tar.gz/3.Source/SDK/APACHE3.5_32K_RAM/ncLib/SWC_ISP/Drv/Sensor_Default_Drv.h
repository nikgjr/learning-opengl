#ifndef __DRV_SENSOR_DEFAULT__
#define __DRV_SENSOR_DEFAULT__

#include "Sensor_Svc.h"


typedef struct {
	void(* Write)(USHORT Addr, USHORT Data);
	USHORT(* Read)(USHORT Addr);
}STRUCT_SENSOR_CONTROL_TYPE;
extern STRUCT_SENSOR_CONTROL_TYPE SENSOR;


#if 0
typedef enum{
    SENSOR_ICLK_27M = 0,           
    SENSOR_ICLK_37p125M,
}etSENSOR_INPUT_CLK_TYPE;
#endif

extern void ncDrv_SENSOR_FPS_Set(void);
extern void ncDrv_SENSOR_Mirror_Set(UCHAR Mode);
extern void ncDrv_SENSOR_Initial_Set(void);
extern void ncDrv_SENSOR_Exposure_Set(STRUCT_AE_SET_TYPE * AeSet);
extern void ncDrv_SENSOR_WDR_Exposure_Set(UCHAR WDR_Ch);


#endif

