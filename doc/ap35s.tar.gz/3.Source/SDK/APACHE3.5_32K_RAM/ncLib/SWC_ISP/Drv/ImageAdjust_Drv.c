
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Drv_GlobalHeader.h"
#include "ISP_Drv.h"
#include "ImageAdjust_Drv.h"
#include "Standard_Drv.h"

void CVBS_BurstSync_Control(void);
void CVBS_ENCGain_Control(void);
void CVBS_BLACKLEVEL_Control(void);


void Chroma_CSC_Matrix_Set(void);
void Chroma_Sat_Gain_Set(void);


void SharpnessRGB_Set(void);
void SharpnessY_Set(void);
void SharpnessHPF_Set(void);

typedef struct
{
	UCHAR Filter0PGain;
	UCHAR Filter0MGain;
	UCHAR Filter0Bratio;
	
	UCHAR Filter1PGain;
	UCHAR Filter1MGain;
	UCHAR Filter1Bratio;
}STRUCT_SHARP;

typedef struct
{
	USHORT  Daylight[9];
	USHORT  Horizon[9];

	FLOAT   Daylightrgb2rgb[9];
	FLOAT   Horizonrgb2rgb[9];
}STRUCT_CSC;

STRUCT_CSC	sMwCSC;
STRUCT_SHARP	sSharpY;
STRUCT_SHARP	sSharpRGB;


/* [2014/12/15] SJH : [STD]-01*/	
const UCHAR MONITOR_GAMMA[12][GAMMA_TBL_CNT] =
{
	{	// 0.45
	0x39,0x4E,0x5E,0x6B,0x76,0x81,0x8A,0x92,
	0x9A,0xA2,0xA9,0xB0,0xB6,0xBD,0xC2,0xC8,
	0x69,0x6E,0x73,0x78,0x7C,0x81,0x85,0x89,
	0x8C,0x90,0x94,0x97,0x9A,0x9E,0xA1,0xA4,
	0xA7,0xAA,0xAD,0xB0,0xB3,0xB5,0xB8,0xBB,
	0xBD,0xC0,0xC3,0xC5,0xC7,0xCA,0xCC,0xCF,
	0xD1,0xD3,0xD5,0xD8,0xDA,0xDC,0xDE,0xE0,
	0xE4,0xE9,0xED,0xF0,0xF4,0xF8,0xFC,0xFF
	},

	{	// 0.5
	0x2D,0x3F,0x4E,0x5A,0x65,0x6E,0x77,0x7F,
	0x87,0x8F,0x96,0x9C,0xA3,0xA9,0xAF,0xB4,
	0x5F,0x65,0x6A,0x6E,0x73,0x77,0x7B,0x7F,
	0x83,0x87,0x8B,0x8F,0x92,0x96,0x99,0x9C,
	0x9F,0xA3,0xA6,0xA9,0xAC,0xAF,0xB2,0xB4,
	0xB7,0xBA,0xBD,0xBF,0xC2,0xC5,0xC7,0xCA,
	0xCC,0xCF,0xD1,0xD4,0xD6,0xD8,0xDB,0xDD,
	0xE2,0xE6,0xEB,0xEF,0xF3,0xF7,0xFB,0xFF
	},

	{	// 0.55
	0x23,0x33,0x40,0x4C,0x56,0x5F,0x67,0x6F,
	0x76,0x7D,0x84,0x8B,0x91,0x97,0x9D,0xA3,
	0x56,0x5C,0x61,0x65,0x6A,0x6E,0x73,0x77,
	0x7B,0x7F,0x83,0x86,0x8A,0x8E,0x91,0x95,
	0x98,0x9B,0x9F,0xA2,0xA5,0xA8,0xAB,0xAE,
	0xB1,0xB4,0xB7,0xBA,0xBD,0xC0,0xC2,0xC5,
	0xC8,0xCA,0xCD,0xD0,0xD2,0xD5,0xD7,0xDA,
	0xDF,0xE4,0xE9,0xED,0xF2,0xF6,0xFB,0xFF
	},

	{	// 0.6
	0x1B,0x2A,0x35,0x3F,0x49,0x51,0x59,0x60,
	0x68,0x6E,0x75,0x7B,0x81,0x87,0x8D,0x92,
	0x4E,0x54,0x58,0x5D,0x62,0x66,0x6B,0x6F,
	0x73,0x77,0x7B,0x7F,0x83,0x86,0x8A,0x8E,
	0x91,0x95,0x98,0x9B,0x9F,0xA2,0xA5,0xA8,
	0xAB,0xAF,0xB2,0xB5,0xB8,0xBB,0xBE,0xC1,
	0xC3,0xC6,0xC9,0xCC,0xCF,0xD1,0xD4,0xD7,
	0xDC,0xE1,0xE7,0xEC,0xF1,0xF6,0xFB,0xFF
	},

	{	// 0.65
	0x15,0x22,0x2C,0x35,0x3E,0x46,0x4D,0x54,
	0x5B,0x61,0x67,0x6D,0x73,0x79,0x7F,0x84,
	0x47,0x4C,0x51,0x56,0x5A,0x5F,0x63,0x67,
	0x6C,0x70,0x74,0x78,0x7C,0x7F,0x83,0x87,
	0x8A,0x8E,0x92,0x95,0x98,0x9C,0x9F,0xA3,
	0xA6,0xA9,0xAC,0xB0,0xB3,0xB6,0xB9,0xBC,
	0xBF,0xC2,0xC5,0xC8,0xCB,0xCE,0xD1,0xD4,
	0xD9,0xDF,0xE5,0xEA,0xF0,0xF5,0xFA,0xFF
	},

	{	// 0.7
	0x11,0x1B,0x24,0x2D,0x34,0x3C,0x42,0x49,
	0x4F,0x55,0x5B,0x61,0x67,0x6C,0x72,0x77,
	0x40,0x45,0x4A,0x4F,0x53,0x58,0x5C,0x60,
	0x65,0x69,0x6D,0x71,0x75,0x79,0x7D,0x80,
	0x84,0x88,0x8B,0x8F,0x93,0x96,0x9A,0x9D,
	0xA0,0xA4,0xA7,0xAB,0xAE,0xB1,0xB4,0xB8,
	0xBB,0xBE,0xC1,0xC4,0xC8,0xCB,0xCE,0xD1,
	0xD7,0xDD,0xE3,0xE9,0xEE,0xF4,0xFA,0xFF
	},

	{	//0.75
	0x0D,0x16,0x1E,0x26,0x2C,0x33,0x39,0x3F,
	0x45,0x4B,0x51,0x56,0x5C,0x61,0x66,0x6B,
	0x3A,0x3F,0x44,0x48,0x4D,0x51,0x56,0x5A,
	0x5E,0x62,0x66,0x6A,0x6E,0x72,0x76,0x7A,
	0x7E,0x82,0x85,0x89,0x8D,0x90,0x94,0x98,
	0x9B,0x9F,0xA2,0xA6,0xA9,0xAD,0xB0,0xB3,
	0xB7,0xBA,0xBD,0xC1,0xC4,0xC7,0xCB,0xCE,
	0xD4,0xDB,0xE1,0xE7,0xED,0xF3,0xF9,0xFF
	},

	{	// 0.8
	0x0A,0x12,0x19,0x1F,0x26,0x2C,0x32,0x37,
	0x3D,0x42,0x47,0x4D,0x52,0x57,0x5C,0x60,
	0x35,0x39,0x3E,0x43,0x47,0x4B,0x50,0x54,
	0x58,0x5C,0x60,0x64,0x68,0x6C,0x70,0x74,
	0x78,0x7C,0x80,0x84,0x87,0x8B,0x8F,0x93,
	0x96,0x9A,0x9D,0xA1,0xA5,0xA8,0xAC,0xAF,
	0xB3,0xB6,0xBA,0xBD,0xC1,0xC4,0xC7,0xCB,
	0xD2,0xD8,0xDF,0xE6,0xEC,0xF3,0xF9,0xFF
	},

	{	// 0.85
	0x08,0x0E,0x15,0x1A,0x20,0x25,0x2B,0x30,
	0x35,0x3A,0x3F,0x44,0x49,0x4E,0x52,0x57,
	0x30,0x34,0x39,0x3D,0x42,0x46,0x4A,0x4E,
	0x52,0x57,0x5B,0x5F,0x63,0x67,0x6B,0x6F,
	0x73,0x77,0x7A,0x7E,0x82,0x86,0x8A,0x8E,
	0x91,0x95,0x99,0x9C,0xA0,0xA4,0xA8,0xAB,
	0xAF,0xB2,0xB6,0xBA,0xBD,0xC1,0xC4,0xC8,
	0xCF,0xD6,0xDD,0xE4,0xEB,0xF2,0xF9,0xFF
	},

	{	// 0.9
	0x06,0x0C,0x11,0x16,0x1B,0x20,0x25,0x2A,
	0x2E,0x33,0x38,0x3C,0x41,0x45,0x4A,0x4E,
	0x2B,0x30,0x34,0x38,0x3C,0x41,0x45,0x49,
	0x4D,0x51,0x55,0x59,0x5D,0x61,0x65,0x69,
	0x6D,0x71,0x75,0x79,0x7D,0x81,0x85,0x89,
	0x8D,0x90,0x94,0x98,0x9C,0xA0,0xA3,0xA7,
	0xAB,0xAF,0xB2,0xB6,0xBA,0xBE,0xC1,0xC5,
	0xCC,0xD4,0xDB,0xE2,0xEA,0xF1,0xF8,0xFF
	},

	{	// 0.95
	0x05,0x09,0x0E,0x13,0x17,0x1B,0x20,0x24,
	0x29,0x2D,0x31,0x36,0x3A,0x3E,0x42,0x47,
	0x27,0x2B,0x30,0x34,0x38,0x3C,0x40,0x44,
	0x48,0x4C,0x50,0x54,0x58,0x5C,0x60,0x64,
	0x68,0x6C,0x70,0x74,0x78,0x7C,0x80,0x84,
	0x88,0x8C,0x90,0x94,0x98,0x9C,0x9F,0xA3,
	0xA7,0xAB,0xAF,0xB3,0xB7,0xBB,0xBE,0xC2,
	0xCA,0xD2,0xD9,0xE1,0xE9,0xF0,0xF8,0xFF
	},

	{	// 1.0
	0x04,0x08,0x0C,0x10,0x14,0x18,0x1C,0x20,
	0x24,0x28,0x2C,0x30,0x34,0x38,0x3C,0x40,
	0x24,0x28,0x2C,0x30,0x34,0x38,0x3C,0x40,
	0x44,0x48,0x4C,0x50,0x54,0x58,0x5C,0x60,
	0x64,0x68,0x6C,0x70,0x74,0x78,0x7C,0x80,
	0x84,0x88,0x8C,0x90,0x94,0x98,0x9C,0xA0,
	0xA4,0xA8,0xAC,0xB0,0xB4,0xB8,0xBC,0xC0,
	0xC8,0xD0,0xD8,0xE0,0xE8,0xF0,0xF8,0xFF
	}
};	

UCHAR Y_Linear[GAMMA_TBL_CNT] = {
	0x04,0x08,0x0C,0x10,0x14,0x18,0x1C,0x20,0x24,0x28,
	0x2C,0x30,0x34,0x38,0x3C,0x40,0x24,0x28,0x2C,0x30,
	0x34,0x38,0x3C,0x40,0x44,0x48,0x4C,0x50,0x54,0x58,
	0x5C,0x60,0x64,0x68,0x6C,0x70,0x74,0x78,0x7C,0x80,
	0x84,0x88,0x8C,0x90,0x94,0x98,0x9C,0xA0,0xA4,0xA8,
	0xAC,0xB0,0xB4,0xB8,0xBC,0xC0,0xC8,0xD0,0xD8,0xE0,
	0xE8,0xF0,0xF8,0xFF
};

#if 1
UCHAR RGB_80_700[GAMMA_TBL_CNT] = {
	0x28,0x31,0x3A,0x45,0x4F,0x5A,0x65,0x70,0x7B,0x86,
	0x90,0x9B,0xA5,0xAF,0xB9,0xC3,0x6B,0x74,0x7C,0x83,
	0x8A,0x91,0x97,0x9D,0xA2,0xA7,0xAB,0xAF,0xB3,0xB6,
	0xB9,0xBC,0xBF,0xC1,0xC3,0xC6,0xC8,0xCA,0xCC,0xCE,
	0xD0,0xD2,0xD4,0xD5,0xD7,0xD9,0xDA,0xDC,0xDE,0xDF,
	0xE1,0xE2,0xE4,0xE5,0xE7,0xE8,0xEB,0xEE,0xF1,0xF4,
	0xF6,0xF9,0xFC,0xFF
};


#else
UCHAR RGB_80_700[GAMMA_TBL_CNT] = {
	0x20,0x2A,0x34,0x40,0x4C,0x58,0x65,0x72,0x7E,0x8A,
	0x96,0xA2,0xAE,0xB9,0xC4,0xD0,0x72,0x7C,0x85,0x8D,
	0x95,0x9C,0xA3,0xA9,0xAF,0xB3,0xB8,0xBC,0xBF,0xC2,
	0xC5,0xC7,0xC9,0xCB,0xCD,0xCF,0xD1,0xD2,0xD4,0xD5,
	0xD7,0xD8,0xD9,0xDA,0xDC,0xDD,0xDE,0xDF,0xE0,0xE1,
	0xE2,0xE3,0xE3,0xE4,0xE5,0xE6,0xE7,0xE9,0xEA,0xEC,
	0xED,0xEF,0xF1,0xF2

};
#endif

void ncDrv_AHD_Gain_Set(void)
{
    rIP_AHD_OUTPUT_SCALE = rSWReg.Category.AHD.Reg.AHD_OUTPUT_GAIN;
    rIP_AHD_BURST_SCALE = rSWReg.Category.AHD.Reg.AHD_BURST_GAIN;
    rIP_AHD_Y_SCALE  = rSWReg.Category.AHD.Reg.AHD_Y_GAIN;
    rIP_AHD_CB_SCALE = rSWReg.Category.AHD.Reg.AHD_CB_GAIN;
    rIP_AHD_CR_SCALE = rSWReg.Category.AHD.Reg.AHD_CR_GAIN;
    rIP_AHD_BURST_PHASE = 0x01;
}

void CVBS_BurstSync_Control(void)
{
    INT32 Vn;
    
    if(CVBS_FORMAT == eCVBS_NTSC)// NTSC
    {
        rIP_CVBS_ENC_U_BURST_9_8 = rSWReg.Category.CVBS.Reg.CVBS_ENC_U_BURST_NTSC_9_8;
        rIP_CVBS_ENC_U_BURST_7_0= rSWReg.Category.CVBS.Reg.CVBS_ENC_U_BURST_NTSC_7_0;
        rIP_CVBS_ENC_V_BURST_9_8 = rSWReg.Category.CVBS.Reg.CVBS_ENC_V_BURST_NTSC_9_8;
        rIP_CVBS_ENC_V_BURST_7_0 = rSWReg.Category.CVBS.Reg.CVBS_ENC_V_BURST_NTSC_7_0;
        rIP_CVBS_ENC_SYNC = rSWReg.Category.CVBS.Reg.CVBS_ENC_SYNC_NTSC;
    }
    else
    {
        if(rSWReg.Category.CVBS.Reg.CVBS_V_BURST_AUTO == STATE_ON)
        {
            Vn  = (0x03 & rSWReg.Category.CVBS.Reg.CVBS_ENC_U_BURST_PAL_9_8);
            Vn  = (Vn << 8) | rSWReg.Category.CVBS.Reg.CVBS_ENC_U_BURST_PAL_7_0;
            Vn  = (Vn & 0x200) ? (1024 - Vn) : -Vn;

            rSWReg.Category.CVBS.Reg.CVBS_ENC_V_BURST_PAL_7_0 = 0xFF & Vn;
            rSWReg.Category.CVBS.Reg.CVBS_ENC_V_BURST_PAL_9_8 = 0x03 & (Vn >> 8);
        }

        rIP_CVBS_ENC_U_BURST_9_8 = rSWReg.Category.CVBS.Reg.CVBS_ENC_U_BURST_PAL_9_8;
        rIP_CVBS_ENC_U_BURST_7_0= rSWReg.Category.CVBS.Reg.CVBS_ENC_U_BURST_PAL_7_0;
        rIP_CVBS_ENC_V_BURST_9_8 = rSWReg.Category.CVBS.Reg.CVBS_ENC_V_BURST_PAL_9_8;
        rIP_CVBS_ENC_V_BURST_7_0 = rSWReg.Category.CVBS.Reg.CVBS_ENC_V_BURST_PAL_7_0;
        rIP_CVBS_ENC_SYNC = rSWReg.Category.CVBS.Reg.CVBS_ENC_SYNC_PAL;
    }
}

void CVBS_ENCGain_Control(void)
{
    if(CVBS_FORMAT == eCVBS_PAL)
    {
        rIP_CVBS_ENC_GAIN_Y = rSWReg.Category.CVBS.Reg.CVBS_ENC_GAIN_Y_PAL;
        rIP_CVBS_ENC_GAIN_CB = rSWReg.Category.CVBS.Reg.CVBS_ENC_GAIN_CB_PAL;
        rIP_CVBS_ENC_GAIN_CR = rSWReg.Category.CVBS.Reg.CVBS_ENC_GAIN_CR_PAL;
    }
    else
    {
        rIP_CVBS_ENC_GAIN_Y = rSWReg.Category.CVBS.Reg.CVBS_ENC_GAIN_Y_NTSC;
        rIP_CVBS_ENC_GAIN_CB = rSWReg.Category.CVBS.Reg.CVBS_ENC_GAIN_CB_NTSC;
        rIP_CVBS_ENC_GAIN_CR = rSWReg.Category.CVBS.Reg.CVBS_ENC_GAIN_CR_NTSC;
    }
}

void CVBS_BLACKLEVEL_Control(void)
{
	float TempLevel;
	UCHAR Temp;

	/* [2015/01/15] ktsyann : [XM]-1 */
	//{{
	UCHAR BlackLevel = 0;
	
	if(CVBS_FORMAT == eCVBS_PAL)	BlackLevel = rSWReg.Category.CVBS.Reg.CVBS_BLACKLEVEL_PAL;
	else							BlackLevel = rSWReg.Category.CVBS.Reg.CVBS_BLACKLEVEL_NTSC;
		
	TempLevel = (float)BlackLevel;
	TempLevel = (TempLevel*2.12);
	if(TempLevel >= 0xFF)	TempLevel = 0xFF;
	Temp = (UCHAR)TempLevel;
	//}}
	
	if(CVBS_FORMAT == eCVBS_PAL)		Temp = Temp + rIP_CVBS_DIS_BLACK_CRT;
	else								Temp = Temp + rIP_CVBS_DIS_BLACK_LCD;
	
	rIP_CVBS_DIS_BLACK_SEL = 0x02;
	rIP_CVBS_DIS_BLACK_USER = Temp;

}

void ncDrv_CVBS_Set(void)
{
    CVBS_BurstSync_Control();
    CVBS_ENCGain_Control();
	CVBS_BLACKLEVEL_Control();
}


void ncDrv_CVBS_HPF_Auto(void)
{
	UCHAR CvbsHpfPGain, CvbsHpfMGain;

	ULONG  	ShutterMax_SV = ((ULONG)(SENSOR_VTOTAL_DEFAULT[INPUT_SIZE])*sMwAe.Tracking.SVDefault)/SENSOR_EXPOSURE_MIN; 

#if(SENSOR_SELECT == OMNIVISION_OV10640 && OPTION_WDR_TYPE == WDRTYPE_DCOMP_OV)
    if(sWdr.Mode)
     	ShutterMax_SV = ((ULONG)(WDR_SENSOR_VTOTAL_DEFAULT[INPUT_SIZE])*sMwAe.Tracking.SVDefault)/SENSOR_EXPOSURE_MIN;
#endif	

	if(rSWReg.Category.CVBS.Reg.CVBS_HPF_PM_MODE)
	{
		if(aIP_AGC_LEVEL_7_0 == 0) /* [2014/3/18] sky : Shutter�� ���Ͽ� Gain Control */
		{			
			CvbsHpfPGain = ncDrv_Interp((USHORT)(sMwAe.Tracking.SV>>10),
                                        (USHORT)(ShutterMax_SV>>10),                    // Start Shutter Level
                                        (USHORT)(sMwAe.Tracking.SVDefault>>10),         // End Shutter Level 
                                        rSWReg.Category.CVBS.Reg.CVBS_HPF_PGAIN_SHUT,   // Start CVBS PGAIN Alpha Level
                                        rSWReg.Category.CVBS.Reg.CVBS_HPF_PGAIN_Y0);    // End CVBS PGAIN Alpha Level 
                                        
			CvbsHpfMGain = ncDrv_Interp((USHORT)(sMwAe.Tracking.SV>>10),
                                        (USHORT)(ShutterMax_SV>>10),                    // Start Shutter Level
                                        (USHORT)(sMwAe.Tracking.SVDefault>>10),         // End Shutter Level 
                                        rSWReg.Category.CVBS.Reg.CVBS_HPF_MGAIN_SHUT,   // Start CVBS MGAIN Alpha Level
                                        rSWReg.Category.CVBS.Reg.CVBS_HPF_MGAIN_Y0);    // End CVBS MGAIN Alpha Level                 
		}
		else
		{
			CvbsHpfPGain = ncDrv_InterpAGC(rSWReg.Category.CVBS.Reg.CVBS_HPF_PM_AGC_X0, 	// Start AGC Level
						                rSWReg.Category.CVBS.Reg.CVBS_HPF_PM_AGC_X1, 	// End AGC Level 
						                rSWReg.Category.CVBS.Reg.CVBS_HPF_PGAIN_Y0, 		// Start CVBS PGAIN Alpha Level
						                rSWReg.Category.CVBS.Reg.CVBS_HPF_PGAIN_Y1);		// End CVBS PGAIN Alpha Level

			CvbsHpfMGain = ncDrv_InterpAGC(rSWReg.Category.CVBS.Reg.CVBS_HPF_PM_AGC_X0, 	// Start AGC Level
								        rSWReg.Category.CVBS.Reg.CVBS_HPF_PM_AGC_X1, 	// End AGC Level
								        rSWReg.Category.CVBS.Reg.CVBS_HPF_MGAIN_Y0, 		// Start CVBS MGAIN Alpha Level
								        rSWReg.Category.CVBS.Reg.CVBS_HPF_MGAIN_Y1);		// End CVBS MGAIN Alpha Level
		}			
		rIP_CVBS_HPF_PGAIN = CvbsHpfPGain;
		rIP_CVBS_HPF_MGAIN = CvbsHpfMGain;
	}
	else
	{
		rIP_CVBS_HPF_PGAIN = rSWReg.Category.CVBS.Reg.CVBS_HPF_PGAIN;
		rIP_CVBS_HPF_MGAIN = rSWReg.Category.CVBS.Reg.CVBS_HPF_MGAIN;
	}
}

void ncDrv_CVBS_DS_LPF_Y_Auto(void)
{
#define CVBSDSLPFY_MAX		0x80
#define CVBSDSLPFY_MIN		0x00

	UCHAR CvbsDsLpfY;
	UCHAR preRegAuto = 0;

	if(rSWReg.Category.CVBS.Reg.CVBS_DS_LPF_Y_MODE)
	{
		CvbsDsLpfY = ncDrv_InterpAGC(rSWReg.Category.CVBS.Reg.CVBS_DS_LPF_Y_AGC_X0, 	// Start AGC Level
				                    rSWReg.Category.CVBS.Reg.CVBS_DS_LPF_Y_AGC_X1, 	// End AGC Level
									rSWReg.Category.CVBS.Reg.CVBS_DS_LPF_Y_ALPHA_Y0, 	// Start CVBS DS LPF Y Alpha Level
									rSWReg.Category.CVBS.Reg.CVBS_DS_LPF_Y_ALPHA_Y1);	// End CVBS DS LPF Y Alpha Level
		
		rIP_CVBS_DS_LPF_Y_ALPHA = CvbsDsLpfY;

		if(rSWReg.Category.CVBS.Reg.CVBS_DS_LPF_COFF_MODE)
		{
			preRegAuto = rIP_CVBS_DS_REG_AUTO;
			rIP_CVBS_DS_REG_AUTO = 0;

/* [2015/04/02] Jong-Hyun, Choi : APACHE28-1 *///	rBank1B.Byte.Reg_0xDB96.B8.CVBS_DS_REG_CHG = 0;
			
			if(ISPGET08(aIP_AGC_LEVEL_7_0) < rSWReg.Category.CVBS.Reg.CVBS_DS_LPF_Y_AGC_X0)
			{
				rIP_CVBS_DS_LPF_COF11_9_8 = 0x00;
				rIP_CVBS_DS_LPF_COF11_7_0 = 0xCF;
				rIP_CVBS_DS_LPF_COF12_9_8 = 0x00;
				rIP_CVBS_DS_LPF_COF12_7_0 = 0x00;
				rIP_CVBS_DS_LPF_COF21_9_8 = 0x01; 
				rIP_CVBS_DS_LPF_COF21_7_0 = 0x98;
				rIP_CVBS_DS_LPF_COF22_9_8 = 0x00; 
				rIP_CVBS_DS_LPF_COF22_7_0 = 0x00;
			}
			else
			{
				rIP_CVBS_DS_LPF_COF11_9_8 = 0x00;
				rIP_CVBS_DS_LPF_COF11_7_0 = 0xCF;
				rIP_CVBS_DS_LPF_COF12_9_8 = 0x00;
				rIP_CVBS_DS_LPF_COF12_7_0 = 0x7F;
				rIP_CVBS_DS_LPF_COF21_9_8 = 0x00; 
				rIP_CVBS_DS_LPF_COF21_7_0 = 0x7F;
				rIP_CVBS_DS_LPF_COF22_9_8 = 0x00; 
				rIP_CVBS_DS_LPF_COF22_7_0 = 0x4D;				
			}
/* [2015/04/02] Jong-Hyun, Choi : APACHE28-1 *///			rBank1B.Byte.Reg_0xDB96.B8.CVBS_DS_REG_CHG = 1;
			
			rIP_CVBS_DS_REG_AUTO =preRegAuto;
/* [2015/04/02] Jong-Hyun, Choi : APACHE28-1 *///			rBank1B.Byte.Reg_0xDB96.B8.CVBS_DS_REG_CHG = 0;
		}
	}
	else
	{
		rIP_CVBS_DS_LPF_Y_ALPHA = CVBSDSLPFY_MAX;

		if(rSWReg.Category.CVBS.Reg.CVBS_DS_LPF_COFF_MODE)
		{
			preRegAuto = rIP_CVBS_DS_REG_AUTO;
			rIP_CVBS_DS_REG_AUTO = 0;
/* [2015/04/02] Jong-Hyun, Choi : APACHE28-1 *///			rBank1B.Byte.Reg_0xDB96.B8.CVBS_DS_REG_CHG = 0;

			// Default Value
			rIP_CVBS_DS_LPF_COF11_9_8 = 0x00;
			rIP_CVBS_DS_LPF_COF11_7_0 = 0xCF;
			rIP_CVBS_DS_LPF_COF12_9_8 = 0x00;
			rIP_CVBS_DS_LPF_COF12_7_0 = 0x00;
			rIP_CVBS_DS_LPF_COF21_9_8 = 0x01;
			rIP_CVBS_DS_LPF_COF21_7_0 = 0x98;
			rIP_CVBS_DS_LPF_COF22_9_8 = 0x00;
			rIP_CVBS_DS_LPF_COF22_7_0 = 0x00;				
/* [2015/04/02] Jong-Hyun, Choi : APACHE28-1 *///			rBank1B.Byte.Reg_0xDB96.B8.CVBS_DS_REG_CHG = 1;
			
			rIP_CVBS_DS_REG_AUTO = preRegAuto;
/* [2015/04/02] Jong-Hyun, Choi : APACHE28-1 *///			rBank1B.Byte.Reg_0xDB96.B8.CVBS_DS_REG_CHG = 0;
		}		
	}	
#undef CVBSDSLPFY_MAX
#undef CVBSDSLPFY_MIN
}


void ncDrv_Gamma_Set(void)
{
#define Y_GAMMA_SW_REG_ADDR	ADDR_Y_GAMMA_00

    UCHAR idx;
	UCHAR GammaGraph = rSWReg.Category.GAMMA.Reg.GAMMA_GRAPH;
	
    /* [2015/11/30] Leo.Sim : ���� ����! */
    rIP_WDR_BASEL_GAMMA_EN   = STATE_OFF;
    rIP_WDR_BASEL2_GAMMA_EN  = STATE_OFF;
    rIP_WDR_BAYER_S_GAMMA_EN = STATE_OFF;
    rIP_WDR_BAYER_M_GAMMA_EN = STATE_OFF;
    rIP_WDR_BAYER_L_GAMMA_EN = STATE_OFF;
    //----------------------------------------------------------

    /* [2016/1/7] jwlee7 : SKY will modify soon */ 
#if 0
    if((etMONITOR_OUT_MODE)sGco.MonitorOutput == eMONITOR_CVBS)
    {
        sHalInt.Flag.Bit.Isp1 = FALSE;
        while(sHalInt.Flag.Bit.Isp1 == FALSE)
        {
           APACHE_SYS_mDelay(1);    // MW_Delay_Set(1);  
        }
    }
    else
    {
       //  MW_VSOP_Skip(1);   
    }
#endif

    if(sWdr.Mode == STATE_ON && rSWReg.Category.WDR.Reg.WDR_GAMMA_EN)
    {    
    	for(idx=0; idx<GAMMA_TBL_CNT; idx++)
    	{
    		ISPSET08((aIP_G_GAMMA_0 + idx), ISPGET08(ADDR_WDR_GAMMA_00 + idx));
    	}
    }
	else
    {	
        for(idx=0; idx<GAMMA_TBL_CNT; idx++)
    	{
    		if(GammaGraph == 0) /* Status Register Gamma */
    		{
    			ISPSET08((aIP_G_GAMMA_0 + idx), ISPGET08(ADDR_RGB_GAMMA_00 + idx));
    		}
    		else                /* 0.45 ~ 1 Gamma */
    		{
    			ISPSET08((aIP_G_GAMMA_0 + idx), MONITOR_GAMMA[GammaGraph-1][idx]);
    		}	
		}
    }
	
    rIP_RGB_GAMMA_GEN = 0x1;      /* USE G to R/B */

    // Y Gamma Set
	
    if(rSWReg.Category.GAMMA.Reg.Y_GAMMA_ALPHA_MODE == STATE_OFF)
    {
        for(idx=0; idx<GAMMA_TBL_CNT; idx++)
        {
            if(rSWReg.Category.GAMMA.Reg.Y_GAMMA_LINEAR_EN)
			{
                ISPSET08((aIP_Y_GAMMA0 + idx), Y_Linear[idx]); 
            }    
            else
			{
                ISPSET08((aIP_Y_GAMMA0 + idx), ISPGET08(Y_GAMMA_SW_REG_ADDR + idx)); //0x827C
           }     
        }
    }
#undef     Y_GAMMA_SW_REG_ADDR
}



void ncDrv_Gamma_Adaptive_Set(void)
{
#define BUFFER_CNT		16L
#define ALPHA_MIN		0L		
#define ALPHA_MAX		100L

	UCHAR	i;
	UCHAR 	Gamma;
	UCHAR 	GammaY1;
	UCHAR 	GammaY2;
	UCHAR	HistoRatio0 = 0;
	UCHAR	AlphaValue;
	UCHAR	AlphaValueAvg;
	USHORT 	AdaptiveRangeMin = ISPGET08(ADDR_ADPT_GAMMA_MIN_7_0); /* Reference Value : 0x2700 */
	USHORT 	AdaptiveRangeMax = ISPGET08(ADDR_ADPT_GAMMA_MAX_7_0); /* Reference Value : 0x3EE0 */

	static UCHAR	BufFilt[BUFFER_CNT]={0};
	static UCHAR 	BuffIdx = 0;
	static UCHAR 	Buffer_CntInit = 0;
	static USHORT 	AccAlphaValue = 0;	
	static UCHAR	PreAlphaAvg;
	static UCHAR	preAdptGammaRefView;

	/* [2014/11/20] JWLee : [STD]-01 */
	if((rSWReg.Category.GAMMA.Reg.ADPT_GAMMA_MODE == STATE_OFF && preAdptGammaRefView == STATE_ON)||
		(rSWReg.Category.GAMMA.Reg.ADPT_REF_VIEW == STATE_OFF && preAdptGammaRefView == STATE_ON))
	{
#if 0
		APP_OSDPrint_String(2, 2, (UCHAR *)"                              ");
		APP_OSDPrint_String(3, 2, (UCHAR *)"                              ");
		APP_OSDPrint_String(4, 2, (UCHAR *)"                              ");
#endif
		rSWReg.Category.GAMMA.Reg.ADPT_REF_VIEW = preAdptGammaRefView = STATE_OFF;
	}

	/* [2014/12/15] SJH : [STD]-01*/
	/* [2014/11/13] JWLee : [STD]-01 */
	/* [2014/10/22] shpark : 1-2 */
	if((rSWReg.Category.GAMMA.Reg.ADPT_GAMMA_MODE == STATE_ON) && (rSWReg.Category.GAMMA.Reg.GAMMA_GRAPH == 0))// user gamma
	{	
		/////////////////////////////////////////////////////
		// Histogram Ratio�� �Ǵ��ؼ� ���� �� Gamma�� ���� //
		/////////////////////////////////////////////////////
		HistoRatio0 = rIP_OPD_HISTO_RATIO0_7_0;

		// Threshold Ʃ�� �ʿ�
		AlphaValue = ncDrv_Interp((USHORT)(HistoRatio0*sMwAe.Agc.Level), AdaptiveRangeMin, AdaptiveRangeMax, ALPHA_MIN, ALPHA_MAX);

		if(Buffer_CntInit < BUFFER_CNT)
		{
			AccAlphaValue += (USHORT)AlphaValue;
			BufFilt[BuffIdx++] = (USHORT)AlphaValue;
			Buffer_CntInit++;
			
			AlphaValueAvg = PreAlphaAvg = AlphaValue;
		}
		else
		{
			if(BuffIdx >= BUFFER_CNT)	BuffIdx = 0;
			AccAlphaValue -= BufFilt[BuffIdx];
			AccAlphaValue += (USHORT)AlphaValue;
			BufFilt[BuffIdx++] = (USHORT)AlphaValue;

			AlphaValueAvg = AccAlphaValue >> 4L;
		}

		if(rSWReg.Category.GAMMA.Reg.ADPT_REF_VIEW == STATE_ON)
		{
#if 0
			APP_OSDPrint_String(2, 2, (UCHAR*)"ADAPTIVE GAMMA TUNE");
			APP_OSDPrint_String(3, 2, (UCHAR*)"REF");
			APP_OSDPrint_Hex2(3, 7, (USHORT)(HistoRatio0*sMwAe.Agc.Level));
			APP_OSDPrint_String(4, 2, (UCHAR*)"RATE");
			APP_OSDPrint_Dec(4, 6, (USHORT)	AlphaValueAvg);
#endif
		}
		preAdptGammaRefView = rSWReg.Category.GAMMA.Reg.ADPT_REF_VIEW;
		
		#if 0
		if(sMwJig.Flag.Cmd2.Bit.Five)
		{
			APP_OSDPrint_String(12, 2, (UCHAR*)"R0");
			APP_OSDPrint_Dec(12, 11, (USHORT)HistoRatio0);
			APP_OSDPrint_String(13, 2, (UCHAR*)"src");
			APP_OSDPrint_Dec(13, 11, (USHORT)(HistoRatio0*sMwAe.Agc.Level));
			APP_OSDPrint_String(14, 2, (UCHAR*)"Aph_Val");
			APP_OSDPrint_Dec(14, 11, (USHORT)(AlphaValue));	
			APP_OSDPrint_String(15, 2, (UCHAR*)"Aph_Avg");
			APP_OSDPrint_Dec(15, 11, (USHORT)(AlphaValueAvg));	
			APP_OSDPrint_String(16, 2, (UCHAR*)"Aph_Acc");
			APP_OSDPrint_Dec(16, 11, (USHORT)(AccAlphaValue));	
		}
		#endif

		if(AlphaValueAvg == PreAlphaAvg) 
			return;

		PreAlphaAvg = AlphaValueAvg;

		for(i=0; i<GAMMA_TBL_CNT; i++)
		{
			GammaY1 = ISPGET08(ADDR_RGB_GAMMA_00 + i);
			GammaY2 = RGB_80_700[i];
			Gamma = ncDrv_Interp(AlphaValueAvg, ALPHA_MIN, ALPHA_MAX, GammaY1, GammaY2);
			
			ISPSET08((aIP_G_GAMMA_0 + i), Gamma);
		}
	}
#undef	BUFFER_CNT
#undef	ALPHA_MIN
#undef	ALPHA_MAX

}

void ncDrv_Gamma_Y_Auto(void)
{
#define Y_GAMMA_SW_REG_ADDR	ADDR_Y_GAMMA_00

	UCHAR 	GammaY2;
	UCHAR 	GammaY1;
	UCHAR 	Gamma;
	static	UCHAR	Alpha = 0;
	UCHAR	i;
	static	UCHAR 	Mode = FALSE;
	UCHAR 	Ratio = 0;

	if(rSWReg.Category.GAMMA.Reg.Y_GAMMA_ALPHA_MODE)
	{
		Ratio = ncDrv_Interp(sMwOpd.OpdYCnt, 0, sMwOpd.Size.Total, 0, 100);
        rSWReg.Category.GAMMA.Reg.Y_GAMMA_ALPHA_CNT = Ratio;
        
		if(Ratio > rSWReg.Category.GAMMA.Reg.Y_GAMMA_ALPHA_RATIO)	Mode = TRUE;
		else	
		{
			if(rSWReg.Category.GAMMA.Reg.Y_GAMMA_ALPHA_RATIO <= 8) rSWReg.Category.GAMMA.Reg.Y_GAMMA_ALPHA_RATIO = 8;
			
			if(Ratio < (rSWReg.Category.GAMMA.Reg.Y_GAMMA_ALPHA_RATIO - 8))	Mode = FALSE;
		}
		
		#if 0
		APP_OSDPrint_String(0, 2, (UCHAR*)"                    ");
		APP_OSDPrint_String(1, 2, (UCHAR*)"YAve");
		APP_OSDPrint_Dec(1, 11, (USHORT)sMwOpd.YAve);
		APP_OSDPrint_String(2, 2, (UCHAR*)"YCnt");
		APP_OSDPrint_Dec(2, 11, (USHORT)sMwOpd.OpdYCnt);
		APP_OSDPrint_String(3, 2, (UCHAR*)"YCnt Rat");
		APP_OSDPrint_Dec(3, 11, (USHORT)Ratio);
		APP_OSDPrint_String(4, 2, (UCHAR*)"TH Rat");
		APP_OSDPrint_Dec(4, 11, (USHORT)rSWReg.Category.GAMMA.Reg.Y_GAMMA_ALPHA_RATIO);	
		APP_OSDPrint_String(5, 2, (UCHAR*)"Mode");
		APP_OSDPrint_Dec(5, 11, (USHORT)Mode);
		#endif
		
		// "Alpha++" Direction : Tuning Gamma
		// "Alpha--" Direction : Linear Gamma	
		for(i=0; i<64; i++)
		{
			GammaY2 	= Y_Linear[i];
			GammaY1 	= ISPGET08(Y_GAMMA_SW_REG_ADDR+i);
			Gamma 		= (((128 - Alpha)*GammaY2) + (Alpha * GammaY1)) >> 7;
			
			rBank13->Category[(32+i)] = Gamma;
		}	
		
		if(Mode)
		{
			if(Alpha < 128)	Alpha++;
		}
		else
		{
			if(Alpha > 0)	Alpha--;
		}
	}
	else
	{
    	rSWReg.Category.GAMMA.Reg.Y_GAMMA_ALPHA_CNT = 0;
    }
    
#undef     Y_GAMMA_SW_REG_ADDR
}


void ncDrv_Gamma_Alpha_Auto(void)
{
#define RGB_GAMMA_ALPHA_DEFAULT 0x00

	UCHAR RGB_GAMMA_ALPHA_Y1;
#if(SENSOR_SELECT == OMNIVISION_OV10640 && OPTION_WDR_TYPE == WDRTYPE_DCOMP_OV)
    if(sWdr.Mode)
    {
    	rIP_RGB_GAMMA_ALPHA = ncDrv_Interp(sMwOpd.Data.NormalAvgY, sMwAeWDR.Tracking.Long.TargetY,
    												sMwAeWDR.Tracking.Long.TargetY + 128, 0x00, 0x60);
    }
    else
    {
    	if(rSWReg.Category.GAMMA.Reg.RGB_GAMMA_ALPHA_MODE)
    	{
#if 0
    		if(MW_TdnStatus_Get() == DN_STATUS_COLOR)	//DAY
    			RGB_GAMMA_ALPHA_Y1 = sScr.Category.GAMMA.Reg.RGB_GAMMA_ALPHA_Y1;
    		else		//BW
#endif
    		RGB_GAMMA_ALPHA_Y1 = rSWReg.Category.GAMMA.Reg.RGB_GAMMA_ALPHA_BW_Y1;

    		rIP_RGB_GAMMA_ALPHA = ncDrv_InterpAGC(rSWReg.Category.GAMMA.Reg.RGB_GAMMA_AGC_X0, 	// Start AGC Level
    											  rSWReg.Category.GAMMA.Reg.RGB_GAMMA_AGC_X1, 	// End AGC Level
    											  rSWReg.Category.GAMMA.Reg.RGB_GAMMA_ALPHA_Y0, 	// Start RGB Gamma Alpha Level
    											  RGB_GAMMA_ALPHA_Y1);				// End RGB Gamma Alpha Level
    	}
    	else		 /* [2014/2/26] JWLee : MANUAL MODE */
    	{
    		rIP_RGB_GAMMA_ALPHA = RGB_GAMMA_ALPHA_DEFAULT;
    	}
    }
#else	
	if(rSWReg.Category.GAMMA.Reg.RGB_GAMMA_ALPHA_MODE)
	{

		RGB_GAMMA_ALPHA_Y1 = rSWReg.Category.GAMMA.Reg.RGB_GAMMA_ALPHA_Y1;

		rIP_RGB_GAMMA_ALPHA = ncDrv_InterpAGC(rSWReg.Category.GAMMA.Reg.RGB_GAMMA_AGC_X0, 	// Start AGC Level
											  rSWReg.Category.GAMMA.Reg.RGB_GAMMA_AGC_X1, 	// End AGC Level 
											  rSWReg.Category.GAMMA.Reg.RGB_GAMMA_ALPHA_Y0, 	// Start RGB Gamma Alpha Level
											  RGB_GAMMA_ALPHA_Y1);				// End RGB Gamma Alpha Level
	}
	else		 /* [2014/2/26] JWLee : MANUAL MODE */
	{
		rIP_RGB_GAMMA_ALPHA = RGB_GAMMA_ALPHA_DEFAULT;
	}
#endif
}


void ncDrv_Chroma_C_Hue_Set(void)
{
#define C_HUE_COLOR_COUNT 6

    if(sWdr.Mode == STATE_OFF)
    {
		rIP_C_HUE_MG = rSWReg.Category.CHROMA.Reg.C_HUE_MG;
		rIP_C_HUE_R = rSWReg.Category.CHROMA.Reg.C_HUE_R;
		rIP_C_HUE_YE = rSWReg.Category.CHROMA.Reg.C_HUE_YE;
		rIP_C_HUE_G = rSWReg.Category.CHROMA.Reg.C_HUE_G;
		rIP_C_HUE_CY = rSWReg.Category.CHROMA.Reg.C_HUE_CY;
		rIP_C_HUE_B = rSWReg.Category.CHROMA.Reg.C_HUE_B;

		rIP_C_HUE_GAIN_MG = rSWReg.Category.CHROMA.Reg.C_HUE_GAIN_MG;
		rIP_C_HUE_GAIN_R = rSWReg.Category.CHROMA.Reg.C_HUE_GAIN_R;
		rIP_C_HUE_GAIN_YE = rSWReg.Category.CHROMA.Reg.C_HUE_GAIN_YE;
		rIP_C_HUE_GAIN_G = rSWReg.Category.CHROMA.Reg.C_HUE_GAIN_G;
		rIP_C_HUE_GAIN_CY = rSWReg.Category.CHROMA.Reg.C_HUE_GAIN_CY;
		rIP_C_HUE_GAIN_B = rSWReg.Category.CHROMA.Reg.C_HUE_GAIN_B;
		
		//memcpy((void*)(aIP_C_HUE_MG), (void*)(ADDR_C_HUE_MG),       C_HUE_COLOR_COUNT);		 //0x130E 0x8214
		//memcpy((void*)(aIP_C_HUE_GAIN_MG), (void*)(ADDR_C_HUE_GAIN_MG),  C_HUE_COLOR_COUNT);	 
    }
    else
    {
		rIP_C_HUE_MG = rSWReg.Category.WDR.Reg.WDR_C_HUE_MG;
		rIP_C_HUE_R = rSWReg.Category.WDR.Reg.WDR_C_HUE_R;
		rIP_C_HUE_YE = rSWReg.Category.WDR.Reg.WDR_C_HUE_YE;
		rIP_C_HUE_G = rSWReg.Category.WDR.Reg.WDR_C_HUE_G;
		rIP_C_HUE_CY = rSWReg.Category.WDR.Reg.WDR_C_HUE_CY;
		rIP_C_HUE_B = rSWReg.Category.WDR.Reg.WDR_C_HUE_B;

		rIP_C_HUE_GAIN_MG = rSWReg.Category.WDR.Reg.WDR_C_HUE_GAIN_MG;
		rIP_C_HUE_GAIN_R = rSWReg.Category.WDR.Reg.WDR_C_HUE_GAIN_R;
		rIP_C_HUE_GAIN_YE = rSWReg.Category.WDR.Reg.WDR_C_HUE_GAIN_YE;
		rIP_C_HUE_GAIN_G = rSWReg.Category.WDR.Reg.WDR_C_HUE_GAIN_G;
		rIP_C_HUE_GAIN_CY = rSWReg.Category.WDR.Reg.WDR_C_HUE_GAIN_CY;
		rIP_C_HUE_GAIN_B = rSWReg.Category.WDR.Reg.WDR_C_HUE_GAIN_B;
		
    	//memcpy((void*)(aIP_C_HUE_MG), (void*)(ADDR_WDR_C_HUE_MG),       C_HUE_COLOR_COUNT); 	 //0x130E 0x8122
    	//memcpy((void*)(aIP_C_HUE_GAIN_MG), (void*)(ADDR_WDR_C_HUE_GAIN_MG),  C_HUE_COLOR_COUNT);
    }

#if 0
	DEBUGMSG(MSGINFO, "rIP_C_HUE_MG = %02X CHROMA_MG = %02X \n", rIP_C_HUE_MG, rSWReg.Category.CHROMA.Reg.C_HUE_MG);
	DEBUGMSG(MSGINFO, "rIP_C_HUE_R  = %02X CHROMA_R  = %02X \n", rIP_C_HUE_R,  rSWReg.Category.CHROMA.Reg.C_HUE_R);
	DEBUGMSG(MSGINFO, "rIP_C_HUE_YE = %02X CHROMA_YE = %02X \n", rIP_C_HUE_YE, rSWReg.Category.CHROMA.Reg.C_HUE_YE);
	DEBUGMSG(MSGINFO, "rIP_C_HUE_G  = %02X CHROMA_G  = %02X \n", rIP_C_HUE_G,  rSWReg.Category.CHROMA.Reg.C_HUE_G);
	DEBUGMSG(MSGINFO, "rIP_C_HUE_CY = %02X CHROMA_CY = %02X \n", rIP_C_HUE_CY, rSWReg.Category.CHROMA.Reg.C_HUE_CY);
	DEBUGMSG(MSGINFO, "rIP_C_HUE_B  = %02X CHROMA_B  = %02X \n", rIP_C_HUE_B,  rSWReg.Category.CHROMA.Reg.C_HUE_B);
#endif
}

void Chroma_CSC_Matrix_Set(void)
{
#define CSC_MATRIX_SIZE     21L
#define CSC_RR                0L
#define CSC_RG                1L
#define CSC_RB                2L
#define CSC_GR                3L
#define CSC_GG                4L
#define CSC_GB                5L
#define CSC_BR                6L
#define CSC_BG                7L
#define CSC_BB                8L

    UCHAR i;

	sMwCSC.Daylight[CSC_RR] = ISPGET16(ADDR_CSC_HT_RR_GAIN_7_0) & 0x0FFF;
	sMwCSC.Daylight[CSC_RG] = ISPGET16(ADDR_CSC_HT_RG_GAIN_7_0) & 0x0FFF;
	sMwCSC.Daylight[CSC_RB] = ISPGET16(ADDR_CSC_HT_RB_GAIN_7_0) & 0x0FFF;
	sMwCSC.Daylight[CSC_GR] = ISPGET16(ADDR_CSC_HT_GR_GAIN_7_0) & 0x0FFF;
	sMwCSC.Daylight[CSC_GG] = ISPGET16(ADDR_CSC_HT_GG_GAIN_7_0) & 0x0FFF;
	sMwCSC.Daylight[CSC_GB]	= ISPGET16(ADDR_CSC_HT_GB_GAIN_7_0) & 0x0FFF;
	sMwCSC.Daylight[CSC_BR] = ISPGET16(ADDR_CSC_HT_BR_GAIN_7_0) & 0x0FFF;
	sMwCSC.Daylight[CSC_BG] = ISPGET16(ADDR_CSC_HT_BG_GAIN_7_0) & 0x0FFF;
	sMwCSC.Daylight[CSC_BB] = ISPGET16(ADDR_CSC_HT_BB_GAIN_7_0) & 0x0FFF;
                            
	sMwCSC.Horizon[CSC_RR] = ISPGET16(ADDR_CSC_LT_RR_GAIN_7_0) & 0x0FFF;
	sMwCSC.Horizon[CSC_RG] = ISPGET16(ADDR_CSC_LT_RG_GAIN_7_0) & 0x0FFF;
	sMwCSC.Horizon[CSC_RB] = ISPGET16(ADDR_CSC_LT_RB_GAIN_7_0) & 0x0FFF;
	sMwCSC.Horizon[CSC_GR] = ISPGET16(ADDR_CSC_LT_GR_GAIN_7_0) & 0x0FFF;
	sMwCSC.Horizon[CSC_GG] = ISPGET16(ADDR_CSC_LT_GG_GAIN_7_0) & 0x0FFF;
	sMwCSC.Horizon[CSC_GB] = ISPGET16(ADDR_CSC_LT_GB_GAIN_7_0) & 0x0FFF;
	sMwCSC.Horizon[CSC_BR] = ISPGET16(ADDR_CSC_LT_BR_GAIN_7_0) & 0x0FFF;
	sMwCSC.Horizon[CSC_BG] = ISPGET16(ADDR_CSC_LT_BG_GAIN_7_0) & 0x0FFF;
	sMwCSC.Horizon[CSC_BB] = ISPGET16(ADDR_CSC_LT_BB_GAIN_7_0) & 0x0FFF;
	
	for(i=0; i < 9; i++)
	{
		sMwCSC.Daylightrgb2rgb[i] = ncDrv_ConvertHex2Float(sMwCSC.Daylight[i]);
        sMwCSC.Horizonrgb2rgb[i] = ncDrv_ConvertHex2Float(sMwCSC.Horizon[i]);
		
    }

    if(rSWReg.Category.CHROMA.Reg.CSC_AUTO_EN == eCSC_MANUAL)
    {
		rIP_CSC_R_R_GAIN_7_0 = rSWReg.Category.CHROMA.Reg.CSC_HT_RR_GAIN_7_0;  
		rIP_CSC_R_R_GAIN_11_8 = rSWReg.Category.CHROMA.Reg.CSC_HT_RR_GAIN_11_8;			
		rIP_CSC_R_G_GAIN_7_0 = rSWReg.Category.CHROMA.Reg.CSC_HT_RG_GAIN_7_0;  
		rIP_CSC_R_G_GAIN_11_8 = rSWReg.Category.CHROMA.Reg.CSC_HT_RG_GAIN_11_8;			
		rIP_CSC_R_B_GAIN_7_0 = rSWReg.Category.CHROMA.Reg.CSC_HT_RB_GAIN_7_0;  
		rIP_CSC_R_B_GAIN_11_8 = rSWReg.Category.CHROMA.Reg.CSC_HT_RB_GAIN_11_8;			
		rIP_CSC_R_OFFSET_7_0 = rSWReg.Category.CHROMA.Reg.CSC_HT_R_OFFSET_7_0; 
		
		rIP_CSC_G_R_GAIN_7_0 = rSWReg.Category.CHROMA.Reg.CSC_HT_GR_GAIN_7_0;  
		rIP_CSC_G_R_GAIN_11_8 = rSWReg.Category.CHROMA.Reg.CSC_HT_GR_GAIN_11_8;			
		rIP_CSC_G_G_GAIN_7_0 = rSWReg.Category.CHROMA.Reg.CSC_HT_GG_GAIN_7_0; 		
		rIP_CSC_G_G_GAIN_11_8 = rSWReg.Category.CHROMA.Reg.CSC_HT_GG_GAIN_11_8;			
		rIP_CSC_G_B_GAIN_7_0 = rSWReg.Category.CHROMA.Reg.CSC_HT_GB_GAIN_7_0;  
		rIP_CSC_G_B_GAIN_11_8 = rSWReg.Category.CHROMA.Reg.CSC_HT_GB_GAIN_11_8;			
		rIP_CSC_G_OFFSET_7_0 = rSWReg.Category.CHROMA.Reg.CSC_HT_G_OFFSET_7_0; 
		
		rIP_CSC_B_R_GAIN_7_0 = rSWReg.Category.CHROMA.Reg.CSC_HT_BR_GAIN_7_0;  
		rIP_CSC_B_R_GAIN_11_8 = rSWReg.Category.CHROMA.Reg.CSC_HT_BR_GAIN_11_8;			
		rIP_CSC_B_G_GAIN_7_0 = rSWReg.Category.CHROMA.Reg.CSC_HT_BG_GAIN_7_0;  
		rIP_CSC_B_G_GAIN_11_8 = rSWReg.Category.CHROMA.Reg.CSC_HT_BG_GAIN_11_8;			
		rIP_CSC_B_B_GAIN_7_0 = rSWReg.Category.CHROMA.Reg.CSC_HT_BB_GAIN_7_0;  
		rIP_CSC_B_B_GAIN_11_8 = rSWReg.Category.CHROMA.Reg.CSC_HT_BB_GAIN_11_8;			
		rIP_CSC_B_OFFSET_7_0 = rSWReg.Category.CHROMA.Reg.CSC_HT_B_OFFSET_7_0; 
			
        //memcpy((void*)(aIP_CSC_R_R_GAIN_7_0), (void*)(ADDR_CSC_HT_RR_GAIN_7_0),   CSC_MATRIX_SIZE); //0x1101, 0x81EA
    }
	
    #if 0
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Daylight[CSC_RR]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Daylight[CSC_RG]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Daylight[CSC_RB]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Daylight[CSC_GR]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Daylight[CSC_GG]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Daylight[CSC_GB]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Daylight[CSC_BR]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Daylight[CSC_BG]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Daylight[CSC_BB]  );

	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Horizon[CSC_RR]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Horizon[CSC_RG]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Horizon[CSC_RB]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Horizon[CSC_GR]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Horizon[CSC_GG]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Horizon[CSC_GB]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Horizon[CSC_BR]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Horizon[CSC_BG]  );
	ncLib_DEBUG_Printf(1, "0x%s \n",  sMwCSC.Horizon[CSC_BB]  );	
    #endif
	
}

void Chroma_Sat_Gain_Set(void)
{
	USHORT Rgain, Bgain;

	Bgain = (USHORT)((float)rSWReg.Category.CHROMA.Reg.CB_SAT_GAIN*2.55);
	Rgain = (USHORT)((float)rSWReg.Category.CHROMA.Reg.CR_SAT_GAIN*2.55);

	rIP_CR_SAT_GAIN = (UCHAR)Rgain;
	rIP_CB_SAT_GAIN = (UCHAR)Bgain;
}

void ncDrv_Chroma_Set(void)
{
    ncDrv_Chroma_C_Hue_Set(); //Chroma_C_Hue_Set();
    Chroma_CSC_Matrix_Set();
	Chroma_Sat_Gain_Set();
}

void ncDrv_Chroma_CSCMatrix_Auto(void)
{
#define CSC_MATRIX_SIZE   21L
#define T_DAYLIGHT          1
#define T_HORIZON           0

	FLOAT Ratio;
	//UCHAR Gap;
	//static FLOAT PreRatio = 0xFF;
	UCHAR i;
	static FLOAT DaylightRatio = 1, HorizonRatio = 0;
	FLOAT Daylightrgb2rgb[9], Horizonrgb2rgb[9];
	FLOAT rgb2rgb[9];
	static USHORT rgb2rgbValue[9];
	USHORT x0, x1;	
    
	if(rSWReg.Category.CHROMA.Reg.CSC_AUTO_EN == eCSC_MANUAL)
	{
	    //PreRatio = 0xFF;
	    DaylightRatio = 1;
	    HorizonRatio = 0;

	    return;
	}

	if((rSWReg.Category.AWB.Reg.WB_MODE > eWHITBAL_ATW)&&(rSWReg.Category.AWB.Reg.WB_MODE < eWHITBAL_AWB))
	{
	    sMwAwb.AveCIE.Xpos = 0x00;
	    sMwAwb.AveCIE.Ypos = 0x00;
	}

    ISPSET16(ADDR_COLOR_TEMPERATURE_CIE_X_7_0, sMwAwb.AveCIE.Xpos);
    ISPSET16(ADDR_COLOR_TEMPERATURE_CIE_Y_7_0, sMwAwb.AveCIE.Ypos);
	
	x0 = rSWReg.Category.CHROMA.Reg.CSC_HT_X0_15_8;
	x0 = (x0 << 8) | rSWReg.Category.CHROMA.Reg.CSC_HT_X0_7_0;
	x1 = rSWReg.Category.CHROMA.Reg.CSC_LT_X0_15_8;
	x1 = (x1 << 8) | rSWReg.Category.CHROMA.Reg.CSC_LT_X0_7_0;

	Ratio = ncDrv_Transition(sMwAwb.AveCIE.Xpos,
    						  x0,// High Temperature(Daylight)
    						  x1,// Low Temperature(Horizon)
    						  T_DAYLIGHT,// Daylight Weight
    						  T_HORIZON);// Horizon Weight

    if(rSWReg.Category.AWB.Reg.WB_MODE != eWHITBAL_ATW)   Ratio = T_DAYLIGHT;

	//Gap = (_abs(Ratio, PreRatio) * 100);

	//if(Gap > 1)
	{
	    //PreRatio = Ratio;
	    
		DaylightRatio = Ratio;
		HorizonRatio = 1 - Ratio;

		for(i = 0; i < 9; i++)
		{
			Daylightrgb2rgb[i] = sMwCSC.Daylightrgb2rgb[i] * DaylightRatio;
			Horizonrgb2rgb[i] = sMwCSC.Horizonrgb2rgb[i] * HorizonRatio;		    

			rgb2rgb[i] = Daylightrgb2rgb[i] + Horizonrgb2rgb[i];// �Ҽ��� Data
			rgb2rgbValue[i] = (SHORT)(rgb2rgb[i] * 1024);// �Ҽ��� Data�� 12bit Register Data�� ��ȯ
			rgb2rgbValue[i] = (rgb2rgbValue[i] & 0x0FFF);// ���� 4bit ����.
		}

    	// RR, RG, RB
    	rIP_CSC_R_R_GAIN_11_8 	= (UCHAR)((rgb2rgbValue[0] >> 8) & 0xFF);
    	rIP_CSC_R_R_GAIN_7_0 	= (UCHAR)(rgb2rgbValue[0] & 0xFF);
    	rIP_CSC_R_G_GAIN_11_8 	= (UCHAR)((rgb2rgbValue[1] >> 8) & 0xFF);
    	rIP_CSC_R_G_GAIN_7_0 	= (UCHAR)(rgb2rgbValue[1] & 0xFF);
    	rIP_CSC_R_B_GAIN_11_8 	= (UCHAR)((rgb2rgbValue[2] >> 8) & 0xFF);
    	rIP_CSC_R_B_GAIN_7_0 	= (UCHAR)(rgb2rgbValue[2] & 0xFF);

    	// GR, GG, GB
    	rIP_CSC_G_R_GAIN_11_8 	= (UCHAR)((rgb2rgbValue[3] >> 8) & 0xFF);
    	rIP_CSC_G_R_GAIN_7_0 	= (UCHAR)(rgb2rgbValue[3] & 0xFF);
    	rIP_CSC_G_G_GAIN_11_8 	= (UCHAR)((rgb2rgbValue[4] >> 8) & 0xFF);
    	rIP_CSC_G_G_GAIN_7_0 	= (UCHAR)(rgb2rgbValue[4] & 0xFF);
    	rIP_CSC_G_B_GAIN_11_8 	= (UCHAR)((rgb2rgbValue[5] >> 8) & 0xFF);
    	rIP_CSC_G_B_GAIN_7_0 	= (UCHAR)(rgb2rgbValue[5] & 0xFF);

    	// BR, BG, BB
    	rIP_CSC_B_R_GAIN_11_8 	= (UCHAR)((rgb2rgbValue[6] >> 8) & 0xFF);
    	rIP_CSC_B_R_GAIN_7_0 	= (UCHAR)(rgb2rgbValue[6] & 0xFF);
    	rIP_CSC_B_G_GAIN_11_8 	= (UCHAR)((rgb2rgbValue[7] >> 8) & 0xFF);
    	rIP_CSC_B_G_GAIN_7_0 	= (UCHAR)(rgb2rgbValue[7] & 0xFF);
    	rIP_CSC_B_B_GAIN_11_8 	= (UCHAR)((rgb2rgbValue[8] >> 8) & 0xFF);
    	rIP_CSC_B_B_GAIN_7_0 	= (UCHAR)(rgb2rgbValue[8] & 0xFF);
	}
    #if 0
	else
	{
        if(Ratio == T_DAYLIGHT)     memcpy((void*)(aIP_CSC_R_R_GAIN_7_0), (void*)(ADDR_CSC_HT_RR_GAIN_7_0),   CSC_MATRIX_SIZE);
        else if(Ratio == T_HORIZON) memcpy((void*)(aIP_CSC_R_R_GAIN_7_0), (void*)(ADDR_CSC_LT_RR_GAIN_7_0),   CSC_MATRIX_SIZE);
	}
    #endif
}

void ncDrv_Chroma_CSCRGBAlpha_Auto(void)
{
#define CSC_RGB_ALPHA_DEFAULT   0x80
	UCHAR CSCRGBAlpha;
	//USHORT x0, x1;
	//UCHAR StartY0;
	
	if(rSWReg.Category.SUPPRESS.Reg.SUP_CSC_AGC_EN)
	{		
		CSCRGBAlpha = ncDrv_InterpAGC(rSWReg.Category.SUPPRESS.Reg.SUP_CSC_AGC_X0, 	// Start AGC Level
									rSWReg.Category.SUPPRESS.Reg.SUP_CSC_AGC_X1, 	// End AGC Level 
									rSWReg.Category.SUPPRESS.Reg.SUP_CSC_ALPHA_Y0, // Start CSC RGB Alpha Level
									rSWReg.Category.SUPPRESS.Reg.SUP_CSC_ALPHA_Y1);// End CSC RGB Alpha Level
		
		rIP_CSC_RGB_ALPHA = CSCRGBAlpha;
	}
	else
	{
		rIP_CSC_RGB_ALPHA = CSC_RGB_ALPHA_DEFAULT;
	}	
}


void SharpnessRGB_Set(void)
{
	UCHAR tblShpLevel[3] = {0L, 5L, 10L};
	UCHAR tblShpGain[3] = {0x00, 0x00, 0xFF};

    if(sWdr.Mode == STATE_OFF)
    {
    	sSharpRGB.Filter0Bratio = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F0_BRATIO_Y0;
    	sSharpRGB.Filter1Bratio = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F1_BRATIO_Y0;

        //rBank2C.Byte.Reg_0xEC81.B8.RGB_HPF_EN = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_AUTO;
        rIP_RGB_HPF_EN = (rSWReg.Category.SHARPNESS.Reg.SHARP_MODE) ? rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_MODE : STATE_OFF;
        
    	tblShpGain[1L] = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F0_PGAIN_Y0;
    	sSharpRGB.Filter0PGain = ncDrv_InterpTbl08(5, tblShpLevel, tblShpGain, 3L);
    	tblShpGain[1L] = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F0_MGAIN_Y0;
    	sSharpRGB.Filter0MGain = ncDrv_InterpTbl08(5, tblShpLevel, tblShpGain, 3L);
    	tblShpGain[1L] = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F1_PGAIN_Y0;
    	sSharpRGB.Filter1PGain = ncDrv_InterpTbl08(rSWReg.Category.SHARPNESS.Reg.SHARP_LEVEL, tblShpLevel, tblShpGain, 3L);
    	tblShpGain[1L] = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F1_MGAIN_Y0;
    	sSharpRGB.Filter1MGain = ncDrv_InterpTbl08(rSWReg.Category.SHARPNESS.Reg.SHARP_LEVEL, tblShpLevel, tblShpGain, 3L);
    }
    else
    {
    	sSharpRGB.Filter0Bratio = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_F0_BRATIO_Y0;
    	sSharpRGB.Filter1Bratio = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_F1_BRATIO_Y0;

        //rBank2C.Byte.Reg_0xEC81.B8.RGB_HPF_EN = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_AUTO;
        rIP_RGB_HPF_EN = (rSWReg.Category.SHARPNESS.Reg.SHARP_MODE) ? rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_MODE : STATE_OFF;
        
    	tblShpGain[1L] = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_F0_PGAIN_Y0;
    	sSharpRGB.Filter0PGain = ncDrv_InterpTbl08(5, tblShpLevel, tblShpGain, 3L);
    	tblShpGain[1L] = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_F0_MGAIN_Y0;
    	sSharpRGB.Filter0MGain = ncDrv_InterpTbl08(5, tblShpLevel, tblShpGain, 3L);
    	tblShpGain[1L] = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_F1_PGAIN_Y0;
    	sSharpRGB.Filter1PGain = ncDrv_InterpTbl08(rSWReg.Category.SHARPNESS.Reg.SHARP_LEVEL, tblShpLevel, tblShpGain, 3L);
    	tblShpGain[1L] = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_F1_MGAIN_Y0;
    	sSharpRGB.Filter1MGain = ncDrv_InterpTbl08(rSWReg.Category.SHARPNESS.Reg.SHARP_LEVEL, tblShpLevel, tblShpGain, 3L);
	}
}


void SharpnessY_Set(void)
{
	UCHAR tblShpLevel[3] = {0L, 5L, 10L};
	UCHAR tblShpGain[3] = {0x00, 0x00, 0xFF};

    if(sWdr.Mode == STATE_OFF)
    {
    	sSharpY.Filter0Bratio = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F0_BRATIO_Y0;
    	sSharpY.Filter1Bratio = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F1_BRATIO_Y0;

        //rBank15.Byte.Reg_0xD501.B8.YHPF_EN = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_AUTO;
        rIP_YHPF_EN = (rSWReg.Category.SHARPNESS.Reg.SHARP_MODE) ? rSWReg.Category.SHARPNESS.Reg.SHARP_Y_MODE : STATE_OFF;
        
    	tblShpGain[1L] = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F0_PGAIN_Y0;
    	sSharpY.Filter0PGain = ncDrv_InterpTbl08(5, tblShpLevel, tblShpGain, 3L);
    	tblShpGain[1L] = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F0_MGAIN_Y0;
    	sSharpY.Filter0MGain = ncDrv_InterpTbl08(5, tblShpLevel, tblShpGain, 3L);
    	tblShpGain[1L] = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F1_PGAIN_Y0;
    	sSharpY.Filter1PGain = ncDrv_InterpTbl08(rSWReg.Category.SHARPNESS.Reg.SHARP_LEVEL, tblShpLevel, tblShpGain, 3L);
    	tblShpGain[1L] = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F1_MGAIN_Y0;
    	sSharpY.Filter1MGain = ncDrv_InterpTbl08(rSWReg.Category.SHARPNESS.Reg.SHARP_LEVEL, tblShpLevel, tblShpGain, 3L);
    }
    else
    {
    	sSharpY.Filter0Bratio = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_F0_BRATIO_Y0;
    	sSharpY.Filter1Bratio = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_F1_BRATIO_Y0;

        //rBank15.Byte.Reg_0xD501.B8.YHPF_EN = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_AUTO;
        rIP_YHPF_EN = (rSWReg.Category.SHARPNESS.Reg.SHARP_MODE) ? rSWReg.Category.WDR.Reg.WDR_SHARP_Y_MODE : STATE_OFF;
        
    	tblShpGain[1L] = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_F0_PGAIN_Y0;
    	sSharpY.Filter0PGain = ncDrv_InterpTbl08(5, tblShpLevel, tblShpGain, 3L);

    	tblShpGain[1L] = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_F0_MGAIN_Y0;
    	sSharpY.Filter0MGain = ncDrv_InterpTbl08(5, tblShpLevel, tblShpGain, 3L);

    	tblShpGain[1L] = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_F1_PGAIN_Y0;
    	sSharpY.Filter1PGain = ncDrv_InterpTbl08(rSWReg.Category.SHARPNESS.Reg.SHARP_LEVEL, tblShpLevel, tblShpGain, 3L);
    	tblShpGain[1L] = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_F1_MGAIN_Y0;
    	sSharpY.Filter1MGain = ncDrv_InterpTbl08(rSWReg.Category.SHARPNESS.Reg.SHARP_LEVEL, tblShpLevel, tblShpGain, 3L);
    }
}

void SharpnessHPF_Set(void)
{
    if(sWdr.Mode == STATE_OFF)
    {
        rIP_YHPF_F0_MCOR_OFFSET     = rSWReg.Category.SHARPNESS.Reg.YHPF_F0_MCOR_OFFSET;
        rIP_YHPF_F0_PCOR_OFFSET     = rSWReg.Category.SHARPNESS.Reg.YHPF_F0_PCOR_OFFSET;
        rIP_YHPF_F1_MCOR_OFFSET     = rSWReg.Category.SHARPNESS.Reg.YHPF_F1_MCOR_OFFSET;
        rIP_YHPF_F1_PCOR_OFFSET     = rSWReg.Category.SHARPNESS.Reg.YHPF_F1_PCOR_OFFSET;
        rIP_RGB_HPF_F0_MCOR_OFFSET  = rSWReg.Category.SHARPNESS.Reg.RGB_F0_MCOR_OFFSET;
        rIP_RGB_HPF_F0_PCOR_OFFSET  = rSWReg.Category.SHARPNESS.Reg.RGB_F0_PCOR_OFFSET;
        rIP_RGB_HPF_F1_MCOR_OFFSET  = rSWReg.Category.SHARPNESS.Reg.RGB_F1_MCOR_OFFSET;
        rIP_RGB_HPF_F1_PCOR_OFFSET  = rSWReg.Category.SHARPNESS.Reg.RGB_F1_PCOR_OFFSET;
    }
    else
    {
        rIP_YHPF_F0_MCOR_OFFSET     = rSWReg.Category.WDR.Reg.WDR_YHPF_F0_MCOR_OFFSET; 
        rIP_YHPF_F0_PCOR_OFFSET     = rSWReg.Category.WDR.Reg.WDR_YHPF_F0_PCOR_OFFSET; 
        rIP_YHPF_F1_MCOR_OFFSET     = rSWReg.Category.WDR.Reg.WDR_YHPF_F1_MCOR_OFFSET; 
        rIP_YHPF_F1_PCOR_OFFSET     = rSWReg.Category.WDR.Reg.WDR_YHPF_F1_PCOR_OFFSET; 
        rIP_RGB_HPF_F0_MCOR_OFFSET  = rSWReg.Category.WDR.Reg.WDR_RGB_F0_MCOR_OFFSET; 
        rIP_RGB_HPF_F0_PCOR_OFFSET  = rSWReg.Category.WDR.Reg.WDR_RGB_F0_PCOR_OFFSET; 
        rIP_RGB_HPF_F1_MCOR_OFFSET  = rSWReg.Category.WDR.Reg.WDR_RGB_F1_MCOR_OFFSET; 
        rIP_RGB_HPF_F1_PCOR_OFFSET  = rSWReg.Category.WDR.Reg.WDR_RGB_F1_PCOR_OFFSET;
    }
}
 
void ncDrv_Sharpness_Set(void)
{
    SharpnessY_Set();
    SharpnessRGB_Set();
    SharpnessHPF_Set();
}


void ncDrv_Sharpness_RGB_Auto(void)
{
	UCHAR AgcX0, AgcX1;

    UCHAR F0_PGAIN_Y1;
    UCHAR F0_MGAIN_Y1;
    UCHAR F0_BRATIO_Y1;
    UCHAR F1_PGAIN_Y1; 
    UCHAR F1_MGAIN_Y1; 
    UCHAR F1_BRATIO_Y1;

    if(sWdr.Mode == STATE_OFF)
    {
        if(rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_MODE == eSHARPNESS_MODE_OFF)   return;
        
        if(ncDrv_TdnStatus_Get() == DN_STATUS_COLOR)
        {
    		AgcX0 = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_AGC_X0;
    		AgcX1 = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_AGC_X1;

            F0_PGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F0_PGAIN_Y1;
            F0_MGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F0_MGAIN_Y1;
            F0_BRATIO_Y1 = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F0_BRATIO_Y1;
            F1_PGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F1_PGAIN_Y1;
            F1_MGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F1_MGAIN_Y1;
            F1_BRATIO_Y1 = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F1_BRATIO_Y1;
        }
        else
        {
    		AgcX0 = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_AGC_X0_BW;
    		AgcX1 = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_AGC_X1_BW;

            F0_PGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F0_PGAIN_Y1_BW;
            F0_MGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F0_MGAIN_Y1_BW;
            F0_BRATIO_Y1 = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F0_BRATIO_Y1_BW;
            F1_PGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F1_PGAIN_Y1_BW;
            F1_MGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F1_MGAIN_Y1_BW;
            F1_BRATIO_Y1 = rSWReg.Category.SHARPNESS.Reg.SHARP_RGB_F1_BRATIO_Y1_BW;
        }
    }
    else
    {
        if(rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_MODE == eSHARPNESS_MODE_OFF)   return;

		AgcX0 = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_AGC_X0;
		AgcX1 = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_AGC_X1;

        F0_PGAIN_Y1  = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_F0_PGAIN_Y1;
        F0_MGAIN_Y1  = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_F0_MGAIN_Y1;
        F0_BRATIO_Y1 = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_F0_BRATIO_Y1;
        F1_PGAIN_Y1  = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_F1_PGAIN_Y1;
        F1_MGAIN_Y1  = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_F1_MGAIN_Y1;
        F1_BRATIO_Y1 = rSWReg.Category.WDR.Reg.WDR_SHARP_RGB_F1_BRATIO_Y1;
    }
    
	rIP_RGB_HPF_F0_PGAIN         = ncDrv_InterpAGC(AgcX0, AgcX1, sSharpRGB.Filter0PGain,  F0_PGAIN_Y1);
	rIP_RGB_HPF_F0_MGAIN         = ncDrv_InterpAGC(AgcX0, AgcX1, sSharpRGB.Filter0MGain,  F0_MGAIN_Y1);
	rIP_RGB_HPF_EDGE_BRATIO_F0   = ncDrv_InterpAGC(AgcX0, AgcX1, sSharpRGB.Filter0Bratio,  F0_BRATIO_Y1);

	rIP_RGB_HPF_F1_PGAIN         = ncDrv_InterpAGC(AgcX0, AgcX1, sSharpRGB.Filter1PGain,  F1_PGAIN_Y1);
	rIP_RGB_HPF_F1_MGAIN         = ncDrv_InterpAGC(AgcX0, AgcX1, sSharpRGB.Filter1MGain,  F1_MGAIN_Y1);
	rIP_RGB_HPF_EDGE_BRATIO_F1   = ncDrv_InterpAGC(AgcX0, AgcX1, sSharpRGB.Filter1Bratio,  F0_BRATIO_Y1);
}


void ncDrv_Sharpness_Y_Auto(void)
{
	UCHAR AgcX0=0, AgcX1=0;

    UCHAR F0_PGAIN_Y1=0;
    UCHAR F0_MGAIN_Y1=0;
    UCHAR F0_BRATIO_Y1=0;
    UCHAR F1_PGAIN_Y1=0; 
    UCHAR F1_MGAIN_Y1=0; 
    UCHAR F1_BRATIO_Y1=0;
    
    if(sWdr.Mode == STATE_OFF)
    {
        if(rSWReg.Category.SHARPNESS.Reg.SHARP_Y_MODE == eSHARPNESS_MODE_OFF)   return;
        
        if(ncDrv_TdnStatus_Get() == DN_STATUS_COLOR)
        {
    		AgcX0 = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_AGC_X0;
    		AgcX1 = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_AGC_X1;

            F0_PGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F0_PGAIN_Y1;
            F0_MGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F0_MGAIN_Y1;
            F0_BRATIO_Y1 = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F0_BRATIO_Y1;
            F1_PGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F1_PGAIN_Y1;
            F1_MGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F1_MGAIN_Y1;
            F1_BRATIO_Y1 = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F1_BRATIO_Y1;
        }
        else
        {
    		AgcX0 = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_AGC_X0_BW;
    		AgcX1 = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_AGC_X1_BW;

            F0_PGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F0_PGAIN_Y1_BW;
            F0_MGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F0_MGAIN_Y1_BW;
            F0_BRATIO_Y1 = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F0_BRATIO_Y1_BW;
            F1_PGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F1_PGAIN_Y1_BW;
            F1_MGAIN_Y1  = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F1_MGAIN_Y1_BW;
            F1_BRATIO_Y1 = rSWReg.Category.SHARPNESS.Reg.SHARP_Y_F1_BRATIO_Y1_BW;
        }
    }
    else
    {
        if(rSWReg.Category.WDR.Reg.WDR_SHARP_Y_MODE == eSHARPNESS_MODE_OFF)   return;
        
		AgcX0 = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_AGC_X0;
		AgcX1 = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_AGC_X1;

        F0_PGAIN_Y1  = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_F0_PGAIN_Y1;
        F0_MGAIN_Y1  = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_F0_MGAIN_Y1;
        F0_BRATIO_Y1 = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_F0_BRATIO_Y1;
        F1_PGAIN_Y1  = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_F1_PGAIN_Y1;
        F1_MGAIN_Y1  = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_F1_MGAIN_Y1;
        F1_BRATIO_Y1 = rSWReg.Category.WDR.Reg.WDR_SHARP_Y_F1_BRATIO_Y1;
    }

    
	rIP_YHPF_F0_PGAIN        = ncDrv_InterpAGC(AgcX0, AgcX1, sSharpY.Filter0PGain,  F0_PGAIN_Y1);
	rIP_YHPF_F0_MGAIN        = ncDrv_InterpAGC(AgcX0, AgcX1, sSharpY.Filter0MGain,  F0_MGAIN_Y1);
	rIP_IBLUR_EDGE_BRATIO_F0 = ncDrv_InterpAGC(AgcX0, AgcX1, sSharpY.Filter0Bratio,  F0_BRATIO_Y1);
	rIP_YHPF_F1_PGAIN        = ncDrv_InterpAGC(AgcX0, AgcX1, sSharpY.Filter1PGain,  F0_PGAIN_Y1);
	rIP_YHPF_F1_MGAIN        = ncDrv_InterpAGC(AgcX0, AgcX1, sSharpY.Filter1MGain,  F1_MGAIN_Y1);
	rIP_IBLUR_EDGE_BRATIO_F1 = ncDrv_InterpAGC(AgcX0, AgcX1, sSharpY.Filter1Bratio,  F1_BRATIO_Y1);
}


// Added by shpark[20140730]
void ncDrv_Sharpness_MainHPF_Auto(void)
{
	UCHAR MainHpfPGain=0, MainHpfMGain=0;
	
	if(rSWReg.Category.SHARPNESS.Reg.MAIN_HPF_PM_MODE)
	{

			MainHpfPGain = ncDrv_InterpAGC(rSWReg.Category.SHARPNESS.Reg.MAIN_HPF_PM_AGC_X0, 	// Start AGC Level
										rSWReg.Category.SHARPNESS.Reg.MAIN_HPF_PM_AGC_X1, 	// End AGC Level 
										rSWReg.Category.SHARPNESS.Reg.MAIN_HPF_PGAIN_Y0, 		// Start CVBS PGAIN Alpha Level
										rSWReg.Category.SHARPNESS.Reg.MAIN_HPF_PGAIN_Y1);		// End CVBS PGAIN Alpha Level

			MainHpfMGain = ncDrv_InterpAGC(rSWReg.Category.SHARPNESS.Reg.MAIN_HPF_PM_AGC_X0, 	// Start AGC Level
						 				rSWReg.Category.SHARPNESS.Reg.MAIN_HPF_PM_AGC_X1, 	// End AGC Level 
										rSWReg.Category.SHARPNESS.Reg.MAIN_HPF_MGAIN_Y0, 		// Start CVBS MGAIN Alpha Level
										rSWReg.Category.SHARPNESS.Reg.MAIN_HPF_MGAIN_Y1);		// End CVBS MGAIN Alpha Level

	}
	else
	{
		MainHpfPGain = rSWReg.Category.SHARPNESS.Reg.MAIN_HPF_PGAIN;
		MainHpfMGain = rSWReg.Category.SHARPNESS.Reg.MAIN_HPF_MGAIN;
	}

	rIP_MAIN_HPF_PGAIN = MainHpfPGain;
	rIP_MAIN_HPF_MGAIN = MainHpfMGain;

	//rIP_MAIN_HPF_EN = rSWReg.Category.SHARPNESS.Reg.MAIN_HPF_PM_MODE;
}

/************************************************************************************************************
* Function.8 AGC�� �����Ͽ� YHPF_F0_COR_Y0/YHPF_F1_COR_Y0�� linear�ϰ� Control�ϱ� ���� Function.
*************************************************************************************************************
* 1. YHPF_COR_AUTO_EN(0xE044)�� On(0x1)�� ��� AGC �� ���Ͽ� YHPF_F0_COR_Y0(0xC8BA), YHPF_F1_COR_Y0(0xC8C9)�� ���� �����.
*	- Start AGC X0 : rSWReg.Byte.Reg_0xE047.B8.YHPF_COR_AUTO_X0
*	- End AGC X1 : rSWReg.Byte.Reg_0xE048.B8.YHPF_COR_AUTO_X1
*	- Start Y HPF F0/1 COR Level Y0 : rSWReg.Byte.Reg_0xE049.B8.YHPF_COR_AUTO_Y0
*	- End Y HPF F0/1 COR Level Y1 : rSWReg.Byte.Reg_0xE04A.B8.YHPF_COR_AUTO_Y1

*	- X��0,1�� AGC "Start" & "End"�� �ǹ�
*	- Y��0,1�� Y HPF F0,1 COR Y0 ��Level.
* 2. YHPF_COR_AUTO_EN(0xE044)�� Off(0x0)�� ��� YHPF_F0_COR_Y0(0xE045), YHPF_F1_COR_Y0(0xE046)�� Fix.
************************************************************************************************************/
void ncDrv_Sharpness_YHPF_Y0_Auto(void)
{
	UCHAR YHpfF01PCorY0=0;
	UCHAR YHpfF01PCorY1=0;
	UCHAR YHpfF01PCorY2=0;
	UCHAR YHpfF01MCorY0=0;
	UCHAR YHpfF01MCorY1=0;
	UCHAR YHpfF01MCorY2=0;

    UCHAR YHPF_PCOR_AGC_X0 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_AGC_X0;
    UCHAR YHPF_PCOR_AGC_X1 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_AGC_X1;
    UCHAR YHPF_MCOR_AGC_X0 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_AGC_X0;
    UCHAR YHPF_MCOR_AGC_X1 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_AGC_X1;

    UCHAR YHPF_PCOR_Y0_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_Y0_Y0;
    UCHAR YHPF_PCOR_Y0_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_Y0_Y1;
    UCHAR YHPF_PCOR_Y1_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_Y1_Y0;  
    UCHAR YHPF_PCOR_Y1_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_Y1_Y1;
    UCHAR YHPF_PCOR_Y2_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_Y2_Y0;  
    UCHAR YHPF_PCOR_Y2_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_Y2_Y1;
    UCHAR YHPF_MCOR_Y0_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_Y0_Y0;
    UCHAR YHPF_MCOR_Y0_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_Y0_Y1;
    UCHAR YHPF_MCOR_Y1_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_Y1_Y0;
    UCHAR YHPF_MCOR_Y1_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_Y1_Y1;
    UCHAR YHPF_MCOR_Y2_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_Y2_Y0;
    UCHAR YHPF_MCOR_Y2_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_Y2_Y1; 

    if(ncDrv_TdnStatus_Get() == DN_STATUS_BW)
    {
        YHPF_PCOR_Y0_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_Y0_Y0_BW;
        YHPF_PCOR_Y0_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_Y0_Y1_BW;
        YHPF_PCOR_Y1_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_Y1_Y0_BW;
        YHPF_PCOR_Y1_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_Y1_Y1_BW;
        YHPF_PCOR_Y2_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_Y2_Y0_BW;
        YHPF_PCOR_Y2_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_PCOR_Y2_Y1_BW;
        YHPF_MCOR_Y0_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_Y0_Y0_BW;
        YHPF_MCOR_Y0_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_Y0_Y1_BW;
        YHPF_MCOR_Y1_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_Y1_Y0_BW;
        YHPF_MCOR_Y1_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_Y1_Y1_BW;
        YHPF_MCOR_Y2_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_Y2_Y0_BW;
        YHPF_MCOR_Y2_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_MCOR_Y2_Y1_BW;
    }
			
	if(rSWReg.Category.SHARPNESS.Reg.YHPF_COR_MODE)// Auto Mode (by AGC) 
	{
		YHpfF01PCorY0= ncDrv_InterpAGC(YHPF_PCOR_AGC_X0, YHPF_PCOR_AGC_X1, YHPF_PCOR_Y0_Y0, YHPF_PCOR_Y0_Y1);
		YHpfF01PCorY1= ncDrv_InterpAGC(YHPF_PCOR_AGC_X0, YHPF_PCOR_AGC_X1, YHPF_PCOR_Y1_Y0, YHPF_PCOR_Y1_Y1);
		YHpfF01PCorY2= ncDrv_InterpAGC(YHPF_PCOR_AGC_X0, YHPF_PCOR_AGC_X1, YHPF_PCOR_Y2_Y0, YHPF_PCOR_Y2_Y1);
		YHpfF01MCorY0= ncDrv_InterpAGC(YHPF_MCOR_AGC_X0, YHPF_MCOR_AGC_X1, YHPF_MCOR_Y0_Y0, YHPF_MCOR_Y0_Y1);
		YHpfF01MCorY1= ncDrv_InterpAGC(YHPF_MCOR_AGC_X0, YHPF_MCOR_AGC_X1, YHPF_MCOR_Y1_Y0, YHPF_MCOR_Y1_Y1);
		YHpfF01MCorY2= ncDrv_InterpAGC(YHPF_MCOR_AGC_X0, YHPF_MCOR_AGC_X1, YHPF_MCOR_Y2_Y0, YHPF_MCOR_Y2_Y1);

		rIP_YHPF_F0_PCOR_Y0 = YHpfF01PCorY0;
		rIP_YHPF_F1_PCOR_Y0 = YHpfF01PCorY0;

		rIP_YHPF_F0_PCOR_Y1 = YHpfF01PCorY1;
		rIP_YHPF_F1_PCOR_Y1 = YHpfF01PCorY1;

		rIP_YHPF_F0_PCOR_Y2 = YHpfF01PCorY2;
		rIP_YHPF_F1_PCOR_Y2 = YHpfF01PCorY2;

		rIP_YHPF_F0_MCOR_Y0 = YHpfF01MCorY0;
		rIP_YHPF_F1_MCOR_Y0 = YHpfF01MCorY0;

		rIP_YHPF_F0_MCOR_Y1 = YHpfF01MCorY1;
		rIP_YHPF_F1_MCOR_Y1 = YHpfF01MCorY1;

		rIP_YHPF_F0_MCOR_Y2 = YHpfF01MCorY2;
		rIP_YHPF_F1_MCOR_Y2 = YHpfF01MCorY2;
		
	}
	else
	{
		rIP_YHPF_F0_PCOR_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_F0_PCOR_Y0;
		rIP_YHPF_F1_PCOR_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_F1_PCOR_Y0;

		rIP_YHPF_F0_PCOR_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_F0_PCOR_Y1;
		rIP_YHPF_F1_PCOR_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_F1_PCOR_Y1;

		rIP_YHPF_F0_PCOR_Y2 = rSWReg.Category.SHARPNESS.Reg.YHPF_F0_PCOR_Y2;
		rIP_YHPF_F1_PCOR_Y2 = rSWReg.Category.SHARPNESS.Reg.YHPF_F1_PCOR_Y2;

		rIP_YHPF_F0_MCOR_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_F0_MCOR_Y0;
		rIP_YHPF_F1_MCOR_Y0 = rSWReg.Category.SHARPNESS.Reg.YHPF_F1_MCOR_Y0;

		rIP_YHPF_F0_MCOR_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_F0_MCOR_Y1;
		rIP_YHPF_F1_MCOR_Y1 = rSWReg.Category.SHARPNESS.Reg.YHPF_F1_MCOR_Y1;

		rIP_YHPF_F0_MCOR_Y2 = rSWReg.Category.SHARPNESS.Reg.YHPF_F0_MCOR_Y2;
		rIP_YHPF_F1_MCOR_Y2 = rSWReg.Category.SHARPNESS.Reg.YHPF_F1_MCOR_Y2;
	}
}

//===========================================================================================================
//      Extern Function Prototype
//===========================================================================================================

void ncDrv_LUMA_IBLUR_INT3_Auto(void)
{
#define IBLUR_INT3_ALPHA_DEFAULT    0x03

	UCHAR IBlurInt3Alpha;

	if(rSWReg.Category.LUMA.Reg.IBLUR_INT3_AGC_EN)
	{
		IBlurInt3Alpha = ncDrv_InterpAGC(rSWReg.Category.LUMA.Reg.IBLUR_INT3_AGC_X0, 	// Start AGC Level
										 rSWReg.Category.LUMA.Reg.IBLUR_INT3_AGC_X1, 	// End AGC Level 
										 rSWReg.Category.LUMA.Reg.IBLUR_INT3_Y0,		// Start CSC IBLUR INT3 Alpha Level
										 rSWReg.Category.LUMA.Reg.IBLUR_INT3_Y1);		// End CSC IBLUR INT3 Alpha Level		
	}
	else
	{
		IBlurInt3Alpha = IBLUR_INT3_ALPHA_DEFAULT;
	}

	rIP_IBLUR_INT3 = IBlurInt3Alpha;
}

void ncDrv_LUMA_Y_Offset_Auto(void)
{
#define Y_OFFSET2_ALPHA_DEFAULT 0x00

	USHORT YOffset2_Ctrl;

	if(rSWReg.Category.LUMA.Reg.Y_OFFSET2_AGC_EN)
	{
		YOffset2_Ctrl = ncDrv_InterpAGC(rSWReg.Category.LUMA.Reg.Y_OFFSET2_AGC_X0,
										rSWReg.Category.LUMA.Reg.Y_OFFSET2_AGC_X1,
										rSWReg.Category.LUMA.Reg.Y_OFFSET2_Y0,
										rSWReg.Category.LUMA.Reg.Y_OFFSET2_Y1);
 	}
	else
	{
    	YOffset2_Ctrl = Y_OFFSET2_ALPHA_DEFAULT;
	}

    ISPSET16(aIP_Y_OFFSET2_7_0, YOffset2_Ctrl);
}

/************************************************************************************************************
* Function.7 AGC�� �����Ͽ� FNR2D_EN�� On/Off Control�ϱ� ���� Function.
*************************************************************************************************************
* 1. FNR2D_MODE(0xE04B)�� On(0x1)�� ��� AGC �� ���Ͽ� FNR2D_EN(0xC7F1)�� ���� �����.
*	- AGC < FNR2D_AUTO_AGC(0xE04C)�̸� FNR2D_EN(0xC7F1)�� Off.
*	- AGC >= FNR2D_AUTO_AGC(0xE04C)�̸� FNR2D_EN(0xC7F1)�� On. 

* 2. FNR2D_MODE(0xE04B)�� Off(0x0)�� ��� FNR2D_EN(0xC7F1)�� ����  FNR2D_MANUAL(0xE04B)�� Fix.
************************************************************************************************************/
void ncDrv_NR_FNR2D_Auto(void)
{
	if(rSWReg.Category.NR.Reg.FNR2D_MODE == eMODE_AUTO) /* [2014/2/26] JWLee : Auto Mode (by AGC)  */
	{
		if(ISPGET08(aIP_AGC_LEVEL_7_0) < rSWReg.Category.NR.Reg.FNR2D_AUTO_AGC)
			rIP_FNR2D_EN = STATE_OFF;
		else
			rIP_FNR2D_EN = STATE_ON;
	}
	else
	{
		rIP_FNR2D_EN = rSWReg.Category.NR.Reg.FNR2D_MODE;
	}
}


void ncDrv_NR_CI_FLAT_Auto(void)
{
	if(ISPGET08(aIP_AGC_LEVEL_7_0)> rSWReg.Category.NR.Reg.CI_FLAT_MIX_AGC_ON_LEVEL)
	    rIP_CI_FLAT_MIX_MODE = rSWReg.Category.NR.Reg.CI_FLAT_MIX_AGC_ON;
    else if(ISPGET08(aIP_AGC_LEVEL_7_0) < rSWReg.Category.NR.Reg.CI_FLAT_MIX_AGC_OFF_LEVEL)
		rIP_CI_FLAT_MIX_MODE = rSWReg.Category.NR.Reg.CI_FLAT_MIX_AGC_OFF;
}

