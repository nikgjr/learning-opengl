#if(SENSOR_SELECT == SONY_IMX224MQR)

    /* 1. SENSOR COMMON INTERFACE */
    #define SENSOR_INTERFACE                INPUT_LVDS
    #define SENSOR_SLAVE                    NO
    #define SENSOR_MAX_FPS                  FPS_MAX_60P
    #define SENSOR_MAX_SIZE                 SIZE_MAX_720
    #define SENSOR_ICLK                     SENSOR_ICLK_37p125M
    #define SENSOR_COMM_TYPE                SENSOR_COMM_SPI
    #define SENSOR_ACP_ID                   0x0104

    /* 2. SENSOR_COMM_TYPE = SENSOR_COMM_I2C */
    #define I2C_DEVICE_ID                   NOT_USE
    #define I2C_ADDRESS_SIZE                NOT_USE
    #define I2C_DATA_SIZE                   NOT_USE

    /* 3. SENSOR_COMM_TYPE = SENSOR_COMM_SPI */
    #define SPI_WIRE_COUNT                  SPI_WIRE_4LANE
	#define SPI_ADDRESS_BANK_EN             YES
    #define SPI_ADDRESS_SIZE                SIZE_1_BYTE
    #define SPI_DATA_SIZE                   SIZE_1_BYTE
    #define SPI_MS_MODE                     SPI_MODE_MASTER 
    #define SPI_COMM_DIRECTION              COMM_LSB_FIRST

    /* 4. SENSOR MISCELLANEOUSE OPTIONS */
    #define OPTION_LDC_EN                   NO
    #define OPTION_WDR_TYPE                 WDRTYPE_DOL3

#endif

