
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __DEFOG_DRV__
#define __DEFOG_DRV__

#define DEFOGBLOCK_SIZE	0x08	// 8 x 8
/********************************************************************************
* Function Name 	: MW_Defog_Auto()
* Description		: Defog Auto controller 
* Refer to		: API Document
* Argument		:	
										 
* Return			: 
					@ [TRUE]		: Success
					@ [Error Code]	: Fail (API Reference Guide)
********************************************************************************/
extern void ncDrv_Defog_Auto(void);

/********************************************************************************
* Function Name 	: MW_Defog_Set()
* Description		: Defog Register Set
* Refer to		: API Document
* Argument		:	
										 
* Return			: 
					@ [TRUE]		: Success
					@ [Error Code]	: Fail (API Reference Guide)
********************************************************************************/
extern void ncDrv_Defog_Set(void);
extern void ncDrv_Defog_ReSize(void);
extern void ncDrv_Defog_Mirror(void);
extern void ncDrv_Defog_Flip(void);

#endif

