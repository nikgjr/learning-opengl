
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __MW_OSD__
#define __MW_OSD__

/*****************************************************
	[OSD String Font Information]
*****************************************************/ 
#define		LANGUAGE_NUMBER		16
#define		MAXCHAR_NUM		12

#define		TITLEMENU_NUM		12
#define		MAINMENU_NUM		12
#define		SUBMENU_NUM		9

#define		TOTAL				LANGUAGE_NUMBER*MAXCHAR_NUM

/*****************************************************
	[OSD Char FONT Address Index Number]																																																			
*****************************************************/ 
#define		C_0					01
#define		C_1					02
#define		C_2					03
#define		C_3					04
#define		C_4					05
#define		C_5					06
#define		C_6					07
#define		C_7					08
#define		C_8					09
#define		C_9					10

#define		C_A					11
#define		C_B					12
#define		C_C					13
#define		C_D					14
#define		C_E					15
#define		C_F					16
#define		C_G					17
#define		C_H					18
#define		C_I					19
#define		C_J					20
#define		C_K					21
#define		C_L					22
#define		C_M					23
#define		C_N					24
#define		C_O					25
#define		C_P					26
#define		C_Q					27
#define		C_R					28
#define		C_S					29
#define		C_T					30
#define		C_U					31
#define		C_V					32
#define		C_W				33
#define		C_X					34
#define		C_Y					35
#define		C_Z					36

#define		C_DOT				54
#define		C_ENTER			55
#define		C_MENUSELECT		37
#define		C_BAR				45


//============================================================================
//      Global Variable
//============================================================================
typedef struct
{
	UCHAR	NumX;							// The Grid Number
	UCHAR	NumY;

	UCHAR	CenterPosX;
	UCHAR	CenterPosY;
	UCHAR	StringFont[MAXCHAR_NUM];
	
	UCHAR	MenuTitlePosX;
	UCHAR	MenuTitlePosY;
	UCHAR	MenuMainSubPosX;
	UCHAR	MenuMainSubPosY;

	USHORT	LogoStartIndexNum;
	//USHORT	ICONStartIndexNum;
	ULONG	FlashSize;
	ULONG	DDRSize;
	ULONG	HGride;
	ULONG	VGride;
}STRUCT_MW_OSD;

typedef struct{	
	UCHAR PosX;
	UCHAR PosY;
	UCHAR Style;
	UCHAR Color;
	UCHAR Data;
	UCHAR Limit;
	UCHAR Sign;
	UCHAR StringNum;
	UCHAR StringType;
	
	USHORT FontIndex;
}STRUCT_MW_MENU;

typedef struct{	
    UCHAR WriteCount;
	UCHAR PosY;
	UCHAR PosX;
	UCHAR Style;
	UCHAR Color;
    UCHAR * CharList;
}STRUCT_MW_OSDSET;

extern	STRUCT_MW_OSD		sMwOsd;
extern	STRUCT_MW_MENU 		sMwMenu;

//============================================================================
//      Function Prototype
//============================================================================
/********************************************************************************
* Function Name 	: ncDrv_OSDClear_Set()
* Description		: OSD Clear
* Refer to		: API Document
* Argument		: void
* Return			: void
********************************************************************************/
void ncDrv_OSDClear_Set(void);

/********************************************************************************
* Function Name 	: ncDrv_OSDChar_Set()
* Description		: Character OSD Write
* Refer to		: API Document
* Argument		: void
* Return			: void
********************************************************************************/
void ncDrv_OSDChar_Set(void);

/********************************************************************************
* Function Name 	: ncDrv_OSDString_Set()
* Description		: String OSD Write
* Refer to		: API Document
* Argument		: void	
* Return			: void
********************************************************************************/
void ncDrv_OSDString_Set(void);


/********************************************************************************
* Function Name 	: ncDrv_OSDOptionChange_Set()
* Description		: Command Change
* Refer to		: API Document
* Argument		:
					@ Style_E	: [Style Change Enable or Disable]
					@ Color_E	: [Color Change Enable or Disable]
					@ Index_E	: [Index Change Enable or Disable]
					@ S_vpos	: [Start V Position]
					@ S_hpos	: [Start H Position]
					@ E_vpos	: [End V Position]
					@ E_hpos	: [End H Position]
					@ Style		: [Change to "Style" Vaue]
					@ Color		: [Change to "Color" Vaue]
					@ Index		: [Change to "Index" Vaue]
					
* Return			: void
********************************************************************************/
void ncDrv_OSDOptionChange_Set(	BOOL Style_E, 
											BOOL Color_E, 
											BOOL Font_E, 
											UCHAR S_vpos, 
											UCHAR S_hpos, 
											UCHAR E_vpos, 
											UCHAR E_hpos, 
											UCHAR Style, 
											UCHAR Color, 
											INT32 Font);

/********************************************************************************
* Function Name 	: ncDrv_OSDBin_Get()
* Description		: OSD INIT(sFlash Read OSD Font)
* Refer to		: API Document
* Argument		:
					@ Mode		: [All Load(Font, Logo, ICON) or Only Font Load]
										 
* Return			: The return value does not exist.
********************************************************************************/
void ncDrv_OSDBin_Get(void);

/********************************************************************************
* Function Name 	: ncDrv_BoxDisplay_Set()
* Description		: Color Box Display Control
* Refer to		: API Document
* Argument		:
					@ Box		: [Box Number "0" or "1"]
					@ Mode		: [Disable / Enable "0" or "1"]
										 
* Return			: The return value does not exist.
********************************************************************************/
#define BOXn_ENABLE	0x10
#define BOXn_DISABLE	0x00

#define BOX0_ENABLE	0x01
#define BOX1_ENABLE	0x10
#define BOXALL_ENABLE	(BOX0_ENABLE | BOX1_ENABLE)
#define BOXALL_DISABLE	0x00

#define STRING_TYPE_NORMAL	0x00
#define STRING_TYPE_TITLE		0x01
			
void ncDrv_BoxDisplay_Set(UCHAR Mode);

/********************************************************************************
* Function Name 	: ncDrv_OSDFont_Set()
* Description		: OSD Set(OSD)
* Refer to		: API Document
* Argument		:
										 
* Return			: The return value does not exist.
********************************************************************************/
void ncDrv_OSDFont_Set(void);

void ncDrv_OSD_MenuPosition_Set(void);

/********************************************************************************
* Function Name 	: MW_OSDICON_Set()
* Description		: OSD Set(ICON)
* Refer to		: API Document
* Argument		:
										 
* Return			: The return value does not exist.
********************************************************************************/
void APP_OSDPrint_Dec(UCHAR PosY, UCHAR PosX, USHORT WriteData);
void APP_OSDPrint_Hex(UCHAR PosY, UCHAR PosX, UCHAR WriteData);
void APP_OSDPrint_Hex2(UCHAR PosY, UCHAR PosX, USHORT WriteData);
void APP_OSDPrint_String(UCHAR PosY, UCHAR PosX, UCHAR* String);
void ncDrv_OSDPath_Set(void);
void NICP_OSDPrint_Set(STRUCT_MW_OSDSET *OsdSet);

void ncDrv_Osd_PosSetX(UCHAR PosX);
void ncDrv_Osd_PosSetY(UCHAR PosY);
void ncDrv_Osd_SetStr(UCHAR* String);
void ncDrv_Osd_SetDec(UCHAR WriteData);
void ncDrv_Osd_SetHex(UCHAR WriteData);






#endif

