/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#if 1
#define DPGL_BASE_ADDR           APACHE_DPGL
#define DPGL_ENABLE_ADDR         (DPGL_BASE_ADDR + 0x00000500)
#define DPGL_ENABLE              (1 << 0) // [0]
#define DPGL_VS_POL              (1 << 4) // [1]
#define DPGL_HA_POL              (1 << 8) // [2]
#define DPGL_HS_POL              (1 << 12) // [2]
#define DPGL_ST_POS              (1 << 16) // [4]
#define DPGL_AUTO_PRE_RUN        (1 << 20) // [5]
#define DPGL_OUTLINE_ON          (1 << 24) // [6]
#define DPGL_V_AUTO_UP           (1 << 31) // [31]
#define DPGL_V_MANU_UP           (1 << 30) // [30]
#define DPGL_MANUAL_UP           (1 << 29) // [29]
#define DPGL_XY_OFFSET_ADDR      (DPGL_BASE_ADDR + 0x00000504)
#define DPGL_X_OFFSET            (1 << 0) //[11:0]
#define DPGL_Y_OFFSET            (1 << 16) //[27:16]
#define DPGL_IMG_SIZE_ADDR       (DPGL_BASE_ADDR + 0x00000508)
#define DPGL_IMG_HEIGHT          (720 << 0) //[10:0]
#define DPGL_IMG_WIDTH           (1288 << 11) //[21:11]
#define DPGL_LPF_COEFF012_ADDR   (DPGL_BASE_ADDR + 0x0000050C)
#define DPGL_LPF_COEFF0          (0x10 << 18) // 9bit
#define DPGL_LPF_COEFF1          (0x20 << 9)// 9bit
#define DPGL_LPF_COEFF2          (0x10 << 0)// 9bit
#define DPGL_LPF_COEFF345_ADDR   (DPGL_BASE_ADDR + 0x00000510)
#define DPGL_LPF_COEFF3          (0x20 << 18)// 9bit
#define DPGL_LPF_COEFF4          (0x40 << 9)// 9bit
#define DPGL_LPF_COEFF5          (0x20 << 0)// 9bit
#define DPGL_LPF_COEFF678_ADDR   (DPGL_BASE_ADDR + 0x00000514)
#define DPGL_LPF_COEFF6          (0x10 << 18)// 9bit
#define DPGL_LPF_COEFF7          (0x20 << 9)// 9bit
#define DPGL_LPF_COEFF8          (0x10 << 0)// 9bit
#define DPGL_SYNC_INFORM_ADDR    (DPGL_BASE_ADDR + 0x00000518)
#define DPGL_PRE_RUN_CNT         (1 << 0)// [11:0]
#define DPGL_OUTLINE_RGB         (1 << 0)// [23:0]
#else
#define DPGL_BASE_ADDR           APACHE_DPGL
#define DPGL_ENABLE_ADDR         (DPGL_BASE_ADDR + 0x00000500)
#define DPGL_ENABLE              (1 << 0) // [0]
#define DPGL_VS_POL              (1 << 1) // [1]
#define DPGL_HA_POL              (1 << 2) // [2]
#define DPGL_HS_POL              (1 << 3) // [2]
#define DPGL_ST_POS              (1 << 4) // [4]
#define DPGL_AUTO_PRE_RUN        (1 << 5) // [5]
#define DPGL_OUTLINE_ON          (1 << 6) // [6]
#define DPGL_V_AUTO_UP           (1 << 31) // [31]
#define DPGL_V_MANU_UP           (1 << 30) // [30]
#define DPGL_MANUAL_UP           (1 << 29) // [29]
#define DPGL_XY_OFFSET_ADDR      (DPGL_BASE_ADDR + 0x00000504)
#define DPGL_X_OFFSET            (1 << 0) //[11:0]
#define DPGL_Y_OFFSET            (1 << 16) //[27:16]
#define DPGL_IMG_SIZE_ADDR       (DPGL_BASE_ADDR + 0x00000508)
#define DPGL_IMG_HEIGHT          (720 << 0) //[10:0]
#define DPGL_IMG_WIDTH           (1288 << 11) //[21:11]
#define DPGL_LPF_COEFF012_ADDR   (DPGL_BASE_ADDR + 0x0000050C)
#define DPGL_LPF_COEFF0          (0x10 << 18) // 9bit
#define DPGL_LPF_COEFF1          (0x20 << 9)// 9bit
#define DPGL_LPF_COEFF2          (0x10 << 0)// 9bit
#define DPGL_LPF_COEFF345_ADDR   (DPGL_BASE_ADDR + 0x00000510)
#define DPGL_LPF_COEFF3          (0x20 << 18)// 9bit
#define DPGL_LPF_COEFF4          (0x40 << 9)// 9bit
#define DPGL_LPF_COEFF5          (0x20 << 0)// 9bit
#define DPGL_LPF_COEFF678_ADDR   (DPGL_BASE_ADDR + 0x00000514)
#define DPGL_LPF_COEFF6          (0x10 << 18)// 9bit
#define DPGL_LPF_COEFF7          (0x20 << 9)// 9bit
#define DPGL_LPF_COEFF8          (0x10 << 0)// 9bit
#define DPGL_SYNC_INFORM_ADDR    (DPGL_BASE_ADDR + 0x00000518)
#define DPGL_PRE_RUN_CNT         (1 << 0)// [11:0]
#define DPGL_OUTLINE_RGB         (1 << 0)// [23:0]

#endif



#define DPGL_PAGE_CNT			91
#define DPGL_PAGE_CNT_MAX   	160
#define DPGL_POINT_PAGE_SIZE   (DPGL_PAGE_CNT_MAX*4)


#define DPGL_BASE_ADDR_RGAD   (DPGL_BASE_ADDR + DPGL_POINT_PAGE_SIZE)






typedef struct{	
	CHAR Enable;
	CHAR Enable_Grad;
	CHAR angel;
}STRUCT_DPGL;

STRUCT_DPGL sDpgl;

void ncDrv_DPGL_SyncUpdate(void)
{
	UINT32 i, j;

   
	UINT32 data;

	 for(i = 0; i < 20; i++)
    {
        for(j = 0; j < 10000; j++);
    }

	 
	data =  DPGL_V_AUTO_UP | DPGL_HA_POL | DPGL_HS_POL | DPGL_AUTO_PRE_RUN | DPGL_ENABLE |DPGL_OUTLINE_RGB | DPGL_ST_POS;
	REGRW32(DPGL_BASE_ADDR, 0x0500) = data;  // PGL_EN 
}


void ncDrv_DPGL_Initialize(void)
{
	sDpgl.Enable =0;
	sDpgl.angel  =0;
	sDpgl.Enable_Grad=0;
	ncDrv_DPGL_Enable(sDpgl.Enable);
	ncDrv_DPGL_Set_Grad_Enable(sDpgl.Enable_Grad);

	ncDrv_DDRMemory_Address_Set();
	
}

void ncDrv_DPGL_Enable(UCHAR enable)
{
	UINT32 data;

	if(enable==0)
	{
		sDpgl.Enable=0;
		sDpgl.Enable_Grad=0;
	}
	else if(enable==1)
	{
		sDpgl.Enable=1;
		sDpgl.Enable_Grad=0;
	}
	else if(enable==2)
	{
		sDpgl.Enable=1;
		sDpgl.Enable_Grad=1;
	}
	
	
//	DEBUGMSG(MSGINFO, "ncDrv_DPGL_Enable %x \n",enable);
	
	if(sDpgl.Enable)
	{
		data = DPGL_IMG_HEIGHT | DPGL_IMG_WIDTH;
		REGRW32(DPGL_BASE_ADDR, 0x0508) = data;   // img size default 1288x720  DPGL_IMG_SIZE_ADDR

		data = DPGL_LPF_COEFF0 | DPGL_LPF_COEFF1 | DPGL_LPF_COEFF2 ;
		REGRW32(DPGL_BASE_ADDR, 0x050C ) = data; //DPGL_LPF_COEFF012_ADDR,data);   // LPF COEFF 

		data = DPGL_LPF_COEFF3 | DPGL_LPF_COEFF4 | DPGL_LPF_COEFF5 ;
		REGRW32(DPGL_BASE_ADDR, 0x0510)= data; //reg_write(DPGL_LPF_COEFF345_ADDR,data);   // LPF COEFF 

		data = DPGL_LPF_COEFF6 | DPGL_LPF_COEFF7 | DPGL_LPF_COEFF8 ;
		REGRW32(DPGL_BASE_ADDR, 0x0514)= data; // reg_write(DPGL_LPF_COEFF678_ADDR,data);   // LPF COEFF 

		//   data = 0<<24;
		//   REGRW32(DPGL_BASE_ADDR, 0x051C)= data; // reg_write(DPGL_LPF_COEFF678_ADDR,data);   // LPF COEFF 

		data =  DPGL_V_AUTO_UP | DPGL_HA_POL | DPGL_HS_POL | DPGL_AUTO_PRE_RUN | DPGL_ENABLE |DPGL_OUTLINE_RGB | DPGL_ST_POS;
		REGRW32(DPGL_BASE_ADDR, 0x0500) = data;  // PGL_EN 
	}
	else
	{
		data = 0xFFFFFFFE&   (DPGL_V_AUTO_UP | DPGL_HA_POL | DPGL_HS_POL | DPGL_AUTO_PRE_RUN |DPGL_OUTLINE_RGB | DPGL_ST_POS);
		REGRW32(DPGL_BASE_ADDR, 0x0500) = data;  // PGL_EN 
	}

	ncDrv_DPGL_Set_Angel(sDpgl.angel);
	ncDrv_DPGL_Set_Grad_Enable(sDpgl.Enable_Grad);
}

void ncDrv_DPGL_Set_Angel(UCHAR Angel)
{
	
	UINT8  SfPage[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
	
	UINT32 SfAddr = FLASHMEMORY_DPGL_AREA_ADDRESS + (Angel * DPGL_POINT_PAGE_SIZE); 

	
	
	sDpgl.angel=Angel;
	
	ncLib_SF_Control(GCMD_SF_READ_PAGE, SfAddr, &SfPage[0], CMD_END);
	memcpy( (void*)(DPGL_BASE_ADDR),  &SfPage[0],	 SF_PAGE_SIZE );//0x100
	SfAddr += SF_PAGE_SIZE; 


	ncLib_SF_Control(GCMD_SF_READ_PAGE, SfAddr, &SfPage[0], CMD_END);
	memcpy( (void*)(DPGL_BASE_ADDR+(SF_PAGE_SIZE*1)),  &SfPage[0],	 SF_PAGE_SIZE );//0x100
	SfAddr += SF_PAGE_SIZE; 

	

	ncLib_SF_Control(GCMD_SF_READ_PAGE, SfAddr, &SfPage[0], CMD_END);
	memcpy( (void*)(DPGL_BASE_ADDR+(SF_PAGE_SIZE*2)),  &SfPage[0],	 0x80 );//0x80

	//DEBUGMSG(MSGINFO, "ncDrv_DPGL_Set_Angel %d \n",Angel);


	//ncDrv_DPGL_SyncUpdate();

	if(sDpgl.Enable_Grad)
		ncDrv_DPGL_Set_Grad_Enable(sDpgl.Enable_Grad);
	
	
	
}

void ncDrv_DPGL_Set_Grad_Enable(UCHAR enable)
{
	UINT32 i;
	UINT32 offset= 0x0000;
	UINT8  SfPage[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
	
	UINT32 SfAddr = FLASHMEMORY_DPGL_AREA_ADDRESS + ((91+sDpgl.angel) * DPGL_POINT_PAGE_SIZE);    
	
	sDpgl.Enable_Grad=enable;

	if(sDpgl.Enable_Grad)
	{
		sDpgl.Enable_Grad=1;
		ncLib_SF_Control(GCMD_SF_READ_PAGE, SfAddr, &SfPage[0], CMD_END);
		memcpy( (void*)(DPGL_BASE_ADDR_RGAD),  &SfPage[0],	 SF_PAGE_SIZE );//0x100
		SfAddr += SF_PAGE_SIZE; 
			

		ncLib_SF_Control(GCMD_SF_READ_PAGE, SfAddr, &SfPage[0], CMD_END);
		memcpy( (void*)(DPGL_BASE_ADDR_RGAD+(SF_PAGE_SIZE*1)),  &SfPage[0],	 SF_PAGE_SIZE );//0x100
		SfAddr += SF_PAGE_SIZE; 

		ncLib_SF_Control(GCMD_SF_READ_PAGE, SfAddr, &SfPage[0], CMD_END);
		memcpy( (void*)(DPGL_BASE_ADDR_RGAD+(SF_PAGE_SIZE*2)),  &SfPage[0],	 0x80 );//0x80

	}
	else
	{
		for(i=0; i<DPGL_PAGE_CNT_MAX; i++ )
		{
			REGRW32(DPGL_BASE_ADDR_RGAD, offset) = 0xFF;  
			offset += 4;
		}
	}
	//ncDrv_DPGL_SyncUpdate();

	//DEBUGMSG(MSGINFO, "ncDrv_DPGL_Set_Grad_Enable %x \n",sDpgl.Enable_Grad);
	
}






