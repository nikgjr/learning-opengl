
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Api_GlobalHeader.h"

void ncDrv_PGL_Initialize(void)
{
#if 0
REGRW8(APACHE_ISP_BASE, 0x0D00) = 0x11;
REGRW8(APACHE_ISP_BASE, 0x0D01) = 0x94;
REGRW8(APACHE_ISP_BASE, 0x0D02) = 0x01;
REGRW8(APACHE_ISP_BASE, 0x0D03) = 0xA1;
REGRW8(APACHE_ISP_BASE, 0x0D04) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D05) = 0x51;
REGRW8(APACHE_ISP_BASE, 0x0D06) = 0x03;
REGRW8(APACHE_ISP_BASE, 0x0D07) = 0x15;
REGRW8(APACHE_ISP_BASE, 0x0D08) = 0x04;
REGRW8(APACHE_ISP_BASE, 0x0D09) = 0xE3;
REGRW8(APACHE_ISP_BASE, 0x0D0A) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D0B) = 0x94;
REGRW8(APACHE_ISP_BASE, 0x0D0C) = 0x02;
REGRW8(APACHE_ISP_BASE, 0x0D0D) = 0x7A;
REGRW8(APACHE_ISP_BASE, 0x0D0E) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D0F) = 0x91;
REGRW8(APACHE_ISP_BASE, 0x0D10) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D11) = 0xEC;
REGRW8(APACHE_ISP_BASE, 0x0D12) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D17) = 0x0B;
REGRW8(APACHE_ISP_BASE, 0x0D18) = 0x11;
REGRW8(APACHE_ISP_BASE, 0x0D19) = 0x12;
REGRW8(APACHE_ISP_BASE, 0x0D1A) = 0x1A;
REGRW8(APACHE_ISP_BASE, 0x0D1B) = 0x46;
REGRW8(APACHE_ISP_BASE, 0x0D1C) = 0x46;
REGRW8(APACHE_ISP_BASE, 0x0D1D) = 0x46;
REGRW8(APACHE_ISP_BASE, 0x0D1E) = 0x47;
REGRW8(APACHE_ISP_BASE, 0x0D1F) = 0x04;
REGRW8(APACHE_ISP_BASE, 0x0D20) = 0x05;
REGRW8(APACHE_ISP_BASE, 0x0D21) = 0x08;
REGRW8(APACHE_ISP_BASE, 0x0D22) = 0x05;
REGRW8(APACHE_ISP_BASE, 0x0D23) = 0x80;
REGRW8(APACHE_ISP_BASE, 0x0D24) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D25) = 0xC0;
REGRW8(APACHE_ISP_BASE, 0x0D26) = 0x03;
REGRW8(APACHE_ISP_BASE, 0x0D27) = 0xD8;
REGRW8(APACHE_ISP_BASE, 0x0D28) = 0x01;
REGRW8(APACHE_ISP_BASE, 0x0D29) = 0xB4;
REGRW8(APACHE_ISP_BASE, 0x0D2A) = 0x02;
REGRW8(APACHE_ISP_BASE, 0x0D2B) = 0xA8;
REGRW8(APACHE_ISP_BASE, 0x0D2C) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D2D) = 0x68;
REGRW8(APACHE_ISP_BASE, 0x0D2E) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D2F) = 0x6C;
REGRW8(APACHE_ISP_BASE, 0x0D30) = 0x03;
REGRW8(APACHE_ISP_BASE, 0x0D31) = 0x40;
REGRW8(APACHE_ISP_BASE, 0x0D32) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D33) = 0x28;
REGRW8(APACHE_ISP_BASE, 0x0D34) = 0x02;
REGRW8(APACHE_ISP_BASE, 0x0D35) = 0xFD;
REGRW8(APACHE_ISP_BASE, 0x0D36) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D37) = 0x98;
REGRW8(APACHE_ISP_BASE, 0x0D38) = 0x01;
REGRW8(APACHE_ISP_BASE, 0x0D39) = 0xC0;
REGRW8(APACHE_ISP_BASE, 0x0D3A) = 0x03;
REGRW8(APACHE_ISP_BASE, 0x0D3B) = 0x80;
REGRW8(APACHE_ISP_BASE, 0x0D3C) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D3D) = 0xC0;
REGRW8(APACHE_ISP_BASE, 0x0D3E) = 0x03;
REGRW8(APACHE_ISP_BASE, 0x0D3F) = 0xD8;
REGRW8(APACHE_ISP_BASE, 0x0D40) = 0x01;
REGRW8(APACHE_ISP_BASE, 0x0D41) = 0xB4;
REGRW8(APACHE_ISP_BASE, 0x0D42) = 0x02;
REGRW8(APACHE_ISP_BASE, 0x0D43) = 0xA8;
REGRW8(APACHE_ISP_BASE, 0x0D44) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D45) = 0x68;
REGRW8(APACHE_ISP_BASE, 0x0D46) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D47) = 0x6C;
REGRW8(APACHE_ISP_BASE, 0x0D48) = 0x03;
REGRW8(APACHE_ISP_BASE, 0x0D49) = 0x40;
REGRW8(APACHE_ISP_BASE, 0x0D4A) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D4B) = 0x28;
REGRW8(APACHE_ISP_BASE, 0x0D4C) = 0x02;
REGRW8(APACHE_ISP_BASE, 0x0D4D) = 0xFD;
REGRW8(APACHE_ISP_BASE, 0x0D4E) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D4F) = 0x98;
REGRW8(APACHE_ISP_BASE, 0x0D50) = 0x01;
REGRW8(APACHE_ISP_BASE, 0x0D51) = 0xC0;
REGRW8(APACHE_ISP_BASE, 0x0D52) = 0x03;
REGRW8(APACHE_ISP_BASE, 0x0D53) = 0x80;
REGRW8(APACHE_ISP_BASE, 0x0D54) = 0x80;
REGRW8(APACHE_ISP_BASE, 0x0D55) = 0x80;
REGRW8(APACHE_ISP_BASE, 0x0D56) = 0x80;
REGRW8(APACHE_ISP_BASE, 0x0D57) = 0x80;
REGRW8(APACHE_ISP_BASE, 0x0D58) = 0x80;
REGRW8(APACHE_ISP_BASE, 0x0D59) = 0x80;
REGRW8(APACHE_ISP_BASE, 0x0D5A) = 0x80;
REGRW8(APACHE_ISP_BASE, 0x0D5B) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D5C) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D5D) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D5E) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D5F) = 0x3A;
REGRW8(APACHE_ISP_BASE, 0x0D60) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D61) = 0x3A;
REGRW8(APACHE_ISP_BASE, 0x0D62) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D63) = 0x39;
REGRW8(APACHE_ISP_BASE, 0x0D64) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D65) = 0x38;
REGRW8(APACHE_ISP_BASE, 0x0D66) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D67) = 0x0C;
REGRW8(APACHE_ISP_BASE, 0x0D68) = 0x08;
REGRW8(APACHE_ISP_BASE, 0x0D69) = 0x0B;
REGRW8(APACHE_ISP_BASE, 0x0D6A) = 0x09;
REGRW8(APACHE_ISP_BASE, 0x0D6B) = 0x07;
REGRW8(APACHE_ISP_BASE, 0x0D6C) = 0x03;
REGRW8(APACHE_ISP_BASE, 0x0D6D) = 0xAF;
REGRW8(APACHE_ISP_BASE, 0x0D6E) = 0x01;
REGRW8(APACHE_ISP_BASE, 0x0D6F) = 0xEA;
REGRW8(APACHE_ISP_BASE, 0x0D70) = 0x00;
REGRW8(APACHE_ISP_BASE, 0x0D71) = 0x6B;
REGRW8(APACHE_ISP_BASE, 0x0D72) = 0x03;
REGRW8(APACHE_ISP_BASE, 0x0D73) = 0x5E;
REGRW8(APACHE_ISP_BASE, 0x0D74) = 0x04;

#endif
	rIP_PGL_EN =  0;

}

void ncDrv_PGL_Onoff(UCHAR OnOff)
{
	static UCHAR old=0xff;

	if(old==OnOff)
		return;
	old = OnOff;

	rIP_PGL_EN =  OnOff;
}

void ncDrv_PGL_HLTOP(UCHAR UpDown)
{
	USHORT val = ISPGET16(aIP_PGL_HL_TOP_7_0);
	if(UpDown==PGL_UP)
		val++;
	else
		val--;
	ISPSET16(aIP_PGL_HL_TOP_7_0, val) ;
}
void ncDrv_PGL_HLBTM(UCHAR UpDown)
{
	USHORT val = ISPGET16(aIP_PGL_HL_BTM_7_0);
	if(UpDown==PGL_UP)
		val++;
	else
		val--;
    ISPSET16(aIP_PGL_HL_BTM_7_0, val);
}
void ncDrv_PGL_HRTOP(UCHAR UpDown)
{
	USHORT val = ISPGET16(aIP_PGL_HR_TOP_7_0);
	if(UpDown==PGL_UP)
		val++;
	else
		val--;
    ISPSET16(aIP_PGL_HR_TOP_7_0, val);
}
void ncDrv_PGL_HRBTM(UCHAR UpDown)
{
	USHORT val = ISPGET16(aIP_PGL_HR_BTM_7_0);
	if(UpDown==PGL_UP)
		val++;
	else
		val--;
    ISPSET16(aIP_PGL_HR_BTM_7_0, val);
}

void ncDrv_PGL_VTOP(UCHAR UpDown)
{
	USHORT val = ISPGET16(aIP_PGL_V_TOP_7_0);
	if(UpDown==PGL_UP)
		val++;
	else
		val--;
    ISPSET16(aIP_PGL_V_TOP_7_0, val);
}
void ncDrv_PGL_VBTM(UCHAR UpDown)
{
	USHORT val = ISPGET16(aIP_PGL_V_BTM_7_0);
	if(UpDown==PGL_UP)
		val++;
	else
		val--;
    ISPSET16(aIP_PGL_V_BTM_7_0, val);
}


void ncDrv_PGL_ColorV1(UCHAR UpDown)
{
	static USHORT val;
	USHORT	Y,CB,CR;
	if(UpDown==PGL_UP)
	{
		if(val>0x3F)
			val = 0;
		else
			val++;
	}
	else
	{
		if(val)
			val--;
		else
			val = 0x3F;
	}
	Y  = (val&0x03)<<8;
	CB = (val&0x0C)<<6;
	CR = (val&0x30)<<4;
	ISPSET16(aIP_PGL_AR1_Y_7_0, Y);
	ISPSET16(aIP_PGL_AR1_CB_7_0, CB);
	ISPSET16(aIP_PGL_AR1_CR_7_0, CR);
}
void ncDrv_PGL_ColorV2(UCHAR UpDown)
{
	static USHORT val;
	USHORT	Y,CB,CR;
	if(UpDown==PGL_UP)
	{
		if(val>0x3F)
			val = 0;
		else
			val++;
	}
	else
	{
		if(val)
			val--;
		else
			val = 0x3F;
	}
	Y  = (val&0x03)<<8;
	CB = (val&0x0C)<<6;
	CR = (val&0x30)<<4;
	ISPSET16(aIP_PGL_AR2_Y_7_0, Y);
	ISPSET16(aIP_PGL_AR2_CB_7_0, CB);
	ISPSET16(aIP_PGL_AR2_CR_7_0, CR);
}
void ncDrv_PGL_ColorV3(UCHAR UpDown)
{
	static USHORT val;
	USHORT	Y,CB,CR;
	if(UpDown==PGL_UP)
	{
		if(val>0x3F)
			val = 0;
		else
			val++;
	}
	else
	{
		if(val)
			val--;
		else
			val = 0x3F;
	}
	Y  = (val&0x03)<<8;
	CB = (val&0x0C)<<6;
	CR = (val&0x30)<<4;
	ISPSET16(aIP_PGL_AR3_Y_7_0, Y);
	ISPSET16(aIP_PGL_AR3_CB_7_0, CB);
	ISPSET16(aIP_PGL_AR3_CR_7_0, CR);
}
void ncDrv_PGL_ColorV4(UCHAR UpDown)
{
	static USHORT val;
	USHORT	Y,CB,CR;
	if(UpDown==PGL_UP)
	{
		if(val>0x3F)
			val = 0;
		else
			val++;
	}
	else
	{
		if(val)
			val--;
		else
			val = 0x3F;
	}
	Y  = (val&0x03)<<8;
	CB = (val&0x0C)<<6;
	CR = (val&0x30)<<4;
	ISPSET16(aIP_PGL_AR4_Y_7_0, Y);
	ISPSET16(aIP_PGL_AR4_CB_7_0, CB);
	ISPSET16(aIP_PGL_AR4_CR_7_0, CR);
}


void ncDrv_PGL_AlphaV1(UCHAR UpDown)
{
	UCHAR val = ISPGET08(aIP_PGL_AR1_BGR);
	if(UpDown==PGL_UP)
	{
		if(val>=0x80)
			val = 0;
		else
			val +=0x08;
	}
	else
	{
		if(val==0x0)
			val = 0x80;
		else if(val>0x08)
			val -=0x08;
		else
			val = 0x00;
	}
	
	ISPSET08(aIP_PGL_AR1_BGR, val);
}

void ncDrv_PGL_AlphaV2(UCHAR UpDown)
{
	UCHAR val = ISPGET08(aIP_PGL_AR2_BGR);
	if(UpDown==PGL_UP)
	{
		if(val>=0x80)
			val = 0;
		else
			val +=0x08;
	}
	else
	{
		if(val==0x0)
			val = 0x80;
		else if(val>0x08)
			val -=0x08;
		else
			val = 0x00;
	}

	ISPSET08(aIP_PGL_AR2_BGR, val);
}

void ncDrv_PGL_AlphaV3(UCHAR UpDown)
{
	UCHAR val = ISPGET08(aIP_PGL_AR3_BGR);
	if(UpDown==PGL_UP)
	{
		if(val>=0x80)
			val = 0;
		else
			val +=0x08;
	}
	else
	{
		if(val==0x0)
			val = 0x80;
		else if(val>0x08)
			val -=0x08;
		else
			val = 0x00;
	}

	ISPSET08(aIP_PGL_AR3_BGR, val);
}

void ncDrv_PGL_AlphaV4(UCHAR UpDown)
{
	UCHAR val = ISPGET08(aIP_PGL_AR4_BGR);
	if(UpDown==PGL_UP)
	{
		if(val>=0x80)
			val = 0;
		else
			val +=0x08;
	}
	else
	{
		if(val==0x0)
			val = 0x80;
		else if(val>0x08)
			val -=0x08;
		else
			val = 0x00;
	}
	
	ISPSET08(aIP_PGL_AR4_BGR, val);
}


void ncDrv_ValCheck(USHORT	Address)
{	
#if 1
	if( IsInRage(APACHE_ISP_BASE|Address, (UINT32)aIP_PGL_HL_TOP_7_0, (UINT32)aIP_PGL_HL_TOP_10_8) && (ISPGET16(aIP_PGL_HL_TOP_7_0) >= ISPGET16(aIP_PGL_HL_TOP_2_7_0)) )
	{
		ISPSET16(aIP_PGL_HL_TOP_2_7_0,ISPGET16(aIP_PGL_HL_TOP_7_0)+4);
	}
	else if( IsInRage(APACHE_ISP_BASE|Address, (UINT32)aIP_PGL_HL_TOP_2_7_0, (UINT32)aIP_PGL_HL_TOP_2_10_8) && (ISPGET16(aIP_PGL_HL_TOP_7_0) >= ISPGET16(aIP_PGL_HL_TOP_2_7_0)) )
	{
		ISPSET16(aIP_PGL_HL_TOP_7_0,ISPGET16(aIP_PGL_HL_TOP_2_7_0)-4);
	}
	
	else if( IsInRage(APACHE_ISP_BASE|Address, (UINT32)aIP_PGL_HL_BTM_7_0, (UINT32)aIP_PGL_HL_BTM_10_8) && (ISPGET16(aIP_PGL_HL_BTM_7_0) >= ISPGET16(aIP_PGL_HL_BTM_2_7_0)) )
	{
		ISPSET16(aIP_PGL_HL_BTM_2_7_0,ISPGET16(aIP_PGL_HL_BTM_7_0)+4);
	}
	else if( IsInRage(APACHE_ISP_BASE|Address, (UINT32)aIP_PGL_HL_BTM_2_7_0, (UINT32)aIP_PGL_HL_BTM_2_10_8) && (ISPGET16(aIP_PGL_HL_BTM_7_0) >= ISPGET16(aIP_PGL_HL_BTM_2_7_0)) )
	{
		ISPSET16(aIP_PGL_HL_BTM_7_0,ISPGET16(aIP_PGL_HL_BTM_2_7_0)-4);
	}
	
	else if( IsInRage(APACHE_ISP_BASE|Address, (UINT32)aIP_PGL_HR_TOP_7_0, (UINT32)aIP_PGL_HR_TOP_10_8) && (ISPGET16(aIP_PGL_HR_TOP_7_0) >= ISPGET16(aIP_PGL_HR_TOP_2_7_0)) )
	{
		ISPSET16(aIP_PGL_HR_TOP_2_7_0,ISPGET16(aIP_PGL_HR_TOP_7_0)+4);
	}
	else if( IsInRage(APACHE_ISP_BASE|Address, (UINT32)aIP_PGL_HR_TOP_2_7_0, (UINT32)aIP_PGL_HR_TOP_2_10_8) && (ISPGET16(aIP_PGL_HR_TOP_7_0) >= ISPGET16(aIP_PGL_HR_TOP_2_7_0)) )
	{
		ISPSET16(aIP_PGL_HR_TOP_7_0,ISPGET16(aIP_PGL_HR_TOP_2_7_0)-4);
	}
	
	else if( IsInRage(APACHE_ISP_BASE|Address, (UINT32)aIP_PGL_HR_BTM_7_0, (UINT32)aIP_PGL_HR_BTM_10_8) && (ISPGET16(aIP_PGL_HR_BTM_7_0) >= ISPGET16(aIP_PGL_HR_BTM_2_7_0)) )
	{
		ISPSET16(aIP_PGL_HR_BTM_2_7_0,ISPGET16(aIP_PGL_HR_BTM_7_0)+4);
	}
	else if( IsInRage(APACHE_ISP_BASE|Address, (UINT32)aIP_PGL_HR_BTM_2_7_0, (UINT32)aIP_PGL_HR_BTM_2_10_8) && (ISPGET16(aIP_PGL_HR_BTM_7_0) >= ISPGET16(aIP_PGL_HR_BTM_2_7_0)) )
	{
		ISPSET16(aIP_PGL_HR_BTM_7_0,ISPGET16(aIP_PGL_HR_BTM_2_7_0)-4);
	}


#if 1
	if( IsInRage(APACHE_ISP_BASE|Address, (UINT32)aIP_PGL_HR_BTM_7_0, (UINT32)aIP_PGL_HR_BTM_10_8) 
		&& ( ISPGET16(aIP_PGL_HR_BTM_7_0) >0x500-4 ) )
	{
		ISPSET16(aIP_PGL_HR_BTM_7_0, 0x500-4);
	}
	else if( IsInRage(APACHE_ISP_BASE|Address, (UINT32)aIP_PGL_HR_BTM_2_7_0, (UINT32)aIP_PGL_HR_BTM_2_10_8) 
		&& ( ISPGET16(aIP_PGL_HR_BTM_2_7_0) >0x500 ) )
	{
		ISPSET16(aIP_PGL_HR_BTM_2_7_0, 0x500);
	}

	else if( IsInRage(APACHE_ISP_BASE|Address, (UINT32)aIP_PGL_HR_TOP_7_0, (UINT32)aIP_PGL_HR_TOP_10_8) 
		&& (ISPGET16(aIP_PGL_HR_TOP_7_0) >= 0x500-4) )
	{
		ISPSET16(aIP_PGL_HR_TOP_7_0,0x500-4);
	}
	else if( IsInRage(APACHE_ISP_BASE|Address, (UINT32)aIP_PGL_HR_TOP_2_7_0, (UINT32)aIP_PGL_HR_TOP_10_8) 
		&& (ISPGET16(aIP_PGL_HR_TOP_2_7_0) >= 0x500) )
	{
		ISPSET16(aIP_PGL_HR_TOP_2_7_0,0x500);
	}
#endif
#endif
}

