
/********************************************************************************
*   Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*   Enviroment    : IAR Embedded Workbench IDE
*   Project       : APC28_EGT3 
********************************************************************************
*   History      : 
        CreationDate    Modify      Ver     Description
        -------------------------------------------------------
        2010.08.13      kysim       0.2     Initial  Revision
        2014.12.02      JWLee       1.0     Newly Generated     
        2015.04.01      jhchoi      1.1     NCFW Platform Revision
********************************************************************************/
#include "APACHE35.h"
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Api_GlobalHeader.h"

STRUCT_MW_OSD	sMwOsd;
STRUCT_MW_MENU 	sMwMenu;


//#define   __MW_OSD_DEBUG__    // for debuging


#define     OSD_STYLE_MAX               16
#define     OSD_COLOR_MAX               8
#define     OSD_BOX_MAX                 4
#define     OSD_ATTR_TRANS_MAX          8
#define     OSD_ATTR_BLK_MAX            4
#define     OSD_ATTR_COLOR_MAX          16
#define     OSD_GVRINDEX_MAX            1023
#define     OSD_CLR_WAITIME             100
#define     OSD_CHG_WAITIME             200

#define     OSDBMPBIT                   2
#define     OSDBMPBIT_SHIFT             1   // 2^1 = OSDBMPBIT
#define     PAGECHARNUM                 64  // 2^6 = PAGECHARNUM, [Shift 6]
#define     PAGECHARNUM_SHIFT           6

#define     FONTPAGENUM                 4
#define     LOGOPAGENUM                 1
#define     ICONPAGENUM                 3

#define     STYLE_TRANSENABLE           0x80
#define     STYLE_TRANSDISABLE          0x00
#define     STYLE_BLINKENABLE           0x40
#define     STYLE_BLINKDISABLE          0x00
#define     STYLE_TRANSVALUE_INDEX0     0x00
#define     STYLE_TRANSVALUE_INDEX1     0x08
#define     STYLE_TRANSVALUE_INDEX2     0x10
#define     STYLE_TRANSVALUE_INDEX3     0x18
#define     STYLE_TRANSVALUE_INDEX4     0x20
#define     STYLE_TRANSVALUE_INDEX5     0x28
#define     STYLE_TRANSVALUE_INDEX6     0x30
#define     STYLE_TRANSVALUE_INDEX7     0x38
#define     STYLE_BLINKTIMER_INDES0     0x00
#define     STYLE_BLINKTIMER_INDES1     0x02
#define     STYLE_BLINKTIMER_INDES2     0x04
#define     STYLE_BLINKTIMER_INDES3     0x06
#define     STYLE_BGENABLE              0x01
#define     STYLE_BGDISABLE             0x00

#define     TRANS_FONTENABLE            0x80
#define     TRANS_FONTDISABLE           0x00
#define     TRANS_BGENABLE              0x80
#define     TRANS_BGDISABLE             0x00

#define	SFLASH_FONTDEFAULT_ADDR			0x091000
#define	SFLASH_FONT32_ADDR				0x095000
#define	SFLASH_FONT48_ADDR				0x0C1000

//============================================================================
//      Extern Function Prototype
//============================================================================

//============================================================================
//      Function Prototype
//============================================================================

//============================================================================
//      Function
//============================================================================
void OSD_RomFont_Load(void)
{
	#define LANGUAGE_START_AREA ADDR_LANGUAGE

	UCHAR RomSelArea = ISPGET08((LANGUAGE_START_AREA + (rSWReg.Category.OSD.Reg.LANGUAGE << 1)) & 0x0F);

    /* [2014/2/24] hyundong : RomFont Language Select    */
	rBank1D->Byte.Reg_0x1D00.B8.OSD_EN = 1;
    rBank1D->Byte.Reg_0x1DCF.B8.O_OSD_ROM_EN = 1;


   rBank1D->Byte.Reg_0x1D01.B8.OSD_GRD_VSTART_7_0 = 0x10;
   rBank1D->Byte.Reg_0x1D03.B8.OSD_GRD_HSTART_7_0 = 0x10;

   rBank1D->Byte.Reg_0x1D05.B8.OSD_GRD_VNUM = 0x18;
   rBank1D->Byte.Reg_0x1D06.B8.OSD_GRD_HNUM = 0x30;

	sMwOsd.NumX = rIP_OSD_GRD_HNUM + 1;// X Grid Number
	sMwOsd.NumY = rIP_OSD_GRD_VNUM + 1;// Y Grid Number
		
   rBank1D->Byte.Reg_0x1D07.B8.OSD_GRD_VSIZE = 0x1A;
   rBank1D->Byte.Reg_0x1D08.B8.OSD_GRD_HSIZE = 0x18;

   rBank1D->Byte.Reg_0x1D6F.B8.O_OSD_COLOR0_7_0 = 0xFF;
   rBank1D->Byte.Reg_0x1D70.B8.O_OSD_COLOR0_15_8 = 0xFF;

	 rBank1D->Byte.Reg_0x1D33.B8.O_OSD_ATTR_COLOR2_7_0  = 0xFF;
	rBank1D->Byte.Reg_0x1D34.B8.O_OSD_ATTR_COLOR2_15_8 = 0x0F;
	
    rBank1D->Byte.Reg_0x1D8D.B8.O_OSD_COLOR15_7_0  = 0x10;
	rBank1D->Byte.Reg_0x1D8E.B8.O_OSD_COLOR15_15_8 = 0x01;


		
     if(RomSelArea == 1)
    {
        /* [2014/2/26] hyundong :  English & China Simplified*/
        rIP_O_OSD_ROM_SEL_FONT = 0;
        //rIP_O_OSD_ROM_CHINESE_TRADITIONAL = 0;
    }
    else if(RomSelArea == 2)
    {
        /* [2014/2/26] hyundong :    English & China Traditional */
        rIP_O_OSD_ROM_SEL_FONT = 0;
        //rIP_O_OSD_ROM_CHINESE_TRADITIONAL = 1;   
    }
    else
    {
        /* [2014/2/26] hyundong : English & European*/
        rIP_O_OSD_ROM_SEL_FONT = 1;
    }


     /* [2014/10/15] hyundong : Rom Font is 24x24 Pixel(Fixed) */
    sMwOsd.HGride   = 24;   
    sMwOsd.VGride   = 24;
        

    //{/* [2014/10/21] shpark : 1-1 */
    //rBank1D.Byte.Reg_0xDD00.B8.OSD_OUTLINE_EN = 1;    
}


void OSD_RamFont_Load(void)
{
    #define LANGUAGE_START_AREA ADDR_LANGUAGE

    UCHAR   Area1=0;
    UCHAR   Area2=0;
    UCHAR   LoanCnt =0;
    UCHAR   division = 0;
    UCHAR   AreaIndex=0;
    UCHAR   tFLASH_rdata[64];
    ULONG   tFlashAdd = 0;
    ULONG   tFLASH_fsize= 0;
    ULONG   DDRAddr = sGco.DDRADDOSD;
    ULONG   FlashAddresBase;
    UINT32 SfAddr;
	UINT8* RamAddr;
	UINT8  SfPage[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
	UINT32 i;
	
//    if(rSWReg.Category.OSD.Reg.ROM_FONT_EN)       return;

    if(rSWReg.Category.OSD.Reg.OSD_PATH)
    {   
         /* [2014/7/16] hyundong : OSD CVBS Path */
        sMwOsd.HGride   = 32;
        sMwOsd.VGride   = 32;
        FlashAddresBase = SFLASH_FONT32_ADDR;
		
		rBank1D->Byte.Reg_0x1D07.B8.OSD_GRD_VSIZE = 31;
		rBank1D->Byte.Reg_0x1D08.B8.OSD_GRD_HSIZE = 45;

		rBank1D->Byte.Reg_0x1D05.B8.OSD_GRD_VNUM = 0x15;
		rBank1D->Byte.Reg_0x1D06.B8.OSD_GRD_HNUM = 0x1A;
    }
    else
    {
         /* [2014/7/16] hyundong : OSD Digital Path */
        sMwOsd.HGride   = 48;   
        sMwOsd.VGride   = 48;
        FlashAddresBase = SFLASH_FONT48_ADDR;
		rBank1D->Byte.Reg_0x1D07.B8.OSD_GRD_VSIZE = 47;
		rBank1D->Byte.Reg_0x1D08.B8.OSD_GRD_HSIZE = 47;
		
		rBank1D->Byte.Reg_0x1D05.B8.OSD_GRD_VNUM = 0xD;
		rBank1D->Byte.Reg_0x1D06.B8.OSD_GRD_HNUM = 0x19;
    }
    
    sMwOsd.FlashSize    = (((sMwOsd.HGride * sMwOsd.VGride) << OSDBMPBIT_SHIFT) >> 3) << PAGECHARNUM_SHIFT;
    sMwOsd.DDRSize  = (((sMwOsd.VGride << OSDBMPBIT_SHIFT)<<5) >> 3) << PAGECHARNUM_SHIFT;

	ncDrv_DDRMemory_Address_Set();

	RamAddr = (UINT8*)(ISPGET32(aIP_O_OSD_BUS_BASEADDR_7_0));
	for(i = 0; i < FLASHMEMORY_OSD_FONF_AREA_SIZE; i += SF_PAGE_SIZE)
	{
		ncLib_SF_Control(SCMD_SF_LUT_READ_DATA, (FLASHMEMORY_OSD_FONF_AREA_ADDRESS+i), (RamAddr+i), SF_PAGE_SIZE, CMD_END); //0xD4000
	}

	rBank1D->Byte.Reg_0x1DCF.B8.O_OSD_BUS_ENABLE = 1;
	rBank1D->Byte.Reg_0x1DCF.B8.O_OSD_BUS_DATA_MSB = 0;

	rBank1D->Byte.Reg_0x1DD0.B8.O_OSD_BUS_BASEADDR_7_0   = 0x00;
	rBank1D->Byte.Reg_0x1DD1.B8.O_OSD_BUS_BASEADDR_15_8  = 0x00;
	rBank1D->Byte.Reg_0x1DD2.B8.O_OSD_BUS_BASEADDR_23_16 = 0x60;
	rBank1D->Byte.Reg_0x1DD3.B8.O_OSD_BUS_BASEADDR_31_24 = 0x08;
	

	rBank1D->Byte.Reg_0x1DD8.B8.O_OSD_ROM_BASE_INDEX_7_0 = 0x00;
	rBank1D->Byte.Reg_0x1DD9.B8.O_OSD_ROM_BASE_INDEX_9_8 = 0x02;

	rBank1D->Byte.Reg_0x1D00.B8.OSD_GRD_INDEXZERO_EN = 0x01;
	
    
}

void OSD_DefaultFont_Load(void)
{
#if 0
    UCHAR   i;
    UCHAR   division = 0;
    UCHAR   tFLASH_rdata[64];
    ULONG   DDRAddr;
    ULONG   DDRSize;

    ULONG   FlashAddr;
    ULONG   FlashSize;
    ULONG   FlashOffset;
    UCHAR   FontSize;
    UCHAR   FontAddChar = 20;
    
    if((sGco.MonitorOutput == eMONITOR_CVBS)&&(sGco.OutputSize.Active.SizeH == 720))
    {
        //if(sGco.OutputSize.Active.SizeH == 720)
        //{
            FontSize = 24;
        //}
        //else
        //{
        //  FontSize = 32;
        //}
    }
    else
    {
        FontSize = 32;
    }

    //DDRSize = ((32 * FontSize * OSDBMPBIT) / 8)*PAGECHARNUM;
    DDRSize = (((FontSize << OSDBMPBIT_SHIFT) << 5) >> 3) << PAGECHARNUM_SHIFT;
    
    DDRAddr = sGco.DDRADDOSD + (DDRSize * FONTPAGENUM);
        
    //FlashSize = ((FontSize * FontSize * OSDBMPBIT) / 8) * FontAddChar;
    //FlashOffset = (32*32*OSDBMPBIT/8) * FontAddChar;
    FlashSize = (((FontSize * FontSize) << OSDBMPBIT_SHIFT) >> 3) * FontAddChar;
    FlashOffset = ((OSDBMPBIT << 10) >> 3) * FontAddChar;
    
    if(FontSize == 32)      FlashAddr = SFLASH_FONTDEFAULT_ADDR;
    else                FlashAddr = SFLASH_FONTDEFAULT_ADDR + FlashOffset;    
    
#if 0
    HAL_SPI_Open(SPI1_1, &sExtComm.SPI.Flash);

    HAL_SPI1WaitBusyBit;
    HAL_SPI1CS_Set(LOW);
    HAL_SPI1WaitBusyBit;

    HAL_SPI1_Set(SPI_READ);
    HAL_SPI1_Set((FlashAddr >> 16) & 0xFF);
    HAL_SPI1_Set((FlashAddr>>8) & 0xFF);
    HAL_SPI1_Set((FlashAddr) & 0xFF);
#endif

    if(FontSize <= 32)          division = 8;

    FlashSize = ((FlashSize + 63)>> 6) << 6;    //((fsize + 63) / 64) * 64;
    
    while(FlashSize != 0)
    {
        // read 64Byte data from flash memory
        for(i=0; i < 64; i++)
        {
//            if((i&(division-1)) <((FontSize<<1)>>3))      tFLASH_rdata[i] = HAL_SPI1_Get();
//            else                                    tFLASH_rdata[i] = 0x00;
        }
        
        // write 64Byte data to DDR memory
        ncDrv_DDRMemory_Set(DDRAddr, tFLASH_rdata);
        DDRAddr += 64;
        
        FlashSize -= FontSize<< 1;
    }

#if 0
    rSPI1CK  = SPI_1BYTE | SPI_CKSEL_1100;  
    HAL_SPI1CS_Set(HIGH);
    //toto 2012.09.24_3
//  HAL_SPI_Close(SPI1);
    HAL_SPI_Close(SPI1_1);
#endif
#endif
    
}

USHORT OSD_RomFont_Change_Task(USHORT FontIndex)
{
   
    return  FontIndex;
}

void ncDrv_OSD_MenuPosition_Set(void)
{
#if 0
    UCHAR HGride,VGride;
    
    USHORT  BoxPosXStart;
    USHORT  BoxPosXEnd;

    USHORT  BoxPosYStart;
    USHORT  BoxPosYEnd;
    
    UCHAR   BoxMarginX;
    UCHAR   BoxMarginY;
    
    UCHAR   BoxSizeX = 3+MAINMENU_NUM + SUBMENU_NUM + rSWReg.Category.OSD.Reg.MENU_MAIN_SUB_INTERVAL -1;  /* [2014/3/15] hyundong :  OSD Menu H Max Size  */ 
    UCHAR   BoxSizeY = 1;

    HGride = sMwOsd.HGride-rSWReg.Category.OSD.Reg.MENU_OSD_GRD_HSIZE;/* [2015/02/13] SJH : [STD]-01 */
    VGride = sMwOsd.VGride;

    rIP_OSD_GRD_HSIZE = HGride-1;  //H Size 
    rIP_OSD_GRD_VSIZE = VGride-1;  //V Size

    rIP_OSD_GRD_HSTART_7_0 = 0;
    rIP_OSD_GRD_HSTART_10_8 = 0;
    rIP_OSD_GRD_VSTART_7_0 = 0;
    rIP_OSD_GRD_VSTART_10_8 = 0;

    if(sGco.MonitorOutput == eMONITOR_CVBS)
    {
     /* [2014/10/15] hyundong : OSD Menu Position Set in CVBS Path */
        switch(sGco.OutputSize.Active.SizeH)
        {
            case 960:
                //32(H)x32(V) Pixel
                rIP_OSD_GRD_VSIZEx2 = 0;
                rIP_OSD_GRD_HSIZEx2 = 0;
                rIP_OSD_GRD_VNUM = sGco.OutputSize.Active.SizeV/VGride - 1;  
                rIP_OSD_GRD_HNUM = sGco.OutputSize.Active.SizeH/HGride - 1;
                
                sMwOsd.MenuTitlePosX = rSWReg.Category.OSD.Reg.MENU_CVBS_960H_POSX;           
                sMwOsd.MenuTitlePosY = rSWReg.Category.OSD.Reg.MENU_CVBS_960H_POSY;
            break;
            
            case 1200:
                //32(H)x32(V) Pixel
                rIP_OSD_GRD_VSIZEx2 = 0;
                rIP_OSD_GRD_HSIZEx2 = 0;
                rIP_OSD_GRD_VNUM = sGco.OutputSize.Active.SizeV/VGride - 1;  
                rIP_OSD_GRD_HNUM = sGco.OutputSize.Active.SizeH/HGride - 1;
                
                sMwOsd.MenuTitlePosX = rSWReg.Category.OSD.Reg.MENU_CVBS_1280H_NTSC_POSX;     
                sMwOsd.MenuTitlePosY = rSWReg.Category.OSD.Reg.MENU_CVBS_1280H_NTSC_POSY;
            break;
            
            case 1280:
                //32(H)x32(V) Pixel
                rIP_OSD_GRD_VSIZEx2 = 0;
                rIP_OSD_GRD_HSIZEx2 = 0;
                rIP_OSD_GRD_VNUM = sGco.OutputSize.Active.SizeV/VGride - 1;  
                rIP_OSD_GRD_HNUM = sGco.OutputSize.Active.SizeH/HGride - 1;
                
                sMwOsd.MenuTitlePosX = rSWReg.Category.OSD.Reg.MENU_CVBS_1280H_PAL_POSX;  
                sMwOsd.MenuTitlePosY = rSWReg.Category.OSD.Reg.MENU_CVBS_1280H_PAL_POSY;
            break;
        }
    }
    else
    {
        sMwOsd.MenuTitlePosX = rSWReg.Category.OSD.Reg.MENU_DIGITAL_POS_X; 
        sMwOsd.MenuTitlePosY = rSWReg.Category.OSD.Reg.MENU_DIGITAL_POS_Y;
    
        rIP_OSD_GRD_HSIZEx2 = 0;
        rIP_OSD_GRD_VSIZEx2 = 0;      // Font Size HSize x VSize, UpScale Hx2, V2x2 => Real FontSize = HSize*2 x VSize*2 
        rIP_OSD_GRD_HNUM = sGco.OutputSize.Active.SizeH/(HGride) - 1;
        rIP_OSD_GRD_VNUM = sGco.OutputSize.Active.SizeV/(VGride) - 1;
    }

    sMwOsd.CenterPosX = rIP_OSD_GRD_HNUM >> 1;
    sMwOsd.CenterPosY = rIP_OSD_GRD_VNUM >> 1;

    sMwOsd.NumX = rIP_OSD_GRD_HNUM + 1;// X Grid Number
    sMwOsd.NumY = rIP_OSD_GRD_VNUM + 1;// Y Grid Number

    /* [2014/3/15] hyundong : MainMenu Position, SubMenu Position Data Set   */
    sMwOsd.MenuMainSubPosX = sMwOsd.MenuTitlePosX;
    sMwOsd.MenuMainSubPosY = sMwOsd.MenuTitlePosY + 2;

    
    /* [2014/3/14] hyundong : OSD Title Boxes Position  Auto Set    */
    /* [2014/3/15] hyundong : OSD Box1 Set (Inside Box)    */
    if(sMwOsd.MenuTitlePosX == 0)       BoxMarginX = 0;
    else                                BoxMarginX = 10;

    if(sMwOsd.MenuTitlePosY == 0)       BoxMarginY = 0;
    else                                BoxMarginY = 10;
    
    BoxPosXStart = sMwOsd.MenuTitlePosX*HGride - BoxMarginX;
    BoxPosYStart = sMwOsd.MenuTitlePosY*HGride - BoxMarginY;

    BoxPosXEnd = (sMwOsd.MenuTitlePosX+ BoxSizeX)*HGride + BoxMarginX;
    BoxPosYEnd = (sMwOsd.MenuTitlePosY+ BoxSizeY)*HGride + BoxMarginY;
    
    rIP_O_OSD_BOX1_SX_10_8 = (BoxPosXStart>>8);
    rIP_O_OSD_BOX1_SX_7_0 = (BoxPosXStart&0xFF);
    rIP_O_OSD_BOX1_SY_10_8 = (BoxPosYStart>>8);
    rIP_O_OSD_BOX1_SY_7_0 = (BoxPosYStart&0xFF);
    rIP_O_OSD_BOX1_EX_10_8 = (BoxPosXEnd>>8);
    rIP_O_OSD_BOX1_EX_7_0 = (BoxPosXEnd&0xFF);
    rIP_O_OSD_BOX1_EY_10_8 = (BoxPosYEnd>>8);
    rIP_O_OSD_BOX1_EY_7_0 = (BoxPosYEnd&0xFF);

    /* [2014/3/15] hyundong : OSD Box0 Set (Outside Box)    */
    if(sMwOsd.MenuTitlePosX == 0)       BoxMarginX = 0;
    else                                BoxMarginX = 20;

    if(sMwOsd.MenuTitlePosY == 0)       BoxMarginY = 0;
    else                                BoxMarginY = 20;        

    BoxPosXStart = sMwOsd.MenuTitlePosX*HGride - BoxMarginX;
    BoxPosYStart = sMwOsd.MenuTitlePosY*HGride - BoxMarginY;

    BoxPosXEnd = (sMwOsd.MenuTitlePosX+ BoxSizeX)*HGride + BoxMarginX;
    BoxPosYEnd = (sMwOsd.MenuTitlePosY+ BoxSizeY)*HGride + BoxMarginY;
    
    rIP_O_OSD_BOX0_SX_10_8 = (BoxPosXStart>>8);
    rIP_O_OSD_BOX0_SX_7_0= (BoxPosXStart&0xFF);
    rIP_O_OSD_BOX0_SY_10_8 = (BoxPosYStart>>8);
    rIP_O_OSD_BOX0_SY_7_0 = (BoxPosYStart&0xFF);
    
    rIP_O_OSD_BOX0_EX_10_8 = (BoxPosXEnd>>8);
    rIP_O_OSD_BOX0_EX_7_0 = (BoxPosXEnd&0xFF);
    rIP_O_OSD_BOX0_EY_10_8 = (BoxPosYEnd>>8);
    rIP_O_OSD_BOX0_EY_7_0 = (BoxPosYEnd&0xFF);
#endif

}

void ncDrv_OSDPath_Set(void)
{
#if 0
/* [2015/2/27] JWLee */ 
//      if(rSWReg.Category.MONITOR.Reg.MONITOR_OUTPUT == 0)       rSWReg.Category.OSD.Reg.OSD_PATH = 1; //CVBS Path
//      else                                                    rSWReg.Category.OSD.Reg.OSD_PATH = 0; //Digital Path

    if(sGco.MonitorOutput == eMONITOR_CVBS)
    {
        rSWReg.Category.OSD.Reg.OSD_PATH = 1;
        //rIP_SEL_OSD_CK = 1;
        rIP_OSD_GRD_INTERLACE = 1;
    }
    else      /* DIGITAL PATH */
    {
        if((etFRAME_SIZE)OUTPUT_SIZE == eSIZE_1280_720)
            rSWReg.Category.OSD.Reg.OSD_PATH = 1;
        else
            rSWReg.Category.OSD.Reg.OSD_PATH = 0;
                
        //rIP_SEL_OSD_CK = 0;
        rIP_OSD_GRD_INTERLACE = 0;
    }

    if(CVBS_FORMAT == eCVBS_NTSC)   rIP_OSD_GRD_FSWAP = 1;   
    else                            rIP_OSD_GRD_FSWAP = 0;   
        
    rIP_OSD_GRD_PREVSYNC_OFFSET_16 = 0x00;
    rIP_OSD_GRD_PREVSYNC_OFFSET_15_8 = 0x00;
    rIP_OSD_GRD_PREVSYNC_OFFSET_7_0 = 0x00;

    
#endif
}

void ncDrv_OSDClear_Set(void)
{
//    rXSFR_BANK = 0x0D;

    rIP_O_OSD_SVADDR = 0;                    // Start V 
    rIP_O_OSD_SHADDR = 0;                    // Start H
    rIP_O_OSD_EVADDR = rIP_OSD_GRD_VNUM;      // End V
    rIP_O_OSD_EHADDR = rIP_OSD_GRD_HNUM;      // End H
    rIP_O_OSD_CLR_EN = 1;

#if 0
    while(1)
    {
        if(rBank1D.Byte.Reg_0xDD92.B8.O_OSD_CLR_EN == 0x00)         break;
    }
#endif

}


void ncDrv_OSDChar_Set(void)
{
	
    INT32 font_pos;
    UCHAR PosX = sMwMenu.PosX;
    UCHAR PosY = sMwMenu.PosY;
    USHORT FontIndex = sMwMenu.FontIndex;
    UCHAR Style = sMwMenu.Style;
    UCHAR Color = sMwMenu.Color;
    UCHAR Temp = 0;
    
#ifdef  __MW_OSD_DEBUG__
    UCHAR rdata;
    UCHAR wdata;
#endif

        font_pos  = PosY * sMwOsd.NumX + PosX;

 /* [2014/3/20] hyundong : Rom Font modify.    */
    if(rIP_O_OSD_ROM_EN)         FontIndex = OSD_RomFont_Change_Task(FontIndex);

	if(rSWReg.Category.OSD.Reg.ROM_FONT_EN==1)
	{
		FontIndex = 0x0200+FontIndex;
	}
	
//    rXSFR_BANK      = 0x00;
    rIP_RESERVED_0000  = 0x00;                                                                         // isp async mode
    rIP_IND_XSFR_BANK  = (0x80 | (0x07 & (font_pos >> 7)));                                            // bank set
        
    rIP_IND_XSFR_ADDR  = ((0xff & (font_pos << 1)) | 0x01);                                            // address set  (MSB)
    Temp = ((Style & 0x07) << 5) | ((Color & 0x07) << 2) | ((FontIndex >> 8) & 0x03);                       // wdata        (MSB)
    rIP_IND_XSFR_RWDATA_ISP  = Temp;
    rIP_IND_XSFR_RWDATA_ISP  = Temp;
    rIP_IND_XSFR_RWDATA_ISP  = Temp;

    rIP_IND_XSFR_ADDR  = (0xff & (font_pos << 1));                                                         // address set  (LSB)     
    rIP_IND_XSFR_RWDATA_ISP  = FontIndex & 0xFF;                                                                 // wdata        (LSB)
    rIP_IND_XSFR_RWDATA_ISP  = FontIndex & 0xFF;                                                                 // wdata        (LSB)
    rIP_IND_XSFR_RWDATA_ISP  = FontIndex & 0xFF;

#ifdef  __MW_OSD_DEBUG__
#if 0
    wdata   = 0x80 | (0x07 & (font_pos >> 7));
    rdata   = REGRW8(APACHE_ISP_BASE, 0xFF01);
    if(wdata != rdata) {
        DEBUGMSG(MSGWARN, "Bank Set Error ==> ");
        DEBUGMSG(MSGWARN, "w[%X], ", wdata);
        DEBUGMSG(MSGWARN, "r[%X]\r\n", rdata);
    }

    wdata   = (0xff & (font_pos << 1)) | 0x01;
    rdata   = REGRW8(APACHE_ISP_BASE, 0xFF02);
    if(wdata != rdata) {
        DEBUGMSG(MSGWARN, "MSB Addr Set Error ==> ");
        DEBUGMSG(MSGWARN, "w[%X], ", wdata);
        DEBUGMSG(MSGWARN, "r[%X]\r\n", rdata);
    }

    wdata   = ((Style & 0x07) << 5) | ((Color & 0x07) << 2) | ((FontIndex >> 8) & 0x03);
    rdata   = REGRW8(APACHE_ISP_BASE, 0xFF03);
    if(wdata != rdata) {
        DEBUGMSG(MSGWARN, "MSB Wdata Set Error ==> ");
        DEBUGMSG(MSGWARN, "w[%X], ", wdata);
        DEBUGMSG(MSGWARN, "r[%X]\r\n", rdata);
    }

    wdata   = 0xff & (font_pos << 1);
    rdata   = REGRW8(APACHE_ISP_BASE, 0xFF04);
    if(wdata != rdata) {
        DEBUGMSG(MSGWARN, "MSB Addr Set Error ==> ");
        DEBUGMSG(MSGWARN, "w[%X], ", wdata);
        DEBUGMSG(MSGWARN, "r[%X]\r\n", rdata);
    }

    wdata   = FontIndex & 0xFF;
    rdata   = REGRW8(APACHE_ISP_BASE, 0xFF05);
    if(wdata != rdata) {
        DEBUGMSG(MSGWARN, "MSB Wdata Set Error ==> ");
        DEBUGMSG(MSGWARN, "w[%X], ", wdata);
        DEBUGMSG(MSGWARN, "r[%X]\r\n", rdata);
    }
#endif
#endif

    return;
}

//////////////////////////////////////////////////////////
//  Function    :   ncDrv_OSDString_Set                                            //
//  Error Msg   :                                                               //
//                      0x81        horizontal index over                   //
//                      0x82        vertical index over                         //
//                      0x83        max index over                              //
//  Assign Bits :                                                                           //
//         [15:13]       [12:10]        [9:0]                                           //
//    {  Fnt_Style,  Fnt_Color,  Fnt_Index  }                               //
//////////////////////////////////////////////////////////
void ncDrv_OSDString_Set(void)
{
    USHORT  StringBuffer;
    
    INT32 str_pos, i;
    UCHAR str_attr;
    UCHAR StringCount, Count;
    ULONG osd_table_addr = 0;
    ULONG osd_STaddress;
#if 0
    ULONG osd_STaddress = SFLASH_MENU_TABLE_ADDR;
#endif
    UCHAR PosX = sMwMenu.PosX;
    UCHAR PosY = sMwMenu.PosY;
    USHORT FontIndex = sMwMenu.FontIndex;
    UCHAR Style = sMwMenu.Style;
    UCHAR Color = sMwMenu.Color;
    UCHAR CharCnt = sMwMenu.StringNum;
    UCHAR Temp = 0;
    UCHAR StringCountMax = 3+MAINMENU_NUM + SUBMENU_NUM + rSWReg.Category.OSD.Reg.MENU_MAIN_SUB_INTERVAL;
    
#ifdef  __MW_OSD_DEBUG__
    UCHAR rdata;
    UCHAR wdata;

    DEBUGMSG(MSGWARN, "NumX[%X] ", sMwOsd.NumX);
    DEBUGMSG(MSGWARN, "MaxX[%d]\r\n", PosX);
    DEBUGMSG(MSGWARN, "NumY[%X] ", sMwOsd.NumY);
    DEBUGMSG(MSGWARN, "MaxY[%d]\r\n", PosY);
#endif

//  if(sMwOsd.NumX <= PosX) return 0x81;
//  if(sMwOsd.NumY <= PosY) return 0x82;
//  if(str_pos > OSD_GVRINDEX_MAX) return 0x83;

    osd_table_addr = ((ULONG)osd_STaddress + ((ULONG)FontIndex* TOTAL) + ((ULONG)rSWReg.Category.OSD.Reg.LANGUAGE* MAXCHAR_NUM));

    //MW_SFlashData_Get(osd_table_addr, MAXCHAR_NUM, &sMwOsd.StringFont[0]);

    StringCount = 0;
    for(Count = 0; Count<12; Count++)
    {
        if(sMwOsd.StringFont[Count] == 0)
        {
            if((Count+1) > 11)                                                          break;
            if(sMwOsd.StringFont[Count+1] == 0 && sMwOsd.StringFont[Count+2] == 0)      break;
            else                                StringCount++;
        }   
        else                                    StringCount++;
    }       

    if(sMwMenu.StringType == STRING_TYPE_TITLE)
    {
        if(rSWReg.Category.OSD.Reg.MENU_TITLE_ALIGN_MODE == 1)            // Center Align 
        {
            PosX = PosX + ((StringCountMax - StringCount)>>1)  - 1;  
            CharCnt = StringCount;      
        }
        else if(rSWReg.Category.OSD.Reg.MENU_TITLE_ALIGN_MODE == 2)       // Right Align
        {
            PosX = PosX + (StringCountMax - StringCount) - 1;       
            CharCnt = StringCount;      
        }
        sMwMenu.StringType = STRING_TYPE_NORMAL;
    }
        
    str_pos  = PosY * sMwOsd.NumX + PosX;
    str_attr = ((Style & 0x07) << 5) | ((Color & 0x07) << 2);   
//    rXSFR_BANK      = 0x00; 
    REGRW8(APACHE_ISP_BASE, 0xFF00)  = 0x00;                                 // isp async mode
    
    i = 0;
    while(i < CharCnt)
    {
         /* [2014/3/20] hyundong : Rom Font modify.    */
        if(rIP_O_OSD_ROM_EN)         StringBuffer = OSD_RomFont_Change_Task(sMwOsd.StringFont[i]);
        else                                                StringBuffer = sMwOsd.StringFont[i];

        REGRW8(APACHE_ISP_BASE, 0xFF01) = (0x80 | (0x07 & (str_pos >> 7)));  // bank set
        REGRW8(APACHE_ISP_BASE, 0xFF02) = ((0xff & (str_pos << 1)) | 0x01);  // address set(MSB)

        Temp = str_attr | ((StringBuffer >> 8) & 0x01); // wdata      (MSB)
        REGRW8(APACHE_ISP_BASE, 0xFF03) = Temp;
        REGRW8(APACHE_ISP_BASE, 0xFF03) = Temp;
        REGRW8(APACHE_ISP_BASE, 0xFF03) = Temp;
        
        REGRW8(APACHE_ISP_BASE, 0xFF02) = (0xff & (str_pos << 1));               // address set(LSB)     
        REGRW8(APACHE_ISP_BASE, 0xFF03) = StringBuffer;                                  // wdata      (LSB)
        REGRW8(APACHE_ISP_BASE, 0xFF03) = StringBuffer;                                  // wdata      (LSB)
        REGRW8(APACHE_ISP_BASE, 0xFF03) = StringBuffer; 
            
#ifdef  __MW_OSD_DEBUG__
#if 0
        ncLib_DEBUG_Printf(1, "[0x%x]\r\n", sMwOsd.StringFont[i]);
        ncLib_DEBUG_Printf(1, "{%d}\r\n", i);

        wdata   = 0x80 | (0x07 & (str_pos >> 7));
        rdata   = REGRW8(APACHE_ISP_BASE, 0xFF01);
        if(wdata != rdata) {
            ncLib_DEBUG_Printf(1, "Bank Set Error ==> ");
            ncLib_DEBUG_Printf(1, "w[%X], ", wdata);
            ncLib_DEBUG_Printf(1, "r[%X]\r\n", rdata);
        }

        wdata   = (0xff & (str_pos << 1)) | 0x01;
        rdata   = REGRW8(APACHE_ISP_BASE, 0xFF02);
        if(wdata != rdata) {
            ncLib_DEBUG_Printf(1, "MSB Addr Set Error ==> ");
            ncLib_DEBUG_Printf(1, "w[%X], ", wdata);
            ncLib_DEBUG_Printf(1, "r[%X]\r\n", rdata);
        }

        wdata   = str_attr | ((sMwOsd.StringFont[i] >> 8) & 0x01);
        rdata   = REGRW8(APACHE_ISP_BASE, 0xFF03);
        if(wdata != rdata) {
            ncLib_DEBUG_Printf(1, "MSB Wdata Set Error ==> ");
            ncLib_DEBUG_Printf(1, "w[%X], ", wdata);
            ncLib_DEBUG_Printf(1, "r[%X]\r\n", rdata);
        }

        wdata   = 0xff & (str_pos << 1);
        rdata   = REGRW8(APACHE_ISP_BASE, 0xFF04);
        if(wdata != rdata) {
            ncLib_DEBUG_Printf(1, "MSB Addr Set Error ==> ");
            ncLib_DEBUG_Printf(1, "w[%X], ", wdata);
            ncLib_DEBUG_Printf(1, "r[%X]\r\n", rdata);
        }

        wdata   = sMwOsd.StringFont[i];
        rdata   = REGRW8(APACHE_ISP_BASE, 0xFF05);
        if(wdata != rdata) {
            ncLib_DEBUG_Printf(1, "MSB Wdata Set Error ==> ");
            ncLib_DEBUG_Printf(1, "w[%X], ", wdata);
            ncLib_DEBUG_Printf(1, "r[%X]\r\n", rdata);
        }
#endif
#endif

        i++;
        str_pos++;

        PosX++;
        if(sMwOsd.NumX <= PosX) break;
    }
    
    return;
}


//////////////////////////////////////////////////////////
//  Function    :   Command_Change                                       //
//  Error Msg   :                                                           //
//                      0x81        vertical GVR index over                     //
//                      0x82        horizontal GVR index over                   //
//                      0x83        a previous command is not finished  //
//  Assign Bits :                                                                    //
//       [15:12]  [11:8]   [7:4]     [3:0]                                     //
//    {  Color1,  Color2,  Color3,  BFColor  }                                  //
//////////////////////////////////////////////////////////
void ncDrv_OSDOptionChange_Set(    BOOL Style_E, 
                                            BOOL Color_E, 
                                            BOOL Font_E, 
                                            UCHAR S_vpos, 
                                            UCHAR S_hpos, 
                                            UCHAR E_vpos, 
                                            UCHAR E_hpos, 
                                            UCHAR Style, 
                                            UCHAR Color, 
                                            INT32 Font)
{
    UCHAR vpos_st, hpos_st, vpos_ed, hpos_ed;
    
    vpos_st     = (S_vpos >= sMwOsd.NumY)       ? (sMwOsd.NumY - 1)     : S_vpos;
    hpos_st     = (S_hpos >= sMwOsd.NumX)       ? (sMwOsd.NumX - 1)     : S_hpos;
    vpos_ed     = (E_vpos >= sMwOsd.NumY)       ? (sMwOsd.NumY - 1)     : E_vpos;
    hpos_ed     = (E_hpos >= sMwOsd.NumX)       ? (sMwOsd.NumX - 1)     : E_hpos;
//  if(vpos_ed < vpos_st)  return 0x81;
//  if(hpos_ed < hpos_st)  return 0x82;

    rIP_O_OSD_SVADDR = vpos_st;  // Start V 
    rIP_O_OSD_SHADDR = hpos_st;  // Start H
    rIP_O_OSD_EVADDR = vpos_ed;  // End V
    rIP_O_OSD_EHADDR = hpos_ed;  // End H

    rIP_O_OSD_FNT_9_8 = ((Font >> 8) & 0x03);
    rIP_O_OSD_FNT_7_0 = (Font & 0xFF);
    rIP_O_OSD_COLOR = Color;
    rIP_O_OSD_STYLE = Style;
    
    
    rIP_O_OSD_CHG_MODE = ((Font_E & 0x01) << 2) | ((Color_E & 0x01) << 1) | (Style_E & 0x01);
    rIP_O_OSD_CHG_EN = 1;

    // check previous command 
    while(1)
    {
        if(rIP_O_OSD_CHG_EN == 0x00)             break;
    }

    return;
}


void ncDrv_BoxDisplay_Set(UCHAR Mode)
{
    if(rSWReg.Category.OSD.Reg.BOX_0_EN)
    {
        if((Mode & 0x01))           rIP_O_OSD_BOX0_EN = 1;   //ON
        else                        rIP_O_OSD_BOX0_EN = 0;   //OFF
    }
    else                            rIP_O_OSD_BOX0_EN = 0;   //OFF


    if(rSWReg.Category.OSD.Reg.BOX_1_EN)
    {
        if((Mode & 0x10))           rIP_O_OSD_BOX1_EN = 1;   //ON
        else                        rIP_O_OSD_BOX1_EN = 0;   //OFF
    }
    else                            rIP_O_OSD_BOX1_EN = 0;   //OFF

}

void ncDrv_OSDBin_Get(void)
{
	OSD_RomFont_Load();
	if(rSWReg.Category.OSD.Reg.ROM_FONT_EN==0)
		OSD_RamFont_Load();
	
	ncDrv_OSDClear_Set();
	return;
}

void ncDrv_OSDFont_Set(void)
{
    UCHAR Style = 0;
    UCHAR TransFont = 0;
    UCHAR TransBG = 0;
    UCHAR Outline = 0;
    
    // Title Menu Style0 Index Set
    Style = (STYLE_TRANSENABLE | STYLE_BLINKDISABLE| STYLE_TRANSVALUE_INDEX0 | STYLE_BLINKTIMER_INDES0 | STYLE_BGDISABLE);

    if(rSWReg.Category.OSD.Reg.MENU_TITLE_FONT_TRANS)
    {
        TransFont = (15 - rSWReg.Category.OSD.Reg.MENU_TITLE_FONT_TRANS)*9;
        TransFont |= TRANS_FONTENABLE;
    }
    else        TransFont = TRANS_FONTDISABLE;  
    Outline = (!rSWReg.Category.OSD.Reg.MENU_TITLE_FONT_OUTLINE);
    Outline = (Outline << 7);

    rIP_O_OSD_ATTR_STYLE0 = Style;

    rIP_O_OSD_TRANS_TABLE0_31_24 = TransFont;
    rIP_O_OSD_TRANS_TABLE0_23_16 = Outline;
    rIP_O_OSD_TRANS_TABLE0_15_8 = Outline;
    rIP_O_OSD_TRANS_TABLE0_7_0  = 0x00;

    rIP_O_OSD_ATTR_COLOR0_15_8 = (rSWReg.Category.OSD.Reg.MENU_TITLE_FONT_COLOR << 4) | rSWReg.Category.OSD.Reg.MENU_TITLE_FONT_OUTLINE_COLOR;
    rIP_O_OSD_ATTR_COLOR0_7_0 = (rSWReg.Category.OSD.Reg.MENU_TITLE_FONT_OUTLINE_COLOR << 4);

    // Main Menu Style1 Index  Set
    Style = (STYLE_TRANSENABLE | STYLE_BLINKDISABLE| STYLE_TRANSVALUE_INDEX1 | STYLE_BLINKTIMER_INDES1 | STYLE_BGDISABLE);
    if(rSWReg.Category.OSD.Reg.MENU_MAIN_FONT_TRANS)
    {
        TransFont = (15 - rSWReg.Category.OSD.Reg.MENU_MAIN_FONT_TRANS)*9;
        TransFont |= TRANS_FONTENABLE;
    }
    else        TransFont = TRANS_FONTDISABLE;
    Outline = (!rSWReg.Category.OSD.Reg.MENU_MAIN_FONT_OUTLINE);
    Outline = (Outline << 7);
    TransBG = (TRANS_BGENABLE | ((15 - rSWReg.Category.OSD.Reg.MENU_FOCUS_BG_TRANS)*9));

    rIP_O_OSD_ATTR_STYLE1 = Style;
    
    rIP_O_OSD_TRANS_TABLE1_31_24 = TransFont;
    rIP_O_OSD_TRANS_TABLE1_23_16 = Outline;
    rIP_O_OSD_TRANS_TABLE1_15_8 = Outline;
    rIP_O_OSD_TRANS_TABLE1_7_0 = TransBG;

    rIP_O_OSD_ATTR_COLOR1_15_8 = (rSWReg.Category.OSD.Reg.MENU_MAIN_FONT_COLOR<<4) | rSWReg.Category.OSD.Reg.MENU_MAIN_FONT_OUTLINE_COLOR;
    rIP_O_OSD_ATTR_COLOR1_7_0 = (rSWReg.Category.OSD.Reg.MENU_MAIN_FONT_OUTLINE_COLOR << 4) | rSWReg.Category.OSD.Reg.MENU_FOCUS_BG_COLOR;

    // Sub Menu Style2 Index Set
    Style = (STYLE_TRANSENABLE | STYLE_BLINKDISABLE| STYLE_TRANSVALUE_INDEX2 | STYLE_BLINKTIMER_INDES2 | STYLE_BGDISABLE);
    if(rSWReg.Category.OSD.Reg.MENU_SUB_FONT_TRANS)
    {   
        TransFont = (15 - rSWReg.Category.OSD.Reg.MENU_SUB_FONT_TRANS)*9;
        TransFont |= TRANS_FONTENABLE;
    }
    else        TransFont = TRANS_FONTDISABLE;

    Outline = (!rSWReg.Category.OSD.Reg.MENU_SUB_FONT_OUTLINE);
    Outline = (Outline << 7);
    TransBG = (TRANS_BGENABLE | (15 - rSWReg.Category.OSD.Reg.MENU_FOCUS_BG_TRANS)*9);

    rIP_O_OSD_ATTR_STYLE2 = Style;

    rIP_O_OSD_TRANS_TABLE2_31_24 = TransFont;
    rIP_O_OSD_TRANS_TABLE2_23_16 = Outline;
    rIP_O_OSD_TRANS_TABLE2_15_8 = Outline;
    rIP_O_OSD_TRANS_TABLE2_7_0 = TransBG;

    rIP_O_OSD_ATTR_COLOR2_15_8 = (rSWReg.Category.OSD.Reg.MENU_SUB_FONT_COLOR<<4) | rSWReg.Category.OSD.Reg.MENU_SUB_FONT_OUTLINE_COLOR;
    rIP_O_OSD_ATTR_COLOR2_7_0 = (rSWReg.Category.OSD.Reg.MENU_SUB_FONT_OUTLINE_COLOR << 4) | rSWReg.Category.OSD.Reg.MENU_FOCUS_BG_COLOR;

    // Main Menu Focus Style3 Index Set
    if(rSWReg.Category.OSD.Reg.MENU_FOCUS_MODE == 0)// BackGround Style
    {
        Style = (STYLE_TRANSENABLE | STYLE_BLINKDISABLE| STYLE_TRANSVALUE_INDEX3 | STYLE_BLINKTIMER_INDES3 | STYLE_BGENABLE);
        if(rSWReg.Category.OSD.Reg.MENU_MAIN_FONT_TRANS)
        {
            TransFont = (15 - rSWReg.Category.OSD.Reg.MENU_MAIN_FONT_TRANS)*9;
            TransFont |= TRANS_FONTENABLE;
        }
        else        TransFont = TRANS_FONTDISABLE;
        Outline = (!rSWReg.Category.OSD.Reg.MENU_MAIN_FONT_OUTLINE);
        Outline = (Outline << 7);

        rIP_O_OSD_ATTR_COLOR3_15_8 = (rSWReg.Category.OSD.Reg.MENU_MAIN_FONT_COLOR<<4) | rSWReg.Category.OSD.Reg.MENU_MAIN_FONT_OUTLINE_COLOR;
        rIP_O_OSD_ATTR_COLOR3_7_0 = (rSWReg.Category.OSD.Reg.MENU_MAIN_FONT_OUTLINE_COLOR << 4) | rSWReg.Category.OSD.Reg.MENU_FOCUS_BG_COLOR;
    }
    else    // Font Highlight
    {
        Style = (STYLE_TRANSENABLE | STYLE_BLINKDISABLE| STYLE_TRANSVALUE_INDEX3 | STYLE_BLINKTIMER_INDES3 | STYLE_BGDISABLE);
        
        if(rSWReg.Category.OSD.Reg.MENU_FOCUS_FONT_TRANS)
        {
            TransFont = (15 - rSWReg.Category.OSD.Reg.MENU_FOCUS_FONT_TRANS)*9;
            TransFont |= TRANS_FONTENABLE;
        }
        else        TransFont = TRANS_FONTDISABLE;
        
        Outline = (!rSWReg.Category.OSD.Reg.MENU_FOCUS_FONT_OUTLINE);
        Outline = (Outline << 7);

        rIP_O_OSD_ATTR_COLOR3_15_8 = ((rSWReg.Category.OSD.Reg.MENU_FOCUS_FONT_COLOR<<4) | rSWReg.Category.OSD.Reg.MENU_FOCUS_FONT_OUTLINE_COLOR);
        rIP_O_OSD_ATTR_COLOR3_7_0 = (rSWReg.Category.OSD.Reg.MENU_FOCUS_FONT_OUTLINE_COLOR << 4);  
    }

    if(rSWReg.Category.OSD.Reg.MENU_FOCUS_BG_TRANS)
    {   
        TransBG = (15 - rSWReg.Category.OSD.Reg.MENU_FOCUS_BG_TRANS)*9;
        TransBG |= TRANS_BGENABLE;
    }
    else        TransBG = TRANS_BGDISABLE;

    rIP_O_OSD_ATTR_STYLE3 = Style;
    rIP_O_OSD_TRANS_TABLE3_31_24 = TransFont;
    rIP_O_OSD_TRANS_TABLE3_23_16= Outline;
    rIP_O_OSD_TRANS_TABLE3_15_8 = Outline;
    rIP_O_OSD_TRANS_TABLE3_7_0 = TransBG;

    
    // Sub Menu Focus Style4 Index Set
    if(rSWReg.Category.OSD.Reg.MENU_FOCUS_MODE == 0)// BackGround Style
    {
        Style = (STYLE_TRANSENABLE | STYLE_BLINKDISABLE| STYLE_TRANSVALUE_INDEX4 | STYLE_BLINKTIMER_INDES3 | STYLE_BGENABLE);
        if(rSWReg.Category.OSD.Reg.MENU_SUB_FONT_TRANS)
        {   
            TransFont = (15 - rSWReg.Category.OSD.Reg.MENU_SUB_FONT_TRANS)*9;
            TransFont |= TRANS_FONTENABLE;
        }
        else        TransFont = TRANS_FONTDISABLE;

        Outline = (!rSWReg.Category.OSD.Reg.MENU_SUB_FONT_OUTLINE);
        Outline = (Outline << 7);

        rIP_O_OSD_ATTR_COLOR4_15_8 = (rSWReg.Category.OSD.Reg.MENU_SUB_FONT_COLOR<<4) | rSWReg.Category.OSD.Reg.MENU_SUB_FONT_OUTLINE_COLOR;
        rIP_O_OSD_ATTR_COLOR4_7_0= (rSWReg.Category.OSD.Reg.MENU_SUB_FONT_OUTLINE_COLOR << 4) | rSWReg.Category.OSD.Reg.MENU_FOCUS_BG_COLOR; 

    }
    else// Font Highlight
    {
        Style = (STYLE_TRANSENABLE | STYLE_BLINKDISABLE| STYLE_TRANSVALUE_INDEX4 | STYLE_BLINKTIMER_INDES3 | STYLE_BGDISABLE);
        if(rSWReg.Category.OSD.Reg.MENU_FOCUS_FONT_TRANS)
        {
            TransFont = (15 - rSWReg.Category.OSD.Reg.MENU_FOCUS_FONT_TRANS)*9;
            TransFont |= TRANS_FONTENABLE;
        }
        else        TransFont = TRANS_FONTDISABLE;
        Outline = (!rSWReg.Category.OSD.Reg.MENU_FOCUS_FONT_OUTLINE);
        Outline = (Outline << 7);

        rIP_O_OSD_ATTR_COLOR4_15_8 = ((rSWReg.Category.OSD.Reg.MENU_FOCUS_FONT_COLOR<<4) | rSWReg.Category.OSD.Reg.MENU_FOCUS_FONT_OUTLINE_COLOR);
        rIP_O_OSD_ATTR_COLOR4_7_0= (rSWReg.Category.OSD.Reg.MENU_FOCUS_FONT_OUTLINE_COLOR << 4);       
    }
        
    if(rSWReg.Category.OSD.Reg.MENU_FOCUS_BG_TRANS)
    {   
        TransBG = (15 - rSWReg.Category.OSD.Reg.MENU_FOCUS_BG_TRANS)*9;
        TransBG |= TRANS_BGENABLE;
    }
    else        TransBG = TRANS_BGDISABLE;
    
    rIP_O_OSD_ATTR_STYLE4 = Style;
    rIP_O_OSD_TRANS_TABLE4_31_24 = TransFont;
    rIP_O_OSD_TRANS_TABLE4_23_16= Outline;
    rIP_O_OSD_TRANS_TABLE4_15_8 = Outline;
    rIP_O_OSD_TRANS_TABLE4_7_0 = TransBG;

    // Blink Style5 Index Set
    rIP_O_OSD_ATTR_STYLE5 = 0x40;
    rIP_O_OSD_BLK_TABLE0_31_24 = 0xF1;
    rIP_O_OSD_BLK_TABLE0_23_16 = 0x83;
    rIP_O_OSD_BLK_TABLE0_15_8 = 0xBF;
    rIP_O_OSD_BLK_TABLE0_7_0 = 0x80;

    // OSD ON
    rIP_O_OSD_BUS_ENABLE = 1;

	rIP_OSD_OUTLINE_EN = 0;
	rIP_OSD_BLKTIMER_RST = 0;
	rIP_OSD_FNT_CLPF_EN = 0;
	rIP_OSD_FNT_YLPF_EN = 0;

    //{/* [2014/10/21] shpark : 1-1 */
    //rBank1D.Byte.Reg_0xDD00.B8.OSD_OUTLINE_EN = 0;

    rIP_OSD_GRD_INDEXZERO_EN = 1;
    rIP_OSD_GRD_FSWAP = 0;
    rIP_OSD_EN = 1;

}

void APP_OSDPrint_Dec(UCHAR PosY, UCHAR PosX, USHORT WriteData)
{
	UCHAR cnt=0;
	UCHAR osd_Sdata[5]={0,};

	sMwMenu.Style = 2;
	sMwMenu.Color = 2;
	
	osd_Sdata[0] = WriteData / 10000;
	osd_Sdata[1] = (WriteData % 10000)/1000;
	osd_Sdata[2] = (WriteData % 1000)/100;
	osd_Sdata[3] = (WriteData % 100)/10;
	osd_Sdata[4] = WriteData % 10;
	
	if(WriteData>9999)
	{
		osd_Sdata[0] = osd_Sdata[0]+1;
		osd_Sdata[1] = osd_Sdata[1]+1;
		osd_Sdata[2] = osd_Sdata[2]+1;	
		osd_Sdata[3] = osd_Sdata[3]+1;	
		osd_Sdata[4] = osd_Sdata[4]+1;	
	}
	else if(WriteData>999)
	{
		osd_Sdata[0] = osd_Sdata[1]+1;
		osd_Sdata[1] = osd_Sdata[2]+1;
		osd_Sdata[2] = osd_Sdata[3]+1;	
		osd_Sdata[3] = osd_Sdata[4]+1;
		osd_Sdata[4] = 0;	
	}
	else if(WriteData>99)
	{
		osd_Sdata[0] = osd_Sdata[2]+1;
		osd_Sdata[1] = osd_Sdata[3]+1;
		osd_Sdata[2] = osd_Sdata[4]+1;	
		osd_Sdata[3] = 0;
		osd_Sdata[4] = 0;	
	}
	else if(WriteData>9)
	{
		osd_Sdata[0] = osd_Sdata[3]+1;
		osd_Sdata[1] = osd_Sdata[4]+1;
		osd_Sdata[2] = 0;	
		osd_Sdata[3] = 0;
		osd_Sdata[4] = 0;	
	}	
	else
	{
		osd_Sdata[0] = osd_Sdata[4]+1;
		osd_Sdata[1] = 0;
		osd_Sdata[2] = 0;	
		osd_Sdata[3] = 0;
		osd_Sdata[4] = 0;	
	}

	sMwMenu.PosY = PosY;
	for(cnt=0; cnt<5; cnt++)
	{
		sMwMenu.PosX = (PosX + cnt);
		sMwMenu.FontIndex = osd_Sdata[cnt];
		ncDrv_OSDChar_Set();
	}
}

void APP_OSDPrint_Hex(UCHAR PosY, UCHAR PosX, UCHAR WriteData)
{
	UCHAR OsdBuffer[2];
		
	OsdBuffer[0] = (UCHAR)(WriteData >> 4) + 1;
	OsdBuffer[1] = (WriteData & 0xF) + 1;

//	sMwMenu.Style = 2;
//	sMwMenu.Color = 2;

	sMwMenu.PosX = PosX;
	sMwMenu.PosY = PosY;
	sMwMenu.Style = 2;
	sMwMenu.Color = 2;

	sMwMenu.FontIndex = OsdBuffer[0];
	ncDrv_OSDChar_Set();

	sMwMenu.PosX = sMwMenu.PosX + 1;
	sMwMenu.FontIndex = OsdBuffer[1] ;
	ncDrv_OSDChar_Set();
	
}


void APP_OSDPrint_Hex2(UCHAR PosY, UCHAR PosX, USHORT WriteData)
{
	UCHAR OsdBuffer[4];
    USHORT Mod;

    OsdBuffer[0] = (UCHAR)(WriteData >> 12)+1;
	Mod = (WriteData & 0xFFF);
    OsdBuffer[1] = (UCHAR)(Mod >> 8)+1;
	Mod = (Mod & 0xFF);
    OsdBuffer[2] = (UCHAR)(Mod >> 4)+1;
	Mod = (Mod & 0xF);
    OsdBuffer[3] = (Mod & 0xF)+1;
    
	sMwMenu.PosX = PosX;
	sMwMenu.PosY = PosY;
	sMwMenu.Style = 2;
	sMwMenu.Color = 2;

	sMwMenu.FontIndex = OsdBuffer[0];
	ncDrv_OSDChar_Set();

	sMwMenu.PosX++;
	sMwMenu.FontIndex = OsdBuffer[1];
	ncDrv_OSDChar_Set();

	sMwMenu.PosX++;
	sMwMenu.FontIndex = OsdBuffer[2];
	ncDrv_OSDChar_Set();

	sMwMenu.PosX++;
	sMwMenu.FontIndex = OsdBuffer[3];
	ncDrv_OSDChar_Set();

}

void APP_OSDPrint_String(UCHAR PosY, UCHAR PosX, UCHAR* String)
{
	UCHAR Data;
	sMwMenu.PosX = PosX;
	sMwMenu.PosY = PosY;
	sMwMenu.Style = 2;
	sMwMenu.Color = 2;

	while(*String)
	{
		Data = *String;
		
		if(Data >= '0' && Data <= '9')			Data = Data - 47;
		else if(Data >= 'A' && Data <= 'Z')		Data = Data - 54;
		else if(Data >= 'a' && Data <= 'z')		Data = Data - 86;
		else if(Data == '/')					Data = Data + 1;
		else									Data = 0;

		sMwMenu.FontIndex = Data;
		ncDrv_OSDChar_Set();
		sMwMenu.PosX++;
		String++;
	}
}

void ncDrv_Osd_PosSetX(UCHAR PosX)
{
	sMwMenu.PosX = PosX;
}
void ncDrv_Osd_PosSetY(UCHAR PosY)
{
	sMwMenu.PosY = PosY;
}
void ncDrv_Osd_SetStr(UCHAR* String)
{
	APP_OSDPrint_String(sMwMenu.PosY,sMwMenu.PosX,String);
}
void ncDrv_Osd_SetDec(UCHAR WriteData)
{
	APP_OSDPrint_Dec(sMwMenu.PosY,sMwMenu.PosX,WriteData);
}
void ncDrv_Osd_SetHex(UCHAR WriteData)
{
	APP_OSDPrint_Hex(sMwMenu.PosY,sMwMenu.PosX,WriteData);
}


