
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __BLACKLEVEL_DRV__
#define __BLACKLEVEL_DRV__

typedef enum{
	MODE_OFF 	= 0,
	MODE_MANUAL,
	MODE_AUTO,
	MODE_AUTOandMANUAL
}BLACKLEVEL_MODE;

void ncDrv_BlackLevelCompensation_Auto(void);

void ncDrv_BlackLevelCompensation_Set(void);

#endif

