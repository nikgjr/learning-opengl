/**
********************************************************************************
*
*  Copyright (C) 2013 NEXTCHIP Inc. All rights reserved.
*
*  @file    : IspFlash_Drv.c
*
*  @brief   : APACHE ISP Flash Memory module driver source file
*
*  @author  : Alessio / Automotive SoC Software Team
*
*  @date    : 2013.12.23
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 2013.12.23 - ISP flash memory basic driver modified by Alessio
*
********************************************************************************
*/


/*
********************************************************************************
*           INCLUDE
********************************************************************************
*/

#include <time.h>

#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "ISP_Drv.h"
#include "System_Drv.h"
#include "IspFlash_Drv.h"

#define SF_PAGE_SIZE  (256)

/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

/*
 * User ISP Area Select
 */

#if 0
#define APACHE_SF_USER1_AREA               0
#define APACHE_SF_USER2_AREA               1

#define APACHE_SF_USER_ISP_AREA            APACHE_SF_USER1_AREA
#endif


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

/*===============================================================================
    SFR Register Num
===============================================================================*/
#define ROM_BANK_NUM        40
#define ROM_BANK_MEMBER     2
#define ISPREG_NUM          0xFF

const UCHAR ISP_REG_TABLE[ROM_BANK_NUM][ROM_BANK_MEMBER] = 
{
/* 0x00 */  {0x00,ISPREG_NUM},
/* 0x01 */  {0x01,ISPREG_NUM},
/* 0x02 */  {0x02,ISPREG_NUM},
/* 0x03 */  {0x03,ISPREG_NUM},
/* 0x04 */  {0x04,ISPREG_NUM},
/* 0x05 */  {0x05,ISPREG_NUM},
/* 0x06 */  {0x06,ISPREG_NUM},
/* 0x07 */  {0x07,ISPREG_NUM},
/* 0x08 */  {0x08,ISPREG_NUM},
/* 0x09 */  {0x09,ISPREG_NUM},
/* 0x0A */  /* OPD RGBY */
/* 0x0B */  /* OPD RGBY */
/* 0x0C */  /* OPD RGBY */
/* 0x0D */  {0x0D,ISPREG_NUM},
/* 0x0E */  {0x0E,ISPREG_NUM},
/* 0x0F */  {0x0F,ISPREG_NUM},
/* 0x10 */  /* MCU BUFFER */    
/* 0x11 */  {0x11,ISPREG_NUM},
/* 0x12 */  {0x12,ISPREG_NUM},
/* 0x13 */  {0x13,ISPREG_NUM},
/* 0x14 */  {0x14,ISPREG_NUM},
/* 0x15 */  {0x15,ISPREG_NUM},
/* 0x16 */  {0x16,ISPREG_NUM},
/* 0x17 */  {0x17,ISPREG_NUM},
/* 0x18 */  {0x18,ISPREG_NUM},
/* 0x19 */  {0x19,ISPREG_NUM},
/* 0x1A */  {0x1A,ISPREG_NUM},
/* 0x1B */  {0x1B,ISPREG_NUM},
/* 0x1C */  {0x1C,ISPREG_NUM},
/* 0x1D */  {0x1D,ISPREG_NUM},
/* 0x1E */  /* BMD BUFFER */
/* 0x1F */  /* BMD BUFFER */
/* 0x20 */  {0x20,ISPREG_NUM},
/* 0x21 */  {0x21,ISPREG_NUM},
/* 0x22 */  {0x22,ISPREG_NUM},
/* 0x23 */  /* OPD HISTOGRAM */
/* 0x24 */  {0x24,ISPREG_NUM},
/* 0x25 */  {0x25,ISPREG_NUM},
/* 0x26 */  {0x26,ISPREG_NUM},
/* 0x27 */  {0x27,ISPREG_NUM},
/* 0x28 */  {0x28,ISPREG_NUM},
/* 0x29 */  {0x29,ISPREG_NUM},
/* 0x2A */  {0x2A,ISPREG_NUM},
/* 0x2B */  {0x2B,ISPREG_NUM},   
/* 0x2C */  {0x2C,ISPREG_NUM}, 
/* 0x2D */  {0x2D,ISPREG_NUM},
/* 0x2E */  {0x2E,ISPREG_NUM},
};
/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

int ncDrv_ISP_FlashMemory_AllSave(UINT8 area)
{
    UINT32 address, i;
    UINT32 length, maxlength;
    int Result = NC_SUCCESS;

    UINT32 *pBuf = (UINT32 *) APACHE_ISP_BASE;

    //DEBUGMSG_SDK(MSGINFO, "ISP FlashMemory AllSave Start\n");

    if (area == ISP_USER_AREA)
    {
        address = FLASHMEMORY_ISP_REG_AREA_ADDRESS;
        length = FLASHMEMORY_ISP_REG_AREA_SIZE;
    }
    else
    {
        // ISP_FACTORY_AREA
        address = FLASHMEMORY_ISP_REG_BACKUP_AREA_ADDRESS;
        length = FLASHMEMORY_ISP_REG_BACKUP_AREA_SIZE;
    }

    for (i = 0; i < length; i += SF_PAGE_SIZE)
    {
        //DEBUGMSG_SDK(MSGINFO, "Page Write  : 0x%08x\n", address+i);
        //ncLib_SF_Control(GCMD_SF_WRITE_PAGE, address + i, (UINT8 *) (pBuf + i / 4), CMD_END);
		ncSvc_SF_WriteData(address + i, (UINT8 *)(pBuf + i / 4), SF_PAGE_SIZE);
    }

    maxlength = i;

    if (length > maxlength)
    {
        Result = NC_FAILURE;
        DEBUGMSG_SDK(MSGERR, "Error, ISP FlashMemory AllSave Failure!!!\n");
    }
    else
    {
        DEBUGMSG_SDK(MSGINFO, "ISP FlashMemory AllSave Success!!!\n");
    }

    return Result;
}

void __test_sf_display_buff_1( UINT8 *pBuff, UINT32 Size, UINT32 PageAddr)
{
    UINT32 i;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");	
    DEBUGMSG(MSGINFO, "\n>> PageAddr = 0x%08X", PageAddr);	
    for(i=0;i<Size;i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", PageAddr+i);	
        DEBUGMSG(MSGINFO, "%02X ", pBuff[i]);	
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");	
}

UINT8 pBuf[256]  __attribute__ ((aligned (8)));

int ncDrv_ISP_FlashMemory_AllLoad(UINT8 area)
{
    UINT32 address;
    volatile UINT32 i, j, offset;
    UCHAR  Bank = 0;
	USHORT Add = 0;

    int Result = NC_SUCCESS;

    //UINT32 *pBuf = (UINT32 *)APACHE_ISP_BASE;

    if(area == ISP_USER_AREA)
    {
        address = FLASHMEMORY_ISP_REG_AREA_ADDRESS;
    }
    else
    {
        // ISP_FACTORY_AREA
        address = FLASHMEMORY_ISP_REG_BACKUP_AREA_ADDRESS;
    }

	//ISP REGISTER LOAD
	
    for(i=0; i<ROM_BANK_NUM; i++)
    {
        Bank = ISP_REG_TABLE[i][0];   
		
        //MW_SFlashData_Get(IspRegAddr,RegisterNum,&sFlashISP[0]);
      
        if(Bank == 0) 
		{
			/* [2016/03/29] shpark : GL_SWAP, INPUT_H_TOTAL Set */
			//ncLib_SF_Control(GCMD_SF_READ_PAGE, address, (UINT8 *)(pBuf+0), CMD_END);
			ncSvc_SF_ReadData(address, (UINT8 *)(pBuf+0), SF_PAGE_SIZE);

			REGRW8(APACHE_ISP_BASE, ((Bank*SF_PAGE_SIZE)+0xE3)) = pBuf[0xE3];
			REGRW8(APACHE_ISP_BASE, ((Bank*SF_PAGE_SIZE)+0xE4)) = pBuf[0xE4];
			REGRW8(APACHE_ISP_BASE, ((Bank*SF_PAGE_SIZE)+0xE6)) = pBuf[0xE6];
			/************************************************************************/
			
            address += SF_PAGE_SIZE;
			
        }
		else
		{
            //ncLib_SF_Control(GCMD_SF_READ_PAGE, address, (UINT8 *)(pBuf+0), CMD_END);
			ncSvc_SF_ReadData(address, (UINT8 *)(pBuf+0), SF_PAGE_SIZE);
			
    		//__test_sf_display_buff_1(pBuf, SF_PAGE_SIZE, address);
    		
            for(j = 0; j < SF_PAGE_SIZE; j++)
            {
                offset = (Bank*SF_PAGE_SIZE)+j;
				
                REGRW8(APACHE_ISP_BASE, offset) = pBuf[j];
            }
			
            address += SF_PAGE_SIZE;     
        }
    }

	//STATUS REGISTER LOAD
	
    for(i = 0; i <= 5; i++) /* 0x0000 ~ 0x5A0 :  1440ea */ 
    {
		//ncLib_SF_Control(GCMD_SF_READ_PAGE, address, (UINT8 *)(pBuf+0), CMD_END);
		ncSvc_SF_ReadData(address, (UINT8 *)(pBuf+0), SF_PAGE_SIZE);
		
        //MW_SFlashData_Get(IspRegAddr,256,&sFlashISP[0]);
 
        for(j = 0; j < SF_PAGE_SIZE; j++)
        {
            Add = i;
            Add = (Add <<8)|j;

            rSWReg.BYTE[Add] = pBuf[j];

            //InnerCheckSum += pBuf[j];

            if((i == STATUS_REG_BANK_COUNT) &&(j >= (sizeof(STRUCT_SW_CONTROL_REGISTER)%0xFF)))
            {
                break; 
            }
        }
		
        address += 256;
    }

    sGco.MonitorOutput = (etMONITOR_OUT_MODE)rSWReg.Category.MONITOR.Reg.MONITOR_OUTPUT; 
  

#if 0
	sScr.Category.SYSTEM.Reg.ISP_SAVE           = FALSE;
    sScr.Category.MD.Reg.MD_AUTO_EN             = TRUE;
    sScr.Category.OSD.Reg.MENU_STATE            = FALSE;
    
    sScr.Category.DEFFECT.Reg.FREEZE_MODE       = FALSE;
    
    /* All Grid View Disable Init */
    sScr.Category.BACKLIGHT.Reg.BLC_GRID_EN     = FALSE;
    sScr.Category.TDN.Reg.BW_IR_SMART_GRID_VIEW = FALSE;
    sScr.Category.DEFOG.Reg.DEFOG_GIRD_VIEW     = FALSE;
    sScr.Category.BACKLIGHT.Reg.HSBLC_GRID_EN   = FALSE;

    /* DPC Scan State Init */
    sScr.Category.DPC.Reg.DPC_SCAN_VIEW         = eDPC_SCANVIEW_OFF;
    sScr.Category.DPC.Reg.WDPC_SCAN_STATE       = FALSE;
    sScr.Category.DPC.Reg.BDPC_SCAN_STATE       = FALSE;
    sScr.Category.AWB.Reg.AWC_SET               = FALSE;

    sScr.Category.AE.Reg.DC_LENS_ASHUT_MIN      = 0;    // Min Shutter Fix 

    sScr.Category.AWB.Reg.COLOREXCEPT_RATIO     = 0;    // 0% Init

    sScr.Category.NR.Reg.DNR3_DEBUG_MODE        = eMODE_OFF;
    sScr.Category.MONITOR.Reg.MONITOR_OUTPUT = sGco.MonitorOutput;

    SetChar(ADDR_MONITOR_OUTPUT_AHD, sGco.MonitorOutputEn);
    
    sScr.Category.GAMMA.Reg.ADPT_REF_VIEW = FALSE;
    
    sGco.GPI.B8.AHDMODE_PortNum = sScr.Category.GPIO.Reg.GPI_AHD_MODE;

    if(SENSOR_MAX_FPS == FPS_MAX_30P)   sScr.Category.MONITOR.Reg.ISP_INPUT_FRAME = eFRAME_RATE_30;
    if(SENSOR_MAX_SIZE == SIZE_MAX_720)
    {
        sScr.Category.MONITOR.Reg.ISP_INPUT_SIZE = eSIZE_1280_720;
        sScr.Category.MONITOR.Reg.ISP_OUTPUT_SIZE = eSIZE_1280_720;
    }

    sGco.InputFrame.Size = (etFRAME_SIZE)sScr.Category.MONITOR.Reg.ISP_INPUT_SIZE;
    sGco.InputFrame.Rate = (etFRAME_RATE)sScr.Category.MONITOR.Reg.ISP_INPUT_FRAME;
    sGco.OutputFrame.Size = (etFRAME_SIZE)sScr.Category.MONITOR.Reg.ISP_OUTPUT_SIZE;
    sGco.OutputFrame.Rate = (etFRAME_RATE)sScr.Category.MONITOR.Reg.ISP_OUTPUT_FRAME;

    MW_SFlashData_Get(SFLASH_MEMORY_INFO_ADDR,1L,&sFlashISP[0]);                /* FLASH_TYPE */
    sScr.Category.SYSTEM.Reg.FLASH_TYPE = sFlashISP[0];

    if(sScr.Category.MONITOR.Reg.MONITOR_OUTPUT == 0)
    {
        MW_SFlashData_Get((SFLASH_WDPC_INFO_ADDR + 4L),1L,&sFlashISP[0]);       /* WDPC_STATE */
    }
    else
    {
        MW_SFlashData_Get((SFLASH_WDPC_AHD_INFO_ADDR + 4L),1L,&sFlashISP[0]);   /* WDPC_STATE */
    }

    if(sFlashISP[0] == 0x0A)    sScr.Category.DPC.Reg.WDPC_STATE = TRUE;
    else                        sScr.Category.DPC.Reg.WDPC_STATE = FALSE;

    sMwDpc.Bit.WDPCState = sScr.Category.DPC.Reg.WDPC_STATE;                    /* [2014/8/28] sky : 1-2 */
    
    MW_SFlashData_Get((SFLASH_BDPC_INFO_ADDR+ 2L), 1L, &sFlashISP[0]);          /* BDPC_STATE */
    if(sFlashISP[0] == 0x0A)    sScr.Category.DPC.Reg.BDPC_STATE = TRUE;
    else                        sScr.Category.DPC.Reg.BDPC_STATE = FALSE;

    sMwDpc.Bit.BDPCState = sScr.Category.DPC.Reg.BDPC_STATE;                    /* [2014/8/28] sky : 1-2 */

#ifdef SFLASH_RECOVERY
	if( (Checksum[0] == ((InnerCheckSum)&0xFF)) && Checksum[1] == ( (InnerCheckSum>>8)&0xFF))
		Result = NC_SUCCESS;
	else
		Result = NC_FAILURE;
#else
	Result = NC_SUCCESS;
#endif
#endif

    return Result;
}

int ncDrv_ISP_FlashMemory_StatusSave(UINT8 area)
{
    UINT32 addr;
    int Result = NC_SUCCESS;

    if(area == ISP_USER_AREA)
    {
        addr = FLASHMEMORY_ISP_REG_AREA_ADDRESS;
    }
    else if(area == ISP_FACTORY_AREA)
    {
        addr = FLASHMEMORY_ISP_REG_BACKUP_AREA_ADDRESS;
    }

    ncLib_SF_Control(GCMD_SF_WRITE_PAGE, addr,       (UINT8 *)(&rSWReg.BYTE[0x00]), CMD_END);
    ncLib_SF_Control(GCMD_SF_WRITE_PAGE, addr+0x100, (UINT8 *)(&rSWReg.BYTE[0x100]), CMD_END);

    //DEBUGMSG_SDK(MSGINFO, "ISP STATUS FlashMemory All Save Success!!!\n");

    return Result;
}


int ncDrv_ISP_FlashMemory_StatusLoad(UINT8 area)
{
    UINT32 addr;
    int Result = NC_SUCCESS;

    if(area == ISP_USER_AREA)
    {
        addr = FLASHMEMORY_ISP_REG_AREA_ADDRESS;
    }   
    else if(area == ISP_FACTORY_AREA)
    {
        addr = FLASHMEMORY_ISP_REG_BACKUP_AREA_ADDRESS;
    }


    ncLib_SF_Control(GCMD_SF_READ_PAGE, addr,       (UINT8 *)(&rSWReg.BYTE[0]),     CMD_END);
    ncLib_SF_Control(GCMD_SF_READ_PAGE, addr+0x100, (UINT8 *)(&rSWReg.BYTE[0x100]), CMD_END);

    //DEBUGMSG_SDK(MSGINFO, "ISP STATUS FlashMemory All Load Success!!!\n");

    return Result;
}

/*
int ncDrv_ISP_FlashMemory_SCUSave(UINT8 area)
{
    UINT32 addr, data;
    UINT8 pBuffer[256] = {0, };
    int Result = NC_SUCCESS;

    if(area == ISP_USER_AREA)
    {
#if (APACHE_SF_USER_ISP_AREA == APACHE_SF_USER1_AREA)
        addr = FLASHMEMORY_SCU_USER_AREA_ADDRESS;
#else
        addr = FLASHMEMORY_SCU_USER2_AREA_ADDRESS;
#endif
    }
    else if(area == ISP_FACTORY_AREA)
    {
        addr = FLASHMEMORY_SCU_FACTORY_AREA_ADDRESS;
    }


    data = APACHE_READ(APACHE_SYSCON_BASE | 0x0024);
    DEBUGMSG_SDK(MSGINFO, "ISP SCU FlashMemory All Save Data[0x24]=0x%08X\n", data);

    pBuffer[0] = (data & 0xFF);
    pBuffer[1] = ((data>>8) & 0xFF);
    pBuffer[2] = ((data>>16) & 0xFF);
    pBuffer[3] = ((data>>24) & 0xFF);

    data = APACHE_READ(APACHE_SYSCON_BASE | 0x0028);
    DEBUGMSG_SDK(MSGINFO, "ISP SCU FlashMemory All Save Data[0x28]=0x%08X\n", data);

    pBuffer[4] = (data & 0xFF);
    pBuffer[5] = ((data>>8) & 0xFF);
    pBuffer[6] = ((data>>16) & 0xFF);
    pBuffer[7] = ((data>>24) & 0xFF);

    ncLib_SF_Control(GCMD_SF_WRITE_PAGE, addr, (UINT8 *)(&pBuffer[0]), CMD_END);

    DEBUGMSG_SDK(MSGINFO, "ISP SCU FlashMemory All Save Success!!!\n");

    return Result;
}

*/

/*
int ncDrv_ISP_FlashMemory_SCULoad(UINT8 area)
{
    UINT32 addr, data, i;
    UINT8 pBuffer[8];
    int Result = NC_SUCCESS;

    if(area == ISP_USER_AREA)
    {
#if (APACHE_SF_USER_ISP_AREA == APACHE_SF_USER1_AREA)
        addr = FLASHMEMORY_SCU_USER_AREA_ADDRESS;
#else
        addr = FLASHMEMORY_SCU_USER2_AREA_ADDRESS;
#endif
    }
    else if(area == ISP_FACTORY_AREA)
    {
        addr = FLASHMEMORY_SCU_FACTORY_AREA_ADDRESS;
    }


    ncLib_SF_Control(GCMD_SF_READ_DATA, addr, (UINT8 *)(&pBuffer[0]), sizeof(pBuffer), CMD_END);

    for(i = 0; i < 8; i++)
    {
        DEBUGMSG_SDK(MSGINFO, "ISP SCU FlashMemory All Load Data[%d]=0x%02X\n", i, pBuffer[i]);
    }

    data = pBuffer[0] | (pBuffer[1]<<8) | (pBuffer[2]<<16) | (pBuffer[3]<<24);
    APACHE_WRITE(APACHE_SYSCON_BASE | 0x0024, data);
    DEBUGMSG_SDK(MSGINFO, "ISP SCU FlashMemory All Load Data[0x24]=0x%08X\n", data);

    data = pBuffer[4] | (pBuffer[5]<<8) | (pBuffer[6]<<16) | (pBuffer[7]<<24);
    APACHE_WRITE(APACHE_SYSCON_BASE | 0x0028, data);
    DEBUGMSG_SDK(MSGINFO, "ISP SCU FlashMemory All Load Data[0x28]=0x%08X\n", data);

    DEBUGMSG_SDK(MSGINFO, "ISP SCU FlashMemory All Load Success!!!\n");

    return Result;
}

*/
int ncDrv_ISP_FlashMemory_CategorySave(UINT32 address, UINT32 length, UINT8 *buffer)
{
    int Result = NC_SUCCESS;

    Result = (UINT8) ncLib_SF_Control(GCMD_SF_WRITE_PAGE, address, (UINT8 *)buffer, length, CMD_END);

    //DEBUGMSG_SDK(MSGINFO, "ISP STATUS FlashMemory Category Save Success!!!\n");

    return Result;
}


int ncDrv_ISP_FlashMemory_CategoryLoad(UINT32 address, UINT32 length, UINT8 *buffer)
{
    int Result = NC_SUCCESS;

    Result = (UINT8) ncLib_SF_Control(GCMD_SF_READ_DATA, address, (UINT8 *)buffer, length, CMD_END);

    //DEBUGMSG_SDK(MSGINFO, "ISP STATUS FlashMemory Category Load Success!!!\n");

    return Result;
}

ULONG ISP_FlashAddress_StartPoint_Get(UCHAR Load)   // 1 : USER, 2 : BUFFER, 3: Factory
{
    ULONG FlashIspRegAddr = 0;
   
#if 0
    if(Load == ISP_FACTORY_AREA)
    {
        if(sGco.MonitorOutput == eMONITOR_CVBS)         FlashIspRegAddr = SFLASH_ISPCVBS_FACTORY_ADDR;
        else if(sGco.MonitorOutput == eMONITOR_HDSDI)   FlashIspRegAddr = SFLASH_ISPHDSDI_FACTORY_ADDR;
        else if(sGco.MonitorOutput == eMONITOR_AHD)     FlashIspRegAddr = SFLASH_ISPAHD_FACTORY_ADDR;
        else                                            FlashIspRegAddr = SFLASH_ISPCVBS_FACTORY_ADDR;     
    }
    else if(Load == ISP_USER_AREA)
    {
        if(sGco.MonitorOutput == eMONITOR_CVBS)         FlashIspRegAddr = SFLASH_ISPCVBS_USER_ADDR;
        else if(sGco.MonitorOutput == eMONITOR_HDSDI)   FlashIspRegAddr = SFLASH_ISPHDSDI_USER_ADDR;
        else if(sGco.MonitorOutput == eMONITOR_AHD)     FlashIspRegAddr = SFLASH_ISPAHD_USER_ADDR;
        else                                            FlashIspRegAddr = SFLASH_ISPCVBS_USER_ADDR;
    }

#ifdef SFLASH_RECOVERY
    else if(Load == ISP_BUFFER_AREA)
    {
    	if(sGco.MonitorOutput == eMONITOR_CVBS)         FlashIspRegAddr = SFLASH_ISPCVBS_BUFFER_ADDR;
        else if(sGco.MonitorOutput == eMONITOR_HDSDI)   FlashIspRegAddr = SFLASH_ISPHDSDI_BUFFER_ADDR;
        else if(sGco.MonitorOutput == eMONITOR_AHD)     FlashIspRegAddr = SFLASH_ISPAHD_BUFFER_ADDR;
        else                                            FlashIspRegAddr = SFLASH_ISPCVBS_BUFFER_ADDR;
    }
#endif
#endif
    if(Load == ISP_USER_AREA)
    {
        FlashIspRegAddr = FLASHMEMORY_ISP_REG_AREA_ADDRESS;
    }   
    else if(Load == ISP_FACTORY_AREA)
    {
        FlashIspRegAddr = FLASHMEMORY_ISP_REG_BACKUP_AREA_ADDRESS;
    }
   return FlashIspRegAddr;
   
}

#if 0
#ifdef SFLASH_RECOVERY
ULONG ISP_FlashAddress_CheckSumAddr_Get(UCHAR Load)
{
	ULONG FlashIspChecksumAddr;

    if(Load == ISP_FACTORY_AREA)
    {
        if(sGco.MonitorOutput == eMONITOR_CVBS)         FlashIspChecksumAddr = SFLASH_ISP_FACTORY_CVBS_CHECKSUM_ADDR;
        else if(sGco.MonitorOutput == eMONITOR_HDSDI)   FlashIspChecksumAddr = SFLASH_ISP_FACTORY_HDSDI_CHECKSUM_ADDR;
        else if(sGco.MonitorOutput == eMONITOR_AHD)     FlashIspChecksumAddr = SFLASH_ISP_FACTORY_AHD_CHECKSUM_ADDR;
    }
    else if(Load == ISP_USER_AREA)
    {
        if(sGco.MonitorOutput == eMONITOR_CVBS)         FlashIspChecksumAddr = SFLASH_ISP_USER_CVBS_CHECKSUM_ADDR;
        else if(sGco.MonitorOutput == eMONITOR_HDSDI)   FlashIspChecksumAddr = SFLASH_ISP_USER_HDSDI_CHECKSUM_ADDR;
        else if(sGco.MonitorOutput == eMONITOR_AHD)     FlashIspChecksumAddr = SFLASH_ISP_USER_AHD_CHECKSUM_ADDR;
    }
    else if(Load == ISP_BUFFER_AREA)
    {
    	if(sGco.MonitorOutput == eMONITOR_CVBS)         FlashIspChecksumAddr = SFLASH_ISP_BUFFER_CVBS_CHECKSUM_ADDR;
        else if(sGco.MonitorOutput == eMONITOR_HDSDI)   FlashIspChecksumAddr = SFLASH_ISP_BUFFER_HDSDI_CHECKSUM_ADDR;
        else if(sGco.MonitorOutput == eMONITOR_AHD)     FlashIspChecksumAddr = SFLASH_ISP_BUFFER_AHD_CHECKSUM_ADDR;
    }
	
	return FlashIspChecksumAddr;
}

#endif
#endif



void ncDrv_ISP_Flashmemory_Default_Load(UCHAR LoadArea)
{
#if 0
    USHORT i, StartAdd, EndAdd;
    UCHAR rData[255], Length;
    ULONG sFlashStatusAdd, sFlashIspEndAdd = ((ISPREG_NUM * ROM_BANK_NUM) + ROM_BANK_NUM);

    switch(LoadArea)
    {
        case FACTORY_STATUS_BLC_LOAD: /* BLC Default Load */
            StartAdd    = ADDF_BLC_START;
            EndAdd  = ADDF_BLC_END;
        break;
        case FACTORY_STATUS_HSBLC_LOAD: /* HSBLC Default Load */
            StartAdd    = ADDF_HSBLC_START;
            EndAdd  = ADDF_HSBLC_END;       
        break;
        case FACTORY_STATUS_MOTION_LOAD: /* Motion Default Load */
            StartAdd    = ADDF_MOTION_START;
            EndAdd  = ADDF_MOTION_END;      
        break;
        case FACTORY_STATUS_PRIVACY_LOAD: /* Privacy Default Load */
            StartAdd    = ADDF_PRIVACY_START;
            EndAdd  = ADDF_PRIVACY_END;     
        break;
        case FACTORY_STATUS_DEFOG_LOAD: /* Defog Default Load */
            StartAdd    = ADDF_DEFOG_START;
            EndAdd  = ADDF_DEFOG_END;       
        break;
        default:
            return;
        break;
    }

    StartAdd &= 0xFFF;
    EndAdd &= 0xFFF;
    sFlashStatusAdd = ISP_FlashAddress_StartPoint_Get(ISP_FACTORY_AREA) + sFlashIspEndAdd + StartAdd;
    Length = (EndAdd - StartAdd) + 1;

    ncLib_SF_Control(GCMD_SF_READ_DATA,sFlashStatusAdd,&rData[0],Length,CMD_END);
        
    for(i=0; i<Length; i++)
    {
    	rSWReg.BYTE[StartAdd] = rData[i];
        StartAdd++;
    }
    
#endif
}




/* End Of File */
