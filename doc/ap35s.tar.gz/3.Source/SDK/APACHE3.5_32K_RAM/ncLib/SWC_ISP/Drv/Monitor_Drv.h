
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __DRV_MONITOR_H__
#define __DRV_MONITOR_H__
/*=============================================================================
	Definitions for Options
=============================================================================*/
#define DDR_SCROE_THRESHOLD     18
#define DDRCALCVERSION          3

// Flash commands
#define SPI_EQIO			0x38	// Enable Quad I/O
#define SPI_RSTQIO			0xFF	// Reset Quad I/O
#define	SPI_WREN			0x06	// write enable
#define	SPI_WRDI			0x04	// write disable/Exit OTP Mode
#define	SPI_RDSR			0x05	// read status register
#define	SPI_WRSR			0x01	// write status register
#define SPI_PP				0x02	// Page Program
#define SPI_SE				0x20	// Sector Erase/OTP Erase
#define SPI_BE				0xD8	// Block Erase
#define SPI_CE				0xC7	// Chip Erase(0xC7 or 0x60)
#define	SPI_DP  			0xB9	// deep power-down
#define	SPI_RDP 			0xAB	// release from deep power-down, and read Device ID
#define SPI_MFDI			0x90	// Manufacturer/Device ID
#define	SPI_RDID			0x9F	// read identification
#define SPI_EOM				0x3A	// Enter OTP Mode

// Read Instruction
#define	SPI_READ			0x03	// read uc_data bytes
#define	SPI_FAST_READ		0x0B	// read uc_data bytes at higher speed
#define	SPI_UO_FAST_READ	0x3B	// Dual Output Fast Read
#define	SPI_DIO_FAST_READ	0xBB	// Dual Input/Output Fast Read
#define	SPI_QIO_FAST_READ	0xEB	// Quad Input/Output Fast Raad

// Status Register
#define	SRWD				0x80	// 
#define	PEE					0x40	//Program/erase error bit
#define	BP3					0x20
#define	BP2					0x10
#define	BP1					0x08
#define	BP0					0x04
#define	WEL					0x02	//Check the write enable bit of the SPI status register
#define	WIP					0x01	//Check the write in progress bit of the SPI status register

#define MOSI2MISO			0x00
#define MISO2MOSI			0x20

//#define 	SFR_BANK_SELECT(x)		(rXSFR_BANK = (x))

typedef struct
{
	//UCHAR 	MSGBuff[16];
	
	//UCHAR 	RegisterSave;
	
	UCHAR	DDRDebug;
	
	UCHAR	UART1_En;

	UCHAR	PortInit;
	

}STRUCT_MW_MCU;

extern STRUCT_MW_MCU	sMwMCU;

void MW_SwReset_Set(void);
void ncDrv_MONITOR_IIF_POSITION_Set(void);
void ncDrv_OutputFormat_Set(void);
void ncDrv_OutputFormat_Set_Flicker(void);

BOOL MW_OperationFPS_Control(void);
BOOL MW_OperationSize_Control(void);


#endif

