/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	File	: MD_Drv.c		
*	Brief	: This file is MD API for NEXTCHIP standard library
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2016.01.26		Leo.Sim	    1.0		Initial  Revision
********************************************************************************/
#include "API_GlobalHeader.h"
#include "Drv_GlobalHeader.h"

#define MD_BLOCK_SIZE		32L		 /* 1 BLOCK = 32 PIXEL */
#define MD_AREA_COUNT		4L
#define MD_SW_AREA_OFFSET	5L
#define MD_IP_AREA_OFFSET	7L

#define MD_SW_REG_ADDR_MODE	ADDR_MD1_TRANS
#define MD_SW_REG_ADDR_AREA	ADDR_MD1_X
#define MD_IP_ALARM_WINDOW	(ISPGET08(aIP_BMD_MD_INT_WIN3_EN) & 0x0F)

//============================================================================
//      Function
//============================================================================
void ncDrv_MD_ReSize(void)
{
    typedef union{
        UCHAR SIZE[4];
        struct{
            UCHAR XPOS         :6;
            UCHAR X0_RESERVE   :2;
            UCHAR YPOS         :6;
            UCHAR X1_RESERVE   :2;
            UCHAR XSIZE        :6;
            UCHAR Y0_RESERVE   :2;
            UCHAR YSIZE        :6;
            UCHAR Y1_RESERVE   :2;
        }Info;
    } STRUCT_MD_SIZE;
    
    STRUCT_MD_SIZE* MDSize;
    UCHAR area;

    for(area=0L; area < MD_AREA_COUNT; area++)
    {
        MDSize = (STRUCT_MD_SIZE*)(MD_SW_REG_ADDR_AREA + (area * MD_SW_AREA_OFFSET));

        ISPSET08((aIP_BMD_MD0_WIN0_HST+(area * MD_IP_AREA_OFFSET)+0), ((OUTPUT_SIZE==INPUT_SIZE) ? MDSize->Info.XPOS : (USHORT)((FLOAT)MDSize->Info.XPOS/1.5)));
        ISPSET08((aIP_BMD_MD0_WIN0_HST+(area * MD_IP_AREA_OFFSET)+1), ((OUTPUT_SIZE==INPUT_SIZE) ? MDSize->Info.YPOS : (USHORT)((FLOAT)MDSize->Info.YPOS/1.5)));
        ISPSET08((aIP_BMD_MD0_WIN0_HST+(area * MD_IP_AREA_OFFSET)+2), ((OUTPUT_SIZE==INPUT_SIZE) ? MDSize->Info.XSIZE : (USHORT)((FLOAT)MDSize->Info.XSIZE/1.5)));
        ISPSET08((aIP_BMD_MD0_WIN0_HST+(area * MD_IP_AREA_OFFSET)+3), ((OUTPUT_SIZE==INPUT_SIZE) ? MDSize->Info.YSIZE : (USHORT)((FLOAT)MDSize->Info.YSIZE/1.5)));        
    }
}

void ncDrv_MD_Mirror(void)
{
#define MD_SW_X_ADDR 	MD_SW_REG_ADDR_AREA
#define MD_ISP_X_ADDR 	aIP_BMD_MD0_WIN0_HST

	UCHAR area=0;
	UCHAR StartX, Width, XPos = 0;
	UCHAR SwAddrOffset = 0;	
	
	for(area = 0L; area < MD_AREA_COUNT; area ++)
	{
		SwAddrOffset = area * MD_SW_AREA_OFFSET;
		
		StartX = ISPGET08(MD_SW_X_ADDR + SwAddrOffset);		//xstart address
		Width = ISPGET08(MD_SW_X_ADDR + 2L + SwAddrOffset);	//width address
		XPos = ISPGET08(aIP_BMD_HBNUM)-(StartX + Width);

		ISPSET08((MD_SW_X_ADDR + SwAddrOffset), XPos);			//sw reg
	}
    ncDrv_MD_ReSize();	
}

void ncDrv_MD_Flip(void)
{
#define MD_SW_Y_ADDR 	MD_SW_REG_ADDR_AREA	+ 1L
#define MD_ISP_Y_ADDR 	aIP_BMD_MD0_WIN0_HST + 1L

	UCHAR area=0;
	UCHAR StartY = 0;
	UCHAR Height = 0;
	UCHAR YPos = 0;
	UCHAR SwAddrOffset = 0;	
	
	for(area = 0L; area < MD_AREA_COUNT; area ++)
	{
		SwAddrOffset = area * MD_SW_AREA_OFFSET;
		
		StartY = ISPGET08(MD_SW_Y_ADDR + SwAddrOffset);		//Ystart address
		Height = ISPGET08(MD_SW_Y_ADDR + 2L + SwAddrOffset);	//Height address
		YPos = ISPGET08(aIP_BMD_VBNUM)-(StartY + Height);

		ISPSET08((MD_SW_Y_ADDR + SwAddrOffset), YPos);			//sw reg
	}
    ncDrv_MD_ReSize();
}


UCHAR ncDrv_MD_Auto(void)
{
#define GRID_OUTLINE			0x80
#define GRID_OUTLINE_BLINK		0x20
#define GRID_BLOCK				0x10

#define CLEAR_MOTION_VIEW		GRID_OUTLINE | GRID_BLOCK

	typedef enum{
		MD_VIEW_OFF =0,			// 0x00
		MD_VIEW_BLOCK,			// 0x10
		MD_VIEW_OUTLINE,			// 0x80
		MD_VIEW_BLOCK_OUTLINE,	// 0x90
		MD_VIEW_MAX
	}MD_VIEW_TYPE;
	
 	UCHAR MotionViewType[MD_VIEW_MAX] = {0x00, 0x10, 0x80, 0x90};		//GRID, OUTLINE, GRID+BLINKING, OUTLINE+BLINKING
	UCHAR AlarmType = MotionViewType[rSWReg.Category.MD.Reg.MD_ALARM_VIEW_TYPE];
	UCHAR OSDAlarmPosY = 0;

	if(sGco.MonitorOutput != eMONITOR_CVBS)
		OSDAlarmPosY =  rSWReg.Category.MD.Reg.OSD_Y_HDSDI;
	else
	{
		switch(rSWReg.Category.CVBS.Reg.CVBS_OUTPUT_SIZE)
		{
			case eCVBS_H_960H:	OSDAlarmPosY = rSWReg.Category.MD.Reg.OSD_Y_CVBS_960H;	break;		
			case eCVBS_H_1280H:	
			default:            OSDAlarmPosY = rSWReg.Category.MD.Reg.OSD_Y_CVBS_1280H;	break;
		}
	}

	 /* AUTO FUCTION DISABLE IN OSD...OTHER ELSE */	       /* MANUAL DCP ����ȯ�濡���� MOTION CLEAR */
	if(rSWReg.Category.MD.Reg.MD_AUTO_EN == STATE_OFF || rIP_DPC_LINE_EN == STATE_ON)
	{
		//Modification is required
		//if(sHalTimer2.MotionAlarmOn == STATE_ON)
		{
			//Modification is required
			//sHalTimer2.MotionAlarmOn = STATE_OFF;
	    		BitsClear(ISPGET08(aIP_BMD_MD0_WIN0_OUTLN_EN), CLEAR_MOTION_VIEW);
	    		BitsClear(ISPGET08(aIP_BMD_MD0_WIN1_OUTLN_EN), CLEAR_MOTION_VIEW);
	    		BitsClear(ISPGET08(aIP_BMD_MD1_WIN0_OUTLN_EN), CLEAR_MOTION_VIEW);
	    		BitsClear(ISPGET08(aIP_BMD_MD1_WIN1_OUTLN_EN), CLEAR_MOTION_VIEW);
#if 0
			APP_OSDPrint_String(OSDAlarmPosY, sMwOsd.CenterPosX-7L, (UCHAR*)"                ");
#endif
			//HAL_GPIO_Set(rSWReg.Category.GPIO.Reg.GPO_MOTION_ALARM, !rSWReg.Category.GPIO.Reg.GPO_MOTION_ALARM_ACTIVE);
			rSWReg.Category.MD.Reg.MD_AREA_STATUS = rSWReg.Category.GPIO.Reg.GPO_MOTION_ALARM_ACTIVE ? MD_IP_ALARM_WINDOW : ~MD_IP_ALARM_WINDOW;
		} 
		return 0L;
	}

	 /* AUTO FUNCTION ENABLE */
	//Modification is required
	//if(sHalTimer2.MotionAlarmOn == STATE_ON && sHalTimer2.MotionAlarmCount < rSWReg.Category.MD.Reg.MD_ALARM_TIME)
	if(1)
	{ /* [2014/2/20] JWLee : MOTION DETECTED */
		if(rSWReg.Category.MD.Reg.MD_ALARM_OSD_EN == STATE_ON)
#if 0
			APP_OSDPrint_String(OSDAlarmPosY, sMwOsd.CenterPosX-7L, (UCHAR*)"MOTION DETECTED");
#endif

		if(rSWReg.Category.MD.Reg.MD_ALARM_GPO_EN == STATE_ON)
#if 0
		
			HAL_GPIO_Set(rSWReg.Category.GPIO.Reg.GPO_MOTION_ALARM, rSWReg.Category.GPIO.Reg.GPO_MOTION_ALARM_ACTIVE);
#endif

		//MOTION VIEW TYPE & STATUS REGISTER[BIT]
		if(rIP_BMD_INT_REG_MD0_WIN0)
		{	
			BitsSet(ISPGET08(aIP_BMD_MD0_WIN0_OUTLN_EN),  AlarmType);		
			rSWReg.Category.GPIO.Reg.GPO_MOTION_ALARM_ACTIVE ? BitSet(rSWReg.Category.MD.Reg.MD_AREA_STATUS,  0L) : BitClear(rSWReg.Category.MD.Reg.MD_AREA_STATUS,  0L);
			rIP_BMD_INT_REG_MD0_WIN0 = 0;
		}
		if(rIP_BMD_INT_REG_MD0_WIN1)
		{
			BitsSet(ISPGET08(aIP_BMD_MD0_WIN1_OUTLN_EN),  AlarmType);		
			rSWReg.Category.GPIO.Reg.GPO_MOTION_ALARM_ACTIVE ? BitSet(rSWReg.Category.MD.Reg.MD_AREA_STATUS,  1L) : BitClear(rSWReg.Category.MD.Reg.MD_AREA_STATUS,  1L);	
			rIP_BMD_INT_REG_MD0_WIN1 = 0;
		}
		if(rIP_BMD_INT_REG_MD1_WIN0)
		{	
			BitsSet(ISPGET08(aIP_BMD_MD1_WIN0_OUTLN_EN),  AlarmType);		
			rSWReg.Category.GPIO.Reg.GPO_MOTION_ALARM_ACTIVE ? BitSet(rSWReg.Category.MD.Reg.MD_AREA_STATUS,  2L) : BitClear(rSWReg.Category.MD.Reg.MD_AREA_STATUS,  2L);
			rIP_BMD_INT_REG_MD1_WIN0 = 0;
		}
		if(rIP_BMD_INT_REG_MD1_WIN1)
		{	
			BitsSet(ISPGET08(aIP_BMD_MD1_WIN1_OUTLN_EN),  AlarmType);		
			rSWReg.Category.GPIO.Reg.GPO_MOTION_ALARM_ACTIVE ? BitSet(rSWReg.Category.MD.Reg.MD_AREA_STATUS,  3L) : BitClear(rSWReg.Category.MD.Reg.MD_AREA_STATUS,  3L);
			rIP_BMD_INT_REG_MD1_WIN1 = 0;
		}
	}

	//Modification is required
	//else if(sHalTimer2.MotionAlarmOn == STATE_ON)		 /* Turn-off the motion alarm. Execute One time */
	{ /* [2014/2/20] JWLee : DETECTED MOTION CLEAR */
		//Modification is required
		//sHalTimer2.MotionAlarmOn = STATE_OFF;
#if 0
		APP_OSDPrint_String(OSDAlarmPosY, sMwOsd.CenterPosX-7L, (UCHAR*)"                ");
#endif
//		HAL_GPIO_Set(rSWReg.Category.GPIO.Reg.GPO_MOTION_ALARM, !rSWReg.Category.GPIO.Reg.GPO_MOTION_ALARM_ACTIVE);
		rSWReg.Category.MD.Reg.MD_AREA_STATUS = rSWReg.Category.GPIO.Reg.GPO_MOTION_ALARM_ACTIVE ? MD_IP_ALARM_WINDOW : ~MD_IP_ALARM_WINDOW;

		if(rSWReg.Category.MD.Reg.MD_SEL_EN == STATE_OFF && rSWReg.Category.MD.Reg.MD_OUTLINE_EN == STATE_OFF)
		{
			BitsClear(ISPGET08(aIP_BMD_MD0_WIN0_OUTLN_EN), CLEAR_MOTION_VIEW);
			BitsClear(ISPGET08(aIP_BMD_MD0_WIN1_OUTLN_EN), CLEAR_MOTION_VIEW);
			BitsClear(ISPGET08(aIP_BMD_MD1_WIN0_OUTLN_EN), CLEAR_MOTION_VIEW);
			BitsClear(ISPGET08(aIP_BMD_MD1_WIN1_OUTLN_EN), CLEAR_MOTION_VIEW);
		}
	}
	//Modification is required
	//return ((rIP_ADJ_OFFSET_7_0 & 0x0F)<<1L);
}

void ncDrv_MD_Set(void)
{
#define MOTION_AREA_MIN	6L

	typedef	union{
		UCHAR D8;
		struct{
			UCHAR TRANS:		2;
			UCHAR COLOR:		2;
			UCHAR DET_DISP_EN:	1;
			UCHAR SEL_TYPE:		3;	//5: blink, 6:grid type, 7:outline_en
		}B8;
	}STRUCT_MD_MODE;

	typedef enum{
		MD_SBLK_OFF =0,	// 0x06
		MD_SBLK_GRID,		// 0x07
		MD_SBLK_OUTLINE,	// 0x05
		MD_SBLK_MAX
	}MD_SEL_TYPE;
	
	STRUCT_MD_MODE SwMDMode;
	UCHAR area = 0;	
	UCHAR SelType[MD_SBLK_MAX] ={0x00, 0x07, 0x05};		//OFF, GRID BLINKING, OUTLINE BLINKING

	rIP_BMD_VBNUM = sGco.FrameSize.SizeV>>5L;	 /* [2014/2/27] JWLee : divided by BLOCK_SIZE(32) */
	rIP_BMD_HBNUM = sGco.FrameSize.SizeH>>5L;	 /* [2014/2/27] JWLee : divided by BLOCK_SIZE(32) */
	rIP_BMD_OFFSET_V_9_8 = 0L;
	rIP_BMD_OFFSET_V_7_0 = (sGco.FrameSize.SizeV%MD_BLOCK_SIZE)>>1L;
	rIP_BMD_OFFSET_H_9_8 = 0L;
	rIP_BMD_OFFSET_H_7_0 = ((sGco.FrameSize.SizeH%MD_BLOCK_SIZE)+H_ACTIVE_OFFSET)>>1L;

	rIP_BMD_EN = rSWReg.Category.MD.Reg.MD_MODE;
	rIP_BMD_MD0_THLV_7_0  = 202L - (rSWReg.Category.MD.Reg.MD_SENS_AREA_1_2 << 1L);
	rIP_BMD_MD1_THLV_7_0  = 202L - (rSWReg.Category.MD.Reg.MD_SENS_AREA_3_4 << 1L);

	BitsClear(ISPGET08(aIP_BMD_MD0_G_EN), 0x0F);

	for(area = 0L; area < MD_AREA_COUNT; area++)
	{
		//______________________________GET AREA INFORM_________________________________//

		SwMDMode.D8 = ISPGET08(MD_SW_REG_ADDR_MODE + (area * MD_SW_AREA_OFFSET));

        SwMDMode.B8.TRANS = 3 - SwMDMode.B8.TRANS;
		//________________________________MANIPULATE____________________________________//

		if(area == rSWReg.Category.MD.Reg.MD_SEL_AREA && rSWReg.Category.MD.Reg.MD_SEL_EN == STATE_ON)
		{
			SwMDMode.B8.SEL_TYPE = SelType[rSWReg.Category.MD.Reg.MD_SEL_BLINK_TYPE];
		}
		else
		{
			if(rSWReg.Category.MD.Reg.MD_OUTLINE_EN)	SwMDMode.B8.SEL_TYPE = 0x04;		//Outline On
			else								    SwMDMode.B8.SEL_TYPE = 0x00;
		}

		//________________________________APPLY_________________________________________//

//		if(area < 2L)		AddrOffset = 0L;		//MD AREA 1,2
//		else				AddrOffset = 4L;		//MD ARAA 3,4

        ISPSET08(aIP_BMD_MD0_G_EN, (ISPGET08(aIP_BMD_MD0_G_EN)| (BitCheck(rSWReg.Category.MD.Reg.MD_AREA_ON, area) << (3L -area))));
		ISPSET08((aIP_BMD_MD0_WIN0_TRANS + (area * MD_IP_AREA_OFFSET)), SwMDMode.D8&0xEF);

		/* [2014/11/21] jonghyun : STD-1 */
		//{
		ISPSET08((aIP_BMD_MD0_WIN0_TRANS +5+ (area * MD_IP_AREA_OFFSET)) , 0x0A);		//BMD_MDx_WINx_THCNT_TH_7_0	
		ISPSET08((aIP_BMD_MD0_WIN0_TRANS +6+ (area * MD_IP_AREA_OFFSET)) , 0x00);		//BMD_MDx_WINx_THCNT_TH_10_8
		//}
	}
	
    ncDrv_MD_ReSize();
}

void ncDrv_MD_SetFlicker(void)
{
	//DEBUGMSG(MSGWARN, "ncDrv_MD_SetFlicker\n");
	
	rIP_BMD_EN = 1;
	rIP_BMD_HBNUM = 0x28;
	rIP_BMD_VBNUM = 0x17;

	 rIP_BMD_MD0_G_EN =1;
	 rIP_BMD_MD1_G_EN =1;

	rIP_BMD_MD0_WIN0_EN =1;
	rIP_BMD_MD0_WIN1_EN =1;
	rIP_BMD_MD1_WIN0_EN =1;
	rIP_BMD_MD1_WIN1_EN =1;




	 
	 
	rIP_BMD_OFFSET_H_7_0 =0;
	rIP_BMD_OFFSET_H_9_8 =0;
	rIP_BMD_OFFSET_V_7_0 =0;
	rIP_BMD_OFFSET_V_9_8 =0;
	rIP_BMD_SUM_SHIFT    =0;

	
	
	rIP_BMD_BLK_INCLV=0;
	

	rIP_BMD_MD_INT_WIN3_EN=1;
	rIP_BMD_MD_INT_WIN2_EN=1;
	rIP_BMD_MD_INT_WIN1_EN=1;
	rIP_BMD_MD_INT_WIN0_EN=1;
	rIP_BMD_MD_CAP_WIN3_EN=1;
	rIP_BMD_MD_CAP_WIN2_EN=1;
	rIP_BMD_MD_CAP_WIN1_EN=1;
	rIP_BMD_MD_CAP_WIN0_EN=1;


	


	rIP_BMD_MD0_WIN0_OUTLN_EN    =0;
	rIP_BMD_MD0_WIN0_OUTLN_TYPE  =0;
	rIP_BMD_MD0_WIN0_OUTLN_BLK   =0;
	rIP_BMD_MD0_WIN0_DPEN        =0;   
	rIP_BMD_MD0_WIN0_TRANS   	 =0;    
	
	
	rIP_BMD_MD0_WIN1_OUTLN_EN    =0;
	rIP_BMD_MD0_WIN1_OUTLN_TYPE  =0;
	rIP_BMD_MD0_WIN1_OUTLN_BLK   =0;
	rIP_BMD_MD0_WIN1_DPEN        =0;   
	rIP_BMD_MD0_WIN1_TRANS   	 =0;    


	rIP_BMD_MD1_WIN0_OUTLN_EN    =0;
	rIP_BMD_MD1_WIN0_OUTLN_TYPE  =0;
	rIP_BMD_MD1_WIN0_OUTLN_BLK   =0;
	rIP_BMD_MD1_WIN0_DPEN        =0;   
	rIP_BMD_MD1_WIN0_TRANS   	 =0;    


	rIP_BMD_MD1_WIN1_OUTLN_EN    =0;
	rIP_BMD_MD1_WIN1_OUTLN_TYPE  =0;
	rIP_BMD_MD1_WIN1_OUTLN_BLK   =0;
	rIP_BMD_MD1_WIN1_DPEN        =0;   
	rIP_BMD_MD1_WIN1_TRANS   	 =0;    


	rIP_BMD_MD0_WIN0_CLOLR       =0;
	rIP_BMD_MD0_WIN1_CLOLR       =1;
	rIP_BMD_MD1_WIN0_CLOLR       =2;
	rIP_BMD_MD1_WIN1_CLOLR       =3;
	

	rIP_BMD_MD0_WIN0_HST        =0x01; 
	rIP_BMD_MD0_WIN0_VST        =0x00;
	rIP_BMD_MD0_WIN0_WIDTH      =0x25; 
	rIP_BMD_MD0_WIN0_HEIGHT     =0x0B; 
	
	rIP_BMD_MD0_WIN1_HST      =0x01;    
	rIP_BMD_MD0_WIN1_VST      =0x0B;   
	rIP_BMD_MD0_WIN1_WIDTH    =0x25;   
	rIP_BMD_MD0_WIN1_HEIGHT   =0x0B;   

	rIP_BMD_MD1_WIN0_HST       =0x00;   
	rIP_BMD_MD1_WIN0_VST       =0x00;  
	rIP_BMD_MD1_WIN0_WIDTH     =0x27;  
	rIP_BMD_MD1_WIN0_HEIGHT    =0x16;  

	rIP_BMD_MD1_WIN1_HST      =0x0;   
	rIP_BMD_MD1_WIN1_VST      =0x0;  
	rIP_BMD_MD1_WIN1_WIDTH    =0x0;  
	rIP_BMD_MD1_WIN1_HEIGHT   =0x0;  

	rIP_BMD_INT_REG_MD0_WIN0 =1;
	rIP_BMD_INT_REG_MD0_WIN1 =1;
	rIP_BMD_INT_REG_MD1_WIN0 =1;
	rIP_BMD_INT_REG_MD1_WIN1 =1;


	rIP_BMD_GAIN = 0x40;


	rIP_BMD_MD0_THLV_7_0=0x08;
	rIP_BMD_MD0_THLV_9_8=0;
	rIP_BMD_MD1_THLV_7_0=0x70;
	rIP_BMD_MD1_THLV_9_8=0;
	rIP_BMD_UPLOAD_TYPE=2;
	rIP_BMD_UPLOAD_BLENDING = 0x20;




}


