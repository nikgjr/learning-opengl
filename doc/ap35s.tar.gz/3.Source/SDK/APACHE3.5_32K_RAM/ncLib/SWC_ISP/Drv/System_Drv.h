
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __DRV_SYSTEM_H__
#define __DRV_SYSTEM_H__

#include "Drv_GlobalVariable.h"


#if 0
#define	SFLASH_MDPC_POS_ADDR					0x000010						//   MANUAL DPC ADDRESS 	: 32 * 4
#define	SFLASH_BDPC_INFO_ADDR					0x000090						//   STATIC BLACK DPC NUMBER 	: 4BYTE
#define	SFLASH_BDPC_POS_ADDR					0x000094						//   STATIC WHITE DPC ADDRESS 	: 128 * 4

#define	SFLASH_FW_INFO_ADDR						0x001000
#define	SFLASH_MEMORY_INFO_ADDR					0x001004

#define SFLASH_ISP_BUFFER_CVBS_CHECKSUM_ADDR	0x001010
#define SFLASH_ISP_BUFFER_AHD_CHECKSUM_ADDR		0x001012
#define SFLASH_ISP_BUFFER_HDSDI_CHECKSUM_ADDR	0x001014

#define SFLASH_ISP_USER_CVBS_CHECKSUM_ADDR		0x001016
#define SFLASH_ISP_USER_AHD_CHECKSUM_ADDR		0x001018
#define SFLASH_ISP_USER_HDSDI_CHECKSUM_ADDR		0x00101A

#define SFLASH_ISP_FACTORY_CVBS_CHECKSUM_ADDR	0x00101C
#define SFLASH_ISP_FACTORY_AHD_CHECKSUM_ADDR	0x00101E
#define SFLASH_ISP_FACTORY_HDSDI_CHECKSUM_ADDR	0x001020

#define	SFLASH_BOOT_AREA0_ADDR					0x002000
#define	SFLASH_FW_AREA0_ADDR					0x003000
#define	SFLASH_BOOT_AREA1_ADDR					0x02C000
#define	SFLASH_FW_AREA1_ADDR					0x02D000
#define	SFLASH_BOOT_AREA2_ADDR					0x056000
#define	SFLASH_FW_AREA2_ADDR					0x057000

#define	SFLASH_ISPCVBS_BUFFER_ADDR				0x023000
#define	SFLASH_ISPAHD_BUFFER_ADDR				0x026000
#define	SFLASH_ISPHDSDI_BUFFER_ADDR				0x029000
#define	SFLASH_ISPCVBS_USER_ADDR				0x04D000
#define	SFLASH_ISPAHD_USER_ADDR					0x050000
#define	SFLASH_ISPHDSDI_USER_ADDR				0x053000
#define	SFLASH_ISPCVBS_FACTORY_ADDR				0x077000
#define	SFLASH_ISPAHD_FACTORY_ADDR				0x07A000
#define	SFLASH_ISPHDSDI_FACTORY_ADDR			0x07D000
#define	SFLASH_MODE_INFOR_ADDR					0x080000						// CVBS, HDSDI, AHD OUTPUT

#define	SFLASH_WDPC_POS_ADDR				0x081000		// 8K
#define	SFLASH_WDPC_INFO_ADDR				0x082FFB		// STATIC WHITE DPC NUMBER 	: 5BYTE
#define	SFLASH_WDPC_AHD_POS_ADDR			0x083000		// 8K
#define	SFLASH_WDPC_AHD_INFO_ADDR			0x084FFB		// STATIC WHITE DPC NUMBER 	: 5BYTE

#define	SFLASH_WDPC_POS_ADDR_H_FLIP			0x085000
#define	SFLASH_WDPC_INFO_ADDR_H_FLIP		0x086FFB
#define	SFLASH_WDPC_POS_AHD_ADDR_H_FLIP		0x087000
#define	SFLASH_WDPC_INFO_AHD_ADDR_H_FLIP	0x088FFB

#define	SFLASH_WDPC_POS_ADDR_V_FLIP			0x089000
#define	SFLASH_WDPC_INFO_ADDR_V_FLIP		0x08AFFB
#define	SFLASH_WDPC_POS_AHD_ADDR_V_FLIP		0x08B000
#define	SFLASH_WDPC_INFO_AHD_ADDR_V_FLIP	0x08CFFB

#define	SFLASH_WDPC_POS_ADDR_R_FLIP			0x08D000
#define	SFLASH_WDPC_INFO_ADDR_R_FLIP		0x08EFFB
#define	SFLASH_WDPC_POS_AHD_ADDR_R_FLIP		0x08F000
#define	SFLASH_WDPC_INFO_AHD_ADDR_R_FLIP	0x090FFB

#define	SFLASH_MENU_MAP_ADDR			0x091000
#define	SFLASH_MENU_TABLE_ADDR			0x094000

#define	SFLASH_FONTDEFAULT_ADDR			0x091000
#define	SFLASH_FONT32_ADDR				0x095000
#define	SFLASH_FONT48_ADDR				0x0C1000


#define 	FW_AREA						0x80
#define 	CVBS_USER_ISP_AREA			0x81
#define 	CVBS_FACTORY_ISP_AREA		0x82
#define 	MENU_TABLE_AREA				0x83
#define 	MENU_MAP_AREA				0x84
#define 	FONT_DEFAULT					0x87
#define 	FONT_32_32						0x85
#define	    FONT_48_48						0x88
//#define 	FONT_24_24						0x86
#define 	ALL_AREA						0x89
#define 	BOOT_AREA						0x8A
#define 	HDSDI_USER_ISP_AREA			0x8B
#define 	HDSDI_FACTORY_ISP_AREA		0x8C
#define 	AHD_USER_ISP_AREA				0x8D
#define 	AHD_FACTORY_ISP_AREA			0x8E
#endif

/*==============================================================================
	[Board Type]
==============================================================================*/
#define FPGA							0
#define BD3838						1

#define BOARD_TYPE 					BD3838

/*==============================================================================
	[Board CLOCK]
==============================================================================*/
#define CLK_27MHZ					0
#define CLK_54MHZ					1
#define CLK_13_5MHZ					2
#define CLK_6_75MHZ					3

#define MCU_CLK						CLK_54MHZ

/****************************************************************************************************/


#define ADC_BUFFER_MAX      16

typedef enum{
    eADC_CH_0 = 0,
    eADC_CH_1,
    eADC_CH_2,
    eADC_CH_3,
    eADC_CH_MAX
}etADC_CHANNEL_TYPE;

typedef enum
{
    PLL_CH0 = 0,
    PLL_CH1,
    PLL_CH2,
    PLL_CH_MAX,
}etPLL_CHANNEL;

typedef enum
{
    PLL_CLK_27M = 0,
    PLL_CLK_36M,
    PLL_CLK_37p125M,
    PLL_CLK_45M,
    PLL_CLK_48M,
    PLL_CLK_54M,
    PLL_CLK_72M,
    PLL_CLK_74p25M,
    PLL_CLK_90M,
    PLL_CLK_96M,
    PLL_CLK_108M,
    PLL_CLK_120M,    
    PLL_CLK_144M,
    PLL_CLK_148p5M,
    PLL_CLK_166p5M,
    PLL_CLK_333M,    
    PLL_CLK_MAX,
}etPLL_CLOCK;

typedef struct
{
	UCHAR 	ADCValue[4];

	union{
		UCHAR All;
		struct{
			UCHAR	AE:			1;      /* Auto Exposure */
			UCHAR	AWB:		1;      /* Auto White Blance */
			UCHAR	AFT:		1;      /* Auto Function Tasks */
			UCHAR	B3:			1;
			UCHAR	B4:			1;
			UCHAR	B5:			1;
			UCHAR	B6:			1;
			UCHAR	SpiEnable:	1;
		}Run;
	}Control;

}STRUCT_MW_SYSTEM;
extern STRUCT_MW_SYSTEM	sMwSystem;

typedef struct{
    STRUCT_I2C_CONTROL Sensor;
    STRUCT_I2C_CONTROL NICP;
    STRUCT_I2C_CONTROL TW6872;
    STRUCT_I2C_CONTROL Sil9034;
}STRUCT_EXTCOMM_I2C;

typedef struct{
    STRUCT_SPI_CONTROL Sensor;
    STRUCT_SPI_CONTROL NICP;
    STRUCT_SPI_CONTROL Flash;
}STRUCT_EXTCOMM_SPI;

typedef struct{
    STRUCT_EXTCOMM_I2C  I2C;
    STRUCT_EXTCOMM_SPI  SPI;
}STRUCT_EXTCOMM_TYPE;

extern STRUCT_EXTCOMM_TYPE	sExtComm;

typedef struct
{
    USHORT SizeH;
    USHORT SizeV;
}stIMAGE_SIZE;

typedef struct
{
    stIMAGE_SIZE Total;
    stIMAGE_SIZE Active;
}stIMAGE_SIZE_INFO;


typedef struct
{
    etFRAME_SIZE Size;
    etFRAME_RATE Rate;
}stFRAME_INFO;

typedef struct
{
    BOOL    Initializing;       /* BOOTING */
    stIMAGE_SIZE FrameSize;                 /* FOR OSD AREA(PM, MOTION, DEFOG ...) */
    stIMAGE_SIZE_INFO InputSize;
    stIMAGE_SIZE_INFO OutputSize;
    stIMAGE_SIZE_INFO CVBSSize;

    stFRAME_INFO InputFrame;                /* SENSOR OUTPUT FRAME */
    stFRAME_INFO OutputFrame;               /*    ISP OUTPUT FRAME */

    etMONITOR_OUT_MODE  MonitorOutput;

    UINT32   DDRADDDPC1;
    UINT32   DDRADDDPC2;
    UINT32   DDRADDOSD;

    UCHAR   MonitorOutputEn;
    
    BOOL    FrcResetFlag;
    
    union
    {
        UCHAR D8;
        struct
        {
            UCHAR   AHDMODE_PortNum:        7;
            UCHAR   Reserved:               1;
        }B8;
    }GPI;
    
}STRUCT_GLOBAL_CONSUMER_OPTION;

extern STRUCT_GLOBAL_CONSUMER_OPTION   sGco;

void ncDrv_VSIN_Skip(UCHAR Skip);
void ncDrv_VSIP_Skip(UCHAR Skip);
void ncDrv_VSOP_Skip(UCHAR Skip);
UCHAR ncDrv_ADCValue_Get(etADC_CHANNEL_TYPE Channel);
void ncDrv_ADCAverage_Task(void);
void ncDrv_StatusRegister_LinkFunction_Set(UINT32 waddr, UCHAR wdata);

void ncDrv_MCU_Peripherals_Initialize_Set(void);

void ncDrv_VariableInitialize_Boot_Set(void);
void ncDrv_SDR_Phase_Search(void);

void ncDrv_MCU_Synchronization_Task(void);


void ncDrv_Sensor_Communication_Set(void);
void ncDrv_Sensor_Reset(void);

void ncDrv_DDRMemory_Set(INT32 Add, UCHAR Data[64]);
void ncDrv_DDRMemory_Get(INT32 Add, UCHAR * Data);
void ncDrv_DDRMemory_Address_Set(void);

void ncDrv_FWIsp_Reset(void);
void ncDrv_FWSys_Reset(void);
void ncDrv_FWSys_ChangeMode_Reset(UCHAR Mode);


void ncDrv_MainFRC_Reset(void);
void ncDrv_MainFRC_Reset_Control(void);


#endif

