/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#include "Lib_GlobalHeader.h"
#include "Api_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Sensor_IMX224_Drv.h"

#include "SSP_Lib.h"
#include "SCU_Lib.h"

#if (SENSOR_SELECT == SONY_IMX224MQR)
void __test_imx_hwreset1(void)
{
    eGPIO_GROUP group = GPIO_GROUP_A;
    eGPIO_PORT  port  = GPIO_PORT20;

    // Set GPIO OUTPUT
    ncLib_GPIO_Control(GCMD_GPIO_ENA, group, port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, group, port, GPIO_DIR_OUT, CMD_END);

    // HIGH
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, group, port, GPIO_HIGH, CMD_END);
    APACHE_SYS_mDelay(100);

    // LOW
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, group, port, GPIO_LOW, CMD_END);
    APACHE_SYS_mDelay(100);

    // HIGH
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, group, port, GPIO_HIGH, CMD_END);
    APACHE_SYS_mDelay(100);
}
void APACHE_SSP_Init(UINT32 nChNum)
{
    INT32 ret;
    tSSP_INIT_PARAM tSSPParam;


    /*
    * Open Synchronous Serial Port Interface.
    */
 /*   ret = ncLib_SSP_Open(ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_SSPI, CMD_END));	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "SSP Open Error!\n");
    }*/


    /*
    * Init SSP Channel
    */
    tSSPParam.mFormat       = SSP_FMT_SPI;
    tSSPParam.mMode         = SSP_MODE_MASTER;
    tSSPParam.mDataWidth    = SSP_DS_8BIT;
    tSSPParam.mBitRate      = 1;
    tSSPParam.mTxIntEn      = FALSE; 
    tSSPParam.mRxIntEn      = FALSE;
    tSSPParam.mSPO          = SSP_SPO_HIGH;
    tSSPParam.mSPH          = SSP_SPH_HIGH;	
    ret = ncLib_SSP_Control(GCMD_SSP_INIT_CH, nChNum, &tSSPParam, CMD_END);	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "SSP Init Error!\n");
    } 
}

void APACHE_SSP_DeInit(UINT32 nChNum)
{
    INT32 ret;


    /*
    * Deinit SSP Channel
    */
    ret = ncLib_SSP_Control(GCMD_SSP_DEINIT_CH, nChNum, CMD_END);	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "SSP DeInit Error!\n");
    } 


    /*
    * Close Synchronous Serial Port Interface.
    */
/*    ret = ncLib_SSP_Close();	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "SSP Close Error!\n");
    }*/
}

UINT8 __reverse_byte1(UINT8 byte)
{
    UINT8 i;
    UINT8 byte_rev   = 0x0;
    const UINT8 BIT8[8]    = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
    const UINT8 BIT8REV[8] = {0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01};

    for(i=0;i<8;i++)
    {
        if(byte&BIT8[i]) byte_rev |= BIT8REV[i];
    }

    return byte_rev;
}
UINT8 __test_imx_read1(UINT32 nChNum, UINT8 ChipID, UINT8 Addr)
{
    UINT8 Command[2];    
    UINT8 Data;
    
    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, nChNum, CMD_END);	

    Command[0] = __reverse_byte1(((1<<7)|ChipID));
    Command[1] = __reverse_byte1(Addr);
    ncLib_SSP_Write(nChNum, Command, 2);
    ncLib_SSP_Read(nChNum, &Data, 1);    

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, nChNum, CMD_END);	

    return __reverse_byte1(Data);
}
void __test_imx_regdump1(UINT32 nChNum, UINT8  ChipID)
{
    UINT8  Addr;
    
    for(Addr=0; Addr<0xFF; Addr++)
    {
        DEBUGMSG(MSGINFO, " IMX_Bank%d : Addr[0x%02X] Reg[0x%02X]\n", ChipID, Addr, __test_imx_read1(nChNum, ChipID, Addr));
    }
}

void __test_imx_write1(UINT32 nChNum, UINT8 ChipID, UINT8 Addr, UINT8 Data)
{
    UINT8 Command[3];
    
    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, nChNum, CMD_END);	

    Command[0] = __reverse_byte1(ChipID);
    Command[1] = __reverse_byte1(Addr);
    Command[2] = __reverse_byte1(Data);
    ncLib_SSP_Write(nChNum, Command, 3);

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, nChNum, CMD_END);	
}

void ncDrv_SENSOR_Initial_Set(void)
{
    UINT32 nChNum = 1;   // LVDS Board (SSP1) 
    UINT8  ChipID;
    UINT8  data;
    UINT32 LVDS_ISP, WDR_ISP;
    UINT8 SEL_SENSOR;

    DEBUGMSG(MSGINFO, " >> IMX244 Init\n");

    // Sensor Reset
    __test_imx_hwreset1();

	SEL_SENSOR = 0x10;
    REGRW8(0x30f00000,0x0011) = SEL_SENSOR;
    
    // Init SSP Channel
    APACHE_SSP_Init(nChNum);

#if FPGA_MODE
    LVDS_ISP = REGRW32(0x30300000,0x00B0) | (1<<30);
    REGRW32(0x30300000,0x00B0) = LVDS_ISP; 

    WDR_ISP = REGRW32(0x30300000,0x00BC) | (1<<1);
    REGRW32(0x30300000,0x00BC) = WDR_ISP; 
#endif   

     ChipID = 0x02;	
    __test_imx_write1(nChNum, ChipID, 0x03, 0x01);	//RESET=1
    APACHE_SYS_mDelay(10);
    __test_imx_write1(nChNum, ChipID, 0x03, 0x00);	//RESET=0
    __test_imx_write1(nChNum, ChipID, 0x02, 0x01);	//XMSTA=1
    APACHE_SYS_mDelay(10);

    __test_imx_write1(nChNum, ChipID, 0x00, 0x01);
    __test_imx_write1(nChNum, ChipID, 0x01, 0x00);
    
////////////////// IMX224 Sensor DOL Mode Setting //////////////////
// HD // 10bits LVDS Output 4ch
////////////////// Chip ID = 02h //////////////////////
	if(rSWReg.Category.WDR.Reg.IMX224_OUTPUT_BIT == 0)	//10Bit
	{
        __test_imx_write1(nChNum, ChipID, 0x05, 0x00); 
        __test_imx_write1(nChNum, ChipID, 0x44, 0xE0);   // LVDS 4ch Output // Number of Output bit Setting
    }
    else
    {
        __test_imx_write1(nChNum, ChipID, 0x05, 0x01); 
        __test_imx_write1(nChNum, ChipID, 0x44, 0xE1);   // LVDS 4ch Output // Number of Output bit Setting
    }
    
    __test_imx_write1(nChNum, ChipID, 0x06, 0x00); //Drive Mode : Fixed to ��0h��
    __test_imx_write1(nChNum, ChipID, 0x07, 0x10); //Window mode : HD Mode(720p)

    
    if(sWdr.Type == eWDRTYPE_OFF)		// Normal
	{
       __test_imx_write1(nChNum, ChipID, 0x0C, 0x00); //WDMODE : Normal Mode // WDSEL : Normal	
    }
    else if(sWdr.Type == eWDRTYPE_DOL2)		// DOL2 
    {
        __test_imx_write1(nChNum, ChipID, 0x0C, 0x11); //WDMODE : DOL Mode // WDSEL : DOL2
    }
    else if(sWdr.Type == eWDRTYPE_DOL3)
    {
      __test_imx_write1(nChNum, ChipID, 0x0C, 0x21); //WDMODE : DOL Mode // WDSEL : DOL3    
    }
   
#if 0
    __test_imx_write1(nChNum, ChipID, 0x09, 0x01); 		
    __test_imx_write1(nChNum, ChipID, 0x18, 0xEE); // VMAX : 2EEh
    __test_imx_write1(nChNum, ChipID, 0x19, 0x02); // 
    __test_imx_write1(nChNum, ChipID, 0x1B, 0xE4); // HMAX : 672h
    __test_imx_write1(nChNum, ChipID, 0x1C, 0x0C); // 

#endif 
#if 0
//    if(sGco.InputFrame.Rate == eFRAME_RATE_30)
 //   {
        __test_imx_write1(nChNum, ChipID, 0x09, 0x02); 		
        __test_imx_write1(nChNum, ChipID, 0x18, 0xEE); // VMAX : 2EEh
        __test_imx_write1(nChNum, ChipID, 0x19, 0x02); // 
        __test_imx_write1(nChNum, ChipID, 0x1B, 0xC8); // HMAX : 672h
        __test_imx_write1(nChNum, ChipID, 0x1C, 0x19); // 
//    }
#endif
#if 1
   // else //60p 
 //   {
        __test_imx_write1(nChNum, ChipID, 0x09, 0x01); 		
        __test_imx_write1(nChNum, ChipID, 0x18, 0xEE); // VMAX : 2EEh
        __test_imx_write1(nChNum, ChipID, 0x19, 0x02); // 
        __test_imx_write1(nChNum, ChipID, 0x1B, 0xE4); // HMAX : 672h
        __test_imx_write1(nChNum, ChipID, 0x1C, 0x0C); //
//    }
#endif

    
    ////////////////// INCK Setting //////////////////
    //#ifdef 37.125Mhz
    __test_imx_write1(nChNum, ChipID, 0x5C, 0x20);
    __test_imx_write1(nChNum, ChipID, 0x5D, 0x00);
    __test_imx_write1(nChNum, ChipID, 0x5E, 0x20);
    __test_imx_write1(nChNum, ChipID, 0x5F, 0x00);

#if 0
//#else //74.25Mhz 
	__test_imx_write1(nChNum, ChipID, 0x5C, 0x20);
	__test_imx_write1(nChNum, ChipID, 0x5D, 0x10);
	__test_imx_write1(nChNum, ChipID, 0x5E, 0x20);
	__test_imx_write1(nChNum, ChipID, 0x5F, 0x10);

//#endif
#endif
     ChipID = 0x02;	
     __test_imx_write1(nChNum, ChipID, 0x0A, 0x00); // Black Level : F0h	
 
	if(sWdr.Type == eWDRTYPE_OFF)		// Normal
	{
       __test_imx_write1(nChNum, ChipID, 0x43, 0x01); // DOLSCDEN : Pattern2 // DOLSYDINFOEN/HINFOEN : Identification Code Setting

    }
    else 
    {
        __test_imx_write1(nChNum, ChipID, 0x43, 0x03); // DOLSCDEN : Pattern2 // DOLSYDINFOEN/HINFOEN : Identification Code Setting
    }



    ChipID = 0x03;			
    __test_imx_write1(nChNum, ChipID, 0x44, 0x07); // CMOS / LVDS Output
  //  __test_imx_write1(nChNum, ChipID, 0x08, 0x00); // XVS / XHS output subsampling specified


    if(sWdr.Type == eWDRTYPE_DOL2)		// DOL2
    {       
        __test_imx_write1(nChNum, ChipID, 0x09, 0x01); // DOL2
        __test_imx_write1(nChNum, ChipID, 0x08, 0x00); // XVS/XHS Normal
    }

#if 1

    if(sWdr.Type == eWDRTYPE_DOL3)		// DOL3
    {
        __test_imx_write1(nChNum, ChipID, 0x09, 0x03); // DOL3
        __test_imx_write1(nChNum, ChipID, 0x08, 0x00); // XVS/XHS Normal
    }
    
#endif
    __test_imx_write1(nChNum, ChipID, 0x0A, 0x00); // DOLHBFIXEN


    ChipID = 0x03;
    __test_imx_write1(nChNum, ChipID, 0x54, 0x00); // DOL Mode

    
    if(sWdr.Type == eWDRTYPE_DOL2)		// DOL2
    {
    	__test_imx_write1(nChNum, ChipID, 0x57, 0xBC); // DOL2 / HD
    	__test_imx_write1(nChNum, ChipID, 0x58, 0x05); //
    }
    if(sWdr.Type == eWDRTYPE_DOL3)		// DOL3
    {
#if 0
    	__test_imx_write1(nChNum, ChipID, 0x57, 0x8B); // DOL3 / HD -> (0x57, 0xD1); // DOL3 / HD
#endif

      	__test_imx_write1(nChNum, ChipID, 0x57, 0x8E); // DOL3 / HD -> (0x57, 0xD1); // DOL3 / HD
    	__test_imx_write1(nChNum, ChipID, 0x58, 0x08); // -> (0x58, 0x03); //
    }
    
    ChipID = 0x02;		
    __test_imx_write1(nChNum, ChipID, 0x0F, 0x00);
    __test_imx_write1(nChNum, ChipID, 0x12, 0x2C);
    __test_imx_write1(nChNum, ChipID, 0x13, 0x01);
    __test_imx_write1(nChNum, ChipID, 0x16, 0x09);
    __test_imx_write1(nChNum, ChipID, 0x1D, 0xC2);
    __test_imx_write1(nChNum, ChipID, 0x70, 0x02);
    __test_imx_write1(nChNum, ChipID, 0x71, 0x01);
    __test_imx_write1(nChNum, ChipID, 0x9E, 0x22);
    __test_imx_write1(nChNum, ChipID, 0xA5, 0xFB);
    __test_imx_write1(nChNum, ChipID, 0xA6, 0x02);
    __test_imx_write1(nChNum, ChipID, 0xB3, 0xFF);
    __test_imx_write1(nChNum, ChipID, 0xB4, 0x01);
    __test_imx_write1(nChNum, ChipID, 0xB5, 0x42);
    __test_imx_write1(nChNum, ChipID, 0xB8, 0x10);
    __test_imx_write1(nChNum, ChipID, 0xC2, 0x01);
    ////////////////// Chip ID = 03h //////////////////////

    ChipID = 0x03;
    __test_imx_write1(nChNum, ChipID, 0x0F, 0x0F);
    __test_imx_write1(nChNum, ChipID, 0x10, 0x0E);
    __test_imx_write1(nChNum, ChipID, 0x11, 0xE7);
    __test_imx_write1(nChNum, ChipID, 0x12, 0x9C);
    __test_imx_write1(nChNum, ChipID, 0x13, 0x83);
    __test_imx_write1(nChNum, ChipID, 0x14, 0x10);
    __test_imx_write1(nChNum, ChipID, 0x15, 0x42);
    __test_imx_write1(nChNum, ChipID, 0x28, 0x1E);
    __test_imx_write1(nChNum, ChipID, 0xED, 0x38);
    ////////////////// Chip ID = 04h //////////////////////??? 

    ChipID = 0x04;
    __test_imx_write1(nChNum, ChipID, 0x0C, 0xCF);
    __test_imx_write1(nChNum, ChipID, 0x4C, 0x40);
    __test_imx_write1(nChNum, ChipID, 0x4D, 0x03);
    __test_imx_write1(nChNum, ChipID, 0x61, 0xE0);
    __test_imx_write1(nChNum, ChipID, 0x62, 0x02);
    __test_imx_write1(nChNum, ChipID, 0x6E, 0x2F);
    __test_imx_write1(nChNum, ChipID, 0x6F, 0x30);
    __test_imx_write1(nChNum, ChipID, 0x70, 0x03);
    __test_imx_write1(nChNum, ChipID, 0x98, 0x00);
    __test_imx_write1(nChNum, ChipID, 0x9A, 0x12);
    __test_imx_write1(nChNum, ChipID, 0x9B, 0xE1);
    __test_imx_write1(nChNum, ChipID, 0x9C, 0x0C);
    // Operation Start
    ////////////////// Chip ID = 02 //////////////////////??? 
    APACHE_SYS_mDelay(100);
    ChipID = 0x02;
    __test_imx_write1(nChNum, ChipID, 0x00, 0x00); // Operation Mode Setting

    APACHE_SYS_mDelay(100);
    ChipID = 0x02;
    __test_imx_write1(nChNum, ChipID, 0x02, 0x00); // Master Mode Operation Start


    if(sWdr.Type == eWDRTYPE_DOL2)		// DOL2
    {
    	__test_imx_write1(nChNum, ChipID, 0x20, 0xFF);    /* MIDDLE */
    	__test_imx_write1(nChNum, ChipID, 0x21, 0x01);    
    	__test_imx_write1(nChNum, ChipID, 0x22, 0x00);    

    	__test_imx_write1(nChNum, ChipID, 0x23, 0x05);    /* SHORT */
    	__test_imx_write1(nChNum, ChipID, 0x24, 0x02);    
    	__test_imx_write1(nChNum, ChipID, 0x25, 0x00);    

    	__test_imx_write1(nChNum, ChipID, 0x2C, 0x09);    /* MIDDLE RANGE */
    	__test_imx_write1(nChNum, ChipID, 0x2D, 0x00);    
    	__test_imx_write1(nChNum, ChipID, 0x2E, 0x00);    
    }
#if 1
    if(sWdr.Type == eWDRTYPE_DOL3)		// DOL3
    {

    
    	__test_imx_write1(nChNum, ChipID, 0x20, 0x08);    /* MIDDLE */
    	__test_imx_write1(nChNum, ChipID, 0x21, 0x00);    
    	__test_imx_write1(nChNum, ChipID, 0x22, 0x00);    

    	__test_imx_write1(nChNum, ChipID, 0x23, 0x06);    /* SHORT */
    	__test_imx_write1(nChNum, ChipID, 0x24, 0x02);    
    	__test_imx_write1(nChNum, ChipID, 0x25, 0x06);    

    	__test_imx_write1(nChNum, ChipID, 0x26, 0x06);    /* LONG */
    	__test_imx_write1(nChNum, ChipID, 0x27, 0x03);    
    	__test_imx_write1(nChNum, ChipID, 0x28, 0x00);    

    	__test_imx_write1(nChNum, ChipID, 0x2C, 0x02);    /* MIDDLE RANGE */
    	__test_imx_write1(nChNum, ChipID, 0x2D, 0x02);    
    	__test_imx_write1(nChNum, ChipID, 0x2E, 0x00);    

    	__test_imx_write1(nChNum, ChipID, 0x2F, 0x02);    /* SHORT RANGE */
    	__test_imx_write1(nChNum, ChipID, 0x30, 0x03);    
    	__test_imx_write1(nChNum, ChipID, 0x31, 0x00);  
    }
#endif

#if 1

         ChipID = 0x03;
    	__test_imx_write1(nChNum, ChipID, 0x57, 0x8e);
    	__test_imx_write1(nChNum, ChipID, 0x58, 0x0B);
    	
        __test_imx_write1(nChNum, ChipID, 0xCD, 0x00);
        __test_imx_write1(nChNum, ChipID, 0xCE, 0x00);
        __test_imx_write1(nChNum, ChipID, 0xCF, 0x00);
        __test_imx_write1(nChNum, ChipID, 0xD0, 0x00);
        __test_imx_write1(nChNum, ChipID, 0xD1, 0x00);
        __test_imx_write1(nChNum, ChipID, 0xD2, 0x00);
        __test_imx_write1(nChNum, ChipID, 0xD3, 0x00);
        __test_imx_write1(nChNum, ChipID, 0xD4, 0x00);
        __test_imx_write1(nChNum, ChipID, 0xDA, 0x00);
        __test_imx_write1(nChNum, ChipID, 0xDD, 0x43);
        __test_imx_write1(nChNum, ChipID, 0xDE, 0x02);
        __test_imx_write1(nChNum, ChipID, 0xDF, 0x23);
        __test_imx_write1(nChNum, ChipID, 0xE0, 0x05);
        __test_imx_write1(nChNum, ChipID, 0xE1, 0x40);

        ChipID = 0x05;

        __test_imx_write1(nChNum, ChipID, 0x54, 0x00);
        __test_imx_write1(nChNum, ChipID, 0x57, 0x8b);
        __test_imx_write1(nChNum, ChipID, 0x58, 0x08);        
#endif

#if 0 // debug
      __test_imx_regdump1(nChNum, 0x02);    
     // __test_imx_regdump1(nChNum, 0x03);    

     //__test_imx_regdump1(nChNum, 0x04);    
      //
     // __test_imx_regdump1(nChNum, 0x05);        
#endif  

    // Deinit SSP Channel
    APACHE_SSP_DeInit(nChNum);



    
}

const STRUCT_SENSOR_INTERFACE_TYPE sSensorInterface = {
		/* [IIF H/V PORCH]         */
		/*       720P HFLIP OFF,ON */    {{{ 0x0C, 0x1E },                /* [2015/08/31] JWLee */
		/*            VFLIP OFF,ON */      { 0x10, 0x08 }},               /* [2015/08/31] JWLee */
		/*      1080P HFLIP OFF,ON */     {{    0,    0 },                /* [2015/08/31] JWLee */
		/*            VFLIP OFF,ON */      {    0,    0 }}},              /* [2015/08/31] JWLee */
		/* [INPUT H TOTAL]         */
		/* WDR OFF  720P PAL, NTSC */  {{{ 0x0A4F, 0x0671 },
		/* WDR OFF 1080P PAL, NTSC */    { 0x13FF, 0x10AA }},
		/* WDR ON   720P PAL, NTSC */   {{ 0x0A4F, 0x1355 },
		/* WDR ON  1080P PAL, NTSC */    { 0x13FF, 0x10AA }}},
};

void ncDrv_SENSOR_FPS_Set(void) 
{
#define SENSOR_H_TOTAL_30P_NTSC		0x19C8	// 6600
#define SENSOR_H_TOTAL_25P_PAL		0x1EF0	// 7920
#define SENSOR_H_TOTAL_60P_NTSC		0xCE4	// 3300
#define SENSOR_H_TOTAL_50P_PAL		0xF78	// 3960
#define SENSOR_H_TOTAL_120P_NTSC		0x672	// 1650
#define SENSOR_H_TOTAL_100P_PAL		0x7BC	// 1980

    UINT32 nChNum = 1;   // LVDS Board (SSP1) 
    UINT8  ChipID;
    USHORT HTotalSize;
    UCHAR FRSEL = __test_imx_read1(nChNum, ChipID,0x09)&0xFC; //(0x0209 & 0xFC);
    
    // Init SSP Channel
    APACHE_SSP_Init(nChNum);
    if(sWdr.Type == eWDRTYPE_DOL3)
    {
        FRSEL = 0;
        HTotalSize = CVBS_FORMAT ? SENSOR_H_TOTAL_120P_NTSC : SENSOR_H_TOTAL_100P_PAL;
    }
    else
    {
        if(sGco.InputFrame.Rate == eFRAME_RATE_30)  // 30/25P
        {
            FRSEL = 2;
    		HTotalSize = CVBS_FORMAT ? SENSOR_H_TOTAL_30P_NTSC : SENSOR_H_TOTAL_25P_PAL;
        }
        else
        {
            FRSEL = 1;
    	    HTotalSize = CVBS_FORMAT ? SENSOR_H_TOTAL_60P_NTSC : SENSOR_H_TOTAL_50P_PAL;
        }
    }    
#if 0
    SENSOR.Write(0x0209, (SENSOR.Read(0x0209)&0xFC)|FRSEL);
    SENSOR.Write(0x021B, HTotalSize);
    SENSOR.Write(0x021C, HTotalSize>>8);
#endif
    ChipID = 0x02;
    __test_imx_write1(nChNum, ChipID, 0x09, (__test_imx_read1(nChNum, ChipID,0x09)&0xFC)|FRSEL); 
    __test_imx_write1(nChNum, ChipID, 0x1B, HTotalSize); 
    __test_imx_write1(nChNum, ChipID, 0x1C, HTotalSize>>8);       
}

void ncDrv_SENSOR_Mirror_Set(UCHAR Mode)
{
#if 0
	USHORT FlipMode = SENSOR.Read(0x8207);

	FlipMode &= 0xFC; // Off
	switch(Mode)
	{
		case eFLIP_MIRROR:  FlipMode |= 0x02;	break;
		case eFLIP_V: 		FlipMode |= 0x01;	break;
		case eFLIP_ROTATE: 	FlipMode |= 0x03;	break;
	}
	SENSOR.Write(0x0207, FlipMode);
#endif
}


const UCHAR SENSOR_DIFF_LIMIT = 0;
const UCHAR SENSOR_EXPOSURE_MIN = 2;
const USHORT SENSOR_VTOTAL_DEFAULT[eSIZE_MAX] = {750, 1125};

#if((OPTION_WDR_TYPE == WDRTYPE_DFRAME_1M)||(OPTION_WDR_TYPE==WDRTYPE_DFRAME_2M))
void ncDrv_SENSOR_WDR_Exposure_Set(UCHAR WDR_Ch)
{
#if 0
#define SENSOR_42DB     0x1A4

    USHORT ExposureLine = 0;
    USHORT VMaxLineBase = SENSOR_VTOTAL_DEFAULT[INPUT_SIZE];
    static USHORT SensorGainL = 0, SensorGainS = 0; 
    static USHORT preGVLineCompL, preGVLineCompS;
        
    if(sMwAeWDR.Tracking.Long.ExposureLine > VMaxLineBase)  sMwAeWDR.Tracking.Long.ExposureLine = 0;
    else                                                    sMwAeWDR.Tracking.Long.ExposureLine = VMaxLineBase - sMwAeWDR.Tracking.Long.ExposureLine;

    if(sMwAeWDR.Tracking.Short.ExposureLine > VMaxLineBase) sMwAeWDR.Tracking.Short.ExposureLine = 0;
    else                                                    sMwAeWDR.Tracking.Short.ExposureLine = VMaxLineBase - sMwAeWDR.Tracking.Short.ExposureLine;   
    
    // Sensor Shutter is applied in the second VSYNC.
    // Sensor AGC is applied in the first VSYNC.
    if(WDR_Ch == DFWDR_SHORT)
    {
        // Short Shutter
        ExposureLine = sMwAeWDR.Tracking.Short.ExposureLine;
        
        // Sensor Gain
        #if 0
        SensorGainS = 0;
        #else
        SensorGainS = ((USHORT)(MW_AE_ConvertGainTodB(sMwAeWDR.Tracking.Long.GV) * 10))>>2;
        if(SensorGainS > (SENSOR_42DB>>2))   SensorGainS = (SENSOR_42DB>>2);
        #endif
        
        // Sensor Gain Set
        SENSOR.Write(0x0214, SensorGainS);
    	SENSOR.Write(0x0215, SensorGainS>>8);
    	
    	SetShort(aIP_ADJ_GAIN_7_0, preGVLineCompL);
    	//SetShort(aIP_AJD_GAIN_S_7_0, 0x80);

    	preGVLineCompS = sMwAeWDR.Tracking.Short.GVCompHS;
    }
    else if(WDR_Ch == DFWDR_LONG)
    {
        // Long Shutter
        ExposureLine = sMwAeWDR.Tracking.Long.ExposureLine;

        // Sensor Gain
        SensorGainL = (USHORT)(MW_AE_ConvertGainTodB(sMwAeWDR.Tracking.Long.GV) * 10);
        if(SensorGainL > SENSOR_42DB)   SensorGainL = SENSOR_42DB;
        
        // Sensor Gain Set
        SENSOR.Write(0x0214, SensorGainL);
    	SENSOR.Write(0x0215, SensorGainL>>8);
	
        //SetShort(aIP_ADJ_GAIN_7_0, 0x80);
        SetShort(aIP_AJD_GAIN_S_7_0, preGVLineCompS);

        preGVLineCompL = sMwAeWDR.Tracking.Long.GVCompHS;
    }

    // Sensor Shutter Set
    SENSOR.Write(0x0221, ((ExposureLine>>8)&0xFF));
    SENSOR.Write(0x0220, (ExposureLine&0xFF));
#endif
}
#endif
#endif



#if (SENSOR_SELECT == SONY_IMX224MQR)||(SENSOR_SELECT == SENSOR_COMMON)
#if (SENSOR_SELECT == SONY_IMX224MQR)
void ncDrv_SENSOR_Exposure_Set(STRUCT_AE_SET_TYPE * AeSet)
#elif (SENSOR_SELECT == SENSOR_COMMON)
void SENSOR_Exposure_Set_IMX224(STRUCT_AE_SET_TYPE * AeSet)
#endif
{
    UINT32 nChNum = 1;   // LVDS Board (SSP1) 
    UINT8  ChipID;
    UINT8  data;

    USHORT  IspDgainAlpha=GAIN_VALUE_MIN;

    AeSet->ExposureLine = AeSet->VTotalLine - AeSet->ExposureLine;
	AeSet->SensorGain = (USHORT)(ncSvc_AE_ConvertGainTodB((GAIN_VALUE_TYPE)AeSet->TotalGain) * 10);

	if(AeSet->SensorGain >0x1A4)	AeSet->SensorGain = 0x1A4;
	
//=======================================================================================
//  ISP & SENSOR Value Write
//=======================================================================================
#if 0
	// SENSUP
	SENSOR.Write(0x0219, ((AeSet->VTotalLine>>8)&0xFF));  
	SENSOR.Write(0x0218, (AeSet->VTotalLine&0xFF));

    if(AeSet->ExposureLine <= SENSOR_EXPOSURE_MIN)
       AeSet->ExposureLine = SENSOR_EXPOSURE_MIN;
       
    // SENSOR SHUTTER
	SENSOR.Write(0x0221, ((AeSet->ExposureLine>>8)&0xFF));    
	SENSOR.Write(0x0220, (AeSet->ExposureLine&0xFF));

	// SENSOR ANALOG GAIN
    SENSOR.Write(0x0214, AeSet->SensorGain);
	SENSOR.Write(0x0215, AeSet->SensorGain>>8);    
#endif
    // Init SSP Channel
    APACHE_SSP_Init(nChNum);

    ChipID = 0x02;		
    // SENSUP
    __test_imx_write1(nChNum, ChipID, 0x19, ((AeSet->VTotalLine>>8)&0xFF)); 
    __test_imx_write1(nChNum, ChipID, 0x18, (AeSet->VTotalLine&0xFF)); 
    
    if(AeSet->ExposureLine <= SENSOR_EXPOSURE_MIN)
       AeSet->ExposureLine = SENSOR_EXPOSURE_MIN;
       
    // SENSOR SHUTTER       
    __test_imx_write1(nChNum, ChipID, 0x21, ((AeSet->ExposureLine>>8)&0xFF)); 
    __test_imx_write1(nChNum, ChipID, 0x20, (AeSet->ExposureLine&0xFF)); 
    
    // SENSOR ANALOG GAIN
    __test_imx_write1(nChNum, ChipID, 0x14, AeSet->SensorGain); 
    __test_imx_write1(nChNum, ChipID, 0x15, AeSet->SensorGain>>8); 
     
    
    APACHE_SSP_DeInit(nChNum);
    
	// ISP DIGITAL GAIN
	ncSvc_AE_IspDGainAlphaSet(IspDgainAlpha);
//=======================================================================================
}
#endif


