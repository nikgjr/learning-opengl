
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/
#include "APACHE35.h"
#include "Drv_GlobalHeader.h"
#include "Svc_GlobalHeader.h"
#include "Api_GlobalHeader.h"

volatile void ncDrv_Delay_Set(INT32 Delay)
{
	volatile ULONG count = 0;

	while(1)
	{
		if(count>Delay)
			break;
		count++;
	}
}

volatile void ncDrv_DelayMs_Set(INT32 Ms)
{
#if 0
	volatile USHORT count;
	
	if(rIP_SEL_MCU_CK == 0x00)//54Mhz
	{
		while(Ms--){
			for(count=0; count<1900; count++);
		}
	}
	else// if(temp == 0x10)//27Mhz
	{
		while(Ms--){
			for(count=0; count<950; count++);
		}
	}
#endif
}

USHORT ncDrv_Divider(USHORT dividend, USHORT divisor)
{
  	ISPSET16(aIP_DIVIDEND_7_0, dividend);
	ISPSET16(aIP_DIVISOR_7_0, divisor);

	if(dividend == 0 || divisor == 0)	return 0;
	
	return ISPGET16(aIP_DIV_QUOTIENT_7_0);

#if 0
    REGRW16(APACHE_ISP_BASE, aIP_DIVIDEND_7_0) =  dividend;
	REGRW16(APACHE_ISP_BASE, aIP_DIVISOR_7_0) = divisor;

	return REGRW16(APACHE_ISP_BASE, aIP_DIV_QUOTIENT_7_0);
#endif
}

FLOAT ncDrv_ConvertHex2Float(USHORT usHex)
{
#define CC_PRECISION    1024L

	FLOAT dCCValue;
	
	if (usHex & 0x0800)
	{
		// negative
		usHex |= 0xF000;
		usHex = (~usHex) + 1;
		dCCValue = (float)usHex / -CC_PRECISION;		// 10 bit precision = 1024
	}
	else
	{
		dCCValue = (float)usHex / CC_PRECISION;		// 10 bit precision = 1024
	}
	
	return dCCValue;
}


FLOAT ncDrv_Transition( FLOAT InputF, FLOAT StartInX,FLOAT EndInX, FLOAT StartOutX,FLOAT EndOutY )
{
	FLOAT FactorOut = 0;
	FLOAT LowIn = StartInX;
	FLOAT HighIn =  EndInX;

	InputF = (InputF>HighIn) ? HighIn : InputF;
	InputF = (InputF<LowIn) ? LowIn : InputF;


	FactorOut =StartOutX+( (InputF - LowIn)*( EndOutY - StartOutX ))/( HighIn - LowIn);

	if( EndOutY >= StartOutX )
	{
		FactorOut = (FactorOut>EndOutY) ? EndOutY : FactorOut;
		FactorOut = (FactorOut<StartOutX) ? StartOutX : FactorOut;
	}
	else
	{
		FactorOut = (FactorOut>StartOutX) ? StartOutX : FactorOut;
		FactorOut = (FactorOut<EndOutY) ? EndOutY : FactorOut;
	}

	return FactorOut;
}

UCHAR ncDrv_BufferAvg_Get(BUFFER_AVERAGE_TYPE * BuffInfo, UCHAR BufferCnt, UCHAR Value)
{
    UCHAR AvgValue;

    if(BufferCnt > BUFF_CNT_B08) BufferCnt = BUFF_CNT_B08;
    
    if(BuffInfo->BuffCntInit < BufferCnt)
	{
		BuffInfo->AccValue += (USHORT)Value;
		BuffInfo->BuffCntInit++;
		AvgValue = BuffInfo->AccValue / BuffInfo->BuffCntInit;
	}
	else
	{
		if(BuffInfo->BuffIdx >= BufferCnt)	BuffInfo->BuffIdx = 0;
		BuffInfo->AccValue -= BuffInfo->Buffer[BuffInfo->BuffIdx];
		BuffInfo->AccValue += (USHORT)Value;
		AvgValue = (BuffInfo->AccValue / BufferCnt);
	}

    BuffInfo->Buffer[BuffInfo->BuffIdx++] = (USHORT)Value;

	return AvgValue;
}

USHORT ncDrv_BufferAvg_Get16(BUFFER_AVERAGE_16BIT_TYPE * BuffInfo, UCHAR BufferCnt, USHORT Value)
{
    USHORT AvgValue;

    if(BufferCnt > BUFF_CNT_B16) BufferCnt = BUFF_CNT_B16;
    
    if(BuffInfo->BuffCntInit < BufferCnt)
	{
		BuffInfo->AccValue += (USHORT)Value;
		BuffInfo->BuffCntInit++;
		AvgValue = BuffInfo->AccValue / BuffInfo->BuffCntInit;
	}
	else
	{
		if(BuffInfo->BuffIdx >= BufferCnt)	BuffInfo->BuffIdx = 0;
		BuffInfo->AccValue -= BuffInfo->Buffer[BuffInfo->BuffIdx];
		BuffInfo->AccValue += (USHORT)Value;
		AvgValue = (BuffInfo->AccValue / BufferCnt);
	}

    BuffInfo->Buffer[BuffInfo->BuffIdx++] = (USHORT)Value;

	return AvgValue;
}

UCHAR ncDrv_InterpTbl16to8(USHORT X_in,  USHORT * pLutX, UCHAR * pLutY, UCHAR nSizeLut)
{
	UCHAR Yout = 0L;
	USHORT jStart = 1, j ;
	
	for ( j = jStart; j < nSizeLut; j ++ ) 
	{
		if ( X_in <= pLutX [j] || j == nSizeLut - 1 ) 
		{
			break;
		}
	}

	ISPSET16(aIP_LINEAR_X0_7_0, pLutX[j-1]);
	ISPSET16(aIP_LINEAR_X1_7_0, pLutX[j]);
	ISPSET16(aIP_LINEAR_Y0_7_0, pLutY[j-1]);
	ISPSET16(aIP_LINEAR_Y1_7_0, pLutY[j]);
	ISPSET16(aIP_LINEAR_SRC_X_7_0, X_in);

	ncDrv_Delay_Set(1L);	//min 6 clock
	
	Yout = ISPGET16(aIP_LINEAR_DST_Y1_7_0);

	return (UCHAR)Yout;

}
USHORT ncDrv_InterpAGC(USHORT x0, USHORT x1, USHORT y0, USHORT y1)
{
	USHORT Yout = 0L;

	ISPSET16(aIP_LINEAR_X0_7_0, x0);
	ISPSET16(aIP_LINEAR_X1_7_0, x1);
	ISPSET16(aIP_LINEAR_Y0_7_0, y0);
	ISPSET16(aIP_LINEAR_Y1_7_0, y1);
	ISPSET16(aIP_LINEAR_SRC_X_7_0, rIP_AGC_LEVEL_7_0);

	ncDrv_Delay_Set(1L);	//min 6 clock
	
	Yout = ISPGET16(aIP_LINEAR_DST_Y1_7_0);

	return (USHORT)Yout;
}

USHORT ncDrv_Interp(USHORT X_In, USHORT x0, USHORT x1, USHORT y0, USHORT y1)
{
	USHORT Yout = 0L;

	ISPSET16(aIP_LINEAR_X0_7_0, x0);
	ISPSET16(aIP_LINEAR_X1_7_0, x1);
	ISPSET16(aIP_LINEAR_Y0_7_0, y0);
	ISPSET16(aIP_LINEAR_Y1_7_0, y1);
	ISPSET16(aIP_LINEAR_SRC_X_7_0, X_In);

	ncDrv_Delay_Set(1L);	//min 6 clock
	
	Yout = ISPGET16(aIP_LINEAR_DST_Y1_7_0);

	return (USHORT)Yout;

#if 0
	USHORT Yout = 0L;

	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_X0_7_0) = x0;
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_X1_7_0) = x1;
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_Y0_7_0) = y0;
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_Y1_7_0) = y1;
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_SRC_X_7_0) = X_In;

	ncDrv_Delay_Set(1L);	//min 6 clock
	
	Yout = REGRW16(APACHE_ISP_BASE, aIP_LINEAR_DST_Y1_7_0);

	return (USHORT)Yout;
#endif
}

UCHAR ncDrv_InterpTbl08(UCHAR X_in,  UCHAR * pLutX, UCHAR * pLutY, UCHAR nSizeLut)
{
	UCHAR Yout = 0L;
	UCHAR jStart = 1, j ;
	
	for ( j = jStart; j < nSizeLut; j ++ ) 
	{
		if ( X_in <= pLutX [j] || j == nSizeLut - 1 ) 
		{
			break;
		}
	}

	ISPSET16(aIP_LINEAR_X0_7_0, pLutX[j-1]);
	ISPSET16(aIP_LINEAR_X1_7_0, pLutX[j]);
	ISPSET16(aIP_LINEAR_Y0_7_0, pLutY[j-1]);
	ISPSET16(aIP_LINEAR_Y1_7_0, pLutY[j]);
	ISPSET16(aIP_LINEAR_SRC_X_7_0, X_in);

	ncDrv_Delay_Set(1L);	//min 6 clock
	
	Yout = ISPGET16(aIP_LINEAR_DST_Y1_7_0);

	return (UCHAR)Yout;
	
#if 0
	UCHAR Yout = 0L;
	UCHAR jStart = 1, j ;
	
	for ( j = jStart; j < nSizeLut; j ++ ) 
	{
		if ( X_in <= pLutX [j] || j == nSizeLut - 1 ) 
		{
			break;
		}
	}
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_X0_7_0) = pLutX[j-1];
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_X1_7_0) = pLutX[j];
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_Y0_7_0) = pLutY[j-1];
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_Y1_7_0) = pLutY[j];
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_SRC_X_7_0) = X_in;

	ncDrv_Delay_Set(1L);	//min 6 clock
	
	Yout = REGRW16(APACHE_ISP_BASE, aIP_LINEAR_DST_Y1_7_0);

	return (UCHAR)Yout;
#endif
}

USHORT ncDrv_InterpTbl16(USHORT X_in,  USHORT * pLutX, USHORT * pLutY, UCHAR nSizeLut)
{
	USHORT Yout = 0L;
	USHORT jStart = 1, j ;
	
	for ( j = jStart; j < nSizeLut; j ++ ) 
	{
		if ( X_in <= pLutX [j] || j == nSizeLut - 1 ) 
		{
			break;
		}
	}

	ISPSET16(aIP_LINEAR_X0_7_0, pLutX[j-1]);
	ISPSET16(aIP_LINEAR_X1_7_0, pLutX[j]);
	ISPSET16(aIP_LINEAR_Y0_7_0, pLutY[j-1]);
	ISPSET16(aIP_LINEAR_Y1_7_0, pLutY[j]);
	ISPSET16(aIP_LINEAR_SRC_X_7_0, X_in);

	ncDrv_Delay_Set(1L);	//min 6 clock
	
	Yout = ISPGET16(aIP_LINEAR_DST_Y1_7_0);

	return (USHORT)Yout;

#if 0
	USHORT Yout = 0L;
	USHORT jStart = 1, j ;
	
	for ( j = jStart; j < nSizeLut; j ++ ) 
	{
		if ( X_in <= pLutX [j] || j == nSizeLut - 1 ) 
		{
			break;
		}
	}

	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_X0_7_0) = pLutX[j-1];
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_X1_7_0) = pLutX[j];
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_Y0_7_0) = pLutY[j-1];
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_Y1_7_0) = pLutY[j];
	REGRW16(APACHE_ISP_BASE, aIP_LINEAR_SRC_X_7_0) = X_in;

	ncDrv_Delay_Set(1L);	//min 6 clock
	
	Yout = REGRW16(APACHE_ISP_BASE, aIP_LINEAR_DST_Y1_7_0);

	return (USHORT)Yout;
#endif
}



