/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	File	: MD_Drv.h		
*	Brief	: This file is MD API for NEXTCHIP standard library
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2016.01.26		Leo.Sim	    1.0		Initial  Revision
********************************************************************************/

#ifndef __MW_MOTION__
#define __MW_MOTION__

#define MDBLOCK_SIZE	0x20	// 32x32
#define MD_MOVE_DEPTH	1

void ncDrv_MD_Mirror(void);
void ncDrv_MD_Flip(void);

/********************************************************************************
* Function Name 	: ncDrv_MD_Set()
* Description		: Motion controller 
* Refer to		    : API Document
* Argument		    : void
* Return			: void
********************************************************************************/
void ncDrv_MD_Set(void);

/********************************************************************************
* Function Name 	: ncDrv_MD_Auto()
* Description		: Motion Detection Information
* Refer to		    : API Document
* Argument		    :
					
* Return			:
					@ [0x00] : Not Detected
					@ [0x01] : Area.1 Detected
					@ [0x02] : Area.2 Detected
					@ [0x04] : Area.3 Detected
					@ [0x08] : Area.4 Detected
					@ [Error Code]	: Fail (API Reference Guide)
********************************************************************************/
UCHAR ncDrv_MD_Auto(void);
void ncDrv_MD_ReSize(void);


/********************************************************************************
* Function Name 	: ncDrv_MD_Set()
* Description		: Motion controller 
* Refer to		    : API Document
* Argument		    : void
* Return			: void
********************************************************************************/
void ncDrv_MD_SetFlicker(void);


#endif


