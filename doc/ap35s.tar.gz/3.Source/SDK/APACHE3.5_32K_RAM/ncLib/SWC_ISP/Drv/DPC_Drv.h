
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __MW_DEFECT__
#define __MW_DEFECT__

typedef enum{
	eOff = 0,
	eAuto
}eLiveDPCMode;

#define SCAN_READY		0
#define SCAN_START		1

#define DPC_MOVE_DEPTH 	8
#define DPC_GRID_MIN 		255

/* [2014/8/28] sky : 1-2 */
typedef union{
	UCHAR D8;
	struct {
		UCHAR	WDPCState:			1;
		UCHAR	BDPCState:			1;
		UCHAR	WDPCInit:			1;
		UCHAR	Reserved:			5;
	}Bit;
}STRUCT_MW_DPC;

extern STRUCT_MW_DPC	sMwDpc;

/********************************************************************************
* Function Name 	: ncDrv_StaticDPCWhite_Set()
* Description		: Static DPC Set
* Refer to		: API Document
* Argument		:
										 
* Return		:	@ [TRUE]		: Success
				@ [Error Code]	: Fail (API Reference Guide)
********************************************************************************/
/* [2014/11/24] ktsyann : [STD]1-2 */
UCHAR ncDrv_StaticDPCWhite_Set(UCHAR tMode);

/********************************************************************************
* Function Name 	: ncDrv_StaticDPCWhite_Cancel()
* Description		: "Static dead pixel" SCAN Ready Cancel
* Refer to		: API Document
* Argument		:
										 
* Return			: @ None
********************************************************************************/
void ncDrv_StaticDPCWhite_Cancel(void);

/********************************************************************************
* Function Name 	: ncDrv_StaticDPCWhite_Scan()
* Description		: "Static dead pixel" SCAN
* Refer to		: API Document
* Argument		:
					@ Mode		: [Ready / Start]
										 
* Return			: @ [Static DPC Number](API Reference Guide)
********************************************************************************/
USHORT ncDrv_StaticDPCWhite_Scan(UCHAR Mode);

/********************************************************************************
* Function Name 	: ncDrv_StaticDPCBlack_Set()
* Description		: "Black dead pixel" Set
* Refer to		: API Document
* Argument		:
					@ Mode		: [Ready / Start]
										 
* Return			: @ [Static DPC Number](API Reference Guide)
********************************************************************************/
void ncDrv_StaticDPCBlack_Set(void);

/********************************************************************************
* Function Name 	: ncDrv_StaticDPCBlack_Cancel()
* Description		: "Black dead pixel" SCAN Ready Cancel
* Refer to		: API Document
* Argument		:
										 
* Return			: @ None
********************************************************************************/
void ncDrv_StaticDPCBlack_Cancel(void);

/********************************************************************************
* Function Name 	: ncDrv_StaticDPCBlack_Scan()
* Description		: "Black dead pixel" SCAN
* Refer to		: API Document
* Argument		:
					@ Mode		: [Ready / Start]
										 
* Return			: @ [Static DPC Number](API Reference Guide)
********************************************************************************/
UCHAR ncDrv_StaticDPCBlack_Scan(UCHAR Mode);

/********************************************************************************
* Function Name 	: ncDrv_LiveDPC_Auto()
* Description		: Live DPC Auto Control by AGC
* Refer to		: API Document
* Argument		:
										 
* Return		:	@ [TRUE]		: Success
				@ [Error Code]	: Fail (API Reference Guide)
********************************************************************************/
void ncDrv_LiveDPC_Auto(void);

/********************************************************************************
* Function Name 	: ncDrv_ManualDPC_Set()
* Description		: Manual DPC Set
* Refer to		: API Document
* Argument		:
										 
* Return		:	@ [TRUE]		: Success
				@ [Error Code]	: Fail (API Reference Guide)
********************************************************************************/
void ncDrv_ManualDPC_Set(void);

void ncDrv_DPC_ReSize(void);
void ncDrv_DPC_ScanView(void);
void ncDrv_DPC_Grid_Set(void);

#endif


