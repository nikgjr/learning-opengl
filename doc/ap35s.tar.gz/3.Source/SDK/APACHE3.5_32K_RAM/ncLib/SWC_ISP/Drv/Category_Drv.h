
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/


#ifndef __DRV_CATEGORY_FUNCTION__
#define __DRV_CATEGORY_FUNCTION__

/*=============================================================================
	Definitions for Options
=============================================================================*/



/*=============================================================================
	Definitions for Control,Tuning,Variable Structure
=============================================================================*/

typedef struct {
	USHORT Index;
	void(* Func)(USHORT waddr);
} CATEGORY_pFNC_TYPE;


typedef enum{
	/* 00 [0x00] */ CtgIdx_SYSTEM,
	/* 01 [0x01] */ CtgIdx_BLACKLEVEL,
	/* 02 [0x02] */ CtgIdx_LSC,
	/* 03 [0x03] */ CtgIdx_AE,
	/* 04 [0x04] */ CtgIdx_AWB,
	/* 05 [0x05] */ CtgIdx_WDR,
	/* 06 [0x06] */ CtgIdx_BACKLIGHT,
	/* 07 [0x07] */ CtgIdx_DPC,
	/* 08 [0x08] */ CtgIdx_SUPPRESS,
	/* 09 [0x09] */ CtgIdx_LUMA,
	/* 10 [0x0A] */ CtgIdx_CHROMA,
	/* 11 [0x0B] */ CtgIdx_GAMMA,
	/* 12 [0x0C] */ CtgIdx_NR,
	/* 13 [0x0D] */ CtgIdx_SHARPNESS,
	/* 14 [0x0E] */ CtgIdx_DEFOG,
	/* 15 [0x0F] */ CtgIdx_MD,
	/* 16 [0x10] */ CtgIdx_PM,
	/* 17 [0x11] */ CtgIdx_DEFFECT,
	/* 18 [0x12] */ CtgIdx_TDN,
	/* 19 [0x13] */ CtgIdx_OSD,
	/* 20 [0x14] */ CtgIdx_CAMTITLE,
	/* 21 [0x15] */ CtgIdx_AF,
	/* 22 [0x16] */ CtgIdx_CVBS,
	/* 23 [0x17] */ CtgIdx_AHD,
	/* 24 [0x18] */ CtgIdx_MONITOR,
	/* 25 [0x19] */ CtgIdx_PROTOCOL,
	/* 26 [0x1A] */ CtgIdx_KEYINPUT,
	/* 27 [0x1B] */ CtgIdx_GPIO,
	/* 28 [0x1C] */ CtgIdx_OSG,
	/* 29 [0x1D] */ CtgIdx_PGL,
	/* 30 [0x1E] */ CtgIdx_VM,
	/* 31 [0x1F] */ CtgIdx_USER,

	/* 32 [0x20] */ CtgIdx_MAX
}eCATEGORY_INDEX;
#define CATEGORY_FUNC_CNT    CtgIdx_MAX


extern const CATEGORY_pFNC_TYPE pCategory_Func[CATEGORY_FUNC_CNT];

typedef struct{
    union 
    {
		ULONG D32;
		struct 
		{

		/* 00 [0x00] */ ULONG FLAG_SYSTEM:      1;
		/* 01 [0x01] */ ULONG FLAG_BLACKLEVEL:  1;
		/* 02 [0x02] */ ULONG FLAG_LSC:         1;
		/* 03 [0x03] */ ULONG FLAG_AE:          1;
		/* 04 [0x04] */ ULONG FLAG_AWB:         1;
		/* 05 [0x05] */ ULONG FLAG_WDR:         1;
		/* 06 [0x06] */ ULONG FLAG_BACKLIGHT:   1;
		/* 07 [0x07] */ ULONG FLAG_DPC:         1;

		/* 08 [0x08] */ ULONG FLAG_SUPPRESS:    1;
		/* 09 [0x09] */ ULONG FLAG_LUMA:        1;
		/* 10 [0x0A] */ ULONG FLAG_CHROMA:      1;
		/* 11 [0x0B] */ ULONG FLAG_GAMMA:       1;
		/* 12 [0x0C] */ ULONG FLAG_NR:          1;
		/* 13 [0x0D] */ ULONG FLAG_SHARPNESS:   1;
		/* 14 [0x0E] */ ULONG FLAG_DEFOG:       1;
		/* 15 [0x0F] */ ULONG FLAG_MD:          1;

		/* 16 [0x10] */ ULONG FLAG_PM:          1;
		/* 17 [0x11] */ ULONG FLAG_DEFFECT:     1;
		/* 18 [0x12] */ ULONG FLAG_TDN:         1;
		/* 19 [0x13] */ ULONG FLAG_OSD:         1;
		/* 20 [0x14] */ ULONG FLAG_CAMTITLE:    1;
		/* 21 [0x15] */ ULONG FLAG_AF:          1;
		/* 22 [0x16] */ ULONG FLAG_CVBS:        1;
		/* 23 [0x17] */ ULONG FLAG_AHD:         1;

		/* 24 [0x18] */ ULONG FLAG_MONITOR:     1;
		/* 25 [0x19] */ ULONG FLAG_PROTOCOL:    1;
		/* 26 [0x1A] */ ULONG FLAG_KEYINPUT:    1;
		/* 27 [0x1B] */ ULONG FLAG_GPIO:        1;
		/* 28 [0x1C] */ ULONG FLAG_OSG:         1;
		/* 29 [0x1D] */ ULONG FLAG_PGL:         1;
		/* 30 [0x1E] */ ULONG FLAG_VM:          1;
		/* 31 [0x1F] */ ULONG FLAG_USER:        1;
		}B32;
	}Category;
} STRUCT_MW_CATEGORY_PROCESS_FLAG;
extern STRUCT_MW_CATEGORY_PROCESS_FLAG	sMwCategoryFlag;

typedef struct{
    union 
    {
		INT32 D32;
		struct 
		{
		    ULONG SUB_FLAG_CVBS:      			1;
		    ULONG SUB_FLAG_WDPC:       			1;
		    ULONG SUB_FLAG_BDPC:       			1;
		    ULONG SUB_FLAG_MONITOR:     		1;
		    ULONG SUB_FLAG_MONITOR_OUTPUT:      1;
		    ULONG SUB_FLAG_PIRIS_LENS_SET:		1;
		    ULONG SUB_FLAG_PIRIS_STEP:      	1;
		    ULONG SUB_FLAG_ETC:    				1;

		    ULONG SUB_FLAG_REGKEY_INPUT:		1;
		    ULONG SUB_FLAG_OSD_POS:				1;
		    ULONG SUB_FLAG_OSD_PATH:			1;
		    ULONG SUB_FLAG_LANGUAGE:			1;
	    
		    ULONG SUB_FLAG_RESERVED:    		20;
		}B32;
	}Category;
} STRUCT_MW_CATEGORY_PROCESS_SUBFLAG;
extern STRUCT_MW_CATEGORY_PROCESS_SUBFLAG	sMwCategorySubFlag;



/*=============================================================================
	Function Declaration
=============================================================================*/

UCHAR ncDrv_CategoryIndex_Get(USHORT Address);
void ncDrv_CategoryFunction_Set(USHORT waddr);
void ncDrv_CategoryFunc_Exec(void);
void ncDrv_CategorySubCheck_Set(UINT32 Address);
extern void ncDrv_CategoryFunc_Init(void);


#endif


