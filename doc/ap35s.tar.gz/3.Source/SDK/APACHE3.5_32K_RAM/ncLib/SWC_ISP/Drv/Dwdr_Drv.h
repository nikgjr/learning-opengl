
/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/

#ifndef __DWDR_DRV__
#define __DWDR_DRV__

/********************************************************************************
* Function Name 	: MW_DWDR_Set()
* Description		: D-WDR Control
* Refer to		: API Document
* Argument		:	
										 
* Return			: void
********************************************************************************/
void ncDrv_DWDR_Set(void);

/********************************************************************************
* Function Name 	: MW_DWDR_Auto()
* Description		: DWDR Auto Control
* Refer to		: API Document
* Argument		: void
										 
* Return			: void
********************************************************************************/
void ncDrv_DWDR_Auto(void);

#endif // end of  __DWDR_DRV__

