/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Timer_Lib.h
*
*  @brief   : This file is Timer controller API for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2013.11.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note
*
*
*
*
********************************************************************************
*/
#ifndef __TIMER_LIB_H__
#define __TIMER_LIB_H__

/*
********************************************************************************
*                                  INCLUDE
********************************************************************************
*/
#include <time.h>
#include <stdarg.h>









/*
********************************************************************************
*                   	           DEFINES
********************************************************************************
*/

/*
********************************************************************************
*                                ENUMERATION
********************************************************************************
*/
typedef enum _TIMER_CMD
{
    /*
    * Generic Timer / Count Commands
    */
    GCMD_TC_INIT_CH = 0,
    GCMD_TC_START,
    GCMD_TC_STOP,
    GCMD_TC_SET_PERIOD_TIME,            // Apache3.5 Not Support
    GCMD_TC_CHK_ONESHOT_DONE,
    GCMD_TC_CONNECT_USER_HANDLER,
    GCMD_TC_DISCONNECT_USER_HANDLER,
    GCMD_TC_MAX,

    /*
    * Specific Timer / Count Commands
    */
    SCMD_TC_DUMMY = 100,
    SCMD_TC_MAX,
} eTIMER_CMD;


typedef enum _TIMER_CH
{
    TC_CH0 = 0,
    TC_CH1,
    TC_CH2,                 // PWM Mode
    TC_CH3,                 // PWM Mode
    TC_CH4,                 // PWM Mode
    TC_CH_MAX
} TIMER_CH;


typedef enum _TIMER_CLK_SRC
{
    TC_CLK_DIV2 = 0,        // Clock / 2
    TC_CLK_DIV4,            // Clock / 4
    TC_CLK_DIV16,           // Clock / 16
    TC_CLK_DIV64,           // Clock / 64
    TC_CLK_EXT0,            // Reserved
    TC_CLK_EXT1,            // Reserved
    TC_CLK_MAX
} TIMER_CLK_SRC;


typedef enum _TIMER_MODE
{
    TC_MODE_PERIOD = 0,
    TC_MODE_PWM,            
    TC_MODE_ONESHOT,
    TC_MODE_CAPTURE,	    // Apache3.5 Not Used	
    TC_MODE_MAX
} TIMER_MODE;


typedef enum _TIMER_TRIG_MODE
{
    TC_TRIG_LEVEL_HIGH = 0,
    TC_TRIG_LEVEL_LOW,
    TC_TRIG_EDGE_HIGH,
    TC_TRIG_EDGE_LOW,
    TC_TRIG_MAX
} TIMER_TRIG_MODE;










/*
********************************************************************************
*                             TYPEDEFS
********************************************************************************
*/
typedef struct _TC_INIT_PARAM {
    UINT8  mMode;               // 0: Period, 1: PWM, 2: Oneshot
    UINT8  mClockSource;        // Apache3.5 Not Used.
    UINT8  mPrescaler;          // 1 or 16 or 255
    UINT8  mTrigMode;           // Apache3.5 Not Used.
    UINT32 mPeriod1;            // 1'st period (usec)
    UINT32 mPeriod2;            // Apache3.5 Not Used.
} tTC_INIT_PARAM, *ptTC_INIT_PARAM;










/*
********************************************************************************
*                             CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                             VARIABLE DECLARATIONS
********************************************************************************
*/

/*
********************************************************************************
*                             FUNCTION DECLARATIONS
********************************************************************************
*/
/**
****************************************************************************
*
*  @desc        This function will open timer component.
*               Set timer/count input clock and initialize resources.
*
*  @param_in    nInputClk       Input clock of Timer/Count controller
*
*  @return      NC_FAIL         Fail
*  @return      NC_SUCCESS      Success
*
****************************************************************************
*/
extern INT32  ncLib_TIMER_Open(UINT32 nInputClk);


/**
****************************************************************************
*
*  @desc        This function will close timer component and clean resources.
*
*  @return      NC_FAIL         Fail
*  @return      NC_SUCCESS      Success
*
****************************************************************************
*/
extern INT32  ncLib_TIMER_Close(void);


/**
****************************************************************************
*
* TBD
*
****************************************************************************
*/
extern INT32  ncLib_TIMER_Read(void);


/**
****************************************************************************
*
* TBD
*
****************************************************************************
*/
extern INT32  ncLib_TIMER_Write(void);


/**
****************************************************************************
*
*  @desc        This function will control all functions about timer component.
*
*  @param_in    Cmd             Control Command
*
*  @return      NC_FAIL         Fail
*  @return      NC_SUCCESS      Success
*
****************************************************************************
*/
extern INT32  ncLib_TIMER_Control(eTIMER_CMD Cmd, ...);







#endif /* __TIMER_LIB_H__ */
