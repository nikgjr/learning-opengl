/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : UART_Lib.h
*
*  @brief   : This file is UART Controller API for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __UART_LIB_H__
#define __UART_LIB_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define BACKSP_KEY          0x08
#define RETURN_KEY          0x0D
#define DELETE_KEY          0x7F
#define BELL                0x07


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* UART GENERIC & SPECIFIC COMMANDS
*/

typedef enum
{
    /*
    * Generic Commands
    */

    GCMD_UT_INIT_CH = 0,
    GCMD_UT_DEINIT_CH,

    GCMD_UT_SET_BAUDRATE,
    GCMD_UT_GET_RX_FIFO_CNT,

    GCMD_UT_GET_CHAR,
    GCMD_UT_PUT_CHAR,
    GCMD_UT_GET_STRING,
    GCMD_UT_PUT_STRING,
    GCMD_UT_PRINT_STRING,

    GCMD_UT_CONNECT_ISR_HANDLER,
    GCMD_UT_DISCONNECT_ISR_HANDLER,

    GCMD_UT_CONNECT_USER_HANDLER,
    GCMD_UT_DISCONNECT_USER_HANDLER,

    GCMD_UT_EN_DMA_MODE,
    GCMD_UT_DIS_DMA_MODE,

    GCMD_UT_SET_TX_FIFO_LEVEL,
    GCMD_UT_SET_RX_FIFO_LEVEL,
    
    GCMD_UT_MAX,

} eUART_CMD;


typedef enum
{
    UART_CH0 = 0,
    UART_CH1,
    MAX_OF_UART_CH
} eUART_CH;

typedef enum
{
    UT_SPS_DIS = (0<<7),
    UT_SPS_ENA = (1<<7),
    MAX_OF_UART_SPS
} eUART_SPS;

typedef enum
{
    UT_DATA_5BIT = (0<<5),
    UT_DATA_6BIT = (1<<5),
    UT_DATA_7BIT = (2<<5),
    UT_DATA_8BIT = (3<<5),
    MAX_OF_UART_DATA_WLEN_BIT
} eUART_DATA_WLEN;

typedef enum
{
    UT_FIFO_DIS = (0<<4),
    UT_FIFO_ENA = (1<<4),
    MAX_OF_UART_FIFO
} eUART_FIFO;

typedef enum
{
    UT_STOP_1BIT = (0<<3),
    UT_STOP_2BIT = (1<<3),
    MAX_OF_UART_STOP_BIT
} eUART_STOP_BIT;

typedef enum
{
    UT_EPS_DIS = (0<<2),
    UT_EPS_ENA = (1<<2),
    MAX_OF_UART_EPS
} eUART_EPS;

typedef enum
{
    UT_PARITY_DIS = (0<<1),
    UT_PARITY_ENA = (1<<1),
    MAX_OF_UART_PARITY
} eUART_PARITY;

typedef enum
{
    UT_BRK_DIS = (0<<0),
    UT_BRK_ENA = (1<<0),
    MAX_OF_UART_BRK
} eUART_BRK;

typedef enum
{
    UT_BAUDRATE_300     = 300,
    UT_BAUDRATE_600     = 600,
    UT_BAUDRATE_1200    = 1200,
    UT_BAUDRATE_2400    = 2400,
    UT_BAUDRATE_4800    = 4800,
    UT_BAUDRATE_9600    = 9600,
    UT_BAUDRATE_19200   = 19200,
    UT_BAUDRATE_38400   = 38400,
    UT_BAUDRATE_57600   = 57600,
    UT_BAUDRATE_115200  = 115200,
    UT_BAUDRATE_230400  = 230400,
    UT_BAUDRATE_460800  = 460800,
    UT_BAUDRATE_921600  = 921600
} eUART_BAUDRATE;

typedef enum
{
    UT_DMAE_RX = (1<<0),
    UT_DMAE_TX = (1<<1),
    MAX_OF_UART_DMAE
} eUART_DMAE;

typedef enum
{
    UT_TXFLS_1DIV8 = (0<<0),
    UT_TXFLS_1DIV4 = (1<<0),
    UT_TXFLS_1DIV2 = (2<<0),
    UT_TXFLS_3DIV4 = (3<<0),
    UT_TXFLS_7DIV8 = (4<<0),
    MAX_OF_UART_TXFLS
} eUART_TXFLS;

typedef enum
{
    UT_RXFLS_1DIV8 = (0<<3),
    UT_RXFLS_1DIV4 = (1<<3),
    UT_RXFLS_1DIV2 = (2<<3),
    UT_RXFLS_3DIV4 = (3<<3),
    UT_RXFLS_7DIV8 = (4<<3),
    MAX_OF_UART_RXFLS
} eUART_RXFLS;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tUART_PARAM
{
    UINT32 uartClk;         // UART input clock
    UINT32 baudRate;        // UART baudrate

    eUART_SPS sps;          // Stick parity select
    eUART_DATA_WLEN wlen;   // Word length
    eUART_FIFO fen;         // Enable FIFOs
    eUART_STOP_BIT stp2;    // Two stop bits select
    eUART_EPS eps;          // Even parity select
    eUART_PARITY pen;       // Parity enable
    eUART_BRK brk;          // Send break
} tUART_PARAM, *ptUART_PARAM;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncLib_UART_Open(UINT32 nInputClk);
extern INT32 ncLib_UART_Close(void);

extern INT32 ncLib_UART_Read(void);
extern INT32 ncLib_UART_Write(void);

extern INT32 ncLib_UART_Control(eUART_CMD Cmd, ...);


#endif /* __UART_LIB_H__ */


/* End Of File */
