/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : DMA_Lib.h
*
*  @brief   : This file is DMA controller API for NEXTCHIP standard library
*
*  @author  : Alessio / Automotive SoC Software Team
*
*  @date    : 2016.01.25
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 2016.01.25 - DMA API library modified by Alessio
*
********************************************************************************
*/

#ifndef __DMA_LIB_H__
#define __DMA_LIB_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/
#define DMA_INST_BUFF_SIZE              (512)











/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* DMAC GENERIC & SPECIFIC COMMANDS
*/

typedef enum _DMA_CMD
{
    /*
    * Generic Commands
    */

    GCMD_DMA_INIT_CH = 0,
    GCMD_DMA_DEINIT_CH,
    GCMD_DMA_INTR_ENA,
    GCMD_DMA_INTR_CLR,

    GCMD_DMA_START,
    GCMD_DMA_TRANSFER,
    GCMD_DMA_DONE,

	/*
	 * Specific Commands
	 */
    GCMD_DMA_MAX,

} eDMA_CMD;


typedef enum
{
    DMA_CH0,
    DMA_CH1,
    DMA_CH2,
    DMA_CH3,
    MAX_OF_DMA_CH
} eDMA_CH;

typedef enum
{
    DMA_MEM_TO_MEM,
    DMA_MEM_TO_DEV,
    DMA_DEV_TO_MEM,
    MAX_OF_DMA_TYPE
} eDMA_TYPE;

typedef enum
{
    DMA_UART0_SPI0_TX,
    DMA_UART0_SPI0_RX,
    DMA_UART1_SPI1_TX,
    DMA_UART1_SPI1_RX,
    MAX_OF_DMA_PERI_NUM
} eDMA_PERI_NUM;

typedef enum
{
    DMA_BS_1B,
    DMA_BS_2B,
    DMA_BS_4B,
    DMA_BS_8B,
    //DMA_BS_16B,   // do not use b.c of 64bit bus
    MAX_OF_DMA_BURST_SIZE
} eDMA_BURST_SIZE;

typedef enum
{
    DMA_BL_1XFER = 1,
    DMA_BL_2XFER,
    DMA_BL_3XFER,
    DMA_BL_4XFER,
    DMA_BL_5XFER,
    DMA_BL_6XFER,
    DMA_BL_7XFER,
    DMA_BL_8XFER,
    DMA_BL_9XFER,
    DMA_BL_10XFER,
    DMA_BL_11XFER,
    DMA_BL_12XFER,
    DMA_BL_13XFER,
    DMA_BL_14XFER,
    DMA_BL_15XFER,
    DMA_BL_16XFER,
    MAX_OF_DMA_BURST_LEN
} eDMA_BURST_LEN;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    eDMA_BURST_LEN burstLen;
    eDMA_BURST_SIZE burstSize;

    eDMA_CH dmaCh;
    eDMA_TYPE reqType;
    eDMA_PERI_NUM periNum;

    UINT32 srcAddr;
    UINT32 dstAddr;
    UINT32 xferBytes;

    UINT32 instBase;    

    UINT32 srcPhyAddr;      // Use the lib inside
    UINT32 dstPhyAddr;      // Use the lib inside
    UINT32 instPhyAddr;     // Use the lib inside
} tDMA_INFO, *ptDMA_INFO;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncLib_DMA_Open(void);
extern INT32 ncLib_DMA_Close(void);

extern INT32 ncLib_DMA_Read(void);
extern INT32 ncLib_DMA_Write(void);

extern INT32 ncLib_DMA_Control(eDMA_CMD Cmd, ...);


#endif /* __DMA_LIB_H__ */


/* End Of File */
