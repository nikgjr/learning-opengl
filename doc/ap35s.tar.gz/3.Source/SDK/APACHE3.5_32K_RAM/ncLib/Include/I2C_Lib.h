/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : I2C_Lib.h
*
*  @brief   : This file is I2C controller API for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __I2C_LIB_H__
#define __I2C_LIB_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/* Apache3.5 Device ID */
#define I2C_SLAVE_DEVICE_ID     0x78


#define MODE_8BIT_ACCESS        0
#define MODE_16BIT_ACCESS       1

#define I2C_SLAVE_MODE_ACCESS   MODE_8BIT_ACCESS


#define APACHE_CMD_REG          0x00    // Command Register
#define APACHE_ADDRL_REG        0x01    // Address Low Register
#define APACHE_ADDRH_REG        0x02    // Address High Register
#define APACHE_DATA0_REG        0x03    // Data 0 Register
#define APACHE_DATA1_REG        0x04    // Data 1 Register
#define APACHE_DATA2_REG        0x05    // Data 2 Register
#define APACHE_DATA3_REG        0x06    // Data 3 Register
#define APACHE_DATA4_REG        0x07    // Data 4 Register
#define APACHE_DATA5_REG        0x08    // Data 5 Register
#define APACHE_DATA6_REG        0x09    // Data 6 Register
#define APACHE_DATA7_REG        0x0A    // Data 7 Register
#define APACHE_DATA8_REG        0x0B    // Data 8 Register
#define APACHE_DATA9_REG        0x0C    // Data 9 Register
#define APACHE_DATA10_REG       0x0D    // Data 10 Register
#define APACHE_DATA11_REG       0x0E    // Data 11 Register
#define APACHE_DATA12_REG       0x0F    // Data 12 Register
#define APACHE_DATA13_REG       0x10    // Data 13 Register
#define APACHE_DATA14_REG       0x11    // Data 14 Register
#define APACHE_DATA15_REG       0x12    // Data 15 Register


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* I2C GENERIC & SPECIFIC COMMANDS
*/

typedef enum _I2C_CMD
{
    /*
    * Generic Commands
    */

    GCMD_I2C_INIT_CH = 0,
    GCMD_I2C_DEINIT_CH,

    GCMD_I2C_SET_BITRATE,
    GCMD_I2C_SET_BYTE_ORDER,

    GCMD_I2C_CONNECT_ISR_HANDLER,
    GCMD_I2C_DISCONNECT_ISR_HANDLER,

    GCMD_I2C_MAX,

} eI2C_CMD;


typedef enum
{
    I2C_CH0,
    I2C_CH1,
    MAX_OF_I2C_CH
} eI2C_CH;

typedef enum
{
    I2C_OP_MODE_MASTER,
    I2C_OP_MODE_SLAVE,
    MAX_OF_I2C_MODE
} eI2C_OP_MODE;

typedef enum
{
    I2C_ADDR_8_DATA_8,
    I2C_ADDR_8_DATA_16,
    I2C_ADDR_16_DATA_8,
    I2C_ADDR_16_DATA_16,
    MAX_OF_I2C_LENGTH_TYPE
} eI2C_LENGTH_TYPE;

typedef enum
{
    I2C_BITRATE_10KBPS  = 10000,
    I2C_BITRATE_20KBPS  = 20000,
    I2C_BITRATE_30KBPS  = 30000,
    I2C_BITRATE_40KBPS  = 40000,
    I2C_BITRATE_50KBPS  = 50000,
    I2C_BITRATE_60KBPS  = 60000,
    I2C_BITRATE_70KBPS  = 70000,
    I2C_BITRATE_80KBPS  = 80000,
    I2C_BITRATE_90KBPS  = 90000,
    I2C_BITRATE_100KBPS = 100000,
    I2C_BITRATE_200KBPS = 200000,
    I2C_BITRATE_300KBPS = 300000,
    I2C_BITRATE_400KBPS = 400000,
} eI2C_BITRATE;

typedef enum
{
    I2C_LITTLE_ENDIAN,
    I2C_BIG_ENDIAN,
	MAX_OF_I2C_BYTE_ORDER
} eI2C_BYTE_ORDER;

typedef enum
{
    I2C_IMS_IDLE,
    I2C_IMS_ACK,
    I2C_IMS_NACK,
    I2C_IMS_DATA_SEND,
    I2C_IMS_DATA_RECEIVE,
    MAX_OF_I2C_MASTER_STAUTS
} eI2C_MASTER_STATUS;

typedef enum
{
    I2C_ISS_IDLE,
    I2C_ISS_TXACK,
    I2C_ISS_RXACK,	
    I2C_ISS_HOST_READ,
    I2C_ISS_HOST_WRITE,
    I2C_ISS_DATA_SEND,
    I2C_ISS_DATA_RECEIVE,
    MAX_OF_SLAVE_STATUS
} eI2C_SLAVE_STATUS;	


/*
* I2C Slave Command Parameter
*/

enum
{
    I2C_SL_READY,
    I2C_SL_START
};

enum
{
    I2C_SL_IDLE,
    I2C_SL_BUSY,
    I2C_SL_ERROR
};

enum
{
    I2C_SL_READ,
    I2C_SL_WRITE
};

enum
{
    I2C_SL_ISP,
    I2C_SL_CIS,
};

enum
{
    I2C_SL_SINGLE,
    I2C_SL_SEQUENCE
};


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT32 id;                  // Device ID
    UINT32 clock;               // I2C baudrate
    UINT32 srcClock;            // I2C input clock
    UINT32 txIdx;               // Tx buffer index
    UINT8 *txBuf;               // Tx buffer
    eI2C_MASTER_STATUS status;  // Master mode status
} tI2C_MASTER, *ptI2C_MASTER;

typedef struct
{
    UINT32 id;                  // Device ID
    UINT32 rxIdx;               // Rx buffer index
    UINT8 *rxBuf;               // Rx buffer
    eI2C_SLAVE_STATUS status;   // Slave mode status
} tI2C_SLAVE, *ptI2C_SLAVE;

typedef struct
{
    eI2C_CH channel;            // I2C channel
    eI2C_OP_MODE mode;          // I2C mode
    eI2C_BYTE_ORDER byteOrder;  // 0 : little endian, 1 : big endian
    eI2C_LENGTH_TYPE type;      // I2C data type

    tI2C_MASTER master;         // I2C master buffer structure
    tI2C_SLAVE slave;           // I2C slave buffer structure
} tI2C_INFO, *ptI2C_INFO;

// not used ...
typedef struct
{
    union
    {
        UINT8 D8;

        struct
        {
            UINT8 StartFlag:    1;  // 0 : ready,  1 : start
            UINT8 RWmode:       1;  // 0 : write,  1 : read
            UINT8 Target:       1;  // 0 : ISP,    1 : CIS
            UINT8 AccessType:   1;  // 0 : single, 1 : sequential
            UINT8 DataSize:     4;  // 0 : 1 ~ 16
        } B8;
    }RxCmd;

    union
    {
        UINT8 D8;

        struct
        {
            UINT8 Status:       2;  // 0 : idle,   1 : busy, 2 : error
            UINT8 Target:       1;  // 0 : ISP,    1 : CIS
            UINT8 AccessType:   1;  // 0 : single, 1 : sequential
            UINT8 DataSize:     4;  // 0 : 1 ~ 16
        } B8;
    }TxCmd;
} tI2C_CMD;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncLib_I2C_Open(UINT32 nInputClk);
extern INT32 ncLib_I2C_Close(void);

extern INT32 ncLib_I2C_Read(eI2C_CH channel, UINT8 deviceId, UINT16 address, void *pBuffer, UINT32 length, eI2C_LENGTH_TYPE type);
extern INT32 ncLib_I2C_Write(eI2C_CH channel, UINT8 deviceId, UINT16 address, UINT32 data, UINT32 length, eI2C_LENGTH_TYPE type);

extern INT32 ncLib_I2C_Control(eI2C_CMD Cmd, ...);


#endif  /* __I2C_LIB_H__ */


/* End Of File */
