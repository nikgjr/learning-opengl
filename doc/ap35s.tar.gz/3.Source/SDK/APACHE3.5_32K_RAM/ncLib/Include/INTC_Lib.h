/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : INTC_Lib.h
*
*  @brief   : This file is interrupt controller API for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __INTC_LIB_H__
#define __INTC_LIB_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define DEF_INTC_TRIGGER_LEVEL      TRIG_HIGH_LEVEL
#define DEF_INTC_PRIORITY_LEVEL     240


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum
{
	GCMD_INTC_REGISTER_INT = 0,
	GCMD_INTC_UNREGISTER_INT,
	GCMD_INTC_SGI_TRIGGER,

	GCMD_INTC_SET_TRIG_MODE,
	GCMD_INTC_SET_PRIORITY_LEVEL,
	GCMD_INTC_ENABLE_INT,
	GCMD_INTC_DISABLE_INT,
	GCMD_INTC_ONOFF_RAISED_INT,      // for Debug
	GCMD_INTC_CHK_RAISED_INT,        // for Debug
	GCMD_INTC_CLR_RAISED_INT,        // for Debug
	GCMD_INTC_MAX
} eINTC_CMD;


typedef enum
{
	TRIG_LEVEL_HIGH = 0,
	TRIG_LEVEL_LOW,
	TRIG_EDGE_HIGH,
	TRIG_EDGE_LOW,
	TRIG_EDGE_BOTH
} eTRIG_MODE;

typedef enum
{
    IRQ_NUM_NULL = 0,

    IRQ_NUM_SGI_0 = IRQ_NUM_NULL,
    IRQ_NUM_SGI_1,
    IRQ_NUM_SGI_2,   
    IRQ_NUM_SGI_3,
    IRQ_NUM_SGI_MAX,

    IRQ_NUM_WDT = 32,       // (32+ 0)
    IRQ_NUM_TIMER0,         // (32+ 1)
    IRQ_NUM_TIMER1,         // (32+ 2)
    IRQ_NUM_DMA_CHANNEL0,   // (32+ 3)
    IRQ_NUM_DMA_CHANNEL1,   // (32+ 4)
    IRQ_NUM_DMA_CHANNEL2,   // (32+ 5)
    IRQ_NUM_DMA_CHANNEL3,   // (32+ 6)
    IRQ_NUM_DMA_ABORT,      // (32+ 7)
    IRQ_NUM_I2C0,           // (32+ 8)
    IRQ_NUM_I2C1,           // (32+ 9)
    IRQ_NUM_SPI0,           // (32+10)
    IRQ_NUM_SPI1,           // (32+11)
    IRQ_NUM_UART0,          // (32+12)
    IRQ_NUM_UART1,          // (32+13)

    IRQ_NUM_REV0,           // (32+14)
    IRQ_NUM_REV1,           // (32+15)
    IRQ_NUM_VDUMP,          // (32+16)

    IRQ_NUM_ISP0,           // (32+17)
    IRQ_NUM_ISP1,           // (32+18)
    IRQ_NUM_ISP2,           // (32+19)
    IRQ_NUM_ISP3,           // (32+20)
    IRQ_NUM_ISP4,           // (32+21)
    IRQ_NUM_ISP5,           // (32+22)
    IRQ_NUM_ISP6,           // (32+23)
    IRQ_NUM_ISP7,           // (32+24)
    IRQ_NUM_ISP8,           // (32+25)

    IRQ_NUM_EXT_INT0,       // (32+26)
    IRQ_NUM_TSENSOR,        // (32+27)

    IRQ_NUM_CAN,            // (32+28)

    IRQ_NUM_SUB_TIMER0,     // (32+29)
    IRQ_NUM_SUB_TIMER1,     // (32+30)
    IRQ_NUM_SUB_TIMER2,     // (32+31)

    MAX_IRQ_NUM,

    FIQ_NUM_NULL = MAX_IRQ_NUM,
    MAX_FIQ_NUM
} eINT_NUM;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32  ncLib_INTC_Open(void);
extern INT32  ncLib_INTC_Close(void);
extern INT32  ncLib_INTC_Read(void);
extern INT32  ncLib_INTC_Write(void);
extern INT32  ncLib_INTC_Control(eINTC_CMD Cmd, ...);

extern void   ncLib_INTC_IrqHandler(void);
extern void   ncLib_INTC_FiqHandler(void);




#endif /* __INTC_LIB_H__ */
