/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : WDT_Lib.h
*
*  @brief   : This file is WDT controller API for NEXTCHIP standard library
*
*  @author  : alessio / TS Group / SoC SW Team
*
*  @date    : 2016.02.12
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __WDT_LIB_H__
#define __WDT_LIB_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* WDT GENERIC & SPECIFIC COMMANDS
*/

typedef enum _WDT_CMD
{
    /*
    * Generic Commands
    */

    GCMD_WDT_INIT = 0,
    GCMD_WDT_DEINIT,

    GCMD_WDT_RUN,
    GCMD_WDT_STOP,
    GCMD_WDT_REFRESH,

    GCMD_WDT_INTR_DONE,
    GCMD_WDT_INTR_CLR,

    GCMD_WDT_CONNECT_ISR_HANDLER,
    GCMD_WDT_DISCONNECT_ISR_HANDLER,

    GCMD_WDT_MAX,

} eWDT_CMD;


typedef enum
{
    WDT_TIMER,      // watch-dog timer mode
    WDT_RESET,      // watch-dog reset mode
    MAX_OF_WDT_MODE
} eWDT_MODE;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

typedef struct
{
    eWDT_MODE   mode;   // 0 : Timer mode, 1 : Reset mode
    UINT32      mSec;   // Operation time (mSec Unit)
} tWDT_PARAM, *ptWDT_PARAM;


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncLib_WDT_Open(UINT32 nInputClk);
extern INT32 ncLib_WDT_Close(void);

extern INT32 ncLib_WDT_Read(void);
extern INT32 ncLib_WDT_Write(void);

extern INT32 ncLib_WDT_Control(eWDT_CMD Cmd, ...);


#endif  /* __WDT_LIB_H__ */


/* End Of File */
