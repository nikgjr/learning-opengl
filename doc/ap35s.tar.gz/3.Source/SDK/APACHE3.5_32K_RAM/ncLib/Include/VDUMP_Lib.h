/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : VDUMP_Lib.h
*
*  @brief   : This file is video dump controller API for NEXTCHIP standard library
*
*  @author  : alessio / TS Group / SoC SW Team
*
*  @date    : 2016.03.08
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __VDUMP_LIB_H__
#define __VDUMP_LIB_H__


/*
********************************************************************************
*                   INCLUDE
********************************************************************************
*/

#include <stdarg.h>


/*
********************************************************************************
*                   DEFINES
********************************************************************************
*/


/*
********************************************************************************
*                   ENUMERATION
********************************************************************************
*/

/*
* VDUMP GENERIC & SPECIFIC COMMANDS
*/

typedef enum _VDP_CMD
{
    /*
    * Generic Commands
    */

    GCMD_VDP_INIT = 0,
    GCMD_VDP_DEINIT,

    GCMD_VDP_START,

    GCMD_VDP_GET_ONEFRMSTT,
    GCMD_VDP_GET_LINECNT,
    GCMD_VDP_GET_PIXELCNT,
    GCMD_VDP_CHK_ERROR,

    GCMD_VDP_INTR_DONE,

    GCMD_VDP_CONNECT_ISR_HANDLER,
    GCMD_VDP_DISCONNECT_ISR_HANDLER,

    GCMD_VDP_MAX,

} eVDP_CMD;


typedef enum
{
    VDP_CH0,
    VDP_CH1,
    VDP_CH2,
    MAX_OF_VDP_CH
} eVDP_CH;

typedef enum
{
    VDP_I_PRE_YEDGE_PATH,
    VDP_I_DEFOG_PATH,
    VDP_I_HPF_PATH,
    VDP_I_OPD_PATH,
    MAX_OF_VDP_INPUT_PATH
} eVDP_INPUT_PATH;

typedef enum
{
    VDP_I_YUV_FORMAT,
    VDP_I_RGB_FORMAT,
    MAX_OF_VDP_INPUT_FORMAT
} eVDP_INPUT_FORMAT;

typedef enum
{
    VDP_YUV444,
    VDP_YUV422,
    MAX_OF_VDP_VUV_FORMAT
} eVDP_YUV_FORMAT;

typedef enum
{
    VDP_O_Y_FORMAT,
    VDP_O_UV_FORMAT,
    VDP_O_G_FORMAT,
    VDP_O_B_FORMAT,
    VDP_O_R_FORMAT,
    MAX_OF_VDP_OUTPUT_FORMAT
} eVDP_OUTPUT_FORMAT;

typedef enum
{
    VDP_P_CRCBY_BGR,
    VDP_P_CBCRY_GBR,
    VDP_P_CRYCB_BRG,
    VDP_P_CBYCR_GRB,
    VDP_P_YCRCB_RBG,
    VDP_P_YCBCR_RGB,
    MAX_OF_VDP_PARSING
} eVDP_PARSING;

typedef enum
{
    VDP_INTR_I_VSYNC_END    = 0x01,
    VDP_INTR_I_VSYNC_START  = 0x02,
    VDP_INTR_CH0_END        = 0x04,
    VDP_INTR_CH0_START      = 0x08,
    VDP_INTR_CH1_END        = 0x10,
    VDP_INTR_CH1_START      = 0x20,
    VDP_INTR_CH2_END        = 0x40,
    VDP_INTR_CH2_START      = 0x80,
    MAX_OF_VDP_INTR
} eVDP_INTR;

typedef enum
{
    VDP_TYPE_FRAME_START,
    VDP_TYPE_FRAME_END,
    MAX_OF_VDP_FRAME_TYPE
} eVDP_FRAME_TYPE;

typedef enum
{
    VDP_ENDIAN_LITTLE,
    VDP_ENDIAN_BIG,
    MAX_OF_VDP_ENDIAN
} eVDP_ENDIAN;

typedef enum
{
    VDP_BIT_8,
    VDP_BIT_16,
    VDP_BIT_32,
    MAX_OF_VDP_DATA_BIT
} eVDP_DATA_BIT;

typedef enum
{
    VDP_BURST_1,
    VDP_BURST_2,
    VDP_BURST_4,
    VDP_BURST_6_RESERVED,
    VDP_BURST_8,
    VDP_BURST_16,
    VDP_BURST_32_RESERVED,
    VDP_BURST_64_RESERVED,
    VDP_BURST_128_RESERVED,
    MAX_OF_VDP_WRITE_BURST
} eVDP_WRITE_BURST;

typedef enum
{
    VDP_DBG_DISABLE,
    VDP_DBG_ENABLE,
    MAX_OF_VDP_DBG_ENABLE
} eVDP_DBG_ENABLE;

typedef enum
{
    VDP_DBG_STT_IDLE,
    VDP_DBG_STT_ONE_FRM,
    VDP_DBG_STT_WRITE_MODE, // Write Start
    VDP_DBG_STT_HSYNC_MASK, // Write End
    VDP_DBG_STT_WAIT,
    MAX_OF_VDP_DBG_STATUS
} eVDP_DBG_STATUS;

typedef enum
{
    VDP_ERR_DMA_BUFF_OVER  = 0x1,
    VDP_ERR_DUMP_TIME_OVER = 0x2,
    MAX_OF_VDP_ERROR_STATUS
} eVDP_ERROR_STATUS;


/*
********************************************************************************
*                   TYPEDEFS
********************************************************************************
*/

typedef struct
{
    BOOL nChEnable;             // Channel n Enable

    eVDP_ENDIAN nEndian;
    eVDP_PARSING nParsing;
    eVDP_DATA_BIT nBit;
    eVDP_WRITE_BURST nBurst;

    UINT32 nDumpAddress;        // Image Output Data Save Base Address
    UINT32 nTotalLength;        // Get Output Total Length
} tVDP_ChInfo, *ptVDP_ChInfo;

typedef struct
{
    BOOL   ScaleEnable;     // 0 : Crop, 1 : Scaler used

    UINT32 InputH;          // Image Input Horizontal Length
    UINT32 InputV;          // Image Input Vertical Length

    UINT32 OutputH;         // Image Output Horizontal Length
    UINT32 OutputV;         // Image Output Vertical Length

    //UINT32 CropStartX;      // Scaler Start X Position
    //UINT32 CropStartY;      // Scaler Start Y Position

    //UINT32 OutputHScale;    // Image Output Horizontal Down Scaler Length
    //UINT32 OutputVScale;    // Image Output Vertical Down Scaler Length

    eVDP_FRAME_TYPE   nFrameEdge;   // Start, End Select
    eVDP_INPUT_PATH   nInputPath;   // VDUMP Input Path Select
    eVDP_INPUT_FORMAT nInFormat;    // YUV, RGB Format Select
    eVDP_YUV_FORMAT   nYUVSelect;   // YUV444, YUV422 Format Select
    eVDP_INTR nIntr;

    eVDP_DBG_ENABLE nDBGEnable;     // test mode enable
    tVDP_ChInfo nDumpCh[MAX_OF_VDP_CH];
} tVDP_PARAM, *ptVDP_PARAM;


/*
********************************************************************************
*                   CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*                   VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*                   FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncLib_VDP_Open(void);
extern INT32 ncLib_VDP_Close(void);

extern INT32 ncLib_VDP_Read(void);
extern INT32 ncLib_VDP_Write(void);

extern INT32 ncLib_VDP_Control(eVDP_CMD Cmd, ...);


#endif /* __VDP_LIB_H__ */


/* End Of File */
