/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Debug_Lib.h
*
*  @brief   : Test Development Kit message debug header file.
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.06
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __DEBUG_LIB__
#define __DEBUG_LIB__


/*
********************************************************************************
*               INCLUDE FILES
********************************************************************************
*/

#include "Uart_Lib.h"


/*
********************************************************************************
*               DEFINITIONS
********************************************************************************
*/

/*
* Debug UART Channel
*/

#define	DBG_PORT            UART_CH0    // channel 0 UART port used


/*
* Debug Log Zone
*/
#define MSGPOS				4

#define MSGERR				(0x1<<0)	// Error message enable
#define MSGWARN				(0x1<<1)	// Warning message enable
#define MSGINFO				(0x1<<2)	// Information message enable

#define MSGOFF				(0x0<<0)
#define MSGFULL				(MSGINFO|MSGWARN|MSGERR)

/* + Only SDK Zone : Debug message enable + */
#define MSGRECQ				(1<<4)
#define MSGENC				(1<<5)
#define MSGDMA				(1<<6)
#define MSGGPIO				(1<<7)
#define MSGI2C				(1<<8)
#define MSGINC				(1<<9)
#define MSGSCU				(1<<10)
#define MSGSF				(1<<11)
#define MSGSSP				(1<<12)
#define MSGTC				(1<<13)
#define MSGST				(1<<14)
#define MSGUART				(1<<15)
#define MSGDBG				(1<<16)
#define MSGWDT				(1<<17)
#define MSGVTS				(1<<18)
#define MSGCAN				(1<<19)
#define MSGEVT				(1<<20)
#define MSGISP				(1<<21)
#define MSGAVB				(1<<22)
#define MSGMAC				(1<<23)
/* - Only SDK Zone - */

/*
* Re-define debug functions for all log level
*/

// Used in application layer
#define DEBUGMSG(zone, fmt, args...)  \
        //do { if(zone) ncLib_DEBUG_Printf(zone, fmt, ## args); } while(0)

// Used in SDK layer
#define DEBUGMSG_SDK(zone, fmt, args...)  \
        //do { if(zone<<MSGPOS) ncLib_DEBUG_Printf(zone<<MSGPOS, fmt, ## args); } while(0)

#define DBGSCANF(msg)               ncLib_DEBUG_Scanf(msg)


/*
* Error Messages
*/

#define LOG_ERR_OPEN                        "Open Error"
#define LOG_ERR_CLOSE                       "Close Error"
#define LOG_ERR_READ                        "Read Error"
#define LOG_ERR_WRITE                       "Write Error"
#define LOG_ERR_CONTROL                     "Control Error"

#define LOG_ERR_ALREADY_OPEN                "This Module is already Opened"
#define LOG_ERR_NOT_OPEN                    "This Module is not Opened"
#define LOG_ERR_BUSY_CH                     "This Channel is busy"
#define LOG_ERR_INPUT_CLK                   "Input Clock Error"
#define LOG_ERR_ISR_CONNECT                 "ISR Connection Fail"
#define LOG_ERR_NOT_SUPPORT_FUN             "Not Support This Function"
#define LOG_ERR_NOT_SUPPORT_CMD             "Not Support This Command"
#define LOG_ERR_UNKNOWN_CMD                 "Unknown Command"
#define LOG_ERR_ARG_NUM                     "Wrong Argument Number"
#define LOG_ERR_NO_CMD_END                  "No CMD_END"


/*
* ETC
*/
#define CLEAR_SCREEN            "\033[2J"
#define MOVE_CURSOR_LEFT        "\033[1D"
#define MOVE_CURSOR_LEFT4       "\033[4D"


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* DEBUG GENERIC & SPECIFIC COMMANDS
*/

typedef enum _DBG_CMD
{
    /*
    * Generic Commands
    */

    GCMD_DBG_INIT = 0,
    GCMD_DBG_DEINIT,

    GCMD_DBG_SET_BAUDRATE,
    GCMD_DBG_APP_LOG_ZONE,
    GCMD_DBG_SDK_LOG_ZONE,

    GCMD_DBG_MAX,

} eDBG_CMD;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncLib_DEBUG_Open(UINT32 nInputClk);
extern INT32 ncLib_DEBUG_Close(void);

extern INT32 ncLib_DEBUG_Read(void);
extern INT32 ncLib_DEBUG_Write(void);

extern INT32 ncLib_DEBUG_Control(eDBG_CMD Cmd, ...);

// Debug Message Library
extern void ncLib_DEBUG_Printf(UINT32 DebugZone, const char *fmt, ...);
extern UINT32 ncLib_DEBUG_Scanf(char *buf);
extern UINT32 ncLib_DEBUG_Scanf2(char *buf);


#endif  /* __DEBUG_LIB__ */


/* End Of File */
