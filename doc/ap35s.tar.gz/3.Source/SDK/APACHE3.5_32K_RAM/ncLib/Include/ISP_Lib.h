/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : ISP_Lib.h
*
*  @brief   : This file is ISP controller API for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __ISP_LIB_H__
#define __ISP_LIB_H__


/*
********************************************************************************
*                   INCLUDE
********************************************************************************
*/

#include <stdarg.h>
#include "APACHE35.h"
#include "SW_Register_Lib.h"

/*
********************************************************************************
*                   DEFINES
********************************************************************************
*/


/*
********************************************************************************
*                   ENUMERATION
********************************************************************************
*/

/*
* ISP GENERIC & SPECIFIC COMMANDS
*/

typedef enum _ISP_CMD
{
    /*
    * Generic Commands
    */

    GCMD_ISP_SYS_INIT = 0,
    GCMD_ISP_FUNCTION_INIT,
    GCMD_ISP_2A_FUNTION,
    GCMD_ISP_SUB_FUNCTION,
    GCMD_ISP_APPLICATION,
    GCMD_ISP_DEINIT,

    /* ISP System Control */
    GCMD_ISP_ALL_SAVE,
    GCMD_ISP_ALL_LOAD,
    GCMD_ISP_SR_SAVE,
    GCMD_ISP_SR_LOAD,
    GCMD_ISP_Default_LOAD,
    
    GCMD_ISP_RESET,

    GCMD_ISP_CONNECT_ISR_HANDLER,
    GCMD_ISP_DISCONNECT_ISR_HANDLER,


    GCMD_ISP_GET_INTR_VSYNC, 
    GCMD_ISP_CLR_INTR_VSYNC, 
    //GCMD_ISP_CONNECT_USER_HANDLER,
    //GCMD_ISP_DISCONNECT_USER_HANDLER,

	GCMD_ISP_SENSOR_SVC_INIT,
	
    GCMD_ISP_MAX,


    /*
    * Specific Commands
    */

    SCMD_ISP_DUMMY = 100,

    SCMD_ISP_MAX
} eISP_CMD;

typedef enum
{
    ISP_INTR_IN_VSYNCPOS = 0,
    ISP_INTR_IN_VSYNCNEG,
    ISP_INTR_OUT_VSYNCPOS,
    ISP_INTR_OUT_VSYNCNEG,
    ISP_INTR_DPCSCAN,
} eISP_INTR_NUM;

/*
********************************************************************************
*                   TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*                   CONSTANT DEFINITIONS
********************************************************************************
*/
#define ISP_ADDRESS_START       	BANK00_START_ADDRESS            /* Define first ISP register bank */
#define ISP_ADDRESS_END         	BANK2D_START_ADDRESS + 0x100    /* Define last ISP register bank */

/*
********************************************************************************
*                   VARIABLE DECLARATIONS
********************************************************************************
*/

extern volatile STRUCT_SW_CONTROL_REGISTER     rSWReg;

/*
********************************************************************************
*                   FUNCTION DECLARATIONS
********************************************************************************
*/
extern INT32 ncLib_ISP_Open(void);
extern INT32 ncLib_ISP_Close(void);
extern INT32 ncLib_ISP_Read(void);
extern INT32 ncLib_ISP_Write(void);
extern INT32 ncLib_ISP_Control(eISP_CMD Cmd, ...);


#endif /* __ISP_LIB_H__ */


/* End Of File */
