/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : ISP_Lib.h
*
*  @brief   : This file is ISP controller API for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __TASK_LIB_H__
#define __TASK_LIB_H__


/*
********************************************************************************
*                   INCLUDE
********************************************************************************
*/

#include <stdarg.h>
#include "APACHE35.h"

/*
********************************************************************************
*                   DEFINES
********************************************************************************
*/


/*
********************************************************************************
*                   ENUMERATION
********************************************************************************
*/

/*
* ISP GENERIC & SPECIFIC COMMANDS
*/

typedef enum
{
    /*
    * Generic Commands
    */

    eTASK_INIT = 0,
    eTASK_OPD,
    eTASK_AE,
    eTASK_WB,
    eTASK_WDR,
    eTASK_IMAGE_TUNE,
    eTASK_LSC,
    eTASK_NR,
    eTASK_BLC,
    eTASK_DWDR,
    eTASK_DEFOG,
    eTASK_DPC,
    eTASK_VIEWMODE,
    eTASK_FLICKER,
    eTASK_CATEGORY,    
    eTASK_MAX,
} etISP_TASK_CMD_TYPE;

/*
********************************************************************************
*                   TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*                   CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*                   VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*                   FUNCTION DECLARATIONS
********************************************************************************
*/

#ifdef API_FUNCTION_CALL
extern INT32 ncLib_Task_Open(void);
extern INT32 ncLib_Task_Close(void);
extern INT32 ncLib_Task_Read(void);
extern INT32 ncLib_Task_Write(void);
#endif 

extern INT32 ncLib_Task_Control(etISP_TASK_CMD_TYPE Cmd, ...);


#endif /* __TASK_LIB_H__ */


/* End Of File */
