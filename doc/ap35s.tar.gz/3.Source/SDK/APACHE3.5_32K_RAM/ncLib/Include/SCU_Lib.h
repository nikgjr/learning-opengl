/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SCU_Lib.h
*
*  @brief   : APACHE3 SCU Library Header File
*
*  @author  : parkjy / SoC SW Team / TS Group
*
*  @date    : 2016.01.27
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note
*
*
*
*
********************************************************************************
*/
#ifndef __SCU_LIB_H__
#define __SCU_LIB_H__

/*
********************************************************************************
*   INCLUDE FILES
********************************************************************************
*/

/*
********************************************************************************
*   ENUMERATION
********************************************************************************
*/
// svn://192.168.20.21/APACHE3.5/trunk/M1.01-80.FPGA_xx/FPGA_DB_xxxx/APACHE3.5M1_FPGA_DB_Release_Note.xlsx
typedef enum _SCU_BOARD_TYPE
{
    SCU_BD_TYPE_FPGA_01 = 0,    // apache3p5_2016_0113 - Not Support
    SCU_BD_TYPE_FPGA_02,        // r560-a1_2016_0126
    SCU_BD_TYPE_FPGA_03,        // r560-a8_2016_0131
    SCU_BD_TYPE_FPGA_04,        // r627-a1_2016_0204
    SCU_BD_TYPE_FPGA_05,        // r730-a1_2016_0222
    SCU_BD_TYPE_FPGA_06,        // r844-a1_2016_0308
    SCU_BD_TYPE_FPGA_07,        // r1061-a1_2016_0325
    SCU_BD_TYPE_FPGA_08,
    SCU_BD_TYPE_FPGA_09,
    SCU_BD_TYPE_FPGA_10,
    SCU_BD_TYPE_ES,
    SCU_BD_TYPE_MAX
} eSCU_BOARD_TYPE;

typedef enum _SCU_CMD
{
    /*
     * Generic SCU Commands
     */
    GCMD_SCU_GET_STRAP_INFO = 0,
    GCMD_SCU_GET_CLK,

    GCMD_SCU_SET_PINMUX,
    GCMD_SCU_SET_PINMUX_GROUP,      // Apache3.5 Not Used

    GCMD_SCU_GET_DATA,
    GCMD_SCU_SET_DATA,

    GCMD_SCU_GET_MP2V,
    GCMD_SCU_GET_MV2P,

    GCMD_SCU_MAX,

    /*
     * Specific SCU Commands
     */
    SCMD_SCU_DB_NUM = 100, 
    SCMD_SCU_MAX,
} eSCU_CMD;

/*
 * Clock ID for Apache3.5
 */
typedef enum _SCU_CLK_ID
{
    SCU_CLK_ID_CPU = 0,     // CPU Clock
    SCU_CLK_ID_AXI,         // AXI0 Clock
    SCU_CLK_ID_AHB,         // Apache3.5 Not Used
    SCU_CLK_ID_APB,         // APB Clock
    SCU_CLK_ID_ENC,         // Apache3.5 Not Used
    SCU_CLK_ID_SSPI,        // Standard SPI Clock
    SCU_CLK_ID_QSPI,        // Quad SPI Clock for sFlash
    SCU_CLK_ID_UART,        // UART Clock
    SCU_CLK_ID_TIMER,       // Timer Clock
    SCU_CLK_ID_WDT,         // WDT Clock
    SCU_CLK_ID_I2C,         // I2C Clock
    SCU_CLK_ID_CAN,         // CAN Clock
    SCU_CLK_ID_DDR,         // DDR Clock

    SCU_CLK_ID_IISP,
    SCU_CLK_ID_MISP,
    SCU_CLK_ID_OISP,
    SCU_CLK_ID_OF,
    SCU_CLK_ID_656,
    SCU_CLK_ID_VDO,
    SCU_CLK_ID_CVBS,
    SCU_CLK_ID_VEN,
    SCU_CLK_ID_DAC,
    SCU_CLK_ID_WDR,
    SCU_CLK_ID_OSG,
    SCU_CLK_ID_LDC,
    SCU_CLK_ID_OSD,
    SCU_CLK_ID_ADC, 
    SCU_CLK_ID_TS,
     
    SCU_CLK_ID_MAX
} eSCU_CLK_ID;

/*
 * Pad ID for Apache3.5
 */
typedef enum _PAD_ID
{
    PAD_GPIO0 = 0,
    PAD_GPIO1,
    PAD_GPIO2,
    PAD_GPIO3,
    PAD_GPIO4,
    PAD_EXTINT,

    PAD_I2C0_SCL,
    PAD_I2C0_SDA,
    PAD_I2C1_SCL,
    PAD_I2C2_SDA,

    PAD_CAN_RX,
    PAD_CAN_TX,
    PAD_UART_RX,
    PAD_UART_TX,

    PAD_SPI2_CSN0,
    PAD_SPI2_CSN1,
    PAD_SPI2_DQ0,
    PAD_SPI2_DQ1,
    PAD_SPI2_DQ2,
    PAD_SPI2_DQ3,
    PAD_SPI2_SCK,

    PAD_SEN_CK_O,
    PAD_SEN_RSTN_O,
    PAD_SEN_PCK,
    PAD_SEN_PH,
    PAD_SEN_PV,
    PAD_SEN_PD0,
    PAD_SEN_PD1,
    PAD_SEN_PD2,
    PAD_SEN_PD3,
    PAD_SEN_PD4,
    PAD_SEN_PD5,
    PAD_SEN_PD6,
    PAD_SEN_PD7,
    PAD_SEN_PD8,
    PAD_SEN_PD9,
    PAD_SEN_PD10,
    PAD_SEN_PD11,

    PAD_VOUT_CK_O,
    PAD_VOUT_VSYNC,
    PAD_VOUT_HSYNC,
    PAD_VOUT_HACT,
    PAD_VOUT_B0,
    PAD_VOUT_B1,
    PAD_VOUT_B2,
    PAD_VOUT_B3,
    PAD_VOUT_B4,
    PAD_VOUT_B5,
    PAD_VOUT_B6,
    PAD_VOUT_B7,
    PAD_VOUT_G0_C0,
    PAD_VOUT_G1_C1,
    PAD_VOUT_G2_C2,
    PAD_VOUT_G3_C3,
    PAD_VOUT_G4_C4,
    PAD_VOUT_G5_C5,
    PAD_VOUT_G6_C6,
    PAD_VOUT_G7_C7,
    PAD_VOUT_R0_Y0,
    PAD_VOUT_R1_Y1,
    PAD_VOUT_R2_Y2,
    PAD_VOUT_R3_Y3,
    PAD_VOUT_R4_Y4,
    PAD_VOUT_R5_Y5,
    PAD_VOUT_R6_Y6,
    PAD_VOUT_R7_Y7,

    PAD_MAX
} ePAD_ID;

typedef enum _PAD_FUNC
{
    PAD_FUNC_0 = 0,
    PAD_FUNC_1,
    PAD_FUNC_2,
    PAD_FUNC_3,
    PAD_FUNC_4,
        
    PAD_FUNC_MAX
} ePAD_FUNC;











/*
********************************************************************************
*   DEFINES
********************************************************************************
*/


/*
********************************************************************************
*   TYPEDEFS
********************************************************************************
*/

/*
********************************************************************************
*   CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*   VARIABLE DECLARATIONS
********************************************************************************
*/

/*
********************************************************************************
*   FUNCTION DECLARATIONS
********************************************************************************
*/
extern INT32 ncLib_SCU_Open(void);
extern INT32 ncLib_SCU_Close(void);
extern INT32 ncLib_SCU_Read(void);
extern INT32 ncLib_SCU_Write(void);
extern INT32 ncLib_SCU_Control(eSCU_CMD Cmd, ...);



#endif  /* __SCU_LIB_H__ */


/* End Of File */
