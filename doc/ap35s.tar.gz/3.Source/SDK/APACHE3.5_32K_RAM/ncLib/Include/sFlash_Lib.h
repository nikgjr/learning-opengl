/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : sFlash_Lib.h
*
*  @brief   : This file is sFlash controller API for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.01.19
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note
*
*
*
*
********************************************************************************
*/
#ifndef __SFLASH_LIB_H__
#define __SFLASH_LIB_H__

/*
********************************************************************************
*                                 INCLUDE
********************************************************************************
*/
#include <stdarg.h>










/*
********************************************************************************
*                   	          DEFINES
********************************************************************************
*/
#define MEMORY_CAPACITY_512Kb					0x00
#define MEMORY_CAPACITY_1Mb						0x01
#define MEMORY_CAPACITY_2Mb						0x02
#define MEMORY_CAPACITY_4Mb						0x03
#define MEMORY_CAPACITY_8Mb						0x04
#define MEMORY_CAPACITY_16Mb					0x05
#define MEMORY_CAPACITY_32Mb					0x06
#define MEMORY_CAPACITY_64Mb					0x07
#define MEMORY_CAPACITY_128Mb					0x08

#define SF_BLOCK_SIZE							(64*KB)
#define SF_SECTOR_SIZE							(4*KB)
#define SF_PAGE_SIZE							(256)









/*
********************************************************************************
*                                ENUMERATION
********************************************************************************
*/
typedef enum _SF_CMD
{
    /*
    * Generic Serial Flash Commands
    */
    GCMD_SF_DUMMY = 0,

    GCMD_SF_INIT,
    GCMD_SF_DEINIT,
    GCMD_SF_SET_BITRATE,
    GCMD_SF_BLOCK_ERASE,
    GCMD_SF_SECTOR_ERASE,
    GCMD_SF_READ_DATA,
    GCMD_SF_READ_PAGE,
    GCMD_SF_WRITE_DATA,
    GCMD_SF_WRITE_PAGE,
    GCMD_SF_READ_ID,
    GCMD_SF_READ_STATUS,
    GCMD_SF_WRTIE_STATUS,
    GCMD_SF_READ_STATUS2,
    GCMD_SF_WRITE_STATUS2,
    GCMD_SF_WAIT_WIP,
    GCMD_SF_WRITE_EN,
    GCMD_SF_WRITE_DS,

    GCMD_SF_MAX,

    /*
    * Specific Serial Flash Commands
    */
    SCMD_SF_OSG_READ_EN = 100,
    SCMD_SF_OSG_READ_DS,	
    SCMD_SF_OSG_READ_DATA,
    SCMD_SF_LUT_READ_DATA,
    SCMD_SF_GET_PAD_CTRL,
    SCMD_SF_FREE_PAD_CTRL,
    SCMD_SF_MAX,
} eSF_CMD;



typedef enum _SF_BITRATE
{
    SF_BITRATE_1Mbps = 1,   // 1Mbps
    SF_BITRATE_2Mbps,       // 2Mbps
    SF_BITRATE_3Mbps,       // 3Mbps
    SF_BITRATE_4Mbps,      	// 4Mbps
    SF_BITRATE_5Mbps,      	// 5Mbps
    SF_BITRATE_6Mbps,      	// 6Mbps
    SF_BITRATE_7Mbps,      	// 7Mbps
    SF_BITRATE_8Mbps,     	// 8Mbps
    SF_BITRATE_9Mbps,      	// 9Mbpss
    SF_BITRATE_10Mbps,     	// 10Mbps
    SF_BITRATE_11Mbps,     	// 11Mbps
    SF_BITRATE_12Mbps,     	// 12Mbps
    SF_BITRATE_13Mbps,     	// 13Mbps
    SF_BITRATE_14Mbps,     	// 14Mbps
    SF_BITRATE_15Mbps,     	// 15Mbps
    SF_BITRATE_16Mbps,     	// 16Mbps
    SF_BITRATE_17Mbps,     	// 17Mbps
    SF_BITRATE_18Mbps,     	// 18Mbps
    SF_BITRATE_19Mbps,     	// 19Mbps
    SF_BITRATE_20Mbps,     	// 20Mbps
    SF_BITRATE_21Mbps,     	// 21Mbps
    SF_BITRATE_22Mbps,     	// 22Mbps
    SF_BITRATE_23Mbps,     	// 23Mbps
    SF_BITRATE_24Mbps,     	// 24Mbps
    SF_BITRATE_25Mbps,     	// 25Mbps
    SF_BITRATE_26Mbps,     	// 26Mbps
    SF_BITRATE_27Mbps,     	// 27Mbps
    SF_BITRATE_28Mbps,     	// 28Mbps
    SF_BITRATE_29Mbps,     	// 29Mbps
    SF_BITRATE_30Mbps,     	// 30Mbps
    SF_BITRATE_31Mbps,     	// 31Mbps
    SF_BITRATE_32Mbps,     	// 32Mbps
    SF_BITRATE_33Mbps,     	// 33Mbps
    SF_BITRATE_34Mbps,     	// 34Mbps
    SF_BITRATE_35Mbps,     	// 35Mbps
    SF_BITRATE_36Mbps,     	// 36Mbps
    SF_BITRATE_37Mbps,     	// 37Mbps
    SF_BITRATE_38Mbps,     	// 38Mbps
    SF_BITRATE_39Mbps,     	// 39Mbps
    SF_BITRATE_40Mbps,     	// 40Mbps
} SF_BITRATE;








/*
********************************************************************************
*                                 TYPEDEFS
********************************************************************************
*/
typedef struct _tSF_INIT_PARAM
{
    UINT8       mChNum;             // SPI Channel Number
    BOOL        mDmaMode;           // 0: PIO, 1: DMA mode
    BOOL        mQuadMode;          // 0: Standard SPI, 1: Quad SPI

    SF_BITRATE  mBitRate;           // Mbps
} tSF_INIT_PARAM, *ptSF_INIT_PARAM;


typedef struct _tSFLASH_ID {
    UINT8   mbManufacture;          // Manufacture ID
    UINT8   mbMemoryType;           // Memory Type
    UINT8   mbMemoryCapacity;       // Memory Capacity
} tSFLASH_ID, *ptSFLASH_ID;











/*
********************************************************************************
*                           CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                           VARIABLE DECLARATIONS
********************************************************************************
*/

/*
********************************************************************************
*                            FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32  ncLib_SF_Open(UINT32 nInputClk);
extern INT32  ncLib_SF_Close(void);
extern INT32  ncLib_SF_Read(UINT32 Addr, UINT8 *pData, UINT32 Size);
extern INT32  ncLib_SF_Write(UINT32 Addr, UINT8 *pData, UINT32 Size);
extern INT32  ncLib_SF_Control(eSF_CMD Cmd, ...);



#endif /* __SFLASH_LIB_H__ */


