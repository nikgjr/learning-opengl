/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : GPIO_Lib.h
*
*  @brief   : This file is GPIO controller API for NEXTCHIP standard library
*
*  @author  : Parkjy / SoCSW Team / TS Group
*
*  @date    : 2016.02.02
*
*  @version : Version 1.0.0
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __GPIO_LIB_H__
#define __GPIO_LIB_H__


/*
********************************************************************************
*                   INCLUDE
********************************************************************************
*/

#include <type.h>










/*
********************************************************************************
*                   DEFINES
********************************************************************************
*/


/*
********************************************************************************
*                   ENUMERATION
********************************************************************************
*/

/*
* GPIO GENERIC & SPECIFIC COMMANDS
*/

typedef enum _GPIO_CMD
{
    /*
    * Generic Commands
    */

    GCMD_GPIO_ENA = 0,
    GCMD_GPIO_DIS,

    GCMD_GPIO_SET_DIR,
    GCMD_GPIO_SET_DATA,
    GCMD_GPIO_GET_DATA,

    GCMD_GPIO_MAX,

} eGPIO_CMD;


typedef enum
{
    GPIO_GROUP_A,           // Apache3.5 [32:0]
    GPIO_GROUP_B,           // Apache3.5 [31:0]
    GPIO_GROUP_C,           // Apache3.5 [7:0]
    GPIO_GROUP_D,           // Apache3.5 Not Used.
    MAX_OF_GPIO_GROUP
} eGPIO_GROUP;

typedef enum
{
    GPIO_PORT0,
    GPIO_PORT1,
    GPIO_PORT2,
    GPIO_PORT3,
    GPIO_PORT4,
    GPIO_PORT5,
    GPIO_PORT6,
    GPIO_PORT7,

    GPIO_PORT8,
    GPIO_PORT9,
    GPIO_PORT10,
    GPIO_PORT11,
    GPIO_PORT12,
    GPIO_PORT13,
    GPIO_PORT14,
    GPIO_PORT15,

    GPIO_PORT16,
    GPIO_PORT17,
    GPIO_PORT18,
    GPIO_PORT19,
    GPIO_PORT20,
    GPIO_PORT21,
    GPIO_PORT22,
    GPIO_PORT23,

    GPIO_PORT24,
    GPIO_PORT25,
    GPIO_PORT26,
    GPIO_PORT27,
    GPIO_PORT28,
    GPIO_PORT29,
    GPIO_PORT30,
    GPIO_PORT31,
    MAX_OF_GPIO_PORT,
    GPIO_PORT_NOT_USED
} eGPIO_PORT;

typedef enum
{
    GPIO_LOW,
    GPIO_HIGH,
    MAX_OF_GPIO_DATA
} eGPIO_DATA;

typedef enum
{
    GPIO_DIR_IN,    
    GPIO_DIR_OUT,
    MAX_OF_GPIO_DIR
} eGPIO_DIR;


/*
********************************************************************************
*                   TYPEDEFS
********************************************************************************
*/

typedef struct
{
    eGPIO_GROUP group;
    eGPIO_PORT  port;
    eGPIO_DIR   dir;
    eGPIO_DATA  data;
} tGPIO_PARAM, *ptGPIO_PARAM;


/*
********************************************************************************
*                   CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*                   VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*                   FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncLib_GPIO_Open(void);
extern INT32 ncLib_GPIO_Close(void);

extern INT32 ncLib_GPIO_Read(void);
extern INT32 ncLib_GPIO_Write(void);

extern INT32 ncLib_GPIO_Control(eGPIO_CMD Cmd, ...);


#endif /* __GPIO_LIB_H__ */


/* End Of File */
