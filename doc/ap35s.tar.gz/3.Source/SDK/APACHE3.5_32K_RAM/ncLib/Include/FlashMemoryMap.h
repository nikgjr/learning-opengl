/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : FlashMemoryMap.h
*
*  @brief   : This file is Flash Memory Map define
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.1.0
*
********************************************************************************
*  @note    : 2016.01.09 - Flash Memory Map Version 0.1.0
*
********************************************************************************
*/

#ifndef __FLASH_MEMORY_MAP_H__
#define __FLASH_MEMORY_MAP_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/* Version is date */

#define VERSION_160109                  20160109
#define VERSION_160202                  20160202
#define VERSION_160304                  20160304
#define VERSION_160409_TEST             20160409

/* Version define */

#define FLASH_MEMORY_MAP_VERSION        VERSION_160304

/*
* FLASH MEMORY MAP -------------------------------------------------------------
*/

#if (FLASH_MEMORY_MAP_VERSION == VERSION_160109)

// Bootloader-BL2 Backup Area
#define FLASHMEMORY_BOOTLOADER_BACKUP_AREA_ADDRESS  0x001FC000
#define FLASHMEMORY_BOOTLOADER_BACKUP_AREA_SIZE     (16*1024)

// Firmware Application Backup Area
#define FLASHMEMORY_FIRMWARE_BACKUP_AREA_ADDRESS    0x001BC000
#define FLASHMEMORY_FIRMWARE_BACKUP_AREA_SIZE       (256*1024)

// ISP Register Backup Area
#define FLASHMEMORY_ISP_REG_BACKUP_AREA_ADDRESS     0x001B9000
#define FLASHMEMORY_ISP_REG_BACKUP_AREA_SIZE        (12*1024)

// Sensor Register Backup Area
#define FLASHMEMORY_SENSOR_REG_BACKUP_AREA_ADDRESS  0x001B7000
#define FLASHMEMORY_SENSOR_REG_BACKUP_AREA_SIZE     (8*1024)

// OSG Warning Image Area
#define FLASHMEMORY_OSG_WARNING_AREA_ADDRESS        0x001B5000
#define FLASHMEMORY_OSG_WARNING_AREA_SIZE           (8*1024)

// Reserved Area
#define FLASHMEMORY_RESERVED_AREA_ADDRESS           0x00196800
#define FLASHMEMORY_RESERVED_AREA_SIZE              (122*1024)

// OSG & LDC & FONT & ICON IMAGE Area
#define FLASHMEMORY_IMAGE_AREA_ADDRESS              0x0004E000
#define FLASHMEMORY_IMAGE_AREA_SIZE                 (1312*1024)

// OSG & LDC & FONT & ICON IMAGE Header Area
#define FLASHMEMORY_IMAGE_HEADER_AREA_ADDRESS 		0x0004B000
#define FLASHMEMORY_IMAGE_HEADER_AREA_SIZE          (12*1024)

// DPC Data Area
#define FLASHMEMORY_DPC_AREA_ADDRESS                0x00049000
#define FLASHMEMORY_DPC_AREA_SIZE                   (8*1024)

// Sensor Register Area
#define FLASHMEMORY_SENSOR_REG_AREA_ADDRESS         0x00047000
#define FLASHMEMORY_SENSOR_REG_AREA_SIZE            (8*1024)

// ISP Register Area
#define FLASHMEMORY_ISP_REG_AREA_ADDRESS            0x00044000
#define FLASHMEMORY_ISP_REG_AREA_SIZE               (12*1024)

// Firmware Application Area
#define FLASHMEMORY_FIRMWARE_APP_AREA_ADDRESS       0x00004000
#define FLASHMEMORY_FIRMWARE_APP_AREA_SIZE          (256*1024)

// Bootloader-BL2 Area
#define FLASHMEMORY_BOOTLOADER_AREA_ADDRESS         0x00000000
#define FLASHMEMORY_BOOTLOADER_AREA_SIZE            (16*1024)

//==============================================================================

#elif (FLASH_MEMORY_MAP_VERSION == VERSION_160202)

// Bootloader-BL2 Backup Area
#define FLASHMEMORY_BOOTLOADER_BACKUP_AREA_ADDRESS  0x001F8000
#define FLASHMEMORY_BOOTLOADER_BACKUP_AREA_SIZE     (32*1024)

// Firmware Application Backup Area
#define FLASHMEMORY_FIRMWARE_BACKUP_AREA_ADDRESS    0x001B8000
#define FLASHMEMORY_FIRMWARE_BACKUP_AREA_SIZE       (256*1024)

// ISP Register Backup Area
#define FLASHMEMORY_ISP_REG_BACKUP_AREA_ADDRESS     0x001B5000
#define FLASHMEMORY_ISP_REG_BACKUP_AREA_SIZE        (12*1024)

// Sensor Register Backup Area
#define FLASHMEMORY_SENSOR_REG_BACKUP_AREA_ADDRESS  0x001B3000
#define FLASHMEMORY_SENSOR_REG_BACKUP_AREA_SIZE     (8*1024)

// OSG Warning Image Area
#define FLASHMEMORY_OSG_WARNING_AREA_ADDRESS        0x001B1000
#define FLASHMEMORY_OSG_WARNING_AREA_SIZE           (8*1024)

// Reserved Area
#define FLASHMEMORY_RESERVED_AREA_ADDRESS           0x0019A800
#define FLASHMEMORY_RESERVED_AREA_SIZE              (122*1024)

// OSG & LDC & FONT & ICON IMAGE Area
#define FLASHMEMORY_IMAGE_AREA_ADDRESS              0x00052000
#define FLASHMEMORY_IMAGE_AREA_SIZE                 (1312*1024)

// OSG & LDC & FONT & ICON IMAGE Header Area
#define FLASHMEMORY_IMAGE_HEADER_AREA_ADDRESS       0x0004F000
#define FLASHMEMORY_IMAGE_HEADER_AREA_SIZE          (12*1024)

// DPC Data Area
#define FLASHMEMORY_DPC_AREA_ADDRESS                0x0004D000
#define FLASHMEMORY_DPC_AREA_SIZE                   (8*1024)

// Sensor Register Area
#define FLASHMEMORY_SENSOR_REG_AREA_ADDRESS         0x0004B000
#define FLASHMEMORY_SENSOR_REG_AREA_SIZE            (8*1024)

// ISP Register Area
#define FLASHMEMORY_ISP_REG_AREA_ADDRESS            0x00048000
#define FLASHMEMORY_ISP_REG_AREA_SIZE               (12*1024)

// Firmware Application Area
#define FLASHMEMORY_FIRMWARE_APP_AREA_ADDRESS       0x00008000
#define FLASHMEMORY_FIRMWARE_APP_AREA_SIZE          (256*1024)

// Bootloader-BL2 Area
#define FLASHMEMORY_BOOTLOADER_AREA_ADDRESS         0x00000000
#define FLASHMEMORY_BOOTLOADER_AREA_SIZE            (32*1024)

//==============================================================================

#elif (FLASH_MEMORY_MAP_VERSION == VERSION_160304)

// Bootloader-BL2 Area

#define FLASHMEMORY_BOOTLOADER_BACKUP_AREA_ADDRESS  		0x1F8000
#define FLASHMEMORY_FIRMWARE_BACKUP_AREA_ADDRESS    		0x1B8000
#define FLASHMEMORY_FIRMWARE_RESERVED_BACKUP_AREA_ADDRESS 	0x1B0000
#define FLASHMEMORY_ISP_REG_BACKUP_AREA_ADDRESS     		0x1AD000
#define FLASHMEMORY_SENSOR_REG_BACKUP_AREA_ADDRESS  		0x1AB000
#define FLASHMEMORY_OSG_WARNING_AREA_ADDRESS        		0x1A9000

#define FLASHMEMORY_LDC_END_AREA_ADDRESS   					0x1A8FFF
#define FLASHMEMORY_OSG_START_AREA_ADDRESS   				0x080000
#define FLASHMEMORY_OSG_LDC_HEADER_AREA_ADDRESS     		0x07D000

#define FLASHMEMORY_OSD_FONF_AREA_ADDRESS           		0x074000
#define FLASHMEMORY_DPGL_AREA_ADDRESS			    		0x057000
#define FLASHMEMORY_DPC_AREA_ADDRESS                		0x055000

#define FLASHMEMORY_SENSOR_REG_AREA_ADDRESS         		0x053000
#define FLASHMEMORY_ISP_REG_AREA_ADDRESS            		0x050000
#define FLASHMEMORY_FIRMWARE_RESERVED_AREA_ADDRESS  		0x048000
#define FLASHMEMORY_FIRMWARE_APP_AREA_ADDRESS       		0x008000
#define FLASHMEMORY_BOOTLOADER_AREA_ADDRESS         		0x000000


#define FLASHMEMORY_BOOTLOADER_BACKUP_AREA_SIZE     		(32   *1024)
#define FLASHMEMORY_FIRMWARE_BACKUP_AREA_SIZE       		(256  *1024)
#define FLASHMEMORY_FIRMWARE_RESERVED_BACKUP_AREA_SIZE 		(32   *1024)
#define FLASHMEMORY_ISP_REG_BACKUP_AREA_SIZE        		(12   *1024)
#define FLASHMEMORY_SENSOR_REG_BACKUP_AREA_SIZE     		(8    *1024)
#define FLASHMEMORY_OSG_WARNING_AREA_SIZE           		(8    *1024)

#define FLASHMEMORY_OSG_LDC_AREA_SIZE   					(1188 *1024)
#define FLASHMEMORY_OSG_LDC_HEADER_AREA_SIZE     			(12   *1024)
#define FLASHMEMORY_OSD_FONF_AREA_SIZE           			(36   *1024)
#define FLASHMEMORY_DPGL_AREA_SIZE			   				(116  *1024)

#define FLASHMEMORY_DPC_AREA_SIZE                   		(8    *1024)
#define FLASHMEMORY_SENSOR_REG_AREA_SIZE            		(8    *1024)
#define FLASHMEMORY_ISP_REG_AREA_SIZE               		(12   *1024)

#define FLASHMEMORY_FIRMWARE_RESERVED_AREA_SIZE     		(32   *1024)
#define FLASHMEMORY_FIRMWARE_APP_AREA_SIZE          		(256  *1024)
#define FLASHMEMORY_BOOTLOADER_AREA_SIZE            		(32   *1024)


#define FLASHMEMORY_IMAGE_AREA_ADDRESS              0x00052000
#define FLASHMEMORY_IMAGE_AREA_SIZE                 (1312*1024)

//==============================================================================
#elif (FLASH_MEMORY_MAP_VERSION == VERSION_160409_TEST)

// Bootloader-BL2 Area

#define FLASHMEMORY_BOOTLOADER_BACKUP_AREA_ADDRESS  		0x1F8000
#define FLASHMEMORY_FIRMWARE_BACKUP_AREA_ADDRESS    		0x1A5000
//#define FLASHMEMORY_FIRMWARE_RESERVED_BACKUP_AREA_ADDRESS 0x1A5000
#define FLASHMEMORY_ISP_REG_BACKUP_AREA_ADDRESS     		0x1A2000
#define FLASHMEMORY_SENSOR_REG_BACKUP_AREA_ADDRESS  		0x1A0000
#define FLASHMEMORY_OSG_WARNING_AREA_ADDRESS        		0x19E000

#define FLASHMEMORY_LDC_END_AREA_ADDRESS   					0x19DFFF
#define FLASHMEMORY_OSG_START_AREA_ADDRESS   				0x099000
#define FLASHMEMORY_OSG_LDC_HEADER_AREA_ADDRESS     		0x096000

#define FLASHMEMORY_OSD_FONF_AREA_ADDRESS           		0x08D000
#define FLASHMEMORY_DPGL_AREA_ADDRESS			    		0x070000
                                                                                                           
#define	FLASHMEMORY_WDPC_INFO_AHD_ADDRESS_R_FLIP			0x06FFFB 
#define	FLASHMEMORY_WDPC_POS_AHD_ADDRESS_R_FLIP				0x06E000 
#define	FLASHMEMORY_WDPC_INFO_ADDRESS_R_FLIP				0x06DFFB 
#define	FLASHMEMORY_WDPC_POS_ADDRESS_R_FLIP					0x06C000 

#define	FLASHMEMORY_WDPC_INFO_AHD_ADDRESS_V_FLIP			0x06BFFB 
#define	FLASHMEMORY_WDPC_POS_AHD_ADDRESS_V_FLIP				0x06A000 
#define	FLASHMEMORY_WDPC_INFO_ADDRESS_V_FLIP				0x069FFB 
#define	FLASHMEMORY_WDPC_POS_ADDRESS_V_FLIP					0x068000 

#define	FLASHMEMORY_WDPC_INFO_AHD_ADDRESS_H_FLIP			0x067FFB 
#define	FLASHMEMORY_WDPC_POS_AHD_ADDRESS_H_FLIP				0x066000 
#define	FLASHMEMORY_WDPC_INFO_ADDRESS_H_FLIP				0x065FFB 
#define	FLASHMEMORY_WDPC_POS_ADDRESS_H_FLIP					0x064000 

#define	FLASHMEMORY_WDPC_AHD_INFO_ADDRESS					0x063FFB 	// STATIC WHITE DPC NUMBER 	: 5BYTE
#define	FLASHMEMORY_WDPC_AHD_POS_ADDRESS					0x062000 	// 8K
#define	FLASHMEMORY_WDPC_INFO_ADDRESS						0x061FFB 	// STATIC WHITE DPC NUMBER 	: 5BYTE
#define	FLASHMEMORY_WDPC_POS_ADDRESS						0x060000 	// 8K
 
//#define FLASHMEMORY_DPC_AREA_ADDRESS                		0x060000

#define FLASHMEMORY_SENSOR_REG_AREA_ADDRESS         		0x05E000
#define FLASHMEMORY_ISP_REG_AREA_ADDRESS            		0x05B000
//#define FLASHMEMORY_FIRMWARE_RESERVED_AREA_ADDRESS  		0x05B000
#define FLASHMEMORY_FIRMWARE_APP_AREA_ADDRESS       		0x008000
#define FLASHMEMORY_BOOTLOADER_AREA_ADDRESS         		0x000000

//#define	FLASHMEMORY_BDPC_POS_ADDRESS					0x000094	//   STATIC WHITE DPC ADDRESS 	: 128 * 4
//#define	FLASHMEMORY_BDPC_INFO_ADDRESS					0x000090	//   STATIC BLACK DPC NUMBER 	: 4BYTE
//#define	FLASHMEMORY_MDPC_POS_ADDRESS					0x000010	//   MANUAL DPC ADDRESS 	: 32 * 4

#define FLASHMEMORY_BOOTLOADER_BACKUP_AREA_SIZE     		(32   *1024)
#define FLASHMEMORY_FIRMWARE_BACKUP_AREA_SIZE       		(332  *1024)
//#define FLASHMEMORY_FIRMWARE_RESERVED_BACKUP_AREA_SIZE 	(0    *1024)
#define FLASHMEMORY_ISP_REG_BACKUP_AREA_SIZE        		(12   *1024)
#define FLASHMEMORY_SENSOR_REG_BACKUP_AREA_SIZE     		(8    *1024)
#define FLASHMEMORY_OSG_WARNING_AREA_SIZE           		(8    *1024)

#define FLASHMEMORY_OSG_LDC_AREA_SIZE   					(1044 *1024)
#define FLASHMEMORY_OSG_LDC_HEADER_AREA_SIZE     			(12   *1024)
#define FLASHMEMORY_OSD_FONF_AREA_SIZE           			(36   *1024)
#define FLASHMEMORY_DPGL_AREA_SIZE			   				(116  *1024)

#define FLASHMEMORY_DPC_AREA_SIZE                   		(64   *1024)
#define FLASHMEMORY_SENSOR_REG_AREA_SIZE            		(8    *1024)
#define FLASHMEMORY_ISP_REG_AREA_SIZE               		(12   *1024)

//#define FLASHMEMORY_FIRMWARE_RESERVED_AREA_SIZE     		(0    *1024)
#define FLASHMEMORY_FIRMWARE_APP_AREA_SIZE          		(332  *1024)
#define FLASHMEMORY_BOOTLOADER_AREA_SIZE            		(32   *1024)


#define FLASHMEMORY_IMAGE_AREA_ADDRESS              0x00052000
#define FLASHMEMORY_IMAGE_AREA_SIZE                 (1312*1024)

//==============================================================================
#endif


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/


#endif  /* __FLASH_MEMORY_MAP_H__ */


/* End Of File */
