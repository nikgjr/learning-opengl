/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : JIG_Lib.h
*
*  @brief   : This file is JIG controller application support package hearder
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.09
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __JIG_LIB_H__
#define __JIG_LIB_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Uart_Lib.h"


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define	JIG_PORT                UART_CH1

#define JIGMSG(fmt, args...)    //ncLib_JIG_Printf(fmt, ## args)
#define JIGSCANF(msg)           //ncLib_JIG_Scanf(msg)


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* JIG GENERIC & SPECIFIC COMMANDS
*/

typedef enum
{
    /*
    * Generic Commands
    */

    GCMD_JIG_INIT = 0,
    GCMD_JIG_DEINIT,

    GCMD_JIG_SET_BAUDRATE,
    GCMD_JIG_DO_COMMAND,

    GCMD_JIG_MAX

} eJIG_CMD;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncLib_JIG_Open(UINT32 nInputClk);
extern INT32 ncLib_JIG_Close(void);

extern INT32 ncLib_JIG_Read(void);
extern INT32 ncLib_JIG_Write(void);

extern INT32 ncLib_JIG_Control(eJIG_CMD Cmd, ...);

// JIG Message Library
extern void   ncLib_JIG_Printf(const char *fmt, ...);
extern UINT32 ncLib_JIG_Scanf(char *buf);


#endif  /* __JIG_LIB_H__ */


/* End Of File */
