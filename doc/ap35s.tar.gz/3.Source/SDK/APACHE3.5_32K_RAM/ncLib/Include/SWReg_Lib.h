/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SoftRegister_Lib.c
*
*  @brief   : This file is SWR (SoftWare Register) API for standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.08
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __SOFTREGISTER_LIB_H__
#define __SOFTREGISTER_LIB_H__


/*
********************************************************************************
*                   INCLUDE
********************************************************************************
*/

#include <stdarg.h>


/*
********************************************************************************
*                   DEFINES
********************************************************************************
*/


/*
********************************************************************************
*                   ENUMERATION
********************************************************************************
*/

/*
* SWR GENERIC & SPECIFIC COMMANDS
*/

typedef enum _SWR_CMD
{
    /*
    * Generic Commands
    */

    GCMD_SWR_INIT = 0,
    GCMD_SWR_DEINIT,

    GCMD_SWR_GET_DATA,
    GCMD_SWR_SET_DATA,

    GCMD_SWR_MAX,

} eSWR_CMD;


typedef enum
{
	/* Application Commands */

    SWR_ID_SENSOR_SLAVEID = 0,
    SWR_ID_SENSOR_SELECT,
    SWR_ID_SENSOR_MODE,
    SWR_ID_SENSOR_PROTOCOL,
    SWR_ID_AVB_CHANNEL,
    SWR_ID_DISPLAY_MODE,
    SWR_ID_SDPC_LOAD,
    SWR_ID_SDPC_SAVE,
    SWR_ID_ENC_MODE,
    SWR_ID_ENC_QP,
    SWR_ID_ENC_BITRATE,
    SWR_ID_PGL_INDEX,
    SWR_ID_VIEWMODE_INDEX,

    MAX_OF_SWR_ID_NUM
} eSWR_ID_NUM;


/*
********************************************************************************
*                   TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*                   CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*                   VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*                   FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncLib_SWR_Open(void);
extern INT32 ncLib_SWR_Close(void);

extern UINT8 ncLib_SWR_Read(UINT32 nOffset);
extern void ncLib_SWR_Write(UINT32 nOffset, UINT8 nData);

extern UINT32 ncLib_SWR_Control(eSWR_CMD Cmd, ...);


#endif /* __SOFTREGISTER_LIB_H__ */


/* End Of File */
