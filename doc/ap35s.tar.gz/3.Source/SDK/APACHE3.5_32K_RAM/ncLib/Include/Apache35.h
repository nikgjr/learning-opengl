/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Apache35.h
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __APACHE35_H__
#define __APACHE35_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Type.h"


/*
********************************************************************************
*               MEMORY MAP FOR APACHE3.5 PLATFORM
********************************************************************************
*/

//----------------------------------------
// AXI Memory Map

#define APACHE_BOOT_ROM                 0x00000000
#define APACHE_BOOT_RAM                 0x04000000
#define APACHE_DRAM_BASE                0x08000000
#define APACHE_DRAM_SIZE                (8*1024*1024)
#define APACHE_ATCM_BASE                0x0C000000
#define APACHE_BTCM_BASE                0x0C100000

#define APACHE_PL390_0_BASE             0x20000000
#define APACHE_PL390_1_BASE             0x20100000
#define APACHE_OSG_BASE                 0x20200000


//----------------------------------------
// APB Memory Map

#define APACHE_R4CONFIG_BASE            (0x30000000)
#define APACHE_DMA_0_BASE               (0x30100000)
#define APACHE_DMA_1_BASE               (0x30200000)
#define APACHE_SYSCON_BASE              (0x30300000)
#define APACHE_ICU_BASE                 (0x30310000)
#define APACHE_SUBTIMER_BASE            (0x30320000)    // SUB TIMER
#define APACHE_WDT_BASE                 (0x30400000)
#define APACHE_TIMER_BASE               (0x30500000)    // MAIN TIMER
#define APACHE_TEMP_BASE                (0x30600000)
#define APACHE_DDRC_BASE                (0x30700000)
#define APACHE_I2C_0_BASE               (0x30800000)
#define APACHE_I2C_1_BASE               (0x30900000)
#define APACHE_UART_0_BASE              (0x30a00000)
#define APACHE_UART_1_BASE              (0x30b00000)
#define APACHE_GPIO_BASE                (0x30c00000)
#define APACHE_SPI_0_BASE               (0x30d00000)
#define APACHE_SPI_1_BASE               (0x30e00000)
#define APACHE_ISP_BASE                 (0x30f00000)

#define APACHE_CAN_BASE                 (0x31000000)
#define APACHE_QSPI_BASE                (0x31100000)
#define APACHE_DPGL                     (0x31200000)   
#define APACHE_VDUMP_BASE               (0x31110000)


//----------------------------------------------------

#define SIM_REG_BASE                    (APACHE_SYSCON_BASE+0x1000)

#define rDEBUG_STATUS                   (*(volatile unsigned *)(SIM_REG_BASE+0x30))
#define rDEBUG_STEP                     (*(volatile unsigned *)(SIM_REG_BASE+0x34))
#define rSYSCON_TICK_COUNTER            (*(volatile unsigned *)(SIM_REG_BASE+0x40))


#define __SIM_STATUS(_x_)               rDEBUG_STATUS = (_x_)
#define __SIM_STEP(_x_)                 rDEBUG_STEP = (_x_)

/*
********************************************************************************
*               MEMORY MAP RE-DEFINITION FOR APPLICATION
********************************************************************************
*/

/*
********************************************************************************
*               DATA & STRUCTURE
********************************************************************************
*/

//Key Def
#define KEY_LEFT                        0x01
#define KEY_RIGHT                       0x02
#define KEY_UP                          0x04
#define KEY_DOWN                        0x08
#define KEY_SET                         0x10
#define KEY_DEF                         0x1F
#define KEY_EMPTY                       0x1F

#define KEY_MENUOFF                     0x0F

#define PORT_BIT0                       0x1E
#define PORT_BIT1                       0x1D
#define PORT_BIT2                       0x1B
#define PORT_BIT3                       0x17
#define PORT_BIT4                       0x0F

#define PACKET_LENGTH_REG_READ          0x07
#define TxPACKET_LENGTH_DEFAULT         0x03


/*
********************************************************************************
*               MACROS
********************************************************************************
*/

typedef volatile unsigned int   _REG_;
typedef volatile unsigned int   _ADRS_;

#define M_WRITE_MEM(_addr_, _data_)     (*(_ADRS_ *)(_addr_) = _data_)
#define M_READ_MEM(_addr_)              (*(_ADRS_ *)(_addr_))

#define M_WRITE_REG(_addr_, _data_)     (*(_REG_ *)(_addr_) = _data_)
#define M_READ_REG(_addr_)              (*(_REG_ *)(_addr_))

#define M_32_SWAP(a) {                            \
          UINT32 _tmp;                            \
          _tmp = a;                               \
          ((UINT8 *)&a)[0] = ((UINT8 *)&_tmp)[3]; \
          ((UINT8 *)&a)[1] = ((UINT8 *)&_tmp)[2]; \
          ((UINT8 *)&a)[2] = ((UINT8 *)&_tmp)[1]; \
          ((UINT8 *)&a)[3] = ((UINT8 *)&_tmp)[0]; \
        }


#define APACHE_WRITE(addr, data)        *((volatile UINT32 *)(addr))=data
#define APACHE_READ(addr)               *((volatile UINT32 *)(addr))

#define APACHE_SET_BIT(addr, bit)       APACHE_WRITE(addr, APACHE_READ(addr) | (1<<(bit))     )
#define APACHE_CLEAR_BIT(addr, bit)     APACHE_WRITE(addr, APACHE_READ(addr) & (~(1<<(bit)))  )


#define BitSet(x,y)                     ((x) |= (0x01 << (y)))
#define BitClear(x,y)                   ((x) &= ~(0x01 << (y)))
#define BitInvert(x,y)                  ((x) ^= (0x01 <<(y)))
#define BitCheck(x,y)                   (((x) >> (y)) & 0x01)
#define BitSetVal(x,y,v)                ((v)? (BitSet(x,y)):(BitClear(x, y)))

#define BitsSet(x,y)                    ((x) |= (y))    
#define BitsClear(x,y)                  ((x) &= ~(y))
#define BitsInvert(x,y)                 ((x) = ~(y))

#define _abs(a, b)                      (((a) < (b)) ? ((b)-(a)) : ((a)-(b)))
#define _min(a, b)                      ((a) < (b) ? (a) : (b))
#define _max(a,b)                       ((a) > (b) ? (a) : (b))


/**
* @brief Register Read/Write Macro, 8bit, 16bit, 32bit access volatile type
* @arg   base_addr : base address value
* @arg      offset : address offset value
*/

#define GET_USB(x)                      ((UCHAR)(((x)>>24) & 0xFF))
#define GET_HSB(x)                      ((UCHAR)(((x)>>16) & 0xFF))
#define GET_MSB(x)                      ((UCHAR)(((x)>>8) & 0xFF))
#define GET_LSB(x)                      ((UCHAR)((x) & 0xFF))

#define MAKEWORD(high, low)             ((((USHORT)high & 0xff) << 8) | ((USHORT)low & 0xff) )
#define LOBYTE(w)           	        ((UCHAR)((ULONG)(w) & 0xff))
#define HIBYTE(w)           	        ((UCHAR)((ULONG)(w) >> 8))


#define REGRW8(base_addr, offset)       (*(volatile unsigned char *) (base_addr + offset))
#define REGRW16(base_addr, offset)      (*(volatile unsigned short *)(base_addr + offset))
#define REGRW32(base_addr, offset)      (*(volatile unsigned int *)  (base_addr + offset))




#define ISPREG(address)                 (*(volatile unsigned char *) (address))

#define ISPGET08(address)               (UCHAR)ISPREG(address)
#define ISPGET16(address)               (USHORT)((ISPREG(address+1U)<<8U) | (USHORT)ISPREG(address))
#define ISPGET32(address)               (ULONG)((ISPREG((address)+3U)<<24U) | (ISPREG((address)+2U)<<16U)\
                                        | (ISPREG((address)+1U)<<8U) | (ULONG)ISPREG(address))    

#define ISPSET08(address, value)        ISPREG(address) = (unsigned char)(value)
#define ISPSET16(address, value)        ISPREG(address+1U) = (unsigned char)((value) >> 8U); \
                                        ISPREG(address) = (unsigned char)((value) & 0xFFU)
                                        
#define ISPSET32(address, value)        ISPREG((address)+3U) = (unsigned char)((value) >> 24U);\
                                        ISPREG((address)+2U) = (unsigned char)((value) >> 16U);\
                                        ISPREG((address)+1U) = (unsigned char)((value) >> 8U);\
                                        ISPREG(address) = (unsigned char)((value) & 0xFFU)



#define M_SYS_NOUSING(_var_)            (_var_ = _var_)
#define M_SYS_MS2CNT(_clk_,_div_,_ms_)  ((_clk_ / CLK_MS_DIV / _div_) * _ms_)
#define M_SYS_US2CNT(_clk_,_div_,_us_)  ((_clk_ / CLK_10US_DIV / _div_) * (_us_/10))


#define IsInRage(a,b,c)                 (((a) >= (b)) ? ( ((a) <= (c)) ? 1:0 ) : 0)
#define IntegrityCheck(a,b,c)           (((a)-(b)) < (c))?0:1
#define	ConverShort(a,b)                ((a<<8)+b)		

/*
* Definition for Critical Section
*/

extern void __ENTER_CRITICAL_SECTION(void);
extern void __EXIT_CRITICAL_SECTION(void);

#define ENTER_CRITICAL_SECTION          __ENTER_CRITICAL_SECTION()
#define EXIT_CRITICAL_SECTION           __EXIT_CRITICAL_SECTION()


#endif	/* __APACHE35_H__ */

