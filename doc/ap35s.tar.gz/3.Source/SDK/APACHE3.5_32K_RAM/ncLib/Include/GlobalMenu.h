/********************************************************************************
*	Copyright (C) NEXTCHIP Co.,Ltd. All rights reserved.
********************************************************************************
*	Enviroment    : IAR Embedded Workbench IDE
*	Project       : APC28_EGT3 
********************************************************************************
*	History      : 
		CreationDate	Modify		Ver		Description
		-------------------------------------------------------
		2010.08.13		kysim		0.2		Initial  Revision
		2014.12.02		JWLee		1.0     Newly Generated		
		2015.04.01		jhchoi		1.1		NCFW Platform Revision
********************************************************************************/






#ifndef __Global_Menu__
#define __Global_Menu__

/**************************************************************************************************
Project : APACHE28
Time : 2013_12_03
**************************************************************************************************/

//<ExternPage>
#define		FUNC_CANCEL		0xFC
#define		FUNC_RESET		0xFD
#define		FUNC_SAVE		0xFE

#define		FUNC_DEFOG_DEFAULT				0x80
#define		FUNC_BLC_DEFAULT				0x81
#define		FUNC_HSBLC_DEFAULT				0x82
#define		FUNC_MOTION_DEFAULT				0x83
#define		FUNC_PRIVACY_DEFAULT			0x84
#define		FUNC_LANGUAGE_CHANGE			0x85

#define		FUNC_WHITE_DPC_SCAN				0x86
#define		FUNC_BLACK_DPC_SCAN				0x87
#define		FUNC_MONITOR_OUT_CHANGE			0x88

#define		FUNC_CAMTITLE					0x8B
#define		FUNC_CAMID						0x8C
#define		FUNC_AWCSET						0x8D
#define		FUNC_FIRMWARE_VER				0x8E

#define		FUNC_DEFOG_AREA					0xC9
#define		FUNC_BLC_AREA					0xCA
#define		FUNC_HSBLC_AREA					0xCB
#define		FUNC_IRSMART_AREA				0xCC
#define		FUNC_MOTION_AREA				0xCD
#define		FUNC_PRIVACY_AREA				0xCE
#define		FUNC_DPC_WHITE_AREA				0xCF
#define		FUNC_DPC_BLACK_AREA				0xD0

#define		NONE				            0xFF
//<END>


//<CurrentPageNumber>
#define		DEFOG_PAGE					0x18
#define		BLC_PAGE					0x05
#define		HSBLC_PAGE					0x06
#define		MOTION_PAGE					0x11
#define		PRIVACY_PAGE				0x12
#define		IRSMART_PAGE				0x0F
#define		MD_ALRAM_PAGE				0x15	
#define		HIDDEN						0x07
#define		WDPC_PAGE					0x1B
#define		BDPC_PAGE					0x1C
#define		NONE				        0xFF
//<END>

//<SubFunctionTable>
#define		SHUTTER_MAX_FIX					0x01
#define		HSBLC_AREA_SELECT				0x02					
#define		MOTION_DISPLAY_ONOFF			0x03
#define		MOTION_SENSITIVITY				0x04

#define		PRIVACY_AREA_DISPLAY			0x05
#define		PRIVACY_AREA_COLOR				0x06
#define		PRIVACY_AREA_TRANSPARNET		0x07
#define		MOTION_COLOR					0x08
#define		MOTION_TRANSPARNET				0x09
/* [2015/01/15] ktsyann : [XM]-1 */
//{{
#define		CRT_BLACK_LEVEL					0x0A
//}}
#define		BRIGHTNESS_TYPE					0x0B
#define		LANGUAGE_SELECT					0x0C
#define		DC_OUTDOOR_SHUTTER_MAX			0x0D
#define		DC_OUTDOOR_SHUTTER_MIN			0x0E
/* [2015/01/15] ktsyann : [XM]-1 */
//{{
#define		LCD_BLACK_LEVEL					0x0F
//}}

#define		LENS_MODE_SELECT				0x80
#define		DN_AGC_LEVEL					0x81
#define		ND_AGC_LEVEL					0x82
#define		DN_CDS_LEVEL					0x83
#define		ND_CDS_LEVEL					0x84
#define		PIRIS_POS_LIMIT					0x85
#define		MONITOR_OUTPUT_SELECT			0x86
#define		EXPOSURE_AGC_LEVEL	 			0x87
#define 	DPC_VIEW						0x88


#define		NONE							0xFF
//<END>


//<DisplayOnOffTalbe Address>
#define		DAYNIGHT_AUTO_PAGE				0x844C
#define		AJUST_PAGE						0x844E
#define		NR_PAGE							0x8450
#define		TND_BW_PAGE						0x8452
#define		HIDDEN_LONG_DISTANCE_PAGE		0x8454
/* [2015/01/15] ktsyann : [XM]-1 */
//{{
#define		CRT_PAGE						0x8456
#define		LCD_PAGE						0x8458
//}}

#define		NONE_ADDRESS					0xFFFF
//<END>


//////////////////////////////////////////////////////////////////////////////////////////////////////
////MenuTable
//////////////////////////////////////////////////////////////////////////////////////////////////////
#define F_AREA_AGAIN_CHAR		    0x0000
#define F_AREA_POSITION_CHAR	    0x0001
#define F_AREA_RETURN_CHAR		    0x0002
#define F_AREA_SIZE_CHAR		    0x0003
#define F_BAR3_CHAR		            0x0004
#define F_CAMT_CHAR		            0x0005
#define F_CAMTITLE_CHAR		        0x0006
#define F_CAMTITLE_CLR_CHAR		    0x0007
#define F_CAMTITLE_END_CHAR		    0x0008
#define F_CAMTITLE_POS_CHAR		    0x0009
#define F_CLEAR_NCM_CHAR		    0x000A
#define F_DEFECT_CLOSETHE_CHAR	    0x000B
#define F_DEFECT_IRIS_CHAR		    0x000C
#define F_DEFECT_KEY_CHAR		    0x000D
#define F_DEFECT_PRESSENTER_CHAR	0x000E
#define F_DEFECT_THEN_CHAR		    0x000F
#define F_DOWN_CURSOR_CHAR		    0x0010
#define F_ENTER_CURSOR_CHAR		    0x0011
#define F_LEFT_CURSOR_CHAR		    0x0012
#define F_MOTION_NCM_CHAR		    0x0013
#define F_OFF_CHAR		            0x0014
#define F_PRESSKEY_CHAR		        0x0015
#define F_PRIVACY_BOTTOM_LEFT_CHAR	0x0016
#define F_PRIVACY_BOTTOM_RIGHT_CHAR	0x0017
#define F_PRIVACY_TOP_LEFT_CHAR		0x0018
#define F_PRIVACY_TOP_RIGHT_CHAR	0x0019
#define F_RESET_CHAR		        0x001A
#define F_RIGHT_CURSOR_CHAR		    0x001B
#define F_SHUTTER0_AUTO_CHAR		0x001C
#define F_SHUTTER1_25_CHAR		    0x001D
#define F_SHUTTER2_30_CHAR		    0x001E
#define F_SHUTTER3_50_CHAR		    0x001F
#define F_SHUTTER4_60_CHAR		    0x0020
#define F_SHUTTER5_FLK_CHAR		    0x0021
#define F_SHUTTER6_200_CHAR		    0x0022
#define F_SHUTTER7_240_CHAR		    0x0023
#define F_SHUTTER8_400_CHAR		    0x0024
#define F_SHUTTER9_480_CHAR		    0x0025
#define F_SHUTTER10_1000_CHAR		0x0026
#define F_SHUTTER11_2000_CHAR		0x0027
#define F_SHUTTER12_5000_CHAR		0x0028
#define F_SHUTTER13_10000_CHAR		0x0029
#define F_SHUTTER14_50000_CHAR		0x002A
#define F_SHUTTER15_X2_CHAR		    0x002B
#define F_SHUTTER16_X4_CHAR		    0x002C
#define F_SHUTTER17_X6_CHAR		    0x002D
#define F_SHUTTER18_X8_CHAR		    0x002E
#define F_SHUTTER19_X10_CHAR		0x002F
#define F_SHUTTER20_X15_CHAR		0x0030
#define F_SHUTTER21_X20_CHAR		0x0031
#define F_SHUTTER22_X25_CHAR		0x0032
#define F_SHUTTER23_X30_CHAR		0x0033
#define F_UP_CURSOR_CHAR		    0x0034
#define F_WAIT_CHAR		            0x0035

#endif
