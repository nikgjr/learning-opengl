/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : CAN_Lib.h
*
*  @brief   : This file is CAN2.0 controller API for NEXTCHIP standard library
*
*  @author  : alessio / TS Group / SoC SW Team
*
*  @date    : 2016.02.16
*
*  @version : Version 1.0.0
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __CAN_LIB_H__
#define __CAN_LIB_H__


/*
********************************************************************************
*                   INCLUDE
********************************************************************************
*/

#include <stdarg.h>


/*
********************************************************************************
*                   DEFINES
********************************************************************************
*/


/*
********************************************************************************
*                   ENUMERATION
********************************************************************************
*/

/*
* CAN GENERIC & SPECIFIC COMMANDS
*/

typedef enum _CAN_CMD
{
    /*
    * Generic Commands
    */

    GCMD_CAN_INIT_CH = 0,
    GCMD_CAN_DEINIT_CH,

    GCMD_CAN_SETUP,
    GCMD_CAN_SEND,
    GCMD_CAN_RECEIVE,
    GCMD_CAN_REMOTE_REQ,

    GCMD_CAN_CONNECT_ISR_HANDLER,
    GCMD_CAN_DISCONNECT_ISR_HANDLER,

    /* for test */
    GCMD_CAN_PERI_SELFTEST_SETUP,
    GCMD_CAN_PERI_SELFTEST_SEND,

    GCMD_CAN_MAX,

} eCAN_CMD;


typedef enum
{
    CAN_CH0,        // BasicCAN, PeriCAN
    CAN_CH1,        // Reserved, CAN-FD
    MAX_OF_CAN_CH
} eCAN_CH;

typedef enum
{
    CAN_MSGOBJ_RESERVED,
    CAN_MSGOBJ_ACTIVE,
    MAX_OF_CAN_MSGOBJ_STT
} eCAN_MSGOBJ_STT;

typedef enum
{
    CAN_CDR_BASIC_MODE,
    CAN_CDR_PERI_MODE,
    MAX_OF_CAN_CDR_MODE
} eCAN_CDR_MODE;

typedef enum
{
    CAN_FI_STANDARD_FORMAT,
    CAN_FI_EXTENDED_FORMAT,
    MAX_OF_CAN_FI_FRAME_FORMAT
} eCAN_FI_FRAME;

typedef enum
{
    CAN_FI_DATA_FRAME,
    CAN_FI_REMOTE_FRAME,
    MAX_OF_CAN_FI_RTR_FRAME
} eCAN_FI_RTR;

typedef enum
{
    CAN_BPS_10KBPS,     // 6.7km Class A max
    CAN_BPS_20KBPS,     // 3.3km Class B
    CAN_BPS_50KBPS,     // 1.3km Class B
    CAN_BPS_100KBPS,    // 620m  Class B
    CAN_BPS_125KBPS,    // 530m  Class B max
    CAN_BPS_250KBPS,    // 270m  Class C
    CAN_BPS_500KBPS,    // 130m  Class C
    CAN_BPS_800KBPS,    // 80m   Class C
    CAN_BPS_1000KBPS,   // 40m   Class C max
    MAX_OF_CAN_BPS
} eCAN_KBPS;


/*
********************************************************************************
*                   TYPEDEFS
********************************************************************************
*/

typedef struct
{
    eCAN_CH       channel;      // 0 : channel_0, 1 : channel_1
    eCAN_CDR_MODE mode;         // 0 : basicCAN, 1 : preiCAN
    eCAN_KBPS     baudrate;     // 1kbps ~ 1000kbps
    eCAN_FI_FRAME format;       // 0 - standard, 1 - extended frame format
} tCAN_INFO, *ptCAN_INFO;


typedef struct
{
    unsigned int id;            // 11bit or 29bit identifier
    unsigned int length;        // length of data field in bytes
    unsigned char data[8];      // data field

    eCAN_MSGOBJ_STT objch;      // message object active status
    eCAN_CDR_MODE mode;         // 0 - basicCAN, 1 - preiCAN
    eCAN_FI_FRAME format;       // 0 - standard, 1 - extended frame format
    eCAN_FI_RTR rtr;            // 0 - data frame, 1 - remote frame
} tCAN_MSG, *ptCAN_MSG;


typedef struct
{
    UINT32 acrId;               // Acceptance code register identifier
    UINT32 amrId;               // Acceptance mask register identifier

    eCAN_KBPS baudrate;         // Bus Timing
    tCAN_INFO info;             // Can information structure
} tCAN_PARAM, *ptCAN_PARAM;


/*
********************************************************************************
*                   CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*                   VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*                   FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32 ncLib_CAN_Open(UINT32 nInputClk);
extern INT32 ncLib_CAN_Close(void);

extern INT32 ncLib_CAN_Read(void);
extern INT32 ncLib_CAN_Write(void);

extern INT32 ncLib_CAN_Control(eCAN_CMD Cmd, ...);


#endif /* __CAN_LIB_H__ */


/* End Of File */
