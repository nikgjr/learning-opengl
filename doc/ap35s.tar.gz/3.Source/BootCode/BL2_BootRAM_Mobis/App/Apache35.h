/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Apache35.h
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __APACHE35_H__
#define __APACHE35_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Type.h"


/*
********************************************************************************
*               MEMORY MAP FOR APACHE3.5 PLATFORM
********************************************************************************
*/

//----------------------------------------
// AXI Memory Map

#define APACHE_AXI_BASE         0x00000000
#define APACHE_AHB_BASE         0x00000000
#define APACHE_APB_BASE         0xF0000000

#define APACHE_BOOT_ROM         0x00000000
#define APACHE_BOOT_RAM         0x04000000
#define APACHE_DRAM_BASE        0x08000000
#define APACHE_DRAM_SIZE        (16*1024*1024)
#define APACHE_ATCM_BASE        0x0C000000
#define APACHE_BTCM_BASE        0x0C100000

#define APACHE_PL390_0_BASE     0x20000000
#define APACHE_PL390_1_BASE     0x20100000

//----------------------------------------
// APB Memory Map

#define APACHE_R4CONFIG_BASE    (0x30000000)
#define APACHE_DMA_0_BASE       (0x30100000)
#define APACHE_DMA_1_BASE       (0x30200000)
#define APACHE_SYSCON_BASE      (0x30300000)
#define APACHE_ICU_BASE         (0x30310000)
#define APACHE_SUBTIMER_BASE    (0x30320000)
#define APACHE_WDT_BASE         (0x30400000)
#define APACHE_TIMER_BASE       (0x30500000)
#define APACHE_TEMP_BASE        (0x30600000)
#define APACHE_DDRC_BASE        (0x30700000)
#define APACHE_I2C_0_BASE       (0x30800000)
#define APACHE_I2C_1_BASE       (0x30900000)
#define APACHE_UART_0_BASE      (0x30a00000)
#define APACHE_UART_1_BASE      (0x30b00000)
#define APACHE_GPIO_BASE        (0x30c00000)
#define APACHE_SPI_0_BASE       (0x30d00000)
#define APACHE_SPI_1_BASE       (0x30e00000)
#define APACHE_ISP_BASE         (0x30f00000)

#define APACHE_CAN_BASE         (0x31000000)
#define APACHE_QSPI_BASE        (0x31100000)
#define APACHE_DPGL             (0x31120000)


/*
********************************************************************************
*               MEMORY MAP RE-DEFINITION FOR APPLICATION
********************************************************************************
*/

/*
    SYSTEM CONTROL UNIT
*/

#define SYS_CON_BASE            APACHE_SYSCON_BASE

#define SYSCON_RESET            0x0000
#define SYSCON_REMAP_START      0x0010
#define SYSCON_REMAP_END        0x0014
#define SYSCON_REMAP_OFFSET     0x0018
#define SYSCON_REMAP_ENABLE     0x001c

#define SCU_STRAP               0x0080

#define SYS_DEBUG_BASE          0x1010
#define SCU_DEBUG_STARTUP       (SYS_DEBUG_BASE + 0x0000)
#define SCU_DEBUG_BL_VER        (SYS_DEBUG_BASE + 0x0004)
#define SCU_DEBUG_STEP          (SYS_DEBUG_BASE + 0x0008)
#define SCU_DEBUG_RESULT        (SYS_DEBUG_BASE + 0x000C)
//#define SYSCON_TICK_COUNTER     (SYS_DEBUG_BASE + 0x0040)


/*
********************************************************************************
*               DATA & STRUCTURE
********************************************************************************
*/


/*
********************************************************************************
*               MACROS
********************************************************************************
*/

/**
* @brief Register Read/Write Macro, 8bit, 16bit, 32bit access volatile type
* @arg   base_addr : base address value
* @arg      offset : address offset value
*/

#define APACHE_WRITE(addr, data)            *((volatile UINT32 *)(addr))=data
#define APACHE_READ(addr)                   *((volatile UINT32 *)(addr))

#define REGRW8(base_addr, offset)           (*(volatile unsigned char *) (base_addr + offset))
#define REGRW16(base_addr, offset)          (*(volatile unsigned short *)(base_addr + offset))
#define REGRW32(base_addr, offset)          (*(volatile unsigned int *)  (base_addr + offset))

#define WRITE32(data, addr)                 *((volatile unsigned int *)(addr))=data
#define READ32(addr)                        *((volatile unsigned int *)(addr))


#define Align(a, b)                         (((a) + (b-1)) & ~(b-1))

/*
* Definition for Critical Section
*/

//extern void __ENTER_CRITICAL_SECTION(void); // Interrupt Enable
//extern void __EXIT_CRITICAL_SECTION(void);  // Interrupt Disable

//#define ENTER_CRITICAL_SECTION      __ENTER_CRITICAL_SECTION()
//#define EXIT_CRITICAL_SECTION       __EXIT_CRITICAL_SECTION()


#endif	/* __APACHE35_H__ */
