/*
********************************************************************************
*
*  Copyright (C) 2013 NEXTCHIP Inc. All rights reserved.
*
*  @file    : PeliCAN_Drv.h
*
*  @brief   : Apache3 CAN2.0 module driver header file
*
*  @author  : Alessio / Automotive SoC Software Team
*
*  @date    : 2013.11.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 2013.11.18 - CAN2.0 basic driver modified by Alessio
*
********************************************************************************
*/

#ifndef __PELICAN_DRV_H__
#define __PELICAN_DRV_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


// PeliCAN Register Map
                                    //    OM / RM, (Operation Mode / Reset Mode)
#define rCANP_MOD           0x0000  // 00 RW / RW, Mode Register 
#define rCANP_CMR           0x0004  // 01 WO / WO, Command Register
#define rCANP_SR            0x0008  // 02 RO / RO, Status Register
#define rCANP_IR            0x000C  // 03 RO / RO, Interrupt Register

#define rCANP_IER           0x0010  // 04 RW / RW, Interrupt Enable Register 
#define rCANP_RESERVED0     0x0014  // 05 -- / --, Reserved Register 
#define rCANP_BTR0          0x0018  // 06 RO / RW, Bus Timing 0 Register
#define rCANP_BTR1          0x001C  // 07 RO / RW, Bus Timing 1 Register


#define rCANP_RESERVED1     0x0020  // 08 -- / --, Reserved Register
#define rCANP_RESERVED2     0x0024  // 09 -- / --, Reserved Register 
#define rCANP_RESERVED3     0x0028  // 10 -- / --, Reserved Register 
#define rCANP_ALC           0x002C  // 11 RO / , Arbitration Lost Capture Register 

#define rCANP_ECC           0x0030  // 12 RO / RO, Error Code Capture Register 
#define rCANP_EWLR          0x0034  // 13 RO / RW, Error Warning Limit Register 
#define rCANP_RXERR         0x0038  // 14 RO / RW, RX Error Counter Register 
#define rCANP_TXERR         0x003C  // 15 RO / RW, TX Error Counter Register 

/*
 * Acceptance Filter
 */
#define rCANP_ACR0          0x0040  // 16 -- / RW, Acceptance code register 0
#define rCANP_ACR1          0x0044  // 17 -- / RW, Acceptance code register 1
#define rCANP_ACR2          0x0048  // 18 -- / RW, Acceptance code register 2
#define rCANP_ACR3          0x004C  // 19 -- / RW, Acceptance code register 3
#define rCANP_AMR0          0x0050  // 20 -- / RW, Acceptance mask register 0
#define rCANP_AMR1          0x0054  // 21 -- / RW, Acceptance mask register 1
#define rCANP_AMR2          0x0058  // 22 -- / RW, Acceptance mask register 2
#define rCANP_AMR3          0x005C  // 23 -- / RW, Acceptance mask register 3


/*
 * Standard Frame Format register
 */
#define rCANP_SFF_FI        0x0040  // 16 RW / --, Frame information SFF
#define rCANP_SFF_ID1       0x0044  // 17 RW / --, Identification SFF
#define rCANP_SFF_ID2       0x0048  // 18 RW / --, Identification SFF
#define rCANP_SFF_DATA1     0x004C  // 19 RW / --, RX Data Register 1 SFF

#define rCANP_SFF_DATA2     0x0050  // 20 RW / --, RX Data Register 2 SFF
#define rCANP_SFF_DATA3     0x0054  // 21 RW / --, RX Data Register 3 SFF
#define rCANP_SFF_DATA4     0x0058  // 22 RW / --, RX Data Register 4 SFF
#define rCANP_SFF_DATA5     0x005C  // 23 RW / --, RX Data Register 5 SFF

#define rCANP_SFF_DATA6     0x0060  // 24 RW / --, RX Data Register 6 SFF
#define rCANP_SFF_DATA7     0x0064  // 25 RW / --, RX Data Register 7 SFF
#define rCANP_SFF_DATA8     0x0068  // 26 RW / --, RX Data Register 8 SFF

/*
 * Extended Frame Format register
 */
#define rCANP_EFF_FI        0x0040  // 16 RW / --, Frame information EFF
#define rCANP_EFF_ID1       0x0044  // 17 RW / --, RX Frame Identifier Register 1 EFF
#define rCANP_EFF_ID2       0x0048  // 18 RW / --, RX Frame Identifier Register 2 EFF
#define rCANP_EFF_ID3       0x004C  // 19 RW / --, RX Frame Identifier Register 3 EFF

#define rCANP_EFF_ID4       0x0050  // 20 RW / --, RX Frame Identifier Register 4 EFF
#define rCANP_EFF_DATA1     0x0054  // 21 RW / --, RX Data Register 1 EFF
#define rCANP_EFF_DATA2     0x0058  // 22 RW / --, RX Data Register 2 EFF
#define rCANP_EFF_DATA3     0x005C  // 23 RW / --, RX Data Register 3 EFF

#define rCANP_EFF_DATA4     0x0060  // 24 RW / --, RX Data Register 3 EFF
#define rCANP_EFF_DATA5     0x0064  // 25 RW / --, RX Data Register 3 EFF
#define rCANP_EFF_DATA6     0x0068  // 26 RW / --, RX Data Register 3 EFF
#define rCANP_EFF_DATA7     0x006C  // 27 RW / --, RX Data Register 3 EFF
#define rCANP_EFF_DATA8     0x0070  // 28 RW / --, RX Data Register 3 EFF

#define rCANP_RMC           0x0074  // 29 RO / RO, RX Message Counter Register
#define rCANP_RESERVED4     0x0078  // 30 -- / --, Reserved Register
#define rCANP_CDR           0x007C  // 30 RW / RW, Clock Divider Register


//---- Register-0 : PeliCAN Mode Register.
#define CANP_MOD_AFM         (1<<3)  // Acceptance Filter Mode
#define CANP_MOD_STM         (1<<2)  // Self Test Mode
#define CANP_MOD_LOM         (1<<1)  // Listen Only Mode
#define CANP_MOD_RM          (1<<0)  // Reset Mode

//---- Register-1 : Command Register.
#define CANP_CMR_SRR         (1<<4)  // Self reception request
#define CANP_CMR_CDO         (1<<3)  // Clear Data Overrun
#define CANP_CMR_RRB         (1<<2)  // Release Receive Buffer
#define CANP_CMR_AT          (1<<1)  // Abort Transmission
#define CANP_CMR_TR          (1<<0)  // Transmission request

//---- Register-2 : Status Register.
#define CANP_SR_BS           (1<<7)  // Error, Bus Status
#define CANP_SR_ES           (1<<6)  // Error, Error Status
#define CANP_SR_TS           (1<<5)  // Transmit Status
#define CANP_SR_RS           (1<<4)  // Receive Status
#define CANP_SR_TCS          (1<<3)  // Transmit Complete Status
#define CANP_SR_TBS          (1<<2)  // Transmit Buffer Status
#define CANP_SR_DOS          (1<<1)  // Error, Data Overrun Status
#define CANP_SR_RBS          (1<<0)  // Receive Buffer Status

//---- Register-3 : Interrupt Register.
#define CANP_IR_BEI          (1<<7)  // (PeliCAN only) Bus Error Interrupt
#define CANP_IR_ALI          (1<<6)  // (PeliCAN only) Arbitration Lost Interrupt
#define CANP_IR_EPI          (1<<5)  // (PeliCAN only) Error Passive Interrupt
#define CANP_IR_DOI          (1<<3)  // Data Overrun Interrupt
#define CANP_IR_EI           (1<<2)  // Error Warning Interrupt
#define CANP_IR_TI           (1<<1)  // Transmit Interrupt
#define CANP_IR_RI           (1<<0)  // Receive Interrupt

//---- Register-4 : Interrupt Enable Register.
#define CANP_IER_FIE         (0xFF)  // Full Interrupt Enable
#define CANP_IER_BEIE        (1<<7)  // Bus Error Interrupt Enable
#define CANP_IER_ALIE        (1<<6)  // Arbitration Lost Interrupt Enable
#define CANP_IER_EPIE        (1<<5)  // Error Passive Interrupt Enable
#define CANP_IER_DOIE        (1<<3)  // Data Overrun Interrupt Enable
#define CANP_IER_EIE         (1<<2)  // Error Warning Interrupt Enable
#define CANP_IER_TIE         (1<<1)  // Transmit Interrupt Enable
#define CANP_IER_RIE         (1<<0)  // Receive Interrupt Enable

//---- Register-6 : Bus Timing 0 Register.
#define CANP_BTR0_SJW_SHIFT  (6) // Synchronization Jump 2bit
#define CANP_BTR0_BRP_SHIFT  (0) // Baud Rate Prescaler 6bit

/*
    SJW ...
    tSJW = tscl * (2 * SJW.1 + SJW.0 + 1)

    BRP ...
    tscl = 2 * tCLK * (32 * BRP.5 + 16 * BRP.4 + 8 * BRP.3 + 4 * BRP.2 + 2 * 
BRP.1 + BRP.0 + 1)
    where tCLK = time period of the XTAL frequency = 1/fXTAL
*/

//---- Register-7 : Bus Timing 1 Register.
#define CANP_BTR1_SAM_SHIFT      (7) // Sampling
#define CANP_BTR1_TSEG2_SHIFT    (4) // Time Segment2 3bit
#define CANP_BTR1_TSEG1_SHIFT    (0) // Time Segment1 4bit
// eCAN_BTR1_SAM Typedef Enum Reference

/*
tSYNCSEG = 1 * tscl
tTSEG1 = tscl * (8 * TSEG1.3 + 4 * TSEG1.2 + 2 * TSEG1.1 * TSEG1.0 + 1)
tTSEG2 = tscl * (4 * TSEG2.2 + 2 * TSEG2.1 + TSEG2.0 + 1)
*/

//---- Register-11 : Arbitration Lost Capture Register.
// SJA1000 datasheet pgae-35 table-18 reference

//---- Register-12 : Error Code Capture Register.
#define CANP_ECC_ERR_SHIFT       (6)     // Error Code
#define CANP_ECC_DIR             (1<<5)  // Transfer direction
#define CANP_ECC_SEG_MASK        (0x1F)  // Segmentation field mask
// SJA1000 datasheet pgae-37 table-21 reference
// eCAN_ECC_ERRC Typedef Enum Reference

//---- Register-16 : Frame Information Register.
#define CANP_FI_FF_SHIFT         (7) // Frame Format
#define CANP_FI_RTR_SHIFT        (6) // Remote Transmission Request
// eCAN_FI_RTR_FRAME Typedef Enum Reference
// eCAN_FI_FRAME_FORMAT Typedef Enum Reference

//---- Register-31 : Clock Driver Register.
#define CANP_CDR_MODE_SHIFT      (7) // CAN Mode
#define CANP_CDR_CLKOFF          (1<<3) // Clock off
// eCAN_CDR_MODE Typedef Enum Reference


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

/*
 * PeliCAN Mode (CAN2.0B)
 */

INT32 ncDrv_PeliCAN_Init(UINT32, tCAN_PARAM*);
void ncDrv_PeliCAN_DeInit(void);
INT32 ncDrv_PeliCAN_Send(tCAN_MSG*);
INT32 ncDrv_PeliCAN_SendComplete(void);
INT32 ncDrv_PeliCAN_Receive(tCAN_MSG*);
void ncDrv_PeliCAN_SFF_ReadFIFO(tCAN_MSG*);
void ncDrv_PeliCAN_EFF_ReadFIFO(tCAN_MSG*);
void ncDrv_PeliCAN_SetAcceptanceFilter(UINT32, UINT32);
void ncDrv_PeliCAN_ISRHandler(void);

#endif  /*__PELICAN_DRV_H__ */


/* End Of File */
