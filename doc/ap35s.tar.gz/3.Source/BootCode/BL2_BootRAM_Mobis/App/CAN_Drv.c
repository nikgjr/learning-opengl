/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : CAN_Drv.c
*
*  @brief   : Apache3 CAN2.0 module driver source file
*
*  @author  : alessio / TS Group / SoC SW Team
*
*  @date    : 2016.01.16
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*           INCLUDE
********************************************************************************
*/

#include "Main.h"

#if BL2_CAN_MODE_ENABLE

#include "CAN_Drv.h"
#include "CAN_Drv_PeliCAN.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

UINT32 gCANInClock;
UINT32 gCANMode = 0;

UINT8 gCanRxMsgBoxWrCnt = 0;
UINT8 gCanRxMsgBoxRdCnt = 0;

tCAN_MSG gp_CanRxMsgBox[CAN_MESSAGE_NUM_MAX];


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncDrv_CAN_Init(tCAN_PARAM *config)
{
    UINT32 sys_reg = 0;

    gCANInClock = 16000000;

    gCANMode = config->mode;

    sys_reg = REGRW32(APACHE_SYSCON_BASE, 0x0004);
    sys_reg |= (1 << 19);
    REGRW32(APACHE_SYSCON_BASE, 0x0004)= sys_reg;

    if(config->mode == CAN_CDR_BASIC_MODE)
    {
        //ncDrv_BasicCAN_Init(gCANInClock, config);
    }
    else
    {
        ncDrv_PeliCAN_Init(gCANInClock, config);
    }
}


void ncDrv_CAN_DeInit(void)
{
    UINT32 mode = ncDrv_CAN_GetCanMode();

    if(mode == CAN_CDR_BASIC_MODE)
    {
        //ncDrv_BasicCAN_DeInit();
    }
    else
    {
        ncDrv_PeliCAN_DeInit();
    }
}


INT32 ncDrv_CAN_Send(tCAN_MSG *txmsg)
{
    INT32 ret = NC_SUCCESS;
    UINT32 mode = ncDrv_CAN_GetCanMode();

    if(mode == CAN_CDR_BASIC_MODE)
    {
        //ncDrv_BasicCAN_Send(txmsg);
    }
    else
    {
        ncDrv_PeliCAN_Send(txmsg);
    }

    return ret;
}


INT32 ncDrv_CAN_Receive(tCAN_MSG *rxmsg)
{
    INT32 ret = NC_SUCCESS;
    UINT32 mode = ncDrv_CAN_GetCanMode();

    if(mode == CAN_CDR_BASIC_MODE)
    {
        //ret = ncDrv_BasicCAN_Receive(rxmsg);
    }
    else
    {
        ret = ncDrv_PeliCAN_Receive(rxmsg);
    }

    return ret;
}


UINT32 ncDrv_CAN_BaseAddr(void)
{
    UINT32 base_addr = rCAN_0_BASE;
    return base_addr;
}

UINT32 ncDrv_CAN_GetCanMode(void)
{
    return gCANMode;
}


/*
 * Refer to below web-site
 * https://www.kvaser.com/support/calculators/bit-timing-calculator/
 */
void ncDrv_CAN_CalculateBitTiming(UINT32 inputclk, eCAN_KBPS baudrate, UINT32* timing0, UINT32* timing1)
{
    if(baudrate == 10000)
    {
    	*timing0 = 0x1F;
    	*timing1 = 0x7F;
    }
    else if(baudrate == 20000)
    {
    	*timing0 = 0x0F;
    	*timing1 = 0x7F;
    }
    else if(baudrate == 50000)
    {
    	*timing0 = 0x07;
    	*timing1 = 0x7A;
    }
    else if(baudrate == 100000)
    {
    	*timing0 = 0x03;
    	*timing1 = 0x7A;
    }
    else if(baudrate == 125000)
    {
    	*timing0 = 0x03;
    	*timing1 = 0x76;
    }
    else if(baudrate == 250000)
    {
    	*timing0 = 0x01;
    	*timing1 = 0x76;
    }
    else if(baudrate == 500000)
    {
    	*timing0 = 0x00;
    	*timing1 = 0x76;
    }
    else if(baudrate == 800000)
    {
    	*timing0 = 0x03;
    	*timing1 = 0x43;
    }
    else if(baudrate == 1000000)
    {
    	*timing0 = 0x00;
    	*timing1 = 0x32;
    }
    else
    {   /*125000*/
    	*timing0 = 0x3;
    	*timing1 = 0x76;
    }
}


void ncDrv_CAN_SetAcceptanceFilter(UINT32 mode, UINT32 code, UINT32 mask)
{
    if(mode == CAN_CDR_BASIC_MODE)
    {
        //ncDrv_BasicCAN_SetAcceptanceFilter(code, mask);
    }
    else
    {
        ncDrv_PeliCAN_SetAcceptanceFilter(code, mask);
    }
}


INT32 ncDrv_CAN_SetRxMsgBoxIndex(void)
{
    if(gCanRxMsgBoxWrCnt >= CAN_MESSAGE_NUM_MAX)
    {
        gCanRxMsgBoxWrCnt = 0;
    }

    if(gp_CanRxMsgBox[gCanRxMsgBoxWrCnt].objch == CAN_MSGOBJ_ACTIVE)
    {
        //DEBUGMSG("Can Rx Buff Full\n");
    }

    gp_CanRxMsgBox[gCanRxMsgBoxWrCnt].objch = CAN_MSGOBJ_ACTIVE;

    return gCanRxMsgBoxWrCnt++;
}


INT32 ncDrv_CAN_GetRxMsgBoxIndex(void)
{
    return gCanRxMsgBoxRdCnt;
}


void ncDrv_CAN_ClearRxMsgBoxIndex(UINT32 index)
{
	gp_CanRxMsgBox[gCanRxMsgBoxRdCnt].objch = CAN_MSGOBJ_RESERVED;

    gCanRxMsgBoxRdCnt++;
    if(gCanRxMsgBoxRdCnt >= CAN_MESSAGE_NUM_MAX)
    {
        gCanRxMsgBoxRdCnt = 0;
    }
}


void ncDrv_CAN_ISR_Handler(void)
{
    UINT8 mode;

    mode = ncDrv_CAN_GetCanMode();

    if(mode == CAN_CDR_BASIC_MODE)
    {
        //ncDrv_BasicCAN_ISRHandler();
    }
    else
    {
        ncDrv_PeliCAN_ISRHandler();
    }
}


#endif


/* End Of File */
