/*
********************************************************************************
*
*  Copyright (C) 2013 NEXTCHIP Inc. All rights reserved.
*
*  @file    : CAN_Drv.h
*
*  @brief   : Apache3 CAN2.0 module driver header file
*
*  @author  : Alessio / Automotive SoC Software Team
*
*  @date    : 2013.11.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 2013.11.18 - CAN2.0 basic driver modified by Alessio
*
********************************************************************************
*/

#ifndef __CAN_DRV_H__
#define __CAN_DRV_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
* Compile Option
*/

#define CAN_MESSAGE_NUM_MAX             4
#define CAN_BUS_TIMING_CALC_MESSAGE     0
#define CAN_ISR_DBG_MESSAGE             0

/*
* CAN Register Base Address
*/

#define rCAN_0_BASE         APACHE_CAN_BASE


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum
{
    CAN_MSGOBJ_RESERVED,
    CAN_MSGOBJ_ACTIVE,
    MAX_OF_CAN_MSGOBJ_STT
} eCAN_MSGOBJ_STT;

typedef enum
{
    CAN_CDR_BASIC_MODE,
    CAN_CDR_PELI_MODE,
    CAN_CDR_PELI_SELF_TEST_MODE,
    MAX_OF_CAN_CDR_MODE
} eCAN_CDR_MODE;

typedef enum
{
    CAN_FI_STANDARD_FORMAT,
    CAN_FI_EXTENDED_FORMAT,
    MAX_OF_CAN_FI_FRAME_FORMAT
} eCAN_FI_FRAME;

typedef enum
{
    CAN_FI_DATA_FRAME,
    CAN_FI_REMOTE_FRAME,
    MAX_OF_CAN_FI_RTR_FRAME
} eCAN_FI_RTR;

typedef enum
{
    CAN_BPS_10KBPS   = 10000,     // 6.7km Class A max
    CAN_BPS_20KBPS   = 20000,     // 3.3km Class B
    CAN_BPS_50KBPS   = 50000,     // 1.3km Class B
    CAN_BPS_100KBPS  = 100000,    // 620m  Class B
    CAN_BPS_125KBPS  = 125000,    // 530m  Class B max
    CAN_BPS_250KBPS  = 250000,    // 270m  Class C
    CAN_BPS_500KBPS  = 500000,    // 130m  Class C
    CAN_BPS_800KBPS  = 800000,    // 80m   Class C
    CAN_BPS_1000KBPS = 1000000,   // 40m   Class C max
} eCAN_KBPS;

typedef enum
{
    CAN_SINGLE_FILTER,
    CAN_DUAL_FILTER
} eCAN_FILTER_MODE;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    unsigned int id;            // 11bit or 29bit identifier
    unsigned int length;        // length of data field in bytes
    unsigned char data[8];      // data field

    eCAN_MSGOBJ_STT objch;      // message object active status
    eCAN_CDR_MODE mode;         // 0 - basicCAN, 1 - preiCAN
    eCAN_FI_FRAME format;       // 0 - standard, 1 - extended frame format
    eCAN_FI_RTR rtr;            // 0 - data frame, 1 - remote frame
} tCAN_MSG, *ptCAN_MSG;


typedef struct
{
    UINT32 acrId;               // Acceptance code register identifier
    UINT32 amrId;               // Acceptance mask register identifier
    eCAN_CDR_MODE mode;         // 0 : basicCAN, 1 : preiCAN
    eCAN_KBPS baudrate;         // Bus Timing
    eCAN_FILTER_MODE filter;	// 0 : single filter 1 : dual filter
} tCAN_PARAM, *ptCAN_PARAM;

extern tCAN_MSG gp_CanRxMsgBox[CAN_MESSAGE_NUM_MAX];


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

/*
 * User API
 */
void ncDrv_CAN_Init(tCAN_PARAM *);
void ncDrv_CAN_DeInit(void);
INT32 ncDrv_CAN_Send(tCAN_MSG *);
INT32 ncDrv_CAN_Receive(tCAN_MSG *);

/*
 * Internal Functions
 */
UINT32 ncDrv_CAN_BaseAddr(void);
UINT32 ncDrv_CAN_GetCanMode(void);
void ncDrv_CAN_CalculateBitTiming(UINT32, eCAN_KBPS, UINT32*, UINT32*);
void ncDrv_CAN_SetAcceptanceFilter(UINT32, UINT32, UINT32);
INT32 ncDrv_CAN_SetRxMsgBoxIndex(void);
INT32 ncDrv_CAN_GetRxMsgBoxIndex(void);
void ncDrv_CAN_ClearRxMsgBoxIndex(UINT32);
void ncDrv_CAN_IRQ_Handler(UINT32);
void ncDrv_CAN_ISR_Handler(void);
INT32 ncDrv_CAN_ConnectUserHandler(PrVoid);
INT32 ncDrv_CAN_DisConnectUserHandler(void);


#endif  /* __CAN_DRV_H__ */


/* End Of File */
