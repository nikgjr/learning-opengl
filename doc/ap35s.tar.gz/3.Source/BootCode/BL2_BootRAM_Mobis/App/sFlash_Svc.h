/*
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : sFlash_Svc.h
*
*  @brief   : This file is sFlash controller API for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.01.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __SFLASH_SVC_H__
#define __SFLASH_SVC_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define SF_PAGE_SIZE							(256)


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tSFLASH_ID {
	UINT8  mbManufacture;           // Manufacture ID
	UINT8  mbMemoryType;            // Memory Type
	UINT8  mbMemoryCapacity;        // Memory Capacity
} tSFLASH_ID, *ptSFLASH_ID;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32  ncSvc_SF_Init(void);

extern void   ncSvc_SF_WaitWIP(void);
extern void   ncSvc_SF_WriteEnable(void);
extern void   ncSvc_SF_WriteDisable(void);
extern UINT8  ncSvc_SF_ReadStatus(void);
extern UINT8  ncSvc_SF_ReadStatus2(void);
extern void   ncSvc_SF_WriteStatus(UINT8 Status);
extern void   ncSvc_SF_WriteStatus2(UINT8 Status1, UINT8 Status2);

extern INT32  ncSvc_SF_ReadDeviceIdentification(ptSFLASH_ID ptsFlashID);

extern INT32  ncSvc_SF_SectorErase(UINT32 Addr);
extern INT32  ncSvc_SF_ReadData(UINT32 Addr, UINT8 *pData, UINT32 Size);
extern INT32  ncSvc_SF_WriteData(UINT32 Addr, UINT8 *pData, UINT32 Size);


#endif /* __SFLASH_SVC_H__ */
