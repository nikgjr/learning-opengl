/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Type.h
*
*  @brief   :
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __TYPE_H__
#define __TYPE_H__


/*
********************************************************************************
*               DATA TYPE
********************************************************************************
*/

typedef unsigned long long      UINT64;
typedef unsigned int            UINT32;
typedef unsigned short          UINT16;
typedef unsigned short          USHORT;
typedef unsigned char           UINT8;
typedef unsigned char           UCHAR;

typedef signed long long        INT64;
typedef signed int              INT32;
typedef signed short            INT16;
typedef signed short            SHORT;
typedef signed char             INT8;
typedef signed char             CHAR;

typedef float                   FLOAT;
typedef float                   FP32;
typedef unsigned char           BOOL;


/*
********************************************************************************
*               LOGICAL SYMBOL TYPE
********************************************************************************
*/

#ifndef TRUE
#define TRUE                    1
#endif

#ifndef FALSE
#define FALSE                   0
#endif

// Logical Symbols
#ifndef	OK
#define OK                      1
#endif

#ifndef	ERROR
#define ERROR                   0
#endif

#ifndef ON
#define ON                      1
#endif

#ifndef OFF
#define	OFF                     0
#endif

#ifndef ENABLE
#define ENABLE                  1
#endif

#ifndef DISABLE
#define	DISABLE                 0
#endif

#ifndef HIGH
#define HIGH                    1
#endif

#ifndef LOW
#define	LOW                     0
#endif

#ifndef NULL
#define NULL                    0
#endif

// function return value

#define NC_FAILURE              (-1)
#define NC_SUCCESS              0

#define KB                      (1024)
#define MB                      (1048576)

#define KHZ                     (1000)
#define MHZ                     (1000000)


// A function with no argument returning pointer to a void function
typedef void (*PrVoid) 	   (void);


#endif  /* __TYPE_H__ */


/* End Of File */

