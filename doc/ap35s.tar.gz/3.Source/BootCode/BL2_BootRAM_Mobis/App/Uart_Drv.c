/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Uart_Drv.c
*
*  @brief   : This file is UART Controller Driver for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : ARM PrimeCell�� UART (PL011) / Revision: r1p4
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>

#include "Main.h"

#if BL2_DEBUG_PRINT_ENABLE


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define UART_BUFFER_SIZE        16


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

tREG_UART *prPUart = (tREG_UART *)UART0;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncDrv_UART_Initialize(tREG_UART *rUART, tUART_PARAM *param)
{
    /*
    ** First, disable everything.
    */

    rUART->UARTCR = 0;


    /*
    ** Set baud rate
    */

    ncDrv_UART_SetBaudrate(rUART, param);


    /*
    ** ----------------------------------------------
    ** NOTE: MUST BE WRITTEN LAST (AFTER IBRD & FBRD)
    ** ----------------------------------------------
    **
    ** Set the UART to be 8 bits, 1 stop bit, no parity, fifo enabled.
    */

    rUART->UARTLCR_H = (param->sps | param->wlen | param->fen | param->stp2 | param->eps | param->pen | param->brk);


    /*
    ** Set the UART FIFO level to .....
    */

    rUART->UARTIFLS = FLS_RX_1DIV8 | FLS_TX_1DIV2;
    rUART->UARTICR |= 0xFFFF;
    rUART->UARTIMSC = (IMSC_OEIM | IMSC_BEIM | IMSC_PEIM | IMSC_FEIM | IMSC_RTIM
                     | IMSC_RXIM | IMSC_DSRMIM | IMSC_DCDMIM | IMSC_CTSMIM | IMSC_RIMIM);


    /*
    ** Finally, enable the UART
    */

    rUART->UARTCR = (CR_RX_EN | CR_TX_EN | CR_UART_EN);
}


void ncDrv_UART_SetBaudrate(tREG_UART *rUART, tUART_PARAM *param)
{
    UINT32 temp, ref_clk, divider, remainder, fraction;

    /*
    ** Set baud rate
    **
    ** IBRD = UART_CLK / (16 * BPS)
    ** FBRD = ROUND((64 * MOD(UART_CLK,(16 * BPS))) / (16 * BPS))
    */

    temp = 16 * (param->baudRate);
    ref_clk = param->uartClk;
    divider = ref_clk / temp;

    remainder = ref_clk % temp;
    temp = (8 * remainder) / param->baudRate;
    fraction = (temp >> 1) + (temp & 1);

    rUART->UARTIBRD = divider;
    rUART->UARTFBRD = fraction;
}


void ncDrv_UART_putchar(tREG_UART *rUART, UINT8 ch)
{
    while(rUART->UARTFR & FR_TXFF);

    rUART->UARTDR = ch;
}


void ncDrv_UART_printhex(tREG_UART *rUART, UINT8 hex)
{
    UINT8 tmp;

    /* 1st Digit */
    tmp = hex >> 4;

    if(tmp < 0x0A)
    {
        tmp += 0x30;
    }
    else
    {
        tmp += 0x37;
    }

    ncDrv_UART_putchar(rUART, tmp);

    /* 2nd Digit */
    tmp = hex & 0x0F;

    if(tmp < 0x0A)
    {
        tmp += 0x30;
    }
    else
    {
        tmp += 0x37;
    }

    ncDrv_UART_putchar(rUART, tmp);
}


void ncDrv_UART_printdec(tREG_UART *rUART, UINT32 num, UINT8 type)
{
    UINT8 quot;
    UINT32 tmp;

    if(!num)
    {
        ncDrv_UART_putchar(rUART, '0');
        return;
    }

    if(type == DEC_8)
    {
        tmp = 100;
    }
    else if(type == DEC_16)
    {
        tmp = 10000;
    }
    else if(type == DEC_32)
    {
        tmp = 1000000000;
    }
    else
    {
        tmp = 1000000000;
    }

    while(!(num/tmp))
        tmp /= 10;

    while(1)
    {
        quot = num/tmp;

        ncDrv_UART_putchar(rUART, (quot+0x30));

        num -= quot * tmp;
        tmp /= 10;

        if(!tmp)
        {
            break;
        }
    }
}


/*

The compiler generates errors like "Identifier va_list is undefined" when building GNU-style code.

This is because of slightly differing methods of implementing variadic functions between RVCT and GCC.
The solution is to use the compiler option --preinclude stdarg.h to include the definitions of these types before the start of the application code.

 **/

void ncDrv_UART_printf(const char *fmt, ...)
{
    va_list args;
    UINT8 pos = 0;
    UINT8 i;
    UINT16 u_short;
    UINT32 u_long;
    UINT8 *str;
    BOOL f_uint16 = FALSE, f_u32 = FALSE;

    va_start (args, fmt);

    while(fmt[pos])
    {
        if(fmt[pos] == '%')
        {
            if(f_uint16 || f_u32)
            {
                pos +=2;
            }
            else
            {
                pos++;
            }

            switch(fmt[pos])
            {
				case 'x':
				case 'X':
                    if(f_uint16)
                    {
                        u_short = va_arg(args, UINT32);

                        for(i = 2; i > 0; i--)
                        {
                            ncDrv_UART_printhex(prPUart, (UINT8)(u_short>>(8*(i-1))));
                        }

                        f_uint16 = FALSE;
                    }
                    else if(f_u32)
                    {
                        u_long = va_arg (args, UINT32);

                        for(i=4; i>0; i--)
                        {
                            ncDrv_UART_printhex(prPUart, (UINT8)(u_long>>(8*(i-1))));
                        }

                        f_u32 = FALSE;
                    }
                    else
                    {
                        ncDrv_UART_printhex(prPUart, (va_arg(args, UINT32)));
                    }
                break;

                case 'd':
                case 'D':
                    if(f_uint16)
                    {
                        u_short = va_arg(args, UINT32);

                        ncDrv_UART_printdec(prPUart, (UINT32)u_short, DEC_16);

                        f_uint16 = FALSE;
                    }
                    else if(f_u32)
                    {
                        u_long = va_arg(args, UINT32);

                        ncDrv_UART_printdec(prPUart, (UINT32)u_long, DEC_32);

                        f_u32 = FALSE;
                    }
                    else
                        ncDrv_UART_printdec(prPUart, (UINT32)(va_arg(args, UINT32)), DEC_8);
                break;

                case '4':
                    f_uint16 = TRUE;
                    pos -=2;
                break;

                case '8':
                    f_u32 = TRUE;
                    pos -=2;
                break;

                case 's':
                case 'S':
                    u_long = va_arg(args, UINT32);

                    str = (UINT8 *)u_long;

                    while(1)
                    {
                        ncDrv_UART_putchar(prPUart, (UINT8)(*str++));

                        if(*str == 0)
                        {
                            break;
                        }
                    }
                break;

                case 'c':
                case 'C':
                    u_long = va_arg(args, UINT32);

                    ncDrv_UART_putchar(prPUart, (UINT8)u_long);
                break;

                default:
                break;
            }
        }
        else if(fmt[pos] == '\n')
        {
            ncDrv_UART_putchar(prPUart, '\n');
            ncDrv_UART_putchar(prPUart, '\r');
        }
        else
        {
            ncDrv_UART_putchar(prPUart, fmt[pos]);
        }

        pos++;
    }

    va_end (args);
}


#endif // BOOT_DEBUG_STEP_PRINT_ENABLE


/* End Of File */
