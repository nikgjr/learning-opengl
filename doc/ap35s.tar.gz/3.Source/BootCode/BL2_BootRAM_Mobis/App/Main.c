/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.c
*
*  @brief   : This file is implemented about main of BL2_BootRAM
*
*  @author  : alessio / TS Group. SoCSW Team
*
*  @date    : 2016.02.02
*
*  @version : Version 0.0.1
*
********************************************************************************
*  History  :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "Main.h"



/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define FLASH_PAGE_SIZE             256

/* Flash Memory Map Address */

#define BACKUP_APP_DATA_AREA        0x001A5100  // fixed address
#define BACKUP_APP_HEADER_AREA      0x001A5000  // fixed address

#define NORMAL_APP_DATA_AREA        0x00008100  // fixed address
#define NORMAL_APP_HEADER_AREA      0x00008000  // fixed address


/* Flash Memory APP Header Define */

#define APP_SIGNATURE_ID            0x35335041  // "53PA"
#define APP_IMAGE_LENGTH_MAX        (256*1024)
#define APP_IMAGE_BASE_ADDRESS      APACHE_DRAM_BASE

#define LPDDR_BASE_ADDRESS          APP_IMAGE_BASE_ADDRESS


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

stAPP_HEADER stAPPHD;

UINT32 gFlashCS = 0;



/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
void ncBL2_PLL_Init(void)
{
    UINT32 nBootStrap;

    // Read Boot-Strap : sFlash CS Pin Select
    nBootStrap = REGRW32(SYS_CON_BASE, SCU_STRAP) & 0xF;
    gFlashCS = (nBootStrap >> 2) & 0x1;


    // Set Clock 
    __BL2_PLL_SetConfig();
}

void ncBL2_UART_Init(void)
{
#if BL2_DEBUG_PRINT_ENABLE
    tUART_PARAM param;

    param.uartClk = 54000000;
    param.baudRate = 115200;
    param.sps = LCR_SPS_DIS;
    param.wlen = LCR_WLEN_8BIT;
    param.fen = LCR_FIFO_EN;
    param.stp2 = LCR_STP2_DIS;
    param.eps = LCR_EPS_DIS;
    param.pen = LCR_PARITY_DIS;
    param.brk = 0;

    // PinMux UART Select ...
    __BL2_UART_PinMux();

    ncDrv_UART_Initialize((tREG_UART *)UART0, &param);

    DEBUGMSG( "\n\n");
    DEBUGMSG( "=======================================================\n");
    DEBUGMSG( " BL2 Version: [V%d.%d.%d]\n", BL2_VER_MAJOR, BL2_VER_MINOR1, BL2_VER_MINOR2);
    DEBUGMSG( "-------------------------------------------------------\n");
    DEBUGMSG( " > BootStrap Mode  : 0x%x\n", (REGRW32(SYS_CON_BASE, SCU_STRAP)&0xF));
#endif
}

void ncBL2_DDR_Init(void)
{
    UINT32 Reg;
    INT32 loop;

    // DDR 108MHz Config
    WRITE32(0x000000A0, (APACHE_DDRC_BASE+0x04));
    WRITE32(0x00070805, (APACHE_DDRC_BASE+0x08));
    WRITE32(0x00622222, (APACHE_DDRC_BASE+0x0c));
    WRITE32(0x54600191, (APACHE_DDRC_BASE+0x10));
    WRITE32(0x00400022, (APACHE_DDRC_BASE+0x14));
    WRITE32(0x0000000E, (APACHE_DDRC_BASE+0x24));

    // PHY init Start
    WRITE32((1<<1)|(1<<0), (APACHE_DDRC_BASE+0x00));

    loop = 0x100000;
    while(loop--)
    {
        Reg = READ32((APACHE_DDRC_BASE+0x00));

        // PHY init complete
        if(Reg & (1<<4))
            break;
    }    

#if BL2_DEBUG_PRINT_ENABLE
    // PHY init result [1:success, 0:fail]
    DEBUGMSG( " > PHY Init - %s, Result - %s\n", loop<=0 ? "TimeOut":"Done", (Reg & (1<<5)) ? "Success":"Fail");
#endif

}

void ncBL2_SF_Init(void)
{
    __BL2_SSP_PinMux(gFlashCS);

    ncSvc_SF_Init();
    
    if(gFlashCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        REGRW32(APACHE_QSPI_BASE, 0x005C) = 0xFFFFFF;
    }
    else // BOOTSTRAP_BOOT_EXTERNAL_MODE
    {
        REGRW32(APACHE_QSPI_BASE, 0x005C) = 0x0;
    }
}

void ncBL2_SF_DeInit(void)
{
    __BL2_SF_PinMuxRelease(gFlashCS);  
}

INT32 ncBL2_sFlash_GetAppHeader(UINT32 nAddress)
{
    UINT8 pBuffer[FLASH_PAGE_SIZE] __attribute__ ((aligned (8)));   // [QSPI] Important align;
    INT32 ret = NC_SUCCESS;

    ncSvc_SF_ReadData(nAddress, (UINT8 *)pBuffer, SF_PAGE_SIZE);

    stAPPHD.mSignature  = CharToInt(&pBuffer[0]);   // APP Header Signature("AP35")
    stAPPHD.mRetryCount = CharToInt(&pBuffer[4]);   // APP Retry count
    stAPPHD.mAPPLength  = CharToInt(&pBuffer[8]);   // APP Header + Image Total Length
    stAPPHD.Reserved    = CharToInt(&pBuffer[12]);  

    stAPPHD.mImgSrcAddr = CharToInt(&pBuffer[16]);  // APP Image Source Address
    stAPPHD.mImgDstAddr = CharToInt(&pBuffer[20]);  // APP Image Destination Address
    stAPPHD.mImgLength  = CharToInt(&pBuffer[24]);  // APP Image Length
    stAPPHD.mImgCSum    = CharToInt(&pBuffer[28]);  // APP Image Checksum


#if BL2_DEBUG_PRINT_ENABLE
    {
        UINT32 i;
        
        if(nAddress == NORMAL_APP_HEADER_AREA)
        {
            DEBUGMSG( " > Flash Memory Normal APP Header Information ...\n");
        }
        else
        {
            DEBUGMSG( " > Flash Memory Backup APP Header Information ...\n");
        }

        DEBUGMSG( "-------------------------------------------------------\n");
        DEBUGMSG( " > Flash Address = 0x%8x", nAddress);

        for(i = 0; i < 32; i++)
        {
            if(!(i%0x10))
                DEBUGMSG( "\n 0x%x : ", (i>>24)&0xFF, (i>>16)&0xFF, (i>>8)&0xFF, i&0xFF);
            DEBUGMSG( "%x ", pBuffer[i]);
        }

        DEBUGMSG( "\n-------------------------------------------------------\n");

        DEBUGMSG( " > APP Signature     = %c%c%c%c\n",   pBuffer[0], pBuffer[1], pBuffer[2], pBuffer[3]);
        DEBUGMSG( " > APP RetryCount    = 0x%8x\n", stAPPHD.mRetryCount);
        DEBUGMSG( " > APP Header Length = 0x%8x\n", stAPPHD.mAPPLength);
        DEBUGMSG( " > APP Reserved      = 0x%8x\n", stAPPHD.Reserved);

        DEBUGMSG( " > APP Image SrcAddr = 0x%8x\n", stAPPHD.mImgSrcAddr);
        DEBUGMSG( " > APP Image DstAddr = 0x%8x\n", stAPPHD.mImgDstAddr);
        DEBUGMSG( " > APP Image Length  = 0x%8x\n", stAPPHD.mImgLength);
        DEBUGMSG( " > APP Image CSum    = 0x%8x\n", stAPPHD.mImgCSum);
    }
#endif

    if(stAPPHD.mSignature != APP_SIGNATURE_ID)
    {
#if BL2_DEBUG_PRINT_ENABLE
        DEBUGMSG( " > Error, Flash Memory APP Header Signature id Failure\n");
#endif
        ret = NC_FAILURE;
    }
    else if(!stAPPHD.mRetryCount || (stAPPHD.mRetryCount > 5))
    {
#if BL2_DEBUG_PRINT_ENABLE
        DEBUGMSG( " > Error, Flash Memory APP Header Retry Count Failure\n");
#endif
        ret = NC_FAILURE;
    }
    else if((stAPPHD.mAPPLength == 0) || (stAPPHD.mAPPLength > APP_IMAGE_LENGTH_MAX))
    {
#if BL2_DEBUG_PRINT_ENABLE
        DEBUGMSG( " > Error, Flash Memory APP Total Length Failure\n");
#endif  
        ret = NC_FAILURE;
    }
    else if(stAPPHD.mImgLength != (stAPPHD.mAPPLength-0x100))
    {
#if BL2_DEBUG_PRINT_ENABLE
        DEBUGMSG( " > Error, Flash Memory APP Image Length Failure\n");
#endif
        return NC_FAILURE;
    }
    else if(stAPPHD.mImgDstAddr != APP_IMAGE_BASE_ADDRESS)
    {
#if BL2_DEBUG_PRINT_ENABLE
        DEBUGMSG( " > Error, System Memory APP Dst_Address Failure\n");
#endif
        return NC_FAILURE;
    }

    if(ret == NC_FAILURE)
    {
        return ret;
    }
    
#if BL2_DEBUG_PRINT_ENABLE
    DEBUGMSG( " > Success, Flash Get APP Header\n");
    DEBUGMSG( "-------------------------------------------------------\n");
#endif

    return ret;
}

INT32 ncBL2_sFlash_GetAppImage(UINT32 nAddress)
{
    UINT32 i, size, retry;
    UINT32 nChecksum = 0;
    UINT8 *pBuffer;
    UINT32 *pDwBuffer;
    INT32 ret = NC_SUCCESS;


#if BL2_DEBUG_PRINT_ENABLE
    if(nAddress == NORMAL_APP_DATA_AREA)
    {
        DEBUGMSG( " > Flash Memory Normal APP Image Data Read ...\n");
    }
    else
    {
        DEBUGMSG( " > Flash Memory Backup APP Image Data Read ...\n");
    }

    DEBUGMSG( "-------------------------------------------------------\n");
    DEBUGMSG( " > Flash Memory Address  = 0x%8x\n", nAddress);
    DEBUGMSG( " > System Memory Address = 0x%8x\n", stAPPHD.mImgDstAddr);
    DEBUGMSG( " > APP Image Length      = 0x%8x\n", stAPPHD.mImgLength);
    DEBUGMSG( " > APP Image CSum        = 0x%8x\n", stAPPHD.mImgCSum);
    DEBUGMSG( "-------------------------------------------------------\n");
#endif

    size = Align(stAPPHD.mImgLength, 8);
    pBuffer = (UINT8 *)stAPPHD.mImgDstAddr;
    pDwBuffer = (UINT32 *)stAPPHD.mImgDstAddr;

    for(retry = 0; retry < stAPPHD.mRetryCount; retry++)
    {
        nChecksum = 0;

        ncSvc_SF_ReadData(nAddress, (UINT8 *)pBuffer, size);

        // 32bit checksum ...
        for(i = 0; i < stAPPHD.mImgLength/4; i++)
        {
            nChecksum += pDwBuffer[i];
        }

#if BL2_DEBUG_PRINT_ENABLE
        DEBUGMSG( " > Application Image nChecksum = 0x%8x\n", nChecksum);
#endif

        if(stAPPHD.mImgCSum != nChecksum)
        {
#if BL2_DEBUG_PRINT_ENABLE
            DEBUGMSG( " > Error, Flash Memory Application Data Download Checksum Failure\n");
#endif
            ret = NC_FAILURE;
        }
        else
        {
            break;
        }
    }

#if BL2_DEBUG_PRINT_ENABLE
    if(ret == NC_SUCCESS)
        DEBUGMSG( " > Success, Flash Get APP Image Read, DDR Write\n");
#endif

    return ret;
}

E_BL2_ERROR ncBL2_NormalBoot(void)
{
    INT32 ret = NC_SUCCESS;

    ret = ncBL2_sFlash_GetAppHeader(NORMAL_APP_HEADER_AREA);

    if(ret == NC_FAILURE)
    {
#if BL2_DEBUG_PRINT_ENABLE
        DEBUGMSG( " > Error, APP Normal Header Read Failure\n");
#endif
        return E_ERROR_NORMAL_APP_HEADER;
    }

    ret = ncBL2_sFlash_GetAppImage(NORMAL_APP_DATA_AREA);
    if(ret == NC_FAILURE)
    {
#if BL2_DEBUG_PRINT_ENABLE
        DEBUGMSG( " > Error, APP Normal Image Read Failure\n");
#endif
        return E_ERROR_NORMAL_APP_IMAGE;
    }

    return E_NOERROR;
}


E_BL2_ERROR ncBL2_BackupBoot(E_APP_BACKUP nScenario)
{
    INT32 ret = NC_SUCCESS;

    switch(nScenario)
    {
        case E_BACKUP_APP_HEADER:
        {
            ret = ncBL2_sFlash_GetAppHeader(BACKUP_APP_HEADER_AREA);

            if(ret == NC_FAILURE)
            {
#if BL2_DEBUG_PRINT_ENABLE
                DEBUGMSG( " > Error, APP Backup Header Read Failure\n");
#endif
                return E_ERROR_BACKUP_APP_HEADER;
            }
            
            ret = ncBL2_sFlash_GetAppImage(NORMAL_APP_DATA_AREA);
            if(ret == NC_FAILURE)
            {
#if BL2_DEBUG_PRINT_ENABLE
                DEBUGMSG( " > Error, APP Normal Image Read Failure\n");
#endif
                ret = ncBL2_sFlash_GetAppImage(BACKUP_APP_DATA_AREA);
                if(ret == NC_FAILURE)
                {
#if BL2_DEBUG_PRINT_ENABLE
                    DEBUGMSG( " > Error, APP Backup Image Read Failure\n");
#endif
                    return E_ERROR_BACKUP_APP_IMAGE;
                }
            }
        }
        break;

        case E_BACKUP_APP_IMAGE:
        {

            ret = ncBL2_sFlash_GetAppImage(BACKUP_APP_DATA_AREA);
            if(ret == NC_FAILURE)
            {
#if BL2_DEBUG_PRINT_ENABLE
                DEBUGMSG( " > Error, APP Backup Image Read Failure\n");
#endif
                return E_ERROR_BACKUP_APP_IMAGE;
            }
        }
        break;

        default :
        break;
    }

    return E_NOERROR;
}

void ncBL2_JumpDDR(void)
{
    UINT32 nTemp, i;
    PrVoid PC_CountReset = (PrVoid)NULL;

    REGRW32(SYS_CON_BASE, SYSCON_REMAP_START)  = 0x00000000;
    REGRW32(SYS_CON_BASE, SYSCON_REMAP_END)    = LPDDR_BASE_ADDRESS;
    REGRW32(SYS_CON_BASE, SYSCON_REMAP_ENABLE) = 1;

    while(1)
    {
        for(i = 0; i < 5; i++)
        {
            nTemp = REGRW32(SYS_CON_BASE, SYSCON_REMAP_ENABLE);
        }

        if(nTemp)
        {
            PC_CountReset();
        }
    }
}


INT32 main(void)
{ 
    E_BL2_ERROR nErrStatus;
    INT32 ret = NC_SUCCESS;

    //////////////////////////////////////////////////////////////////////////////
    // Defualt Peripheral Init
    //////////////////////////////////////////////////////////////////////////////
    ncBL2_PLL_Init();
    ncBL2_UART_Init();
    ncBL2_SF_Init();
    ncBL2_DDR_Init();

#if BL2_CAN_MODE_ENABLE
    ncSrv_CAN_FW_Update();
#endif

    //////////////////////////////////////////////////////////////////////////////
    // sFlash App Data Read -> DDR Write
    //////////////////////////////////////////////////////////////////////////////
    nErrStatus = ncBL2_NormalBoot();

    if(nErrStatus == E_ERROR_NORMAL_APP_HEADER)
    {
        nErrStatus = ncBL2_BackupBoot(E_BACKUP_APP_HEADER);
    }
    else if(nErrStatus == E_ERROR_NORMAL_APP_IMAGE)
    {     
        nErrStatus = ncBL2_BackupBoot(E_BACKUP_APP_IMAGE);
        if(nErrStatus == E_ERROR_BACKUP_APP_IMAGE)
        {
            nErrStatus = ncBL2_BackupBoot(E_BACKUP_APP_HEADER);
        }
    }

#if BL2_DEBUG_PRINT_ENABLE 
    if(nErrStatus == E_NOERROR)
    {
        DEBUGMSG(" > BOOT_SUCCESS\n");
    }
    else
    { 
        DEBUGMSG(" > BOOT_ERROR\n");
    } 
    DEBUGMSG( "-------------------------------------------------------\n");
#endif

    //////////////////////////////////////////////////////////////////////////////
    // Success : Jump DDR -> Run Appliaction
    // Fail    : Wait Status (It can be downloaded from the outside by JIG board)
    //////////////////////////////////////////////////////////////////////////////
    ncBL2_SF_DeInit();    
    if(nErrStatus == E_NOERROR)
    {
        REGRW32(SYS_CON_BASE, SCU_DEBUG_RESULT) = (('O'<<8) | ('K'<<0));
        ncBL2_JumpDDR();
    }
    else
    {
        REGRW32(SYS_CON_BASE, SCU_DEBUG_RESULT) = (('N'<<8) | ('G'<<0));
        while(1); 
    }

    return ret;
}

/* End Of File */
