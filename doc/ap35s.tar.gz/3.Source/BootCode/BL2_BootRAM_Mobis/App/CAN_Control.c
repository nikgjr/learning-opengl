/**
 ********************************************************************************
 *
 *  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
 *
 *  @file    : CAN_Srv.c
 *
 *  @brief   : This file is SCU, GPIO ...
 *
 *  @author  : alessio / SoC SW Group / Platform Team
 *
 *  @date    : 2016.01.27
 *
 *  @version : Version 0.0.1
 *
 ********************************************************************************
 *  @note    :
 *
 ********************************************************************************
 */

/*
 ********************************************************************************
 *               INCLUDE
 ********************************************************************************
 */

#include "Main.h"


#if BL2_CAN_MODE_ENABLE

#include "CAN_Control.h"
#include "CAN_Drv.h"



/*
 ********************************************************************************
 *               LOCAL DEFINITIONS
 ********************************************************************************
 */

#define FLASH_ERASE_AREA		0x00008000  // fixed address
#define FLASH_WRITE_AREA		0x00008000  // fixed address
#define FLASH_READ_AREA			0x00008000  // fixed address

#define LPDDR_APP_SRC_AREA		0x08040000
#define LPDDR_APP_DST_AREA		0x08000000

#define SF_SECTOR_SIZE			4096


/*
 ********************************************************************************
 *               LOCAL CONSTANT DEFINITIONS
 ********************************************************************************
 */

/*
 ********************************************************************************
 *               LOCAL TYPEDEF
 ********************************************************************************
 */

/*
 ********************************************************************************
 *               IMPORTED VARIABLE DEFINITIONS
 ********************************************************************************
 */

/*
 ********************************************************************************
 *               GLOBAL VARIABLE DEFINITIONS
 ********************************************************************************
 */

tCAN_MSG canRxMsg;
tCAN_MSG canTxMsg;


/*
 ********************************************************************************
 *               IMPORTED FUNCTION DEFINITIONS
 ********************************************************************************
 */

/*
 ********************************************************************************
 *               LOCAL FUNCTION PROTOTYPES
 ********************************************************************************
 */


/*
 ********************************************************************************
 *               FUNCTION DEFINITIONS
 ********************************************************************************
 */

void ncSrv_CAN_LPDDR_Wtire(tCAN_MSG nCanRxMsg, UINT8 nLength)
{
	UINT32 i;
	static UINT32 offset;
	UINT8 *pBuffer = (UINT8 *)LPDDR_APP_SRC_AREA;

	for(i = 0; i < nLength; i++)
	{
		pBuffer[offset++] = nCanRxMsg.data[i];
	}
}


void ncSrv_Flash_FW_Download(UINT32 nLength)
{
	UINT32 i;
	UINT32 size;
	UINT32 address;
	UINT8 *pBuffer;
	UINT8 *pDDRBuffer;
	UINT32 *pSRCBuffer;
	UINT32 *pDSTBuffer;

#if BL2_DEBUG_PRINT_ENABLE
	DEBUGMSG("nLength = %8x\n", nLength);
#endif

	/*
	 * Flash Memory Erase
	 * */

	nLength += SF_PAGE_SIZE;
	address = FLASH_ERASE_AREA;

	for(i = 0; i <64; i++)
	{
		address = FLASH_ERASE_AREA+(i*SF_SECTOR_SIZE);

		ncSvc_SF_SectorErase(address);

#if BL2_DEBUG_PRINT_ENABLE
		DEBUGMSG("Flash Erase Address = 0x%8X\n", address);
#endif
	}

#if BL2_DEBUG_PRINT_ENABLE
	DEBUGMSG("Flash Memory Erase : eCAN_CMD_SUCCESS\n");
#endif

	/*
	 * Flash Memory Write and Read
	 * */

    pBuffer = (UINT8 *)LPDDR_APP_SRC_AREA;
	address = FLASH_WRITE_AREA;

	for(i = 0; i < nLength; i+=SF_PAGE_SIZE)
	{
		ncSvc_SF_WriteData(address+i, (UINT8 *)(pBuffer+i), SF_PAGE_SIZE);
	}

	pDDRBuffer = (UINT8 *)LPDDR_APP_DST_AREA;
	address = FLASH_READ_AREA;
	nLength = Align(nLength, 8);

	for(i = 0; i < nLength; i+=SF_PAGE_SIZE)
	{
		ncSvc_SF_ReadData(address+i, (UINT8 *)(pDDRBuffer+i), SF_PAGE_SIZE);
	}

#if BL2_DEBUG_PRINT_ENABLE
    DEBUGMSG("Flash Memory Write : eCAN_CMD_SUCCESS\n");
#endif

	/*
	 * Compare
	 * */

    pSRCBuffer = (UINT32 *)LPDDR_APP_SRC_AREA;
    pDSTBuffer = (UINT32 *)LPDDR_APP_DST_AREA;
	size = nLength/4;

	for(i = 0; i < size; i++)
	{
		if(pSRCBuffer[i] != pDSTBuffer[i])
		{
#if BL2_DEBUG_PRINT_ENABLE
		    DEBUGMSG("Compare %d, pCSBuffer[%8x] != pBuffer[%8x] eCAN_CMD_FAILURE\n", i, pSRCBuffer[i], pDSTBuffer[i]);
#endif
		    return;
		}
	}

#if BL2_DEBUG_PRINT_ENABLE
    DEBUGMSG("Compare : eCAN_CMD_SUCCESS\n");
#endif
}


INT32 ncSrv_CAN_FW_Update(void)
{
	UINT8 i, nCmd;
	UINT32 length;
    tCAN_PARAM PeliCAN;
    INT32 ret = NC_SUCCESS;

    PeliCAN.acrId = 0xFFFFFFFF;
    PeliCAN.amrId = 0xFFFFFFFF;
    PeliCAN.baudrate = CAN_BPS_125KBPS;
    PeliCAN.mode = CAN_CDR_PELI_MODE;
    PeliCAN.filter = CAN_SINGLE_FILTER;

    ncDrv_CAN_Init(&PeliCAN);

    //memset((UINT8 *)&canRxMsg, 0, sizeof(tCAN_MSG));

    canTxMsg.id = 0x793;
    canTxMsg.length = 8;
    canTxMsg.objch = CAN_MSGOBJ_ACTIVE;
    canTxMsg.mode = CAN_CDR_PELI_MODE;
    canTxMsg.format = CAN_FI_STANDARD_FORMAT;
    canTxMsg.rtr = CAN_FI_DATA_FRAME;

    while(1)
    {
#if BL2_DEBUG_PRINT_ENABLE
        //DEBUGMSG("[CAN_BOOT] Wait CAN Command\n");
#endif

        ret = ncDrv_CAN_Receive(&canRxMsg);
        if(ret == NC_SUCCESS)
        {
#if BL2_DEBUG_PRINT_ENABLE
			DEBUGMSG("Rx ");
			for(i = 0; i < 8; i++)
			{
				DEBUGMSG("%x ",canRxMsg.data[i]);
			}
			DEBUGMSG("\n");
#endif

			for(i = 0; i < 8; i++)
			{
				canTxMsg.data[i] = 0xAA;
			}

	        nCmd = canRxMsg.data[0];

	        switch(nCmd)
	        {
				case 0x02:
				{
			        switch(canRxMsg.data[1])
			        {
						case 0x10:
						{
							if(canRxMsg.data[2] == 0x02)
							{
								canTxMsg.data[2] = 0x02;
							}
							else if(canRxMsg.data[2] == 0x03)
							{
								canTxMsg.data[2] = 0x03;
							}

							canTxMsg.data[0] = 0x02;
							canTxMsg.data[1] = 0x50;
						}
						break;

						case 0x28:
						{
							if(canRxMsg.data[2] == 0x01)
							{
								canTxMsg.data[0] = 0x02;
								canTxMsg.data[1] = 0x68;
								canTxMsg.data[2] = 0x01;
							}
						}
						break;

						case 0x27:
						{
							if(canRxMsg.data[2] == 0x01)
							{
								canTxMsg.data[0] = 0x06;
								canTxMsg.data[1] = 0x67;
								canTxMsg.data[2] = 0x01;
								canTxMsg.data[3] = 0x01;
								canTxMsg.data[4] = 0x01;
								canTxMsg.data[5] = 0x01;
								canTxMsg.data[6] = 0x01;
							}
						}
						break;
			        }
				}
				break;

				case 0x04:
				{
			        switch(canRxMsg.data[1])
			        {
						case 0x31:
						{
							if(canRxMsg.data[2] == 0x01)
							{
								canTxMsg.data[0] = 0x04;
								canTxMsg.data[1] = 0x71;
								canTxMsg.data[2] = 0x01;
								canTxMsg.data[3] = 0xFF;
								canTxMsg.data[4] = 0x00;
							}
						}
						break;
			        }
				}
				break;

				case 0x06:
				{
			        switch(canRxMsg.data[1])
			        {
						case 0x27:
						{
							if(canRxMsg.data[2] == 0x02)
							{
								canTxMsg.data[0] = 0x02;
								canTxMsg.data[1] = 0x67;
								canTxMsg.data[2] = 0x02;
							}
						}
						break;
			        }
				}
				break;

				case 0xAA:
				{
					length = 156772;
					ncSrv_Flash_FW_Download(length);
					goto Exit_CAN_Control;
				}
				break;
	        }

#if BL2_DEBUG_PRINT_ENABLE
			DEBUGMSG("Tx ");
			for(i = 0; i < 8; i++)
			{
				DEBUGMSG("%x ",canTxMsg.data[i]);
			}
			DEBUGMSG("\n");
#endif

            ncDrv_CAN_Send(&canTxMsg);
        }
    }

Exit_CAN_Control:

    ncDrv_CAN_DeInit();

	return ret;
}


#endif


/* End Of File */
