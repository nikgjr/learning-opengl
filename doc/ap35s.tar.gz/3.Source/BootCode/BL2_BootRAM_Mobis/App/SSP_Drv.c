/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SSP_Drv.c
*
*  @brief   : This file is SSP Controller Driver for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.01.08
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : ARM PrimeCell�� SSP (PL022) / Revision: r1p3
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define DEFAULT_SSP_CLOCK_DIVIDER           2


#define	SPI_IS_BUSY(status)     ((status)&SSP_BSY)
#define	SPI_IS_RxReady(status)  ((status)&SSP_RNE)


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
void ncDrv_SSP_ClearRxFIFO(void)
{
    UINT32 Count;

    for(Count=0; Count<8; Count++)
    {
        if(APACHE_SPI_READ(SSP_SR) & SSP_RNE)
        {
            APACHE_SPI_READ(SSP_DR);  // Drop Data
        }
        else
        {
            break;
        }
    }
}


BOOL ncDrv_SSP_WaitBusIsBusy(UINT32 TimeOut)
{
    UINT32 Status;
    UINT32 Count;
    UINT32 ret = FALSE;

    for(Count=0; Count<TimeOut; Count++)
    {
        Status = APACHE_SPI_READ(SSP_SR);

        if(!SPI_IS_BUSY(Status))
        {
            ret = TRUE;
            break;
        }
    }

    return ret;
}


BOOL ncDrv_SSP_WaitRxFIFOIsReady(UINT32 TimeOut)
{
    UINT32 Status;
    UINT32 Count;
    UINT32 Ret = FALSE;

    for(Count=0; Count<TimeOut; Count++)
    {
        Status = APACHE_SPI_READ(SSP_SR);
        if(SPI_IS_RxReady(Status))
        {
            Ret = TRUE;
            break;
        }
    }

    return Ret;
}


void ncDrv_SSP_Init(void)
{
    APACHE_SPI_WRITE(SSP_CR0, (SSP_SPH_LOW | SSP_SPO_LOW | SSP_FRF_SPI | SSP_DSS_8BIT) );
    APACHE_SPI_WRITE(SSP_CR1,  (SSP_SOD_EN | SSP_MS_MASTER | SSP_SSE_EN | SSP_LBM_DS));
    APACHE_SPI_WRITE(SSP_CPSR, DEFAULT_SSP_CLOCK_DIVIDER);
    APACHE_SPI_WRITE(SSP_IMSC, (SSP_TXIM_MASKED | SSP_RXIM_MASKED | SSP_RTIM_NOMASKED | SSP_RORIM_NOMASKED));
    APACHE_SPI_WRITE(SSP_RIS, (SSP_TXRIS | SSP_RXRIS | SSP_RTRIS | SSP_RORRIS));
}


INT32 ncDrv_SSP_DeInit(void)
{
    INT32 ret = NC_SUCCESS;

    APACHE_SPI_WRITE(SSP_CR1, 0);

    return ret;
}


INT32 ncDrv_SSP_Read(UINT8 *pBuf, UINT32 nLength)
{
    INT32  ret = NC_SUCCESS;
    UINT32 i;

    for(i = 0; i < nLength; i++)
    {
        /* Write dummy data */
        APACHE_SPI_WRITE(SSP_DR, 0x00);

        if(!ncDrv_SSP_WaitBusIsBusy(1000))
        {
            ret = NC_FAILURE;
        }

        if(!ncDrv_SSP_WaitRxFIFOIsReady(1000))
        {
            ret = NC_FAILURE;
        }

        /* Read data */
        pBuf[i] = (UINT8)APACHE_SPI_READ(SSP_DR);
    }

    return ret;
}


INT32 ncDrv_SSP_Write(UINT8 *pBuf, UINT32 nLength)
{
    UINT32 i;
    INT32 ret = NC_SUCCESS;

    for(i = 0; i < nLength; i++)
    {
        /* Write data */
        APACHE_SPI_WRITE(SSP_DR, pBuf[i]);

        ncDrv_SSP_WaitBusIsBusy(1000);

        /* Read dummy Data */
        ret = APACHE_SPI_READ(SSP_DR);
    }

    return ret;
}

/* End Of File */
