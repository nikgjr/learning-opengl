/*
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : sFlash_Svc.h
*
*  @brief   : This file is sFlash controller API for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.01.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __SFLASH_SVC_H__
#define __SFLASH_SVC_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "sFlash_Lib.h"


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern void   ncSvc_SF_SetSPIInputClock(UINT32 Clock);
extern INT32  ncSvc_SF_Init(ptSF_INIT_PARAM ptParam);
extern INT32  ncSvc_SF_Release(void);

extern INT32  ncSvc_SF_SectorErase(UINT32 PageAddr);
extern INT32  ncSvc_SF_BlockErase(UINT32 PageAddr);

extern void   ncSvc_SF_WaitWIP(void);
extern void   ncSvc_SF_WriteEnable(void);
extern void   ncSvc_SF_WriteDisable(void);
extern UINT8  ncSvc_SF_ReadStatus(void);
extern UINT8  ncSvc_SF_ReadStatus2(void);
extern void   ncSvc_SF_WriteStatus(UINT8 Status);
extern void   ncSvc_SF_WriteStatus2(UINT8 Status1, UINT8 Status2);

extern INT32  ncSvc_SF_ReadDeviceIdentification(ptSFLASH_ID ptsFlashID);
extern INT32  ncSvc_SF_ReadPage(UINT32 PageAddr, UINT8 *pData);
extern INT32  ncSvc_SF_ReadData(UINT32 Addr, UINT8 *pData, UINT32 Size);

extern INT32 ncSvc_SF_WriteData(UINT32 Addr, UINT8 *pData, UINT32 Size);
extern void ncSvc_SF_EnableWP(BOOL OnOff);

#endif /* __SFLASH_SVC_H__ */
