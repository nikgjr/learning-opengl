/*
********************************************************************************
*
*  Copyright (C) 2016 	NEXTCHIP Inc. All rights reserved.
*
*  @file    : sFlash_Lib.c
*
*  @brief   : This file is sFlash controller API for NEXTCHIP standard library
*
*  @author  :
*
*  @date    :	2016.01.19
*
*  @version :	Version 1.0.0
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <stdarg.h>

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

BOOL gbSFOpen;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncLib_SF_Open(UINT32 nInputClk)
{
    INT32 ret = NC_SUCCESS;

    if(gbSFOpen == FALSE)
    {
        ncLib_SSP_Open(nInputClk);
        ncSvc_SF_SetSPIInputClock(nInputClk);

        gbSFOpen = TRUE;
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_SF_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbSFOpen == TRUE)
    {
        ncLib_SSP_Close();
        gbSFOpen = FALSE;
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_SF_Read(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_SF_Write(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_SF_Control(eSF_CMD Cmd, ...)
{
    INT32   ret = NC_SUCCESS;
    UINT32  count = 0;
    UINT32  argData[10];
    va_list vlist;
    BOOL    bEndCmd = FALSE;

    if(gbSFOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vlist, Cmd);

        for(count=0; count<10; count++)
        {
            argData[count] = va_arg(vlist, UINT32);

            if(argData[count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vlist);


        if(bEndCmd == FALSE)
        {
            ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case GCMD_SF_INIT:
                    ret = ncSvc_SF_Init((ptSF_INIT_PARAM) argData[0]);
                break;

                case GCMD_SF_DEINIT:
                    ret = ncSvc_SF_Release();
                break;

                case GCMD_SF_BLOCK_ERASE:
                    ret = ncSvc_SF_BlockErase(argData[0]);
                break;

                case GCMD_SF_SECTOR_ERASE:
                    ret = ncSvc_SF_SectorErase(argData[0]);
                break;

                case GCMD_SF_READ_DATA:
                    ret = ncSvc_SF_ReadData(argData[0], (UINT8 *) argData[1], argData[2]);
                break;

                case GCMD_SF_READ_PAGE:
                    ret = ncSvc_SF_ReadPage(argData[0], (UINT8 *) argData[1]);
                break;

                case GCMD_SF_WRITE_DATA:
                    ret = ncSvc_SF_WriteData(argData[0], (UINT8 *)argData[1], argData[2]);
                break;

                case GCMD_SF_READ_STATUS:
                    ret = ncSvc_SF_ReadStatus();
                break;

                case GCMD_SF_WRTIE_STATUS:
                    ncSvc_SF_WriteStatus(argData[0]);
                break;

                case GCMD_SF_READ_STATUS2:
                    ret = ncSvc_SF_ReadStatus2();
                break;

                case GCMD_SF_WRITE_STATUS2:
                    ncSvc_SF_WriteStatus2(argData[0], argData[1]);
                break;

                case GCMD_SF_WAIT_WIP:
                    ncSvc_SF_WaitWIP();
                break;

                case GCMD_SF_WRITE_EN:
                    ncSvc_SF_WriteEnable();
                break;

                case GCMD_SF_WRITE_DS:
                    ncSvc_SF_WriteDisable();
                break;

                case SCMD_SF_SET_QUAD_CLK:
                break;

                default :
                ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


/* End Of File */
