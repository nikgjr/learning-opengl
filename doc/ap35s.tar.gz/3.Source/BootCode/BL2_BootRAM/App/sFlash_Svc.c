/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : sFlash_Svc.c
*
*  @brief   : This file is sFlash controller API for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.11.19
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define PAGE_SIZE								256

#define CMD_sFlash_WR_EN						0x06
#define CMD_sFlash_WR_DS						0x04
#define CMD_sFlash_RD_STS						0x05
#define CMD_sFlash_RD_STS2						0x35		// for WINBOND SPI Flash
#define CMD_sFlash_WR_STS						0x01
#define CMD_sFlash_RD_DATA						0x03
#define CMD_sFlash_PAGE_PROGRAM					0x02
#define CMD_sFlash_SECTOR_ERASE					0x20
#define CMD_sFlash_BLOCK_ERASE					0xD8
#define CMD_sFlash_RD_IDENTIFICATION			0x9F

#define CMD_sFlash_QUAD_ENABLE					0x35		// for MXIC SPI Flash
#define CMD_sFlash_QUAD_FAST_READ				0xEB

#define STS_WIP									(0x1<<0)
#define STS_WEL									(0x1<<1)

#define FLASH_ID_WINBOND						(0xEF)
#define FLASH_ID_EON							(0x1C)
#define FLASH_ID_MXIC							(0xC2)
#define FLASH_ID_MICRON							(0x20)
#define FLASH_ID_SPANSION						(0xEF)

#define FLASH_SECTOR_SIZE						(0x1000)
#define FLASH_BLOCK_SIZE						(0x10000)

#define BP0     (1<<2)
#define BP1     (1<<3)
#define BP2     (1<<4)
#define BP3     (1<<5)

/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

BOOL   gbDmaMode   = FALSE;
BOOL   gbQuadMode  = FALSE;
UINT32 gSFInputClock = 0;
UINT8  gSSPChNum;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

BOOL ncDrv_QSPI_WaitBusIsBusy(UINT32 TimeOut)
{
    BOOL Ret = FALSE;
    UINT32 Status;
    UINT32 Count;

    for(Count=0; Count<TimeOut; Count++)
    {
        Status = APACHE_READ(APACHE_QSPI_BASE+0x18);

        if(!(Status&(1<<16)))
        {
            Ret = TRUE;
            break;
        }
    }

    return Ret;
}


BOOL ncDrv_QSPI_WaitFrameDone(UINT32 TimeOut)
{
    BOOL Ret = FALSE;
    UINT32 Status;
    UINT32 Count;

    for(Count=0; Count<TimeOut; Count++)
    {
        Status = APACHE_READ(APACHE_QSPI_BASE+0x18);

        if((Status&(1<<22)))
        {
            Ret = TRUE;
            break;
        }
    }

    return Ret;
}


INT32 ncDrv_QSPI_ReadData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
#if BL2_JTAG_BOOT_ENABLE
    //APACHE_WRITE(APACHE_QSPI_BASE+0x00, 0x005107EB); // quad-spi clock bit[11:8], 1MHz
    APACHE_WRITE(APACHE_QSPI_BASE+0x00, 0x005108EB); // [yonghwi.lee] change baud rate for FPGA env
#else
    //APACHE_WRITE(APACHE_QSPI_BASE+0x00, 0x00510DEB); // quad-spi clock bit[11:8], D : 1/3 49.5MHz
    APACHE_WRITE(APACHE_QSPI_BASE+0x00, 0x00510EEB); // quad-spi clock bit[11:8], E : 1/2 74.25MHz
#endif
    APACHE_WRITE(APACHE_QSPI_BASE+0x18, 0x00000000);

    APACHE_WRITE(APACHE_QSPI_BASE+0x10, (UINT32 )pData);
    APACHE_WRITE(APACHE_QSPI_BASE+0x14, 0x000000B0);

    APACHE_WRITE(APACHE_QSPI_BASE+0x04, Addr + Size);
    APACHE_WRITE(APACHE_QSPI_BASE+0x08, 0x00FF0000);
    APACHE_WRITE(APACHE_QSPI_BASE+0x0C, Addr);

    if(!ncDrv_QSPI_WaitBusIsBusy(0x1000000))
    {
        //DEBUGMSG(1, "\n >> QSPI Wait Busy TimeOut!\n");
    }	

    if(!ncDrv_QSPI_WaitFrameDone(0x1000000))
    {
        //DEBUGMSG(1, "\n >> QSPI Frame Done TimeOUt!\n");
    }	

    return NC_SUCCESS;
}


void ncSvc_SF_SetSPIInputClock(UINT32 Clock)
{
    gSFInputClock = Clock;
}


INT32 ncSvc_SF_Init(ptSF_INIT_PARAM ptParam)
{
    INT32 ret;
    tSSP_INIT_PARAM tSSPParam;
    tSFLASH_ID tsFlashID;
    UINT8 Status1;
    UINT8 Status2;

    tSSPParam.mFormat		= SSP_FMT_SPI;
    tSSPParam.mMode			= SSP_MODE_MASTER;
    tSSPParam.mDataWidth	= SSP_DS_8BIT;
    tSSPParam.mBitRate		= ptParam->mBitRate;
    tSSPParam.mDmaMode		= ptParam->mDmaMode;
    tSSPParam.mTxIntEn		= FALSE; 
    tSSPParam.mRxIntEn		= FALSE;
    tSSPParam.mSPO			= SSP_SPO_LOW;
    tSSPParam.mSPH			= SSP_SPH_LOW;	

    ret = ncLib_SSP_Control(GCMD_SSP_INIT_CH, ptParam->mChNum, &tSSPParam, CMD_END);	
    if(ret == NC_FAILURE)
    {
        return ret;
    }

    gSSPChNum = ptParam->mChNum;
    gbDmaMode = ptParam->mDmaMode;

    ncSvc_SF_ReadDeviceIdentification(&tsFlashID);

    if(ptParam->mQuadMode == FALSE)
    {
        gbQuadMode = FALSE;
    }
    else
    {
        if(tsFlashID.mbManufacture == FLASH_ID_WINBOND)
        {
            Status1 = ncSvc_SF_ReadStatus();
            Status2 = ncSvc_SF_ReadStatus2();

            if( !(Status2 & 0x2) )
            {
                ncSvc_SF_WriteStatus2(Status1, Status2|0x2);
            }
        }
        else if(tsFlashID.mbManufacture == FLASH_ID_MXIC)
        {
            Status1 = ncSvc_SF_ReadStatus();
            if( !(Status1 & (1<<6)) )
            {
                ncSvc_SF_WriteStatus(Status1|(1<<6));
            }
        }

        gbQuadMode = TRUE;
    }

#if BOOT_DEBUG_PRINT_ENABLE
    {
        UINT32 nChipSize = 0x10000; //FLASH_BLOCK_SIZE;
        UINT32 i, nCapacity;

        nCapacity = tsFlashID.mbMemoryCapacity & 0x0F;

        for(i = 0; i <= 8; i++)
        {
            if(nCapacity == i)
            {
                break;
            }
            else
            {
                nChipSize = nChipSize * 2;
            }
        }

        DEBUGMSG(MSGINFO, "\n1.Flash Memory Information ...\n");
        DEBUGMSG(MSGINFO, "SPI Mode = %d\n", gbQuadMode);
        DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, "  manufacturer ID : 0x%x\n", tsFlashID.mbManufacture);
        DEBUGMSG(MSGINFO, "  memory type     : 0x%x\n", tsFlashID.mbMemoryType);
        DEBUGMSG(MSGINFO, "  memory density  : 0x%x\n", tsFlashID.mbMemoryCapacity);
        DEBUGMSG(MSGINFO, "  memory size     : %d MBbyte\n", nChipSize/MB);
        DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");
    }
#endif

    return NC_SUCCESS;
}


INT32 ncSvc_SF_Release(void)
{
    INT32 ret;

    /*
    * Deinit SSP Channel
    */

    ret = ncLib_SSP_Control(GCMD_SSP_DEINIT_CH, gSSPChNum, CMD_END);	

    //if(ret == NC_FAILURE)
    //{
    //}

    if(gbQuadMode == TRUE)
    {
    }

    gSSPChNum  = 0;
    gbQuadMode = 0;
    gbDmaMode  = 0;

    return ret;
}


void ncSvc_SF_WaitWIP(void)
{
    while(ncSvc_SF_ReadStatus() & STS_WIP) ;
}


void ncSvc_SF_WriteEnable(void)
{
    UINT8 Command;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, gSSPChNum, CMD_END);	

    Command = CMD_sFlash_WR_EN;
    ncLib_SSP_Write(gSSPChNum, &Command, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, gSSPChNum, CMD_END);	

    while( (ncSvc_SF_ReadStatus() & STS_WEL) != STS_WEL  ) ;
}


void ncSvc_SF_WriteDisable(void)
{
    UINT8 Command;

    while( ncSvc_SF_ReadStatus() & STS_WIP  ) ;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, gSSPChNum, CMD_END);	

    Command = CMD_sFlash_WR_DS;
    ncLib_SSP_Write(gSSPChNum, &Command, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, gSSPChNum, CMD_END);	
}


UINT8 ncSvc_SF_ReadStatus(void)
{
    UINT8 Command;
    UINT8 Status;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, gSSPChNum, CMD_END);	

    Command = CMD_sFlash_RD_STS;
    ncLib_SSP_Write(gSSPChNum, &Command, 1);	
    ncLib_SSP_Read(gSSPChNum, &Status, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, gSSPChNum, CMD_END);	

    return Status;
}


UINT8 ncSvc_SF_ReadStatus2(void)
{
    UINT8 Command;
    UINT8 Status;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, gSSPChNum, CMD_END);	

    Command = CMD_sFlash_RD_STS2;
    ncLib_SSP_Write(gSSPChNum, &Command, 1);	
    ncLib_SSP_Read(gSSPChNum, &Status, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, gSSPChNum, CMD_END);	

    return Status;
}


void ncSvc_SF_WriteStatus(UINT8 Status)
{
    UINT8 Command[2];

    ncSvc_SF_WriteEnable();

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, gSSPChNum, CMD_END);	

    Command[0] = CMD_sFlash_WR_STS;
    Command[1] = Status;
    ncLib_SSP_Write(gSSPChNum, Command, 2);

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, gSSPChNum, CMD_END);	

    ncSvc_SF_WriteDisable();
}


void ncSvc_SF_WriteStatus2(UINT8 Status1, UINT8 Status2)
{
    UINT8 Command[3];

    ncSvc_SF_WriteEnable();

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, gSSPChNum, CMD_END);	

    Command[0] = CMD_sFlash_WR_STS;
    Command[1] = Status1;
    Command[2] = Status2;	
    ncLib_SSP_Write(gSSPChNum, Command, 3);

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, gSSPChNum, CMD_END);	

    ncSvc_SF_WriteDisable();
}


INT32 ncSvc_SF_ReadDeviceIdentification(ptSFLASH_ID ptsFlashID)
{
    UINT8 Command;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, gSSPChNum, CMD_END);	

    Command = CMD_sFlash_RD_IDENTIFICATION;
    ncLib_SSP_Write(gSSPChNum, &Command, 1);	
    ncLib_SSP_Read(gSSPChNum, (UINT8*)ptsFlashID, 3);		

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, gSSPChNum, CMD_END);	

    return NC_SUCCESS;
}


INT32 ncSvc_SF_ReadPage(UINT32 PageAddr, UINT8 *pData)
{
    UINT8 Command[4];

    if(gbDmaMode == TRUE)
    {

    }
    else
    {
        ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, gSSPChNum, CMD_END);	

        Command[0] = CMD_sFlash_RD_DATA;
        Command[1] = (PageAddr>>16 & 0xFF);
        Command[2] = (PageAddr>>8  & 0xFF);
        Command[3] = (PageAddr     & 0xFF);
        ncLib_SSP_Write(gSSPChNum, Command, 4);		
        ncLib_SSP_Read(gSSPChNum, pData, PAGE_SIZE);	

        ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, gSSPChNum, CMD_END);	
    }

    return NC_SUCCESS;
}


INT32 ncSvc_SF_ReadData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    UINT8 Command[4];

    if(gbQuadMode == TRUE)
    {
        ncDrv_QSPI_ReadData(Addr, pData, Size);
    }
    else
    {
        if(gbDmaMode == TRUE)
        {
        }
        else
        {
            ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, gSSPChNum, CMD_END);	

            Command[0] = CMD_sFlash_RD_DATA;
            Command[1] = (Addr>>16 & 0xFF);
            Command[2] = (Addr>>8  & 0xFF);
            Command[3] = (Addr     & 0xFF);

            ncLib_SSP_Write(gSSPChNum, Command, 4);		
            ncLib_SSP_Read(gSSPChNum, pData, Size);	

            ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, gSSPChNum, CMD_END);	
        }
    }

    return NC_SUCCESS;
}


INT32 ncSvc_SF_WriteData(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();


    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, gSSPChNum, CMD_END);

    Command[0] = CMD_sFlash_PAGE_PROGRAM;
    Command[1] = (Addr>>16 & 0xFF);
    Command[2] = (Addr>>8  & 0xFF);
    Command[3] = (Addr     & 0xFF);
    ncLib_SSP_Write(gSSPChNum, Command, 4);

    if((gbDmaMode == TRUE) && (Size>16))
        ;
    else
        ncLib_SSP_Write(gSSPChNum, pData, Size);

    ncLib_SSP_Control(GCMD_SSP_WAIT_BUSY, gSSPChNum, CMD_END);
    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, gSSPChNum, CMD_END);


    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}


/*
********************************************************************************
* Function Name : ncSvc_SF_SectorErase()
*
*
* Description : Send "Sector Erase" command to erase 1 sector of serial flash
*               (1 sector size is 4KB)
*
*
* Arguments  : @ PageAddr : Sector address to be erased
*
*
* Return     : None
********************************************************************************
*/
INT32 ncSvc_SF_SectorErase(UINT32 PageAddr)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, gSSPChNum, CMD_END);

    Command[0] = CMD_sFlash_SECTOR_ERASE;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);
    ncLib_SSP_Write(gSSPChNum, Command, 4);

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, gSSPChNum, CMD_END);

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}


/*
********************************************************************************
* Function Name : ncSvc_SF_BlockErase()
*
*
* Description : Send "Block Erase" command to erase 1 block of serial flash
*               (1 Block Size is 64KB)
*
*
* Arguments  : @ PageAddr : Block address to be erased
*
*
* Return     : None
********************************************************************************
*/
INT32 ncSvc_SF_BlockErase(UINT32 PageAddr)
{
    UINT8 Command[4];

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteEnable();

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, gSSPChNum, CMD_END);

    Command[0] = CMD_sFlash_BLOCK_ERASE;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);
    ncLib_SSP_Write(gSSPChNum, Command, 4);

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, gSSPChNum, CMD_END);

    ncSvc_SF_WaitWIP();
    ncSvc_SF_WriteDisable();

    return NC_SUCCESS;
}


/*
********************************************************************************
* Function Name : ncSvc_SF_EnableWP()
*
*
* Description : Set Data Protection by setting BP0, BP1, BP2, BP3 in Status Register.
*
*
* Arguments  :
*
*
* Return     : None
********************************************************************************
*/
void ncSvc_SF_EnableWP(BOOL OnOff)
{

    tSFLASH_ID tsFlashID;
    UINT8 Status1=0;
    UINT8 protection = BP3|BP2|BP1|BP0;

    ncSvc_SF_ReadDeviceIdentification(&tsFlashID);

    if(OnOff)
    {
        Status1 = ncSvc_SF_ReadStatus();
        Status1 |= protection;
        ncSvc_SF_WriteStatus(Status1);
    }
    else
    {
        Status1 = ncSvc_SF_ReadStatus();
        Status1 &= ~(protection);
        ncSvc_SF_WriteStatus(Status1);
    }
}


/* End Of File */
