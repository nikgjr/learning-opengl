/**
 ********************************************************************************
 *
 *  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
 *
 *  @file    : CAN_Srv.c
 *
 *  @brief   : This file is SCU, GPIO ...
 *
 *  @author  : alessio / SoC SW Group / Platform Team
 *
 *  @date    : 2016.01.27
 *
 *  @version : Version 0.0.1
 *
 ********************************************************************************
 *  @note    :
 *
 ********************************************************************************
 */

/*
 ********************************************************************************
 *               INCLUDE
 ********************************************************************************
 */

#include "Main.h"


#if BL2_CAN_BOOT_ENABLE

#include "CAN_Boot.h"
#include "CAN_Drv.h"


/*
 ********************************************************************************
 *               LOCAL DEFINITIONS
 ********************************************************************************
 */


/*
 ********************************************************************************
 *               LOCAL CONSTANT DEFINITIONS
 ********************************************************************************
 */

/*
 ********************************************************************************
 *               LOCAL TYPEDEF
 ********************************************************************************
 */

/*
 ********************************************************************************
 *               IMPORTED VARIABLE DEFINITIONS
 ********************************************************************************
 */

/*
 ********************************************************************************
 *               GLOBAL VARIABLE DEFINITIONS
 ********************************************************************************
 */

/*
 ********************************************************************************
 *               IMPORTED FUNCTION DEFINITIONS
 ********************************************************************************
 */

/*
 ********************************************************************************
 *               LOCAL FUNCTION PROTOTYPES
 ********************************************************************************
 */


/*
 ********************************************************************************
 *               FUNCTION DEFINITIONS
 ********************************************************************************
 */

tCAN_PARAM param;
tCAN_MSG msg;
tCAN_INFO info;

extern BOOL gbQuadMode;

UINT32 __ctoi(UINT8* src)
{
    UINT8 tmp[4] = {0,};

    tmp[0] = src[3];
    tmp[1] = src[2];
    tmp[2] = src[1];
    tmp[3] = src[0];

    return *(UINT32*)tmp;
}

static void spi_quad_to_single()
{

    UINT32 Status1=0;

    __BL2_SSP_PinMux(0, 0);
    Status1 = ncSvc_SF_ReadStatus();
    if ((Status1 & (1 << 6)))
    {
        Status1 &= ~(1 << 6);
        ncSvc_SF_WriteStatus(Status1);
    }
    gbQuadMode = FALSE;
}

static void spi_single_to_quad()
{

    UINT32 Status1=0;

    Status1 = ncSvc_SF_ReadStatus();
    if (!(Status1 & (1 << 6)))
    {
        ncSvc_SF_WriteStatus(Status1 | (1 << 6));
    }
    Status1 = ncSvc_SF_ReadStatus();
    gbQuadMode = TRUE;
    __BL2_QSPI_PinMux(0, 0);
    gbQuadMode = TRUE;
}


static INT32 ncSrv_CAN_FlashDownload(UINT32 img_size, UINT32 img_addr, UINT32 src_csum)
{
    UINT32 ret=NC_SUCCESS;
    UINT32 i=0;

    UINT32 size = img_size;
    UINT32 start_addr = img_addr;
    UINT32 data_len = 8;
    UINT32 mod=0;
    UINT32 cnt=0;
    UINT32 addr = start_addr;
    UINT8 r_buf[8] __attribute__ ((aligned (8))) = {0,};
    UINT32 dst_csum=0;

#if BOOT_DEBUG_PRINT_ENABLE
    DEBUGMSG(MSGINFO, "[CAN_BOOT] ++ ncSrv_CAN_FlashDownload() ++\n");
#endif

    for(i=0; i<size; i+=SF_SECTOR_SIZE)
        ncLib_SF_Control(GCMD_SF_SECTOR_ERASE, addr+i-1, CMD_END);

#if BOOT_DEBUG_PRINT_ENABLE
    DEBUGMSG(MSGINFO, "[CAN_BOOT] ERASE is completed\n");
#endif

    cnt = img_size / data_len;
    mod = img_size % data_len;

    while (cnt > 0)
    {
        ret = ncDrv_CAN_PeliReceive(&msg);
        if (ret != NC_SUCCESS)
            continue;

        ncLib_SF_Control(GCMD_SF_WRITE_DATA, addr, &msg.data[0], data_len, CMD_END);
        addr += data_len;
        cnt--;
    }

    if (mod != 0)
    {
        while (1)
        {
            ret = ncDrv_CAN_PeliReceive(&msg);
            if (ret != NC_SUCCESS)
                continue;

            ncLib_SF_Control(GCMD_SF_WRITE_DATA, addr, &msg.data[0], mod,
                    CMD_END);
            break;
        }
    }

    cnt = img_size / data_len;
    addr = start_addr;

    while (cnt > 0)
    {
        ncLib_SF_Control(GCMD_SF_READ_DATA, addr, (UINT8 *)r_buf, data_len, CMD_END);
        for(i=0; i<8; i++)
        {
            dst_csum += r_buf[i];
        }
        addr += data_len;
        cnt--;
    }

    if(mod != 0)
    {
        ncLib_SF_Control(GCMD_SF_READ_DATA, addr, (UINT8 *) r_buf, mod, CMD_END);
        for (i = 0; i < mod; i++)
        {
            dst_csum += r_buf[i];
        }
    }


    if(src_csum != dst_csum)
    {
        ret = NC_FAILURE;
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "[CAN_BOOT] fail image download\n");
#endif
    }
    else
    {
        ret = NC_SUCCESS;
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "[CAN_BOOT] success image download");
#endif
    }
    return ret;

}


INT32 ncSrv_CAN_Boot(void)
{

    UINT32 ret = NC_SUCCESS;
    UINT32 cmd=0;
    UINT32 addr = 0;
    UINT32 size = 0;
    UINT32 check_sum=0;


    info.format = CAN_FI_STANDARD_FORMAT;
    info.baudrate = CAN_BPS_125KBPS;

    param.acrId = 0xFF;
    param.amrId = 0xFF;
    param.baudrate = info.baudrate;
    param.info = info;


    ncDrv_CAN_Initialize();
    ncDrv_CAN_PeliSetup(CAN_OSC_CLOCK, &param);

    cmd = 0xff;

    spi_quad_to_single();

    while (1)
    {
        while(1)
        {
            ret = ncDrv_CAN_PeliReceive(&msg);
            if (ret != NC_SUCCESS)
                continue;
            cmd = msg.data[0];
            if ((cmd >= CAN_CMD_BOOT) && (cmd <=CAN_CMD_CHECK_SUM))
                break;
        }

        switch (cmd)
        {
        case CAN_CMD_BOOT:
        {
            ret = NC_SUCCESS;
            goto CAN_MODE_EXIT;
        }
        break;

        case CAN_CMD_START_ADDR:
            addr = __ctoi(&msg.data[4]);
        break;

        case CAN_CMD_IMG_SIZE:
            size = __ctoi(&msg.data[4]);
        break;

        case CAN_CMD_FLASH_DOWN:
            if(size != 0)
                ncSrv_CAN_FlashDownload(size, addr, check_sum);
        break;

        case CAN_CMD_CHECK_SUM:
            check_sum = __ctoi(&msg.data[4]);
        break;

        }
    }


CAN_MODE_EXIT:

    ncDrv_CAN_Deinitialize();
    spi_single_to_quad();

    return ret;
}


#endif


/* End Of File */
