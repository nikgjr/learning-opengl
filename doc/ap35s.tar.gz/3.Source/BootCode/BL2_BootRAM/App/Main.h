/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.h
*
*  @brief   : This file is implemented about main of BL1_BootROM
*
*  @author  : alessio / SoCSW Platform Team
*
*  @date    : 2016.02.02
*
*  @version : Version 0.0.1
*
********************************************************************************
*  History  :
*
********************************************************************************
*/

#ifndef __MAIN_H__
#define __MAIN_H__


/*
********************************************************************************
*               INCLUDE FILES
********************************************************************************
*/

#include "Type.h"
#include "Apache35.h"

#include "Utility.h"

#include "DDR.h"
#include "SCU.h"

#include "Uart_Drv.h"
#include "SSP_Drv.h"

#include "sFlash_Svc.h"

#include "SSP_Lib.h"
#include "sFlash_Lib.h"


/*
********************************************************************************
*               DEFINITIONS
********************************************************************************
*/

/* APACHE3.5 Bootloader-BL2 Version */

#define BL2_VER_MAJOR               1
#define BL2_VER_MINOR1              0
#define BL2_VER_MINOR2              4

#define BL2_BUILD_DATE              __DATE__
#define BL2_BUILD_TIME              __TIME__

//#define __BL2_CPU192MHz_DDR096MHz__
#define __BL2_CPU108MHz_DDR108MHz__

#define __BL2_DDR_tREFI_HIGH_TEMP__

/* APACHE3.5 Simple Boot Option  */

#if 1   // Real Boot  & Post-Simulation
#define BL2_JTAG_BOOT_ENABLE            0   // test : JTAG Download SW Test
#define BOOT_DEBUG_STEP_PRINT_ENABLE    0   // test : Step value UART debug message enable
#define BOOT_DEBUG_PRINT_ENABLE         0   // test : Scenario test debug message enable
#define BL2_FAST_BOOT_ENABLE            0   // test : Fast Boot SW Test

#elif 0 // Real Boot Printf Boot
#define BL2_JTAG_BOOT_ENABLE            0   // test : JTAG Download SW Test
#define BOOT_DEBUG_STEP_PRINT_ENABLE    1   // test : Step value UART debug message enable
#define BOOT_DEBUG_PRINT_ENABLE         1   // test : Scenario test debug message enable
#define BL2_FAST_BOOT_ENABLE            0   // test : Fast Boot SW Test

#elif 0 // SW Test FPGA Full Printf Boot
#define BL2_JTAG_BOOT_ENABLE            1   // test : JTAG Download SW Test
#define BOOT_DEBUG_STEP_PRINT_ENABLE    1   // test : Step value UART debug message enable
#define BOOT_DEBUG_PRINT_ENABLE         1   // test : Scenario test debug message enable
#define BL2_FAST_BOOT_ENABLE            0   // test : Fast Boot SW Test

#elif 0  // Fast Boot  & Post-Simulation
#define BL2_JTAG_BOOT_ENABLE            0   // test : JTAG Download SW Test
#define BOOT_DEBUG_STEP_PRINT_ENABLE    0   // test : Step value UART debug message enable
#define BOOT_DEBUG_PRINT_ENABLE         0   // test : Scenario test debug message enable
#define BL2_FAST_BOOT_ENABLE            1   // test : Fast Boot SW Test

#endif


/* support CAN flash write */
#define BL2_CAN_BOOT_ENABLE             0   // test : can firmware download mode


/* APACHE3.5 SPI Option  */

#define SPI_CH                      SSP_CH0

#define SPI_SSP                     0
#define SPI_QSPI                    1
#define SPI_TYPE                    SPI_QSPI


/* APACHE3.5 LPDDR Option  */

#define LPDDR_ISSL                  0
#define LPDDR_WINBOND               1
#define LPDDR_TYPE                  LPDDR_WINBOND


/* APACHE3.5 UART Debugging Message Macro */

#define MSGERR                      (0x1<<0)    // Error message enable
#define MSGWARN                     (0x1<<1)    // Warning message enable
#define MSGINFO                     (0x1<<2)    // Information message enable
#define MSGON                       (0x1<<3)    // Force message enable

#define DEBUGMSG(zone, fmt, args...)  \
        do { if(zone) ncDrv_UART_printf(fmt, ## args); } while(0)


/* APACHE3.5 OSC Option  */

#define OSC_25MHZ                   25000000
#define OSC_27MHZ                   27000000
#define OSC_50MHZ                   50000000


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

enum
{
    BOOTSTRAP_BOOT_DOWNLOAD_MODE,
    BOOTSTRAP_BOOT_NORMAL_MODE,
};


enum
{
    BOOTSTRAP_BOOT_SIP_FLASH,
    BOOTSTRAP_BOOT_EXTERNAL_MODE,
};


typedef enum
{
    E_NOERROR = 0,

    E_ERROR_FLASH_MEMROY_INFO,

    E_ERROR_NORMAL_APP_HEADER,
    E_ERROR_NORMAL_APP_IMAGE,

    E_ERROR_BACKUP_APP_HEADER,
    E_ERROR_BACKUP_APP_IMAGE,

    NUM_OF_BL2_ERROR
} E_BL2_ERROR;  // BootLoader Error Number


typedef enum
{
    E_BACKUP_APP_HEADER,
    E_BACKUP_APP_IMAGE,

    NUM_OF_APP_BACKUP
} E_APP_BACKUP; // Application Error Number


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT32 mSignature;      // APP Header Signature
    UINT32 mRetryCount;     // APP Retry count
    UINT32 mAPPLength;      // APP Header + Image Total Length
    UINT32 mConfig;         // APP Configuration 
                            // [0] 0 : QSPI, 1 : SPI

    UINT32 mImgSrcAddr;     // APP Flash Memory Source Address
    UINT32 mImgDstAddr;     // APP System Memory Destination Address
    UINT32 mImgLength;      // APP Image Length
    UINT32 mImgCSum;        // APP Image Checksum
} stAPP_HEADER, *pstAPP_HEADER;

typedef struct
{
    UINT8 mNF;          // [5:0] PLL Multiplication Factor Value
    UINT8 mNR;          // [3:0] PLL Reference Divider Value
    UINT8 mOD;          // [3:0] PLL Post VCO Divider Value
    UINT8 mBWADJ;       // [5:0] PLL Bandwidth Adjust Divider Value

    UINT32 PLL0_Freq;   // PLL0 Output Frequency
    UINT32 PLL1_Freq;   // PLL1 Output Frequency
    UINT32 PLL2_Freq;   // PLL2 Output Frequency

    UINT32 CPU_Freq;
    UINT32 AXI_Freq;    // QSPI Frequency Used
    UINT32 APB_Freq;    // SSP, UART Frequency Used
    UINT32 DDR_Freq;    // DDR Frequency Used
    UINT32 CAN_Freq;    // CAN Frequency Used

} tPLLConfig, *ptPLLConfig;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

extern UINT32 gFlashCS;
extern tPLLConfig gtPllConfig;


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

void ncBL2_BOOT_DebugMessage(UINT8 nMsg);

INT32 ncBL2_sFlash_GetHeader(UINT32 nAddress);
INT32 ncBL2_sFlash_GetImage(UINT32 nAddress);

E_BL2_ERROR ncBL2_NormalBootMode(void);
E_BL2_ERROR ncBL2_BackupBootMode(E_APP_BACKUP nScenario);


#endif /* __MAIN_H__ */
