/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SSP_Lib.h
*
*  @brief   : This file is SSP controller API for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.01.19
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __SSP_LIB_H__
#define __SSP_LIB_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum _SSP_CMD
{
    /*
    * Generic SSP Commands
    */
    GCMD_SSP_INIT_CH = 0,
    GCMD_SSP_DEINIT_CH,
    GCMD_SSP_CS_ENABLE_CH,
    GCMD_SSP_CS_DISABLE_CH,
    GCMD_SSP_SET_BITRATE,
    GCMD_SSP_WAIT_BUSY,
    GCMD_SSP_MAX,

    /*
    * Specific Timer / Count Commands
    */
    SCMD_SSP_DUMMY = 100,
    SCMD_SSP_MAX,
} eSSP_CMD;


typedef enum _SSP_FMT
{
    SSP_FMT_SPI = 0,    /* Motorola SPI */
    SSP_FMT_SSP_TI,     /* Texas Instruments SSP */
    SSP_FMT_SSP_NS,     /* National Semiconductor Microwire */
    SSP_FMT_SSP_DSP,    /* Texas Instruments SSP like */
    SSP_FMT_I2S         /* Philips I2S */
} eSSP_FMT;

typedef enum _SSP_MODE
{
    SSP_MODE_MASTER = 0,    // Master Mode
    SSP_MODE_SLAVE          // TBD
} eSSP_MODE;

/* Clock Polarity for Motorola SPI or National Semiconductor Microwire */
typedef enum _SSP_SPO
{
    SSP_SPO_LOW = 0,        /* Clock will remain low when SSP is in the idle state */
    SSP_SPO_HIGH            /* Clock will remain high when SSP is in the idle state */
} eSSP_SPO;

/* Clock Phase for Motorola SPI or National Semiconductor Microwire */
typedef enum _SSP_SPH
{
    SSP_SPH_LOW = 0,        /* Catch data at falling edge */
    SSP_SPH_HIGH            /* Catch data at rising edge */
} eSSP_SPH;

/* Data Justify for Philips I2S */
typedef enum _SSP_JUSTIFY
{
    SSP_JUSTFY_LEFT = 0,    /* Valid data bit is left-justified */
    SSP_JUSTFY_RIGHT        /* Valid data bit is right-justified */
} eSSP_JUSTIFY;

/* Mono or Stereo Data for Philips I2S */
typedef enum _SSP_STEREO
{
    SSP_MONO = 0,           /* Mono Data */
    SSP_STEREO              /* Stereo Data */
} eSSP_STEREO;

/* Data width */
typedef enum _SSP_DS
{
    SSP_DS_4BIT = 3,
    SSP_DS_5BIT,
    SSP_DS_6BIT,
    SSP_DS_7BIT,
    SSP_DS_8BIT,
    SSP_DS_9BIT,
    SSP_DS_10BIT,
    SSP_DS_11BIT,
    SSP_DS_12BIT,
    SSP_DS_13BIT,
    SSP_DS_14BIT,
    SSP_DS_15BIT,
    SSP_DS_16BIT,
} eSSP_DS;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tSSP_INIT_PARAM
{
    eSSP_FMT    mFormat;        // frame format
    eSSP_MODE   mMode;          // master, slave
    eSSP_DS     mDataWidth;     // data width (4 ~ 16)
    UINT32      mBitRate;       // Mbps

    BOOL        mDmaMode;       // DMA mode
    BOOL        mTxIntEn;       // Enable Tx tnterrupt
    BOOL        mRxIntEn;       // Disable Rx interrupt

    /* for Motorola SPI or National Semiconductor Microwire */
    eSSP_SPO    mSPO;
    eSSP_SPH    mSPH;
} tSSP_INIT_PARAM, *ptSSP_INIT_PARAM;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32  ncLib_SSP_Open(UINT32 nInputClk);
extern INT32  ncLib_SSP_Close(void);
extern INT32  ncLib_SSP_Read(UINT32 nChNum, UINT8 *pBuf, UINT32 nLength);
extern INT32  ncLib_SSP_Write(UINT32 nChNum, UINT8 *pBuf, UINT32 nLength);
extern INT32  ncLib_SSP_Control(eSSP_CMD Cmd, ...);


#endif /* __SSP_LIB_H__ */
