/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : CAN_Drv.c
*
*  @brief   : Apache3 CAN2.0 module driver source file
*
*  @author  : alessio / TS Group / SoC SW Team
*
*  @date    : 2016.01.16
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*           INCLUDE
********************************************************************************
*/

#include "Main.h"


#if BL2_CAN_BOOT_ENABLE

#include "CAN_Drv.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

#define MSGERR                      (0x1<<0)    // Error message enable
#define MSGWARN                     (0x1<<1)    // Warning message enable
#define MSGINFO                     (0x1<<2)    // Information message enable
#define MSGON                       (0x1<<3)    // Force message enable

#define DEBUGMSG(zone, fmt, args...)  \
        do { if(zone) ncDrv_UART_printf(fmt, ## args); } while(0)

UINT32 Desired_BaudRate[MAX_OF_CAN_BPS]=
{
    10000,      // CAN_BPS_10KBPS 6.7km Class A max
    20000,      // CAN_BPS_20KBPS 3.3km Class B
    50000,      // CAN_BPS_50KBPS 1.3km Class B
    100000,     // CAN_BPS_100KBPS 620m Class B
    125000,     // CAN_BPS_125KBPS 530m Class B max
    250000,     // CAN_BPS_250KBPS 270m Class C
    500000,     // CAN_BPS_500KBPS 130m Class C
    800000,     // CAN_BPS_800KBPS 80m Class C
    1000000,    // CAN_BPS_1000KBPS 40m Class C max
};


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

long long int llround(double x);


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

volatile REG_CAN_RX_SFF *gp_RegCanRxSFF;
volatile REG_CAN_TX_SFF *gp_RegCanTxSFF;

volatile REG_CAN_RX_EFF *gp_RegCanRxEFF;
volatile REG_CAN_TX_EFF *gp_RegCanTxEFF;
volatile REG_CAN_ACCEPTANCE *gp_RegCanAcceptance;

UINT8 gCanRxMsgBoxWrCnt = 0;
UINT8 gCanRxMsgBoxRdCnt = 0;
tCAN_MSG gp_CanRxMsgBox[CAN_MESSAGE_NUM_MAX];


/*
* For User Handler
*/
PrVoid ncDrv_CAN_UserHandler = NULL;

eCAN_CH_INTR gCanInterruptDone;

tCAN_INFO gCanInfo;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/



UINT32 __round(FP32 F)
{
    FP32   X;
    UINT32 Y;

    X = F;
    Y = (UINT32)F;

    X = X - (FP32)Y;

    if(X != 0.0) X = 1.0;

    X += F;

    return (UINT32)X;
}



UINT32 ncDrv_CAN_BaseAddr(void)
{
    UINT32 base_addr;

    base_addr = rCAN_0_BASE;
    return base_addr;
}


void ncDrv_CAN_Initialize(void)
{
    UINT32 base_addr;

    base_addr = rCAN_0_BASE;
    gCanInterruptDone = CAN_NONE;

    // PeliCAN, CAN2.0B Operation mode case ...
    gp_RegCanRxSFF = (volatile REG_CAN_RX_SFF *)(base_addr+rCANP_FIR);
    gp_RegCanTxSFF = (volatile REG_CAN_TX_SFF *)(base_addr+rCANP_FIR);
    gp_RegCanRxEFF = (volatile REG_CAN_RX_EFF *)(base_addr+rCANP_FIR);
    gp_RegCanTxEFF = (volatile REG_CAN_TX_EFF *)(base_addr+rCANP_FIR);

    // PeliCAN, CAN2.0B Reset mode case ...
    gp_RegCanAcceptance = (volatile REG_CAN_ACCEPTANCE *)(base_addr+rCANP_ACR);

    // CAN information message box clear ...
    gCanRxMsgBoxWrCnt = 0;
    gCanRxMsgBoxRdCnt = 0;

    //yonghwi.lee check this code...
    memset(gp_CanRxMsgBox, 0, sizeof(tCAN_MSG)*CAN_MESSAGE_NUM_MAX);
}


void ncDrv_CAN_Deinitialize(void)
{
    REGRW32(ncDrv_CAN_BaseAddr(), 0x10) = 0x00;  // Interrupt Enable All Disable
    REGRW32(ncDrv_CAN_BaseAddr(), 0x04) = 0x0C; // Command Clear Data Overrun, Release Receive Buffer
    REGRW32(ncDrv_CAN_BaseAddr(), 0x00) = 0x01;  // Mode Reset

    // PeliCAN, CAN2.0B Operation mode case ...
    gp_RegCanRxSFF = NULL;
    gp_RegCanTxSFF = NULL;
    gp_RegCanRxEFF = NULL;
    gp_RegCanTxEFF = NULL;

    // PeliCAN, CAN2.0B Reset mode case ...
    gp_RegCanAcceptance = NULL;
}


void ncDrv_CAN_IRQ_Handler(UINT32 nIrqNum)
{
    /*
    * Default ISR Routine
    */

    ncDrv_CAN_ISR_Handler();

    /*
    * User Handler Call Back Function
    */
    if(ncDrv_CAN_UserHandler != NULL)
    {
        ncDrv_CAN_UserHandler();
    }
}


void ncDrv_CAN_ISR_Handler(void)
{
    UINT8 mode;

    mode = ncDrv_CAN_GetCanMode();
    ncDrv_CAN_ISRPeliCANHandler();
    //gCanInterruptDone[channel] = CAN_DONE;
}


INT32 ncDrv_CAN_ConnectUserHandler(PrVoid UserHandler)
{
    INT32 ret = NC_SUCCESS;

    ncDrv_CAN_UserHandler = (PrVoid) UserHandler;
    return ret;
}


INT32 ncDrv_CAN_DisConnectUserHandler(void)
{
    INT32 ret = NC_SUCCESS;

    ncDrv_CAN_UserHandler = (PrVoid) NULL;
    return ret;
}


BOOL ncDrv_CAN_GetInterruptDone(void)
{
    if(gCanInterruptDone == CAN_DONE)
    {
        gCanInterruptDone = CAN_NONE;
        return (BOOL)CAN_DONE;
    }

    return (BOOL)CAN_NONE;
}


int ncDrv_CAN_SetRxMsgBoxIndex(void)
{
    if(gCanRxMsgBoxWrCnt >= CAN_MESSAGE_NUM_MAX)
    {
        gCanRxMsgBoxWrCnt = 0;
    }

    //DEBUGMSG_SDK(MSGINFO, "Rx-msg Wr%d\n", gCanRxMsgBoxWrCnt);
    gp_CanRxMsgBox[gCanRxMsgBoxWrCnt].objch = CAN_MSGOBJ_ACTIVE;

    return gCanRxMsgBoxWrCnt++;
}


int ncDrv_CAN_GetRxMsgBoxIndex(void)
{
    //DEBUGMSG_SDK(MSGINFO, "Rx-msg Rd%d\n", gCanRxMsgBoxRdCnt);
    return gCanRxMsgBoxRdCnt;
}


void ncDrv_CAN_ClearRxMsgBoxIndex(void)
{
	gp_CanRxMsgBox[gCanRxMsgBoxRdCnt].objch = CAN_MSGOBJ_RESERVED;

    gCanRxMsgBoxRdCnt++;
    if(gCanRxMsgBoxRdCnt >= CAN_MESSAGE_NUM_MAX)
    {
        gCanRxMsgBoxRdCnt = 0;
    }
}


UINT8 ncDrv_CAN_GetErrorStatus(void)
{
    return (REGRW32(ncDrv_CAN_BaseAddr(), rCANB_SR) & 0xFF);
}


UINT8 ncDrv_CAN_GetIntrruptStatus(void)
{
    return (REGRW32(ncDrv_CAN_BaseAddr(), rCANB_IR) & 0xFF);
}


UINT8 ncDrv_CAN_GetCanMode(void)
{
    return (REGRW32(ncDrv_CAN_BaseAddr(), rCANB_CDR) >> CAN_CDR_MODE_SHIFT) & 0x1;
}


void ncDrv_CAN_SetCanMode(void)
{
    REGRW32(ncDrv_CAN_BaseAddr(), rCANB_CDR) = (CAN_CDR_PELI_MODE << CAN_CDR_MODE_SHIFT);
}


void ncDrv_CAN_SetBusTimingBaudrate_kvaser(UINT32 inputclk, eCAN_KBPS index)
{
    /*
    UINT32 i;
    UINT32 btr0, btr1;
    float tmp, tmp2, err, abs_err;
    float presc, btq, t1, t2, sjw;
    UINT32 maxPrescaler;
    float clock, bitrate;
    float tolerance;
    UINT32 matches, exactMatches;

#if CAN_BUS_TIMING_CALC_MESSAGE
    DEBUGMSG(MSGINFO, "CAN Bus Timing Results\n");
#endif

    clock = (float)inputclk;
    bitrate = (float)Desired_BaudRate[index];

    tmp = clock / bitrate / 2.0;

    for(i = 0; i < 3; i++)
    {
        btr0 = 0;
        btr1 = 0;

        matches = 0;
        exactMatches = 0;
        maxPrescaler = 64;

        if(i == 0) tolerance = 0.0;
        else if(i == 1) tolerance = 0.005;
        else tolerance = 0.015;

#if CAN_BUS_TIMING_CALC_MESSAGE
        DEBUGMSG(MSGINFO, "\n\n");
        DEBUGMSG(MSGINFO, "The following bus parameters are allowed, assuming\n");
        DEBUGMSG(MSGINFO, "your CAN controller is clocked with %f MHz. \n", clock/1000000.0);
        DEBUGMSG(MSGINFO, "you want a CAN bus bit rate of %f kbps. \n", bitrate/1000.0);
        //DEBUGMSG_SDK(MSGINFO, "settings leading to speed deviations of more than %1.1f%% are discarded. \n", llround(tolerance*1000)/10);
        DEBUGMSG(MSGINFO, "settings leading to speed deviations of more than %1.1f%% are discarded. \n", (tolerance*1000)/10);

        DEBUGMSG(MSGINFO, "-------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, "t1  |t2  |btq  |sp%%    |sjw  |bit Rate  |Err%%  |BTR0  |BTR1\n");
        DEBUGMSG(MSGINFO, "-------------------------------------------------------------\n");
#endif

        for(presc = 1.0; presc <= (float)maxPrescaler; presc++)
        {
            tmp2 = tmp / presc;

            btq = llround(tmp2);

            if(btq >= 4.0 && btq <= 32.0)
            {
                err = - (tmp2 / btq - 1.0);

                err = llround(err * 10000.0) / 10000.0;

                abs_err = fabs(err);

                //if(fabs(err) > tolerance) continue;
                if((float)abs_err > (float)tolerance) continue;

                for(t1 = 3.0; t1 < 18.0; t1++)
                {
                    t2 = btq - t1;

                    if((t1 < t2) || (t2 > 8.0) || (t2 < 2.0)) continue;

                    for(sjw = 1.0; sjw <= 4.0; sjw++)
                    {
                        btr0 = (UINT8)((presc-1.0) + (sjw-1.0) * 64.0);
                        btr1 = (UINT8)((t1-2.0) + (t2-1.0) * 16.0);

#if CAN_BUS_TIMING_CALC_MESSAGE
                        DEBUGMSG(MSGINFO, "%02d  |", (UINT8)t1);
                        DEBUGMSG(MSGINFO, "%02d  |", (UINT8)t2);
                        DEBUGMSG(MSGINFO, "%02d   |", (UINT8)btq);
                        DEBUGMSG(MSGINFO, "%02.02f  |", llround(t1 / btq * 10000.0)/100.0);
                        DEBUGMSG(MSGINFO, "%d    |", (UINT8)sjw);
                        DEBUGMSG(MSGINFO, "%03.03f   |", llround(bitrate*(1.0-err))/1000.0);
                        DEBUGMSG(MSGINFO, "%.02f  |", llround(-err*10000.0)/100.0);
                        DEBUGMSG(MSGINFO, "0x%02X  |", btr0);
                        DEBUGMSG(MSGINFO, "0x%02X\n", btr1);
#endif

                        matches++;

                        if(err == 0.0) exactMatches++;
                        if((err == 0.0) || (err < 0.0)) goto Calc_Exit;
                    }
                }
            }
        }

Calc_Exit:

#if CAN_BUS_TIMING_CALC_MESSAGE
        DEBUGMSG(MSGINFO, "-------------------------------------------------------------\n");
#endif

        if(matches == 0)
        {
            //+ DEBUGMSG_SDK(MSGERR, "Error : The desired CAN bus speed is not possible with ");
            //+ DEBUGMSG_SDK(MSGERR, "the specified CAN clock frequency and tolerance.\n");
        }
        else if(exactMatches == 0)
        {
            // Set bus timing register 0
            REGRW32(ncDrv_CAN_BaseAddr(), rCANB_BTR0) = btr0;

            // Set bus timing register 1
            REGRW32(ncDrv_CAN_BaseAddr(), rCANB_BTR1) = btr1;

            //+ DEBUGMSG_SDK(MSGWARN, "Warning : You can\'t get exactly the desired CAN bus speed with ");
            //+ DEBUGMSG_SDK(MSGWARN, "the specified CAN clock frequency. Be sure to check the Err%% column.\n");
            break;
        }
        else
        {
            // Set bus timing register 0
            REGRW32(ncDrv_CAN_BaseAddr(), rCANB_BTR0) = btr0;

            // Set bus timing register 1
            REGRW32(ncDrv_CAN_BaseAddr(), rCANB_BTR1) = btr1;

#if CAN_BUS_TIMING_CALC_MESSAGE
            DEBUGMSG(MSGINFO, "Success : CAN bus timing calculation success\n");
#endif
            break;
        }
    }
*/
    REGRW32(ncDrv_CAN_BaseAddr(), rCANB_BTR0) = 0x3;

                // Set bus timing register 1
    REGRW32(ncDrv_CAN_BaseAddr(), rCANB_BTR1) = 0x76;

}


void ncDrv_CAN_SetAcceptanceFilter(UINT8 format, UINT32 code, UINT32 mask)
{
    //UINT8 i;
    //eCAN_FI_FRAME format = CAN_FI_STANDARD_FORMAT;

    /*
     * SJA1000 AN97076 datasheet page 18, 19 Example 1 case
     */

    //+ DEBUGMSG_SDK(MSGINFO, "Acceptance filter code = 0x%08X, mask = 0x%08X\n", code, mask);
    if (format == CAN_FI_STANDARD_FORMAT) {
        gp_RegCanAcceptance->ACR[0] = (code >> 3) & 0xFF;
        gp_RegCanAcceptance->ACR[1] = (code << 5) & 0xE0;
        gp_RegCanAcceptance->ACR[2] = 0xFF;
        gp_RegCanAcceptance->ACR[3] = 0xFF;

        gp_RegCanAcceptance->AMR[0] = (mask >> 3) & 0xFF;
        gp_RegCanAcceptance->AMR[1] = (mask << 5) & 0xE0;
        gp_RegCanAcceptance->AMR[2] = 0xFF;
        gp_RegCanAcceptance->AMR[3] = 0xFF;

        gp_RegCanAcceptance->ACR[1] |= 0x10;   // RTR
        gp_RegCanAcceptance->AMR[1] |= 0x10;   // RTR
    }
    else // CAN_FI_EXTENDED_FORMAT
    {
        gp_RegCanAcceptance->ACR[0] = (code >> 21) & 0xFF;
        gp_RegCanAcceptance->ACR[1] = (code >> 13) & 0xFF;
        gp_RegCanAcceptance->ACR[2] = (code >> 5) & 0xFF;
        gp_RegCanAcceptance->ACR[3] = (code << 3) & 0xFF;

        gp_RegCanAcceptance->AMR[0] = (mask >> 21) & 0xFF;
        gp_RegCanAcceptance->AMR[1] = (mask >> 13) & 0xFF;
        gp_RegCanAcceptance->AMR[2] = (mask >> 5) & 0xFF;
        gp_RegCanAcceptance->AMR[3] = (mask << 3) & 0xFF;

        gp_RegCanAcceptance->ACR[3] |= 0x04;   // RTR
        gp_RegCanAcceptance->AMR[3] |= 0x04;   // RTR
    }

}


int ncDrv_CAN_SendComplete(void)
{
    UINT32 wait = 0;
    UINT32 status;
    int Result = NC_SUCCESS;

    while(1)
    {
        wait++;
        status = REGRW32(ncDrv_CAN_BaseAddr(), rCANB_SR);

        if(wait > 100000) // �뷫, 5mS �ȿ� �����ؾ���.
        {
            //+ DEBUGMSG_SDK(MSGERR, "Error, Send Timeout 0x%02X\n", status);
            Result = NC_FAILURE;
            break;
        }

        if(status & CAN_SR_BS)  // bus off error
        {
            //+ DEBUGMSG_SDK(MSGERR, "Error, Send Bus off 0x%02X\n", status);
            Result = NC_FAILURE;
            break;
        }

        if(status & CAN_SR_ES)  // error
        {
            //+ DEBUGMSG_SDK(MSGERR, "Error, Send Abort Transmission 0x%02X\n", status);
            REGRW32(ncDrv_CAN_BaseAddr(), rCANB_CMR) = CAN_CMR_AT;
            Result = NC_FAILURE;
            break;
        }

        if(status & CAN_SR_DOS) // data overrun error
        {
            //+ DEBUGMSG_SDK(MSGERR, "Error, Send data overrun 0x%02X\n", status);
            REGRW32(ncDrv_CAN_BaseAddr(), rCANB_CMR) |= CAN_CMR_CDO;
            Result = NC_FAILURE;
        }

        if(status & CAN_SR_TCS) // data transmit complete
        {
            //DEBUGMSG_SDK(MSGERR, "Ok, Send data transmit complete 0x%02X\n", status);
            Result = NC_SUCCESS;
            break;
        }
    }

    return Result;
}


#endif


/* End Of File */
