/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.c
*
*  @brief   : This file is implemented about main of BL2_BootRAM
*
*  @author  : alessio / TS Group. SoCSW Team
*
*  @date    : 2016.02.02
*
*  @version : Version 0.0.1
*
********************************************************************************
*  History  :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "Main.h"

#if BL2_CAN_BOOT_ENABLE
#include "CAN_Boot.h"
#endif


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define FLASH_PAGE_SIZE             256

/* Flash Memory Map Address */

#define BACKUP_APP_DATA_AREA        0x001A5100  // fixed address
#define BACKUP_APP_HEADER_AREA      0x001A5000  // fixed address

#define NORMAL_APP_DATA_AREA        0x00008100  // fixed address
#define NORMAL_APP_HEADER_AREA      0x00008000  // fixed address


/* Flash Memory APP Header Define */

#define APP_SIGNATURE_ID            0x35335041  // "53PA"
#define APP_IMAGE_LENGTH_MAX        (332*1024)
#define APP_IMAGE_BASE_ADDRESS      0x08000000  // fixed address

#define LPDDR_BASE_ADDRESS          APP_IMAGE_BASE_ADDRESS


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

const UINT32 caPLLClock[16]=
{
    // PLL0,    PLL1,      PLL2
    192000000, 297000000,  16000000, OSC_27MHZ,
    216000000, 297000000,  16000000, OSC_27MHZ,
    297000000, 297000000,  16000000, OSC_27MHZ,
    297000000, 297000000,  16000000, OSC_27MHZ
};


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

typedef struct
{
    UINT8 mMode;        // 0 : Download Mode, 1 : Normal Boot Mode
    UINT8 mFlashCS;     // 0 : SiP Flash CS,  1 : External Flash CS
    UINT8 mPLLConfig;   // PLL Configuration
    UINT8 Reserved;
} tBootStrap, *ptBootStrap;

typedef struct _tSUC_CLK
{
    UINT32 mCPU;
    UINT32 mAXI;
    UINT32 mAPB;
    UINT32 mCAN;
    UINT32 mDDR;

    UINT32 mADC;
    UINT32 mTS;
} tSCU_CLK, *ptSCU_CLK;


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

static tREG_UART *prPUart = (tREG_UART *)UART0;

tBootStrap gtBStrap;
tPLLConfig gtPllConfig;

stAPP_HEADER stAPPHD;

UINT32 gBootMode = 0;
UINT32 gFlashCS = 0;
UINT32 gDDRMemoryType = LPDDR_WINBOND;

UINT32 gCPUClock = 0;
UINT32 gAXIClock = 0;
UINT32 gAPBClock = 0;
UINT32 gDDRClock = 0;
UINT32 gCANClock = 0;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

void ncBL2_SystemInitialize(void);
void ncBL2_GetBootStrap(void);
void ncBL2_UART_Initialize(void);
void ncBL2_DDRC_Initialize(void);
void ncBL2_QSPI_Initialize(void);
void ncBL2_QSPI_Deinitialize(void);


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncBL2_SystemInitialize(void)
{
    ncBL2_GetBootStrap();
    ncBL2_UART_Initialize();
    ncBL2_QSPI_Initialize();
    ncBL2_DDRC_Initialize();
}


void ncBL2_GetBootStrap(void)
{
    UINT32 nBootStrap;
    UINT32 nTemp, nDiv_xx;
    UINT32 nPLLConfig, nSystemClock, nCANClock;


#if BL2_JTAG_BOOT_ENABLE
    // Software Reset Control Register
    //REGRW32(SYS_CON_BASE, 0x0000) = 0xFFFFFFF0; // DDR Reset Disable [20bit]
    //SysDelay(10);
    REGRW32(SYS_CON_BASE, 0x0000) = 0x00000000;
    SysDelay(10);

    // Clock Enable Register
    REGRW32(SYS_CON_BASE, 0x0004) = 0x0031FFFF;
    SysDelay(10);

    //mMode = BOOTSTRAP_BOOT_NORMAL_MODE;
    //mMode = BOOTSTRAP_BOOT_DOWNLOAD_MODE;
    //mFlashCS = BOOTSTRAP_BOOT_SIP_FLASH;
    //mFlashCS = BOOTSTRAP_BOOT_EXTERNAL_MODE;
    nBootStrap = ((BOOTSTRAP_BOOT_NORMAL_MODE<<3) | (BOOTSTRAP_BOOT_SIP_FLASH<<2) | (0<<0));
#else
    nBootStrap = REGRW32(SYS_CON_BASE, SCU_STRAP) & 0xC;

#if defined (__BL2_CPU192MHz_DDR096MHz__)
    nBootStrap |= 0;
#elif defined (__BL2_CPU108MHz_DDR108MHz__)
    nBootStrap |= 1;
#else
    nBootStrap |= 2;
#endif

#endif

    // Boot Mode Select
    gtBStrap.mMode      = (nBootStrap >> 3) & 0x1;
    gtBStrap.mFlashCS   = (nBootStrap >> 2) & 0x1;
    gtBStrap.mPLLConfig = (nBootStrap & 0x3);

    __BL2_PLL_SetConfig(gtBStrap.mPLLConfig);

    nPLLConfig = gtBStrap.mPLLConfig;

    nTemp = (REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_SEL) & 0x3);
    nSystemClock = caPLLClock[(nPLLConfig*4)+nTemp];

    nTemp = (REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_SEL) >> SEL_CAN_CLK) & 0x3;
    nCANClock = caPLLClock[(nPLLConfig*4)+nTemp];

    /*
     * Get clock (ADC, CAN, DDR, APB, AXI, CPU, TS)
     * */

    nTemp = REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV1);

    nDiv_xx = ((nTemp >> DIV_CPU_CLK) & 0x3);
    gtPllConfig.CPU_Freq = (nSystemClock / (1<<nDiv_xx));

    nDiv_xx = ((nTemp >> DIV_AXI_CLK) & 0x3);
    gtPllConfig.AXI_Freq = (nSystemClock / (1<<nDiv_xx));

    nDiv_xx = ((nTemp >> DIV_APB_CLK) & 0x3);
    gtPllConfig.APB_Freq = (nSystemClock / (1<<nDiv_xx));

    nDiv_xx = ((nTemp >> DIV_DDR_CLK) & 0x3);
    gtPllConfig.DDR_Freq = (nSystemClock / (2<<nDiv_xx));

    nDiv_xx = ((nTemp >> DIV_CAN_CLK) & 0x1F);
    gtPllConfig.CAN_Freq = (nCANClock / (nDiv_xx + 1));

#if BL2_JTAG_BOOT_ENABLE // test
    gCPUClock = gtPllConfig.CPU_Freq;
    gAXIClock = gtPllConfig.AXI_Freq;
    gAPBClock = OSC_25MHZ;  // gtPllConfig.APB_Freq
    gDDRClock = OSC_50MHZ;  // gtPllConfig.DDR_Freq
    gCANClock = gtPllConfig.CAN_Freq;
#else
    gCPUClock = gtPllConfig.CPU_Freq;
    gAXIClock = gtPllConfig.AXI_Freq;
    gAPBClock = gtPllConfig.APB_Freq;
    gDDRClock = gtPllConfig.DDR_Freq;
    gCANClock = gtPllConfig.CAN_Freq;
#endif

    gDDRMemoryType = LPDDR_WINBOND;    // LPDDR_ISSL, LPDDR_WINBOND
}


void ncBL2_UART_Initialize(void)
{
#if (BOOT_DEBUG_PRINT_ENABLE || BOOT_DEBUG_STEP_PRINT_ENABLE)
    tUART_PARAM param;

    param.uartClk = gAPBClock;
    param.baudRate = 115200;
    param.sps = LCR_SPS_DIS;
    param.wlen = LCR_WLEN_8BIT;
    param.fen = LCR_FIFO_EN;
    param.stp2 = LCR_STP2_DIS;
    param.eps = LCR_EPS_DIS;
    param.pen = LCR_PARITY_DIS;
    param.brk = 0;

    // PinMux UART Select ...
    __BL2_UART_PinMux(UART_CH0);

    ncDrv_UART_Initialize(prPUart, &param);

#if BOOT_DEBUG_PRINT_ENABLE
    DEBUGMSG(MSGINFO, "\n\n");
    DEBUGMSG(MSGINFO, "=======================================================\n");
    DEBUGMSG(MSGINFO, "BL2 Version: [V%d.%d.%d] [%s, %s]\n",
                    BL2_VER_MAJOR, BL2_VER_MINOR1, BL2_VER_MINOR2, BL2_BUILD_DATE, BL2_BUILD_TIME);
    DEBUGMSG(MSGINFO, "=======================================================\n");
    DEBUGMSG(MSGINFO, "SYSCON_REMAP_ENABLE = %d\n", REGRW32(SYS_CON_BASE, SYSCON_REMAP_ENABLE));
    DEBUGMSG(MSGINFO, "BootStrap Mode = %d\n", gtBStrap.mMode);
    DEBUGMSG(MSGINFO, "BootStrap FlashCS = %d\n", gtBStrap.mFlashCS);
    DEBUGMSG(MSGINFO, "BootStrap PLLConfig = %d\n", gtBStrap.mPLLConfig);
    DEBUGMSG(MSGINFO, "=======================================================\n");
    DEBUGMSG(MSGINFO, "CPU = %8d, AXI = %8d, APB = %8d, DDR = %8d\n", gCPUClock, gAXIClock, gAPBClock, gDDRClock);
    DEBUGMSG(MSGINFO, "=======================================================\n");
    DEBUGMSG(MSGINFO, "\n");
#endif
#endif

    REGRW32(SYS_CON_BASE, SCU_DEBUG_BL_VER) = ('v'<<24) | (BL2_VER_MAJOR<<16) | (BL2_VER_MINOR1<<8) | BL2_VER_MINOR2;
}


void ncBL2_QSPI_Initialize(void)
{
    UINT8 nChNum = SPI_CH;
    tSF_INIT_PARAM tsFlashParam;

    ncLib_SF_Open(gAPBClock);

    tsFlashParam.mChNum    = nChNum;
    tsFlashParam.mDmaMode  = FALSE;
    tsFlashParam.mQuadMode = SPI_TYPE;
    tsFlashParam.mBitRate  = SF_BITRATE_5Mbps;

    gFlashCS = gtBStrap.mFlashCS;

    __BL2_SSP_PinMux(nChNum, gtBStrap.mFlashCS);

    ncLib_SF_Control(GCMD_SF_INIT, &tsFlashParam, CMD_END);

    // #define rQSPI_EXT_ADDR 0x005C
    if(gFlashCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        REGRW32(APACHE_QSPI_BASE, 0x005C) = 0xFFFFFF;
    }
    else // BOOTSTRAP_BOOT_EXTERNAL_MODE
    {
        REGRW32(APACHE_QSPI_BASE, 0x005C) = 0x0;
    }

    __BL2_QSPI_PinMux(nChNum, gtBStrap.mFlashCS);
}


void ncBL2_DDRC_Initialize(void)
{
    //INT32 ret = NC_SUCCESS;

    ncDrv_DDRC_Initialize(gDDRClock, gDDRMemoryType);
}


void ncBL2_QSPI_Deinitialize(void)
{
    ncLib_SF_Control(GCMD_SF_DEINIT, CMD_END);
    ncLib_SF_Close();

    __BL2_QSPI_PinMuxRelease(gtBStrap.mFlashCS);
}


void ncBL2_BOOT_DebugMessage(UINT8 nMsg)
{
#if BOOT_DEBUG_STEP_PRINT_ENABLE
    DEBUGMSG(MSGINFO, "%c", nMsg);
#endif
    REGRW32(SYS_CON_BASE, SCU_DEBUG_STEP) = nMsg;
}


UINT32 ncBL2_CheckBootMode(void)
{
    /*
     *  0 : Download Mode, 1 : Normal Mode
     */

    if(gtBStrap.mMode & BOOTSTRAP_BOOT_NORMAL_MODE)
    {
        return BOOTSTRAP_BOOT_NORMAL_MODE;
    }
    else
    {
        return BOOTSTRAP_BOOT_DOWNLOAD_MODE;
    }
}


void ncBL2_SetSystemRemap(void)
{
    UINT32 nTemp, i;
    PrVoid PC_CountReset = (PrVoid)NULL;

    REGRW32(SYS_CON_BASE, SYSCON_REMAP_START)  = 0x00000000;
    REGRW32(SYS_CON_BASE, SYSCON_REMAP_END)    = LPDDR_BASE_ADDRESS;
    REGRW32(SYS_CON_BASE, SYSCON_REMAP_ENABLE) = 1;

#if 1 // v0.9.3 add
    while(1)
    {
        for(i = 0; i < 5; i++)
        {
            nTemp = REGRW32(SYS_CON_BASE, SYSCON_REMAP_ENABLE);
        }

        if(nTemp)
        {
            PC_CountReset();
        }
    }
#else
    PC_CountReset();
#endif
}


INT32 main(void)
{
    UINT32 nErrFlag = 0;
    E_BL2_ERROR nErrStatus;
    INT32 ret = NC_SUCCESS;

    gBootMode = 0;

    __EXIT_CRITICAL_SECTION();

    REGRW32(SYS_CON_BASE, SCU_DEBUG_STEP) = '0';

    ncBL2_SystemInitialize();

#if BL2_FAST_BOOT_ENABLE
    ncBL2_SetSystemRemap();
#endif

#if BL2_CAN_BOOT_ENABLE
    ncSrv_CAN_Boot();
#endif

    ncBL2_BOOT_DebugMessage('\n');
    ncBL2_BOOT_DebugMessage('B');
    ncBL2_BOOT_DebugMessage('L');
    ncBL2_BOOT_DebugMessage('2');
    ncBL2_BOOT_DebugMessage(' ');

    ncBL2_BOOT_DebugMessage('1');

    gBootMode = ncBL2_CheckBootMode();


    /*
     Boot Strap Normal or Download select ...
     */

    if(gBootMode == BOOTSTRAP_BOOT_NORMAL_MODE)
    {
        nErrFlag = '2';
        ncBL2_BOOT_DebugMessage('2');

        nErrStatus = ncBL2_NormalBootMode();

        if(nErrStatus == E_ERROR_NORMAL_APP_HEADER)
        {
            nErrFlag = '3';
            ncBL2_BOOT_DebugMessage('3');

            nErrStatus = ncBL2_BackupBootMode(E_BACKUP_APP_HEADER);
        }
        else if(nErrStatus == E_ERROR_NORMAL_APP_IMAGE)
        {
            nErrFlag = '4';
            ncBL2_BOOT_DebugMessage('4');

            nErrStatus = ncBL2_BackupBootMode(E_BACKUP_APP_IMAGE);
            //nErrStatus = ncBL2_BackupBootMode(E_BACKUP_APP_HEADER); // 20160817 v1.0.0 : checksum fail bug modification
        }


        /*
         Boot Sequence Result ...
         */

        ncBL2_BOOT_DebugMessage('5');

        ncBL2_QSPI_Deinitialize();

        if(nErrStatus == E_NOERROR)
        {
            ncBL2_BOOT_DebugMessage('6');
#if BOOT_DEBUG_PRINT_ENABLE
            DEBUGMSG(MSGINFO, "\nBOOT_SUCCESS\n");
#endif
            REGRW32(SYS_CON_BASE, SCU_DEBUG_RESULT) = ((nErrFlag<<16) | ('O'<<8) | ('K'<<0));
            ncBL2_SetSystemRemap();
        }
        else
        {
            ncBL2_BOOT_DebugMessage('7');
#if BOOT_DEBUG_PRINT_ENABLE
            DEBUGMSG(MSGINFO, "\nBOOT_ERROR\n");
#endif
            REGRW32(SYS_CON_BASE, SCU_DEBUG_RESULT) = ((nErrFlag<<16) | ('N'<<8) | ('G'<<0));
        }
    }
    else
    {
        ncBL2_BOOT_DebugMessage('8');

        ncBL2_QSPI_Deinitialize();

        ncBL2_BOOT_DebugMessage('9');
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "\nBOOT_DN\n");
#endif
        REGRW32(SYS_CON_BASE, SCU_DEBUG_RESULT) = ('D'<<8) | ('N'<<0);
    }

    return ret;
}


INT32 ncBL2_sFlash_GetHeader(UINT32 nAddress)
{
    UINT32 i;
    UINT8 pBuffer[FLASH_PAGE_SIZE] __attribute__ ((aligned (8)));   // [QSPI] Important align;
    INT32 ret = NC_SUCCESS;

    ncLib_SF_Control(GCMD_SF_READ_DATA, nAddress, (UINT8 *)pBuffer, SF_PAGE_SIZE, CMD_END);

    stAPPHD.mSignature  = CharToInt(&pBuffer[0]);   // APP Header Signature("AP35")
    stAPPHD.mRetryCount = CharToInt(&pBuffer[4]);   // APP Retry count
    stAPPHD.mAPPLength  = CharToInt(&pBuffer[8]);   // APP Header + Image Total Length
    stAPPHD.mConfig     = CharToInt(&pBuffer[12]);  // APP Configuration

    stAPPHD.mImgSrcAddr = CharToInt(&pBuffer[16]);  // APP Image Source Address
    stAPPHD.mImgDstAddr = CharToInt(&pBuffer[20]);  // APP Image Destination Address
    stAPPHD.mImgLength  = CharToInt(&pBuffer[24]);  // APP Image Length
    //stAPPHD.mImgCSum    = CharToInt(&pBuffer[28]) & 0xFFFF;  // APP Image Checksum
    stAPPHD.mImgCSum    = CharToInt(&pBuffer[28]);  // APP Image Checksum


#if BOOT_DEBUG_PRINT_ENABLE
    if(nAddress == NORMAL_APP_HEADER_AREA)
    {
        DEBUGMSG(MSGINFO, "\n2.Flash Memory Normal APP Header Information ...\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, "\n2.Flash Memory Backup APP Header Information ...\n");
    }

    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, ">> Flash Address = 0x%8x", nAddress);

    for(i = 0; i < 32; i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%x : ", (i>>24)&0xFF, (i>>16)&0xFF, (i>>8)&0xFF, i&0xFF);
        DEBUGMSG(MSGINFO, "%x ", pBuffer[i]);
    }

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "\n");

    DEBUGMSG(MSGINFO, "APP Signature     = %c%c%c%c\n",   pBuffer[0], pBuffer[1], pBuffer[2], pBuffer[3]);
    DEBUGMSG(MSGINFO, "APP RetryCount    = 0x%8x\n", stAPPHD.mRetryCount);
    DEBUGMSG(MSGINFO, "APP Header Length = 0x%8x\n", stAPPHD.mAPPLength);
    DEBUGMSG(MSGINFO, "APP Configuration = 0x%8x\n", stAPPHD.mConfig);

    DEBUGMSG(MSGINFO, "APP Image SrcAddr = 0x%8x\n", stAPPHD.mImgSrcAddr);
    DEBUGMSG(MSGINFO, "APP Image DstAddr = 0x%8x\n", stAPPHD.mImgDstAddr);
    DEBUGMSG(MSGINFO, "APP Image Length  = 0x%8x\n", stAPPHD.mImgLength);
    DEBUGMSG(MSGINFO, "APP Image CSum    = 0x%8x\n", stAPPHD.mImgCSum);
    DEBUGMSG(MSGINFO, "\n");
#endif

    if(stAPPHD.mSignature != APP_SIGNATURE_ID)
    {
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, Flash Memory APP Header Signature id Failure\n");
#endif
        ret = NC_FAILURE;
    }
    else if(!stAPPHD.mRetryCount || (stAPPHD.mRetryCount > 5))
    {
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, Flash Memory APP Header Retry Count Failure\n");
#endif
        ret = NC_FAILURE;
    }
    else if((stAPPHD.mAPPLength == 0) || (stAPPHD.mAPPLength > APP_IMAGE_LENGTH_MAX))
    {
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, Flash Memory APP Total Length Failure\n");
#endif
        ret = NC_FAILURE;
    }
    else if(stAPPHD.mImgLength != (stAPPHD.mAPPLength-0x100))
    {
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, Flash Memory APP Image Length Failure\n");
#endif
        return NC_FAILURE;
    }
    else if(stAPPHD.mImgDstAddr != APP_IMAGE_BASE_ADDRESS)
    {
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, System Memory APP Dst_Address Failure\n");
#endif
        return NC_FAILURE;
    }

#if 0
    else if(stAPPHD.mConfig > 1)
    {
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, Flash Memory APP Config Failure\n");
#endif
        return NC_FAILURE;
    }
#endif

    if(ret == NC_FAILURE)
    {
        return ret;
    }

#if BOOT_DEBUG_PRINT_ENABLE
    DEBUGMSG(MSGINFO, "Success, Flash Get APP Header\n");
#endif

    return ret;
}


INT32 ncBL2_sFlash_GetImage(UINT32 nAddress)
{
    UINT32 i, size, offset, retry;
    UINT32 nChecksum = 0;
    UINT8 *pBuffer;
    UINT32 *pDwBuffer;
    INT32 ret = NC_SUCCESS;

#if BOOT_DEBUG_PRINT_ENABLE
    if(nAddress == NORMAL_APP_DATA_AREA)
    {
        DEBUGMSG(MSGINFO, "\n3.Flash Memory Normal APP Image Data Read ...\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, "\n3.Flash Memory Backup APP Image Data Read ...\n");
    }

    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "Flash Memory Address  = 0x%8x\n", nAddress);
    DEBUGMSG(MSGINFO, "System Memory Address = 0x%8x\n", stAPPHD.mImgDstAddr);
    DEBUGMSG(MSGINFO, "APP Image Length      = 0x%8x\n", stAPPHD.mImgLength);
    DEBUGMSG(MSGINFO, "APP Image CSum        = 0x%8x\n", stAPPHD.mImgCSum);
    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "\n");
#endif


    size = stAPPHD.mImgLength+FLASH_PAGE_SIZE;
    pBuffer = (UINT8 *)stAPPHD.mImgDstAddr;
    pDwBuffer = (UINT32 *)stAPPHD.mImgDstAddr;


    for(retry = 0; retry < stAPPHD.mRetryCount; retry++)
    {
        nChecksum = 0;

        for(offset = 0; offset < size; offset += FLASH_PAGE_SIZE)
        {
            ncLib_SF_Control(GCMD_SF_READ_DATA, nAddress+offset, (UINT8 *)(pBuffer+offset), SF_PAGE_SIZE, CMD_END);
        }

        // 32bit checksum ...

#if 0
        for(i = 0; i < stAPPHD.mImgLength; i++)
        {
            nChecksum += pBuffer[i];
        }

        nChecksum &= 0xFFFF;
#else
        for(i = 0; i < stAPPHD.mImgLength/4; i++)
        {
            nChecksum += pDwBuffer[i];
        }
#endif

#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, " >> Application Image nChecksum = 0x%8x\n", nChecksum);
#endif

        if(stAPPHD.mImgCSum != nChecksum)
        {
#if BOOT_DEBUG_PRINT_ENABLE
            DEBUGMSG(MSGINFO, "Error, Flash Memory Application Data Download Checksum Failure\n");
#endif
            ret = NC_FAILURE;
        }
        else
        {
            break;
        }
    }

#if BOOT_DEBUG_PRINT_ENABLE
    if(ret == NC_SUCCESS)
    {
        DEBUGMSG(MSGINFO, "Success, Flash Get APP Image Read, DDR Write\n");
    }
#endif

    return ret;
}


E_BL2_ERROR ncBL2_NormalBootMode(void)
{
    INT32 ret = NC_SUCCESS;

    ncBL2_BOOT_DebugMessage('A');

    ncBL2_BOOT_DebugMessage('B');
    ret = ncBL2_sFlash_GetHeader(NORMAL_APP_HEADER_AREA);

    if(ret == NC_FAILURE)
    {
        ncBL2_BOOT_DebugMessage('C');
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, APP Normal Header Read Failure\n");
#endif
        return E_ERROR_NORMAL_APP_HEADER;
    }

    ncBL2_BOOT_DebugMessage('D');
    ret = ncBL2_sFlash_GetImage(NORMAL_APP_DATA_AREA);

    if(ret == NC_FAILURE)
    {
        ncBL2_BOOT_DebugMessage('E');
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, APP Normal Image Read Failure\n");
#endif
        return E_ERROR_NORMAL_APP_IMAGE;
    }

    ncBL2_BOOT_DebugMessage('F');

    return E_NOERROR;
}


E_BL2_ERROR ncBL2_BackupBootMode(E_APP_BACKUP nScenario)
{
    INT32 ret = NC_SUCCESS;

    ncBL2_BOOT_DebugMessage('a');

    switch(nScenario)
    {
        case E_BACKUP_APP_HEADER:
        {
            ncBL2_BOOT_DebugMessage('b');
            ret = ncBL2_sFlash_GetHeader(BACKUP_APP_HEADER_AREA);

            if(ret == NC_FAILURE)
            {
                ncBL2_BOOT_DebugMessage('c');
#if BOOT_DEBUG_PRINT_ENABLE
                DEBUGMSG(MSGINFO, "Error, APP Backup Header Read Failure\n");
#endif
                return E_ERROR_BACKUP_APP_HEADER;
            }

            ncBL2_BOOT_DebugMessage('d');
            ret = ncBL2_sFlash_GetImage(NORMAL_APP_DATA_AREA);

            if(ret == NC_FAILURE)
            {
                ncBL2_BOOT_DebugMessage('e');
#if BOOT_DEBUG_PRINT_ENABLE
                DEBUGMSG(MSGINFO, "Error, APP Normal Image Read Failure\n");
#endif
                ret = ncBL2_sFlash_GetImage(BACKUP_APP_DATA_AREA);

                if(ret == NC_FAILURE)
                {
                    ncBL2_BOOT_DebugMessage('f');
#if BOOT_DEBUG_PRINT_ENABLE
                    DEBUGMSG(MSGINFO, "Error, APP Backup Image Read Failure\n");
#endif
                    return E_ERROR_BACKUP_APP_IMAGE;
                }
            }
        }
        break;

        case E_BACKUP_APP_IMAGE:
        {
            ncBL2_BOOT_DebugMessage('g');
            ret = ncBL2_sFlash_GetImage(BACKUP_APP_DATA_AREA);

            if(ret == NC_FAILURE)
            {
                ncBL2_BOOT_DebugMessage('h');
#if BOOT_DEBUG_PRINT_ENABLE
                DEBUGMSG(MSGINFO, "Error, APP Backup Image Read Failure\n");
#endif
                return E_ERROR_BACKUP_APP_IMAGE;
            }
        }
        break;

        default :
        break;
    }

    ncBL2_BOOT_DebugMessage('i');

    return E_NOERROR;
}


/* End Of File */
