/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SCU.h
*
*  @brief   : This file is SCU, GPIO ...
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.06
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __SCU_H__
#define __SCU_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
 ICU v2.0 Register Address
 */

#define rICU_BASE               APACHE_ICU_BASE

#define rICU_MUX_00             0x0000
#define rICU_MUX_04             0x0004
#define rICU_MUX_08             0x0008
#define rICU_MUX_0C             0x000C
#define rICU_MUX_10             0x0010
#define rICU_MUX_14             0x0014
#define rICU_MUX_18             0x0018
#define rICU_MUX_1C             0x001C
#define rICU_MUX_20             0x0020


/*
 GPIO Register Address
 */

#define rGPIO_BASE0             APACHE_ICU_BASE

#define rGPIO_V1_OUT_PORT0      0x0300
#define rGPIO_V1_DIR0           0x0304
#define rGPIO_V1_IN_PORT0       0x0308

#define rGPIO_V2_OUT_PORT0      0x0400
#define rGPIO_V2_DIR0           0x0404
#define rGPIO_V2_IN_PORT0       0x0408

#define rGPIO_BASE1             APACHE_GPIO_BASE
#define rGPIO_OUT_PORT1         0x03FC      // (0xFF<<2)
#define rGPIO_DIR1              0x0400
#define rGPIO_IN_PORT1          0x03FC      // (0xFF<<2)


/*
 PLL Register Address
 */

#define rSCU_PLL_ENABLE         0x0084
#define PLL2_BYPS               (1<<6)
#define PLL1_BYPS               (1<<5)
#define PLL0_BYPS               (1<<4)
#define PLL2_RESET              (1<<2)
#define PLL1_RESET              (1<<1)
#define PLL0_RESET              (1<<0)

#define rSCU_PLL_STABLE         0x0088
#define PLL2_STBL               (1<<2)
#define PLL1_STBL               (1<<1)
#define PLL0_STBL               (1<<0)

#define rSCU_PLL0_CONFIG        0x008C
#define rSCU_PLL1_CONFIG        0x0090
#define rSCU_PLL2_CONFIG        0x0094
#define PLL_NF                  16
#define PLL_NR                  8
#define PLL_OD                  0

#define rSCU_PLL_BWADJ          0x0098
#define PLL2_BWADJ              16
#define PLL1_BWADJ              8
#define PLL0_BWADJ              0

#define rSCU_PLL_PD             0x009C

#define rSCU_PLL_CLK_SEL        0x00A0
#define PLL2_OUTSEL             8
#define PLL1_OUTSEL             4
#define PLL0_OUTSEL             0
#define INPUT_OSC               0
#define OUT_REV                 1
#define OUTPUT_PLL              2
#define EXT_CLK                 3

#define rSCU_SYS_CLK_SEL        0x00A4
#define SEL_CAN_CLK             4
#define SEL_SYS_CLK             0
#define SYS_PLL0                0
#define SYS_PLL1                1
#define SYS_PLL2                2
#define SYS_OSC                 3

#define rSCU_SYS_CLK_DIV1       0x00A8
#define DIV_ADC_CLK             24
#define DIV_CAN_CLK             16
#define DIV_DDR_CLK             12
#define DIV_APB_CLK             8
#define DIV_AXI_CLK             4
#define DIV_CPU_CLK             0

#define rSCU_SYS_CLK_DIV2       0x00AC
#define DIV_TS_CLK              0

#define rSCU_ISP_CLK_SEL        0x00B0
#define rSCU_ISP_CLK_DIV        0x00B4
#define rSCU_ISP_CLK_DLY        0x00B8


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
 * GPIO for Apache3.5
 */
typedef enum
{
    GPIO_GROUP_A,           // Apache3.5 [32:0]
    GPIO_GROUP_B,           // Apache3.5 [31:0]
    GPIO_GROUP_C,           // Apache3.5 [7:0]
    GPIO_GROUP_D,           // Apache3.5 Not Used.
    MAX_OF_GPIO_GROUP
} eGPIO_GROUP;

typedef enum
{
    GPIO_PORT0,
    GPIO_PORT1,
    GPIO_PORT2,
    GPIO_PORT3,
    GPIO_PORT4,
    GPIO_PORT5,
    GPIO_PORT6,
    GPIO_PORT7,

    GPIO_PORT8,
    GPIO_PORT9,
    GPIO_PORT10,
    GPIO_PORT11,
    GPIO_PORT12,
    GPIO_PORT13,
    GPIO_PORT14,
    GPIO_PORT15,

    GPIO_PORT16,
    GPIO_PORT17,
    GPIO_PORT18,
    GPIO_PORT19,
    GPIO_PORT20,
    GPIO_PORT21,
    GPIO_PORT22,
    GPIO_PORT23,

    GPIO_PORT24,
    GPIO_PORT25,
    GPIO_PORT26,
    GPIO_PORT27,
    GPIO_PORT28,
    GPIO_PORT29,
    GPIO_PORT30,
    GPIO_PORT31,
    MAX_OF_GPIO_PORT,
    GPIO_PORT_NOT_USED
} eGPIO_PORT;

typedef enum
{
    GPIO_LOW,
    GPIO_HIGH,
    MAX_OF_GPIO_DATA
} eGPIO_DATA;

typedef enum
{
    GPIO_DIR_IN,
    GPIO_DIR_OUT,
    MAX_OF_GPIO_DIR
} eGPIO_DIR;


/*
 * Pad ID for Apache3.5
 */
typedef enum _PAD_ID
{
    PAD_GPIO0 = 0,
    PAD_GPIO1,
    PAD_GPIO2,
    PAD_GPIO3,
    PAD_GPIO4,
    PAD_EXTINT,

    PAD_I2C0_SCL,
    PAD_I2C0_SDA,
    PAD_I2C1_SCL,
    PAD_I2C2_SDA,

    PAD_CAN_RX,
    PAD_CAN_TX,
    PAD_UART_RX,
    PAD_UART_TX,

    PAD_SPI2_CSN0,
    PAD_SPI2_CSN1,
    PAD_SPI2_DQ0,
    PAD_SPI2_DQ1,
    PAD_SPI2_DQ2,
    PAD_SPI2_DQ3,
    PAD_SPI2_SCK,

    PAD_SEN_CK_O,
    PAD_SEN_RSTN_O,
    PAD_SEN_PCK,
    PAD_SEN_PH,
    PAD_SEN_PV,
    PAD_SEN_PD0,
    PAD_SEN_PD1,
    PAD_SEN_PD2,
    PAD_SEN_PD3,
    PAD_SEN_PD4,
    PAD_SEN_PD5,
    PAD_SEN_PD6,
    PAD_SEN_PD7,
    PAD_SEN_PD8,
    PAD_SEN_PD9,
    PAD_SEN_PD10,
    PAD_SEN_PD11,

    PAD_VOUT_CK_O,
    PAD_VOUT_VSYNC,
    PAD_VOUT_HSYNC,
    PAD_VOUT_HACT,
    PAD_VOUT_B0,
    PAD_VOUT_B1,
    PAD_VOUT_B2,
    PAD_VOUT_B3,
    PAD_VOUT_B4,
    PAD_VOUT_B5,
    PAD_VOUT_B6,
    PAD_VOUT_B7,
    PAD_VOUT_G0_C0,
    PAD_VOUT_G1_C1,
    PAD_VOUT_G2_C2,
    PAD_VOUT_G3_C3,
    PAD_VOUT_G4_C4,
    PAD_VOUT_G5_C5,
    PAD_VOUT_G6_C6,
    PAD_VOUT_G7_C7,
    PAD_VOUT_R0_Y0,
    PAD_VOUT_R1_Y1,
    PAD_VOUT_R2_Y2,
    PAD_VOUT_R3_Y3,
    PAD_VOUT_R4_Y4,
    PAD_VOUT_R5_Y5,
    PAD_VOUT_R6_Y6,
    PAD_VOUT_R7_Y7,

    PAD_MAX
} ePAD_ID;

typedef enum _PAD_FUNC
{
    PAD_FUNC_0 = 0,
    PAD_FUNC_1,
    PAD_FUNC_2,
    PAD_FUNC_3,
    PAD_FUNC_4,

    PAD_FUNC_MAX
} ePAD_FUNC;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern void __BL1_UART_PinMux(UINT32 nChNum);

extern void __BL1_SSP_PinMux(UINT32 nChNum, UINT32 nCS);
extern void __BL1_SSP_PinMuxRelease(UINT32 nChNum, UINT32 nCS);

extern void __BL1_SSP_CS_High(UINT32 nChNum, UINT32 nCS);
extern void __BL1_SSP_CS_Low(UINT32 nChNum, UINT32 nCS);


#endif  /* __SCU_H__ */


/* End Of File */
