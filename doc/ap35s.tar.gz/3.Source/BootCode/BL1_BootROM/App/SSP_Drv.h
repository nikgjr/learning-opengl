/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SSP_Drv.h
*
*  @brief   : This file is SSP Controller Driver for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2013.11.11
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : ARM PrimeCell�� SSP (PL022) / Revision: r1p3
*
********************************************************************************
*/

#ifndef __SSP_DRV_H__
#define __SSP_DRV_H__

/*
 ********************************************************************************
 *               INCLUDE
 ********************************************************************************
 */

/*
 ********************************************************************************
 *               DEFINES
 ********************************************************************************
 */

// Serial Flash Memory Information

#define DEFAULT_SSP_CLOCK_DIVIDER   2

#define MEMORY_CAPACITY_512Kb       0x00
#define MEMORY_CAPACITY_1Mb         0x01
#define MEMORY_CAPACITY_2Mb         0x02
#define MEMORY_CAPACITY_4Mb         0x03
#define MEMORY_CAPACITY_8Mb         0x04
#define MEMORY_CAPACITY_16Mb        0x05
#define MEMORY_CAPACITY_32Mb        0x06
#define MEMORY_CAPACITY_64Mb        0x07
#define MEMORY_CAPACITY_128Mb       0x08

#define SF_BLOCK_SIZE               (64*KB)
#define SF_SECTOR_SIZE              (4*KB)
#define SF_PAGE_SIZE                (256)

#define SPI_MODE_SINGLE             0
#define SPI_MODE_QUAD               1

#define APACHE_SPI0                 0
#define APACHE_SPI1                 1

/*
 * Definitions for SPI Register
 */

// SSP Control Register 0
#define	SSP_CR0                     0x00
#define SSP_SCR_MSK                 (0xFF<<8)
//#define SSP_SPH_LOW               (0x0<<7)
//#define SSP_SPH_HIGH              (0x1<<7)
//#define SSP_SPO_LOW               (0x0<<6)
//#define SSP_SPO_HIGH              (0x1<<6)
#define SSP_FRF_SPI                 (0x0<<4)    // Motororal SPI
#define SSP_FRF_SSP                 (0x1<<4)    // TI SSP
#define SSP_FRF_MICROWIRE           (0x2<<4)    // National Microwire
#define SSP_FRF_RESERVED            (0x3<<4)    // Reserved
#define SSP_FRF_MSK                 (0x3<<4)
#define SSP_DSS_4BIT                (0x3<<0)    // 4-bit data
#define SSP_DSS_5BIT                (0x4<<0)    // 5-bit data
#define SSP_DSS_6BIT                (0x5<<0)    // 6-bit data
#define SSP_DSS_7BIT                (0x6<<0)    // 7-bit data
#define SSP_DSS_8BIT                (0x7<<0)    // 8-bit data
#define SSP_DSS_9BIT                (0x8<<0)    // 9-bit data
#define SSP_DSS_10BIT               (0x9<<0)    // 10-bit data
#define SSP_DSS_11BIT               (0xA<<0)    // 11-bit data
#define SSP_DSS_12BIT               (0xB<<0)    // 12-bit data
#define SSP_DSS_13BIT               (0xC<<0)    // 13-bit data
#define SSP_DSS_14BIT               (0xD<<0)    // 14-bit data
#define SSP_DSS_15BIT               (0xE<<0)    // 15-bit data
#define SSP_DSS_16BIT               (0xF<<0)    // 16-bit data
#define SSP_DSS_MSK                 (0xF<<0)

// SSP Control Register 1
#define SSP_CR1                     0x04
#define SSP_SOD_EN                  (0x0<<3)
#define SSP_SOD_DS                  (0x1<<3)
#define SSP_MS_MASTER               (0x0<<2)
#define SSP_MS_SLAVE                (0x1<<2)
#define SSP_SSE_DS                  (0x0<<1)
#define SSP_SSE_EN                  (0x1<<1)
#define SSP_LBM_DS                  (0x0<<0)
#define SSP_LBM_EN                  (0x1<<0)

// SSP Data Register
#define SSP_DR                      0x08

// SSP Status Register
#define SSP_SR                      0x0C
#define SSP_BSY                     (0x1<<4)    // 0: SSP is idle           , 1: SSP is busy
#define SSP_RFF                     (0x1<<3)    // 0: RX FIFO is not full   , 1: RX FIFO is full
#define SSP_RNE                     (0x1<<2)    // 0: RX FIFO is empty      , 1: RX FIFO is not empty
#define SSP_TNF                     (0x1<<1)    // 0: TX FIFO is full       , 1: TX FIFO is not full
#define SSP_TFE                     (0x1<<0)    // 0: TX FIFO is not empty  , 1: TX FIFO is empty

// SSP Clock Prescale Register
#define SSP_CPSR                    0x10
#define SSP_CPSR_MSK                (0xFF<<0)

// SSP Interrupt Mask Register
#define SSP_IMSC                    0x14
#define SSP_TXIM                    (0x1<<3)    // Transmit FIFO Interrupt
#define SSP_RXIM                    (0x1<<2)    // Receive FIFO Interrupt
#define SSP_RTIM                    (0x1<<1)    // Receive FIFO Time Out
#define SSP_RORIM                   (0x1<<0)    // Receive Overrun Interrupt
#define SSP_TXIM_MASKED             (0x0<<3)
#define SSP_TXIM_NOMASKED           (0x1<<3)
#define SSP_RXIM_MASKED             (0x0<<2)
#define SSP_RXIM_NOMASKED           (0x1<<2)
#define SSP_RTIM_MASKED             (0x0<<1)
#define SSP_RTIM_NOMASKED           (0x1<<1)
#define SSP_RORIM_MASKED            (0x0<<0)
#define SSP_RORIM_NOMASKED          (0x1<<0)

// SSP Raw Interrupt Status Register
#define SSP_RIS                     0x18
#define SSP_TXRIS                   (0x1<<3)
#define SSP_RXRIS                   (0x1<<2)
#define SSP_RTRIS                   (0x1<<1)
#define SSP_RORRIS                  (0x1<<0)

// SSP Masked Interrupt Status Register
#define SSP_MIS                     0x1C
#define SSP_TXMIS                   (0x1<<3)
#define SSP_RXMIS                   (0x1<<2)
#define SSP_RTMIS                   (0x1<<1)
#define SSP_RORMIS                  (0x1<<0)

// SSP Interrupt Clear Register
#define SSP_ICR                     0x20
#define SSP_RTIC                    (0x1<<1)    // Receive Time Out Interrupt
#define SSP_RORIC                   (0x1<<0)    // Receive Overrun Interrupt

// SSP DMA Control Register
#define SSP_DMACR                   0x24
#define SSP_TXDMA_EN                (0x1<<1)
#define SSP_RXDMA_EN                (0x1<<0)

// SSP Peripheral Identification Register
#define SSP_PERI_ID0                0xFE0
#define SSP_PERI_ID1                0xFE4
#define SSP_PERI_ID2                0xFE8
#define SSP_PERI_ID3                0xFEC

// SSP PrimeCell Identification Register
#define SSP_PCELL_ID0               0xFF0
#define SSP_PCELL_ID1               0xFF4
#define SSP_PCELL_ID2               0xFF8
#define SSP_PCELL_ID3               0xFFC

/*
 * Macro
 */

#define APACHE_SPI_WRITE(port, offset, data)    *((volatile UINT32 *)(APACHE_SPI_0_BASE+(0x100000*port)+offset))=data
#define APACHE_SPI_READ(port, offset)           *((volatile UINT32 *)(APACHE_SPI_0_BASE+(0x100000*port)+offset))

#define SPI_IS_BUSY(status)                     ((status)&SSP_BSY)


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum _SSP_CH
{
    SSP_CH0 = 0,
    SSP_CH1,
    SSP_CH_MAX
} eSSP_CH;

typedef enum _SSP_FMT {
    SSP_FMT_SPI = 0, /* Motorola SPI */
    SSP_FMT_SSP_TI, /* Texas Instruments SSP */
    SSP_FMT_SSP_NS, /* National Semiconductor Microwire */
    SSP_FMT_SSP_DSP, /* Texas Instruments SSP like */
    SSP_FMT_I2S /* Philips I2S */
} eSSP_FMT;

typedef enum _SSP_MODE {
    SSP_MODE_MASTER = 0,    // Master Mode
    SSP_MODE_SLAVE          // TBD
} eSSP_MODE;

/* Clock Polarity for Motorola SPI or National Semiconductor Microwire */
typedef enum _SSP_SPO {
    SSP_SPO_LOW = 0, /* Clock will remain low when SSP is in the idle state */
    SSP_SPO_HIGH /* Clock will remain high when SSP is in the idle state */
} eSSP_SPO;

/* Clock Phase for Motorola SPI or National Semiconductor Microwire */
typedef enum _SSP_SPH {
    SSP_SPH_LOW = 0, /* Catch data at falling edge */
    SSP_SPH_HIGH /* Catch data at rising edge */
} eSSP_SPH;

/* Data Justify for Philips I2S */
typedef enum _SSP_JUSTIFY {
    SSP_JUSTFY_LEFT = 0, /* Valid data bit is left-justified */
    SSP_JUSTFY_RIGHT /* Valid data bit is right-justified */
} eSSP_JUSTIFY;

/* Mono or Stereo Data for Philips I2S */
typedef enum _SSP_STEREO {
    SSP_MONO = 0, /* Mono Data */
    SSP_STEREO /* Stereo Data */
} eSSP_STEREO;

/* Data width */
typedef enum _SSP_DS {
    SSP_DS_4BIT = 3,
    SSP_DS_5BIT,
    SSP_DS_6BIT,
    SSP_DS_7BIT,
    SSP_DS_8BIT,
    SSP_DS_9BIT,
    SSP_DS_10BIT,
    SSP_DS_11BIT,
    SSP_DS_12BIT,
    SSP_DS_13BIT,
    SSP_DS_14BIT,
    SSP_DS_15BIT,
    SSP_DS_16BIT,
} eSSP_DS;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tSSP_INIT_PARAM
{
    eSSP_FMT mFormat;   // frame format
    eSSP_MODE mMode;    // master, slave
    eSSP_DS mDataWidth; // data width (4 ~ 16)
    UINT32 mBitRate;    // Mbps

    BOOL mDmaMode;      // DMA mode
    BOOL mTxIntEn;      // Enable Tx tnterrupt
    BOOL mRxIntEn;      // Disable Rx interrupt

    /* for Motorola SPI or National Semiconductor Microwire */
    eSSP_SPO mSPO;
    eSSP_SPH mSPH;

} tSSP_INIT_PARAM, *ptSSP_INIT_PARAM;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern void ncDrv_SSP_ClearRxFIFO(UINT32 Port);
extern BOOL ncDrv_SSP_WaitBusIsBusy(UINT32 Port, UINT32 TimeOut);

extern INT32 ncDrv_SSP_Init(UINT32 nChNum, ptSSP_INIT_PARAM ptParam);
extern INT32 ncDrv_SSP_DeInit(UINT32 nChNum);
extern INT32 ncDrv_SSP_Read(UINT32 nChNum, UINT8 *pBuf, UINT32 nLength);
extern INT32 ncDrv_SSP_Write(UINT32 nChNum, UINT8 *pBuf, UINT32 nLength);


#endif  /* __SSP_DRV_H__ */


/* End Of File */
