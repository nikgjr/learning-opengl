/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.c
*
*  @brief   : This file is implemented about main of BL1_BootROM
*
*  @author  : alessio / TS Group. SoCSW Team
*
*  @date    : 2016.01.10
*
*  @version : Version 0.0.1
*
********************************************************************************
*  History  :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

/* Flash Memory Map Address */

#define BACKUP_BL2_DATA_AREA        0x001F8100  // fixed address
#define BACKUP_BL2_HEADER_AREA      0x001F8000  // fixed address

#define NORMAL_BL2_DATA_AREA        0x00000100  // fixed address
#define NORMAL_BL2_HEADER_AREA      0x00000000  // fixed address


/* Flash Memory BL2 Header Define */

#define BL2_SIGNATURE_ID            0x35335041  // "53PA"
#define BL2_IMAGE_LENGTH_MAX        (32*1024)
#define BL2_IMAGE_BASE_ADDRESS      0x04000000  // fixed address

#define SRAM_BASE_ADDRESS           BL2_IMAGE_BASE_ADDRESS


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

typedef struct
{
    UINT8 mMode;        // 0 : Download Mode, 1 : Normal Boot Mode
    UINT8 mFlashCS;     // 0 : SiP Flash CS,  1 : External Flash CS
    UINT8 mPLLConfig;   // PLL Configuration
    UINT8 Reserved;
} tBootStrap, *ptBootStrap;


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

static tREG_UART *prPUart = (tREG_UART *)UART0;

tBootStrap gtBStrap;

tSFLASH_ID sFlashID;
stBL2_HEADER stBL2HD;

UINT32 gBootMode;

UINT32 gCPUClock;
UINT32 gAXIClock;
UINT32 gAPBClock;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

void ncBL1_SystemInitialize(void);
void ncBL1_GetBootStrap(void);
void ncBL1_UART_Initialize(void);
void ncBL1_SPI_Initialize(UINT32 nClkDiv);
void ncBL1_SPI_Deinitialize(void);


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncBL1_SystemInitialize(void)
{
    ncBL1_GetBootStrap();
    ncBL1_UART_Initialize();
    ncBL1_SPI_Initialize(0);
}


void ncBL1_GetBootStrap(void)
{
    UINT32 nBootStrap;
    UINT32 nTemp, nDiv_xx;

    // Clock Enable Register
    REGRW32(SYS_CON_BASE, 0x0004) = 0x0039FFFF;
    SysDelay(1);

    // Software Reset Control Register
    REGRW32(SYS_CON_BASE, 0x0000) = 0xFFFFFFF0;
    SysDelay(1);
    REGRW32(SYS_CON_BASE, 0x0000) = 0x00000000;
    SysDelay(1);


#if BL1_JTAG_BOOT_ENABLE // test

    //mMode = BOOTSTRAP_BOOT_NORMAL_MODE;
    //mMode = BOOTSTRAP_BOOT_DOWNLOAD_MODE;
    //mFlashCS = BOOTSTRAP_BOOT_SIP_FLASH;
    //mFlashCS = BOOTSTRAP_BOOT_EXTERNAL_MODE;
    nBootStrap = ((BOOTSTRAP_BOOT_NORMAL_MODE<<3) | (BOOTSTRAP_BOOT_SIP_FLASH<<2) | (0<<0));

    gtBStrap.mMode      = (nBootStrap >> 3) & 0x1;
    gtBStrap.mFlashCS   = (nBootStrap >> 2) & 0x1;
    gtBStrap.mPLLConfig = (nBootStrap & 0x3);

    nTemp = REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV1);

    nDiv_xx = (nTemp>>DIV_CPU_CLK) & 0x3;
    gCPUClock = OSC_50MHZ / (nDiv_xx + 1);

    nDiv_xx = (nTemp>>DIV_AXI_CLK) & 0x3;
    gAXIClock = OSC_50MHZ / (nDiv_xx + 1);

    nDiv_xx = (nTemp>>DIV_APB_CLK) & 0x3;
    gAPBClock = OSC_50MHZ / (nDiv_xx);

#else

    nBootStrap = REGRW32(SYS_CON_BASE, SCU_STRAP) & 0xF;

    // Boot Mode Select
    gtBStrap.mMode      = (nBootStrap >> 3) & 0x1;
    gtBStrap.mFlashCS   = (nBootStrap >> 2) & 0x1;
    gtBStrap.mPLLConfig = (nBootStrap & 0x3);

    nTemp = REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV1);

    nDiv_xx = (nTemp>>DIV_CPU_CLK) & 0x3;
    gCPUClock = OSC_27MHZ / (nDiv_xx + 1);

    nDiv_xx = (nTemp>>DIV_AXI_CLK) & 0x3;
    gAXIClock = OSC_27MHZ / (nDiv_xx + 1);

    nDiv_xx = (nTemp>>DIV_APB_CLK) & 0x3;
    gAPBClock = OSC_27MHZ / (nDiv_xx);

#endif
}


void ncBL1_UART_Initialize(void)
{
#if BOOT_DEBUG_STEP_PRINT_ENABLE

    tUART_PARAM param;

    param.uartClk = gAPBClock;
    param.baudRate = 115200;
    param.sps = LCR_SPS_DIS;
    param.wlen = LCR_WLEN_8BIT;
    param.fen = LCR_FIFO_EN;
    param.stp2 = LCR_STP2_DIS;
    param.eps = LCR_EPS_DIS;
    param.pen = LCR_PARITY_DIS;
    param.brk = 0;

    // PinMux UART Select ...
    __BL1_UART_PinMux(UART_CH0);

    ncDrv_UART_Initialize(prPUart, &param);

#if BOOT_DEBUG_PRINT_ENABLE
    DEBUGMSG(MSGINFO, "\n\n");
    DEBUGMSG(MSGINFO, "=======================================================\n");
    DEBUGMSG(MSGINFO, "BL1 Version: [V%d.%d.%d] [%s, %s]\n",
                    BL1_VER_MAJOR, BL1_VER_MINOR1, BL1_VER_MINOR2, BL1_BUILD_DATE, BL1_BUILD_TIME);
    DEBUGMSG(MSGINFO, "=======================================================\n");
    DEBUGMSG(MSGINFO, "SYSCON_REMAP_ENABLE = %d\n", REGRW32(SYS_CON_BASE, SYSCON_REMAP_ENABLE));
    DEBUGMSG(MSGINFO, "BootStrap Mode = %d\n", gtBStrap.mMode);
    DEBUGMSG(MSGINFO, "BootStrap FlashCS = %d\n", gtBStrap.mFlashCS);
    DEBUGMSG(MSGINFO, "BootStrap PLLConfig = %d\n", gtBStrap.mPLLConfig);
    DEBUGMSG(MSGINFO, "=======================================================\n");
    DEBUGMSG(MSGINFO, "CPU = %8d, AXI = %8d, APB = %8d\n", gCPUClock, gAXIClock, gAPBClock);
    DEBUGMSG(MSGINFO, "=======================================================\n");
    DEBUGMSG(MSGINFO, "\n");
#endif

#endif

    REGRW32(SYS_CON_BASE, SCU_DEBUG_BL_VER) = ('v'<<24) | (BL1_VER_MAJOR<<16) | (BL1_VER_MINOR1<<8) | BL1_VER_MINOR2;
}


void ncBL1_SPI_Initialize(UINT32 nClkDiv)
{
    UINT8 nChNum = SPI_CH;
    tSSP_INIT_PARAM tSSPParam;

    /*
     * Initialize SSP Channel
     */

    tSSPParam.mFormat    = SSP_FMT_SPI;
    tSSPParam.mMode      = SSP_MODE_MASTER;
    tSSPParam.mDataWidth = SSP_DS_8BIT;
    tSSPParam.mBitRate   = nClkDiv;         // APB Clock / 2 default
    tSSPParam.mDmaMode   = FALSE;
    tSSPParam.mTxIntEn   = FALSE;
    tSSPParam.mRxIntEn   = FALSE;
    tSSPParam.mSPO       = SSP_SPO_LOW;
    tSSPParam.mSPH       = SSP_SPH_LOW;

    // PinMux SPI Select ...
    __BL1_SSP_PinMux(nChNum, gtBStrap.mFlashCS);

    ncDrv_sFlash_Init(nChNum, &tSSPParam);
}


void ncBL1_SPI_Deinitialize(void)
{
    UINT8 nChNum = SPI_CH;

    ncDrv_sFlash_Deinit(nChNum);

    __BL1_SSP_PinMuxRelease(nChNum, gtBStrap.mFlashCS);
}


void ncBL1_BOOT_DebugMessage(UINT8 nMsg)
{
#if BOOT_DEBUG_STEP_PRINT_ENABLE
    DEBUGMSG(MSGINFO, "%c", nMsg);
#endif
    REGRW32(SYS_CON_BASE, SCU_DEBUG_STEP) = nMsg;
}


UINT32 ncBL1_CheckBootMode(void)
{
    /*
     *  0 : Download Mode, 1 : Normal Mode
     */

    if(gtBStrap.mMode & BOOTSTRAP_BOOT_NORMAL_MODE)
    {
        return BOOTSTRAP_BOOT_NORMAL_MODE;
    }
    else
    {
        return BOOTSTRAP_BOOT_DOWNLOAD_MODE;
    }
}


void ncBL1_SetSystemJump(void)
{
    PrVoid PC_CountReset = (PrVoid)SRAM_BASE_ADDRESS;

    PC_CountReset();
}


#if BL1_FAST_BOOT_ENABLE
void ncBL1_SetSystemRemap(void)
{
    UINT32 nTemp, i;
    PrVoid PC_CountReset = (PrVoid)NULL;

    REGRW32(SYS_CON_BASE, SYSCON_REMAP_START)  = 0x00000000;
    REGRW32(SYS_CON_BASE, SYSCON_REMAP_END)    = SRAM_BASE_ADDRESS;
    REGRW32(SYS_CON_BASE, SYSCON_REMAP_ENABLE) = 1;

    while(1)
    {
        for(i = 0; i < 5; i++)
        {
            nTemp = REGRW32(SYS_CON_BASE, SYSCON_REMAP_ENABLE);
        }

        if(nTemp)
        {
            PC_CountReset();
        }
    }

    //PC_CountReset();
}
#endif


INT32 main(void)
{
    UINT32 nSPIDiv = 0;
    UINT32 nErrFlag = 0;
    E_BL1_ERROR nErrStatus;
    INT32 ret = NC_SUCCESS;

    gBootMode = 0;

    __EXIT_CRITICAL_SECTION();

#if BL1_FAST_BOOT_ENABLE
    REGRW32(SYS_CON_BASE, SCU_DEBUG_RESULT) = ('P'<<8) | ('S'<<0);
    ncBL1_SetSystemRemap();
#else

    REGRW32(SYS_CON_BASE, SCU_DEBUG_STEP) = '0';

    ncBL1_GetBootStrap();

    ncBL1_UART_Initialize();

#if BL1_SPI_CLK_DIV_LOOP
    //nSPIDiv = 0;

    while(1)    // alessio_20160229 : add
#endif
    {
        ncBL1_SPI_Initialize(nSPIDiv);

        ncBL1_BOOT_DebugMessage('\n');
        ncBL1_BOOT_DebugMessage('B');
        ncBL1_BOOT_DebugMessage('L');
        ncBL1_BOOT_DebugMessage('1');
        ncBL1_BOOT_DebugMessage(' ');

        ncBL1_BOOT_DebugMessage('1');

        gBootMode = ncBL1_CheckBootMode();


        /*
         * Boot Strap Normal or Download select ...
         */

        if(gBootMode == BOOTSTRAP_BOOT_NORMAL_MODE)
        {
            nErrFlag = '2';
            ncBL1_BOOT_DebugMessage('2');

            nErrStatus = ncBL1_NormalBootMode();

            if(nErrStatus == E_ERROR_NORMAL_BL2_HEADER)
            {
                nErrFlag = '3';
                ncBL1_BOOT_DebugMessage('3');

                nErrStatus = ncBL1_BackupBootMode(E_BACKUP_BL2_HEADER);
            }
            else if(nErrStatus == E_ERROR_NORMAL_BL2_IMAGE)
            {
                nErrFlag = '4';
                ncBL1_BOOT_DebugMessage('4');

                nErrStatus = ncBL1_BackupBootMode(E_BACKUP_BL2_IMAGE);
                //nErrStatus = ncBL1_BackupBootMode(E_BACKUP_BL2_HEADER);   // 20160817 v1.1.1 : checksum fail bug modification
            }


            /*
             * Boot Sequence Result ...
             */

            ncBL1_BOOT_DebugMessage('5');

            ncBL1_SPI_Deinitialize();

            if(nErrStatus == E_NOERROR)
            {
                ncBL1_BOOT_DebugMessage('6');
#if BOOT_DEBUG_PRINT_ENABLE
                DEBUGMSG(MSGINFO, "\nBOOT_SUCCESS\n");
#endif
                REGRW32(SYS_CON_BASE, SCU_DEBUG_RESULT) = (nSPIDiv<<24) | (nErrFlag<<16) | ('O'<<8) | ('K'<<0);
                ncBL1_SetSystemJump();

                return ret;
            }
            else
            {
                ncBL1_BOOT_DebugMessage('7');
#if BOOT_DEBUG_PRINT_ENABLE
                DEBUGMSG(MSGINFO, "\nBOOT_ERROR\n");
#endif
                REGRW32(SYS_CON_BASE, SCU_DEBUG_RESULT) = (nSPIDiv<<24) | (nErrFlag<<16) | ('N'<<8) | ('G'<<0);
            }
        }
        else
        {
            ncBL1_BOOT_DebugMessage('8');

            ncBL1_SPI_Deinitialize();

            ncBL1_BOOT_DebugMessage('9');
#if BOOT_DEBUG_PRINT_ENABLE
            DEBUGMSG(MSGINFO, "\nBOOT_DN\n");
#endif
            REGRW32(SYS_CON_BASE, SCU_DEBUG_RESULT) = ('D'<<8) | ('N'<<0);

            return ret;
        }


#if BL1_SPI_CLK_DIV_LOOP

        nSPIDiv++;
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "nSPIDiv = %d\n", nSPIDiv);
#endif

        if(nSPIDiv >= 0x6)
        {
#if BOOT_DEBUG_PRINT_ENABLE
            DEBUGMSG(MSGINFO, "\nBOOT_FLASH_MEMORY_FAIL\n");
#endif
            REGRW32(SYS_CON_BASE, SCU_DEBUG_RESULT) = ('F'<<8) | ('F'<<0);

            ret = NC_FAILURE;
            break;
        }

#endif
    } // while(1)
#endif

    return ret;
}


INT32 ncBL1_sFlash_Information(void)
{
    UINT8 rRDID[4];
    UINT32 nChipSize = FLASH_BLOCK_SIZE;
    UINT32 i;
    INT32 ret = NC_SUCCESS;


    ncDrv_sFlash_ReadID(SPI_CH, gtBStrap.mFlashCS, rRDID);

    sFlashID.mbManufacture = rRDID[0];
    sFlashID.mbMemoryType = rRDID[1];
    sFlashID.mbMemoryCapacity = rRDID[2]&0x0F;

    for(i = 0; i <= 8; i++)
    {
        if(sFlashID.mbMemoryCapacity == i)
        {
            ret = NC_SUCCESS;
            break;
        }
        else
        {
            nChipSize = nChipSize * 2;
            ret = NC_FAILURE;
        }
    }

#if BOOT_DEBUG_PRINT_ENABLE
    DEBUGMSG(MSGINFO, "\n1.Flash Memory Information ...\n");
    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "  manufacturer ID : 0x%x\n", rRDID[0]);
    DEBUGMSG(MSGINFO, "  memory type     : 0x%x\n", rRDID[1]);
    DEBUGMSG(MSGINFO, "  memory density  : 0x%x\n", rRDID[2]);
    DEBUGMSG(MSGINFO, "  memory size     : %d MBbyte\n", nChipSize/MB);
    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");
#endif

    return ret;
}


INT32 ncBL1_sFlash_GetHeader(UINT32 nAddress)
{
#if BOOT_DEBUG_PRINT_ENABLE
    UINT32 i, size;
    UINT32 nChecksum = 0;
#endif
    UINT8 pBuffer[FLASH_PAGE_SIZE];
    INT32 ret = NC_SUCCESS;


    ncDrv_sFlash_Read(SPI_CH, gtBStrap.mFlashCS, nAddress, pBuffer);

    stBL2HD.mSignature  = CharToInt(&pBuffer[0]);   // BL2 Header Signature("AP35")
    stBL2HD.mRetryCount = CharToInt(&pBuffer[4]);   // BL2 Retry count
    stBL2HD.mBL2Length  = CharToInt(&pBuffer[8]);   // BL2 Header + Image Total Length
    stBL2HD.Reserved    = CharToInt(&pBuffer[12]);  // BL2 Reserved

    stBL2HD.mImgSrcAddr = CharToInt(&pBuffer[16]);  // BL2 Image Source Address
    stBL2HD.mImgDstAddr = CharToInt(&pBuffer[20]);  // BL2 Image Destination Address
    stBL2HD.mImgLength  = CharToInt(&pBuffer[24]);  // BL2 Image Length
    stBL2HD.mImgCSum    = CharToInt(&pBuffer[28]) & 0xFFFF;  // BL2 Image Checksum


#if BOOT_DEBUG_PRINT_ENABLE
    if(nAddress == NORMAL_BL2_HEADER_AREA)
    {
        DEBUGMSG(MSGINFO, "\n2.Flash Memory Normal BL2 Header Information ...\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, "\n2.Flash Memory Backup BL2 Header Information ...\n");
    }

    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, ">> Flash Address = 0x%8x", nAddress);

    for(i = 0; i < 32; i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%x : ", (i>>24)&0xFF, (i>>16)&0xFF, (i>>8)&0xFF, i&0xFF);
        DEBUGMSG(MSGINFO, "%x ", pBuffer[i]);
    }

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "\n");

    DEBUGMSG(MSGINFO, "BL2 Signature     = %c%c%c%c\n", pBuffer[0], pBuffer[1], pBuffer[2], pBuffer[3]);
    DEBUGMSG(MSGINFO, "BL2 RetryCount    = 0x%8x\n", stBL2HD.mRetryCount);
    DEBUGMSG(MSGINFO, "BL2 Header Length = 0x%8x\n", stBL2HD.mBL2Length);
    DEBUGMSG(MSGINFO, "BL2 Reserved      = 0x%8x\n", stBL2HD.Reserved);

    DEBUGMSG(MSGINFO, "BL2 Image SrcAddr = 0x%8x\n", stBL2HD.mImgSrcAddr);
    DEBUGMSG(MSGINFO, "BL2 Image DstAddr = 0x%8x\n", stBL2HD.mImgDstAddr);
    DEBUGMSG(MSGINFO, "BL2 Image Length  = 0x%8x\n", stBL2HD.mImgLength);
    DEBUGMSG(MSGINFO, "BL2 Image CSum    = 0x%8x\n", stBL2HD.mImgCSum);
    DEBUGMSG(MSGINFO, "\n");
#endif


    if(stBL2HD.mSignature != BL2_SIGNATURE_ID)
    {
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, Flash Memory BL2 Header Signature id Failure\n");
#endif
        ret = NC_FAILURE;
    }
    else if(!stBL2HD.mRetryCount || (stBL2HD.mRetryCount > 5))
    {
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, Flash Memory BL2 Header Retry Count Failure\n");
#endif
        ret = NC_FAILURE;
    }
    else if((stBL2HD.mBL2Length == 0) || (stBL2HD.mBL2Length > BL2_IMAGE_LENGTH_MAX))
    {
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, Flash Memory BL2 Total Length Failure\n");
#endif
        ret = NC_FAILURE;
    }
    else if(stBL2HD.mImgLength != (stBL2HD.mBL2Length-0x100))
    {
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, Flash Memory BL2 Image Length Failure\n");
#endif
        return NC_FAILURE;
    }
    else if(stBL2HD.mImgDstAddr != BL2_IMAGE_BASE_ADDRESS)
    {
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, System Memory BL2 Dst_Address Failure\n");
#endif
        return NC_FAILURE;
    }

    if(ret == NC_FAILURE)
    {
        return ret;
    }

#if BOOT_DEBUG_PRINT_ENABLE
    DEBUGMSG(MSGINFO, "Success, Flash Get BL2 Header\n");
#endif

    return ret;
}


INT32 ncBL1_sFlash_GetImage(UINT32 nAddress)
{
    UINT32 i, size, offset, retry;
    UINT32 nChecksum = 0;
    UINT8 *pBuffer;
    INT32 ret = NC_SUCCESS;


#if BOOT_DEBUG_PRINT_ENABLE
    if(nAddress == NORMAL_BL2_DATA_AREA)
    {
        DEBUGMSG(MSGINFO, "\n3.Flash Memory Normal BL2 Image Data Read ...\n");
    }
    else
    {
        DEBUGMSG(MSGINFO, "\n3.Flash Memory Backup BL2 Image Data Read ...\n");
    }

    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "Flash Memory Address  = 0x%8x\n", nAddress);
    DEBUGMSG(MSGINFO, "System Memory Address = 0x%8x\n", stBL2HD.mImgDstAddr);
    DEBUGMSG(MSGINFO, "BL2 Image Length      = 0x%8x\n", stBL2HD.mImgLength);
    DEBUGMSG(MSGINFO, "BL2 Image CSum        = 0x%8x\n", stBL2HD.mImgCSum);
    DEBUGMSG(MSGINFO, "-------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "\n");
#endif


    size = stBL2HD.mImgLength+FLASH_PAGE_SIZE;
    pBuffer = (UINT8 *)stBL2HD.mImgDstAddr;


    for(retry = 0; retry < stBL2HD.mRetryCount; retry++)
    {
        nChecksum = 0;

        for(offset = 0; offset < size; offset += FLASH_PAGE_SIZE)
        {
            ncDrv_sFlash_Read(SPI_CH, gtBStrap.mFlashCS, nAddress+offset, (UINT8 *)(pBuffer+offset));
        }

        // 32bit checksum ...

        for(i = 0; i < stBL2HD.mImgLength; i++)
        {
            nChecksum += pBuffer[i];
        }

        nChecksum &= 0xFFFF;

#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, " >> BL2 Image nChecksum = 0x%8x\n", nChecksum);
#endif

        if(stBL2HD.mImgCSum != nChecksum)
        {
#if BOOT_DEBUG_PRINT_ENABLE
            DEBUGMSG(MSGINFO, "Error, Flash Memory BL2 Data Download Checksum Failure\n");
#endif
            ret = NC_FAILURE;
        }
        else
        {
            break;
        }
    }

#if BOOT_DEBUG_PRINT_ENABLE
    if(ret == NC_SUCCESS)
    {
        DEBUGMSG(MSGINFO, "Success, Flash Get BL2 Image Read, SRAM Write\n");
    }
#endif

    return ret;
}


E_BL1_ERROR ncBL1_NormalBootMode(void)
{
    INT32 ret = NC_SUCCESS;

    ncBL1_BOOT_DebugMessage('A');
    ret = ncBL1_sFlash_Information();

    if(ret == NC_FAILURE)
    {
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, Serial Flash Memory Information Failure\n");
#endif
        return E_ERROR_FLASH_MEMROY_INFO;
    }

    ncBL1_BOOT_DebugMessage('B');
    ret = ncBL1_sFlash_GetHeader(NORMAL_BL2_HEADER_AREA);

    if(ret == NC_FAILURE)
    {
        ncBL1_BOOT_DebugMessage('C');
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, BL2 Normal Header Read Failure\n");
#endif
        return E_ERROR_NORMAL_BL2_HEADER;
    }

    ncBL1_BOOT_DebugMessage('D');
    ret = ncBL1_sFlash_GetImage(NORMAL_BL2_DATA_AREA);

    if(ret == NC_FAILURE)
    {
        ncBL1_BOOT_DebugMessage('E');
#if BOOT_DEBUG_PRINT_ENABLE
        DEBUGMSG(MSGINFO, "Error, BL2 Normal Image Read Failure\n");
#endif
        return E_ERROR_NORMAL_BL2_IMAGE;
    }

    ncBL1_BOOT_DebugMessage('F');

    return E_NOERROR;
}


E_BL1_ERROR ncBL1_BackupBootMode(E_BL1_BACKUP nScenario)
{
    INT32 ret = NC_SUCCESS;

    ncBL1_BOOT_DebugMessage('a');

    switch(nScenario)
    {
        case E_BACKUP_BL2_HEADER:
        {
            ncBL1_BOOT_DebugMessage('b');
            ret = ncBL1_sFlash_GetHeader(BACKUP_BL2_HEADER_AREA);

            if(ret == NC_FAILURE)
            {
                ncBL1_BOOT_DebugMessage('c');
#if BOOT_DEBUG_PRINT_ENABLE
                DEBUGMSG(MSGINFO, "Error, BL2 Backup Header Read Failure\n");
#endif
                return E_ERROR_BACKUP_BL2_HEADER;
            }

            ncBL1_BOOT_DebugMessage('d');
            ret = ncBL1_sFlash_GetImage(NORMAL_BL2_DATA_AREA);

            if(ret == NC_FAILURE)
            {
                ncBL1_BOOT_DebugMessage('e');
#if BOOT_DEBUG_PRINT_ENABLE
                DEBUGMSG(MSGINFO, "Error, BL2 Normal Image Read Failure\n");
#endif
                ret = ncBL1_sFlash_GetImage(BACKUP_BL2_DATA_AREA);

                if(ret == NC_FAILURE)
                {
                    ncBL1_BOOT_DebugMessage('f');
#if BOOT_DEBUG_PRINT_ENABLE
                    DEBUGMSG(MSGINFO, "Error, BL2 Backup Image Read Failure\n");
#endif
                    return E_ERROR_BACKUP_BL2_IMAGE;
                }
            }
        }
        break;

        case E_BACKUP_BL2_IMAGE:
        {
            ncBL1_BOOT_DebugMessage('g');
            ret = ncBL1_sFlash_GetImage(BACKUP_BL2_DATA_AREA);

            if(ret == NC_FAILURE)
            {
                ncBL1_BOOT_DebugMessage('h');
#if BOOT_DEBUG_PRINT_ENABLE
                DEBUGMSG(MSGINFO, "Error, BL2 Backup Image Read Failure\n");
#endif
                return E_ERROR_BACKUP_BL2_IMAGE;
            }
        }
        break;

        default :
        break;
    }

    ncBL1_BOOT_DebugMessage('i');

    return E_NOERROR;
}


/* End Of File */
