/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : sFlash.c
*
*  @brief   : This file is serial flash memory control driver
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.25
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncDrv_sFlash_Init(UINT32 nChNum, ptSSP_INIT_PARAM ptParam)
{
    ncDrv_SSP_Init(nChNum, ptParam);
}


void ncDrv_sFlash_Deinit(UINT32 nChNum)
{
    ncDrv_SSP_DeInit(nChNum);
}


void ncDrv_sFlash_ReadID(UINT32 nChNum, UINT32 nCS, UINT8 *pBuff)
{
    UINT8 Command;

    ncDrv_SSP_ClearRxFIFO(nChNum);
    ncDrv_SSP_WaitBusIsBusy(nChNum, 1000);

    Command = CMD_RD_IDENTIFICATION;

    __BL1_SSP_CS_Low(nChNum, nCS);

    ncDrv_SSP_Write(nChNum, &Command, 1);
    ncDrv_SSP_Read(nChNum, pBuff, 3);

    __BL1_SSP_CS_High(nChNum, nCS);

}


void ncDrv_sFlash_Read(UINT32 nChNum, UINT32 nCS, UINT32 PageAddr, UINT8 *pBuff)
{
    UINT8 Command[4];

    ncDrv_SSP_ClearRxFIFO(nChNum);
    ncDrv_SSP_WaitBusIsBusy(nChNum, 1000);

    Command[0] = CMD_RD_DATA;
    Command[1] = (PageAddr>>16 & 0xFF);
    Command[2] = (PageAddr>>8  & 0xFF);
    Command[3] = (PageAddr     & 0xFF);

    __BL1_SSP_CS_Low(nChNum, nCS);

    ncDrv_SSP_Write(nChNum, Command, 4);
    ncDrv_SSP_Read(nChNum, pBuff, FLASH_PAGE_SIZE);

    __BL1_SSP_CS_High(nChNum, nCS);
}


/* End Of File */
