/*
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : sFlash_Svc.h
*
*  @brief   : This file is sFlash controller API for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2016.01.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __SFLASH_SVC_H__
#define __SFLASH_SVC_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "sFlash_Lib.h"


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32  ncSvc_SF_Init(void);
extern INT32  ncSvc_SF_Release(void);

extern void   ncSvc_SF_WaitWIP(void);
extern void   ncSvc_SF_WriteEnable(void);
extern void   ncSvc_SF_WriteDisable(void);
extern UINT8  ncSvc_SF_ReadStatus(void);
extern UINT8  ncSvc_SF_ReadStatus2(void);
extern void   ncSvc_SF_WriteStatus(UINT8 Status);
extern void   ncSvc_SF_WriteStatus2(UINT8 Status1, UINT8 Status2);

extern INT32  ncSvc_SF_ReadDeviceIdentification(ptSFLASH_ID ptsFlashID);

#endif /* __SFLASH_SVC_H__ */
