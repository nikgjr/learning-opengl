/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.c
*
*  @brief   : This file is implemented about main of BL2_BootRAM
*
*  @author  : alessio / TS Group. SoCSW Team
*
*  @date    : 2016.02.02
*
*  @version : Version 0.0.1
*
********************************************************************************
*  History  :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "Main.h"



/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define FLASH_PAGE_SIZE             256

/* Flash Memory Map Address */

#define BACKUP_APP_DATA_AREA        0x001A5100  // fixed address
#define BACKUP_APP_HEADER_AREA      0x001A5000  // fixed address

#define NORMAL_APP_DATA_AREA        0x00008100  // fixed address
#define NORMAL_APP_HEADER_AREA      0x00008000  // fixed address


/* Flash Memory APP Header Define */

#define APP_SIGNATURE_ID            0x35335041  // "53PA"
#define APP_IMAGE_LENGTH_MAX        (332*1024)
#define APP_IMAGE_BASE_ADDRESS      0x08000000  // fixed address

#define LPDDR_BASE_ADDRESS          APP_IMAGE_BASE_ADDRESS


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

stAPP_HEADER stAPPHD;

UINT32 gFlashCS = 0;



/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncBL2_GetBootStrap(void)
{
    UINT32 nBootStrap;

    nBootStrap = REGRW32(SYS_CON_BASE, SCU_STRAP) & 0xF;
    gFlashCS = (nBootStrap >> 2) & 0x1;

    __BL2_PLL_SetConfig();
}

void ncBL2_QSPI_Initialize(void)
{
    __BL2_SSP_PinMux(gFlashCS);

    ncSvc_SF_Init();
    
    // #define rQSPI_EXT_ADDR 0x005C
    if(gFlashCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        REGRW32(APACHE_QSPI_BASE, 0x005C) = 0xFFFFFF;
    }
    else // BOOTSTRAP_BOOT_EXTERNAL_MODE
    {
        REGRW32(APACHE_QSPI_BASE, 0x005C) = 0x0;
    }

    __BL2_QSPI_PinMux(gFlashCS);
}


void ncBL2_DDRC_Initialize(void)
{
    UINT32 Reg;
    INT32 loop = 0x100000;

#if defined (__BL2_CPU192MHz_DDR096MHz__)

    WRITE32(0x000000A0, (APACHE_DDRC_BASE+0x04));
    WRITE32(0x00060705, (APACHE_DDRC_BASE+0x08));
    WRITE32(0x00622222, (APACHE_DDRC_BASE+0x0c));
    #ifdef __BL2_DDR_tREFI_HIGH_TEMP__
        WRITE32(0x4b000164, (APACHE_DDRC_BASE+0x10));
    #else
        WRITE32(0x4b000591, (APACHE_DDRC_BASE+0x10));  
    #endif
    WRITE32(0x00400022, (APACHE_DDRC_BASE+0x14));
    WRITE32(0x0000000E, (APACHE_DDRC_BASE+0x24));
    

    // PHY init Start
    WRITE32((1<<1)|(1<<0), (APACHE_DDRC_BASE+0x00));

    while(loop--)
    {
        Reg = READ32((APACHE_DDRC_BASE+0x00));

        // PHY init complete
        if(Reg & (1<<4))
            break;
    }
    
#elif defined (__BL2_CPU108MHz_DDR108MHz__)

    WRITE32(0x000000A0, (APACHE_DDRC_BASE+0x04));
    WRITE32(0x00070805, (APACHE_DDRC_BASE+0x08));
    WRITE32(0x00622222, (APACHE_DDRC_BASE+0x0c));
    #ifdef __BL2_DDR_tREFI_HIGH_TEMP__
        WRITE32(0x54600191, (APACHE_DDRC_BASE+0x10));
    #else // tREFI(15.6us)
        WRITE32(0x54600644, (APACHE_DDRC_BASE+0x10));
    #endif
    WRITE32(0x00400022, (APACHE_DDRC_BASE+0x14));
    WRITE32(0x0000000E, (APACHE_DDRC_BASE+0x24));
    
    // PHY init Start
    WRITE32((1<<1)|(1<<0), (APACHE_DDRC_BASE+0x00));

    while(loop--)
    {
        Reg = READ32((APACHE_DDRC_BASE+0x00));

        // PHY init complete
        if(Reg & (1<<4))
            break;
    }    
    
#else // Default CPU297MHz, DDR148.5MHz

    WRITE32(0x000000A0, (APACHE_DDRC_BASE+0x04));
    WRITE32(0x00090B07, (APACHE_DDRC_BASE+0x08));
    WRITE32(0x00623233, (APACHE_DDRC_BASE+0x0c));
    #ifdef __BL2_DDR_tREFI_HIGH_TEMP__
        WRITE32(0x74040227, (APACHE_DDRC_BASE+0x10));   // tREFI(3.9us)
    #else
        WRITE32(0x7404089D, (APACHE_DDRC_BASE+0x10));   // tREFI(15.6us)
    #endif
    WRITE32(0x00400022, (APACHE_DDRC_BASE+0x14));
    WRITE32(0x00000000, (APACHE_DDRC_BASE+0x24));

    // PHY init Start
    WRITE32((1<<1)|(1<<0), (APACHE_DDRC_BASE+0x00));

    while(loop--)
    {
        Reg = READ32((APACHE_DDRC_BASE+0x00));

        // PHY init complete
        if(Reg & (1<<4))
            break;
    }

    // Fixed RDQ
    WRITE32(0x08080808, (APACHE_DDRC_BASE+0x20));
    
#endif
}


void ncBL2_QSPI_Deinitialize(void)
{
    ncSvc_SF_Release();    
    
    __BL2_QSPI_PinMuxRelease(gFlashCS);
}

void ncBL2_SetSystemRemap(void)
{
    UINT32 nTemp, i;
    PrVoid PC_CountReset = (PrVoid)NULL;

    REGRW32(SYS_CON_BASE, SYSCON_REMAP_START)  = 0x00000000;
    REGRW32(SYS_CON_BASE, SYSCON_REMAP_END)    = LPDDR_BASE_ADDRESS;
    REGRW32(SYS_CON_BASE, SYSCON_REMAP_ENABLE) = 1;

#if 1 // v0.9.3 add
    while(1)
    {
        for(i = 0; i < 5; i++)
        {
            nTemp = REGRW32(SYS_CON_BASE, SYSCON_REMAP_ENABLE);
        }

        if(nTemp)
        {
            PC_CountReset();
        }
    }
#else
    PC_CountReset();
#endif
}

INT32 ncBL2_sFlash_GetHeader(UINT32 nAddress)
{
    UINT32 i;
    UINT8 pBuffer[FLASH_PAGE_SIZE] __attribute__ ((aligned (8)));   // [QSPI] Important align;
    INT32 ret = NC_SUCCESS;

    ncDrv_QSPI_ReadData(nAddress, (UINT8 *)pBuffer, SF_PAGE_SIZE);

    stAPPHD.mSignature  = CharToInt(&pBuffer[0]);   // APP Header Signature("AP35")
    stAPPHD.mRetryCount = CharToInt(&pBuffer[4]);   // APP Retry count
    stAPPHD.mAPPLength  = CharToInt(&pBuffer[8]);   // APP Header + Image Total Length
    stAPPHD.mConfig     = CharToInt(&pBuffer[12]);  // APP Configuration

    stAPPHD.mImgSrcAddr = CharToInt(&pBuffer[16]);  // APP Image Source Address
    stAPPHD.mImgDstAddr = CharToInt(&pBuffer[20]);  // APP Image Destination Address
    stAPPHD.mImgLength  = CharToInt(&pBuffer[24]);  // APP Image Length
    //stAPPHD.mImgCSum    = CharToInt(&pBuffer[28]) & 0xFFFF;  // APP Image Checksum
    stAPPHD.mImgCSum    = CharToInt(&pBuffer[28]);  // APP Image Checksum


    if(stAPPHD.mSignature != APP_SIGNATURE_ID)
    {
        ret = NC_FAILURE;
    }
    else if(!stAPPHD.mRetryCount || (stAPPHD.mRetryCount > 5))
    {
        ret = NC_FAILURE;
    }
    else if((stAPPHD.mAPPLength == 0) || (stAPPHD.mAPPLength > APP_IMAGE_LENGTH_MAX))
    {
        ret = NC_FAILURE;
    }
    else if(stAPPHD.mImgLength != (stAPPHD.mAPPLength-0x100))
    {
        return NC_FAILURE;
    }
    else if(stAPPHD.mImgDstAddr != APP_IMAGE_BASE_ADDRESS)
    {
        return NC_FAILURE;
    }

    if(ret == NC_FAILURE)
    {
        return ret;
    }

    return ret;
}

INT32 ncBL2_sFlash_GetImage(UINT32 nAddress)
{
    UINT32 i, size, retry;
    UINT32 nChecksum = 0;
    UINT8 *pBuffer;
    UINT32 *pDwBuffer;
    INT32 ret = NC_SUCCESS;

    size = Align(stAPPHD.mImgLength, 8);
    pBuffer = (UINT8 *)stAPPHD.mImgDstAddr;
    pDwBuffer = (UINT32 *)stAPPHD.mImgDstAddr;

    for(retry = 0; retry < stAPPHD.mRetryCount; retry++)
    {
        nChecksum = 0;

        ncDrv_QSPI_ReadData(nAddress, (UINT8 *)pBuffer, size);

        // 32bit checksum ...
        for(i = 0; i < stAPPHD.mImgLength/4; i++)
        {
            nChecksum += pDwBuffer[i];
        }

        if(stAPPHD.mImgCSum != nChecksum)
        {
            ret = NC_FAILURE;
        }
        else
        {
            break;
        }
    }

    return ret;
}


E_BL2_ERROR ncBL2_NormalBootMode(void)
{
    INT32 ret = NC_SUCCESS;

    ret = ncBL2_sFlash_GetHeader(NORMAL_APP_HEADER_AREA);

    if(ret == NC_FAILURE)
    {
        return E_ERROR_NORMAL_APP_HEADER;
    }

    ret = ncBL2_sFlash_GetImage(NORMAL_APP_DATA_AREA);
    if(ret == NC_FAILURE)
    {
        return E_ERROR_NORMAL_APP_IMAGE;
    }

    return E_NOERROR;
}


E_BL2_ERROR ncBL2_BackupBootMode(E_APP_BACKUP nScenario)
{
    INT32 ret = NC_SUCCESS;

    switch(nScenario)
    {
        case E_BACKUP_APP_HEADER:
        {
            ret = ncBL2_sFlash_GetHeader(BACKUP_APP_HEADER_AREA);

            if(ret == NC_FAILURE)
            {
                return E_ERROR_BACKUP_APP_HEADER;
            }
            
            ret = ncBL2_sFlash_GetImage(NORMAL_APP_DATA_AREA);
            if(ret == NC_FAILURE)
            {
                ret = ncBL2_sFlash_GetImage(BACKUP_APP_DATA_AREA);
                if(ret == NC_FAILURE)
                {
                    return E_ERROR_BACKUP_APP_IMAGE;
                }
            }
        }
        break;

        case E_BACKUP_APP_IMAGE:
        {

            ret = ncBL2_sFlash_GetImage(BACKUP_APP_DATA_AREA);
            if(ret == NC_FAILURE)
            {
                return E_ERROR_BACKUP_APP_IMAGE;
            }
        }
        break;

        default :
        break;
    }

    return E_NOERROR;
}


INT32 main(void)
{
    E_BL2_ERROR nErrStatus;
    INT32 ret = NC_SUCCESS;

#if 0 // test code
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_10, 20); // Mux->GPIO_A[3]
    __BL2_SetGPIODir(GPIO_PORT1, GPIO_DIR_OUT); // Mux->GPIO_A[3]
    __BL2_SetGPIOData(GPIO_PORT1, GPIO_LOW); // Mux->GPIO_A[3]
#endif

    ncBL2_GetBootStrap();
    ncBL2_QSPI_Initialize();
    ncBL2_DDRC_Initialize();

    nErrStatus = ncBL2_NormalBootMode();

    if(nErrStatus == E_ERROR_NORMAL_APP_HEADER)
    {
        nErrStatus = ncBL2_BackupBootMode(E_BACKUP_APP_HEADER);
    }
    else if(nErrStatus == E_ERROR_NORMAL_APP_IMAGE)
    {
        nErrStatus = ncBL2_BackupBootMode(E_BACKUP_APP_IMAGE);
    }

    ncBL2_QSPI_Deinitialize();

    ncBL2_SetSystemRemap();

    return ret;
}

/* End Of File */
