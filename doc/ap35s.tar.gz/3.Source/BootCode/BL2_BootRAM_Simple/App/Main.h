/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.h
*
*  @brief   : This file is implemented about main of BL1_BootROM
*
*  @author  : alessio / SoCSW Platform Team
*
*  @date    : 2016.02.02
*
*  @version : Version 0.0.1
*
********************************************************************************
*  History  :
*
********************************************************************************
*/

#ifndef __MAIN_H__
#define __MAIN_H__


/*
********************************************************************************
*               INCLUDE FILES
********************************************************************************
*/

#include "Type.h"
#include "Apache35.h"

#include "Utility.h"
#include "SCU.h"

#include "SSP_Drv.h"

#include "sFlash_Svc.h"

#include "SSP_Lib.h"
#include "sFlash_Lib.h"


/*
********************************************************************************
*               DEFINITIONS
********************************************************************************
*/

/* APACHE3.5 Bootloader-BL2 Version */

#define BL2_VER_MAJOR               1
#define BL2_VER_MINOR1              0
#define BL2_VER_MINOR2              4


//#define __BL2_CPU192MHz_DDR096MHz__
#define __BL2_CPU108MHz_DDR108MHz__

#define __BL2_DDR_tREFI_HIGH_TEMP__








/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

enum
{
    BOOTSTRAP_BOOT_DOWNLOAD_MODE,
    BOOTSTRAP_BOOT_NORMAL_MODE,
};


enum
{
    BOOTSTRAP_BOOT_SIP_FLASH,
    BOOTSTRAP_BOOT_EXTERNAL_MODE,
};


typedef enum
{
    E_NOERROR = 0,

    E_ERROR_FLASH_MEMROY_INFO,

    E_ERROR_NORMAL_APP_HEADER,
    E_ERROR_NORMAL_APP_IMAGE,

    E_ERROR_BACKUP_APP_HEADER,
    E_ERROR_BACKUP_APP_IMAGE,

    NUM_OF_BL2_ERROR
} E_BL2_ERROR;  // BootLoader Error Number


typedef enum
{
    E_BACKUP_APP_HEADER,
    E_BACKUP_APP_IMAGE,

    NUM_OF_APP_BACKUP
} E_APP_BACKUP; // Application Error Number


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT32 mSignature;      // APP Header Signature
    UINT32 mRetryCount;     // APP Retry count
    UINT32 mAPPLength;      // APP Header + Image Total Length
    UINT32 mConfig;         // APP Configuration 
                            // [0] 0 : QSPI, 1 : SPI

    UINT32 mImgSrcAddr;     // APP Flash Memory Source Address
    UINT32 mImgDstAddr;     // APP System Memory Destination Address
    UINT32 mImgLength;      // APP Image Length
    UINT32 mImgCSum;        // APP Image Checksum
} stAPP_HEADER, *pstAPP_HEADER;












/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

extern UINT32 gFlashCS; 


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

INT32 ncBL2_sFlash_GetHeader(UINT32 nAddress);
INT32 ncBL2_sFlash_GetImage(UINT32 nAddress);

E_BL2_ERROR ncBL2_NormalBootMode(void);
E_BL2_ERROR ncBL2_BackupBootMode(E_APP_BACKUP nScenario);


#endif /* __MAIN_H__ */
