/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SCU.c
*
*  @brief   : This file is SCU, GPIO ...
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.27
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Main.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void __BL2_SetPinMux(UINT32 Func, UINT32 Offset, UINT32 Pos)
{
    REGRW32(APACHE_ICU_BASE, Offset) &= ~(0x7<<Pos);
    REGRW32(APACHE_ICU_BASE, Offset) |= ((Func&0x7)<<Pos);
}


void __BL2_SetGPIODir(eGPIO_PORT port, eGPIO_DIR dir)
{
    if(dir == GPIO_DIR_IN)
        REGRW32(rGPIO_BASE0, 0x0404) &= ~(1<<port);
    else
        REGRW32(rGPIO_BASE0, 0x0404) |= (1<<port);
}


void __BL2_SetGPIOData(eGPIO_PORT port, eGPIO_DATA level)
{
    if(level == GPIO_LOW)
        REGRW32(rGPIO_BASE0, 0x0400) &= ~(1<<port);
    else
        REGRW32(rGPIO_BASE0, 0x0400) |= (1<<port);
}

void __BL2_SSP_PinMux(UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 12); //SPI2_PINMUX_CS0  / SPI2_CSN0 / Mux->GPIO_12
        __BL2_SetGPIODir(GPIO_PORT12, GPIO_DIR_OUT); // Mux->GPIO_12
    }
    else
    {
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 8);  //SPI2_PINMUX_CS1  / SPI2_CSN1 / Mux->GPIO_13
        __BL2_SetGPIODir(GPIO_PORT13, GPIO_DIR_OUT); // Mux->GPIO_13
    }

    __BL2_SetPinMux(PAD_FUNC_1, rICU_MUX_04, 24); //SPI2_PINMUX_MOSI / SPI0_DQ0
    __BL2_SetPinMux(PAD_FUNC_1, rICU_MUX_04, 20); //SPI2_PINMUX_MISO / SPI2_DQ1
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 4);  //SPI2_PINMUX_MISO / SPI2_DQ2  / Mux->GPIO_16
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 8);  //SPI2_PINMUX_MISO / SPI2_DQ3  / Mux->GPIO_17
    __BL2_SetPinMux(PAD_FUNC_1, rICU_MUX_04, 16); //SPI2_PINMUX_CLK  / SPI2_SCK

    __BL2_SetGPIODir(GPIO_PORT16, GPIO_DIR_IN);
    __BL2_SetGPIODir(GPIO_PORT17, GPIO_DIR_IN);

    __BL2_SSP_CS_High(nCS);
}


void __BL2_QSPI_PinMux(UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL2_SetPinMux(PAD_FUNC_2, rICU_MUX_04, 12); //SPI2_PINMUX_CS0  / SPI2_CSN0 / Mux->GPIO_12
    }
    else
    {
        __BL2_SetPinMux(PAD_FUNC_2, rICU_MUX_04, 8);  //SPI2_PINMUX_CS1  / SPI2_CSN1 / Mux->GPIO_13
    }

    __BL2_SetPinMux(PAD_FUNC_0, rICU_MUX_04, 24); //SPI2_PINMUX_MOSI / SPI0_DQ0
    __BL2_SetPinMux(PAD_FUNC_0, rICU_MUX_04, 20); //SPI2_PINMUX_MISO / SPI2_DQ1
    __BL2_SetPinMux(PAD_FUNC_0, rICU_MUX_08, 4);  //SPI2_PINMUX_MISO / SPI2_DQ2  / Mux->GPIO_16
    __BL2_SetPinMux(PAD_FUNC_0, rICU_MUX_08, 8);  //SPI2_PINMUX_MISO / SPI2_DQ3  / Mux->GPIO_17
    __BL2_SetPinMux(PAD_FUNC_0, rICU_MUX_04, 16); //SPI2_PINMUX_CLK  / SPI2_SCK
}


void __BL2_QSPI_PinMuxRelease(UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 12); //SPI2_PINMUX_CS0  / SPI2_CSN0 / Mux->GPIO_12
        __BL2_SetGPIODir(GPIO_PORT12, GPIO_DIR_IN); // Mux->GPIO_12
    }
    else // BOOTSTRAP_BOOT_EXTERNAL_MODE
    {
        __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 8);  //SPI2_PINMUX_CS1  / SPI2_CSN1 / Mux->GPIO_13
        __BL2_SetGPIODir(GPIO_PORT13, GPIO_DIR_IN); // Mux->GPIO_13
    }

    // PinMux SPI Port Release ...
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 24); //SPI1_PINMUX_MOSI / SPI2_DQ0
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 20); //SPI1_PINMUX_MISO / SPI2_DQ1
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 4); //SPI1_PINMUX_MISO / SPI2_DQ2
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_08, 8); //SPI1_PINMUX_MISO / SPI2_DQ3
    __BL2_SetPinMux(PAD_FUNC_4, rICU_MUX_04, 16); //SPI1_PINMUX_CLK / SPI2_SCK

    // Set GPIO InputMode
    __BL2_SetGPIODir(GPIO_PORT14, GPIO_DIR_IN);
    __BL2_SetGPIODir(GPIO_PORT15, GPIO_DIR_IN);
    __BL2_SetGPIODir(GPIO_PORT16, GPIO_DIR_IN);
    __BL2_SetGPIODir(GPIO_PORT17, GPIO_DIR_IN);
    __BL2_SetGPIODir(GPIO_PORT18, GPIO_DIR_IN);
}


void __BL2_SSP_CS_High(UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL2_SetGPIOData(GPIO_PORT12, GPIO_HIGH);
    }
    else
    {
        __BL2_SetGPIOData(GPIO_PORT13, GPIO_HIGH);
    }
}


void __BL2_SSP_CS_Low(UINT32 nCS)
{
    if(nCS == BOOTSTRAP_BOOT_SIP_FLASH)
    {
        __BL2_SetGPIOData(GPIO_PORT12, GPIO_LOW);
    }
    else
    {
        __BL2_SetGPIOData(GPIO_PORT13, GPIO_LOW);
    }
}

void __BL2_PLL_SetConfig(void)
{
    UINT32 nStable;
    UINT32 nTemp;
    UINT32 nWaitCount = 100000;


#if defined (__BL2_CPU192MHz_DDR096MHz__)

    /*
     * PLL Configuration ...
     * OSC  27MHz
     * PLL0 192000000
     * PLL1 297000000
     * PLL2  16000000
     */
    nTemp = (63 << PLL_NF) | (2 << PLL_NR) | (2 << PLL_OD);
    REGRW32(SYS_CON_BASE, rSCU_PLL0_CONFIG) = nTemp;

    nTemp = (21 << PLL_NF) | (0 << PLL_NR) | (1 << PLL_OD);
    REGRW32(SYS_CON_BASE, rSCU_PLL1_CONFIG) = nTemp;

    nTemp = (15<< PLL_NF) | (2 << PLL_NR) | (8 << PLL_OD);
    REGRW32(SYS_CON_BASE, rSCU_PLL2_CONFIG) = nTemp;

    REGRW32(SYS_CON_BASE, rSCU_PLL_BWADJ) = ((15<<PLL2_BWADJ)|(21<<PLL1_BWADJ)|(63<<PLL0_BWADJ)); 
    
#elif defined (__BL2_CPU108MHz_DDR108MHz__)

    /*
     * PLL Configuration ...
     * OSC  27MHz
     * PLL0 216000000
     * PLL1 297000000
     * PLL2  16000000
     */
    nTemp = (15 << PLL_NF) | (0 << PLL_NR) | (1 << PLL_OD);
    REGRW32(SYS_CON_BASE, rSCU_PLL0_CONFIG) = nTemp;

    nTemp = (21 << PLL_NF) | (0 << PLL_NR) | (1 << PLL_OD);
    REGRW32(SYS_CON_BASE, rSCU_PLL1_CONFIG) = nTemp;

    nTemp = (15<< PLL_NF) | (2 << PLL_NR) | (8 << PLL_OD);
    REGRW32(SYS_CON_BASE, rSCU_PLL2_CONFIG) = nTemp;

    REGRW32(SYS_CON_BASE, rSCU_PLL_BWADJ) = ((15<<PLL2_BWADJ)|(21<<PLL1_BWADJ)|(15<<PLL0_BWADJ));
    
#else

    /*
     * PLL Configuration ...
     * OSC  27MHz
     * PLL0 297000000
     * PLL1 297000000
     * PLL2  16000000
     */
    nTemp = (21 << PLL_NF) | (0 << PLL_NR) | (1 << PLL_OD);
    REGRW32(SYS_CON_BASE, rSCU_PLL0_CONFIG) = nTemp;

    nTemp = (21 << PLL_NF) | (0 << PLL_NR) | (1 << PLL_OD);
    REGRW32(SYS_CON_BASE, rSCU_PLL1_CONFIG) = nTemp;

    nTemp = (15<< PLL_NF) | (2 << PLL_NR) | (8 << PLL_OD);
    REGRW32(SYS_CON_BASE, rSCU_PLL2_CONFIG) = nTemp;

    REGRW32(SYS_CON_BASE, rSCU_PLL_BWADJ) = ((15<<PLL2_BWADJ)|(21<<PLL1_BWADJ)|(21<<PLL0_BWADJ));

#endif

    /*
     * PLL Setting Completed ...
     * */
    nTemp = (PLL2_RESET | PLL1_RESET | PLL0_RESET);
    REGRW32(SYS_CON_BASE, rSCU_PLL_ENABLE) = nTemp;



    /*
     * PLL Stable Waiting ...
     * */
    nStable = (PLL2_STBL | PLL1_STBL | PLL0_STBL);

    while(nWaitCount--)
    {
        SysDelay(1);

        nTemp = REGRW32(SYS_CON_BASE, rSCU_PLL_STABLE) & 0xF;
        if(nTemp == nStable)
        {
            break;
        }
    }



    /*
     * PLL0.1.2 Clock Select ...
     * */
    nTemp = (OUTPUT_PLL<<PLL2_OUTSEL) | (OUTPUT_PLL<<PLL1_OUTSEL) | (OUTPUT_PLL<<PLL0_OUTSEL);
    REGRW32(SYS_CON_BASE, rSCU_PLL_CLK_SEL) = nTemp;



    /*
     * System, CAN Clock Select ...
     * */
    nTemp = (SYS_PLL2<<SEL_CAN_CLK) | (SYS_PLL0<<SEL_SYS_CLK);
    REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_SEL) = nTemp;



    /*
     * System Clock Divider (ADC, CAN, DDR, APB, AXI, CPU, TS)
     * */
#if defined (__BL2_CPU192MHz_DDR096MHz__) 

    nTemp = (2<<DIV_ADC_CLK) | (0<<DIV_CAN_CLK) | (0<<DIV_DDR_CLK) | (2<<DIV_APB_CLK) | (1<<DIV_AXI_CLK) | (0<<DIV_CPU_CLK);
    REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV1) = nTemp;

    nTemp = (3<<DIV_ADC_SEL);
    REGRW32(SYS_CON_BASE, rSCU_SYS_VDO_CLK_DIV) = nTemp;

    nTemp = (5<<DIV_TS_CLK);
    REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV2) = nTemp;
    
#elif defined (__BL2_CPU108MHz_DDR108MHz__)

    nTemp = (2<<DIV_ADC_CLK) | (0<<DIV_CAN_CLK) | (0<<DIV_DDR_CLK) | (2<<DIV_APB_CLK) | (1<<DIV_AXI_CLK) | (1<<DIV_CPU_CLK);
    REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV1) = nTemp;

    nTemp = (3<<DIV_ADC_SEL);
    REGRW32(SYS_CON_BASE, rSCU_SYS_VDO_CLK_DIV) = nTemp;

    nTemp = (5<<DIV_TS_CLK);
    REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV2) = nTemp;
    
#else

    nTemp = (4<<DIV_ADC_CLK) | (0<<DIV_CAN_CLK) | (0<<DIV_DDR_CLK) | (2<<DIV_APB_CLK) | (1<<DIV_AXI_CLK) | (0<<DIV_CPU_CLK);
    REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV1) = nTemp;

    nTemp = (3<<DIV_ADC_SEL);
    REGRW32(SYS_CON_BASE, rSCU_SYS_VDO_CLK_DIV) = nTemp;

    nTemp = (7<<DIV_TS_CLK);
    REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV2) = nTemp;
    
#endif
}


/* End Of File */
