/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.h
*
*  @brief   : This file is implemented about main of MPW1 TEST VECTOR (FUNC1 SF)
*
*  @author  :  / TS Group. SoCSW Team
*
*  @date    : 2016.07.28
*
*  @version : Version 0.0.1
*
********************************************************************************
*  History  :
*
********************************************************************************
*/

#ifndef __MAIN_H__
#define __MAIN_H__


/*
********************************************************************************
*               INCLUDE FILES
********************************************************************************
*/

#include "Test.h"
#include "Type.h"
#include "Apache35.h"

#include "GIC.h"
#include "GPIO.h"
#include "UART.h"
#include "I2C.h"
#include "CAN.h"
#include "Timer.h"
#include "SCU.h"
#include "GPIO.h"
#include "CAN.h"
#include "sFlash.h"
#include "ADC.h"


/*
********************************************************************************
*               DEFINITIONS
********************************************************************************
*/

/* APACHE3.5 Test Vector Version */

#define BL2_M1_TV_VER_MAJOR			1
#define BL2_M1_TV_VER_MINOR1		1
#define BL2_M1_TV_VER_MINOR2       	0


//#define DEBUGMSG(fmt, args...)  \
//        do { ncDrv_UART_printf(fmt, ## args); } while(0)

#define SRAM_BASE_ADDRESS 0x04000000


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum
{
    TV_UART_0,
	TV_UART_1,
	TV_CAN,
	TV_I2C,
	TV_TIMER_0,
	TV_TIMER_1,
	TV_SUB_TIMER_0,
	TV_SUB_TIMER_1,
	TV_SUB_TIMER_2,
	TV_SPI,
	TV_QSPI,

	TV_MAX
} TEST_VECTOR;  // Test Vector Number


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/


#endif /* __MAIN_H__ */
