/*
********************************************************************************
*
*  Copyright (C) 2013 NEXTCHIP Inc. All rights reserved.
*
*  @file    : CAN_Drv.h
*
*  @brief   : Apache3 CAN2.0 module driver header file
*
*  @author  : Alessio / Automotive SoC Software Team
*
*  @date    : 2013.11.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 2013.11.18 - CAN2.0 basic driver modified by Alessio
*
********************************************************************************
*/

#ifndef __CAN_DRV_H__
#define __CAN_DRV_H__


/********* test define ***********/

//CAN_Lib.h

typedef enum
{
    CAN_MSGOBJ_RESERVED,
    CAN_MSGOBJ_ACTIVE,
    MAX_OF_CAN_MSGOBJ_STT
} eCAN_MSGOBJ_STT;

typedef enum
{
    CAN_CDR_BASIC_MODE,
    CAN_CDR_PERI_MODE,
    MAX_OF_CAN_CDR_MODE
} eCAN_CDR_MODE;

typedef enum
{
    CAN_FI_STANDARD_FORMAT,
    CAN_FI_EXTENDED_FORMAT,
    MAX_OF_CAN_FI_FRAME_FORMAT
} eCAN_FI_FRAME;

typedef enum
{
    CAN_FI_DATA_FRAME,
    CAN_FI_REMOTE_FRAME,
    MAX_OF_CAN_FI_RTR_FRAME
} eCAN_FI_RTR;

typedef enum
{
    CAN_BPS_10KBPS,     // 6.7km Class A max
    CAN_BPS_20KBPS,     // 3.3km Class B
    CAN_BPS_50KBPS,     // 1.3km Class B
    CAN_BPS_100KBPS,    // 620m  Class B
    CAN_BPS_125KBPS,    // 530m  Class B max
    CAN_BPS_250KBPS,    // 270m  Class C
    CAN_BPS_500KBPS,    // 130m  Class C
    CAN_BPS_800KBPS,    // 80m   Class C
    CAN_BPS_1000KBPS,   // 40m   Class C max
    MAX_OF_CAN_BPS
} eCAN_KBPS;

typedef struct
{
    eCAN_KBPS     baudrate;     // 1kbps ~ 1000kbps
    eCAN_FI_FRAME format;       // 0 - standard, 1 - extended frame format
} tCAN_INFO, *ptCAN_INFO;


typedef struct
{
    unsigned int id;            // 11bit or 29bit identifier
    unsigned int length;        // length of data field in bytes
    unsigned char data[8] __attribute__ ((aligned (8)));      // data field

    eCAN_MSGOBJ_STT objch;      // message object active status
    eCAN_FI_FRAME format;       // 0 - standard, 1 - extended frame format
    eCAN_FI_RTR rtr;            // 0 - data frame, 1 - remote frame
} tCAN_MSG, *ptCAN_MSG;

typedef struct
{
    UINT32 acrId;               // Acceptance code register identifier
    UINT32 amrId;               // Acceptance mask register identifier

    eCAN_KBPS baudrate;         // Bus Timing
    tCAN_INFO info;             // Can information structure
} tCAN_PARAM, *ptCAN_PARAM;



#define MSGERR                      (0x1<<0)    // Error message enable
#define MSGWARN                     (0x1<<1)    // Warning message enable
#define MSGINFO                     (0x1<<2)    // Information message enable
#define MSGON                       (0x1<<3)    // Force message enable
/********************************/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
* Compile Option
*/

#define CAN_MESSAGE_NUM_MAX             4
#define CAN_MESSAGE_BUFFER_RING         1   // 1 : Ring Buffer, 0 : Working
#define CAN_BUS_TIMING_CALC_MESSAGE     1


/*
* GPIO REGISTER STRUCTURE
*/

#define rCAN_0_BASE         APACHE_CAN_BASE
#define rCAN_1_BASE         APACHE_CAN_BASE

// BasicCAN Register Map
                                    //    OM / RM, (Operation Mode / Reset Mode)
#define rCANB_CR            0x0000  // 00 RW / RW, Contro Register
#define rCANB_CMR           0x0004  // 01 WO / WO, Command Register
#define rCANB_SR            0x0008  // 02 RO / RO, Status Register
#define rCANB_IR            0x000C  // 03 RO / RO, Interrupt Register

#define rCANB_ACR           0x0010  // 04 -- / RW, Acceptance Code Register
#define rCANB_AMR           0x0014  // 05 -- / RW, Acceptance Mask Register
#define rCANB_BTR0          0x0018  // 06 RO / RW, Bus Timing 0 Register
#define rCANB_BTR1          0x001C  // 07 RO / RW, Bus Timing 1 Register

#define rCANB_RESERVED0     0x0020  // 08 -- / --, Reserved Register
#define rCANB_RESERVED1     0x0024  // 09 -- / --, Reserved Register
#define rCANB_TID1          0x0028  // 10 RW / --, Transmit Identifier Byte 1 Register
#define rCANB_TID2          0x002C  // 11 RW / --, Transmit Identifier Byte 2 Register

#define rCANB_TXDATA1       0x0030  // 12 RW / --, Transmit Data Byte 1 Register
#define rCANB_TXDATA2       0x0034  // 13 RW / --, Transmit Data Byte 2 Register
#define rCANB_TXDATA3       0x0038  // 14 RW / --, Transmit Data Byte 3 Register
#define rCANB_TXDATA4       0x003C  // 15 RW / --, Transmit Data Byte 4 Register

#define rCANB_TXDATA5       0x0040  // 16 RW / --, Transmit Data Byte 5 Register
#define rCANB_TXDATA6       0x0044  // 17 RW / --, Transmit Data Byte 6 Register
#define rCANB_TXDATA7       0x0048  // 18 RW / --, Transmit Data Byte 7 Register
#define rCANB_TXDATA8       0x004C  // 19 RW / --, Transmit Data Byte 8 Register

#define rCANB_RID1          0x0050  // 20 RW / RW, Receive Identifier Byte 1 Register
#define rCANB_RID2          0x0054  // 21 RW / RW, Receive Identifier Byte 2 Register
#define rCANB_RXDATA1       0x0058  // 22 RW / RW, Receive Data Byte 1 Register
#define rCANB_RXDATA2       0x005C  // 23 RW / RW, Receive Data Byte 2 Register

#define rCANB_RXDATA3       0x0060  // 24 RW / RW, Receive Data Byte 3 Register
#define rCANB_RXDATA4       0x0064  // 25 RW / RW, Receive Data Byte 4 Register
#define rCANB_RXDATA5       0x0068  // 26 RW / RW, Receive Data Byte 5 Register
#define rCANB_RXDATA6       0x006C  // 27 RW / RW, Receive Data Byte 6 Register

#define rCANB_RXDATA7       0x0070  // 28 RW / RW, Receive Data Byte 7 Register
#define rCANB_RXDATA8       0x0074  // 29 RW / RW, Receive Data Byte 8 Register
#define rCANB_RESERVED2     0x0078  // 30 -- / --, Reserved Register
#define rCANB_CDR           0x007C  // 31 RW / RW, Clock Divider Register


// PeriCAN Register Map
                                    //    OM / RM, (Operation Mode / Reset Mode)
#define rCANP_MOD           0x0000  // 00 RW / RW, Mode Register
//#define rCANB_CMR           0x0004  // 01 WO / WO, Command Register
//#define rCANB_SR            0x0008  // 02 RO / RO, Status Register
//#define rCANB_IR            0x000C  // 03 RO / RO, Interrupt Register

#define rCANP_IER           0x0010  // 04 RW / RW, Interrupt Enable Register
#define rCANP_RESERVED0     0x0014  // 05 -- / --, Reserved Register
//#define rCANB_BTR0          0x0018  // 06 RO / RW, Bus Timing 0 Register
//#define rCANB_BTR1          0x001C  // 07 RO / RW, Bus Timing 1 Register

#define rCANP_RESERVED1     0x0020  // 08 -- / --, Reserved Register
#define rCANP_RESERVED2     0x0024  // 09 -- / --, Reserved Register
#define rCANP_RESERVED3     0x0028  // 10 -- / --, Reserved Register
#define rCANP_ALC           0x002C  // 11 RO / , Arbitration Lost Capture Register

#define rCANP_ECC           0x0030  // 12 RO / RO, Error Code Capture Register
#define rCANP_EWLR          0x0034  // 13 RO / RW, Error Warning Limit Register
#define rCANP_RXERR         0x0038  // 14 RO / RW, RX Error Counter Register
#define rCANP_TXERR         0x003C  // 15 RO / RW, TX Error Counter Register

#define rCANP_ACR           0x0040  // 16 RW / --, Acceptance Code Register
#define rCANP_FIR           0x0040  // 16 RW / --, Rx and TX Frame Infomation Register

// ------- REG_CAN_RX_SFF Typedef Structure Reference
// ------- REG_CAN_TX_SFF Typedef Structure Reference
// ------- REG_CAN_RX_EFF Typedef Structure Reference
// ------- REG_CAN_TX_EFF Typedef Structure Reference
// ------- REG_CAN_ACCEPTANCE Typedef Structure Reference

#define rCANP_RMC           0x0074  // 29 RO / RO, RX Message Counter Register
#define rCANP_RESERVED4     0x0078  // 30 -- / --, Reserved Register
//#define rCANB_CDR           0x007C  // 31 RW / RW, Clock Divider Register


/*
* GPIO REGISTER BIT DESCRIPTION
*/

//---- Register-0 : BasicCAN Control Register.
#define CAN_CR_FIE          (0x1E)  // Full Interrupt Enable
#define CAN_CR_OIE          (1<<4)  // Overrun Interrupt Enable
#define CAN_CR_EIE          (1<<3)  // Error Interrupt Enable
#define CAN_CR_TIE          (1<<2)  // Transmit Interrupt Enable
#define CAN_CR_RIE          (1<<1)  // Receive Interrupt Enable
#define CAN_CR_RR           (1<<0)  // Reset Request

//---- Register-0 : PeriCAN Mode Register.
#define CAN_MOD_AFM         (1<<3)  // Acceptance Filter Mode
#define CAN_MOD_STM         (1<<2)  // Self Test Mode
#define CAN_MOD_LOM         (1<<1)  // Listen Only Mode
#define CAN_MOD_RM          (1<<0)  // Reset Mode

//---- Register-1 : Command Register.
#define CAN_CMR_SRR         (1<<4)  // Self reception request
#define CAN_CMR_CDO         (1<<3)  // Clear Data Overrun
#define CAN_CMR_RRB         (1<<2)  // Release Receive Buffer
#define CAN_CMR_AT          (1<<1)  // Abort Transmission
#define CAN_CMR_TR          (1<<0)  // Transmission request

//---- Register-2 : Status Register.
#define CAN_SR_BS           (1<<7)  // Error, Bus Status
#define CAN_SR_ES           (1<<6)  // Error, Error Status
#define CAN_SR_TS           (1<<5)  // Transmit Status
#define CAN_SR_RS           (1<<4)  // Receive Status
#define CAN_SR_TCS          (1<<3)  // Transmit Complete Status
#define CAN_SR_TBS          (1<<2)  // Transmit Buffer Status
#define CAN_SR_DOS          (1<<1)  // Error, Data Overrun Status
#define CAN_SR_RBS          (1<<0)  // Receive Buffer Status

//---- Register-3 : Interrupt Register.
#define CAN_IR_BEI          (1<<7)  // (PeriCAN only) Bus Error Interrupt
#define CAN_IR_ALI          (1<<6)  // (PeriCAN only) Arbitration Lost Interrupt
#define CAN_IR_EPI          (1<<5)  // (PeriCAN only) Error Passive Interrupt
#define CAN_IR_DOI          (1<<3)  // Data Overrun Interrupt
#define CAN_IR_EI           (1<<2)  // Error Warning Interrupt
#define CAN_IR_TI           (1<<1)  // Transmit Interrupt
#define CAN_IR_RI           (1<<0)  // Receive Interrupt

//---- Register-4 : Interrupt Enable Register.
#define CAN_IER_FIE         (0xFF)  // Full Interrupt Enable
#define CAN_IER_BEIE        (1<<7)  // Bus Error Interrupt Enable
#define CAN_IER_ALIE        (1<<6)  // Arbitration Lost Interrupt Enable
#define CAN_IER_EPIE        (1<<5)  // Error Passive Interrupt Enable
#define CAN_IER_DOIE        (1<<3)  // Data Overrun Interrupt Enable
#define CAN_IER_EIE         (1<<2)  // Error Warning Interrupt Enable
#define CAN_IER_TIE         (1<<1)  // Transmit Interrupt Enable
#define CAN_IER_RIE         (1<<0)  // Receive Interrupt Enable

//---- Register-6 : Bus Timing 0 Register.
#define CAN_BTR0_SJW_SHIFT  (6) // Synchronization Jump 2bit
#define CAN_BTR0_BRP_SHIFT  (0) // Baud Rate Prescaler 6bit

/*
    SJW ...
    tSJW = tscl * (2 * SJW.1 + SJW.0 + 1)

    BRP ...
    tscl = 2 * tCLK * (32 * BRP.5 + 16 * BRP.4 + 8 * BRP.3 + 4 * BRP.2 + 2 *
BRP.1 + BRP.0 + 1)
    where tCLK = time period of the XTAL frequency = 1/fXTAL
*/

//---- Register-7 : Bus Timing 1 Register.
#define CAN_BTR1_SAM_SHIFT      (7) // Sampling
#define CAN_BTR1_TSEG2_SHIFT    (4) // Time Segment2 3bit
#define CAN_BTR1_TSEG1_SHIFT    (0) // Time Segment1 4bit
// eCAN_BTR1_SAM Typedef Enum Reference

/*
tSYNCSEG = 1 * tscl
tTSEG1 = tscl * (8 * TSEG1.3 + 4 * TSEG1.2 + 2 * TSEG1.1 * TSEG1.0 + 1)
tTSEG2 = tscl * (4 * TSEG2.2 + 2 * TSEG2.1 + TSEG2.0 + 1)
*/

//---- Register-11 : Arbitration Lost Capture Register.
// SJA1000 datasheet pgae-35 table-18 reference

//---- Register-12 : Error Code Capture Register.
#define CAN_ECC_ERR_SHIFT       (6)     // Error Code
#define CAN_ECC_DIR             (1<<5)  // Transfer direction
#define CAN_ECC_SEG_MASK        (0x1F)  // Segmentation field mask
// SJA1000 datasheet pgae-37 table-21 reference
// eCAN_ECC_ERRC Typedef Enum Reference

//---- Register-16 : Frame Information Register.
#define CAN_FI_FF_SHIFT         (7) // Frame Format
#define CAN_FI_RTR_SHIFT        (6) // Remote Transmission Request
// eCAN_FI_RTR_FRAME Typedef Enum Reference
// eCAN_FI_FRAME_FORMAT Typedef Enum Reference

//---- Register-31 : Clock Driver Register.
#define CAN_CDR_MODE_SHIFT      (7) // CAN Mode
#define CAN_CDR_CLKOFF          (1<<3) // Clock off
// eCAN_CDR_MODE Typedef Enum Reference


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum
{
    CAN_NONE,
    CAN_DONE,
    MAX_OF_CAN_CH_INTR
} eCAN_CH_INTR;

typedef enum
{
    CAN_BIT_ERROR,
    CAN_FORM_ERROR,
    CAN_STUFF_ERROR,
    CAN_OTHER_TYPE_OF_ERROR,
    MAX_OF_CAN_ECC_ERRC
} eCAN_ECC_ERRC;

typedef enum
{
    CAN_BTR1_SAM_CLASS_C,   // Class C high speed buses
    CAN_BTR1_SAM_CLASS_AB,  // ClassA,B low/medium speed buses
    MAX_OF_CAN_BTR1_SAM
} eCAN_BTR1_SAM;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
                                //             OM / RM, (Operation Mode / Reset Mode)
    unsigned int CR;            // 0x0000, 00, RW / RW, Contro Register
    unsigned int CMR;           // 0x0004, 01, WO / WO, Command Register
    unsigned int SR;            // 0x0008, 02, RO / RO, Status Register
    unsigned int IR;            // 0x000C, 03, RO / RO, Interrupt Register

    unsigned int ACR;           // 0x0010, 04, -- / RW, Acceptance Code Register
    unsigned int AMR;           // 0x0014, 05, -- / RW, Acceptance Mask Register
    unsigned int BTR0;          // 0x0018, 06, -- / RW, Bus Timing 0 Register
    unsigned int BTR1;          // 0x001C, 07, -- / RW, Bus Timing 1 Register

    unsigned int RESERVED0;     // 0x0020, 08, -- / --, Reserved Register
    unsigned int RESERVED1;     // 0x0024, 09, -- / --, Reserved Register

    unsigned int TID1;          // 0x0028, 10, RW / --, Transmit Identifier Byte 1 Register
    unsigned int TID2;          // 0x002C, 11, RW / --, Transmit Identifier Byte 2 Register
    unsigned int TXDATA[8];     // 0x0030, 12~19, RW / --, Transmit Data Byte Register

    unsigned int RID1;          // 0x0050, 20, RW / RW, Receive Identifier Byte 1 Register
    unsigned int RID2;          // 0x0054, 21, RW / RW, Receive Identifier Byte 2 Register
    unsigned int RXDATA[8];     // 0x0058, 22~29, RW / RW, Receive Data Byte Register

    unsigned int RESERVED2;     // 0x0078, 30, -- / --, Reserved Register
} REG_CAN_BASIC;

typedef struct
{
    unsigned int RXFI;          // 0x0040, 16, RW, RX Frame Infomation Register
    unsigned int RXID[2];       // 0x0050, 17~18, RW, RX Frame Identifier Register
    unsigned int RXDATA[8];     // 0x0058, , RW, RX Data Register
} REG_CAN_RX_SFF;

typedef struct
{
    unsigned int TXFI;          // 0x0040, 16, RW, TX Frame Infomation Register
    unsigned int TXID[2];       // 0x0028, 10~11, RW, TX Frame Identifier Register
    unsigned int TXDATA[8];     // 0x0030, 12~19, RW, TX Data Register
} REG_CAN_TX_SFF;

typedef struct
{
    unsigned int RXFI;          // 0x0040, 16, RW, RX Frame Infomation Register
    unsigned int RXID[4];       // 0x0044, 17~20, RW, RX Frame Identifier Register
    unsigned int RXDATA[8];     // 0x0054, 21~28, RW, RX Data Register
} REG_CAN_RX_EFF;

typedef struct
{
    unsigned int TXFI;          // 0x0040, 16, RW, TX Frame Infomation Register
    unsigned int TXID[4];       // 0x0044, 17~20, RW, TX Frame Identifier Register
    unsigned int TXDATA[8];     // 0x0054, 21~28, RW, TX Data Register
} REG_CAN_TX_EFF;

typedef struct
{
    unsigned int ACR[4];        // 0x0040, 16~19, RW, Acceptance Code Register
    unsigned int AMR[4];        // 0x0050, 20~23, RW, Acceptance Mask Register
} REG_CAN_ACCEPTANCE;


extern volatile REG_CAN_BASIC  *gp_RegCanBasic;
extern volatile REG_CAN_RX_SFF *gp_RegCanRxSFF;
extern volatile REG_CAN_TX_SFF *gp_RegCanTxSFF;

extern volatile REG_CAN_RX_EFF *gp_RegCanRxEFF;
extern volatile REG_CAN_TX_EFF *gp_RegCanTxEFF;
extern volatile REG_CAN_ACCEPTANCE *gp_RegCanAcceptance;

extern tCAN_MSG gp_CanRxMsgBox[CAN_MESSAGE_NUM_MAX];

extern tCAN_INFO gCanInfo;
extern eCAN_CH_INTR gCanInterruptDone;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

UINT32 ncDrv_CAN_BaseAddr(void);
void ncDrv_CAN_Initialize(void);
void ncDrv_CAN_Deinitialize(void);

void ncDrv_CAN_IRQ_Handler(UINT32 nIrqNum);
void ncDrv_CAN_ISR_Handler(void);
INT32 ncDrv_CAN_ConnectUserHandler(PrVoid UserHandler);
INT32 ncDrv_CAN_DisConnectUserHandler(void);
BOOL ncDrv_CAN_GetInterruptDone(void);

int ncDrv_CAN_SetRxMsgBoxIndex(void);
int ncDrv_CAN_GetRxMsgBoxIndex(void);
void ncDrv_CAN_ClearRxMsgBoxIndex(void);

UINT8 ncDrv_CAN_GetErrorStatus(void);
UINT8 ncDrv_CAN_GetIntrruptStatus(void);

UINT8 ncDrv_CAN_GetCanMode(void);
void ncDrv_CAN_SetCanMode(void);
void ncDrv_CAN_SetBusTimingBaudrate_kvaser(UINT32 inputclk, eCAN_KBPS index);
void ncDrv_CAN_SetAcceptanceFilter(UINT8 format, UINT32 code, UINT32 mask);
int ncDrv_CAN_SendComplete(void);


// PeriCAN Mode (CAN2.0B)
extern void ncDrv_CAN_ISRPeriCANHandler(void);
extern int ncDrv_CAN_PeriSFF_Receive(tCAN_MSG *sffmsg);
extern int ncDrv_CAN_PeriEFF_Receive(tCAN_MSG *effmsg);
extern int ncDrv_CAN_PeriSetup(UINT32 inputclk, tCAN_PARAM *config);
extern int ncDrv_CAN_PeriSend(tCAN_MSG *txmsg);
extern int ncDrv_CAN_PeriReceive(tCAN_MSG *rxmsg);
extern int ncDrv_CAN_PeriRemoteRequest(tCAN_MSG *rxmsg);

extern int ncDrv_CAN_PeriSelfTest_Setup(UINT32 inputclk, tCAN_PARAM *config);
extern int ncDrv_CAN_PeriSelfTest_Send(tCAN_MSG *txmsg);

#endif  /* __CAN_DRV_H__ */


/* End Of File */
