/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : I2C_SlaveDrv.c
*
*  @brief   : I2C module master mode driver source file
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.07
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : Argo I2C IP / Revision: 0.5
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Test.h"
#include "Apache35.h"
#include "I2C.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define I2C_TIMEOUT     10


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncDrv_I2C_MasterInitialize(tI2C_INFO *i2cinfo)
{
    eI2C_CH channel;
    UINT32 srcClock, dstClock;

    channel = i2cinfo->channel;

    gI2cInfo[channel] = *i2cinfo;

    srcClock = gI2cInfo[channel].master.srcClock;
    dstClock = gI2cInfo[channel].master.clock;

    ncDrv_I2C_SetClock(channel, srcClock, dstClock);

    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) &= ~ISR_MASK;

#if 1 // alessio_20160110 Interrupt Disable
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_IER) = 0;
#else
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_IER) |= (IER_MACKP|IER_MACK);
#endif

    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_OPR) = OPR_CORE_EN;

    ncDrv_I2C_SetOpMode(channel, IM_MTX);

    gI2cInfo[channel].master.status = I2C_IMS_IDLE;
    gI2cInfo[channel].master.txIdx = 0;

    ncDrv_I2C_SetByteOrder(channel, gI2cInfo[channel].byteOrder);
}


void ncDrv_I2C_mSetStart(eI2C_CH channel)
{
#if 1
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) &= ~ISR_MASK;
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_OPR) = OPR_CORE_EN;

    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_CONR) = 0;

    ncDrv_I2C_SetOpMode(channel, IM_MTX);    // add
#else
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) = 0;
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_IER) = 0;
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_OPR) = OPR_CORE_EN;
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_CONR) &= ~(0x1<<4);
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_CONR) |= IM_MTX;
#endif
}


void ncDrv_I2C_mSetStop(eI2C_CH channel)
{
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_LCMR) = LCMR_STOP | LCMR_RESUME;
}


UINT8 ncDrv_I2C_mWaitEvent(eI2C_CH channel)
{
    unsigned int isr, lsr, waiteDelay = I2C_TIME_OUT;

    while(waiteDelay > 0)
    {
        isr = REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR);
        lsr = REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_LSR);

        //DEBUGMSG_SDK(MSGINFO, "isr/lsr = 0x%x, 0x%x\n", isr, lsr);

        ncDrv_I2C_Delay(1);

        if(isr & ISR_AL)
        {
            DEBUGMSG_SDK(MSGINFO, "%x\n", isr);
            REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) = 0;
            return 1;
        }

        if(isr & ISR_MACK)
        {
            REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) &= ~0x1;

            if(lsr & LSR_NACK) return 1;

            break;
        }

        if(isr & ISR_MACKP)
        {
            REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) &= ~0x2;
            break;
        }

        waiteDelay--;
        if(waiteDelay == 0)
        {
            //DEBUGMSG_SDK(MSGERR, "Wait timeout %d\n", waiteDelay);
            return 1;
        }
    }

    return 0;
}


UINT8 ncDrv_I2C_mReceiveData(eI2C_CH channel, UINT8 *pBuffer)
{
    UINT8 temp;

    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_LCMR) |= LCMR_RESUME;

    if(ncDrv_I2C_mWaitEvent(channel) != 0)
    {
        return 1;
    }

    temp = (UINT8)REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_MRXR);
    *pBuffer = temp;

    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) &= (0x1 << 1);

    return 0;
}


UINT8 ncDrv_I2C_mSendData(eI2C_CH channel, UINT8 Buffer, UINT8 StartBit)
{
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_MTXR) = Buffer;

    if(StartBit)
    {
        REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_LCMR) = (LCMR_START | LCMR_RESUME);
    }
    else
    {
        REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_LCMR) = LCMR_RESUME;
    }

    if(ncDrv_I2C_mWaitEvent(channel) != 0)
    {
        return 1;
    }

    return 0;
}


UINT8 ncDrv_I2C_mSlaveAddress(eI2C_CH channel, UINT16 SlaveAddr, UINT8 SlaveBit, UINT8 read_or_write)
{
    if(SlaveBit == I2C_DEV_10BIT)
    {
        if(ncDrv_I2C_mSendData(channel, (SlaveAddr >> 7) & 0x06 | 0xf0 | read_or_write, 1) != 0)
        {
            return 1;
        }

        if(ncDrv_I2C_mSendData(channel, (SlaveAddr) & 0xff | read_or_write, 0) != 0)
        {
            return 1;
        }
    }
    else
    {
        if(ncDrv_I2C_mSendData(channel, SlaveAddr | read_or_write, 1) != 0)
        {
            return 1;
        }
    }

    return 0;
}


UINT8 ncDrv_I2C_mRegAddress(eI2C_CH channel, UINT16 RegAddress, UINT8 AddressByte)
{
    do
    {
        AddressByte--;

        if(ncDrv_I2C_mSendData(channel, (RegAddress >> (AddressByte ? 8 : 0)) & 0xff, 0) != 0)
        {
            DEBUGMSG_SDK(MSGINFO, "Error, Send Address\n");
            return 1;
        }
    }
    while(AddressByte);

    return 0;
}


INT32 ncDrv_I2C_mSendSingleByte(eI2C_CH channel, UINT32 Data, UINT32 Length, eI2C_LENGTH_TYPE Type)
{
    INT32 Result = NC_SUCCESS;

    do
    {
        if(Length == 1)
        {
            if((Result = ncDrv_I2C_mSendData(channel, (Data&0xFF), 0)) != NC_SUCCESS)
            {
                Result = NC_FAILURE;
                DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Data\n");
                break;
            }
        }
        else
        {
            // only 2byte data send ...
            if((Result = ncDrv_I2C_mSendData(channel, (Data>>8) & 0xFF, 0)) != NC_SUCCESS)
            {
                Result = NC_FAILURE;
                DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Data\n");
                break;
            }
        }

        Length--;
    }
    while(Length);

    return Result;
}


INT32 ncDrv_I2C_mSendMultiByte(eI2C_CH channel, UINT32 Data, UINT32 Length, eI2C_LENGTH_TYPE Type)
{
    INT32 Result = NC_SUCCESS;

    if(Type == I2C_ADDR_8_DATA_8 || Type == I2C_ADDR_16_DATA_8)
    {
        UINT8 *pBuffer;

        pBuffer = (UINT8 *)Data;

        do
        {
            if((Result = ncDrv_I2C_mSendData(channel, (UINT8)*pBuffer, 0)) != NC_SUCCESS)
            {
                Result = NC_FAILURE;
                DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Data\n");
                break;
            }

            pBuffer++;
            Length-=1;
        }
        while(Length);
    }
    else
    {
        UINT16 *pBuffer;
        //UINT16 temp;

        pBuffer = (UINT16 *)Data;

        do
        {
            if((Result = ncDrv_I2C_mSendData(channel, (UINT8)(*pBuffer>>8) & 0xFF, 0)) != NC_SUCCESS)
            {
                Result = NC_FAILURE;
                DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Data\n");
                break;
            }

            if((Result = ncDrv_I2C_mSendData(channel, (UINT8)*pBuffer, 0)) != NC_SUCCESS)
            {
                Result = NC_FAILURE;
                DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Data\n");
                break;
            }

            pBuffer++;
            Length-=2;
        }
        while(Length);
    }

    return Result;
}


UINT32 ncDrv_I2C_mReadData(eI2C_CH channel, UINT8 Device, UINT16 Address, void *pBuf, UINT32 Length, eI2C_LENGTH_TYPE Type)
{
    UINT8 *pdata;
    UINT8 SlaveBit = 0;
    UINT8 AddressByte = 1;
    UINT8 i, temp, offset, swapSize;
    INT32 Result = NC_SUCCESS;

    swapSize = Length;
    SlaveBit = I2C_DEV_7BIT;

    switch(Type)
    {
        case I2C_ADDR_8_DATA_8:   AddressByte = 1; Length *= 1; break;
        case I2C_ADDR_8_DATA_16:  AddressByte = 1; Length *= 2; break;
        case I2C_ADDR_16_DATA_8:  AddressByte = 2; Length *= 1; break;
        case I2C_ADDR_16_DATA_16: AddressByte = 2; Length *= 2; break;
    }

    pdata = (UINT8 *)pBuf;

    ncDrv_I2C_mSetStart(channel);

    if((Result = ncDrv_I2C_mSlaveAddress(channel, Device, SlaveBit, I2C_WRITE)) != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Device ID\n");
        goto RSTOP;
    }

    if((Result = ncDrv_I2C_mRegAddress(channel, Address, AddressByte)) != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Address\n");
        goto RSTOP;
    }

    if((Result = ncDrv_I2C_mSlaveAddress(channel, Device, SlaveBit, I2C_READ)) != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Restart Device ID\n");
        goto RSTOP;
    }

    ncDrv_I2C_SetOpMode(channel, IM_MRX);

    do
    {
        if(Length == 1)
        {
            if((Result = ncDrv_I2C_mReceiveData(channel, pdata)) != NC_SUCCESS)
            {
                DEBUGMSG_SDK(MSGINFO, "Error, I2C Receive Data\n");
                goto RSTOP;
            }

            ncDrv_I2C_SetNack(channel);
        }
        else
        {
            if((Result = ncDrv_I2C_mReceiveData(channel, pdata)) != NC_SUCCESS)
            {
                DEBUGMSG_SDK(MSGINFO, "Error, I2C Receive Data\n");
                goto RSTOP;
            }

            ncDrv_I2C_SetAck(channel);
        }

        pdata++;
        Length--;
    }
    while(Length);

    if((Type == I2C_ADDR_8_DATA_16) || (Type == I2C_ADDR_16_DATA_16))
    {
        if(ncDrv_I2C_GetByteOrder(channel) == I2C_LITTLE_ENDIAN)
        {
            pdata = (UINT8 *)pBuf;

            for(i = 0; i < swapSize; i++)
            {
                offset = i*2;

                temp = pdata[offset];
                pdata[offset]   = pdata[offset+1];
                pdata[offset+1] = temp;
            }
        }
    }

RSTOP:

    ncDrv_I2C_mSetStop(channel);

    return Result;
}


UINT32 ncDrv_I2C_mWriteData(eI2C_CH channel, UINT8 Device, UINT16 Address, UINT32 Data, UINT32 Length, eI2C_LENGTH_TYPE Type)
{
    UINT8 burst = 0;
    UINT8 SlaveBit = 0;
    UINT8 AddressByte = 1;
    INT32 Result = NC_SUCCESS;

    SlaveBit = I2C_DEV_7BIT;
    burst = Length-1;   // burst : 0 byte, 1 ~ : Variable byte

    switch(Type)
    {
        case I2C_ADDR_8_DATA_8:   AddressByte = 1; Length *= 1; break;
        case I2C_ADDR_8_DATA_16:  AddressByte = 1; Length *= 2; break;
        case I2C_ADDR_16_DATA_8:  AddressByte = 2; Length *= 1; break;
        case I2C_ADDR_16_DATA_16: AddressByte = 2; Length *= 2; break;
    }

    ncDrv_I2C_mSetStart(channel);

    if((Result = ncDrv_I2C_mSlaveAddress(channel, Device, SlaveBit, I2C_WRITE)) != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGERR, "Error, I2C Send Device ID 0x%X\n", Device);
        goto WSTOP;
    }

    if((Result = ncDrv_I2C_mRegAddress(channel, Address, AddressByte)) != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGERR, "Error, I2C Send Address 0x%X\n", Address);
        goto WSTOP;
    }

    if(!burst)
    {
        Result = ncDrv_I2C_mSendSingleByte(channel, Data, Length, Type);
        if(Result != NC_SUCCESS)
        {
            DEBUGMSG_SDK(MSGERR, "Error, I2C Send Single-Data\n");
            goto WSTOP;
        }
    }
    else
    {
        Result = ncDrv_I2C_mSendMultiByte(channel, Data, Length, Type);
        if(Result != NC_SUCCESS)
        {
            DEBUGMSG_SDK(MSGERR, "Error, I2C Send Multi-Data\n");
            goto WSTOP;
        }
    }

    ncDrv_I2C_SetNack(channel);

WSTOP:

    ncDrv_I2C_mSetStop(channel);

    return Result;
}


#if 0
UINT32 ncDrv_I2C_mWriteBurst(eI2C_CH channel, UINT16 Device, UINT16 Address, UINT8 *pBuf, UINT32 Length, eI2C_ADDR_LEN Type)
{
    UINT8 *pdata;
    UINT8 SlaveBit = 0;
    UINT8 AddressByte = 0x1; 
    INT32 Result = NC_SUCCESS;

    SlaveBit = I2C_DEV_7BIT;

    if(Type == I2C_ADDR_16BIT)
    {
        AddressByte = 0x2; 
    }

    pdata = pBuf;

    ncDrv_I2C_mSetStart(channel);

    if((Result = ncDrv_I2C_mSlaveAddress(channel, Device, SlaveBit, I2C_WRITE)) != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Device ID\n");
        goto BWSTOP;
    }

    if((Result = ncDrv_I2C_mRegAddress(channel, Address, AddressByte)) != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Address\n");
        goto BWSTOP;
    }

    do
    {
        if((Result = ncDrv_I2C_mSendData(channel, *pdata, 0)) != NC_SUCCESS)
        {
            DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Data\n");
            goto BWSTOP;
        }

        pdata++;
        Length--;
    }
    while(Length);

    ncDrv_I2C_SetNack(channel);

BWSTOP:

    ncDrv_I2C_mSetStop(channel);

    return Result;
}


UINT32 ncDrv_I2C_mReadBurst(eI2C_CH channel, UINT16 Device, UINT16 Address, UINT8 *pBuf, UINT32 Length, eI2C_ADDR_LEN Type)
{
    UINT8 *pdata;
    UINT8 SlaveBit = 0;
    UINT8 AddressByte = 0x1;
    INT32 Result = NC_SUCCESS;

    SlaveBit = I2C_DEV_7BIT;

    if(Type == I2C_ADDR_16BIT)
    {
        AddressByte = 0x2; 
    }

    pdata = pBuf;

    ncDrv_I2C_mSetStart(channel);

    if((Result = ncDrv_I2C_mSlaveAddress(channel, Device, SlaveBit, I2C_WRITE)) != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Device ID\n");
        goto BRSTOP;
    }

    if((Result = ncDrv_I2C_mRegAddress(channel, Address, AddressByte)) != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Address\n");
        goto BRSTOP;
    }

    if((Result = ncDrv_I2C_mSlaveAddress(channel, Device, SlaveBit, I2C_READ)) != NC_SUCCESS)
    {
        DEBUGMSG_SDK(MSGINFO, "Error, I2C Send Restart Device ID\n");
        goto BRSTOP;
    }

    ncDrv_I2C_SetOpMode(channel, IM_MRX);

    do
    {
        if(Length == 1)
        {
            if((Result = ncDrv_I2C_mReceiveData(channel, pdata)) != NC_SUCCESS)
            {
                DEBUGMSG_SDK(MSGINFO, "Error, I2C Receive Data\n");
                goto BRSTOP;
            }

            ncDrv_I2C_SetNack(channel);
        }
        else
        {
            if((Result = ncDrv_I2C_mReceiveData(channel, pdata)) != NC_SUCCESS)
            {
                DEBUGMSG_SDK(MSGINFO, "Error, I2C Receive Data\n");
                goto BRSTOP;
            }

            ncDrv_I2C_SetAck(channel);
        }

        pdata++;
        Length--;
    }
    while(Length);

BRSTOP:

    ncDrv_I2C_mSetStop(channel);

    return Result;
}
#endif


/* End Of File */
