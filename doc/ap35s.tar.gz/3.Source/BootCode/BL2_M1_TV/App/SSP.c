/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SSP_Drv.c
*
*  @brief   : This file is SSP Controller Driver for NEXTCHIP standard library
*
*  @author  : parkjy / SoCSW Team / TS Group
*
*  @date    : 2016.01.08
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : ARM PrimeCell�� SSP (PL022) / Revision: r1p3
*
********************************************************************************
*/

/*
********************************************************************************
*                               INCLUDE
********************************************************************************
*/


#include "Apache35.h"
#include "SSP.h"












/*
********************************************************************************
*                              LOCAL DEFINITIONS
********************************************************************************
*/
#define	SPI_IS_BUSY(status)     ((status)&SSP_BSY)
#define	SPI_IS_RxReady(status)  ((status)&SSP_RNE)









/*
********************************************************************************
*                           LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                                 LOCAL TYPEDEF
********************************************************************************
*/

/*
********************************************************************************
*                       IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                        GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/
UINT32	gnSSPInClock                = 0;
UINT32  gnSSPWidth[SSP_CH_MAX]      = {0, };











/*
********************************************************************************
*                       IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                            LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

/*
********************************************************************************
*                             FUNCTION DEFINITIONS
********************************************************************************
*/
void ncDrv_SSP_SetDMAMode(UINT32 nChNum, eSSP_DMAE cr)
{
   APACHE_SPI_WRITE(nChNum, SSP_DMACR, cr );
}

void ncDrv_SSP_SetBitRate(UINT32 nChNum, UINT32 bitrate)
{
    UINT32 Reg;
    UINT32 CPSDVR = DEFAULT_SSP_CLOCK_DIVIDER;
    UINT32 SCR;
    UINT32 SCR_0;
    UINT32 SCR_1;


    if( bitrate * MHZ * CPSDVR > gnSSPInClock)
    {
        //DEBUGMSG_SDK(MSGWARN, "Input Clock Frequency is too High!\n");
        SCR = 0;
    }
    else
    {
        /*
        * SPI clock formula
        * SCR = (InputClock/(CPSDVR * BitRate))-1
        */
        SCR_0 = (gnSSPInClock / (CPSDVR*bitrate*MHZ));	// Quotient of SCR
        SCR_1 = (gnSSPInClock % (CPSDVR*bitrate*MHZ));	// Remainder of SCR
        if( SCR_1 > ((CPSDVR*bitrate*MHZ)/2) )
        {
            SCR_0 = SCR_0 + 1;                          // for rounding
        }
        SCR = SCR_0 - 1;
    }

    Reg = APACHE_SPI_READ(nChNum, SSP_CR0);
    Reg &= ~(SSP_SCR_MSK);
    Reg |= (SCR<<8);
    APACHE_SPI_WRITE(nChNum, SSP_CR0, Reg);

    APACHE_SPI_WRITE(nChNum, SSP_CPSR, CPSDVR);    
}

/*
********************************************************************************
*
*  @brief		This function will get interrupt mask register
*
*  @param		Port   : SSP Port Number (0 ~ 1)
*
*  @return		Interrupt Mssk bit								\n
*                        SSP_TXIM	: Transmit FIFO Interrupt	\n
*                        SSP_RXIM	: Receive FIFO Interrupt	\n
*                        SSP_RTIM	: Receive FIFO Time Out		\n
*                        SSP_RORIM	: Receive Overrun Interrupt
*
*  @note
*
********************************************************************************
*/
UINT32 ncDrv_SSP_GetInterruptMask(UINT32 Port)
{
	UINT32 Mask = 0;

	Mask = APACHE_SPI_READ(Port, SSP_IMSC);

	return Mask;
}

/*
********************************************************************************
*
*  @brief		Clear Receive all FIFO data
*
*  @param		Port : SSP Port Number (0 ~ 1)
*
*  @return		None
*
*  @note
*
********************************************************************************
*/
void ncDrv_SSP_ClearRxFIFO(UINT32 Port)
{
    UINT32 Count;

    for(Count=0; Count<8; Count++)
    {
        if(APACHE_SPI_READ(Port, SSP_SR) & SSP_RNE)
        {
            APACHE_SPI_READ(Port, SSP_DR);	// Drop Data
        }
        else
        {
            break;
        }
    }
}


/*
********************************************************************************
*
*  @brief		Wait till SPI bus is not busy
*
*  @param		Port : SSP Port Number (0 ~ 1)
*           	TimeOut : Time out count
*
*  @return		TRUE  : The status bit is set \n
*               FALSE : Time out error
*
*  @note
*
********************************************************************************
*/
BOOL ncDrv_SSP_WaitBusIsBusy(UINT32 Port, UINT32 TimeOut)
{
    BOOL Ret = FALSE;
    UINT32 Status;
    UINT32 Count;
    
    for(Count=0; Count<TimeOut; Count++)
    {
        Status = APACHE_SPI_READ(Port, SSP_SR);
        if(!SPI_IS_BUSY(Status))
        {
            Ret = TRUE;
            break;
        }
    }

    return Ret;
}

BOOL ncDrv_SSP_WaitRxFIFOIsReady(UINT32 Port, UINT32 TimeOut)
{
    UINT32 Status;
    UINT32 Count;
    UINT32 Ret = FALSE;

    for(Count=0; Count<TimeOut; Count++)
    {
        Status = APACHE_SPI_READ(Port, SSP_SR);
        if(SPI_IS_RxReady(Status))
        {
            Ret = TRUE;
            break;
        }
    }

    return Ret;
}

/*
********************************************************************************
*                             SPI SDK API FUNCTIONS
********************************************************************************
*/
/*
********************************************************************************
*
*  @brief		Initialize SSP Port
*
*  @param		Port 	: SSP Port Number (0 ~ 1)
*           	ptParam : SSP control parameters							\n
*                 |- mFrameFormat : SSP frame format selection		        \n
*                 |    |- SSP_FRF_SPI		 : Motororal SPI                \n
*                 |    |- SSP_FRF_SSP		 : TI SSP                       \n
*                 |    |- SSP_FRF_MICROWIRE  : National Microwire           \n
*                 |                                                         \n
*                 |- mMode                                                  \n
*                 |    |- SSP_MS_MASTER   : Master Mode                     \n
*                 |    |- SSP_MS_SLAVE	  : Slave Mode                      \n
*                 |                                                         \n
*                 |- mSPO                                                   \n
*                 |    |- SSP_SPO_LOW	  : SPO Clock Polarity is LOW       \n
*                 |    |- SSP_SPO_HIGH	  : SPO Clock Polarity is HIGH      \n
*                 |                                                         \n
*                 |- mSPH                                                   \n
*                 |    |- SSP_SPH_LOW	  : SPH Clock Polarity is LOW       \n
*                 |    |- SSP_SPH_HIGH	  : SPH Clock Polarity is HIGH      \n
*                 |                                                         \n
*                 |- mInputCLK   : SSP Input Clock                          \n
*                 |                                                         \n
*                 |- mOutputCLK	: SSP Output Clock                          \n
*                 |                                                         \n
*                 |- mDataWidth  : SSP Data Width                           \n
*                 |    |- SSP_DSS_4BIT	  : 4-bit data                      \n
*                 |    |- SSP_DSS_5BIT	  : 5-bit data                      \n
*                 |    |- SSP_DSS_6BIT	  : 6-bit data                      \n
*                 |    |- SSP_DSS_7BIT	  : 7-bit data                      \n
*                 |    |- SSP_DSS_8BIT	  : 8-bit data                      \n
*                 |    |- SSP_DSS_9BIT	  : 9-bit data                      \n
*                 |    |- SSP_DSS_10BIT	  : 10-bit data                     \n
*                 |    |- SSP_DSS_11BIT	  : 11-bit data                     \n
*                 |    |- SSP_DSS_12BIT	  : 12-bit data                     \n
*                 |    |- SSP_DSS_13BIT	  : 13-bit data                     \n
*                 |    |- SSP_DSS_14BIT	  : 14-bit data                     \n
*                 |    |- SSP_DSS_15BIT	  : 15-bit data                     \n
*                 |    |- SSP_DSS_16BIT	  : 16-bit data                     \n
*                 |                                                         \n
*                 |- mHandler  : SSP Interrupt Handler
*
*  @return		TRUE  : Success \n
*               FALSE : Fail
*
*  @note
*
********************************************************************************
*/
INT32 ncDrv_SSP_Init(UINT32 nChNum, ptSSP_INIT_PARAM ptParam)
{
    INT32 ret = NC_SUCCESS;
    
    UINT32 Reg;
    UINT32 nIntMask;


    // Set BitRate
    ncDrv_SSP_SetBitRate(nChNum, ptParam->mBitRate);


    // Set SPH/SPO/Format/DataSize
    Reg = APACHE_SPI_READ(nChNum, SSP_CR0);
    Reg &= ~(0xFF<<0);
    Reg |= ((ptParam->mSPH<<7) | (ptParam->mSPO<<6) | (ptParam->mFormat<<4) | (ptParam->mDataWidth<<0));
    APACHE_SPI_WRITE(nChNum, SSP_CR0, Reg);


    // Set Mater Mode/SSP enable/LoopBack Disable
    APACHE_SPI_WRITE(nChNum, SSP_CR1,  SSP_SOD_EN | (ptParam->mMode<<2) | SSP_SSE_EN | SSP_LBM_DS);


    // Set Interrupt Mode
    nIntMask = SSP_TXIM_MASKED | SSP_RXIM_MASKED | SSP_RTIM_NOMASKED | SSP_RORIM_NOMASKED;
    if(ptParam->mTxIntEn == TRUE)
    {
        nIntMask |= SSP_TXIM_NOMASKED;
    }

    if(ptParam->mRxIntEn == TRUE)
    {
        nIntMask |= SSP_RXIM_NOMASKED;
    }
    APACHE_SPI_WRITE(nChNum, SSP_IMSC, nIntMask);

    // Why?
    APACHE_SPI_WRITE(nChNum, SSP_RIS, SSP_TXRIS | SSP_RXRIS | SSP_RTRIS | SSP_RORRIS);

    gnSSPWidth[nChNum] = ptParam->mDataWidth;
    
    return ret;
}


/*
********************************************************************************
*
*  @brief		Release SSP Port
*
*  @param		Port 	: SSP Port Number (0 ~ 1)
*
*  @return		TRUE  : Success \n
*               FALSE : Fail
*
*  @note
*
********************************************************************************
*/
INT32 ncDrv_SSP_DeInit(UINT32 nChNum)
{
    INT32 ret = NC_SUCCESS;
    
    APACHE_SPI_WRITE(nChNum, SSP_CR1, 0);

    return ret;
}


/*
********************************************************************************
*
*  @brief		This function will read data from data register
*
*  @param		nChNum   : SSP Port Number (0 ~ 1)
*
*  @return		Read Data (32bit align)
*
*  @note
*
********************************************************************************
*/
INT32 ncDrv_SSP_Read(UINT32 nChNum, UINT8 *pBuf, UINT32 nLength)
{
    INT32  ret = NC_SUCCESS;
    UINT32 i;
    UINT16 *pBuf16;
    UINT8  div = 1;

    if(gnSSPWidth[nChNum] > SSP_DS_8BIT)
    {
        pBuf16 = (UINT16 *) pBuf;
        div = 2;
    }


    for(i = 0; i < (nLength/div); i++)
    {
        /* Write dummy data */
        APACHE_SPI_WRITE(nChNum, SSP_DR, 0x00);

        if(!ncDrv_SSP_WaitBusIsBusy(nChNum, 1000))
        {
            ret = NC_FAILURE;
            DEBUGMSG_SDK(MSGERR, "SSP Bus Busy~!\n");
        }

        if(!ncDrv_SSP_WaitRxFIFOIsReady(nChNum, 1000))
        {
            ret = NC_FAILURE;
            DEBUGMSG_SDK(MSGERR, "SSP RxFIFO not Ready~!\n");
        }		

        /* Read data */
        if(gnSSPWidth[nChNum] > SSP_DS_8BIT)
        {
            pBuf16[i] = (UINT16) APACHE_SPI_READ(nChNum, SSP_DR);
        }
        else
        {
            pBuf[i]   = (UINT8)  APACHE_SPI_READ(nChNum, SSP_DR);
        }
    }

    return ret;
}


/*
********************************************************************************
*
*  @brief		This function will write data into data register
*
*  @param		nChNum   : SSP Port Number (0 ~ 1)
*               Data   : Write Data (32bit align)
*
*  @return		None
*
*
*  @note
*
********************************************************************************
*/
INT32 ncDrv_SSP_Write(UINT32 nChNum, UINT8 *pBuf, UINT32 nLength)
{
    INT32 ret = NC_SUCCESS;
    UINT32 i;
    UINT16 *pBuf16;
    UINT8  div = 1;

    if(gnSSPWidth[nChNum] > SSP_DS_8BIT)
    {
        pBuf16 = (UINT16 *) pBuf;
        div = 2;
    }

    for(i = 0; i < (nLength/div); i++)
    {
        /* Write data */
        if(gnSSPWidth[nChNum] > SSP_DS_8BIT)
        {
            APACHE_SPI_WRITE(nChNum, SSP_DR, pBuf16[i]);
        }
        else
        {
            APACHE_SPI_WRITE(nChNum, SSP_DR, pBuf[i]);
        }

        ncDrv_SSP_WaitBusIsBusy(nChNum, 1000);

        /* Read dummy Data */
        ret = APACHE_SPI_READ(nChNum, SSP_DR);
    }

    return ret;
}

void ncDrv_SSP_Handler(eSSP_CH nChNum)
{
    UINT32 Reg;

    Reg = APACHE_SPI_READ(nChNum, SSP_MIS);

    if(Reg & SSP_TXMIS)
    {
        DEBUGMSG_SDK(MSGINFO, "+");
    }

    if(Reg & SSP_RXMIS)
    {
        DEBUGMSG_SDK(MSGINFO, "-");
    }
    
    if(Reg & SSP_RTMIS)
    {        
        APACHE_SPI_WRITE(nChNum, SSP_ICR, SSP_RTIC);
        ncDrv_SSP_ClearRxFIFO(nChNum);
    }  

    if(Reg & SSP_RORMIS)
    {
        DEBUGMSG_SDK(MSGERR, "FIFO overrun\n");     

        if(APACHE_SPI_READ(nChNum, SSP_SR) & SSP_RFF)
            DEBUGMSG_SDK(MSGERR, "RxFIFO is full\n");  

        if(APACHE_SPI_READ(nChNum, SSP_SR) & SSP_TNF)
            DEBUGMSG_SDK(MSGERR, "TxFIFO is full\n");  

        APACHE_SPI_WRITE(nChNum, SSP_IMSC, 0);                  // interrupt all disable
        APACHE_SPI_WRITE(nChNum, SSP_ICR, SSP_RTIC|SSP_RORIC);  // clear all interrupt          
        Reg = APACHE_SPI_READ(nChNum, SSP_CR1);
        Reg &= ~(SSP_SSE_EN);
        APACHE_SPI_WRITE(nChNum, SSP_CR1, Reg);
    }      
}


void ncDrv_SSP_Handler0(void *param)
{
    ncDrv_SSP_Handler(SSP_CH0);
}

void ncDrv_SSP_Handler1(void *param)
{
    ncDrv_SSP_Handler(SSP_CH1);
}


/* End Of File */
