/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : ADC_Drv.c
*
*  @brief   : This file is ADC Controller Driver for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache35.h"
#include "Test.h"

#include "ADC.h"
#include "SCU.h"
#include "GPIO.h"
#include "sFlash.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define ADC_LOOP_NUMBER		20

/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

extern UINT32 gnSSPInClock;


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

tSF_REF_TEMP stRefTemp[2];  // 0 : load / 1 : save
tTEMP_INFO stTempInfo[MAX_OF_TEMP_ENVIRON];

UINT32 gAPBClock;
UINT32 gADCClock;
UINT32 gTSClock;

UINT32 gADCRefV;
UINT32 gADC_REF_A;
UINT32 gADC_REF_B;

// 3rd ADC BGR ...
INT32 gREF_TEMP_LT;
INT32 gREF_TEMP_RT;
INT32 gREF_TEMP_HT;

UINT32 gREF_BGR_LT;
UINT32 gREF_BGR_RT;
UINT32 gREF_BGR_HT;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

static UINT32 __CharToInt(UINT8 *pData)
{
    UINT32 i, nValue;

    nValue = 0;

    for(i = 4; i > 0; i--)
    {
        nValue = (nValue<<8) + (pData[i-1]);
    }

    return nValue;
}


static void __IntToChar(UINT8 *pData, UINT32 Value)
{
    UINT32 i, nTemp;

    nTemp = 0;

    for(i = 0; i < 4; i++)
    {
        nTemp = Value>>(i*8);
        pData[i] = (nTemp & 0xFF);
    }
}


void ncDrv_ADC_SetPower(UINT32 pwr)
{
    UINT32 ctrl = REGRW32(rADC_BASE, rTS_CTRL1);

    ctrl &= (~ADC_PD_MASK);
    ctrl |= (pwr << 8);

    REGRW32(rADC_BASE, rTS_CTRL1) = ctrl;
}


INT32 ncDrv_ADC_SetEnable(UINT32 en)
{
	UINT32 ctrl = REGRW32(rADC_BASE, rADC_CTRL0);
	INT32 ret = 0;

    if(en == 1)
    {
		ctrl |= ADC_CTRL0_EN;
		REGRW32(rADC_BASE, rADC_CTRL0) = ctrl;
    }
    else if(en == 0)
    {
		ctrl &= ~ADC_CTRL0_EN;
		REGRW32(rADC_BASE, rADC_CTRL0) = ctrl;
    }
    else
    {
        ret = -1;
    }

    return ret;
}


void ncDrv_ADC_SetSingleMode(UINT32 mode)
{
    UINT32 ctrl = REGRW32(rADC_BASE, rTS_CTRL1);

    ctrl &= (~ADC_TRIG_MODE_MASK);
    ctrl |= (mode << 9);

    REGRW32(rADC_BASE, rTS_CTRL1) = ctrl;

    ncDrv_ADC_SetEnable(0);
}


INT32 ncDrv_ADC_SetManuEnable(UINT32 en)
{
	UINT32 ctrl = REGRW32(rADC_BASE, rADC_CTRL0);
    INT32 ret = 0;

    if(en == 1)
    {
		ctrl |= ADC_CTRL0_MANU_EN;
		REGRW32(rADC_BASE, rADC_CTRL0) = ctrl;
    }
    else if(en == 0)
    {
        ctrl &= ~ADC_CTRL0_MANU_EN;
        REGRW32(rADC_BASE, rADC_CTRL0) = ctrl;
    }
    else
    {
        ret = -1;
    }

    return ret;
}


INT32 ncDrv_ADC_SetTempPower(UINT32 pwr)
{
	UINT32 reg = REGRW32(rADC_BASE, rTS_CTRL0);
	INT32 ret = 0;

	reg &= ~TS_CTRL0_PD_DOWN;

	if(pwr == 0)
	{
		reg |= TS_CTRL0_PD_DOWN;
		REGRW32(rADC_BASE, rTS_CTRL0) = reg;
	}
	else if(pwr == 1)
	{
		reg |= TS_CTRL0_PD_ON;
		REGRW32(rADC_BASE, rTS_CTRL0) = reg;
	}
	else
	{
		ret = -1;
	}

	return ret;
}


INT32 ncDrv_ADC_SetTempChop(UINT32 chop)
{
	UINT32 reg = REGRW32(rADC_BASE, rTS_CTRL0);
	INT32 ret = 0;

	if(chop == 0)
	{
		reg &= ~TS_CTRL0_CHOP_EN;
		REGRW32(rADC_BASE, rTS_CTRL0) = reg;
	}
	else if(chop == 1)
	{
		reg |= TS_CTRL0_CHOP_EN;
		REGRW32(rADC_BASE, rTS_CTRL0) = reg;
	}
	else
	{
		ret = -1;
	}

    return ret;
}


void ncDrv_ADC_SetTempCalibation(UINT32 calib)
{
    UINT32 ctrl = REGRW32(rADC_BASE, rTS_CTRL1);

    ctrl &= (~TS_CTRL1_CAL_MASK);
    ctrl |= (calib << 0);

    REGRW32(rADC_BASE, rTS_CTRL1) = ctrl;
}


UINT32 ncTest_SCU_GetAdcDiv(UINT32* div0, UINT32* div1)
{
    INT32 ret = NC_SUCCESS;

    *div0 = REGRW32(APACHE_SYSCON_BASE, rSCU_VDO_CLK_DIV);
    *div0 = (*div0 >> S_DIV_ADC_SEL) & S_DIV_ADC_SEL_MASK;

    *div1 = REGRW32(APACHE_SYSCON_BASE, rSCU_SYS_CLK_DIV);
    *div1 = (*div1 >> S_ADC_DIV) & 0x1F;

    return ret;
}


UINT32 ncTest_SCU_SetAdcDiv(UINT32 div0, UINT32 div1)
{
    UINT32 reg=0;

    reg = REGRW32(APACHE_SYSCON_BASE, rSCU_VDO_CLK_DIV);
    reg &= ~(S_DIV_ADC_SEL_MASK << S_DIV_ADC_SEL);
    reg |= (div0 << S_DIV_ADC_SEL);
    REGRW32(APACHE_SYSCON_BASE, rSCU_VDO_CLK_DIV) = reg;

    reg = REGRW32(APACHE_SYSCON_BASE, rSCU_SYS_CLK_DIV);
    reg &= ~(0x1F << S_ADC_DIV);
    reg |= (div1 << S_ADC_DIV);
    REGRW32(APACHE_SYSCON_BASE, rSCU_SYS_CLK_DIV) = reg;

    //debug..
    ncTest_SCU_GetAdcDiv(&div0, &div1);

    if(div0 == 0)
        div0 = 1;
    else if(div0 == 1)
        div0 = 4;
    else if(div0 == 2)
        div0 = 128;
    else if(div0 == 3)
        div0 = 4096;
    else
        div0 = 1;

    gADCClock = (gAPBClock / div0);
    gADCClock = (gADCClock / (div1+1));

    return gADCClock;
}


UINT32 ncTest_SCU_GetTempDiv(UINT32* div)
{
    INT32 ret = NC_SUCCESS;

    *div = REGRW32(APACHE_SYSCON_BASE, rSCU_SYS_CLK_DIV2);

    return ret;
}


UINT32 ncTest_SCU_SetTempDiv(UINT32 div)
{
    INT32 ret = NC_SUCCESS;

    REGRW32(APACHE_SYSCON_BASE, rSCU_SYS_CLK_DIV2) = div;

    //debug..
    ncTest_SCU_GetTempDiv(&div);
    gTSClock = (gAPBClock / div+1);

    ncDrv_SCU_mDelay(1);

    return ret;
}


UINT32 ncDrv_ADC_GetDataOut0(void)
{
	UINT32 dout = 0;

	dout = (REGRW32(rADC_BASE, rADC_DOUT) & ADC_DOUT0_MASK) >> 6;

	return dout;
}


UINT32 ncDrv_ADC_GetDataOut1(void)
{
	UINT32 dout = 0;

	dout = (REGRW32(rADC_BASE, rADC_DOUT) & ADC_DOUT1_MASK) >> 22;

    return dout;
}


UINT32 ncDrv_ADC_GetDataOut3(void)
{
	UINT32 dout = 0;

	dout = (REGRW32(rADC_BASE, rADC_EOC) & ADC_DOUT3_MASK) >> 22;

	return dout;
}


INT32 ncDrv_ADC_Conv_Temp(UINT32 dout)
{
    INT32 temp = 0;

    temp = ADC_REF_A * dout - ADC_REF_B;
    temp = temp / 10000;

    return temp;
}


INT32 ncDrv_ADC_GetTemp(void)
{
    UINT32 dout = 0;
    INT32 temp = 0;

    dout = ncDrv_ADC_GetDataOut0();
    temp = ncDrv_ADC_Conv_Temp(dout);

    return temp;
}


UINT32 ncDrv_ADC_GetTempCalibation(void)
{
	UINT32 calib = 0;

	calib = REGRW32(rADC_BASE, rTS_CTRL1) & TS_CTRL1_CAL_MASK;
	calib &= TS_CTRL1_CAL_MASK;

	return calib;
}


UINT32 ncDrv_ADC_GetTempChop(void)
{
	UINT32 chop = 0;

	chop = REGRW32(rADC_BASE, rTS_CTRL0)& TS_CTRL0_CHOP_EN;
    chop = chop >> 4;

    return chop;
}


void ncDrv_ADC_Init(void)
{
    ncDrv_ADC_SetPower(1);
    ncDrv_ADC_SetSingleMode(0);
    ncDrv_ADC_SetManuEnable(0);
    ncDrv_ADC_SetTempPower(1);
    ncDrv_ADC_SetTempChop(1);
    ncDrv_ADC_SetTempCalibation(ADC_DEFAUT_CAL);
    ncDrv_ADC_SetEnable(1);
}


void ncDrv_ADC_DeInit(void)
{
    ncDrv_ADC_SetEnable(0);
    ncDrv_ADC_SetSingleMode(0);
    ncDrv_ADC_SetManuEnable(0);
    ncDrv_ADC_SetTempChop(0);
    ncDrv_ADC_SetTempPower(0);
    //ncDrv_ADC_SetTempCalibation(ADC_DEFAUT_CAL);
    ncDrv_ADC_SetPower(0);
}


INT32 ncDrv_ADC_Compensate_Temp(UINT32 ref, UINT32 dout)
{
    UINT32 nADC_RefV;
    UINT32 nDATA_50;
    UINT32 nDATA_0;
    UINT32 nDATA_25;
    UINT32 nADC_REF_A;
    UINT32 nADC_REF_B;
    INT32 temp=0;

    nADC_RefV  = (BGF_REF_VOLTAGE * 1024) / ref;    // real int value / 1000
    nDATA_50   = (BGF_VTS_50C * 1024) / nADC_RefV;   // int value
    nDATA_0    = (BGF_VTS_0C * 1024) / nADC_RefV;    // int value
    nDATA_25   = (BGF_VTS_25 * 1024) / nADC_RefV;    // int value
    nADC_REF_A = (5000000 / (nDATA_50 - nDATA_0));
    nADC_REF_B = ((nADC_REF_A * nDATA_25) - 2500000) / 10;

    temp = (nADC_REF_A/10) * dout - nADC_REF_B;
    temp = temp / 10000;

    gADCRefV = nADC_RefV;
    gADC_REF_A = nADC_REF_A;
    gADC_REF_B = nADC_REF_B;

    return temp;
}


INT32 ncDrv_ADC_GetTemp_ReComp(UINT32 new_bgr_voltage, UINT32 adc_ch0, UINT32 adc_ch3)
{
    UINT32 nADC_RefV;
    UINT32 nDATA_50;
    UINT32 nDATA_0;
    UINT32 nDATA_25;
    UINT32 nADC_REF_A;
    UINT32 nADC_REF_B;
    INT32 temp=0;

    nADC_RefV  = (new_bgr_voltage * 1024) / adc_ch3;
    nDATA_50   = (BGF_VTS_50C * 1024) / nADC_RefV;
    nDATA_0    = (BGF_VTS_0C * 1024) / nADC_RefV;
    nDATA_25   = (BGF_VTS_25 * 1024) / nADC_RefV;
    nADC_REF_A = (5000000 / (nDATA_50 - nDATA_0));
    nADC_REF_B = ((nADC_REF_A * nDATA_25) - 2500000) / 10;

    temp = (nADC_REF_A/10) * adc_ch0 - nADC_REF_B;
    temp = temp / 10000;

    return temp;
}


INT32 ncDrv_ADC_GetTemp_TempADC_ReComp(UINT32 new_bgr_voltage, UINT32 adc_ch0, UINT32 adc_ch3)
{
    UINT32 nADC_RefV;
    UINT32 newADC_Value;
    INT32 temp = 0;

    nADC_RefV  = (new_bgr_voltage * 1024) / adc_ch3;
    newADC_Value = (adc_ch0 * nADC_RefV) / ADC_REF_VOLTAGE;

    temp = ADC_REF_A * newADC_Value - ADC_REF_B;
    temp = temp / 10000;

    return temp;
}

#if TEST_ADC_RTC_BGR_3RD
INT32 ncDrv_ADC_GetTemp_TempADC_ReComp_Intg(UINT32 new_bgr, UINT32 adc_ts, UINT32 adc_bgr)
{
    float nfADC_RefV;   // 3.3V
    float nfADC_TS;
    //float temperature;  // float temperature value
    INT32 temp_value;   // integer temperature value (return)

    nfADC_RefV = ((float)new_bgr * 3.3) / (float)adc_bgr;
    nfADC_TS = ((float)adc_ts * nfADC_RefV) / 3.3;

    temp_value = (INT32)(5336.0 * nfADC_TS - 2723500.0);
    temp_value = temp_value / 10000;

    //temperature = (0.5336 * nfADC_TS) - 272.35;
    //DEBUGMSG(MSGINFO, "Currently TS temperature_%2.1f'C (return_%d'C)\n", temperature, temp_value);

    return temp_value;
}
#endif


/* 2nd ADC BGR Vector Code */
////////////////////////////////////////////////////////////////////////////////////////////////////////////

void APACHE_TEST_ADC_BGR_GPIO_Step(UINT32 nStep)
{
	UINT32 i;

	for(i = 0; i < nStep; i++)
	{
		ncDrv_SCU_mDelay(1);
		ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT0, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
		ncDrv_SCU_mDelay(1);
		ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT0, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	}
}


void APACHE_TEST_ADC_BGR_GPIO_Read_Status(void)
{
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT31, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
	ncDrv_SCU_mDelay(1);
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT31, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	ncDrv_SCU_mDelay(1);
}


void APACHE_TEST_SF_ADC_BGR_HEADER(UINT8 *pData, UINT32 newVoltage, UINT32 size)
{
    UINT32 i, checksum;

    // [0:7] Signature .. ADC_V1000
    pData[ 0] = 'A';
    pData[ 1] = 'D';
    pData[ 2] = 'C';
    pData[ 3] = '_';
    pData[ 4] = 'V';
    pData[ 5] = '1';
    pData[ 6] = '0';
    pData[ 7] = '0';

    // [8:11] new BGR Voltage .. 1.000V ~ 1.400V
    pData[ 8] = (newVoltage>> 0)&0xFF;
    pData[ 9] = (newVoltage>> 8)&0xFF;
    pData[10] = (newVoltage>>16)&0xFF;
    pData[11] = (newVoltage>>24)&0xFF;

    checksum = 0;
    for(i = 0; i < 12; i++)
    {
        checksum += pData[i];
    }

    // [12:15] Signature + new BGR Voltage Byte checksum
    pData[12] = (checksum>> 0)&0xFF;
    pData[13] = (checksum>> 8)&0xFF;
    pData[14] = (checksum>>16)&0xFF;
    pData[15] = (checksum>>24)&0xFF;
}


static void APACHE_TEST_SF_Buffer_Read_2nd(UINT32 Addr, UINT8 *pData, UINT32 size)
{
    UINT32 i;
    tSF_REF_TEMP pInfo;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");
    for(i = 0; i < size; i++) // SF_PAGE_SIZE
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", Addr+i);
        DEBUGMSG(MSGINFO, "%02X ", pData[i]);
    }

    // version 4byte
    pInfo.version = __CharToInt(&pData[0]);

    // reference low temp 4byte
    pInfo.ref_L_temp = __CharToInt(&pData[4]);

    // reference room temp 4byte
    pInfo.ref_R_temp = __CharToInt(&pData[8]);

    // reference high temp 4byte
    pInfo.ref_H_temp = __CharToInt(&pData[12]);

    // reference low temp adc bgr 4byte
    pInfo.ref_LT_bgr = __CharToInt(&pData[16]);

    // reference room temp adc bgr 4byte
    pInfo.ref_RT_bgr = __CharToInt(&pData[20]);

    // reference high temp adc bgr 4byte
    pInfo.ref_HT_bgr = __CharToInt(&pData[24]);

    //DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");
    //DEBUGMSG(MSGINFO, " version : %d\n", pInfo.version);
    //DEBUGMSG(MSGINFO, " Reference Temperature (L_%d / R_%d / H_%d)\n", pInfo.ref_L_temp, pInfo.ref_R_temp, pInfo.ref_H_temp);
    //DEBUGMSG(MSGINFO, " Reference BGR (L_%d / R_%d / H_%d)\n", pInfo.ref_LT_bgr, pInfo.ref_RT_bgr, pInfo.ref_HT_bgr);
    //DEBUGMSG(MSGINFO, "--------------------------------------------------------------\n");
}


void APACHE_TEST_SF_Buffer_Write_2nd(UINT32 nEnvironment, UINT8 *pData, tSF_REF_TEMP *pInfo)
{
    // Update Version
	stRefTemp[1].version = 1;
    __IntToChar(&pData[0], stRefTemp[1].version);

    // Reference Low  Temperature -28'C
    stRefTemp[1].ref_L_temp = REF_LOW_TEMP;
    __IntToChar(&pData[4], stRefTemp[1].ref_L_temp);

    // Reference Room Temperature +25'C
    stRefTemp[1].ref_R_temp = REF_ROOM_TEMP;
    __IntToChar(&pData[8], stRefTemp[1].ref_R_temp);

    // Reference High Temperature +102'C
    stRefTemp[1].ref_H_temp = REF_HIGH_TEMP;
    __IntToChar(&pData[12], stRefTemp[1].ref_H_temp);

    if(nEnvironment == ADC_TEMP_LT)
    {
        stRefTemp[1].ref_LT_bgr = gREF_BGR_LT;
        stRefTemp[1].ref_RT_bgr = stRefTemp[0].ref_RT_bgr;
        stRefTemp[1].ref_HT_bgr = stRefTemp[0].ref_HT_bgr;
    }
    else if(nEnvironment == ADC_TEMP_RT)
    {
        stRefTemp[1].ref_LT_bgr = stRefTemp[0].ref_LT_bgr;
        stRefTemp[1].ref_RT_bgr = gREF_BGR_RT;
        stRefTemp[1].ref_HT_bgr = stRefTemp[0].ref_HT_bgr;
    }
    else if(nEnvironment == ADC_TEMP_HT)
    {
        stRefTemp[1].ref_LT_bgr = stRefTemp[0].ref_LT_bgr;
        stRefTemp[1].ref_RT_bgr = stRefTemp[0].ref_RT_bgr;
        stRefTemp[1].ref_HT_bgr = gREF_BGR_HT;
    }
    else
    {
        stRefTemp[1].ref_LT_bgr = stRefTemp[0].ref_LT_bgr;
        stRefTemp[1].ref_RT_bgr = stRefTemp[0].ref_RT_bgr;
        stRefTemp[1].ref_HT_bgr = stRefTemp[0].ref_HT_bgr;
    }

    // Reference Low  Temperature BGR
    __IntToChar(&pData[16], stRefTemp[1].ref_LT_bgr);

    // Reference Room Temperature BGR
    __IntToChar(&pData[20], stRefTemp[1].ref_RT_bgr);

    // Reference High Temperature BGR
    __IntToChar(&pData[24], stRefTemp[1].ref_HT_bgr);

    // Reference High Temperature BGR
    stRefTemp[1].reserved = 0xFFFFFFFF;
    __IntToChar(&pData[28], stRefTemp[1].reserved);
}


void APACHE_TEST_SF_Initialize(void)
{
    tSFLASH_ID tFlashID;
    tSF_INIT_PARAM tsFlashParam;

    gnSSPInClock = ncDrv_SCU_GetApbClock();

    tsFlashParam.mChNum 	= 0;
    tsFlashParam.mDmaMode	= FALSE;
    tsFlashParam.mQuadMode	= FALSE;
    tsFlashParam.mBitRate	= SF_BITRATE_40Mbps;

    ncSvc_SF_Init(&tsFlashParam);

    ncSvc_SF_ReadDeviceIdentification(&tFlashID);
}


UINT32 APACHE_TEST_Read_Security_Register(void)
{
    UINT32 i;
    UINT32 Addr = 0;
    UINT8  rBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
    UINT32 rdcs, sfcs;
    UINT32 readData;

    for(i = 0; i < 3; i++)
    {
		/* Read : Security Register LB1[S11], LB2[S12], LB3[S13] */
		Addr = ((i+1) << 12); // LB1 : 0x1000, LB2 : 0x2000, LB3 : 0x3000

		ncSvc_SF_SR_ReadData(Addr, (UINT8 *)rBuff, 16);
    }

    rdcs = 0;
    for(i = 0; i < 12; i++)
    {
        rdcs += rBuff[i];
    }

    sfcs = 0;
    sfcs = rBuff[12];
    sfcs |= rBuff[13] << 8;
    sfcs |= rBuff[14] << 16;
    sfcs |= rBuff[15] << 24;

    readData = 0;
    if(rdcs == sfcs)
    {
        readData = rBuff[8];
        readData |= rBuff[9] << 8;
        readData |= rBuff[10] << 16;
        readData |= rBuff[11] << 24;
    }

    return readData;
}


UINT32 APACHE_TEST_Read_Security_Register_Intg(void)
{
    UINT32 i;
    UINT32 Addr = 0;
    UINT8  rBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));

    for(i = 0; i < 1; i++)
    {
		/* Read : Security Register LB1[S11], LB2[S12], LB3[S13] */
		Addr = ((i+1) << 12); // LB1 : 0x1000, LB2 : 0x2000, LB3 : 0x3000

		ncSvc_SF_SR_ReadData(Addr, (UINT8 *)rBuff, 32);
    }

    // version 4byte
    stRefTemp[0].version = __CharToInt(&rBuff[0]);

    // reference low temp 4byte
    stRefTemp[0].ref_L_temp = (INT32)__CharToInt(&rBuff[4]);

    // reference room temp 4byte
    stRefTemp[0].ref_R_temp = (INT32)__CharToInt(&rBuff[8]);

    // reference high temp 4byte
    stRefTemp[0].ref_H_temp = (INT32)__CharToInt(&rBuff[12]);

    // reference low temp adc bgr 4byte
    stRefTemp[0].ref_LT_bgr = __CharToInt(&rBuff[16]);

    // reference room temp adc bgr 4byte
    stRefTemp[0].ref_RT_bgr = __CharToInt(&rBuff[20]);

    // reference high temp adc bgr 4byte
    stRefTemp[0].ref_HT_bgr = __CharToInt(&rBuff[24]);

    // reserved 4byte
    stRefTemp[0].reserved = __CharToInt(&rBuff[28]);

    gREF_TEMP_LT = REF_LOW_TEMP;
    gREF_TEMP_RT = REF_ROOM_TEMP;
    gREF_TEMP_HT = REF_HIGH_TEMP;

    stRefTemp[0].ref_L_temp = REF_LOW_TEMP;
    stRefTemp[0].ref_R_temp = REF_ROOM_TEMP;
    stRefTemp[0].ref_H_temp = REF_HIGH_TEMP;

    gREF_BGR_LT = stRefTemp[0].ref_LT_bgr;
    gREF_BGR_RT = stRefTemp[0].ref_RT_bgr;
    gREF_BGR_HT = stRefTemp[0].ref_HT_bgr;

    return 0;
}


void APACHE_TEST_Write_Security_Register(UINT32 newVoltage)
{
    UINT32 i;
    UINT32 Addr = 0;
    UINT8  wBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));

    /* Erase : Security Register LB1[S11], LB2[S12], LB3[S13] */
    for(i = 0; i < 3; i++)
    {
        Addr = ((i+1) << 12); // LB1 : 0x1000, LB2 : 0x2000, LB3 : 0x3000

        ncSvc_SF_SR_Erase(Addr);
    }


    APACHE_TEST_SF_ADC_BGR_HEADER(wBuff, newVoltage, SF_PAGE_SIZE);

    /* Write : Security Register LB1[S11], LB2[S12], LB3[S13] */
    for(i = 0; i < 3; i++)
    {
        Addr = ((i+1) << 12); // LB1 : 0x1000, LB2 : 0x2000, LB3 : 0x3000

        ncSvc_SF_SR_WriteData(Addr, (UINT8 *)(wBuff), 16);
    }
}


void APACHE_TEST_Write_Security_Register_Intg(UINT32 nEnvironment)
{
    UINT32 i;
    UINT32 Addr = 0;
    UINT8  rBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));
    UINT8  wBuff[SF_PAGE_SIZE] __attribute__ ((aligned (8)));


	/* Read : Security Register LB1[S11], LB2[S12], LB3[S13] */
    for(i = 0; i < 1; i++)
    {
		Addr = ((i+1) << 12); // LB1 : 0x1000, LB2 : 0x2000, LB3 : 0x3000

		ncSvc_SF_SR_ReadData(Addr, (UINT8 *)rBuff, 32);
    }
    APACHE_TEST_SF_Buffer_Read_2nd(Addr, &rBuff[0], 32);


    /* Erase : Security Register LB1[S11], LB2[S12], LB3[S13] */
    for(i = 0; i < 1; i++)
    {
        Addr = ((i+1) << 12); // LB1 : 0x1000, LB2 : 0x2000, LB3 : 0x3000

        ncSvc_SF_SR_Erase(Addr);
    }


    /* Write : Security Register LB1[S11], LB2[S12], LB3[S13] */
    APACHE_TEST_SF_Buffer_Write_2nd(nEnvironment, &wBuff[0], &stRefTemp[1]);
    for(i = 0; i < 1; i++)
    {
        Addr = ((i+1) << 12); // LB1 : 0x1000, LB2 : 0x2000, LB3 : 0x3000

        ncSvc_SF_SR_WriteData(Addr, (UINT8 *)(wBuff), 32);
    }
}


void APACHE_TEST_SF_Deinitialize(void)
{
	ncSvc_SF_Release();
}


void APACHE_TEST_ADC_RTC_BGR_2ND(void)
{
#if TEST_ADC_RTC_BGR_2ND
    UINT32 i, temp;
    UINT32 newSavBgrVolt;
    UINT32 newCurBgrVolt;
    UINT32 newBgrTemp;
    UINT32 newBgrTemp_min;
    UINT32 newBgrTemp_max;
    UINT32 adc_vdo_div, adc_sys_div, adc_clk;
    UINT32 sflahUpdate, clocksel;
    tADC_INFO nCh[4];

	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT0, GPIO_HIGH, rGPIO_V2_OUT_PORT0); // ready step gpio
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT31, GPIO_LOW, rGPIO_V2_OUT_PORT0); // gpio data read status

    /*
     * sFlash Memory Initialize
     * */

    APACHE_TEST_SF_Initialize();

    ncDrv_GPIO_GetData(GPIO_GROUP_A, GPIO_PORT9, &sflahUpdate, rGPIO_V2_IN_PORT0);	// ADC Clock Select 1 or sFlash Update


    /*
     * ADC Initialize
     * */

	// ADC Clock 108/2 -> 54MHz
	gAPBClock = ncDrv_SCU_GetApbClock();

	/* Open ADC (temperature sensor) */
	REGRW32(APACHE_SYSCON_BASE, rSCU_CLK_EN) |= S_ADC_CLK_EN ;  // Clock Enable
	ncDrv_SCU_mDelay(1);
	REGRW32(APACHE_SYSCON_BASE, rSCU_RST_CTRL) |= S_ADC_RST;    // RST High
	ncDrv_SCU_mDelay(1);
	REGRW32(APACHE_SYSCON_BASE, rSCU_RST_CTRL) &= ~S_ADC_RST;   // RST Low
	ncDrv_SCU_mDelay(1);
	REGRW32(APACHE_SYSCON_BASE, rSCU_CLK_EN) |= S_TS_CLK_EN ; 	// Clock Enable
	ncDrv_SCU_mDelay(1);

	/* Init temperature sensor */
	// APB Clock 54MHz
	//adc_vdo_div = 0x0;	// ADC clock select / 54MHz
	//adc_vdo_div = 0x1;	// ADC clock select / 13,500,000Hz
	//adc_vdo_div = 0x2;	// ADC clock select / 421,875Hz
	//adc_vdo_div = 0x3;	// ADC clock select / 13,183.59375Hz
	/*
		0 : apb_clk
		1 : apb_clk / 4
		2 : apb_clk / 128
		3 : apb_clk / 4096
	*/
	//adc_sys_div = 0x4;	// adc_clk = DIV_ADC_SEL / (adc_sys_div + 1)

	ncDrv_GPIO_GetData(GPIO_GROUP_A, GPIO_PORT8, &clocksel, rGPIO_V2_IN_PORT0);	// ADC Clock Select 0

	switch(clocksel)
	{
		case E_ADC_CLK_4KHZ:	// 4,394.53125
			adc_vdo_div = 3;
			adc_sys_div = 2;
		break;

		case E_ADC_CLK_2KHZ:	// 2,197.265625
			adc_vdo_div = 3;
			adc_sys_div = 5;
		break;

		default :
			adc_vdo_div = 3;
			adc_sys_div = 2;
		break;
	}

	adc_clk = ncTest_SCU_SetAdcDiv(adc_vdo_div, adc_sys_div);

	ncDrv_ADC_Init();
	ncDrv_SCU_mDelay(10);

    for(i = 0; i < 4; i++)
    {
        nCh[i].adc_avg = 0x0000;

        nCh[i].adc_min = 0xFFFF;
        nCh[i].adc_max = 0x0000;

        nCh[i].temp_min = 0xFFFFFFFF;
        nCh[i].temp_max = 0x0000;
    }

    newBgrTemp_min = 0xFFFFFFFF;
    newBgrTemp_max = 0x0000;


    /*
     * sFlash Memory Get new BGR Voltage Value
     * */

	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT0, GPIO_LOW, rGPIO_V2_OUT_PORT0);	// start step gpio

    newSavBgrVolt = APACHE_TEST_Read_Security_Register();

    /*
     * ADC Get Value
     * */

    for(i = 0; i < ADC_LOOP_NUMBER; i++)
    {
		ncDrv_SCU_mDelay(30);

        /* Get Temperature Output */
        nCh[0].adc = ncDrv_ADC_GetDataOut0();
        if(nCh[0].adc < nCh[0].adc_min) nCh[0].adc_min = nCh[0].adc;
        if(nCh[0].adc > nCh[0].adc_max) nCh[0].adc_max = nCh[0].adc;
        nCh[0].adc_avg += nCh[0].adc;

        //ncLib_ADC_Control(GCMD_ADC_GET_TEMP_DATA_2, &nCh[0].temp, nCh[0].adc, CMD_END);
        //if(nCh[0].temp < nCh[0].temp_min) nCh[0].temp_min = nCh[0].temp;
        //if(nCh[0].temp > nCh[0].temp_max) nCh[0].temp_max = nCh[0].temp;

        /* Get BGR Output */
        nCh[3].adc = ncDrv_ADC_GetDataOut3();
        if(nCh[3].adc < nCh[3].adc_min) nCh[3].adc_min = nCh[3].adc;
        if(nCh[3].adc > nCh[3].adc_max) nCh[3].adc_max = nCh[3].adc;
        nCh[3].adc_avg += nCh[3].adc;

        //ncLib_ADC_Control(GCMD_ADC_GET_TEMP_BGR_DATA_2, &nCh[3].temp, nCh[0].adc, nCh[3].adc, CMD_END);
        //if(nCh[3].temp < nCh[3].temp_min) nCh[3].temp_min = nCh[3].temp;
        //if(nCh[3].temp > nCh[3].temp_max) nCh[3].temp_max = nCh[3].temp;

        if(sflahUpdate)
        {
        	newCurBgrVolt = nCh[3].adc*3300/1024;
			//newBgrTemp = ncDrv_ADC_GetTemp_ReComp(newCurBgrVolt, nCh[0].adc, nCh[3].adc);
            newBgrTemp = ncDrv_ADC_GetTemp_TempADC_ReComp(newCurBgrVolt, nCh[0].adc, nCh[3].adc); // adc ch0 change
        }
        else
        {
            //newBgrTemp = ncDrv_ADC_GetTemp_ReComp(newSavBgrVolt, nCh[0].adc, nCh[3].adc);
            newBgrTemp = ncDrv_ADC_GetTemp_TempADC_ReComp(newSavBgrVolt, nCh[0].adc, nCh[3].adc); // adc ch0 change
        }

        if(newBgrTemp < newBgrTemp_min) newBgrTemp_min = newBgrTemp;
        if(newBgrTemp > newBgrTemp_max) newBgrTemp_max = newBgrTemp;
    }

    APACHE_TEST_ADC_BGR_GPIO_Step(1);

    /*
     * ADC ch0 min, ch3 min, trim temp min GPIO Output
     * */

    __SIM_ADC_CH0(nCh[0].adc_min);
	__SIM_ADC_CH3(nCh[3].adc_min);
	//__SIM_ADC_CELSIUS(newBgrTemp_min);

	for(i = 0; i < 10; i++)
	{
		temp = (nCh[0].adc_min >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

	for(i = 0; i < 10; i++)
	{
		temp = (nCh[3].adc_min >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

	if(newBgrTemp_min & 0xF0000000)
	{
		temp = ~newBgrTemp_min;
		newBgrTemp_min = temp+1;

		ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT9, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
	}
	else
	{
		ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT9, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	}

	for(i = 0; i < 8; i++)
	{
		temp = (newBgrTemp_min >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

    APACHE_TEST_ADC_BGR_GPIO_Step(2);

    /*
     * ADC ch0 max, ch3 max, trim temp max GPIO Output
     * */

    __SIM_ADC_CH0(nCh[0].adc_max);
	__SIM_ADC_CH3(nCh[3].adc_max);
	//__SIM_ADC_CELSIUS(newBgrTemp_max);

	for(i = 0; i < 10; i++)
	{
		temp = (nCh[0].adc_max >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

	for(i = 0; i < 10; i++)
	{
		temp = (nCh[3].adc_max >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

	if(newBgrTemp_max & 0xF0000000)
	{
		temp = ~newBgrTemp_max;
		newBgrTemp_max = temp+1;

		ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT9, GPIO_HIGH, rGPIO_V2_OUT_PORT0);
	}
	else
	{
		ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT9, GPIO_LOW, rGPIO_V2_OUT_PORT0);
	}

	for(i = 0; i < 8; i++)
	{
		temp = (newBgrTemp_max >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

    APACHE_TEST_ADC_BGR_GPIO_Step(3);


    /*
     * ADC BGR new Voltage Value
     * */

    if(sflahUpdate)
    {
		nCh[3].adc_avg /= ADC_LOOP_NUMBER;
		newCurBgrVolt = nCh[3].adc_avg*3300/1024;
    }
    else
    {
    	newCurBgrVolt = newSavBgrVolt;
    }

    for(i = 0; i < 11; i++)
	{
		temp = (newCurBgrVolt >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

    APACHE_TEST_ADC_BGR_GPIO_Step(4);


    /*
     * sFlash Memory Set new BGR Voltage Value
     * */

    if(sflahUpdate)
    {
		APACHE_TEST_Write_Security_Register(newCurBgrVolt);
    }

	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT0, GPIO_HIGH, rGPIO_V2_OUT_PORT0);	// end step gpio

    /*
     * ADC DeInitialize
     * */

    ncDrv_ADC_DeInit();


    /*
     * sFlash Memory DeInitialize
     * */

    APACHE_TEST_SF_Deinitialize();
#endif
}


/* 3rd ADC BGR Vector Code */
////////////////////////////////////////////////////////////////////////////////////////////////////////////

void APACHE_TEST_ADC_RTC_BGR_3RD(void)
{
#if TEST_ADC_RTC_BGR_3RD
	UINT32 i, j;
    UINT32 sflahUpdate, clocksel, nTTE;
    UINT32 newBgrTemp;
	UINT32 temp;
    UINT32 adc_vdo_div, adc_sys_div, adc_clk;
    float bgr_slope;
    float trim_bgr;
    float trimREF_voltage;
    float trimTS;


	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT0, GPIO_HIGH, rGPIO_V2_OUT_PORT0); // ready step gpio
	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT31, GPIO_LOW, rGPIO_V2_OUT_PORT0); // gpio data read status

    ncDrv_GPIO_GetData(GPIO_GROUP_A, GPIO_PORT9, &sflahUpdate, rGPIO_V2_IN_PORT0);	// ADC Clock Select 1 or sFlash Update
    ncDrv_GPIO_GetData(GPIO_GROUP_A, GPIO_PORT8, &clocksel, rGPIO_V2_IN_PORT0);		// ADC Clock Select

    ncDrv_GPIO_GetData(GPIO_GROUP_B, GPIO_PORT11, &temp, rGPIO_V2_IN_PORT0);		// Test Temperature Environ Select 0
    nTTE = temp;
	ncDrv_GPIO_GetData(GPIO_GROUP_B, GPIO_PORT12, &temp, rGPIO_V2_IN_PORT0);		// Test Temperature Environ Select 1
	nTTE |= temp<<1;


    /*
     * Serial Flash Memory Initialize ...
     * */

    APACHE_TEST_SF_Initialize();


    /*
     * ADC Initialize ...
     * */

	// ADC Clock 108/2 -> 54MHz
	gAPBClock = ncDrv_SCU_GetApbClock();

	/* Open ADC (temperature sensor) */
	REGRW32(APACHE_SYSCON_BASE, rSCU_CLK_EN) |= S_ADC_CLK_EN ;  // Clock Enable
	ncDrv_SCU_mDelay(1);
	REGRW32(APACHE_SYSCON_BASE, rSCU_RST_CTRL) |= S_ADC_RST;    // RST High
	ncDrv_SCU_mDelay(1);
	REGRW32(APACHE_SYSCON_BASE, rSCU_RST_CTRL) &= ~S_ADC_RST;   // RST Low
	ncDrv_SCU_mDelay(1);
	REGRW32(APACHE_SYSCON_BASE, rSCU_CLK_EN) |= S_TS_CLK_EN ; 	// Clock Enable
	ncDrv_SCU_mDelay(1);

	/* Init temperature sensor */
	// APB Clock 54MHz
	//adc_vdo_div = 0x0;	// ADC clock select / 54MHz
	//adc_vdo_div = 0x1;	// ADC clock select / 13,500,000Hz
	//adc_vdo_div = 0x2;	// ADC clock select / 421,875Hz
	//adc_vdo_div = 0x3;	// ADC clock select / 13,183.59375Hz
	/*
		0 : apb_clk
		1 : apb_clk / 4
		2 : apb_clk / 128
		3 : apb_clk / 4096
	*/
	//adc_sys_div = 0x4;	// adc_clk = DIV_ADC_SEL / (adc_sys_div + 1)

	switch(clocksel)
	{
		case E_ADC_CLK_4KHZ:	// 4,394.53125
			adc_vdo_div = 3;
			adc_sys_div = 2;
		break;

		case E_ADC_CLK_2KHZ:	// 2,197.265625
			adc_vdo_div = 3;
			adc_sys_div = 5;
		break;

		default :
			adc_vdo_div = 3;
			adc_sys_div = 2;
		break;
	}

	adc_clk = ncTest_SCU_SetAdcDiv(adc_vdo_div, adc_sys_div);

	ncDrv_ADC_Init();
	ncDrv_SCU_mDelay(10);


    /*
     * Temperature Test Information Memory Initialize ...
     * */

    for(i = ADC_TEMP_LT; i < MAX_OF_TEMP_ENVIRON; i++)
    {
    	for(j = E_ADC_CH0_TS; j < MAX_OF_ADC_CH_TYPE; j++)
    	{
            stTempInfo[i].Ch[j].adc_min = 0xFFFF;
            stTempInfo[i].Ch[j].adc_avg = 0x0000;
            stTempInfo[i].Ch[j].adc_max = 0x0000;
    	}
    }

    if(nTTE == ADC_TEMP_UNKNOWN)
    {
    	sflahUpdate = 0;
    }

	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT0, GPIO_LOW, rGPIO_V2_OUT_PORT0);	// start step gpio


    /*
     * Serial Flash Memory Read ...
     * */

    APACHE_TEST_Read_Security_Register_Intg();


    /*
     * Temperature Test 20 Count and Calculation ...
     * */

    for(i = 0; i < ADC_LOOP_NUMBER; i++)
    {
		ncDrv_SCU_mDelay(33);

        /* 1. Get Temperature Output ---------------------------------------- */
		stTempInfo[nTTE].Ch[0].adc = ncDrv_ADC_GetDataOut0();

        if(i == 0)
        {
            stTempInfo[nTTE].Ch[0].adc_min = stTempInfo[nTTE].Ch[0].adc;
            stTempInfo[nTTE].Ch[0].adc_max = stTempInfo[nTTE].Ch[0].adc;
        }

        if(stTempInfo[nTTE].Ch[0].adc < stTempInfo[nTTE].Ch[0].adc_min) stTempInfo[nTTE].Ch[0].adc_min = stTempInfo[nTTE].Ch[0].adc;
        if(stTempInfo[nTTE].Ch[0].adc > stTempInfo[nTTE].Ch[0].adc_max) stTempInfo[nTTE].Ch[0].adc_max = stTempInfo[nTTE].Ch[0].adc;
        stTempInfo[nTTE].Ch[0].adc_avg = (stTempInfo[nTTE].Ch[0].adc_min + stTempInfo[nTTE].Ch[0].adc_max)/2;

        /* 2. Get BGR Output ------------------------------------------------ */
        stTempInfo[nTTE].Ch[3].adc = ncDrv_ADC_GetDataOut3();

        if(i == 0)
        {
            stTempInfo[nTTE].Ch[3].adc_min = stTempInfo[nTTE].Ch[3].adc;
            stTempInfo[nTTE].Ch[3].adc_max = stTempInfo[nTTE].Ch[3].adc;
        }

        if(stTempInfo[nTTE].Ch[3].adc < stTempInfo[nTTE].Ch[3].adc_min) stTempInfo[nTTE].Ch[3].adc_min = stTempInfo[nTTE].Ch[3].adc;
        if(stTempInfo[nTTE].Ch[3].adc > stTempInfo[nTTE].Ch[3].adc_max) stTempInfo[nTTE].Ch[3].adc_max = stTempInfo[nTTE].Ch[3].adc;
        stTempInfo[nTTE].Ch[3].adc_avg = (stTempInfo[nTTE].Ch[3].adc_min + stTempInfo[nTTE].Ch[3].adc_max)/2;

        /* 3. Get Current Temperature Output -------------------------------- */
        if(sflahUpdate)
        {
            switch(nTTE)
            {
                case 0:
                    gREF_BGR_LT = stTempInfo[nTTE].Ch[3].adc_avg;
                break;

                case 1:
                    gREF_BGR_RT = stTempInfo[nTTE].Ch[3].adc_avg;
                break;

                case 2:
                    gREF_BGR_HT = stTempInfo[nTTE].Ch[3].adc_avg;
                break;
            }

            newBgrTemp = stTempInfo[nTTE].Ch[3].adc_avg;
        }
        else
        {
            newBgrTemp = gREF_BGR_RT;
        }

        stTempInfo[nTTE].CurTemp = ncDrv_ADC_GetTemp_TempADC_ReComp_Intg(newBgrTemp, stTempInfo[nTTE].Ch[0].adc, stTempInfo[nTTE].Ch[3].adc);

        /* 4. Detect LT or HT Temperature ----------------------------------- */
#if 0
        if(stTempInfo[nTTE].CurTemp < gREF_TEMP_RT)
        {
            /* 5. detected Low Temperature, Low BGR Slope Calculation ------- */
            if(gREF_BGR_LT == 0xFFFFFFFF)
            {
                bgr_slope = 0;
            }
            else
            {
                bgr_slope = ((float)(gREF_BGR_RT - gREF_BGR_LT) / (float)(gREF_TEMP_RT - gREF_TEMP_LT));
            }
        }
        else if(stTempInfo[nTTE].CurTemp >= gREF_TEMP_RT)
        {
            /* 5. detected High Temperature, High BGR Slope Calculation ----- */
            if(gREF_BGR_HT == 0xFFFFFFFF)
            {
                bgr_slope = 0;
            }
            else
            {
                bgr_slope = ((float)(gREF_BGR_HT - gREF_BGR_RT) / (float)(gREF_TEMP_HT - gREF_TEMP_RT));
            }
        }
#else
        if(nTTE == ADC_TEMP_UNKNOWN)
        {
            if(stTempInfo[nTTE].CurTemp < gREF_TEMP_RT)
            {
                /* 5. detected Low Temperature, Low BGR Slope Calculation ------- */
				bgr_slope = ((float)((INT32)gREF_BGR_RT - (INT32)gREF_BGR_LT) / (float)(gREF_TEMP_RT - gREF_TEMP_LT));
            }
            else if(stTempInfo[nTTE].CurTemp >= gREF_TEMP_RT)
            {
                /* 5. detected High Temperature, High BGR Slope Calculation ----- */
				bgr_slope = ((float)((INT32)gREF_BGR_HT - (INT32)gREF_BGR_RT) / (float)(gREF_TEMP_HT - gREF_TEMP_RT));
            }
        }
        else
        {
            bgr_slope = (float)(0.0);
        }
#endif

        /* 6. Calibrated ADC BGR Code and 3.3V Reference Voltage ------------ */
        trim_bgr = bgr_slope * (float)(stTempInfo[nTTE].CurTemp - gREF_TEMP_RT) + (float)gREF_BGR_RT;
        //stTempInfo[nTTE].trimBGR = gBGR_SLOPE * (stTempInfo[nTTE].CurTemp - gREF_TEMP_RT) + gREF_BGR_RT;

        /* 7. 2nd Calibrated Temperature ------------------------------------ */
        trimREF_voltage = (trim_bgr * 3.3) / (float)stTempInfo[nTTE].Ch[3].adc;
        //stTempInfo[nTTE].trimREF_Volt = (stTempInfo[nTTE].trimBGR * 3300) / stTempInfo[nTTE].Ch[3].adc;
        trimTS = ((float)stTempInfo[nTTE].Ch[0].adc * trimREF_voltage) / 3.3;
        stTempInfo[nTTE].trimTS = (UINT32)trimTS; // (stTempInfo[nTTE].Ch[0].adc * stTempInfo[nTTE].trimREF_Volt) / 3300;

        if(i == 0)
        {
            stTempInfo[nTTE].trimTS_min = stTempInfo[nTTE].trimTS;
            stTempInfo[nTTE].trimTS_max = stTempInfo[nTTE].trimTS;
        }

        if(stTempInfo[nTTE].trimTS < stTempInfo[nTTE].trimTS_min) stTempInfo[nTTE].trimTS_min = stTempInfo[nTTE].trimTS;
        if(stTempInfo[nTTE].trimTS > stTempInfo[nTTE].trimTS_max) stTempInfo[nTTE].trimTS_max = stTempInfo[nTTE].trimTS;
    }

    /*
     * Calculated ADC Output ...
     * */

    APACHE_TEST_ADC_BGR_GPIO_Step(1);

    /* -------------------------------------------------------------------------------------------------------------------
     * ADC ch0 min, ch3 min, trim ts min GPIO Output
     * */

    __SIM_ADC_CH0(stTempInfo[nTTE].Ch[0].adc_min);
	__SIM_ADC_CH3(stTempInfo[nTTE].Ch[3].adc_min);
	__SIM_ADC_TRIM_TS(stTempInfo[nTTE].trimTS_min);

	for(i = 0; i < 10; i++)
	{
		temp = (stTempInfo[nTTE].Ch[0].adc_min >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

	for(i = 0; i < 10; i++)
	{
		temp = (stTempInfo[nTTE].Ch[3].adc_min >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

	for(i = 0; i < 10; i++)
	{
		temp = (stTempInfo[nTTE].trimTS_min >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

    APACHE_TEST_ADC_BGR_GPIO_Step(2);

    /*
     * ADC ch0 max, ch3 max, trim ts max GPIO Output
     * */

    __SIM_ADC_CH0(stTempInfo[nTTE].Ch[0].adc_max);
	__SIM_ADC_CH3(stTempInfo[nTTE].Ch[3].adc_max);
	__SIM_ADC_TRIM_TS(stTempInfo[nTTE].trimTS_max);

	for(i = 0; i < 10; i++)
	{
		temp = (stTempInfo[nTTE].Ch[0].adc_max >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

	for(i = 0; i < 10; i++)
	{
		temp = (stTempInfo[nTTE].Ch[3].adc_max >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

	for(i = 0; i < 10; i++)
	{
		temp = (stTempInfo[nTTE].trimTS_max >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

    APACHE_TEST_ADC_BGR_GPIO_Step(3);

    /*
     * ADC BGR sFlash Memory GPIO Output
     * */

    __SIM_ADC_SF_LT_BGR(gREF_BGR_LT);
    __SIM_ADC_SF_RT_BGR(gREF_BGR_RT);
    __SIM_ADC_SF_HT_BGR(gREF_BGR_HT);

	for(i = 0; i < 10; i++)
	{
		temp = (gREF_BGR_LT >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

	for(i = 0; i < 10; i++)
	{
		temp = (gREF_BGR_RT >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

	for(i = 0; i < 10; i++)
	{
		temp = (gREF_BGR_HT >> i) & 0x1;
		ncDrv_GPIO_SetData(GPIO_GROUP_B, (GPIO_PORT1+i), (eGPIO_DATA)temp, rGPIO_V2_OUT_PORT0);
	}

	APACHE_TEST_ADC_BGR_GPIO_Read_Status();

    APACHE_TEST_ADC_BGR_GPIO_Step(4);


    /* -------------------------------------------------------------------------------------------------------------------
     * sFlash Memory Set new BGR Voltage Value
     * */

    if(sflahUpdate && (nTTE != ADC_TEMP_UNKNOWN))
    {
		APACHE_TEST_Write_Security_Register_Intg(nTTE);
    }
    sflahUpdate = 0;

	ncDrv_GPIO_SetData(GPIO_GROUP_B, GPIO_PORT0, GPIO_HIGH, rGPIO_V2_OUT_PORT0);	// end step gpio


	/*
     * ADC Deinitialize ...
     * */

    ncDrv_ADC_DeInit();


    /*
     * Serial Flash Memory Deinitialize ...
     * */

    APACHE_TEST_SF_Deinitialize();
#endif
}

/* End Of File */
