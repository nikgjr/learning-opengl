/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : I2C_SlaveDrv.c
*
*  @brief   : I2C module slave mode driver source file
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.07
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : Argo I2C IP / Revision: 0.5
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include <time.h>

#include "Apache35.h"
#include "I2C.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define I2C_SLAVE_DATA_INFORMATION


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncDrv_I2C_SlaveInitialize(tI2C_INFO *i2cinfo)
{
    eI2C_CH channel;

    channel = i2cinfo->channel;

    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) &= ~ISR_MASK;
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_IER) |= (IER_SAM|IER_SACKP|IER_SACK);

    i2cinfo->slave.id >>= 1;
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_SADDRL) = i2cinfo->slave.id & 0xFF;
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_SADDRH) = (i2cinfo->slave.id>>8) & 0xFF;

    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_OPR) = (OPR_S7ADDR|OPR_CORE_EN);

    ncDrv_I2C_SetOpMode(channel, IM_SRX);

    gI2cInfo[channel] = *i2cinfo;
    gI2cInfo[channel].slave.status = I2C_ISS_IDLE;
    gI2cInfo[channel].slave.rxIdx = 0;
}

UINT8 ncDrv_I2C_sReadDataFromBuf(eI2C_CH channel)
{
	UINT8 data;
	data =gI2cInfo[channel].slave.rxBuf[1];
	return data;
}

UINT32 ncDrv_I2C_sReadSingleByte(eI2C_CH channel, eI2C_INDEX_TYPE type)
{
    UINT8 addr, data, index;

    data = REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_SRXR);

    index = gI2cInfo[channel].slave.rxIdx;
    gI2cInfo[channel].slave.rxBuf[index] = data;

    if(type == I2C_INDEX_DATA)
    {
#ifdef I2C_SLAVE_DATA_INFORMATION
        addr = gI2cInfo[channel].slave.rxBuf[I2C_INDEX_ADDR];
        data = gI2cInfo[channel].slave.rxBuf[I2C_INDEX_DATA];

        DEBUGMSG_SDK(MSGINFO, "Byte Access Host Write addr[0x%X] data[0x%X] \n", addr, data);
#endif

        gI2cInfo[channel].slave.rxIdx = 0;
        gI2cInfo[channel].slave.status = I2C_ISS_IDLE;
    }
    else
    {
        gI2cInfo[channel].slave.rxIdx++;
    }

    return 0;
}


UINT32 ncDrv_I2C_sWriteSingleByte(eI2C_CH channel, eI2C_INDEX_TYPE type)
{
    UINT8 addr, data, index;

    index = gI2cInfo[channel].master.txIdx;
    //data = gI2cInfo[channel].master.txBuf[index];

    if(type == I2C_INDEX_DATA)
    {
#ifdef I2C_SLAVE_DATA_INFORMATION
        addr = gI2cInfo[channel].slave.rxBuf[0];
        data = gI2cInfo[channel].master.txBuf[0];

        DEBUGMSG_SDK(MSGINFO, "Byte Access Host Read addr[0x%X] data[0x%X] \n", addr, data);
#endif

        gI2cInfo[channel].slave.rxIdx = 0;
        gI2cInfo[channel].master.txIdx = 0;
        gI2cInfo[channel].slave.status = I2C_ISS_IDLE;
    }
    else if(type == I2C_INDEX_ADDR)
    {
        gI2cInfo[channel].slave.rxIdx++;
        gI2cInfo[channel].master.txIdx++;
    }

    data = gI2cInfo[channel].master.txBuf[index];
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_STXR) = data;

    return 0;
}


UINT32 ncDrv_I2C_sReadSingleWord(eI2C_CH channel, eI2C_INDEX_TYPE type)
{
    UINT8 index, temp;
    UINT8 addr_h, addr_l;
    UINT8 data_h, data_l;

    temp = REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_SRXR);

    index = gI2cInfo[channel].slave.rxIdx;
    gI2cInfo[channel].slave.rxBuf[index] = temp;

    if(type == I2C_INDEX_DATA)
    {
        if(index == 2)
        {
            gI2cInfo[channel].slave.rxIdx++;
        }
        else
        {
#ifdef I2C_SLAVE_DATA_INFORMATION
            addr_h = gI2cInfo[channel].slave.rxBuf[0];
            addr_l = gI2cInfo[channel].slave.rxBuf[1];

            data_h = gI2cInfo[channel].slave.rxBuf[2];
            data_l = gI2cInfo[channel].slave.rxBuf[3];

            DEBUGMSG_SDK(MSGINFO, "Word Access Host Write addr[0x%02X%02X] data[0x%02X%02X] \n", addr_h, addr_l, data_h, data_l);
#endif

            gI2cInfo[channel].slave.rxIdx = 0;
            gI2cInfo[channel].slave.status = I2C_ISS_IDLE;
        }
    }
    else
    {
        gI2cInfo[channel].slave.rxIdx++;
    }

    return 0;
}


UINT32 ncDrv_I2C_sWriteSingleWord(eI2C_CH channel, eI2C_INDEX_TYPE type)
{
    UINT8 index, temp;
    UINT8 addr_h, addr_l;
    UINT8 data_h, data_l;

    index = gI2cInfo[channel].master.txIdx;

    if(type == I2C_INDEX_DATA)
    {
        if(index == 0)
        {
            gI2cInfo[channel].master.txIdx++;
        }
        else
        {
            addr_h = gI2cInfo[channel].slave.rxBuf[0];
            addr_l = gI2cInfo[channel].slave.rxBuf[1];

            data_h = gI2cInfo[channel].master.txBuf[0];
            data_l = gI2cInfo[channel].master.txBuf[1];

            DEBUGMSG_SDK(MSGINFO, "Word Access Host Read addr[0x%02X%02X] data[0x%02X%02X]\n", addr_h, addr_l, data_h, data_l);

            gI2cInfo[channel].slave.rxIdx = 0;
            gI2cInfo[channel].master.txIdx = 0;
            gI2cInfo[channel].slave.status = I2C_ISS_IDLE;
        }
    }
    else if(type == I2C_INDEX_ADDR)
    {
        gI2cInfo[channel].slave.rxIdx++;
        gI2cInfo[channel].master.txIdx++;
    }

    temp = gI2cInfo[channel].master.txBuf[index];

    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_STXR) = temp;

    return 0;
}


/* End Of File */
