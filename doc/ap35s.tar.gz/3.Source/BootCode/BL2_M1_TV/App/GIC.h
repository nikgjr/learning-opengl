/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : INTC_Drv.h
*
*  @brief   : This file is interrupt controller driver for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.07
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : ARM PrimeCell�� Generic Interrupt Controller (PL390) / Revision: r0p0
*
********************************************************************************
*/

#ifndef __INTC_DRV_H__
#define __INTC_DRV_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Type.h"


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define RAISED_IRQS_TOTAL   30  // Interrupt source number
#define IRQS_TOTAL          64  // Total interrupt source number
#define IRQS_START          32  // Interrupt source start number
#define INVALID_IRQ_NO      0x3FF   // Total interrupt source number


/*
 * GIC Register Map
 */
#define rGIC_DIST_BASE  APACHE_PL390_0_BASE
#define rGIC_CPU_BASE   APACHE_PL390_1_BASE

//----------------------------------------------------------
// Distributor register map

// rICDxxx  Register Interrupt Controller Distributor xxxx

// SGI : Software Generated Interrupt
// PPI : Private Peripheral Interrupt
// SPI : Shared Peripheral Interrupt

#define rICDDCR         0x0000  // RW, 32bit, Distributor Control Register
#define rICDICTR        0x0004  // RO, 32bit, Interrupt Controller Type Register
#define rICDIIDR        0x0008  // RO, 32bit, Distributor Implementer Identification Register
#define rICDISR         0x0080  // RW, 16bit, 0x0080 Interrupt Security Register for SGI
                                // RW, 16bit, 0x0082 Interrupt Security Register for PPI
                                // RW, 32bit, 0x0084 ~ 0x0FC Interrupt Security Register for SPI
#define rICDISER        0x0100  // RO, 16bit, 0x0100 Enable Set Registers for SGI
                                // RW, 16bit, 0x0102 Enable Set Registers for PPI
                                // RW, 32bit, 0x0104 ~ 0x017C Enable Set Registers for SPI
#define rICDICER        0x0180  // RO, 16bit, 0x0180 Enable Clear Registers for SGI
                                // RW, 16bit, 0x0182 Enable Clear Registers for PPI
                                // RW, 32bit, 0x0184 ~ 0x01FC Enable Clear Registers for SPI
#define rICDISPR        0x0200  // RO, 16bit, 0x0200 Pending Set Registers for SGI
                                // RW, 16bit, 0x0202 Pending Set Registers for PPI
                                // RW, 32bit, 0x0204 ~ 0x027C Pending Set Registers for SPI
#define rICDICPR        0x0280  // RO, 16bit, 0x0280 Pending Clear Registers for SGI
                                // RW, 16bit, 0x0282 Pending Clear Registers for PPI
                                // RW, 32bit, 0x0284 ~ 0x02FC Pending Clear Registers for SPI
#define rICDABR         0x0300  // RO, 16bit, 0x0300 Active Status Registers for SGI
                                // RO, 16bit, 0x0302 Active Status Registers for PPI
                                // RO, 32bit, 0x0304 ~ 0x037C Active Status Registers for SPI
#define rICDIPR         0x0400  // RW, 8bit,  0x0400 ~ 0x040F Priority Level Registers for SGI
                                // RW, 8bit,  0x0410 ~ 0x041F Priority Level Reigsters for PPI
                                // RW, 8bit,  0x0420 ~ 0x04FB Priority Level Registers for SPI
#define rICDIPTR        0x0800  // RO, 8bit,  0x0800 ~ 0x081F Target Registers for SGI, PPI
                                // RW, 8bit,  0x0820 ~ 0x08FB Target Registers for SPI
#define rICDICR         0x0C00  // RO, 32bit, 0x0C00 ~ 0x0C04 Interrupt Configuration Registers for SGI, PPI
                                // RW, 32bit, 0x0C08 ~ 0x0CFC Interrupt Configuration Registers for SPI
#define rICDPPISR       0x0D00  // RO, 32bit, PPI Status Register
#define rICDSPISR       0x0D04  // RO, 32bit, 0x0D04 ~ 0x0D7C SPI Status Register
#define rICDLIR         0x0DD4  // --, 32bit, Legacy Interrupt Registers
#define rICDMR          0x0DE0  // --, 32bit, Match Register
#define rICDER          0x0DE4  // --, 32bit, Enable Register
#define rICDSGIR        0x0F00  // WO, 32bit, Software Generated Interrupt Register
#define rICDPIR         0x0FC0  // RO, 8bit,  Peripheral Identification Registers
#define rICDPIR74       0x0FD0  // RO, 8bit,  0x0FD0 ~ 0x0FDC Peripheral Identification Registers[7:4]
#define rICDPIR30       0x0FE0  // RO, 8bit,  0x0FE0 ~ 0x0FEC Peripheral Identification Registers[3:0]
#define rICDPCIR30      0x0FF0  // RO, 8bit,  0x0FF0 ~ 0x0FFC PrimeCell Identification Registers[3:0]


//----------------------------------------------------------
// CPU interface register map

// rICCxxx  Register Interrupt Controller CPU xxxx

#define rICCICR         0x0000  // RW, 32bit, CPU Interface Control Register
#define rICCPMR         0x0004  // RW, 32bit, Priority Mask Register
#define rICCBPR         0x0008  // RW, 32bit, Binary Point Register
#define rICCIAR         0x000C  // RO, 32bit, Interrupt Acknowledge Register
#define rICCEOIR        0x0010  // WO, 32bit, End of Interrupt Register
#define rICCRPR         0x0014  // RO, 32bit, Running Priority Register
#define rICCHPIR        0x0018  // RO, 32bit, Highest Pending Interrupt Register
#define rICCABPR        0x001C  // RW, 32bit, Aliased Binary Point Register
#define rICCITER        0x0040  // --, -----, Integration Test Enable Register
#define rICCIOR         0x0044  // --, -----, Interrupt Output Register
#define rICCMR          0x0050  // --, -----, Match Register
#define rICCER          0x0054  // --, -----, Enable Register
#define rICCIIDR        0x00FC  // RO, 32bit, CPU Interface Implementer Identification Register
#define rICCPIR         0x0FC0  // RO, 8bit,  Peripheral Identification Register
#define rICCPIR74       0x0FD0  // RO, 8bit,  0x0FD0 ~ 0x0FDC Peripheral Identification Registers[7:4]
#define rICCPIR30       0x0FE0  // RO, 8bit,  0x0FE0 ~ 0x0FEC Peripheral Identification Registers[3:0]
#define rICCPCIR30      0x0FF0  // RO, 8bit,  0x0FF0 ~ 0x0FFC PrimeCell Identification Registers[3:0]


//----------------------------------------------------
// Mask bit value and bit, reg offset shift value

#define IRQS_PER_REG            32
#define PRIOS_PER_REG           4
#define TARGETS_PER_REG         4
#define CONFIGS_PER_REG         16
#define PRIO_FIELD_MASK         0xFF
#define PRIO_FIELD_WIDTH        8
#define TARGET_FIELD_MASK       0xFF
#define TARGET_FIELD_WIDTH      8
#define CONFIG_FIELD_MASK       0x03
#define CONFIG_FIELD_WIDTH      2


//----------------------------------------------------
// CPU target interface value

#define CPU_TARGET_IF0          0x01    // one CPU interface
#define CPU_TARGET_IF1          0x02    // two CPU interface
#define CPU_TARGET_IF2          0x04    // three CPU interface
#define CPU_TARTET_IF3          0x08    // four CPU interface
#define CPU_TARGET_IF4          0x10    // five CPU interface
#define CPU_TARGET_IF5          0x20    // six CPU interface
#define CPU_TARGET_IF6          0x40    // seven CPU interface
#define CPU_TARTET_IF7          0x80    // eight CPU interface


#define DEF_INTC_TRIGGER_LEVEL      TRIG_HIGH_LEVEL
#define DEF_INTC_PRIORITY_LEVEL     240


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


typedef enum
{
	GCMD_INTC_REGISTER_INT = 0,
	GCMD_INTC_UNREGISTER_INT,
	GCMD_INTC_SGI_TRIGGER,

	GCMD_INTC_SET_TRIG_MODE,
	GCMD_INTC_SET_PRIORITY_LEVEL,
	GCMD_INTC_ENABLE_INT,
	GCMD_INTC_DISABLE_INT,
	GCMD_INTC_ONOFF_RAISED_INT,      // for Debug
	GCMD_INTC_CHK_RAISED_INT,        // for Debug
	GCMD_INTC_CLR_RAISED_INT,        // for Debug
	GCMD_INTC_MAX
} eINTC_CMD;


typedef enum
{
	TRIG_LEVEL_HIGH = 0,
	TRIG_LEVEL_LOW,
	TRIG_EDGE_HIGH,
	TRIG_EDGE_LOW,
	TRIG_EDGE_BOTH
} eTRIG_MODE;

typedef enum
{
    IRQ_NUM_NULL = 0,

    IRQ_NUM_SGI_0 = IRQ_NUM_NULL,
    IRQ_NUM_SGI_1,
    IRQ_NUM_SGI_2,
    IRQ_NUM_SGI_3,
    IRQ_NUM_SGI_MAX,

    IRQ_NUM_WDT = 32,       // (32+ 0)
    IRQ_NUM_TIMER0,         // (32+ 1)
    IRQ_NUM_TIMER1,         // (32+ 2)
    IRQ_NUM_DMA_CHANNEL0,   // (32+ 3)
    IRQ_NUM_DMA_CHANNEL1,   // (32+ 4)
    IRQ_NUM_DMA_CHANNEL2,   // (32+ 5)
    IRQ_NUM_DMA_CHANNEL3,   // (32+ 6)
    IRQ_NUM_DMA_ABORT,      // (32+ 7)
    IRQ_NUM_I2C0,           // (32+ 8)
    IRQ_NUM_I2C1,           // (32+ 9)
    IRQ_NUM_SPI0,           // (32+10)
    IRQ_NUM_SPI1,           // (32+11)
    IRQ_NUM_UART0,          // (32+12)
    IRQ_NUM_UART1,          // (32+13)

    IRQ_NUM_REV0,           // (32+14)
    IRQ_NUM_REV1,           // (32+15)
    IRQ_NUM_VDUMP,          // (32+16)

    IRQ_NUM_ISP0,           // (32+17)
    IRQ_NUM_ISP1,           // (32+18)
    IRQ_NUM_ISP2,           // (32+19)
    IRQ_NUM_ISP3,           // (32+20)
    IRQ_NUM_ISP4,           // (32+21)
    IRQ_NUM_ISP5,           // (32+22)
    IRQ_NUM_ISP6,           // (32+23)
    IRQ_NUM_ISP7,           // (32+24)
    IRQ_NUM_ISP8,           // (32+25)

    IRQ_NUM_EXT_INT0,       // (32+26)
    IRQ_NUM_REV2,           // (32+27)

    IRQ_NUM_CAN,            // (32+28)

    IRQ_NUM_SUB_TIMER0,     // (32+29)
    IRQ_NUM_SUB_TIMER1,     // (32+30)
    IRQ_NUM_SUB_TIMER2,     // (32+31)

    MAX_IRQ_NUM,

    FIQ_NUM_NULL = MAX_IRQ_NUM,
    MAX_FIQ_NUM
} eINT_NUM;







/*
 * Interrupt level and edge config value
 */
typedef enum
{
    GIT_N_N_LEVEL,
    GIT_N_N_EDGE,
    GIT_1_N_LEVEL,
    GIT_1_N_EDGE,
} eGIC_INT_TYPE;


/*
 * Interrupt mask level config value
 */
typedef enum
{
    GPM_LEVEL_16 = 0xF0,
    GPM_LEVEL_32 = 0xF8,
    GPM_LEVEL_64 = 0xFC,
    GPM_LEVEL_128 = 0xFE,
    GPM_LEVEL_256 = 0xFF
} eGIC_PRIO_MASK;

typedef enum
{
    IAR_CPUID,
    IAR_INTRID,
    MAX_OF_GICC_IAR
} eGICC_IAR;

typedef enum
{
    EOIR_CPUID,
    EOIR_EOIINTID,
    MAX_OF_GICC_EOIR
} eGICC_EOIR;

typedef enum
{
    IF_IDENT_IMPLEMEMT,
    IF_IDENT_REVISION,
    IF_IDENT_ARCH_VERSION,
    IF_IDENT_PRODUCTID,
    MAX_OF_GICC_IF_IDENT
} eGICC_IF_IDENT;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT32 irqNo;
    UINT32 level;
} tGIC_RAISED_IRQ;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern void   ncDrv_GIC_HaltHandler(void);
extern void   ncDrv_GIC_IrqHandler(void);

extern INT32  ncDrv_GIC_Initialize(void);
extern INT32  ncDrv_GIC_Deinitialize(void);

extern void   ncDrv_GIC_EnableIrq(INT32 irq);
extern void   ncDrv_GIC_DisableIrq(INT32 irq);
extern void   ncDrv_GIC_EnableAllIrqs(void);
extern void   ncDrv_GIC_DisableAllIrqs(void);
extern void   ncDrv_GIC_ClearPendingIrq(INT32 irq);
extern void   ncDrv_GIC_EnableAllIrqsClearPending(void);

extern void   ncDrv_GIC_OnOffRaisedIrq(BOOL OnOff);
extern void   ncDrv_GIC_ClearAllRaisedIrq(void);
extern void   ncDrv_GIC_SetRaisedIrq(INT32 irq);
extern INT32  ncDrv_GIC_CheckRaisedIrq(INT32 irq);
extern INT32  ncDrv_GIC_WaitIrq(INT32 irq, UINT32 timeout);

extern void   ncDrv_GIC_SetIrqCPUTarget(UINT32 irq, UINT32 value);
extern void   ncDrv_GIC_SetInterruptConfigration(UINT32 irq, UINT32 value);
extern void   ncDrv_GIC_SetPriorityLevel(UINT32 irq, UINT32 value);

extern void   ncDrv_GIC_SGITrigger(UINT32 irq);

extern void GIC_InitIntHandler(void);
extern void GIC_UserHandler(UINT32 nIntNum);
extern void GIC_RegisterHandler(UINT32 nIntNum, PrHandler pHandler);
extern void GIC_UnRegisterHandler(UINT32 nIntNum);
extern void GIC_InitIntHandler(void);

#endif  /* __INTC_DRV_H__ */


/* End Of File */
