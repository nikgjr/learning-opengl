/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Uart_Drv.c
*
*  @brief   : This file is UART Controller Driver for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : ARM PrimeCell® UART (PL011) / Revision: r1p4
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache35.h"
#include "Test.h"
#include "UART.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define UART_BUFFER_SIZE        16


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

//tREG_UART *prPUart = (tREG_UART *)UART0;

/*
* For User Handler
*/
PrVoid ncDrv_Uart_UserHandler0 = NULL;
PrVoid ncDrv_Uart_UserHandler1 = NULL;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncDrv_UART_IRQ_Handler0(UINT32 nIrqNum)
{
    /*
    * Implement UART0 Tx, Rx Interrupt Service Routine
    */

    ncDrv_UART_ISR_Handler(UART_CH0);

    /*
    * User Handler Call Back Function
    */

    if(ncDrv_Uart_UserHandler0 != NULL)
    {
        ncDrv_Uart_UserHandler0();
    }
}


void ncDrv_UART_IRQ_Handler1(UINT32 nIrqNum)
{
    /*
    * Implement UART1 Tx, Rx Interrupt Service Routine
    */

    ncDrv_UART_ISR_Handler(UART_CH1);

    /*
    * User Handler Call Back Function
    */

    if(ncDrv_Uart_UserHandler1 != NULL)
    {
        ncDrv_Uart_UserHandler1();
    }
}


void ncDrv_UART_ISR_Handler(eUART_CH channel)
{
    UINT32 nStatus = 0;
    tREG_UART *rUART;

    if(channel == UART_CH0)
    {
        rUART = (tREG_UART *)UART0;
    }
    else
    {
        rUART = (tREG_UART *)UART1;
    }

    nStatus = rUART->UARTMIS;

    rUART->UARTICR = nStatus;
}


INT32 ncDrv_UART_ConnectUserHandler(eUART_CH channel, PrVoid UserHandler)
{
    INT32 ret = NC_SUCCESS;

    switch(channel)
    {
        case UART_CH0:
            ncDrv_Uart_UserHandler0 = (PrVoid) UserHandler;
        break;

        case UART_CH1:
            ncDrv_Uart_UserHandler1 = (PrVoid) UserHandler;
        break;

        default:
            ret = NC_FAILURE;
        break;
    }

    return ret;
}


INT32 ncDrv_UART_DisConnectUserHandler(eUART_CH channel)
{
    INT32 ret = NC_SUCCESS;

    switch(channel)
    {
        case UART_CH0:
            ncDrv_Uart_UserHandler0 = (PrVoid) NULL;
        break;

        case UART_CH1:
            ncDrv_Uart_UserHandler1 = (PrVoid) NULL;
        break;

        default:
            ret = NC_FAILURE;
        break;
    }

    return ret;
}


void ncDrv_UART_Initialize(tREG_UART *rUART, tUART_PARAM *param)
{
    /*
    ** First, disable everything.
    */

    rUART->UARTCR = 0;
    rUART->UARTLCR_H = 0;

    /*
    ** Set baud rate
    */

    ncDrv_UART_SetBaudrate(rUART, param);


    /*
    ** ----------------------------------------------
    ** NOTE: MUST BE WRITTEN LAST (AFTER IBRD & FBRD)
    ** ----------------------------------------------
    **
    ** Set the UART to be 8 bits, 1 stop bit, no parity, fifo enabled.
    */

    rUART->UARTLCR_H = (param->sps | param->wlen | param->fen | param->stp2 | param->eps | param->pen | param->brk);


    /*
    ** Set the UART FIFO level to .....
    */

    rUART->UARTIFLS = FLS_RX_1DIV8 | FLS_TX_1DIV2;
    rUART->UARTICR |= 0xFFFF;
    rUART->UARTIMSC = (IMSC_OEIM | IMSC_BEIM | IMSC_PEIM | IMSC_FEIM | IMSC_RTIM
                     | IMSC_RXIM | IMSC_DSRMIM | IMSC_DCDMIM | IMSC_CTSMIM | IMSC_RIMIM);


    /*
    ** Finally, enable the UART
    */

    rUART->UARTCR = (CR_RX_EN | CR_TX_EN | CR_UART_EN);
}


void ncDrv_UART_Deinitialize(tREG_UART *rUART)
{
    /*
    ** First, disable everything.
    */

    rUART->UARTCR = 0;


    /*
    ** Set baud rate
    **
    ** IBRD = UART_CLK / (16 * BPS)
    ** FBRD = ROUND((64 * MOD(UART_CLK,(16 * BPS))) / (16 * BPS))
    */

    rUART->UARTIBRD = 0;
    rUART->UARTFBRD = 0;

    /*
    ** ----------------------------------------------
    ** NOTE: MUST BE WRITTEN LAST (AFTER IBRD & FBRD)
    ** ----------------------------------------------
    **
    ** Set the UART to be 8 bits, 1 stop bit, no parity, fifo enabled.
    */

    rUART->UARTLCR_H = 0;


    /*
    ** Set the UART FIFO levle to .....
    */

    rUART->UARTIFLS = 0x12;
    rUART->UARTICR |=0xFFFF;
    rUART->UARTIMSC = 0;
}


void ncDrv_UART_SetBaudrate(tREG_UART *rUART, tUART_PARAM *param)
{
    UINT32 temp, ref_clk, divider, remainder, fraction;

    /*
    ** Set baud rate
    **
    ** IBRD = UART_CLK / (16 * BPS)
    ** FBRD = ROUND((64 * MOD(UART_CLK,(16 * BPS))) / (16 * BPS))
    */

    temp = 16 * (param->baudRate);
    ref_clk = param->uartClk;
    divider = ref_clk / temp;

    remainder = ref_clk % temp;
    temp = (8 * remainder) / param->baudRate;
    fraction = (temp >> 1) + (temp & 1);

    rUART->UARTIBRD = divider;
    rUART->UARTFBRD = fraction;
}


UINT8 ncDrv_UART_GetControl(tREG_UART *rUART, eUART_CMD nCmd)
{
    UINT8 nCount = 0;

#if 0
    switch(nCmd)
    {
        case GCMD_UT_GET_RX_FIFO_CNT:
            if(rUART->UARTFR & FR_RXFE)
            {
                nCount = 0;
            }
            else
            {
                nCount = 1;
            }
        break;
    }
#endif

    return nCount;
}


void ncDrv_UART_putchar(tREG_UART *rUART, UINT8 ch)
{
    while(rUART->UARTFR & FR_TXFF);

    rUART->UARTDR = ch;
}


void ncDrv_UART_print_string(tREG_UART *rUART, char *str)
{
    char prev = 0x0;

    while(*str)
    {
        if(*str == '\n' && prev != '\r') ncDrv_UART_putchar(rUART, '\r');

        ncDrv_UART_putchar(rUART, *str);

        prev = *str++;
    }
}


void ncDrv_UART_putstr(tREG_UART *rUART, char *str)
{
    ncDrv_UART_print_string(rUART, str);
    ncDrv_UART_print_string(rUART, "\n");
}


int ncDrv_UART_getchar(tREG_UART *rUART) {

	int i=0;

	for (i = 0; i < UART_TIME_OUT; i++) {
		if (!(rUART->UARTFR & FR_RXFE))
			return (UINT8) rUART->UARTDR;
	}

	return -1;
}


int ncDrv_UART_writebytes(tREG_UART *rUart, void *buffer, int length)
{
    int i;
    char *s = (char*)buffer;

    for(i = 0; i < length; i++)
    {
        ncDrv_UART_putchar(rUart, s[i]);
    }

    return length;
}


int ncDrv_UART_readbytes(tREG_UART *rUART, void *buffer, int length)
{
    int i = 0;
    int ch;
    char *s = (char*)buffer;

    while(1)
    {
        ch = ncDrv_UART_getchar(rUART);

        if(ch == -1)
        {
            // delay here
            continue;
        }

        s[i++] = (char)ch;

        if(i == length)
        {
            break;
        }
    }

    return length;
}


void ncDrv_UART_printhex(tREG_UART *rUART, UINT8 hex)
{
    UINT8 tmp;

    /* 1st Digit */
    tmp = hex >> 4;

    if(tmp < 0x0A)
    {
        tmp += 0x30;
    }
    else
    {
        tmp += 0x37;
    }

    ncDrv_UART_putchar(rUART, tmp);

    /* 2nd Digit */
    tmp = hex & 0x0F;

    if(tmp < 0x0A)
    {
        tmp += 0x30;
    }
    else
    {
        tmp += 0x37;
    }

    ncDrv_UART_putchar(rUART, tmp);
}


void ncDrv_UART_printdec(tREG_UART *rUART, UINT32 num, UINT8 type)
{
    UINT8 quot;
    UINT32 tmp;

    if(!num)
    {
        ncDrv_UART_putchar(rUART, '0');
        return;
    }

    if(type == DEC_8)
    {
        tmp = 100;
    }
    else if(type == DEC_16)
    {
        tmp = 10000;
    }
    else if(type == DEC_32)
    {
        tmp = 1000000000;
    }
    else
    {
        tmp = 1000000000;
    }

    while(!(num/tmp))
        tmp /= 10;

    while(1)
    {
        quot = num/tmp;

        ncDrv_UART_putchar(rUART, (quot+0x30));

        num -= quot * tmp;
        tmp /= 10;

        if(!tmp)
        {
            break;
        }
    }
}

#if 0
void ncDrv_UART_printf(const char *fmt, ...)
{
    va_list args;
    char buffer[512];

    va_start(args, fmt);

    vsnprintf(buffer, sizeof(buffer), fmt, args);

    va_end(args);

    /* Only Uart Channel 0 */
    ncDrv_UART_print_string(UART0, buffer);
}
#endif


char *ncDrv_UART_getstr(tREG_UART *rUART, char *s)
{
    int c = 0;
    int i = 0;

    while(1)
    {
        c = ncDrv_UART_getchar(rUART);

        if(c < 0)
        {
            continue;
        }

        if(c == '\r' || c == '\n')
        {
            ncDrv_UART_putchar(rUART, '\r');
            ncDrv_UART_putchar(rUART, '\n');

            break;
        }

        if(c == '\b' || c==127)
        {
            if(i>0)
            {
                i--;
                ncDrv_UART_putchar(rUART, c);
                ncDrv_UART_putchar(rUART, ' ');
                ncDrv_UART_putchar(rUART, c);
            }
        }
        else
        {
            s[i++]=(char)c;
            ncDrv_UART_putchar(rUART, c);
        }
    }

    s[i]='\0';

    return s;
}


UINT32 ncDrv_UART_GetPeripheralID(tREG_UART *rUART)
{
    UINT32 periID = 0;

    periID  = rUART->UARTPID0 & 0xFF;
    periID |= (rUART->UARTPID1 & 0xFF) << 8;
    periID |= (rUART->UARTPID2 & 0xFF) << 16;
    periID |= (rUART->UARTPID3 & 0xFF) << 24;

    return periID;
}


UINT32 ncDrv_UART_GetPrimeCelllID(tREG_UART *rUART)
{
    UINT32 primeCellID = 0;

    primeCellID  = rUART->UARTCID0 & 0xFF;
    primeCellID |= (rUART->UARTCID1 & 0xFF) << 8;
    primeCellID |= (rUART->UARTCID2 & 0xFF) << 16;
    primeCellID |= (rUART->UARTCID3 & 0xFF) << 24;

    return primeCellID;
}


void ncDrv_UART_EnDMAMode(tREG_UART *rUART, eUART_DMAE cr)
{
    rUART->UARTDMACR |= cr;
}

void ncDrv_UART_DisDMAMode(tREG_UART *rUART, eUART_DMAE cr)
{
    rUART->UARTDMACR &= ~(cr);
}

void ncDrv_UART_SetTxFIFOLevel(tREG_UART *rUART, eUART_TXFLS level)
{
    rUART->UARTIFLS &= ~FLS_TX_MASK;
    rUART->UARTIFLS |= level;
}

void ncDrv_UART_SetRxFIFOLevel(tREG_UART *rUART, eUART_RXFLS level)
{
    rUART->UARTIFLS &= ~FLS_RX_MASK;
    rUART->UARTIFLS |= level;
}


/* End Of File */
