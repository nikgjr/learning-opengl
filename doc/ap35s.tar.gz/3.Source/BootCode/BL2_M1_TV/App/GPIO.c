/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : GPIO_Drv.c
*
*  @brief   : Apache3 General Purpose Input/Output module driver source file
*
*  @author  : parkjy / SoCSW Team / TS Group
*
*  @date    : 2016.02.02
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*           INCLUDE
********************************************************************************
*/

#include "Apache35.h"
#include "GPIO.h"







/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/
void ncDrv_GPIO_SetDirection(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_DIR dir, UINT32 offset)
{
    switch(group)
    {
        case GPIO_GROUP_A:
        case GPIO_GROUP_B:
        {
            if( dir == GPIO_DIR_IN )
                REGRW32(rGPIO_BASE0, offset+(group*0x10)) &= ~(1<<port);
            else
                REGRW32(rGPIO_BASE0, offset+(group*0x10)) |= (1<<port);
        }
        break;

        case GPIO_GROUP_C:
        {
            if( dir == GPIO_DIR_IN )
                REGRW32(rGPIO_BASE1, rGPIO_DIR1) &= ~(1<<port);
            else
                REGRW32(rGPIO_BASE1, rGPIO_DIR1) |= (1<<port);
        }
        break;
    }
}


void ncDrv_GPIO_GetData(eGPIO_GROUP group, eGPIO_PORT port, UINT32 *data, UINT32 offset)
{
    switch(group)
    {
        case GPIO_GROUP_A:
        case GPIO_GROUP_B:
        {
            *data = (REGRW32(rGPIO_BASE0, offset+(group*0x10)) >> port) & 0x01;
        }
        break;

        case GPIO_GROUP_C:
        {
            *data = (REGRW32(rGPIO_BASE1, rGPIO_IN_PORT1) >> port) & 0x01;
        }
        break;
    }
}


void ncDrv_GPIO_SetData(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_DATA level, UINT32 offset)
{
    switch(group)
    {
        case GPIO_GROUP_A:
        case GPIO_GROUP_B:
        {
            if( level == GPIO_LOW )
                REGRW32(rGPIO_BASE0, offset+(group*0x10)) &= ~(1<<port);
            else
                REGRW32(rGPIO_BASE0, offset+(group*0x10)) |= (1<<port);
        }
        break;

        case GPIO_GROUP_C:
        {
            if( level == GPIO_LOW )
                REGRW32(rGPIO_BASE1, rGPIO_OUT_PORT1) &= ~(1<<port);
            else
                REGRW32(rGPIO_BASE1, rGPIO_OUT_PORT1) |= (1<<port);
        }
        break;
    }
}



/* End Of File */
