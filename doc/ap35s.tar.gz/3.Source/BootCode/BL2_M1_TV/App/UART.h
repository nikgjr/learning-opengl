/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : UART_Drv.h
*
*  @brief   : This file is UART Controller Driver for NEXTCHIP standard library
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.05
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : ARM PrimeCell�� UART (PL011) / Revision: r1p4
*
********************************************************************************
*/

#ifndef __UART_DRV_H__
#define __UART_DRV_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Type.h"


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
* UART Option ...
*/

#define RX_FIFO_SIZE        16

#define DEC_8               0
#define DEC_16              1
#define DEC_32              2


/*
* UART Register Structure
*/

#define rUART_0_BASE        APACHE_UART_0_BASE
#define rUART_1_BASE        APACHE_UART_1_BASE

#define UART0               ((tREG_UART *)rUART_0_BASE)
#define UART1               ((tREG_UART *)rUART_1_BASE)

#define rUARTPID0           0x0FE0  // RW, Uart Periph ID0 register
#define rUARTPID1           0x0FE4  // RW, Uart Periph ID1 register
#define rUARTPID2           0x0FE8  // RW, Uart Periph ID2 register
#define rUARTPID3           0x0FEC  // RO, Uart Periph ID3 register
#define rUARTCID0           0x0FF0  // RW, Uart PCell ID0 register
#define rUARTCID1           0x0FF4  // RW, Uart PCell ID1 register
#define rUARTCID2           0x0FF8  // RW, Uart PCell ID2 register
#define rUARTCID3           0x0FFC  // RW, Uart PCell ID3 register


/*
* Register Field
*/

/* UARTDR */
#define DR_OE               (1<<11)
#define DR_BE               (1<<10)
#define DR_PE               (1<<9)
#define DR_FE               (1<<8)
#define DR_DATA             (0xFF<<0)

/* UARTRSR/UARTECR */
#define RSR_OE              (1<<3)
#define RSR_BE              (1<<2)
#define RSR_PE              (1<<1)
#define RSR_FE              (1<<0)

/* UARTFR */
#define FR_RI               (1<<8)
#define FR_TXFE             (1<<7)
#define FR_RXFF             (1<<6)
#define FR_TXFF             (1<<5)
#define FR_RXFE             (1<<4)
#define FR_BUSY             (1<<3)
#define FR_DCD              (1<<2)
#define FR_DSR              (1<<1)
#define FR_CTS              (1<<0)

/* UARTILPR */
#define ILPR_ILPDVSR        (0xFF<<0)

/* UARTIBRD */
#define IBRD_DIVINT         (0xFFFF<<0)

/* UARTFBRD */
#define FBRD_DIVFRAC        (0x3F<<0)

/* UARTLCR_H */
#define LCR_SPS_EN          (1<<7)
#define LCR_SPS_DIS         (0<<7)
#define LCR_WLEN_8BIT       (3<<5)
#define LCR_WLEN_7BIT       (2<<5)
#define LCR_WLEN_6BIT       (1<<5)
#define LCR_WLEN_5BIT       (0<<5)
#define LCR_FIFO_EN         (1<<4)
#define LCR_FIFO_DIS        (0<<4)
#define LCR_STP2_EN         (1<<3)
#define LCR_STP2_DIS        (0<<3)
#define LCR_EPS_EN          (1<<2)
#define LCR_EPS_DIS         (0<<2)
#define LCR_PARITY_EN       (1<<1)
#define LCR_PARITY_DIS      (0<<1)
#define LCR_BRK             (1<<0)

/* UARTCR */
#define CR_CTS_EN           (1<<15)
#define CR_RTS_EN           (1<<14)
#define CR_OUT2             (1<<13)
#define CR_OUT1             (1<<12)
#define CR_RTS              (1<<11)
#define CR_DTR              (1<<10)
#define CR_RX_EN            (1<<9)
#define CR_TX_EN            (1<<8)
#define CR_LB_EN            (1<<7)
#define CR_SIRLP            (1<<2)
#define CR_SIR_EN           (1<<1)
#define CR_UART_EN          (1<<0)

/* UARTIFLS */
#define FLS_RX_7DIV8        (4<<3)
#define FLS_RX_3DIV4        (3<<3)
#define FLS_RX_1DIV2        (2<<3)
#define FLS_RX_1DIV4        (1<<3)
#define FLS_RX_1DIV8        (0<<3)
#define FLS_RX_MASK         (7<<3)

#define FLS_TX_7DIV8        (4<<0)
#define FLS_TX_3DIV4        (3<<0)
#define FLS_TX_1DIV2        (2<<0)
#define FLS_TX_1DIV4        (1<<0)
#define FLS_TX_1DIV8        (0<<0)
#define FLS_TX_MASK         (7<<0)

/* UARTIMSC */
#define IMSC_OEIM           (1<<10)
#define IMSC_BEIM           (1<<9)
#define IMSC_PEIM           (1<<8)
#define IMSC_FEIM           (1<<7)
#define IMSC_RTIM           (1<<6)
#define IMSC_TXIM           (1<<5)
#define IMSC_RXIM           (1<<4)
#define IMSC_DSRMIM         (1<<3)
#define IMSC_DCDMIM         (1<<2)
#define IMSC_CTSMIM         (1<<1)
#define IMSC_RIMIM          (1<<0)

/* UARTRIS */
#define RIS_OERIS           (1<<10)
#define RIS_BERIS           (1<<9)
#define RIS_PERIS           (1<<8)
#define RIS_FERIS           (1<<7)
#define RIS_RTRIS           (1<<6)
#define RIS_TXRIS           (1<<5)
#define RIS_RXRIS           (1<<4)
#define RIS_DSRRMIS         (1<<3)
#define RIS_DCDRMIS         (1<<2)
#define RIS_CTSRMIS         (1<<1)
#define RIS_RIRMIS          (1<<0)

/* UARTMIS */
#define MIS_OEMIS           (1<<10)
#define MIS_BEMIS           (1<<9)
#define MIS_PEMIS           (1<<8)
#define MIS_FEMIS           (1<<7)
#define MIS_RTMIS           (1<<6)
#define MIS_TXMIS           (1<<5)
#define MIS_RXMIS           (1<<4)
#define MIS_DSRMMIS         (1<<3)
#define MIS_DCDMMIS         (1<<2)
#define MIS_CTSMMIS         (1<<1)
#define MIS_RIMMIS          (1<<0)

/* UARTICR */
#define ICR_OEIC            (1<<10)
#define ICR_BEIC            (1<<9)
#define ICR_PEIC            (1<<8)
#define ICR_FEIC            (1<<7)
#define ICR_RTIC            (1<<6)
#define ICR_TXIC            (1<<5)
#define ICR_RXIC            (1<<4)
#define ICR_DSRMIC          (1<<3)
#define ICR_DCDMIC          (1<<2)
#define ICR_CTSMIC          (1<<1)
#define ICR_RIMIC           (1<<0)

/* UARTDMACR */
#define DMACR_DMAONERR      (1<<2)
#define DMACR_TXDMAE        (1<<1)
#define DMACR_RXDMAE        (1<<0)


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/


typedef enum
{
    /*
    * Generic Commands
    */

    GCMD_UT_INIT_CH = 0,
    GCMD_UT_DEINIT_CH,

    GCMD_UT_SET_BAUDRATE,
    GCMD_UT_GET_RX_FIFO_CNT,

    GCMD_UT_GET_CHAR,
    GCMD_UT_PUT_CHAR,
    GCMD_UT_GET_STRING,
    GCMD_UT_PUT_STRING,
    GCMD_UT_PRINT_STRING,

    GCMD_UT_CONNECT_ISR_HANDLER,
    GCMD_UT_DISCONNECT_ISR_HANDLER,

    GCMD_UT_CONNECT_USER_HANDLER,
    GCMD_UT_DISCONNECT_USER_HANDLER,

    GCMD_UT_EN_DMA_MODE,
    GCMD_UT_DIS_DMA_MODE,

    GCMD_UT_SET_TX_FIFO_LEVEL,
    GCMD_UT_SET_RX_FIFO_LEVEL,

    GCMD_UT_MAX,

} eUART_CMD;


typedef enum
{
    UART_CH0 = 0,
    UART_CH1,
    MAX_OF_UART_CH
} eUART_CH;

typedef enum
{
    UT_SPS_DIS = (0<<7),
    UT_SPS_ENA = (1<<7),
    MAX_OF_UART_SPS
} eUART_SPS;

typedef enum
{
    UT_DATA_5BIT = (0<<5),
    UT_DATA_6BIT = (1<<5),
    UT_DATA_7BIT = (2<<5),
    UT_DATA_8BIT = (3<<5),
    MAX_OF_UART_DATA_WLEN_BIT
} eUART_DATA_WLEN;

typedef enum
{
    UT_FIFO_DIS = (0<<4),
    UT_FIFO_ENA = (1<<4),
    MAX_OF_UART_FIFO
} eUART_FIFO;

typedef enum
{
    UT_STOP_1BIT = (0<<3),
    UT_STOP_2BIT = (1<<3),
    MAX_OF_UART_STOP_BIT
} eUART_STOP_BIT;

typedef enum
{
    UT_EPS_DIS = (0<<2),
    UT_EPS_ENA = (1<<2),
    MAX_OF_UART_EPS
} eUART_EPS;

typedef enum
{
    UT_PARITY_DIS = (0<<1),
    UT_PARITY_ENA = (1<<1),
    MAX_OF_UART_PARITY
} eUART_PARITY;

typedef enum
{
    UT_BRK_DIS = (0<<0),
    UT_BRK_ENA = (1<<0),
    MAX_OF_UART_BRK
} eUART_BRK;

typedef enum
{
    UT_BAUDRATE_300     = 300,
    UT_BAUDRATE_600     = 600,
    UT_BAUDRATE_1200    = 1200,
    UT_BAUDRATE_2400    = 2400,
    UT_BAUDRATE_4800    = 4800,
    UT_BAUDRATE_9600    = 9600,
    UT_BAUDRATE_19200   = 19200,
    UT_BAUDRATE_38400   = 38400,
    UT_BAUDRATE_57600   = 57600,
    UT_BAUDRATE_115200  = 115200,
    UT_BAUDRATE_230400  = 230400,
    UT_BAUDRATE_460800  = 460800,
    UT_BAUDRATE_921600  = 921600
} eUART_BAUDRATE;

typedef enum
{
    UT_DMAE_RX = (1<<0),
    UT_DMAE_TX = (1<<1),
    MAX_OF_UART_DMAE
} eUART_DMAE;

typedef enum
{
    UT_TXFLS_1DIV8 = (0<<0),
    UT_TXFLS_1DIV4 = (1<<0),
    UT_TXFLS_1DIV2 = (2<<0),
    UT_TXFLS_3DIV4 = (3<<0),
    UT_TXFLS_7DIV8 = (4<<0),
    MAX_OF_UART_TXFLS
} eUART_TXFLS;

typedef enum
{
    UT_RXFLS_1DIV8 = (0<<3),
    UT_RXFLS_1DIV4 = (1<<3),
    UT_RXFLS_1DIV2 = (2<<3),
    UT_RXFLS_3DIV4 = (3<<3),
    UT_RXFLS_7DIV8 = (4<<3),
    MAX_OF_UART_RXFLS
} eUART_RXFLS;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tUART_PARAM
{
    UINT32 uartClk;         // UART input clock
    UINT32 baudRate;        // UART baudrate

    eUART_SPS sps;          // Stick parity select
    eUART_DATA_WLEN wlen;   // Word length
    eUART_FIFO fen;         // Enable FIFOs
    eUART_STOP_BIT stp2;    // Two stop bits select
    eUART_EPS eps;          // Even parity select
    eUART_PARITY pen;       // Parity enable
    eUART_BRK brk;          // Send break
} tUART_PARAM, *ptUART_PARAM;


/*
* UART Register Control Structure
*/

typedef volatile struct _REG_UART
{
    UINT32 UARTDR;      // [0x000] Data Register
    UINT32 UARTRSR;     // [0x004] Receive Status Register[RSR]/Error Clear Register[ECR]
    UINT32 reserved_008_014[4];
    UINT32 UARTFR;      // [0x018] Flag Register
    UINT32 reserved_01c;
    UINT32 UARTILPR;    // [0x020] IrDA Low-Power Conunter Register
    UINT32 UARTIBRD;    // [0x024] Integer Baud Rate Register
    UINT32 UARTFBRD;    // [0x028] Fractional Baud Rate Register
    UINT32 UARTLCR_H;   // [0x02C] Line Control Register
    UINT32 UARTCR;      // [0x030] Control Register
    UINT32 UARTIFLS;    // [0x034] Interrupt FIFO Level Select Register
    UINT32 UARTIMSC;    // [0x038] Interrupt Mask Set/Clear Register
    UINT32 UARTRIS;     // [0x03C] Raw Interrupt Status Register
    UINT32 UARTMIS;     // [0x040] Masked Interrupt Status Register
    UINT32 UARTICR;     // [0x044] Interrupt Clear Register
    UINT32 UARTDMACR;   // [0x048] DMA Control Register

    UINT32 reserved_04C_fdc[997];
    UINT32 UARTPID0;    // [0xFE0] Uart Periph ID0 Register
    UINT32 UARTPID1;    // [0xFE4] Uart Periph ID1 Register
    UINT32 UARTPID2;    // [0xFE8] Uart Periph ID2 Register
    UINT32 UARTPID3;    // [0xFEC] Uart Periph ID3 Register
    UINT32 UARTCID0;    // [0xFF0] Uart PCell ID0 Register
    UINT32 UARTCID1;    // [0xFF4] Uart PCell ID1 Register
    UINT32 UARTCID2;    // [0xFF8] Uart PCell ID2 Register
    UINT32 UARTCID3;    // [0xFFC] Uart PCell ID3 Register
} tREG_UART, *ptREG_UART;


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern void ncDrv_UART_IRQ_Handler0(UINT32 nIrqNum);
extern void ncDrv_UART_IRQ_Handler1(UINT32 nIrqNum);
extern void ncDrv_UART_ISR_Handler(eUART_CH channel);

extern INT32 ncDrv_UART_ConnectUserHandler(eUART_CH channel, PrVoid UserHandler);
extern INT32 ncDrv_UART_DisConnectUserHandler(eUART_CH channel);

extern void ncDrv_UART_Initialize(tREG_UART *rUART, tUART_PARAM *param);
extern void ncDrv_UART_Deinitialize(tREG_UART *rUART);

extern void ncDrv_UART_SetBaudrate(tREG_UART *rUART, tUART_PARAM *param);
extern UINT8 ncDrv_UART_GetControl(tREG_UART *rUART, eUART_CMD nCmd);

extern void ncDrv_UART_putchar(tREG_UART *rUART, UINT8 ch);
extern void ncDrv_UART_print_string(tREG_UART *rUART, char *str);
extern void ncDrv_UART_putstr(tREG_UART *rUART, char *str);
extern int ncDrv_UART_getchar(tREG_UART *rUART);
extern int ncDrv_UART_writebytes(tREG_UART *rUart, void *buffer, int length);
extern int ncDrv_UART_readbytes(tREG_UART *rUART, void *buffer, int length);
extern void ncDrv_UART_printhex(tREG_UART *rUART, UINT8 hex);
extern void ncDrv_UART_printdec(tREG_UART *rUART, UINT32 num, UINT8 type);

extern void ncDrv_UART_printf(const char *fmt, ...);
extern char *ncDrv_UART_getstr(tREG_UART *rUART, char *s);

extern UINT32 ncDrv_UART_GetPeripheralID(tREG_UART *rUART);
extern UINT32 ncDrv_UART_GetPrimeCelllID(tREG_UART *rUART);

extern void ncDrv_UART_EnDMAMode(tREG_UART *rUART, eUART_DMAE cr);
extern void ncDrv_UART_DisDMAMode(tREG_UART *rUART, eUART_DMAE cr);

extern void ncDrv_UART_SetTxFIFOLevel(tREG_UART *rUART, eUART_TXFLS level);
extern void ncDrv_UART_SetRxFIFOLevel(tREG_UART *rUART, eUART_RXFLS level);

#endif  /* __UART_DRV_H__ */


/* End Of File */
