/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SCU_Drv.c
*
*  @brief   : SCU module driver source file
*
*  @author  : parkjy / SoC SW Team / TS Group
*
*  @date    : 2016.01.27
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/
/*
********************************************************************************
*                                 INCLUDE FILES
********************************************************************************
*/
#include "Apache35.h"
#include "Main.h"
#include "SCU.h"




/*
********************************************************************************
*                              LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*                           LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                                 LOCAL TYPEDEF
********************************************************************************
*/



/*
********************************************************************************
*                       IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                        GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

UINT32 g_cpu_clk;
UINT32 g_axi_clk;
UINT32 g_apb_clk;
UINT32 g_can_clk;


/*
********************************************************************************
*                       IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/

/*
********************************************************************************
*                            LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

/*
********************************************************************************
*                             FUNCTION DEFINITIONS
********************************************************************************
*/
void ncDrv_SCU_mDelay(UINT32 mSec)
{
    UINT32 i, j;

    for(i = 0; i < mSec; i++)
    {
        //for(j = 0; j < 100; j++);
        for(j = 0; j < 10000; j++);	// CPU 108MHz case
    }
}

void ncDrv_SCU_SetPad_V1(UINT32 Func, UINT32 Offset)
{
    REGRW32(rICU_BASE, Offset) &= ~0xf;
    REGRW32(rICU_BASE, Offset) |= ((1<<3)|(Func&0x7));
}

void ncDrv_SCU_SetPad_V2(UINT32 Func, UINT32 Offset, UINT32 Pos)
{
    REGRW32(rICU_BASE, Offset) &= ~(0x7<<Pos);
    REGRW32(rICU_BASE, Offset) |= ((Func&0x7)<<Pos);
}



INT32 ncDrv_SCU_SetPinMux(UINT32 Pad, UINT32 Func)
{
    INT32 ret = NC_SUCCESS;

    switch(Pad)
    {
        case PAD_GPIO0:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_10, 8);
        break;

        case PAD_GPIO1:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_10, 12);
        break;

        case PAD_GPIO2:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_10, 16);
        break;

        case PAD_GPIO3:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_10, 20);
        break;

        case PAD_GPIO4:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_10, 24);
        break;

        case PAD_EXTINT:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_14, 12);
        break;

        case PAD_I2C0_SCL:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_1C, 8);
        break;

        case PAD_I2C0_SDA:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_1C, 4);
        break;

        case PAD_I2C1_SCL:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_08, 0);
        break;

        case PAD_I2C2_SDA:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_04, 28);
        break;

        case PAD_CAN_RX:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_10, 4);
        break;

        case PAD_CAN_TX:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_10, 0);
        break;

        case PAD_UART_RX:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_0C, 28);
        break;

        case PAD_UART_TX:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_0C, 24);
        break;

        case PAD_SPI2_CSN0:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_04, 12);
        break;

        case PAD_SPI2_CSN1:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_04, 8);
        break;

        case PAD_SPI2_DQ0:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_04, 24);
        break;

        case PAD_SPI2_DQ1:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_04, 20);
        break;

        case PAD_SPI2_DQ2:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_08, 4);
        break;

        case PAD_SPI2_DQ3:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_08, 8);
        break;

        case PAD_SPI2_SCK:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_04, 16);
        break;

        case PAD_SEN_CK_O:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_1C, 20);
        break;

        case PAD_SEN_RSTN_O:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_1C, 12);
        break;

        case PAD_SEN_PCK:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_1C, 16);
        break;

        case PAD_SEN_PH:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_1C, 24);
        break;

        case PAD_SEN_PV:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_1C, 28);
        break;

        case PAD_SEN_PD0:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_20, 0);
        break;

        case PAD_SEN_PD1:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_20, 4);
        break;

        case PAD_SEN_PD2:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_00, 0);
        break;

        case PAD_SEN_PD3:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_00, 4);
        break;

        case PAD_SEN_PD4:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_00, 8);
        break;

        case PAD_SEN_PD5:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_00, 12);
        break;

        case PAD_SEN_PD6:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_00, 16);
        break;

        case PAD_SEN_PD7:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_00, 20);
        break;

        case PAD_SEN_PD8:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_00, 24);
        break;

        case PAD_SEN_PD9:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_00, 28);
        break;

        case PAD_SEN_PD10:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_04, 0);
        break;

        case PAD_SEN_PD11:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_04, 4);
        break;

        case PAD_VOUT_CK_O:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_08, 24);
        break;

        case PAD_VOUT_VSYNC:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_08, 16);
        break;

        case PAD_VOUT_HSYNC:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_08, 12);
        break;

        case PAD_VOUT_HACT:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_08, 20);
        break;

        case PAD_VOUT_B0:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_10, 28);
        break;

        case PAD_VOUT_B1:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_0C, 20);
        break;

        case PAD_VOUT_B2:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_0C, 16);
        break;

        case PAD_VOUT_B3:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_0C, 12);
        break;

        case PAD_VOUT_B4:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_0C, 8);
        break;

        case PAD_VOUT_B5:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_0C, 4);
        break;

        case PAD_VOUT_B6:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_0C, 0);
        break;

        case PAD_VOUT_B7:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_08, 28);
        break;

        case PAD_VOUT_G0_C0:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_18, 0);
        break;

        case PAD_VOUT_G1_C1:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_14, 28);
        break;

        case PAD_VOUT_G2_C2:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_14, 24);
        break;

        case PAD_VOUT_G3_C3:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_14, 20);
        break;

        case PAD_VOUT_G4_C4:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_14, 16);
        break;

        case PAD_VOUT_G5_C5:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_14, 8);
        break;

        case PAD_VOUT_G6_C6:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_14, 4);
        break;

        case PAD_VOUT_G7_C7:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_14, 0);
        break;

        case PAD_VOUT_R0_Y0:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_1C, 0);
        break;

        case PAD_VOUT_R1_Y1:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_18, 28);
        break;

        case PAD_VOUT_R2_Y2:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_18, 24);
        break;

        case PAD_VOUT_R3_Y3:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_18, 20);
        break;

        case PAD_VOUT_R4_Y4:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_18, 16);
        break;

        case PAD_VOUT_R5_Y5:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_18, 12);
        break;

        case PAD_VOUT_R6_Y6:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_18, 8);
        break;

        case PAD_VOUT_R7_Y7:
            ncDrv_SCU_SetPad_V2(Func, rICU_MUX_18, 4);
        break;

        default:
            ret = NC_FAILURE;
            break;
    }

    return ret;
}

UINT32 ncDrv_SCU_GetBootStrap(void)
{
    UINT32 PLL;

    PLL = REGRW32(rSCU_BASE, rSCU_STRAP_INFO);

    return PLL;
}

UINT32 ncDrv_SCU_GetData(UINT32 offset)
{
    return REGRW32(rSCU_BASE, (offset&0xFFF));
}

UINT32 ncDrv_SCU_SetData(UINT32 offset, UINT32 data)
{
    REGRW32(rSCU_BASE, (offset&0xFFF)) = data;

    return NC_SUCCESS;
}

UINT32 ncDrv_SCU_Virtual2Physical(UINT32 addr)
{
    UINT32 offset = 0;

    if(REGRW32(rSCU_BASE, rSCU_REMAP0_SET)&0x1)
    {
        if( addr < APACHE_BOOT_RAM )
            offset = REGRW32(rSCU_BASE, rSCU_REMAP0_EADDR);
    }

    return (addr+offset);
}

UINT32 ncDrv_SCU_Physical2Virtual(UINT32 addr)
{
    UINT32 offset = 0;

    if(REGRW32(rSCU_BASE, rSCU_REMAP0_SET)&0x1)
    {
        if( addr < APACHE_BOOT_RAM )
            offset = REGRW32(rSCU_BASE, rSCU_REMAP0_EADDR);
    }

    return (addr-offset);
}

INT32 ncDrv_SCU_Init(void)
{
    INT32  ret = NC_SUCCESS;
    UINT32 nPllClockSel = 0;
    UINT32 nDiv_xx;

#if BL2_JTAG_BOOT_ENABLE
    g_cpu_clk = FPGA_APB_CLOCK;
    g_axi_clk = FPGA_APB_CLOCK;
    g_apb_clk = FPGA_APB_CLOCK;
    g_can_clk = FPGA_CAN_CLOCK;
#else

    /*
     * System, CAN Clock Select ...
     * */

    // change CAN clock souce to PLL0

    nPllClockSel = (SYS_PLL0<<SEL_CAN_CLK) | (SYS_PLL0<<SEL_SYS_CLK);
    REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_SEL) = nPllClockSel;

    /*
     * System Clock Divider (ADC, CAN, DDR, APB, AXI, CPU, TS)
     * */

    g_cpu_clk = TV_PLL_CLOCK/1;
    g_axi_clk = TV_PLL_CLOCK/2;
    g_apb_clk = TV_PLL_CLOCK/4;
    g_can_clk = TV_CAN_CLOCK;

#if (TEST_ADC_RTC_BGR_2ND || TEST_ADC_RTC_BGR_3RD)
    g_cpu_clk = TV_PLL_CLOCK/1;	// 216
    g_axi_clk = TV_PLL_CLOCK/2;	// 108MHz
    g_apb_clk = TV_PLL_CLOCK/4;	// 54
    nDiv_xx = (4<<DIV_ADC_CLK) | (17<<DIV_CAN_CLK) | (0<<DIV_DDR_CLK) | (2<<DIV_APB_CLK) | (1<<DIV_AXI_CLK) | (0<<DIV_CPU_CLK);		// 216MHz
#else
    nDiv_xx = (4<<DIV_ADC_CLK) | (17<<DIV_CAN_CLK) | (0<<DIV_DDR_CLK) | (2<<DIV_APB_CLK) | (1<<DIV_AXI_CLK) | (0<<DIV_CPU_CLK);
#endif
    REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV1) = nDiv_xx;

    REGRW32(SYS_CON_BASE, rSCU_SYS_CLK_DIV2) = 5;

    //Clock Enable
    REGRW32(SYS_CON_BASE, 0x0004) = 0x0039FFFF;

#endif

    return ret;
}

UINT32 ncDrv_SCU_GetApbClock()
{
	return g_apb_clk;
}

UINT32 ncDrv_SCU_GetCanClock()
{
	return g_can_clk;
}


INT32 ncDrv_SCU_DeInit(void)
{
    INT32  ret = NC_SUCCESS;

    return ret;
}

/* End Of File */
