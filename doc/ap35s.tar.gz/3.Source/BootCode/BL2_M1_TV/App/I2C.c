/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : I2C_Drv.c
*
*  @brief   : I2C module driver source file
*
*  @author  : alessio / SoC SW Group / Platform Team
*
*  @date    : 2016.01.07
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : Argo I2C IP / Revision: 0.5
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache35.h"
#include "I2C.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define UART_BUFFER_SIZE        16


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

tI2C_INFO gI2cInfo[MAX_OF_I2C_CH];

/*
* For User Handler
*/
PrVoid ncDrv_I2C_UserHandler0 = NULL;
PrVoid ncDrv_I2C_UserHandler1 = NULL;


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

UINT32 ncDrv_I2C_BaseAddr(eI2C_CH channel)
{
    UINT32 base_addr;

    switch(channel)
    {
        case I2C_CH0:
            base_addr = rI2C_0_BASE;
        break;

        case I2C_CH1:
            base_addr = rI2C_1_BASE;
        break;
    }

    return base_addr;
}


void ncDrv_I2C_IRQ_Handler0(UINT32 nIrqNum)
{
    /*
    * Default ISR Routine
    */

    ncDrv_I2C_ISR_Handler(I2C_CH0);

    /*
    * User Handler Call Back Function
    */
    if(ncDrv_I2C_UserHandler0 != NULL)
    {
        ncDrv_I2C_UserHandler0();
    }
}


void ncDrv_I2C_IRQ_Handler1(UINT32 nIrqNum)
{
    /*
    * Default ISR Routine
    */

    ncDrv_I2C_ISR_Handler(I2C_CH1);

    /*
    * User Handler Call Back Function
    */
    if(ncDrv_I2C_UserHandler1 != NULL)
    {
        ncDrv_I2C_UserHandler1();
    }
}


void ncDrv_I2C_ISR_Handler(eI2C_CH channel)
{
    UINT8 status;

    status = REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR);



#if 0
    if(status & ISR_MACK)
    {
        DEBUGMSG_SDK(MSGINFO, "---I2C_ISR, Master ISR_MACK\n");

        REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) &= ~ISR_MACK;

        if(REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_LSR) & LSR_NACK)
        {
            gI2cInfo[channel].master.status = I2C_IMS_NACK;
        }
        else
        {
            gI2cInfo[channel].master.status = I2C_IMS_ACK;
        }
    }
    else if(status & ISR_MACKP)
    {
        DEBUGMSG_SDK(MSGINFO, "---I2C_ISR, Master ISR_MACKP\n");

        REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) &= ~ISR_MACKP;

        gI2cInfo[channel].master.status = I2C_IMS_ACK;
    }
    else
#endif
    if(status & ISR_SAM)
    {
        //DEBUGMSG_SDK(MSGINFO, "---I2C_ISR, Slave ISR_SAM\n");

        ncDrv_I2C_SetOpMode(channel, IM_SRX);

        REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) &= ~ISR_SAM;

        ncDrv_I2C_SetAck(channel);

        /* ToDo : Device ID check */
        //DEBUGMSG_SDK(MSGINFO, "channel=%d ISR_SAM:rI2c->SRXR=0x%04x\n", channel, REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_SRXR));

        if(REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_SRXR) & I2C_READ)
        {
            gI2cInfo[channel].slave.status = I2C_ISS_HOST_READ;

            #if (I2C_SLAVE_MODE_ACCESS == MODE_8BIT_ACCESS)
            ncDrv_I2C_sWriteSingleByte(channel, I2C_INDEX_DATA);   // data
            #else
            ncDrv_I2C_sWriteSingleWord(channel, I2C_INDEX_DATA);   // data high
            #endif

            ncDrv_I2C_SetOpMode(channel, IM_STX);
            //DEBUGMSG_SDK(MSGINFO, "Host Read\n");
        }
        else
        {
            gI2cInfo[channel].slave.status = I2C_ISS_HOST_WRITE;

            ncDrv_I2C_SetOpMode(channel, IM_SRX);
            //DEBUGMSG_SDK(MSGINFO, "Host Write\n");
        }

        //it makes 9th bit clock for ack or nack

        ncDrv_I2C_SetResume(channel);
    }
	else if(status & ISR_SACKP)
	{
        // Slave RX Prepare Ack (host WRITE to slave), occurs when each byte is received

        //DEBUGMSG_SDK(MSGINFO, "---I2C_ISR, Slave ISR_SACKP\n");

        REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) &= ~ISR_SACKP;

        //gI2cInfo[channel].slave.status = I2C_ISS_RXACK;

        /* ToDo : Address and Data check */
        if(gI2cInfo[channel].slave.status == I2C_ISS_HOST_WRITE)
        {
            #if (I2C_SLAVE_MODE_ACCESS == MODE_8BIT_ACCESS)
            if(gI2cInfo[channel].slave.rxIdx == 0)
            {
                ncDrv_I2C_sReadSingleByte(channel, I2C_INDEX_ADDR);   // address
            }
            else
            {
                ncDrv_I2C_sReadSingleByte(channel, I2C_INDEX_DATA);   // data
            }
            #else   // MODE_16BIT_ACCESS
            if(gI2cInfo[channel].slave.rxIdx < 2)
            {
                ncDrv_I2C_sReadSingleWord(channel, I2C_INDEX_ADDR);   // address
            }
            else
            {
                ncDrv_I2C_sReadSingleWord(channel, I2C_INDEX_DATA);   // data
            }
            #endif
        }
        else    // I2C_ISS_HOST_READ
        {
            gI2cInfo[channel].slave.status = I2C_ISS_RXACK;
        }

        ncDrv_I2C_SetAck(channel);
        ncDrv_I2C_SetResume(channel);
	}
    else if(status & ISR_SACK)
    {
        // Slave TX Ack (host READ from slave), occurs when after host read 1byte

        //DEBUGMSG_SDK(MSGINFO, "---I2C_ISR, Slave ISR_SACK\n");

        REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_ISR) &= ~ISR_SACK;

        //gI2cInfo[channel].slave.status = I2C_ISS_TXACK;

        if(gI2cInfo[channel].slave.status == I2C_ISS_HOST_READ)
        {
            #if (I2C_SLAVE_MODE_ACCESS == MODE_8BIT_ACCESS)
            if(gI2cInfo[channel].master.txIdx)
            {
                ncDrv_I2C_sWriteSingleByte(channel, I2C_INDEX_NONE);   // data ignore
            }
            #else   // MODE_16BIT_ACCESS
            if(gI2cInfo[channel].master.txIdx == 1)
            {
                ncDrv_I2C_sWriteSingleWord(channel, I2C_INDEX_DATA);   // data low
            }
            else
            {
                ncDrv_I2C_sWriteSingleWord(channel, I2C_INDEX_NONE);   // data ignore
            }
            #endif
        }
        else    // I2C_ISS_HOST_WRITE
        {
            gI2cInfo[channel].slave.status = I2C_ISS_TXACK;
        }

        ncDrv_I2C_SetResume(channel);
    }
}


INT32 ncDrv_I2C_ConnectUserHandler(eI2C_CH channel, PrVoid UserHandler)
{
    INT32 ret = NC_SUCCESS;

    switch(channel)
    {
        case I2C_CH0:
            ncDrv_I2C_UserHandler0 = (PrVoid) UserHandler;
        break;

        case I2C_CH1:
            ncDrv_I2C_UserHandler1 = (PrVoid) UserHandler;
        break;

        default:
            ret = NC_FAILURE;
        break;
    }

    return ret;
}


INT32 ncDrv_I2C_DisConnectUserHandler(eI2C_CH channel)
{
    INT32 ret = NC_SUCCESS;

    switch(channel)
    {
        case I2C_CH0:
            ncDrv_I2C_UserHandler0 = (PrVoid) NULL;
        break;

        case I2C_CH1:
            ncDrv_I2C_UserHandler1 = (PrVoid) NULL;
        break;

        default:
            ret = NC_FAILURE;
        break;
    }

    return ret;
}


void ncDrv_I2C_DeInitialize(eI2C_CH channel)
{
   REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_OPR) = (OPR_RESET|OPR_CORE_DI);
}


void ncDrv_I2C_SetClock(eI2C_CH channel, UINT32 pclock, UINT32 sclk)
{
    UINT32 DIV;         /* SCL Divisor */
    UINT32 DIV1, DIV2;  /* DIV1 [5:3], DIV2[2:0] */
    UINT32 x, y;        /* X [5:3], Y [2:0] */
    UINT32 diff;
    UINT32 temp;

    DIV = pclock / (sclk * 5);

    diff = DIV - 1;

    for(x = 0; x < 8; x++)      // [5:3]
    {
        for(y = 0; y < 8; y++)  // [2:0]
        {
            /*
            * SCL Divisor = (I2CCDVR[5:3]+1) * 2^(I2CCDVR[2:0]+1)
            */
            temp = (x + 1) * (0x1 << (y + 1));

            if(temp < DIV)
            {
                if(DIV - temp < diff)
                {
                    diff = DIV - temp;
                    DIV1 = x;
                    DIV2 = y;
                }
            }
        }
    }

    DIV = ((DIV1 << 3) | DIV2);

    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_DIV) = DIV;

    //DEBUGMSG_SDK(MSGINFO, "I2c Div : 0x%02x, SCL: %d, Real SCL: %d\n", DIV, sclk, (pclock/(5*((DIV1+1) * (0x1<<(DIV2+1))))));
}


void ncDrv_I2C_SetByteOrder(eI2C_CH channel, eI2C_BYTE_ORDER byteOrder)
{
    gI2cInfo[channel].byteOrder = byteOrder;
}


UINT32 ncDrv_I2C_GetByteOrder(eI2C_CH channel)
{
    return gI2cInfo[channel].byteOrder;
}


void ncDrv_I2C_SetOpMode(eI2C_CH channel, eI2C_MODE mode)
{
#if 0
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_CONR) &= ~(CONR_MMASK|CONR_SMASK);
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_CONR) |= mode;
#else
    if(mode & CONR_MMASK)
    {
        REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_CONR) &= ~(CONR_MMASK);
    }

    if(mode & CONR_SMASK)
    {
        REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_CONR) &= ~(CONR_SMASK);
    }

    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_CONR) |= mode;
#endif
}


void ncDrv_I2C_SetAck(eI2C_CH channel)
{
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_CONR) &= ~CONR_NACK;
}


void ncDrv_I2C_SetNack(eI2C_CH channel)
{
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_CONR) |= CONR_NACK;
}


void ncDrv_I2C_SetResume(eI2C_CH channel)
{
    REGRW32(ncDrv_I2C_BaseAddr(channel), rI2C_LCMR) = LCMR_RESUME;
}


void ncDrv_I2C_Delay(UINT32 count)
{
    UINT32 i; //, j;

    for(i = 0; i < count; i++)
    {
        //for(j = 0; j < 500; j++);
        //for(j = 0; j < 1000; j++);
        //for(j = 0; j < 2500; j++);
        //for(j = 0; j < 5000; j++);
    }
}


/* End Of File */
