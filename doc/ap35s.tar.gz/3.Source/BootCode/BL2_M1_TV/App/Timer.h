/*
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Timer_Drv.h
*
*  @brief   : This file is Timer Controller Driver for NEXTCHIP standard library
*
*  @author  : parkjy / SoC SW Group / Platform Team
*
*  @date    : 2013.11.18
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note      :
*
*
********************************************************************************
*/
#ifndef __TIMER_DRV_H__
#define __TIMER_DRV_H__

/*
********************************************************************************
*           INCLUDE FILES
********************************************************************************
*/

/*
********************************************************************************
*                   	           DEFINES
********************************************************************************
*/
/*
 * REGISTER STRUCTURE
 */
#define rTIMER_BASE         APACHE_TIMER_BASE
#define rTIMER_0_BASE       (rTIMER_BASE+0x0000)
#define rTIMER_1_BASE       (rTIMER_BASE+0x0020)

#define rTIMER_LOAD			0x0000	// RW, Decrement Counter Load Register (reload only periodic mode)
#define rTIMER_VALUE		0x0004 	// RO, Current Value Register (decrementing counter)
#define rTIMER_CTRL			0x0008	// RW, Timer Control Register
	#define TCON_ENABLE			(7)
	#define TCON_MODE_FREERUN	(6)
	#define TCON_MODE_PERIOD	(6)
	#define TCON_INT_ONOFF		(5)
	#define TCON_PRESCALE_1		(0<<2)
	#define TCONL_PRESCALE_16	(1<<2)
	#define TCON_PRESCALE_256	(2<<2)
	#define TCON_PRESCALE		(2)
	#define TCON_SIZE_32BIT		(1)
	#define TCON_COUNT_MODE		(0)
#define rTIMER_INTCLR		0x000C	// WO, Interrupt Clear Register
	#define TCON_INT_CLR		1
#define rTIMER_RIS			0x0010	// RO, Raw Interrupt Status Register
#define rTIMER_MIS			0x0014	// RO, Interrupt Status Register
#define rTIMER_BGLOAD		0x0018	// RO, Background Load Register



#define rSUBTIMER_BASE      APACHE_SUBTIMER_BASE
    #define T34_PWM_CONT    7
    #define T2_PWM_CONT     6
    #define T4_TIME_CLR     5
    #define T4_TIME_EN      4
    #define T3_TIME_CLR     3
    #define T3_TIME_EN      2
    #define T2_TIME_CLR     1
    #define T2_TIME_EN      0

#define rTIMER_2_BASE       (rSUBTIMER_BASE+0x04)
#define rTIMER_3_BASE       (rSUBTIMER_BASE+0x18)
#define rTIMER_4_BASE       (rSUBTIMER_BASE+0x2C)

#define rTIMER_MOD          0x0000
    #define TMOD_DIV        4
    #define TMOD_INTER      (0<<2)
    #define TMOD_PWM        (3<<2)
    #define TMOD_OVFEN      (1<<1)
    #define TMOD_MATEN      (1<<0)
#define rTIMER_DLSB         0x0004
#define rTIMER_DMSB         0x0008
#define rTIMER_CLSB         0x000C
#define rTIMER_CMSB         0x0010











/*
********************************************************************************
*                                ENUMERATION
********************************************************************************
*/
typedef enum
{
    TM_PERIOD,
    TM_PWM,
    TM_ONESHOT,
    TM_CAPTURE,
    TM_FREERUN,
    MAX_OF_TIMER_MODE
} eTIMER_MODE;

typedef enum
{
    TCMD_STOP,
    TCMD_START,
    TCMD_CLEAR,
    MAX_OF_TIMER_COMMAND
} eTIMER_COMMAND;

typedef enum
{
    TCS_PCLKDIV2,
    TCS_PCLKDIV4,
    TCS_PCLKDIV16,
    TCS_PCLKDIV64,
    TCS_PMUOUT_CLK,
    TCS_EXTCLK,
    MAX_OF_TIMER_CLK_SRC
} eTIMER_CLK_SRC;

typedef enum
{
    TCT_RISING_EDGE,    // high term counting
    TCT_FALLING_EDGE,   // low term counting
    MAX_OF_TIMER_CLR_TYPE
} eTIMER_CLR_TYPE;

typedef enum
{
    TFT_NONE,
    TFT_DELAY,      // waiting to timeout in function
    TFT_COUNT,      // need to check timeout using TIMER_CheckExpired()
    TFT_CALLBACK,
    MAX_OF_TIMER_FUNC_TYPE
} eTIMER_FUNC_TYPE;

typedef enum
{
    TCS_NONE,
    TCS_CAPTURE_DONE,
    TCS_OVERFLOW,
    MAX_OF_TIMER_CAPTURE_STATUS
} eTIMER_CAPTURE_STATUS;

typedef enum
{
    TOS_NONE,
    TOS_DONE,
    MAX_OF_TIMER_ONESHOT_STATUS
} eTIMER_ONESHOT_STATUS;

typedef enum
{
    TIT_MATCH0,     // = TCON_TIF0,
    TIT_MATCH1,     // = TCON_TIF1,
    TIT_OVERFLOW,   // = TCON_TOVF,
    TIT_MATCH_ALL,  // = TCON_TIF10 and TCON_TIF1,
    MAX_OF_TIMER_INT_TYPE
} eTIMER_INT_TYPE;

typedef enum
{
    TTP_LOW,		// PWM Low Level Start
    TTP_HIGH,		// PWM High Level Start
    MAX_OF_TIMER_TOUT_POLARITY
} eTIMER_TOUT_POLARITY;





typedef enum _TIMER_CMD
{
    /*
    * Generic Timer / Count Commands
    */
    GCMD_TC_INIT_CH = 0,
    GCMD_TC_START,
    GCMD_TC_STOP,
    GCMD_TC_SET_PERIOD_TIME,            // Apache3.5 Not Support
    GCMD_TC_CHK_ONESHOT_DONE,
    GCMD_TC_CONNECT_USER_HANDLER,
    GCMD_TC_DISCONNECT_USER_HANDLER,
    GCMD_TC_MAX,

    /*
    * Specific Timer / Count Commands
    */
    SCMD_TC_DUMMY = 100,
    SCMD_TC_MAX,
} eTIMER_CMD;


typedef enum _TIMER_CH
{
    TC_CH0 = 0,
    TC_CH1,
    TC_CH2,                 // PWM Mode
    TC_CH3,                 // PWM Mode
    TC_CH4,                 // PWM Mode
    TC_CH_MAX
} TIMER_CH;


typedef enum _TIMER_CLK_SRC
{
    TC_CLK_DIV2 = 0,        // Clock / 2
    TC_CLK_DIV4,            // Clock / 4
    TC_CLK_DIV16,           // Clock / 16
    TC_CLK_DIV64,           // Clock / 64
    TC_CLK_EXT0,            // Reserved
    TC_CLK_EXT1,            // Reserved
    TC_CLK_MAX
} TIMER_CLK_SRC;


typedef enum _TIMER_MODE
{
    TC_MODE_PERIOD = 0,
    TC_MODE_PWM,
    TC_MODE_ONESHOT,
    TC_MODE_CAPTURE,	    // Apache3.5 Not Used
    TC_MODE_MAX
} TIMER_MODE;


typedef enum _TIMER_TRIG_MODE
{
    TC_TRIG_LEVEL_HIGH = 0,
    TC_TRIG_LEVEL_LOW,
    TC_TRIG_EDGE_HIGH,
    TC_TRIG_EDGE_LOW,
    TC_TRIG_MAX
} TIMER_TRIG_MODE;







/*
********************************************************************************
*                             TYPEDEFS
********************************************************************************
*/
typedef void (*pfTimerCallback)(void);

typedef struct
{
    BOOL expired;
    UINT32 tickCnt;
    UINT32 timeOut;
    eTIMER_FUNC_TYPE type;
    pfTimerCallback callback;
    eTIMER_MODE mode;
    UINT16 capLowTerm;
    UINT16 capHighTerm;
    eTIMER_CAPTURE_STATUS capStatus;
    eTIMER_ONESHOT_STATUS oneshotStatus;
    eTIMER_CLR_TYPE clrType;
    BOOL capIntA;
} tTIMER_INFO;


typedef struct _TC_INIT_PARAM {
    UINT8  mMode;               // 0: Period, 1: PWM, 2: Oneshot
    UINT8  mClockSource;        // Apache3.5 Not Used.
    UINT8  mPrescaler;          // 1 or 16 or 255
    UINT8  mTrigMode;           // Apache3.5 Not Used.
    UINT32 mPeriod1;            // 1'st period (usec)
    UINT32 mPeriod2;            // Apache3.5 Not Used.
} tTC_INIT_PARAM, *ptTC_INIT_PARAM;



/*
********************************************************************************
*                             CONSTANT DEFINITIONS
********************************************************************************
*/
#define MAX_TIMER_CH       				5










/*
********************************************************************************
*                             VARIABLE DECLARATIONS
********************************************************************************
*/
extern UINT32 gnTimerInClock;
extern UINT32 gaTimerClock[TC_CH_MAX];
extern UINT32 gaTimerDivider[TC_CH_MAX];
extern UINT32 gaTimerTickCount[TC_CH_MAX];
extern FP32   gaTimerTickUnitTime[TC_CH_MAX];










/*
********************************************************************************
*                             FUNCTION DECLARATIONS
********************************************************************************
*/
extern void   ncDrv_TIMER_ISR_Handler(TIMER_CH channel);
extern void   ncDrv_TIMER_IRQ_Handler0(void *param);
extern void   ncDrv_TIMER_IRQ_Handler1(void *param);
extern void   ncDrv_TIMER_IRQ_Handler2(void *param);
extern void   ncDrv_TIMER_IRQ_Handler3(void *param);
extern void   ncDrv_TIMER_IRQ_Handler4(void *param);
extern INT32  ncDrv_TIMER_ConnectUserHandler(TIMER_CH channel, PrVoid UserHandler);
extern INT32  ncDrv_TIMER_DisConnectUserHandler(TIMER_CH channel);
extern INT32  ncDrv_TIMER_GetOneShotModeDone(TIMER_CH channel);
extern INT32  ncDrv_TIMER_Start(TIMER_CH channel);
extern INT32  ncDrv_TIMER_Stop(TIMER_CH channel);
extern INT32  ncDrv_TIMER_Init(TIMER_CH channel, ptTC_INIT_PARAM ptTcParam);
extern INT32  ncDrv_TIMER_Open(UINT32 nInputClk);

#endif  /* __TIMER_DRV_H__ */


/* End Of File */

