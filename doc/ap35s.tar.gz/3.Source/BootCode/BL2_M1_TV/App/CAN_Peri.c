/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : CAN_Drv_PeriCAN.c
*
*  @brief   : Apache3 CAN2.0B module driver source file
*
*  @author  : alessio / TS Group / SoC SW Team
*
*  @date    : 2016.02.16
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*           INCLUDE
********************************************************************************
*/

#include "Main.h"


#include "CAN.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void ncDrv_CAN_ISRPeriCANHandler()
{
    int i, extended, intr_status;

    intr_status = REGRW32(ncDrv_CAN_BaseAddr(), rCANB_IR) & 0xFF;

    //DEBUGMSG_SDK(MSGINFO, "can isr interrupt status 0x%X\n", intr_status);

    if(intr_status & CAN_IR_RI)
    {
        if((i = ncDrv_CAN_SetRxMsgBoxIndex()) != NC_FAILURE)
        {
            extended = (REGRW32(ncDrv_CAN_BaseAddr(), rCANP_FIR) & 0x80) >> CAN_FI_FF_SHIFT;

            gp_CanRxMsgBox[i].format = (eCAN_FI_FRAME)extended;

            if(extended == CAN_FI_EXTENDED_FORMAT)
            {
                ncDrv_CAN_PeriEFF_Receive(&gp_CanRxMsgBox[i]);
            }
            else
            {
                ncDrv_CAN_PeriSFF_Receive(&gp_CanRxMsgBox[i]);
            }

            gCanInterruptDone = CAN_DONE;
        }

        REGRW32(ncDrv_CAN_BaseAddr(), rCANB_CMR) |= (CAN_CMR_CDO | CAN_CMR_RRB);
    }
    else
    {
        UINT32 sr, alc, ecc, ewl, rxec, txec;

        REGRW32(ncDrv_CAN_BaseAddr(), rCANB_CMR) |= (CAN_CMR_CDO | CAN_CMR_RRB);

        sr = REGRW32(ncDrv_CAN_BaseAddr(), rCANB_SR);

        alc = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_ALC);
        ecc = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_ECC);
        ewl = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EWLR);

        rxec = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_RXERR);
        txec = REGRW32(ncDrv_CAN_BaseAddr(), rCANP_TXERR);

        //+ DEBUGMSG_SDK(MSGERR, "Error, isr Interrupt status 0x%02X \n", intr_status);
        //+ DEBUGMSG_SDK(MSGERR, "Error, isr status sr(0x%02X), alc(0x%02X), ecc(0x%02X), ewl(0x%02X)\n", sr, alc, ecc, ewl);
        //+ DEBUGMSG_SDK(MSGERR, "Error, isr status srxec(0x%02X), txec(0x%02X)\n", rxec, txec);
    }
}


int ncDrv_CAN_PeriSFF_Receive(tCAN_MSG *sffmsg)
{
    unsigned char i, rtr, dlc;
    unsigned int id;
    int Result = NC_SUCCESS;

    rtr = (UINT8)(gp_RegCanRxSFF->RXFI>>6) & 0x1;
    dlc = (UINT8)(gp_RegCanRxSFF->RXFI) & 0xF;

    id = (gp_RegCanRxSFF->RXID[1] & 0xFF);
    id |= (gp_RegCanRxSFF->RXID[0] & 0xFF) << 8;

    sffmsg->rtr = (eCAN_FI_RTR)rtr;
    sffmsg->length = dlc;
    sffmsg->id = id>>5;

    for(i = 0; i < dlc; i++)
    {
        sffmsg->data[i] = (UINT8)gp_RegCanRxSFF->RXDATA[i];
    }

    return Result;
}


int ncDrv_CAN_PeriEFF_Receive(tCAN_MSG *effmsg)
{
    unsigned char i, rtr, dlc;
    unsigned int id;
    int Result = NC_SUCCESS;

    rtr = (UINT8)(gp_RegCanRxEFF->RXFI>>6) & 0x1;
    dlc = (UINT8)(gp_RegCanRxEFF->RXFI) & 0xF;

    id = (gp_RegCanRxEFF->RXID[3] & 0xFF);
    id |= (gp_RegCanRxEFF->RXID[2] & 0xFF) << 8;
    id |= (gp_RegCanRxEFF->RXID[1] & 0xFF) << 16;
    id |= (gp_RegCanRxEFF->RXID[0] & 0xFF) << 24;

    effmsg->rtr = (eCAN_FI_RTR)rtr;
    effmsg->length = dlc;
    effmsg->id = id>>3;

    for(i = 0; i < dlc; i++)
    {
        effmsg->data[i] = (UINT8)gp_RegCanRxEFF->RXDATA[i];
    }

    return Result;
}


int ncDrv_CAN_PeriSetup(UINT32 inputclk, tCAN_PARAM *config)
{
    int Result = NC_SUCCESS;

    //+ DEBUGMSG_SDK(MSGINFO, "CAN2.0B PeriCAN mode, %s %s setup\n", config->info.format == 0 ? "Standard" : "Extended", "format");

    gCanInfo = config->info;

    // Switch-on reset mode
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_MOD) = (CAN_MOD_RM);

    // Set the periCAN mode and clock divider
    ncDrv_CAN_SetCanMode();
    REGRW32(ncDrv_CAN_BaseAddr(), rCANB_CDR) |= CAN_CDR_CLKOFF;

    // Switch-on reset mode
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_MOD) = (CAN_MOD_AFM | CAN_MOD_RM);   // single filter set

    // Set command register to zero 
    REGRW32(ncDrv_CAN_BaseAddr(), rCANB_CMR) = 0;

    // Set the error warning limit to 96
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_EWLR) = 0x60;

    // Disable all interrupts
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_IER) = 0;

    // Setting the bus timing
    //ncDrv_CAN_SetBusTimingBaudrate(channel, inputclk, config->baudrate);
    ncDrv_CAN_SetBusTimingBaudrate_kvaser(inputclk, config->baudrate);

    // Set all acceptance code registers to 0xFF. Received messages must have these bits set
    ncDrv_CAN_SetAcceptanceFilter(config->info.format, config->acrId, config->amrId);

    // Reset receive error counter
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_RXERR) = 0;

    // Reset transmit error counter 
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_TXERR) = 0;

    // Switch-off reset mode
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_MOD) &= ~CAN_MOD_RM;

    // Interrupt Enable, Receive Interrupt Enable

#if 1 // alessio_20150717 : interrupt mode default
    //if(gCanInfo[channel].intr_en == CAN_INTERRUPT_TYPE)
    {
        REGRW32(ncDrv_CAN_BaseAddr(), rCANP_IER) = (CAN_IER_RIE);
    }
#else
    else
    {
        REGRW32(ncDrv_CAN_BaseAddr(channel), rCANP_IER) = (CAN_IER_RIE|CAN_IER_EIE|CAN_IER_DOIE|CAN_IER_EPIE|CAN_IER_ALIE|CAN_IER_BEIE);
    }
#endif

    return Result;
}


int ncDrv_CAN_PeriSend(tCAN_MSG *txmsg)
{
    int i;
    int Result = NC_SUCCESS;

    //+ DEBUGMSG_SDK(MSGINFO, "CAN2.0B PeriCAN %s tx send\n", "Operation");

    // Tx frame information
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_FIR) = (txmsg->format<<7) | (txmsg->rtr<<6) | (txmsg->length&0x0F);

    if(txmsg->format == CAN_FI_EXTENDED_FORMAT)
    {
        gp_RegCanTxEFF->TXID[0] = (txmsg->id>>21) & 0xFF; // ID.[28-21]
        gp_RegCanTxEFF->TXID[1] = (txmsg->id>>13) & 0xFF; // ID.[20-13]
        gp_RegCanTxEFF->TXID[2] = (txmsg->id>>5)  & 0xFF; // ID.[12-5]
        gp_RegCanTxEFF->TXID[3] = (txmsg->id<<3)  & 0xF8; // ID.[4-0] last 3bits are don care.

        // Tx n bytes
        for(i = 0; i < txmsg->length; i++)
        {
            gp_RegCanTxEFF->TXDATA[i] = txmsg->data[i];
        }
    }
    else
    {
        gp_RegCanTxSFF->TXID[0] = (txmsg->id>>3) & 0xFF; // ID.[28-21]
        gp_RegCanTxSFF->TXID[1] = (txmsg->id<<5) & 0xE0; // ID.[20-13]

        // Tx n bytes
        for(i = 0; i < txmsg->length; i++)
        {
            gp_RegCanTxSFF->TXDATA[i] = txmsg->data[i];
        }
    }

    // Transmission request
    REGRW32(ncDrv_CAN_BaseAddr(), rCANB_CMR) = CAN_CMR_TR;

    Result = ncDrv_CAN_SendComplete();
    if(Result == NC_FAILURE)
    {
        //+ DEBUGMSG_SDK(MSGERR, "Error, PeriCAN Send Status 0x%02X\n", REGRW32(ncDrv_CAN_BaseAddr(channel), rCANB_SR));
    }

    return Result;
}


int ncDrv_CAN_PeriReceive(tCAN_MSG *rxmsg)
{
    int i, msgch;
    int Result = NC_SUCCESS;
    unsigned int intr_status;

    //DEBUGMSG_SDK(MSGINFO, "CAN2.0B PeriCAN operation rx receive\n");

#if 1 // alessio_20150717 : interrupt mode default
    //if(gCanInfo[channel].intr_en == CAN_INTERRUPT_TYPE)
    {
        // Wait until can receives rx irq
        //while(!ncDrv_CAN_GetInterruptDone(channel));    // todo : ...

    	for(i=0;i<CAN_TIME_OUT;i++)
    	{
    		intr_status = REGRW32(ncDrv_CAN_BaseAddr(), rCANB_IR) & 0xFF;
			if (intr_status) {
				ncDrv_CAN_ISR_Handler();
				break;
			}
    	}

        if(!ncDrv_CAN_GetInterruptDone())
        {
            Result = NC_FAILURE;
            //DEBUGMSG_SDK(MSGERR, "Error, PeriCAN receive NONE interrupt 0x%02X \n", REGRW32(ncDrv_CAN_BaseAddr(channel), rCANB_IR));

            goto receive_error;
        }


        #if 0
        if(timeout == 0)
        {
            DEBUGMSG_SDK(MSGERR, "Error, PeriCAN receive timeout, interrupt 0x%02X \n", REGRW32(ncDrv_CAN_BaseAddr(channel), rCANB_IR));

            Result = NC_FAILURE;
            goto receive_error;
        }
        #endif
    }
#else
    else
    {
        while(!(ncDrv_CAN_GetIntrruptStatus(channel) & CAN_IR_RI));

        if(timeout == 0)
        {
            DEBUGMSG_SDK(MSGERR, "Error, PeriCAN receive timeout, interrupt 0x%02X \n", REGRW32(ncDrv_CAN_BaseAddr(channel), rCANB_IR));

            Result = NC_FAILURE;
            goto receive_error;
        }

        if(ncDrv_CAN_GetIntrruptStatus(channel) & CAN_IR_DOI)
        {
            DEBUGMSG_SDK(MSGERR, "Error, PeriCAN receive data overflow, status 0x%02X \n", REGRW32(ncDrv_CAN_BaseAddr(channel), rCANB_SR));

            Result = NC_FAILURE;
            goto receive_error;
        }

        if(ncDrv_CAN_GetErrorStatus(channel) & CAN_SR_RBS)
        {
            UINT32 extended;

            if((i = ncDrv_CAN_SetRxMsgBoxIndex(channel)) != NC_FAILURE)
            {
                extended = (REGRW32(ncDrv_CAN_BaseAddr(channel), rCANP_FIR) & 0x80) >> CAN_FI_FF_SHIFT;

                gp_CanRxMsgBox[channel][i].format = (eCAN_FI_FRAME)extended;
                gp_CanRxMsgBox[channel][i].mode = CAN_CDR_PERI_MODE;

                if(extended == CAN_FI_EXTENDED_FORMAT)
                {
                    ncDrv_CAN_PeriEFF_Receive(channel, &gp_CanRxMsgBox[channel][i]);
                }
                else
                {
                    ncDrv_CAN_PeriSFF_Receive(channel, &gp_CanRxMsgBox[channel][i]);
                }
            }

            REGRW32(ncDrv_CAN_BaseAddr(channel), rCANB_CMR) |= CAN_CMR_RRB;
        }
        else
        {
            DEBUGMSG_SDK(MSGERR, "Error, PeriCAN receive FIFO empty, status 0x%02X \n", REGRW32(ncDrv_CAN_BaseAddr(channel), rCANB_SR));

            Result = NC_FAILURE;
            goto receive_error;
        }
    }
#endif

    msgch = ncDrv_CAN_GetRxMsgBoxIndex();

    rxmsg->format = gp_CanRxMsgBox[msgch].format;
    rxmsg->rtr = gp_CanRxMsgBox[msgch].rtr;

    rxmsg->id = gp_CanRxMsgBox[msgch].id;
    rxmsg->length = gp_CanRxMsgBox[msgch].length;

    for(i = 0; i < rxmsg->length; i++)
    {
        rxmsg->data[i] = gp_CanRxMsgBox[msgch].data[i];
    }

    ncDrv_CAN_ClearRxMsgBoxIndex();

    if(rxmsg->rtr == CAN_FI_REMOTE_FRAME)
    {
        //+ DEBUGMSG_SDK(MSGINFO, "PeriCAN Remote Transmission Request !!!\n");
    }

receive_error:

    return Result;
}


int ncDrv_CAN_PeriRemoteRequest(tCAN_MSG *rxmsg)
{
    int i;
    tCAN_MSG txmsg;
    int Result = NC_SUCCESS;

    if(rxmsg->rtr != CAN_FI_REMOTE_FRAME)
    {
        //DEBUGMSG_SDK(MSGINFO, "CAN Rx Transmission Data Frame\n");
        //DEBUGMSG_SDK(MSGINFO, "status 0x%02X \n", REGRW32(ncDrv_CAN_BaseAddr(channel), rCANB_SR));
        //DEBUGMSG_SDK(MSGINFO, "interrupt status 0x%02X \n", REGRW32(ncDrv_CAN_BaseAddr(channel), rCANB_IR));

        return Result;
    }

    txmsg.id = rxmsg->id;
    txmsg.length = 8;

    for(i = 0; i < txmsg.length; i++)
    {
        txmsg.data[i] = 0x30+i;
    }

    txmsg.objch = CAN_MSGOBJ_ACTIVE;
    txmsg.format = rxmsg->format;
    txmsg.rtr = CAN_FI_DATA_FRAME;

    ncDrv_CAN_PeriSend(&txmsg);

    //+ DEBUGMSG_SDK(MSGINFO, "CAN Rx Transmission Request Remote Frame\n");

    return Result;
}


int ncDrv_CAN_PeriSelfTest_Setup(UINT32 inputclk, tCAN_PARAM *config)
{
    int Result = NC_SUCCESS;

    //DEBUGMSG_SDK(MSGINFO, "CAN2.0B PeriCAN %s mode setup\n", "SelfTest");

    gCanInfo = config->info;

    // Switch-on reset mode
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_MOD) = CAN_MOD_RM;

    // Set the periCAN mode and clock divider
    ncDrv_CAN_SetCanMode();
    //REGRW32(ncDrv_CAN_BaseAddr(channel), rCANB_CDR) |= CAN_CDR_CLKOFF;

    // Switch-on reset mode
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_MOD) = (CAN_MOD_AFM | CAN_MOD_STM | CAN_MOD_RM);

    // Setting the bus timing
    //ncDrv_CAN_SetBusTimingBaudrate(channel, inputclk, config->baudrate);
    ncDrv_CAN_SetBusTimingBaudrate_kvaser(inputclk, config->baudrate);

#if 0
    // Set all acceptance code registers to 0xFF. Received messages must have these bits set
    ncDrv_CAN_SetAcceptanceFilter(channel, CAN_CDR_PERI_MODE, config->acrId, config->amrId);
#else
    REGRW32(ncDrv_CAN_BaseAddr(), 16*4) = 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), 17*4) = 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), 18*4) = 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), 19*4) = 0xFF;

    REGRW32(ncDrv_CAN_BaseAddr(), 20*4) = 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), 21*4) = 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), 22*4) = 0xFF;
    REGRW32(ncDrv_CAN_BaseAddr(), 23*4) = 0xFF;
#endif

    // Switch-off reset mode
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_MOD) = (CAN_MOD_AFM | CAN_MOD_STM);

    // Interrupt Enable, Receive Interrupt Enable
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_IER) = (CAN_IER_RIE);

    return Result;
}


int ncDrv_CAN_PeriSelfTest_Send(tCAN_MSG *txmsg)
{
    int i;
    int Result = NC_SUCCESS;

    //DEBUGMSG_SDK(MSGINFO, "CAN2.0B PeriCAN %s tx send\n", "SelfTest");

    // Tx frame information
    REGRW32(ncDrv_CAN_BaseAddr(), rCANP_FIR) = (txmsg->format<<7) | (txmsg->rtr<<6) | (txmsg->length&0x0F);

    if(txmsg->format == CAN_FI_EXTENDED_FORMAT)
    {
        gp_RegCanTxEFF->TXID[0] = (txmsg->id>>21) & 0xFF; // ID.[28-21]
        gp_RegCanTxEFF->TXID[1] = (txmsg->id>>13) & 0xFF; // ID.[20-13]
        gp_RegCanTxEFF->TXID[2] = (txmsg->id>>5)  & 0xFF; // ID.[12-5]
        gp_RegCanTxEFF->TXID[3] = (txmsg->id<<3)  & 0xF8; // ID.[4-0] last 3bits are don care.

        // Tx n bytes
        for(i = 0; i < txmsg->length; i++)
        {
            gp_RegCanTxEFF->TXDATA[i] = txmsg->data[i];
        }
    }
    else
    {
        gp_RegCanTxSFF->TXID[0] = (txmsg->id>>3) & 0xFF; // ID.[28-21]
        gp_RegCanTxSFF->TXID[1] = (txmsg->id<<5) & 0xE0; // ID.[20-13]

        // Tx n bytes
        for(i = 0; i < txmsg->length; i++)
        {
            gp_RegCanTxSFF->TXDATA[i] = txmsg->data[i];
        }
    }

    // Transmission request
    REGRW32(ncDrv_CAN_BaseAddr(), rCANB_CMR) = CAN_CMR_SRR;

    Result = ncDrv_CAN_SendComplete();
    if(Result == NC_FAILURE)
    {
        //+ DEBUGMSG_SDK(MSGERR, "Error, PeriCAN Send Status 0x%02X\n", REGRW32(ncDrv_CAN_BaseAddr(channel), rCANB_SR));
    }

    return Result;
}


/* End Of File */
