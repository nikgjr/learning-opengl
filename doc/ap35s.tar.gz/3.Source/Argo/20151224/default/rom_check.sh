#!/bin/sh

OUTPUT=./output/rpsv2000t
TARGET=~rtl/APACHE3.5/bit/rom_code

echo '============================================'
echo 'Check   ROM Code !!!!'
echo '============================================'
diff ${OUTPUT}/CR4_Base_032.coe ${TARGET}
diff ${OUTPUT}/CR4_Base_064.coe ${TARGET}
diff ${OUTPUT}/CR4_Base_128.coe ${TARGET}
diff ${OUTPUT}/CR4_Base.bin ${TARGET}



