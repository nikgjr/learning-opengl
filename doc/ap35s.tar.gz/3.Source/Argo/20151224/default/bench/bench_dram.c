
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/ansi.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"
#include "../system/system.h"

#include "../drivers/ddr.h"
#include "../test/test_mem.h"

#include "bench.h"
int bench_dram_test(u32 addr, int count)
{
	int i;
	u32 wdata, rdata;
	int err;
	for(i=0; i<count; i++)
	{
		wdata = i+1;
		reg_write(addr+i*4, wdata);
		rdata = reg_read(addr+i*4);

		__SIM_RESP(wdata);
		__SIM_RESP(rdata);

		tdk_printf("addr=0x%08x, %s\n", addr+i*4, ansi_get_status_string(wdata==rdata));
		err += (wdata!=rdata) ? 1 : 0;
	}
	return err;
}

int bench_dram(int argc, char *argv[])
{
	u32 data, i;
	int loop = 100000;
	int ret;

	tdk_printf("DDR Reset Config Value\n");

	for(i = 0; i < 0x20; i = i + 4)
	{
		data = reg_read(DDR_PHY_CONFIG+i);
		__SIM_RESP(data);
	}

	// DDR Reference Clock 150MHz
	reg_write(DDR_ADDR_SIZE, 	0xa0);			// 0xa5 : ARGO LPDDR board
	reg_write(DDR_TIMING_0, 	0x000c0c06);
	reg_write(DDR_TIMING_1, 	0x00623233);
	reg_write(DDR_TIMING_2,		0x753008b3);
	reg_write(DDR_LMR_EXT_STD,	0x00400032);	// 0x0040_0032 : ARGO LPDDR Board
												// 0x0040_0022 : 32Bit LPDDR FPAG Board
	reg_write(DDR_LMR_EXT_3_2, 	0x0);

	tdk_printf("DDR New Config Value\n");
	for(i = 0; i < 0x20; i = i + 4)
	{
		data = reg_read(DDR_PHY_CONFIG+i);
		__SIM_RESP(data);
	}

	// PHY Init
	reg_write(DDR_PHY_CONFIG, 	DDR_PHY_INIT);

	while(loop--)
	{
		data = reg_read(DDR_PHY_CONFIG);
		if(data & DDR_PHY_COMPLETE) break;
	}

	tdk_printf("DDR Init : %s\n", loop<=0 ? ANSI_FAIL:ANSI_PASS);

	ret = bench_dram_test(APACHE_DRAM_BASE, 16);
	return ret;
}

int bench_dram_config(int argc, char *argv[])
{
	int ret;
	int i;
	u32 data;

	ret = test_mem_config(0, NULL);
	if(ret) return -1;

	data = reg_read(DDR_PHY_CONFIG);
	tdk_printf("DDR_PHY_CONFIG = 0x%08x\n", data);


#if 0
	data = reg_read(0xf0300000);
//	while(!(data & 0x00000010))
	while(!(data & (0x1<<4)))
		data = reg_read(0xf0300000);

	if(data & (0x1<<5))
		tdk_printf("successed to initialization of phy of ddr\n", 0, data);
#endif

	for(i=0; i<16; i++)
	{
		u32 wdata;
		u32 rdata;
		wdata = i+1;
		reg_write(APACHE_DRAM_BASE+i*4, wdata);
		rdata = reg_read(APACHE_DRAM_BASE+i*4);

		__SIM_RESP(wdata);
		__SIM_RESP(rdata);

		tdk_printf("addr=0x%08x, %s\n", APACHE_DRAM_BASE+i*4, ansi_get_status_string(wdata==rdata));
	}


	return 0;
}

