#ifndef __TEST_ID__
#define __TEST_ID__

#define			TEST_NULL			0x0000
#define			TEST_TIMER			0x0100
#define			TEST_WDT			0x0200
#define			TEST_DMA			0x0300
#define			TEST_GPIO			0x0400
#define			TEST_UART			0x0500
#define			TEST_SPI			0x0600
#define			TEST_USB			0x0700
#define			TEST_ETHERNET		0x0800
#define			TEST_SDIO			0x0900
#define			TEST_I2C			0x1000

#define			TEST_I2C_MODEL		TEST_I2C+0x10
#define			TEST_I2C_LOOPBACK	TEST_I2C+0x20

#define			TEST_SPI_MODEL		TEST_SPI+0x10
#define			TEST_SPI_LOOPBACK	TEST_SPI+0x20

#define			TEST_UART_MODEL		TEST_UART+0x10
#define			TEST_UART_LOOPBACK	TEST_UART+0x20


#define			TEST_DRAM				0x2000
#define			TEST_DRAM_BENCH			0x2010
#define			TEST_DRAM_CONFIG		0x2011
#define			TEST_DDR2				0x2020

#define 		TEST_RAM				0x3000
#define			TEST_BUSACCESS			0x4000
#define			TEST_RESET				0x4010
#define			TEST_TCM_BENCH			0x4020

#define			TEST_DEBUG_MESSAGE		0x1000

#define			TEST_ISP			    0x5000

#define			TEST_ISP_NORMAL		    TEST_ISP

#define			TEST_CAN			    0x6000

int bench_irom		(int argc, char *argv[]);
int bench_iram      (int argc, char *argv[]);
int bench_gic       (int argc, char *argv[]);
int bench_syscon    (int argc, char *argv[]);
int bench_wdt       (int argc, char *argv[]);
int bench_pwm       (int argc, char *argv[]);
int bench_i2c       (int argc, char *argv[]);
int bench_spi       (int argc, char *argv[]);
int bench_spi2      (int argc, char *argv[]);
int bench_uart      (int argc, char *argv[]);
int bench_gpio      (int argc, char *argv[]);
int bench_i2s       (int argc, char *argv[]);
int bench_timer     (int argc, char *argv[]);
int bench_dma       (int argc, char *argv[]);
int bench_hsuart    (int argc, char *argv[]);
int bench_hsuart_int(int argc, char *argv[]);
int bench_hsuart_dma(int argc, char *argv[]);
int bench_dap       (int argc, char *argv[]);
int bench_nand      (int argc, char *argv[]);
int bench_dcu		(int argc, char *argv[]);
int bench_gau		(int argc, char *argv[]);
int bench_ddrc		(int argc, char *argv[]);


int bench_dram		(int argc, char *argv[]);
int bench_dram_config(int argc, char *argv[]);
int bench_ethernet	(int argc, char *argv[]);
int bench_otp		(int argc, char *argv[]);
int bench_tcm		(int argc, char *argv[]);

int bench_isp       (int argc, char *argv[]);
int bench_can       (int argc, char *argv[]);

#endif
