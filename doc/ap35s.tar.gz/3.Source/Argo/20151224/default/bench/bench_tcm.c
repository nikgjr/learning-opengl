/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2014 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/ansi.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"
#include "../system/system.h"

#include "../config/CR4_TopRegMap.h"

/*
 * test_id = __SIM_READ_REG(SIM_DEBUG_TESTID)
 * return 0:success, !0 fail
 */

extern void tcm_init(void);

int bench_tcm(int argc, char *argv[])
{
	u32 data;
	int i;

	__SIM_STEP(APACHE_ATCM_BASE);
	tcm_init();
	reg_write(APACHE_ATCM_BASE+0x00,0x01020304);
	reg_write(APACHE_ATCM_BASE+0x04,0x05060708);
	reg_write(APACHE_ATCM_BASE+0x08,0x090a0b0c);
	reg_write(APACHE_ATCM_BASE+0x0c,0x0d0e0f10);

	reg_write(APACHE_ATCM_BASE+0x10,0x11120314);
	reg_write(APACHE_ATCM_BASE+0x14,0x15160718);
	reg_write(APACHE_ATCM_BASE+0x18,0x191a0b1c);
	reg_write(APACHE_ATCM_BASE+0x1c,0x1d1e0f20);
//	data = reg_read(APACHE_ATCM_BASE+0x0);
//	__SIM_RESP(data);
#if 0
	tdk_puts("====READ  ATCM");
	for(i=0; i<16; i++)
	{
		data = reg_read(APACHE_ATCM_BASE+i*4);
		__SIM_RESP(data);
	}

	tdk_puts("====WRITE ATCM");
	for(i=0; i<16; i++)
	{
		data = i+1;
		__SIM_RESP(data);
		reg_write(APACHE_ATCM_BASE+i*4, i);
	}
#endif
	__SIM_STEP(APACHE_ATCM_BASE+0xffff);

	return 0;
}
