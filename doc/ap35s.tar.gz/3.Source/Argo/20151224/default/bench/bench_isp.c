//==============================================================================================//
// Global Option                                                                                //
//==============================================================================================//
// Inner-Mode parameter (Resolution:*)                                                          //
//                                                                                              //
//       *SR_MODE       *IN_MODE      *FRC_MODE     *LDC_MODE       *OF_MODE                    //
//   |==============|==============|=============|=============|===============|                //
//                                                                                              //
// Sensor   -->    ICDC    -->    FRC    -->    LDC    -->     OF    -->      PAD               //
//                                               |             |                                //
//                                               |             |     *AHD_MODE                  //
//                                               |             |  |============|                //
//                                               |             |                                //
//                                               |            AHD   ----|                       //
//                                               |                      |---> DAC               //
//                                               |-------> CVBS-FRC ----|                       //
//                                                                                              //
//                                                                |============|                //
//                                                                  *CVBS_MODE                  //
//                                                                                              //
//  1. *SR_MODE     : 1280x720_60hz                                                             //
//  2. *IN_MODE     : 1280X720_60hz                                                             //
//  3. *FRC_MODE    : 1280X720_60hz                                                             //
//  4. *LDC_MODE    : 1280x720_60hz                                                             //
//  5. *OF_MODE     : 1280x720_60hz                                                             //
//  5. *AHD_MODE    : 1280x720_60hz                                                             //
//  5. *CVBS_MODE   : 1280x576_60hz                                                             //
//==============================================================================================//
#include <stdio.h>
#include "bench.h"

#include "../tdk/tdk.h"

#include "../drivers/gicdrv.h"
#include "../drivers/ddr.h"

#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

// initialization
void System_init_PAD(void);     // PAD set
void System_init_GPIO(void);    // GPIO set
void System_init_CLOCK(void);   // Clock set
void System_init_INT(void);     // Interrupt set

// interrupt handler
#define ISP0_INT_SET    0x01
#define ISP1_INT_SET    0x02
#define ISP2_INT_SET    0x04    // VSI_NEG
#define ISP3_INT_SET    0x08    // VSI_POS
#define ISP4_INT_SET    0x10    // VSO_NEG
#define ISP5_INT_SET    0x20    // VSO_POS
#define ISP6_INT_SET    0x40
#define ISP7_INT_SET    0x80
#define ISP8_INT_SET    0x01
volatile unsigned char Interrupt[2];
void isp_irq_handler2(void *param)
{
    Interrupt[0] |= ISP2_INT_SET;
	tdk_puts("isp2 interrupt\n");
}
void isp_irq_handler3(void *param)
{
    Interrupt[0] |= ISP3_INT_SET;
	tdk_puts("isp3 interrupt\n");
}
void isp_irq_handler4(void *param)
{
    Interrupt[0] |= ISP4_INT_SET;
	tdk_puts("isp4 interrupt\n");
}
void isp_irq_handler5(void *param)
{
    Interrupt[0] |= ISP5_INT_SET;
	tdk_puts("isp5 interrupt\n");
}

int bench_isp(int argc, char *argv[])
{

    // isp_reg_scan(0x100,0xF000);

    /////////////////////////////////////////////////////////
    // Initialization
    /////////////////////////////////////////////////////////
    int input_h_total;
    unsigned char qspi_done;
    unsigned char est_h_tot_l;
    unsigned char est_h_tot_m;
    unsigned int  est_h_tot0;
    unsigned int  est_h_tot;

	tdk_printf("ISP Bench : Start\n");
//	dmc_init();
	ddr_config(1,148.63);
	ddr_init();	

    // Init CLK, PAD, GPIO, Clock_Tree, Interrupt
    System_init_PAD();
    System_init_GPIO();
    System_init_CLOCK();
    System_init_INT();

#if (OSG_MODE_SEL == OSG_ON_SET)
    OSG_set();
#endif

    /////////////////////////////////////////////////////////
    // Main-Test
    /////////////////////////////////////////////////////////
    // this parameter is reffered to some IPs using Line Memory in IISP clock domain
    #if(WDR_MODE_SEL==WDR_NORMAL_SET)
        input_h_total = IN_HTOTAL;
    #elif(WDR_MODE_SEL==WDR_DOL2_SET)
        input_h_total = IN_HTOTAL * 2;
    #elif(WDR_MODE_SEL==WDR_DOL3_SET)
        input_h_total = IN_HTOTAL * 3;
    #else
        input_h_total = IN_HTOTAL;
    #endif

    isp_write(0x00E4,input_h_total >> 8);   // SDR_H_TOTAL
    isp_write(0x00E3,input_h_total);
    isp_write(0x00E8,input_h_total >> 8);   // SDR_H_TOTAL
    isp_write(0x00E7,input_h_total);

#if((ENV_TEST == ENV_TEST_OFF) | (ENV_TEST == ENV_TEST_FUNC)  | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL)| (ENV_TEST == ENV_TEST_FUNC_BYPASS))
    #if(SENSOR_PARALLEL==ON)
    #else
    lvds_decoder_set();
    #endif

    input_interface_set();
    OVLYMIX_set();

    #if(CVBS_EN == ON)
    CVBS_set();
//  TESTPATTERN_CVBS();
    #else
    #endif

    #if(WDR_MODE_SEL==WDR_NORMAL_SET)
//    *(SFR16)0xC800 = 0x01;      // WDR_DOL_MODE[2], WDR_DOL_EN[1], WDR_EN[0]
    lbfrc_2fr_set();
    wdr_2fr_set();
    #elif(WDR_MODE_SEL==WDR_DECOMP_SET)
//    *(SFR16)0xC800 = 0x00;      // WDR_DOL_MODE[2], WDR_DOL_EN[1], WDR_EN[0]
    lbfrc_decomp_set();
    wdr_decomp_set();
    #elif(WDR_MODE_SEL==WDR_DOL2_SET)
//    *(SFR16)0xC800 = 0x03;      // WDR_DOL_MODE[2], WDR_DOL_EN[1], WDR_EN[0]
    lbfrc_dol2_set();
    wdr_dol2_set();
    #elif(WDR_MODE_SEL==WDR_DOL3_SET)
//    *(SFR16)0xC800 = 0x07;      // WDR_DOL_MODE[2], WDR_DOL_EN[1], WDR_EN[0]
    lbfrc_dol3_set();
    wdr_dol3_set();
    #elif(WDR_MODE_SEL==WDR_OV10640_SET)
    lbfrc_lwdr3_set();
    wdr_dol3_set();
    #else
    isp_write(ISP_WDR_BASE+0x00,0x00);     // WDR_DOL_MODE[2], WDR_DOL_EN[1], WDR_EN[0]
    #endif

    // ADC setting;
    isp_write(0x00E0,0x01);     // {7'd0,ADC_EN};

    ITP_set();
    BLC_set();
    LSC_set();
    LINEAR_CTRL_set();
    INPUT_CROP_set();
    awb_adj_set();
    FLK_set();
    IRIS_set();
    HLCSUPP_set();
    OPD_set();
//  DITHER_set();
    DPC_LIVE();
    NR3D_set();
    FRC_set();
    CI_set();
//    NR2D_set();
    FNR2D_set();
    CSC_set();
    RGB_GAMMA_set();
    CSC_CABR_set();

    DEFOG_set();
    YC_PROC_set();
    IBLUR_set();
    YEDGE_set();
    ALLNR_set();
    LTM_set();
    PMASK_set();
    BMD_set();
#if (OSG_MODE_SEL == OSG_ON_SET)
    OSG_set();
#else
#endif
//  TESTPATTERN_OUTPUT(0);
    SPGL_set();
//  PYHPF_set();
    DPGL_set();
    DPGL_POS_set(0);
    PYEDGE_set();
    #if(LDC_MODE_SEL == LDC_ON_SET)
    delay(50);                      // 200ms ~ wait
    quad_spi_set();
    LDC_set();
    isp_write(0x00E1,0x04 | (0xFB & isp_read(0x00E1)));   // {6'd0, O_HSYNC_BYPASS, O_HSYNC_BYPASS_FR};
    qspi_done = isp_read(ISP_QSPI_BASE+0x11);
    qspi_done = (qspi_done >> 6) & 0x1;
    while(qspi_done==0) {
        delay(2);
        qspi_done = isp_read(ISP_QSPI_BASE+0x11);
        qspi_done = (qspi_done >> 6) & 0x1;
    }
        #if(LDC_PIP_EN == ON)
        quad_spi_set_pip();
        LDC_set();
        qspi_done = isp_read(ISP_QSPI_BASE+0x011);
        qspi_done = (qspi_done >> 6) & 0x1;
        while(qspi_done==0) {
            delay(2);
            qspi_done = isp_read(ISP_QSPI_BASE+0x011);
            qspi_done = (qspi_done >> 6) & 0x1;
        }
        #else
        #endif
    #elif (LDC_MODE_SEL == LDC_ON_ALL_FUNC)
    quad_spi_set();
    #else
    #endif

    #if(LDC_MODE_SEL == LDC_OFF_SET)
    #else
    YC_CROP_set();
    #endif
    OF_set(0, 0, 0, 1);
    VBI_set();

    #if(AHD_EN == ON)
    AHD_set();
    #else
    #endif

#elif(ENV_TEST == ENV_TEST_GPIO)
    TESTPATTERN_OUTPUT(0);
    OUTPUT_FORMATTER_Init(0, 0, 0, 1);
#else
#endif

#if((ENV_TEST == ENV_TEST_FUNC)  | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL)| (ENV_TEST == ENV_TEST_FUNC_BYPASS))
    isp_write(ISP_CVBSFRC_BASE+0x0A,0x08);  // {4'h0,I_CVBS_BLACK_BG_ON,I_CVBS_TG_INV_FLD,2'b0};
#endif

    /////////////////////////////////////////////////////////
    // long time Test
    /////////////////////////////////////////////////////////
#if(OSD_EN == ON)
    // HD-OSD-Flesh-Fonts are uploaded to SDR-RAM and the OSD Display RAM is Cleared by the OSD initial signal (need the delay time over 200ms for SDR-Controller initialization)
    delay(50);                      // 200ms ~ wait
    OSD_FontLoad();                 // 3 Font(48x48 HD/SD) wirte to SDR RAM
    OSD_Init(0);                    // set parameter : 1920x1080p_F48x48(1)
#endif

    /////////////////////////////////////////////////////////
    // 1 frame
    /////////////////////////////////////////////////////////
    while(!(ISP4_INT_SET & Interrupt[0])); // VSO_NEG PENDING
    Interrupt[0] &= (0xFF ^ ISP4_INT_SET);

    
    DPGL_POS_set(0);
    /////////////////////////////////////////////////////////
    // 2 frames
    /////////////////////////////////////////////////////////
    while(!(ISP4_INT_SET & Interrupt[0])); // VSO_NEG PENDING
    Interrupt[0] &= (0xFF ^ ISP4_INT_SET);

#if(WDR_2FRM_LONG_FIRST==ON)
    isp_write(ISP_WDR_BASE+0x01,0x00);      //WDR_HALF_FRAME[7:6];WDR_DEFINE_IMG[5:4];WDR_SENSOR_EN[3]WDR_INIT_CHK[2]WDR_H_SWAP[1]WDR_V_SWAP[0];
#else
#endif

    #if (LDC_MODE_SEL == LDC_ON_ALL_FUNC)
        #if(LDC_PIP_EN == ON)
        qspi_done = isp_read(ISP_QSPI_BASE+0x11);
        qspi_done = (qspi_done >> 6) & 0x1;
        while(qspi_done==0) {
            delay(2);
            qspi_done = isp_read(ISP_QSPI_BASE+0x11);
            qspi_done = (qspi_done >> 6) & 0x1;
        }
        quad_spi_set_pip();
        #else
        #endif
    #else
    #endif

    delay(50);                      // 200ms ~ wait

    /////////////////////////////////////////////////////////
    // 3 frames
    /////////////////////////////////////////////////////////
    while(!(ISP4_INT_SET & Interrupt[0])); // VSO_NEG PENDING
    Interrupt[0] &= (0xFF ^ ISP4_INT_SET);

    delay(50);                      // 200ms ~ wait
    est_h_tot_m = isp_read(0x01CC);
    est_h_tot_l = isp_read(0x01CB);
    est_h_tot0 = ((int)est_h_tot_m << 8 | est_h_tot_l);
    est_h_tot  = est_h_tot0 + 1;
 
    isp_write(0x00E4,est_h_tot>>8); // SDR_H_TOTAL
    isp_write(0x00E3,est_h_tot);
    isp_write(0x00E8,est_h_tot>>8); // SDR_H_TOTAL
    isp_write(0x00E7,est_h_tot);

#if((ENV_TEST == ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL))
    isp_write(0x1C6A,0x00);         // {4'h0,I_CVBS_BLACK_BG_ON,I_CVBS_TG_INV_FLD,2'b0};
#endif

    #if(MAIN_FRC == ON)
    isp_write(0x0680,0x01 | isp_read(0x0680));          // {NOSYNC,FRC_HACT_POSITION[6],FRC_DPCM_EN[5]_,FRC_VFLIP_EN[4],FRC_READ_MODE[3],FRC_HSYNC_MODE[2],FRC_SYNC_MODE[1:0]};
    isp_write(0x00E1,0x06 | (0xF9 & isp_read(0x00E1))); // {6'd0, O_HSYNC_BYPASS, O_HSYNC_BYPASS_FR};
    isp_write(0x28E0,0x20 | isp_read(0x28E0));          // {2'h0,YC_VSYNC_REGEN_EN,YC_CROP_SEL,3'h0,YC_CROP_EN};
        #if(ENV_120P_SET==ON)
            #if(DIGITAL_MODE_SEL == DIGITAL_MODE_BT1120_DEMULTIPLEX)
            #elif(DIGITAL_MODE_SEL == DIGITAL_MODE_BT120_MULTIPLEX)
            #elif(DIGITAL_MODE_SEL == DIGITAL_MODE_BT656)
            #endif
        #else
        #endif
    #endif

#if((ENV_TEST == ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL) | (ENV_TEST == ENV_TEST_FUNC_BYPASS))
    isp_write(0x0680,0xFB & isp_read(0x0680));          // {NOSYNC,FRC_HACT_POSITION[6],FRC_DPCM_EN[5]_,FRC_VFLIP_EN[4],FRC_READ_MODE[3],FRC_HSYNC_MODE[2],FRC_SYNC_MODE[1:0]};
    isp_write(0x00E1,0x00);                             // {6'd0, O_HSYNC_BYPASS, O_HSYNC_BYPASS_FR};
#endif

    #if (LDC_MODE_SEL == LDC_ON_ALL_FUNC)
    qspi_done = isp_read(ISP_QSPI_BASE+0x11);
    qspi_done = (qspi_done >> 6) & 0x1;
    while(qspi_done==0) {
        delay(2);
        qspi_done = isp_read(ISP_QSPI_BASE+0x11);
        qspi_done = (qspi_done >> 6) & 0x1;
    }
    LDC_set();
    #else
    #endif

#if(ENV_TEST == ENV_TEST_OFF)
    isp_write(0x00E1,0x04 | (0xFB & isp_read(0x00E1))); // {6'd0, O_HSYNC_BYPASS, O_HSYNC_BYPASS_FR};
#endif

    #if(OSD_EN == ON)
    OSD_Init(0xFF);
    OSD_Test(0);
    #endif

    #if(DNR_EN == ON)
    isp_write(0x0900,0xC7);     // {DNR_MD_SEL[7:6],DNR_H_SWAP[2],DNR_V_SWAP[1],DNR_EN[0]};
    #endif

    /////////////////////////////////////////////////////////
    // 4 frames
    /////////////////////////////////////////////////////////
    while(!(ISP4_INT_SET & Interrupt[0])); // VSO_NEG PENDING
    Interrupt[0] &= (0xFF ^ ISP4_INT_SET);

    delay(50);                      // 200ms ~ wait
    est_h_tot_m = isp_read(0x01CC);
    est_h_tot_l = isp_read(0x01CB);
    est_h_tot0 = ((int)est_h_tot_m << 8 | est_h_tot_l);
    est_h_tot  = est_h_tot0 + 1;
 
    isp_write(0x00E4,est_h_tot>>8); // SDR_H_TOTAL
    isp_write(0x00E3,est_h_tot);
    isp_write(0x00E8,est_h_tot>>8); // SDR_H_TOTAL
    isp_write(0x00E7,est_h_tot);

    /////////////////////////////////////////////////////////
    // 5 frames
    /////////////////////////////////////////////////////////
    while(!(ISP4_INT_SET & Interrupt[0])); // VSO_NEG PENDING
    Interrupt[0] &= (0xFF ^ ISP4_INT_SET);

    delay(50);                      // 200ms ~ wait
    est_h_tot_m = isp_read(0x01CC);
    est_h_tot_l = isp_read(0x01CB);
    est_h_tot0 = ((int)est_h_tot_m << 8 | est_h_tot_l);
    est_h_tot  = est_h_tot0 + 1;
 
    isp_write(0x00E4,est_h_tot>>8); // SDR_H_TOTAL
    isp_write(0x00E3,est_h_tot);
    isp_write(0x00E8,est_h_tot>>8); // SDR_H_TOTAL
    isp_write(0x00E7,est_h_tot);

#if(OSD_EN == ON)
    OSD_Test(1);
#endif

    /////////////////////////////////////////////////////////
    // 6 frames
    /////////////////////////////////////////////////////////
    while(!(ISP4_INT_SET & Interrupt[0])); // VSO_NEG PENDING
    Interrupt[0] &= (0xFF ^ ISP4_INT_SET);

    delay(50);                      // 200ms ~ wait
    est_h_tot_m = isp_read(0x01CC);
    est_h_tot_l = isp_read(0x01CB);
    est_h_tot0 = ((int)est_h_tot_m << 8 | est_h_tot_l);
    est_h_tot  = est_h_tot0 + 1;
 
    isp_write(0x00E4,est_h_tot>>8); // SDR_H_TOTAL
    isp_write(0x00E3,est_h_tot);
    isp_write(0x00E8,est_h_tot>>8); // SDR_H_TOTAL
    isp_write(0x00E7,est_h_tot);

	tdk_printf("ISP Bench : Finish\n");

    while(1);

	return 0;
}

void System_init_PAD(void)
{
    //========================================
    // PAD Parameter Set (Global Foundary Lib)
    //========================================
#if(ENV_TEST == ENV_TEST_IDS)
#else
#endif
pinmux_i2c0();
pinmux_i2c1();
pinmux_q_spi();
pinmux_cis();
pinmux_bt1120_20bit();
pinmux_uart0();
pinmux_can();
}

void System_init_GPIO(void)
{
    //========================================
    // GPIO Parameter Set
    //========================================
#if(ENV_TEST == ENV_TEST_IDS)
#else
#endif
}

void System_init_CLOCK(void)
{
    //========================================
    // Clock Tree Parameter Set
    //========================================
#if(ENV_TEST == ENV_TEST_IDS)
#else
#endif
}

void System_init_INT(void)
{
    //========================================
    // interrupt Set
    //========================================
    ISP_INT_set();

    Interrupt[0]    = 0;
    Interrupt[1]    = 0;

#if(ENV_TEST == ENV_TEST_IDS)
#else
    GIC_RegisterHandler(GIC_ISP2, isp_irq_handler2, NULL);
    GIC_RegisterHandler(GIC_ISP3, isp_irq_handler3, NULL);
    GIC_RegisterHandler(GIC_ISP4, isp_irq_handler4, NULL);
    GIC_RegisterHandler(GIC_ISP5, isp_irq_handler5, NULL);

    GIC_EnableIrq(GIC_ISP2);
    GIC_EnableIrq(GIC_ISP3);
    GIC_EnableIrq(GIC_ISP4);
    GIC_EnableIrq(GIC_ISP5);
#endif
}
