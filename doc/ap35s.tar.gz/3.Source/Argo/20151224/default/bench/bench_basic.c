/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2014 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/ansi.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"
#include "../system/system.h"

/*
 * test_id = __SIM_READ_REG(SIM_DEBUG_TESTID)
 * return 0:success, !0 fail
 */
int bench_basic(int argc, char *argv[])
{
	return 0;
}
