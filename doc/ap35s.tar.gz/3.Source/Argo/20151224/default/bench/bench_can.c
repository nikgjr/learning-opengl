//==============================================================================================//
// Global Option                                                                                //
//==============================================================================================//
// Inner-Mode parameter (Resolution:*)                                                          //
//                                                                                              //
//       *SR_MODE       *IN_MODE      *FRC_MODE     *LDC_MODE       *OF_MODE                    //
//   |==============|==============|=============|=============|===============|                //
//                                                                                              //
// Sensor   -->    ICDC    -->    FRC    -->    LDC    -->     OF    -->      PAD               //
//                                               |             |                                //
//                                               |             |     *AHD_MODE                  //
//                                               |             |  |============|                //
//                                               |             |                                //
//                                               |            AHD   ----|                       //
//                                               |                      |---> DAC               //
//                                               |-------> CVBS-FRC ----|                       //
//                                                                                              //
//                                                                |============|                //
//                                                                  *CVBS_MODE                  //
//                                                                                              //
//  1. *SR_MODE     : 1280x720_60hz                                                             //
//  2. *IN_MODE     : 1280X720_60hz                                                             //
//  3. *FRC_MODE    : 1280X720_60hz                                                             //
//  4. *LDC_MODE    : 1280x720_60hz                                                             //
//  5. *OF_MODE     : 1280x720_60hz                                                             //
//  5. *AHD_MODE    : 1280x720_60hz                                                             //
//  5. *CVBS_MODE   : 1280x576_60hz                                                             //
//==============================================================================================//
#include <stdio.h>
#include "bench.h"

#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"
#include "../include/sfr.h"

#include "../drivers/gicdrv.h"

#include "can_regmap.h"

// initialization
void System_init_PAD(void);     // PAD set
void System_init_GPIO(void);    // GPIO set
void System_init_CLOCK(void);   // Clock set
void System_init_INT(void);     // Interrupt set


int bench_can(int argc, char *argv[])
{
	tdk_printf("CAN Bench : Start\n");

//	dmc_init();

    // Init CLK, PAD, GPIO, Clock_Tree, Interrupt
//    System_init_PAD();
//    System_init_GPIO();
//    System_init_CLOCK();
//    System_init_INT();
    pinmux_i2c0();
    pinmux_i2c1();
    pinmux_q_spi();
    pinmux_cis();
    pinmux_bt1120_20bit();
    pinmux_uart0();
    pinmux_can();

    delay (1000);
    reg_write(ADDR_CAN_SEL, 0x00);
    can_set();
    while(1);

	return 0;
}

/*
void System_init_PAD(void)
{
    //========================================
    // PAD Parameter Set (Global Foundary Lib)
    //========================================
#if(ENV_TEST == ENV_TEST_IDS)
#else
#endif
}

void System_init_GPIO(void)
{
    //========================================
    // GPIO Parameter Set
    //========================================
#if(ENV_TEST == ENV_TEST_IDS)
#else
#endif
}

void System_init_CLOCK(void)
{
    //========================================
    // Clock Tree Parameter Set
    //========================================
#if(ENV_TEST == ENV_TEST_IDS)
#else
#endif
}

void System_init_INT(void)
{
    //========================================
    // interrupt Set
    //========================================
//    ISP_INT_set();

//    Interrupt[0]    = 0;
//    Interrupt[1]    = 0;

#if(ENV_TEST == ENV_TEST_IDS)
#else
    GIC_RegisterHandler(GIC_ISP2, isp_irq_handler2, NULL);
    GIC_RegisterHandler(GIC_ISP3, isp_irq_handler3, NULL);
    GIC_RegisterHandler(GIC_ISP4, isp_irq_handler4, NULL);
    GIC_RegisterHandler(GIC_ISP5, isp_irq_handler5, NULL);

    GIC_EnableIrq(GIC_ISP2);
    GIC_EnableIrq(GIC_ISP3);
    GIC_EnableIrq(GIC_ISP4);
    GIC_EnableIrq(GIC_ISP5);
#endif

}
*/
