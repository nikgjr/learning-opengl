//==============================================================================================//
// Global Option                                                                                //
//==============================================================================================//
// Inner-Mode parameter (Resolution:*)                                                          //
//                                                                                              //
//       *SR_MODE       *IN_MODE      *FRC_MODE     *LDC_MODE       *OF_MODE                    //
//   |==============|==============|=============|=============|===============|                //
//                                                                                              //
// Sensor   -->    ICDC    -->    FRC    -->    LDC    -->     OF    -->      PAD               //
//                                               |             |                                //
//                                               |             |     *AHD_MODE                  //
//                                               |             |  |============|                //
//                                               |             |                                //
//                                               |            AHD   ----|                       //
//                                               |                      |---> DAC               //
//                                               |-------> CVBS-FRC ----|                       //
//                                                                                              //
//                                                                |============|                //
//                                                                  *CVBS_MODE                  //
//                                                                                              //
//  1. *SR_MODE     : 1280x720_60hz                                                             //
//  2. *IN_MODE     : 1280X720_60hz                                                             //
//  3. *FRC_MODE    : 1280X720_60hz                                                             //
//  4. *LDC_MODE    : 1280x720_60hz                                                             //
//  5. *OF_MODE     : 1280x720_60hz                                                             //
//  5. *AHD_MODE    : 1280x720_60hz                                                             //
//  5. *CVBS_MODE   : 1280x576_60hz                                                             //
//==============================================================================================//
#include <stdio.h>
#include "bench.h"
#include "../tdk/tdk.h"

	// IRQ Example
//#include "../drivers/gicdrv.h"
//void isp_irq_hadnler3(void *param)
//{
//	tdk_puts("GIC_ISP_3 I");
//}

int bench_isp(int argc, char *argv[])
{
	tdk_printf("ISP Bench : Start\n");

    // isp_reg_scan(0x100,0xF000);

	dmc_init();

	// IRQ Example
//	GIC_RegisterHandler(GIC_ISP3, isp_irq_hadnler3, NULL);
//	GIC_EnableIrq(GIC_ISP3);
//  ISP_INT_set();

    lvds_decoder_set();
    input_interface_set();
    BLC_set();
    ITP_set();
    INPUT_CROP_set();
    lbfrc_decomp_set();
//  lbfrc_dol3_set(); 
//  lbfrc_dol2_set(); 
//  lbfrc_2fr_set(); 
//  lbfrc_lwdr3_set();
//  lbfrc_lwdr2_set();
    LINEAR_CTRL_set();
    LSC_set();
    FLK_set();
    awb_adj_set();
    HLC_set();
    OPD_set();
    WDR_DOL3_set(); 
//  WDR_DOL2_set();
//  WDR_2FR_set();
    DPC_STATIC_WR();
    DPC_STATIC_RD();
    DPC_LIVE();
    DITHER_set();
    NR3D_set();
    FRC_set();
    FNR2D_set();
    CI_set();
    NR2D_set();
    CSC_set();
    CSC_CABR_set();
    RGB_GAMMA_set();
    PYEDGE_set();
    YC_CROP_set();
    LDC_set();
    DEFOG_set();
    YC_PROC_set();
    RGB_BOX_set();
    IBLUR_set();
    ALLNR_set();
    LTM_set();
    YEDGE_set();
    HLCSUPP_set();
    PMASK_set();
    BMD_set();
    OVLYMIX_set();
    OTP_set(0x00);
    OSD_Init(0);
    OSD_FontLoad();
    OF_set(0, 0, 0, 1);
    AHD_set();
    CVBS_set();
	tdk_printf("ISP Bench : Finish\n");

    while(1);

	return 0;
}


