#ifndef __ISP_REG_MAP_H__
#define __ISP_REG_MAP_H__

#include "../config/CR4_TopRegMap.h"

/*===================================================*/
/* base address                                      */
/*===================================================*/
#define MEM_BASE                APACHE_DRAM_BASE 
#define ISP_BASE                APACHE_CUSTOM_0

#define ISP_IND_BANK            0x0001
#define ISP_IND_ADDR            0x0002
#define ISP_IND_RWDATA          0x0003
#define ISP_IND_OSD_RDATA       0x0004

#define ISP_QSPI_BASE           0x05C0

#define ISP_INT_BASE            0x0020
#define ISP_LVDS_DEC_BASE0      0x0200
#define ISP_LVDS_DEC_BASE1      0x2900
#define ISP_IIF_BASE0           0x0100
#define ISP_IIF_BASE1           0x0300
#define ISP_ITP_BASE            0x0300
#define ISP_LSC_BASE            0x0300
#define ISP_AWB_ADJ_BASE        0x0400
#define ISP_INPUT_CROP_BASE     0x0400
#define ISP_LINEAR_CTRL_BASE    0x0400
#define ISP_FLK_BASE            0x0500
#define ISP_HLC_BASE            0x0500
#define ISP_IRIS_BASE           0x0600
#define ISP_BLC_BASE            0x0300
#define ISP_NR3D_BASE           0x0900
#define ISP_WDR_BASE            0x0800
#define ISP_SPGL_BASE           0x0D00
#define ISP_CI_BASE             0x0F00
#define ISP_FNR2D_BASE          0x0F00
#define ISP_NR2D_BASE           0x0F00
#define ISP_CSC_CABR_BASE       0x0F00
#define ISP_CSC_BASE            0x1100
#define ISP_PYEDGE_BASE         0x28F0
#define ISP_LDC_BASE            0x2800
#define ISP_YCCROP_BASE         0x28E0
#define ISP_DEFOG_BASE          0x1180
#define ISP_YCPROC_BASE         0x1300
#define ISP_RGBBOX_BASE         0x1400
#define ISP_DITHER_BASE0        0x0400
#define ISP_DITHER_BASE1        0x2700
#define ISP_DPC_LIVE_BASE       0x0700
#define ISP_FRC_BASE            0x0600
#define ISP_LBFRC_BASE          0x2A00
#define ISP_OPD_BASE            0x2100
#define ISP_RGB_GAMMA_BASE      0x1200
#define ISP_YC_CROP_BASE        0x2800
#define ISP_IBLUR_BASE          0x1420
#define ISP_ALLNR_BASE          0x14A0
#define ISP_LTM_BASE            0x14C0
#define ISP_YEDGE_BASE          0x1500
#define ISP_ESUPP_BASE          0x1580
#define ISP_HLCSUPP_BASE        0x15C0
#define ISP_PM_BASE             0x1600
#define ISP_BMD_BASE            0x1700
#define ISP_VBI_BASE            0x1780
#define ISP_OVLYMIX_BASE        0x17B0
#define ISP_OF_BASE             0x1A00
#define ISP_OTP_BASE            0x1AB0
#define ISP_CVBSVE_BASE         0x1B00
#define ISP_CVBSCROP_BASE       0x1B80
#define ISP_CVBSDS_BASE         0x1B90
#define ISP_CVBSHPF_BASE        0x1C43
#define ISP_CVBSFRC_BASE        0x1C60
#define ISP_OSD_BASE            0x1D00
#define ISP_AHD_BASE            0x2000
#define ISP_OPD1_BASE           0x2100
#define ISP_OPD2_BASE           0x2200
#define ISP_OSG1_BASE           0x2400
#define ISP_OSG2_BASE           0x2500
#define ISP_OSG3_BASE           0x2600
#define ISP_HPF_BASE            0x2700

/*===================================================*/
/* function                                          */
/*===================================================*/
#define		ISP_REG_CALL_FUNC   0

#endif

#if ISP_REG_CALL_FUNC
void isp_write(unsigned int, unsigned char);
unsigned char isp_read (unsigned int);
void mem_write(unsigned int, unsigned char);
unsigned char mem_read (unsigned int);
#else
#define isp_write(addr,data) *((volatile unsigned char *)(ISP_BASE+addr))=(data)
#define isp_read(addr) *((volatile unsigned char *)(ISP_BASE+addr))
#define mem_write(addr,data) *((volatile unsigned char *)(MEM_BASE+addr))=(data)
#define mem_read(addr) *((volatile unsigned char *)(MEM_BASE+addr))
#endif

void isp_reg_scan(unsigned int start, unsigned int range);
