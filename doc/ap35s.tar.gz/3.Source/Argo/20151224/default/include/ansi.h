/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/
#ifndef __ANSI__
#define __ANSI__

/*
[0m  : 모든 색과 스타일 초기화
[1m  : 굵게(bold) / 밝게
[3m  : 이탤릭체(italic)
[4m  : 밑줄(underline)
[7m  : 반전(글자색/배경색을 거꾸로)
[9m  : 가로줄 치기
[22m : 굵게(bold) 제거
[23m : 이탤릭체(italic)제거
[24m : 밑줄(underline)제거
[27m : 반전 제거
[29m : 가로줄 제거

[출처] ANSI terminal color codes|작성자 탐장
 */

#define ANSI_RESET                  "\033[0m"

#define ANSI_TEXT_BLACK             "\033[30m"//  : 글자색:검정
#define ANSI_TEXT_RED               "\033[31m"//  : 글자색:빨강
#define ANSI_TEXT_GREEN             "\033[32m"//  : 글자색:초록
#define ANSI_TEXT_YELLOW            "\033[33m"//  : 글자색:노랑
#define ANSI_TEXT_BLUE              "\033[34m"//  : 글자색:파랑
#define ANSI_TEXT_MGENTA            "\033[35m"//  : 글자색:마젠트(분홍)
#define ANSI_TEXT_CYAN              "\033[36m"//  : 글자색:시안(청록)
#define ANSI_TEXT_WHITE             "\033[37m"//  : 글자색:백색
#define ANSI_TEXT_RESET             "\033[39m"//  : 글자색으로 기본값으로
#define ANSI_BACKGROUND_BLACK       "\033[40m"//  : 바탕색:흑색
#define ANSI_BACKGROUND_RED         "\033[41m"//  : 바탕색:적색
#define ANSI_BACKGROUND_GREEN       "\033[42m"//  : 바탕색:녹색
#define ANSI_BACKGROUND_YELLOW      "\033[43m"//  : 바탕색:황색
#define ANSI_BACKGROUND_BLUE        "\033[44m"//  : 바탕색:청색
#define ANSI_BACKGROUND_PINK        "\033[45m"//  : 바탕색:분홍색
#define ANSI_BACKGROUND_DARKBLUE    "\033[46m"//  : 바탕색:청록색
#define ANSI_BACKGROUND_WHITE       "\033[47m"//  : 바탕색:흰색
#define ANSI_BACKGROUND_RESET       "\033[49m"// :바탕색을 기본값으로

#define ansi_get_green_text(x)      ANSI_TEXT_GREEN x ANSI_TEXT_RESET
#define ansi_get_blue_text(x)       ANSI_TEXT_BLUE x ANSI_TEXT_RESET
#define ansi_get_red_text(x)        ANSI_TEXT_RED x ANSI_TEXT_RESET

#define ANSI_PASS					ansi_get_green_text("PASS")
#define ANSI_FAIL					ansi_get_red_text("FAIL")
#define ansi_get_status_string(x)	( (x) ) ? ANSI_PASS : ANSI_FAIL

#endif

