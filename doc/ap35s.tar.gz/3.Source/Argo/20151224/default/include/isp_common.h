void delay(int para);
