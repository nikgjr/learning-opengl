#ifndef __ISP_ENV_H__
#define __ISP_ENV_H__

#include "isp_param.h"

//--------------------------------------------------------------
// Test Environment.
// default : RTL sim
//           1.3M in/out + digital + CVBS(960nt) output
//--------------------------------------------------------------
// FPGA setting
//--------------------------------------------------------------
#define ENV_FPGA                                ENV_FPGA_OFF                // RTL Simulation
//#define ENV_FPGA                                ENV_FPGA_DEFAULT            // Digital out + CVBS out (720 960 quad 1200 1280 1440 1920 double only)
//#define ENV_FPGA                                ENV_FPGA_CVBS_1200_1280_4X  // Digital out + CVBS out (1200 1280 quad only)
//#define ENV_FPGA                                ENV_FPGA_CVBS_1440_1920_4X  // Digital out + CVBS out (1440 1920 quad only)
//#define ENV_FPGA                                ENV_FPGA_AHD                // Digital out + AHD out (1.3M 60P / 2M 30P / 148.5MHz)
//#define ENV_FPGA                                ENV_FPGA_AHD_13M30P         // Digital out + AHD out (1.3M 30P / 144MHz)

//--------------------------------------------------------------
// AHD setting & size setting
// RTL sim : AHD simulation is 13M 60P / 2M 30P
//--------------------------------------------------------------
#define PATH_AHD                                OFF             // AHD Path Mode if (ENV_TEST != ENV_TEST_OFF) => OFF

#define ENV_SIZE                                SIZE_1M_SET     // 1.3M (in/out size : 1280x720 set) with IMX224 sensor model
//#define ENV_SIZE                                SIZE_2M_SET     // 2M (in/out size : 1920x1080 set)

//--------------------------------------------------------------
// Test mode set (with rtl_sim or glm_sim)
// default : test mode off
//--------------------------------------------------------------
#define ENV_TEST                                ENV_TEST_OFF    // Test mode OFF
//#define ENV_TEST                                ENV_TEST_MODE   // Test Simulation Mode (don't set registers, Test Item: SCAN, BIST, DCI, DCO, DAC, PLL, LVDS, SDR, ADC)
//#define ENV_TEST                                ENV_TEST_IDS    // Test IDS Mode (only set GPMODE, PAD)
//#define ENV_TEST                                ENV_TEST_GPIO   // Test GPIO Mode (set the system initial function using modules of output_test_pattern and output_formatter)
//#define ENV_TEST                                ENV_TEST_FUNC   // Test Function (using External Clock)
//#define ENV_TEST                                ENV_TEST_FUNC_BYPASS   // Test Function (using External Clock + without SDRAM)
//#define ENV_TEST                                ENV_TEST_FUNC_WITH_PLL // Test Function using Internal Clock

//--------------------------------------------------------------
// WDR mode select
// if (ENV_SIZE==2M_SET) => WDR_OFF_SET or WDR_NORMAL_SET (DOL mode disable)
// if (ENV_SIZE==1M_SET) => DOL mode enable (with IMX224)
//--------------------------------------------------------------
#define WDR_MODE_SEL            WDR_OFF_SET                 // WDR Off
//#define WDR_MODE_SEL            WDR_DECOMP_SET                 // WDR On & Decompression
//#define WDR_MODE_SEL            WDR_NORMAL_SET              // WDR On & DOL mode Off
//#define WDR_MODE_SEL            WDR_DOL2_SET                // WDR On & DOL mode 2
//#define WDR_MODE_SEL            WDR_DOL3_SET                // WDR On & DOL mode 3
//#define WDR_MODE_SEL            WDR_OV10640_SET

#define ENV_120P_SET            OFF
//#define ENV_120P_SET            ON

//--------------------------------------------------------------
// LDC mode select (sensor model & input cdc is 30fps)
//--------------------------------------------------------------
#define LDC_MODE_SEL            LDC_OFF_SET                 // LDC Off
//#define LDC_MODE_SEL            LDC_ON_SET                 // LDC only On (LDC test only => WDR_MODE_SEL is WDR_OFF_SET set!!)
//#define LDC_MODE_SEL            LDC_ON_ALL_FUNC            // LDC On + FRC & all func. enable

//--------------------------------------------------------------
// OSG Test mode select 
//--------------------------------------------------------------
//#define OSG_MODE_SEL            OSG_OFF_SET                 // OSG Off
  #define OSG_MODE_SEL            OSG_ON_SET                  // OSG On
  #define OSG_DN_MODE             AXI_OFF_SET                 // AXI Off
//#define OSG_DN_MODE             AXI_ON_SET                  // AXI On

//--------------------------------------------------------------
// CVBS mode select (if PATH_AHD == ON or ENV_TEST_MODE(IDS,GPIO) -> cvbs off)
// if CVBS_MODE_DIGITAL ON => CVBS Digital out path enable
//                            Digital out data = CVBS mix data
// default : 960nt quad
//           * fpga sim env 1  : CVBS_default       is 960/720 => quad & 1200/1280/1440/1920 double only
//           * fpga sim env 2  : CVBS_1200_1280_4X  is 1200/1280 quad only
//           * fpga sim env 3  : CVBS_1440_1920_4X  is 1440/1920 quad only
//           * rtl sim         : 960/720/1200/1280 quad test
//--------------------------------------------------------------
#define CVBS_MODE_DIGITAL   OFF
//#define CVBS_MODE_DIGITAL   ON

//--------------------------------------------------------------
// CVBS_PATH_ONLY => digital out is disable & cvbs path output set
//                   (MAIN_FRC -> OFF set)
//--------------------------------------------------------------
#define CVBS_PATH_ONLY      OFF
//#define CVBS_PATH_ONLY      ON

//--------------------------------------------------------------
// 720h/960h
//--------------------------------------------------------------
// Common set (fpga sim & rtl sim)
//--------------------------------------------------------------
//#define CVBS_MODE_SEL           (CVBS_MODE_960H | CVBS_MODE_QUAD)                   // 960 NT
//#define CVBS_MODE_SEL           (CVBS_MODE_960H | CVBS_MODE_PAL | CVBS_MODE_QUAD)   // 960 PAL
#define CVBS_MODE_SEL           (CVBS_MODE_720H | CVBS_MODE_QUAD)                   // 720 NT
//#define CVBS_MODE_SEL           (CVBS_MODE_720H | CVBS_MODE_PAL | CVBS_MODE_QUAD)   // 720 PAL

//--------------------------------------------------------------
// 1200h / 1280h
//--------------------------------------------------------------
// fpga sim env 1 : CVBS_default 1200/1280 double
//--------------------------------------------------------------
//#define CVBS_MODE_SEL           (CVBS_MODE_1200H)                                   // 1200 NT
//#define CVBS_MODE_SEL           (CVBS_MODE_1280H | CVBS_MODE_PAL)                   // 1280 PAL

//--------------------------------------------------------------
// fpga sim env 2 & rtl sim : CVBS_1200_1280_4X is 1200/1280 quad only
//--------------------------------------------------------------
//#define CVBS_MODE_SEL           (CVBS_MODE_1200H | CVBS_MODE_QUAD)                  // 1200 NT
//#define CVBS_MODE_SEL           (CVBS_MODE_1280H | CVBS_MODE_PAL | CVBS_MODE_QUAD)  // 1280 PAL

//--------------------------------------------------------------
// 1440h / 1920h
//--------------------------------------------------------------
// fpga sim env 1 : CVBS_default 1440/1920 double
//--------------------------------------------------------------
//#define CVBS_MODE_SEL           (CVBS_MODE_1440H)                                   // 1440 NT
//#define CVBS_MODE_SEL           (CVBS_MODE_1440H | CVBS_MODE_PAL)                   // 1440 PAL
//#define CVBS_MODE_SEL           (CVBS_MODE_1920H)                                   // 1920 NT
//#define CVBS_MODE_SEL           (CVBS_MODE_1920H | CVBS_MODE_PAL)                   // 1920 PAL

//--------------------------------------------------------------
// fpga sim env 3 & rtl sim : CVBS_1440_1920_4X is 1440/1920 quad only
//--------------------------------------------------------------
//#define CVBS_MODE_SEL           (CVBS_MODE_1440H | CVBS_MODE_QUAD)                  // 1440 NT
//#define CVBS_MODE_SEL           (CVBS_MODE_1440H | CVBS_MODE_PAL | CVBS_MODE_QUAD)  // 1440 PAL
//#define CVBS_MODE_SEL           (CVBS_MODE_1920H | CVBS_MODE_QUAD)                  // 1920 NT
//#define CVBS_MODE_SEL           (CVBS_MODE_1920H | CVBS_MODE_PAL | CVBS_MODE_QUAD)  // 1920 PAL

//--------------------------------------------------------------------------
// VDUMP
//--------------------------------------------------------------------------
#define IN_IMAGE_1280X720_60P
//#define DS_320X240
//#define DS_318X240
//#define DS_316X240
//#define DS_314X240
//#define DS_312X240
//#define DS_320x180
#endif
