#ifndef __VDUMP_REG__
#define __VDUMP_REG__

#define VDUMP_BASE_ADDR	0x31110000
#define	ADDR_VDUMP_ENABLE					(VDUMP_BASE_ADDR + 0x8000)
#define	VDUMP_CH2_ENABLE					(1 << 3)		 // [3]
#define	VDUMP_CH1_ENABLE					(1 << 2)		 // [2]
#define	VDUMP_CH0_ENABLE					(1 << 1)		 // [1]
#define	VDUMP_ENABLE						(1 << 0)		 // [0]
#define	ADDR_VDUMP_FORMAT_SEL				(VDUMP_BASE_ADDR + 0x8004)
#define	VDUMP_IN_SEL						(1 << 16)		 // [17:16]
#define	VDUMP_BIT_ALIGN						(1 << 8)		 // [10:8]
#define	VDUMP_FORMAT_SEL					(1 << 0)		 // [0]
#define	ADDR_VDUMP_REGUP_SEL				(VDUMP_BASE_ADDR + 0x8008)
#define	VDUMP_INT_SEL						(1 << 24)		 // [25:24]
#define	VDUMP_INT_TYPE_SEL					(1 << 16)		 // [19:16]
#define	VDUMP_REGUP_SEL						(1 << 0)		 // [0]
#define	ADDR_CH0_VDUMP_PACKED_BIT			(VDUMP_BASE_ADDR + 0xC100)
#define	CH0_VDUMP_ENDIAN					(1 << 16)		 // [16]
#define	CH0_VDUMP_SHIFT						(1 << 8)		 // [9:8]
#define	CH0_VDUMP_PACKED_BIT				(1 << 0)		 // [1:0]
#define	ADDR_CH0_VDUMP_STRIDE				(VDUMP_BASE_ADDR + 0xC104)
#define	CH0_VDUMP_STRIDE					(1 << 0)		 // [12:0]
#define	ADDR_CH0_WRITE_ADDR					(VDUMP_BASE_ADDR + 0xC108)
#define	CH0_WRITE_ADDR						(1 << 0)		 // [31:0]
#define	ADDR_CH0_BURST_CTRL					(VDUMP_BASE_ADDR + 0xC10C)
#define	CH0_BURST_CTRL						(1 << 0)		 // [3:0]
#define	ADDR_CH0_VLINE						(VDUMP_BASE_ADDR + 0xC110)
#define	CH0_HPIX							(1 << 16)		 // [25:16]
#define	CH0_VLINE							(1 << 0)		 // [10:0]
#define	ADDR_CH0_ENABLE_CVBS_WRAP			(VDUMP_BASE_ADDR + 0xC114)
#define	CH0_ENABLE_CVBS_WRAP				(1 << 0)		 // [0]
#define	ADDR_CH0_CVBS_ADDR_1				(VDUMP_BASE_ADDR + 0xC118)
#define	CH0_CVBS_ADDR_1						(1 << 0)		 // [31:0]
#define	ADDR_CH0_CVBS_ADDR_MAX				(VDUMP_BASE_ADDR + 0xC11C)
#define	CH0_CVBS_ADDR_MAX					(1 << 0)		 // [31:0]
#define	ADDR_CH1_VDUMP_PACKED_BIT			(VDUMP_BASE_ADDR + 0xC200)
#define	CH1_VDUMP_ENDIAN					(1 << 16)		 // [16]
#define	CH1_VDUMP_SHIFT						(1 << 8)		 // [9:8]
#define	CH1_VDUMP_PACKED_BIT				(1 << 0)		 // [1:0]
#define	ADDR_CH1_VDUMP_STRIDE				(VDUMP_BASE_ADDR + 0xC204)
#define	CH1_VDUMP_STRIDE					(1 << 0)		 // [12:0]
#define	ADDR_CH1_WRITE_ADDR					(VDUMP_BASE_ADDR + 0xC208)
#define	CH1_WRITE_ADDR						(1 << 0)		 // [31:0]
#define	ADDR_CH1_BURST_CTRL					(VDUMP_BASE_ADDR + 0xC20C)
#define	CH1_BURST_CTRL						(1 << 0)		 // [3:0]
#define	ADDR_CH1_VLINE						(VDUMP_BASE_ADDR + 0xC210)
#define	CH1_HPIX							(1 << 16)		 // [25:16]
#define	CH1_VLINE							(1 << 0)		 // [10:0]
#define	ADDR_CH1_ENABLE_CVBS_WRAP			(VDUMP_BASE_ADDR + 0xC214)
#define	CH1_ENABLE_CVBS_WRAP				(1 << 0)		 // [0]
#define	ADDR_CH1_CVBS_ADDR_1				(VDUMP_BASE_ADDR + 0xC218)
#define	CH1_CVBS_ADDR_1						(1 << 0)		 // [31:0]
#define	ADDR_CH1_CVBS_ADDR_MAX				(VDUMP_BASE_ADDR + 0xC21C)
#define	CH1_CVBS_ADDR_MAX					(1 << 0)		 // [31:0]
#define	ADDR_CH2_VDUMP_PACKED_BIT			(VDUMP_BASE_ADDR + 0xC300)
#define	CH2_VDUMP_ENDIAN					(1 << 16)		 // [16]
#define	CH2_VDUMP_SHIFT						(1 << 8)		 // [9:8]
#define	CH2_VDUMP_PACKED_BIT				(1 << 0)		 // [1:0]
#define	ADDR_CH2_VDUMP_STRIDE				(VDUMP_BASE_ADDR + 0xC304)
#define	CH2_VDUMP_STRIDE					(1 << 0)		 // [12:0]
#define	ADDR_CH2_WRITE_ADDR					(VDUMP_BASE_ADDR + 0xC308)
#define	CH2_WRITE_ADDR						(1 << 0)		 // [31:0]
#define	ADDR_CH2_BURST_CTRL					(VDUMP_BASE_ADDR + 0xC30C)
#define	CH2_BURST_CTRL						(1 << 0)		 // [3:0]
#define	ADDR_CH2_VLINE						(VDUMP_BASE_ADDR + 0xC310)
#define	CH2_HPIX							(1 << 16)		 // [25:16]
#define	CH2_VLINE							(1 << 0)		 // [10:0]
#define	ADDR_CH2_ENABLE_CVBS_WRAP			(VDUMP_BASE_ADDR + 0xC314)
#define	CH2_ENABLE_CVBS_WRAP				(1 << 0)		 // [0]
#define	ADDR_CH2_CVBS_ADDR_1				(VDUMP_BASE_ADDR + 0xC318)
#define	CH2_CVBS_ADDR_1						(1 << 0)		 // [31:0]
#define	ADDR_CH2_CVBS_ADDR_MAX				(VDUMP_BASE_ADDR + 0xC31C)
#define	CH2_CVBS_ADDR_MAX					(1 << 0)		 // [31:0]
#define	ADDR_VDUMP_CROP_DATA_EN				(VDUMP_BASE_ADDR + 0x8040)
#define	VDUMP_CROP_SYNC_EN					(1 << 16)		 // [16]
#define	VDUMP_CROP_VSYNC_REGEN_EN			(1 << 8)		 // [8]
#define	VDUMP_CROP_DATA_EN					(1 << 0)		 // [0]
#define	ADDR_VDUMP_CROP_HBLK_LINE_REF		(VDUMP_BASE_ADDR + 0x8044)
#define	VDUMP_CROP_HDE_ST_POS				(1 << 16)		 // [31:16]
#define	VDUMP_CROP_HBLK_LINE_REF			(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_CROP_HDE_END_POS			(VDUMP_BASE_ADDR + 0x804C)
#define	VDUMP_CROP_VDE_ST_POS				(1 << 16)		 // [31:16]
#define	VDUMP_CROP_HDE_END_POS				(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_CROP_VDE_END_POS			(VDUMP_BASE_ADDR + 0x8054)
#define	VDUMP_CROP_VDE_END_POS				(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_CR_OFFSET				(VDUMP_BASE_ADDR + 0x8060)
#define	VDUMP_Y_OFFSET						(1 << 16)		 // [23:16]
#define	VDUMP_CB_OFFSET						(1 << 8)		 // [15:8]
#define	VDUMP_CR_OFFSET						(1 << 0)		 // [7:0]
#define	ADDR_VDUMP_R_OFFSET_SIGN			(VDUMP_BASE_ADDR + 0x8064)
#define	VDUMP_R_CB_GAIN_SIGN				(1 << 2)		 // [2]
#define	VDUMP_R_CR_GAIN_SIGN				(1 << 1)		 // [1]
#define	VDUMP_R_OFFSET_SIGN					(1 << 0)		 // [0]
#define	ADDR_VDUMP_R_CB_GAIN				(VDUMP_BASE_ADDR + 0x8068)
#define	VDUMP_R_Y_GAIN						(1 << 16)		 // [31:16]
#define	VDUMP_R_CB_GAIN						(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_R_OFFSET					(VDUMP_BASE_ADDR + 0x806C)
#define	VDUMP_R_CR_GAIN						(1 << 16)		 // [31:16]
#define	VDUMP_R_OFFSET						(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_R_MAX					(VDUMP_BASE_ADDR + 0x8070)
#define	VDUMP_R_MIN							(1 << 16)		 // [31:16]
#define	VDUMP_R_MAX							(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_G_OFFSET_SIGN			(VDUMP_BASE_ADDR + 0x8074)
#define	VDUMP_G_CB_GAIN_SIGN				(1 << 2)		 // [2]
#define	VDUMP_G_CR_GAIN_SIGN				(1 << 1)		 // [1]
#define	VDUMP_G_OFFSET_SIGN					(1 << 0)		 // [0]
#define	ADDR_VDUMP_G_CB_GAIN				(VDUMP_BASE_ADDR + 0x8078)
#define	VDUMP_G_Y_GAIN						(1 << 16)		 // [31:16]
#define	VDUMP_G_CB_GAIN						(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_G_OFFSET					(VDUMP_BASE_ADDR + 0x807C)
#define	VDUMP_G_CR_GAIN						(1 << 16)		 // [31:16]
#define	VDUMP_G_OFFSET						(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_G_MAX					(VDUMP_BASE_ADDR + 0x8080)
#define	VDUMP_G_MIN							(1 << 16)		 // [31:16]
#define	VDUMP_G_MAX							(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_B_OFFSET_SIGN			(VDUMP_BASE_ADDR + 0x8084)
#define	VDUMP_B_CB_GAIN_SIGN				(1 << 2)		 // [2]
#define	VDUMP_B_CR_GAIN_SIGN				(1 << 1)		 // [1]
#define	VDUMP_B_OFFSET_SIGN					(1 << 0)		 // [0]
#define	ADDR_VDUMP_B_CB_GAIN				(VDUMP_BASE_ADDR + 0x8088)
#define	VDUMP_B_Y_GAIN						(1 << 16)		 // [31:16]
#define	VDUMP_B_CB_GAIN						(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_B_OFFSET					(VDUMP_BASE_ADDR + 0x808C)
#define	VDUMP_B_CR_GAIN						(1 << 16)		 // [31:16]
#define	VDUMP_B_OFFSET						(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_B_MAX					(VDUMP_BASE_ADDR + 0x8090)
#define	VDUMP_B_MIN							(1 << 16)		 // [31:16]
#define	VDUMP_B_MAX							(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_GAIN_ADJ_OFFSET			(VDUMP_BASE_ADDR + 0x8094)
#define	VDUMP_GAIN_ADJ_GAIN					(1 << 16)		 // [31:16]
#define	VDUMP_GAIN_ADJ_OFFSET				(1 << 0)		 // [15:0]
#define	ADDR_VDUMP_OUTPUT_MODE				(VDUMP_BASE_ADDR + 0x8098)
#define	VDUMP_CHROMA_MODE					(1 << 4)		 // [5:4]
#define	VDUMP_OUTPUT_MODE					(1 << 0)		 // [0]

#endif
