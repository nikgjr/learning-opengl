#include "../config/CR4_TopRegMap.h"

#ifndef __DPGL_H__
#define __DPGL_H__
/*===================================================*/
/* base address                                      */
/*===================================================*/
#define DPGL_BASE_ADDR            APACHE_DPGL
#define DPGL_ENABLE_ADDR         (DPGL_BASE_ADDR + 0x00000280)
#define DPGL_ENABLE              (1 << 0) // [0]
#define DPGL_V_POL               (1 << 1) // [1]
#define DPGL_H_POL               (1 << 2) // [2]
#define DPGL_ST_POS              (1 << 3) // [3]
#define DPGL_V_AUTO_UP           (1 << 31) // [31]
#define DPGL_V_MANU_UP           (1 << 30) // [30]
#define DPGL_MANUAL_UP           (1 << 29) // [29]
#define DPGL_XY_OFFSET_ADDR      (DPGL_BASE_ADDR + 0x00000284)
#define DPGL_X_OFFSET            (1 << 0) //[11:0]
#define DPGL_Y_OFFSET            (1 << 16) //[27:16]
#define DPGL_IMG_HEIGHT_ADDR     (DPGL_BASE_ADDR + 0x00000288)
#define DPGL_IMG_HEIGHT          (1 << 0) //[10:0]

#endif
