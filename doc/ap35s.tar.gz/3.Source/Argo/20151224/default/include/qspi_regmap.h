#include "../config/CR4_TopRegMap.h"

/*===================================================*/
/* base address                                      */
/*===================================================*/
#define QSPI_BASE                APACHE_CUSTOM_2

