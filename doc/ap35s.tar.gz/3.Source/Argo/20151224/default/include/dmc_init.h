void dmc_init();
