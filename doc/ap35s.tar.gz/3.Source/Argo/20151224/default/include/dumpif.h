#include "../tdk/tdk_types.h"
#include "../config/CR4_TopRegMap.h"

// Type #0
typedef volatile struct
{
	u32 ENABLE;
	u32 IN_SEL;
	u32 FORMAT_SEL;
	u32 YC_SEL;
	u32 DATA_UPPER;
} SFR_DUMPIF;

#define DUMPIF 		((SFR_DUMPIF*)	APACHE_CUSTOM_1)

// Type #1
#define DUMPIF_ENABLE 		APACHE_CUSTOM_1 | 0x0000
#define DUMPIF_IN_SEL 		APACHE_CUSTOM_1 | 0x0004


void dumpif_enable();
