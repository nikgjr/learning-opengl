#ifndef __ENV_PATH_OPTION__
#define __ENV_PATH_OPTION__

#include "isp_param.h"
#include "isp_env.h"

#ifndef ENV_FPGA
#define ENV_FPGA                ENV_FPGA_OFF
#endif
#ifndef ENV_TEST
#define ENV_TEST                ENV_TEST_OFF
#endif
#ifndef ENV_SIZE
#define ENV_SIZE                SIZE_1M_SET
#endif
#ifndef PATH_AHD
#define PATH_AHD                OFF
#endif

//--------------------------------------------------------------
// FPGA_OPTION set.
//--------------------------------------------------------------
#if(ENV_FPGA==ENV_FPGA_AHD_13M30P)
    #define ENV_SIZE                SIZE_1M_SET
#endif

#if((ENV_FPGA==ENV_FPGA_DEFAULT) | (ENV_FPGA==ENV_FPGA_CVBS_1200_1280_4X) | (ENV_FPGA==ENV_FPGA_CVBS_1440_1920_4X))
    #define PATH_AHD                OFF
#elif ((ENV_FPGA==ENV_FPGA_AHD) | (ENV_FPGA==ENV_FPGA_AHD_13M30P))
    #define PATH_AHD                ON
#endif

#if(ENV_FPGA==ENV_FPGA_DEFAULT)
    #if(CVBS_MODE_SEL & CVBS_MODE_1920H)
        #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
            #define CVBS_MODE_SEL       (CVBS_MODE_1920H | CVBS_MODE_PAL)
        #else
            #define CVBS_MODE_SEL       (CVBS_MODE_1920H)
        #endif
    #elif(CVBS_MODE_SEL & CVBS_MODE_1440H)
        #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
            #define CVBS_MODE_SEL       (CVBS_MODE_1440H | CVBS_MODE_PAL)
        #else
            #define CVBS_MODE_SEL       (CVBS_MODE_1440H)
        #endif
    #elif(CVBS_MODE_SEL & CVBS_MODE_1280H)
        #define CVBS_MODE_SEL           (CVBS_MODE_1280H | CVBS_MODE_PAL)
    #elif(CVBS_MODE_SEL & CVBS_MODE_1200H)
        #define CVBS_MODE_SEL           (CVBS_MODE_1200H)
    #endif
#elif(ENV_FPGA==ENV_FPGA_CVBS_1200_1280_4X)
    #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
        #define CVBS_MODE_SEL       (CVBS_MODE_1280H | CVBS_MODE_PAL | CVBS_MODE_QUAD)
    #else
        #define CVBS_MODE_SEL       (CVBS_MODE_1200H | CVBS_MODE_QUAD)
    #endif
#elif(ENV_FPGA==ENV_FPGA_CVBS_1440_1920_4X)
    #if(CVBS_MODE_SEL & CVBS_MODE_1920H)
        #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
            #define CVBS_MODE_SEL   (CVBS_MODE_1920H | CVBS_MODE_PAL | CVBS_MODE_QUAD)
        #else
            #define CVBS_MODE_SEL   (CVBS_MODE_1920H | CVBS_MODE_QUAD)
        #endif
    #else
        #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
            #define CVBS_MODE_SEL   (CVBS_MODE_1440H | CVBS_MODE_PAL | CVBS_MODE_QUAD)
        #else
            #define CVBS_MODE_SEL   (CVBS_MODE_1440H | CVBS_MODE_QUAD)
        #endif
    #endif
#endif

//==============================================================
// 1. Test Simulation
//==============================================================
// Global Option
#define __DEBUG_MSG__                   // Global Message Using MSG Buffer to debug

//==============================================================
// Common Path
//==============================================================
#define LCDC_CROP_SEL               LCDC_CVBS_CROP_OFF
#define LCDC_EN                     OFF

#define SENSOR_CTRL_SEL             CTRL_MODE_SPI
#define EXT1_CTRL_SEL               CTRL_MODE_SPI
#define EXT2_CTRL_SEL               CTRL_MODE_SPI

#define UART_IF                     ON

#define MAIN_FRC_X2                 OFF     // 30Hz -> 60hz
#define OSD_SD                      OFF

#define MEM_SEL                     MEM_64M

//==============================================================
// in/out size & function option
//==============================================================
// 120P setting option (Only rtl_sim & 1.3M DOL3 func)
//==============================================================
#if(ENV_FPGA != ENV_FPGA_OFF)
    #define ENV_120P_SET            OFF
#elif(ENV_TEST != ENV_TEST_OFF)
    #define ENV_120P_SET            OFF
#elif(ENV_SIZE != SIZE_1M_SET)
    #define ENV_120P_SET            OFF
#elif(WDR_MODE_SEL != WDR_DOL3_SET)
    #define ENV_120P_SET            OFF
#endif

//==============================================================
// sensor interface option (parallel/lvds setting)
//==============================================================
#if(ENV_TEST == ENV_TEST_OFF)
    #if (ENV_SIZE == SIZE_1M_SET)
        #define SENSOR_PARALLEL             ON // kensoo
        #define LVDS_BIT_SEL                LVDS_10BIT_SEL
    #else
        #define SENSOR_PARALLEL             ON
    #endif
#else
    #define SENSOR_PARALLEL                 ON
#endif

//==============================================================
// WDR setting option
//     2M sensor : only 2-frame mode or off
//     func test : only lwdr3 mode
//==============================================================
#if(ENV_TEST == ENV_TEST_OFF)
    #if (ENV_SIZE != SIZE_1M_SET)
        #if (WDR_MODE_SEL != WDR_OFF_SET)
            #define WDR_MODE_SEL            WDR_NORMAL_SET
            #define WDR_2FRM_LONG_FIRST     ON
        #endif
    #else
        #if (WDR_MODE_SEL == WDR_NORMAL_SET)
            #define WDR_2FRM_LONG_FIRST     ON
        #endif
    #endif
#else
    #define WDR_MODE_SEL                    WDR_OV10640_SET
#endif

//==============================================================
// LDC func setting
//     LDC_ON_SET : only 1.3M set & normal sensor model
//     2M sensor : only LDC OFF set
//==============================================================
#if(ENV_TEST == ENV_TEST_OFF)
    #if (ENV_SIZE == SIZE_1M_SET)
        #if(WDR_MODE_SEL == WDR_OV10640_SET)
            #if (LDC_MODE_SEL == LDC_ON_SET)
                #define LDC_MODE_SEL            LDC_ON_ALL_FUNC
            #endif
        #elif(WDR_MODE_SEL == WDR_DOL3_SET)
            #if (LDC_MODE_SEL == LDC_ON_SET)
                #define LDC_MODE_SEL            LDC_ON_ALL_FUNC
            #endif
        #elif(WDR_MODE_SEL == WDR_DOL2_SET)
            #if (LDC_MODE_SEL == LDC_ON_SET)
                #define LDC_MODE_SEL            LDC_ON_ALL_FUNC
            #endif
        #endif
    #else
        #if (WDR_MODE_SEL==WDR_OFF_SET)
            #if (LDC_MODE_SEL == LDC_ON_SET)
                #define LDC_MODE_SEL            LDC_ON_ALL_FUNC
            #endif
        #else
            #define LDC_MODE_SEL                LDC_OFF_SET
        #endif
    #endif
#elif(ENV_TEST == ENV_TEST_FUNC)
    #define OSG_MODE_SEL                        OSG_ON_SET                  // OSG Off
    #define LDC_MODE_SEL                        LDC_ON_ALL_FUNC
#elif(ENV_TEST == ENV_TEST_FUNC_WITH_PLL)
    #define OSG_MODE_SEL                        OSG_ON_SET                  // OSG Off
    #define LDC_MODE_SEL                        LDC_ON_ALL_FUNC
#else
    #define OSG_MODE_SEL                        OSG_OFF_SET                 // OSG Off
    #define LDC_MODE_SEL                        LDC_OFF_SET
#endif

//==============================================================
// size setting (IIF / FRC)
//==============================================================
#if(ENV_TEST == ENV_TEST_OFF)
    #if (ENV_SIZE == SIZE_1M_SET)
        #if(LDC_MODE_SEL == LDC_ON_SET)
            #define SR_MODE_SEL                 SR_MODE_1280X720
            #define IN_MODE_SEL                 IN_MODE_1280X720_30HZ
        #else
            #if(WDR_MODE_SEL == WDR_OV10640_SET)
                #define SR_MODE_SEL             SR_MODE_OV10640
                #define IN_MODE_SEL             IN_MODE_OV10640
            #else
                #define SR_MODE_SEL             SR_MODE_1280X720
                #define IN_MODE_SEL             IN_MODE_1280X720
            #endif
        #endif

        #if(LDC_MODE_SEL == LDC_OFF_SET)
            #define FRC_MODE_SEL                FRC_MODE_1280X720_60HZ
        #else
            #define FRC_MODE_SEL                FRC_MODE_1280X720_30HZ
        #endif
    #else
        #define SR_MODE_SEL                 SR_MODE_1920X1080
        #define IN_MODE_SEL                 IN_MODE_1920X1080
        #define FRC_MODE_SEL                FRC_MODE_1920X1080
    #endif
#elif(ENV_TEST == ENV_TEST_FUNC_BYPASS)
    #define SR_MODE_SEL                     SR_MODE_TEST_OV_128X64
    #define IN_MODE_SEL                     IN_MODE_OV_128X64
#else
    #define SR_MODE_SEL                     SR_MODE_TEST_OV_128X64
    #define IN_MODE_SEL                     IN_MODE_OV_128X64
    #define FRC_MODE_SEL                    FRC_MODE_OV_128X64
#endif

//==============================================================
// CVBS size setting option
//==============================================================
#if(ENV_TEST == ENV_TEST_OFF)
    #if (ENV_SIZE == SIZE_1M_SET)
        #if(CVBS_MODE_SEL & CVBS_MODE_1920H)
            #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
                #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
                    #define CVBS_MODE_SEL       (CVBS_MODE_1280H | CVBS_MODE_PAL | CVBS_MODE_QUAD)
                #else
                    #define CVBS_MODE_SEL       (CVBS_MODE_1280H | CVBS_MODE_PAL)
                #endif
            #else
                #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
                    #define CVBS_MODE_SEL       (CVBS_MODE_1200H | CVBS_MODE_QUAD)
                #else
                    #define CVBS_MODE_SEL       (CVBS_MODE_1200H)
                #endif
            #endif
        #elif(CVBS_MODE_SEL & CVBS_MODE_1440H)
            #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
                #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
                    #define CVBS_MODE_SEL       (CVBS_MODE_1280H | CVBS_MODE_PAL | CVBS_MODE_QUAD)
                #else
                    #define CVBS_MODE_SEL       (CVBS_MODE_1280H | CVBS_MODE_PAL)
                #endif
            #else
                #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
                    #define CVBS_MODE_SEL       (CVBS_MODE_1200H | CVBS_MODE_QUAD)
                #else
                    #define CVBS_MODE_SEL       (CVBS_MODE_1200H)
                #endif
            #endif
        #endif
    #endif
#elif(ENV_TEST == ENV_TEST_FUNC_BYPASS)
    #define CVBS_MODE_SEL                   CVBS_MODE_OFF
#else
    #define CVBS_MODE_SEL                   (CVBS_MODE_TESTH | CVBS_MODE_TESTV)
#endif

//--------------------------------------------------------------
// Path Option
//--------------------------------------------------------------
#if(ENV_TEST == ENV_TEST_FUNC)
    #define SENSOR_SLAVE            OFF
    #define DIGITAL_MODE_SEL        DIGITAL_MODE_BT1120_DEMULTIPLEX
    #define AHD_MODE_SEL            AHD_MODE_OFF

    #define AHD_EN                  OFF
    #define DNR_EN                  ON
    #define MAIN_FRC                ON
    #define MAIN_FRC_DPCM           ON
    #define CVBS_FRC                ON
    #define CVBS_FRC_DPCM           ON
    #define OSD_EN                  ON
    #define WDR_EN                  ON
    #define DPC_EN                  ON
    #define LDC_EN                  ON
    #define CVBS_EN                 ON
#elif(ENV_TEST == ENV_TEST_FUNC_WITH_PLL)
    #define SENSOR_SLAVE            OFF
    #define DIGITAL_MODE_SEL        DIGITAL_MODE_BT1120_DEMULTIPLEX
    #define AHD_MODE_SEL            AHD_MODE_OFF

    #define AHD_EN                  OFF
    #define DNR_EN                  ON
    #define MAIN_FRC                ON
    #define MAIN_FRC_DPCM           ON
    #define CVBS_FRC                ON
    #define CVBS_FRC_DPCM           ON
    #define OSD_EN                  ON
    #define WDR_EN                  ON
    #define DPC_EN                  ON
    #define LDC_EN                  ON
    #define CVBS_EN                 ON
#elif(ENV_TEST == ENV_TEST_FUNC_BYPASS)
    #define SENSOR_SLAVE            OFF
    #define DIGITAL_MODE_SEL        DIGITAL_MODE_BT1120_DEMULTIPLEX
    #define AHD_MODE_SEL            AHD_MODE_OFF

    #define AHD_EN                  OFF
    #define DNR_EN                  OFF
    #define MAIN_FRC                OFF
    #define MAIN_FRC_DPCM           OFF
    #define CVBS_FRC                OFF
    #define CVBS_FRC_DPCM           OFF
    #define OSD_EN                  OFF
    #define WDR_EN                  ON
    #define DPC_EN                  OFF
    #define LDC_EN                  OFF
    #define CVBS_EN                 OFF
#elif((ENV_TEST == ENV_TEST_IDS) | (ENV_TEST == ENV_TEST_GPIO) | (ENV_TEST == ENV_TEST_MODE))
    #define DIGITAL_MODE_SEL        DIGITAL_MODE_OFF
    #define CVBS_MODE_SEL           CVBS_MODE_OFF
    #define AHD_MODE_SEL            AHD_MODE_OFF

    #define AHD_EN                  OFF
    #define DNR_EN                  OFF
    #define MAIN_FRC                OFF
    #define MAIN_FRC_DPCM           OFF
    #define CVBS_FRC                OFF
    #define CVBS_FRC_DPCM           OFF
    #define OSD_EN                  OFF
    #define WDR_EN                  OFF
    #define DPC_EN                  OFF
    #define LDC_EN                  OFF
    #define CVBS_EN                 OFF
#else
    #define SENSOR_SLAVE            OFF
    #define DIGITAL_MODE_SEL        DIGITAL_MODE_BT1120_DEMULTIPLEX

    #if(LDC_MODE_SEL == LDC_ON_SET)
        #define DNR_EN                  OFF
        #define MAIN_FRC                OFF
        #define MAIN_FRC_DPCM           OFF
    #else
        #define DNR_EN                  ON
        #define MAIN_FRC                ON
        #define MAIN_FRC_DPCM           ON
    #endif
    #define CVBS_FRC                ON
    #define CVBS_FRC_DPCM           ON
    #define OSD_EN                  ON
    #define DPC_EN                  ON
    #define LDC_EN                  ON

    #if(PATH_AHD == ON)
        #define AHD_MODE_SEL            AHD_MODE_ON
        #define CVBS_MODE_SEL           CVBS_MODE_OFF

        #define AHD_EN                  ON
        #define CVBS_EN                 OFF
    #else
        #define AHD_MODE_SEL            AHD_MODE_OFF

        #define AHD_EN                  OFF
//Jyoo        #define CVBS_EN                 ON
        #define CVBS_EN                 OFF
    #endif
#endif

#if((ENV_FPGA==ENV_FPGA_DEFAULT) | (ENV_FPGA==ENV_FPGA_CVBS_1200_1280_4X) | (ENV_FPGA==ENV_FPGA_CVBS_1440_1920_4X))
    #define DIGITAL_MODE_SEL        DIGITAL_MODE_BT1120_DEMULTIPLEX
#endif

#if(LDC_MODE_SEL == LDC_ON_SET)
    #define OSD_EN                  OFF
#else
#endif

#if (ENV_SIZE == SIZE_2M_SET)
    #if (LDC_MODE_SEL == LDC_ON_ALL_FUNC)
        #define CVBS_MODE_SEL           CVBS_MODE_OFF
        #define OSD_EN                  OFF
        #define CVBS_EN                 OFF
    #endif
#endif

#if(PATH_AHD==ON)
    #define CVBS_PATH_ONLY      OFF
#endif

#if(CVBS_PATH_ONLY==ON)
    #define MAIN_FRC                OFF
#endif

    #define LDC_PIP_EN                  OFF
    #define LDC_PANORAMA_SET            OFF
    #define MAIN_FRC_DPCM2              OFF

#if(LDC_PANORAMA_SET==ON)
    #define OSD_EN                  OFF
#endif

//==============================================================
// SDR_BASE_ADDR
//==============================================================
#if(ENV_SIZE==SIZE_2M_SET)
    #if (LDC_MODE_SEL==LDC_ON_ALL_FUNC)
        #define DPC_BASE_ADDR               0x08000000
        #define CVBS_BASE0_ADDR             0x08004000
        #define CVBS_BASE1_ADDR             0x08004000
        #define DNR_BASE_ADDR               0x08004000
        #define LBFRC_BASE0_ADDR            0x08400800
        #define LBFRC_BASE1_ADDR            0x08400800
        #define LBFRC_BASE2_ADDR            0x08400800
        #define LBFRC_MAX_ADDR              0x08400800
        #define LBFRC_2FR_ADDR              0x08400800
        #define LDC_BASE_ADDR               0x08400800
        #define LDC_PIP_BASE_ADDR           0x087F5000
        #define LDC_LUT0_BASE_ADDR          0x087F5000
        #define LDC_LUT1_BASE_ADDR          0x087FA438
        #define LDC_PIP_LUT0_BASE_ADDR      0x087FF870
        #define LDC_PIP_LUT1_BASE_ADDR      0x087FF870
        #define OSD_BASE_ADDR               0x08000000
    #else
        #define DPC_BASE_ADDR               0x08000000
        #define CVBS_BASE0_ADDR             0x08004000
        #define CVBS_BASE1_ADDR             0x0809C000
        #define DNR_BASE_ADDR               0x08134000
        #define LBFRC_BASE0_ADDR            0x0853C000
        #define LBFRC_BASE1_ADDR            0x087B7800
        #define LBFRC_BASE2_ADDR            0x087B7800
        #define LBFRC_MAX_ADDR              0x087B7800
        #define LBFRC_2FR_ADDR              0x087B7800
        #define LDC_BASE_ADDR               0x087B7800
        #define LDC_PIP_BASE_ADDR           0x087B7800
        #define LDC_LUT0_BASE_ADDR          0x087B7800
        #define LDC_LUT1_BASE_ADDR          0x087B7800
        #define LDC_PIP_LUT0_BASE_ADDR      0x087B7800
        #define LDC_PIP_LUT1_BASE_ADDR      0x087B7800
        #define OSD_BASE_ADDR               0x087DEC00
    #endif
#else
    #if(LDC_MODE_SEL == LDC_ON_SET)
    // LDC Only Scenario
        #define DPC_BASE_ADDR               0x08000000
        #define CVBS_BASE0_ADDR             0x08004000
        #define CVBS_BASE1_ADDR             0x0809C000
        #define DNR_BASE_ADDR               0x08134000
        #define LBFRC_BASE0_ADDR            0x08303000
        #define LBFRC_BASE1_ADDR            0x08303000
        #define LBFRC_BASE2_ADDR            0x08303000
        #define LBFRC_MAX_ADDR              0x08303000
        #define LBFRC_2FR_ADDR              0x08303000
        #define LDC_BASE_ADDR               0x08303000
        #define LDC_PIP_BASE_ADDR           0x086A0C00
        #define LDC_LUT0_BASE_ADDR          0x08786C00
        #define LDC_LUT1_BASE_ADDR          0x08795530
        #define LDC_PIP_LUT0_BASE_ADDR      0x087ECC50
        #define LDC_PIP_LUT1_BASE_ADDR      0x087F0888
        #define OSD_BASE_ADDR               0x08000000
    #else
    // 1.3M Main Scenario 10-1
        #if(CVBS_PATH_ONLY==ON)
            #define DPC_BASE_ADDR               0x08000000
            #define CVBS_BASE0_ADDR             0x08004000
            #define CVBS_BASE1_ADDR             0x08112000
            #define DNR_BASE_ADDR               0x08220000
            #define LBFRC_BASE0_ADDR            0x08302800
            #define LBFRC_BASE1_ADDR            0x083BF400
            #define LBFRC_BASE2_ADDR            0x0841DC00
            #define LBFRC_MAX_ADDR              0x0841DC00
            #define LBFRC_2FR_ADDR              0x0841DC00
            #define LDC_BASE_ADDR               0x0841DC00
            #define LDC_PIP_BASE_ADDR           0x085E2C00
            #define LDC_LUT0_BASE_ADDR          0x086C8C00
            #define LDC_LUT1_BASE_ADDR          0x086D7530
            #define LDC_PIP_LUT0_BASE_ADDR      0x087B1F00
            #define LDC_PIP_LUT1_BASE_ADDR      0x087B5B38
            #define OSD_BASE_ADDR               0x087DEC00
        #elif(LDC_PANORAMA_SET==ON)
            #define DPC_BASE_ADDR               0x08000000
            #define CVBS_BASE0_ADDR             0x08004000
            #define CVBS_BASE1_ADDR             0x0809C000
            #define DNR_BASE_ADDR               0x08134000
            #define LBFRC_BASE0_ADDR            0x08303000
            #define LBFRC_BASE1_ADDR            0x08303000
            #define LBFRC_BASE2_ADDR            0x08303000
            #define LBFRC_MAX_ADDR              0x08303000
            #define LBFRC_2FR_ADDR              0x08303000
            #define LDC_BASE_ADDR               0x08303000
            #define LDC_PIP_BASE_ADDR           0x086A0C00
            #define LDC_LUT0_BASE_ADDR          0x08786C00
            #define LDC_LUT1_BASE_ADDR          0x08795530
            #define LDC_PIP_LUT0_BASE_ADDR      0x087ECC50
            #define LDC_PIP_LUT1_BASE_ADDR      0x087F0888
            #define OSD_BASE_ADDR               0x08000000
        #else
            #define DPC_BASE_ADDR               0x08000000
            #define CVBS_BASE0_ADDR             0x08004000
            #define CVBS_BASE1_ADDR             0x0809C000
            #define DNR_BASE_ADDR               0x08134000
            #define LBFRC_BASE0_ADDR            0x08303000
            #define LBFRC_BASE1_ADDR            0x083BFC00
            #define LBFRC_BASE2_ADDR            0x0841E400
            #define LBFRC_MAX_ADDR              0x0841E400
            #define LBFRC_2FR_ADDR              0x0841E400
            #define LDC_BASE_ADDR               0x0841E400
            #define LDC_PIP_BASE_ADDR           0x085E3400
            #define LDC_LUT0_BASE_ADDR          0x086C9400
            #define LDC_LUT1_BASE_ADDR          0x086D7D30
            #define LDC_PIP_LUT0_BASE_ADDR      0x087B2700
            #define LDC_PIP_LUT1_BASE_ADDR      0x087B6338
            #define OSD_BASE_ADDR               0x087DEC00
        #endif
    #endif
#endif

//==============================================================
//==============================================================

//==============================================================
// 3. Selection
//==============================================================
// sensor size
#if (SR_MODE_SEL==SR_MODE_TEST_128X64)
    #define SR_VB_OB                            SR_TEST_128X64_VB_OB
    #define SR_V_OB                             SR_TEST_128X64_V_OB
    #define SR_VB_TR                            SR_TEST_128X64_VB_TR
    #define SR_VB_ACT                           SR_TEST_128X64_VB_ACT
    #define SR_HB_OB                            SR_TEST_128X64_HB_OB
    #define SR_H_OB                             SR_TEST_128X64_H_OB
    #define SR_HB_TR                            SR_TEST_128X64_HB_TR
    #define SR_HB_ACT                           SR_TEST_128X64_HB_ACT
#elif (SR_MODE_SEL==SR_MODE_TEST_OV_128X64)
    #define SR_VB_OB                            SR_TEST_OV_128X64_VB_OB
    #define SR_V_OB                             SR_TEST_OV_128X64_V_OB
    #define SR_VB_TR                            SR_TEST_OV_128X64_VB_TR
    #define SR_VB_ACT                           SR_TEST_OV_128X64_VB_ACT
    #define SR_HB_OB                            SR_TEST_OV_128X64_HB_OB
    #define SR_H_OB                             SR_TEST_OV_128X64_H_OB
    #define SR_HB_TR                            SR_TEST_OV_128X64_HB_TR
    #define SR_HB_ACT                           SR_TEST_OV_128X64_HB_ACT
#elif (SR_MODE_SEL==SR_MODE_1280X720)
    #define SR_VB_OB                            SR_IMX224_1280X720_VB_OB
    #define SR_V_OB                             SR_IMX224_1280X720_V_OB
    #define SR_VB_TR                            SR_IMX224_1280X720_VB_TR
    #define SR_VB_ACT                           SR_IMX224_1280X720_VB_ACT
    #define SR_HB_OB                            SR_IMX224_1280X720_HB_OB
    #define SR_H_OB                             SR_IMX224_1280X720_H_OB
    #define SR_HB_TR                            SR_IMX224_1280X720_HB_TR
    #define SR_HB_ACT                           SR_IMX224_1280X720_HB_ACT
#elif (SR_MODE_SEL==SR_MODE_1280X1024)
    #define SR_VB_OB                            SR_1280X1024_VB_OB
    #define SR_V_OB                             SR_1280X1024_V_OB
    #define SR_VB_TR                            SR_1280X1024_VB_TR
    #define SR_VB_ACT                           SR_1280X1024_VB_ACT
    #define SR_HB_OB                            SR_1280X1024_HB_OB
    #define SR_H_OB                             SR_1280X1024_H_OB
    #define SR_HB_TR                            SR_1280X1024_HB_TR
    #define SR_HB_ACT                           SR_1280X1024_HB_ACT
#elif (SR_MODE_SEL==SR_MODE_OV10640)
    #define SR_VB_OB                            SR_OV10640_1280X720_VB_OB
    #define SR_V_OB                             SR_OV10640_1280X720_V_OB
    #define SR_VB_TR                            SR_OV10640_1280X720_VB_TR
    #define SR_VB_ACT                           SR_OV10640_1280X720_VB_ACT
    #define SR_HB_OB                            SR_OV10640_1280X720_HB_OB
    #define SR_H_OB                             SR_OV10640_1280X720_H_OB
    #define SR_HB_TR                            SR_OV10640_1280X720_HB_TR
    #define SR_HB_ACT                           SR_OV10640_1280X720_HB_ACT
#else
    #define SR_VB_OB                            SR_1920X1080_VB_OB
    #define SR_V_OB                             SR_1920X1080_V_OB
    #define SR_VB_TR                            SR_1920X1080_VB_TR
    #define SR_VB_ACT                           SR_1920X1080_VB_ACT
    #define SR_HB_OB                            SR_1920X1080_HB_OB
    #define SR_H_OB                             SR_1920X1080_H_OB
    #define SR_HB_TR                            SR_1920X1080_HB_TR
    #define SR_HB_ACT                           SR_1920X1080_HB_ACT
#endif

// input
#if(IN_MODE_SEL == IN_MODE_1280X1024)
    #define IN_VBLK0                            IN_1280X1024_VBLK
    #define IN_VACT0                            IN_1280X1024_VACT
    #define IN_HBLK                             IN_1280X1024_HBLK
    #define IN_HACT                             IN_1280X1024_HACT
#elif(IN_MODE_SEL == IN_MODE_1280X720)
    #define IN_VBLK0                            IN_1280X720_VBLK
    #define IN_VACT0                            IN_1280X720_VACT
    #define IN_HBLK                             IN_1280X720_HBLK
    #define IN_HACT                             IN_1280X720_HACT
#elif(IN_MODE_SEL == IN_MODE_1280X720_30HZ)
    #define IN_VBLK0                            IN_1280X720_30HZ_VBLK
    #define IN_VACT0                            IN_1280X720_30HZ_VACT
    #define IN_HBLK                             IN_1280X720_30HZ_HBLK
    #define IN_HACT                             IN_1280X720_30HZ_HACT
#elif(IN_MODE_SEL == IN_MODE_OV10640)
    #define IN_VBLK0                            IN_1280X720_VBLK
    #define IN_VACT0                            IN_1280X720_VACT
    #define IN_HBLK                             IN_OV10640_HBLK
    #define IN_HACT                             IN_OV10640_HACT
#elif(IN_MODE_SEL == IN_MODE_128X64)
    #define IN_VBLK0                            IN_128X64_VBLK
    #define IN_VACT0                            IN_128X64_VACT
    #define IN_HBLK                             IN_128X64_HBLK
    #define IN_HACT                             IN_128X64_HACT
#elif(IN_MODE_SEL == IN_MODE_OV_128X64)
    #define IN_VBLK0                            IN_128X64_OV_VBLK
    #define IN_VACT0                            IN_128X64_OV_VACT
    #define IN_HBLK                             IN_128X64_OV_HBLK
    #define IN_HACT                             IN_128X64_OV_HACT
#else   // default : IN_MODE_1920X1080
    #define IN_VBLK0                            IN_1920X1080_VBLK
    #define IN_VACT0                            IN_1920X1080_VACT
    #define IN_HBLK                             IN_1920X1080_HBLK
    #define IN_HACT                             IN_1920X1080_HACT
#endif

#if(WDR_MODE_SEL == WDR_OV10640_SET)
    //#define IN_VBLK                             IN_VBLK0-1
    //#define IN_VACT                             IN_VACT0+1
    #define IN_VBLK                             IN_VBLK0
    #define IN_VACT                             IN_VACT0
#else
    #define IN_VBLK                             IN_VBLK0
    #define IN_VACT                             IN_VACT0
#endif

#define IN_VTOTAL                               (IN_VBLK + IN_VACT)
#define IN_HTOTAL                               (IN_HBLK + IN_HACT)

#if(WDR_MODE_SEL == WDR_OV10640_SET)
//#define IN_HACT_LBFRC                           IN_HACT/3
//#define IN_HBLK_LBFRC                           IN_HBLK/3-1
//#define IN_VACT_LBFRC                           IN_VACT-1
//#define IN_VBLK_LBFRC                           IN_VBLK+1
#define IN_HACT_LBFRC                           IN_HACT/3
#define IN_HBLK_LBFRC                           IN_HBLK/3
#define IN_VACT_LBFRC                           IN_VACT
#define IN_VBLK_LBFRC                           IN_VBLK
#else
#define IN_HACT_LBFRC                           IN_HACT
#define IN_HBLK_LBFRC                           IN_HBLK
#define IN_VACT_LBFRC                           IN_VACT
#define IN_VBLK_LBFRC                           IN_VBLK
#endif
//#define IN_HBLK_LBFRC                           IN_HTOTAL - IN_HACT_LBFRC

#if(WDR_MODE_SEL == WDR_OV10640_SET)
//#define IIF_VACT                            IN_VACT+1
//#define IIF_OB1_VACT                        IN_VACT+1
#define IIF_VACT                            IN_VACT
#define IIF_OB1_VACT                        IN_VACT
#else
#define IIF_VACT                            IN_VACT
#define IIF_OB1_VACT                        IN_VACT
#endif

#define IIF_HACT0                           IN_HACT
#define IIF_FP_HACT0                        (SR_HB_OB+SR_H_OB+SR_HB_TR+SR_HB_ACT)
#define IIF_OB1_HACT0                       SR_H_OB
#define IIF_OB1_FP_HACT0                    SR_HB_OB
#define IIF_OB2_HACT0                       IN_HACT
#define IIF_OB2_FP_HACT0                    (SR_HB_OB+SR_H_OB+SR_HB_TR+SR_HB_ACT)

#if(SENSOR_PARALLEL==ON)
    #define IIF_HACT                        IIF_HACT0       
    #define IIF_FP_HACT                     IIF_FP_HACT0    
    #define IIF_OB1_HACT                    IIF_OB1_HACT0   
    #define IIF_OB1_FP_HACT                 IIF_OB1_FP_HACT0
    #define IIF_OB2_HACT                    IIF_OB2_HACT0   
    #define IIF_OB2_FP_HACT                 IIF_OB2_FP_HACT0
#else
    #if(LVDS_BIT_SEL==LVDS_10BIT_SEL)
        #define IIF_HACT                    IIF_HACT0        * 1.25
        #define IIF_FP_HACT                 IIF_FP_HACT0     * 1.25
        #define IIF_OB1_HACT                IIF_OB1_HACT0    * 1.25
        #define IIF_OB1_FP_HACT             IIF_OB1_FP_HACT0 * 1.25
        #define IIF_OB2_HACT                IIF_OB2_HACT0    * 1.25
        #define IIF_OB2_FP_HACT             IIF_OB2_FP_HACT0 * 1.25
    #else                                                    
        #define IIF_HACT                    IIF_HACT0        * 1.5
        #define IIF_FP_HACT                 IIF_FP_HACT0     * 1.5
        #define IIF_OB1_HACT                IIF_OB1_HACT0    * 1.5
        #define IIF_OB1_FP_HACT             IIF_OB1_FP_HACT0 * 1.5
        #define IIF_OB2_HACT                IIF_OB2_HACT0    * 1.5
        #define IIF_OB2_FP_HACT             IIF_OB2_FP_HACT0 * 1.5
    #endif
#endif

#define IIF_FP_VACT                         (SR_VB_OB+SR_V_OB+SR_VB_TR+SR_VB_ACT)
#define IIF_OB1_FP_VACT                     (SR_VB_OB+SR_V_OB+SR_VB_TR+SR_VB_ACT)
#define IIF_OB2_VACT                        SR_V_OB
#define IIF_OB2_FP_VACT                     SR_VB_OB

// frc output
#if(FRC_MODE_SEL == FRC_MODE_1920X1080)
    #define FRC_VBLK                            FRC_1920X1080_VBLK
    #define FRC_VACT                            FRC_1920X1080_VACT
    #define FRC_HBLK                            FRC_1920X1080_HBLK
    #define FRC_HACT                            FRC_1920X1080_HACT
#elif(FRC_MODE_SEL == FRC_MODE_1920X1080_25HZ)
    #define FRC_VBLK                            FRC_1920X1080_25HZ_VBLK
    #define FRC_VACT                            FRC_1920X1080_25HZ_VACT
    #define FRC_HBLK                            FRC_1920X1080_25HZ_HBLK
    #define FRC_HACT                            FRC_1920X1080_25HZ_HACT
#elif(FRC_MODE_SEL == FRC_MODE_1280X1024)
    #define FRC_VBLK                            FRC_1280X1024_VBLK
    #define FRC_VACT                            FRC_1280X1024_VACT
    #define FRC_HBLK                            FRC_1280X1024_HBLK
    #define FRC_HACT                            FRC_1280X1024_HACT
#elif(FRC_MODE_SEL == FRC_MODE_1280X720_60HZ)
    #define FRC_VBLK                            FRC_1280X720_60HZ_VBLK
    #define FRC_VACT                            FRC_1280X720_60HZ_VACT
    #define FRC_HBLK                            FRC_1280X720_60HZ_HBLK
    #define FRC_HACT                            FRC_1280X720_60HZ_HACT
#elif(FRC_MODE_SEL == FRC_MODE_1280X720_30HZ)
    #define FRC_VBLK                            FRC_1280X720_30HZ_VBLK
    #define FRC_VACT                            FRC_1280X720_30HZ_VACT
    #define FRC_HBLK                            FRC_1280X720_30HZ_HBLK
    #define FRC_HACT                            FRC_1280X720_30HZ_HACT
#elif(FRC_MODE_SEL == FRC_MODE_128X64)
    #define FRC_VBLK                            FRC_128X64_VBLK
    #define FRC_VACT                            FRC_128X64_VACT
    #define FRC_HBLK                            FRC_128X64_HBLK
    #define FRC_HACT                            FRC_128X64_HACT
#elif(FRC_MODE_SEL == FRC_MODE_OV_128X64)
    #define FRC_VBLK                            FRC_128X64_OV_VBLK
    #define FRC_VACT                            FRC_128X64_OV_VACT
    #define FRC_HBLK                            FRC_128X64_OV_HBLK
    #define FRC_HACT                            FRC_128X64_OV_HACT
#else
    #define FRC_VBLK                            IN_VBLK_LBFRC
    #define FRC_VACT                            IN_VACT_LBFRC
    #define FRC_HBLK                            IN_HBLK_LBFRC
    #define FRC_HACT                            IN_HACT_LBFRC
#endif
#define FRC_VTOTAL                              (FRC_VBLK + FRC_VACT)
#define FRC_HTOTAL                              (FRC_HBLK + FRC_HACT)

// cvbs output
#if(CVBS_MODE_SEL & CVBS_MODE_1920H)
    #define CVBS_HACT                           CVBS_1920_HACT
    #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
    #define CVBS_HBLK                           CVBS_1920PAL_HBLK
    #else
    #define CVBS_HBLK                           CVBS_1920NT_HBLK
    #endif
#elif(CVBS_MODE_SEL & CVBS_MODE_1440H)
    #define CVBS_HACT                           CVBS_1440_HACT
    #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
    #define CVBS_HBLK                           CVBS_1440PAL_HBLK
    #else
    #define CVBS_HBLK                           CVBS_1440NT_HBLK
    #endif
#elif(CVBS_MODE_SEL & CVBS_MODE_1280H)
    #define CVBS_HACT                           CVBS_1280_HACT
    #define CVBS_HBLK                           CVBS_1280PAL_HBLK
#elif(CVBS_MODE_SEL & CVBS_MODE_1200H)
    #define CVBS_HACT                           CVBS_1200_HACT
    #define CVBS_HBLK                           CVBS_1200NT_HBLK
#elif(CVBS_MODE_SEL & CVBS_MODE_960H)
    #define CVBS_HACT                           CVBS_960_HACT
    #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
    #define CVBS_HBLK                           CVBS_960PAL_HBLK
    #else
    #define CVBS_HBLK                           CVBS_960NT_HBLK
    #endif
#elif(CVBS_MODE_SEL & CVBS_MODE_TESTH)
    #define CVBS_HACT                           CVBS_128X64_OV_HACT
    #define CVBS_HBLK                           CVBS_128X64_OV_HBLK
#else
    #define CVBS_HACT                           CVBS_720_HACT
    #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
    #define CVBS_HBLK                           CVBS_720PAL_HBLK
    #else
    #define CVBS_HBLK                           CVBS_720NT_HBLK
    #endif
#endif

#if(CVBS_MODE_SEL & CVBS_MODE_PAL)
    #define CVBS_VBLK1                          CVBS_PAL_VBLK1
    #define CVBS_VBLK2                          CVBS_PAL_VBLK2
    #define CVBS_VACT                           CVBS_PAL_VACT
#elif(CVBS_MODE_SEL & CVBS_MODE_TESTV)
    #define CVBS_VBLK1                          CVBS_128X64_OV_VBLK
    #define CVBS_VBLK2                          CVBS_128X64_OV_VBLK
    #define CVBS_VACT                           CVBS_128X64_OV_VACT
#else
    #define CVBS_VBLK1                          CVBS_NT_VBLK1
    #define CVBS_VBLK2                          CVBS_NT_VBLK2
    #define CVBS_VACT                           CVBS_NT_VACT
#endif

#if(FRC_MODE_SEL == FRC_MODE_1920X1080)
    #define CVBS_CROP_FRC_VACT                  1080
    #define CVBS_CROP_FRC_HACT                  1920
#elif(FRC_MODE_SEL == FRC_MODE_1920X1080_25HZ)
    #define CVBS_CROP_FRC_VACT                  1080
    #define CVBS_CROP_FRC_HACT                  1920
#elif(FRC_MODE_SEL == FRC_MODE_1280X1024)
    #define CVBS_CROP_FRC_VACT                  1024
    #define CVBS_CROP_FRC_HACT                  1280
#elif(FRC_MODE_SEL == FRC_MODE_1280X720_60HZ)
    #define CVBS_CROP_FRC_VACT                  720
    #define CVBS_CROP_FRC_HACT                  1280
#elif(FRC_MODE_SEL == FRC_MODE_1280X720_30HZ)
    #define CVBS_CROP_FRC_VACT                  720
    #define CVBS_CROP_FRC_HACT                  1280
#elif(FRC_MODE_SEL == FRC_MODE_128X64)
    #define CVBS_CROP_FRC_VACT                  64
    #define CVBS_CROP_FRC_HACT                  128
#elif(FRC_MODE_SEL == FRC_MODE_OV_128X64)
    #define CVBS_CROP_FRC_VACT                  64
    #define CVBS_CROP_FRC_HACT                  128
#else
    #define CVBS_CROP_FRC_VACT                  IN_VACT_LBFRC
    #define CVBS_CROP_FRC_HACT                  IN_HACT_LBFRC
#endif

#if(FRC_MODE_SEL == FRC_MODE_1920X1080)
    #define OUTPUT_FORMATTER_VACT               1080
    #define OUTPUT_FORMATTER_HACT               1920
#elif(FRC_MODE_SEL == FRC_MODE_1920X1080_25HZ)
    #define OUTPUT_FORMATTER_VACT               1080
    #define OUTPUT_FORMATTER_HACT               1920
#elif(FRC_MODE_SEL == FRC_MODE_1280X1024)
    #define OUTPUT_FORMATTER_VACT               1024
    #define OUTPUT_FORMATTER_HACT               1280
#elif(FRC_MODE_SEL == FRC_MODE_1280X720_60HZ)
    #define OUTPUT_FORMATTER_VACT               720
    #define OUTPUT_FORMATTER_HACT               1280
#elif(FRC_MODE_SEL == FRC_MODE_1280X720_30HZ)
    #define OUTPUT_FORMATTER_VACT               720
    #define OUTPUT_FORMATTER_HACT               1280
#elif(FRC_MODE_SEL == FRC_MODE_128X64)
    #define OUTPUT_FORMATTER_VACT               64
    #define OUTPUT_FORMATTER_HACT               128
#elif(FRC_MODE_SEL == FRC_MODE_OV_128X64)
    #define OUTPUT_FORMATTER_VACT               64
    #define OUTPUT_FORMATTER_HACT               128
#else
    #define OUTPUT_FORMATTER_VACT               IN_VACT_LBFRC
    #define OUTPUT_FORMATTER_HACT               IN_HACT_LBFRC
#endif
#define OUTPUT_FORMATTER_VBLK                   FRC_VTOTAL - OUTPUT_FORMATTER_VACT
#define OUTPUT_FORMATTER_HBLK                   FRC_HTOTAL - OUTPUT_FORMATTER_HACT

// lvds decoder for imx224
#if(LVDS_BIT_SEL==LVDS_10BIT_SEL)
    #define LD_SYNC_CODE0                       0x0003FF
    #define LD_SYNC_CODE1                       0x000000
    #define LD_SYNC_CODE2                       0x000000
    #define LD_SYNC_CODE3_PVSYNC                0x0002AC
    #define LD_SYNC_CODE3_NVSYNC                0x000200
    #define LD_SYNC_CODE3_PHSYNC                0x000200
    #define LD_SYNC_CODE3_NHSYNC                0x000274

    #define LD_SYNC_CODE3_PVSYNC0L_DOL          0x00AC
    #define LD_SYNC_CODE3_PVSYNC0M_DOL          0x00AC
    #define LD_SYNC_CODE3_PVSYNC0S_DOL          0x00AC
    #define LD_SYNC_CODE3_PVSYNC1L_DOL          0x01AC
    #define LD_SYNC_CODE3_PVSYNC1M_DOL          0x01AC
    #define LD_SYNC_CODE3_PVSYNC1S_DOL          0x01AC
    #define LD_SYNC_CODE3_NVSYNC0L_DOL          0x0001
    #define LD_SYNC_CODE3_NVSYNC0M_DOL          0x0002
    #define LD_SYNC_CODE3_NVSYNC0S_DOL          0x0200
    #define LD_SYNC_CODE3_NVSYNC1L_DOL          0x0101
    #define LD_SYNC_CODE3_NVSYNC1M_DOL          0x0102
    #define LD_SYNC_CODE3_NVSYNC1S_DOL          0x0300
    #define LD_SYNC_CODE3_PHSYNC0L_DOL          0x0001
    #define LD_SYNC_CODE3_PHSYNC0M_DOL          0x0002
    #define LD_SYNC_CODE3_PHSYNC0S_DOL          0x0200
    #define LD_SYNC_CODE3_PHSYNC1L_DOL          0x0101
    #define LD_SYNC_CODE3_PHSYNC1M_DOL          0x0102
    #define LD_SYNC_CODE3_PHSYNC1S_DOL          0x0300
    #define LD_SYNC_CODE3_NHSYNC0L_DOL          0x0075
    #define LD_SYNC_CODE3_NHSYNC0M_DOL          0x0076
    #define LD_SYNC_CODE3_NHSYNC0S_DOL          0x0274
    #define LD_SYNC_CODE3_NHSYNC1L_DOL          0x0175
    #define LD_SYNC_CODE3_NHSYNC1M_DOL          0x0176
    #define LD_SYNC_CODE3_NHSYNC1S_DOL          0x0374
#else
    #define LD_SYNC_CODE0                       0x000FFF
    #define LD_SYNC_CODE1                       0x000000
    #define LD_SYNC_CODE2                       0x000000
    #define LD_SYNC_CODE3_PVSYNC                0x000AB0
    #define LD_SYNC_CODE3_NVSYNC                0x000800
    #define LD_SYNC_CODE3_PHSYNC                0x000800
    #define LD_SYNC_CODE3_NHSYNC                0x0009D0

    #define LD_SYNC_CODE3_PVSYNC0L_DOL          0x02B0
    #define LD_SYNC_CODE3_PVSYNC0M_DOL          0x02B0
    #define LD_SYNC_CODE3_PVSYNC0S_DOL          0x02B0
    #define LD_SYNC_CODE3_PVSYNC1L_DOL          0x06B0
    #define LD_SYNC_CODE3_PVSYNC1M_DOL          0x06B0
    #define LD_SYNC_CODE3_PVSYNC1S_DOL          0x06B0
    #define LD_SYNC_CODE3_NVSYNC0L_DOL          0x0801
    #define LD_SYNC_CODE3_NVSYNC0M_DOL          0x0802
    #define LD_SYNC_CODE3_NVSYNC0S_DOL          0x0804
    #define LD_SYNC_CODE3_NVSYNC1L_DOL          0x0C01
    #define LD_SYNC_CODE3_NVSYNC1M_DOL          0x0C02
    #define LD_SYNC_CODE3_NVSYNC1S_DOL          0x0C04
    #define LD_SYNC_CODE3_PHSYNC0L_DOL          0x0801
    #define LD_SYNC_CODE3_PHSYNC0M_DOL          0x0802
    #define LD_SYNC_CODE3_PHSYNC0S_DOL          0x0804
    #define LD_SYNC_CODE3_PHSYNC1L_DOL          0x0C01
    #define LD_SYNC_CODE3_PHSYNC1M_DOL          0x0C02
    #define LD_SYNC_CODE3_PHSYNC1S_DOL          0x0C04
    #define LD_SYNC_CODE3_NHSYNC0L_DOL          0x09D1
    #define LD_SYNC_CODE3_NHSYNC0M_DOL          0x09D2
    #define LD_SYNC_CODE3_NHSYNC0S_DOL          0x09D4
    #define LD_SYNC_CODE3_NHSYNC1L_DOL          0x0DD1
    #define LD_SYNC_CODE3_NHSYNC1M_DOL          0x0DD2
    #define LD_SYNC_CODE3_NHSYNC1S_DOL          0x0DD4
#endif

//==============================================================
//==============================================================


#endif  // __ENV_PATH_OPTION__
