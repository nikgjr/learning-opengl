#ifndef __ENV_PARAM_H__
#define __ENV_PARAM_H__

//==============================================================
// 1. declaration
//==============================================================
//--------------------------------------------------------------
// Type
//--------------------------------------------------------------
#ifndef FALSE
    #define FALSE   0x00
#endif

#ifndef TRUE
    #define TRUE    0x01
#endif

#ifndef ON
    #define ON      0x00
#endif

#ifndef OFF
    #define OFF     0x01
#endif

//--------------------------------------------------------------
// FPGA_OPTION
//--------------------------------------------------------------
#define ENV_FPGA_OFF                            0
#define ENV_FPGA_DEFAULT                        1
#define ENV_FPGA_CVBS_1200_1280_4X              2
#define ENV_FPGA_CVBS_1440_1920_4X              3
#define ENV_FPGA_AHD                            4
#define ENV_FPGA_AHD_13M30P                     5

//--------------------------------------------------------------
// Memory Option
//--------------------------------------------------------------
#define MEM_NON                                 0x00
#define MEM_32M                                 0x01
#define MEM_64M                                 0x02

//--------------------------------------------------------------
// LCDC CROP MODE
//--------------------------------------------------------------
#define LCDC_CVBS_CROP_OFF               0
#define LCDC_CVBS_CROP_1920x1080_NT              1

//--------------------------------------------------------------
// CROP V resolution for LCDC
//--------------------------------------------------------------
// 74.25Mhz
#define CVBS_VCROP_1920x1080_NT                 1056

//--------------------------------------------------------------
// Test mode Option
//--------------------------------------------------------------
#define ENV_TEST_OFF                            1
#define ENV_TEST_MODE                           2
#define ENV_TEST_IDS                            3
#define ENV_TEST_GPIO                           4
#define ENV_TEST_FUNC                           5
#define ENV_TEST_FUNC_BYPASS                    6
#define ENV_TEST_FUNC_WITH_PLL                  7

//--------------------------------------------------------------
// External Control Option
//--------------------------------------------------------------
#define CTRL_MODE_SPI                           1
#define CTRL_MODE_I2C                           2

//--------------------------------------------------------------
// In/Out Size set
//--------------------------------------------------------------
#define SIZE_1M_SET                             1
#define SIZE_2M_SET                             2

//--------------------------------------------------------------
// SENSOR_MODE
//--------------------------------------------------------------
#define SR_MODE_1920X1080                       1               // Parallel Mode, PAT_NUM = 14 (30P) / 34 (60P)
#define SR_MODE_1280X1024                       2               // Parallel Mode, PAT_NUM = 1E
#define SR_MODE_1280X720                        3               // LVDS (DOL) Mode, IMX224
#define SR_MODE_TEST_128X64                     4               // parallel Mode, PAT_NUM = 17
#define SR_MODE_TEST_OV_128X64                  5               // parallel Mode, PAT_NUM = 17

//--------------------------------------------------------------
// IN_MODE
//--------------------------------------------------------------
#define IN_MODE_1920X1080                       1
#define IN_MODE_1280X1024                       2
#define IN_MODE_1280X720                        3
#define IN_MODE_128X64                          4
#define IN_MODE_1280X720_30HZ                   5
#define IN_MODE_OV_128X64                       6

//--------------------------------------------------------------
// FRC_MODE
//--------------------------------------------------------------
#define FRC_MODE_OFF                            0
#define FRC_MODE_1920X1080                      1
#define FRC_MODE_1920X1080_25HZ                 2               // 2376x1250(1920x1080) 25 Test
#define FRC_MODE_1280X1024                      3
#define FRC_MODE_1280X720_60HZ                  4
#define FRC_MODE_1280X720_30HZ                  5               // 60 TO 30 Test
#define FRC_MODE_128X64                         6
#define FRC_MODE_BYPASS                         7
#define FRC_MODE_OV_128X64                      8

//--------------------------------------------------------------
// CVBS_MODE
//--------------------------------------------------------------
#define CVBS_MODE_OFF                           0x000
#define CVBS_MODE_720H                          0x001
#define CVBS_MODE_960H                          0x002
#define CVBS_MODE_1200H                         0x004
#define CVBS_MODE_1280H                         0x008
#define CVBS_MODE_1440H                         0x010
#define CVBS_MODE_1920H                         0x020
#define CVBS_MODE_BYPASS                        0x040
#define CVBS_MODE_PAL                           0x100
#define CVBS_MODE_COMET                         0x200
#define CVBS_MODE_QUAD                          0x400
#define CVBS_MODE_TESTH                         0x080
#define CVBS_MODE_TESTV                         0x800

//--------------------------------------------------------------
// AHD_MODE
//--------------------------------------------------------------
#define AHD_MODE_OFF                            0
#define AHD_MODE_ON                             1   // 2M 30P or 1.3M 60P
//#define AHD_MODE_1M                             1
//#define AHD_MODE_2M                             2

//--------------------------------------------------------------
// DIGITAL MODE
//--------------------------------------------------------------
#define DIGITAL_MODE_OFF                        0
#define DIGITAL_MODE_BT1120_DEMULTIPLEX         1
#define DIGITAL_MODE_BT1120_MULTIPLEX           2
#define DIGITAL_MODE_BT656                      3

//--------------------------------------------------------------
// WDR mode option
//--------------------------------------------------------------
#define WDR_OFF_SET                             0x00
#define WDR_NORMAL_SET                          0x01
#define WDR_DOL2_SET                            0x02
#define WDR_DOL3_SET                            0x03
#define WDR_OV10640_SET                         0x04
#define WDR_DECOMP_SET                          0x08

//--------------------------------------------------------------
// LDC mode option
//--------------------------------------------------------------
#define LDC_OFF_SET                             0x00
#define LDC_ON_SET                              0x01
#define LDC_ON_ALL_FUNC                         0x02

//--------------------------------------------------------------
// OSG mode option
//--------------------------------------------------------------
#define OSG_OFF_SET                             0x00
#define OSG_ON_SET                              0x01
#define AXI_OFF_SET                             0x00
#define AXI_ON_SET                              0x01

//--------------------------------------------------------------
// LVDS_DECODER
//--------------------------------------------------------------
#define LVDS_10BIT_SEL                          1

//--------------------------------------------------------------
// sensor resolution for IIF FP_H/VACT size
//--------------------------------------------------------------
#define SR_1920X1080_VB_OB                     0
#define SR_1920X1080_V_OB                      0
#define SR_1920X1080_VB_TR                     8
#define SR_1920X1080_VB_ACT                    6
#define SR_1920X1080_HB_OB                     8
#define SR_1920X1080_H_OB                      20
#define SR_1920X1080_HB_TR                     36
#define SR_1920X1080_HB_ACT                    12

#define SR_1280X1024_VB_OB                     0
#define SR_1280X1024_V_OB                      0
#define SR_1280X1024_VB_TR                     5
#define SR_1280X1024_VB_ACT                    28
#define SR_1280X1024_HB_OB                     0
#define SR_1280X1024_H_OB                      0
#define SR_1280X1024_HB_TR                     8
#define SR_1280X1024_HB_ACT                    16

#define SR_IMX224_1280X720_VB_OB               3
#define SR_IMX224_1280X720_V_OB                4
#define SR_IMX224_1280X720_VB_TR               0
#define SR_IMX224_1280X720_VB_ACT              3
#define SR_IMX224_1280X720_HB_OB               4
#define SR_IMX224_1280X720_H_OB                0
#define SR_IMX224_1280X720_HB_TR               0
#define SR_IMX224_1280X720_HB_ACT              26

#define SR_OV10640_1280X720_VB_OB              0
#define SR_OV10640_1280X720_V_OB               0
#define SR_OV10640_1280X720_VB_TR              0
#define SR_OV10640_1280X720_VB_ACT             0
#define SR_OV10640_1280X720_HB_OB              0
#define SR_OV10640_1280X720_H_OB               0
#define SR_OV10640_1280X720_HB_TR              0
#define SR_OV10640_1280X720_HB_ACT             0

#define SR_TEST_128X64_VB_OB                   0
#define SR_TEST_128X64_V_OB                    0
#define SR_TEST_128X64_VB_TR                   9
#define SR_TEST_128X64_VB_ACT                  10
#define SR_TEST_128X64_HB_OB                   10
#define SR_TEST_128X64_H_OB                    10
#define SR_TEST_128X64_HB_TR                   0
#define SR_TEST_128X64_HB_ACT                  10

#define SR_TEST_OV_128X64_VB_OB                0
#define SR_TEST_OV_128X64_V_OB                 0
#define SR_TEST_OV_128X64_VB_TR                9
#define SR_TEST_OV_128X64_VB_ACT               10
#define SR_TEST_OV_128X64_HB_OB                30
#define SR_TEST_OV_128X64_H_OB                 30
#define SR_TEST_OV_128X64_HB_TR                0
#define SR_TEST_OV_128X64_HB_ACT               30

//--------------------------------------------------------------
// input resolution
//--------------------------------------------------------------
#define IN_1920X1080_VBLK                       45
#define IN_1920X1080_VACT                       1080
#define IN_1920X1080_HBLK                       272
#define IN_1920X1080_HACT                       1928

#define IN_1280X1024_VBLK                       68
#define IN_1280X1024_VACT                       1024
#define IN_1280X1024_HBLK                       370
#define IN_1280X1024_HACT                       1280

#define IN_1280X720_VBLK                        30
#define IN_1280X720_VACT                        720
#define IN_1280X720_HBLK                        362
#define IN_1280X720_HACT                        1288

#define IN_1280X720_30HZ_VBLK                   30
#define IN_1280X720_30HZ_VACT                   720
#define IN_1280X720_30HZ_HBLK                   2012
#define IN_1280X720_30HZ_HACT                   1288

#define IN_OV10640_HBLK                         1086
#define IN_OV10640_HACT                         3864

#define IN_128X64_VBLK                          46
#define IN_128X64_VACT                          64
#define IN_128X64_HBLK                          147
#define IN_128X64_HACT                          128

#define IN_128X64_OV_VBLK                       46
#define IN_128X64_OV_VACT                       64
#define IN_128X64_OV_HBLK                       216
#define IN_128X64_OV_HACT                       384

//--------------------------------------------------------------
// FRC resolution
//--------------------------------------------------------------
#define FRC_1920X1080_VBLK                      45
#define FRC_1920X1080_VACT                      1080
#define FRC_1920X1080_HBLK                      272
#define FRC_1920X1080_HACT                      1928

#define FRC_1920X1080_25HZ_VBLK                 45
#define FRC_1920X1080_25HZ_VACT                 1080
#define FRC_1920X1080_25HZ_HBLK                 720
#define FRC_1920X1080_25HZ_HACT                 1920

#define FRC_1280X1024_VBLK                      68
#define FRC_1280X1024_VACT                      1024
#define FRC_1280X1024_HBLK                      370
#define FRC_1280X1024_HACT                      1280

#define FRC_1280X720_60HZ_VBLK                  30
#define FRC_1280X720_60HZ_VACT                  720
#define FRC_1280X720_60HZ_HBLK                  362
#define FRC_1280X720_60HZ_HACT                  1288

#define FRC_1280X720_30HZ_VBLK                  30
#define FRC_1280X720_30HZ_VACT                  720
#define FRC_1280X720_30HZ_HBLK                  2012
#define FRC_1280X720_30HZ_HACT                  1288

#define FRC_128X64_VBLK                         46
#define FRC_128X64_VACT                         64
#define FRC_128X64_HBLK                         72
#define FRC_128X64_HACT                         128

#define FRC_128X64_OV_VBLK                      46
#define FRC_128X64_OV_VACT                      64
#define FRC_128X64_OV_HBLK                      472
#define FRC_128X64_OV_HACT                      128

//--------------------------------------------------------------
// CVBS resolution
//--------------------------------------------------------------
#define CVBS_NT_VBLK1                           20
#define CVBS_NT_VBLK2                           19
#define CVBS_NT_VACT                            486

#define CVBS_PAL_VBLK1                          24
#define CVBS_PAL_VBLK2                          25
#define CVBS_PAL_VACT                           576

#define CVBS_720NT_HBLK                         138
#define CVBS_720PAL_HBLK                        144
#define CVBS_720_HACT                           720

#define CVBS_960NT_HBLK                         184
#define CVBS_960PAL_HBLK                        192
#define CVBS_960_HACT                           960

#define CVBS_1200NT_HBLK                        230
#define CVBS_1200_HACT                          1200

#define CVBS_1280PAL_HBLK                       256
#define CVBS_1280_HACT                          1280

#define CVBS_1440NT_HBLK                        276
#define CVBS_1440PAL_HBLK                       288
#define CVBS_1440_HACT                          1440

#define CVBS_1920NT_HBLK                        368
#define CVBS_1920PAL_HBLK                       384
#define CVBS_1920_HACT                          1920

#define CVBS_128X64_OV_VBLK                     23
#define CVBS_128X64_OV_VACT                     64
#define CVBS_128X64_OV_HBLK                     472
#define CVBS_128X64_OV_HACT                     128

#endif
