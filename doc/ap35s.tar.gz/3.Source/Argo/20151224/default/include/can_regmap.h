#include "../config/CR4_TopRegMap.h"

/*===================================================*/
/* base address                                      */
/*===================================================*/
#define CAN_BASE                APACHE_CUSTOM_1
#define CAN_BASE0               (CAN_BASE+0x00000000)
#define CAN_BASE1               (CAN_BASE+0x00010000)
