#!/bin/bash
#/******************************************************************************
# *                                                                            *
# * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
# *                                                                            *
# ******************************************************************************/


###################
# RVDS Env
###################
export ARMLMD_LICENSE_FILE=27000@192.168.0.215;
source /tools/ARM/RVDS4.1/RVDS41env.posh

###################
# GCC Env
###################
source /tools/sourcery/2012.03.sh

make SIMULATION=1 clean all

echo "==================================="
echo "Build Result=$?"
echo "==================================="
