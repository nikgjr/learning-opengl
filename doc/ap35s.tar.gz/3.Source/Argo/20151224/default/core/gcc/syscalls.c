
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
//#include <reent.h>

#include <sys/config.h>
#include <sys/unistd.h>

struct stat;

extern int  __HEAP_START;
extern unsigned int __base_of_heap__;
extern unsigned int __end_of_heap__;

caddr_t heap_ptr = NULL;

caddr_t _sbrk(int incr)
{
#if 0
	static unsigned char *heap = NULL;
	unsigned char *prev_heap;

	if (heap == NULL)
	{
		heap = (unsigned char *) &__HEAP_START;
	}
	prev_heap = heap;
	/* check removed to show basic approach */

	heap += incr;

	return (caddr_t) prev_heap;
#endif

#if 0
	static unsigned char *heap_end;
	unsigned char *prev_heap_end;

	/* initialize */
	if (heap_end == 0)
		heap_end = &__end_of_head__;

	prev_heap_end = heap_end;

	if (heap_end + incr - heap > HEAPSIZE)
	{
		/* heap overflow—announce on stderr */
		write(2, "Heap overflow!\n", 15);
		abort();
	}

	heap_end += incr;

	return (caddr_t) prev_heap_end;
#endif

	/*
	* sbrk -- changes heap size size. Get nbytes more
	* RAM. We just increment a pointer in what’s
	* left of memory on the board.
	*/
	caddr_t base;
	caddr_t start = (caddr_t) &__base_of_heap__;
	caddr_t end = (caddr_t) &__end_of_heap__;
	if (heap_ptr == NULL)
	{
		heap_ptr = start;
	}

	if ((heap_ptr+incr) <= end)
	{
		base = heap_ptr;
		heap_ptr += incr;
		return (base);
	}
	else
	{
		errno = ENOMEM;
		return NULL;
	}
}

/*
_READ_WRITE_RETURN_TYPE _EXFNPTR(_read, (struct _reent *, _PTR, char *, int));
_READ_WRITE_RETURN_TYPE _EXFNPTR(_write, (struct _reent *, _PTR, const char *, int));
fpos_t _EXFNPTR(_seek, (struct _reent *, _PTR, _fpos_t, int));
int _EXFNPTR(_close, (struct _reent *, _PTR));
*/

/*

_open_r		A reentrant version of open. It takes a pointer to the global data block, which holds errno.
	int _open_r(void *reent, const char *file, int flags, int mode);

_close_r	A reentrant version of close. It takes a pointer to the global data block, which holds errno.
	int _close_r(void *reent, int fd);


_lseek_r	A reentrant version of lseek. It takes a pointer to the global data block, which holds errno.
	off_t _lseek_r(void *reent, int fd, off_t pos, int whence);


_read_r		A reentrant version of read. It takes a pointer to the global data block, which holds errno.
	long _read_r(void *reent, int fd, void *buf, size_t cnt);


_write_r	A reentrant version of write. It takes a pointer to the global data block, which holds errno.
	long _write_r(void *reent, int fd, const void *buf, size_t cnt);


_fork_r		A reentrant version of fork. It takes a pointer to the global data block, which holds errno.
	int _fork_r(void *reent);

_wait_r		A reentrant version of wait. It takes a pointer to the global data block, which holds errno.
	int _wait_r(void *reent, int *status);


_stat_r		A reentrant version of stat. It takes a pointer to the global data block, which holds errno.
	int _stat_r(void *reent, const char *file, struct stat *pstat);


_fstat_r	A reentrant version of fstat. It takes a pointer to the global data block, which holds errno.
	int _fstat_r(void *reent, int fd, struct stat *pstat);


_link_r		A reentrant version of link. It takes a pointer to the global data block, which holds errno.
	int _link_r(void *reent, const char *old, const char *new);


_unlink_r	A reentrant version of unlink. It takes a pointer to the global data block, which holds errno.
	int _unlink_r(void *reent, const char *file);


_sbrk_r	A reentrant version of sbrk. It takes a pointer to the global data block, which holds errno.
	char *_sbrk_r(void *reent, size_t incr);


_READ_WRITE_RETURN_TYPE _read(int __fd, void *__buf, size_t __nbyte )
{
	return 0;
}
_READ_WRITE_RETURN_TYPE _write(int __fd, const void *__buf, size_t __nbyte )
{
	return 0;
}
 */

#if 1
int _open_r(void *reent, const char *file, int flags, int mode)
{
	return 0;
}
int _close_r(void *reent, int fd)
{
	return 0;
}
off_t _lseek_r(void *reent, int fd, off_t pos, int whence)
{
	return 0;
}
long _read_r(void *reent, int fd, void *buf, size_t cnt)
{
	return 0;
}
long _write_r(void *reent, int fd, const void *buf, size_t cnt)
{
	return 0;
}
int _fork_r(void *reent)
{
	return 0;
}
int _wait_r(void *reent, int *status)
{
	return 0;
}
int _stat_r(void *reent, const char *file, struct stat *pstat)
{
	return 0;
}
int _fstat_r(void *reent, int fd, struct stat *pstat)
{
	return 0;
}
int _link_r(void *reent, const char *old, const char *new)
{
	return 0;
}
int _unlink_r(void *reent, const char *file)
{
	return 0;
}
int _isatty_r(void *reent, int id)
{
	return 0;
}
#else

int _close_r (struct _reent *, int)
int _execve_r (struct _reent *, const char *, char *const *, char *const *)
int _fcntl_r (struct _reent *, int, int, int)
int _fork_r (struct _reent *)
int _fstat_r (struct _reent *, int, struct stat *)
int _getpid_r (struct _reent *)
int _isatty_r (struct _reent *, int)
int _kill_r (struct _reent *, int, int)
int _link_r (struct _reent *, const char *, const char *)
_off_t _lseek_r (struct _reent *, int, _off_t, int)
int _mkdir_r (struct _reent *, const char *, int)
int _open_r (struct _reent *, const char *, int, int)
_ssize_t _read_r (struct _reent *, int, void *, size_t)
int _rename_r (struct _reent *, const char *, const char *)
void *_sbrk_r (struct _reent *, ptrdiff_t)
int _stat_r (struct _reent *, const char *, struct stat *)
_CLOCK_T_ _times_r (struct _reent *, struct tms *)
int _unlink_r (struct _reent *, const char *)
int _wait_r (struct _reent *, int *)
_ssize_t _write_r (struct _reent *, int, const void *, size_t)

#endif

