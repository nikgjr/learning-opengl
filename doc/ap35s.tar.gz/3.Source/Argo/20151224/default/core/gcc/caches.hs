@-------------------------------------------------------------------------------
@ MACRO:        DISABLE_CACHES
@
@ Purpose:      Disable instruction and data caches
@
@ Parameters:   x
@-------------------------------------------------------------------------------
                
.macro	DISABLE_CACHES
                MRC     p15, 0, r0, c1, c0, 0       @ Read SCTLR into r0
                BIC     r0, r0, #0x00004            @ disable data cache
                BIC     r0, r0, #0x01000            @ disable instruction cache
                MCR     p15, 0, r0, c1, c0, 0
		.endm

@-------------------------------------------------------------------------------
@ MACRO:        ENABLE_CACHES
@
@ Purpose:      Enable instruction and data caches
@
@ Parameters:   x
@-------------------------------------------------------------------------------
                
.macro	ENABLE_CACHES
                MRC     p15, 0, r0, c1, c0, 0       @ Read System Control Register configuration data
                ORR     r0, r0, #0x0004             @ Set C bit
                ORR     r0, r0, #0x1000             @ Set I bit
                MCR     p15, 0, r0, c1, c0, 0       @ Write System Control Register configuration data
		.endm
