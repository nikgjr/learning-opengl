#!/bin/sh

OUTPUT=./output/rpsv2000t
TARGET=~rtl/APACHE3.5/bit/rom_code

echo '============================================'
echo 'Release ROM Code !!!!'
echo '============================================'
cp -a ${OUTPUT}/CR4_Base*.coe ${TARGET}
cp -a ${OUTPUT}/CR4_Base*.asm ${TARGET}
cp -a ${OUTPUT}/CR4_Base.bin  ${TARGET}


