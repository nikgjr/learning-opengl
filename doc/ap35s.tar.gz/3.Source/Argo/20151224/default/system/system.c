/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include "../config/CR4_TopRegMap.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"

#include "system.h"

#include "../drivers/uart_pl011.h"
#include "../drivers/gicdrv.h"
#include "../drivers/ddr.h"
#include "../include/ansi.h"
//#include "../drivers/gpio.h"
#include "../task/isp/isp_mode.h"

/****************************************************************************
*       Global Variable
*****************************************************************************/
u32 gDelayCnt = SYS_DELAY_CNT;
u32 gStep = 0;
u32 gErrCnt = 0;

u32 dmaOffset = 0;
u32 gRemap_Start = 0;
u32 gRemap_End = 0;
u32 gRemap_Offset = 0;
u32 gRemap_Size = 0;

/**
 * FPGA board에서 UART block 초기화 함수
 */
void System_UartInit(void)
{
#if IS_BOARD()
	tPUART_PARAM param;
	u32 system_clock;

	system_clock = rSYSCON_SYSTEM_CLOCK;
	if(system_clock)
	{
		param.uartClk = system_clock*1000;
	}
	else
	{
		param.uartClk = SYSTEM_CLK;
	}

	param.baudRate = 115200;
	param.sps = LCR_SPS_DIS;
	param.wlen = LCR_WLEN_8BIT;
	param.fen = LCR_FIFO_EN;
	param.stp2 = LCR_STP2_DIS;
	param.eps = LCR_EPS_DIS;
	param.pen = LCR_PARITY_DIS;
	param.brk = 0;

	uart_init(UART0, &param);

#endif
}

#if 0
void SYS_GPIOInit(void)
{
	// GPIO OUT=0 IN=1


	// GPIO_00	OUT		LCDDISP
	// GPIO_01	OUT		EN_PWRLCD
	// GPIO_02	IN		LCD_DECTION
	// GPIO_03	OUT		LCDPWM

	// GPIO_04	INT		ZB_IRQ0
	// GPIO_05	INT		TS_INT0

	// +---------+---------+---------+---------+---------+---------+---------+---------+
	// | GPIO_07 | GPIO_06 | GPIO_05 | GPIO_04 | GPIO_03 | GPIO_02 | GPIO_01 | GPIO_00 |
	// +---------+---------+---------+---------+---------+---------+---------+---------+
	// |    0    |    0    |  1 (I1) |  1 (I0) |    0    |    1    |    0    |    0    |
	// +---------+---------+---------+---------+---------+---------+---------+---------+

	// +---------+---------+---------+---------+---------+---------+---------+---------+
	// | GPIO_15 | GPIO_14 | GPIO_13 | GPIO_12 | GPIO_11 | GPIO_10 | GPIO_09 | GPIO_08 |
	// +---------+---------+---------+---------+---------+---------+---------+---------+
	// |    0    |    0    |    0    |    0    |    0    |    0    |   10    |    1    |
	// +---------+---------+---------+---------+---------+---------+---------+---------+

	tREG_GPIO *rGpio=GPIO0;
	u16 val=0x3b;

	rGpio->DIR = 0x34;
	M_GPIO_SET_VAL(rGpio, val);

	rGpio=GPIO1;
	rGpio->DIR = 0x03;
	M_GPIO_SET_VAL(rGpio, 0x10);
}
#endif

void SYS_MemInit(void)
{
	u32 data;
	int loop=0x10000;

	// NEXTCHIP 32 Bit Memory
	reg_write(DDR_ADDR_SIZE, 0xa0);
	reg_write(DDR_LMR_EXT_STD, 0x00400022);

	reg_write(DDR_PHY_CONFIG, DDR_PHY_INIT);


	while(loop--)
	{
		data = reg_read(DDR_PHY_CONFIG);
		if(data & DDR_PHY_COMPLETE) break;
	}

	tdk_printf("DDR Init : %s\n", loop<=0 ? ANSI_FAIL:ANSI_PASS);

	tdk_dump32(DDRC_BASE, 32, NULL);
	data = reg_read(DDR_PHY_CONFIG);
	tdk_printf("DDR_PHY_CONFIG = 0x%08x\n", data);
}

/**
 * 시스템 초기화 함수
 */
void SYS_Init(void)
{
    reg_write(rPLL0_DIV, PLL0_DIV);
    reg_write(rPLL1_DIV, PLL1_DIV);
    reg_write(rPLL2_DIV, PLL2_DIV);
    reg_write(rPLL_BWADJ, PLL_BWADJ);
    reg_write(rPLL_EN, PLL_EN);

    while(reg_read(rPLL_STABLE) != 0x7) ;

    /* PLL settings & Initialize clocks */
    reg_write(rCLK_PLL_SEL, PLL_SEL);
    reg_write(rCLK_SYS_SEL, SYS_SEL);
    reg_write(rCLK_SYS_DIV, SYS_DIV);
    reg_write(rCLK_ISP_SEL, ISP_SEL);
    reg_write(rCLK_ISP_DIV, ISP_DIV);
    reg_write(rISP_MODE, ISP_MODE);

    __SIM_STEP(0x400 | ISP_SIM_MODE);

    /* Enable core interrupt */
	__SIM_STEP(0x300);
	GIC_InitInterrupts();
	__SIM_DEBUG(0x301);
#if IS_BOARD()
	System_UartInit();
	__SIM_DEBUG(0x302);
//	System_GPIOInit();
#endif

//	SYS_MemInit();
	__SIM_DEBUG(0x303);

	__SIM_DEBUG(0x3ff);

	if(rSYSCON_REMAP_ENABLE)
	{
		gRemap_Start = rSYSCON_REMAP_START;
		gRemap_End = rSYSCON_REMAP_END;
		gRemap_Offset = rSYSCON_REMAP_OFFSET;
		gRemap_Size = gRemap_Start+1;
	}
  	rSYSCON_RESET = 0xfffffff0;
    SYS_Delay (1);
  	rSYSCON_RESET = 0x00000000;
//	rSYSCON_RESET = 0xffffffff;

    reg_write(rISP_MODE, reg_read(rISP_MODE) | (0x1<<31)); // PM RSTN release
}

/**
 * Delay 함수
 * @param	usec	delay count
 */
void SYS_Delay(u32 usec)
{
    u32 i;

    usec /= 10; // 10us boundary
    while(usec--)
        for(i=0; i<gDelayCnt; i++);
}

void SYS_DelayTick(u32 tick)
{
	u32 start = rSYSCON_TICK_COUNTER;
	u32 elapsed;

	while(1)
	{
		elapsed = rSYSCON_TICK_COUNTER - start;
		if(elapsed > tick)
		{
			break;
		}
	}
}

void SYS_SimInfo(u32 step, char *message)
{
	gStep = step;
	__SIM_STEP(gStep);

	tdk_printf("====== step=%08x, %-30s ============\n", gStep, message);
}

void SYS_RemapEnable(u32 start, u32 end, u32 offset)
{
	rSYSCON_REMAP_START = start;
	rSYSCON_REMAP_END = end;
	rSYSCON_REMAP_OFFSET = offset;
	rSYSCON_REMAP_ENABLE = 1;

/*
    gRemap_Start = rSYSCON_REMAP_START;
    gRemap_End = rSYSCON_REMAP_END;
    gRemap_Offset = rSYSCON_REMAP_OFFSET;
    gRemap_Size = gRemap_End-gRemap_Start+1;
  */

//	rSYSCON_RESET = 0;
	rSYSCON_RESET = SYSCON_RESET_R4;
	while(1);
}

u32 SYS_GetRemapBaseAddress()
{
	return gRemap_Start+gRemap_Offset;
}

u32 SYS_GetNoneCacheAddress(void)
{
	unsigned addr = CODE_SIZE;

	// DMA or Encoder DMA can't access ROM Area
#if 1
	if(SYS_GetRemapBaseAddress()==0x0)
	{
//		addr = 0x04000000+CODE_SIZE;
		addr = 0x04000000+0x00018000;
	}
	else
	{
//		addr = CODE_SIZE;
		addr = 0x00018000;
	}
#endif

	return addr;
}

u32 SYS_GetNoneCacheSize(void)
{
	int size = CODE_SIZE;
	return size;
}

int IF_SIZE = 4*KB;

u32 SYS_GetNFI_H2S_Address(void)
{
	return SYS_GetNoneCacheAddress()+SYS_GetNoneCacheSize()-IF_SIZE;
}

u32 SYS_GetNFI_H2S_Size(void)
{
	return IF_SIZE/2;
}

u32 SYS_GetNFI_S2H_Address(void)
{
	return SYS_GetNoneCacheAddress()+SYS_GetNoneCacheSize()-IF_SIZE/2;
}

u32 SYS_GetNFI_S2H_Size(void)
{
	return IF_SIZE/2;
}

u32 SYS_Virtual2Physical(unsigned addr)
{
	return addr + gRemap_Offset;
}

u32 SYS_Physical2Virtual(unsigned addr)
{
	return addr - gRemap_Offset;
}

int sys_printf(const char *fmt, ...)
{
	va_list args;
	int len;
	char buffer[512];

	va_start(args, fmt);
	len = vsnprintf(buffer, sizeof(buffer), fmt, args);
	va_end(args);

	memcpy((void*)SIM_CMD_BUFFER, buffer, len);
//	rDEBUG_COMMAND_BUFFER[len+0] = NULL;
//	rDEBUG_COMMAND_BUFFER[len+1] = NULL;
//	rDEBUG_COMMAND_BUFFER[len+2] = NULL;
//	rDEBUG_COMMAND_BUFFER[len+3] = NULL;
//	rDEBUG_COMMAND_BUFFER[len+4] = NULL;
	rDEBUG_COMMAND = 1;
	return len;
}

int sys_puts(const char *message)
{
	int len = strlen(message);
	memcpy((void*)SIM_CMD_BUFFER, message, len);
	rDEBUG_COMMAND_BUFFER[len+0] = '\n';
//	rDEBUG_COMMAND_BUFFER[len+1] = NULL;
//	rDEBUG_COMMAND_BUFFER[len+2] = NULL;
//	rDEBUG_COMMAND_BUFFER[len+3] = NULL;
//	rDEBUG_COMMAND_BUFFER[len+4] = NULL;
	rDEBUG_COMMAND = 1;
	return 0;
}
