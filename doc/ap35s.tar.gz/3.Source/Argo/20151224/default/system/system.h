/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#ifndef __SYSTEM_H__
#define __SYSTEM_H__

#include "../tdk/tdk_types.h"
#include "../config/CR4_TopRegMap.h"

typedef volatile u32   _REG_;
typedef volatile u32   _ADRS_;

extern u32 dmaOffset;

/****************************************************************************
*       Definitions
*****************************************************************************/
#if __SYSCLK_50M
    #define SYS_DELAY_CNT   19 // 10us  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #define SYS_DELAY_UNIT  10 // us    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #define SYS_CLK         33000000
#elif __SYSCLK_80M
    #define SYS_DELAY_CNT   60 // 10us
    #define SYS_DELAY_UNIT  10 // us
    #define SYS_CLK         80000000
#endif

#define HCLK                SYS_CLK
#define PCLK                (SYS_CLK/8)

#define CLK_MS_DIV          1000
#define CLK_100US_DIV       10000
#define CLK_10US_DIV        100000

#define HI                  1
#define LO                  0
#define EN                  1
#define DIS                 0

#define DEC_8               0
#define DEC_16              1
#define DEC_32              2

/****************************************************************************
*       Macros
*****************************************************************************/
#define M_SYS_NOUSING(_var_)                (_var_ = _var_)
#define M_SYS_MS2CNT(_clk_, _div_, _ms_)    ((_clk_ / CLK_MS_DIV / _div_) * _ms_)
#define M_SYS_US2CNT(_clk_, _div_, _us_)    ((_clk_ / CLK_10US_DIV / _div_) * (_us_/10))

#define M_LED_ON(_x_)                       (*(_REG_ *)(0xF00000E0) &= ~(1<<_x_))
#define M_LED_OFF(_x_)                      (*(_REG_ *)(0xF00000E0) |= (1<<_x_))
#define M_LED_TOG(_x_)                      (*(_REG_ *)(0xF00000E0) ^= (1<<_x_))

#define SIM_DEBUG_STATUS					0
#define SIM_DEBUG_STEP						1
#define SIM_DEBUG_RESPONSE					2
#define SIM_DEBUG_WADDR						3
#define SIM_DEBUG_WDATA						4
#define SIM_DEBUG_RADDR						5
#define SIM_DEBUG_RDATA						6

#define SIM_DEBUG_IRQ						11
#define SIM_DEBUG_TICK_COUNT				12
#define SIM_DEBUG_IRQ_COUNT					13
#define SIM_DEBUG_RESET_COUNT				14
#define SIM_DEBUG_TESTID					15

//#if 0
#if defined(BUILD_R4) || defined(BUILD_VERSATILE_R4) || defined(BUILD_A5)
#define __SIM_PASS()						rDEBUG_STATUS = 0x0
#define __SIM_FAIL(ret)						rDEBUG_STATUS = ((u32)(ret))
#define __SIM_END_OK()						rDEBUG_STATUS = 0x0
#define __SIM_END_FAIL(_x_)					rDEBUG_STATUS = ((u32)(_x_))
#define __SIM_STEP(_x_)						rDEBUG_STEP = (_x_)
#define __SIM_DBG(_x_)						rDEBUG_STEP = (_x_)
#define __SIM_DEBUG(_x_)					rDEBUG_STEP = (_x_)
#define __SIM_RESP(_x_)						rDEBUG_RESPONS = (_x_)
#define __SIM_WRITE(addr,data)				rDEBUG_WADDR=(addr),rDEBUG_WDATA=(data)
#define __SIM_READ(addr,data)				rDEBUG_RADDR=(addr),rDEBUG_RDATA=(data)
#define __SIM_IRQ(_x_)						rDEBUG_IRQ_COUNT
#define __SIM_DEBUG_REG(id,value)			(*(_REG_ *)(SIM_REG_BASE+((id)<<2)) = (unsigned int)(value))
#define __SIM_READ_REG(id)					(*(_REG_ *)(SIM_REG_BASE+((id)<<2)))
#else
#define __SIM_PASS()
#define __SIM_FAIL(ret)
#define __SIM_END_OK()
#define __SIM_END_FAIL(_x_)
#define __SIM_STEP(_x_)
#define __SIM_DBG(_x_)
#define __SIM_DEBUG(_x_)
#define __SIM_RESP(_x_)
#define __SIM_WRITE(addr,data)
#define __SIM_READ(addr,data)
#define __SIM_IRQ(_x_)
#define __SIM_DEBUG_REG(id,value)
#define __SIM_READ_REG(id)					0x0
#endif


#define __SIM_STR8(x)
#define __SIM_STR4(x)

#define M_WRITE_MEM(_addr_, _data_)         (*(_ADRS_ *)(_addr_) = _data_)
#define M_READ_MEM(_addr_)                  (*(_ADRS_ *)(_addr_))

#define M_WRITE_REG(_addr_, _data_)         (*(_REG_ *)(_addr_) = _data_)
#define M_READ_REG(_addr_)                  (*(_REG_ *)(_addr_))

#define M_32_SWAP(a) {                            \
          u32 _tmp;                          	  \
          _tmp = a;                               \
          ((UINT8 *)&a)[0] = ((UINT8 *)&_tmp)[3]; \
          ((UINT8 *)&a)[1] = ((UINT8 *)&_tmp)[2]; \
          ((UINT8 *)&a)[2] = ((UINT8 *)&_tmp)[1]; \
          ((UINT8 *)&a)[3] = ((UINT8 *)&_tmp)[0]; \
        }

/****************************************************************************
*       SYSTEM Initialize
*****************************************************************************/

/****************************************************************************
*       ISP simulation mode
*****************************************************************************/
#define DEFAULT                0
#define AHD_1280x720_30p       1
#define AHD_1280x720_25p       2
#define AHD_1280x720_60p       3
#define AHD_1280x720_50p       4
#define HDCVI_1280x720_30p     5
#define HDCVI_1280x720_25p     6
#define HDCVI_1280x720_60p     7
#define HDCVI_1280x720_50p     8
#define HDTVI_1280x720_30p     9
#define HDTVI_1280x720_25p     10
#define HDTVI_1280x720_60p     11
#define HDTVI_1280x720_50p     12
#define CVBS_NTSC_1280h        13
#define CVBS_NTSC_960h         14
#define CVBS_NTSC_720h         15
#define CVBS_PAL_1280h         16
#define CVBS_PAL_960h          17
#define CVBS_PAL_720h          18

#define PARALLEL               0

#define ISP_SIM_MODE DEFAULT
// #define ISP_SIM_MODE AHD_1280x720_30p
#define ISP_SENSOR_MODE PARALLEL

/****************************************************************************
*       Enumeration Definitions
*****************************************************************************/

/****************************************************************************
*       Structure Definitions
*****************************************************************************/

/****************************************************************************
*       Global Variable Definitions
*****************************************************************************/
extern u32 gStep;
extern u32 gErrCnt;



/****************************************************************************
*       Global Function Definitions
*****************************************************************************/
void SYS_GPIOInit(void);
void SYS_MemInit(void);
void SYS_Init(void);
void SYS_Delay(u32 usec);
void SYS_DelayTick(u32 tick);
void SYS_SimInfo(u32 step, char *message);

void SYS_DisplayInit(void);

// 나중에 반드시 정리가 필요한 사항입니다.
// 임시 코드
void SYS_RemapEnable(u32 start, u32 end, u32 offset);
u32 SYS_GetRemapSize(void);
u32 SYS_GetRemapBaseAddress(void);
u32 SYS_GetNoneCacheSize(void);
u32 SYS_GetNoneCacheAddress(void);
u32 SYS_GetNFI_H2S_Address(void);
u32 SYS_GetNFI_H2S_Size(void);
u32 SYS_GetNFI_S2H_Address(void);
u32 SYS_GetNFI_S2H_Size(void);
u32 SYS_GetNIH2SBufferAddress(void);
u32 SYS_GetNIS2HBufferAddress(void);
u32 SYS_GetNIBufferSize(void);
u32 SYS_Virtual2Physical(unsigned addr);
u32 SYS_Physical2Virtual(unsigned addr);

int sys_printf(const char *fmt, ...);
int sys_puts(const char *message);

#endif /* __SYSTEM_H__ */

