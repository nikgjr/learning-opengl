/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#include "semaphore.h"
#include "../tdk/tdk.h"

/****************************************************************************
*       Global Variable
*****************************************************************************/
SEMAPHORE sem0;
SEMAPHORE sem1;

/**
 * Semaphore 초기화 함수
 * @param	*pSem	pointer
 */
void sem_init(SEMAPHORE *pSem)
{
	*pSem=0;
}

/**
 * Semaphore post 함수
 * @param	*pSem	pointer
 */
void sem_post(SEMAPHORE *pSem)
{
	(*pSem)++;
}

/**
 * Semaphore pend 함수
 * @param	*pSem	pointer
 */
int sem_pend(SEMAPHORE *pSem, u32 timeout)
{
	if(timeout==0)
	{
		while (1)
		{
			/* enter critical section */
			if (*pSem)
			{
				(*pSem)--;
				/* exit critical section */
				return 0;
			}
			/* exit critical section */
		}
	}
	else
	{
		while (timeout--)
		{
			tdk_puts("Check Semaphore");
			/* enter critical section */
			if (*pSem)
			{
				(*pSem)--;
				/* exit critical section */
				return 0;
			}
			/* exit critical section */
		}
	}

	return -1;
}

/**
 * Semaphore pend 함수
 * @param	*pSem	pointer
 */
BOOL sem_check_pen(SEMAPHORE *pSem)
{
    if(*pSem)
    {
        (*pSem)--;
        return TRUE;
    }
    else
        return FALSE;
}


