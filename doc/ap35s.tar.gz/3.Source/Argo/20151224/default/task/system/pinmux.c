#include "../tdk/tdk.h"
#include "./tdk/tdk_util.h"
#include "../include/sfr.h"

void pinmux_cis(void)
{
	tdk_printf("PINMUX SENSOR\n");
    reg_write(ADDR_REG_TMUX_SEN_RSTN_O 	, SEN_RSTN_O_REN |REG_HIZ_SEN_RSTN_O | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PCK 	, SEN_PCK_REN    |REG_HIZ_SEN_PCK    | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_CK_O 	, SEN_CK_O_REN   |REG_HIZ_SEN_CK_O   | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PH 		, SEN_PH_REN     |REG_HIZ_SEN_PH     | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PV 		, SEN_PV_REN     |REG_HIZ_SEN_PV     | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PD0 	, SEN_PD0_REN    |REG_HIZ_SEN_PD0    | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PD1 	, SEN_PD1_REN    |REG_HIZ_SEN_PD1    | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PD2 	, SEN_PD2_REN    |REG_HIZ_SEN_PD2    | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PD3 	, SEN_PD3_REN    |REG_HIZ_SEN_PD3    | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PD4 	, SEN_PD4_REN    |REG_HIZ_SEN_PD4    | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PD5 	, SEN_PD5_REN    |REG_HIZ_SEN_PD5    | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PD6 	, SEN_PD6_REN    |REG_HIZ_SEN_PD6    | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PD7 	, SEN_PD7_REN    |REG_HIZ_SEN_PD7    | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PD8 	, SEN_PD8_REN    |REG_HIZ_SEN_PD8    | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PD9 	, SEN_PD9_REN    |REG_HIZ_SEN_PD9    | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PD10 	, SEN_PD10_REN   |REG_HIZ_SEN_PD10   | 0x0);
    reg_write(ADDR_REG_TMUX_SEN_PD11 	, SEN_PD11_REN   |REG_HIZ_SEN_PD11   | 0x0);
}
void pinmux_yc16(void)
{
	tdk_printf("PINMUX YC16\n");
    reg_write(ADDR_REG_TMUX_VOUT_HSYNC 	, VOUT_HSYNC_REN | REG_HIZ_VOUT_HSYNC | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_VSYNC 	, VOUT_VSYNC_REN | REG_HIZ_VOUT_VSYNC | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_HACT 	, VOUT_HACT_REN  | REG_HIZ_VOUT_HACT  | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_B0 	, VOUT_B0_REN    | REG_HIZ_VOUT_B0    | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_B1 	, VOUT_B1_REN    | REG_HIZ_VOUT_B1    | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_B2 	, VOUT_B2_REN    | REG_HIZ_VOUT_B2    | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_B3 	, VOUT_B3_REN    | REG_HIZ_VOUT_B3    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B4 	, VOUT_B4_REN    | REG_HIZ_VOUT_B4    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B5 	, VOUT_B5_REN    | REG_HIZ_VOUT_B5    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B6 	, VOUT_B6_REN    | REG_HIZ_VOUT_B6    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B7 	, VOUT_B7_REN    | REG_HIZ_VOUT_B7    | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_G0_C0 	, VOUT_G0_C0_REN | REG_HIZ_VOUT_G0_C0 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_G1_C1 	, VOUT_G1_C1_REN | REG_HIZ_VOUT_G1_C1 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_G2_C2 	, VOUT_G2_C2_REN | REG_HIZ_VOUT_G2_C2 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_G3_C3 	, VOUT_G3_C3_REN | REG_HIZ_VOUT_G3_C3 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_G4_C4 	, VOUT_G4_C4_REN | REG_HIZ_VOUT_G4_C4 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_G5_C5 	, VOUT_G5_C5_REN | REG_HIZ_VOUT_G5_C5 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_G6_C6 	, VOUT_G6_C6_REN | REG_HIZ_VOUT_G6_C6 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_G7_C7 	, VOUT_G7_C7_REN | REG_HIZ_VOUT_G7_C7 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_R0_Y0 	, VOUT_R0_Y0_REN | REG_HIZ_VOUT_R0_Y0 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_R1_Y1 	, VOUT_R1_Y1_REN | REG_HIZ_VOUT_R1_Y1 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_R2_Y2 	, VOUT_R2_Y2_REN | REG_HIZ_VOUT_R2_Y2 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_R3_Y3 	, VOUT_R3_Y3_REN | REG_HIZ_VOUT_R3_Y3 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_R4_Y4 	, VOUT_R4_Y4_REN | REG_HIZ_VOUT_R4_Y4 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_R5_Y5 	, VOUT_R5_Y5_REN | REG_HIZ_VOUT_R5_Y5 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_R6_Y6 	, VOUT_R6_Y6_REN | REG_HIZ_VOUT_R6_Y6 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_R7_Y7 	, VOUT_R7_Y7_REN | REG_HIZ_VOUT_R7_Y7 | 0x0);

}
void pinmux_bt656(void)
{
	tdk_printf("PINMUX BT656-Like\n");
    reg_write(ADDR_REG_TMUX_VOUT_HSYNC 	,VOUT_HSYNC_REN |  REG_HIZ_VOUT_HSYNC | 0x2);
    reg_write(ADDR_REG_TMUX_VOUT_VSYNC 	,VOUT_VSYNC_REN |  REG_HIZ_VOUT_VSYNC | 0x2);
    reg_write(ADDR_REG_TMUX_VOUT_HACT 	,VOUT_HACT_REN  |  REG_HIZ_VOUT_HACT  | 0x2);
//  reg_write(ADDR_REG_TMUX_VOUT_B0 	,VOUT_B0_REN    |  REG_HIZ_VOUT_B0 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B1 	,VOUT_B1_REN    |  REG_HIZ_VOUT_B1 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B2 	,VOUT_B2_REN    |  REG_HIZ_VOUT_B2 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B3 	,VOUT_B3_REN    |  REG_HIZ_VOUT_B3 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B4 	,VOUT_B4_REN    |  REG_HIZ_VOUT_B4 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B5 	,VOUT_B5_REN    |  REG_HIZ_VOUT_B5 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B6 	,VOUT_B6_REN    |  REG_HIZ_VOUT_B6 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B7 	,VOUT_B7_REN    |  REG_HIZ_VOUT_B7 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G0_C0 	,VOUT_G0_C0_REN |  REG_HIZ_VOUT_G0_C0 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G1_C1 	,VOUT_G1_C1_REN |  REG_HIZ_VOUT_G1_C1 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G2_C2 	,VOUT_G2_C2_REN |  REG_HIZ_VOUT_G2_C2 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G3_C3 	,VOUT_G3_C3_REN |  REG_HIZ_VOUT_G3_C3 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G4_C4 	,VOUT_G4_C4_REN |  REG_HIZ_VOUT_G4_C4 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G5_C5 	,VOUT_G5_C5_REN |  REG_HIZ_VOUT_G5_C5 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G6_C6 	,VOUT_G6_C6_REN |  REG_HIZ_VOUT_G6_C6 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G7_C7 	,VOUT_G7_C7_REN |  REG_HIZ_VOUT_G7_C7 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_R0_Y0 	,VOUT_R0_Y0_REN |  REG_HIZ_VOUT_R0_Y0 | 0x2);
    reg_write(ADDR_REG_TMUX_VOUT_R1_Y1 	,VOUT_R1_Y1_REN |  REG_HIZ_VOUT_R1_Y1 | 0x2);
    reg_write(ADDR_REG_TMUX_VOUT_R2_Y2 	,VOUT_R2_Y2_REN |  REG_HIZ_VOUT_R2_Y2 | 0x2);
    reg_write(ADDR_REG_TMUX_VOUT_R3_Y3 	,VOUT_R3_Y3_REN |  REG_HIZ_VOUT_R3_Y3 | 0x2);
    reg_write(ADDR_REG_TMUX_VOUT_R4_Y4 	,VOUT_R4_Y4_REN |  REG_HIZ_VOUT_R4_Y4 | 0x2);
    reg_write(ADDR_REG_TMUX_VOUT_R5_Y5 	,VOUT_R5_Y5_REN |  REG_HIZ_VOUT_R5_Y5 | 0x2);
    reg_write(ADDR_REG_TMUX_VOUT_R6_Y6 	,VOUT_R6_Y6_REN |  REG_HIZ_VOUT_R6_Y6 | 0x2);
    reg_write(ADDR_REG_TMUX_VOUT_R7_Y7 	,VOUT_R7_Y7_REN |  REG_HIZ_VOUT_R7_Y7 | 0x2);
}
void pinmux_bt1120_10bit(void)
{
	tdk_printf("PINMUX Multiplexed BT1120\n");
    reg_write(ADDR_REG_TMUX_VOUT_HSYNC 	,VOUT_HSYNC_REN | REG_HIZ_VOUT_HSYNC | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_VSYNC 	,VOUT_VSYNC_REN | REG_HIZ_VOUT_VSYNC | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_HACT 	,VOUT_HACT_REN  | REG_HIZ_VOUT_HACT  | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_B0 	,VOUT_B0_REN    | REG_HIZ_VOUT_B0    | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_B1 	,VOUT_B1_REN    | REG_HIZ_VOUT_B1    | 0x3);
//  reg_write(ADDR_REG_TMUX_VOUT_B2 	,VOUT_B2_REN    | REG_HIZ_VOUT_B2    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B3 	,VOUT_B3_REN    | REG_HIZ_VOUT_B3    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B4 	,VOUT_B4_REN    | REG_HIZ_VOUT_B4    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B5 	,VOUT_B5_REN    | REG_HIZ_VOUT_B5    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B6 	,VOUT_B6_REN    | REG_HIZ_VOUT_B6    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B7 	,VOUT_B7_REN    | REG_HIZ_VOUT_B7    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G0_C0 	,VOUT_G0_C0_REN | REG_HIZ_VOUT_G0_C0 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G1_C1 	,VOUT_G1_C1_REN | REG_HIZ_VOUT_G1_C1 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G2_C2 	,VOUT_G2_C2_REN | REG_HIZ_VOUT_G2_C2 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G3_C3 	,VOUT_G3_C3_REN | REG_HIZ_VOUT_G3_C3 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G4_C4 	,VOUT_G4_C4_REN | REG_HIZ_VOUT_G4_C4 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G5_C5 	,VOUT_G5_C5_REN | REG_HIZ_VOUT_G5_C5 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G6_C6 	,VOUT_G6_C6_REN | REG_HIZ_VOUT_G6_C6 | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_G7_C7 	,VOUT_G7_C7_REN | REG_HIZ_VOUT_G7_C7 | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_R0_Y0 	,VOUT_R0_Y0_REN | REG_HIZ_VOUT_R0_Y0 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R1_Y1 	,VOUT_R1_Y1_REN | REG_HIZ_VOUT_R1_Y1 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R2_Y2 	,VOUT_R2_Y2_REN | REG_HIZ_VOUT_R2_Y2 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R3_Y3 	,VOUT_R3_Y3_REN | REG_HIZ_VOUT_R3_Y3 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R4_Y4 	,VOUT_R4_Y4_REN | REG_HIZ_VOUT_R4_Y4 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R5_Y5 	,VOUT_R5_Y5_REN | REG_HIZ_VOUT_R5_Y5 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R6_Y6 	,VOUT_R6_Y6_REN | REG_HIZ_VOUT_R6_Y6 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R7_Y7 	,VOUT_R7_Y7_REN | REG_HIZ_VOUT_R7_Y7 | 0x3);
}
void pinmux_bt1120_20bit(void)
{
	tdk_printf("PINMUX De-Multiplexed BT1120\n");
    reg_write(ADDR_REG_TMUX_VOUT_HSYNC 	,VOUT_HSYNC_REN |  REG_HIZ_VOUT_HSYNC | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_VSYNC 	,VOUT_VSYNC_REN |  REG_HIZ_VOUT_VSYNC | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_HACT 	,VOUT_HACT_REN  |  REG_HIZ_VOUT_HACT  | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_B0 	,VOUT_B0_REN    |  REG_HIZ_VOUT_B0    | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_B1 	,VOUT_B1_REN    |  REG_HIZ_VOUT_B1    | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_B2 	,VOUT_B2_REN    |  REG_HIZ_VOUT_B2    | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_B3 	,VOUT_B3_REN    |  REG_HIZ_VOUT_B3    | 0x3);
//  reg_write(ADDR_REG_TMUX_VOUT_B4 	,VOUT_B4_REN    |  REG_HIZ_VOUT_B4    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B5 	,VOUT_B5_REN    |  REG_HIZ_VOUT_B5    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B6 	,VOUT_B6_REN    |  REG_HIZ_VOUT_B6    | 0x0);
//  reg_write(ADDR_REG_TMUX_VOUT_B7 	,VOUT_B7_REN    |  REG_HIZ_VOUT_B7    | 0x0);
    reg_write(ADDR_REG_TMUX_VOUT_G0_C0 	,VOUT_G0_C0_REN |  REG_HIZ_VOUT_G0_C0 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_G1_C1 	,VOUT_G1_C1_REN |  REG_HIZ_VOUT_G1_C1 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_G2_C2 	,VOUT_G2_C2_REN |  REG_HIZ_VOUT_G2_C2 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_G3_C3 	,VOUT_G3_C3_REN |  REG_HIZ_VOUT_G3_C3 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_G4_C4 	,VOUT_G4_C4_REN |  REG_HIZ_VOUT_G4_C4 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_G5_C5 	,VOUT_G5_C5_REN |  REG_HIZ_VOUT_G5_C5 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_G6_C6 	,VOUT_G6_C6_REN |  REG_HIZ_VOUT_G6_C6 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_G7_C7 	,VOUT_G7_C7_REN |  REG_HIZ_VOUT_G7_C7 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R0_Y0 	,VOUT_R0_Y0_REN |  REG_HIZ_VOUT_R0_Y0 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R1_Y1 	,VOUT_R1_Y1_REN |  REG_HIZ_VOUT_R1_Y1 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R2_Y2 	,VOUT_R2_Y2_REN |  REG_HIZ_VOUT_R2_Y2 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R3_Y3 	,VOUT_R3_Y3_REN |  REG_HIZ_VOUT_R3_Y3 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R4_Y4 	,VOUT_R4_Y4_REN |  REG_HIZ_VOUT_R4_Y4 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R5_Y5 	,VOUT_R5_Y5_REN |  REG_HIZ_VOUT_R5_Y5 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R6_Y6 	,VOUT_R6_Y6_REN |  REG_HIZ_VOUT_R6_Y6 | 0x3);
    reg_write(ADDR_REG_TMUX_VOUT_R7_Y7 	,VOUT_R7_Y7_REN |  REG_HIZ_VOUT_R7_Y7 | 0x3);
}
void pinmux_rgb(void)
{
	tdk_printf("PINMUX RGB888\n");
    reg_write(ADDR_REG_TMUX_EXTINT 		,EXTINT_REN     |  REG_HIZ_EXTINT     | 0x1); // TODO
    reg_write(ADDR_REG_TMUX_VOUT_HSYNC 	,VOUT_HSYNC_REN |  REG_HIZ_VOUT_HSYNC | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_VSYNC 	,VOUT_VSYNC_REN |  REG_HIZ_VOUT_VSYNC | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_HACT 	,VOUT_HACT_REN  |  REG_HIZ_VOUT_HACT  | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_B0 	,VOUT_B0_REN    |  REG_HIZ_VOUT_B0    | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_B1 	,VOUT_B1_REN    |  REG_HIZ_VOUT_B1    | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_B2 	,VOUT_B2_REN    |  REG_HIZ_VOUT_B2    | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_B3 	,VOUT_B3_REN    |  REG_HIZ_VOUT_B3    | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_B4 	,VOUT_B4_REN    |  REG_HIZ_VOUT_B4    | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_B5 	,VOUT_B5_REN    |  REG_HIZ_VOUT_B5    | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_B6 	,VOUT_B6_REN    |  REG_HIZ_VOUT_B6    | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_B7 	,VOUT_B7_REN    |  REG_HIZ_VOUT_B7    | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_G0_C0 	,VOUT_G0_C0_REN |  REG_HIZ_VOUT_G0_C0 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_G1_C1 	,VOUT_G1_C1_REN |  REG_HIZ_VOUT_G1_C1 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_G2_C2 	,VOUT_G2_C2_REN |  REG_HIZ_VOUT_G2_C2 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_G3_C3 	,VOUT_G3_C3_REN |  REG_HIZ_VOUT_G3_C3 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_G4_C4 	,VOUT_G4_C4_REN |  REG_HIZ_VOUT_G4_C4 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_G5_C5 	,VOUT_G5_C5_REN |  REG_HIZ_VOUT_G5_C5 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_G6_C6 	,VOUT_G6_C6_REN |  REG_HIZ_VOUT_G6_C6 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_G7_C7 	,VOUT_G7_C7_REN |  REG_HIZ_VOUT_G7_C7 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_R0_Y0 	,VOUT_R0_Y0_REN |  REG_HIZ_VOUT_R0_Y0 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_R1_Y1 	,VOUT_R1_Y1_REN |  REG_HIZ_VOUT_R1_Y1 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_R2_Y2 	,VOUT_R2_Y2_REN |  REG_HIZ_VOUT_R2_Y2 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_R3_Y3 	,VOUT_R3_Y3_REN |  REG_HIZ_VOUT_R3_Y3 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_R4_Y4 	,VOUT_R4_Y4_REN |  REG_HIZ_VOUT_R4_Y4 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_R5_Y5 	,VOUT_R5_Y5_REN |  REG_HIZ_VOUT_R5_Y5 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_R6_Y6 	,VOUT_R6_Y6_REN |  REG_HIZ_VOUT_R6_Y6 | 0x1);
    reg_write(ADDR_REG_TMUX_VOUT_R7_Y7 	,VOUT_R7_Y7_REN |  REG_HIZ_VOUT_R7_Y7 | 0x1);
}
void pinmux_q_spi(void)
{
	tdk_printf("PINMUX Quad SPI\n");
    reg_write(ADDR_REG_TMUX_SPI2_CSN1 ,SPI2_CSN1_REN | REG_HIZ_SPI2_CSN1);
    reg_write(ADDR_REG_TMUX_SPI2_CSN0 ,SPI2_CSN0_REN | REG_HIZ_SPI2_CSN0);
    reg_write(ADDR_REG_TMUX_SPI2_SCK  ,SPI2_SCK_REN  | REG_HIZ_SPI2_SCK );
    reg_write(ADDR_REG_TMUX_SPI2_DQ0  ,SPI2_DQ0_REN  | REG_HIZ_SPI2_DQ0 );
    reg_write(ADDR_REG_TMUX_SPI2_DQ1  ,SPI2_DQ1_REN  | REG_HIZ_SPI2_DQ1 );
    reg_write(ADDR_REG_TMUX_SPI2_DQ2  ,SPI2_DQ2_REN  | REG_HIZ_SPI2_DQ2 );
    reg_write(ADDR_REG_TMUX_SPI2_DQ3  ,SPI2_DQ3_REN  | REG_HIZ_SPI2_DQ3 );
}
void pinmux_spi1(void)
{
	tdk_printf("PINMUX SPI #1\n");
    reg_write(ADDR_REG_TMUX_SPI2_CSN0 ,SPI2_CSN1_REN | REG_HIZ_SPI2_CSN0 | 0x1);
    reg_write(ADDR_REG_TMUX_SPI2_SCK  ,SPI2_SCK_REN  | REG_HIZ_SPI2_SCK  | 0x1); // SCK1
    reg_write(ADDR_REG_TMUX_SPI2_DQ0  ,SPI2_DQ0_REN  | REG_HIZ_SPI2_DQ0  | 0x1); // MOSI1
    reg_write(ADDR_REG_TMUX_SPI2_DQ1  ,SPI2_DQ1_REN  | REG_HIZ_SPI2_DQ1  | 0x1); // MISO1
}
void pinmux_spi0(void)
{
	tdk_printf("PINMUX SPI #0\n");
    reg_write(ADDR_REG_TMUX_SPI2_CSN1 ,SPI2_CSN1_REN | REG_HIZ_SPI2_CSN1 | 0x2);
    reg_write(ADDR_REG_TMUX_SPI2_SCK  ,SPI2_SCK_REN  | REG_HIZ_SPI2_SCK  | 0x2); // SCK2
    reg_write(ADDR_REG_TMUX_SPI2_DQ0  ,SPI2_DQ0_REN  | REG_HIZ_SPI2_DQ0  | 0x2); // MOSI0
    reg_write(ADDR_REG_TMUX_SPI2_DQ1  ,SPI2_DQ1_REN  | REG_HIZ_SPI2_DQ1  | 0x2); // MISO0
}
void pinmux_i2c0(void)
{
	tdk_printf("PINMUX I2C #0\n");
    reg_write(ADDR_REG_TMUX_I2C0_SDA  ,I2C0_SDA_REN  | REG_HIZ_I2C0_SDA  | 0x0); // SDA0
    reg_write(ADDR_REG_TMUX_I2C0_SCL  ,I2C0_SCL_REN  | REG_HIZ_I2C0_SCL  | 0x0); // SCL0
}
void pinmux_i2c1(void)
{
	tdk_printf("PINMUX I2C #1\n");
    reg_write(ADDR_REG_TMUX_I2C1_SDA  ,I2C1_SDA_REN  | REG_HIZ_I2C1_SDA  | 0x0); // SDA1
    reg_write(ADDR_REG_TMUX_I2C1_SCL  ,I2C1_SCL_REN  | REG_HIZ_I2C1_SCL  | 0x0); // SCL1
}
void pinmux_uart0(void)
{
	tdk_printf("PINMUX UART #0\n");
    reg_write(ADDR_REG_TMUX_UART_TX  ,UART_TX_REN  | REG_HIZ_UART_TX  | 0x0); // UART_TX
    reg_write(ADDR_REG_TMUX_UART_RX  ,UART_RX_REN  | REG_HIZ_UART_RX  | 0x0); // UART_RX
}
void pinmux_uart1(void)
{
	tdk_printf("PINMUX UART #1\n");
    reg_write(ADDR_REG_TMUX_CAN_TX  ,CAN_TX_REN  | REG_HIZ_CAN_TX  | 0x1); // UART_TX
    reg_write(ADDR_REG_TMUX_CAN_RX  ,CAN_RX_REN  | REG_HIZ_CAN_RX  | 0x1); // UART_RX
}
void pinmux_can(void)
{
	tdk_printf("PINMUX CAN\n");
    reg_write(ADDR_REG_TMUX_CAN_TX  ,CAN_TX_REN  | REG_HIZ_CAN_TX  | 0x0); // CAN_TX
    reg_write(ADDR_REG_TMUX_CAN_RX  ,CAN_RX_REN  | REG_HIZ_CAN_RX  | 0x0); // CAN_RX
}
void pinmux_gpio(void)
{
	tdk_printf("PINMUX GPIO\n");
    reg_write(ADDR_REG_TMUX_GPIO0  ,GPIO0_REN  | REG_HIZ_GPIO0  | 0x0); // GPIO0
    reg_write(ADDR_REG_TMUX_GPIO1  ,GPIO1_REN  | REG_HIZ_GPIO1  | 0x0); // GPIO1
    reg_write(ADDR_REG_TMUX_GPIO2  ,GPIO2_REN  | REG_HIZ_GPIO2  | 0x0); // GPIO2
    reg_write(ADDR_REG_TMUX_GPIO3  ,GPIO3_REN  | REG_HIZ_GPIO3  | 0x0); // GPIO3
    reg_write(ADDR_REG_TMUX_GPIO4  ,GPIO4_REN  | REG_HIZ_GPIO4  | 0x0); // GPIO4
}
void pinmux_int(void)
{
    reg_write(ADDR_REG_TMUX_EXTINT  ,EXTINT_REN  |REG_HIZ_EXTINT  | 0x0); // EXTINT
}
void pinmux_ext_sync_in(void)
{
    reg_write(ADDR_REG_TMUX_SEN_PH  ,SEN_PH_REN  |REG_HIZ_SEN_PH  | 0x1); // PH
    reg_write(ADDR_REG_TMUX_SEN_PV  ,SEN_PV_REN  |REG_HIZ_SEN_PV  | 0x1); // PV
}
void pinmux_ext_sync_out(void)
{
    reg_write(ADDR_REG_TMUX_I2C1_SCL  ,I2C1_SCL_REN  |REG_HIZ_I2C1_SCL  | 0x2); // PH
    reg_write(ADDR_REG_TMUX_I2C1_SDA  ,I2C1_SDA_REN  |REG_HIZ_I2C1_SDA  | 0x2); // PV
}
