#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../system/system.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_prompt.h"

#include "../include/ansi.h"
#include "../drivers/ddr.h"

#include "../tdk/tdk_util.h"

void dmc_init()
{
	u32 data, i;
	int loop = 100000;

	reg_write(DDR_ADDR_SIZE, (reg_read(DDR_ADDR_SIZE) & 0xffffffe0) | 0x04); // bank : 2, row : 12, col : 8
	reg_write(DDR_PHY_CONFIG, DDR_PHY_INIT);
	while(loop--)
	{
		data = reg_read(DDR_PHY_CONFIG);
		if(data & DDR_PHY_COMPLETE) break;
	}
	tdk_printf("DDR Init : %s\n", loop<=0 ? ANSI_FAIL:ANSI_PASS);
}
