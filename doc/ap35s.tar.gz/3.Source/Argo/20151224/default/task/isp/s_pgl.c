#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"
void SPGL_set(void)
{
	tdk_printf("SPGL set\n");
    isp_write(ISP_SPGL_BASE+0x00,0x11);   // PGL_EN 

//2015.12.16
//    isp_write(ISP_SPGL_BASE+0x01,0x90);   // PGL_x,y
//    isp_write(ISP_SPGL_BASE+0x02,0x01);
//    isp_write(ISP_SPGL_BASE+0x03,0x7E);
//    isp_write(ISP_SPGL_BASE+0x04,0x00);
//    isp_write(ISP_SPGL_BASE+0x05,0x2A);
//    isp_write(ISP_SPGL_BASE+0x06,0x03);
//    isp_write(ISP_SPGL_BASE+0x07,0x88);
//    isp_write(ISP_SPGL_BASE+0x08,0x03);
//    isp_write(ISP_SPGL_BASE+0x09,0x64);
//    isp_write(ISP_SPGL_BASE+0x0A,0x00);
//    isp_write(ISP_SPGL_BASE+0x0B,0x94);
//    isp_write(ISP_SPGL_BASE+0x0C,0x02);
//    isp_write(ISP_SPGL_BASE+0x0D,0x64);
//    isp_write(ISP_SPGL_BASE+0x0E,0x00);
//    isp_write(ISP_SPGL_BASE+0x0F,0x64);
//    isp_write(ISP_SPGL_BASE+0x10,0x00);
//    isp_write(ISP_SPGL_BASE+0x11,0x64);
//    isp_write(ISP_SPGL_BASE+0x12,0x00);
//
//    isp_write(ISP_SPGL_BASE+0x6D,0xA6);   // PGL_x,y_2
//    isp_write(ISP_SPGL_BASE+0x6E,0x01);
//    isp_write(ISP_SPGL_BASE+0x6F,0xC8);
//    isp_write(ISP_SPGL_BASE+0x70,0x00);
//    isp_write(ISP_SPGL_BASE+0x71,0x34);
//    isp_write(ISP_SPGL_BASE+0x72,0x03);
//    isp_write(ISP_SPGL_BASE+0x73,0xC8);
//    isp_write(ISP_SPGL_BASE+0x74,0x03);

//2015.12.17
      isp_write(ISP_SPGL_BASE+0x01,0x68);   // PGL_x,y
      isp_write(ISP_SPGL_BASE+0x02,0x00);
      isp_write(ISP_SPGL_BASE+0x03,0x1E);
      isp_write(ISP_SPGL_BASE+0x04,0x00);
      isp_write(ISP_SPGL_BASE+0x05,0xD2);
      isp_write(ISP_SPGL_BASE+0x06,0x00);
      isp_write(ISP_SPGL_BASE+0x07,0xFA);
      isp_write(ISP_SPGL_BASE+0x08,0x00);
      isp_write(ISP_SPGL_BASE+0x09,0x6D);
      isp_write(ISP_SPGL_BASE+0x0A,0x01);
      isp_write(ISP_SPGL_BASE+0x0B,0x84);
      isp_write(ISP_SPGL_BASE+0x0C,0x02);
      isp_write(ISP_SPGL_BASE+0x0D,0x96);
      isp_write(ISP_SPGL_BASE+0x0E,0x00);
      isp_write(ISP_SPGL_BASE+0x0F,0x96);
      isp_write(ISP_SPGL_BASE+0x10,0x00);
      isp_write(ISP_SPGL_BASE+0x11,0x96);
      isp_write(ISP_SPGL_BASE+0x12,0x00);

      isp_write(ISP_SPGL_BASE+0x17,0x0F); // H WIDTH,LENGTH
      isp_write(ISP_SPGL_BASE+0x18,0x0F);
      isp_write(ISP_SPGL_BASE+0x19,0x0F);
      isp_write(ISP_SPGL_BASE+0x1A,0x0F);
      isp_write(ISP_SPGL_BASE+0x1B,0x0A);
      isp_write(ISP_SPGL_BASE+0x1C,0x0A);
      isp_write(ISP_SPGL_BASE+0x1D,0x0A);
      isp_write(ISP_SPGL_BASE+0x1E,0x0A);

      isp_write(ISP_SPGL_BASE+0x53,0x20); // Line,AR BGR
      isp_write(ISP_SPGL_BASE+0x54,0x20);
      isp_write(ISP_SPGL_BASE+0x55,0x20);
      isp_write(ISP_SPGL_BASE+0x56,0x20);
      isp_write(ISP_SPGL_BASE+0x57,0x20);
      isp_write(ISP_SPGL_BASE+0x58,0x20);
      isp_write(ISP_SPGL_BASE+0x59,0x20);
      isp_write(ISP_SPGL_BASE+0x5A,0x20);

      isp_write(ISP_SPGL_BASE+0x6D,0x6C);   // PGL_x,y_2
      isp_write(ISP_SPGL_BASE+0x6E,0x00);
      isp_write(ISP_SPGL_BASE+0x6F,0x32);
      isp_write(ISP_SPGL_BASE+0x70,0x00);
      isp_write(ISP_SPGL_BASE+0x71,0xD6);
      isp_write(ISP_SPGL_BASE+0x72,0x00);
      isp_write(ISP_SPGL_BASE+0x73,0x0E);
      isp_write(ISP_SPGL_BASE+0x74,0x01);
}
