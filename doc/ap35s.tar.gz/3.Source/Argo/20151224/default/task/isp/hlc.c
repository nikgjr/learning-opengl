#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void HLC_set()
{
	tdk_printf("HLC set\n");
    isp_write(ISP_HLC_BASE+0x40,0x01);  // HLC_MIX_EN
    isp_write(ISP_HLC_BASE+0x41,0x80);  // HLC_LTH
    isp_write(ISP_HLC_BASE+0x42,0xC0);  // HLC_HTH
    isp_write(ISP_HLC_BASE+0x44,0xE0);  // HLC_PEAK1_LTH
    isp_write(ISP_HLC_BASE+0x43,0xF0);  // HLC_PEAK1_HTH
    isp_write(ISP_HLC_BASE+0x46,0xE0);  // HLC_PEAK2_LTH
    isp_write(ISP_HLC_BASE+0x45,0xF0);  // HLC_PEAK2_HTH
//  isp_write(ISP_HLC_BASE+0x48,0x00);  // HLC_X0_START
//  isp_write(ISP_HLC_BASE+0x47,0x00);  // HLC_Y0_START
    isp_write(ISP_HLC_BASE+0x4A,0x28);  // HLC_X0_WIDTH
    isp_write(ISP_HLC_BASE+0x49,0x10);  // HLC_Y0_HEIGHT
    isp_write(ISP_HLC_BASE+0x4B,0x06);  // HLC_ATTR0
}

