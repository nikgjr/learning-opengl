#include "isp_regmap.h"
#include "../tdk/tdk.h"

#if ISP_REG_CALL_FUNC
void isp_write(unsigned int addr, unsigned char data)
{
    *((volatile unsigned char *)(ISP_BASE+addr))=data;
}

unsigned char isp_read (unsigned int addr)
{
    return *((volatile unsigned char *)(ISP_BASE+addr));
}

void mem_write(unsigned int addr, unsigned char data)
{
    *((volatile unsigned char *)(MEM_BASE+addr))=data;
}

unsigned char mem_read (unsigned int addr)
{
    return *((volatile unsigned char *)(MEM_BASE+addr));
}
#endif

void isp_reg_scan(unsigned int start, unsigned int range)
{
    unsigned int addr       = start;
    unsigned int addr_end   = addr + range;
    unsigned char bit       = 0;
    unsigned char error[8]  = {0,};

    while(addr != addr_end)
    {
        bit = 0;
        while(bit != 8)
        {
            error[bit] = 0;

            // 1. set 0
            isp_write(addr,0x00);
            if(isp_read(addr)!=0x00)        error[bit] |= 0x01;

            // 2. set 1
            isp_write(addr,(0x01<<bit));
            if(isp_read(addr)!=(0x01<<bit)) error[bit] |= 0x02;

            // 3. set 0
            isp_write(addr,0x00);
            if(isp_read(addr)!=0x00)        error[bit] |= 0x04;

            bit++;
        }

	    tdk_printf("addr[0x%X] : %1X%1X%1X%1X%1X%1X%1X%1X\n", addr,error[7],error[6],error[5],error[4],error[3],error[2],error[1],error[0]);
        addr++;
    }    
}
