#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void VBI_set(void)
{
	tdk_printf("VBI set\n");
    isp_write(ISP_VBI_BASE+0x00,0x3F);              // {2'd0,O_VBI_DATA_C_EN,O_VBI_DATA_NUM,O_VBI_DATA_8BIT,O_VBI_STREAM_EN,O_VBI_EN};
//  isp_write(ISP_VBI_BASE+0x02,0x00);              // {5'd0, O_VBI_START_LINE[10:8]};
    isp_write(ISP_VBI_BASE+0x01,0x08);              // O_VBI_START_LINE[7:0];
    isp_write(ISP_VBI_BASE+0x04,0x03);              // {6'd0, O_VBI_ANC_FLAG0[9:8]};
    isp_write(ISP_VBI_BASE+0x03,0xFF);              // O_VBI_ANC_FLAG0[7:0];
    isp_write(ISP_VBI_BASE+0x06,0x03);              // {6'd0, O_VBI_ANC_FLAG1[9:8]};
    isp_write(ISP_VBI_BASE+0x05,0xFF);              // O_VBI_ANC_FLAG1[7:0];
//  isp_write(ISP_VBI_BASE+0x08,0x00);              // {6'd0, O_VBI_ANC_FLAG2[9:8]};
//  isp_write(ISP_VBI_BASE+0x07,0x00);              // O_VBI_ANC_FLAG2[7:0];
    isp_write(ISP_VBI_BASE+0x09,0x01);              // O_VBI_STREAM_DID;
    isp_write(ISP_VBI_BASE+0x0A,0x01);              // O_VBI_STREAM_KEY;
    isp_write(ISP_VBI_BASE+0x0B,0x06);              // O_VBI_STREAM_LENGTH;
    isp_write(ISP_VBI_BASE+0x0D,FRC_VTOTAL >> 8);   // O_V_TOT_LINE[10:8];
    isp_write(ISP_VBI_BASE+0x0C,FRC_VTOTAL);        // O_V_TOT_LINE[7:0];
    isp_write(ISP_VBI_BASE+0x0E,0x01);              // O_VBI_STREAM_DATA0;
    isp_write(ISP_VBI_BASE+0x0F,0x02);              // O_VBI_STREAM_DATA1;
    isp_write(ISP_VBI_BASE+0x10,0x03);              // O_VBI_STREAM_DATA2;
    isp_write(ISP_VBI_BASE+0x11,0x04);              // O_VBI_STREAM_DATA3;
    isp_write(ISP_VBI_BASE+0x12,0x05);              // O_VBI_STREAM_DATA4;
    isp_write(ISP_VBI_BASE+0x13,0x06);              // O_VBI_STREAM_DATA5;
    isp_write(ISP_VBI_BASE+0x14,0x04);              // O_VBI_DATA0_LENGTH;
    isp_write(ISP_VBI_BASE+0x15,0x04);              // O_VBI_DATA1_LENGTH;
    isp_write(ISP_VBI_BASE+0x16,0x02);              // O_VBI_DATA0_DID;
    isp_write(ISP_VBI_BASE+0x17,0x02);              // O_VBI_DATA1_DID;
    isp_write(ISP_VBI_BASE+0x18,0x01);              // O_VBI_DATA0_KEY;
    isp_write(ISP_VBI_BASE+0x19,0x03);              // O_VBI_DATA1_KEY;
    isp_write(ISP_VBI_BASE+0x1D,0x13);              // O_VBI_DATA0_VALUE[31:24];
    isp_write(ISP_VBI_BASE+0x1C,0x14);              // O_VBI_DATA0_VALUE[23:16];
    isp_write(ISP_VBI_BASE+0x1B,0x15);              // O_VBI_DATA0_VALUE[15:8] ;
    isp_write(ISP_VBI_BASE+0x1A,0x16);              // O_VBI_DATA0_VALUE[7:0]  ;
    isp_write(ISP_VBI_BASE+0x21,0x23);              // O_VBI_DATA1_VALUE[31:24];
    isp_write(ISP_VBI_BASE+0x20,0x24);              // O_VBI_DATA1_VALUE[23:16];
    isp_write(ISP_VBI_BASE+0x1F,0x25);              // O_VBI_DATA1_VALUE[15:8] ;
    isp_write(ISP_VBI_BASE+0x1E,0x26);              // O_VBI_DATA1_VALUE[7:0]  ;
}
