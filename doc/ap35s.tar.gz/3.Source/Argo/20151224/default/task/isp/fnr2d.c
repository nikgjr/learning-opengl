#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"
void FNR2D_set(void)
{
	tdk_printf("FNR2D set\n");
    isp_write(ISP_FNR2D_BASE+0x60,0x00);  // FNR2D_EN[0]
//  isp_write(ISP_FNR2D_BASE+0x61,0x00);  // {1'b0,FNR2D_INT2_0[6:4],1'h0,FNR2D_INT2_1[2:0]}
//  isp_write(ISP_FNR2D_BASE+0x62,0x00);  // {1'b0,FNR2D_INT2_2[6:4],1'h0,FNR2D_INT2_3[2:0]}
//  isp_write(ISP_FNR2D_BASE+0x63,0x00);  // {1'b0,FNR2D_INT2_4[6:4],1'h0,FNR2D_INT2_5[2:0]}
//  isp_write(ISP_FNR2D_BASE+0x64,0x00);  // {1'b0,FNR2D_INT2_6[6:4],1'h0,FNR2D_INT2_7[2:0]}
//  isp_write(ISP_FNR2D_BASE+0x65,0x00);  // {1'b0,FNR2D_INT2_8[6:4],1'h0,FNR2D_INT2_9[2:0]}
}

