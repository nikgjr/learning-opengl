#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void BMD_set(void)
{
	tdk_printf("BMD set\n");

    isp_write(ISP_BMD_BASE+0x00,0x0F);  // {2'h0, I_MD_CAP_PULSE_STOP, I_MD_CAP_PULSE_INV, I_GRID_COLOR, I_GRID_EN, I_EN}
    isp_write(ISP_BMD_BASE+0x01,0x3C);  // {2'd0, O_BMD_HBNUM};
    isp_write(ISP_BMD_BASE+0x02,0x22);  // {2'd0, O_BMD_VBNUM};
    isp_write(ISP_BMD_BASE+0x03,0x05);  // O_BMD_OFFSET_V[7:0];
//  isp_write(ISP_BMD_BASE+0x04,0x00);  // {6'd0, O_BMD_OFFSET_V[9:8]};
    isp_write(ISP_BMD_BASE+0x05,0x05);  // O_BMD_OFFSET_H[7:0];
//  isp_write(ISP_BMD_BASE+0x06,0x00);  // {6'd0, O_BMD_OFFSET_H[9:8]};
//  isp_write(ISP_BMD_BASE+0x07,0x00);  // {4'd0, O_BMD_SUM_SHIFT};
//  isp_write(ISP_BMD_BASE+0x08,0x40);  // O_BMD_GAIN;
//  isp_write(ISP_BMD_BASE+0x09,0x20);  // O_BMD_BLK_INCLV;
//  isp_write(ISP_BMD_BASE+0x0A,0x00);  // {O_BMD_UPLOAD_TYPE, O_BMD_UPLOAD_SKIPNUM};
//  isp_write(ISP_BMD_BASE+0x0B,0x80);  // O_BMD_UPLOAD_BLENDING;

    isp_write(ISP_BMD_BASE+0x0C,0xFF);  // {I_MD_INT_WIN_SEL, I_MD_INT_WIN_SEL};
    isp_write(ISP_BMD_BASE+0x0D,0xF1);  // {I_MD_INT_G_SEL, I_MD_CAP_G_SEL, I_MD_CAP_TIME_MUL};
    isp_write(ISP_BMD_BASE+0x0E,0x10);  // I_MD_CAP_TIME_LEN;
    isp_write(ISP_BMD_BASE+0x0F,0xFF);  // {I_MD1_G_EN, I_MD0_G_EN, I_MD1_WIN1_EN, I_MD1_WIN0_EN, I_MD0_WIN1_EN, I_MD0_WIN0_EN};

    isp_write(ISP_BMD_BASE+0x10,0x10);  // O_BMD_MD0_THLV[7:0];
//  isp_write(ISP_BMD_BASE+0x11,0x00);  // {6'd0, O_BMD_MD0_THLV[9:8]};
    isp_write(ISP_BMD_BASE+0x12,0x10);  // O_BMD_MD1_THLV[7:0];
//  isp_write(ISP_BMD_BASE+0x13,0x00);  // {6'd0, O_BMD_MD1_THLV[9:8]};

    isp_write(ISP_BMD_BASE+0x14,0x01);  // O_BMD_MD0_G_THCNT_TH[7:0];
//  isp_write(ISP_BMD_BASE+0x15,0x00);  // {5'd0, O_BMD_MD0_G_THCNT_TH[10:8]};
    isp_write(ISP_BMD_BASE+0x16,0x01);  // O_BMD_MD1_G_THCNT_TH[7:0];
//  isp_write(ISP_BMD_BASE+0x17,0x00);  // {5'd0, O_BMD_MD1_G_THCNT_TH[10:8]};

    isp_write(ISP_BMD_BASE+0x18,0x90);  // {O_BMD_MD0_WIN0_OUTLN_EN, O_BMD_MD0_WIN0_OUTLN_TYPE, O_BMD_MD0_WIN0_OUTLN_BLK, O_BMD_MD0_WIN0_DPEN, O_BMD_MD0_WIN0_COLOR, O_BMD_MD0_WIN0_TRANS};
//  isp_write(ISP_BMD_BASE+0x19,0x00);  // {2'd0, O_BMD_MD0_WIN0_HST};
//  isp_write(ISP_BMD_BASE+0x1A,0x00);  // {2'd0, O_BMD_MD0_WIN0_VST};
    isp_write(ISP_BMD_BASE+0x1B,0x14);  // {2'd0, O_BMD_MD0_WIN0_WIDTH};
    isp_write(ISP_BMD_BASE+0x1C,0x0B);  // {2'd0, O_BMD_MD0_WIN0_HEIGHT};
    isp_write(ISP_BMD_BASE+0x1D,0x01);  // O_BMD_MD0_WIN0_THCNT_TH[7:0];
//  isp_write(ISP_BMD_BASE+0x1E,0x00);  // {5'd0, O_BMD_MD0_WIN0_THCNT_TH[10:8]};

    isp_write(ISP_BMD_BASE+0x1F,0x91);  // {O_BMD_MD0_WIN1_OUTLN_EN, O_BMD_MD0_WIN1_OUTLN_TYPE, O_BMD_MD0_WIN1_OUTLN_BLK, O_BMD_MD0_WIN1_DPEN, O_BMD_MD0_WIN1_COLOR, O_BMD_MD0_WIN1_TRANS};
    isp_write(ISP_BMD_BASE+0x20,0x14);  // {2'd0, O_BMD_MD0_WIN1_HST};
//  isp_write(ISP_BMD_BASE+0x21,0x00);  // {2'd0, O_BMD_MD0_WIN1_VST};
    isp_write(ISP_BMD_BASE+0x22,0x14);  // {2'd0, O_BMD_MD0_WIN1_WIDTH};
    isp_write(ISP_BMD_BASE+0x23,0x0B);  // {2'd0, O_BMD_MD0_WIN1_HEIGHT};
    isp_write(ISP_BMD_BASE+0x24,0x02);  // O_BMD_MD0_WIN1_THCNT_TH[7:0];
//  isp_write(ISP_BMD_BASE+0x25,0x00);  // {5'd0, O_BMD_MD0_WIN1_THCNT_TH[10:8]};

    isp_write(ISP_BMD_BASE+0x26,0x94);  // {O_BMD_MD1_WIN0_OUTLN_EN, O_BMD_MD1_WIN0_OUTLN_TYPE, O_BMD_MD1_WIN0_OUTLN_BLK, O_BMD_MD1_WIN0_DPEN, O_BMD_MD1_WIN0_COLOR, O_BMD_MD1_WIN0_TRANS};
    isp_write(ISP_BMD_BASE+0x27,0x00);  // {2'd0, O_BMD_MD1_WIN0_HST};
    isp_write(ISP_BMD_BASE+0x28,0x0B);  // {2'd0, O_BMD_MD1_WIN0_VST};
    isp_write(ISP_BMD_BASE+0x29,0x14);  // {2'd0, O_BMD_MD1_WIN0_WIDTH};
    isp_write(ISP_BMD_BASE+0x2A,0x0C);  // {2'd0, O_BMD_MD1_WIN0_HEIGHT};
    isp_write(ISP_BMD_BASE+0x2B,0x03);  // O_BMD_MD1_WIN0_THCNT_TH[7:0];
//  isp_write(ISP_BMD_BASE+0x2C,0x00);  // {5'd0, O_BMD_MD1_WIN0_THCNT_TH[10:8]};

    isp_write(ISP_BMD_BASE+0x2D,0xD2);  // {O_BMD_MD1_WIN1_OUTLN_EN, O_BMD_MD1_WIN1_OUTLN_TYPE, O_BMD_MD1_WIN1_OUTLN_BLK, O_BMD_MD1_WIN1_DPEN, O_BMD_MD1_WIN1_COLOR, O_BMD_MD1_WIN1_TRANS};
    isp_write(ISP_BMD_BASE+0x2E,0x14);  // {2'd0, O_BMD_MD1_WIN1_HST};
    isp_write(ISP_BMD_BASE+0x2F,0x0B);  // {2'd0, O_BMD_MD1_WIN1_VST};
    isp_write(ISP_BMD_BASE+0x30,0x14);  // {2'd0, O_BMD_MD1_WIN1_WIDTH};
    isp_write(ISP_BMD_BASE+0x31,0x0C);  // {2'd0, O_BMD_MD1_WIN1_HEIGHT};
    isp_write(ISP_BMD_BASE+0x32,0x04);  // O_BMD_MD1_WIN1_THCNT_TH[7:0];
//  isp_write(ISP_BMD_BASE+0x33,0x00);  // {5'd0, O_BMD_MD1_WIN1_THCNT_TH[10:8]};
}
