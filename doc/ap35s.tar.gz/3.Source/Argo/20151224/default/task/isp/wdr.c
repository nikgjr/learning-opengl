#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"
void WDR_DOL3_set(void)
{
    isp_write(ISP_WDR_BASE+0x00,0x0f);      // WDR_ADJUST_IMG_METHOD[6], WDR_ADJUST_IMG_SEL[5], WDR_AUTO_IMG_SEL[4], WDR_ACE_SEL[3], WDR_DOL_EN[2], WDR_DOL_MODE[1], WDR_EN[0],
    isp_write(ISP_WDR_BASE+0x01,0x00);      // WDR_HALF_FRAME[7:6], WDR_DEFINE_IMG[5:4], WDR_H_SWAP[1], WDR_V_SWAP[0],
    isp_write(ISP_WDR_BASE+0x02,0x00);      // WDR_DBG_MODE[7:4], WDR_DBG_MODE_SUB[2:1], WDR_DBG_EN[0],
    isp_write(ISP_WDR_BASE+0x03,0x00);      // H_SWAP_SUB_LSC[7], V_SWAP_SUB_LSC[6], H_SWAP_SUB_AWB[5], V_SWAP_SUB_AWB[4], WDR_ADJ_EN[2],

    isp_write(ISP_WDR_BASE+0x04,0x00);      // WDR_ADJ_GAIN[14:8][6:0];
    isp_write(ISP_WDR_BASE+0x05,0x00);      // WDR_ADJ_GAIN[7:0] [7:0];
    isp_write(ISP_WDR_BASE+0x06,IN_VACT_LBFRC >> 8);        // WDR_V_SIZE[10:8]  [2:0];
    isp_write(ISP_WDR_BASE+0x07,IN_VACT_LBFRC     );               // WDR_V_SIZE[7:0]   [7:0];
    isp_write(ISP_WDR_BASE+0x08,IN_HACT_LBFRC >> 8);      // WDR_H_SIZE[10:8]  [2:0];
    isp_write(ISP_WDR_BASE+0x09,IN_HACT_LBFRC     );      // WDR_H_SIZE[7:0]   [7:0];

    isp_write(ISP_WDR_BASE+0x0A,0x8f);      // WDR_SBLUR_SIZE_CHK[7], WDR_SB_FILTER_SET[3:1], WDR_SBLUR_EN[0],
    isp_write(ISP_WDR_BASE+0x0B,0x02);      //

    isp_write(ISP_WDR_BASE+0x0D,0x00);      // WDR_SB_EMIX_BGAP_DIS[7], WDR_SB_EMIX_BGAP_SIGN0[6], WDR_SB_EMIX_BGAP_SIGN1[5],
    isp_write(ISP_WDR_BASE+0x0E,128 );          // WDR_SB_EMIX_BGAP_THR0[7:0]
    isp_write(ISP_WDR_BASE+0x0F,64  );          // WDR_SB_EMIX_BGAP_THR1[7:0]
    isp_write(ISP_WDR_BASE+0x10,32  );          // WDR_SB_EMIX_BGAP_THR2[7:0]
    isp_write(ISP_WDR_BASE+0x11,0x10);        // WDR_SB_EMIX_BGAP_RAT0[7:0]
    isp_write(ISP_WDR_BASE+0x12,0x28);        // WDR_SB_EMIX_BGAP_RAT1[7:0]
    isp_write(ISP_WDR_BASE+0x13,0x10);        // WDR_SB_EMIX_BGAP_RAT2[7:0]

    isp_write(ISP_WDR_BASE+0x14,0x00);      // WDR_SB_EMIX_DGAP_DIS[7], WDR_SB_EMIX_DGAP_SIGN0[6], WDR_SB_EMIX_DGAP_SIGN1[5],
    isp_write(ISP_WDR_BASE+0x15,128 );      // WDR_SB_EMIX_DGAP_THR0[7:0];
    isp_write(ISP_WDR_BASE+0x16,64  );      // WDR_SB_EMIX_DGAP_THR1[7:0];
    isp_write(ISP_WDR_BASE+0x17,32  );      // WDR_SB_EMIX_DGAP_THR2[7:0];
    isp_write(ISP_WDR_BASE+0x18,0x10);    // WDR_SB_EMIX_DGAP_RAT0[7:0];
    isp_write(ISP_WDR_BASE+0x19,0x18);    // WDR_SB_EMIX_DGAP_RAT1[7:0];
    isp_write(ISP_WDR_BASE+0x1A,0x20);    // WDR_SB_EMIX_DGAP_RAT2[7:0];

    isp_write(ISP_WDR_BASE+0x1B,0x00);      // WDR_SB_BLND_BGAP_DIS[7], WDR_SB_BLND_BGAP_SIGN0[6], WDR_SB_BLND_BGAP_SIGN1[5],
    isp_write(ISP_WDR_BASE+0x1C,255 );       // WDR_SB_BLND_BGAP_THR0[7:0]
    isp_write(ISP_WDR_BASE+0x1D,254 );       // WDR_SB_BLND_BGAP_THR1[7:0]
    isp_write(ISP_WDR_BASE+0x1E,253 );       // WDR_SB_BLND_BGAP_THR2[7:0]
    isp_write(ISP_WDR_BASE+0x1F,0xFF);     // WDR_SB_BLND_BGAP_RAT0[7:0]
    isp_write(ISP_WDR_BASE+0x20,0xFF);     // WDR_SB_BLND_BGAP_RAT1[7:0]
    isp_write(ISP_WDR_BASE+0x21,0xFF);     // WDR_SB_BLND_BGAP_RAT2[7:0]

    isp_write(ISP_WDR_BASE+0x22,0x00);      // WDR_SB_BLND_DGAP_DIS[7], WDR_SB_BLND_DGAP_SIGN0[6], WDR_SB_BLND_DGAP_SIGN1[5],
    isp_write(ISP_WDR_BASE+0x23,255 );       // WDR_SB_BLND_DGAP_THR0[7:0];
    isp_write(ISP_WDR_BASE+0x24,254 );       // WDR_SB_BLND_DGAP_THR1[7:0];
    isp_write(ISP_WDR_BASE+0x25,253 );       // WDR_SB_BLND_DGAP_THR2[7:0];
    isp_write(ISP_WDR_BASE+0x26,0xFF);     // WDR_SB_BLND_DGAP_RAT0[7:0];
    isp_write(ISP_WDR_BASE+0x27,0xFF);     // WDR_SB_BLND_DGAP_RAT1[7:0];
    isp_write(ISP_WDR_BASE+0x28,0xFF);     // WDR_SB_BLND_DGAP_RAT2[7:0];

    isp_write(ISP_WDR_BASE+0x29,0xe7);     // WDR_GAIN_EN[7:0];
    isp_write(ISP_WDR_BASE+0x2A,0x00);     // WDR_GAIN00[5:3];  WDR_GAIN01[2:0];
    isp_write(ISP_WDR_BASE+0x2B,0x01);     // WDR_GAIN02[5:3];  WDR_GAIN03[2:0];
    isp_write(ISP_WDR_BASE+0x2C,0x00);     // WDR_EMIX_PATH_SEL[3:2];WDR_EMIX_WEIGHT_SEL[1:0];

    isp_write(ISP_WDR_BASE+0x2D,0x02);     // WDR_EMIX_RATIO[3:0];
    isp_write(ISP_WDR_BASE+0x2E,0x00);     // WDR_EMIX_CENTER[11:4][7:0];
    isp_write(ISP_WDR_BASE+0x2F,96  );     // WDR_EMIX_CENTER[3:0] [3:0];
    isp_write(ISP_WDR_BASE+0x30,0x00);     // WDR_EMIX_LOFFSET[7:0];
    isp_write(ISP_WDR_BASE+0x31,0x00);     // WDR_EMIX_HOFFSET[7:0];

    isp_write(ISP_WDR_BASE+0x32,0x2e);     // WDR_EMIX_BLEND_RATIO[7:4]; WDR_EMIX_SIGN1[3]; WDR_EMIX_CH[2]; WDR_EMIX_BLEND_EN[1];

    isp_write(ISP_WDR_BASE+0x33,128 );     // WDR_EMIX_THR0[7:0];
    isp_write(ISP_WDR_BASE+0x34,51  );     // WDR_EMIX_THR1[7:0];
    isp_write(ISP_WDR_BASE+0x35,8   );     // WDR_EMIX_SLOPE0[6:0];
    isp_write(ISP_WDR_BASE+0x36,2   );     // WDR_EMIX_SLOPE1[6:0];

    isp_write(ISP_WDR_BASE+0x37,0x30);     // WDR_BLD_ZERO_SEL[7]; WDR_BLD_L_RATIO[6:3]; WDR_BLD_METHOD[1];

    isp_write(ISP_WDR_BASE+0x38,0x0c);     // WDR_BLD_BLND_SEL_CH[3:2]; WDR_BLD_BASE_SEL_CH[1:0];

    isp_write(ISP_WDR_BASE+0x39,96  );     // WDR_BLD_THR0[7:0];
    isp_write(ISP_WDR_BASE+0x3A,128 );     // WDR_BLD_THR1[7:0];
    isp_write(ISP_WDR_BASE+0x3B,192 );     // WDR_BLD_THR2[7:0];
    isp_write(ISP_WDR_BASE+0x3C,4   );     // WDR_BLD_SLOPE0[6:0];
    isp_write(ISP_WDR_BASE+0x3D,12  );     // WDR_BLD_SLOPE1[6:0];
    isp_write(ISP_WDR_BASE+0x3E,16  );     // WDR_BLD_SLOPE2[6:0];

    isp_write(ISP_WDR_BASE+0x3F,0x00);     // WDR_BLD_SIGN1[7]; WDR_BLD_SIGN2[6];

    isp_write(ISP_WDR_BASE+0x40,0x00);     // WDR_BLD_HBLEND[7:0];
    isp_write(ISP_WDR_BASE+0x41,0x00);     // WDR_BLD_LBLEND[7:0];

    isp_write(ISP_WDR_BASE+0x42,0x00);     // WDR_SENSOR_EN[0];

    isp_write(ISP_WDR_BASE+0x43,0x00);     // WDR_SENSOR_SEL_L[7:4]; WDR_SENSOR_SEL_M[3:0];

    isp_write(ISP_WDR_BASE+0x44,0x00);     // WDR_SENSOR_SEL_S[3:0];

    isp_write(ISP_WDR_BASE+0x48,0x00);     // WDR_ADJ_OFFSET[12:8] [5:0];
    isp_write(ISP_WDR_BASE+0x49,0x00);     // WDR_ADJ_OFFSET[7:0]  [7:0];

    isp_write(ISP_WDR_BASE+0x50,0x00);     // WDR_HEMIX_NO_PRESET[1]; WDR_LEMIX_NO_PRESET[0];

    isp_write(ISP_WDR_BASE+0x51,0x2b);     // WDR_HEMIX_STR[7:4]; WDR_LEMIX_STR[3:0];
    isp_write(ISP_WDR_BASE+0x52,0x00);     // WDR_EMIX_HSIGY00[6:0];
    isp_write(ISP_WDR_BASE+0x53,0x00);     // WDR_EMIX_HSIGY01[6:0];
    isp_write(ISP_WDR_BASE+0x54,0x00);     // WDR_EMIX_HSIGY02[6:0];
    isp_write(ISP_WDR_BASE+0x55,0x00);     // WDR_EMIX_HSIGY03[6:0];
    isp_write(ISP_WDR_BASE+0x56,0x00);     // WDR_EMIX_HSIGY04[6:0];
    isp_write(ISP_WDR_BASE+0x57,0x00);     // WDR_EMIX_HSIGY05[6:0];
    isp_write(ISP_WDR_BASE+0x58,0x00);     // WDR_EMIX_HSIGY06[6:0];
    isp_write(ISP_WDR_BASE+0x59,0x00);     // WDR_EMIX_HSIGY07[6:0];
    isp_write(ISP_WDR_BASE+0x5A,0x00);     // WDR_EMIX_HSIGY08[6:0];
    isp_write(ISP_WDR_BASE+0x5B,0x00);     // WDR_EMIX_HSIGY09[6:0];
    isp_write(ISP_WDR_BASE+0x5C,0x00);     // WDR_EMIX_HSIGY10[6:0];
    isp_write(ISP_WDR_BASE+0x5D,0x00);     // WDR_EMIX_HSIGY11[6:0];
    isp_write(ISP_WDR_BASE+0x5E,0x00);     // WDR_EMIX_HSIGY12[6:0];
    isp_write(ISP_WDR_BASE+0x5F,0x00);     // WDR_EMIX_HSIGY13[6:0];
    isp_write(ISP_WDR_BASE+0x60,0x00);     // WDR_EMIX_HSIGY14[6:0];
    isp_write(ISP_WDR_BASE+0x61,0x00);     // WDR_EMIX_HSIGY15[6:0];
    isp_write(ISP_WDR_BASE+0x62,0x00);     // WDR_EMIX_HSIGY16[6:0];
    isp_write(ISP_WDR_BASE+0x63,0x00);     // WDR_EMIX_HSIGY17[6:0];
    isp_write(ISP_WDR_BASE+0x64,0x00);     // WDR_EMIX_HSIGY18[6:0];
    isp_write(ISP_WDR_BASE+0x65,0x00);     // WDR_EMIX_HSIGY19[6:0];
    isp_write(ISP_WDR_BASE+0x66,0x00);     // WDR_EMIX_HSIGY20[6:0];
    isp_write(ISP_WDR_BASE+0x67,0x00);     // WDR_EMIX_HSIGY21[6:0];
    isp_write(ISP_WDR_BASE+0x68,0x00);     // WDR_EMIX_HSIGY22[6:0];
    isp_write(ISP_WDR_BASE+0x69,0x00);     // WDR_EMIX_HSIGY23[6:0];

    isp_write(ISP_WDR_BASE+0x6A,0x00);     // WDR_EMIX_LSIGY00[6:0];
    isp_write(ISP_WDR_BASE+0x6B,0x00);     // WDR_EMIX_LSIGY01[6:0];
    isp_write(ISP_WDR_BASE+0x6C,0x00);     // WDR_EMIX_LSIGY02[6:0];
    isp_write(ISP_WDR_BASE+0x6D,0x00);     // WDR_EMIX_LSIGY03[6:0];
    isp_write(ISP_WDR_BASE+0x6E,0x00);     // WDR_EMIX_LSIGY04[6:0];
    isp_write(ISP_WDR_BASE+0x6F,0x00);     // WDR_EMIX_LSIGY05[6:0];
    isp_write(ISP_WDR_BASE+0x70,0x00);     // WDR_EMIX_LSIGY06[6:0];
    isp_write(ISP_WDR_BASE+0x71,0x00);     // WDR_EMIX_LSIGY07[6:0];
    isp_write(ISP_WDR_BASE+0x72,0x00);     // WDR_EMIX_LSIGY08[6:0];
    isp_write(ISP_WDR_BASE+0x73,0x00);     // WDR_EMIX_LSIGY09[6:0];
    isp_write(ISP_WDR_BASE+0x74,0x00);     // WDR_EMIX_LSIGY10[6:0];
    isp_write(ISP_WDR_BASE+0x75,0x00);     // WDR_EMIX_LSIGY11[6:0];
    isp_write(ISP_WDR_BASE+0x76,0x00);     // WDR_EMIX_LSIGY12[6:0];
    isp_write(ISP_WDR_BASE+0x77,0x00);     // WDR_EMIX_LSIGY13[6:0];
    isp_write(ISP_WDR_BASE+0x78,0x00);     // WDR_EMIX_LSIGY14[6:0];
    isp_write(ISP_WDR_BASE+0x79,0x00);     // WDR_EMIX_LSIGY15[6:0];
    isp_write(ISP_WDR_BASE+0x7A,0x00);     // WDR_EMIX_LSIGY16[6:0];
    isp_write(ISP_WDR_BASE+0x7B,0x00);     // WDR_EMIX_LSIGY17[6:0];
    isp_write(ISP_WDR_BASE+0x7C,0x00);     // WDR_EMIX_LSIGY18[6:0];
    isp_write(ISP_WDR_BASE+0x7D,0x00);     // WDR_EMIX_LSIGY19[6:0];
    isp_write(ISP_WDR_BASE+0x7E,0x00);     // WDR_EMIX_LSIGY20[6:0];
    isp_write(ISP_WDR_BASE+0x7F,0x00);     // WDR_EMIX_LSIGY21[6:0];
    isp_write(ISP_WDR_BASE+0x80,0x00);     // WDR_EMIX_LSIGY22[6:0];
    isp_write(ISP_WDR_BASE+0x81,0x00);     // WDR_EMIX_LSIGY23[6:0];

    isp_write(ISP_WDR_BASE+0x90,0x00);     // WDR_INIT_CHK[0];
}

void WDR_DOL2_set(void)
{
    isp_write(ISP_WDR_BASE+0x00,0x0d);      // WDR_ADJUST_IMG_METHOD[6], WDR_ADJUST_IMG_SEL[5], WDR_AUTO_IMG_SEL[4], WDR_ACE_SEL[3], WDR_DOL_EN[2], WDR_DOL_MODE[1], WDR_EN[0],
    isp_write(ISP_WDR_BASE+0x01,0x00);      // WDR_HALF_FRAME[7:6], WDR_DEFINE_IMG[5:4], WDR_H_SWAP[1], WDR_V_SWAP[0],
    isp_write(ISP_WDR_BASE+0x02,0x00);      // WDR_DBG_MODE[7:4], WDR_DBG_MODE_SUB[2:1], WDR_DBG_EN[0],
    isp_write(ISP_WDR_BASE+0x03,0x00);      // H_SWAP_SUB_LSC[7], V_SWAP_SUB_LSC[6], H_SWAP_SUB_AWB[5], V_SWAP_SUB_AWB[4], WDR_ADJ_EN[2],

    isp_write(ISP_WDR_BASE+0x04,0x00);      // WDR_ADJ_GAIN[14:8][6:0];
    isp_write(ISP_WDR_BASE+0x05,0x00);      // WDR_ADJ_GAIN[7:0] [7:0];
    isp_write(ISP_WDR_BASE+0x06,IN_VACT_LBFRC >> 8);        // WDR_V_SIZE[10:8]  [2:0];
    isp_write(ISP_WDR_BASE+0x07,IN_VACT_LBFRC     );               // WDR_V_SIZE[7:0]   [7:0];
    isp_write(ISP_WDR_BASE+0x08,IN_HACT_LBFRC >> 8);      // WDR_H_SIZE[10:8]  [2:0];
    isp_write(ISP_WDR_BASE+0x09,IN_HACT_LBFRC     );      // WDR_H_SIZE[7:0]   [7:0];

    isp_write(ISP_WDR_BASE+0x0A,0x8f);      // WDR_SBLUR_SIZE_CHK[7], WDR_SB_FILTER_SET[3:1], WDR_SBLUR_EN[0],

    isp_write(ISP_WDR_BASE+0x0D,0x00 );      // WDR_SB_EMIX_BGAP_DIS[7], WDR_SB_EMIX_BGAP_SIGN0[6], WDR_SB_EMIX_BGAP_SIGN1[5],
    isp_write(ISP_WDR_BASE+0x0E,128  );          // WDR_SB_EMIX_BGAP_THR0[7:0]
    isp_write(ISP_WDR_BASE+0x0F,64   );          // WDR_SB_EMIX_BGAP_THR1[7:0]
    isp_write(ISP_WDR_BASE+0x10,32   );          // WDR_SB_EMIX_BGAP_THR2[7:0]
    isp_write(ISP_WDR_BASE+0x11,0x10 );        // WDR_SB_EMIX_BGAP_RAT0[7:0]
    isp_write(ISP_WDR_BASE+0x12,0x28 );        // WDR_SB_EMIX_BGAP_RAT1[7:0]
    isp_write(ISP_WDR_BASE+0x13,0x10 );        // WDR_SB_EMIX_BGAP_RAT2[7:0]

    isp_write(ISP_WDR_BASE+0x14,0x00 );      // WDR_SB_EMIX_DGAP_DIS[7], WDR_SB_EMIX_DGAP_SIGN0[6], WDR_SB_EMIX_DGAP_SIGN1[5],
    isp_write(ISP_WDR_BASE+0x15,128  );      // WDR_SB_EMIX_DGAP_THR0[7:0];
    isp_write(ISP_WDR_BASE+0x16,64   );      // WDR_SB_EMIX_DGAP_THR1[7:0];
    isp_write(ISP_WDR_BASE+0x17,32   );      // WDR_SB_EMIX_DGAP_THR2[7:0];
    isp_write(ISP_WDR_BASE+0x18,0x10 );    // WDR_SB_EMIX_DGAP_RAT0[7:0];
    isp_write(ISP_WDR_BASE+0x19,0x18 );    // WDR_SB_EMIX_DGAP_RAT1[7:0];
    isp_write(ISP_WDR_BASE+0x1A,0x20 );    // WDR_SB_EMIX_DGAP_RAT2[7:0];

    isp_write(ISP_WDR_BASE+0x1B,0x00 );      // WDR_SB_BLND_BGAP_DIS[7], WDR_SB_BLND_BGAP_SIGN0[6], WDR_SB_BLND_BGAP_SIGN1[5],
    isp_write(ISP_WDR_BASE+0x1C,255  );       // WDR_SB_BLND_BGAP_THR0[7:0]
    isp_write(ISP_WDR_BASE+0x1D,254  );       // WDR_SB_BLND_BGAP_THR1[7:0]
    isp_write(ISP_WDR_BASE+0x1E,253  );       // WDR_SB_BLND_BGAP_THR2[7:0]
    isp_write(ISP_WDR_BASE+0x1F,0xFF );     // WDR_SB_BLND_BGAP_RAT0[7:0]
    isp_write(ISP_WDR_BASE+0x20,0xFF );     // WDR_SB_BLND_BGAP_RAT1[7:0]
    isp_write(ISP_WDR_BASE+0x21,0xFF );     // WDR_SB_BLND_BGAP_RAT2[7:0]

    isp_write(ISP_WDR_BASE+0x22,0x00 );      // WDR_SB_BLND_DGAP_DIS[7], WDR_SB_BLND_DGAP_SIGN0[6], WDR_SB_BLND_DGAP_SIGN1[5],
    isp_write(ISP_WDR_BASE+0x23,255  );       // WDR_SB_BLND_DGAP_THR0[7:0];
    isp_write(ISP_WDR_BASE+0x24,254  );       // WDR_SB_BLND_DGAP_THR1[7:0];
    isp_write(ISP_WDR_BASE+0x25,253  );       // WDR_SB_BLND_DGAP_THR2[7:0];
    isp_write(ISP_WDR_BASE+0x26,0xFF );     // WDR_SB_BLND_DGAP_RAT0[7:0];
    isp_write(ISP_WDR_BASE+0x27,0xFF );     // WDR_SB_BLND_DGAP_RAT1[7:0];
    isp_write(ISP_WDR_BASE+0x28,0xFF );     // WDR_SB_BLND_DGAP_RAT2[7:0];

    isp_write(ISP_WDR_BASE+0x29,0xe7);     // WDR_GAIN_EN[7:0];
    isp_write(ISP_WDR_BASE+0x2A,0x00);     // WDR_GAIN00[5:3];  WDR_GAIN01[2:0];
    isp_write(ISP_WDR_BASE+0x2B,0x01);     // WDR_GAIN02[5:3];  WDR_GAIN03[2:0];
    isp_write(ISP_WDR_BASE+0x2C,0x00);     // WDR_EMIX_PATH_SEL[3:2];WDR_EMIX_WEIGHT_SEL[1:0];

    isp_write(ISP_WDR_BASE+0x2D,0x02);     // WDR_EMIX_RATIO[3:0];
    isp_write(ISP_WDR_BASE+0x2E,0x00);     // WDR_EMIX_CENTER[11:4][7:0];
    isp_write(ISP_WDR_BASE+0x2F,96  );     // WDR_EMIX_CENTER[3:0] [3:0];
    isp_write(ISP_WDR_BASE+0x30,0x00);     // WDR_EMIX_LOFFSET[7:0];
    isp_write(ISP_WDR_BASE+0x31,0x00);     // WDR_EMIX_HOFFSET[7:0];

    isp_write(ISP_WDR_BASE+0x32,0x2e);     // WDR_EMIX_BLEND_RATIO[7:4]; WDR_EMIX_SIGN1[3]; WDR_EMIX_CH[2]; WDR_EMIX_BLEND_EN[1];

    isp_write(ISP_WDR_BASE+0x33,128 );     // WDR_EMIX_THR0[7:0];
    isp_write(ISP_WDR_BASE+0x34,51  );     // WDR_EMIX_THR1[7:0];
    isp_write(ISP_WDR_BASE+0x35,8   );     // WDR_EMIX_SLOPE0[6:0];
    isp_write(ISP_WDR_BASE+0x36,2   );     // WDR_EMIX_SLOPE1[6:0];

    isp_write(ISP_WDR_BASE+0x37,0x30);     // WDR_BLD_ZERO_SEL[7]; WDR_BLD_L_RATIO[6:3]; WDR_BLD_METHOD[1];

    isp_write(ISP_WDR_BASE+0x38,0x0c);     // WDR_BLD_BLND_SEL_CH[3:2]; WDR_BLD_BASE_SEL_CH[1:0];

    isp_write(ISP_WDR_BASE+0x39,96  );     // WDR_BLD_THR0[7:0];
    isp_write(ISP_WDR_BASE+0x3A,128 );     // WDR_BLD_THR1[7:0];
    isp_write(ISP_WDR_BASE+0x3B,192 );     // WDR_BLD_THR2[7:0];
    isp_write(ISP_WDR_BASE+0x3C,4   );     // WDR_BLD_SLOPE0[6:0];
    isp_write(ISP_WDR_BASE+0x3D,12  );     // WDR_BLD_SLOPE1[6:0];
    isp_write(ISP_WDR_BASE+0x3E,16  );     // WDR_BLD_SLOPE2[6:0];

    isp_write(ISP_WDR_BASE+0x3F,0x00);     // WDR_BLD_SIGN1[7]; WDR_BLD_SIGN2[6];

    isp_write(ISP_WDR_BASE+0x40,0x00);     // WDR_BLD_HBLEND[7:0];
    isp_write(ISP_WDR_BASE+0x41,0x00);     // WDR_BLD_LBLEND[7:0];

    isp_write(ISP_WDR_BASE+0x42,0x00);     // WDR_SENSOR_EN[0];

    isp_write(ISP_WDR_BASE+0x43,0x00);     // WDR_SENSOR_SEL_L[7:4]; WDR_SENSOR_SEL_M[3:0];

    isp_write(ISP_WDR_BASE+0x44,0x00);     // WDR_SENSOR_SEL_S[3:0];

    isp_write(ISP_WDR_BASE+0x48,0x00);     // WDR_ADJ_OFFSET[12:8] [5:0];
    isp_write(ISP_WDR_BASE+0x49,0x00);     // WDR_ADJ_OFFSET[7:0]  [7:0];

    isp_write(ISP_WDR_BASE+0x50,0x00);     // WDR_HEMIX_NO_PRESET[1]; WDR_LEMIX_NO_PRESET[0];

    isp_write(ISP_WDR_BASE+0x51,0x2b);     // WDR_HEMIX_STR[7:4]; WDR_LEMIX_STR[3:0];
    isp_write(ISP_WDR_BASE+0x52,0x00);     // WDR_EMIX_HSIGY00[6:0];
    isp_write(ISP_WDR_BASE+0x53,0x00);     // WDR_EMIX_HSIGY01[6:0];
    isp_write(ISP_WDR_BASE+0x54,0x00);     // WDR_EMIX_HSIGY02[6:0];
    isp_write(ISP_WDR_BASE+0x55,0x00);     // WDR_EMIX_HSIGY03[6:0];
    isp_write(ISP_WDR_BASE+0x56,0x00);     // WDR_EMIX_HSIGY04[6:0];
    isp_write(ISP_WDR_BASE+0x57,0x00);     // WDR_EMIX_HSIGY05[6:0];
    isp_write(ISP_WDR_BASE+0x58,0x00);     // WDR_EMIX_HSIGY06[6:0];
    isp_write(ISP_WDR_BASE+0x59,0x00);     // WDR_EMIX_HSIGY07[6:0];
    isp_write(ISP_WDR_BASE+0x5A,0x00);     // WDR_EMIX_HSIGY08[6:0];
    isp_write(ISP_WDR_BASE+0x5B,0x00);     // WDR_EMIX_HSIGY09[6:0];
    isp_write(ISP_WDR_BASE+0x5C,0x00);     // WDR_EMIX_HSIGY10[6:0];
    isp_write(ISP_WDR_BASE+0x5D,0x00);     // WDR_EMIX_HSIGY11[6:0];
    isp_write(ISP_WDR_BASE+0x5E,0x00);     // WDR_EMIX_HSIGY12[6:0];
    isp_write(ISP_WDR_BASE+0x5F,0x00);     // WDR_EMIX_HSIGY13[6:0];
    isp_write(ISP_WDR_BASE+0x60,0x00);     // WDR_EMIX_HSIGY14[6:0];
    isp_write(ISP_WDR_BASE+0x61,0x00);     // WDR_EMIX_HSIGY15[6:0];
    isp_write(ISP_WDR_BASE+0x62,0x00);     // WDR_EMIX_HSIGY16[6:0];
    isp_write(ISP_WDR_BASE+0x63,0x00);     // WDR_EMIX_HSIGY17[6:0];
    isp_write(ISP_WDR_BASE+0x64,0x00);     // WDR_EMIX_HSIGY18[6:0];
    isp_write(ISP_WDR_BASE+0x65,0x00);     // WDR_EMIX_HSIGY19[6:0];
    isp_write(ISP_WDR_BASE+0x66,0x00);     // WDR_EMIX_HSIGY20[6:0];
    isp_write(ISP_WDR_BASE+0x67,0x00);     // WDR_EMIX_HSIGY21[6:0];
    isp_write(ISP_WDR_BASE+0x68,0x00);     // WDR_EMIX_HSIGY22[6:0];
    isp_write(ISP_WDR_BASE+0x69,0x00);     // WDR_EMIX_HSIGY23[6:0];

    isp_write(ISP_WDR_BASE+0x6A,0x00);     // WDR_EMIX_LSIGY00[6:0];
    isp_write(ISP_WDR_BASE+0x6B,0x00);     // WDR_EMIX_LSIGY01[6:0];
    isp_write(ISP_WDR_BASE+0x6C,0x00);     // WDR_EMIX_LSIGY02[6:0];
    isp_write(ISP_WDR_BASE+0x6D,0x00);     // WDR_EMIX_LSIGY03[6:0];
    isp_write(ISP_WDR_BASE+0x6E,0x00);     // WDR_EMIX_LSIGY04[6:0];
    isp_write(ISP_WDR_BASE+0x6F,0x00);     // WDR_EMIX_LSIGY05[6:0];
    isp_write(ISP_WDR_BASE+0x70,0x00);     // WDR_EMIX_LSIGY06[6:0];
    isp_write(ISP_WDR_BASE+0x71,0x00);     // WDR_EMIX_LSIGY07[6:0];
    isp_write(ISP_WDR_BASE+0x72,0x00);     // WDR_EMIX_LSIGY08[6:0];
    isp_write(ISP_WDR_BASE+0x73,0x00);     // WDR_EMIX_LSIGY09[6:0];
    isp_write(ISP_WDR_BASE+0x74,0x00);     // WDR_EMIX_LSIGY10[6:0];
    isp_write(ISP_WDR_BASE+0x75,0x00);     // WDR_EMIX_LSIGY11[6:0];
    isp_write(ISP_WDR_BASE+0x76,0x00);     // WDR_EMIX_LSIGY12[6:0];
    isp_write(ISP_WDR_BASE+0x77,0x00);     // WDR_EMIX_LSIGY13[6:0];
    isp_write(ISP_WDR_BASE+0x78,0x00);     // WDR_EMIX_LSIGY14[6:0];
    isp_write(ISP_WDR_BASE+0x79,0x00);     // WDR_EMIX_LSIGY15[6:0];
    isp_write(ISP_WDR_BASE+0x7A,0x00);     // WDR_EMIX_LSIGY16[6:0];
    isp_write(ISP_WDR_BASE+0x7B,0x00);     // WDR_EMIX_LSIGY17[6:0];
    isp_write(ISP_WDR_BASE+0x7C,0x00);     // WDR_EMIX_LSIGY18[6:0];
    isp_write(ISP_WDR_BASE+0x7D,0x00);     // WDR_EMIX_LSIGY19[6:0];
    isp_write(ISP_WDR_BASE+0x7E,0x00);     // WDR_EMIX_LSIGY20[6:0];
    isp_write(ISP_WDR_BASE+0x7F,0x00);     // WDR_EMIX_LSIGY21[6:0];
    isp_write(ISP_WDR_BASE+0x80,0x00);     // WDR_EMIX_LSIGY22[6:0];
    isp_write(ISP_WDR_BASE+0x81,0x00);     // WDR_EMIX_LSIGY23[6:0];

    isp_write(ISP_WDR_BASE+0x90,0x00);     // WDR_INIT_CHK[0];
}

void WDR_2FR_set(void)
{
    isp_write(ISP_WDR_BASE+0x00,0x01 );      // WDR_ADJUST_IMG_METHOD[6], WDR_ADJUST_IMG_SEL[5], WDR_AUTO_IMG_SEL[4], WDR_ACE_SEL[3], WDR_DOL_EN[2], WDR_DOL_MODE[1], WDR_EN[0],
    isp_write(ISP_WDR_BASE+0x01,0x00 );      // WDR_HALF_FRAME[7:6], WDR_DEFINE_IMG[5:4], WDR_H_SWAP[1], WDR_V_SWAP[0],
    isp_write(ISP_WDR_BASE+0x02,0x00 );      // WDR_DBG_MODE[7:4], WDR_DBG_MODE_SUB[2:1], WDR_DBG_EN[0],
    isp_write(ISP_WDR_BASE+0x03,0x00 );      // H_SWAP_SUB_LSC[7], V_SWAP_SUB_LSC[6], H_SWAP_SUB_AWB[5], V_SWAP_SUB_AWB[4], WDR_ADJ_EN[2],

    isp_write(ISP_WDR_BASE+0x04,0x00 );      // WDR_ADJ_GAIN[14:8][6:0];
    isp_write(ISP_WDR_BASE+0x05,0x00 );      // WDR_ADJ_GAIN[7:0] [7:0];
    isp_write(ISP_WDR_BASE+0x06,IN_VACT_LBFRC >> 8);        // WDR_V_SIZE[10:8]  [2:0];
    isp_write(ISP_WDR_BASE+0x07,IN_VACT_LBFRC     );               // WDR_V_SIZE[7:0]   [7:0];
    isp_write(ISP_WDR_BASE+0x08,IN_HACT_LBFRC >> 8);      // WDR_H_SIZE[10:8]  [2:0];
    isp_write(ISP_WDR_BASE+0x09,IN_HACT_LBFRC     );      // WDR_H_SIZE[7:0]   [7:0];

    isp_write(ISP_WDR_BASE+0x0A,0x8f );      // WDR_SBLUR_SIZE_CHK[7], WDR_SB_FILTER_SET[3:1], WDR_SBLUR_EN[0],

    isp_write(ISP_WDR_BASE+0x0D,0x00 );      // WDR_SB_EMIX_BGAP_DIS[7], WDR_SB_EMIX_BGAP_SIGN0[6], WDR_SB_EMIX_BGAP_SIGN1[5],
    isp_write(ISP_WDR_BASE+0x0E,128  );          // WDR_SB_EMIX_BGAP_THR0[7:0]
    isp_write(ISP_WDR_BASE+0x0F,64   );          // WDR_SB_EMIX_BGAP_THR1[7:0]
    isp_write(ISP_WDR_BASE+0x10,32   );          // WDR_SB_EMIX_BGAP_THR2[7:0]
    isp_write(ISP_WDR_BASE+0x11,0x10 );        // WDR_SB_EMIX_BGAP_RAT0[7:0]
    isp_write(ISP_WDR_BASE+0x12,0x28 );        // WDR_SB_EMIX_BGAP_RAT1[7:0]
    isp_write(ISP_WDR_BASE+0x13,0x10 );        // WDR_SB_EMIX_BGAP_RAT2[7:0]

    isp_write(ISP_WDR_BASE+0x14,0x00 );      // WDR_SB_EMIX_DGAP_DIS[7], WDR_SB_EMIX_DGAP_SIGN0[6], WDR_SB_EMIX_DGAP_SIGN1[5],
    isp_write(ISP_WDR_BASE+0x15,128  );      // WDR_SB_EMIX_DGAP_THR0[7:0];
    isp_write(ISP_WDR_BASE+0x16,64   );      // WDR_SB_EMIX_DGAP_THR1[7:0];
    isp_write(ISP_WDR_BASE+0x17,32   );      // WDR_SB_EMIX_DGAP_THR2[7:0];
    isp_write(ISP_WDR_BASE+0x18,0x10 );    // WDR_SB_EMIX_DGAP_RAT0[7:0];
    isp_write(ISP_WDR_BASE+0x19,0x18 );    // WDR_SB_EMIX_DGAP_RAT1[7:0];
    isp_write(ISP_WDR_BASE+0x1A,0x20 );    // WDR_SB_EMIX_DGAP_RAT2[7:0];

    isp_write(ISP_WDR_BASE+0x1B,0x00 );      // WDR_SB_BLND_BGAP_DIS[7], WDR_SB_BLND_BGAP_SIGN0[6], WDR_SB_BLND_BGAP_SIGN1[5],
    isp_write(ISP_WDR_BASE+0x1C,255  );       // WDR_SB_BLND_BGAP_THR0[7:0]
    isp_write(ISP_WDR_BASE+0x1D,254  );       // WDR_SB_BLND_BGAP_THR1[7:0]
    isp_write(ISP_WDR_BASE+0x1E,253  );       // WDR_SB_BLND_BGAP_THR2[7:0]
    isp_write(ISP_WDR_BASE+0x1F,0xFF );     // WDR_SB_BLND_BGAP_RAT0[7:0]
    isp_write(ISP_WDR_BASE+0x20,0xFF );     // WDR_SB_BLND_BGAP_RAT1[7:0]
    isp_write(ISP_WDR_BASE+0x21,0xFF );     // WDR_SB_BLND_BGAP_RAT2[7:0]

    isp_write(ISP_WDR_BASE+0x22,0x00 );      // WDR_SB_BLND_DGAP_DIS[7], WDR_SB_BLND_DGAP_SIGN0[6], WDR_SB_BLND_DGAP_SIGN1[5],
    isp_write(ISP_WDR_BASE+0x23,255  );       // WDR_SB_BLND_DGAP_THR0[7:0];
    isp_write(ISP_WDR_BASE+0x24,254  );       // WDR_SB_BLND_DGAP_THR1[7:0];
    isp_write(ISP_WDR_BASE+0x25,253  );       // WDR_SB_BLND_DGAP_THR2[7:0];
    isp_write(ISP_WDR_BASE+0x26,0xFF );     // WDR_SB_BLND_DGAP_RAT0[7:0];
    isp_write(ISP_WDR_BASE+0x27,0xFF );     // WDR_SB_BLND_DGAP_RAT1[7:0];
    isp_write(ISP_WDR_BASE+0x28,0xFF );     // WDR_SB_BLND_DGAP_RAT2[7:0];

    isp_write(ISP_WDR_BASE+0x29,0xe7);     // WDR_GAIN_EN[7:0];
    isp_write(ISP_WDR_BASE+0x2A,0x00);     // WDR_GAIN00[5:3];  WDR_GAIN01[2:0];
    isp_write(ISP_WDR_BASE+0x2B,0x01);     // WDR_GAIN02[5:3];  WDR_GAIN03[2:0];
    isp_write(ISP_WDR_BASE+0x2C,0x00);     // WDR_EMIX_PATH_SEL[3:2];WDR_EMIX_WEIGHT_SEL[1:0];

    isp_write(ISP_WDR_BASE+0x2D,0x02);     // WDR_EMIX_RATIO[3:0];
    isp_write(ISP_WDR_BASE+0x2E,0x00);     // WDR_EMIX_CENTER[11:4][7:0];
    isp_write(ISP_WDR_BASE+0x2F,96  );     // WDR_EMIX_CENTER[3:0] [3:0];
    isp_write(ISP_WDR_BASE+0x30,0x00);     // WDR_EMIX_LOFFSET[7:0];
    isp_write(ISP_WDR_BASE+0x31,0x00);     // WDR_EMIX_HOFFSET[7:0];

    isp_write(ISP_WDR_BASE+0x32,0x2e);     // WDR_EMIX_BLEND_RATIO[7:4]; WDR_EMIX_SIGN1[3]; WDR_EMIX_CH[2]; WDR_EMIX_BLEND_EN[1];

    isp_write(ISP_WDR_BASE+0x33,128 );     // WDR_EMIX_THR0[7:0];
    isp_write(ISP_WDR_BASE+0x34,51  );     // WDR_EMIX_THR1[7:0];
    isp_write(ISP_WDR_BASE+0x35,8   );     // WDR_EMIX_SLOPE0[6:0];
    isp_write(ISP_WDR_BASE+0x36,2   );     // WDR_EMIX_SLOPE1[6:0];

    isp_write(ISP_WDR_BASE+0x37,0x30);     // WDR_BLD_ZERO_SEL[7]; WDR_BLD_L_RATIO[6:3]; WDR_BLD_METHOD[1];

    isp_write(ISP_WDR_BASE+0x38,0x0c);     // WDR_BLD_BLND_SEL_CH[3:2]; WDR_BLD_BASE_SEL_CH[1:0];

    isp_write(ISP_WDR_BASE+0x39,96  );     // WDR_BLD_THR0[7:0];
    isp_write(ISP_WDR_BASE+0x3A,128 );     // WDR_BLD_THR1[7:0];
    isp_write(ISP_WDR_BASE+0x3B,192 );     // WDR_BLD_THR2[7:0];
    isp_write(ISP_WDR_BASE+0x3C,4   );     // WDR_BLD_SLOPE0[6:0];
    isp_write(ISP_WDR_BASE+0x3D,12  );     // WDR_BLD_SLOPE1[6:0];
    isp_write(ISP_WDR_BASE+0x3E,16  );     // WDR_BLD_SLOPE2[6:0];

    isp_write(ISP_WDR_BASE+0x3F,0x00);     // WDR_BLD_SIGN1[7]; WDR_BLD_SIGN2[6];

    isp_write(ISP_WDR_BASE+0x40,0x00);     // WDR_BLD_HBLEND[7:0];
    isp_write(ISP_WDR_BASE+0x41,0x00);     // WDR_BLD_LBLEND[7:0];

    isp_write(ISP_WDR_BASE+0x42,0x00);     // WDR_SENSOR_EN[0];

    isp_write(ISP_WDR_BASE+0x43,0x00);     // WDR_SENSOR_SEL_L[7:4]; WDR_SENSOR_SEL_M[3:0];

    isp_write(ISP_WDR_BASE+0x44,0x00);     // WDR_SENSOR_SEL_S[3:0];

    isp_write(ISP_WDR_BASE+0x48,0x00);     // WDR_ADJ_OFFSET[12:8] [5:0];
    isp_write(ISP_WDR_BASE+0x49,0x00);     // WDR_ADJ_OFFSET[7:0]  [7:0];

    isp_write(ISP_WDR_BASE+0x50,0x00);     // WDR_HEMIX_NO_PRESET[1]; WDR_LEMIX_NO_PRESET[0];

    isp_write(ISP_WDR_BASE+0x51,0x2b);     // WDR_HEMIX_STR[7:4]; WDR_LEMIX_STR[3:0];
    isp_write(ISP_WDR_BASE+0x52,0x00);     // WDR_EMIX_HSIGY00[6:0];
    isp_write(ISP_WDR_BASE+0x53,0x00);     // WDR_EMIX_HSIGY01[6:0];
    isp_write(ISP_WDR_BASE+0x54,0x00);     // WDR_EMIX_HSIGY02[6:0];
    isp_write(ISP_WDR_BASE+0x55,0x00);     // WDR_EMIX_HSIGY03[6:0];
    isp_write(ISP_WDR_BASE+0x56,0x00);     // WDR_EMIX_HSIGY04[6:0];
    isp_write(ISP_WDR_BASE+0x57,0x00);     // WDR_EMIX_HSIGY05[6:0];
    isp_write(ISP_WDR_BASE+0x58,0x00);     // WDR_EMIX_HSIGY06[6:0];
    isp_write(ISP_WDR_BASE+0x59,0x00);     // WDR_EMIX_HSIGY07[6:0];
    isp_write(ISP_WDR_BASE+0x5A,0x00);     // WDR_EMIX_HSIGY08[6:0];
    isp_write(ISP_WDR_BASE+0x5B,0x00);     // WDR_EMIX_HSIGY09[6:0];
    isp_write(ISP_WDR_BASE+0x5C,0x00);     // WDR_EMIX_HSIGY10[6:0];
    isp_write(ISP_WDR_BASE+0x5D,0x00);     // WDR_EMIX_HSIGY11[6:0];
    isp_write(ISP_WDR_BASE+0x5E,0x00);     // WDR_EMIX_HSIGY12[6:0];
    isp_write(ISP_WDR_BASE+0x5F,0x00);     // WDR_EMIX_HSIGY13[6:0];
    isp_write(ISP_WDR_BASE+0x60,0x00);     // WDR_EMIX_HSIGY14[6:0];
    isp_write(ISP_WDR_BASE+0x61,0x00);     // WDR_EMIX_HSIGY15[6:0];
    isp_write(ISP_WDR_BASE+0x62,0x00);     // WDR_EMIX_HSIGY16[6:0];
    isp_write(ISP_WDR_BASE+0x63,0x00);     // WDR_EMIX_HSIGY17[6:0];
    isp_write(ISP_WDR_BASE+0x64,0x00);     // WDR_EMIX_HSIGY18[6:0];
    isp_write(ISP_WDR_BASE+0x65,0x00);     // WDR_EMIX_HSIGY19[6:0];
    isp_write(ISP_WDR_BASE+0x66,0x00);     // WDR_EMIX_HSIGY20[6:0];
    isp_write(ISP_WDR_BASE+0x67,0x00);     // WDR_EMIX_HSIGY21[6:0];
    isp_write(ISP_WDR_BASE+0x68,0x00);     // WDR_EMIX_HSIGY22[6:0];
    isp_write(ISP_WDR_BASE+0x69,0x00);     // WDR_EMIX_HSIGY23[6:0];

    isp_write(ISP_WDR_BASE+0x6A,0x00);     // WDR_EMIX_LSIGY00[6:0];
    isp_write(ISP_WDR_BASE+0x6B,0x00);     // WDR_EMIX_LSIGY01[6:0];
    isp_write(ISP_WDR_BASE+0x6C,0x00);     // WDR_EMIX_LSIGY02[6:0];
    isp_write(ISP_WDR_BASE+0x6D,0x00);     // WDR_EMIX_LSIGY03[6:0];
    isp_write(ISP_WDR_BASE+0x6E,0x00);     // WDR_EMIX_LSIGY04[6:0];
    isp_write(ISP_WDR_BASE+0x6F,0x00);     // WDR_EMIX_LSIGY05[6:0];
    isp_write(ISP_WDR_BASE+0x70,0x00);     // WDR_EMIX_LSIGY06[6:0];
    isp_write(ISP_WDR_BASE+0x71,0x00);     // WDR_EMIX_LSIGY07[6:0];
    isp_write(ISP_WDR_BASE+0x72,0x00);     // WDR_EMIX_LSIGY08[6:0];
    isp_write(ISP_WDR_BASE+0x73,0x00);     // WDR_EMIX_LSIGY09[6:0];
    isp_write(ISP_WDR_BASE+0x74,0x00);     // WDR_EMIX_LSIGY10[6:0];
    isp_write(ISP_WDR_BASE+0x75,0x00);     // WDR_EMIX_LSIGY11[6:0];
    isp_write(ISP_WDR_BASE+0x76,0x00);     // WDR_EMIX_LSIGY12[6:0];
    isp_write(ISP_WDR_BASE+0x77,0x00);     // WDR_EMIX_LSIGY13[6:0];
    isp_write(ISP_WDR_BASE+0x78,0x00);     // WDR_EMIX_LSIGY14[6:0];
    isp_write(ISP_WDR_BASE+0x79,0x00);     // WDR_EMIX_LSIGY15[6:0];
    isp_write(ISP_WDR_BASE+0x7A,0x00);     // WDR_EMIX_LSIGY16[6:0];
    isp_write(ISP_WDR_BASE+0x7B,0x00);     // WDR_EMIX_LSIGY17[6:0];
    isp_write(ISP_WDR_BASE+0x7C,0x00);     // WDR_EMIX_LSIGY18[6:0];
    isp_write(ISP_WDR_BASE+0x7D,0x00);     // WDR_EMIX_LSIGY19[6:0];
    isp_write(ISP_WDR_BASE+0x7E,0x00);     // WDR_EMIX_LSIGY20[6:0];
    isp_write(ISP_WDR_BASE+0x7F,0x00);     // WDR_EMIX_LSIGY21[6:0];
    isp_write(ISP_WDR_BASE+0x80,0x00);     // WDR_EMIX_LSIGY22[6:0];
    isp_write(ISP_WDR_BASE+0x81,0x00);     // WDR_EMIX_LSIGY23[6:0];

    isp_write(ISP_WDR_BASE+0x90,0x00);     // WDR_INIT_CHK[0];
}

