#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../system/system.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_prompt.h"

#include "../include/ansi.h"
#include "../drivers/ddr.h"

#include "../tdk/tdk_util.h"
#include "../include/vdump.h"

#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

void dumpif_enable()
{

#ifdef IN_IMAGE_1280X720_60P
    #ifdef DS_320X240
        // CROP
        reg_write(VDUMP_BASE_ADDR | 0x0040, 0x00010101); // s0_vdump_crop_sync_en = 1'd1;s0_vdump_crop_data_en = 1'd1;s0_vdump_crop_vsync_regen_en = 1'd1;
        reg_write(VDUMP_BASE_ADDR | 0x0044, 0x00000000); // s0_vdump_crop_hde_st_pos  = 12'd0; s0_vdump_crop_hblk_line_ref  = 12'd0;
        reg_write(VDUMP_BASE_ADDR | 0x004C, 0x000004FF); // s0_vdump_crop_vde_st_pos  = 12'd0; s0_vdump_crop_hde_end_pos = 12'd1279;
        reg_write(VDUMP_BASE_ADDR | 0x0054, 0x000002D0); // s0_vdump_crop_vde_end_pos = 12'd720;
        // LPF
        reg_write(VDUMP_BASE_ADDR | 0x0100, 0x000000FF); // I_IN_HACT_SIZE = 8'hFF; (Dec: 1279)
        reg_write(VDUMP_BASE_ADDR | 0x0101, 0x00000400); // I_IN_HACT_SIZE = 8'h04;
        reg_write(VDUMP_BASE_ADDR | 0x0102, 0x00730000); // I_IN_HBLK_SIZE = 8'h73; (Dec: 1650-1279 = 371)
        reg_write(VDUMP_BASE_ADDR | 0x0103, 0x01000000); // I_IN_HBLK_SIZE = 8'h01; 
        reg_write(VDUMP_BASE_ADDR | 0x0104, 0x000000D0); // I_IN_VACT_SIZE = 8'hD0; (Dec: 720)
        reg_write(VDUMP_BASE_ADDR | 0x0105, 0x00000200); // I_IN_VACT_SIZE = 8'h02;
        // DS
        reg_write(VDUMP_BASE_ADDR | 0x0119, 0x0000CC00); // I_H_DTO = IN_HACT_SIZE(1279) / OUT_HACT_SIZE(320) * 16384
        reg_write(VDUMP_BASE_ADDR | 0x011A, 0x00FF0000); // I_H_DTO
        reg_write(VDUMP_BASE_ADDR | 0x011B, 0x00000000); // I_V_DTO = IN_VACT_SIZE(720) / OUT_VACT_SIZE(240) * 16384
        reg_write(VDUMP_BASE_ADDR | 0x011C, 0x000000C0); // I_V_DTO 
        reg_write(VDUMP_BASE_ADDR | 0x011D, 0x00004000); // I_OUT_HACT_SIZE (Dec: 320) (Hex: 140)
        reg_write(VDUMP_BASE_ADDR | 0x011E, 0x00010000); // I_OUT_HACT_SIZE 
        reg_write(VDUMP_BASE_ADDR | 0x011F, 0xF0000000); // I_OUT_VACT_SIZE (Dec: 240) (Hex: F0)
        reg_write(VDUMP_BASE_ADDR | 0x0120, 0x00000000); // I_OUT_VACT_SIZE
    #elif DS_318X240
        // CROP
        reg_write(VDUMP_BASE_ADDR | 0x0040, 0x00010101); // s0_vdump_crop_sync_en = 1'd1;s0_vdump_crop_data_en = 1'd1;s0_vdump_crop_vsync_regen_en = 1'd1;
        reg_write(VDUMP_BASE_ADDR | 0x0044, 0x00000000); // s0_vdump_crop_hde_st_pos  = 12'd0; s0_vdump_crop_hblk_line_ref  = 12'd0;
        reg_write(VDUMP_BASE_ADDR | 0x004C, 0x000004F7); // s0_vdump_crop_vde_st_pos  = 12'd0; s0_vdump_crop_hde_end_pos = 12'd1271;
        reg_write(VDUMP_BASE_ADDR | 0x0054, 0x000002D0); // s0_vdump_crop_vde_end_pos = 12'd720;
        // LPF
        reg_write(VDUMP_BASE_ADDR | 0x0100, 0x000000F7); // I_IN_HACT_SIZE = 8'hF7; (Dec: 1271)
        reg_write(VDUMP_BASE_ADDR | 0x0101, 0x00000400); // I_IN_HACT_SIZE = 8'h04;
        reg_write(VDUMP_BASE_ADDR | 0x0102, 0x007B0000); // I_IN_HBLK_SIZE = 8'h7B; (Dec: 1650-1271 = 379)
        reg_write(VDUMP_BASE_ADDR | 0x0103, 0x01000000); // I_IN_HBLK_SIZE = 8'h01; 
        reg_write(VDUMP_BASE_ADDR | 0x0104, 0x000000D0); // I_IN_VACT_SIZE = 8'hD0; (Dec: 720)
        reg_write(VDUMP_BASE_ADDR | 0x0105, 0x00000200); // I_IN_VACT_SIZE = 8'h02;
        // DS
        reg_write(VDUMP_BASE_ADDR | 0x0119, 0x0000CC00); // I_H_DTO = IN_HACT_SIZE(1271) / OUT_HACT_SIZE(318) * 16384
        reg_write(VDUMP_BASE_ADDR | 0x011A, 0x00FF0000); // I_H_DTO
        reg_write(VDUMP_BASE_ADDR | 0x011B, 0x00000000); // I_V_DTO = IN_VACT_SIZE(720) / OUT_VACT_SIZE(240) * 16384
        reg_write(VDUMP_BASE_ADDR | 0x011C, 0x000000C0); // I_V_DTO 
        reg_write(VDUMP_BASE_ADDR | 0x011D, 0x00003E00); // I_OUT_HACT_SIZE (Dec: 318) (Hex: 13E)
        reg_write(VDUMP_BASE_ADDR | 0x011E, 0x00010000); // I_OUT_HACT_SIZE 
        reg_write(VDUMP_BASE_ADDR | 0x011F, 0xF0000000); // I_OUT_VACT_SIZE (Dec: 240) (Hex: F0)
        reg_write(VDUMP_BASE_ADDR | 0x0120, 0x00000000); // I_OUT_VACT_SIZE
    #elif DS_316X240
        // CROP
        reg_write(VDUMP_BASE_ADDR | 0x0040, 0x00000000); // s0_vdump_crop_data_en = 1'd1;
        reg_write(VDUMP_BASE_ADDR | 0x0040, 0x00010101); // s0_vdump_crop_sync_en = 1'd1;s0_vdump_crop_data_en = 1'd1;s0_vdump_crop_vsync_regen_en = 1'd1;
        reg_write(VDUMP_BASE_ADDR | 0x0044, 0x00000000); // s0_vdump_crop_hde_st_pos  = 12'd0; s0_vdump_crop_hblk_line_ref  = 12'd0;
        reg_write(VDUMP_BASE_ADDR | 0x004C, 0x000004EF); // s0_vdump_crop_vde_st_pos  = 12'd0; s0_vdump_crop_hde_end_pos = 12'd1263;
        reg_write(VDUMP_BASE_ADDR | 0x0054, 0x000002D0); // s0_vdump_crop_vde_end_pos = 12'd720;
        // LPF
        reg_write(VDUMP_BASE_ADDR | 0x0100, 0x000000EF); // I_IN_HACT_SIZE = 8'hEF; (Dec: 1263)
        reg_write(VDUMP_BASE_ADDR | 0x0101, 0x00000400); // I_IN_HACT_SIZE = 8'h04;
        reg_write(VDUMP_BASE_ADDR | 0x0102, 0x00830000); // I_IN_HBLK_SIZE = 8'h83; (Dec: 1650-1263 = 387)
        reg_write(VDUMP_BASE_ADDR | 0x0103, 0x01000000); // I_IN_HBLK_SIZE = 8'h01; 
        reg_write(VDUMP_BASE_ADDR | 0x0104, 0x000000D0); // I_IN_VACT_SIZE = 8'hD0; (Dec: 720)
        reg_write(VDUMP_BASE_ADDR | 0x0105, 0x00000200); // I_IN_VACT_SIZE = 8'h02;
        // DS
        reg_write(VDUMP_BASE_ADDR | 0x0119, 0x0000CC00); // I_H_DTO = IN_HACT_SIZE(1263) / OUT_HACT_SIZE(316) * 16384
        reg_write(VDUMP_BASE_ADDR | 0x011A, 0x00FF0000); // I_H_DTO
        reg_write(VDUMP_BASE_ADDR | 0x011B, 0x00000000); // I_V_DTO = IN_VACT_SIZE(720) / OUT_VACT_SIZE(240) * 16384
        reg_write(VDUMP_BASE_ADDR | 0x011C, 0x000000C0); // I_V_DTO 
        reg_write(VDUMP_BASE_ADDR | 0x011D, 0x00003C00); // I_OUT_HACT_SIZE (Dec: 316) (Hex: 13C)
        reg_write(VDUMP_BASE_ADDR | 0x011E, 0x00010000); // I_OUT_HACT_SIZE 
        reg_write(VDUMP_BASE_ADDR | 0x011F, 0xF0000000); // I_OUT_VACT_SIZE (Dec: 240) (Hex: F0)
        reg_write(VDUMP_BASE_ADDR | 0x0120, 0x00000000); // I_OUT_VACT_SIZE
    #elif DS_314X240
        // CROP
        reg_write(VDUMP_BASE_ADDR | 0x0040, 0x00000000); // s0_vdump_crop_data_en = 1'd1;
        reg_write(VDUMP_BASE_ADDR | 0x0040, 0x00010101); // s0_vdump_crop_sync_en = 1'd1;s0_vdump_crop_data_en = 1'd1;s0_vdump_crop_vsync_regen_en = 1'd1;
        reg_write(VDUMP_BASE_ADDR | 0x0044, 0x00000000); // s0_vdump_crop_hde_st_pos  = 12'd0; s0_vdump_crop_hblk_line_ref  = 12'd0;
        reg_write(VDUMP_BASE_ADDR | 0x004C, 0x000004E7); // s0_vdump_crop_vde_st_pos  = 12'd0; s0_vdump_crop_hde_end_pos = 12'd1255;
        reg_write(VDUMP_BASE_ADDR | 0x0054, 0x000002D0); // s0_vdump_crop_vde_end_pos = 12'd720;
        // LPF
        reg_write(VDUMP_BASE_ADDR | 0x0100, 0x000000E7); // I_IN_HACT_SIZE = 8'hE7; (Dec: 1255)
        reg_write(VDUMP_BASE_ADDR | 0x0101, 0x00000400); // I_IN_HACT_SIZE = 8'h04;
        reg_write(VDUMP_BASE_ADDR | 0x0102, 0x008B0000); // I_IN_HBLK_SIZE = 8'h8B; (Dec: 1650-1255 = 395)
        reg_write(VDUMP_BASE_ADDR | 0x0103, 0x01000000); // I_IN_HBLK_SIZE = 8'h01; 
        reg_write(VDUMP_BASE_ADDR | 0x0104, 0x000000D0); // I_IN_VACT_SIZE = 8'hD0; (Dec: 720)
        reg_write(VDUMP_BASE_ADDR | 0x0105, 0x00000200); // I_IN_VACT_SIZE = 8'h02;
        // DS
        reg_write(VDUMP_BASE_ADDR | 0x0119, 0x0000CB00); // I_H_DTO = IN_HACT_SIZE(1255) / OUT_HACT_SIZE(314) * 16384
        reg_write(VDUMP_BASE_ADDR | 0x011A, 0x00FF0000); // I_H_DTO
        reg_write(VDUMP_BASE_ADDR | 0x011B, 0x00000000); // I_V_DTO = IN_VACT_SIZE(720) / OUT_VACT_SIZE(240) * 16384
        reg_write(VDUMP_BASE_ADDR | 0x011C, 0x000000C0); // I_V_DTO 
        reg_write(VDUMP_BASE_ADDR | 0x011D, 0x00003A00); // I_OUT_HACT_SIZE (Dec: 314) (Hex: 13A)
        reg_write(VDUMP_BASE_ADDR | 0x011E, 0x00010000); // I_OUT_HACT_SIZE 
        reg_write(VDUMP_BASE_ADDR | 0x011F, 0xF0000000); // I_OUT_VACT_SIZE (Dec: 240) (Hex: F0)
        reg_write(VDUMP_BASE_ADDR | 0x0120, 0x00000000); // I_OUT_VACT_SIZE
    #elif DS_312X240
        // CROP
        reg_write(VDUMP_BASE_ADDR | 0x0040, 0x00000000); // s0_vdump_crop_data_en = 1'd1;
        reg_write(VDUMP_BASE_ADDR | 0x0040, 0x00010101); // s0_vdump_crop_sync_en = 1'd1;s0_vdump_crop_data_en = 1'd1;s0_vdump_crop_vsync_regen_en = 1'd1;
        reg_write(VDUMP_BASE_ADDR | 0x0044, 0x00000000); // s0_vdump_crop_hde_st_pos  = 12'd0; s0_vdump_crop_hblk_line_ref  = 12'd0;
        reg_write(VDUMP_BASE_ADDR | 0x004C, 0x000004DF); // s0_vdump_crop_vde_st_pos  = 12'd0; s0_vdump_crop_hde_end_pos = 12'd1247;
        reg_write(VDUMP_BASE_ADDR | 0x0054, 0x000002D0); // s0_vdump_crop_vde_end_pos = 12'd720;
        // LPF
        reg_write(VDUMP_BASE_ADDR | 0x0100, 0x000000DF); // I_IN_HACT_SIZE = 8'hDF; (Dec: 1247)
        reg_write(VDUMP_BASE_ADDR | 0x0101, 0x00000400); // I_IN_HACT_SIZE = 8'h04;
        reg_write(VDUMP_BASE_ADDR | 0x0102, 0x00930000); // I_IN_HBLK_SIZE = 8'h93; (Dec: 1650-1247 = 403)
        reg_write(VDUMP_BASE_ADDR | 0x0103, 0x01000000); // I_IN_HBLK_SIZE = 8'h01; 
        reg_write(VDUMP_BASE_ADDR | 0x0104, 0x000000D0); // I_IN_VACT_SIZE = 8'hD0; (Dec: 720)
        reg_write(VDUMP_BASE_ADDR | 0x0105, 0x00000200); // I_IN_VACT_SIZE = 8'h02;
        // DS
        reg_write(VDUMP_BASE_ADDR | 0x0119, 0x0000CB00); // I_H_DTO = IN_HACT_SIZE(1247) / OUT_HACT_SIZE(312) * 16384
        reg_write(VDUMP_BASE_ADDR | 0x011A, 0x00FF0000); // I_H_DTO
        reg_write(VDUMP_BASE_ADDR | 0x011B, 0x00000000); // I_V_DTO = IN_VACT_SIZE(720) / OUT_VACT_SIZE(240) * 16384
        reg_write(VDUMP_BASE_ADDR | 0x011C, 0x000000C0); // I_V_DTO 
        reg_write(VDUMP_BASE_ADDR | 0x011D, 0x00003800); // I_OUT_HACT_SIZE (Dec: 312) (Hex: 138)
        reg_write(VDUMP_BASE_ADDR | 0x011E, 0x00010000); // I_OUT_HACT_SIZE 
        reg_write(VDUMP_BASE_ADDR | 0x011F, 0xF0000000); // I_OUT_VACT_SIZE (Dec: 240) (Hex: F0)
        reg_write(VDUMP_BASE_ADDR | 0x0120, 0x00000000); // I_OUT_VACT_SIZE
    #elif DS_320x180 // CROP OUT : 1279x719
        // CROP
        reg_write(VDUMP_BASE_ADDR | 0x0040, 0x00000000); // s0_vdump_crop_data_en = 1'd1;
        reg_write(VDUMP_BASE_ADDR | 0x0040, 0x00010101); // s0_vdump_crop_sync_en = 1'd1;s0_vdump_crop_data_en = 1'd1;s0_vdump_crop_vsync_regen_en = 1'd1;
        reg_write(VDUMP_BASE_ADDR | 0x0044, 0x00000000); // s0_vdump_crop_hde_st_pos  = 12'd0; s0_vdump_crop_hblk_line_ref  = 12'd0;
        reg_write(VDUMP_BASE_ADDR | 0x004C, 0x000004FF); // s0_vdump_crop_vde_st_pos  = 12'd0; s0_vdump_crop_hde_end_pos = 12'd1279;
        reg_write(VDUMP_BASE_ADDR | 0x0054, 0x000002CF); // s0_vdump_crop_vde_end_pos = 12'd719;
        // LPF
        reg_write(VDUMP_BASE_ADDR | 0x0100, 0x000000FF); // I_IN_HACT_SIZE = 8'hFF; (Dec: 1279)
        reg_write(VDUMP_BASE_ADDR | 0x0101, 0x00000400); // I_IN_HACT_SIZE = 8'h04;
        reg_write(VDUMP_BASE_ADDR | 0x0102, 0x00730000); // I_IN_HBLK_SIZE = 8'h73; (Dec: 1650-1279 = 371)
        reg_write(VDUMP_BASE_ADDR | 0x0103, 0x01000000); // I_IN_HBLK_SIZE = 8'h01; 
        reg_write(VDUMP_BASE_ADDR | 0x0104, 0x000000CF); // I_IN_VACT_SIZE = 8'hCF; (Dec: 719)
        reg_write(VDUMP_BASE_ADDR | 0x0105, 0x00000200); // I_IN_VACT_SIZE = 8'h02;
        // DS
        reg_write(VDUMP_BASE_ADDR | 0x0119, 0x0000CC00); // I_H_DTO = IN_HACT_SIZE(1279) / OUT_HACT_SIZE(320) * 16384
        reg_write(VDUMP_BASE_ADDR | 0x011A, 0x00FF0000); // I_H_DTO
        reg_write(VDUMP_BASE_ADDR | 0x011B, 0xA4000000); // I_V_DTO = IN_VACT_SIZE(719) / OUT_VACT_SIZE(180) * 16384
        reg_write(VDUMP_BASE_ADDR | 0x011C, 0x000000FF); // I_V_DTO 
        reg_write(VDUMP_BASE_ADDR | 0x011D, 0x00004000); // I_OUT_HACT_SIZE (Dec: 320) (Hex: 140)
        reg_write(VDUMP_BASE_ADDR | 0x011E, 0x00010000); // I_OUT_HACT_SIZE 
        reg_write(VDUMP_BASE_ADDR | 0x011F, 0xB4000000); // I_OUT_VACT_SIZE (Dec: 180) (Hex: B4)
        reg_write(VDUMP_BASE_ADDR | 0x0120, 0x00000000); // I_OUT_VACT_SIZE
    #else
        reg_write(VDUMP_BASE_ADDR | 0x0040, 0x00000000); // s0_vdump_crop_data_en = 1'd0;
#endif
    // LPF
    reg_write(VDUMP_BASE_ADDR | 0x0106, 0x00210000); // I_DS_BYPASS = 1'b0; I_LPF_YEN=1'b1; I_LPF_CEN=1'b0; I_LPF_EN =1'b1;
    reg_write(VDUMP_BASE_ADDR | 0x0107, 0x80000000); // {I_PRE_REG_EN,I_IN_SIZE_CUSTOM,I_DS_METHOD_Y,I_DS_METHOD_C,I_TABLE_SEL_Y,I_TABLE_SEL_C} = 8'h0;
    reg_write(VDUMP_BASE_ADDR | 0x0108, 0x00000001); // I_LPF_Y_ALPHA = 8'h1;
    reg_write(VDUMP_BASE_ADDR | 0x010F, 0xCF000000); // I_LPF_COF11 0.204179955571658    (0xCF)
    reg_write(VDUMP_BASE_ADDR | 0x0110, 0x00000000); // I_LPF_COF11
    reg_write(VDUMP_BASE_ADDR | 0x0111, 0x00007F00); // I_LPF_COF12 0.123841403152973    (0x7F)
    reg_write(VDUMP_BASE_ADDR | 0x0112, 0x00000000); // I_LPF_COF12
    reg_write(VDUMP_BASE_ADDR | 0x0115, 0x00007F00); // I_LPF_COF21 0.123841403152973    (0x7F)
    reg_write(VDUMP_BASE_ADDR | 0x0116, 0x00000000); // I_LPF_COF21 
    reg_write(VDUMP_BASE_ADDR | 0x0117, 0x4D000000); // I_LPF_COF22 0.0751136079541114   (0x4D)
    reg_write(VDUMP_BASE_ADDR | 0x0118, 0x00000000); // I_LPF_COF22
#else
#endif
    // RGB2RGB
    reg_write(VDUMP_BASE_ADDR | 0x0201, 0x0000bb00); // CSC_R_R_GAIN_fs = 12'hbb;
    reg_write(VDUMP_BASE_ADDR | 0x0202, 0x00000000); // CSC_R_R_GAIN_fs = 12'hbb;
    reg_write(VDUMP_BASE_ADDR | 0x0203, 0x07500000); // CSC_R_G_GAIN_fs = 12'h275;
    reg_write(VDUMP_BASE_ADDR | 0x0204, 0x00000002); // CSC_R_G_GAIN_fs = 12'h275;
    reg_write(VDUMP_BASE_ADDR | 0x0205, 0x00003f00); // CSC_R_B_GAIN_fs = 12'h3f;
    reg_write(VDUMP_BASE_ADDR | 0x0206, 0x00000000); // CSC_R_B_GAIN_fs = 12'h3f;
    reg_write(VDUMP_BASE_ADDR | 0x0208, 0x00000068); // CSC_G_R_GAIN_fs = 12'h68;
    reg_write(VDUMP_BASE_ADDR | 0x0209, 0x00000000); // CSC_G_R_GAIN_fs = 12'h68;
    reg_write(VDUMP_BASE_ADDR | 0x020A, 0x005a0000); // CSC_G_G_GAIN_fs = 12'h15a;
    reg_write(VDUMP_BASE_ADDR | 0x020B, 0x01000000); // CSC_G_G_GAIN_fs = 12'h15a;
    reg_write(VDUMP_BASE_ADDR | 0x020C, 0x000000c2); // CSC_G_B_GAIN_fs = 12'h1c2;
    reg_write(VDUMP_BASE_ADDR | 0x020D, 0x00000100); // CSC_G_B_GAIN_fs = 12'h1c2;
    reg_write(VDUMP_BASE_ADDR | 0x020F, 0xc2000000); // CSC_B_R_GAIN_fs = 12'h1c2;
    reg_write(VDUMP_BASE_ADDR | 0x0210, 0x00000001); // CSC_B_R_GAIN_fs = 12'h1c2;
    reg_write(VDUMP_BASE_ADDR | 0x0211, 0x00009900); // CSC_B_G_GAIN_fs = 12'h199;
    reg_write(VDUMP_BASE_ADDR | 0x0212, 0x00010000); // CSC_B_G_GAIN_fs = 12'h199;
    reg_write(VDUMP_BASE_ADDR | 0x0213, 0x29000000); // CSC_B_B_GAIN_fs = 12'h29;
    reg_write(VDUMP_BASE_ADDR | 0x0214, 0x00000000); // CSC_B_B_GAIN_fs = 12'h29;


}
