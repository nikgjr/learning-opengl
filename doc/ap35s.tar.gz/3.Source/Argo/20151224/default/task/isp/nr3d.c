#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"
void NR3D_set(void)
{
    unsigned int DNR_RB_IMG_WLINE, DNR_WB_IMG_WLINE;

    isp_write(ISP_NR3D_BASE+0x00,0xc6);  // {DNR_MD_SEL[7:6],DNR_REG_SEL[5:4],DNR_REG_MODE[3],DNR_H_SWAP[2],DNR_V_SWAP[1],DNR_EN[0]};
    isp_write(ISP_NR3D_BASE+0x01,0x27);  // {DNR_ADJ_EN[7],1'd0,DNR_SEL_G_DLY,NR3D_RB_NOSYNC,1'd0,DNR_MD_MODE[2:1],DNR_MANUAL_SET};
    isp_write(ISP_NR3D_BASE+0x03,0x03);  // {DNR_MANUAL_TH[9:8],DNR_MANUAL_CTH[9:8]}
    isp_write(ISP_NR3D_BASE+0x02,0x44);  // {DNR_MANUAL_TH[7:0]}
    isp_write(ISP_NR3D_BASE+0x0A,0xC0);  // {DNR_MANUAL_LPF_ALPHA}
//  isp_write(ISP_NR3D_BASE+0x0C,0x00);  // {DNR_MANUAL_HPF_ALPHA}
//  isp_write(ISP_NR3D_BASE+0x0B,0x00);  // {DNR_MANUAL_C_ALPHA}
//  isp_write(ISP_NR3D_BASE+0x0D,0x00);  // {DNR_MANUAL_M_ALPHA}
//  isp_write(ISP_NR3D_BASE+0x0F,0x00);  // {DNR_MANUAL_D_ALPHA}
//  isp_write(ISP_NR3D_BASE+0x11,0x00);  // {DNR_MANUAL_STH[1:0]}
//  isp_write(ISP_NR3D_BASE+0x13,0x00);  // {DNR_MANUAL_STH[7:0]}
    isp_write(ISP_NR3D_BASE+0x14,0x10);  // {DNR_MANUAL_SLV[4:0]}
//  isp_write(ISP_NR3D_BASE+0x15,0x00);  // {DNR_DSP_MODE[7:0]}
    isp_write(ISP_NR3D_BASE+0x93,0x0a);  // { 2'h0, O_DNR_NUM_MT_RTH[5:0] };
    isp_write(ISP_NR3D_BASE+0x94,0x0a);  // { 2'h0, O_DNR_NUM_MT_GTH[5:0] };
    isp_write(ISP_NR3D_BASE+0x95,0x0a);  // { 2'h0, O_DNR_NUM_MT_BTH[5:0] };
    isp_write(ISP_NR3D_BASE+0x96,0x40);  // { O_DNR_DMT_MAX[9:2] };
    isp_write(ISP_NR3D_BASE+0x97,0x40);  // { O_DNR_DMT_R_MAX[9:2] };
    isp_write(ISP_NR3D_BASE+0x98,0x40);  // { O_DNR_DMT_G_MAX[9:2] };
    isp_write(ISP_NR3D_BASE+0x99,0x40);  // { O_DNR_DMT_B_MAX[9:2] };
    isp_write(ISP_NR3D_BASE+0xA2,0x33);  // { 2'h0, O_DNR_PIX_DIF_IIR, O_DNR_ADP_FIL_EN, 1'd0, O_DNR_ADP_FIL_SIZE[2:0]};
    isp_write(ISP_NR3D_BASE+0x05,0x00);  // { 2'h0, O_DNR_MANUAL_RTH[9:8], G, B}
    isp_write(ISP_NR3D_BASE+0x04,0x10);  // { O_DNR_MANUAL_RTH[7:0]}
    isp_write(ISP_NR3D_BASE+0x06,0x10);  // { O_DNR_MANUAL_GTH[7:0]}
    isp_write(ISP_NR3D_BASE+0x08,0x10);  // { O_DNR_MANUAL_BTH[7:0]}

//  isp_write(ISP_NR3D_BASE+0x21,0x00);  // table
//  isp_write(ISP_NR3D_BASE+0x29,0x00);  //
    isp_write(ISP_NR3D_BASE+0x20,0x08);  //
    isp_write(ISP_NR3D_BASE+0x22,0x0F);  //
    isp_write(ISP_NR3D_BASE+0x24,0x30);  //
    isp_write(ISP_NR3D_BASE+0x26,0x30);  //
    isp_write(ISP_NR3D_BASE+0x28,0x30);  //
    isp_write(ISP_NR3D_BASE+0x2A,0x30);  //
    isp_write(ISP_NR3D_BASE+0x2C,0x30);  //
//  isp_write(ISP_NR3D_BASE+0x2E,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x31,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x39,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x30,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x32,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x34,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x36,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x38,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x3A,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x3C,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x3E,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x60,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x61,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x62,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x63,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x64,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x65,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x66,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x67,0x00);  //
    isp_write(ISP_NR3D_BASE+0x41,0x50);  //
//  isp_write(ISP_NR3D_BASE+0x49,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x40,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x42,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x44,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x46,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x48,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x4A,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x4C,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x4E,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x51,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x59,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x50,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x52,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x54,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x56,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x58,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x5A,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x5C,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x5E,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x69,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x6B,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x6D,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x6E,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x71,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x70,0x00);  //
    isp_write(ISP_NR3D_BASE+0x72,0x09);  //
    isp_write(ISP_NR3D_BASE+0x74,0x10);  //
    isp_write(ISP_NR3D_BASE+0x76,0x10);  //
    isp_write(ISP_NR3D_BASE+0x79,0x10);  //
    isp_write(ISP_NR3D_BASE+0x78,0x3E);  //
//  isp_write(ISP_NR3D_BASE+0x7A,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x7C,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x7E,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x81,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x80,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x82,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x84,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x86,0x00);  //
//  isp_write(ISP_NR3D_BASE+0x89,0x00);  //
    isp_write(ISP_NR3D_BASE+0x88,0x0A);  //
//  isp_write(ISP_NR3D_BASE+0x8A,0x00);  //
    isp_write(ISP_NR3D_BASE+0x8C,0x13);  //
//  isp_write(ISP_NR3D_BASE+0x8E,0x00);  //

    isp_write(ISP_NR3D_BASE+0x90,0x20);  // {2'd0, DNR_DISP_LPF_TYPE[1:0],1'd0,1'd0,DNR_FRC_DISP_EN[1],DNR_DEBUG_DISP[0]}
    isp_write(ISP_NR3D_BASE+0x91,0xFF);  //
    isp_write(ISP_NR3D_BASE+0x92,0x0A);  // {DNR_MT_NUM_YTH[5:0]}
    isp_write(ISP_NR3D_BASE+0xA0,0x04);  // DNR_GAMMA_ALPHA[7:3],DNR_GAMMA_EN[2],1'd0,DNR_IIR_SMTH_NMT_EN[0]};

#if(DNR_EN == ON)
    // WLINE = ROUND(VLINE * 2.1)
    // DNR_RB_IMG_WLINE = (unsigned int)(OUT_VACT * 2.1 + 0.9);
    // DNR_WB_IMG_WLINE = (unsigned int)(OUT_VACT * 2.1 + 0.9);
    DNR_RB_IMG_WLINE = (unsigned int)((FRC_VACT+16) * 2);
    DNR_WB_IMG_WLINE = (unsigned int)((FRC_VACT+16) * 2);
#else
    DNR_RB_IMG_WLINE = (unsigned int)(FRC_VACT);
    DNR_WB_IMG_WLINE = (unsigned int)(FRC_VACT);
#endif

//  isp_write(0x09B5,0x00;                              // {DNR_RB_PRI_SET[6:4],1'b0,DNR_RB_PRI_MODE[1:0]}
    isp_write(ISP_NR3D_BASE+0xB7,FRC_HACT >> 8);            // DNR_RB_IMG_HPIXEL[10:8]
    isp_write(ISP_NR3D_BASE+0xB6,FRC_HACT     );                   // DNR_RB_IMG_HPIXEL[7:0]
    isp_write(ISP_NR3D_BASE+0xB9,FRC_VACT >> 8);            // DNR_RB_IMG_VLINE[10:8]
    isp_write(ISP_NR3D_BASE+0xB8,FRC_VACT     );                   // DNR_RB_IMG_VLINE[7:0]
    isp_write(ISP_NR3D_BASE+0xBB,DNR_RB_IMG_WLINE >> 8);    // DNR_RB_IMG_WLINE[12:8]
    isp_write(ISP_NR3D_BASE+0xBA,DNR_RB_IMG_WLINE     );           // DNR_RB_IMG_WLINE[7:0]
    isp_write(ISP_NR3D_BASE+0xBC,0x05);                              // DNR_RB_BURST_CTRL[3:0]

    isp_write(ISP_NR3D_BASE+0xC7,DNR_BASE_ADDR >> 24);      // DNR_WB_WRITE_ADDR[31:24]
    isp_write(ISP_NR3D_BASE+0xC6,DNR_BASE_ADDR >> 16);      // DNR_WB_WRITE_ADDR[23:16]
    isp_write(ISP_NR3D_BASE+0xC5,DNR_BASE_ADDR >> 8);       // DNR_WB_WRITE_ADDR[15:8]
    isp_write(ISP_NR3D_BASE+0xC4,DNR_BASE_ADDR);            // DNR_WB_WRITE_ADDR[7:0]
    isp_write(ISP_NR3D_BASE+0xC9,FRC_HACT >> 8);            // DNR_WB_LINE_WIDTH[12:8]
    isp_write(ISP_NR3D_BASE+0xC8,FRC_HACT     );                   // DNR_WB_LINE_WIDTH[7:0]
    isp_write(ISP_NR3D_BASE+0xCB,FRC_VACT >> 8);            // DNR_WB_IMG_VLINE[10:8]
    isp_write(ISP_NR3D_BASE+0xCA,FRC_VACT     );                   // DNR_WB_IMG_VLINE[7:0]
    isp_write(ISP_NR3D_BASE+0xCD,DNR_WB_IMG_WLINE >> 8);    // DNR_WB_IMG_WLINE[12:8]
    isp_write(ISP_NR3D_BASE+0xCC,DNR_WB_IMG_WLINE     );           // DNR_WB_IMG_WLINE[7:0]
    isp_write(ISP_NR3D_BASE+0xCE,0x05);                              // {4'h0,DNR_WB_BURST_CTRL[3:0]}
//  *(SFR16)0xC9CF = 0x00;                              // {DNR_WB_PRI_SET[6:4],2'h0,DNR_WB_PRI_MODE[1:0}

#if(MAIN_FRC == ON)
    #if(MAIN_FRC_DPCM == ON)
        isp_write(ISP_NR3D_BASE+0xB4,0x09) | isp_read(ISP_NR3D_BASE+0xB4);     // {DNR_RB_DPCM_EN[3],1'd0,DNR_RB_READ_MODE[1],DNR_RB_ENABLE[0]}
        isp_write(ISP_NR3D_BASE+0xC3,0x0B) | isp_read(ISP_NR3D_BASE+0xC3);     // {I_NR3D_WB_DPCM_EN[3], I_NR3D_WB_INIT[2], I_NR3D_WB_WRAP_EN[1], I_NR3D_WB_ENABLE[0]}
    #else
        isp_write(ISP_NR3D_BASE+0xB4,0x01) | isp_read(ISP_NR3D_BASE+0xB4);     // {DNR_RB_DPCM_EN[3],1'd0,DNR_RB_READ_MODE[1],DNR_RB_ENABLE[0]}
        isp_write(ISP_NR3D_BASE+0xC3,0x01) | isp_read(ISP_NR3D_BASE+0xC3);     // {I_NR3D_WB_DPCM_EN[3], I_NR3D_WB_INIT[2], I_NR3D_WB_WRAP_EN[1], I_NR3D_WB_ENABLE[0]}
    #endif
#else
        isp_write(ISP_NR3D_BASE+0xB4,0xFE) & isp_read(ISP_NR3D_BASE+0xB4);     // {DNR_RB_DPCM_EN[3],1'd0,DNR_RB_READ_MODE[1],DNR_RB_ENABLE[0]}
        isp_write(ISP_NR3D_BASE+0xC3,0xFC) & isp_read(ISP_NR3D_BASE+0xC3);     // {I_NR3D_WB_DPCM_EN[3],I_NR3D_WB_INIT[2],I_NR3D_WB_WRAP_EN[1],I_NR3D_WB_ENABLE[0]}
#endif

}

