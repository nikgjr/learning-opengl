#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void RGB_GAMMA_set(void)
{
    isp_write(ISP_RGB_GAMMA_BASE+0x00,0x80);  // RGB_GAMMA_EN
    isp_write(ISP_RGB_GAMMA_BASE+0x01,4  );  // R_GAMMA_0
    isp_write(ISP_RGB_GAMMA_BASE+0x02,8  );  // R_GAMMA_1
    isp_write(ISP_RGB_GAMMA_BASE+0x03,12 );  // R_GAMMA_2
    isp_write(ISP_RGB_GAMMA_BASE+0x04,16 );  // R_GAMMA_3
    isp_write(ISP_RGB_GAMMA_BASE+0x05,20 );  // R_GAMMA_4
    isp_write(ISP_RGB_GAMMA_BASE+0x06,24 );  // R_GAMMA_5
    isp_write(ISP_RGB_GAMMA_BASE+0x07,28 );  // R_GAMMA_6
    isp_write(ISP_RGB_GAMMA_BASE+0x08,32 );  // R_GAMMA_7
    isp_write(ISP_RGB_GAMMA_BASE+0x09,36 );  // R_GAMMA_8
    isp_write(ISP_RGB_GAMMA_BASE+0x0A,40 );  // R_GAMMA_9
    isp_write(ISP_RGB_GAMMA_BASE+0x0B,44 );  // R_GAMMA_10
    isp_write(ISP_RGB_GAMMA_BASE+0x0C,48 );  // R_GAMMA_11
    isp_write(ISP_RGB_GAMMA_BASE+0x0D,52 );  // R_GAMMA_12
    isp_write(ISP_RGB_GAMMA_BASE+0x0E,56 );  // R_GAMMA_13
    isp_write(ISP_RGB_GAMMA_BASE+0x0F,60 );  // R_GAMMA_14
    isp_write(ISP_RGB_GAMMA_BASE+0x10,64 );  // R_GAMMA_15
    isp_write(ISP_RGB_GAMMA_BASE+0x11,36 );  // R_GAMMA_16
    isp_write(ISP_RGB_GAMMA_BASE+0x12,40 );  // R_GAMMA_17
    isp_write(ISP_RGB_GAMMA_BASE+0x13,44 );  // R_GAMMA_18
    isp_write(ISP_RGB_GAMMA_BASE+0x14,48 );  // R_GAMMA_19
    isp_write(ISP_RGB_GAMMA_BASE+0x15,52 );  // R_GAMMA_20
    isp_write(ISP_RGB_GAMMA_BASE+0x16,56 );  // R_GAMMA_21
    isp_write(ISP_RGB_GAMMA_BASE+0x17,60 );  // R_GAMMA_22
    isp_write(ISP_RGB_GAMMA_BASE+0x18,64 );  // R_GAMMA_23
    isp_write(ISP_RGB_GAMMA_BASE+0x19,68 );  // R_GAMMA_24
    isp_write(ISP_RGB_GAMMA_BASE+0x1A,72 );  // R_GAMMA_25
    isp_write(ISP_RGB_GAMMA_BASE+0x1B,76 );  // R_GAMMA_26
    isp_write(ISP_RGB_GAMMA_BASE+0x1C,80 );  // R_GAMMA_27
    isp_write(ISP_RGB_GAMMA_BASE+0x1D,84 );  // R_GAMMA_28
    isp_write(ISP_RGB_GAMMA_BASE+0x1E,88 );  // R_GAMMA_29
    isp_write(ISP_RGB_GAMMA_BASE+0x1F,92 );  // R_GAMMA_30
    isp_write(ISP_RGB_GAMMA_BASE+0x20,96 );  // R_GAMMA_31
    isp_write(ISP_RGB_GAMMA_BASE+0x21,100);  // R_GAMMA_32
    isp_write(ISP_RGB_GAMMA_BASE+0x22,104);  // R_GAMMA_33
    isp_write(ISP_RGB_GAMMA_BASE+0x23,108);  // R_GAMMA_34
    isp_write(ISP_RGB_GAMMA_BASE+0x24,112);  // R_GAMMA_35
    isp_write(ISP_RGB_GAMMA_BASE+0x25,116);  // R_GAMMA_36
    isp_write(ISP_RGB_GAMMA_BASE+0x26,120);  // R_GAMMA_37
    isp_write(ISP_RGB_GAMMA_BASE+0x27,124);  // R_GAMMA_38
    isp_write(ISP_RGB_GAMMA_BASE+0x28,128);  // R_GAMMA_39
    isp_write(ISP_RGB_GAMMA_BASE+0x29,132);  // R_GAMMA_40
    isp_write(ISP_RGB_GAMMA_BASE+0x2A,136);  // R_GAMMA_41
    isp_write(ISP_RGB_GAMMA_BASE+0x2B,140);  // R_GAMMA_42
    isp_write(ISP_RGB_GAMMA_BASE+0x2C,144);  // R_GAMMA_43
    isp_write(ISP_RGB_GAMMA_BASE+0x2D,148);  // R_GAMMA_44
    isp_write(ISP_RGB_GAMMA_BASE+0x2E,152);  // R_GAMMA_45
    isp_write(ISP_RGB_GAMMA_BASE+0x2F,156);  // R_GAMMA_46
    isp_write(ISP_RGB_GAMMA_BASE+0x30,160);  // R_GAMMA_47
    isp_write(ISP_RGB_GAMMA_BASE+0x31,164);  // R_GAMMA_48
    isp_write(ISP_RGB_GAMMA_BASE+0x32,168);  // R_GAMMA_49
    isp_write(ISP_RGB_GAMMA_BASE+0x33,172);  // R_GAMMA_50
    isp_write(ISP_RGB_GAMMA_BASE+0x34,176);  // R_GAMMA_51
    isp_write(ISP_RGB_GAMMA_BASE+0x35,180);  // R_GAMMA_52
    isp_write(ISP_RGB_GAMMA_BASE+0x36,184);  // R_GAMMA_53
    isp_write(ISP_RGB_GAMMA_BASE+0x37,188);  // R_GAMMA_54
    isp_write(ISP_RGB_GAMMA_BASE+0x38,192);  // R_GAMMA_55
    isp_write(ISP_RGB_GAMMA_BASE+0x39,200);  // R_GAMMA_56
    isp_write(ISP_RGB_GAMMA_BASE+0x3A,208);  // R_GAMMA_57
    isp_write(ISP_RGB_GAMMA_BASE+0x3B,216);  // R_GAMMA_58
    isp_write(ISP_RGB_GAMMA_BASE+0x3C,224);  // R_GAMMA_59
    isp_write(ISP_RGB_GAMMA_BASE+0x3D,232);  // R_GAMMA_60
    isp_write(ISP_RGB_GAMMA_BASE+0x3E,240);  // R_GAMMA_61
    isp_write(ISP_RGB_GAMMA_BASE+0x3F,248);  // R_GAMMA_62
    isp_write(ISP_RGB_GAMMA_BASE+0x40,255);  // R_GAMMA_63
    isp_write(ISP_RGB_GAMMA_BASE+0x41,4  );  // G_GAMMA_0
    isp_write(ISP_RGB_GAMMA_BASE+0x42,8  );  // G_GAMMA_1
    isp_write(ISP_RGB_GAMMA_BASE+0x43,12 );  // G_GAMMA_2
    isp_write(ISP_RGB_GAMMA_BASE+0x44,16 );  // G_GAMMA_3
    isp_write(ISP_RGB_GAMMA_BASE+0x45,20 );  // G_GAMMA_4
    isp_write(ISP_RGB_GAMMA_BASE+0x46,24 );  // G_GAMMA_5
    isp_write(ISP_RGB_GAMMA_BASE+0x47,28 );  // G_GAMMA_6
    isp_write(ISP_RGB_GAMMA_BASE+0x48,32 );  // G_GAMMA_7
    isp_write(ISP_RGB_GAMMA_BASE+0x49,36 );  // G_GAMMA_8
    isp_write(ISP_RGB_GAMMA_BASE+0x4A,40 );  // G_GAMMA_9
    isp_write(ISP_RGB_GAMMA_BASE+0x4B,44 );  // G_GAMMA_10
    isp_write(ISP_RGB_GAMMA_BASE+0x4C,48 );  // G_GAMMA_11
    isp_write(ISP_RGB_GAMMA_BASE+0x4D,52 );  // G_GAMMA_12
    isp_write(ISP_RGB_GAMMA_BASE+0x4E,56 );  // G_GAMMA_13
    isp_write(ISP_RGB_GAMMA_BASE+0x4F,60 );  // G_GAMMA_14
    isp_write(ISP_RGB_GAMMA_BASE+0x50,64 );  // G_GAMMA_15
    isp_write(ISP_RGB_GAMMA_BASE+0x51,36 );  // G_GAMMA_16
    isp_write(ISP_RGB_GAMMA_BASE+0x52,40 );  // G_GAMMA_17
    isp_write(ISP_RGB_GAMMA_BASE+0x53,44 );  // G_GAMMA_18
    isp_write(ISP_RGB_GAMMA_BASE+0x54,48 );  // G_GAMMA_19
    isp_write(ISP_RGB_GAMMA_BASE+0x55,52 );  // G_GAMMA_20
    isp_write(ISP_RGB_GAMMA_BASE+0x56,56 );  // G_GAMMA_21
    isp_write(ISP_RGB_GAMMA_BASE+0x57,60 );  // G_GAMMA_22
    isp_write(ISP_RGB_GAMMA_BASE+0x58,64 );  // G_GAMMA_23
    isp_write(ISP_RGB_GAMMA_BASE+0x59,68 );  // G_GAMMA_24
    isp_write(ISP_RGB_GAMMA_BASE+0x5A,72 );  // G_GAMMA_25
    isp_write(ISP_RGB_GAMMA_BASE+0x5B,76 );  // G_GAMMA_26
    isp_write(ISP_RGB_GAMMA_BASE+0x5C,80 );  // G_GAMMA_27
    isp_write(ISP_RGB_GAMMA_BASE+0x5D,84 );  // G_GAMMA_28
    isp_write(ISP_RGB_GAMMA_BASE+0x5E,88 );  // G_GAMMA_29
    isp_write(ISP_RGB_GAMMA_BASE+0x5F,92 );  // G_GAMMA_30
    isp_write(ISP_RGB_GAMMA_BASE+0x60,96 );  // G_GAMMA_31
    isp_write(ISP_RGB_GAMMA_BASE+0x61,100);  // G_GAMMA_32
    isp_write(ISP_RGB_GAMMA_BASE+0x62,104);  // G_GAMMA_33
    isp_write(ISP_RGB_GAMMA_BASE+0x63,108);  // G_GAMMA_34
    isp_write(ISP_RGB_GAMMA_BASE+0x64,112);  // G_GAMMA_35
    isp_write(ISP_RGB_GAMMA_BASE+0x65,116);  // G_GAMMA_36
    isp_write(ISP_RGB_GAMMA_BASE+0x66,120);  // G_GAMMA_37
    isp_write(ISP_RGB_GAMMA_BASE+0x67,124);  // G_GAMMA_38
    isp_write(ISP_RGB_GAMMA_BASE+0x68,128);  // G_GAMMA_39
    isp_write(ISP_RGB_GAMMA_BASE+0x69,132);  // G_GAMMA_40
    isp_write(ISP_RGB_GAMMA_BASE+0x6A,136);  // G_GAMMA_41
    isp_write(ISP_RGB_GAMMA_BASE+0x6B,140);  // G_GAMMA_42
    isp_write(ISP_RGB_GAMMA_BASE+0x6C,144);  // G_GAMMA_43
    isp_write(ISP_RGB_GAMMA_BASE+0x6D,148);  // G_GAMMA_44
    isp_write(ISP_RGB_GAMMA_BASE+0x6E,152);  // G_GAMMA_45
    isp_write(ISP_RGB_GAMMA_BASE+0x6F,156);  // G_GAMMA_46
    isp_write(ISP_RGB_GAMMA_BASE+0x70,160);  // G_GAMMA_47
    isp_write(ISP_RGB_GAMMA_BASE+0x71,164);  // G_GAMMA_48
    isp_write(ISP_RGB_GAMMA_BASE+0x72,168);  // G_GAMMA_49
    isp_write(ISP_RGB_GAMMA_BASE+0x73,172);  // G_GAMMA_50
    isp_write(ISP_RGB_GAMMA_BASE+0x74,176);  // G_GAMMA_51
    isp_write(ISP_RGB_GAMMA_BASE+0x75,180);  // G_GAMMA_52
    isp_write(ISP_RGB_GAMMA_BASE+0x76,184);  // G_GAMMA_53
    isp_write(ISP_RGB_GAMMA_BASE+0x77,188);  // G_GAMMA_54
    isp_write(ISP_RGB_GAMMA_BASE+0x78,192);  // G_GAMMA_55
    isp_write(ISP_RGB_GAMMA_BASE+0x79,200);  // G_GAMMA_56
    isp_write(ISP_RGB_GAMMA_BASE+0x7A,208);  // G_GAMMA_57
    isp_write(ISP_RGB_GAMMA_BASE+0x7B,216);  // G_GAMMA_58
    isp_write(ISP_RGB_GAMMA_BASE+0x7C,224);  // G_GAMMA_59
    isp_write(ISP_RGB_GAMMA_BASE+0x7D,232);  // G_GAMMA_60
    isp_write(ISP_RGB_GAMMA_BASE+0x7E,240);  // G_GAMMA_61
    isp_write(ISP_RGB_GAMMA_BASE+0x7F,248);  // G_GAMMA_62
    isp_write(ISP_RGB_GAMMA_BASE+0x80,255);  // G_GAMMA_63
    isp_write(ISP_RGB_GAMMA_BASE+0x81,4  );  // B_GAMMA_0
    isp_write(ISP_RGB_GAMMA_BASE+0x82,8  );  // B_GAMMA_1
    isp_write(ISP_RGB_GAMMA_BASE+0x83,12 );  // B_GAMMA_2
    isp_write(ISP_RGB_GAMMA_BASE+0x84,16 );  // B_GAMMA_3
    isp_write(ISP_RGB_GAMMA_BASE+0x85,20 );  // B_GAMMA_4
    isp_write(ISP_RGB_GAMMA_BASE+0x86,24 );  // B_GAMMA_5
    isp_write(ISP_RGB_GAMMA_BASE+0x87,28 );  // B_GAMMA_6
    isp_write(ISP_RGB_GAMMA_BASE+0x88,32 );  // B_GAMMA_7
    isp_write(ISP_RGB_GAMMA_BASE+0x89,36 );  // B_GAMMA_8
    isp_write(ISP_RGB_GAMMA_BASE+0x8A,40 );  // B_GAMMA_9
    isp_write(ISP_RGB_GAMMA_BASE+0x8B,44 );  // B_GAMMA_10
    isp_write(ISP_RGB_GAMMA_BASE+0x8C,48 );  // B_GAMMA_11
    isp_write(ISP_RGB_GAMMA_BASE+0x8D,52 );  // B_GAMMA_12
    isp_write(ISP_RGB_GAMMA_BASE+0x8E,56 );  // B_GAMMA_13
    isp_write(ISP_RGB_GAMMA_BASE+0x8F,60 );  // B_GAMMA_14
    isp_write(ISP_RGB_GAMMA_BASE+0x90,64 );  // B_GAMMA_15
    isp_write(ISP_RGB_GAMMA_BASE+0x91,36 );  // B_GAMMA_16
    isp_write(ISP_RGB_GAMMA_BASE+0x92,40 );  // B_GAMMA_17
    isp_write(ISP_RGB_GAMMA_BASE+0x93,44 );  // B_GAMMA_18
    isp_write(ISP_RGB_GAMMA_BASE+0x94,48 );  // B_GAMMA_19
    isp_write(ISP_RGB_GAMMA_BASE+0x95,52 );  // B_GAMMA_20
    isp_write(ISP_RGB_GAMMA_BASE+0x96,56 );  // B_GAMMA_21
    isp_write(ISP_RGB_GAMMA_BASE+0x97,60 );  // B_GAMMA_22
    isp_write(ISP_RGB_GAMMA_BASE+0x98,64 );  // B_GAMMA_23
    isp_write(ISP_RGB_GAMMA_BASE+0x99,68 );  // B_GAMMA_24
    isp_write(ISP_RGB_GAMMA_BASE+0x9A,72 );  // B_GAMMA_25
    isp_write(ISP_RGB_GAMMA_BASE+0x9B,76 );  // B_GAMMA_26
    isp_write(ISP_RGB_GAMMA_BASE+0x9C,80 );  // B_GAMMA_27
    isp_write(ISP_RGB_GAMMA_BASE+0x9D,84 );  // B_GAMMA_28
    isp_write(ISP_RGB_GAMMA_BASE+0x9E,88 );  // B_GAMMA_29
    isp_write(ISP_RGB_GAMMA_BASE+0x9F,92 );  // B_GAMMA_30
    isp_write(ISP_RGB_GAMMA_BASE+0xA0,96 );  // B_GAMMA_31
    isp_write(ISP_RGB_GAMMA_BASE+0xA1,100);  // B_GAMMA_32
    isp_write(ISP_RGB_GAMMA_BASE+0xA2,104);  // B_GAMMA_33
    isp_write(ISP_RGB_GAMMA_BASE+0xA3,108);  // B_GAMMA_34
    isp_write(ISP_RGB_GAMMA_BASE+0xA4,112);  // B_GAMMA_35
    isp_write(ISP_RGB_GAMMA_BASE+0xA5,116);  // B_GAMMA_36
    isp_write(ISP_RGB_GAMMA_BASE+0xA6,120);  // B_GAMMA_37
    isp_write(ISP_RGB_GAMMA_BASE+0xA7,124);  // B_GAMMA_38
    isp_write(ISP_RGB_GAMMA_BASE+0xA8,128);  // B_GAMMA_39
    isp_write(ISP_RGB_GAMMA_BASE+0xA9,132);  // B_GAMMA_40
    isp_write(ISP_RGB_GAMMA_BASE+0xAA,136);  // B_GAMMA_41
    isp_write(ISP_RGB_GAMMA_BASE+0xAB,140);  // B_GAMMA_42
    isp_write(ISP_RGB_GAMMA_BASE+0xAC,144);  // B_GAMMA_43
    isp_write(ISP_RGB_GAMMA_BASE+0xAD,148);  // B_GAMMA_44
    isp_write(ISP_RGB_GAMMA_BASE+0xAE,152);  // B_GAMMA_45
    isp_write(ISP_RGB_GAMMA_BASE+0xAF,156);  // B_GAMMA_46
    isp_write(ISP_RGB_GAMMA_BASE+0xB0,160);  // B_GAMMA_47
    isp_write(ISP_RGB_GAMMA_BASE+0xB1,164);  // B_GAMMA_48
    isp_write(ISP_RGB_GAMMA_BASE+0xB2,168);  // B_GAMMA_49
    isp_write(ISP_RGB_GAMMA_BASE+0xB3,172);  // B_GAMMA_50
    isp_write(ISP_RGB_GAMMA_BASE+0xB4,176);  // B_GAMMA_51
    isp_write(ISP_RGB_GAMMA_BASE+0xB5,180);  // B_GAMMA_52
    isp_write(ISP_RGB_GAMMA_BASE+0xB6,184);  // B_GAMMA_53
    isp_write(ISP_RGB_GAMMA_BASE+0xB7,188);  // B_GAMMA_54
    isp_write(ISP_RGB_GAMMA_BASE+0xB8,192);  // B_GAMMA_55
    isp_write(ISP_RGB_GAMMA_BASE+0xB9,200);  // B_GAMMA_56
    isp_write(ISP_RGB_GAMMA_BASE+0xBA,208);  // B_GAMMA_57
    isp_write(ISP_RGB_GAMMA_BASE+0xBB,216);  // B_GAMMA_58
    isp_write(ISP_RGB_GAMMA_BASE+0xBC,224);  // B_GAMMA_59
    isp_write(ISP_RGB_GAMMA_BASE+0xBD,232);  // B_GAMMA_60
    isp_write(ISP_RGB_GAMMA_BASE+0xBE,240);  // B_GAMMA_61
    isp_write(ISP_RGB_GAMMA_BASE+0xBF,248);  // B_GAMMA_62
    isp_write(ISP_RGB_GAMMA_BASE+0xC0,255);  // B_GAMMA_63
//  isp_write(ISP_RGB_GAMMA_BASE+0xC1,0x00;  // RGB_GAMMA_GEN
}

