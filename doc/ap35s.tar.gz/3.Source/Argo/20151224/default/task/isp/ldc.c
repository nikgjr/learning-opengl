#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void LDC_set(void)
{
    unsigned int LDC_IMG_WLINE;

	tdk_printf("LDC set\n");

    #if(LDC_PANORAMA_SET==ON)
        #if(ENV_SIZE==SIZE_1M_SET)
        LDC_IMG_WLINE = (unsigned int)((OUTPUT_FORMATTER_VACT+16) * 2);
        #else
        LDC_IMG_WLINE = (unsigned int)(OUTPUT_FORMATTER_VACT);
        #endif
    #else
    LDC_IMG_WLINE = (unsigned int)(OUTPUT_FORMATTER_VACT);
    #endif
    #if((ENV_TEST==ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL) | (ENV_TEST == ENV_TEST_FUNC_BYPASS))
    isp_write(ISP_LDC_BASE+0x01,0x08);  //  {      LDC_OUT_LINE_DELAY[ 7:0]              } ;
    isp_write(ISP_LDC_BASE+0x02,0x00);  //  {      LDC_OUT_LINE_DELAY[15:8]              } ;

    isp_write(ISP_LDC_BASE+0x40,0x00);  //  {5'd0, LDC_pip_bypass_en, LDC_bypass_en, LDC_mode} ;
    isp_write(ISP_LDC_BASE+0x0C,0x09);  //  {4'd0, LDC_PIP_WMAIN_WRAP_EN, LDC_WMAIN_WRAP_INIT_EN, LDC_WMAIN_WRAP_EN, LDC_WMAIN_EN} ;

    isp_write(ISP_LDC_BASE+0x43,0x11);  //  {      LDC_TXCNT[7:0]                        } ;
    isp_write(ISP_LDC_BASE+0x44,0x08);  //  {      LDC_TYCNT_1[7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x45,0x00);  //  {      LDC_SOFFSET[7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x46,0x00);  //  {      LDC_TOFFSET[7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x47,0x07);  //  {      LDC_DSTW_1[7:0]                       } ;
    isp_write(ISP_LDC_BASE+0x48,0x00);  //  {      LDC_INCR[ 7:0]                        } ;
    isp_write(ISP_LDC_BASE+0x49,0x10);  //  {      LDC_INCR[15:8]                        } ;
    #elif(ENV_SIZE==SIZE_1M_SET)
    isp_write(ISP_LDC_BASE+0x01,0x2C);  //  {      LDC_OUT_LINE_DELAY[ 7:0]              } ;
    isp_write(ISP_LDC_BASE+0x02,0x01);  //  {      LDC_OUT_LINE_DELAY[15:8]              } ;

    isp_write(ISP_LDC_BASE+0x40,0x00);  //  {5'd0, LDC_pip_bypass_en, LDC_bypass_en, LDC_mode} ;
    isp_write(ISP_LDC_BASE+0x0C,0x0B);  //  {4'd0, LDC_PIP_WMAIN_WRAP_EN, LDC_WMAIN_WRAP_INIT_EN, LDC_WMAIN_WRAP_EN, LDC_WMAIN_EN} ;

    isp_write(ISP_LDC_BASE+0x43,0xA1);  //  {      LDC_TXCNT[7:0]                        } ;
    isp_write(ISP_LDC_BASE+0x44,0x5A);  //  {      LDC_TYCNT_1[7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x45,0x00);  //  {      LDC_SOFFSET[7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x46,0x00);  //  {      LDC_TOFFSET[7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x47,0x07);  //  {      LDC_DSTW_1[7:0]                       } ;
    isp_write(ISP_LDC_BASE+0x48,0x00);  //  {      LDC_INCR[ 7:0]                        } ;
    isp_write(ISP_LDC_BASE+0x49,0x10);  //  {      LDC_INCR[15:8]                        } ;
    #else
    isp_write(ISP_LDC_BASE+0x01,0x08);  //  {      LDC_OUT_LINE_DELAY[ 7:0]              } ;
    isp_write(ISP_LDC_BASE+0x02,0x00);  //  {      LDC_OUT_LINE_DELAY[15:8]              } ;

    isp_write(ISP_LDC_BASE+0x40,0x01);  //  {5'd0, LDC_pip_bypass_en, LDC_bypass_en, LDC_mode} ;
    isp_write(ISP_LDC_BASE+0x0C,0x09);  //  {4'd0, LDC_PIP_WMAIN_WRAP_EN, LDC_WMAIN_WRAP_INIT_EN, LDC_WMAIN_WRAP_EN, LDC_WMAIN_EN} ;

    isp_write(ISP_LDC_BASE+0x43,0x3D);  //  {      LDC_TXCNT[7:0]                        } ;
    isp_write(ISP_LDC_BASE+0x44,0x22);  //  {      LDC_TYCNT_1[7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x45,0x00);  //  {      LDC_SOFFSET[7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x46,0x00);  //  {      LDC_TOFFSET[7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x47,0x1F);  //  {      LDC_DSTW_1[7:0]                       } ;
    isp_write(ISP_LDC_BASE+0x48,0x00);  //  {      LDC_INCR[ 7:0]                        } ;
    isp_write(ISP_LDC_BASE+0x49,0x04);  //  {      LDC_INCR[15:8]                        } ;
    #endif

    isp_write(ISP_LDC_BASE+0x00,0x01);                          //  {6'd0, LDC_READ_SYNC_MODE, LDC_EN            } ;
    isp_write(ISP_LDC_BASE+0x03,0x14);                          //  {4'd0, LDC_PIP_LINE_DELAY[3:0]               } ;
    isp_write(ISP_LDC_BASE+0x04,OUTPUT_FORMATTER_HACT     );    //  {      LDC_HWIDTH[ 7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x05,OUTPUT_FORMATTER_HACT >> 8);    //  {5'd0, LDC_HWIDTH[10:8]                      } ;
    isp_write(ISP_LDC_BASE+0x06,OUTPUT_FORMATTER_VACT     );    //  {      LDC_VHEIGHT[ 7:0]                     } ;
    isp_write(ISP_LDC_BASE+0x07,OUTPUT_FORMATTER_VACT >> 8);    //  {5'd0, LDC_VHEIGHT[10:8]                     } ;
    isp_write(ISP_LDC_BASE+0x08,OUTPUT_FORMATTER_HBLK     );    //  {      LDC_HBLANK[ 7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x09,OUTPUT_FORMATTER_HBLK >> 8);    //  {      LDC_HBLANK[15:8]                      } ;
    #if((ENV_TEST==ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL) | (ENV_TEST == ENV_TEST_FUNC_BYPASS))
    isp_write(ISP_LDC_BASE+0x0A,0x26);                          //  {      LDC_VBLANK[ 7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x0B,0x00);                          //  {      LDC_VBLANK[15:8]                      } ;
    #else
    isp_write(ISP_LDC_BASE+0x0A,OUTPUT_FORMATTER_VBLK     );    //  {      LDC_VBLANK[ 7:0]                      } ;
    isp_write(ISP_LDC_BASE+0x0B,OUTPUT_FORMATTER_VBLK >> 8);    //  {      LDC_VBLANK[15:8]                      } ;
    #endif

    isp_write(ISP_LDC_BASE+0x0D,LDC_BASE_ADDR             );    //  {      LDC_WMAIN_START_ADDR[ 7:0]            } ;
    isp_write(ISP_LDC_BASE+0x0E,LDC_BASE_ADDR >> 8        );    //  {      LDC_WMAIN_START_ADDR[15:8]            } ;
    isp_write(ISP_LDC_BASE+0x0F,LDC_BASE_ADDR >> 16       );    //  {      LDC_WMAIN_START_ADDR[23:16]           } ;
    isp_write(ISP_LDC_BASE+0x10,LDC_BASE_ADDR >> 24       );    //  {      LDC_WMAIN_START_ADDR[31:24]           } ;
    isp_write(ISP_LDC_BASE+0x11,OUTPUT_FORMATTER_HACT     );    //  {      LDC_WMAIN_HPIXEL[ 7:0]                } ;
    isp_write(ISP_LDC_BASE+0x12,OUTPUT_FORMATTER_HACT >> 8);    //  {5'd0, LDC_WMAIN_HPIXEL[10:8]                } ;
    isp_write(ISP_LDC_BASE+0x13,OUTPUT_FORMATTER_VACT     );    //  {      LDC_WMAIN_VLINE[ 7:0]                 } ;
    isp_write(ISP_LDC_BASE+0x14,OUTPUT_FORMATTER_VACT >> 8);    //  {5'd0, LDC_WMAIN_VLINE[10:8]                 } ;
    isp_write(ISP_LDC_BASE+0x15,LDC_IMG_WLINE             );    //  {      LDC_WMAIN_WLINE[ 7:0]                 } ;
    isp_write(ISP_LDC_BASE+0x16,LDC_IMG_WLINE >> 8        );    //  {3'd0, LDC_WMAIN_WLINE[12:8]                 } ;
    isp_write(ISP_LDC_BASE+0x17,0x07                      );    //  {4'd0, LDC_WMAIN_BURST_CTRL[3:0]             } ;
    #if((ENV_TEST==ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL) | (ENV_TEST == ENV_TEST_FUNC_BYPASS))
    isp_write(ISP_LDC_BASE+0x18,0x04);      //  {5'd0, LDC_WMAIN_PRI_SET[2:0]                } ;
    #else
    isp_write(ISP_LDC_BASE+0x18,0x05);      //  {5'd0, LDC_WMAIN_PRI_SET[2:0]                } ;
    #endif
    isp_write(ISP_LDC_BASE+0x19,0x00);      //  {6'd0, LDC_WMAIN_PRI_MODE[1:0]               } ;
    #if((ENV_TEST==ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL) | (ENV_TEST == ENV_TEST_FUNC_BYPASS))
    isp_write(ISP_LDC_BASE+0x1A,0x01);      //  {5'd0, LDC_PIP_RMAIN_READ_MODE, LDC_RMAIN_READ_MODE, LDC_RMAIN_EN     } ;
    #else
        #if(MAIN_FRC == ON)
    isp_write(ISP_LDC_BASE+0x1A,0x03);      //  {5'd0, LDC_PIP_RMAIN_READ_MODE, LDC_RMAIN_READ_MODE, LDC_RMAIN_EN     } ;
        #else
    isp_write(ISP_LDC_BASE+0x1A,0x07);      //  {5'd0, LDC_PIP_RMAIN_READ_MODE, LDC_RMAIN_READ_MODE, LDC_RMAIN_EN     } ;
        #endif
    #endif
    isp_write(ISP_LDC_BASE+0x1B,OUTPUT_FORMATTER_HACT     );    //  {      LDC_RMAIN_HPIXEL[ 7:0]                } ;
    isp_write(ISP_LDC_BASE+0x1C,OUTPUT_FORMATTER_HACT >> 8);    //  {5'd0, LDC_RMAIN_HPIXEL[10:8]                } ;
    isp_write(ISP_LDC_BASE+0x1D,OUTPUT_FORMATTER_VACT     );    //  {      LDC_RMAIN_VLINE[ 7:0]                 } ;
    isp_write(ISP_LDC_BASE+0x1E,OUTPUT_FORMATTER_VACT >> 8);    //  {5'd0, LDC_RMAIN_VLINE[10:8]                 } ;
    isp_write(ISP_LDC_BASE+0x1F,LDC_IMG_WLINE             );    //  {      LDC_RMAIN_WLINE[ 7:0]                 } ;
    isp_write(ISP_LDC_BASE+0x20,LDC_IMG_WLINE >> 8        );    //  {3'd0, LDC_RMAIN_WLINE[12:8]                 } ;
    isp_write(ISP_LDC_BASE+0x21,0x04);                          //  {4'd0, LDC_RMAIN_BURST_CTRL[3:0]             } ;
    #if((ENV_TEST==ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL) | (ENV_TEST == ENV_TEST_FUNC_BYPASS))
    isp_write(ISP_LDC_BASE+0x22,0x04);                          //  {5'd0, LDC_RMAIN_PRI_SET[2:0]                } ;
    #else
    isp_write(ISP_LDC_BASE+0x22,0x05);                          //  {5'd0, LDC_RMAIN_PRI_SET[2:0]                } ;
    #endif
    isp_write(ISP_LDC_BASE+0x23,0x00);                          //  {6'd0, LDC_RMAIN_PRI_MODE[1:0]               } ;

    isp_write(ISP_LDC_BASE+0x24,LDC_LUT0_BASE_ADDR)      ;      //  {      LDC_LUT_BASE_ADDR0[7:0]               } ;
    isp_write(ISP_LDC_BASE+0x25,LDC_LUT0_BASE_ADDR >> 8) ;      //  {      LDC_LUT_BASE_ADDR0[15:8]              } ;
    isp_write(ISP_LDC_BASE+0x26,LDC_LUT0_BASE_ADDR >> 16);      //  {      LDC_LUT_BASE_ADDR0[23:16]             } ;
    isp_write(ISP_LDC_BASE+0x27,LDC_LUT0_BASE_ADDR >> 24);      //  {      LDC_LUT_BASE_ADDR0[31:24]             } ;
    isp_write(ISP_LDC_BASE+0x28,LDC_LUT1_BASE_ADDR)      ;      //  {      LDC_LUT_BASE_ADDR1[7:0]               } ;
    isp_write(ISP_LDC_BASE+0x29,LDC_LUT1_BASE_ADDR >> 8) ;      //  {      LDC_LUT_BASE_ADDR1[15:8]              } ;
    isp_write(ISP_LDC_BASE+0x2A,LDC_LUT1_BASE_ADDR >> 16);      //  {      LDC_LUT_BASE_ADDR1[23:16]             } ;
    isp_write(ISP_LDC_BASE+0x2B,LDC_LUT1_BASE_ADDR >> 24);      //  {      LDC_LUT_BASE_ADDR1[31:24]             } ;
    isp_write(ISP_LDC_BASE+0x2C,LDC_PIP_LUT0_BASE_ADDR)      ;  //  {      LDC_PIP_LUT_BASE_ADDR0[7:0]           } ;
    isp_write(ISP_LDC_BASE+0x2D,LDC_PIP_LUT0_BASE_ADDR >> 8) ;  //  {      LDC_PIP_LUT_BASE_ADDR0[15:8]          } ;
    isp_write(ISP_LDC_BASE+0x2E,LDC_PIP_LUT0_BASE_ADDR >> 16);  //  {      LDC_PIP_LUT_BASE_ADDR0[23:16]         } ;
    isp_write(ISP_LDC_BASE+0x2F,LDC_PIP_LUT0_BASE_ADDR >> 24);  //  {      LDC_PIP_LUT_BASE_ADDR0[31:24]         } ;
    isp_write(ISP_LDC_BASE+0x30,LDC_PIP_LUT1_BASE_ADDR)      ;  //  {      LDC_PIP_LUT_BASE_ADDR1[7:0]           } ;
    isp_write(ISP_LDC_BASE+0x31,LDC_PIP_LUT1_BASE_ADDR >> 8) ;  //  {      LDC_PIP_LUT_BASE_ADDR1[15:8]          } ;
    isp_write(ISP_LDC_BASE+0x32,LDC_PIP_LUT1_BASE_ADDR >> 16);  //  {      LDC_PIP_LUT_BASE_ADDR1[23:16]         } ;
    isp_write(ISP_LDC_BASE+0x33,LDC_PIP_LUT1_BASE_ADDR >> 24);  //  {      LDC_PIP_LUT_BASE_ADDR1[31:24]         } ;

    isp_write(ISP_LDC_BASE+0x34,0x80);                          //  {      LDC_PIP_HWIDTH[7:0]                   } ;
    isp_write(ISP_LDC_BASE+0x35,0x02);                          //  {6'd0, LDC_PIP_HWIDTH[9:8]                   } ;
    isp_write(ISP_LDC_BASE+0x36,0x68);                          //  {      LDC_PIP_VHEIGHT[7:0]                  } ;
    isp_write(ISP_LDC_BASE+0x37,0x01);                          //  {6'd0, LDC_PIP_VHEIGHT[9:8]                  } ;
    isp_write(ISP_LDC_BASE+0x38,LDC_PIP_BASE_ADDR)      ;       //  {      LDC_PIP_WMAIN_START_ADDR[7:0]         } ;
    isp_write(ISP_LDC_BASE+0x39,LDC_PIP_BASE_ADDR >> 8) ;       //  {      LDC_PIP_WMAIN_START_ADDR[15:8]        } ;
    isp_write(ISP_LDC_BASE+0x3A,LDC_PIP_BASE_ADDR >> 16);       //  {      LDC_PIP_WMAIN_START_ADDR[23:16]       } ;
    isp_write(ISP_LDC_BASE+0x3B,LDC_PIP_BASE_ADDR >> 24);       //  {      LDC_PIP_WMAIN_START_ADDR[31:24]       } ;
    isp_write(ISP_LDC_BASE+0x3C,0xE0);                          //  {      LDC_PIP_WMAIN_WLINE[ 7:0]             } ;
    isp_write(ISP_LDC_BASE+0x3D,0x02);                          //  {4'd0, LDC_PIP_WMAIN_WLINE[11:8]             } ;
    isp_write(ISP_LDC_BASE+0x3E,0xE0);                          //  {      LDC_PIP_RMAIN_WLINE[ 7:0]             } ;
    isp_write(ISP_LDC_BASE+0x3F,0x02);                          //  {4'd0, LDC_PIP_RMAIN_WLINE[11:8]             } ;

    isp_write(ISP_LDC_BASE+0x41,0x00);                          //  {      LDC_lut_ratio[7:0]                    } ;
    isp_write(ISP_LDC_BASE+0x42,0x00);                          //  {4'd0, LDC_vmirror_en, LDC_hmirror_en, LDC_yscale_down, LDC_xscale_down} ;

    #if(LDC_PIP_EN==ON)
    isp_write(ISP_LDC_BASE+0x4A,0x01);                          //  {7'd0, LDC_pip_en                            } ;
    #else
    isp_write(ISP_LDC_BASE+0x4A,0x00);                          //  {7'd0, LDC_pip_en                            } ;
    #endif
    isp_write(ISP_LDC_BASE+0x4B,0x40);  //  {      LDC_pip_xst[ 7:0]                     } ;
    isp_write(ISP_LDC_BASE+0x4C,0x01);  //  {5'd0, LDC_pip_xst[10:8]                     } ;
    isp_write(ISP_LDC_BASE+0x4D,0x80);  //  {      LDC_pip_xed[ 7:0]                     } ;
    isp_write(ISP_LDC_BASE+0x4E,0x02);  //  {5'd0, LDC_pip_xed[10:8]                     } ;
    isp_write(ISP_LDC_BASE+0x4F,0xB4);  //  {      LDC_pip_yst[ 7:0]                     } ;
    isp_write(ISP_LDC_BASE+0x50,0x00);  //  {5'd0, LDC_pip_yst[10:8]                     } ;
    isp_write(ISP_LDC_BASE+0x51,0x68);  //  {      LDC_pip_yed[ 7:0]                     } ;
    isp_write(ISP_LDC_BASE+0x52,0x01);  //  {5'd0, LDC_pip_yed[10:8]                     } ;
    isp_write(ISP_LDC_BASE+0x53,0x00);  //  {      LDC_hscl_org_pip[ 7: 0]               } ;
    isp_write(ISP_LDC_BASE+0x54,0x02);  //  {      LDC_hscl_org_pip[15: 8]               } ;
    isp_write(ISP_LDC_BASE+0x55,0x00);  //  {6'd0, LDC_hscl_org_pip[17:16]               } ;
    isp_write(ISP_LDC_BASE+0x56,0x00);  //  {      LDC_vscl_org_pip[ 7: 0]               } ;
    isp_write(ISP_LDC_BASE+0x57,0x02);  //  {      LDC_vscl_org_pip[15: 8]               } ;
    isp_write(ISP_LDC_BASE+0x58,0x00);  //  {6'd0, LDC_vscl_org_pip[17:16]               } ;
    isp_write(ISP_LDC_BASE+0x59,0x00);  //  {      LDC_hscl_pip_org[7:0]                 } ;
    isp_write(ISP_LDC_BASE+0x5A,0x01);  //  {6'd0, LDC_hscl_pip_org[9:8]                 } ;
    isp_write(ISP_LDC_BASE+0x5B,0x00);  //  {      LDC_vscl_pip_org[7:0]                 } ;
    isp_write(ISP_LDC_BASE+0x5C,0x01);  //  {6'd0, LDC_vscl_pip_org[9:8]                 } ;

    isp_write(ISP_LDC_BASE+0x5D,0x00);  //  {      LDC_pip_lut_ratio[7:0]                } ;
    isp_write(ISP_LDC_BASE+0x5E,0x00);  //  {6'd0, LDC_pip_vmirror_en, LDC_pip_hmirror_en} ;
    isp_write(ISP_LDC_BASE+0x5F,0x51);  //  {      LDC_PIP_TXCNT[7:0]                    } ;
    isp_write(ISP_LDC_BASE+0x60,0x2E);  //  {      LDC_PIP_TYCNT_1[7:0]                  } ;
    isp_write(ISP_LDC_BASE+0x61,0x00);  //  {      LDC_PIP_SOFFSET[7:0]                  } ;
    isp_write(ISP_LDC_BASE+0x62,0x00);  //  {      LDC_PIP_TOFFSET[7:0]                  } ;
    isp_write(ISP_LDC_BASE+0x63,0x07);  //  {      LDC_PIP_DSTW_1[7:0]                   } ;
    isp_write(ISP_LDC_BASE+0x64,0x00);  //  {      LDC_PIP_INCR[7:0]                     } ;
    isp_write(ISP_LDC_BASE+0x65,0x10);  //  {      LDC_PIP_INCR[15:8]                    } ;

    isp_write(ISP_LDC_BASE+0x66,0x00);  //  {      LDC_bg_color[ 7: 0]                   } ;
    isp_write(ISP_LDC_BASE+0x67,0x00);  //  {      LDC_bg_color[15: 8]                   } ;
    isp_write(ISP_LDC_BASE+0x68,0x00);  //  {      LDC_bg_color[23:16]                   } ;
    isp_write(ISP_LDC_BASE+0x69,0x00);  //  {7'd0, LDC_sect0_en                          } ;
    isp_write(ISP_LDC_BASE+0x6A,0x00);  //  {      LDC_sect0_xst[ 7:0]                   } ;
    isp_write(ISP_LDC_BASE+0x6B,0x00);  //  {5'd0, LDC_sect0_xst[10:8]                   } ;
    isp_write(ISP_LDC_BASE+0x6C,0x00);  //  {      LDC_sect0_xed[ 7:0]                   } ;
    isp_write(ISP_LDC_BASE+0x6D,0x00);  //  {5'd0, LDC_sect0_xed[10:8]                   } ;
    isp_write(ISP_LDC_BASE+0x6E,0x00);  //  {      LDC_sect0_yst[ 7:0]                   } ;
    isp_write(ISP_LDC_BASE+0x6F,0x00);  //  {5'd0, LDC_sect0_yst[10:8]                   } ;
    isp_write(ISP_LDC_BASE+0x70,0x00);  //  {      LDC_sect0_yed[ 7:0]                   } ;
    isp_write(ISP_LDC_BASE+0x71,0x00);  //  {5'd0, LDC_sect0_yed[10:8]                   } ;
    isp_write(ISP_LDC_BASE+0x72,0x00);  //  {7'd0, LDC_sect1_en                          } ;
    isp_write(ISP_LDC_BASE+0x73,0x00);  //  {      LDC_sect1_xst[ 7:0]                   } ;
    isp_write(ISP_LDC_BASE+0x74,0x00);  //  {5'd0, LDC_sect1_xst[10:8]                   } ;
    isp_write(ISP_LDC_BASE+0x75,0x00);  //  {      LDC_sect1_xed[ 7:0]                   } ;
    isp_write(ISP_LDC_BASE+0x76,0x00);  //  {5'd0, LDC_sect1_xed[10:8]                   } ;
    isp_write(ISP_LDC_BASE+0x77,0x00);  //  {      LDC_sect1_yst[ 7:0]                   } ;
    isp_write(ISP_LDC_BASE+0x78,0x00);  //  {5'd0, LDC_sect1_yst[10:8]                   } ;
    isp_write(ISP_LDC_BASE+0x79,0x00);  //  {      LDC_sect1_yed[ 7:0]                   } ;
    isp_write(ISP_LDC_BASE+0x7A,0x00);  //  {      LDC_sect1_yed[10:8]                   } ;

    isp_write(ISP_LDC_BASE+0x7B,0x00);  //  {      LDC_pip_bg_color[ 7: 0]               } ;
    isp_write(ISP_LDC_BASE+0x7C,0x00);  //  {      LDC_pip_bg_color[15: 8]               } ;
    isp_write(ISP_LDC_BASE+0x7D,0x00);  //  {      LDC_pip_bg_color[23:16]               } ;
    isp_write(ISP_LDC_BASE+0x7E,0x00);  //  {7'd0, LDC_pip_sect0_en                      } ;
    isp_write(ISP_LDC_BASE+0x7F,0x00);  //  {      LDC_pip_sect0_xst[ 7:0]               } ;
    isp_write(ISP_LDC_BASE+0x80,0x00);  //  {5'd0, LDC_pip_sect0_xst[10:8]               } ;
    isp_write(ISP_LDC_BASE+0x81,0x00);  //  {      LDC_pip_sect0_xed[ 7:0]               } ;
    isp_write(ISP_LDC_BASE+0x82,0x00);  //  {5'd0, LDC_pip_sect0_xed[10:8]               } ;
    isp_write(ISP_LDC_BASE+0x83,0x00);  //  {      LDC_pip_sect0_yst[ 7:0]               } ;
    isp_write(ISP_LDC_BASE+0x84,0x00);  //  {5'd0, LDC_pip_sect0_yst[10:8]               } ;
    isp_write(ISP_LDC_BASE+0x85,0x00);  //  {      LDC_pip_sect0_yed[ 7:0]               } ;
    isp_write(ISP_LDC_BASE+0x86,0x00);  //  {5'd0, LDC_pip_sect0_yed[10:8]               } ;
    isp_write(ISP_LDC_BASE+0x87,0x00);  //  {7'd0, LDC_pip_sect1_en                      } ;
    isp_write(ISP_LDC_BASE+0x88,0x00);  //  {      LDC_pip_sect1_xst[ 7:0]               } ;
    isp_write(ISP_LDC_BASE+0x89,0x00);  //  {5'd0, LDC_pip_sect1_xst[10:8]               } ;
    isp_write(ISP_LDC_BASE+0x8A,0x00);  //  {      LDC_pip_sect1_xed[ 7:0]               } ;
    isp_write(ISP_LDC_BASE+0x8B,0x00);  //  {5'd0, LDC_pip_sect1_xed[10:8]               } ;
    isp_write(ISP_LDC_BASE+0x8C,0x00);  //  {      LDC_pip_sect1_yst[ 7:0]               } ;
    isp_write(ISP_LDC_BASE+0x8D,0x00);  //  {5'd0, LDC_pip_sect1_yst[10:8]               } ;
    isp_write(ISP_LDC_BASE+0x8E,0x00);  //  {      LDC_pip_sect1_yed[ 7:0]               } ;
    isp_write(ISP_LDC_BASE+0x8F,0x00);  //  {      LDC_pip_sect1_yed[10:8]               } ;

    isp_write(ISP_LDC_BASE+0x90,0x00);  //  {6'd0, LDC_WMAIN_FRAME_DONE, LDC_WMAIN_OVERFLOW};
    isp_write(ISP_LDC_BASE+0x91,0x00);  //  {      w_ldc_WB_CLINE[ 7:0]                  } ; // {      LDC_WMAIN_CURRENT_LINE[ 7:0]          } ;
    isp_write(ISP_LDC_BASE+0x92,0x00);  //  {3'd0, w_ldc_WB_CLINE[12:8]                  } ; // {3'd0, LDC_WMAIN_CURRENT_LINE[12:8]          } ;
    isp_write(ISP_LDC_BASE+0x93,0x00);  //  {      w_ldc_WB_CADDR[ 7: 0]                 } ; // {      LDC_WMAIN_CURRENT_ADDR[ 7: 0]         } ;
    isp_write(ISP_LDC_BASE+0x94,0x00);  //  {      w_ldc_WB_CADDR[15: 8]                 } ; // {      LDC_WMAIN_CURRENT_ADDR[15: 8]         } ;
    isp_write(ISP_LDC_BASE+0x95,0x00);  //  {      w_ldc_WB_CADDR[23:16]                 } ; // {      LDC_WMAIN_CURRENT_ADDR[23:16]         } ;
    isp_write(ISP_LDC_BASE+0x96,0x00);  //  {      w_ldc_WB_CADDR[31:24]                 } ; // {      LDC_WMAIN_CURRENT_ADDR[31:24]         } ;
    isp_write(ISP_LDC_BASE+0x97,0x00);  //
    #if((ENV_TEST==ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL) | (ENV_TEST == ENV_TEST_FUNC_BYPASS))
    isp_write(ISP_LDC_BASE+0x98,0x04);  //  {5'd0, LDC_LMAIN_PRI_SET                     } ; 
    #else
    isp_write(ISP_LDC_BASE+0x98,0x07);  //  {5'd0, LDC_LMAIN_PRI_SET                     } ; 
    #endif
    isp_write(ISP_LDC_BASE+0x99,0x00);  //  {6'd0, LDC_LMAIN_PRI_MODE                    } ; 

    isp_write(ISP_LDC_BASE+0x9A,0x80);  //  {      LDC_PIP_HWIDTH_OUT[7:0]               } ;
    isp_write(ISP_LDC_BASE+0x9B,0x02);  //  {6'd0, LDC_PIP_HWIDTH_OUT[9:8]               } ;
    isp_write(ISP_LDC_BASE+0x9C,0x68);  //  {      LDC_PIP_VHEIGHT_OUT[7:0]              } ;
    isp_write(ISP_LDC_BASE+0x9D,0x01);  //  {6'd0, LDC_PIP_VHEIGHT_OUT[9:8]              } ;
    #if((ENV_TEST==ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL) | (ENV_TEST == ENV_TEST_FUNC_BYPASS))
    isp_write(ISP_LDC_BASE+0xE9,0x01);  //  
    #endif

    isp_write(ISP_LDC_BASE+0xC0,0x1F);  //  {6'd0, LDC_PIP_VHEIGHT_OUT[9:8]              } ;
    isp_write(ISP_LDC_BASE+0xC0,0x00);  //  {6'd0, LDC_PIP_VHEIGHT_OUT[9:8]              } ;
}
