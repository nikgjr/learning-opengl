#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void RGB_BOX_set (void)
{
	tdk_printf("RGB BOX set\n");

    isp_write(ISP_RGBBOX_BASE+0x00,0x03);
    isp_write(ISP_RGBBOX_BASE+0x01,0x10);
    isp_write(ISP_RGBBOX_BASE+0x02,0x10);
    isp_write(ISP_RGBBOX_BASE+0x03,0x10);
    isp_write(ISP_RGBBOX_BASE+0x04,0x10);
    isp_write(ISP_RGBBOX_BASE+0x05,0x03);
}
