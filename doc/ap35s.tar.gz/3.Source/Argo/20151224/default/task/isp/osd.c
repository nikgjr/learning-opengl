#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"
#include "isp_common.h"

#include "../tdk/tdk.h"

#define OSD_FAST_LOAD
#define OSD_FAST_TEST
#define OSD_STYLE_MAX       8
#define OSD_COLOR_MAX       8
#define OSD_BOX_MAX         4
#define OSD_ATTR_TRANS_MAX  8
#define OSD_ATTR_BLK_MAX    4
#define OSD_ATTR_COLOR_MAX  16
#define OSD_GVRINDEX_MAX    1023
//#define OSD_OPTION_FSIZEX2
//#define OSD_OPTION_FMARGIN
//#define OSD_OPTION_CHINESE_TRADITIONAL
unsigned int    gl_gvr_hnum;
unsigned int    gl_gvr_vnum;
unsigned long   gl_fnt_addr;
unsigned char   Command_Clear(BOOL bWait, BOOL bStyle, BOOL bColor, BOOL bIndex, unsigned char Style, unsigned char Color, unsigned int Index);
unsigned char   Command_Change(BOOL bWait, BOOL bStyle, BOOL bColor, BOOL bIndex, unsigned int st_vpos, unsigned int st_hpos, unsigned int ed_vpos, unsigned int ed_hpos, unsigned char Style, unsigned char Color, unsigned int Index);
void OSD_FontWrite( unsigned int gvr_hpos,
                    unsigned int gvr_vpos,
                    unsigned int fnt_style,
                    unsigned int fnt_color,
                    unsigned int fnt_index)
{
    unsigned int h_pos, v_pos, font_pos;
    unsigned char font_data0, font_data1;

    h_pos     = (gl_gvr_hnum <= gvr_hpos) ? (gl_gvr_hnum - 1) : gvr_hpos;
    v_pos     = (gl_gvr_vnum <= gvr_vpos) ? (gl_gvr_vnum - 1) : gvr_vpos;
    font_pos  = v_pos * gl_gvr_hnum + h_pos;
    if(font_pos > OSD_GVRINDEX_MAX) font_pos    = OSD_GVRINDEX_MAX - 1;

    font_data1 = ((fnt_style & 0x07) << 5) | ((fnt_color & 0x07) << 2) | ((fnt_index >> 8) & 0x03);
    font_data0 = fnt_index & 0xFF;

    // FONT DISPLAY SETTING -   (x, y) [POS (bank[2:0], address[7:0]) [FONT (INDEX_PROPERITY)]
    isp_write(ISP_IND_BANK,0x80|(0x07 & (font_pos>>7))); // bank set
    isp_write(ISP_IND_ADDR,(font_pos<<1)|0x01);          // address set(MSB)
    isp_write(ISP_IND_RWDATA,font_data1);                // wdata      (MSB)
    isp_write(ISP_IND_ADDR,(font_pos<<1));               // address set(LSB)
    isp_write(ISP_IND_RWDATA,font_data0);                // wdata      (LSB)
}

unsigned int OSD_FontRead(  unsigned int gvr_hpos,
                            unsigned int gvr_vpos)
{
    unsigned int h_pos, v_pos, font_pos;
    unsigned char font_data0, font_data1;

    h_pos     = (gl_gvr_hnum <= gvr_hpos) ? (gl_gvr_hnum - 1) : gvr_hpos;
    v_pos     = (gl_gvr_vnum <= gvr_vpos) ? (gl_gvr_vnum - 1) : gvr_vpos;
    font_pos  = v_pos * gl_gvr_hnum + h_pos;
    if(font_pos > OSD_GVRINDEX_MAX) font_pos    = OSD_GVRINDEX_MAX - 1;

    // FONT DISPLAY SETTING -   (x, y) [POS (bank[2:0], address[7:0]) [FONT (INDEX_PROPERITY)]
    isp_write(ISP_IND_BANK,0x80|(0x07 & (font_pos >> 7))); // bank set
    isp_write(ISP_IND_ADDR,(font_pos << 1)|0x01);          // address set(MSB)
    font_data1      = isp_read(ISP_IND_RWDATA);            // read       (MSB)
    isp_write(ISP_IND_ADDR,(font_pos << 1));               // address set(LSB)
    font_data0      = isp_read(ISP_IND_RWDATA);            // read       (LSB)

    return ((int)font_data1 << 8 | font_data0);
}

void OSD_FontDataWrite(unsigned char wdata)
{
    mem_write(gl_fnt_addr,wdata);
    gl_fnt_addr++;
}

void OSD_FontLoad(void)
{
    // RAM WRITE TEST (4 font write)
    // w32h32 x 4n : ['0', '1', '2', '3']
#ifdef OSD_FAST_LOAD
    unsigned int byte_cnt = 0;
/*
    unsigned char * byte_buf = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x15, 0x50, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x01, 0x55, 0x55, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x05, 0x55, 0x55, 0x40, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x55, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x50, 0x05, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x40, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x00, 0x00, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x40, 0x15, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x55, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x05, 0x55, 0x55, 0x40, 0x00, 0x00,
                                0x00, 0x00, 0x01, 0x55, 0x55, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x15, 0x50, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x05, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x55, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x05, 0x55, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x51, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x41, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x10, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x55, 0x55, 0x55, 0x40, 0x00,
                                0x00, 0x00, 0x55, 0x55, 0x55, 0x55, 0x40, 0x00,
                                0x00, 0x00, 0x55, 0x55, 0x55, 0x55, 0x40, 0x00,
                                0x00, 0x00, 0x55, 0x55, 0x55, 0x55, 0x40, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x15, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x01, 0x55, 0x55, 0x40, 0x00, 0x00,
                                0x00, 0x00, 0x05, 0x55, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x05, 0x55, 0x55, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x50, 0x05, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x40, 0x01, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x40, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x05, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x05, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x05, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x15, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x01, 0x55, 0x40, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x05, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x15, 0x50, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x01, 0x55, 0x40, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x05, 0x54, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x50, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x55, 0x55, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x55, 0x55, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x55, 0x55, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x55, 0x55, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x55, 0x50, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x05, 0x55, 0x55, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x55, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x55, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x40, 0x05, 0x54, 0x00, 0x00,
                                0x00, 0x01, 0x55, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x15, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x15, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x15, 0x55, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x15, 0x55, 0x40, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x15, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x05, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x01, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x14, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x01, 0x55, 0x00, 0x01, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x40, 0x05, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x55, 0x55, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x55, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x05, 0x55, 0x55, 0x40, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x55, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

    for(byte_cnt=0; byte_cnt<1024;byte_cnt++)
    {
        mem_write(byte_cnt,(unsigned char)byte_buf[byte_cnt]);
    }
*/
    unsigned char byte_buf[256] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x55, 0x50, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x05, 0x55, 0x55, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x55, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x55, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x40, 0x05, 0x54, 0x00, 0x00,
                                0x00, 0x01, 0x55, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x01, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x15, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x15, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x15, 0x55, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x15, 0x55, 0x40, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x15, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x05, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x01, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x14, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x01, 0x54, 0x00, 0x00, 0x55, 0x00, 0x00,
                                0x00, 0x01, 0x55, 0x00, 0x01, 0x55, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x40, 0x05, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x55, 0x55, 0x55, 0x54, 0x00, 0x00,
                                0x00, 0x00, 0x15, 0x55, 0x55, 0x50, 0x00, 0x00,
                                0x00, 0x00, 0x05, 0x55, 0x55, 0x40, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x55, 0x54, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    for(byte_cnt=0; byte_cnt<256;byte_cnt++)
    {
        mem_write(byte_cnt,(unsigned char)byte_buf[byte_cnt]);
    }
#else
    gl_fnt_addr = 0x000000;
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x51);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x41);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x10);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x14);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x01);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x15);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x50);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x05);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x40);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x55);
    OSD_FontDataWrite(0x54);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
    OSD_FontDataWrite(0x00);
#endif
}

void OSD_Init(int init_mode) {
//  init attribution, color, and style
//  init_mode = 0   ==> set parameter : Font32x32, Grid33x31 (GVRAM MAX 1024)
//            = 1   ==> set parameter : Font48x48, Grid40x23
//            = FF  ==> enable BUS

#if(OSD_SD == OFF)
    // OSD Clock = OISP Clock
    if(init_mode == 0xFF)
    {
        isp_write(ISP_OSD_BASE+0x00,0xBF & isp_read(ISP_OSD_BASE+0x00));    // {O_HDOSD_EN, O_HDOSD_GRD_INTERLACE, O_HDOSD_GRD_FSWAP, O_HDOSD_GRD_INDEXZERO_EN, O_HDOSD_FNT_YLPF_EN, O_HDOSD_FNT_CLPF_EN, O_HDOSD_BLKTIMER_RST, O_HDOSD_OUTLINE_EN}
        isp_write(ISP_OSD_BASE+0xCF,0x01 | isp_read(ISP_OSD_BASE+0xCF));    // {O_OSD_IN_CSWAP, O_OSD_YC422_CROMA, O_OSD_YC422_OUT, O_OSD_ROM_EN, O_OSD_ROM_CHINESE_TRADITIONAL, O_OSD_COLOR_OFF, O_OSD_BUS_ENABLE}
        return;
    }
    else if(init_mode == 0)
    {
        // Don't Use ROM FONT
    #if(ENV_TEST != ENV_TEST_OFF)
        gl_gvr_hnum     = 10;
        gl_gvr_vnum     = 10;
    #else
        gl_gvr_hnum     = 33;
        gl_gvr_vnum     = 31;
    #endif

    #if defined OSD_OPTION_FSIZEX2
        isp_write(ISP_OSD_BASE+0x07,0x5F);          // {1'd0, O_OSD_VSIZEx2, O_OSD_GRD_VSIZE};
        isp_write(ISP_OSD_BASE+0x08,0x5F);          // {1'd0, O_OSD_HSIZEx2, O_OSD_GRD_HSIZE};
    #else
        isp_write(ISP_OSD_BASE+0x07,0x1F);          // {1'd0, O_OSD_VSIZEx2, O_OSD_GRD_VSIZE};
        isp_write(ISP_OSD_BASE+0x08,0x1F);          // {1'd0, O_OSD_HSIZEx2, O_OSD_GRD_HSIZE};
    #endif

//      isp_write(ISP_OSD_BASE+0x09,0x00);          // O_OSD_GRD_PREVSYNC_OFFSET[7:0];
        isp_write(ISP_OSD_BASE+0x0A,0x10);          // O_OSD_GRD_PREVSYNC_OFFSET[15:8];
//      isp_write(ISP_OSD_BASE+0x0B,0x00);          // {7'd0, O_OSD_GRD_PREVSYNC_OFFSET[16]};
//      isp_write(ISP_OSD_BASE+0x0C,0x00);          // {3'd0, O_OSD_GRD_SDRREQ_WAIT};
    }
    else if(init_mode == 1)
    {
    #if(ENV_TEST != ENV_TEST_OFF)
        gl_gvr_hnum     = 10;
        gl_gvr_vnum     = 10;
    #else
        gl_gvr_hnum     = 40;
        gl_gvr_vnum     = 23;
    #endif

    #if defined OSD_OPTION_FSIZEX2
        isp_write(ISP_OSD_BASE+0x07,0x6F);          // {1'd0, O_OSD_VSIZEx2, O_OSD_GRD_VSIZE};
        isp_write(ISP_OSD_BASE+0x08,0x6F);          // {1'd0, O_OSD_HSIZEx2, O_OSD_GRD_HSIZE};
    #else
        isp_write(ISP_OSD_BASE+0x07,0x2F);          // {1'd0, O_OSD_VSIZEx2, O_OSD_GRD_VSIZE};
        isp_write(ISP_OSD_BASE+0x08,0x2F);          // {1'd0, O_OSD_HSIZEx2, O_OSD_GRD_HSIZE};
    #endif

//      isp_write(ISP_OSD_BASE+0x09,0x00);          // O_OSD_GRD_PREVSYNC_OFFSET[7:0];
        isp_write(ISP_OSD_BASE+0x0A,0x10);          // O_OSD_GRD_PREVSYNC_OFFSET[15:8];
//      isp_write(ISP_OSD_BASE+0x0B,0x00);          // {7'd0, O_OSD_GRD_PREVSYNC_OFFSET[16]};
//      isp_write(ISP_OSD_BASE+0x0C,0x00);          // {3'd0, O_OSD_GRD_SDRREQ_WAIT};
    }
#else
    // OSD Clock = CVBS Clock
    if(init_mode == 0xFF)
    {
        isp_write(ISP_OSD_BASE+0x00,0x40 | isp_read(ISP_OSD_BASE+0x00));    // {O_HDOSD_EN, O_HDOSD_GRD_INTERLACE, O_HDOSD_GRD_FSWAP, O_HDOSD_GRD_INDEXZERO_EN, O_HDOSD_FNT_YLPF_EN, O_HDOSD_FNT_CLPF_EN, O_HDOSD_BLKTIMER_RST, O_HDOSD_OUTLINE_EN}
        isp_write(ISP_OSD_BASE+0xCF,0x01 | isp_read(ISP_OSD_BASE+0xCF));    // {O_OSD_IN_CSWAP, O_OSD_YC422_CROMA, O_OSD_YC422_OUT, O_OSD_ROM_EN, O_OSD_ROM_CHINESE_TRADITIONAL, O_OSD_COLOR_OFF, O_OSD_BUS_ENABLE}
        return;
    }
    else if(init_mode == 0)
    {
        // Don't Use RAM FONT, Only Use ROM FONT
    #if(ENV_TEST != ENV_TEST_OFF)
        gl_gvr_hnum     = 10;
        gl_gvr_vnum     = 10;
    #else
        gl_gvr_hnum     = 33;
        gl_gvr_vnum     = 31;
    #endif

    #if defined OSD_OPTION_FSIZEX2
        isp_write(ISP_OSD_BASE+0x07,0x5F);          // {1'd0, O_OSD_VSIZEx2, O_OSD_GRD_VSIZE};
        isp_write(ISP_OSD_BASE+0x08,0x5F);          // {1'd0, O_OSD_HSIZEx2, O_OSD_GRD_HSIZE};
    #else
        isp_write(ISP_OSD_BASE+0x07,0x1F);          // {1'd0, O_OSD_VSIZEx2, O_OSD_GRD_VSIZE};
        isp_write(ISP_OSD_BASE+0x08,0x1F);          // {1'd0, O_OSD_HSIZEx2, O_OSD_GRD_HSIZE};
    #endif

        isp_write(ISP_OSD_BASE+0x09,0x80);          // O_OSD_GRD_PREVSYNC_OFFSET[7:0];
//      isp_write(ISP_OSD_BASE+0x0A,0x00);          // O_OSD_GRD_PREVSYNC_OFFSET[15:8];
//      isp_write(ISP_OSD_BASE+0x0B,0x00);          // {7'd0, O_OSD_GRD_PREVSYNC_OFFSET[16]};
//      isp_write(ISP_OSD_BASE+0x0C,0x00);          // {3'd0, O_OSD_GRD_SDRREQ_WAIT};
    }
    else if(init_mode == 1)
    {
    #if(ENV_TEST != ENV_TEST_OFF)
        gl_gvr_hnum     = 10;
        gl_gvr_vnum     = 10;
    #else
        gl_gvr_hnum     = 40;
        gl_gvr_vnum     = 23;
    #endif

    #if defined OSD_OPTION_FSIZEX2
        isp_write(ISP_OSD_BASE+0x07,0x6F);              // {1'd0, O_OSD_VSIZEx2, O_OSD_GRD_VSIZE};
        isp_write(ISP_OSD_BASE+0x08,0x6F);              // {1'd0, O_OSD_HSIZEx2, O_OSD_GRD_HSIZE};
    #else
        isp_write(ISP_OSD_BASE+0x07,0x2F);              // {1'd0, O_OSD_VSIZEx2, O_OSD_GRD_VSIZE};
        isp_write(ISP_OSD_BASE+0x08,0x2F);              // {1'd0, O_OSD_HSIZEx2, O_OSD_GRD_HSIZE};
    #endif

        isp_write(ISP_OSD_BASE+0x09,0x80);              // O_OSD_GRD_PREVSYNC_OFFSET[7:0];
//      isp_write(ISP_OSD_BASE+0x0A,0x00);              // O_OSD_GRD_PREVSYNC_OFFSET[15:8];
//      isp_write(ISP_OSD_BASE+0x0B,0x00);              // {7'd0, O_OSD_GRD_PREVSYNC_OFFSET[16]};
//      isp_write(ISP_OSD_BASE+0x0C,0x00);              // {3'd0, O_OSD_GRD_SDRREQ_WAIT};
    }
#endif

    isp_write(ISP_OSD_BASE+0x05,gl_gvr_vnum-1);         // {2'd0, O_OSD_GRD_VNUM};
    isp_write(ISP_OSD_BASE+0x06,gl_gvr_hnum-1);         // {2'd0, O_OSD_GRD_HNUM};

//  isp_write(ISP_OSD_BASE+0x01,0x00);                  // O_OSD_GRD_VSTART[7:0];
//  isp_write(ISP_OSD_BASE+0x02,0x00);                  // {5'd0, O_OSD_GRD_VSTART[10:8]};
//  isp_write(ISP_OSD_BASE+0x03,0x00);                  // O_OSD_GRD_HSTART[7:0] ;
//  isp_write(ISP_OSD_BASE+0x04,0x00);                  // {5'd0, O_OSD_GRD_HSTART[10:8]};

#if defined OSD_OPTION_FMARGIN
    isp_write(ISP_OSD_BASE+0x0D,0x33);                  // {I_GRD_MARGIN_V, I_GRD_MARGIN_H}
#else
//  isp_write(ISP_OSD_BASE+0x0D,0x00);                  // {I_GRD_MARGIN_V, I_GRD_MARGIN_H}
#endif

//  isp_write(ISP_OSD_BASE+0x1F,0x00);                  // O_OSD_ATTR_STYLE0;   // All off
    isp_write(ISP_OSD_BASE+0x20,0x80);                  // O_OSD_ATTR_STYLE1;   // Trans ON
    isp_write(ISP_OSD_BASE+0x21,0x40);                  // O_OSD_ATTR_STYLE2;   // blk ON
    isp_write(ISP_OSD_BASE+0x22,0x01);                  // O_OSD_ATTR_STYLE3;   // BG ON

    isp_write(ISP_OSD_BASE+0x2F,0x67);                  // O_OSD_ATTR_COLOR0[7:0];
    isp_write(ISP_OSD_BASE+0x30,0x01);                  // O_OSD_ATTR_COLOR0[15:8];
    isp_write(ISP_OSD_BASE+0x31,0x67);                  // O_OSD_ATTR_COLOR1[7:0];
    isp_write(ISP_OSD_BASE+0x32,0x23);                  // O_OSD_ATTR_COLOR1[15:8];
    isp_write(ISP_OSD_BASE+0x33,0x67);                  // O_OSD_ATTR_COLOR2[7:0];
    isp_write(ISP_OSD_BASE+0x34,0x45);                  // O_OSD_ATTR_COLOR2[15:8];

    isp_write(ISP_OSD_BASE+0x3F,0xC0);                  // O_OSD_TRANS_TABLE0[7:0]; // 50%
    isp_write(ISP_OSD_BASE+0x40,0xC0);                  // O_OSD_TRANS_TABLE0[15:8];
    isp_write(ISP_OSD_BASE+0x41,0xC0);                  // O_OSD_TRANS_TABLE0[23:16];
    isp_write(ISP_OSD_BASE+0x42,0xC0);                  // O_OSD_TRANS_TABLE0[31:24];

    isp_write(ISP_OSD_BASE+0x62,0xF0);                  // O_OSD_BLK_TABLE0[31:24];
    isp_write(ISP_OSD_BASE+0x61,0x1F);                  // O_OSD_BLK_TABLE0[23:16];
    isp_write(ISP_OSD_BASE+0x60,0xFF);                  // O_OSD_BLK_TABLE0[15:8];
    isp_write(ISP_OSD_BASE+0x5F,0x80);                  // O_OSD_BLK_TABLE0[7:0];

    isp_write(ISP_OSD_BASE+0x6F,0x10);                  // O_OSD_COLOR0[7:0];   // White(y180:cb128:cr128)
    isp_write(ISP_OSD_BASE+0x70,0xB6);                  // O_OSD_COLOR0[15:8];
    isp_write(ISP_OSD_BASE+0x71,0xBA);                  // O_OSD_COLOR1[7:0];   // Red(y51:cb109:cr212)
    isp_write(ISP_OSD_BASE+0x72,0x31);                  // O_OSD_COLOR1[15:8];
    isp_write(ISP_OSD_BASE+0x73,0x4F);                  // O_OSD_COLOR2[7:0];   // Blue(y28:cb212:cr120)
    isp_write(ISP_OSD_BASE+0x74,0x1F);                  // O_OSD_COLOR2[15:8];
    isp_write(ISP_OSD_BASE+0x75,0xE6);                  // O_OSD_COLOR3[7:0];   // Green(y133:cb63:cr52)
    isp_write(ISP_OSD_BASE+0x76,0x84);                  // O_OSD_COLOR3[15:8];
    isp_write(ISP_OSD_BASE+0x77,0xB1);                  // O_OSD_COLOR4[7:0];   // Yellow(y168:cb44:cr136)
    isp_write(ISP_OSD_BASE+0x78,0xA8);                  // O_OSD_COLOR4[15:8];
    isp_write(ISP_OSD_BASE+0x79,0x45);                  // O_OSD_COLOR5[7:0];   // Cyan(y145:cb147:cr44)
    isp_write(ISP_OSD_BASE+0x7A,0x92);                  // O_OSD_COLOR5[15:8];
    isp_write(ISP_OSD_BASE+0x7B,0x19);                  // O_OSD_COLOR6[7:0];   // Megenta(y63:cb193:cr204)
    isp_write(ISP_OSD_BASE+0x7C,0x3F);                  // O_OSD_COLOR6[15:8];
    isp_write(ISP_OSD_BASE+0x7D,0x10);                  // O_OSD_COLOR7[7:0];   // Black(y16:cb128:cr128)
    isp_write(ISP_OSD_BASE+0x7E,0x12);                  // O_OSD_COLOR7[15:8];

    isp_write(ISP_OSD_BASE+0x8F,0x10);                  // O_OSD_OUTLINE_Y;
    isp_write(ISP_OSD_BASE+0x90,0x80);                  // O_OSD_OUTLINE_CB;
    isp_write(ISP_OSD_BASE+0x91,0x80);                  // O_OSD_OUTLINE_CR;

    isp_write(ISP_OSD_BASE+0x9B,0x19);                  // {3'd0, O_OSD_BOX0_EN, O_OSD_BOX0_STYLE, O_OSD_BOX0_PRI, O_OSD_BOX0_TRANS_EN};
    isp_write(ISP_OSD_BASE+0x9C,0x40);                  // O_OSD_BOX0_SX[7:0];
//  isp_write(ISP_OSD_BASE+0x9D,0x00);                  // {5'd0, O_OSD_BOX0_SX[10:8]};
    isp_write(ISP_OSD_BASE+0x9E,0x40);                  // O_OSD_BOX0_SY[7:0];
//  isp_write(ISP_OSD_BASE+0x9F,0x00);                  // {5'd0, O_OSD_BOX0_SY[10:8]};
    isp_write(ISP_OSD_BASE+0xA0,0x60);                  // O_OSD_BOX0_EX[7:0];
//  isp_write(ISP_OSD_BASE+0xA1,0x00);                  // {5'd0, O_OSD_BOX0_EX[10:8]};
    isp_write(ISP_OSD_BASE+0xA2,0x60);                  // O_OSD_BOX0_EY[7:0];
//  isp_write(ISP_OSD_BASE+0xA3,0x00);                  // {5'd0, O_OSD_BOX0_EY[10:8]};
    isp_write(ISP_OSD_BASE+0xA4,0xA0);                  // O_OSD_BOX0_Y;
    isp_write(ISP_OSD_BASE+0xA5,0x80);                  // O_OSD_BOX0_CB;
    isp_write(ISP_OSD_BASE+0xA6,0x80);                  // O_OSD_BOX0_CR;
    isp_write(ISP_OSD_BASE+0xA7,0x40);                  // O_OSD_BOX0_TRANS_VALUE;
#ifdef OSD_OPTION_CHINESE_TRADITIONAL
    isp_write(ISP_OSD_BASE+0xCF,0x0C);                  // {O_OSD_IN_CSWAP, O_OSD_YC422_CROMA, O_OSD_YC422_OUT, O_OSD_ROM_EN, O_OSD_ROM_CHINESE_TRADITIONAL, O_OSD_COLOR_OFF, O_OSD_BUS_ENABLE}
#else
    isp_write(ISP_OSD_BASE+0xCF,0x08);                  // {O_OSD_IN_CSWAP, O_OSD_YC422_CROMA, O_OSD_YC422_OUT, O_OSD_ROM_EN, O_OSD_ROM_CHINESE_TRADITIONAL, O_OSD_COLOR_OFF, O_OSD_BUS_ENABLE}
#endif
    isp_write(ISP_OSD_BASE+0xD4,0x11);                  // O_HDOSD_BOX0_EDGEDEPTH;
    isp_write(ISP_OSD_BASE+0xD0,OSD_BASE_ADDR);         // O_HDOSD_BUS_BASEADDR[7:0];
    isp_write(ISP_OSD_BASE+0xD1,OSD_BASE_ADDR >> 8);    // O_HDOSD_BUS_BASEADDR[15:8];
    isp_write(ISP_OSD_BASE+0xD2,OSD_BASE_ADDR >> 16);   // O_HDOSD_BUS_BASEADDR[23:16];
    isp_write(ISP_OSD_BASE+0xD3,OSD_BASE_ADDR >> 24);   // O_HDOSD_BUS_BASEADDR[31:24];
#ifdef OSD_FAST_LOAD
    isp_write(ISP_OSD_BASE+0xD8,0x01);                  // I_ROM_BASE_INDEX[7:0]
//  isp_write(ISP_OSD_BASE+0xD9,0x00);                  // I_ROM_BASE_INDEX[9:8]
#else
    isp_write(ISP_OSD_BASE+0xD8,0x04);                  // I_ROM_BASE_INDEX[7:0]
//  isp_write(ISP_OSD_BASE+0xD9,0x00);                  // I_ROM_BASE_INDEX[9:8]
#endif
//  isp_write(ISP_OSD_BASE+0xDA,0x00);                  // {7'h0, I_ROM_SEL_FONT}

    Command_Clear(1, 0, 0, 0, 0, 0, 0);
    isp_write(ISP_OSD_BASE+0x00,0x90);                  // {O_HDOSD_EN, O_HDOSD_GRD_INTERLACE, O_HDOSD_GRD_FSWAP, O_HDOSD_GRD_INDEXZERO_EN, O_HDOSD_FNT_YLPF_EN, O_HDOSD_FNT_CLPF_EN, O_HDOSD_BLKTIMER_RST, O_HDOSD_OUTLINE_EN}
}

void OSD_Test(int test_mode) {
// test_mode == 0   => Write Test
//              1   => Read Test
//              2   => Clear Command Test
//              3   => Change Command Test
    unsigned int rdata;

    if(test_mode == 0)
    {
#ifdef OSD_FAST_TEST
        OSD_FontWrite(1, 0, 0, 0, 1);
        OSD_FontWrite(2, 0, 0, 0, 6);
#else
        OSD_FontWrite(0, 0, 0, 0, 0);
        OSD_FontWrite(1, 0, 0, 0, 1);
        OSD_FontWrite(2, 0, 0, 0, 2);
        OSD_FontWrite(0, 1, 1, 0, 0);
        OSD_FontWrite(1, 1, 1, 0, 1);
        OSD_FontWrite(2, 1, 1, 0, 2);
        OSD_FontWrite(0, 2, 2, 0, 0);
        OSD_FontWrite(1, 2, 2, 0, 1);
        OSD_FontWrite(2, 2, 2, 0, 2);
        OSD_FontWrite(0, 3, 3, 0, 0);
        OSD_FontWrite(1, 3, 3, 0, 1);
        OSD_FontWrite(2, 3, 3, 0, 2);
        OSD_FontWrite(0, 4, 0, 1, 0);
        OSD_FontWrite(1, 4, 0, 1, 1);
        OSD_FontWrite(2, 4, 0, 1, 2);
        OSD_FontWrite(0, 5, 0, 2, 0);
        OSD_FontWrite(1, 5, 0, 2, 1);
        OSD_FontWrite(2, 5, 0, 2, 2);
        OSD_FontWrite(0, 6, 0, 0, 4);
        OSD_FontWrite(1, 6, 0, 0, 5);
        OSD_FontWrite(2, 6, 0, 0, 6);
        OSD_FontWrite(0, 7, 0, 0, 7);
        OSD_FontWrite(1, 7, 0, 0, 8);
        OSD_FontWrite(2, 7, 0, 0, 9);
#endif
    }
    else if(test_mode == 1)
    {
        rdata  = OSD_FontRead(1, 1);
        isp_write(0xFFFF,rdata >> 8);       //write dummy
        isp_write(0xFFFF,rdata);            //write dummy

        rdata  = OSD_FontRead(2, 1);
        isp_write(0xFFFF,rdata >> 8);       //write dummy
        isp_write(0xFFFF,rdata);            //write dummy
    }
    else if(test_mode == 2)
    {
#ifdef OSD_FAST_TEST
        Command_Clear(0, 1, 1, 1, 0, 0, 0);
#else
        Command_Clear(1, 1, 1, 1, 0, 0, 0);
#endif
    }
    else if(test_mode == 3)
    {
#ifdef OSD_FAST_TEST
        Command_Change(0, 1, 1, 0, 0, 0, (gl_gvr_vnum-1), (gl_gvr_hnum-1), 0, 0, 0);
#else
        Command_Change(1, 1, 1, 0, 0, 0, (gl_gvr_vnum-1), (gl_gvr_hnum-1), 0, 0, 0);
#endif
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////
//  Function    :   Command_Clear                                                               //
//  Error Msg   :   0x00        all green                                                       //
//                  0x01        vertical GVR index over                                         //
//                  0x02        horizontal GVR index over                                       //
//                  0x03        a previous command is not finished                              //
//  Assign Bits :                                                                               //
//       [15:12]  [11:8]   [7:4]     [3:0]                                                      //
//    {  Color1,  Color2,  Color3,  BFColor  }                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////
unsigned char   Command_Clear(BOOL bWait, BOOL bStyle, BOOL bColor, BOOL bIndex, unsigned char Style, unsigned char Color, unsigned int Index)
{
    unsigned char Cmd;

    // check previous command
    Cmd = isp_read(ISP_OSD_BASE+0x92);
    if(Cmd & 0x10)          return 0x03;

    isp_write(ISP_OSD_BASE+0x98,((Style & 0x07) << 5) | ((Color & 0x07) << 2));
    isp_write(ISP_OSD_BASE+0x99,Index);
    isp_write(ISP_OSD_BASE+0x9A,Index >> 8);

    isp_write(ISP_OSD_BASE+0x92,0x10 | ((bStyle & 0x01) << 2) | ((bColor & 0x01) << 1) | (bIndex & 0x01));
    if(bWait)
    {
        while(0x10 & isp_read(ISP_OSD_BASE+0x92))
        {
            delay(1);
        }
    }

    return 0x00;
}

//////////////////////////////////////////////////////////////////////////////////////////////////
//  Function    :   Command_Change                                                              //
//  Error Msg   :   0x00        all green                                                       //
//                  0x01        vertical GVR index over                                         //
//                  0x02        horizontal GVR index over                                       //
//                  0x03        a previous command is not finished                              //
//  Assign Bits :                                                                               //
//       [15:12]  [11:8]   [7:4]     [3:0]                                                      //
//    {  Color1,  Color2,  Color3,  BFColor  }                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////
unsigned char   Command_Change(BOOL bWait, BOOL bStyle, BOOL bColor, BOOL bIndex, unsigned int st_vpos, unsigned int st_hpos, unsigned int ed_vpos, unsigned int ed_hpos, unsigned char Style, unsigned char Color, unsigned int Index)
{
    unsigned int vpos_st, hpos_st, vpos_ed, hpos_ed;
    unsigned char Cmd;

    vpos_st    = (st_vpos >= gl_gvr_vnum)   ? (gl_gvr_vnum - 1)    : st_vpos;
    hpos_st    = (st_hpos >= gl_gvr_hnum)   ? (gl_gvr_hnum - 1)    : st_hpos;
    vpos_ed    = (ed_vpos >= gl_gvr_vnum)   ? (gl_gvr_vnum - 1)    : ed_vpos;
    hpos_ed    = (ed_hpos >= gl_gvr_hnum)   ? (gl_gvr_hnum - 1)    : ed_hpos;
    if(vpos_ed <= vpos_st)  return 0x01;
    if(hpos_ed <= hpos_st)  return 0x02;

    // check previous command
    Cmd = isp_read(ISP_OSD_BASE+0x93);
    if(Cmd & 0x10)  return 0x03;

    isp_write(ISP_OSD_BASE+0x94,vpos_st);
    isp_write(ISP_OSD_BASE+0x95,hpos_st);
    isp_write(ISP_OSD_BASE+0x96,vpos_ed);
    isp_write(ISP_OSD_BASE+0x97,hpos_ed);
    isp_write(ISP_OSD_BASE+0x98,((Style & 0x07) << 5) | ((Color & 0x07) << 2));
    isp_write(ISP_OSD_BASE+0x99,Index);
    isp_write(ISP_OSD_BASE+0x9A,Index >> 8);

    isp_write(ISP_OSD_BASE+0x93,0x10 | ((bStyle & 0x01) << 2) | ((bColor & 0x01) << 1) | (bIndex & 0x01));
    if(bWait)
    {
        while(0x10 & isp_read(ISP_OSD_BASE+0x93))
        {
            delay(1);
        }
    }

    return 0x00;
}
