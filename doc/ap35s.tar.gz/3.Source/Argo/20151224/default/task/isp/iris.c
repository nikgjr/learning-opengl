#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void IRIS_set(void)
{
	tdk_printf("IRIS set\n");
    isp_write(ISP_IRIS_BASE+0x00,0x1F); // {O_IRIS_REG_CHG, 2'd0, O_IRIS_REG_CHG_AUTO_EN, O_IRIS_LSEN, O_IRIS_LSEXTG, O_IRIS_VBOUND, O_IRIS_HBOUND};
    isp_write(ISP_IRIS_BASE+0x01,0x40); // {1'd0, O_IRIS_NDIV, O_IRIS_LSSELLN, O_IRIS_LSSHIFT};
//  isp_write(ISP_IRIS_BASE+0x02,0x10); // O_IRIS_BOUND_VAL;
    isp_write(ISP_IRIS_BASE+0x03,0x73); // {1'd0, O_IRIS_CLIP_EN, O_IRIS_2ND_AGCLF_USESTEP, O_IRIS_2ND_AGCLF_EN, O_IRIS_SEL, O_IRIS_VIDEO_SEL};
//  isp_write(ISP_IRIS_BASE+0x05,0x00); // {6'd0, O_IRIS_USER_DCLEVEL[9:8]};
//  isp_write(ISP_IRIS_BASE+0x04,0x00); // O_IRIS_USER_DCLEVEL[7:0];
    isp_write(ISP_IRIS_BASE+0x07,0x10); // {2'd0, O_IRIS_1ND_AGCLEVEL[13:8]};
//  isp_write(ISP_IRIS_BASE+0x06,0x00); // O_IRIS_1ND_AGCLEVEL[7:0];
    isp_write(ISP_IRIS_BASE+0x09,0x01); // {5'd0, O_IRIS_1ND_OFFSET[10:8]};
//  isp_write(ISP_IRIS_BASE+0x08,0x00); // O_IRIS_1ND_OFFSET[7:0];
    isp_write(ISP_IRIS_BASE+0x0B,0x04); // {2'd0, O_IRIS_2ND_AGCLEVEL[13:8]};
//  isp_write(ISP_IRIS_BASE+0x0A,0x00); // O_IRIS_2ND_AGCLEVEL[7:0];
//  isp_write(ISP_IRIS_BASE+0x0D,0x00); // O_IRIS_2ND_AGCLF_SPD[15:8];
    isp_write(ISP_IRIS_BASE+0x0C,0x10); // O_IRIS_2ND_AGCLF_SPD[7:0];
//  isp_write(ISP_IRIS_BASE+0x0F,0x00); // {3'd0, O_IRIS_2ND_AGCLF_STEP[12:8]};
    isp_write(ISP_IRIS_BASE+0x0E,0x02); // O_IRIS_2ND_AGCLF_STEP[7:0];
    isp_write(ISP_IRIS_BASE+0x10,0xF0); // O_IRIS_CLIP_HIGH[7:0];
    isp_write(ISP_IRIS_BASE+0x11,0x10); // O_IRIS_CLIP_LOW[7:0];
    isp_write(ISP_IRIS_BASE+0x13,0x04); // O_IRIS_PWM_MAX[15:8];
//  isp_write(ISP_IRIS_BASE+0x12,0x00); // O_IRIS_PWM_MAX[7:0];
    isp_write(ISP_IRIS_BASE+0x14,0x84); // {O_IRIS_PWM_ACC_SHIFT, 1'd0, O_IRIS_PWM_ACCEN, O_IRIS_PWM_INV, O_IRIS_PWM_BASE_INV};
    isp_write(ISP_IRIS_BASE+0x15,0x04); // {5'd0, O_IRIS_PWM_TRIGER_EN, O_IRIS_PWM_TRIGER_SIGNAL, O_IRIS_PWM_TRIGER_DIR};
    isp_write(ISP_IRIS_BASE+0x17,0x02); // O_IRIS_PWM_TRIGER_HIGHVAL[15:8];
//  isp_write(ISP_IRIS_BASE+0x16,0x00); // O_IRIS_PWM_TRIGER_HIGHVAL[7:0];
//  isp_write(ISP_IRIS_BASE+0x19,0x00); // {6'd0, O_IRIS_PWM_TRIGER_LENGTH[9:8]};
    isp_write(ISP_IRIS_BASE+0x18,0x08); // O_IRIS_PWM_TRIGER_LENGTH[7:0];
//  isp_write(ISP_IRIS_BASE+0x1B,0x00); // O_IRIS_PWM_BASE_MAX[15:8];
    isp_write(ISP_IRIS_BASE+0x1A,0x08); // O_IRIS_PWM_BASE_MAX[7:0];
//  isp_write(ISP_IRIS_BASE+0x1D,0x00); // O_IRIS_PWM_BASE_HIGHVAL[15:8];
    isp_write(ISP_IRIS_BASE+0x1C,0x04); // O_IRIS_PWM_BASE_HIGHVAL[7:0];

    isp_write(ISP_IRIS_BASE+0x12,0x06); // {5'd0, O_IRIS_PWM_TRIGER_EN, O_IRIS_PWM_TRIGER_SIGNAL, O_IRIS_PWM_TRIGER_DIR};
    delay(1);
    isp_write(ISP_IRIS_BASE+0x12,0x04); // {5'd0, O_IRIS_PWM_TRIGER_EN, O_IRIS_PWM_TRIGER_SIGNAL, O_IRIS_PWM_TRIGER_DIR};
}
