#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void OF_set(unsigned char b_CROP, unsigned char b_FREERUN, unsigned char b_REGEN, unsigned char b_FORMAT)
{

    unsigned int hfp, hsy, hbp, vfp, vsy;
    unsigned int line_start;
    unsigned int vcrop_pos;
    unsigned int hcrop_pos;

	tdk_printf("OF set\n");
    hbp = 0;
    vfp = 0;
    vsy = 0;
#if(FRC_MODE_SEL == FRC_MODE_1920X1080)
    hfp = 20;
    hsy = 40;
#elif(FRC_MODE_SEL == FRC_MODE_1280X720_30HZ)
    hfp = 110;
    hsy = 40;
#elif(FRC_MODE_SEL == FRC_MODE_1280X720_60HZ)
    hfp = 110;
    hsy = 40;
#else
    hfp = 0;
    hsy = 0;
#endif

#if(FRC_MODE_SEL == FRC_MODE_1280X720_30HZ)
    vfp = 10;
    line_start = 0x001A;
#elif(FRC_MODE_SEL == FRC_MODE_1280X720_60HZ)
    vfp = 10;
    line_start = 0x001A;
#else
    vfp = 0;
    line_start = 0x0000;
#endif

    #if(LDC_MODE_SEL == LDC_OFF_SET)
    vcrop_pos = (FRC_VACT - OUTPUT_FORMATTER_VACT)/2;
    hcrop_pos = (FRC_HACT - OUTPUT_FORMATTER_HACT)/2;
    #else
    vcrop_pos = (OUTPUT_FORMATTER_VACT - OUTPUT_FORMATTER_VACT)/2;
    hcrop_pos = (OUTPUT_FORMATTER_HACT - OUTPUT_FORMATTER_HACT)/2;
    #endif

    isp_write(0x00E1,0x00);                                         // {6'd0, O_HSYNC_BYPASS, O_HSYNC_BYPASS_FR};
//  isp_write(0x00E1,0x00);                                         // {6'd0, O_HSYNC_BYPASS, O_HSYNC_BYPASS_FR};
    if(b_CROP)
    {
        isp_write(ISP_OF_BASE+0x01,0x01 | (0xFC & isp_read(ISP_OF_BASE+0x01))); // {I_CRIP_YSEL,I_CRIP_CSEL,I_CROP_HSYN_LOCK_EN,I_CROP_HACT_LOCK_EN,I_CROP_VBOUND_EN,I_CROP_VEN};
        isp_write(ISP_OF_BASE+0x53,0x0C | (0xF3 & isp_read(ISP_OF_BASE+0x53))); // {2'h0,I_CROP_NONFREERUN,I_CROP_VTOTAL_EN,I_CROP_HSEN,I_CROP_HAEN,I_CROP_HBOUND_EN,I_CROP_HSEL};
        isp_write(ISP_OF_BASE+0x03,vcrop_pos >> 8);                             // {4'd0, I_CROP_VPOS[11:8]};
        isp_write(ISP_OF_BASE+0x02,vcrop_pos);                                  // I_CROP_VPOS[7:0];
        isp_write(ISP_OF_BASE+0x05,hcrop_pos >> 8);                             // {3'd0, I_CROP_HPOS[12:8]};
        isp_write(ISP_OF_BASE+0x04,hcrop_pos);                                  // I_CROP_HPOS[7:0];
        isp_write(ISP_OF_BASE+0x07,OUTPUT_FORMATTER_VACT >> 8);                 // {4'd0, O_OF_CROP_VSIZE[11:8]};
        isp_write(ISP_OF_BASE+0x06,OUTPUT_FORMATTER_VACT);                      // O_OF_CROP_VSIZE[7:0];
        isp_write(ISP_OF_BASE+0x09,OUTPUT_FORMATTER_HACT >> 8);                 // {3'd0, O_OF_CROP_HSIZE[12:8]};
        isp_write(ISP_OF_BASE+0x08,OUTPUT_FORMATTER_HACT);                      // O_OF_CROP_HSIZE[7:0];
    }

    if(b_FREERUN && (0x01 != (0x03 & isp_read(0x0680))))
    {
        isp_write(ISP_OF_BASE+0x0A,0xFE);                           // {O_OF_FR_H_AUTO, O_OF_FR_VSYNC_ALIGN, O_OF_FR_HSYN_EN, O_OF_FR_HACT_EN, O_OF_BG_EN};
        isp_write(ISP_OF_BASE+0x0F,OUTPUT_FORMATTER_VBLK >> 8);     // {3'd0, O_OF_FR_VBLK[12:8]};
        isp_write(ISP_OF_BASE+0x0E,OUTPUT_FORMATTER_VBLK);          // O_OF_FR_VBLK[7:0];
        isp_write(ISP_OF_BASE+0x11,OUTPUT_FORMATTER_VACT >> 8);     // {3'd0, O_OF_FR_VACT[12:8]};
        isp_write(ISP_OF_BASE+0x10,OUTPUT_FORMATTER_VACT);          // O_OF_FR_VACT[7:0];
    }

    if(b_REGEN)
    {
//      isp_write(ISP_OF_BASE+0x1A,0x14);                           // {3'd0, O_OF_REGEN_HSYN_EN, O_OF_REGEN_HSYN_SEL, O_OF_REGEN_HACT_EN, O_OF_REGEN_HACT_SEL};
//      isp_write(ISP_OF_BASE+0x23,0x0A);                           // {O_OF_REGEN_HSYN_LOCK, O_OF_REGEN_HSYN_LOCK_MODE, O_OF_REGEN_HACT_LOCK, O_OF_REGEN_HACT_LOCK_MODE, O_OF_REGEN_VSYN_EN, O_OF_REGEN_VSYN_ALIGN_EN, O_OF_REGEN_VSYN_ALIGN_SEL};
        isp_write(ISP_OF_BASE+0x1A,0x00);                           // {3'd0, O_OF_REGEN_HSYN_EN, O_OF_REGEN_HSYN_SEL, O_OF_REGEN_HACT_EN, O_OF_REGEN_HACT_SEL};
        isp_write(ISP_OF_BASE+0x23,0x00);                           // {O_OF_REGEN_HSYN_LOCK, O_OF_REGEN_HSYN_LOCK_MODE, O_OF_REGEN_HACT_LOCK, O_OF_REGEN_HACT_LOCK_MODE, O_OF_REGEN_VSYN_EN, O_OF_REGEN_VSYN_ALIGN_EN, O_OF_REGEN_VSYN_ALIGN_SEL};

        hbp = OUTPUT_FORMATTER_HBLK - (hfp + hsy);
        isp_write(ISP_OF_BASE+0x1C,hfp >> 8);                       // {3'd0, O_OF_REGEN_HSYN_FP[12:8]};
        isp_write(ISP_OF_BASE+0x1B,hfp);                            // O_OF_REGEN_HSYN_FP[7:0];
        isp_write(ISP_OF_BASE+0x1E,hsy >> 8);                       // {3'd0, O_OF_REGEN_HSYN_SY[12:8]};
        isp_write(ISP_OF_BASE+0x1D,hsy);                            // O_OF_REGEN_HSYN_SY[7:0];
        isp_write(ISP_OF_BASE+0x20,hbp >> 8);                       // {3'd0, O_OF_REGEN_HACT_BP[12:8]};
        isp_write(ISP_OF_BASE+0x1F,hbp);                            // O_OF_REGEN_HACT_BP[7:0];
        isp_write(ISP_OF_BASE+0x22,OUTPUT_FORMATTER_VACT >> 8);     // {3'd0, O_OF_REGEN_HACT_AT[12:8]};
        isp_write(ISP_OF_BASE+0x21,OUTPUT_FORMATTER_VACT);          // O_OF_REGEN_HACT_AT[7:0];

        vsy = OUTPUT_FORMATTER_VBLK - vfp;
        isp_write(ISP_OF_BASE+0x25,FRC_HTOTAL >> 1 >> 8);           // {3'd0, O_OF_REGEN_VSYN_DY[12:8]};
        isp_write(ISP_OF_BASE+0x24,FRC_HTOTAL >> 1);                // O_OF_REGEN_VSYN_DY[7:0];
        isp_write(ISP_OF_BASE+0x27,vfp >> 8);                       // {3'd0, O_OF_REGEN_VSYN_FP[11:8]};
        isp_write(ISP_OF_BASE+0x26,vfp);                            // O_OF_REGEN_VSYN_FP[7:0];
        isp_write(ISP_OF_BASE+0x29,vsy >> 8);                       // {3'd0, O_OF_REGEN_VSYN_SY[11:8]};
        isp_write(ISP_OF_BASE+0x28,vsy);                            // O_OF_REGEN_VSYN_SY[7:0];
    }

    if(b_FORMAT)
    {
        isp_write(ISP_OF_BASE+0x01,0x01 | (0xFC & isp_read(ISP_OF_BASE+0x01))); // {I_CRIP_YSEL,I_CRIP_CSEL,I_CROP_HSYN_LOCK_EN,I_CROP_HACT_LOCK_EN,I_CROP_VBOUND_EN,I_CROP_VEN};
        isp_write(ISP_OF_BASE+0x53,0x0C | (0xF3 & isp_read(ISP_OF_BASE+0x53))); // {2'h0,I_CROP_NONFREERUN,I_CROP_VTOTAL_EN,I_CROP_HSEN,I_CROP_HAEN,I_CROP_HBOUND_EN,I_CROP_HSEL};
        isp_write(ISP_OF_BASE+0x03,vcrop_pos >> 8);                             // {4'd0, I_CROP_VPOS[11:8]};
        isp_write(ISP_OF_BASE+0x02,vcrop_pos);                                  // I_CROP_VPOS[7:0];
        isp_write(ISP_OF_BASE+0x05,hcrop_pos >> 8);                             // {3'd0, I_CROP_HPOS[12:8]};
        isp_write(ISP_OF_BASE+0x04,hcrop_pos);                                  // I_CROP_HPOS[7:0];
        isp_write(ISP_OF_BASE+0x07,OUTPUT_FORMATTER_VACT >> 8);                 // {4'd0, O_OF_CROP_VSIZE[11:8]};
        isp_write(ISP_OF_BASE+0x06,OUTPUT_FORMATTER_VACT);                      // O_OF_CROP_VSIZE[7:0];
        isp_write(ISP_OF_BASE+0x09,OUTPUT_FORMATTER_HACT >> 8);                 // {3'd0, O_OF_CROP_HSIZE[12:8]};
        isp_write(ISP_OF_BASE+0x08,OUTPUT_FORMATTER_HACT);                      // O_OF_CROP_HSIZE[7:0];
//      isp_write(ISP_OF_BASE+0x2A,0x00);                                       // {6'd0, O_OF_CROMA_MODE, O_OF_CROMA_CSWAP};
        isp_write(ISP_OF_BASE+0x2B,0x87);                                       // {O_OF_BT1120ENC_INSERT_CRC_EN, O_OF_BT1120ENC_INSERT_CRC_IINV, O_OF_BT1120ENC_INSERT_CRC_OINV, O_OF_BT1120ENCD_HSY2HAT, O_OF_BT1120ENCD_YCSWAP, O_OF_BT1120ENC_EN, O_OF_BT1120ENC_USINGHSYNC, O_OF_BT1120ENC_INSERT_LINE_EN};
        isp_write(ISP_OF_BASE+0x2D,line_start >> 8);                            // {5'd0, O_OF_BT1120ENC_INSERT_STNUM[10:8]};
        isp_write(ISP_OF_BASE+0x2C,line_start);                                 // O_OF_BT1120ENC_INSERT_STNUM[7:0];
        isp_write(ISP_OF_BASE+0x2F,FRC_VTOTAL >> 8);                            // {5'd0, O_OF_BT1120ENC_INSERT_TOTALNUM[10:8]};
        isp_write(ISP_OF_BASE+0x2E,FRC_VTOTAL);                                 // O_OF_BT1120ENC_INSERT_TOTALNUM[7:0];

        isp_write(ISP_OF_BASE+0x30,0x2F);                           // {1'd0, O_OF_BT1120ENCD_VSY_POL, O_OF_BT1120ENCD_HSY_POL, O_OF_BT1120ENCD_HAT_POL, O_OF_BT1120ENCD_HSY_LOCK_EN, O_OF_BT1120ENCD_HSY_LOCK_VSEL, O_OF_BT1120ENCD_HAT_LOCK_EN, O_OF_BT1120ENCD_HAT_LOCK_VSEL};
        isp_write(ISP_OF_BASE+0x31,0x00);                           // {3'd0, O_OF_BT1120ENCD_BIT0};
        isp_write(ISP_OF_BASE+0x32,0x01);                           // {3'd0, O_OF_BT1120ENCD_BIT1};
        isp_write(ISP_OF_BASE+0x33,0x02);                           // {3'd0, O_OF_BT1120ENCD_BIT2};
        isp_write(ISP_OF_BASE+0x34,0x03);                           // {3'd0, O_OF_BT1120ENCD_BIT3};
        isp_write(ISP_OF_BASE+0x35,0x04);                           // {3'd0, O_OF_BT1120ENCD_BIT4};
        isp_write(ISP_OF_BASE+0x36,0x05);                           // {3'd0, O_OF_BT1120ENCD_BIT5};
        isp_write(ISP_OF_BASE+0x37,0x06);                           // {3'd0, O_OF_BT1120ENCD_BIT6};
        isp_write(ISP_OF_BASE+0x38,0x07);                           // {3'd0, O_OF_BT1120ENCD_BIT7};
        isp_write(ISP_OF_BASE+0x39,0x08);                           // {3'd0, O_OF_BT1120ENCD_BIT8};
        isp_write(ISP_OF_BASE+0x3A,0x09);                           // {3'd0, O_OF_BT1120ENCD_BIT9};
        isp_write(ISP_OF_BASE+0x3B,0x0A);                           // {3'd0, O_OF_BT1120ENCD_BIT10};
        isp_write(ISP_OF_BASE+0x3C,0x0B);                           // {3'd0, O_OF_BT1120ENCD_BIT11};
        isp_write(ISP_OF_BASE+0x3D,0x0C);                           // {3'd0, O_OF_BT1120ENCD_BIT12};
        isp_write(ISP_OF_BASE+0x3E,0x0D);                           // {3'd0, O_OF_BT1120ENCD_BIT13};
        isp_write(ISP_OF_BASE+0x3F,0x0E);                           // {3'd0, O_OF_BT1120ENCD_BIT14};
        isp_write(ISP_OF_BASE+0x40,0x0F);                           // {3'd0, O_OF_BT1120ENCD_BIT15};
        isp_write(ISP_OF_BASE+0x41,0x10);                           // {3'd0, O_OF_BT1120ENCD_BIT16};
        isp_write(ISP_OF_BASE+0x42,0x11);                           // {3'd0, O_OF_BT1120ENCD_BIT17};
        isp_write(ISP_OF_BASE+0x43,0x12);                           // {3'd0, O_OF_BT1120ENCD_BIT18};
        isp_write(ISP_OF_BASE+0x44,0x13);                           // {3'd0, O_OF_BT1120ENCD_BIT19};
        isp_write(ISP_OF_BASE+0x45,0x04);                           // {5'd0, O_OF_BT1120ENCM_EN, O_OF_BT1120ENCM_YCSWAP, O_OF_BT1120ENCM_ALIGN_SEL};
        isp_write(ISP_OF_BASE+0x46,0x2F);                           // {O_OF_BT1120ENCM_HSY2HAT, O_OF_BT1120ENCM_VSY_POL, O_OF_BT1120ENCM_HSY_POL, O_OF_BT1120ENCM_HAT_POL, O_OF_BT1120ENCM_HSY_LOCK_EN, O_OF_BT1120ENCM_HSY_LOCK_VSEL, O_OF_BT1120ENCM_HAT_LOCK_EN, O_OF_BT1120ENCM_HAT_LOCK_VSEL};
        isp_write(ISP_OF_BASE+0x47,0x01);                           // {O_OF_BT1120ENCM_BIT0, O_OF_BT1120ENCM_BIT1};
        isp_write(ISP_OF_BASE+0x48,0x23);                           // {O_OF_BT1120ENCM_BIT2, O_OF_BT1120ENCM_BIT3};
        isp_write(ISP_OF_BASE+0x49,0x45);                           // {O_OF_BT1120ENCM_BIT4, O_OF_BT1120ENCM_BIT5};
        isp_write(ISP_OF_BASE+0x4A,0x67);                           // {O_OF_BT1120ENCM_BIT6, O_OF_BT1120ENCM_BIT7};
        isp_write(ISP_OF_BASE+0x4B,0x89);                           // {O_OF_BT1120ENCM_BIT8, O_OF_BT1120ENCM_BIT9};
        isp_write(ISP_OF_BASE+0x4C,0x06);                           // {5'd0, O_OF_BT656ENC_EN, O_OF_BT656ENC_USINGHSYNC, O_OF_BT656ENC_YCSWAP};
        isp_write(ISP_OF_BASE+0x4D,0x2F);                           // {O_OF_BT656ENC_HSY2HAT, O_OF_BT656ENC_VSY_POL, O_OF_BT656ENC_HSY_POL, O_OF_BT656ENC_HAT_POL, O_OF_BT656ENC_HSY_LOCK_EN, O_OF_BT656ENC_HSY_LOCK_VSEL, O_OF_BT656ENC_HAT_LOCK_EN, O_OF_BT656ENC_HAT_LOCK_VSEL};
        isp_write(ISP_OF_BASE+0x4E,0x01);                           // {O_OF_BT656ENC_BIT0, O_OF_BT656ENC_BIT1};
        isp_write(ISP_OF_BASE+0x4F,0x23);                           // {O_OF_BT656ENC_BIT2, O_OF_BT656ENC_BIT3};
        isp_write(ISP_OF_BASE+0x50,0x45);                           // {O_OF_BT656ENC_BIT4, O_OF_BT656ENC_BIT5};
        isp_write(ISP_OF_BASE+0x51,0x67);                           // {O_OF_BT656ENC_BIT6, O_OF_BT656ENC_BIT7};
        isp_write(ISP_OF_BASE+0x52,0x89);                           // {O_OF_BT656ENC_BIT8, O_OF_BT656ENC_BIT9};
    }
}
