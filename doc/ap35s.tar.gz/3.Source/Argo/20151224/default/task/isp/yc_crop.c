#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void YC_CROP_set (void)
{
    unsigned int vcrop_pos;
    unsigned int hcrop_pos;

	tdk_printf("YC CROP set\n");

    vcrop_pos = (FRC_VACT - OUTPUT_FORMATTER_VACT)/2;
    hcrop_pos = (FRC_HACT - OUTPUT_FORMATTER_HACT)/2;

    isp_write(ISP_YCCROP_BASE+0x00,0x01                      );     // {2'h0,YC_VSYNC_REGEN_EN,YC_CROP_SEL,3'h0,YC_CROP_EN};
    isp_write(ISP_YCCROP_BASE+0x01,vcrop_pos                 );     //       YC_CROP_VACT_POS[ 7:0]       ;
    isp_write(ISP_YCCROP_BASE+0x02,vcrop_pos >> 8            );     // {4'h0,YC_CROP_VACT_POS[11:8]       };
    isp_write(ISP_YCCROP_BASE+0x03,hcrop_pos                 );     //       YC_CROP_HACT_POS[ 7:0]       ;
    isp_write(ISP_YCCROP_BASE+0x04,hcrop_pos >> 8            );     // {4'h0,YC_CROP_HACT_POS[11:8]       };
    isp_write(ISP_YCCROP_BASE+0x05,OUTPUT_FORMATTER_VACT     );     //       YC_CROP_VACT_CROP_SIZE[ 7:0] ;
    isp_write(ISP_YCCROP_BASE+0x06,OUTPUT_FORMATTER_VACT >> 8);     // {4'h0,YC_CROP_VACT_CROP_SIZE[11:8] };
    isp_write(ISP_YCCROP_BASE+0x07,OUTPUT_FORMATTER_HACT     );     //       YC_CROP_HACT_CROP_SIZE[ 7:0] ;
    isp_write(ISP_YCCROP_BASE+0x08,OUTPUT_FORMATTER_HACT >> 8);     // {4'h0,YC_CROP_HACT_CROP_SIZE[11:8] };
}
