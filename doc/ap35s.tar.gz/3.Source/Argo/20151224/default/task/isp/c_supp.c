#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void HLCSUPP_set(void)
{
	tdk_printf("Hight-Light Chroma Suppress\n");

    isp_write(ISP_HLCSUPP_BASE+0x00,0x00);  // HL_TEST_MODE, C_HL_SUP_EN, C_AGC_SUP_EN,
    isp_write(ISP_HLCSUPP_BASE+0x01,0xE0);  // C_HL_SUP_HI[7:0]
    isp_write(ISP_HLCSUPP_BASE+0x03,0x20);  // C_HL_SUP_LOW[7:0]
    isp_write(ISP_HLCSUPP_BASE+0x05,0x20);  // C_HL_SUP_HI_GAIN
    isp_write(ISP_HLCSUPP_BASE+0x06,0x20);  // C_HL_SUP_LOW_GAIN
//  isp_write(ISP_HLCSUPP_BASE+0x07,0x00);  // C_AGC_START_X
    isp_write(ISP_HLCSUPP_BASE+0x08,0x80);  // C_AGC_MIDDLE_X
    isp_write(ISP_HLCSUPP_BASE+0x09,0xFF);  // C_AGC_END_X
    isp_write(ISP_HLCSUPP_BASE+0x0A,0x80);  // C_AGC_START_Y
    isp_write(ISP_HLCSUPP_BASE+0x0B,0x40);  // C_AGC_MIDDLE_Y
    isp_write(ISP_HLCSUPP_BASE+0x0C,0x00);  // C_AGC_END_Y
}
