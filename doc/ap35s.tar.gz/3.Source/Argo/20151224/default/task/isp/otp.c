#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void OTP_set(unsigned char test_pattern)
{

    long long Ramp_Inc = 0;

	tdk_printf("OTP set\n");
    isp_write(ISP_OTP_BASE+0x00,0x18);          // {3'd0, O_OTP_EN, O_OTP_SYNCGEN_EN, 1'd0, O_OTP_SYNCGEN_HLOCK, O_OTP_CSWAP};
    isp_write(ISP_OTP_BASE+0x01,test_pattern);  // {3'd0, O_OTP_TST_PAT};
//  isp_write(ISP_OTP_BASE+0x03,0x00);          // {4'd0, O_OTP_VBLK_FP[11:8]};
//  isp_write(ISP_OTP_BASE+0x02,0x00);          // O_OTP_VBLK_FP[7:0];
    isp_write(ISP_OTP_BASE+0x05,FRC_VBLK >> 8); // {4'd0, O_OTP_VBLK_SY[11:8]};
    isp_write(ISP_OTP_BASE+0x04,FRC_VBLK);      // O_OTP_VBLK_SY[7:0];
//  isp_write(ISP_OTP_BASE+0x07,0x00);          // {4'd0, O_OTP_VBLK_BP[11:8]};
//  isp_write(ISP_OTP_BASE+0x06,0x00);          // O_OTP_VBLK_BP[7:0];
    isp_write(ISP_OTP_BASE+0x09,FRC_VACT >> 8); // {4'd0, O_OTP_VACT_SIZE[11:8]};
    isp_write(ISP_OTP_BASE+0x08,FRC_VACT);      // O_OTP_VACT_SIZE[7:0];
//  isp_write(ISP_OTP_BASE+0x13,0x00);          // {4'd0, O_OTP_HBLK_FP[11:8]};
//  isp_write(ISP_OTP_BASE+0x12,0x00);          // O_OTP_HBLK_FP[7:0];
    isp_write(ISP_OTP_BASE+0x15,FRC_HBLK >> 8); // {4'd0, O_OTP_HBLK_SY[11:8]};
    isp_write(ISP_OTP_BASE+0x14,FRC_HBLK);      // O_OTP_HBLK_SY[7:0];
//  isp_write(ISP_OTP_BASE+0x17,0x00);          // {4'd0, O_OTP_HBLK_BP[11:8]};
//  isp_write(ISP_OTP_BASE+0x16,0x00);          // O_OTP_HBLK_BP[7:0];
    isp_write(ISP_OTP_BASE+0x19,FRC_HACT >> 8); // {4'd0, O_OTP_HACT_SIZE[11:8]};
    isp_write(ISP_OTP_BASE+0x18,FRC_HACT);      // O_OTP_HACT_SIZE[7:0];
//  isp_write(ISP_OTP_BASE+0x1F,0x00);          // {6'd0, O_OTP_USER_Y[9:8]};
//  isp_write(ISP_OTP_BASE+0x1E,0x00);          // O_OTP_USER_Y[7:0];
//  isp_write(ISP_OTP_BASE+0x21,0x00);          // {6'd0, O_OTP_USER_CB[9:8]};
//  isp_write(ISP_OTP_BASE+0x20,0x00);          // O_OTP_USER_CR[7:0];
//  isp_write(ISP_OTP_BASE+0x23,0x00);          // {6'd0, O_OTP_USER_CR[9:8]};
//  isp_write(ISP_OTP_BASE+0x22,0x00);          // O_OTP_USER_CR[7:0];

    // OTP_RAMP_INC = 27402786 / HSIZE
    Ramp_Inc = (long long)27402786 / FRC_HACT;
    isp_write(ISP_OTP_BASE+0x26,Ramp_Inc >> 16);    // O_OTP_RAMP_INC[23:16];
    isp_write(ISP_OTP_BASE+0x25,Ramp_Inc >> 8);     // O_OTP_RAMP_INC[15:8];
    isp_write(ISP_OTP_BASE+0x24,Ramp_Inc);          // O_OTP_RAMP_INC[7:0];
}
