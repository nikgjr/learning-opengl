// IIF, Skip frame, Input CDC
#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"


void input_interface_set(void)
{
    unsigned int    IIF_HACT_SIZE;
    unsigned int    IIF_FP_HACT_SIZE;
    
    unsigned int    IIF_OB1_HACT_SIZE;
    unsigned int    IIF_OB1_FP_HACT_SIZE;
    
    unsigned int    IIF_OB2_HACT_SIZE;
    unsigned int    IIF_OB2_FP_HACT_SIZE;
	tdk_printf("HLC set\n");
#if(SENSOR_PARALLEL==ON)
    IIF_HACT_SIZE        = (unsigned int) IIF_HACT       ;
    IIF_FP_HACT_SIZE     = (unsigned int) IIF_FP_HACT    ;

    IIF_OB1_HACT_SIZE    = (unsigned int) IIF_OB1_HACT   ;
    IIF_OB1_FP_HACT_SIZE = (unsigned int) IIF_OB1_FP_HACT;

    IIF_OB2_HACT_SIZE    = (unsigned int) IIF_OB2_HACT   ;
    IIF_OB2_FP_HACT_SIZE = (unsigned int) IIF_OB2_FP_HACT;
#else
    #if(LVDS_BIT_SEL==LVDS_10BIT_SEL)
        IIF_HACT_SIZE        = (unsigned int) (IIF_HACT        * 1.25);
        IIF_FP_HACT_SIZE     = (unsigned int) (IIF_FP_HACT     * 1.25);

        IIF_OB1_HACT_SIZE    = (unsigned int) (IIF_OB1_HACT    * 1.25);
        IIF_OB1_FP_HACT_SIZE = (unsigned int) (IIF_OB1_FP_HACT * 1.25);

        IIF_OB2_HACT_SIZE    = (unsigned int) (IIF_OB2_HACT    * 1.25);
        IIF_OB2_FP_HACT_SIZE = (unsigned int) (IIF_OB2_FP_HACT * 1.25);
    #else
        IIF_HACT_SIZE        = (unsigned int) (IIF_HACT        * 1.5);
        IIF_FP_HACT_SIZE     = (unsigned int) (IIF_FP_HACT     * 1.5);

        IIF_OB1_HACT_SIZE    = (unsigned int) (IIF_OB1_HACT    * 1.5);
        IIF_OB1_FP_HACT_SIZE = (unsigned int) (IIF_OB1_FP_HACT * 1.5);

        IIF_OB2_HACT_SIZE    = (unsigned int) (IIF_OB2_HACT    * 1.5);
        IIF_OB2_FP_HACT_SIZE = (unsigned int) (IIF_OB2_FP_HACT * 1.5);
    #endif
#endif

#if(SENSOR_PARALLEL==ON)
        isp_write(ISP_IIF_BASE0+0x80,0x56);  //  {1'd0, IIF_CLK_EN_SEL, IIF_MC2_EN, IIF_MC1_EN, IIF_IS_INPUT_HACT, IIF_INPUT_VSYNC_POL, IIF_INPUT_HSYNC_POL, 1'b0};
        isp_write(ISP_IIF_BASE0+0xB2,0x01);  //  IIF_MC1_MAX_CLK_EN;
        isp_write(ISP_IIF_BASE0+0xB3,0x01);  //  IIF_MC1_MERGE_CLK_EN;

        isp_write(ISP_IIF_BASE0+0x92,0x01);  //  {3'd0, IIF_MC1_ASSIGN_BIT_01};
        isp_write(ISP_IIF_BASE0+0x93,0x02);  //  {3'd0, IIF_MC1_ASSIGN_BIT_02};
        isp_write(ISP_IIF_BASE0+0x94,0x03);  //  {3'd0, IIF_MC1_ASSIGN_BIT_03};
        isp_write(ISP_IIF_BASE0+0x95,0x04);  //  {3'd0, IIF_MC1_ASSIGN_BIT_04};
        isp_write(ISP_IIF_BASE0+0x96,0x05);  //  {3'd0, IIF_MC1_ASSIGN_BIT_05};
        isp_write(ISP_IIF_BASE0+0x97,0x06);  //  {3'd0, IIF_MC1_ASSIGN_BIT_06};
        isp_write(ISP_IIF_BASE0+0x98,0x07);  //  {3'd0, IIF_MC1_ASSIGN_BIT_07};
        isp_write(ISP_IIF_BASE0+0x99,0x08);  //  {3'd0, IIF_MC1_ASSIGN_BIT_08};
        isp_write(ISP_IIF_BASE0+0x9A,0x09);  //  {3'd0, IIF_MC1_ASSIGN_BIT_09};
        isp_write(ISP_IIF_BASE0+0x9B,0x0A);  //  {3'd0, IIF_MC1_ASSIGN_BIT_10};
        isp_write(ISP_IIF_BASE0+0x9C,0x0B);  //  {3'd0, IIF_MC1_ASSIGN_BIT_11};
        isp_write(ISP_IIF_BASE0+0x9D,0x0C);  //  {3'd0, IIF_MC1_ASSIGN_BIT_12};
        isp_write(ISP_IIF_BASE0+0x9E,0x0D);  //  {3'd0, IIF_MC1_ASSIGN_BIT_13};
        isp_write(ISP_IIF_BASE0+0x9F,0x0E);  //  {3'd0, IIF_MC1_ASSIGN_BIT_14};
        isp_write(ISP_IIF_BASE0+0xA0,0x0F);  //  {3'd0, IIF_MC1_ASSIGN_BIT_15};
        isp_write(ISP_IIF_BASE0+0xA1,0x10);  //  {3'd0, IIF_MC1_ASSIGN_BIT_16};
        isp_write(ISP_IIF_BASE0+0xA2,0x11);  //  {3'd0, IIF_MC1_ASSIGN_BIT_17};
        isp_write(ISP_IIF_BASE0+0xA3,0x12);  //  {3'd0, IIF_MC1_ASSIGN_BIT_18};
        isp_write(ISP_IIF_BASE0+0xA4,0x13);  //  {3'd0, IIF_MC1_ASSIGN_BIT_19};
        isp_write(ISP_IIF_BASE0+0xA5,0x14);  //  {3'd0, IIF_MC1_ASSIGN_BIT_20};
        isp_write(ISP_IIF_BASE0+0xA6,0x15);  //  {3'd0, IIF_MC1_ASSIGN_BIT_21};
        isp_write(ISP_IIF_BASE0+0xA7,0x16);  //  {3'd0, IIF_MC1_ASSIGN_BIT_22};
        isp_write(ISP_IIF_BASE0+0xA8,0x17);  //  {3'd0, IIF_MC1_ASSIGN_BIT_23};
        isp_write(ISP_IIF_BASE0+0xA9,0x18);  //  {3'd0, IIF_MC1_ASSIGN_BIT_24};
#else
        isp_write(ISP_IIF_BASE0+0x80,0x52);  //  {1'd0, IIF_CLK_EN_SEL, IIF_MC2_EN, IIF_MC1_EN, IIF_IS_INPUT_HACT, IIF_INPUT_VSYNC_POL, IIF_INPUT_HSYNC_POL, 1'b0};
    #if(LVDS_BIT_SEL==LVDS_10BIT_SEL)
        isp_write(ISP_IIF_BASE0+0xB2,0x05);  //  IIF_MC1_MAX_CLK_EN;
        isp_write(ISP_IIF_BASE0+0xB3,0x1E);  //  IIF_MC1_MERGE_CLK_EN;

        isp_write(ISP_IIF_BASE0+0x92,0x00);  //  {3'd0, IIF_MC1_ASSIGN_BIT_01};
        isp_write(ISP_IIF_BASE0+0x93,0x00);  //  {3'd0, IIF_MC1_ASSIGN_BIT_02};
        isp_write(ISP_IIF_BASE0+0x94,0x01);  //  {3'd0, IIF_MC1_ASSIGN_BIT_03};
        isp_write(ISP_IIF_BASE0+0x95,0x02);  //  {3'd0, IIF_MC1_ASSIGN_BIT_04};
        isp_write(ISP_IIF_BASE0+0x96,0x03);  //  {3'd0, IIF_MC1_ASSIGN_BIT_05};
        isp_write(ISP_IIF_BASE0+0x97,0x04);  //  {3'd0, IIF_MC1_ASSIGN_BIT_06};
        isp_write(ISP_IIF_BASE0+0x98,0x05);  //  {3'd0, IIF_MC1_ASSIGN_BIT_07};
        isp_write(ISP_IIF_BASE0+0x99,0x06);  //  {3'd0, IIF_MC1_ASSIGN_BIT_08};
        isp_write(ISP_IIF_BASE0+0x9A,0x07);  //  {3'd0, IIF_MC1_ASSIGN_BIT_09};
        isp_write(ISP_IIF_BASE0+0x9B,0x08);  //  {3'd0, IIF_MC1_ASSIGN_BIT_10};
        isp_write(ISP_IIF_BASE0+0x9C,0x09);  //  {3'd0, IIF_MC1_ASSIGN_BIT_11};
        isp_write(ISP_IIF_BASE0+0x9D,0x0A);  //  {3'd0, IIF_MC1_ASSIGN_BIT_12};
        isp_write(ISP_IIF_BASE0+0x9E,0x0B);  //  {3'd0, IIF_MC1_ASSIGN_BIT_13};
        isp_write(ISP_IIF_BASE0+0x9F,0x0C);  //  {3'd0, IIF_MC1_ASSIGN_BIT_14};
        isp_write(ISP_IIF_BASE0+0xA0,0x0D);  //  {3'd0, IIF_MC1_ASSIGN_BIT_15};
        isp_write(ISP_IIF_BASE0+0xA1,0x0E);  //  {3'd0, IIF_MC1_ASSIGN_BIT_16};
        isp_write(ISP_IIF_BASE0+0xA2,0x0F);  //  {3'd0, IIF_MC1_ASSIGN_BIT_17};
        isp_write(ISP_IIF_BASE0+0xA3,0x10);  //  {3'd0, IIF_MC1_ASSIGN_BIT_18};
        isp_write(ISP_IIF_BASE0+0xA4,0x11);  //  {3'd0, IIF_MC1_ASSIGN_BIT_19};
        isp_write(ISP_IIF_BASE0+0xA5,0x12);  //  {3'd0, IIF_MC1_ASSIGN_BIT_20};
        isp_write(ISP_IIF_BASE0+0xA6,0x13);  //  {3'd0, IIF_MC1_ASSIGN_BIT_21};
        isp_write(ISP_IIF_BASE0+0xA7,0x14);  //  {3'd0, IIF_MC1_ASSIGN_BIT_22};
        isp_write(ISP_IIF_BASE0+0xA8,0x15);  //  {3'd0, IIF_MC1_ASSIGN_BIT_23};
        isp_write(ISP_IIF_BASE0+0xA9,0x16);  //  {3'd0, IIF_MC1_ASSIGN_BIT_24};
    #else
        isp_write(ISP_IIF_BASE0+0xB2,0x06);  //  IIF_MC1_MAX_CLK_EN;
        isp_write(ISP_IIF_BASE0+0xB3,0x3C);  //  IIF_MC1_MERGE_CLK_EN;

        isp_write(ISP_IIF_BASE0+0x92,0x01);  //  {3'd0, IIF_MC1_ASSIGN_BIT_01};
        isp_write(ISP_IIF_BASE0+0x93,0x02);  //  {3'd0, IIF_MC1_ASSIGN_BIT_02};
        isp_write(ISP_IIF_BASE0+0x94,0x03);  //  {3'd0, IIF_MC1_ASSIGN_BIT_03};
        isp_write(ISP_IIF_BASE0+0x95,0x04);  //  {3'd0, IIF_MC1_ASSIGN_BIT_04};
        isp_write(ISP_IIF_BASE0+0x96,0x05);  //  {3'd0, IIF_MC1_ASSIGN_BIT_05};
        isp_write(ISP_IIF_BASE0+0x97,0x06);  //  {3'd0, IIF_MC1_ASSIGN_BIT_06};
        isp_write(ISP_IIF_BASE0+0x98,0x07);  //  {3'd0, IIF_MC1_ASSIGN_BIT_07};
        isp_write(ISP_IIF_BASE0+0x99,0x08);  //  {3'd0, IIF_MC1_ASSIGN_BIT_08};
        isp_write(ISP_IIF_BASE0+0x9A,0x09);  //  {3'd0, IIF_MC1_ASSIGN_BIT_09};
        isp_write(ISP_IIF_BASE0+0x9B,0x0A);  //  {3'd0, IIF_MC1_ASSIGN_BIT_10};
        isp_write(ISP_IIF_BASE0+0x9C,0x0B);  //  {3'd0, IIF_MC1_ASSIGN_BIT_11};
        isp_write(ISP_IIF_BASE0+0x9D,0x0C);  //  {3'd0, IIF_MC1_ASSIGN_BIT_12};
        isp_write(ISP_IIF_BASE0+0x9E,0x0D);  //  {3'd0, IIF_MC1_ASSIGN_BIT_13};
        isp_write(ISP_IIF_BASE0+0x9F,0x0E);  //  {3'd0, IIF_MC1_ASSIGN_BIT_14};
        isp_write(ISP_IIF_BASE0+0xA0,0x0F);  //  {3'd0, IIF_MC1_ASSIGN_BIT_15};
        isp_write(ISP_IIF_BASE0+0xA1,0x10);  //  {3'd0, IIF_MC1_ASSIGN_BIT_16};
        isp_write(ISP_IIF_BASE0+0xA2,0x11);  //  {3'd0, IIF_MC1_ASSIGN_BIT_17};
        isp_write(ISP_IIF_BASE0+0xA3,0x12);  //  {3'd0, IIF_MC1_ASSIGN_BIT_18};
        isp_write(ISP_IIF_BASE0+0xA4,0x13);  //  {3'd0, IIF_MC1_ASSIGN_BIT_19};
        isp_write(ISP_IIF_BASE0+0xA5,0x14);  //  {3'd0, IIF_MC1_ASSIGN_BIT_20};
        isp_write(ISP_IIF_BASE0+0xA6,0x15);  //  {3'd0, IIF_MC1_ASSIGN_BIT_21};
        isp_write(ISP_IIF_BASE0+0xA7,0x16);  //  {3'd0, IIF_MC1_ASSIGN_BIT_22};
        isp_write(ISP_IIF_BASE0+0xA8,0x17);  //  {3'd0, IIF_MC1_ASSIGN_BIT_23};
        isp_write(ISP_IIF_BASE0+0xA9,0x18);  //  {3'd0, IIF_MC1_ASSIGN_BIT_24};
    #endif
#endif
    isp_write(ISP_IIF_BASE0+0x82, IIF_FP_VACT>>8);  //  {3'd0, IIF_HACT_F_PORCH_VSYNC[12:8]};
    isp_write(ISP_IIF_BASE0+0x81, IIF_FP_VACT   );  //  IIF_HACT_F_PORCH_VSYNC[7:0];
    isp_write(ISP_IIF_BASE0+0x84, IIF_FP_HACT_SIZE>>8);  //  {3'd0, IIF_HACT_F_PORCH_HSYNC[12:8]};
    isp_write(ISP_IIF_BASE0+0x83, IIF_FP_HACT_SIZE   );  //  IIF_HACT_F_PORCH_HSYNC[7:0];
    isp_write(ISP_IIF_BASE0+0x86, IIF_VACT   >>8);  //  {3'd0, IIF_HACT_HEIGHT[12:8]};
    isp_write(ISP_IIF_BASE0+0x85, IIF_VACT      );  //  IIF_HACT_HEIGHT[7:0];
    isp_write(ISP_IIF_BASE0+0x88, IIF_HACT_SIZE   >>8);  //  {3'd0, IIF_HACT_WIDTH[12:8]};
    isp_write(ISP_IIF_BASE0+0x87, IIF_HACT_SIZE      );  //  IIF_HACT_WIDTH[7:0];

    isp_write(ISP_IIF_BASE0+0x8A, IIF_OB1_FP_VACT>>8);  //  {3'd0, IIF_OBACT_F_PORCH_VSYNC[12:8]};
    isp_write(ISP_IIF_BASE0+0x89, IIF_OB1_FP_VACT   );  //  IIF_OBACT_F_PORCH_VSYNC[7:0];
    isp_write(ISP_IIF_BASE0+0x8C, IIF_OB1_FP_HACT_SIZE>>8);  //  {3'd0, IIF_OBACT_F_PORCH_HSYNC[12:8]};
    isp_write(ISP_IIF_BASE0+0x8B, IIF_OB1_FP_HACT_SIZE   );  //  IIF_OBACT_F_PORCH_HSYNC[7:0];
    isp_write(ISP_IIF_BASE0+0x8E, IIF_OB1_VACT   >>8);  //  {3'd0, IIF_OBACT_HEIGHT[12:8]};
    isp_write(ISP_IIF_BASE0+0x8D, IIF_OB1_VACT      );  //  IIF_OBACT_HEIGHT[7:0];
    isp_write(ISP_IIF_BASE0+0x90, IIF_OB1_HACT_SIZE   >>8);  //  {3'd0, IIF_OBACT_WIDTH[12:8]};
    isp_write(ISP_IIF_BASE0+0x8F, IIF_OB1_HACT_SIZE      );  //  IIF_OBACT_WIDTH[7:0];

    isp_write(ISP_IIF_BASE0+0xAB, IIF_OB2_FP_VACT>>8);  //  {3'd0, IIF_V_OBACT_F_PORCH_VSYNC[12:8]};
    isp_write(ISP_IIF_BASE0+0xAA, IIF_OB2_FP_VACT   );  //  IIF_V_OBACT_F_PORCH_VSYNC[7:0];
    isp_write(ISP_IIF_BASE0+0xAD, IIF_OB2_FP_HACT_SIZE>>8);  //  {3'd0, IIF_V_OBACT_F_PORCH_HSYNC[12:8]};
    isp_write(ISP_IIF_BASE0+0xAC, IIF_OB2_FP_HACT_SIZE   );  //  IIF_V_OBACT_F_PORCH_HSYNC[7:0];
    isp_write(ISP_IIF_BASE0+0xAF, IIF_OB2_VACT   >>8);  //  {3'd0, IIF_V_OBACT_HEIGHT[12:8]};
    isp_write(ISP_IIF_BASE0+0xAE, IIF_OB2_VACT      );  //  IIF_V_OBACT_HEIGHT[7:0];
    isp_write(ISP_IIF_BASE0+0xB1, IIF_OB2_HACT_SIZE   >>8);  //  {3'd0, IIF_V_OBACT_WIDTH[12:8]};
    isp_write(ISP_IIF_BASE0+0xB0, IIF_OB2_HACT_SIZE      );  //  IIF_V_OBACT_WIDTH[7:0];

    isp_write(ISP_IIF_BASE0+0x40,0x00);  //  SF_SKIP_FRAM_EN
    isp_write(ISP_IIF_BASE0+0x41,0x00);  //  SF_SKIP_PERIOD[5:0]
    isp_write(ISP_IIF_BASE0+0x42,0x00);  //  SF_SKIP_AUTO_EN

    isp_write(ISP_IIF_BASE1+0x40,0x00);  //  {3'd0, ICDC_VSYNC_DLY_SEL, 1'd0, ICDC_VSYNC_REGEN_POS, ICDC_VSYNC_REGEN_NEG, ICDC_VSYNC_IN_INV};
    isp_write(ISP_IIF_BASE1+0x42, IN_HACT>>8);  //  {3'd0, ICDC_HACT_WIDTH[12:8]};
    isp_write(ISP_IIF_BASE1+0x41, IN_HACT   );       //  ICDC_HACT_WIDTH;
    isp_write(ISP_IIF_BASE1+0x44, IN_VACT>>8);  //  {3'd0, ICDC_HACT_HEIGHT[12:8]};
    isp_write(ISP_IIF_BASE1+0x43, IN_VACT   );       //  ICDC_HACT_HEIGHT;
    isp_write(ISP_IIF_BASE1+0x47,0x00);  //  {1'd0, ICDC_FR_EN, ICDC_FR_SEL_HBLK, ICDC_IN_2X, ICDC_DLY_SEL, ICDC_HACT_BYPASS, ICDC_HMIR};
    isp_write(ISP_IIF_BASE1+0x49,0x00);  //  {3'd0, ICDC_HACT_DLY[12:8]};
    isp_write(ISP_IIF_BASE1+0x48,0x00);  //  {ICDC_HACT_DLY[7:0]};
    isp_write(ISP_IIF_BASE1+0x4C, IN_HBLK>>8);  //  {3'd0, ICDC_HBLK_WIDTH[12:8]};
    isp_write(ISP_IIF_BASE1+0x4B, IN_HBLK   );       //  {ICDC_HBLK_WIDTH[7:0]};
    isp_write(ISP_IIF_BASE1+0x4D,0xFF);  //  ICDC_FR_HACT_HEIGHT

//  isp_write(ISP_IIF_BASE0+0x60,0xC1;  //{ISYNC_VSYNC_POL,ISYNC_HSYNC_POL,ISYNC_DEC_BIT_SEL,3'h0,ISYNC_DEC_EN};
    isp_write(ISP_IIF_BASE0+0x60,0xC0);  //{ISYNC_VSYNC_POL,ISYNC_HSYNC_POL,ISYNC_DEC_BIT_SEL,3'h0,ISYNC_DEC_EN};
    isp_write(ISP_IIF_BASE0+0x61,0xFF);  //       ISYNC_DEC_SYNC_CODE0[ 7:0] ;
    isp_write(ISP_IIF_BASE0+0x62,0x0F);  //{4'h0, ISYNC_DEC_SYNC_CODE0[11:8]};
    isp_write(ISP_IIF_BASE0+0x63,0x00);  //       ISYNC_DEC_SYNC_CODE1[ 7:0] ;
    isp_write(ISP_IIF_BASE0+0x64,0x00);  //{4'h0, ISYNC_DEC_SYNC_CODE1[11:8]};
    isp_write(ISP_IIF_BASE0+0x65,0x00);  //       ISYNC_DEC_SYNC_CODE2[ 7:0] ;
    isp_write(ISP_IIF_BASE0+0x66,0x00);  //{4'h0, ISYNC_DEC_SYNC_CODE2[11:8]};
    isp_write(ISP_IIF_BASE0+0x68, LD_SYNC_CODE3_NVSYNC>>8 );   //  ISYNC_DEC_SYNC_CODE3_RVSYNC[15:8];
    isp_write(ISP_IIF_BASE0+0x67, LD_SYNC_CODE3_NVSYNC    );   //  ISYNC_DEC_SYNC_CODE3_RVSYNC[7:0];
    isp_write(ISP_IIF_BASE0+0x6A, LD_SYNC_CODE3_PVSYNC>>8 );   //  ISYNC_DEC_SYNC_CODE3_FVSYNC[15:8];
    isp_write(ISP_IIF_BASE0+0x69, LD_SYNC_CODE3_PVSYNC    );   //  ISYNC_DEC_SYNC_CODE3_FVSYNC[7:0];
    isp_write(ISP_IIF_BASE0+0x6C, LD_SYNC_CODE3_PHSYNC>>8 );   //  ISYNC_DEC_SYNC_CODE3_RHSYNC[15:8];
    isp_write(ISP_IIF_BASE0+0x6B, LD_SYNC_CODE3_PHSYNC    );   //  ISYNC_DEC_SYNC_CODE3_RHSYNC[7:0];
    isp_write(ISP_IIF_BASE0+0x6E, LD_SYNC_CODE3_NHSYNC>>8 );   //  ISYNC_DEC_SYNC_CODE3_FHSYNC[15:8];
    isp_write(ISP_IIF_BASE0+0x6D, LD_SYNC_CODE3_NHSYNC    );   //  ISYNC_DEC_SYNC_CODE3_FHSYNC[7:0];
    isp_write(ISP_IIF_BASE0+0x6F,0x12);  //{ISYNC_DEC_DATA_MERGE_BIT1 ,ISYNC_DEC_DATA_MERGE_BIT2 };
    isp_write(ISP_IIF_BASE0+0x70,0x34);  //{ISYNC_DEC_DATA_MERGE_BIT3 ,ISYNC_DEC_DATA_MERGE_BIT4 };
    isp_write(ISP_IIF_BASE0+0x71,0x56);  //{ISYNC_DEC_DATA_MERGE_BIT5 ,ISYNC_DEC_DATA_MERGE_BIT6 };
    isp_write(ISP_IIF_BASE0+0x72,0x78);  //{ISYNC_DEC_DATA_MERGE_BIT7 ,ISYNC_DEC_DATA_MERGE_BIT8 };
    isp_write(ISP_IIF_BASE0+0x73,0x9A);  //{ISYNC_DEC_DATA_MERGE_BIT9 ,ISYNC_DEC_DATA_MERGE_BIT10};
    isp_write(ISP_IIF_BASE0+0x74,0xBC);  //{ISYNC_DEC_DATA_MERGE_BIT11,ISYNC_DEC_DATA_MERGE_BIT12};

#if(WDR_MODE_SEL == WDR_OV10640_SET)
    isp_write(ISP_IIF_BASE0+0xB4,0x43);  //  {1'd0, w_IIF_LWDR_CH_SEQ,2'd0, w_IIF_LWDR_EN,w_IIF_LWDR_CH};
//  isp_write(ISP_IIF_BASE1+0x4E,0x0A);  //  {4'h0,W_ICDC_LWDR_TEST_EN,W_ICDC_LWDR_SCHK_ONLY,W_ICDC_LWDR_MCHK_ONLY,W_ICDC_LWDR_LCHK_ONLY};
#else
    isp_write(ISP_IIF_BASE0+0xB4,0x00);  //  {1'd0, w_IIF_LWDR_CH_SEQ,2'd0, w_IIF_LWDR_EN,w_IIF_LWDR_CH};
//  isp_write(ISP_IIF_BASE1+0x4E,0x00);  //  {4'h0,W_ICDC_LWDR_TEST_EN,W_ICDC_LWDR_SCHK_ONLY,W_ICDC_LWDR_MCHK_ONLY,W_ICDC_LWDR_LCHK_ONLY};
#endif
}
