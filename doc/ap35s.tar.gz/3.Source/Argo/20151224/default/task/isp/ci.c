#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void CI_set(void)
{
	tdk_printf("ci set\n");
    isp_write(ISP_CI_BASE+0x00,0x00);  // {i_ci_line_mem_init,i_ci_h_total_auto,i_ci_size_custom,i_ci_hsync_bypass,1'b0,i_H_SWAP_pre,i_V_SWAP_pre,o_jcia_en};
    isp_write(ISP_CI_BASE+0x01,0x00);  // {1'h0,i_gamma_pre,2'h0,i_dir_method};
    isp_write(ISP_CI_BASE+0x02,0x00);  // {6'h0,i_gdir_disable_pre,i_rb_no_refer_pre};
    isp_write(ISP_CI_BASE+0x03,0x00);  // {i_debug_ch  };
    isp_write(ISP_CI_BASE+0x04,0x00);  // {i_debug_mode};
    isp_write(ISP_CI_BASE+0x05,0x00);  // {i_debug_ctrl};

    isp_write(ISP_CI_BASE+0x08,0x18);  // {i_hmg_thr };
    isp_write(ISP_CI_BASE+0x09,0x00);  // {i_hmg_diff};
    isp_write(ISP_CI_BASE+0x0A,0x00);  // {2'h0,i_hdir_diff_th_method,2'h0,i_hdir_diff_method,i_hdir_hmg_method};
    isp_write(ISP_CI_BASE+0x0B,0x00);  // {      i_min_diff_thr            };
    isp_write(ISP_CI_BASE+0x0C,0x40);  // {      i_diff_thr                };
    isp_write(ISP_CI_BASE+0x0D,0x04);  // {5'h0,i_res_enhance_pre,i_diff_uv_en,i_high_freq_en};

    isp_write(ISP_CI_BASE+0x23,0x00);  // {      i_dblur_dir_thr           };

    isp_write(ISP_CI_BASE+0x34,0x0A);  // {      i_gdiff_thr   [7:0]       };
    isp_write(ISP_CI_BASE+0x35,0x00);  // {      i_gdiff_thr   [9:8]       };
    isp_write(ISP_CI_BASE+0x36,0x08);  // {      i_gdiff_thr2  [7:0]       };
    isp_write(ISP_CI_BASE+0x37,0x00);  // {      i_gdiff_thr2  [9:8]       };
    isp_write(ISP_CI_BASE+0x38,0x10);  // {      i_gdiff_thr3  [7:0]       };
    isp_write(ISP_CI_BASE+0x39,0x00);  // {      i_gdiff_thr3  [9:8]       };
    isp_write(ISP_CI_BASE+0x3A,0x00);  // {3'h0,i_flat_mix_src,2'h0,i_flat_mix_mode[1:0]};
    isp_write(ISP_CI_BASE+0x3B,0x00);  // {2'h0,i_jcia_flat_th[5:0]       };
    isp_write(ISP_CI_BASE+0x3C,0x00);  // {      i_jcia_flat_alpha[7:0]    };

    isp_write(ISP_CI_BASE+0x60,0x00);  // {7'h0,i_fnr_en_pre              };
    isp_write(ISP_CI_BASE+0x61,0x00);  // {1'b0,i_fnr_int2_pre[ 5: 3],1'b0,i_fnr_int2_pre[ 2: 0]};
    isp_write(ISP_CI_BASE+0x62,0x00);  // {1'b0,i_fnr_int2_pre[11: 9],1'b0,i_fnr_int2_pre[ 8: 6]};
    isp_write(ISP_CI_BASE+0x63,0x00);  // {1'b0,i_fnr_int2_pre[17:15],1'b0,i_fnr_int2_pre[14:12]};
    isp_write(ISP_CI_BASE+0x64,0x00);  // {1'b0,i_fnr_int2_pre[23:21],1'b0,i_fnr_int2_pre[20:18]};
    isp_write(ISP_CI_BASE+0x65,0x00);  // {1'b0,i_fnr_int2_pre[29:27],1'b0,i_fnr_int2_pre[26:24]};
}

