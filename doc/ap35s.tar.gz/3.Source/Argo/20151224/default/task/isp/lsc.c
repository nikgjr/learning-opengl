#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"
void LSC_set(void)
{
    isp_write(ISP_LSC_BASE+0xC0,0x01);  // LSC_DIST_MODE[3], LSC_EN[0]

    isp_write(ISP_LSC_BASE+0xC2,0x02);  // LSC_CENT_X[12:8]
    isp_write(ISP_LSC_BASE+0xC1,0x80);  // LSC_CENT_X[7:0]
    isp_write(ISP_LSC_BASE+0xC4,0x01);  // LSC_CENT_Y[12:8]
    isp_write(ISP_LSC_BASE+0xC3,0x68);  // LSC_CENT_Y[7:0]

    isp_write(ISP_LSC_BASE+0xC5,0x0c);  // LSC_GR_GAIN
    isp_write(ISP_LSC_BASE+0xC6,0x0c);  // LSC_R_GAIN
    isp_write(ISP_LSC_BASE+0xC7,0x0c);  // LSC_B_GAIN
    isp_write(ISP_LSC_BASE+0xC8,0x0c);  // LSC_GB_GAIN

    isp_write(ISP_LSC_BASE+0xC9,0x66);  // LSC_GR_SHIFT, LSC_R_SHIFT
    isp_write(ISP_LSC_BASE+0xCA,0x66);  // LSC_B_SHIFT, LSC_GB_SHIFT

    isp_write(ISP_LSC_BASE+0xCC,0x0c);  // LSC_GR_GAIN_M
    isp_write(ISP_LSC_BASE+0xCD,0x0c);  // LSC_R_GAIN_M
    isp_write(ISP_LSC_BASE+0xCE,0x0c);  // LSC_B_GAIN_M
    isp_write(ISP_LSC_BASE+0xCF,0x0c);  // LSC_GB_GAIN_M

    isp_write(ISP_LSC_BASE+0xD0,0x0c);  // LSC_GR_GAIN_S
    isp_write(ISP_LSC_BASE+0xD1,0x0c);  // LSC_R_GAIN_S
    isp_write(ISP_LSC_BASE+0xD2,0x0c);  // LSC_B_GAIN_S
    isp_write(ISP_LSC_BASE+0xD3,0x0c);  // LSC_GB_GAIN_S

    isp_write(ISP_LSC_BASE+0xD4,0x66);  // LSC_GR_SHIFT, LSC_R_SHIFT
    isp_write(ISP_LSC_BASE+0xD5,0x66);  // LSC_B_SHIFT, LSC_GB_SHIFT
    isp_write(ISP_LSC_BASE+0xD6,0x66);  // LSC_GR_SHIFT, LSC_R_SHIFT
    isp_write(ISP_LSC_BASE+0xD7,0x66);  // LSC_B_SHIFT, LSC_GB_SHIFT
}

