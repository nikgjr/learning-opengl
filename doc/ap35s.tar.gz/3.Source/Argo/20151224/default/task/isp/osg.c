#include "qspi_regmap.h"
#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"
#include "isp_common.h"

#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"


void OSG_set(void)
{

    unsigned char osg_done;
//  // Single SPI Setting
//  rSPI1MOD        = SPI_SSMD | SPI_EN | SPI_MODE_RXTX ;
//  rSPI1_2MOD      = SPI_SSMD | SPI_EN | SPI_MODE_RXTX ;
//  rSPI1CK         = SPI_CKSEL_1100;
//  rSPI1_2CK       = SPI_CKSEL_1100;

	tdk_printf("OSG set\n");
    //== PIN MUX Setting
    pinmux_q_spi();

    //== Quad SPI Setting
//  quad_spi_set_osg();

//  //====== osg_top_ori.v =====================================================//
    //== COMMON
 	isp_write(ISP_OSG1_BASE+0x00,0x00); // {I_BLACKOUT, 1'b0, I_CSWAP, 5'd0};
 	isp_write(ISP_OSG1_BASE+0x01,0x00); // I_BLACK_Y;
 	isp_write(ISP_OSG1_BASE+0x02,0x80); // I_BLACK_CB;
 	isp_write(ISP_OSG1_BASE+0x03,0x80); // I_BLACK_CR;
    //== LAYER0
    #if((ENV_TEST == ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL) | (ENV_TEST == ENV_TEST_FUNC_BYPASS))
 	isp_write(ISP_OSG1_BASE+0x16,0xC0); // {I_LAYER_0_ENABLE, I_LAYER_0_ON, 1'b0, I_LAYER_0_HINV, I_LAYER_0_EXT_VMUL, I_LAYER_0_EXT_HMUL};
 	isp_write(ISP_OSG1_BASE+0x17,0x00); // I_LAYER_0_FSIZE
 	isp_write(ISP_OSG1_BASE+0x1E,0x00); // O_BASEADDR[7:0];
 	isp_write(ISP_OSG1_BASE+0x1F,0x80); // O_BASEADDR[15:8];
 	isp_write(ISP_OSG1_BASE+0x20,0x00); // O_BASEADDR[23:16];  
    #else
 	isp_write(ISP_OSG1_BASE+0x16,0xC0); // {I_LAYER_0_ENABLE, I_LAYER_0_ON, 1'b0, I_LAYER_0_HINV, I_LAYER_0_EXT_VMUL, I_LAYER_0_EXT_HMUL};
 	isp_write(ISP_OSG1_BASE+0x17,0x02); // I_LAYER_0_FSIZE
 	isp_write(ISP_OSG1_BASE+0x18,0x00); // I_LAYER_0_INDEX[7:0]
 	isp_write(ISP_OSG1_BASE+0x19,0x00); // I_LAYER_0_INDEX[9:8]
 	isp_write(ISP_OSG1_BASE+0x1E,0x00); // O_BASEADDR[7:0];
 	isp_write(ISP_OSG1_BASE+0x1F,0x80); // O_BASEADDR[15:8];
 	isp_write(ISP_OSG1_BASE+0x20,0x00); // O_BASEADDR[23:16];  
    #endif
//  //== LAYER1
//	isp_write(ISP_OSG1_BASE+0x72,0xC0); // {I_LAYER_1_ENABLE, I_LAYER_1_ON, 1'b0, I_LAYER_1_HINV, I_LAYER_1_EXT_VMUL, I_LAYER_1_EXT_HMUL};
//	isp_write(ISP_OSG1_BASE+0x73,0x04); // I_LAYER_1_FSIZE
//  isp_write(ISP_OSG1_BASE+0x76,0x30); // I_LAYER_1_VPOS[7:0];
//  isp_write(ISP_OSG1_BASE+0x77,0x00); // I_LAYER_1_VPOS[10:8];
//	isp_write(ISP_OSG1_BASE+0x7A,0x00); // O_BASEADDR[7:0];
//	isp_write(ISP_OSG1_BASE+0x7B,0x80); // O_BASEADDR[15:8];
//	isp_write(ISP_OSG1_BASE+0x7C,0x00); // O_BASEADDR[23:16];
//  //== LAYER2
//	isp_write(ISP_OSG1_BASE+0xCE,0xC0); // {I_LAYER_2_ENABLE, I_LAYER_2_ON, 1'b0, I_LAYER_2_HINV, I_LAYER_2_EXT_VMUL, I_LAYER_2_EXT_HMUL};
//	isp_write(ISP_OSG1_BASE+0xCF,0x04); // I_LAYER_2_FSIZE
//  isp_write(ISP_OSG1_BASE+0xD2,0x60); // I_LAYER_2_VPOS[7:0];
//  isp_write(ISP_OSG1_BASE+0xD3,0x00); // I_LAYER_2_VPOS[10:8];
//	isp_write(ISP_OSG1_BASE+0xD6,0x00); // O_BASEADDR[7:0];
//	isp_write(ISP_OSG1_BASE+0xD7,0x80); // O_BASEADDR[15:8];
//	isp_write(ISP_OSG1_BASE+0xD8,0x00); // O_BASEADDR[23:16];
//  //== LAYER3
//	isp_write(ISP_OSG2_BASE+0x2A,0xC0); // {I_LAYER_3_ENABLE, I_LAYER_3_ON, 1'b0, I_LAYER_3_HINV, I_LAYER_3_EXT_VMUL, I_LAYER_3_EXT_HMUL};
//	isp_write(ISP_OSG2_BASE+0x2B,0x04); // I_LAYER_3_FSIZE
//  isp_write(ISP_OSG2_BASE+0x2E,0x90); // I_LAYER_3_VPOS[7:0];
//  isp_write(ISP_OSG2_BASE+0x2F,0x00); // I_LAYER_3_VPOS[10:8];
//	isp_write(ISP_OSG2_BASE+0x32,0x00); // O_BASEADDR[7:0];
//	isp_write(ISP_OSG2_BASE+0x33,0x80); // O_BASEADDR[15:8];
//	isp_write(ISP_OSG2_BASE+0x34,0x00); // O_BASEADDR[23:16];
//    //== LAYER4
//	isp_write(ISP_OSG2_BASE+0x86,0xC0); // {I_LAYER_4_ENABLE, I_LAYER_4_ON, 1'b0, I_LAYER_4_HINV, I_LAYER_4_EXT_VMUL, I_LAYER_4_EXT_HMUL};
//	isp_write(ISP_OSG2_BASE+0x87,0x04); // I_LAYER_4_FSIZE
//  isp_write(ISP_OSG2_BASE+0x8A,0xB0); // I_LAYER_4_VPOS[7:0];
//  isp_write(ISP_OSG2_BASE+0x8B,0x00); // I_LAYER_4_VPOS[10:8];
//	isp_write(ISP_OSG2_BASE+0x8E,0x00); // O_BASEADDR[7:0];
//	isp_write(ISP_OSG2_BASE+0x8F,0x80); // O_BASEADDR[15:8];
//	isp_write(ISP_OSG2_BASE+0x90,0x00); // O_BASEADDR[23:16];

    //====== osg_top.v     =====================================================//
    //== LAYER5
//    #if((ENV_TEST == ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL) | (ENV_TEST == ENV_TEST_FUNC_BYPASS))
//    isp_write(ISP_OSG3_BASE+0x16,0xC0); // {I_LAYER_0_ENABLE, I_LAYER_0_ON, 1'b0, I_LAYER_0_HINV, I_LAYER_0_EXT_VMUL, I_LAYER_0_EXT_HMUL};
//    isp_write(ISP_OSG3_BASE+0x17,0xC0); // {I_LAYER_0_GRA_ENABLE, I_LAYER_0_GRA_ON, I_LAYER_0_FSIZE, I_LAYER_0_FSIZE_GRA}
//    isp_write(ISP_OSG3_BASE+0x18,0x00); // I_LAYER_0_INDEX[7:0];
//    isp_write(ISP_OSG3_BASE+0x19,0x00); // {6'd0, I_LAYER_0_INDEX[9:8]};
//    isp_write(ISP_OSG3_BASE+0x1E,0x00); // O_BASEADDR[7:0];
//    isp_write(ISP_OSG3_BASE+0x1F,0x84); // O_BASEADDR[15:8];
//    isp_write(ISP_OSG3_BASE+0x20,0x00); // O_BASEADDR[23:16];
//    isp_write(ISP_OSG3_BASE+0x21,0x00); // O_GRA_BASEADDR[7:0];
//    isp_write(ISP_OSG3_BASE+0x22,0x88); // O_GRA_BASEADDR[15:8];
//    isp_write(ISP_OSG3_BASE+0x23,0x00); // O_GRA_BASEADDR[23:16];
//    #else
//    isp_write(ISP_OSG3_BASE+0x16,0xC0); // {I_LAYER_0_ENABLE, I_LAYER_0_ON, 1'b0, I_LAYER_0_HINV, I_LAYER_0_EXT_VMUL, I_LAYER_0_EXT_HMUL};
//    isp_write(ISP_OSG3_BASE+0x17,0xD2); // {I_LAYER_0_GRA_ENABLE, I_LAYER_0_GRA_ON, I_LAYER_0_FSIZE, I_LAYER_0_FSIZE_GRA}
//    isp_write(ISP_OSG3_BASE+0x18,0x14); // I_LAYER_0_INDEX[7:0];
//    isp_write(ISP_OSG3_BASE+0x19,0x00); // {6'd0, I_LAYER_0_INDEX[9:8]};
//    isp_write(ISP_OSG3_BASE+0x1E,0x00); // O_BASEADDR[7:0];
//    isp_write(ISP_OSG3_BASE+0x1F,0x80); // O_BASEADDR[15:8];
//    isp_write(ISP_OSG3_BASE+0x20,0x00); // O_BASEADDR[23:16];
//    isp_write(ISP_OSG3_BASE+0x21,0x00); // O_GRA_BASEADDR[7:0];
//    isp_write(ISP_OSG3_BASE+0x22,0x0C); // O_GRA_BASEADDR[15:8];
//    isp_write(ISP_OSG3_BASE+0x23,0x02); // O_GRA_BASEADDR[23:16];
//    #endif
//    //== LAYER6
//  isp_write(ISP_OSG3_BASE+0x75,0xC0); // {I_LAYER_1_ENABLE, I_LAYER_1_ON, 1'b0, I_LAYER_1_HINV, I_LAYER_1_EXT_VMUL, I_LAYER_1_EXT_HMUL};
//  isp_write(ISP_OSG3_BASE+0x76,0xC2); // {I_LAYER_1_GRA_ENABLE, I_LAYER_1_GRA_ON, 3'd0, I_LAYER_1_FSIZE}
//  isp_write(ISP_OSG3_BASE+0x77,0x03); // I_LAYER_1_INDEX[7:0];
//  isp_write(ISP_OSG3_BASE+0x78,0x00); // {6'd0, I_LAYER_1_INDEX[9:8]};
//  isp_write(ISP_OSG3_BASE+0x7C,0x00); // O_BASEADDR[7:0];
//  isp_write(ISP_OSG3_BASE+0x7E,0x10); // O_BASEADDR[15:8];
//  isp_write(ISP_OSG3_BASE+0x7F,0x00); // O_BASEADDR[23:16];
//  isp_write(ISP_OSG3_BASE+0x80,0x00); // O_GRA_BASEADDR[7:0];
//  isp_write(ISP_OSG3_BASE+0x81,0x9C); // O_GRA_BASEADDR[15:8];
//  isp_write(ISP_OSG3_BASE+0x82,0x0A); // O_GRA_BASEADDR[23:16];

    //===========================================================//
    // SPI SEL
	isp_write(ISP_OSG2_BASE+0xF1,0x02); // O_OSG_SPI_SEL
                                        // 0: SPI1
                                        // 1: SPI1_2(Extern Flash)
                                        // 2: Quad SPI

	isp_write(ISP_OSG2_BASE+0xF2,0x03); // O_OSG_SPI_INSTRUCTION

    // image load
    // layer 0
    #if(OSG_DN_MODE == AXI_ON_SET)
	isp_write(ISP_OSG1_BASE+0x70,0x01); // {I_LAYER_0_LPF_YEN, I_LAYER_0_LPF_CEN, 5'd0, I_LAYER_0_RELOAD};
	isp_write(ISP_OSG1_BASE+0x70,0x00); // {I_LAYER_0_LPF_YEN, I_LAYER_0_LPF_CEN, 5'd0, I_LAYER_0_RELOAD};
    //== Quad SPI Setting
	isp_write(ISP_OSG3_BASE+0xF1,0x10); // {3'd0, O_AXI_SLAVE_ENABLE, 3'd0, I_OSG_WDONE}
    quad_spi_set_osg();
    #else
    //== Quad SPI Setting
    quad_spi_set_osg();
	isp_write(ISP_OSG1_BASE+0x70,0x01); // {I_LAYER_0_LPF_YEN, I_LAYER_0_LPF_CEN, 5'd0, I_LAYER_0_RELOAD};
	isp_write(ISP_OSG1_BASE+0x70,0x00); // {I_LAYER_0_LPF_YEN, I_LAYER_0_LPF_CEN, 5'd0, I_LAYER_0_RELOAD};
    #endif

    delay(100);
    osg_done = isp_read(ISP_OSG2_BASE+0xe2);
    osg_done = osg_done & (0x1<<5);
    while(!osg_done){
        delay(2);
        osg_done = isp_read(ISP_OSG2_BASE+0xe2);
        osg_done = osg_done & (0x1<<5);
    }
    delay(100);

////
////// layer 1
//	isp_write(ISP_OSG1_BASE+0xCC,0x01); // {I_LAYER_1_LPF_YEN, I_LAYER_1_LPF_CEN, 5'd0, I_LAYER_1_RELOAD};
//	isp_write(ISP_OSG1_BASE+0xCC,0x00); // {I_LAYER_1_LPF_YEN, I_LAYER_1_LPF_CEN, 5'd0, I_LAYER_1_RELOAD};
//
//  delay(20000);
//
//  // layer 2
//	isp_write(ISP_OSG2_BASE+0x28,0x01); // {I_LAYER_2_LPF_YEN, I_LAYER_2_LPF_CEN, 5'd0, I_LAYER_2_RELOAD};
//	isp_write(ISP_OSG2_BASE+0x28,0x00); // {I_LAYER_2_LPF_YEN, I_LAYER_2_LPF_CEN, 5'd0, I_LAYER_2_RELOAD};
//
//  delay(20000);
//
//  // layer 3
//	isp_write(ISP_OSG2_BASE+0x84,0x01); // {I_LAYER_3_LPF_YEN, I_LAYER_3_LPF_CEN, 5'd0, I_LAYER_3_RELOAD};
//	isp_write(ISP_OSG2_BASE+0x84,0x00); // {I_LAYER_3_LPF_YEN, I_LAYER_3_LPF_CEN, 5'd0, I_LAYER_3_RELOAD};
//
//  delay(20000);
//
//  // layer 4
//	isp_write(ISP_OSG2_BASE+0xE0,0x01); // {I_LAYER_4_LPF_YEN, I_LAYER_4_LPF_CEN, 5'd0, I_LAYER_4_RELOAD};
//	isp_write(ISP_OSG2_BASE+0xE0,0x00); // {I_LAYER_4_LPF_YEN, I_LAYER_4_LPF_CEN, 5'd0, I_LAYER_4_RELOAD};
//
//  delay(20000);

//    //// layer 5
//	isp_write(ISP_OSG3_BASE+0x73,0x01); // {I_LAYER_5_LPF_YEN, I_LAYER_5_LPF_CEN, 5'd0, I_LAYER_0_RELOAD};
//	isp_write(ISP_OSG3_BASE+0x73,0x00); // {I_LAYER_5_LPF_YEN, I_LAYER_5_LPF_CEN, 5'd0, I_LAYER_0_RELOAD};
//    delay(100);
//    osg_done = isp_read(ISP_OSG3_BASE+0xd5);
//    osg_done = osg_done & (0x1<<5);
//    while(!osg_done){
//        delay(2);
//        osg_done = isp_read(ISP_OSG3_BASE+0xd5);
//        osg_done = osg_done & (0x1<<5);
//    }
//    delay(100);
//
//	isp_write(ISP_OSG3_BASE+0xD4,0x01); //  I_ALPHA_LAYER_REQ;
//	isp_write(ISP_OSG3_BASE+0xD4,0x00); //  I_ALPHA_LAYER_REQ;
//	isp_write(ISP_OSG3_BASE+0x73,0x01); // {I_LAYER_5_LPF_YEN, I_LAYER_5_LPF_CEN, 5'd0, I_LAYER_0_RELOAD};
//	isp_write(ISP_OSG3_BASE+0x73,0x00); // {I_LAYER_5_LPF_YEN, I_LAYER_5_LPF_CEN, 5'd0, I_LAYER_0_RELOAD};
////  delay(20000);
//
////  //// layer 6
////	isp_write(ISP_OSG3_BASE+0xD2,0x01); // {I_LAYER_5_LPF_YEN, I_LAYER_5_LPF_CEN, 5'd0, I_LAYER_1_RELOAD};
////	isp_write(ISP_OSG3_BASE+0xD2,0x00); // {I_LAYER_5_LPF_YEN, I_LAYER_5_LPF_CEN, 5'd0, I_LAYER_1_RELOAD};
////    delay(20000);
////	isp_write(ISP_OSG3_BASE+0xD4,0x01); //  I_ALPHA_LAYER_REQ;
////	isp_write(ISP_OSG3_BASE+0xD4,0x00); //  I_ALPHA_LAYER_REQ;
////	isp_write(ISP_OSG3_BASE+0xD2,0x01); // {I_LAYER_5_LPF_YEN, I_LAYER_5_LPF_CEN, 5'd0, I_LAYER_1_RELOAD};
////	isp_write(ISP_OSG3_BASE+0xD2,0x00); // {I_LAYER_5_LPF_YEN, I_LAYER_5_LPF_CEN, 5'd0, I_LAYER_1_RELOAD};
//    delay(100);
//    osg_done = isp_read(ISP_QSPI_BASE+0x11);
//    osg_done = osg_done & 0x1;
//    while(osg_done){
//        delay(2);
//        osg_done = isp_read(ISP_QSPI_BASE+0x11);
//        osg_done = osg_done & 0x1;
//    }
//    delay(100);
}

void OSG_reload()
{
	tdk_printf("OSG reload\n");

	isp_write(ISP_OSG1_BASE+0x70,0x01); // {I_LAYER_0_LPF_YEN, I_LAYER_0_LPF_CEN, 5'd0, I_LAYER_O_RELOAD};
	isp_write(ISP_OSG1_BASE+0x70,0x00); // {I_LAYER_0_LPF_YEN, I_LAYER_0_LPF_CEN, 5'd0, I_LAYER_O_RELOAD};
}
