#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void LINEAR_CTRL_set(void)
{
    isp_write(ISP_LINEAR_CTRL_BASE+0x00,0x01);  // LINEAR_CTRL_EN[0]
    isp_write(ISP_LINEAR_CTRL_BASE+0x01,0x00);  // LINEAR_CTRL_V_SWAP[4], LINEAR_CTRL_H_SWAP[0]
    isp_write(ISP_LINEAR_CTRL_BASE+0x02,0x44);  // LINEAR_CTRL_R_GAIN[7:0]
    isp_write(ISP_LINEAR_CTRL_BASE+0x03,0x42);  // LINEAR_CTRL_G_GAIN[7:0]
    isp_write(ISP_LINEAR_CTRL_BASE+0x04,0x46);  // LINEAR_CTRL_B_GAIN[7:0]
    isp_write(ISP_LINEAR_CTRL_BASE+0x05,0x44);  // LINEAR_CTRL_R_GAIN_M[7:0]
    isp_write(ISP_LINEAR_CTRL_BASE+0x06,0x42);  // LINEAR_CTRL_G_GAIN_M[7:0]
    isp_write(ISP_LINEAR_CTRL_BASE+0x07,0x46);  // LINEAR_CTRL_B_GAIN_M[7:0]
    isp_write(ISP_LINEAR_CTRL_BASE+0x08,0x44);  // LINEAR_CTRL_R_GAIN_S[7:0]
    isp_write(ISP_LINEAR_CTRL_BASE+0x09,0x42);  // LINEAR_CTRL_G_GAIN_S[7:0]
    isp_write(ISP_LINEAR_CTRL_BASE+0x0A,0x46);  // LINEAR_CTRL_B_GAIN_S[7:0]
}

