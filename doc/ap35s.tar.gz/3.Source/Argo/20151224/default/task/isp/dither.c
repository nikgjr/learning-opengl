#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void DITHER_set(void)
{
	tdk_printf("DITHER set\n");
    isp_write(ISP_DITHER_BASE0+0x57,0x01);  // BAYER_DITHER_EN[0]
    isp_write(ISP_DITHER_BASE1+0x10,0x01);  // YC_DITHER_EN[0]

    isp_read(ISP_DITHER_BASE0+0x57);  // BAYER_DITHER_EN[0]
    isp_read(ISP_DITHER_BASE1+0x10);  // YC_DITHER_EN[0]
}

