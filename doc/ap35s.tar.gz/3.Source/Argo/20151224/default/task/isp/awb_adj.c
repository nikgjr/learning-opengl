#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void awb_adj_set()
{
	tdk_printf("AWB_ADJ set\n");
    isp_write(ISP_AWB_ADJ_BASE+0x40,0x01);  // ADJ_EN,
//  isp_write(ISP_AWB_ADJ_BASE+0x42,0x00);  // ADJ_GAIN[14:8]
    isp_write(ISP_AWB_ADJ_BASE+0x41,0x88);  // ADJ_GAIN[7:0] <= 5.7 format
    isp_write(ISP_AWB_ADJ_BASE+0x43,0x10);  // ADJ_OFFSET[7:0]
    isp_write(ISP_AWB_ADJ_BASE+0xE5,0x10);  // AGC_LEVEL[7:0]

    isp_write(ISP_AWB_ADJ_BASE+0x45,0x01);  // ADJ_EN2, ADJ_GAIN2[14:8]
//  isp_write(ISP_AWB_ADJ_BASE+0x47,0x00);  // ADJ_GAIN[14:8]
    isp_write(ISP_AWB_ADJ_BASE+0x46,0x82);  // ADJ_GAIN[7:0]  <= 5.7 format
//  isp_write(ISP_AWB_ADJ_BASE+0x49,0x00);  // ADJ_OFFSET2[12:8]
//  isp_write(ISP_AWB_ADJ_BASE+0x48,0x00);  // ADJ_OFFSET2[7:0]

//  isp_write(ISP_AWB_ADJ_BASE+0x50,0x03);  // {5'b0, AWB_H_SWAP[2], AWB_V_SWAP[1], AWB_EN[0]};
    isp_write(ISP_AWB_ADJ_BASE+0x50,0x00);  // {5'b0, AWB_H_SWAP[2], AWB_V_SWAP[1], AWB_EN[0]};
    isp_write(ISP_AWB_ADJ_BASE+0x51,0x41);  // AWB_R_GAIN[7:0]
//  isp_write(ISP_AWB_ADJ_BASE+0x52,0x00);  // AWB_R_GAIN[8]
    isp_write(ISP_AWB_ADJ_BASE+0x53,0x42);  // AWB_G_GAIN[7:0]
//  isp_write(ISP_AWB_ADJ_BASE+0x54,0x00);  // AWB_G_GAIN[8]
    isp_write(ISP_AWB_ADJ_BASE+0x55,0x3F);  // AWB_B_GAIN[7:0]
//  isp_write(ISP_AWB_ADJ_BASE+0x56,0x00);  // AWB_B_GAIN[8]

//  isp_write(ISP_AWB_ADJ_BASE+0x58,0x00);  // {7'b0, AWB_EN2[0];
    isp_write(ISP_AWB_ADJ_BASE+0x59,0x56);  // {1'b0, AWB_R_GAIN2[7:0]}
//  isp_write(ISP_AWB_ADJ_BASE+0x5A,0x00);  // {7'b0, AWB_R_GAIN2[8]}
    isp_write(ISP_AWB_ADJ_BASE+0x5B,0x40);  // {1'b0, AWB_G_GAIN2[7:0]}
//  isp_write(ISP_AWB_ADJ_BASE+0x5C,0x00);  // {7'b0, AWB_G_GAIN2[8]}
    isp_write(ISP_AWB_ADJ_BASE+0x5D,0x52);  // {1'b0, AWB_B_GAIN2[7:0]}
//  isp_write(ISP_AWB_ADJ_BASE+0x5E,0x00);  // {7'b0, AWB_B_GAIN2[8]}

}

