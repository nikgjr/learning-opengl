#include "qspi_regmap.h"
#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"
#include "../include/sfr.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"

void quad_spi_set(void)
{
	tdk_printf("Quad SPI set\n");

    reg_write(QSPI_BASE+0x00,0x00510BEB);     // qspi_int_en[6], qspi_ckpha[5], qspi_sckpol[4], qspi_tdir[2], qspi_en[0]
                                              // qspi_osg_sel[7], qspi_oen_con[6], qspi_rswap[5], qspi_rdir[4], qspi_brate[3:0]
                                              // qspi_command[7:0]
    #if ((ENV_TEST == ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL) | (ENV_TEST == ENV_TEST_FUNC_BYPASS))
    reg_write(QSPI_BASE+0x04,0x00091A1F);     // qspi_end_address_2
                                              // qspi_end_address_1
                                              // qspi_end_address_0
    #elif (ENV_SIZE == SIZE_1M_SET)
    reg_write(QSPI_BASE+0x04,0x0009F658);     // qspi_end_address_2
                                              // qspi_end_address_1
                                              // qspi_end_address_0
    #else
    reg_write(QSPI_BASE+0x04,0x00096438);     // qspi_end_address_2
                                              // qspi_end_address_1
                                              // qspi_end_address_0
    #endif
    reg_write(QSPI_BASE+0x08,0x00FF0000);     // qspi_dummy_address_2
                                              // qspi_dummy_address_1
                                              // qspi_dummy_address_0
    reg_write(QSPI_BASE+0x0C,0x00091000);     // qspi_start_address_2
                                              // qspi_start_address_1
                                              // qspi_start_address_0

    reg_write(QSPI_BASE+0x10,LDC_LUT0_BASE_ADDR); // QSPI_Master_IF_Address
    reg_write(QSPI_BASE+0x14,0x00000080);     
    reg_write(QSPI_BASE+0x18,0x00000000);         // Clear QSPI Frame Done
}

void quad_spi_set_pip(void)
{
	tdk_printf("Quad SPI(PIP) set\n");

    reg_write(QSPI_BASE+0x00,0x00510BEB);     // qspi_int_en[6], qspi_ckpha[5], qspi_sckpol[4], qspi_tdir[2], qspi_en[0]
                                              // qspi_osg_sel[7], qspi_oen_con[6], qspi_rswap[5], qspi_rdir[4], qspi_brate[3:0]
                                              // qspi_command[7:0]
    #if (ENV_SIZE == SIZE_1M_SET)
    reg_write(QSPI_BASE+0x04,0x000A3290);     // qspi_end_address_2
                                              // qspi_end_address_1
                                              // qspi_end_address_0
    reg_write(QSPI_BASE+0x08,0x00FF0000);     // qspi_dummy_address_2
                                              // qspi_dummy_address_1
                                              // qspi_dummy_address_0
    reg_write(QSPI_BASE+0x0C,0x0009F658);     // qspi_start_address_2
                                              // qspi_start_address_1
                                              // qspi_start_address_0
    #else
    reg_write(QSPI_BASE+0x04,0x0009A070);     // qspi_end_address_2
                                              // qspi_end_address_1
                                              // qspi_end_address_0
    reg_write(QSPI_BASE+0x08,0x00FF0000);     // qspi_dummy_address_2
                                              // qspi_dummy_address_1
                                              // qspi_dummy_address_0
    reg_write(QSPI_BASE+0x0C,0x00096438);     // qspi_start_address_2
                                              // qspi_start_address_1
                                              // qspi_start_address_0
    #endif

    reg_write(QSPI_BASE+0x10,LDC_PIP_LUT0_BASE_ADDR      ); // QSPI_Master_IF_Address
    reg_write(QSPI_BASE+0x14,0x00000080);                        
    reg_write(QSPI_BASE+0x18,0x00000000);                   // Clear QSPI Frame Done
}

void quad_spi_set_osg(void)
{
	u32 i;
    u32 flash_download_end;
    u32 flash_buffer_full;
    u32 flash_buffer_empty;
    unsigned char osg_start;
	unsigned char k;
	unsigned int  j;

	tdk_printf("Quad SPI(OSG) set\n");
                                          
    #if(OSG_DN_MODE == AXI_ON_SET)
	tdk_printf("OSG APB Slave Mode set\n");
    reg_write(QSPI_BASE+0x00,0x00510BEB);     // qspi_int_en[6], qspi_ckpha[5], qspi_sckpol[4], qspi_tdir[2], qspi_en[0]
                                              // qspi_osg_sel[7], qspi_oen_con[6], qspi_rswap[5], qspi_rdir[4], qspi_brate[3:0]
                                              // qspi_command[7:0]
    reg_write(QSPI_BASE+0x30,0x00000002);     // OSG_DN_MODE[1] : APB
                                              // OSG_DN_MODE[0] : DIRECT
    osg_start = isp_read(ISP_OSG2_BASE+0xf4);
    osg_start = osg_start & 0x1;
    while(!osg_start){
        delay(2);
        osg_start = isp_read(ISP_OSG2_BASE+0xf4);
        osg_start = osg_start & 0x1;
    }

    reg_write(QSPI_BASE+0x04,0x00008bff);     
    reg_write(QSPI_BASE+0x0C,0x00008000);          
    delay(2000);


    j = 0; 
    i = reg_read(QSPI_BASE+0x28);
    flash_download_end = 0;
    while(!flash_download_end){
        // mem_buffer_full check
        flash_buffer_full = 0;
        while(!flash_buffer_full){
            i = reg_read(QSPI_BASE+0x28);      
            flash_buffer_full = i & (0x1 <<8);
        }

        // mem_buffer_empty check
        flash_buffer_empty = 0;                              
        while(!flash_buffer_empty){
            i = reg_read(QSPI_BASE+0x24);      
            reg_write(0x20200000|j, i); 
            j = j+0x4;

            i = reg_read(QSPI_BASE+0x28);      
            flash_buffer_empty = i & (0x1);
        }
    
        i = reg_read(QSPI_BASE+0x28);      
        flash_download_end = i & (0x1 <<24);
    }
    k = isp_read(ISP_OSG3_BASE+0xF1);
    isp_write(ISP_OSG3_BASE+0xF1, k|0x1);  
    isp_write(ISP_OSG3_BASE+0xF1, k|0x0);  
 
    //k = 0;
    //while(j=0){
    //    i = reg_read(0x20200000|k);   
    //    k = k+0x4;  
    //    j = j-0x4;
    //}
    #else
	tdk_printf("OSG Direct Mode set\n");
    reg_write(QSPI_BASE+0x00,0x00510BEB);     // qspi_int_en[6], qspi_ckpha[5], qspi_sckpol[4], qspi_tdir[2], qspi_en[0]
                                              // qspi_osg_sel[7], qspi_oen_con[6], qspi_rswap[5], qspi_rdir[4], qspi_brate[3:0]
                                              // qspi_command[7:0]
    reg_write(QSPI_BASE+0x30,0x00000001);     // OSG_DN_MODE[1] : APB
                                              // OSG_DN_MODE[0] : DIRECT
    #endif   
    reg_write(QSPI_BASE+0x08,0x00FF0000);     // qspi_dummy_address_2
                                              // qspi_dummy_address_1
                                              // qspi_dummy_address_0

}
