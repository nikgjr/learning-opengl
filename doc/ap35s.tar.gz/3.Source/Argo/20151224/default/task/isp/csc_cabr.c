#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void CSC_CABR_set(void)
{
	tdk_printf("csc_cabr set\n");
    isp_write(ISP_CSC_CABR_BASE+0xC0,0x01);  // {3'd0,CSC_CABR_AREA,3'd0,CSC_CABR_EN}
    isp_write(ISP_CSC_CABR_BASE+0xC1,0x30);  // {CSC_CABR_SHIFT[3:0],1'd0,CSC_CABR_MODE[2:0]}
    isp_write(ISP_CSC_CABR_BASE+0xC2,0x40);  // CSC_CABR_Y_SLOPE
    isp_write(ISP_CSC_CABR_BASE+0xC3,0x20);  // CSC_CABR_C_SLOPE
//  isp_write(ISP_CSC_CABR_BASE+0xC4,0x00);  // {2'h0,CSC_CABR_Y_TH[5:4],3'h0}
    isp_write(ISP_CSC_CABR_BASE+0xC5,0x01);  // CSC_CABR_Y_TH[7:0]
//  isp_write(ISP_CSC_CABR_BASE+0xC6,0x00);  // CSC_CABR_Y_TH[9:8]
    isp_write(ISP_CSC_CABR_BASE+0xC7,0x10);  // {7'd0,CSC_CABR_RB_DIFF_SIGN[0]}
//  isp_write(ISP_CSC_CABR_BASE+0xC9,0x00);  // CSC_CABR_RB_DIFF[9:8]
    isp_write(ISP_CSC_CABR_BASE+0xC8,0x64);  // CSC_CABR_RB_DIFF[7:0]
//  isp_write(ISP_CSC_CABR_BASE+0xCB,0x00);  // {6'd0,CSC_CABR_BR_DIFF[9:8]}
    isp_write(ISP_CSC_CABR_BASE+0xCA,0x64);  // CSC_CABR_BR_DIFF[7:0]
}
