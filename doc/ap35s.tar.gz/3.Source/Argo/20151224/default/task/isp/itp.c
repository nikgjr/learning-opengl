#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void ITP_set()
{
    unsigned int ITP_VBLK;

    #if(WDR_MODE_SEL==WDR_NORMAL_SET)
        ITP_VBLK = IN_VBLK;
    #elif(WDR_MODE_SEL==WDR_DOL2_SET)
        ITP_VBLK = IN_VBLK * 2;
    #elif(WDR_MODE_SEL==WDR_DOL3_SET)
        ITP_VBLK = IN_VBLK * 3;
    #else
        ITP_VBLK = IN_VBLK;
    #endif

    isp_write(ISP_ITP_BASE+0x81,0x03);  // {2'h0,I_VSWAP_pre,I_HSWAP_pre,2'h0,I_WHITE_FULL,I_COLOR_FULL};
    isp_write(ISP_ITP_BASE+0x82,0x00);  //       I_V_BLK_FP[7:0]
    isp_write(ISP_ITP_BASE+0x83,0x00);  // {4'h0,I_V_BLK_FP[11:8]};

    isp_write(ISP_ITP_BASE+0x84, ITP_VBLK     )  ;  //       I_V_BLK_SY[7:0];
    isp_write(ISP_ITP_BASE+0x85, ITP_VBLK >> 8)  ;  // {4'h0,I_V_BLK_SY[11:8]};
    isp_write(ISP_ITP_BASE+0x86,0x00);  //       I_V_BLK_BP[7:0];
    isp_write(ISP_ITP_BASE+0x87,0x00);  // {4'h0,I_V_BLK_BP[11:8]};
    isp_write(ISP_ITP_BASE+0x88,0xD4);  //       I_V_ACT_SIZE[7:0];
    isp_write(ISP_ITP_BASE+0x89,0x02);  // {4'h0,I_V_ACT_SIZE[11:8]};

    isp_write(ISP_ITP_BASE+0x8A,0x00);  //       I_H_BLK_FP[7:0];
    isp_write(ISP_ITP_BASE+0x8B,0x00);  // {4'h0,I_H_BLK_FP[11:8]};
    isp_write(ISP_ITP_BASE+0x8C, IN_HBLK     )  ;  //       I_H_BLK_SY[7:0];
    isp_write(ISP_ITP_BASE+0x8D, IN_HBLK >> 8)  ;  // {4'h0,I_H_BLK_SY[11:8]};
    isp_write(ISP_ITP_BASE+0x8E,0x00);  //       I_H_BLK_BP[7:0];
    isp_write(ISP_ITP_BASE+0x8F,0x00);  // {4'h0,I_H_BLK_BP[11:8]};
    isp_write(ISP_ITP_BASE+0x90, IN_HACT     )  ;  //       I_H_ACT_SIZE[7:0];
    isp_write(ISP_ITP_BASE+0x91, IN_HACT >> 8)  ;  // {4'h0,I_H_ACT_SIZE[11:8]};
    isp_write(ISP_ITP_BASE+0x92,0x00);  //       I_USER_R[7:0];
    isp_write(ISP_ITP_BASE+0x93,0x00);  // {6'h0,I_USER_R[9:8]};
    isp_write(ISP_ITP_BASE+0x94,0x00);  //       I_USER_G[7:0];
    isp_write(ISP_ITP_BASE+0x95,0x00);  // {6'h0,I_USER_G[9:8]};
    isp_write(ISP_ITP_BASE+0x96,0x00);  //       I_USER_B[7:0];
    isp_write(ISP_ITP_BASE+0x97,0x00);  // {6'h0,I_USER_B[9:8]};
    isp_write(ISP_ITP_BASE+0x80,0x20);  // {I_EN,1'b0,I_SYNCGEN_EN,I_TST_PAT[4:0]};
}

