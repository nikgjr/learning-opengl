#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void INPUT_CROP_set(void)
{
    isp_write(ISP_INPUT_CROP_BASE+0x20,0x00);  // INPUT_CROP_VSYNC_EN[2], INPUT_CROP_SYNC_EN[1], INPUT_CROP_EN[0]
    isp_write(ISP_INPUT_CROP_BASE+0x22,0x00);  // INPUT_CROP_H_POS[12:8]
    isp_write(ISP_INPUT_CROP_BASE+0x21,0x00);  // INPUT_CROP_H_POS[ 7:0]
    isp_write(ISP_INPUT_CROP_BASE+0x24,0x00);  // INPUT_CROP_V_POS[12:8]
    isp_write(ISP_INPUT_CROP_BASE+0x23,0x00);  // INPUT_CROP_V_POS[ 7:0]
    isp_write(ISP_INPUT_CROP_BASE+0x26, IN_HACT>>8); // INPUT_CROP_H_SIZE[12:8]
    isp_write(ISP_INPUT_CROP_BASE+0x25, IN_HACT   ); // INPUT_CROP_H_SIZE[ 7:0]
    isp_write(ISP_INPUT_CROP_BASE+0x28, IN_VACT>>8); // INPUT_CROP_V_SIZE[12:8]
    isp_write(ISP_INPUT_CROP_BASE+0x27, IN_VACT   ); // INPUT_CROP_V_SIZE[ 7:0]
}

