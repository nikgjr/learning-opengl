#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void DPC_STATIC_WR(void)
{
	tdk_printf("DPC set\n");

    isp_write(ISP_IND_BANK,0xB0);      // BANK

    isp_write(ISP_IND_ADDR  ,0x00);     // addr
    isp_write(ISP_IND_RWDATA,0x00);     // WDATA
    isp_write(ISP_IND_ADDR  ,0x01);     // addr
    isp_write(ISP_IND_RWDATA,0x09);     // WDATA
    isp_write(ISP_IND_ADDR  ,0x02);     // addr
    isp_write(ISP_IND_RWDATA,0x00);     // WDATA
    isp_write(ISP_IND_ADDR  ,0x03);     // addr
    isp_write(ISP_IND_RWDATA,0x09);     // WDATA
    isp_write(ISP_IND_ADDR  ,0x04);     // addr
    isp_write(ISP_IND_RWDATA,0x00);     // WDATA

    isp_write(ISP_IND_ADDR  ,0x05);     // addr
    isp_write(ISP_IND_RWDATA,0x10);     // WDATA
    isp_write(ISP_IND_ADDR  ,0x06);     // addr
    isp_write(ISP_IND_RWDATA,0x00);     // WDATA
    isp_write(ISP_IND_ADDR  ,0x07);     // addr
    isp_write(ISP_IND_RWDATA,0x10);     // WDATA
    isp_write(ISP_IND_ADDR  ,0x08);     // addr
    isp_write(ISP_IND_RWDATA,0x00);     // WDATA
    isp_write(ISP_IND_ADDR  ,0x09);     // addr
    isp_write(ISP_IND_RWDATA,0x19);     // WDATA
/*
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x0A);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x0B);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x1B);      // WDATA

    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x0C);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x0D);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x1D);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x0E);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x0F);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x1F);      // WDATA

    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x10);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x01);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x11);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x01);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x12);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x01);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x13);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x03);      // WDATA

    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x14);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x01);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x15);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x05);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x16);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x01);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x17);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x07);      // WDATA

    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x18);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x01);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x19);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x09);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x1A);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x01);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x1B);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x0B);      // WDATA

    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x1C);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x01);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x1D);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x0D);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x1E);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x01);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x1F);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x0F);      // WDATA

    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x1C);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x01);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x1D);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x0D);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x1E);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x01);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x1F);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x0F);      // WDATA

    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x20);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x21);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x22);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x23);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA

    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x24);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x25);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x26);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x27);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA

    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x28);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x29);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x2A);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x2B);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA

    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x2C);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x2D);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x2E);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x2F);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA

    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x30);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x31);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x32);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
    isp_write(ISP_DPC_STA_WR_BASE+0x87,0x33);      // addr
    isp_write(ISP_DPC_STA_WR_BASE+0x88,0x00);      // WDATA
*/
}

void DPC_STATIC_RD(void)
{
    unsigned int DPC_STATIC_0;
    unsigned int DPC_STATIC_1;
    unsigned int DPC_STATIC_2;
    unsigned int DPC_STATIC_3;
    unsigned int DPC_STATIC_4;
    unsigned int DPC_STATIC_5;
    unsigned int DPC_STATIC_6;
    unsigned int DPC_STATIC_7;
    unsigned int DPC_STATIC_8;
    unsigned int DPC_STATIC_9;
    unsigned int DPC_STATIC_10;
//    UCHAR DPC_STATIC_11;
//    UCHAR DPC_STATIC_12;
//    UCHAR DPC_STATIC_13;
//    UCHAR DPC_STATIC_14;
//    UCHAR DPC_STATIC_15;
//    UCHAR DPC_STATIC_16;
//    UCHAR DPC_STATIC_17;
//    UCHAR DPC_STATIC_18;
//    UCHAR DPC_STATIC_19;
//    UCHAR DPC_STATIC_20;
//    UCHAR DPC_STATIC_21;
//    UCHAR DPC_STATIC_22;
//    UCHAR DPC_STATIC_23;
//    UCHAR DPC_STATIC_24;
//    UCHAR DPC_STATIC_25;
//    UCHAR DPC_STATIC_26;
//    UCHAR DPC_STATIC_27;
//    UCHAR DPC_STATIC_28;
//    UCHAR DPC_STATIC_29;
//    UCHAR DPC_STATIC_30;
//    UCHAR DPC_STATIC_31;
//    UCHAR DPC_STATIC_32;
//    UCHAR DPC_STATIC_33;
//    UCHAR DPC_STATIC_34;
//    UCHAR DPC_STATIC_35;
//    UCHAR DPC_STATIC_36;
//    UCHAR DPC_STATIC_37;
//    UCHAR DPC_STATIC_38;
//    UCHAR DPC_STATIC_39;
//    UCHAR DPC_STATIC_40;
//    UCHAR DPC_STATIC_41;
//    UCHAR DPC_STATIC_42;
//    UCHAR DPC_STATIC_43;
//    UCHAR DPC_STATIC_44;
//    UCHAR DPC_STATIC_45;
//    UCHAR DPC_STATIC_46;
//    UCHAR DPC_STATIC_47;
//    UCHAR DPC_STATIC_48;
//    UCHAR DPC_STATIC_49;
//    UCHAR DPC_STATIC_50;
//    UCHAR DPC_STATIC_51;
//    UCHAR DPC_STATIC_52;

    isp_write(ISP_IND_BANK, 0x90);      // BANK
    isp_write(ISP_IND_ADDR, 0x00); DPC_STATIC_0 = isp_read(ISP_IND_RWDATA);      // RDATA
    isp_write(ISP_IND_ADDR, 0x01); DPC_STATIC_1 = isp_read(ISP_IND_RWDATA);      // RDATA
    isp_write(ISP_IND_ADDR, 0x02); DPC_STATIC_2 = isp_read(ISP_IND_RWDATA);      // RDATA
    isp_write(ISP_IND_ADDR, 0x03); DPC_STATIC_3 = isp_read(ISP_IND_RWDATA);      // RDATA
    isp_write(ISP_IND_ADDR, 0x04); DPC_STATIC_4 = isp_read(ISP_IND_RWDATA);      // RDATA
    isp_write(ISP_IND_ADDR, 0x05); DPC_STATIC_5 = isp_read(ISP_IND_RWDATA);      // RDATA
    isp_write(ISP_IND_ADDR, 0x06); DPC_STATIC_6 = isp_read(ISP_IND_RWDATA);      // RDATA
    isp_write(ISP_IND_ADDR, 0x07); DPC_STATIC_7 = isp_read(ISP_IND_RWDATA);      // RDATA
    isp_write(ISP_IND_ADDR, 0x08); DPC_STATIC_8 = isp_read(ISP_IND_RWDATA);      // RDATA
    isp_write(ISP_IND_ADDR, 0x09); DPC_STATIC_9 = isp_read(ISP_IND_RWDATA);      // RDATA
/*
    *(SFR16)0xC002 = 0x0a;      // addr
    DPC_STATIC_2 = *(SFR16)0xC003;      // RDATA
    *(SFR16)0xC002 = 0x0b;      // addr
    DPC_STATIC_3 = *(SFR16)0xC003;      // RDATA
    *(SFR16)0xC002 = 0x0c;      // addr
    DPC_STATIC_4 = *(SFR16)0xC003;      // RDATA
    *(SFR16)0xC002 = 0x0d;      // addr
    DPC_STATIC_5 = *(SFR16)0xC003;      // RDATA
    *(SFR16)0xC002 = 0x0e;      // addr
    DPC_STATIC_6 = *(SFR16)0xC003;      // RDATA
    *(SFR16)0xC002 = 0x0f;      // addr
    DPC_STATIC_7 = *(SFR16)0xC003;      // RDATA
*/
}

void DPC_LIVE(void)
{
	tdk_printf("DPC_live set\n");
    isp_write(ISP_DPC_LIVE_BASE+0x00,0xE0);  // {DPC_EN,DPC_BLACK,DPC_WHITE,DPC_TEST,DPC_STATIC_EN,3'd0}
    isp_write(ISP_DPC_LIVE_BASE+0x01,0xff);  // DPC_DM_H_EN
    isp_write(ISP_DPC_LIVE_BASE+0x02,0x0A);  // DPC_TH_H_L[9:2]
    isp_write(ISP_DPC_LIVE_BASE+0x02,0x02);  // {2'd0,DPC_TH_H_L[1:0],2'd0,DPC_TH_H_P}
    isp_write(ISP_DPC_LIVE_BASE+0x04,0x10);  // DPC_TH_H_P[7:0]
    isp_write(ISP_DPC_LIVE_BASE+0x06,0x0A);  // DPC_TH_H_WD[11:4]
//  isp_write(ISP_DPC_LIVE_BASE+0x06,0x00);  // {DPC_TH_H_WD[3:0],2'd0,DPC_TH_H_WP}
    isp_write(ISP_DPC_LIVE_BASE+0x08,0x44);  // DPC_TH_H_WP[7:0]
    isp_write(ISP_DPC_LIVE_BASE+0x0A,0x02);  // DPC_TH_H_ED[9:2]
    isp_write(ISP_DPC_LIVE_BASE+0x0A,0x60);  // {2'd0,DPC_TH_H_ED[1:0],2'd0,DPC_TH_H_EP}
    isp_write(ISP_DPC_LIVE_BASE+0x0C,0x44);  // DPC_TH_H_EP[7:0]
    isp_write(ISP_DPC_LIVE_BASE+0x0E,0xFF);  // DPC_DM_C_EN
    isp_write(ISP_DPC_LIVE_BASE+0x0F,0x0A);  // DPC_TH_C_L[9:2]
    isp_write(ISP_DPC_LIVE_BASE+0x0F,0x02);  // {2'd0,DPC_TH_C_L[1:0],2'd0,DPC_TH_C_P}
    isp_write(ISP_DPC_LIVE_BASE+0x11,0x10);  // DPC_TH_C_P[7:0]
    isp_write(ISP_DPC_LIVE_BASE+0x13,0x0A);  // DPC_TH_C_WD[11:4]
//  isp_write(ISP_DPC_LIVE_BASE+0x13,0x00);  // {DPC_TH_C_WD[3:0],2'd0,DPC_TH_C_WP}
    isp_write(ISP_DPC_LIVE_BASE+0x15,0x44);  // DPC_TH_C_WP[7:0]
    isp_write(ISP_DPC_LIVE_BASE+0x17,0x02);  // DPC_TH_C_ED[9:2]
    isp_write(ISP_DPC_LIVE_BASE+0x17,0x60);  // {2'd0,DPC_TH_C_ED[1:0],2'd0,DPC_TH_C_EP}
    isp_write(ISP_DPC_LIVE_BASE+0x19,0x44);  // DPC_TH_C_EP[7:0]

    isp_write(ISP_DPC_LIVE_BASE+0x27,0x03);  // {6'd0,DPC_STATIC_DIFF_MODE[1:0]}
//  isp_write(ISP_DPC_LIVE_BASE+0x29,0x00);  // {4'd0,DPC_STATIC_INTP_W_TH[11:8]}
//  isp_write(ISP_DPC_LIVE_BASE+0x28,0x00);  // DPC_STATIC_INTP_W_TH[7:0]
    isp_write(ISP_DPC_LIVE_BASE+0x2B,0x0F);  // {4'd0,DPC_STATIC_INTP_B_TH[11:8]}
    isp_write(ISP_DPC_LIVE_BASE+0x2A,0xFF);  // DPC_STATIC_INTP_B_TH[7:0]
//  isp_write(ISP_DPC_LIVE_BASE+0x2C,0x00);  // {3'd0,DPC_STATIC_MCU,3'd0,DPC_STATIC_SRAM}
//  isp_write(ISP_DPC_LIVE_BASE+0x41,0x00);  // {3'd0,DPC_R_ENABLE,3'd0,DPC_W_ENABLE}
    isp_write(ISP_DPC_LIVE_BASE+0x45,0x80);  // DPC_R_READ_ADDR[31:24]
    isp_write(ISP_DPC_LIVE_BASE+0x44,0x3D);  // DPC_R_READ_ADDR[23:16]
    isp_write(ISP_DPC_LIVE_BASE+0x43,0x4C);  // DPC_R_READ_ADDR[15:8 ]
//  isp_write(ISP_DPC_LIVE_BASE+0x42,0x00);  // DPC_R_READ_ADDR[ 7:0 ]
    isp_write(ISP_DPC_LIVE_BASE+0x46,0x07);  // {4'd0,DPC_R_BURST_CTRL[3:0]}
    isp_write(ISP_DPC_LIVE_BASE+0x4A,0x80);  // DPC_W_WRITE_ADDR[31:24]
    isp_write(ISP_DPC_LIVE_BASE+0x49,0x3D);  // DPC_W_WRITE_ADDR[23:16]
    isp_write(ISP_DPC_LIVE_BASE+0x48,0x4C);  // DPC_W_WRITE_ADDR[15:8 ]
//  isp_write(ISP_DPC_LIVE_BASE+0x47,0x00);  // DPC_W_WRITE_ADDR[ 7:0 ]
    isp_write(ISP_DPC_LIVE_BASE+0x4B,0x07);  // {4'd0,DPC_W_BURST_CTRL[3:0]}

    isp_write(ISP_DPC_LIVE_BASE+0x70,0x01);  // {7'd0,DPC_MANUAL_EN}
//  isp_write(ISP_DPC_LIVE_BASE+0x78,0x00);  // {4'd0,DPC_MANUAL_X01[]11:8]}
    isp_write(ISP_DPC_LIVE_BASE+0x77,0x10);  // DPC_MANUAL_X01[7:0]
//  isp_write(ISP_DPC_LIVE_BASE+0x7A,0x00);  // {4'd0,DPC_MANUAL_Y01[]11:8]}
    isp_write(ISP_DPC_LIVE_BASE+0x79,0x10);  // DPC_MANUAL_Y01[7:0]
//  isp_write(ISP_DPC_LIVE_BASE+0x7C,0x00);  // {4'd0,DPC_MANUAL_X02[]11:8]}
    isp_write(ISP_DPC_LIVE_BASE+0x7B,0x20);  // DPC_MANUAL_X02[7:0]
//  isp_write(ISP_DPC_LIVE_BASE+0x7E,0x00);  // {4'd0,DPC_MANUAL_Y02[]11:8]}
    isp_write(ISP_DPC_LIVE_BASE+0x7D,0x20);  // DPC_MANUAL_Y02[7:0]
    isp_write(ISP_DPC_LIVE_BASE+0x80,0x01);  // {4'd0,DPC_MANUAL_X03[]11:8]}
//  isp_write(ISP_DPC_LIVE_BASE+0x7F,0x00);  // DPC_MANUAL_X03[7:0]
//  isp_write(ISP_DPC_LIVE_BASE+0x82,0x00);  // {4'd0,DPC_MANUAL_Y03[]11:8]}
    isp_write(ISP_DPC_LIVE_BASE+0x81,0x10);  // DPC_MANUAL_Y03[7:0]
    isp_write(ISP_DPC_LIVE_BASE+0x84,0x01);  // {4'd0,DPC_MANUAL_X04[]11:8]}
//  isp_write(ISP_DPC_LIVE_BASE+0x83,0x00);  // DPC_MANUAL_X04[7:0]
    isp_write(ISP_DPC_LIVE_BASE+0x86,0x01);  // {4'd0,DPC_MANUAL_Y04[]11:8]}
//  isp_write(ISP_DPC_LIVE_BASE+0x85,0x00);  // DPC_MANUAL_Y04[7:0]
}

