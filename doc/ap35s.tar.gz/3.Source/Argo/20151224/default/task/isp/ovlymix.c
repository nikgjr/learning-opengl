#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void OVLYMIX_set(void)
{
	tdk_printf("OVLYMIX set\n");

    #if(CVBS_MODE_DIGITAL == ON)
    isp_write(ISP_OVLYMIX_BASE+0xB0,0x90);  // {I_CVBS_CROP_ORDER, 3'd0, I_ORDER_DEFAULT_SET   }
    isp_write(ISP_OVLYMIX_BASE+0xB1,0x12);  // {I_BOX_GRID_ORDER,        I_BMD_YC444_ORDER     }
    isp_write(ISP_OVLYMIX_BASE+0xB2,0x35);  // {I_OTP_ORDER,             I_OSG_ORI_ORDER       }
    isp_write(ISP_OVLYMIX_BASE+0xB3,0x67);  // {I_PGL_ORDER,             I_OSG_ORDER           }
    isp_write(ISP_OVLYMIX_BASE+0xB4,0x8A);  // {I_OSD_ORDER,             I_OF_ORDER            }
    #else
    isp_write(ISP_OVLYMIX_BASE+0xB0,0x90);  // {I_CVBS_CROP_ORDER, 3'd0, I_ORDER_DEFAULT_SET   }
    isp_write(ISP_OVLYMIX_BASE+0xB1,0x12);  // {I_BOX_GRID_ORDER,        I_BMD_YC444_ORDER     }
    isp_write(ISP_OVLYMIX_BASE+0xB2,0x35);  // {I_OTP_ORDER,             I_OSG_ORI_ORDER       }
    isp_write(ISP_OVLYMIX_BASE+0xB3,0x67);  // {I_PGL_ORDER,             I_OSG_ORDER           }
    isp_write(ISP_OVLYMIX_BASE+0xB4,0x89);  // {I_OSD_ORDER,             I_OF_ORDER            }
    #endif
}
