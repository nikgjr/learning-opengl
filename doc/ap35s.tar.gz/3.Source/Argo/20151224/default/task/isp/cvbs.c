#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

// CVBS Path (CVBS_CROP, CVBS_DS, CVBS_LINE_FIL, CVBS_FRC, CVBS_HPF, CVBS_VE)
#define CVBS_DS_LPF_MODE_H      1
#define CVBS_DS_LPF_MODE_V      2
#define CVBS_DS_LPF_MODE_HV     3
#define CVBS_DS_LPF_MODE        CVBS_DS_LPF_MODE_HV

#define CVBS_CROP_NON           0   //   0. using H/V Down-Scaling
#define CVBS_CROP_H             1   //   1. using H Cropping and V Down-Scaling
#define CVBS_CROP_HV            2   //   2. using only H/V Cropping
#define CVBS_CROP_MODE          CVBS_CROP_NON
void CVBS_set(void)
{
    // sel_path (CVBS Path)
    //   0. using H/V Down-Scaling
    //   1. using H Cropping and V Down-Scaling
    //   2. using only H/V Cropping

    unsigned int out_hact_size, out_hblk_size, out_vact_size, out_vblk1_size, out_vblk2_size;
    unsigned int cvbs_crop_hblk_size, cvbs_crop_hact_size, cvbs_crop_vact_size;
    unsigned int h_margin, v_margin;
    unsigned long h_dto, v_dto;
    unsigned int out_vact_size_div2;
    unsigned int out_htotal_size;
    unsigned int out_vact_crop_pos;
    unsigned int out_hact_crop_pos;
    unsigned int out_vact_crop_wline;

	tdk_printf("CVBS set\n");
    // Encoder Out Size Calculation
#if(CVBS_MODE_SEL & CVBS_MODE_BYPASS)
    out_hact_size   = FRC_HACT;
    out_hblk_size   = FRC_HBLK;
#else
    out_hact_size   = CVBS_HACT;
    out_hblk_size   = CVBS_HBLK;
#endif

#if(CVBS_MODE_SEL & CVBS_MODE_BYPASS)
    out_vact_size   = FRC_VACT;
    out_vblk1_size  = (FRC_VBLK + 1) >> 1;      // out_vblk1_size >= out_vblk2_size
    out_vblk2_size  = FRC_VBLK >> 1;
#else
    out_vact_size   = CVBS_VACT;
    out_vblk1_size  = CVBS_VBLK1;
    out_vblk2_size  = CVBS_VBLK2;
#endif

    ////////////////////////////////////////////////////////////////////////
    // CVBS_CROP
    ////////////////////////////////////////////////////////////////////////
    // Auto-Crop Size Calculation
    //   - to crop a image at center, use horizontal and vertical margin size
    h_margin = 0;
    v_margin = 0;

#if(CVBS_CROP_MODE == CVBS_CROP_NON)
    cvbs_crop_hact_size = CVBS_CROP_FRC_HACT;
    cvbs_crop_vact_size = CVBS_CROP_FRC_VACT;
    if(FRC_HACT >= cvbs_crop_hact_size)
    {
        cvbs_crop_hblk_size = FRC_HTOTAL - cvbs_crop_hact_size;
        h_margin            = (FRC_HACT - cvbs_crop_hact_size) >> 1;
    }
    else
    {
        cvbs_crop_hblk_size = FRC_HBLK;
    }
    if(FRC_VACT >= cvbs_crop_vact_size)   v_margin = (FRC_VACT - cvbs_crop_vact_size) >> 1;
#elif(CVBS_CROP_MODE == CVBS_CROP_H)
    cvbs_crop_hact_size = out_hact_size;
    cvbs_crop_vact_size = CVBS_CROP_FRC_VACT;
    if(FRC_HACT >= cvbs_crop_hact_size)
    {
        cvbs_crop_hblk_size = FRC_HTOTAL - cvbs_crop_hact_size;
        h_margin            = (FRC_HACT - cvbs_crop_hact_size) >> 1;
    }
    else
    {
        cvbs_crop_hblk_size = FRC_HBLK;
    }
    if(FRC_VACT >= cvbs_crop_vact_size)   v_margin = (FRC_VACT - cvbs_crop_vact_size) >> 1;
#elif(CVBS_CROP_MODE == CVBS_CROP_HV)
    cvbs_crop_hact_size = out_hact_size;
    cvbs_crop_vact_size = out_vact_size;
    if(FRC_HACT >= cvbs_crop_hact_size)
    {
        cvbs_crop_hblk_size = FRC_HTOTAL - cvbs_crop_hact_size;
        h_margin            = (FRC_HACT - cvbs_crop_hact_size) >> 1;
    }
    else
    {
        cvbs_crop_hblk_size = FRC_HBLK;
    }
    if(FRC_VACT >= cvbs_crop_vact_size)   v_margin = (FRC_VACT - cvbs_crop_vact_size) >> 1;
#endif

    isp_write(ISP_CVBSCROP_BASE+0x00,0x08);                         // {O_CVBS_CROP_REG_CHG, 3'd0, O_CVBS_CROP_REG_AUTO, O_CVBS_CROP_VEN, O_CVBS_CROP_HEN, O_CVBS_CROP_HACT_LOCK_EN};
    isp_write(ISP_CVBSCROP_BASE+0x02,v_margin >> 8);                // {4'd0, O_CVBS_CROP_V_POS[11:8]};
    isp_write(ISP_CVBSCROP_BASE+0x01,v_margin);                     // O_CVBS_CROP_V_POS[ 7:0];
    isp_write(ISP_CVBSCROP_BASE+0x04,h_margin >> 8);                // {3'd0, O_CVBS_CROP_H_POS[12:8]};
    isp_write(ISP_CVBSCROP_BASE+0x03,h_margin);                     // O_CVBS_CROP_H_POS[ 7:0];
    isp_write(ISP_CVBSCROP_BASE+0x06,cvbs_crop_vact_size >> 8);     // {4'd0, O_CVBS_CROP_V_ACT[11:8]};
    isp_write(ISP_CVBSCROP_BASE+0x05,cvbs_crop_vact_size);          // O_CVBS_CROP_V_ACT[ 7:0];
    isp_write(ISP_CVBSCROP_BASE+0x08,cvbs_crop_hact_size >> 8);     // {3'd0, O_CVBS_CROP_H_ACT[12:8]};
    isp_write(ISP_CVBSCROP_BASE+0x07,cvbs_crop_hact_size);          // O_CVBS_CROP_H_ACT[ 7:0];
    isp_write(ISP_CVBSCROP_BASE+0x00,0x8F);                         // {O_CVBS_CROP_REG_CHG, 3'd0, O_CVBS_CROP_REG_AUTO, O_CVBS_CROP_VEN, O_CVBS_CROP_HEN, O_CVBS_CROP_HACT_LOCK_EN};

    ////////////////////////////////////////////////////////////////////////
    // CVBS_DS
    ////////////////////////////////////////////////////////////////////////
    // DTO = in / out * 16384
    h_dto = (unsigned long)cvbs_crop_hact_size * 16384 / out_hact_size;
    v_dto = (unsigned long)cvbs_crop_vact_size * 16384 / out_vact_size;

    isp_write(ISP_CVBSDS_BASE+0x06,0x40);                           // {O_CVBSDS_REG_CHG, O_CVBSDS_REG_AUTO, O_CVBSDS_LPF_YEN, O_CVBSDS_LPF_CEN, O_CVBSDS_CHROMA_MODE, O_CVBSDS_CSWAP_MODE, O_CVBSDS_LPF_EN};
    isp_write(ISP_CVBSDS_BASE+0x01,cvbs_crop_hact_size >> 8);       // {3'd0, O_CVBSDS_IN_HACT_SIZE[12:8]};
    isp_write(ISP_CVBSDS_BASE+0x00,cvbs_crop_hact_size);            // O_CVBSDS_IN_HACT_SIZE[7:0];
    isp_write(ISP_CVBSDS_BASE+0x03,cvbs_crop_hblk_size >> 8);       // {3'd0, O_CVBSDS_IN_HBLK_SIZE[12:8]};
    isp_write(ISP_CVBSDS_BASE+0x02,cvbs_crop_hblk_size);            // O_CVBSDS_IN_HBLK_SIZE[7:0];
    isp_write(ISP_CVBSDS_BASE+0x05,cvbs_crop_vact_size >> 8);       // {3'd0, O_CVBSDS_IN_VACT_SIZE[12:8]};
    isp_write(ISP_CVBSDS_BASE+0x04,cvbs_crop_vact_size);            // O_CVBSDS_IN_VACT_SIZE[7:0];

#if(CVBS_DS_LPF_MODE == CVBS_DS_LPF_MODE_H)
    // 0.27406861906119695  (0x119)
    // 0.45186276187760599  (0x1CD)
    // 0.27406861906119695  (0x119)
    isp_write(ISP_CVBSDS_BASE+0x06,0x71);                           // {O_CVBSDS_REG_CHG, O_CVBSDS_REG_AUTO, O_CVBSDS_LPF_YEN, O_CVBSDS_LPF_CEN, O_CVBSDS_CHROMA_MODE, O_CVBSDS_CSWAP_MODE, O_CVBSDS_LPF_EN};
    isp_write(ISP_CVBSDS_BASE+0x0F,0xCD);                           // O_CVBSDS_LPF_COF11[7:0];
    isp_write(ISP_CVBSDS_BASE+0x10,0x01);                           // {6'd0, O_CVBSDS_LPF_COF11[9:8]};
    isp_write(ISP_CVBSDS_BASE+0x11,0x19);                           // O_CVBSDS_LPF_COF12[7:0];
    isp_write(ISP_CVBSDS_BASE+0x12,0x01);                           // {6'd0, O_CVBSDS_LPF_COF12[9:8]};
#elif(CVBS_DS_LPF_MODE == CVBS_DS_LPF_MODE_V)
    // 0.27406861906119695  (0x119)
    // 0.45186276187760599  (0x1CD)
    // 0.27406861906119695  (0x119)
    isp_write(ISP_CVBSDS_BASE+0x06,0x71);                           // {O_CVBSDS_REG_CHG, O_CVBSDS_REG_AUTO, O_CVBSDS_LPF_YEN, O_CVBSDS_LPF_CEN, O_CVBSDS_CHROMA_MODE, O_CVBSDS_CSWAP_MODE, O_CVBSDS_LPF_EN};
    isp_write(ISP_CVBSDS_BASE+0x0F,0xCD);                           // O_CVBSDS_LPF_COF11[7:0];
    isp_write(ISP_CVBSDS_BASE+0x10,0x01);                           // {6'd0, O_CVBSDS_LPF_COF11[9:8]};
    isp_write(ISP_CVBSDS_BASE+0x15,0x19);                           // O_CVBSDS_LPF_COF12[7:0];
    isp_write(ISP_CVBSDS_BASE+0x16,0x01);                           // {6'd0, O_CVBSDS_LPF_COF12[9:8]};
#elif(CVBS_DS_LPF_MODE == CVBS_DS_LPF_MODE_HV)
    // 0.0751136079541114   (0x4D)
    // 0.123841403152973    (0x7F)
    // 0.0751136079541114   (0x4D)
    // 0.123841403152973    (0x7F)
    // 0.204179955571658    (0xCF)
    // 0.123841403152973    (0x7F)
    // 0.0751136079541114   (0x4D)
    // 0.123841403152973    (0x7F)
    // 0.0751136079541114   (0x4D)
    isp_write(ISP_CVBSDS_BASE+0x06,0x71);                           // {O_CVBSDS_REG_CHG, O_CVBSDS_REG_AUTO, O_CVBSDS_LPF_YEN, O_CVBSDS_LPF_CEN, O_CVBSDS_CHROMA_MODE, O_CVBSDS_CSWAP_MODE, O_CVBSDS_LPF_EN};
    isp_write(ISP_CVBSDS_BASE+0x0F,0xCF);                           // O_CVBSDS_LPF_COF11[7:0];
//  isp_write(ISP_CVBSDS_BASE+0x10,0x00);                           // {6'd0, O_CVBSDS_LPF_COF11[9:8]};
    isp_write(ISP_CVBSDS_BASE+0x11,0x7F);                           // O_CVBSDS_LPF_COF12[7:0];
//  isp_write(ISP_CVBSDS_BASE+0x12,0x00);                           // {6'd0, O_CVBSDS_LPF_COF12[9:8]};
    isp_write(ISP_CVBSDS_BASE+0x15,0x7F);                           // O_CVBSDS_LPF_COF21[7:0];
//  isp_write(ISP_CVBSDS_BASE+0x16,0x00);                           // {6'd0, O_CVBSDS_LPF_COF21[9:8]};
    isp_write(ISP_CVBSDS_BASE+0x17,0x4D);                           // O_CVBSDS_LPF_COF22[7:0];
//  isp_write(ISP_CVBSDS_BASE+0x18,0x00);                           // {6'd0, O_CVBSDS_LPF_COF22[9:8]};
#endif

    isp_write(ISP_CVBSDS_BASE+0x07,0x0C);                           // {O_PRE_REG_EN, 1'd0, O_DS_METHOD_Y, O_DS_METHOD_C, O_TABLE_SEL_Y, O_TABLE_SEL_C}
    isp_write(ISP_CVBSDS_BASE+0x1A,h_dto >> 8);                     // O_CVBSDS_H_DTO[15:8];
    isp_write(ISP_CVBSDS_BASE+0x19,h_dto);                          // O_CVBSDS_H_DTO[7:0];
    isp_write(ISP_CVBSDS_BASE+0x1C,v_dto >> 8);                     // O_CVBSDS_V_DTO[15:8];
    isp_write(ISP_CVBSDS_BASE+0x1B,v_dto);                          // O_CVBSDS_V_DTO[7:0];
    isp_write(ISP_CVBSDS_BASE+0x1E,out_hact_size >> 8);             // {5'd0, O_CVBSDS_OUT_HACT_SIZE[10:8]};
    isp_write(ISP_CVBSDS_BASE+0x1D,out_hact_size);                  // O_CVBSDS_OUT_HACT_SIZE[7:0];
    isp_write(ISP_CVBSDS_BASE+0x20,out_vact_size >> 8);             // {6'd0, O_CVBSDS_OUT_VACT_SIZE[9:8]};
    isp_write(ISP_CVBSDS_BASE+0x1F,out_vact_size);                  // O_CVBSDS_OUT_VACT_SIZE[7:0];

    ////////////////////////////////////////////////////////////////////////
    // CVBS_FRC
    ////////////////////////////////////////////////////////////////////////
    out_vact_size_div2 = out_vact_size >> 1;
    out_htotal_size = out_hblk_size+out_hact_size;

    #if(CVBS_MODE_DIGITAL == ON)
    isp_write(ISP_CVBSFRC_BASE+0x00,FRC_VACT);                      // O_CVBS_VACT[7:0];
    isp_write(ISP_CVBSFRC_BASE+0x01,FRC_VACT >> 8);                 // {5'd0, O_CVBS_VACT[10:8]};
    isp_write(ISP_CVBSFRC_BASE+0x02,FRC_VBLK);                      // O_CVBS_VSW1[7:0];
    isp_write(ISP_CVBSFRC_BASE+0x03,FRC_VBLK >> 8);                 // {5'd0, O_CVBS_VSW1[10:8]};
    isp_write(ISP_CVBSFRC_BASE+0x04,0x00);                          // O_CVBS_VSW2[7:0];
    isp_write(ISP_CVBSFRC_BASE+0x05,0x00);                          // {5'd0, O_CVBS_VSW2[10:8]};
    isp_write(ISP_CVBSFRC_BASE+0x06,FRC_HACT);                      // O_CVBS_HACT[7:0];
    isp_write(ISP_CVBSFRC_BASE+0x07,FRC_HACT >> 8);                 // {5'd0, O_CVBS_HACT[10:8]};
    isp_write(ISP_CVBSFRC_BASE+0x08,FRC_HBLK);                      // O_CVBS_HSW[7:0];
    isp_write(ISP_CVBSFRC_BASE+0x09,FRC_HBLK >> 8);                 // {5'd0, O_CVBS_HSW[10:8]};

    isp_write(ISP_CVBSFRC_BASE+0x17,0x00);                          // CVBS_FIELD_EN[1], CVBS_FRAME_MODE[0]
    isp_write(ISP_CVBSFRC_BASE+0x1A,0x11);                          // {2'h0,I_CVBS_CROP_POS_SEL,I_CVBS_CROP_EN,2'h0,I_CVBS_DO_CSWAP,I_CVBS_DIGITAL_OUT}

    #if(CVBS_FRC_DPCM == ON)
    isp_write(ISP_CVBSFRC_BASE+0x0C,0xC1);                          // {I_ENABLE_CVBS_WRAP, O_CVBS_DPCM_EN, r_overflow_cvbs_frc, r_underflow_cvbs_frc, O_FREEZE_CVBS_FRC, O_VFLIP_CVBS_FRC, O_CVBS_WR_FAST, O_ENABLE_CVBS_FRC};
    #else
    isp_write(ISP_CVBSFRC_BASE+0x0C,0x81);                          // {I_ENABLE_CVBS_WRAP, O_CVBS_DPCM_EN, r_overflow_cvbs_frc, r_underflow_cvbs_frc, O_FREEZE_CVBS_FRC, O_VFLIP_CVBS_FRC, O_CVBS_WR_FAST, O_ENABLE_CVBS_FRC};
    #endif
    #else
    isp_write(ISP_CVBSFRC_BASE+0x00,out_vact_size_div2);            // O_CVBS_VACT[7:0];
    isp_write(ISP_CVBSFRC_BASE+0x01,out_vact_size_div2 >> 8);       // {5'd0, O_CVBS_VACT[10:8]};
    isp_write(ISP_CVBSFRC_BASE+0x02,out_vblk1_size);                // O_CVBS_VSW1[7:0];
    isp_write(ISP_CVBSFRC_BASE+0x03,out_vblk1_size >> 8);           // {5'd0, O_CVBS_VSW1[10:8]};
    isp_write(ISP_CVBSFRC_BASE+0x04,out_vblk2_size);                // O_CVBS_VSW2[7:0];
    isp_write(ISP_CVBSFRC_BASE+0x05,out_vblk2_size >> 8);           // {5'd0, O_CVBS_VSW2[10:8]};
    isp_write(ISP_CVBSFRC_BASE+0x06,out_hact_size);                 // O_CVBS_HACT[7:0];
    isp_write(ISP_CVBSFRC_BASE+0x07,out_hact_size >> 8);            // {5'd0, O_CVBS_HACT[10:8]};
    isp_write(ISP_CVBSFRC_BASE+0x08,out_hblk_size);                 // O_CVBS_HSW[7:0];
    isp_write(ISP_CVBSFRC_BASE+0x09,out_hblk_size >> 8);            // {5'd0, O_CVBS_HSW[10:8]};

    isp_write(ISP_CVBSFRC_BASE+0x17,0x02);                          // CVBS_FIELD_EN[1], CVBS_FRAME_MODE[0]
    isp_write(ISP_CVBSFRC_BASE+0x1A,0x00);                          // {2'h0,I_CVBS_CROP_POS_SEL,I_CVBS_CROP_EN,2'h0,I_CVBS_DO_CSWAP,I_CVBS_DIGITAL_OUT}

    #if(CVBS_FRC_DPCM == ON)
    isp_write(ISP_CVBSFRC_BASE+0x0C,0x41);                          // {1'd0, O_CVBS_DPCM_EN, r_overflow_cvbs_frc, r_underflow_cvbs_frc, O_FREEZE_CVBS_FRC, O_VFLIP_CVBS_FRC, O_CVBS_WR_FAST, O_ENABLE_CVBS_FRC};
    #else
    isp_write(ISP_CVBSFRC_BASE+0x0C,0x01);                          // {1'd0, O_CVBS_DPCM_EN, r_overflow_cvbs_frc, r_underflow_cvbs_frc, O_FREEZE_CVBS_FRC, O_VFLIP_CVBS_FRC, O_CVBS_WR_FAST, O_ENABLE_CVBS_FRC};
    #endif
    #endif
    isp_write(ISP_CVBSFRC_BASE+0x0B,0xFF);                          // CVBS_Y_LIM[7:0]

    isp_write(ISP_CVBSFRC_BASE+0x0D,CVBS_BASE0_ADDR);               // cvbs_addr_1(3)
    isp_write(ISP_CVBSFRC_BASE+0x0E,CVBS_BASE0_ADDR >> 8);          // cvbs_addr_1(2)
    isp_write(ISP_CVBSFRC_BASE+0x0F,CVBS_BASE0_ADDR >> 16);         // cvbs_addr_1(1)
    isp_write(ISP_CVBSFRC_BASE+0x10,CVBS_BASE0_ADDR >> 24);         // cvbs_addr_1(0)
    isp_write(ISP_CVBSFRC_BASE+0x11,CVBS_BASE1_ADDR);               // cvbs_addr_2(3)
    isp_write(ISP_CVBSFRC_BASE+0x12,CVBS_BASE1_ADDR >> 8);          // cvbs_addr_2(2)
    isp_write(ISP_CVBSFRC_BASE+0x13,CVBS_BASE1_ADDR >> 16);         // cvbs_addr_2(1)
    isp_write(ISP_CVBSFRC_BASE+0x14,CVBS_BASE1_ADDR >> 24);         // cvbs_addr_2(0)

    isp_write(ISP_CVBSFRC_BASE+0x15,0x07);                          // W_BURST_CTRL_CVBS_FRC[3:0]
    isp_write(ISP_CVBSFRC_BASE+0x16,0x07);                          // R_BURST_CTRL_CVBS_FRC[3:0]

    out_vact_crop_pos = (FRC_VACT - out_vact_size) >> 1;
    out_hact_crop_pos = (FRC_HACT - out_hact_size) >> 1;
    out_vact_crop_wline = out_vact_size * 2;

    isp_write(ISP_CVBSFRC_BASE+0x1B,out_vact_size);                 //       I_CVBS_VCROP_SIZE[ 7:0]
    isp_write(ISP_CVBSFRC_BASE+0x1C,out_vact_size >> 8);            // 5'h0, I_CVBS_VCROP_SIZE[10:8]
    isp_write(ISP_CVBSFRC_BASE+0x1D,out_vact_crop_pos);             //       I_CVBS_VCROP_POS [ 7:0]
    isp_write(ISP_CVBSFRC_BASE+0x1E,out_vact_crop_pos >> 8);        // 5'h0, I_CVBS_VCROP_POS [10:8]
    isp_write(ISP_CVBSFRC_BASE+0x1F,out_hact_size);                 //       I_CVBS_HCROP_SIZE[ 7:0]
    isp_write(ISP_CVBSFRC_BASE+0x20,out_hact_size >> 8);            // 5'h0, I_CVBS_HCROP_SIZE[10:8]
    isp_write(ISP_CVBSFRC_BASE+0x21,out_hact_crop_pos);             //       I_CVBS_HCROP_POS [ 7:0]
    isp_write(ISP_CVBSFRC_BASE+0x22,out_hact_crop_pos >> 8);        // 5'h0, I_CVBS_HCROP_POS [10:8]
    isp_write(ISP_CVBSFRC_BASE+0x23,out_vact_crop_wline);           //       I_CVBS_WLINE_SIZE[ 7:0]
    isp_write(ISP_CVBSFRC_BASE+0x24,out_vact_crop_wline >> 8);      // 4'h0, I_CVBS_WLINE_SIZE[11:8]

    ////////////////////////////////////////////////////////////////////////
    // CVBS HPF
    ////////////////////////////////////////////////////////////////////////
//  isp_write(ISP_CVBSHPF_BASE+0x00,0x00);                          // {3'd0, O_CVBS_HPF_MODE, 3'd0, O_CVBS_HPF_EN};
//  isp_write(ISP_CVBSHPF_BASE+0x01,0x00);                          // {2'd0, O_CVBS_HPF_CROP};
//  isp_write(ISP_CVBSHPF_BASE+0x02,0x00);                          // O_CVBS_HPF_PGAIN;   // 4.4 format
//  isp_write(ISP_CVBSHPF_BASE+0x03,0x00);                          // O_CVBS_HPF_MGAIN;   // 4.4 format
//  isp_write(ISP_CVBSHPF_BASE+0x04,0x00);                          // O_CVBS_HPF_PLIM;
//  isp_write(ISP_CVBSHPF_BASE+0x05,0x00);                          // O_CVBS_HPF_MLIM;

    ////////////////////////////////////////////////////////////////////////
    // Video Encoder
    ////////////////////////////////////////////////////////////////////////
    isp_write(ISP_CVBSVE_BASE+0x00,0x1F);                           // {1'd0, O_ENC_CROMA_MODE, O_ENC_CSWAP, O_ENC_GAIN_Y_EN, O_ENC_GAIN_CB_EN, O_ENC_GAIN_CR_EN, O_ENC_CLIP_Y_EN, O_ENC_CLIP_C_EN};
    isp_write(ISP_CVBSVE_BASE+0x01,0x4C);                           // O_ENC_GAIN_Y;
    isp_write(ISP_CVBSVE_BASE+0x02,0x41);                           // O_ENC_GAIN_CB;
    isp_write(ISP_CVBSVE_BASE+0x03,0x5B);                           // O_ENC_GAIN_CR;

#if(CVBS_MODE_SEL & CVBS_MODE_BYPASS)
#elif(CVBS_MODE_SEL & CVBS_MODE_1920H)
    #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
    // CVBS_1920x576I_PAL
    isp_write(ISP_CVBSVE_BASE+0x08,0xFA);               // {O_IN_DATA_BOUNDARY, O_LPF_CB_EN, O_LPF_CR_EN, O_PAL, O_H_MODE, O_ENC_COMET};
//  isp_write(ISP_CVBSVE_BASE+0x09,0x00);               // O_LPF_C_COEF0[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0B,0x00);               // O_LPF_C_COEF1[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0D,0x00);               // O_LPF_C_COEF2[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0F,0x00);               // O_LPF_C_COEF3[7:0];
    isp_write(ISP_CVBSVE_BASE+0x11,0x50);               // O_LPF_C_COEF4[7:0];
    isp_write(ISP_CVBSVE_BASE+0x13,0x43);               // O_LPF_C_COEF5[7:0];
    isp_write(ISP_CVBSVE_BASE+0x15,0x57);               // O_LPF_C_COEF6[7:0];
    isp_write(ISP_CVBSVE_BASE+0x17,0x68);               // O_LPF_C_COEF7[7:0];
    isp_write(ISP_CVBSVE_BASE+0x19,0x73);               // O_LPF_C_COEF8[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1B,0x76);               // O_LPF_C_COEF9[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1C,0x00);               // O_LPF_C_COEF9[9:8];
    isp_write(ISP_CVBSVE_BASE+0x20,0x80);               // {O_ENC_BSYNC_LPF_EN, O_ENC_BSYNC_USER_EN, O_ENC_BSYNC_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x21,0x80);               // {O_ENC_ACT_LPF_EN, O_ENC_ACT_USER_EN, O_ENC_ACT_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x22,0x80);               // {O_ENC_BFU_LPF_EN, O_ENC_BFU_USER_EN, O_ENC_BFU_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x23,0x80);               // {O_ENC_BFV_LPF_EN, O_ENC_BFV_USER_EN, O_ENC_BFV_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x24,0x31);               // {O_ENC_BURST_RST_MODE, O_ENC_BURST_DLY};
    isp_write(ISP_CVBSVE_BASE+0x27,0x4F);               // O_ENC_HS_SIZE;
    isp_write(ISP_CVBSVE_BASE+0x2E,0x8B);               // O_ENC_U_BURST[7:0];
    isp_write(ISP_CVBSVE_BASE+0x32,0x76);               // O_ENC_SYNC;
        #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
    isp_write(ISP_CVBSVE_BASE+0x33,0xA0);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #else
    isp_write(ISP_CVBSVE_BASE+0x33,0x20);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #endif
    isp_write(ISP_CVBSVE_BASE+0x34,0xAA);               // O_DIS_BLACK_CRT;
    isp_write(ISP_CVBSVE_BASE+0x35,0x80);               // O_DIS_BLACK_LCD;
    #else   //elif(CVBS_MODE_SEL & CVBS_MODE_NTSC)
    isp_write(ISP_CVBSVE_BASE+0x08,0xEA);               // {O_IN_DATA_BOUNDARY, O_LPF_CB_EN, O_LPF_CR_EN, O_PAL, O_H_MODE, O_ENC_COMET};
//  isp_write(ISP_CVBSVE_BASE+0x09,0x00);               // O_LPF_C_COEF0[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0B,0x00);               // O_LPF_C_COEF1[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0D,0x00);               // O_LPF_C_COEF2[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0F,0x00);               // O_LPF_C_COEF3[7:0];
    isp_write(ISP_CVBSVE_BASE+0x11,0x45);               // O_LPF_C_COEF4[7:0];
    isp_write(ISP_CVBSVE_BASE+0x13,0x42);               // O_LPF_C_COEF5[7:0];
    isp_write(ISP_CVBSVE_BASE+0x15,0x58);               // O_LPF_C_COEF6[7:0];
    isp_write(ISP_CVBSVE_BASE+0x17,0x6B);               // O_LPF_C_COEF7[7:0];
    isp_write(ISP_CVBSVE_BASE+0x19,0x78);               // O_LPF_C_COEF8[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1B,0x7C);               // O_LPF_C_COEF9[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1C,0x00);               // O_LPF_C_COEF9[9:8];
    isp_write(ISP_CVBSVE_BASE+0x20,0x80);               // {O_ENC_BSYNC_LPF_EN, O_ENC_BSYNC_USER_EN, O_ENC_BSYNC_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x21,0x80);               // {O_ENC_ACT_LPF_EN, O_ENC_ACT_USER_EN, O_ENC_ACT_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x22,0x80);               // {O_ENC_BFU_LPF_EN, O_ENC_BFU_USER_EN, O_ENC_BFU_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x23,0x80);               // {O_ENC_BFV_LPF_EN, O_ENC_BFV_USER_EN, O_ENC_BFV_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x24,0x16);               // {O_ENC_BURST_RST_MODE, O_ENC_BURST_DLY};
    isp_write(ISP_CVBSVE_BASE+0x27,0x36);               // O_ENC_HS_SIZE;
    isp_write(ISP_CVBSVE_BASE+0x2E,0x90);               // O_ENC_U_BURST[7:0];
    isp_write(ISP_CVBSVE_BASE+0x32,0x70);               // O_ENC_SYNC;
        #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
    isp_write(ISP_CVBSVE_BASE+0x33,0x80);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #else
    isp_write(ISP_CVBSVE_BASE+0x33,0x00);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #endif
    isp_write(ISP_CVBSVE_BASE+0x34,0xAA);               // O_DIS_BLACK_CRT;
    isp_write(ISP_CVBSVE_BASE+0x35,0x80);               // O_DIS_BLACK_LCD;
    #endif
#elif(CVBS_MODE_SEL & CVBS_MODE_1440H)
    #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
    // CVBS_1440x576I_PAL
    isp_write(ISP_CVBSVE_BASE+0x08,0xF8);               // {O_IN_DATA_BOUNDARY, O_LPF_CB_EN, O_LPF_CR_EN, O_PAL, O_H_MODE, O_ENC_COMET};
//  isp_write(ISP_CVBSVE_BASE+0x09,0x00);               // O_LPF_C_COEF0[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0B,0x00);               // O_LPF_C_COEF1[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0D,0x00);               // O_LPF_C_COEF2[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0F,0x00);               // O_LPF_C_COEF3[7:0];
    isp_write(ISP_CVBSVE_BASE+0x11,0x50);               // O_LPF_C_COEF4[7:0];
    isp_write(ISP_CVBSVE_BASE+0x13,0x43);               // O_LPF_C_COEF5[7:0];
    isp_write(ISP_CVBSVE_BASE+0x15,0x57);               // O_LPF_C_COEF6[7:0];
    isp_write(ISP_CVBSVE_BASE+0x17,0x68);               // O_LPF_C_COEF7[7:0];
    isp_write(ISP_CVBSVE_BASE+0x19,0x73);               // O_LPF_C_COEF8[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1B,0x76);               // O_LPF_C_COEF9[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1C,0x00);               // O_LPF_C_COEF9[9:8];
    isp_write(ISP_CVBSVE_BASE+0x20,0x80);               // {O_ENC_BSYNC_LPF_EN, O_ENC_BSYNC_USER_EN, O_ENC_BSYNC_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x21,0x80);               // {O_ENC_ACT_LPF_EN, O_ENC_ACT_USER_EN, O_ENC_ACT_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x22,0x80);               // {O_ENC_BFU_LPF_EN, O_ENC_BFU_USER_EN, O_ENC_BFU_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x23,0x80);               // {O_ENC_BFV_LPF_EN, O_ENC_BFV_USER_EN, O_ENC_BFV_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x24,0x25);               // {O_ENC_BURST_RST_MODE, O_ENC_BURST_DLY};
    isp_write(ISP_CVBSVE_BASE+0x27,0x3B);               // O_ENC_HS_SIZE;
    isp_write(ISP_CVBSVE_BASE+0x2E,0x8B);               // O_ENC_U_BURST[7:0];
    isp_write(ISP_CVBSVE_BASE+0x32,0x76);               // O_ENC_SYNC;
        #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
    isp_write(ISP_CVBSVE_BASE+0x33,0xA0);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #else
    isp_write(ISP_CVBSVE_BASE+0x33,0x20);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #endif
    isp_write(ISP_CVBSVE_BASE+0x34,0xAA);               // O_DIS_BLACK_CRT;
    isp_write(ISP_CVBSVE_BASE+0x35,0x80);               // O_DIS_BLACK_LCD;
    #else   //elif(CVBS_MODE_SEL & CVBS_MODE_NTSC)
    isp_write(ISP_CVBSVE_BASE+0x08,0xE8);               // {O_IN_DATA_BOUNDARY, O_LPF_CB_EN, O_LPF_CR_EN, O_PAL, O_H_MODE, O_ENC_COMET};
//  isp_write(ISP_CVBSVE_BASE+0x09,0x00);               // O_LPF_C_COEF0[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0B,0x00);               // O_LPF_C_COEF1[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0D,0x00);               // O_LPF_C_COEF2[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0F,0x00);               // O_LPF_C_COEF3[7:0];
    isp_write(ISP_CVBSVE_BASE+0x11,0x45);               // O_LPF_C_COEF4[7:0];
    isp_write(ISP_CVBSVE_BASE+0x13,0x42);               // O_LPF_C_COEF5[7:0];
    isp_write(ISP_CVBSVE_BASE+0x15,0x58);               // O_LPF_C_COEF6[7:0];
    isp_write(ISP_CVBSVE_BASE+0x17,0x6B);               // O_LPF_C_COEF7[7:0];
    isp_write(ISP_CVBSVE_BASE+0x19,0x78);               // O_LPF_C_COEF8[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1B,0x7C);               // O_LPF_C_COEF9[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1C,0x00);               // O_LPF_C_COEF9[9:8];
    isp_write(ISP_CVBSVE_BASE+0x20,0x80);               // {O_ENC_BSYNC_LPF_EN, O_ENC_BSYNC_USER_EN, O_ENC_BSYNC_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x21,0x80);               // {O_ENC_ACT_LPF_EN, O_ENC_ACT_USER_EN, O_ENC_ACT_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x22,0x80);               // {O_ENC_BFU_LPF_EN, O_ENC_BFU_USER_EN, O_ENC_BFU_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x23,0x80);               // {O_ENC_BFV_LPF_EN, O_ENC_BFV_USER_EN, O_ENC_BFV_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x24,0x10);               // {O_ENC_BURST_RST_MODE, O_ENC_BURST_DLY};
    isp_write(ISP_CVBSVE_BASE+0x27,0x29);               // O_ENC_HS_SIZE;
    isp_write(ISP_CVBSVE_BASE+0x2E,0x90);               // O_ENC_U_BURST[7:0];
    isp_write(ISP_CVBSVE_BASE+0x32,0x70);               // O_ENC_SYNC;
        #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
    isp_write(ISP_CVBSVE_BASE+0x33,0x80);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #else
    isp_write(ISP_CVBSVE_BASE+0x33,0x00);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #endif
    isp_write(ISP_CVBSVE_BASE+0x34,0xAA);               // O_DIS_BLACK_CRT;
    isp_write(ISP_CVBSVE_BASE+0x35,0x80);               // O_DIS_BLACK_LCD;
    #endif
#elif(CVBS_MODE_SEL & CVBS_MODE_1280H)
    #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
    // CVBS_1280x576I_PAL
    isp_write(ISP_CVBSVE_BASE+0x08,0xF6);               // {O_IN_DATA_BOUNDARY, O_LPF_CB_EN, O_LPF_CR_EN, O_PAL, O_H_MODE, O_ENC_COMET};
//  isp_write(ISP_CVBSVE_BASE+0x09,0x00);               // O_LPF_C_COEF0[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0B,0x00);               // O_LPF_C_COEF1[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0D,0x00);               // O_LPF_C_COEF2[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0F,0x00);               // O_LPF_C_COEF3[7:0];
    isp_write(ISP_CVBSVE_BASE+0x11,0x50);               // O_LPF_C_COEF4[7:0];
    isp_write(ISP_CVBSVE_BASE+0x13,0x43);               // O_LPF_C_COEF5[7:0];
    isp_write(ISP_CVBSVE_BASE+0x15,0x57);               // O_LPF_C_COEF6[7:0];
    isp_write(ISP_CVBSVE_BASE+0x17,0x68);               // O_LPF_C_COEF7[7:0];
    isp_write(ISP_CVBSVE_BASE+0x19,0x73);               // O_LPF_C_COEF8[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1B,0x76);               // O_LPF_C_COEF9[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1C,0x00);               // O_LPF_C_COEF9[9:8];
    isp_write(ISP_CVBSVE_BASE+0x20,0x80);               // {O_ENC_BSYNC_LPF_EN, O_ENC_BSYNC_USER_EN, O_ENC_BSYNC_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x21,0x80);               // {O_ENC_ACT_LPF_EN, O_ENC_ACT_USER_EN, O_ENC_ACT_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x22,0x80);               // {O_ENC_BFU_LPF_EN, O_ENC_BFU_USER_EN, O_ENC_BFU_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x23,0x80);               // {O_ENC_BFV_LPF_EN, O_ENC_BFV_USER_EN, O_ENC_BFV_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x24,0x21);               // {O_ENC_BURST_RST_MODE, O_ENC_BURST_DLY};
    isp_write(ISP_CVBSVE_BASE+0x27,0x35);               // O_ENC_HS_SIZE;
    isp_write(ISP_CVBSVE_BASE+0x2E,0x8B);               // O_ENC_U_BURST[7:0];
    isp_write(ISP_CVBSVE_BASE+0x32,0x76);               // O_ENC_SYNC;
        #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
    isp_write(ISP_CVBSVE_BASE+0xDB33,0xA0);             // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #else
    isp_write(ISP_CVBSVE_BASE+0xDB33,0x20);             // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #endif
    isp_write(ISP_CVBSVE_BASE+0xDB34,0xAA);             // O_DIS_BLACK_CRT;
    isp_write(ISP_CVBSVE_BASE+0xDB35,0x80);             // O_DIS_BLACK_LCD;
    #else   //elif(CVBS_MODE_SEL & CVBS_MODE_NTSC)
    // Don't Soupport
    #endif
#elif(CVBS_MODE_SEL & CVBS_MODE_1200H)
    #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
    // CVBS_1200x576I_PAL
    isp_write(ISP_CVBSVE_BASE+0x08,0xF4);               // {O_IN_DATA_BOUNDARY, O_LPF_CB_EN, O_LPF_CR_EN, O_PAL, O_H_MODE, O_ENC_COMET};
//  isp_write(ISP_CVBSVE_BASE+0x09,0x00);               // O_LPF_C_COEF0[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0B,0x00);               // O_LPF_C_COEF1[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0D,0x00);               // O_LPF_C_COEF2[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0F,0x00);               // O_LPF_C_COEF3[7:0];
    isp_write(ISP_CVBSVE_BASE+0x11,0x45);               // O_LPF_C_COEF4[7:0];
    isp_write(ISP_CVBSVE_BASE+0x13,0x42);               // O_LPF_C_COEF5[7:0];
    isp_write(ISP_CVBSVE_BASE+0x15,0x58);               // O_LPF_C_COEF6[7:0];
    isp_write(ISP_CVBSVE_BASE+0x17,0x6B);               // O_LPF_C_COEF7[7:0];
    isp_write(ISP_CVBSVE_BASE+0x19,0x78);               // O_LPF_C_COEF8[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1B,0x7C);               // O_LPF_C_COEF9[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1C,0x00);               // O_LPF_C_COEF9[9:8];
    isp_write(ISP_CVBSVE_BASE+0x20,0x80);               // {O_ENC_BSYNC_LPF_EN, O_ENC_BSYNC_USER_EN, O_ENC_BSYNC_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x21,0x80);               // {O_ENC_ACT_LPF_EN, O_ENC_ACT_USER_EN, O_ENC_ACT_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x22,0x80);               // {O_ENC_BFU_LPF_EN, O_ENC_BFU_USER_EN, O_ENC_BFU_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x23,0x80);               // {O_ENC_BFV_LPF_EN, O_ENC_BFV_USER_EN, O_ENC_BFV_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x24,0x1F);               // {O_ENC_BURST_RST_MODE, O_ENC_BURST_DLY};
    isp_write(ISP_CVBSVE_BASE+0x27,0x35);               // O_ENC_HS_SIZE;
    isp_write(ISP_CVBSVE_BASE+0x2E,0x8B);               // O_ENC_U_BURST[7:0];
    isp_write(ISP_CVBSVE_BASE+0x32,0x76);               // O_ENC_SYNC;
        #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
    isp_write(ISP_CVBSVE_BASE+0x33,0xA0);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #else
    isp_write(ISP_CVBSVE_BASE+0x33,0x20);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #endif
    isp_write(ISP_CVBSVE_BASE+0x34,0xAA);               // O_DIS_BLACK_CRT;
    isp_write(ISP_CVBSVE_BASE+0x35,0x80);               // O_DIS_BLACK_LCD;
    #else   //elif(CVBS_MODE_SEL & CVBS_MODE_NTSC)
    isp_write(ISP_CVBSVE_BASE+0x08,0xE4);               // {O_IN_DATA_BOUNDARY, O_LPF_CB_EN, O_LPF_CR_EN, O_PAL, O_H_MODE, O_ENC_COMET};
//  isp_write(ISP_CVBSVE_BASE+0x09,0x00);               // O_LPF_C_COEF0[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0B,0x00);               // O_LPF_C_COEF1[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0D,0x00);               // O_LPF_C_COEF2[7:0];
    isp_write(ISP_CVBSVE_BASE+0x0F,0x47);               // O_LPF_C_COEF3[7:0];
    isp_write(ISP_CVBSVE_BASE+0x11,0x35);               // O_LPF_C_COEF4[7:0];
    isp_write(ISP_CVBSVE_BASE+0x13,0x43);               // O_LPF_C_COEF5[7:0];
    isp_write(ISP_CVBSVE_BASE+0x15,0x51);               // O_LPF_C_COEF6[7:0];
    isp_write(ISP_CVBSVE_BASE+0x17,0x5B);               // O_LPF_C_COEF7[7:0];
    isp_write(ISP_CVBSVE_BASE+0x19,0x62);               // O_LPF_C_COEF8[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1B,0x66);               // O_LPF_C_COEF9[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1C,0x00);               // O_LPF_C_COEF9[9:8];
    isp_write(ISP_CVBSVE_BASE+0x20,0x80);               // {O_ENC_BSYNC_LPF_EN, O_ENC_BSYNC_USER_EN, O_ENC_BSYNC_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x21,0x80);               // {O_ENC_ACT_LPF_EN, O_ENC_ACT_USER_EN, O_ENC_ACT_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x22,0x80);               // {O_ENC_BFU_LPF_EN, O_ENC_BFU_USER_EN, O_ENC_BFU_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x23,0x80);               // {O_ENC_BFV_LPF_EN, O_ENC_BFV_USER_EN, O_ENC_BFV_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x24,0x0E);               // {O_ENC_BURST_RST_MODE, O_ENC_BURST_DLY};
    isp_write(ISP_CVBSVE_BASE+0x27,0x22);               // O_ENC_HS_SIZE;
    isp_write(ISP_CVBSVE_BASE+0x2E,0x90);               // O_ENC_U_BURST[7:0];
    isp_write(ISP_CVBSVE_BASE+0x32,0x70);               // O_ENC_SYNC;
        #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
    isp_write(ISP_CVBSVE_BASE+0x33,0x80);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #else
    isp_write(ISP_CVBSVE_BASE+0x33,0x00);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #endif
    isp_write(ISP_CVBSVE_BASE+0x34,0xAA);               // O_DIS_BLACK_CRT;
    isp_write(ISP_CVBSVE_BASE+0x35,0x80);               // O_DIS_BLACK_LCD;
    #endif
#elif(CVBS_MODE_SEL & CVBS_MODE_960H)
    #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
    // CVBS_1200x576I_PAL
    isp_write(ISP_CVBSVE_BASE+0x08,0xF2);               // {O_IN_DATA_BOUNDARY, O_LPF_CB_EN, O_LPF_CR_EN, O_PAL, O_H_MODE, O_ENC_COMET};
//  isp_write(ISP_CVBSVE_BASE+0x09,0x00);               // O_LPF_C_COEF0[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0B,0x00);               // O_LPF_C_COEF1[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0D,0x00);               // O_LPF_C_COEF2[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0F,0x00);               // O_LPF_C_COEF3[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x11,0x00);               // O_LPF_C_COEF4[7:0];
    isp_write(ISP_CVBSVE_BASE+0x13,0x4D);               // O_LPF_C_COEF5[7:0];
    isp_write(ISP_CVBSVE_BASE+0x15,0x5A);               // O_LPF_C_COEF6[7:0];
    isp_write(ISP_CVBSVE_BASE+0x17,0x7A);               // O_LPF_C_COEF7[7:0];
    isp_write(ISP_CVBSVE_BASE+0x19,0x92);               // O_LPF_C_COEF8[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1B,0x9A);               // O_LPF_C_COEF9[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1C,0x00);               // O_LPF_C_COEF9[9:8];
    isp_write(ISP_CVBSVE_BASE+0x20,0x80);               // {O_ENC_BSYNC_LPF_EN, O_ENC_BSYNC_USER_EN, O_ENC_BSYNC_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x21,0x80);               // {O_ENC_ACT_LPF_EN, O_ENC_ACT_USER_EN, O_ENC_ACT_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x22,0x80);               // {O_ENC_BFU_LPF_EN, O_ENC_BFU_USER_EN, O_ENC_BFU_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x23,0x80);               // {O_ENC_BFV_LPF_EN, O_ENC_BFV_USER_EN, O_ENC_BFV_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x24,0x18);               // {O_ENC_BURST_RST_MODE, O_ENC_BURST_DLY};
    isp_write(ISP_CVBSVE_BASE+0x27,0x27);               // O_ENC_HS_SIZE;
    isp_write(ISP_CVBSVE_BASE+0x2E,0x8B);               // O_ENC_U_BURST[7:0];
    isp_write(ISP_CVBSVE_BASE+0x32,0x76);               // O_ENC_SYNC;
        #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
    isp_write(ISP_CVBSVE_BASE+0x33,0xA0);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #else
    isp_write(ISP_CVBSVE_BASE+0x33,0x20);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #endif
    isp_write(ISP_CVBSVE_BASE+0x34,0xAA);               // O_DIS_BLACK_CRT;
    isp_write(ISP_CVBSVE_BASE+0x35,0x80);               // O_DIS_BLACK_LCD;
    #else   //elif(CVBS_MODE_SEL & CVBS_MODE_NTSC)
    isp_write(ISP_CVBSVE_BASE+0x08,0xE2);               // {O_IN_DATA_BOUNDARY, O_LPF_CB_EN, O_LPF_CR_EN, O_PAL, O_H_MODE, O_ENC_COMET};
//  isp_write(ISP_CVBSVE_BASE+0x09,0x00);               // O_LPF_C_COEF0[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0B,0x00);               // O_LPF_C_COEF1[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0D,0x00);               // O_LPF_C_COEF2[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0F,0x00);               // O_LPF_C_COEF3[7:0];
    isp_write(ISP_CVBSVE_BASE+0x11,0x42);               // O_LPF_C_COEF4[7:0];
    isp_write(ISP_CVBSVE_BASE+0x13,0x48);               // O_LPF_C_COEF5[7:0];
    isp_write(ISP_CVBSVE_BASE+0x15,0x53);               // O_LPF_C_COEF6[7:0];
    isp_write(ISP_CVBSVE_BASE+0x17,0x70);               // O_LPF_C_COEF7[7:0];
    isp_write(ISP_CVBSVE_BASE+0x19,0x73);               // O_LPF_C_COEF8[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1B,0x80);               // O_LPF_C_COEF9[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1C,0x00);               // O_LPF_C_COEF9[9:8];
    isp_write(ISP_CVBSVE_BASE+0x20,0x80);               // {O_ENC_BSYNC_LPF_EN, O_ENC_BSYNC_USER_EN, O_ENC_BSYNC_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x21,0x80);               // {O_ENC_ACT_LPF_EN, O_ENC_ACT_USER_EN, O_ENC_ACT_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x22,0x80);               // {O_ENC_BFU_LPF_EN, O_ENC_BFU_USER_EN, O_ENC_BFU_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x23,0x80);               // {O_ENC_BFV_LPF_EN, O_ENC_BFV_USER_EN, O_ENC_BFV_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x24,0x0B);               // {O_ENC_BURST_RST_MODE, O_ENC_BURST_DLY};
    isp_write(ISP_CVBSVE_BASE+0x27,0x1B);               // O_ENC_HS_SIZE;
    isp_write(ISP_CVBSVE_BASE+0x2E,0x90);               // O_ENC_U_BURST[7:0];
    isp_write(ISP_CVBSVE_BASE+0x32,0x70);               // O_ENC_SYNC;
        #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
    isp_write(ISP_CVBSVE_BASE+0x33,0x80);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #else
    isp_write(ISP_CVBSVE_BASE+0x33,0x00);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #endif
    isp_write(ISP_CVBSVE_BASE+0x34,0xAA);               // O_DIS_BLACK_CRT;
    isp_write(ISP_CVBSVE_BASE+0x35,0x80);               // O_DIS_BLACK_LCD;
    #endif
#elif(CVBS_MODE_SEL & CVBS_MODE_720H)
    #if(CVBS_MODE_SEL & CVBS_MODE_PAL)
    // CVBS_1200x576I_PAL
    isp_write(ISP_CVBSVE_BASE+0x08,0xF0);               // {O_IN_DATA_BOUNDARY, O_LPF_CB_EN, O_LPF_CR_EN, O_PAL, O_H_MODE, O_ENC_COMET};
//  isp_write(ISP_CVBSVE_BASE+0x09,0x00);               // O_LPF_C_COEF0[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0B,0x00);               // O_LPF_C_COEF1[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0D,0x00);               // O_LPF_C_COEF2[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0F,0x00);               // O_LPF_C_COEF3[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x11,0x00);               // O_LPF_C_COEF4[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x13,0x00);               // O_LPF_C_COEF5[7:0];
    isp_write(ISP_CVBSVE_BASE+0x15,0x5A);               // O_LPF_C_COEF6[7:0];
    isp_write(ISP_CVBSVE_BASE+0x17,0x87);               // O_LPF_C_COEF7[7:0];
    isp_write(ISP_CVBSVE_BASE+0x19,0xB9);               // O_LPF_C_COEF8[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1B,0xCC);               // O_LPF_C_COEF9[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1C,0x00);               // O_LPF_C_COEF9[9:8];
    isp_write(ISP_CVBSVE_BASE+0x20,0x80);               // {O_ENC_BSYNC_LPF_EN, O_ENC_BSYNC_USER_EN, O_ENC_BSYNC_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x21,0x80);               // {O_ENC_ACT_LPF_EN, O_ENC_ACT_USER_EN, O_ENC_ACT_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x22,0x80);               // {O_ENC_BFU_LPF_EN, O_ENC_BFU_USER_EN, O_ENC_BFU_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x23,0x80);               // {O_ENC_BFV_LPF_EN, O_ENC_BFV_USER_EN, O_ENC_BFV_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x24,0x12);               // {O_ENC_BURST_RST_MODE, O_ENC_BURST_DLY};
    isp_write(ISP_CVBSVE_BASE+0x27,0x1D);               // O_ENC_HS_SIZE;
    isp_write(ISP_CVBSVE_BASE+0x2E,0x8B);               // O_ENC_U_BURST[7:0];
    isp_write(ISP_CVBSVE_BASE+0x32,0x76);               // O_ENC_SYNC;
        #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
    isp_write(ISP_CVBSVE_BASE+0x33,0xA0);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #else
    isp_write(ISP_CVBSVE_BASE+0x33,0x20);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #endif
    isp_write(ISP_CVBSVE_BASE+0x34,0xAA);               // O_DIS_BLACK_CRT;
    isp_write(ISP_CVBSVE_BASE+0x35,0x80);               // O_DIS_BLACK_LCD;
    #else   //elif(CVBS_MODE_SEL & CVBS_MODE_NTSC)
    isp_write(ISP_CVBSVE_BASE+0x08,0xE0);               // {O_IN_DATA_BOUNDARY, O_LPF_CB_EN, O_LPF_CR_EN, O_PAL, O_H_MODE, O_ENC_COMET};
//  isp_write(ISP_CVBSVE_BASE+0x09,0x00);               // O_LPF_C_COEF0[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0B,0x00);               // O_LPF_C_COEF1[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0D,0x00);               // O_LPF_C_COEF2[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x0F,0x00);               // O_LPF_C_COEF3[7:0];
//  isp_write(ISP_CVBSVE_BASE+0x11,0x00);               // O_LPF_C_COEF4[7:0];
    isp_write(ISP_CVBSVE_BASE+0x13,0x43);               // O_LPF_C_COEF5[7:0];
    isp_write(ISP_CVBSVE_BASE+0x15,0x58);               // O_LPF_C_COEF6[7:0];
    isp_write(ISP_CVBSVE_BASE+0x17,0x7D);               // O_LPF_C_COEF7[7:0];
    isp_write(ISP_CVBSVE_BASE+0x19,0x98);               // O_LPF_C_COEF8[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1B,0xA0);               // O_LPF_C_COEF9[7:0];
    isp_write(ISP_CVBSVE_BASE+0x1C,0x00);               // O_LPF_C_COEF9[9:8];
    isp_write(ISP_CVBSVE_BASE+0x20,0x80);               // {O_ENC_BSYNC_LPF_EN, O_ENC_BSYNC_USER_EN, O_ENC_BSYNC_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x21,0x80);               // {O_ENC_ACT_LPF_EN, O_ENC_ACT_USER_EN, O_ENC_ACT_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x22,0x80);               // {O_ENC_BFU_LPF_EN, O_ENC_BFU_USER_EN, O_ENC_BFU_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x23,0x80);               // {O_ENC_BFV_LPF_EN, O_ENC_BFV_USER_EN, O_ENC_BFV_USER_INC}
    isp_write(ISP_CVBSVE_BASE+0x24,0x08);               // {O_ENC_BURST_RST_MODE, O_ENC_BURST_DLY};
    isp_write(ISP_CVBSVE_BASE+0x27,0x14);               // O_ENC_HS_SIZE;
    isp_write(ISP_CVBSVE_BASE+0x2E,0x90);               // O_ENC_U_BURST[7:0];
    isp_write(ISP_CVBSVE_BASE+0x32,0x70);               // O_ENC_SYNC;
        #if(CVBS_MODE_SEL & CVBS_MODE_QUAD)
    isp_write(ISP_CVBSVE_BASE+0x33,0x80);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #else
    isp_write(ISP_CVBSVE_BASE+0x33,0x00);               // {O_SAMPLING_MODE, O_DIS_BLACK_SEL, O_FSC_RST_NT, O_PN_USER_VALUE_EN, O_PN_USER_INTNUM_EN, O_SEL_ENC_OUT}
        #endif
    isp_write(ISP_CVBSVE_BASE+0x34,0xAA);               // O_DIS_BLACK_CRT;
    isp_write(ISP_CVBSVE_BASE+0x35,0x80);               // O_DIS_BLACK_LCD;
    #endif
#endif

#if(CVBS_MODE_SEL & CVBS_MODE_BYPASS)
#elif(CVBS_MODE_SEL & CVBS_MODE_COMET)
    isp_write(ISP_CVBSVE_BASE+0x08,(0x01 | isp_read(ISP_CVBSVE_BASE+0x08)));    // {O_IN_DATA_BOUNDARY, O_LPF_CB_EN, O_LPF_CR_EN, O_PAL, O_H_MODE, O_ENC_COMET};
#else
    isp_write(ISP_CVBSVE_BASE+0x08,(0xFE & isp_read(ISP_CVBSVE_BASE+0x08)));
#endif
}
