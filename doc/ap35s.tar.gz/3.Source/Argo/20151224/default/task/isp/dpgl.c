#include "dpgl_regmap.h"
#include "dpgl_pos.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"
#include "isp_common.h"

void DPGL_set(void)
{
    unsigned int data;
	tdk_printf("Drawing PGL set\n");
    data = DPGL_V_AUTO_UP | DPGL_H_POL | DPGL_ENABLE;
    reg_write(DPGL_ENABLE_ADDR,data);   // PGL_EN 

}

void DPGL_POS_set(int angle)
{
    int i;
    unsigned int data;
    unsigned int addr;

	tdk_printf("Drawing PGL set\n");
    //start blue line
    addr = DPGL_BASE_ADDR;
    data =  1<<31 | 0x255;
    reg_write(addr, data);
    delay(10);
    
    for(i=0; i<B_LINE_POINT; i++){
        addr = addr + 4;
        data =  0x003FFFFF & (WIDE_PGS_B_LINE[0][i][0] << 11 | WIDE_PGS_B_LINE[0][i][1]);
        reg_write(addr, data);
        delay(10);
    }
        
    addr = addr + 4;
    data =  1<<31 | 0x255 << 16;
    reg_write(addr, data);
    
    for(i=0; i<R_LINE_POINT; i++){
        addr = addr + 4;
        data =  0x003FFFFF & (WIDE_PGS_R_LINE[angle][i][0] << 11 | WIDE_PGS_R_LINE[angle][i][1]);
        reg_write(addr, data);
        delay(10);
    }
    
    addr = addr + 4;
    data =  1<<31 | 0x255 << 8;
    reg_write(addr, data);

    for(i=0; i<G_LINE_POINT; i++){
        addr = addr + 4;
        data =  0x003FFFFF & (WIDE_PGS_G_LINE[angle][i][0] << 11 | WIDE_PGS_G_LINE[angle][i][1]);
        reg_write(addr, data);
        delay(10);
    }
    
    addr = addr + 4;
    data =  1<<31 | 0x255 << 16 | 0x255 << 8;
    reg_write(addr, data);

    for(i=0; i<Y_LINE_POINT; i++){
        addr = addr + 4;
        data =  0x003FFFFF & (WIDE_PGS_Y_LINE[angle][i][0] << 11 | WIDE_PGS_Y_LINE[angle][i][1]);
        reg_write(addr, data);
        delay(10);
    }

}
