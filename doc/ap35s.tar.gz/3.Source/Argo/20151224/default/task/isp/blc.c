#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void BLC_set()
{
	tdk_printf("BLC set\n");
//  isp_write(ISP_BLC_BASE+0x0F,0x00);  // BLC_H_OB_SYNC_WIDTH[11:8]
//  isp_write(ISP_BLC_BASE+0x11,0x00);  // BLC_H_OB_SYNC_WIDTH[7:0]
//  isp_write(ISP_BLC_BASE+0x10,0x00);  // BLC_H_OB_SYNC_HEIGHT[7:0]
    isp_write(ISP_BLC_BASE+0x13,0x02);  // BLC_V_OB_SYNC_WIDTH[11:8]
    isp_write(ISP_BLC_BASE+0x12,0x80);  // BLC_V_OB_SYNC_WIDTH[7:0]
    isp_write(ISP_BLC_BASE+0x14,0x04);  // BLC_V_OB_SYNC_HEIGHT[7:0]

    isp_write(ISP_BLC_BASE+0x00,0x23);  // {1'b0, BLC_AGC, BLC_V_OB, BLC_H_OB, BLC_OFFSET_H_SWAP, BLC_OFFSET_V_SWAP, BLC_OFFSET_EN, BLC_EN}
    isp_write(ISP_BLC_BASE+0x01,0x03);  // BLC_PRE
    isp_write(ISP_BLC_BASE+0x02,0x02);  // BLC_MODE
//  isp_write(ISP_BLC_BASE+0x03,0x00);  // BLC_SIGN

//  isp_write(ISP_BLC_BASE+0x05,0x00);
    isp_write(ISP_BLC_BASE+0x04,0x01);  // BLC_GR_OFFSET_L

    isp_write(ISP_BLC_BASE+0x15,0x3F);  // {1'b0, BLC_OFFSET_OV_EN, BLC_DOL_DISABLE, BLC_RGB_DISABLE, BLC_M_EN, BLC_S_EN, BLC_OFFSET_M_EN, BLC_OFFSET_S_EN}
    isp_write(ISP_BLC_BASE+0x16,0x0A);  // {4'd0, BLC_V_OB_M, BLC_H_OB_M, BLC_V_OB_S, BLC_H_OB_S}

    isp_write(ISP_BLC_BASE+0x18,0x03);  // BLC_PRE_M
    isp_write(ISP_BLC_BASE+0x19,0x02);  // BLC_MODE_M
    isp_write(ISP_BLC_BASE+0x1A,0x03);  // BLC_PRE_S
    isp_write(ISP_BLC_BASE+0x1B,0x02);  // BLC_MODE_S
}

