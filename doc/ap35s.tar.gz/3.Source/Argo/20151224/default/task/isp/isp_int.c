#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void ISP_INT_set(void)
{
	tdk_printf("INP_INT set\n");
    isp_write(ISP_INT_BASE+0x00,0x10);  // isp1_int_set(1:md_end),  isp0_int_set(0:dpc_scan_end)
    isp_write(ISP_INT_BASE+0x01,0x32);  // isp3_int_set(3:vsi_pos), isp2_int_set(2:vsi_neg)
    isp_write(ISP_INT_BASE+0x02,0x54);  // isp5_int_set(5:vso_pos), isp4_int_set(4:vso_neg)
    isp_write(ISP_INT_BASE+0x03,0x76);  // isp7_int_set(7:ext_int0, isp6_int_set(6:af_int)
    isp_write(ISP_INT_BASE+0x04,0x08);  //                          isp8_int_set(8:ext_int1)
}

