#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"
void NR2D_set(void)
{
    isp_write(ISP_NR2D_BASE+0x80,0x81);  // {NR2DB_GAMMA_EN[7], 4'h0, NR2DB_SIZE[2], NR2DB_NO_PRESET[1], NR2DB_EN[0]
    isp_write(ISP_NR2D_BASE+0x81,0x04);  // NR2DB_STR[3:0]
//  isp_write(ISP_NR2D_BASE+0x82,0x00);  // NR2DB_SIGY00[6:0]
//  isp_write(ISP_NR2D_BASE+0x83,0x00);  // NR2DB_SIGY01[6:0]
//  isp_write(ISP_NR2D_BASE+0x84,0x00);  // NR2DB_SIGY02[6:0]
//  isp_write(ISP_NR2D_BASE+0x85,0x00);  // NR2DB_SIGY03[6:0]
//  isp_write(ISP_NR2D_BASE+0x86,0x00);  // NR2DB_SIGY04[6:0]
//  isp_write(ISP_NR2D_BASE+0x87,0x00);  // NR2DB_SIGY05[6:0]
//  isp_write(ISP_NR2D_BASE+0x88,0x00);  // NR2DB_SIGY06[6:0]
//  isp_write(ISP_NR2D_BASE+0x89,0x00);  // NR2DB_SIGY07[6:0]
//  isp_write(ISP_NR2D_BASE+0x8A,0x00);  // NR2DB_SIGY08[6:0]
//  isp_write(ISP_NR2D_BASE+0x8B,0x00);  // NR2DB_SIGY09[6:0]
//  isp_write(ISP_NR2D_BASE+0x8C,0x00);  // NR2DB_SIGY10[6:0]
}

