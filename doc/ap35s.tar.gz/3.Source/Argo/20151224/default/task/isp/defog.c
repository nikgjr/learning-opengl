#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void DEFOG_set (void)
{
	tdk_printf("DEFOG set\n");

//  isp_write(ISP_DEFOG_BASE+0x50,0x00);
    isp_write(ISP_DEFOG_BASE+0x4F,0x20);
    isp_write(ISP_DEFOG_BASE+0x4E,0xC0);
    isp_write(ISP_DEFOG_BASE+0x4D,0x20);
    isp_write(ISP_DEFOG_BASE+0x4C,0xC0);
    isp_write(ISP_DEFOG_BASE+0x4B,0x20);
    isp_write(ISP_DEFOG_BASE+0x4A,0xC0);
    isp_write(ISP_DEFOG_BASE+0x49,0x20);
    isp_write(ISP_DEFOG_BASE+0x48,0xC0);
//  isp_write(ISP_DEFOG_BASE+0x47,0x00);
//  isp_write(ISP_DEFOG_BASE+0x46,0x00);
//  isp_write(ISP_DEFOG_BASE+0x45,0x00);
//  isp_write(ISP_DEFOG_BASE+0x44,0x00);
//  isp_write(ISP_DEFOG_BASE+0x43,0x00);
//  isp_write(ISP_DEFOG_BASE+0x42,0x00);
//  isp_write(ISP_DEFOG_BASE+0x41,0x00);
//  isp_write(ISP_DEFOG_BASE+0x40,0x00);
//  isp_write(ISP_DEFOG_BASE+0x3F,0x00);
    isp_write(ISP_DEFOG_BASE+0x3E,0xFF);
//  isp_write(ISP_DEFOG_BASE+0x3D,0x00);
    isp_write(ISP_DEFOG_BASE+0x3C,0xFF);
//  isp_write(ISP_DEFOG_BASE+0x3B,0x00);
    isp_write(ISP_DEFOG_BASE+0x3A,0xFF);
//  isp_write(ISP_DEFOG_BASE+0x39,0x00);
    isp_write(ISP_DEFOG_BASE+0x38,0xFF);
//  isp_write(ISP_DEFOG_BASE+0x1E,0x00);
//  isp_write(ISP_DEFOG_BASE+0x1D,0x00);
//  isp_write(ISP_DEFOG_BASE+0x1C,0x00);
//  isp_write(ISP_DEFOG_BASE+0x1B,0x00);
//  isp_write(ISP_DEFOG_BASE+0x1A,0x00);
    isp_write(ISP_DEFOG_BASE+0x19,0xFF);
    isp_write(ISP_DEFOG_BASE+0x18,0x3F);
    isp_write(ISP_DEFOG_BASE+0x0F,0x04);
    isp_write(ISP_DEFOG_BASE+0x0E,0x0C);    // HLEN
//  isp_write(ISP_DEFOG_BASE+0x0D,0x00);
//  isp_write(ISP_DEFOG_BASE+0x0C,0x00);
    isp_write(ISP_DEFOG_BASE+0x0B,0x0F);
//  isp_write(ISP_DEFOG_BASE+0x0A,0x00);
    isp_write(ISP_DEFOG_BASE+0x09,0x01);    // 1: 1.5%
//  isp_write(ISP_DEFOG_BASE+0x06,0x00);
    isp_write(ISP_DEFOG_BASE+0x05,0x01);
    isp_write(ISP_DEFOG_BASE+0x04,0x03);
    isp_write(ISP_DEFOG_BASE+0x03,0x07);
    isp_write(ISP_DEFOG_BASE+0x02,0x07);
//  isp_write(ISP_DEFOG_BASE+0x01,0x00);
    isp_write(ISP_DEFOG_BASE+0x00,0x13);
}
