#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void PMASK_set(void)
{
	tdk_printf("PMASK set\n");

    isp_write(ISP_PM_BASE+0x00,0x01);   // {3'h0, I_BLNK_SEL, I_PM_BND_YC, I_PM_EN};
    isp_write(ISP_PM_BASE+0x01,0x00);   // {4'h0, I_PM_SEL_EN, 1'b0, I_PM_SEL};
    isp_write(ISP_PM_BASE+0x02,0xFF);   // {4'h0, I_PM_CH_EN};
    isp_write(ISP_PM_BASE+0x03,0x20);   // I_PM_Y_0;
    isp_write(ISP_PM_BASE+0x04,0x22);   // {I_PM_CB_0, I_PM_CR_0};
    isp_write(ISP_PM_BASE+0x05,0x00);   // {3'h0, I_PM_PR_0};
    isp_write(ISP_PM_BASE+0x07,0x00);   // {6'h0, I_PM_PX_00[9:8]};
    isp_write(ISP_PM_BASE+0x06,0x01);   // I_PM_PX_00[7:0];
    isp_write(ISP_PM_BASE+0x09,0x00);   // {6'h0, I_PM_PX_01[9:8]};
    isp_write(ISP_PM_BASE+0x08,0x06);   // I_PM_PX_01[7:0];
    isp_write(ISP_PM_BASE+0x0B,0x00);   // {6'h0, I_PM_PY_00[9:8]};
    isp_write(ISP_PM_BASE+0x0A,0x01);   // I_PM_PY_00[7:0];
    isp_write(ISP_PM_BASE+0x0D,0x00);   // {6'h0, I_PM_PY_01[9:8]};
    isp_write(ISP_PM_BASE+0x0C,0x06);   // I_PM_PY_01[7:0];
    isp_write(ISP_PM_BASE+0x0E,0x40);   // I_PM_Y_1;
    isp_write(ISP_PM_BASE+0x0F,0x44);   // {I_PM_CB_1, I_PM_CR_1};
    isp_write(ISP_PM_BASE+0x10,0x04);   // {3'h0, I_PM_PR_1};
    isp_write(ISP_PM_BASE+0x12,0x00);   // {6'h0, I_PM_PX_10[9:8]};
    isp_write(ISP_PM_BASE+0x11,0x09);   // I_PM_PX_10[7:0];
    isp_write(ISP_PM_BASE+0x14,0x00);   // {6'h0, I_PM_PX_11[9:8]};
    isp_write(ISP_PM_BASE+0x13,0x0E);   // I_PM_PX_11[7:0];
    isp_write(ISP_PM_BASE+0x16,0x00);   // {6'h0, I_PM_PY_10[9:8]};
    isp_write(ISP_PM_BASE+0x15,0x01);   // I_PM_PY_10[7:0];
    isp_write(ISP_PM_BASE+0x18,0x00);   // {6'h0, I_PM_PY_11[9:8]};
    isp_write(ISP_PM_BASE+0x17,0x06);   // I_PM_PY_11[7:0];
    isp_write(ISP_PM_BASE+0x19,0x60);   // I_PM_Y_2;
    isp_write(ISP_PM_BASE+0x1A,0x66);   // {I_PM_CB_2, I_PM_CR_2};
    isp_write(ISP_PM_BASE+0x1B,0x00);   // {3'h0, I_PM_PR_2};
    isp_write(ISP_PM_BASE+0x1D,0x00);   // {6'h0, I_PM_PX_20[9:8]};
    isp_write(ISP_PM_BASE+0x1C,0x11);   // I_PM_PX_20[7:0];
    isp_write(ISP_PM_BASE+0x1F,0x00);   // {6'h0, I_PM_PX_21[9:8]};
    isp_write(ISP_PM_BASE+0x1E,0x16);   // I_PM_PX_21[7:0];
    isp_write(ISP_PM_BASE+0x21,0x00);   // {6'h0, I_PM_PY_20[9:8]};
    isp_write(ISP_PM_BASE+0x20,0x01);   // I_PM_PY_20[7:0];
    isp_write(ISP_PM_BASE+0x23,0x00);   // {6'h0, I_PM_PY_21[9:8]};
    isp_write(ISP_PM_BASE+0x22,0x06);   // I_PM_PY_21[7:0];
    isp_write(ISP_PM_BASE+0x24,0x80);   // I_PM_Y_3;
    isp_write(ISP_PM_BASE+0x25,0x88);   // {I_PM_CB_3, I_PM_CR_3};
    isp_write(ISP_PM_BASE+0x26,0x00);   // {3'h0, I_PM_PR_3};
    isp_write(ISP_PM_BASE+0x28,0x01);   // {6'h0, I_PM_PX_30[9:8]};
    isp_write(ISP_PM_BASE+0x27,0x19);   // I_PM_PX_30[7:0];
    isp_write(ISP_PM_BASE+0x2A,0x01);   // {6'h0, I_PM_PX_31[9:8]};
    isp_write(ISP_PM_BASE+0x29,0x1E);   // I_PM_PX_31[7:0];
    isp_write(ISP_PM_BASE+0x2C,0x00);   // {6'h0, I_PM_PY_30[9:8]};
    isp_write(ISP_PM_BASE+0x2B,0x01);   // I_PM_PY_30[7:0];
    isp_write(ISP_PM_BASE+0x2E,0x00);   // {6'h0, I_PM_PY_31[9:8]};
    isp_write(ISP_PM_BASE+0x2D,0x06);   // I_PM_PY_31[7:0];

    isp_write(ISP_PM_BASE+0x90,0xA0);   // I_PM_Y_4;
    isp_write(ISP_PM_BASE+0x91,0xAA);   // {I_PM_CB_4, I_PM_CR_4};
    isp_write(ISP_PM_BASE+0x92,0x00);   // {3'h0, I_PM_PR_4};
    isp_write(ISP_PM_BASE+0x94,0x02);   // {6'h0, I_PM_PX_40[9:8]};
    isp_write(ISP_PM_BASE+0x93,0x01);   // I_PM_PX_40[7:0];
    isp_write(ISP_PM_BASE+0x96,0x02);   // {6'h0, I_PM_PX_41[9:8]};
    isp_write(ISP_PM_BASE+0x95,0x06);   // I_PM_PX_41[7:0];
    isp_write(ISP_PM_BASE+0x98,0x03);   // {6'h0, I_PM_PY_40[9:8]};
    isp_write(ISP_PM_BASE+0x97,0x09);   // I_PM_PY_40[7:0];
    isp_write(ISP_PM_BASE+0x9A,0x03);   // {6'h0, I_PM_PY_41[9:8]};
    isp_write(ISP_PM_BASE+0x99,0x0E);   // I_PM_PY_41[7:0];
    isp_write(ISP_PM_BASE+0x9B,0xC0);   // I_PM_Y_5;
    isp_write(ISP_PM_BASE+0x9C,0xCC);   // {I_PM_CB_5, I_PM_CR_5};
    isp_write(ISP_PM_BASE+0x9D,0x00);   // {3'h0, I_PM_PR_5};
    isp_write(ISP_PM_BASE+0x9F,0x00);   // {6'h0, I_PM_PX_50[9:8]};
    isp_write(ISP_PM_BASE+0x9E,0x09);   // I_PM_PX_50[7:0];
    isp_write(ISP_PM_BASE+0xA1,0x00);   // {6'h0, I_PM_PX_51[9:8]};
    isp_write(ISP_PM_BASE+0xA0,0x0E);   // I_PM_PX_51[7:0];
    isp_write(ISP_PM_BASE+0xA3,0x00);   // {6'h0, I_PM_PY_50[9:8]};
    isp_write(ISP_PM_BASE+0xA2,0x09);   // I_PM_PY_50[7:0];
    isp_write(ISP_PM_BASE+0xA5,0x00);   // {6'h0, I_PM_PY_51[9:8]};
    isp_write(ISP_PM_BASE+0xA4,0x0E);   // I_PM_PY_51[7:0];
    isp_write(ISP_PM_BASE+0xA6,0xE0);   // I_PM_Y_6;
    isp_write(ISP_PM_BASE+0xA7,0xEE);   // {I_PM_CB_6, I_PM_CR_6};
    isp_write(ISP_PM_BASE+0xA8,0x00);   // {3'h0, I_PM_PR_6};
    isp_write(ISP_PM_BASE+0xAA,0x00);   // {6'h0, I_PM_PX_60[9:8]};
    isp_write(ISP_PM_BASE+0xA9,0x11);   // I_PM_PX_60[7:0];
    isp_write(ISP_PM_BASE+0xAC,0x00);   // {6'h0, I_PM_PX_61[9:8]};
    isp_write(ISP_PM_BASE+0xAB,0x16);   // I_PM_PX_61[7:0];
    isp_write(ISP_PM_BASE+0xAE,0x00);   // {6'h0, I_PM_PY_60[9:8]};
    isp_write(ISP_PM_BASE+0xAD,0x09);   // I_PM_PY_60[7:0];
    isp_write(ISP_PM_BASE+0xA0,0x00);   // {6'h0, I_PM_PY_61[9:8]};
    isp_write(ISP_PM_BASE+0xBF,0x0E);   // I_PM_PY_61[7:0];
    isp_write(ISP_PM_BASE+0xB1,0x00);   // I_PM_Y_7;
    isp_write(ISP_PM_BASE+0xB2,0x00);   // {I_PM_CB_7, I_PM_CR_7};
    isp_write(ISP_PM_BASE+0xB3,0x04);   // {3'h0, I_PM_PR_7};
    isp_write(ISP_PM_BASE+0xB5,0x00);   // {6'h0, I_PM_PX_70[9:8]};
    isp_write(ISP_PM_BASE+0xB4,0x19);   // I_PM_PX_70[7:0];
    isp_write(ISP_PM_BASE+0xB7,0x00);   // {6'h0, I_PM_PX_71[9:8]};
    isp_write(ISP_PM_BASE+0xB6,0x1E);   // I_PM_PX_71[7:0];
    isp_write(ISP_PM_BASE+0xB9,0x00);   // {6'h0, I_PM_PY_70[9:8]};
    isp_write(ISP_PM_BASE+0xB8,0x09);   // I_PM_PY_70[7:0];
    isp_write(ISP_PM_BASE+0xBB,0x00);   // {6'h0, I_PM_PY_71[9:8]};
    isp_write(ISP_PM_BASE+0xBA,0x0E);   // I_PM_PY_71[7:0];
}
