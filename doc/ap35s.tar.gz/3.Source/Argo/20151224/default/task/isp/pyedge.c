#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void PYEDGE_set()
{
	tdk_printf("PYEDGE set\n");
    isp_write(ISP_PYEDGE_BASE+0xF0,0x01);  // {5'd0, PYHPF_SEL[1:0], PYHPF_EN};
    isp_write(ISP_PYEDGE_BASE+0xF1,0x01);  // PYHPF_PLUS_OFFSET
    isp_write(ISP_PYEDGE_BASE+0xF2,0x01);  // PYHPF_MINUS_OFFSET
    isp_write(ISP_PYEDGE_BASE+0xF3,0x11);  // PYHPF_PLUS_GAIN
    isp_write(ISP_PYEDGE_BASE+0xF4,0x11);  // PYHPF_MINUS_GAIN
}

