#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void IBLUR_set(void)
{
//    unsigned int rem_h_value;
//    unsigned int rem_v_value;
//    unsigned int rem_value;
//    rem_h_value = 0xF0 & (OUT_HACT<<4);
//    rem_v_value = 0x0F & OUT_VACT;
//    rem_value = rem_h_value + rem_v_value;
//  isp_write(ISP_IBLUR_BASE+0x00,0x00);            // {O_IBLUR_MOSAIC_SIZE,O_IBLUR_INT3,O_IBLUR_INT5_EDGE,O_IBLUR_INT};
//  isp_write(ISP_IBLUR_BASE+0x01,0x00);            // {O_IBLUR_EDGE_SEL,O_IBLUR_DEBUG_EN,O_IBLUR_H_TOTAL_AUTO,O_IBLUR_DEBUG};
//  isp_write(ISP_IBLUR_BASE+0x02,0x00);            // {6'h0, IBLUR_CUSTOM_SIZE, IBLUR_HSYNC_BYPASS}
    isp_write(ISP_IBLUR_BASE+0x04,FRC_VACT >> 8);   // {5'd0,O_IBLUR_V_SIZE[10:8]};
    isp_write(ISP_IBLUR_BASE+0x03,FRC_VACT);        // O_IBLUR_V_SIZE[7:0];
    isp_write(ISP_IBLUR_BASE+0x06,FRC_HACT >> 8);   // {5'd0,O_IBLUR_H_SIZE[10:8]};
    isp_write(ISP_IBLUR_BASE+0x05,FRC_HACT);        // O_IBLUR_H_SIZE[7:0];
    isp_write(ISP_IBLUR_BASE+0x08,FRC_HTOTAL >> 8); // O_IBLUR_H_TOTAL[15:8];
    isp_write(ISP_IBLUR_BASE+0x07,FRC_HTOTAL);      // O_IBLUR_H_TOTAL[7:0];
//  isp_write(ISP_IBLUR_BASE+0x60,0x00);            // {O_LPF_RATIO,O_IBLUR_LPF_SEL,O_IBLUR_CBLUR_EN,O_LPF_EN};

    isp_write(ISP_IBLUR_BASE+0x20,0x1F);            // {3'd0,O_YBLUR_SIZE_CHK,O_YBLUR_FILTER_SET,O_YBLUR_EN};
    isp_write(ISP_IBLUR_BASE+0x20,0x9F);            // {I_Y_BLUR_1ST_LINE_SEL,2'd0,O_YBLUR_SIZE_CHK,O_YBLUR_FILTER_SET,O_YBLUR_EN};
    isp_write(ISP_IBLUR_BASE+0x22,FRC_VACT >> 8);   // {5'd0,O_YBLUR_V_SIZE[10:8]};
    isp_write(ISP_IBLUR_BASE+0x21,FRC_VACT);        // O_YBLUR_V_SIZE[7:0];
    isp_write(ISP_IBLUR_BASE+0x24,FRC_HACT >> 8);   // {5'd0,O_YBLUR_H_SIZE[10:8]};
    isp_write(ISP_IBLUR_BASE+0x23,FRC_HACT);        // O_YBLUR_H_SIZE[7:0];
//  isp_write(ISP_IBLUR_BASE+0x25,rem_value);       // {O_YBLUR_V_END_MUL,O_YBLUR_H_END_MUL};
//  isp_write(ISP_IBLUR_BASE+0x25,0x00);            // {O_YBLUR_V_END_MUL,O_YBLUR_H_END_MUL};
    isp_write(ISP_IBLUR_BASE+0x26,0x80);            // O_YBLUR_BL_GAP_THR0;
    isp_write(ISP_IBLUR_BASE+0x27,0x20);            // O_YBLUR_BL_GAP_THR1;
    isp_write(ISP_IBLUR_BASE+0x28,0x08);            // O_YBLUR_BL_GAP_THR2;
    isp_write(ISP_IBLUR_BASE+0x29,0x28);            // O_YBLUR_BL_GAP_RATIO0;
    isp_write(ISP_IBLUR_BASE+0x2A,0x18);            // O_YBLUR_BL_GAP_RATIO1;
    isp_write(ISP_IBLUR_BASE+0x2B,0x10);            // O_YBLUR_BL_GAP_RATIO2;
    isp_write(ISP_IBLUR_BASE+0x2C,0x40);            // O_YBLUR_DIFF_GAP_THR0;
    isp_write(ISP_IBLUR_BASE+0x2D,0x20);            // O_YBLUR_DIFF_GAP_THR1;
    isp_write(ISP_IBLUR_BASE+0x2E,0x08);            // O_YBLUR_DIFF_GAP_THR2;
    isp_write(ISP_IBLUR_BASE+0x2F,0x60);            // O_YBLUR_DIFF_GAP_RATIO0;
    isp_write(ISP_IBLUR_BASE+0x30,0x35);            // O_YBLUR_DIFF_GAP_RATIO1;
    isp_write(ISP_IBLUR_BASE+0x31,0x2B);            // O_YBLUR_DIFF_GAP_RATIO2;
    isp_write(ISP_IBLUR_BASE+0x32,0xA0);            // {O_YBLUR_DIFF_GAP_SIGN1,O_YBLUR_DIFF_GAP_SIGN0,O_YBLUR_BL_GAP_SIGN1,O_YBLUR_BL_GAP_SIGN0,2'd0,O_YBLUR_DIFF_GAP_DIS,O_YBLUR_BL_GAP_DIS};
}

void ALLNR_set(void)
{
	tdk_printf("YEDGE ALLNR set\n");

    isp_write(ISP_ALLNR_BASE+0x00,0x01);    // ALLNR_SIGN1[1], ALLNR_EN[0]
    isp_write(ISP_ALLNR_BASE+0x01,0x87);    // ALLNR_CURVE_RATIO[7:4], ALLNR_CURVE_SEL1[3:2], ALLNR_CURVE_SEL0[1:0]
    isp_write(ISP_ALLNR_BASE+0x02,0xF7);    // ALLNR_BLUR_RATIO[7:4], ALLNR_BLUR_SEL1[3:2], ALLNR_BLUR_SEL0[1:0]
    isp_write(ISP_ALLNR_BASE+0x03,0x40);    // ALLNR_THR0[7:0]
    isp_write(ISP_ALLNR_BASE+0x04,0x20);    // ALLNR_THR1[7:0]
    isp_write(ISP_ALLNR_BASE+0x05,0x40);    // ALLNR_SLOPE0[7:0]
    isp_write(ISP_ALLNR_BASE+0x06,0x30);    // ALLNR_SLOPE1[7:0]
}

void LTM_set(void)
{
	tdk_printf("YEDGE LTM set\n");

    isp_write(ISP_LTM_BASE+0x00,0x07);  // {5'd0,O_LTM_SIGN2,O_LTM_SIGN1,O_LTM_EN};
    isp_write(ISP_LTM_BASE+0x01,0x08);  // {O_IBLUR_LTM_RATIO,O_IBLUR_LTM_SEL1,O_IBLUR_LTM_SEL0};
    isp_write(ISP_LTM_BASE+0x02,0x80);  // O_LTM_THR0;
    isp_write(ISP_LTM_BASE+0x03,0x40);  // O_LTM_THR1;
    isp_write(ISP_LTM_BASE+0x04,0x10);  // O_LTM_THR2;
    isp_write(ISP_LTM_BASE+0x05,0x08);  // O_LTM_SLOPE0;
    isp_write(ISP_LTM_BASE+0x06,0x08);  // O_LTM_SLOPE1;
    isp_write(ISP_LTM_BASE+0x07,0x20);  // O_LTM_SLOPE2;
    isp_write(ISP_LTM_BASE+0x08,0x04);  // {O_LTM_C_BYPASS,O_LTM_C_GAIN};
    isp_write(ISP_LTM_BASE+0x09,0x40);  // O_LTM_SLOPE_GAIN;
    isp_write(ISP_LTM_BASE+0x0A,0x00);  // LTM_SLOPE_SIGN_Y[1], LTM_SLOPE_SIGN_C[0]
    isp_write(ISP_LTM_BASE+0x0B,0x00);  // LTM_SLOPE_ZERO_B[5:4], LTM_SLOPE_ZERO_L[1:0]
}

void YEDGE_set(void)
{
	tdk_printf("YEDGE edge enhance set\n");

    isp_write(ISP_YEDGE_BASE+0x01,0xA1);    // {YHPF_F1_MODE[7:6], YHPF_F0_MODE[5:4], YHPF_EN[0]}
    isp_write(ISP_YEDGE_BASE+0x02,0x40);    // YHPF_F0_PGAIN;
    isp_write(ISP_YEDGE_BASE+0x03,0x40);    // YHPF_F0_MGAIN;
    isp_write(ISP_YEDGE_BASE+0x04,0xFF);    // YHPF_F0_PLIM;
    isp_write(ISP_YEDGE_BASE+0x05,0xFF);    // YHPF_F0_MLIM;
//  isp_write(ISP_YEDGE_BASE+0x06,0x00);    // YHPF_F0_PCOR_OFFSET;
//  isp_write(ISP_YEDGE_BASE+0x07,0x00);    // YHPF_F0_MCOR_OFFSET;
    isp_write(ISP_YEDGE_BASE+0x08,0x04);    // YHPF_F0_COR_Y0;
    isp_write(ISP_YEDGE_BASE+0x09,0x08);    // YHPF_F0_COR_Y1;
    isp_write(ISP_YEDGE_BASE+0x0A,0x10);    // YHPF_F0_COR_Y2;
    isp_write(ISP_YEDGE_BASE+0x0B,0x20);    // YHPF_F0_COR_Y3;
    isp_write(ISP_YEDGE_BASE+0x0C,0x10);    // YHPF_F0_COR_Y4;
    isp_write(ISP_YEDGE_BASE+0x0D,0x20);    // YHPF_F0_COR_Y5;
    isp_write(ISP_YEDGE_BASE+0x0E,0x40);    // YHPF_F0_COR_Y6;
    isp_write(ISP_YEDGE_BASE+0x0F,0x80);    // YHPF_F0_COR_Y7;
    isp_write(ISP_YEDGE_BASE+0x10,0xC0);    // YHPF_F0_COR_Y8;

    isp_write(ISP_YEDGE_BASE+0x11,0x40);    // YHPF_F1_PGAIN;
    isp_write(ISP_YEDGE_BASE+0x12,0x40);    // YHPF_F1_MGAIN;
    isp_write(ISP_YEDGE_BASE+0x13,0xFF);    // YHPF_F1_PLIM;
    isp_write(ISP_YEDGE_BASE+0x14,0xFF);    // YHPF_F1_MLIM;
//  isp_write(ISP_YEDGE_BASE+0x15,0x00);    // YHPF_F1_PCOR_OFFSET;
//  isp_write(ISP_YEDGE_BASE+0x16,0x00);    // YHPF_F1_MCOR_OFFSET;
    isp_write(ISP_YEDGE_BASE+0x17,0x04);    // YHPF_F1_COR_Y0;
    isp_write(ISP_YEDGE_BASE+0x18,0x08);    // YHPF_F1_COR_Y1;
    isp_write(ISP_YEDGE_BASE+0x19,0x10);    // YHPF_F1_COR_Y2;
    isp_write(ISP_YEDGE_BASE+0x1A,0x20);    // YHPF_F1_COR_Y3;
    isp_write(ISP_YEDGE_BASE+0x1B,0x10);    // YHPF_F1_COR_Y4;
    isp_write(ISP_YEDGE_BASE+0x1C,0x20);    // YHPF_F1_COR_Y5;
    isp_write(ISP_YEDGE_BASE+0x1D,0x40);    // YHPF_F1_COR_Y6;
    isp_write(ISP_YEDGE_BASE+0x1E,0x80);    // YHPF_F1_COR_Y7;
    isp_write(ISP_YEDGE_BASE+0x1F,0xC0);    // YHPF_F1_COR_Y8;

    isp_write(ISP_YEDGE_BASE+0x40,0x03);    // YHPF_SHADE_MODE[3:2], YHPF_SHADE_DIS_EN[1] YHPF_SHADE_EN[0];
//  isp_write(ISP_YEDGE_BASE+0x42,0x00);    // YHPF_LEFT_LINE[10:8]
    isp_write(ISP_YEDGE_BASE+0x41,0x20);    // YHPF_LEFT_LINE[ 7:0]
    isp_write(ISP_YEDGE_BASE+0x44,0x04);    // YHPF_RIGHT_LINE[10:8]
    isp_write(ISP_YEDGE_BASE+0x43,0x10);    // YHPF_RIGHT_LINE[ 7:0]
//  isp_write(ISP_YEDGE_BASE+0x46,0x00);    // YHPF_UP_LINE[10:8]
    isp_write(ISP_YEDGE_BASE+0x45,0x20);    // YHPF_UP_LINE[ 7:0]
    isp_write(ISP_YEDGE_BASE+0x48,0x03);    // YHPF_DOWN_LINE[10:8]
    isp_write(ISP_YEDGE_BASE+0x47,0x10);    // YHPF_DOWN_LINE[ 7:0]
    isp_write(ISP_YEDGE_BASE+0x49,0x20);    // YHPF_SHADE_GAIN[7:0]

    isp_write(ISP_YEDGE_BASE+0x50,0xF1);    // YHPF_LSHADE_RATIO[7:4], YHPF_LSHADE_SLOPE1_SIGN[1], YHPF_LSHADE_EN[0]
    isp_write(ISP_YEDGE_BASE+0x51,0x40);    // YHPF_LSHADE_THR0
    isp_write(ISP_YEDGE_BASE+0x52,0x20);    // YHPF_LSHADE_THR1
    isp_write(ISP_YEDGE_BASE+0x53,0x20);    // YHPF_LSHADE_SLOPE0
    isp_write(ISP_YEDGE_BASE+0x54,0x20);    // YHPF_LSHADE_SLOPE1
}

