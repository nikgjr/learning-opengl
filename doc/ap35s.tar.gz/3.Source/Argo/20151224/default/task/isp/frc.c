#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"
#include "../tdk/tdk_types.h"
void FRC_set()
{
    unsigned int FRC_IMG_WLINE;
    unsigned int FRC_HPXL_SIZE;

	tdk_printf("FRC set\n");
#if(ENV_FPGA==ENV_FPGA_AHD_13M30P)
    isp_write(ISP_FRC_BASE+0x80,0x0C);                      // {NOSYNC,FRC_HACT_POSITION[6],FRC_DPCM_EN[5]_,FRC_VFLIP_EN[4],FRC_READ_MODE[3],FRC_HSYNC_MODE[2],FRC_SYNC_MODE[1:0]};
#else
    isp_write(ISP_FRC_BASE+0x80,0x04);                      // {NOSYNC,FRC_HACT_POSITION[6],FRC_DPCM_EN[5]_,FRC_VFLIP_EN[4],FRC_READ_MODE[3],FRC_HSYNC_MODE[2],FRC_SYNC_MODE[1:0]};
#endif
//    isp_write(0x0682,0xFF & (FRC_VACT >> 8);    // FRC_VSYNC_NUM[10:8]
    isp_write(ISP_FRC_BASE+0x82, FRC_VACT >> 8);    // FRC_VSYNC_NUM[10:8]
    isp_write(ISP_FRC_BASE+0x81, FRC_VACT     );           // FRC_VSYNC_NUM[7:0]
    isp_write(ISP_FRC_BASE+0x84, FRC_VBLK >> 8);    // FRC_VBLANK_NUM[15:8]
    isp_write(ISP_FRC_BASE+0x83, FRC_VBLK     );           // FRC_VBLANK_NUM[7:0]
    isp_write(ISP_FRC_BASE+0x8A, FRC_HACT >> 8);    // FRC_HACT_PIXEL[10:8]
    isp_write(ISP_FRC_BASE+0x89, FRC_HACT     );           // FRC_HACT_PIXEL[7:0]
    isp_write(ISP_FRC_BASE+0x8C, FRC_HBLK >> 8);    // FRC_HBLANK_PIXEL[15:8]
    isp_write(ISP_FRC_BASE+0x8B, FRC_HBLK     );           // FRC_HBLANK_PIXEL[7:0]
//  isp_write(ISP_FRC_BASE+0x8D,0x00);                      // {5'h0,FRC_OUT_VSYNC_POL,FRC_OUT_HSYNC_POL,FRC_OUT_HACT_POL}

//  isp_write(ISP_FRC_BASE+0x8F,0x00);  // frc_vfporch_num
//  isp_write(ISP_FRC_BASE+0x8E,0x00);  // frc_vfporch_num
    isp_write(ISP_FRC_BASE+0x88, DNR_BASE_ADDR >> 24);               // frc_start_addr
    isp_write(ISP_FRC_BASE+0x87, DNR_BASE_ADDR >> 16);               // frc_start_addr
    isp_write(ISP_FRC_BASE+0x86, DNR_BASE_ADDR >> 8 );                // frc_start_addr
    isp_write(ISP_FRC_BASE+0x85, DNR_BASE_ADDR      );                     // frc_start_addr

//  isp_write(ISP_FRC_BASE+0x99,0x00);  // {FRC_UNDERFLOW[7],FRC_FRAME_DONE[6],FRC_EXT_HSYNC_MODE[5],FRC_EXT_SYNC_FORCE[4],1'b0,FRC_EXT_VSYNC_POL[2],FRC_EXT_HSYNC_POL[1],FRC_EXT_HACT_POL[0]}
    isp_write(ISP_FRC_BASE+0x9A,0x50);  // {FRC_BUS_BURST_CTRL[7:4],4'h0}
//  isp_write(ISP_FRC_BASE+0x91,0x00);  // frc_vbporch_num
//  isp_write(ISP_FRC_BASE+0x90,0x00);  // frc_vbporch_num

#if(DNR_EN == ON)
//  FRC_IMG_WLINE = (unsigned int)(FRC_VACT * 2.1 + 0.9);
    FRC_IMG_WLINE = (unsigned int)((FRC_VACT+16) * 2);
#else
    FRC_IMG_WLINE = (unsigned int)(FRC_VACT);
#endif
    FRC_HPXL_SIZE = (unsigned int)(FRC_HACT);

#if(MAIN_FRC_DPCM == ON)
    isp_write(ISP_FRC_BASE+0x80, 0x20) | isp_read(ISP_FRC_BASE+0x80); // {NOSYNC,FRC_HACT_POSITION[6],FRC_DPCM_EN[5]_,FRC_VFLIP_EN[4],FRC_READ_MODE[3],FRC_HSYNC_MODE[2],FRC_SYNC_MODE[1:0]};
#endif

//  isp_write(0x06C0,0x00;                          // {FRC_OUT_CROP_EN[3], FRC_OUT_CROP_INC_EN[2], FRC_OUT_CROP_HSYNC_SEL[1], FRC_OUT_CROP_VSYNC_SEL[0]}
    isp_write(ISP_FRC_BASE+0x93, FRC_HPXL_SIZE >> 8); // FRC_IMG_HPIXEL[10:8]
    isp_write(ISP_FRC_BASE+0x92, FRC_HPXL_SIZE     ); // FRC_IMG_HPIXEL[7:0]
    isp_write(ISP_FRC_BASE+0x95, FRC_VACT >> 8     ); // FRC_IMG_HPIXEL[10:8]
    isp_write(ISP_FRC_BASE+0x94, FRC_VACT          ); // FRC_IMG_HPIXEL[7:0]
    isp_write(ISP_FRC_BASE+0x97, FRC_IMG_WLINE >> 8); // FRC_IMG_HPIXEL[10:8]
    isp_write(ISP_FRC_BASE+0x96, FRC_IMG_WLINE     ); // FRC_IMG_HPIXEL[7:0]
//  isp_write(ISP_FRC_BASE+0x98,0x00);                          // {FRC_PRI_SET[6:4],FRC_PRI_MODE[1:0]}
//  isp_write(ISP_FRC_BASE+0xC0,0x00);                          // {FRC_OUT_CROP_EN[3], FRC_OUT_CROP_INC_EN[2], FRC_OUT_CROP_HSYNC_SEL[1], FRC_OUT_CROP_VSYNC_SEL[0]}
}


