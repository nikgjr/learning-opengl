#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"
void FLK_set(void)
{
	tdk_printf("FLK set\n");
    isp_write(ISP_FLK_BASE+0x00,0x10);  // FLK_HSTART
    isp_write(ISP_FLK_BASE+0x01,0x10);  // FLK_VSTART
    isp_write(ISP_FLK_BASE+0x03,0x04);  // FLK_HWIDTH[12:8]
    isp_write(ISP_FLK_BASE+0x02,0xE0);  // FLK_HWIDTH[7:0]
    isp_write(ISP_FLK_BASE+0x04,0x20);  // FLK_VHEIGHT
//  isp_write(ISP_FLK_BASE+0x05,0x00);  // FLK_SHIFT
}

