#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void OPD_set(void)
{
	tdk_printf("OPD set\n");

    isp_write(ISP_OPD1_BASE+0x00,0x20); // OPD_GRID_EN[5], OPD_GRID_COLOR[4], OPD_DOL_SEL[0]
    isp_write(ISP_OPD1_BASE+0x01,0x02); // OPD_HL_START_X[7:0]
    isp_write(ISP_OPD1_BASE+0x02,0x02); // OPD_HL_START_Y[7:0]
    isp_write(ISP_OPD1_BASE+0x03,0x03); // OPD_HL_WIDTH_X[7:0]
    isp_write(ISP_OPD1_BASE+0x04,0x03); // OPD_HL_HEIGHT_Y[7:0]
    isp_write(ISP_OPD1_BASE+0x05,0x00); // OPD_Y_AWB_EN[7], OPD_Y_CSC_SEL[6], OPD_Y_ENHANCE[5], OPD_VALID[4], OPD_VALID_S[3], OPD_IRIS_SEL[2], OPD_V_SWAP[1], OPD_H_SWAP[0]
    isp_write(ISP_OPD1_BASE+0x06,0x00); // OPD_START_X[10:8]
    isp_write(ISP_OPD1_BASE+0x07,0x00); // OPD_START_X[7:0]
    isp_write(ISP_OPD1_BASE+0x08,0x00); // OPD_START_Y[10:8]
    isp_write(ISP_OPD1_BASE+0x09,0x00); // OPD_START_Y[7:0]
    #if((ENV_TEST == ENV_TEST_FUNC) | (ENV_TEST == ENV_TEST_FUNC_WITH_PLL) | (ENV_TEST == ENV_TEST_FUNC_BYPASS))    
    isp_write(ISP_OPD1_BASE+0x0A,16);   // OPD_BLOCK_LENGTH_X[7:0]
    isp_write(ISP_OPD1_BASE+0x0B,8);    // OPD_BLOCK_LENGTH_Y[7:0]
    #else
    isp_write(ISP_OPD1_BASE+0x0A,160);  // OPD_BLOCK_LENGTH_X[7:0]
    isp_write(ISP_OPD1_BASE+0x0B,90);   // OPD_BLOCK_LENGTH_Y[7:0]
    #endif
    isp_write(ISP_OPD1_BASE+0x0C,0x07); // OPD_BLOCK_NUM_X[7:0]
    isp_write(ISP_OPD1_BASE+0x0D,0x07); // OPD_BLOCK_NUM_Y[7:0]
    isp_write(ISP_OPD1_BASE+0x0E,0x00); // OPD_INPUT_BIT_RANGE
    isp_write(ISP_OPD1_BASE+0x0F,0x00); // OPD_WEIGHT_GRID_EN[4], OPD_WEIGHT_AREA_EN8~5[3:0]
    isp_write(ISP_OPD1_BASE+0x10,0x00); //                        OPD_WEIGHT_AREA_EN4~0[4:0]
    isp_write(ISP_OPD1_BASE+0x11,0x00); // OPD_UPDATE_RN

    isp_write(ISP_OPD1_BASE+0x71,0x00); // OPD_EXPT_L/M/S_YEN_L, OPD_EXPT_L/M/S_YEN_H
    isp_write(ISP_OPD1_BASE+0x78,0x00); // OPD_RECT_EXC_XY_EN
    isp_write(ISP_OPD1_BASE+0x79,0x00); // OPD_RECT_INC_XY_EN
    isp_write(ISP_OPD1_BASE+0x7A,0x00); // OPD_RECT_INC_XY_EN
    isp_write(ISP_OPD1_BASE+0x7B,0x00); // OPD_RECT_INC_XY_EN

    isp_write(ISP_OPD2_BASE+0xD0,0x00);                 // OPD_HISTO_START_X[7:0]
    isp_write(ISP_OPD2_BASE+0xD1,0x00);                 // OPD_HISTO_START_X[10:8]
    isp_write(ISP_OPD2_BASE+0xD2,0x00);                 // OPD_HISTO_START_Y[7:0]
    isp_write(ISP_OPD2_BASE+0xD3,0x00);                 // OPD_HISTO_START_Y[10:8]
    isp_write(ISP_OPD2_BASE+0xD4,IN_HACT_LBFRC);        // OPD_HISTO_WIDTH[7:0]
    isp_write(ISP_OPD2_BASE+0xD5,IN_HACT_LBFRC >> 8);   // OPD_HISTO_WIDTH[10:8]
    isp_write(ISP_OPD2_BASE+0xD6,IN_VACT_LBFRC);        // OPD_HISTO_WIDTH[7:0]
    isp_write(ISP_OPD2_BASE+0xD7,IN_VACT_LBFRC >> 8);   // OPD_HISTO_WIDTH[10:8]
}
