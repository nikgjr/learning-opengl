#ifndef __ISP_MODE_H__
#define __ISP_MODE_H__

#if ((ISP_SIM_MODE == AHD_1280x720_30p) | (ISP_SIM_MODE == AHD_1280x720_25p) | (ISP_SIM_MODE == HDCVI_1280x720_30p) | (ISP_SIM_MODE == HDCVI_1280x720_60p))

// PLL0 288
#define PLL0_KDIV 3
#define PLL0_NDIV 32
#define PLL0_MDIV 1
#define PLL0_EN   1

// PLL1 297
#define PLL1_KDIV 1
#define PLL1_NDIV 11
#define PLL1_MDIV 1
#define PLL1_EN   1

// PLL2 - disabled
#define PLL2_KDIV 1
#define PLL2_NDIV 6
#define PLL2_MDIV 3
#define PLL2_EN   0

#define PLL0_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT
#define PLL1_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT
#define PLL2_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT

// SYS_SEL
#define SYS_CLK_SEL 1 // 0 : PLL0, 1 : PLL1, 2 : PLL2
#define CAN_CLK_SEL 0 // 0 : PLL0, 1 : PLL1, 2 : PLL2

// SYS_DIV
#define CPU_CLK_DIV 1 // 1, 2, 4
#define AXI_CLK_DIV 2 // 1, 2, 4
#define APB_CLK_DIV 2 // 0 : x1, 1 : x1/2, 2 : x1/4, 3 : x1/8
#define DDR_CLK_DIV 2 // 2, 4, 8
#define CAN_CLK_DIV 18

// ISP_SEL
#define PM_CLK_SEL    0 // 0 : OSC, 1 : PLL0, 2 : PLL1, 3 : PLL2
#define IISP_CLK_SEL  0 // 0 : ISP_SYNC, 1 : SENSOR_SYNC
#define MISP_CLK_SEL  0 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : SEN_CLK
#define OISP_CLK_SEL  3 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : ISP_SYNC
#define VEN_CLK_SEL   2 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : OSC
#define DAC_INV_SEL   0 // 0 : ORG, 1 : INV

// ISP_DIV
#if (ISP_SIM_MODE == HDCVI_1280x720_60p)
#define PM_CLK_DIV    2
#define PM_CLK_DIV2   1
#define ISP_CLK_DIV   2 // 144
#define IISP_CLK_DIV  2 // 72
#define MISP_CLK_DIV  2 // 72
#define OISP_CLK_DIV  2 // 72
#define OF_CLK_DIV    2 // 72
#define VEN_CLK_DIV   1 // 144
#define CVBS_CLK_DIV  2
#define B656_CLK_DIV  1 // 144
#else
#define PM_CLK_DIV    2
#define PM_CLK_DIV2   1
#define ISP_CLK_DIV   2 // 144
#define IISP_CLK_DIV  4 // 36
#define MISP_CLK_DIV  4 // 36
#define OISP_CLK_DIV  4 // 36
#define OF_CLK_DIV    4 // 36
#define VEN_CLK_DIV   1 // 144
#define CVBS_CLK_DIV  2
#define B656_CLK_DIV  2 // 72
#endif

// ISP_MODE
#define VEN_SYNC_MODE  0
#define CVBS_SYNC_MODE 0
#define OF_SYNC_MODE   0
#define SEL_LDC_EN     1
#define SEL_OSG_EN     1
#define SEL_WDR_EN     1
#define SEL_OSD_MODE   0

#elif ((ISP_SIM_MODE == AHD_1280x720_60p) | (ISP_SIM_MODE == AHD_1280x720_50p) | (ISP_SIM_MODE == HDTVI_1280x720_30p) | (ISP_SIM_MODE == HDTVI_1280x720_25p) | (ISP_SIM_MODE == HDTVI_1280x720_60p) | (ISP_SIM_MODE == HDTVI_1280x720_50p))
// PLL0 288
#define PLL0_KDIV 3
#define PLL0_NDIV 32
#define PLL0_MDIV 1
#define PLL0_EN   1

// PLL1 297
#define PLL1_KDIV 1
#define PLL1_NDIV 11
#define PLL1_MDIV 1
#define PLL1_EN   1

// PLL2 - disabled
#define PLL2_KDIV 1
#define PLL2_NDIV 6
#define PLL2_MDIV 3
#define PLL2_EN   0

#define PLL0_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT
#define PLL1_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT
#define PLL2_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT

// SYS_SEL
#define SYS_CLK_SEL 1 // 0 : PLL0, 1 : PLL1, 2 : PLL2
#define CAN_CLK_SEL 0 // 0 : PLL0, 1 : PLL1, 2 : PLL2

// SYS_DIV
#define CPU_CLK_DIV 1 // 1, 2, 4
#define AXI_CLK_DIV 2 // 1, 2, 4
#define APB_CLK_DIV 2 // 0 : x1, 1 : x1/2, 2 : x1/4, 3 : x1/8
#define DDR_CLK_DIV 2 // 2, 4, 8
#define CAN_CLK_DIV 18

// ISP_SEL
#define PM_CLK_SEL    0 // 0 : OSC, 1 : PLL0, 2 : PLL1, 3 : PLL2
#define IISP_CLK_SEL  0 // 0 : ISP_SYNC, 1 : SENSOR_SYNC
#define MISP_CLK_SEL  1 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : SEN_CLK
#define OISP_CLK_SEL  3 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : ISP_SYNC
#define VEN_CLK_SEL   2 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : OSC
#define DAC_INV_SEL   0 // 0 : ORG, 1 : INV

// ISP_DIV
#define PM_CLK_DIV    2
#define PM_CLK_DIV2   1
#if ((ISP_SIM_MODE == HDTVI_1280x720_30p) | (ISP_SIM_MODE == HDTVI_1280x720_25p))
#define ISP_CLK_DIV   2 // 148.5
#define IISP_CLK_DIV  4 // 37.125
#define MISP_CLK_DIV  4 // 37.125
#define OISP_CLK_DIV  4 // 37.125
#define OF_CLK_DIV    4 // 37.125
#define VEN_CLK_DIV   1 // 148.5
#define CVBS_CLK_DIV  2
#define B656_CLK_DIV  2 // 74.25
#else
#define ISP_CLK_DIV   2 // 148.5
#define IISP_CLK_DIV  2 // 74.25
#define MISP_CLK_DIV  2 // 74.25
#define OISP_CLK_DIV  2 // 74.25
#define OF_CLK_DIV    2 // 74.25
#define VEN_CLK_DIV   1 // 148.5
#define CVBS_CLK_DIV  2
#define B656_CLK_DIV  1 // 148.5
#endif

// ISP_MODE
#define VEN_SYNC_MODE  0
#define CVBS_SYNC_MODE 0
#define OF_SYNC_MODE   0
#define SEL_LDC_EN     1
#define SEL_OSG_EN     1
#define SEL_WDR_EN     1
#define SEL_OSD_MODE   0

#elif ((ISP_SIM_MODE == CVBS_NTSC_1280h) | (ISP_SIM_MODE == CVBS_NTSC_960h) | (ISP_SIM_MODE == CVBS_NTSC_720h) | (ISP_SIM_MODE == CVBS_PAL_1280h) | (ISP_SIM_MODE == CVBS_PAL_960h) | (ISP_SIM_MODE == CVBS_PAL_720h))
// PLL0 288
#define PLL0_KDIV 3
#define PLL0_NDIV 32
#define PLL0_MDIV 1
#define PLL0_EN   1

// PLL1 297
#define PLL1_KDIV 1
#define PLL1_NDIV 11
#define PLL1_MDIV 1
#define PLL1_EN   1

// PLL2 - cvbs
#if (ISP_SIM_MODE == CVBS_NTSC_1280h) // 90
#define PLL2_KDIV 1
#define PLL2_NDIV 10
#define PLL2_MDIV 3
#define PLL2_EN   1
#elif (ISP_SIM_MODE == CVBS_PAL_1280h) // 96
#define PLL2_KDIV 3
#define PLL2_NDIV 32
#define PLL2_MDIV 3
#define PLL2_EN   1
#elif ((ISP_SIM_MODE == CVBS_NTSC_960h) | (ISP_SIM_MODE == CVBS_PAL_960h)) // none
#define PLL2_KDIV 1
#define PLL2_NDIV 8
#define PLL2_MDIV 4
#define PLL2_EN   0
#elif ((ISP_SIM_MODE == CVBS_NTSC_720h) | (ISP_SIM_MODE == CVBS_PAL_720h))// 54
#define PLL2_KDIV 1
#define PLL2_NDIV 8
#define PLL2_MDIV 4
#define PLL2_EN   1
#endif

#define PLL0_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT
#define PLL1_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT
#define PLL2_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT

// SYS_SEL
#define SYS_CLK_SEL 1 // 0 : PLL0, 1 : PLL1, 2 : PLL2
#define CAN_CLK_SEL 0 // 0 : PLL0, 1 : PLL1, 2 : PLL2

// SYS_DIV
#define CPU_CLK_DIV 1 // 1, 2, 4
#define AXI_CLK_DIV 2 // 1, 2, 4
#define APB_CLK_DIV 2 // 0 : x1, 1 : x1/2, 2 : x1/4, 3 : x1/8
#define DDR_CLK_DIV 2 // 2, 4, 8
#define CAN_CLK_DIV 18

// ISP_SEL
#define PM_CLK_SEL    0 // 0 : OSC, 1 : PLL0, 2 : PLL1, 3 : PLL2
#define IISP_CLK_SEL  0 // 0 : ISP_SYNC, 1 : SENSOR_SYNC
#define MISP_CLK_SEL  1 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : SEN_CLK
#define OISP_CLK_SEL  3 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : ISP_SYNC

#if ((ISP_SIM_MODE == CVBS_NTSC_960h) | (ISP_SIM_MODE == CVBS_PAL_960h)) // none
#define VEN_CLK_SEL   0 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : OSC
#else
#define VEN_CLK_SEL   2 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : OSC
#endif
#define DAC_INV_SEL   0 // 0 : ORG, 1 : INV

// ISP_DIV
#define PM_CLK_DIV    2
#define PM_CLK_DIV2   1
#define ISP_CLK_DIV   2 // 148.5
#define IISP_CLK_DIV  2 // 74.25
#define MISP_CLK_DIV  2 // 74.25
#define OISP_CLK_DIV  2 // 74.25
#define OF_CLK_DIV    2 // 74.25
#if ((ISP_SIM_MODE == CVBS_NTSC_960h) | (ISP_SIM_MODE == CVBS_PAL_960h)) // none
#define VEN_CLK_DIV   4 // 288 -> 72
#else
#define VEN_CLK_DIV   1 // pll2
#endif
#define CVBS_CLK_DIV  4
#define B656_CLK_DIV  1 // 148.5

// ISP_MODE
#define VEN_SYNC_MODE  1
#define CVBS_SYNC_MODE 1
#define OF_SYNC_MODE   0
#define SEL_LDC_EN     1
#define SEL_OSG_EN     1
#define SEL_WDR_EN     1
#define SEL_OSD_MODE   0

#elif ((ISP_SIM_MODE == HDCVI_1280x720_25p) | (ISP_SIM_MODE == HDCVI_1280x720_50p))
// OSC. 54
// PLL0 288
#define PLL0_KDIV 3
#define PLL0_NDIV 16
#define PLL0_MDIV 1
#define PLL0_EN   1

// PLL1 297
#define PLL1_KDIV 2
#define PLL1_NDIV 11
#define PLL1_MDIV 1
#define PLL1_EN   1

// PLL2 240
#define PLL2_KDIV 9
#define PLL2_NDIV 40
#define PLL2_MDIV 1
#define PLL2_EN   1

#define PLL0_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT
#define PLL1_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT
#define PLL2_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT

// SYS_SEL
#define SYS_CLK_SEL 1 // 0 : PLL0, 1 : PLL1, 2 : PLL2
#define CAN_CLK_SEL 0 // 0 : PLL0, 1 : PLL1, 2 : PLL2

// SYS_DIV
#define CPU_CLK_DIV 1 // 1, 2, 4
#define AXI_CLK_DIV 2 // 1, 2, 4
#define APB_CLK_DIV 2 // 0 : x1, 1 : x1/2, 2 : x1/4, 3 : x1/8
#define DDR_CLK_DIV 2 // 2, 4, 8
#define CAN_CLK_DIV 18

// ISP_SEL
#define PM_CLK_SEL    0 // 0 : OSC, 1 : PLL0, 2 : PLL1, 3 : PLL2
#define IISP_CLK_SEL  0 // 0 : ISP_SYNC, 1 : SENSOR_SYNC
#define MISP_CLK_SEL  2 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : SEN_CLK
#define OISP_CLK_SEL  3 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : ISP_SYNC
#define VEN_CLK_SEL   3 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : OSC
#define DAC_INV_SEL   0 // 0 : ORG, 1 : INV

// ISP_DIV
#define PM_CLK_DIV    2
#define PM_CLK_DIV2   1
#define ISP_CLK_DIV   1 // 240
#define IISP_CLK_DIV  4 // 60
#define MISP_CLK_DIV  4 // 60
#define OISP_CLK_DIV  4 // 60
#define OF_CLK_DIV    4 // 60
#define VEN_CLK_DIV   1 // 240
#define CVBS_CLK_DIV  2 // 60
#define B656_CLK_DIV  2 // 120

// ISP_MODE
#define VEN_SYNC_MODE  0
#define CVBS_SYNC_MODE 1
#define OF_SYNC_MODE   0
#define SEL_LDC_EN     1
#define SEL_OSG_EN     1
#define SEL_WDR_EN     1
#define SEL_OSD_MODE   0

#else // #if (ISP_SIM_MODE == DEFAULT)

// PLL0 297
#define PLL0_KDIV 1
#define PLL0_NDIV 11
#define PLL0_MDIV 1
#define PLL0_EN   1

// PLL1 288
#define PLL1_KDIV 3
#define PLL1_NDIV 32
#define PLL1_MDIV 1
#define PLL1_EN   1

// PLL2 54
#define PLL2_KDIV 1
#define PLL2_NDIV 6
#define PLL2_MDIV 3
#define PLL2_EN   1

#define PLL0_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT
#define PLL1_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT
#define PLL2_SEL 2 // 0 : OSC, 1 : OSC_DIV, 2 : PLL,  3 : EXT

// SYS_SEL
#define SYS_CLK_SEL 0 // 0 : PLL0, 1 : PLL1, 2 : PLL2
#define CAN_CLK_SEL 1 // 0 : PLL0, 1 : PLL1, 2 : PLL2

// SYS_DIV
#define CPU_CLK_DIV 1 // 1, 2, 4
#define AXI_CLK_DIV 2 // 1, 2, 4
#define APB_CLK_DIV 2 // 0 : x1, 1 : x1/2, 2 : x1/4, 3 : x1/8
#define DDR_CLK_DIV 2 // 2, 4, 8
#define CAN_CLK_DIV 18

// ISP_SEL
#define PM_CLK_SEL    0 // 0 : OSC, 1 : PLL0, 2 : PLL1, 3 : PLL2
#define IISP_CLK_SEL  0 // 0 : ISP_SYNC, 1 : SENSOR_SYNC
#define MISP_CLK_SEL  0 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : SEN_CLK
#define OISP_CLK_SEL  3 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : ISP_SYNC
#define VEN_CLK_SEL   2 // 0 : PLL0, 1 : PLL1, 2 : PLL2, 3 : OSC
#define DAC_INV_SEL   0 // 0 : ORG, 1 : INV
#define SEN_CLK_SEL   1 // 0 : PARALLEL, 1 : LVDS
#define SEN_CLK_INV   0 // 0 : ORG, 1 : INV

// ISP_DIV
#define PM_CLK_DIV    2
#define PM_CLK_DIV2   1
#define ISP_CLK_DIV   2
#define IISP_CLK_DIV  2
#define MISP_CLK_DIV  2
#define OISP_CLK_DIV  2
#define OF_CLK_DIV    2
#define VEN_CLK_DIV   1
#define CVBS_CLK_DIV  2
#define B656_CLK_DIV  1

// ISP_MODE
#define VEN_SYNC_MODE  1 // 0 : ISP SYNC, 1 : ISP ASYNC
#define CVBS_SYNC_MODE 1 // 0 : ISP SYNC, 1 : ISP ASYNC
#define OF_SYNC_MODE   0 // 0 : ISP SYNC, 1 : ISP ASYNC
#define SEL_LDC_EN     1
#define SEL_OSG_EN     1
#define SEL_WDR_EN     1
#define SEL_OSD_MODE   0
#endif

#if (ISP_SENSOR_MODE == PARALLEL)
#define SEN_CLK_SEL   0 // 0 : PARALLEL, 1 : LVDS
#define SEN_CLK_INV   1 // 0 : ORG, 1 : INV
#elif (SENSOR_MODE == LVDS)
#define SEN_CLK_SEL   1 // 0 : PARALLEL, 1 : LVDS
#define SEN_CLK_INV   0 // 0 : ORG, 1 : INV
#endif

#define PLL_EN   (PLL2_EN*0x4 + PLL1_EN*0x2 + PLL0_EN)
#define PLL0_DIV ((PLL0_NDIV-1)*0x10000 + (PLL0_KDIV-1)*0x100 + (PLL0_MDIV-1))
#define PLL1_DIV ((PLL1_NDIV-1)*0x10000 + (PLL1_KDIV-1)*0x100 + (PLL1_MDIV-1))
#define PLL2_DIV ((PLL2_NDIV-1)*0x10000 + (PLL2_KDIV-1)*0x100 + (PLL2_MDIV-1))
#define PLL_BWADJ ((PLL2_NDIV-1)*0x10000 + (PLL1_NDIV-1)*0x100 + (PLL0_NDIV-1))
#define PLL_SEL (PLL2_SEL*0x100 + PLL1_SEL*0x10 + PLL0_SEL)
#define SYS_SEL (CAN_CLK_SEL*0x10 + SYS_CLK_SEL)
#define SYS_DIV ((CAN_CLK_DIV-1)*0x10000 + ((DDR_CLK_DIV>>1)-1)*0x1000 + APB_CLK_DIV*0x100 + (AXI_CLK_DIV-1)*0x10 + (CPU_CLK_DIV-1))
// #define ISP_SEL (SEN_CLK_INV*0x80000000 + SEN_CLK_SEL*0x40000000 + DAC_INV_SEL*0x20000000 + CVBS_4X_MODE*0x10000000 + AHD_CLK_SEL*0x01000000 + VEN_CLK_SEL*0x00100000 + OISP_CLK_SEL*0x00010000 + MISP_CLK_SEL*0x00001000 + IISP_CLK_SEL*0x00000100 + PM_CLK_SEL)
#define ISP_SEL (SEN_CLK_INV*0x80000000 + SEN_CLK_SEL*0x40000000 + DAC_INV_SEL*0x20000000 + VEN_CLK_SEL*0x00100000 + OISP_CLK_SEL*0x00010000 + MISP_CLK_SEL*0x00001000 + IISP_CLK_SEL*0x00000100 + PM_CLK_SEL)
#define ISP_DIV ((B656_CLK_DIV-1)*0x40000000 + (CVBS_CLK_DIV-1)*0x10000000 + (VEN_CLK_DIV-1)*0x01000000 + (OF_CLK_DIV-1)*0x00400000 + (OISP_CLK_DIV-1)*0x00100000 + (MISP_CLK_DIV-1)*0x00010000 + (IISP_CLK_DIV-1)*0x00001000 + (ISP_CLK_DIV-1)*0x00000100 + (PM_CLK_DIV2-1)*0x4 + (PM_CLK_DIV-1))
#define ISP_MODE (VEN_SYNC_MODE*0x40 + CVBS_SYNC_MODE*0x20 + OF_SYNC_MODE*0x10 + SEL_LDC_EN*0x8 + SEL_OSG_EN*0x4 + SEL_WDR_EN*0x2 + SEL_OSD_MODE)

#endif // __ISP_MODE_H__

