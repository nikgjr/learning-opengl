#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void lbfrc_decomp_set(void) 
{
    isp_write(ISP_LBFRC_BASE+0x00,0x00);  // LBIC_DPCM_MODE[6:5], LBIC_DPCM_ENABLE[4], LBFRC_FPORCH_EN[3], LBFRC_BPORCH_EN[2], LBFRC_FREERUN_EN[1], LBIC_ENABLE[0]
    isp_write(ISP_LBFRC_BASE+0x01,0x00);  // LBFRC_MEM_SEL[4], LBFRC_SEL_SRC[0]
    isp_write(ISP_LBFRC_BASE+0x02,0x02);  // LWDR_CH_SEQ[6:4], LWDR_CH[2], LWDR_MODE[1], LWDR_EN[0]

    isp_write(ISP_LBFRC_BASE+0x11,0x03);  // INPUT_BIT[5:4], OUTPUT_SHFT[3:2], OUTPUT_BIT[1:0]

    isp_write(ISP_LBFRC_BASE+0x7C,0x10);  // DECOMP_ISP_CLIP_EN[4], DECOMP_ISP_SHIFT_IN [2:0]
    isp_write(ISP_LBFRC_BASE+0x7D,0x20);  // DECOMP_ISP_BIT[6:4]  , DECOMP_ISP_SHIFT_OUT[2:0]
    isp_write(ISP_LBFRC_BASE+0x7E,0x14);  // DECOMP_MEM_CLIP_EN[4], DECOMP_MEM_SHIFT_IN [2:0]
    isp_write(ISP_LBFRC_BASE+0x7F,0x20);  // DECOMP_MEM_BIT[6:4]  , DECOMP_MEM_SHIFT_OUT[2:0]

    isp_write(ISP_LBFRC_BASE+0x80,0x70);  // DECOMP_CLIP[6:4], DECOMP_EN[0]
    isp_write(ISP_LBFRC_BASE+0x83,0x00);  // DECOMP_X0[ 7: 0]
    isp_write(ISP_LBFRC_BASE+0x84,0x02);  // DECOMP_X0[15: 8]
    isp_write(ISP_LBFRC_BASE+0x85,0x00);  // DECOMP_Y0[ 7: 0]
    isp_write(ISP_LBFRC_BASE+0x86,0xE8);  // DECOMP_Y0[15: 8]
    isp_write(ISP_LBFRC_BASE+0x87,0xFF);  // DECOMP_Y0[23:16]
    isp_write(ISP_LBFRC_BASE+0x88,0x80);  // DECOMP_X1[ 7: 0]
    isp_write(ISP_LBFRC_BASE+0x89,0x05);  // DECOMP_X1[15: 8]
    isp_write(ISP_LBFRC_BASE+0x8A,0x00);  // DECOMP_Y1[ 7: 0]
    isp_write(ISP_LBFRC_BASE+0x8B,0xE0);  // DECOMP_Y1[15: 8]
    isp_write(ISP_LBFRC_BASE+0x8C,0xFE);  // DECOMP_Y1[23:16]
    isp_write(ISP_LBFRC_BASE+0x8D,0x80);  // DECOMP_X2[ 7: 0]
    isp_write(ISP_LBFRC_BASE+0x8E,0x08);  // DECOMP_X2[15: 8]
    isp_write(ISP_LBFRC_BASE+0x8F,0x00);  // DECOMP_Y2[ 7: 0]
    isp_write(ISP_LBFRC_BASE+0x90,0x00);  // DECOMP_Y2[15: 8]
    isp_write(ISP_LBFRC_BASE+0x91,0xF0);  // DECOMP_Y2[23:16]

    isp_write(ISP_LBFRC_BASE+0x92,0x02);  // DECOMP_SLOPE0[3:0]
    isp_write(ISP_LBFRC_BASE+0x93,0x04);  // DECOMP_SLOPE1[3:0]
    isp_write(ISP_LBFRC_BASE+0x94,0x06);  // DECOMP_SLOPE2[3:0]
    isp_write(ISP_LBFRC_BASE+0x95,0x09);  // DECOMP_SLOPE3[3:0]

}

void lbfrc_dol3_set(void) 
{
    isp_write(ISP_LBFRC_BASE+0x00,0x3C);  // LBIC_DPCM_MODE[6:5], LBIC_DPCM_ENABLE[4], LBFRC_FPORCH_EN[3], LBFRC_BPORCH_EN[2], LBFRC_FREERUN_EN[1], LBIC_ENABLE[0]
    isp_write(ISP_LBFRC_BASE+0x01,0x10);  // LBFRC_MEM_SEL[4], LBFRC_SEL_SRC[0]
    isp_write(ISP_LBFRC_BASE+0x02,0x00);  // LWDR_CH_SEQ[6:4], LWDR_CH[2], LWDR_MODE[1], LWDR_EN[0]
    isp_write(ISP_LBFRC_BASE+0x06, IN_VACT_LBFRC     )  ;    // VSYNC_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x07, IN_VACT_LBFRC >> 8)  ;    // VSYNC_NUM[10:8]
    isp_write(ISP_LBFRC_BASE+0x08, IN_VBLK_LBFRC     )  ;    // VBLANK_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x09, IN_VBLK_LBFRC >> 8)  ;    // VBLANK_NUM[15:8]
    isp_write(ISP_LBFRC_BASE+0x0A, IN_HACT_LBFRC     )  ;    // HSYNC_PIXEL[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0B, IN_HACT_LBFRC >> 8)  ;    // HSYNC_PIXEL[10:8]
    isp_write(ISP_LBFRC_BASE+0x0C, IN_HBLK_LBFRC     )  ;    // HBLANK_PIXEL[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0D, IN_HBLK_LBFRC >> 8)  ;    // HBLANK_PIXEL[15:8]
    isp_write(ISP_LBFRC_BASE+0x0E,0   );    // VBLANK_NUM_FREE[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0F,0   );    // VBLANK_NUM_FREE[15:8]
    isp_write(ISP_LBFRC_BASE+0x12,0x1E); // FPORCH_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x13,0   );    // FPORCH_NUM[15:8]
    isp_write(ISP_LBFRC_BASE+0x14,0x4 );  // BPORCH_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x15,0   );    // BPORCH_NUM[15:8]

    /*
    isp_write(ISP_LBFRC_BASE+0x0E,0xFF &  (IN_VBLK_LBFRC-10)        ;    // VBLANK_NUM_FREE[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0F,0xFF & ((IN_VBLK_LBFRC-10) >> 8)  ;    // VBLANK_NUM_FREE[15:8]
    */
    
    isp_write(ISP_LBFRC_BASE+0x11,0x00);  // INPUT_BIT[5:4], OUTPUT_SHFT[3:2], OUTPUT_BIT[1:0]
    isp_write(ISP_LBFRC_BASE+0x16,0x04);  // WDR_ON_CHECK[2], WDR_FSKIP_LONG[1], WDR_FSKIP_SHORT[0]

/*
    isp_write(ISP_LBFRC_BASE+0x50,0;                             // MEM0_WADDR_E
    isp_write(ISP_LBFRC_BASE+0x51,0;
    isp_write(ISP_LBFRC_BASE+0x52,0xFF &  (2880   /2)        ;   // MEM0_WADDR_O
    isp_write(ISP_LBFRC_BASE+0x53,0xFF & ((2880   /2) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x54,0xFF &  (2880   /2)        ;   // MEM1_WADDR_E
    isp_write(ISP_LBFRC_BASE+0x55,0xFF & ((2880   /2) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x56,0xFF &  (2880 *2/2)        ;   // MEM1_WADDR_O
    isp_write(ISP_LBFRC_BASE+0x57,0xFF & ((2880 *2/2) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x58,0xFF &  (2880 *2/2)        ;   // MEM_WADDR_MAX
    isp_write(ISP_LBFRC_BASE+0x59,0xFF & ((2880 *2/2) >> 8)  ;

    isp_write(ISP_LBFRC_BASE+0x5A,0;                             // MEM0_RADDR_E
    isp_write(ISP_LBFRC_BASE+0x5B,0;
    isp_write(ISP_LBFRC_BASE+0x5C,0xFF &  (2880   /2)        ;   // MEM0_RADDR_O
    isp_write(ISP_LBFRC_BASE+0x5D,0xFF & ((2880   /2) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x5E,0xFF &  (2880   /2)        ;   // MEM1_RADDR_E
    isp_write(ISP_LBFRC_BASE+0x5F,0xFF & ((2880   /2) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x60,0xFF &  (2880 *2/2)        ;   // MEM1_RADDR_O
    isp_write(ISP_LBFRC_BASE+0x61,0xFF & ((2880 *2/2) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x62,0xFF &  (2880 *2/2)        ;   // MEM_RADDR_MAX
    isp_write(ISP_LBFRC_BASE+0x63,0xFF & ((2880 *2/2) >> 8)  ;
    */

    isp_write(ISP_LBFRC_BASE+0x50,0   );                             // MEM0_WADDR_E
    isp_write(ISP_LBFRC_BASE+0x51,0   );
    isp_write(ISP_LBFRC_BASE+0x52, (2880 *1/4)     )  ;   // MEM0_WADDR_O
    isp_write(ISP_LBFRC_BASE+0x53, (2880 *1/4) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x54, (2880 *1/4)     )  ;   // MEM1_WADDR_E
    isp_write(ISP_LBFRC_BASE+0x55, (2880 *1/4) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x56, (2880 *2/4)     )  ;   // MEM1_WADDR_O
    isp_write(ISP_LBFRC_BASE+0x57, (2880 *2/4) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x58, (2880 *2/4)     )  ;   // MEM_WADDR_MAX
    isp_write(ISP_LBFRC_BASE+0x59, (2880 *2/4) >> 8)  ;

    isp_write(ISP_LBFRC_BASE+0x5A, (2880 *2/4)     )  ;   // MEM0_RADDR_E
    isp_write(ISP_LBFRC_BASE+0x5B, (2880 *2/4) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x5C, (2880 *3/4)     )  ;   // MEM0_RADDR_O
    isp_write(ISP_LBFRC_BASE+0x5D, (2880 *3/4) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x5E, (2880 *3/4)     )  ;   // MEM1_RADDR_E
    isp_write(ISP_LBFRC_BASE+0x5F, (2880 *3/4) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x60, (2880 *4/4)     )  ;   // MEM1_RADDR_O
    isp_write(ISP_LBFRC_BASE+0x61, (2880 *4/4) >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x62, (2880 *4/4)     )  ;   // MEM_RADDR_MAX
    isp_write(ISP_LBFRC_BASE+0x63, (2880 *4/4) >> 8)  ;

    isp_write(ISP_LBFRC_BASE+0x80,0x00);      // DECOMP_CLIP[6:4], DECOMP_EN[0]
    isp_write(ISP_LBFRC_BASE+0xA0,LBFRC_BASE0_ADDR     ) ;   // LBFRC_SDRAM0_ADDR_E
    isp_write(ISP_LBFRC_BASE+0xA1,LBFRC_BASE0_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xA2,LBFRC_BASE0_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xA3,LBFRC_BASE0_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xA4,LBFRC_BASE1_ADDR     ) ;   // LBFRC_SDRAM0_ADDR_O
    isp_write(ISP_LBFRC_BASE+0xA5,LBFRC_BASE1_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xA6,LBFRC_BASE1_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xA7,LBFRC_BASE1_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xA8,LBFRC_BASE1_ADDR     ) ;   // LBFRC_SDRAM1_ADDR_E
    isp_write(ISP_LBFRC_BASE+0xA9,LBFRC_BASE1_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xAA,LBFRC_BASE1_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xAB,LBFRC_BASE1_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xAC,LBFRC_BASE2_ADDR     ) ;     // LBFRC_SDRAM1_ADDR_O
    isp_write(ISP_LBFRC_BASE+0xAD,LBFRC_BASE2_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xAE,LBFRC_BASE2_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xAF,LBFRC_BASE2_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xB0,LBFRC_MAX_ADDR     ) ;     // LBFRC_SDRAM_ADDR_MAX
    isp_write(ISP_LBFRC_BASE+0xB1,LBFRC_MAX_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xB2,LBFRC_MAX_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xB3,LBFRC_MAX_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xB4,0x22);      // LBFRC_WBURST_CTRL[5:4], LBFRC_RBURST_CTRL[1:0]
    isp_write(ISP_LBFRC_BASE+0xB5,6   );
    isp_write(ISP_LBFRC_BASE+0xB6,6   );

    isp_write(ISP_LBFRC_BASE+0x00,0x3D);  // LBIC_DPCM_MODE[6:5], LBIC_DPCM_ENABLE[4], LBIC_ENABLE[0]
}

void lbfrc_dol2_set(void)
{
    isp_write(ISP_LBFRC_BASE+0x00,0x30);  // LBIC_DPCM_MODE[6:5], LBIC_DPCM_ENABLE[4], LBFRC_FPORCH_EN[3], LBFRC_BPORCH_EN[2], LBFRC_FREERUN_EN[1], LBIC_ENABLE[0]
    isp_write(ISP_LBFRC_BASE+0x01,0x00);  // LBFRC_MEM_SEL[4], LBFRC_SEL_SRC[0]
    isp_write(ISP_LBFRC_BASE+0x02,0x00);  // LWDR_CH_SEQ[6:4], LWDR_CH[2], LWDR_MODE[1], LWDR_EN[0]
    isp_write(ISP_LBFRC_BASE+0x06, IN_VACT_LBFRC     )  ;    // VSYNC_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x07, IN_VACT_LBFRC >> 8)  ;    // VSYNC_NUM[10:8]
    isp_write(ISP_LBFRC_BASE+0x08, IN_VBLK_LBFRC     )  ;    // VBLANK_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x09, IN_VBLK_LBFRC >> 8)  ;    // VBLANK_NUM[15:8]
    isp_write(ISP_LBFRC_BASE+0x0A, IN_HACT_LBFRC     )  ;    // HSYNC_PIXEL[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0B, IN_HACT_LBFRC >> 8)  ;    // HSYNC_PIXEL[10:8]
    isp_write(ISP_LBFRC_BASE+0x0C, IN_HBLK_LBFRC     )  ;    // HBLANK_PIXEL[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0D, IN_HBLK_LBFRC >> 8)  ;    // HBLANK_PIXEL[15:8]
    isp_write(ISP_LBFRC_BASE+0x0E,0   );    // VBLANK_NUM_FREE[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0F,0   );    // VBLANK_NUM_FREE[15:8]
    isp_write(ISP_LBFRC_BASE+0x12,0   );    // FPORCH_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x13,0   );    // FPORCH_NUM[15:8]
    isp_write(ISP_LBFRC_BASE+0x14,0   );    // BPORCH_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x15,0   );    // BPORCH_NUM[15:8]

    isp_write(ISP_LBFRC_BASE+0x11,0x00);  // INPUT_BIT[5:4], OUTPUT_SHFT[3:2], OUTPUT_BIT[1:0]
    isp_write(ISP_LBFRC_BASE+0x16,0x04);  // WDR_ON_CHECK[2], WDR_FSKIP_LONG[1], WDR_FSKIP_SHORT[0]

    /*
    isp_write(ISP_LBFRC_BASE+0x18,0x03;  // QINIT_FRAME_EN[1], QINIT_LINE_EN[0]
    isp_write(ISP_LBFRC_BASE+0x20,14;    // LBIC_SIZE_RATIO_MIN[3:0]
    isp_write(ISP_LBFRC_BASE+0x21,15;    // LBIC_SIZE_RATIO_MAX[3:0]
    isp_write(ISP_LBFRC_BASE+0x22,0xFF &  (IN_HACT_LBFRC*12/2)             ;   // LBIC_LINE_SIZE
    isp_write(ISP_LBFRC_BASE+0x23,0x7F & ((IN_HACT_LBFRC*12/2) >> 8)       ;
    isp_write(ISP_LBFRC_BASE+0x24,0xFF &  (IN_HACT_LBFRC*12*14/16/2)       ;   // LBIC_LINE_LTHR0
    isp_write(ISP_LBFRC_BASE+0x25,0x7F & ((IN_HACT_LBFRC*12*14/16/2) >> 8) ;
    isp_write(ISP_LBFRC_BASE+0x26,0xFF &  (IN_HACT_LBFRC*12*3/2)           ;   // LBIC_LINE_LTHR1
    isp_write(ISP_LBFRC_BASE+0x27,0xFF & ((IN_HACT_LBFRC*12*3/2) >> 8)     ;
    isp_write(ISP_LBFRC_BASE+0x28,0x01 & ((IN_HACT_LBFRC*12*3/2) >> 16)    ;
    isp_write(ISP_LBFRC_BASE+0x29,0xFF &  (IN_HACT_LBFRC*12*4/2)           ;   // LBIC_LINE_LTHR2
    isp_write(ISP_LBFRC_BASE+0x2A,0xFF & ((IN_HACT_LBFRC*12*4/2) >> 8)     ;
    isp_write(ISP_LBFRC_BASE+0x2B,0x01 & ((IN_HACT_LBFRC*12*4/2) >> 16)    ;
    isp_write(ISP_LBFRC_BASE+0x2C,0xFF &  (IN_HACT_LBFRC*12*3/2/2)         ;   // LBIC_LINE_LTHR3_2
    isp_write(ISP_LBFRC_BASE+0x2D,0xFF & ((IN_HACT_LBFRC*12*3/2/2) >> 8)   ;
    isp_write(ISP_LBFRC_BASE+0x2E,12;            // LBIC_MEM0_LINE
    isp_write(ISP_LBFRC_BASE+0x2F,12;            // LBIC_MEM0_LINE
    */

    isp_write(ISP_LBFRC_BASE+0x50,0   );                      // MEM0_WADDR_E
    isp_write(ISP_LBFRC_BASE+0x51,0   );
    isp_write(ISP_LBFRC_BASE+0x52, 2880     )  ;   // MEM0_WADDR_O
    isp_write(ISP_LBFRC_BASE+0x53, 2880 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x54, 2880     )  ;   // MEM1_WADDR_E
    isp_write(ISP_LBFRC_BASE+0x55, 2880 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x56, 2880     )  ;   // MEM1_WADDR_O
    isp_write(ISP_LBFRC_BASE+0x57, 2880 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x58, 2880     )  ;   // MEM_WADDR_MAX
    isp_write(ISP_LBFRC_BASE+0x59, 2880 >> 8)  ;

    isp_write(ISP_LBFRC_BASE+0x5A,0   );                      // MEM0_RADDR_E
    isp_write(ISP_LBFRC_BASE+0x5B,0   );
    isp_write(ISP_LBFRC_BASE+0x5C, 2880     )  ;   // MEM0_RADDR_O
    isp_write(ISP_LBFRC_BASE+0x5D, 2880 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x5E, 2880     )  ;   // MEM1_RADDR_E
    isp_write(ISP_LBFRC_BASE+0x5F, 2880 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x60, 2880     )  ;   // MEM1_RADDR_O
    isp_write(ISP_LBFRC_BASE+0x61, 2880 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x62, 2880     )  ;   // MEM_RADDR_MAX
    isp_write(ISP_LBFRC_BASE+0x63, 2880 >> 8)  ;

    isp_write(ISP_LBFRC_BASE+0x80,0x00);      // DECOMP_CLIP[6:4], DECOMP_EN[0]
    isp_write(ISP_LBFRC_BASE+0xA0, LBFRC_BASE0_ADDR     ) ;   // LBFRC_SDRAM0_ADDR_E
    isp_write(ISP_LBFRC_BASE+0xA1, LBFRC_BASE0_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xA2, LBFRC_BASE0_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xA3, LBFRC_BASE0_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xA4, LBFRC_BASE1_ADDR     ) ;   // LBFRC_SDRAM0_ADDR_O
    isp_write(ISP_LBFRC_BASE+0xA5, LBFRC_BASE1_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xA6, LBFRC_BASE1_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xA7, LBFRC_BASE1_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xA8, LBFRC_BASE1_ADDR     ) ;   // LBFRC_SDRAM1_ADDR_E
    isp_write(ISP_LBFRC_BASE+0xA9, LBFRC_BASE1_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xAA, LBFRC_BASE1_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xAB, LBFRC_BASE1_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xAC, LBFRC_BASE2_ADDR     ) ;     // LBFRC_SDRAM1_ADDR_O
    isp_write(ISP_LBFRC_BASE+0xAD, LBFRC_BASE2_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xAE, LBFRC_BASE2_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xAF, LBFRC_BASE2_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xB0, LBFRC_MAX_ADDR     ) ;     // LBFRC_SDRAM_ADDR_MAX
    isp_write(ISP_LBFRC_BASE+0xB1, LBFRC_MAX_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xB2, LBFRC_MAX_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xB3, LBFRC_MAX_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xB4,0x22);      // LBFRC_WBURST_CTRL[5:4], LBFRC_RBURST_CTRL[1:0]
    isp_write(ISP_LBFRC_BASE+0xB5,6   );
    isp_write(ISP_LBFRC_BASE+0xB6,6   );

    isp_write(ISP_LBFRC_BASE+0x00,0x31);  // LBIC_DPCM_MODE[6:5], LBIC_DPCM_ENABLE[4], LBIC_ENABLE[0]
}

void lbfrc_2fr_set(void)
{
    isp_write(ISP_LBFRC_BASE+0x00,0x34);  // LBIC_DPCM_MODE[6:5], LBIC_DPCM_ENABLE[4], LBFRC_FPORCH_EN[3], LBFRC_BPORCH_EN[2], LBFRC_FREERUN_EN[1], LBIC_ENABLE[0]
    isp_write(ISP_LBFRC_BASE+0x01,0x10);  // LBFRC_MEM_SEL[4], LBFRC_SEL_SRC[0]
    isp_write(ISP_LBFRC_BASE+0x02,0x00);  // LWDR_CH_SEQ[6:4], LWDR_CH[2], LWDR_MODE[1], LWDR_EN[0]
    isp_write(ISP_LBFRC_BASE+0x06, IN_VACT_LBFRC     )  ;    // VSYNC_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x07, IN_VACT_LBFRC >> 8)  ;    // VSYNC_NUM[10:8]
    isp_write(ISP_LBFRC_BASE+0x08, IN_VBLK_LBFRC     )  ;    // VBLANK_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x09, IN_VBLK_LBFRC >> 8)  ;    // VBLANK_NUM[15:8]
    isp_write(ISP_LBFRC_BASE+0x0A, IN_HACT_LBFRC     )  ;    // HSYNC_PIXEL[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0B, IN_HACT_LBFRC >> 8)  ;    // HSYNC_PIXEL[10:8]
    isp_write(ISP_LBFRC_BASE+0x0C, IN_HBLK_LBFRC     )  ;    // HBLANK_PIXEL[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0D, IN_HBLK_LBFRC >> 8)  ;    // HBLANK_PIXEL[15:8]
    isp_write(ISP_LBFRC_BASE+0x0E,0   );    // VBLANK_NUM_FREE[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0F,0   );    // VBLANK_NUM_FREE[15:8]

    isp_write(ISP_LBFRC_BASE+0x11,0x00);  // INPUT_BIT[5:4], OUTPUT_SHFT[3:2], OUTPUT_BIT[1:0]
    isp_write(ISP_LBFRC_BASE+0x12,0   );    // FPORCH_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x13,0   );    // FPORCH_NUM[15:8]
    isp_write(ISP_LBFRC_BASE+0x14,4   );    // BPORCH_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x15,0   );    // BPORCH_NUM[15:8]

    isp_write(ISP_LBFRC_BASE+0x16,0x04);  // WDR_ON_CHECK[2], WDR_FSKIP_LONG[1], WDR_FSKIP_SHORT[0]

    /*
    isp_write(ISP_LBFRC_BASE+0x18,0x03;  // QINIT_FRAME_EN[1], QINIT_LINE_EN[0]
    isp_write(ISP_LBFRC_BASE+0x20,14;    // LBIC_SIZE_RATIO_MIN[3:0]
    isp_write(ISP_LBFRC_BASE+0x21,15;    // LBIC_SIZE_RATIO_MAX[3:0]
    isp_write(ISP_LBFRC_BASE+0x22,0xFF &  (IN_HACT_LBFRC*12/2)             ;   // LBIC_LINE_SIZE
    isp_write(ISP_LBFRC_BASE+0x23,0x7F & ((IN_HACT_LBFRC*12/2) >> 8)       ;
    isp_write(ISP_LBFRC_BASE+0x24,0xFF &  (IN_HACT_LBFRC*12*14/16/2)       ;   // LBIC_LINE_LTHR0
    isp_write(ISP_LBFRC_BASE+0x25,0x7F & ((IN_HACT_LBFRC*12*14/16/2) >> 8) ;
    isp_write(ISP_LBFRC_BASE+0x26,0xFF &  (IN_HACT_LBFRC*12*3/2)           ;   // LBIC_LINE_LTHR1
    isp_write(ISP_LBFRC_BASE+0x27,0xFF & ((IN_HACT_LBFRC*12*3/2) >> 8)     ;
    isp_write(ISP_LBFRC_BASE+0x28,0x01 & ((IN_HACT_LBFRC*12*3/2) >> 16)    ;
    isp_write(ISP_LBFRC_BASE+0x29,0xFF &  (IN_HACT_LBFRC*12*4/2)           ;   // LBIC_LINE_LTHR2
    isp_write(ISP_LBFRC_BASE+0x2A,0xFF & ((IN_HACT_LBFRC*12*4/2) >> 8)     ;
    isp_write(ISP_LBFRC_BASE+0x2B,0x01 & ((IN_HACT_LBFRC*12*4/2) >> 16)    ;
    isp_write(ISP_LBFRC_BASE+0x2C,0xFF &  (IN_HACT_LBFRC*12*3/2/2)         ;   // LBIC_LINE_LTHR3_2
    isp_write(ISP_LBFRC_BASE+0x2D,0xFF & ((IN_HACT_LBFRC*12*3/2/2) >> 8)   ;
    isp_write(ISP_LBFRC_BASE+0x2E,12;            // LBIC_MEM0_LINE
    isp_write(ISP_LBFRC_BASE+0x2F,12;            // LBIC_MEM0_LINE
    */

    isp_write(ISP_LBFRC_BASE+0x50,0   );                             // MEM0_WADDR_E
    isp_write(ISP_LBFRC_BASE+0x51,0   );
    isp_write(ISP_LBFRC_BASE+0x52, 2880 *1/2     )  ;   // MEM0_WADDR_O
    isp_write(ISP_LBFRC_BASE+0x53, 2880 *1/2 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x54, 2880 *1/2     )  ;   // MEM1_WADDR_E
    isp_write(ISP_LBFRC_BASE+0x55, 2880 *1/2 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x56, 2880 *1/2     )  ;   // MEM1_WADDR_O
    isp_write(ISP_LBFRC_BASE+0x57, 2880 *1/2 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x58, 2880 *1/2     )  ;   // MEM_WADDR_MAX
    isp_write(ISP_LBFRC_BASE+0x59, 2880 *1/2 >> 8)  ;

    isp_write(ISP_LBFRC_BASE+0x5A, 2880 *1/2     )  ;   // MEM0_RADDR_E
    isp_write(ISP_LBFRC_BASE+0x5B, 2880 *1/2 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x5C, 2880 *2/2     )  ;   // MEM0_RADDR_O
    isp_write(ISP_LBFRC_BASE+0x5D, 2880 *2/2 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x5E, 2880 *2/2     )  ;   // MEM1_RADDR_E
    isp_write(ISP_LBFRC_BASE+0x5F, 2880 *2/2 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x60, 2880 *2/2     )  ;   // MEM1_RADDR_O
    isp_write(ISP_LBFRC_BASE+0x61, 2880 *2/2 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x62, 2880 *2/2     )  ;   // MEM_RADDR_MAX
    isp_write(ISP_LBFRC_BASE+0x63, 2880 *2/2 >> 8)  ;

    isp_write(ISP_LBFRC_BASE+0x80,0x00);      // DECOMP_CLIP[6:4], DECOMP_EN[0]
    isp_write(ISP_LBFRC_BASE+0xA0, LBFRC_BASE0_ADDR     ) ;   // LBFRC_SDRAM0_ADDR_E
    isp_write(ISP_LBFRC_BASE+0xA1, LBFRC_BASE0_ADDR >> 8) ; 
    isp_write(ISP_LBFRC_BASE+0xA2, LBFRC_BASE0_ADDR >> 16);   
    isp_write(ISP_LBFRC_BASE+0xA3, LBFRC_BASE0_ADDR >> 24);   
    isp_write(ISP_LBFRC_BASE+0xA4, LBFRC_2FR_ADDR     ) ;   // LBFRC_SDRAM0_ADDR_O     
    isp_write(ISP_LBFRC_BASE+0xA5, LBFRC_2FR_ADDR >> 8) ;     
    isp_write(ISP_LBFRC_BASE+0xA6, LBFRC_2FR_ADDR >> 16);     
    isp_write(ISP_LBFRC_BASE+0xA7, LBFRC_2FR_ADDR >> 24);     
    isp_write(ISP_LBFRC_BASE+0xA8, LBFRC_2FR_ADDR     ) ;   // LBFRC_SDRAM1_ADDR_E       
    isp_write(ISP_LBFRC_BASE+0xA9, LBFRC_2FR_ADDR >> 8) ;                                
    isp_write(ISP_LBFRC_BASE+0xAA, LBFRC_2FR_ADDR >> 16);                                
    isp_write(ISP_LBFRC_BASE+0xAB, LBFRC_2FR_ADDR >> 24);                                
    isp_write(ISP_LBFRC_BASE+0xAC, LBFRC_2FR_ADDR     ) ;     // LBFRC_SDRAM1_ADDR_O         
    isp_write(ISP_LBFRC_BASE+0xAD, LBFRC_2FR_ADDR >> 8) ;                                  
    isp_write(ISP_LBFRC_BASE+0xAE, LBFRC_2FR_ADDR >> 16);                                  
    isp_write(ISP_LBFRC_BASE+0xAF, LBFRC_2FR_ADDR >> 24);                                  
    isp_write(ISP_LBFRC_BASE+0xB0, LBFRC_2FR_ADDR     ) ;     // LBFRC_SDRAM_ADDR_MAX           
    isp_write(ISP_LBFRC_BASE+0xB1, LBFRC_2FR_ADDR >> 8) ;                                       
    isp_write(ISP_LBFRC_BASE+0xB2, LBFRC_2FR_ADDR >> 16);                                       
    isp_write(ISP_LBFRC_BASE+0xB3, LBFRC_2FR_ADDR >> 24);                                       
    isp_write(ISP_LBFRC_BASE+0xB4,0x33);      // LBFRC_WBURST_CTRL[5:4], LBFRC_RBURST_CTRL[1:0]   
    isp_write(ISP_LBFRC_BASE+0xB5,6   );  
    isp_write(ISP_LBFRC_BASE+0xB6,6   );  

    isp_write(ISP_LBFRC_BASE+0x00,0x35);  // LBIC_DPCM_MODE[6:5], LBIC_DPCM_ENABLE[4], LBIC_ENABLE[0]
}

void lbfrc_lwdr3_set(void)
{
    isp_write(ISP_LBFRC_BASE+0x01,0x00);  // LBFRC_MEM_SEL[4], LBFRC_SEL_SRC[0]
    isp_write(ISP_LBFRC_BASE+0x02,0x45);  // LWDR_CH_SEQ[6:4], LWDR_CH[2], LWDR_MODE[1], LWDR_EN[0]
    isp_write(ISP_LBFRC_BASE+0x06, IN_VACT_LBFRC     )  ;    // VSYNC_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x07, IN_VACT_LBFRC >> 8)  ;    // VSYNC_NUM[10:8]
    isp_write(ISP_LBFRC_BASE+0x08, IN_VBLK_LBFRC     )  ;    // VBLANK_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x09, IN_VBLK_LBFRC >> 8)  ;    // VBLANK_NUM[15:8]
    isp_write(ISP_LBFRC_BASE+0x0A, IN_HACT_LBFRC     )  ;    // HSYNC_PIXEL[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0B, IN_HACT_LBFRC >> 8)  ;    // HSYNC_PIXEL[10:8]
    isp_write(ISP_LBFRC_BASE+0x0C, IN_HBLK_LBFRC     )  ;    // HBLANK_PIXEL[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0D, IN_HBLK_LBFRC >> 8)  ;    // HBLANK_PIXEL[15:8]
    isp_write(ISP_LBFRC_BASE+0x0E,0   );    // VBLANK_NUM_FREE[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0F,0   );    // VBLANK_NUM_FREE[15:8]
    isp_write(ISP_LBFRC_BASE+0x12,0   );    // FPORCH_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x13,0   );    // FPORCH_NUM[15:8]
    isp_write(ISP_LBFRC_BASE+0x14,0   );    // BPORCH_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x15,0   );    // BPORCH_NUM[15:8]

    isp_write(ISP_LBFRC_BASE+0x11,0x00);  // INPUT_BIT[5:4], OUTPUT_SHFT[3:2], OUTPUT_BIT[1:0]
    isp_write(ISP_LBFRC_BASE+0x16,0x04);  // WDR_ON_CHECK[2], WDR_FSKIP_LONG[1], WDR_FSKIP_SHORT[0]

    /*
    isp_write(ISP_LBFRC_BASE+0x18,0x03;  // QINIT_FRAME_EN[1], QINIT_LINE_EN[0]
    isp_write(ISP_LBFRC_BASE+0x20,14;    // LBIC_SIZE_RATIO_MIN[3:0]
    isp_write(ISP_LBFRC_BASE+0x21,15;    // LBIC_SIZE_RATIO_MAX[3:0]
    isp_write(ISP_LBFRC_BASE+0x22,0xFF &  (IN_HACT_LBFRC*12/2)             ;   // LBIC_LINE_SIZE
    isp_write(ISP_LBFRC_BASE+0x23,0x7F & ((IN_HACT_LBFRC*12/2) >> 8)       ;
    isp_write(ISP_LBFRC_BASE+0x24,0xFF &  (IN_HACT_LBFRC*12*14/16/2)       ;   // LBIC_LINE_LTHR0
    isp_write(ISP_LBFRC_BASE+0x25,0x7F & ((IN_HACT_LBFRC*12*14/16/2) >> 8) ;
    isp_write(ISP_LBFRC_BASE+0x26,0xFF &  (IN_HACT_LBFRC*12*3/2)           ;   // LBIC_LINE_LTHR1
    isp_write(ISP_LBFRC_BASE+0x27,0xFF & ((IN_HACT_LBFRC*12*3/2) >> 8)     ;
    isp_write(ISP_LBFRC_BASE+0x28,0x01 & ((IN_HACT_LBFRC*12*3/2) >> 16)    ;
    isp_write(ISP_LBFRC_BASE+0x29,0xFF &  (IN_HACT_LBFRC*12*4/2)           ;   // LBIC_LINE_LTHR2
    isp_write(ISP_LBFRC_BASE+0x2A,0xFF & ((IN_HACT_LBFRC*12*4/2) >> 8)     ;
    isp_write(ISP_LBFRC_BASE+0x2B,0x01 & ((IN_HACT_LBFRC*12*4/2) >> 16)    ;
    isp_write(ISP_LBFRC_BASE+0x2C,0xFF &  (IN_HACT_LBFRC*12*3/2/2)         ;   // LBIC_LINE_LTHR3_2
    isp_write(ISP_LBFRC_BASE+0x2D,0xFF & ((IN_HACT_LBFRC*12*3/2/2) >> 8)   ;
    isp_write(ISP_LBFRC_BASE+0x2E,12;            // LBIC_MEM0_LINE
    isp_write(ISP_LBFRC_BASE+0x2F,12;            // LBIC_MEM0_LINE
    */

    isp_write(ISP_LBFRC_BASE+0x50,0   );                      // MEM0_WADDR_E
    isp_write(ISP_LBFRC_BASE+0x51,0   );
    isp_write(ISP_LBFRC_BASE+0x52, 2880 *1/4     )  ;   // MEM0_WADDR_O
    isp_write(ISP_LBFRC_BASE+0x53, 2880 *1/4 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x54, 2880 *2/4     )  ;   // MEM1_WADDR_E
    isp_write(ISP_LBFRC_BASE+0x55, 2880 *2/4 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x56, 2880 *3/4     )  ;   // MEM1_WADDR_O
    isp_write(ISP_LBFRC_BASE+0x57, 2880 *3/4 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x58, 2880 *3/4     )  ;   // MEM_WADDR_MAX
    isp_write(ISP_LBFRC_BASE+0x59, 2880 *3/4 >> 8)  ;

    isp_write(ISP_LBFRC_BASE+0x5A,0   );                      // MEM0_RADDR_E
    isp_write(ISP_LBFRC_BASE+0x5B,0   );
    isp_write(ISP_LBFRC_BASE+0x5C, 2880 *1/4     )  ;   // MEM0_RADDR_O
    isp_write(ISP_LBFRC_BASE+0x5D, 2880 *1/4 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x5E, 2880 *2/4     )  ;   // MEM1_RADDR_E
    isp_write(ISP_LBFRC_BASE+0x5F, 2880 *2/4 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x60, 2880 *3/4     )  ;   // MEM1_RADDR_O
    isp_write(ISP_LBFRC_BASE+0x61, 2880 *3/4 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x62, 2880 *3/4     )  ;   // MEM_RADDR_MAX
    isp_write(ISP_LBFRC_BASE+0x63, 2880 *3/4 >> 8)  ;

    isp_write(ISP_LBFRC_BASE+0x80,0x00);      // DECOMP_CLIP[6:4], DECOMP_EN[0]
    isp_write(ISP_LBFRC_BASE+0xA0, LBFRC_BASE0_ADDR     ) ;   // LBFRC_SDRAM0_ADDR_E
    isp_write(ISP_LBFRC_BASE+0xA1, LBFRC_BASE0_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xA2, LBFRC_BASE0_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xA3, LBFRC_BASE0_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xA4, LBFRC_MAX_ADDR     ) ;   // LBFRC_SDRAM0_ADDR_O
    isp_write(ISP_LBFRC_BASE+0xA5, LBFRC_MAX_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xA6, LBFRC_MAX_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xA7, LBFRC_MAX_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xA8, LBFRC_MAX_ADDR     ) ;   // LBFRC_SDRAM1_ADDR_E
    isp_write(ISP_LBFRC_BASE+0xA9, LBFRC_MAX_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xAA, LBFRC_MAX_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xAB, LBFRC_MAX_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xAC, LBFRC_MAX_ADDR     ) ;     // LBFRC_SDRAM1_ADDR_O
    isp_write(ISP_LBFRC_BASE+0xAD, LBFRC_MAX_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xAE, LBFRC_MAX_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xAF, LBFRC_MAX_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xB0, LBFRC_MAX_ADDR     ) ;     // LBFRC_SDRAM_ADDR_MAX
    isp_write(ISP_LBFRC_BASE+0xB1, LBFRC_MAX_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xB2, LBFRC_MAX_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xB3, LBFRC_MAX_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xB4,0x22);      // LBFRC_WBURST_CTRL[5:4], LBFRC_RBURST_CTRL[1:0]
    isp_write(ISP_LBFRC_BASE+0xB5,6   );
    isp_write(ISP_LBFRC_BASE+0xB6,6   );

    isp_write(ISP_LBFRC_BASE+0x00,0x01);  // LBIC_DPCM_MODE[6:5], LBIC_DPCM_ENABLE[4], LBIC_ENABLE[0]
}

void lbfrc_lwdr2_set(void){
    isp_write(ISP_LBFRC_BASE+0x01,0x00);  // LBFRC_MEM_SEL[4], LBFRC_SEL_SRC[0]
    isp_write(ISP_LBFRC_BASE+0x02,0x01);  // LWDR_CH_SEQ[6:4], LWDR_CH[2], LWDR_MODE[1], LWDR_EN[0]
    isp_write(ISP_LBFRC_BASE+0x06, IN_VACT_LBFRC     )  ;    // VSYNC_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x07, IN_VACT_LBFRC >> 8)  ;    // VSYNC_NUM[10:8]
    isp_write(ISP_LBFRC_BASE+0x08, IN_VBLK_LBFRC     )  ;    // VBLANK_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x09, IN_VBLK_LBFRC >> 8)  ;    // VBLANK_NUM[15:8]
    isp_write(ISP_LBFRC_BASE+0x0A, IN_HACT_LBFRC     )  ;    // HSYNC_PIXEL[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0B, IN_HACT_LBFRC >> 8)  ;    // HSYNC_PIXEL[10:8]
    isp_write(ISP_LBFRC_BASE+0x0C, IN_HBLK_LBFRC     )  ;    // HBLANK_PIXEL[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0D, IN_HBLK_LBFRC >> 8)  ;    // HBLANK_PIXEL[15:8]
    isp_write(ISP_LBFRC_BASE+0x0E,0   );    // VBLANK_NUM_FREE[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x0F,0   );    // VBLANK_NUM_FREE[15:8]
    isp_write(ISP_LBFRC_BASE+0x12,0   );    // FPORCH_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x13,0   );    // FPORCH_NUM[15:8]
    isp_write(ISP_LBFRC_BASE+0x14,0   );    // BPORCH_NUM[ 7:0]
    isp_write(ISP_LBFRC_BASE+0x15,0   );    // BPORCH_NUM[15:8]

    isp_write(ISP_LBFRC_BASE+0x11,0x00);  // INPUT_BIT[5:4], OUTPUT_SHFT[3:2], OUTPUT_BIT[1:0]
    isp_write(ISP_LBFRC_BASE+0x16,0x04);  // WDR_ON_CHECK[2], WDR_FSKIP_LONG[1], WDR_FSKIP_SHORT[0]

    /*
    isp_write(ISP_LBFRC_BASE+0x18,0x03;  // QINIT_FRAME_EN[1], QINIT_LINE_EN[0]
    isp_write(ISP_LBFRC_BASE+0x20,14;    // LBIC_SIZE_RATIO_MIN[3:0]
    isp_write(ISP_LBFRC_BASE+0x21,15;    // LBIC_SIZE_RATIO_MAX[3:0]
    isp_write(ISP_LBFRC_BASE+0x22,0xFF &  (IN_HACT_LBFRC*12/2)             ;   // LBIC_LINE_SIZE
    isp_write(ISP_LBFRC_BASE+0x23,0x7F & ((IN_HACT_LBFRC*12/2) >> 8)       ;
    isp_write(ISP_LBFRC_BASE+0x24,0xFF &  (IN_HACT_LBFRC*12*14/16/2)       ;   // LBIC_LINE_LTHR0
    isp_write(ISP_LBFRC_BASE+0x25,0x7F & ((IN_HACT_LBFRC*12*14/16/2) >> 8) ;
    isp_write(ISP_LBFRC_BASE+0x26,0xFF &  (IN_HACT_LBFRC*12*3/2)           ;   // LBIC_LINE_LTHR1
    isp_write(ISP_LBFRC_BASE+0x27,0xFF & ((IN_HACT_LBFRC*12*3/2) >> 8)     ;
    isp_write(ISP_LBFRC_BASE+0x28,0x01 & ((IN_HACT_LBFRC*12*3/2) >> 16)    ;
    isp_write(ISP_LBFRC_BASE+0x29,0xFF &  (IN_HACT_LBFRC*12*4/2)           ;   // LBIC_LINE_LTHR2
    isp_write(ISP_LBFRC_BASE+0x2A,0xFF & ((IN_HACT_LBFRC*12*4/2) >> 8)     ;
    isp_write(ISP_LBFRC_BASE+0x2B,0x01 & ((IN_HACT_LBFRC*12*4/2) >> 16)    ;
    isp_write(ISP_LBFRC_BASE+0x2C,0xFF &  (IN_HACT_LBFRC*12*3/2/2)         ;   // LBIC_LINE_LTHR3_2
    isp_write(ISP_LBFRC_BASE+0x2D,0xFF & ((IN_HACT_LBFRC*12*3/2/2) >> 8)   ;
    isp_write(ISP_LBFRC_BASE+0x2E,12;            // LBIC_MEM0_LINE
    isp_write(ISP_LBFRC_BASE+0x2F,12;            // LBIC_MEM0_LINE
    */

    isp_write(ISP_LBFRC_BASE+0x50,0   );                      // MEM0_WADDR_E
    isp_write(ISP_LBFRC_BASE+0x51,0   );
    isp_write(ISP_LBFRC_BASE+0x52, 2880 *1/4     )  ;   // MEM0_WADDR_O
    isp_write(ISP_LBFRC_BASE+0x53, 2880 *1/4 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x54, 2880 *2/4     )  ;   // MEM1_WADDR_E
    isp_write(ISP_LBFRC_BASE+0x55, 2880 *2/4 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x56, 2880 *3/4     )  ;   // MEM1_WADDR_O
    isp_write(ISP_LBFRC_BASE+0x57, 2880 *3/4 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x58, 2880 *3/4     )  ;   // MEM_WADDR_MAX
    isp_write(ISP_LBFRC_BASE+0x59, 2880 *3/4 >> 8)  ;

    isp_write(ISP_LBFRC_BASE+0x5A,0   );                      // MEM0_RADDR_E
    isp_write(ISP_LBFRC_BASE+0x5B,0   );
    isp_write(ISP_LBFRC_BASE+0x5C, 2880 *1/4     )  ;   // MEM0_RADDR_O
    isp_write(ISP_LBFRC_BASE+0x5D, 2880 *1/4 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x5E, 2880 *2/4     )  ;   // MEM1_RADDR_E
    isp_write(ISP_LBFRC_BASE+0x5F, 2880 *2/4 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x60, 2880 *3/4     )  ;   // MEM1_RADDR_O
    isp_write(ISP_LBFRC_BASE+0x61, 2880 *3/4 >> 8)  ;
    isp_write(ISP_LBFRC_BASE+0x62, 2880 *3/4     )  ;   // MEM_RADDR_MAX
    isp_write(ISP_LBFRC_BASE+0x63, 2880 *3/4 >> 8)  ;

    isp_write(ISP_LBFRC_BASE+0x80,0x00);      // DECOMP_CLIP[6:4], DECOMP_EN[0]
    isp_write(ISP_LBFRC_BASE+0xA0, LBFRC_BASE0_ADDR     ) ;   // LBFRC_SDRAM0_ADDR_E
    isp_write(ISP_LBFRC_BASE+0xA1, LBFRC_BASE0_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xA2, LBFRC_BASE0_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xA3, LBFRC_BASE0_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xA4, LBFRC_MAX_ADDR     ) ;   // LBFRC_SDRAM0_ADDR_O
    isp_write(ISP_LBFRC_BASE+0xA5, LBFRC_MAX_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xA6, LBFRC_MAX_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xA7, LBFRC_MAX_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xA8, LBFRC_MAX_ADDR     ) ;   // LBFRC_SDRAM1_ADDR_E
    isp_write(ISP_LBFRC_BASE+0xA9, LBFRC_MAX_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xAA, LBFRC_MAX_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xAB, LBFRC_MAX_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xAC, LBFRC_MAX_ADDR     ) ;     // LBFRC_SDRAM1_ADDR_O
    isp_write(ISP_LBFRC_BASE+0xAD, LBFRC_MAX_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xAE, LBFRC_MAX_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xAF, LBFRC_MAX_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xB0, LBFRC_MAX_ADDR     ) ;     // LBFRC_SDRAM_ADDR_MAX
    isp_write(ISP_LBFRC_BASE+0xB1, LBFRC_MAX_ADDR >> 8) ;
    isp_write(ISP_LBFRC_BASE+0xB2, LBFRC_MAX_ADDR >> 16);
    isp_write(ISP_LBFRC_BASE+0xB3, LBFRC_MAX_ADDR >> 24);
    isp_write(ISP_LBFRC_BASE+0xB4,0x22);      // LBFRC_WBURST_CTRL[5:4], LBFRC_RBURST_CTRL[1:0]
    isp_write(ISP_LBFRC_BASE+0xB5,6   );
    isp_write(ISP_LBFRC_BASE+0xB6,6   );

    isp_write(ISP_LBFRC_BASE+0x00,0x01);  // LBIC_DPCM_MODE[6:5], LBIC_DPCM_ENABLE[4], LBIC_ENABLE[0]
}

