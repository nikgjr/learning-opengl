#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void YC_PROC_set (void)
{
	tdk_printf("YC PROCESS set\n");

    //==================================
    // Y Process
    //==================================
    isp_write(ISP_YCPROC_BASE+0x00,0x30);   // {2'd0,Y_PATH_EN,Y_ENHANCE_EN,3'd0,Y_GAMMA_EN}
//  isp_write(ISP_YCPROC_BASE+0x02,0x00);   // Y_GAIN[12:8]
    isp_write(ISP_YCPROC_BASE+0x01,0x80);   // Y_GAIN[7:0]
//  isp_write(ISP_YCPROC_BASE+0x04,0x00);   // Y_GAIN2[12:8]
    isp_write(ISP_YCPROC_BASE+0x03,0x80);   // Y_GAIN2[7:0]
//  isp_write(ISP_YCPROC_BASE+0x06,0x00);   // Y_OFFSET[9:8]
    isp_write(ISP_YCPROC_BASE+0x05,0x01);   // Y_OFFSET[7:0]
//  isp_write(ISP_YCPROC_BASE+0x08,0x00);   // Y_OFFSET2[9:8]
    isp_write(ISP_YCPROC_BASE+0x07,0x01);   // Y_OFFSET2[7:0]
    isp_write(ISP_YCPROC_BASE+0x09,0x01);   // Y_GAMMA_ALPHA

    //==================================
    // C Process
    //==================================
    isp_write(ISP_YCPROC_BASE+0x0A,0xC0);   // {C_PATH_EN[7],C_SAT_EN[6],C_SAT_BLACK[5],4'd0,C_GAMMA_EN}

    // HUE
    isp_write(ISP_YCPROC_BASE+0x0D,0x80);   // {C_HUE_EN, 7'd0}
//  isp_write(ISP_YCPROC_BASE+0x0E,0x00);   // C_HUE1
//  isp_write(ISP_YCPROC_BASE+0x0F,0x00);   // C_HUE2
//  isp_write(ISP_YCPROC_BASE+0x10,0x00);   // C_HUE3
//  isp_write(ISP_YCPROC_BASE+0x11,0x00);   // C_HUE4
//  isp_write(ISP_YCPROC_BASE+0x12,0x00);   // C_HUE5
//  isp_write(ISP_YCPROC_BASE+0x13,0x00);   // C_HUE6
    isp_write(ISP_YCPROC_BASE+0x14,0x80);   // C_HUE_GAIN1
    isp_write(ISP_YCPROC_BASE+0x15,0x80);   // C_HUE_GAIN2
    isp_write(ISP_YCPROC_BASE+0x16,0x80);   // C_HUE_GAIN3
    isp_write(ISP_YCPROC_BASE+0x17,0x80);   // C_HUE_GAIN4
    isp_write(ISP_YCPROC_BASE+0x18,0x80);   // C_HUE_GAIN5
    isp_write(ISP_YCPROC_BASE+0x19,0x80);   // C_HUE_GAIN6

    //SATURATION
    isp_write(ISP_YCPROC_BASE+0x0B,0x7F);   // CB_SAT_GAIN
    isp_write(ISP_YCPROC_BASE+0x0C,0x7F);   // CR_SAT_GAIN
}
