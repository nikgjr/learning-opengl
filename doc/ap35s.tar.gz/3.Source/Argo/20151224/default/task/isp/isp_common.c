void delay(int para)
{
    volatile int i = 0;
    volatile int delayPara = para;

    while(1)
    {
        if(i>delayPara)
            break;
        i++;
    }
}
