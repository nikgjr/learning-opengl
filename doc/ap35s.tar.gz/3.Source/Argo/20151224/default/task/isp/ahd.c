#include "isp_regmap.h"
#include "isp_env.h"
#include "isp_option.h"
#include "isp_param.h"

#include "../tdk/tdk.h"

void AHD_set()
{
	tdk_printf("AHD set\n");

    #if (ENV_SIZE == SIZE_1M_SET)
        #if(ENV_FPGA==ENV_FPGA_AHD_13M30P)
    // 1. 1280x720 Format   : Core 36Mhz, Sampling 144Mhz, FSC Freqz 3.579545
    // 1.1 30Hz
    isp_wrtie(ISP_AHD_BASE+0x00,0xDF);      // SUB_MODE[7:0]
    isp_wrtie(ISP_AHD_BASE+0x01,0xE0);      // SUB_FORMAT

    // 1.2 25Hz
//  isp_wrtie(ISP_AHD_BASE+0x00,0xDF);      // SUB_MODE[7:0]
//  isp_wrtie(ISP_AHD_BASE+0x01,0xE1);      // SUB_FORMAT
        #else
    // 1. 1280x720 Format   : Core 74.25Mhz, Sampling 148.5Mhz, FSC Freqz 3.579545
    // 1.1 60Hz
    isp_write(ISP_AHD_BASE+0x00,0xDF);      // SUB_MODE[7:0]
    isp_write(ISP_AHD_BASE+0x01,0xE4);      // SUB_FORMAT

    // 1.2 50Hz
//  isp_wrtie(ISP_AHD_BASE+0x00,0xDF);      // SUB_MODE[7:0]
//  isp_wrtie(ISP_AHD_BASE+0x01,0xE5);      // SUB_FORMAT
        #endif
    #else
    // 2. 1920x1080 Format  : Core 74.25Mhz, Sampling 148.5Mhz, FSC Freqz 3.579545
    // 2.1 NTSC : 2200x1125_30Hz
    isp_wrtie(ISP_AHD_BASE+0x00,0xDF);      // SUB_MODE[7:0]
    isp_wrtie(ISP_AHD_BASE+0x01,0xF0);      // SUB_FORMAT

    // 2.2 PAL : 2640x1125_25Hz
//  isp_wrtie(ISP_AHD_BASE+0x00,0xDF);      // SUB_MODE[7:0]
//  isp_wrtie(ISP_AHD_BASE+0x01,0xF1);      // SUB_FORMAT
    #endif
}
