/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tdk.h"
#include "tdk_prompt.h"

struct tdk_prompt_cmd g_prompt_cmd[50];
int g_prompt_count = 0;
char g_prompt_strign[80] = "CR4";

#if 1
char *tdk_prompt_do(const char *command_string)
{
	char *token;
	char *argv[10];
	char *cmd;
	char delimeter[] = "\r\n ";
	char str[512];

	int argc = 0;
	struct tdk_prompt_cmd* commands = NULL;

	strcpy(str, command_string);
	memset(argv, 0, sizeof(argv));

	argc = 0;
	token = strtok(str, delimeter);
	while (token != NULL && argc < 10)
	{
		argv[argc] = token;
		argc++;
		token = strtok(NULL, delimeter);
	}
	cmd = argv[0];

	if (argc == 0)
		return NULL;

	if (strcmp(cmd, "exit") == 0 || strcmp(cmd, "quit")==0 || strcmp(cmd, "help") == 0)
	{
		return cmd;
	}

	commands = tdk_prompt_get_command(cmd);
	if (commands != NULL)
	{
		argv[9] = (char*)commands;
		commands->func(argc, argv);
	}
	else
	{
		return NULL;
	}

	return cmd;
}

void tdk_prompt(void)
{
	char buffer[512] = { 0 };

	int loop = 1;
	char *cmd;

	while(loop)
	{
		tdk_printf("%s> ", g_prompt_strign);
//		fgets(buffer, sizeof(buffer), stdin);
		tdk_gets(buffer);

		if(strlen(buffer) == 0)
		{
			continue;
		}

		cmd = tdk_prompt_do(buffer);

		if(cmd == NULL)
		{
			tdk_printf("Unknown Command = %s\n", buffer);
			continue;
		}

		if(strcmp(cmd, "exit")==0 || strcmp(cmd, "quit")==0)
		{
			loop = 0;
			continue;
		}

		if(strcmp(cmd, "help")==0)
		{
			tdk_prompt_help();
		}
	}
}

void tdk_prompt_setprompt(const char *prompt)
{
	strcpy(g_prompt_strign, prompt);
}

void tdk_prompt_init(struct tdk_prompt_cmd *cmds, int count)
{
	int i;
	g_prompt_count = 0;
	for(i=0; i<count; i++)
	{
		g_prompt_cmd[g_prompt_count] = cmds[i];
		g_prompt_count++;
	}
}

void tdk_prompt_add(struct tdk_prompt_cmd *cmd)
{
	g_prompt_cmd[g_prompt_count] = *cmd;
	g_prompt_count++;
}


void tdk_prompt_help(void)
{
	int i;
	
	tdk_printf("usage:\n");
	tdk_printf("\tcmmand [args...]\n");
	tdk_printf("command help\n");
	
	for(i=0; i<g_prompt_count; i++)
	{
//		tdk_printf("[%3d] cmd=%-30s func=0x%08x\n", i, g_prompt_cmd[i].cmd, g_prompt_cmd[i].func);
		tdk_printf("[%3d] cmd=%-30s %s\n", i, g_prompt_cmd[i].cmd, g_prompt_cmd[i].help);
	}
}

struct tdk_prompt_cmd* tdk_prompt_get_command(const char *str)
{
	int i;

	for(i=0; i<g_prompt_count; i++)
	{
		if(strcmp(g_prompt_cmd[i].cmd, str) == 0)
		{
			if(g_prompt_cmd[i].func)
			{
				return &g_prompt_cmd[i];
			}
		}
	}
	return NULL;
}
#endif
