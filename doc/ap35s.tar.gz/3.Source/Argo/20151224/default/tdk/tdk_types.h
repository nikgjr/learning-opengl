/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#ifndef __TDK_TYPE_H__
#define __TDK_TYPE_H__

typedef unsigned long long      UINT64;
typedef unsigned int            UINT32;
typedef unsigned short          UINT16;
typedef unsigned char           UINT8;
typedef unsigned char           BOOL;
                                        
typedef signed long long        INT64;
typedef signed int              INT32;
typedef signed short            INT16;
typedef signed char             INT8;

typedef unsigned long long      u64;
typedef unsigned int			u32;
typedef unsigned short			u16;
typedef unsigned char			u08;
typedef unsigned char			u8;
typedef signed int				s32;
typedef signed short			s16;
typedef signed char				s08;
typedef signed char				s8;
typedef int						bool;
typedef unsigned int			dma_addr_t;

typedef unsigned char			uchar;
typedef unsigned short			ushort;
typedef unsigned int			uint;
typedef unsigned long			u_long;

typedef unsigned long int		ulong;
typedef ulong lbaint_t;

#ifndef __inline__
#define __inline__
#endif

#ifndef inline
#define inline
#endif


#ifndef TRUE
#define TRUE        1
#endif

#ifndef FALSE
#define FALSE       0
#endif

#ifndef true
#define true        1
#endif

#ifndef false
#define false       0
#endif


#ifndef NULL
#define NULL        0
#endif

#ifndef TDK_FILE
#define TDK_FILE	int
#endif

#define NOT_USE		0

#ifdef __RVDS__
typedef 	unsigned int	tdk_addr;
#elif defined(__GCC__)
typedef 	unsigned int	tdk_addr;
#else
typedef 	void *			tdk_addr;
#endif


#endif /* __TDK_TYPE_H__ */

