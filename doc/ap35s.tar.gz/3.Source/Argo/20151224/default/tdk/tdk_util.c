/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tdk.h"
#include "tdk_util.h"

#ifndef tdk_printf
#define tdk_printf printf
#endif

#ifndef tdk_fprintf
#define	tdk_fprintf(...)
#endif

u32 basic_reg_read(tdk_addr addr)
{
	return *(volatile u32 *)addr;
}

void basic_reg_write(tdk_addr addr, u32 data)
{
	*(volatile u32 *)addr = data;
}

u32 reg_wait_status(u32 addr, u32 flag, int timeout)
{
	u32 status;

	while(timeout)
	{
		status = reg_read(addr);
		if(status & flag) break;
		timeout--;
	}

	if(timeout==0)	return 0xffffffff;

	return status;
}

u32 reg_wait_clear(u32 addr, u32 flag, int timeout)
{
	u32 status;

	while(timeout)
	{
		status = reg_read(addr);
		if((status&flag)==0x0) break;
		timeout--;
	}

	if(timeout==0)	return 0xffffffff;

	return status;
}


struct tdk_util_ops basic_ops = { NULL, basic_reg_read, basic_reg_write };

/*
unsigned short REG_READ16_FUNC(tdk_addr addr)
{
	return 0;
}
void REG_WRITE16_FUNC(tdk_addr addr, u32 data)
{
}

u32 REG_READ_FUNC(tdk_addr addr)
{
	u32 data = AMLOW_RegRead((u32)addr);
	tdk_printf("\tRX:Addr=0x%08x Data=0x%08x\n", addr, data);
	return data;
}

void REG_WRITE_FUNC(tdk_addr addr, u32 data)
{
	tdk_printf("\tTX:Addr=0x%08x Data=0x%08x\n", addr, data);
	AMLOW_RegWrite((u32)addr, data);
}
*/

int tdk_is_hex_string(const char *str)
{
	int len = strlen(str);
	if(len<3) return 0;

	if(str[0]=='0' && (str[1]=='x'||str[1]=='X'))
	{
		return 1;
	}
	return 0;
}

int tdk_is_oct_string(const char *str)
{
	return (strlen(str)>2 && str[0]=='0');
}

int tdk_is_bin_string(const char *str)
{
	int len = strlen(str);
	if(len<3) return 0;

	if(str[0]=='0' && (str[1]=='b'||str[1]=='B'))
	{
		return 1;
	}
	return 0;
}

int tdk_get_radix(const char *str)
{
	int radix;

	if(tdk_is_hex_string(str))
	{
		radix = 16;
	}
	else if(tdk_is_bin_string(str))
	{
		radix = 2;
	}
	else if(tdk_is_oct_string(str))
	{
		radix = 8;
	}
	else
	{
		radix = 10;
	}

	return radix;
}

u32 tdk_string_to_value(const char *str)
{
	int radix;
	char *ptr;
	u32 value;
	int offset = 0;

	if(str == NULL)		return 0;
	if(strlen(str)==0)	return 0;

	radix = tdk_get_radix(str);

	if(radix==2) offset = 2;
	value = strtoul(str+offset, &ptr, radix);

	if(strlen(ptr))
	{
		tdk_printf("remain string = %s\n", ptr);
		value = 0xffffffff;
	}

	return value;
}

/**
 *integer 값을 binary로 string변수에 출력 합니다.
 * @param i 출력할 integer 값
 * @return binary가 저장된 string변수
 */
char *tdk_value_to_bit_string(u32 i)
{
	static char str[32+1] = {'0',};
	int count =32;
	do
	{
		str[--count] = '0' + (char) (i&1);
		i=i>>1;
	}while(count);
	str[32] = '\0';
	return str;
}

int tdk_get_bit_string(char *buffer, u32 value, int start, int end)
{
	int length=start-end+1;
	int i;

	if(length<=0) return 0;

	for(i=start; i>=end; i--)
	{
		*buffer++ = '0' + ((value&(1<<i)) ? 1 : 0) ;
	}
	*buffer++ = ' ';
	*buffer++ = 0;

	return length+1;
}

char *tdk_value_to_binary_string(void *data, int bitLength)
{
	static char buffer[256+1] = { 0 };
	u32 *uint_buffer = (u32 *)data;
	char *str = buffer;
	int count = bitLength/32;
	int i;
//	str += sprintf(str, "0b");

	for(i=0; i<count; i++)
	{
		str += sprintf(str, "%s|", tdk_value_to_bit_string(uint_buffer[count-i-1]));
	}
	return buffer;
}



void tdk_dump08(tdk_addr addr, u32 bytes, struct tdk_util_ops *param)
{
	u32 i, j;
	unsigned char *pMem;
	int item_per_line=16;

	addr = addr/16*16;
	pMem = (unsigned char *)addr;

	if(param && param->fp)
	{
		for(i=0; i<bytes; i++)
		{
			if(i%item_per_line == 0) tdk_fprintf(param->fp, "0x%08x: ", (u32)(unsigned long)i);
			tdk_fprintf(param->fp, "%02x ", pMem[i]);
			if((i+1)%item_per_line == 0) tdk_fprintf(param->fp, "\n");
		}
		if(i%item_per_line != 0) 	tdk_fprintf(param->fp, "\n");
	}
	else
	{
		tdk_printf("\n");
		for (i=0; i<bytes;)
		{
			tdk_printf("0x%08x: ", (u32)(unsigned long)pMem);

			for (j=0; j<16 && i<bytes; j++)
			{
				tdk_printf("%02x ", *pMem++);
				i++;
			}
			tdk_printf("\n");
		}
	}
}

void tdk_dump16(tdk_addr addr, u32 hwords, struct tdk_util_ops *param)
{
	u32 i, j;
	unsigned short *pMem;
	int item_per_line=8;

	pMem = (unsigned short *)addr;

	if(param && param->fp)
	{
		for (i=0; i<hwords; i++)
		{
			if(i%item_per_line == 0) tdk_fprintf(param->fp, "0x%08x: ", (u32)(unsigned long)i);
			
			for (j=0; j<8; j++)
				tdk_fprintf(param->fp, "%04x ", *pMem++);
			if((i+1)%item_per_line == 0) tdk_fprintf(param->fp, "\n");
		}
		if(i%item_per_line != 0) 	tdk_fprintf(param->fp, "\n");
	}
	else
	{
		tdk_printf("\n");
		for (i=0; i<hwords;)
		{
			tdk_printf("0x%08x: ", (u32)(unsigned long)pMem);

			for (j=0; j<8 && i<hwords; j++)
			{
				tdk_printf("%04x ", *pMem++);
				i++;
			}
			tdk_printf("\n");
		}
	}
}

void tdk_dump16_2d(tdk_addr addr, int cx, int cy, struct tdk_util_ops *param)
{
	unsigned short **pMem = (unsigned short **)addr;
	int count=cx*cy;
	int i;
	int item_per_line=8;
	
	if(param && param->fp)
	{
		for (i=0; i<count; i++)
		{
			if(i%item_per_line == 0) tdk_fprintf(param->fp, "0x%08x: ", (u32)(unsigned long)i);
			tdk_fprintf(param->fp, "%04x ", pMem[i/cx][i%cx]);
			if((i+1)%item_per_line == 0) tdk_fprintf(param->fp, "\n");
		}
		if(i%item_per_line != 0) 	tdk_fprintf(param->fp, "\n");
	}
	else
	{
		for (i=0; i<count; i++)
		{
			if(i%item_per_line == 0) tdk_printf("0x%08x: ", (u32)(unsigned long)i);
			tdk_printf("%04x ", pMem[i/cx][i%cx]);
			if((i+1)%item_per_line == 0) tdk_printf("\n");
		}
		if(i%item_per_line != 0) 	tdk_printf("\n");
	}
}

void tdk_dump32(tdk_addr addr, u32 words, struct tdk_util_ops *param)
{
	u32 i, j;
	u32 *pMem;
	if(param == NULL) param = &basic_ops;

	addr = addr/16*16;
	pMem = (u32 *)addr;

	if(param && param->fp)
	{
		for (i=0; i<words;)
		{
			tdk_fprintf(param->fp, "0x%08x: ", (u32)(unsigned long)i);
			
			for (j=0; j<4; j++)
			{
				if(param && param->read)
				{
					tdk_fprintf(param->fp, "%08x ", param->read((tdk_addr)pMem));
				}
				else
				{
					tdk_fprintf(param->fp, "%08x ", *pMem);
				}
				pMem++;
				i++;
			}
			tdk_fprintf(param->fp, "\n");
		}
		if(words%4 != 0) tdk_fprintf(param->fp, "\n");
	}
	else
	{
		tdk_printf("\n");

		for (i=0; i<words;)
		{
			tdk_printf("0x%08x: ", (u32)(unsigned long)pMem);

			for (j=0; j<4; j++)
			{
				if(param && param->read)
				{
					tdk_printf("%08x ", param->read((tdk_addr)pMem));
				}
				else
				{
					tdk_printf("%08x ", *pMem);
				}
				pMem++;
				i++;
			}
			tdk_printf("\n");
		}
	}
}

void tdk_dump32_ex(tdk_addr addr, u32 words, struct tdk_util_ops *param)
{
	u32 i, j;
	u32 *pMem;
	pMem = (u32 *)addr;

	// Loop를 돌면서 메모리 내용을 출력한다.
	tdk_printf("\n");

	for (i=0; i<words;)
	{
		tdk_printf("0x%08x: ",(u32)(unsigned long)pMem);

		for (j=0; j<4; j++)
		{
			if(param && param->read)
			{
				tdk_printf("%08x ", param->read((tdk_addr)pMem));
			}
			else
			{
				tdk_printf("%08x ", *pMem);
			}
			pMem++;
			i++;
		}
		tdk_printf("\n");
	}
}

int tdk_verify08(u32 src, u32 dst, u32 count)
{
    u32 i;
    UINT8 *pSrc, *pDst;

    pSrc = (UINT8 *)src;
    pDst = (UINT8 *)dst;

    for(i=0; i<count; i++)
    {
        if(*pSrc++ != *pDst++)
        {
            tdk_printf("Fail addr:0x%08x, src data:0x%02x, dst dat:0x%02x\n", (u32)(pDst-1), *(pSrc-1), *(pDst-1));
            break;
        }
    }

    return (i != count);
}


int tdk_verify32(u32 src, u32 dst, u32 count)
{
    u32 i;
    u32 *pSrc, *pDst;

    pSrc = (u32 *)src;
    pDst = (u32 *)dst;

    for(i=0; i<count; i++)
    {
        if(*pSrc++ != *pDst++)
        {
            tdk_printf("Fail addr:0x%08x, src data:0x%08x, dst dat:0x%08x\n", (u32)(pDst-1), *(pSrc-1), *(pDst-1));
            break;
        }
    }

    return (i != count);
}


#define TDK_MEM_DEBUG
#define SIMULATOR
#ifdef SIMULATOR
#define xtbsp_board_name()					"mango board"
#define xtbsp_display_string(fmt, ...)		tdk_printf(fmt "\n", ##__VA_ARGS__)
#endif

#define isPrintMessage(addr)	((u32)(addr)|0xffff0000)==0xffff0000

int tdk_addr_mem_test(u32 *start_addr, u32 *end_addr, struct tdk_util_ops *param)
{
	u32 *mem_ptr;
	int pass_fail = 1;
	u32 data;

	if(param == NULL) param = &basic_ops;

#ifdef TDK_MEM_DEBUG
	tdk_printf("\n%s address test from %p to %p\n", xtbsp_board_name(), start_addr, end_addr);
#endif
	for (mem_ptr = (u32 *) start_addr; mem_ptr < (u32 *) end_addr; mem_ptr++)
	{
		param->write((tdk_addr)mem_ptr, (unsigned long) mem_ptr);
#ifdef TDK_MEM_DEBUG
		if (isPrintMessage((unsigned long)mem_ptr))
		{
			tdk_printf("\r %p w",mem_ptr);
		}
#endif
	}
	for (mem_ptr = (u32 *) start_addr; mem_ptr < (u32 *) end_addr; mem_ptr++)
	{
		data = param->read((tdk_addr)mem_ptr);
		if ((unsigned long)mem_ptr != data)
		{
#ifdef TDK_MEM_DEBUG
			tdk_printf("\n %p bad memory %x, %x\n",mem_ptr, data, param->read((tdk_addr)mem_ptr));
#endif
			pass_fail = 0;
			break;
		}
#ifdef TDK_MEM_DEBUG
		if (isPrintMessage((unsigned long)mem_ptr))
		{
			tdk_printf("\r %p r",mem_ptr);
		}
#endif
	}
#ifdef TDK_MEM_DEBUG
	if (pass_fail)
		tdk_printf(" OK");
	else
		tdk_printf(" Fail");
#endif
	return (pass_fail);
}

/***************************************************************************/
int tdk_mem_test_patterns(u32 *start_addr, u32 *end_addr, u32 mem_pattern, struct tdk_util_ops *param)
{
	u32 *mem_ptr;
	int pass_fail = 1;
#ifdef TDK_MEM_DEBUG
	tdk_printf("\n%s memtest from %p to %p with pattern %X\n", xtbsp_board_name(), start_addr, end_addr, mem_pattern);
#endif
	for (mem_ptr = (u32 *) start_addr; mem_ptr < (u32 *) end_addr; mem_ptr++)
	{
#ifdef TDK_MEM_DEBUG
		if (isPrintMessage((unsigned long)mem_ptr))
		{
			tdk_printf("\r %p w",mem_ptr);
		}
#endif
		param->write((tdk_addr)mem_ptr, mem_pattern);
	}
	for (mem_ptr = (u32 *) start_addr; mem_ptr < (u32 *) end_addr; mem_ptr++)
	{
#ifdef TDK_MEM_DEBUG
		if (isPrintMessage((unsigned long)mem_ptr))
		{
			tdk_printf("\r %p r",mem_ptr);
		}
#endif
		if ((u32) mem_pattern != param->read((tdk_addr)mem_ptr))
		{
#ifdef TDK_MEM_DEBUG
			tdk_printf("\n %p bad memory %X\n",mem_ptr,param->read((tdk_addr)mem_ptr));
#endif
			pass_fail = 0;
			break;
		}
	}
#ifdef TDK_MEM_DEBUG
	if (pass_fail)
		tdk_printf(" OK\n");
	else
		tdk_printf(" Failed\n");
#endif
	return (pass_fail);
}

int tdk_mem_test(u32 addr, int size)
{
	int count;
	int i;
	u32 value;
	u32 tmp;

	count = size/4;

	for(i=0; i<count; i++)
	{
		reg_write(addr+i*4, i+1);
		reg_write(addr+0x1000+i*4, 0);
	}
	for(i=0; i<count; i++)
	{
		value =  reg_read(addr+i*4);
		tmp = reg_read(addr+0x1000+i*4);
		if(value != (i+1))
		{
			tdk_printf("memtest:32bit:address=0x%08x, 0x%08x, 0x%08x\n", i+1, value);
			return -1;
		}
	}

	count = size/2;
	for(i=0; i<count; i++)
	{
		reg_write16(addr+i*2, i+1);
		reg_write16(addr+0x1000+i*2, 0);
	}
	for(i=0; i<count; i++)
	{
		value =  reg_read16(addr+i*2);
		tmp =  reg_read16(addr+0x1000+i*2);
		if(value != (i+1))
		{
			tdk_printf("memtest:16bit:address=0x%08x, 0x%08x, 0x%08x\n", i+1, value);
			return -1;
		}
	}

	count = size;
	for(i=0; i<count; i++)
	{
		reg_write8(addr+i, i+1);
		reg_write8(addr+0x1000+i, 0);
	}
	for(i=0; i<count; i++)
	{
		value =  reg_read8(addr+i);
		tmp = reg_read8(addr+0x1000+i);
		if(value != (i+1))
		{
			tdk_printf("memtest:08bit:address=0x%08x, 0x%08x, 0x%08x\n", i+1, value);
			return -1;
		}
	}
	return 0;
}

u32 tdk_cal_checksum(void *buffer, int size, u32 init_value)
{
	u32 sum = init_value;
	int count = size/4;
	u32 *ptr = (u32*)buffer;
	int i;

	for(i=0; i<count; i++)
	{
		sum += *ptr++;
	}
	return sum;
}

u32 tdk_sum(void *buffer, int size, int type, u32 init_value)
{
	u32 sum = init_value;
	int count = size/type;
	int i;
	switch(type)
	{
		case 1:
		{
			unsigned char *ptr = (unsigned char*)buffer;

			for(i=0; i<count; i++)
			{
				sum += *ptr++;
			}
		}
		break;
		case 2:
		{
			unsigned short *ptr = (unsigned short*)buffer;

			for(i=0; i<count; i++)
			{
				sum += *ptr++;
			}
		}
		break;
		case 4:
		{
			u32 *ptr = (u32*)buffer;

			for(i=0; i<count; i++)
			{
				sum += *ptr++;
			}
		}
		break;
	}
	return sum;
}

u32 tdk_wrap_sum(void *buffer, int size, int type, u32 init_value, int wrap_size)
{
	u32 sum = init_value;
	int count = size/type;
	int i;

	u32 base = (u32)buffer/wrap_size*wrap_size;
	u32 offset = (u32)buffer%wrap_size;
	u32 mask = wrap_size-1;

	switch(type)
	{
		case 1:
		{
			for(i=0; i<count; i++)
			{
//				tdk_printf("0x%08x ", base+((offset+i)&mask));
//				if((i+1)%8==0) tdk_printf("\n");
				sum += *(unsigned char *)(base+((offset+i)&mask));
			}

//			tdk_printf("base=0x%08x\n", base);
		}
		break;
	}
	return sum;
}


void MEM_LOOP_EX2(int index, int count, u32 *dst,u32 *src)
{												
	int loop = MEM_LOOP_GET_COUNT(count);		
	for(index=0; index<loop; index++)			
	{											
		*(dst)++ = *(src)++;
		*(dst)++ = *(src)++;
		*(dst)++ = *(src)++;
		*(dst)++ = *(src)++;					

		*(dst)++ = *(src)++;
		*(dst)++ = *(src)++;
		*(dst)++ = *(src)++;
		*(dst)++ = *(src)++;					

		*(dst)++ = *(src)++;
		*(dst)++ = *(src)++;
		*(dst)++ = *(src)++;
		*(dst)++ = *(src)++;					

		*(dst)++ = *(src)++;
		*(dst)++ = *(src)++;
		*(dst)++ = *(src)++;
		*(dst)++ = *(src)++;					
	}											
	loop = count%MEM_LOOP_LINE_SIZE;			
	for(index=0; index<loop; index++)			
	{											
		*(dst)++ = *(src)++;					
	}
}

#define MAX_PERF_COUNT		10
struct tdk_perf_info g_perf_info[MAX_PERF_COUNT];
volatile u32 tdk_perf_count=0;

void tdk_perf_init(void)
{
	memset(g_perf_info, 0x0, sizeof(g_perf_info));
	tdk_perf_count=0;
}

u32 tdk_perf_get_count(void)
{
	return tdk_perf_count;
}

u32 tdk_perf_get_id(int index)
{
	if(index>=MAX_PERF_COUNT) return 0xffffffff;
	return g_perf_info[index].id;
}

u32 tdk_perf_get_tick(int index)
{
	if(index>=MAX_PERF_COUNT) return 0xffffffff;
	return g_perf_info[index].tick;
}

void tdk_perf_printf(void)
{
	int i;
	for(i=0; i<tdk_perf_count; i++)
	{
		tdk_printf("[%4d] ID=0x%08x, TICK=0x%08x\n", i, g_perf_info[i].id, g_perf_info[i].tick);
//		__SIM_DEBUG_REG(SIM_DEBUG_WRITE, g_perf_info[i].id);
//		__SIM_DEBUG_REG(SIM_DEBUG_READ, g_perf_info[i].tick);
	}
}

void tdk_perf_add(u32 id)
{
	u32 index=tdk_perf_count;

	if(tdk_perf_count>MAX_PERF_COUNT) return ;

	tdk_perf_count++;
	g_perf_info[index].id = id;
//	g_perf_info[index].tick = rSYSCON_TICK_COUNTER;
}

