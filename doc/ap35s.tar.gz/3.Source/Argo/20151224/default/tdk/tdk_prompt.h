/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/
#ifndef __PROMPT___
#define __PROMPT___

typedef int (*prompt_callback_func)(int argc, char *argv[]);

struct tdk_prompt_cmd
{
	const char *cmd;
	prompt_callback_func func;
	const char *help;
};

void tdk_prompt_setprompt(const char *prompt);
void tdk_prompt_init(struct tdk_prompt_cmd *cmds, int count);
void tdk_prompt_add(struct tdk_prompt_cmd *cmd);
void tdk_prompt_help(void);
struct tdk_prompt_cmd* tdk_prompt_get_command(const char *str);
char *tdk_prompt_do(const char *str);
void tdk_prompt(void);

#endif
