/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#ifndef __TDK_UTIL__
#define __TDK_UTIL__

#include "tdk_types.h"


#define		REG_CALL_FUNC		0
#define 	TDK_TIMEOUT			0xffffffff

struct tdk_util_ops
{
	TDK_FILE *fp;
	u32 (*read)(tdk_addr addr);
	void (*write)(tdk_addr addr, u32 data);
};

#if REG_CALL_FUNC
unsigned short REG_READ16_FUNC(tdk_addr addr);
void REG_WRITE16_FUNC(tdk_addr addr, u32 data);
u32 REG_READ_FUNC(tdk_addr addr);
void REG_WRITE_FUNC(tdk_addr addr, u32 data);

#define reg_read16(addr)		REG_READ_FUNC((u32)(addr))
#define reg_write16(addr,data)	REG_WRITE_FUNC((u32)(addr), data)

#define reg_read(addr)			REG_READ_FUNC((u32)(addr))
#define reg_write(addr,data)	REG_WRITE_FUNC((u32)(addr), data)


#else
#define reg_read8(addr)				*((volatile unsigned char *)(addr))
#define reg_write8(addr, data)		*((volatile unsigned char *)(addr))=(data)
#define reg_read16(addr)			*((volatile unsigned short *)(addr))
#define reg_write16(addr, data)		*((volatile unsigned short *)(addr))=(data)
#define reg_read(addr)				*((volatile u32 *)(addr))
#define reg_write(addr, data)		*((volatile u32 *)(addr))=(data)
#define reg_read64(addr)			*((volatile u64 *)(addr))
#define reg_write64(addr, data)		*((volatile u64 *)(addr))=(data)
#define reg_verify(addr, data)		reg_read((addr))!=(data)

#define readl(addr)				*((volatile u32 *)(addr))
#define readw(addr)				*((volatile u16 *)(addr))
#define readb(addr)				*((volatile u8 *)(addr))

#define writel(data, addr)		*((volatile u32 *)(addr))=(data)
#define writew(data, addr)		*((volatile u16 *)(addr))=(data)
#define writeb(data, addr)		*((volatile u8 *)(addr))=(data)
#endif
u32 reg_wait_status(u32 addr, u32 flag, int timeout);
u32 reg_wait_clear(u32 addr, u32 flag, int timeout);

#define		TDK_RADIX_HEXA		16
#define 	TDK_RADIX_DECIAML	10
#define		TDK_RADIX_OCTAL		8
#define 	TDK_RADIX_BINARY	2

#define tdk_boolean_to_string(cond)		(cond) ? "OK" : "FAIL"

int tdk_is_hex_string(const char *str);
int tdk_is_oct_string(const char *str);
int tdk_is_bin_string(const char *str);

int tdk_get_radix(const char *str);
u32 tdk_string_to_value(const char *str);
char *tdk_value_to_bit_string(u32 i);
int tdk_get_bit_string(char *buffer, u32 value, int start, int end);
char *tdk_value_to_binary_string(void *data, int bitLength);
#define tdk_get_print_char(ch) (isprint((ch)) ? ch : '.')

void tdk_dump08(tdk_addr addr, u32 bytes, struct tdk_util_ops *param);
void tdk_dump16(tdk_addr addr, u32 bytes, struct tdk_util_ops *param);
void tdk_dump16_2d(tdk_addr addr, int cx, int cy, struct tdk_util_ops *param);
void tdk_dump32(tdk_addr addr, u32 words, struct tdk_util_ops *param);

int tdk_addr_mem_test(u32 *start_addr, u32 *end_addr, struct tdk_util_ops *param);
int tdk_mem_test_patterns(u32 *start_addr, u32 *end_addr, u32 mem_pattern, struct tdk_util_ops *param);
int tdk_mem_test(u32 addr, int size);

u32 tdk_cal_checksum(void *buffer, int size, u32 init_value);
u32 tdk_sum(void *buffer, int size, int type, u32 init_value);
u32 tdk_wrap_sum(void *buffer, int size, int type, u32 init_value, int wrap_size);

int tdk_verify08(u32 src, u32 dst, u32 count);
int tdk_verify32(u32 src, u32 dst, u32 count);

/*
루프단위
	4		8		16		32		64		128		256
	3		7		15		31		53		127		255
	2		3		4		5		6		7		8
*/

#define MEM_LOOP_LINE_SIZE		16
#define MEM_LOOP_LINE_OFFSET	15
#define MEM_LOOP_LINE_SHIFT		4
#define MEM_LOOP_GET_COUNT(x)	(((x)+MEM_LOOP_LINE_OFFSET)>>MEM_LOOP_LINE_SHIFT)

#define MEM_LOOP(index,count,dst,src)			\
	for(index=0; index<count; index++)			\
	{											\
		*(dst)++ = *(src)++;					\
	}											

#define MEM_LOOP_EX		MEM_LOOP_EX16

#define MEM_LOOP_EX16(index,count,dst,src)		\
{												\
	int loop = MEM_LOOP_GET_COUNT(count);		\
	for(index=0; index<loop; index++)			\
	{											\
		*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;					\
		*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;					\
		*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;					\
		*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;					\
	}											\
	loop = count%MEM_LOOP_LINE_SIZE;			\
	for(index=0; index<loop; index++)			\
	{											\
		*(dst)++ = *(src)++;					\
	}											\
}


#define MEM_LOOP_EX32(index,count,dst,src)		\
{												\
	int loop = MEM_LOOP_GET_COUNT(count);		\
	for(index=0; index<loop; index++)			\
	{											\
		*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;					\
		*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;					\
		*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;					\
		*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;					\
		*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;					\
		*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;					\
		*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;					\
		*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;	*(dst)++ = *(src)++;					\
	}											\
	loop = count%MEM_LOOP_LINE_SIZE;			\
	for(index=0; index<loop; index++)			\
	{											\
		*(dst)++ = *(src)++;					\
	}											\
}

void MEM_LOOP_EX2(int index, int count, u32 *dst,u32 *src);

#define TDK_HTONS(n) (((((unsigned short)(n) & 0xFF)) << 8) | (((unsigned short)(n) & 0xFF00) >> 8))
#define TDK_NTOHS(n) (((((unsigned short)(n) & 0xFF)) << 8) | (((unsigned short)(n) & 0xFF00) >> 8))

#define TDK_HTONL(n) (((((unsigned long)(n) & 0xFF)) << 24) | \
                  ((((unsigned long)(n) & 0xFF00)) << 8) | \
                  ((((unsigned long)(n) & 0xFF0000)) >> 8) | \
                  ((((unsigned long)(n) & 0xFF000000)) >> 24))

#define TDK_NTOHL(n) (((((unsigned long)(n) & 0xFF)) << 24) | \
                  ((((unsigned long)(n) & 0xFF00)) << 8) | \
                  ((((unsigned long)(n) & 0xFF0000)) >> 8) | \
                  ((((unsigned long)(n) & 0xFF000000)) >> 24))

struct tdk_perf_info
{
	u32 id;
	u32 tick;
};

void tdk_perf_init(void);
void tdk_perf_printf(void);
void tdk_perf_add(u32 id);
u32 tdk_perf_get_count(void);
u32 tdk_perf_get_id(int index);
u32 tdk_perf_get_tick(int index);

#endif
