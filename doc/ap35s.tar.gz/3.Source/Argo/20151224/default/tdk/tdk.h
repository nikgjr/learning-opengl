/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#ifndef __TDK__
#define __TDK__

#ifndef inline
#define inline
#endif



//*
#define		USEC	48
#define		MS		48000
#define		S		48000000

#define		KB		1024
#define 	MB		0x100000

#define		MHz		1000000

#define 	BYTE2MBIT(byte)		((byte)*8.0/MB)
#define		BYTE2KBIT(byte)		((byte)*8.0/KB)

#define 	BYTE2MBYTE(byte)	((float)(byte)/MB)
#define 	BYTE2KBYTE(byte)	((float)(byte)/KB)
#define 	US2SEC(us)			((float)(us)/S)
#define		US2MSEC(us)			((float)(us)/MS)

#define		MBITPERUSEC(byte,usec)	BYTE2MBIT(byte)/US2SEC(usec)
#define		MBITPERSEC(byte,sec)	BYTE2MBIT(byte)/(float)usec

#define		MBYTEPERUSEC(byte,usec)	BYTE2MBYTE(byte)/US2SEC(usec)
#define		MBYTEPERSEC(byte,sec)	BYTE2MBYTE(byte)/(float)usec


#if _TDK_PLATFORM_==TDK_PLATFORM_R4
//#define TDK_PL011
#define TDK_PLATFORM_STRING		"TDK_PLATFORM_R4"
#endif


#ifdef BUILD_LINUX
#define TDK_STDIO
#define TDK_EMULATOR
#endif

#ifdef TDK_DEBUG

#ifdef WIN32
	//#define tdk_message					g_lpszDebugFileName=__FILE__;g_iDebugLine=__LINE__; ::JFTrace
	//#define tdk_error					::AfxTrace(_T("%s(%d) "), __FILE__, __LINE__); ::AfxTrace
	#define tdk_printf						printf
	#define tdk_error						printf
#else
	#if defined(TDK_EMULATOR) || defined(TDK_STDIO)
aa
		#define tdk_message					printf
		#define tdk_printf					printf
		#define tdk_error					printf
		#define tdk_gets					gets
		#define tdk_getchar					getchar
		#define tdk_getch					getchar
		#define tdk_putchar					putchar
		#define tdk_putch					putchar
	#elif defined(TDK_NEW_UART)
bb
		#define tdk_message					UART_Printf
		#define tdk_printf					UART_Printf
		#define tdk_error					UART_Printf
		#define printf 						UART_Printf
		#define tdk_gets					UART_Gets
		#define tdk_getchar()				UART_GetChar(UART0)
		#define tdk_getch					UART_GetChar(UART0)
	#elif defined(TDK_PL011)
cc
		#define tdk_message					PUART_Printf
		#define tdk_printf					PUART_Printf
		#define tdk_error					PUART_Printf
//		#define printf 						PUART_Printf
		#define tdk_gets					PUART_Gets
		#define tdk_getchar()				PUART_GetChar(UART0)
		#define tdk_getch					PUART_GetChar(UART0)
		#define tdk_putchar(ch)				PUART_PutChar(UART0, (ch))
		#define tdk_uart_test()				PUART_IsRXBufferReady(UART0)
	#else
		#define tdk_message					uart_printf
		#define tdk_printf					uart_printf
		#define tdk_error					uart_printf
		#define tdk_puts					uart_puts
//		#define printf 						UART_Printf
		#define tdk_gets					uart_gets
		#define tdk_getchar()				uart_getchar(UART0)
		#define tdk_getch()					uart_getchar(UART0)
		#define tdk_putchar(ch)				uart_putchar(UART0, (ch))
		#define tdk_uart_test()				uart_test()
	#endif
#endif

#else   // TDK_DEBUG

#if _MSC_VER >= 1400
#define tdk_printf					(__noop)
#define tdk_error						(__noop)

#else

#define tdk_gets(buffer)
#define tdk_getchar()						-1
#define tdk_getch()							-1
#define tdk_putchar(ch)
#define tdk_puts							sys_puts
#define tdk_printf							sys_printf
#define tdk_error							sys_printf
#define tdk_message(...)
#define tdk_uart_test()						1

#endif

#endif // TDK_DEBUG

#include "../drivers/uart_pl011.h"
#include "../system/system.h"
void tdk_delay(int value);
void tdk_delay_tick(int tick);

#endif
