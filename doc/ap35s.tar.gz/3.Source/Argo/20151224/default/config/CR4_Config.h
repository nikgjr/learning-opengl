/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#ifndef __CONFIG_H__
#define __CONFIG_H__

//#include "../tdk/tdk_types.h"

#define SYSTEM_CLK			50*MHz
#define SYSTEM_CLK_SIM		SYSTEM_CLK

#define ARM_RTOS_NONE			0
#define ARM_RTOS_UCOS_II		1
#define ARM_RTOS_UCOS_III		2
#define ARM_RTOS_FREERTOS		3

#define ARM_RTOS			ARM_RTOS_NONE

#define PLATFORM_APACHE35		1

#define PLATFORM_TYPE		PLATFORM_APACHE35


#define __SYSCLK_50M        1
#define __SYSCLK_80M        0

#ifndef __FOR_SIM
#define __FOR_SIM           0 // for simulation & __SIM_... definition
#endif

#define	IS_SIMULATOR()		(__FOR_SIM!=0)
#define IS_BOARD()			(__FOR_SIM==0)

#define IS_SEMIHOSTING()	0
#ifndef CODE_SIZE
#define CODE_SIZE	8*1024	// 16KByte
#endif

/****************************************************************************
*       Macros
*****************************************************************************/

/****************************************************************************
*       Enumeration Definitions
*****************************************************************************/

/****************************************************************************
*       Structure Definitions
*****************************************************************************/

/****************************************************************************
*       Global Variable Definitions
*****************************************************************************/

/****************************************************************************
*       Global Function Definitions
*****************************************************************************/


#endif /* __CONFIG_H__ */



