/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#ifndef __TOP_REG_MAP_H__
#define __TOP_REG_MAP_H__

#include "CR4_Config.h"

#define		APACHE_AXI_BASE			0x00000000
#define		APACHE_AHB_BASE			0x00000000
#define		APACHE_APB_BASE			0xF0000000

#define		APACHE_BOOT_ROM			0x00000000
#define		APACHE_BOOT_RAM			0x04000000
#define		APACHE_DRAM_BASE		0x08000000
#define 	APACHE_DRAM_SIZE		(16*1024*1024)
#define		APACHE_ATCM_BASE		0x0C000000
#define		APACHE_BTCM_BASE		0x0C100000

#define		APACHE_PL390_BASE_0		0x20000000
#define		APACHE_PL390_BASE_1		0x20100000


#define		APACHE_R4CONFIG_BASE	(0x30000000)
#define		APACHE_DMA_0_BASE		(0x30100000)
#define		APACHE_DMA_1_BASE		(0x30200000)
#define		APACHE_SYSCON_BASE		(0x30300000)
#define		APACHE_WDT_BASE			(0x30400000)
#define		APACHE_TIMER_BASE		(0x30500000)
#define		APACHE_TEMP_BASE		(0x30600000)
#define		APACHE_DDRC_BASE		(0x30700000)
#define		APACHE_I2C_0_BASE		(0x30800000)
#define		APACHE_I2C_1_BASE		(0x30900000)
#define		APACHE_UART_0_BASE		(0x30a00000)
#define		APACHE_UART_1_BASE		(0x30b00000)
#define		APACHE_GPIO_0_BASE		(0x30c00000)
#define		APACHE_SPI_0_BASE		(0x30d00000)
#define		APACHE_SPI_1_BASE		(0x30e00000)

#define 	APACHE_CUSTOM_0			(0x30f00000)
#define 	APACHE_CUSTOM_1			(0x31000000)
#define 	APACHE_CUSTOM_2			(0x31100000)
#define 	APACHE_DPGL 			(0x31120000)

#define		SYS_CON_BASE			APACHE_SYSCON_BASE

#define		SIM_REG_BASE			(SYS_CON_BASE+0x1000)
#define		SIM_CMD_BASE			(SYS_CON_BASE+0x2000)
#define		SIM_CMD_BUFFER			(SYS_CON_BASE+0x2100)

#define		SDIO_BASE				APACHE_SDIO_BASE
#define		SDIO_RD_FIFO_TH			(SYS_CON_BASE+0x0100)
#define		SDIO_WR_FIFO_TH			(SYS_CON_BASE+0x0104)
#define		SDIO_CONFIG_TAP			(SYS_CON_BASE+0x0108)
#define		SDIO_CONFIG_ATT			(SYS_CON_BASE+0x010C)
#define		SDIO_CONFIG_THRES		(SYS_CON_BASE+0x0110)

#define		GIC_DIST_BASE			(APACHE_PL390_BASE_0)
#define		GIC_CPU_BASE			(APACHE_PL390_BASE_1)

/* Peripharal Base */
#define		TIMER_BASE				(APACHE_TIMER_BASE)
#define		UART_BASE				(APACHE_UART_0_BASE)
#define		DMA_BASE				(APACHE_DMA_1_BASE)
#define		GPIO_BASE				(APACHE_GPIO_0_BASE)
#define		I2C_BASE				(APACHE_I2C_0_BASE)
#define		SPI_BASE				(APACHE_SPI_0_BASE)
#define		DDRC_BASE				(APACHE_DDRC_BASE)
#define		PWM_BASE				0x0

/* Register Definitions */
/* GIC Distributor */
#define 	GICDIST             ((tREG_GIC_DIST *)(GIC_DIST_BASE))
#define 	GICCPU              ((tREG_GIC_CPU *)(GIC_CPU_BASE))

/* TIMER */
#define TIMER0              ((tREG_TIMER *)(TIMER_BASE + 0x000))
#define TIMER1              ((tREG_TIMER *)(TIMER_BASE + 0x020))
#define OS_TIMER			TIMER0

/* UART */
#define UART0               ((tREG_PUART *)(UART_BASE + 0x000000))
#define UART1               ((tREG_PUART *)(UART_BASE + 0x100000))

#define OS_UART				UART0

/* DMA */
#define DMA                 ((tREG_DMA *)(DMA_BASE))

/* EMI */
#define EMI                 ((tREG_EMI *)(EMI_BASE))

/* GPIO */
#define GPIO0               ((tREG_GPIO *)(APACHE_GPIO_0_BASE))
#define GPIO1               ((tREG_GPIO *)(APACHE_GPIO_1_BASE))

/* SDRAM */
#define SDRAM               ((tREG_SDRAM *)(SDRAM_BASE))

/* I2C */

/* WDT */
#define WDT					((tREG_WDT *)(APACHE_WDT_BASE))

/* SPI */
#define SPI0				(SPI_BASE+0x00000000)
#define SPI1				(SPI_BASE+0x00100000)

#define I2C0                ((tREG_I2C *)(I2C_BASE + 0x00000000))
#define I2C1                ((tREG_I2C *)(I2C_BASE + 0x00100000))

//=====================================================================
// Syscon
//=====================================================================

#define SYSCON_RESET_R4			0x1
#define SYSCON_RESET_BUS		0x2
#define SYSCON_RESET_SYSCON		0x4
#define SYSCON_RESET_PERI		0x8

#define rSYSCON_RESET			(*(volatile unsigned *)(SYS_CON_BASE+0x0000))
#define rSYSCON_REMAP_START		(*(volatile unsigned *)(SYS_CON_BASE+0x0010))
#define rSYSCON_REMAP_END		(*(volatile unsigned *)(SYS_CON_BASE+0x0014))
#define rSYSCON_REMAP_OFFSET	(*(volatile unsigned *)(SYS_CON_BASE+0x0018))
#define rSYSCON_REMAP_ENABLE	(*(volatile unsigned *)(SYS_CON_BASE+0x001c))

//#define rSYSCON_TICK_COUNTER	(*(volatile unsigned *)(SYS_CON_BASE+0x0030))

#define rSYSCON_PRODUCT_ID		(*(volatile unsigned *)(SYS_CON_BASE+0x0f00))
#define rSYSCON_SYSTEM_CLOCK	(*(volatile unsigned *)(SYS_CON_BASE+0x2000))

#define rDEBUG_STATUS			(*(volatile unsigned *)(SIM_REG_BASE+0x00))
#define rDEBUG_STEP				(*(volatile unsigned *)(SIM_REG_BASE+0x04))
#define rDEBUG_RESPONS			(*(volatile unsigned *)(SIM_REG_BASE+0x08))
#define rDEBUG_WADDR			(*(volatile unsigned *)(SIM_REG_BASE+0x0c))
#define rDEBUG_WDATA			(*(volatile unsigned *)(SIM_REG_BASE+0x10))
#define rDEBUG_RADDR			(*(volatile unsigned *)(SIM_REG_BASE+0x14))
#define rDEBUG_RDATA			(*(volatile unsigned *)(SIM_REG_BASE+0x18))
#define rDEBUG_REG07			(*(volatile unsigned *)(SIM_REG_BASE+0x1c))
#define rDEBUG_REG08			(*(volatile unsigned *)(SIM_REG_BASE+0x20))
#define rDEBUG_REG09			(*(volatile unsigned *)(SIM_REG_BASE+0x24))
#define rDEBUG_REG10			(*(volatile unsigned *)(SIM_REG_BASE+0x28))
#define rDEBUG_REG11			(*(volatile unsigned *)(SIM_REG_BASE+0x2c))
#define rDEBUG_REG12			(*(volatile unsigned *)(SIM_REG_BASE+0x30))
#define rSYSCON_TICK_COUNTER	(*(volatile unsigned *)(SIM_REG_BASE+0x30))
#define rDEBUG_IRQ_COUNT		(*(volatile unsigned *)(SIM_REG_BASE+0x34))
#define rDEBUG_RESET_COUNT		(*(volatile unsigned *)(SIM_REG_BASE+0x38))
#define rDEBUG_TESTID			(*(volatile unsigned *)(SIM_REG_BASE+0x3c))

#define rDEBUG_COMMAND			(*(volatile unsigned *)(SIM_CMD_BASE+0x0000))
#define rDEBUG_COMMAND_BUFFER	((volatile char*)(SIM_CMD_BUFFER))

#endif

#ifndef __SYS_REG_MAP_H__
#define __SYS_REG_MAP_H__
#define rSYSCON_PLL_EN
// #define rCLK_RESET       (*(volatile unsigned *)(SYS_CON_BASE+0x0000))
#define rCLK_EN          (SYS_CON_BASE+0x0004)
#define rCFG_DMA         (SYS_CON_BASE+0x0008)
#define rDDR_INIT        (SYS_CON_BASE+0x000c)
// #define rREMAP_ST_ADDR   (*(volatile unsigned *)(SYS_CON_BASE+0x0010))
// #define rREMAP_END_ADDR  (*(volatile unsigned *)(SYS_CON_BASE+0x0014))
// #define rREMAP_OFFSET    (*(volatile unsigned *)(SYS_CON_BASE+0x0018))
// #define rREMAP_SET       (*(volatile unsigned *)(SYS_CON_BASE+0x001c))
#define rREMAP1ST_ADDR   (SYS_CON_BASE+0x0020)
#define rREMAP1END_ADDR  (SYS_CON_BASE+0x0024)
#define rREMAP1OFFSET    (SYS_CON_BASE+0x0028)
#define rREMAP1SET       (SYS_CON_BASE+0x002c)

// #define rSDIO_RD_FIFO_TH (*(volatile unsigned *)(SYS_CON_BASE+0x0100))
// #define rSDIO_WR_FIFO_TH (*(volatile unsigned *)(SYS_CON_BASE+0x0104))
// #define rSDIO_TUNING_TAP (*(volatile unsigned *)(SYS_CON_BASE+0x0108))
// #define rSDIO_TUNING_ATT (*(volatile unsigned *)(SYS_CON_BASE+0x010c))
// #define rSDIO_TUNE_THRES (*(volatile unsigned *)(SYS_CON_BASE+0x0110))

// #define rVERSION         (*(volatile unsigned *)(SYS_CON_BASE+0x0f00))

// #define rDEBUG_TICK_CNT  (*(volatile unsigned *)(SYS_CON_BASE+0x1030))
// #define rDEBUG_IRQ       (*(volatile unsigned *)(SYS_CON_BASE+0x1034))
// #define rDEBUG_RESET     (*(volatile unsigned *)(SYS_CON_BASE+0x1038))
// #define rDEBUG_TESTID    (*(volatile unsigned *)(SYS_CON_BASE+0x103c))

#define rSTRAP_INFO      (SYS_CON_BASE+0x0080)
#define rPLL_EN          (SYS_CON_BASE+0x0084)
#define rPLL_STABLE      (SYS_CON_BASE+0x0088)
#define rPLL0_DIV        (SYS_CON_BASE+0x008c)
#define rPLL1_DIV        (SYS_CON_BASE+0x0090)
#define rPLL2_DIV        (SYS_CON_BASE+0x0094)
#define rPLL_BWADJ       (SYS_CON_BASE+0x0098)
#define rPLL_OD          (SYS_CON_BASE+0x009c)

#define rCLK_PLL_SEL     (SYS_CON_BASE+0x00a0)
#define rCLK_SYS_SEL     (SYS_CON_BASE+0x00a4)
#define rCLK_SYS_DIV     (SYS_CON_BASE+0x00a8)
#define rCLK_ISP_SEL     (SYS_CON_BASE+0x00ac)
#define rCLK_ISP_DIV     (SYS_CON_BASE+0x00b0)
#define rCLK_ISP_DLY     (SYS_CON_BASE+0x00b4)

#define rISP_MODE        (SYS_CON_BASE+0x00b8)

#endif
