/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../tdk/tdk_types.h"
#include "../config/CR4_TopRegMap.h"
#include "../system/system.h"

#include "../tdk/tdk.h"
#include "../tdk/tdk_prompt.h"

#include "../bench/bench.h"
#include "../test/func_register.h"
#include "../test/test_alloc.h"
#include "../test/test_basic.h"
#include "../test/test_bus.h"
#include "../test/test_dma.h"
#include "../test/test_i2c.h"
#include "../test/test_mem.h"
#include "../test/test.h"

#include "../tdk/tdk_util.h"


#if SIM_IRQ
#define SIM_INIT_GIC		1
#else
#define SIM_INIT_GIC		0
#endif

#include "../include/ansi.h"


int sim_main(int argc, char *argv[])
{
	int ret = 0;
	u32 id;


	__SIM_STEP(0x200);


	SYS_Init();

	tdk_printf("==========================================\n");
	tdk_printf("Simulation SW start\n");
	tdk_printf("==========================================\n");
	id = __SIM_READ_REG(SIM_DEBUG_TESTID);
	tdk_printf("Simulation ID=0x%08x\n", id);
	tdk_printf("rSYSCON_REMAP_ENABLE=%d\n", rSYSCON_REMAP_ENABLE);

	if((id&0x80000000) && (rSYSCON_REMAP_ENABLE==0))
	{
		u32 data;

		tdk_printf("==========================================\n");
		tdk_printf("REMAP DRAM\n");
		tdk_printf("Init DRAM\n");
		ret = ddr_init();
		if(ret)
		{
			tdk_printf("fail to DDR Init\n");
			return -1;
		}


		tdk_printf("SW RESET\n");
		tdk_printf("==========================================\n");
		SYS_RemapEnable(0, 16*MB, APACHE_DRAM_BASE);
	}
	else if((id&0x40000000) && (rSYSCON_REMAP_ENABLE==0))
	{
		tdk_printf("==========================================\n");
		tdk_printf("REMAP SRAM\n");
		tdk_printf("SW RESET\n");
		tdk_printf("==========================================\n");
		SYS_RemapEnable(0, 16*MB, APACHE_BOOT_RAM);
	}

	switch(id&0xffffff)
	{
	case TEST_NULL		:
		break;
	case TEST_TIMER		:
		ret = test_timer(0, NULL);
		break;
	case TEST_WDT		:
		ret = test_wdt(0, NULL);
		break;
	case TEST_DMA		:
		{
			char *argv[] = { "dma", "1" };
			ret = test_dma(0, argv);
		}
		break;
	case TEST_GPIO		:
		ret = -1;
		break;
	case TEST_UART_LOOPBACK	:
		pinmux_uart0();
		pinmux_uart1();
		ret = test_uart_loopback(0, NULL);
		break;
	case TEST_SPI_MODEL		:
		pinmux_spi0();
//		pinmux_spi1();
		ret = test_spi_model(0, NULL);
		break;
	case TEST_I2C_MODEL:
		pinmux_i2c0();
		pinmux_i2c1();
		ret = test_i2c_model(0, NULL);
		break;
	case TEST_DRAM_BENCH:
		ret = bench_dram(0, NULL);
		break;
	case TEST_DRAM_CONFIG:
		ret = bench_dram_config(0, NULL);
		break;
	case TEST_BUSACCESS:
		ret = test_bus_access(0, NULL);
		break;
	case TEST_RESET:
		ret = test_reset(0, NULL);
		break;
	case TEST_TCM_BENCH:
		ret = bench_tcm(0, NULL);
		break;

	case 0x1000:
		__SIM_STEP(0x201);
		tdk_printf("A\n");
		tdk_printf("AB\n");
		tdk_printf("ABC\n");
		tdk_printf("ABCD\n");
		tdk_printf("ABCDE\n");
		tdk_printf("ABCD\nE\n");

		__SIM_STEP(0x202);
		tdk_puts("A");
		tdk_puts("AB");
		tdk_puts("ABC");
		tdk_puts("ABCD");
		tdk_puts("ABCDE");

	//	__SIM_PASS();
		break;
    
    case TEST_ISP_NORMAL:
		ret = bench_isp(0, NULL);        
        break;

    case TEST_CAN:
		ret = bench_can(0, NULL);        
        break;

	default:
		ret = -1;
		tdk_printf("%s\n", ansi_get_red_text("Invalid Test ID"));
		break;
	}

	tdk_printf("==================================\n");
	tdk_printf("Simulation Finish !!!\n");
	tdk_printf("Return Code = 0x%08x", ret);
	tdk_printf("==================================\n");

	__SIM_STEP(0x2FF);

	return ret;
}
