/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../tdk/tdk_types.h"
#include "../config/CR4_TopRegMap.h"
#include "../system/system.h"

#include "../tdk/tdk.h"
#include "../tdk/tdk_prompt.h"

#include "../bench/bench.h"
#include "../test/test.h"
#include "../test/func_register.h"
#include "../test/func_download.h"
#include "../test/test_alloc.h"
#include "../test/test_basic.h"
#include "../test/test_bus.h"
#include "../test/test_dma.h"
#include "../test/test_mem.h"

#if IS_BOARD()
struct tdk_prompt_cmd cmds[] =
{
		{	"r32",			func_r32, 									"Register 32 Bit Read"			},
		{	"w32",			func_w32, 									"Register 32 Bit Write"			},
		{	"d32",			func_d32, 									"Register 32 Bit Dump"			},
		{	"c32",			func_c32, 									"Register 32 Bit Clear"			},
		{	"compare",		func_compare,								"Compare Memory"				},
		{	"alloc",		test_alloc, 								"Alloc & Free Test"				},
		{	"reset.cpu",	test_reset,									"Reset Test"					},
		{	"uart.echo",	test_uart_echo,								"UART Echo Test"				},
		{	"timer",		test_timer,									"Timer Test"					},
		{	"wdt",			test_wdt,									"WDT Test"						},
		{	"dma",			test_dma,									"DMA Test"						},
		{	"dma.info",		test_dma_info,								"DMA Info"						},
#if 0
		{	"rz",			func_rz,									"Reset Test"					},

		{	"flash.FM25",		test_spi_FM25M32A,							"Flash Test"					},
		{	"flash.erase",		test_sflash_erase,							"Flash Erase"					},
		{	"flash.program",	test_sflash_program,						"Flash Programming"				},
		{	"flash.dump",		test_sflash_dump,							"Flash Dump"					},
		{	"flash.test",		test_sflash_test,							"Flash Test"					},
#endif

		{	"mem.init",		test_mem_init,								"Memory Init Test"				},
		{	"mem.test",		test_mem,									"Memory Read/Write Test"		},
		{	"mem.config",	test_mem_config,							"Memory Confing Test"			},
		{	"mem.fill",		test_mem_fill,								"Memory Fill Test"				},
		{	"mem.check",	test_mem_check,								"Memory Fill Test check" 		},
};

char g_command[80] = "";

/**
 * main 함수
 */
int app_main(int argc, char *argv[])
{
#if IS_BOARD()

#ifdef BUILD_R4
    SYS_Init();
#endif

    tdk_printf("\n\n\n");
    tdk_printf("==================================================================\n");
    tdk_printf("R4 Software Start\n");
    tdk_printf("Build Date : %s\n", __DATE__);
    tdk_printf("==================================================================\n");

#if IS_SEMIHOSTING()
    printf("\n\n\n");
    printf("==================================================================\n");
    printf("R4 Software Start\n");
    printf("Build Date : %s\n", __DATE__);
    printf("==================================================================\n");
    printf("_TDK_PLATFORM_=%s\n", TDK_PLATFORM_STRING);
    printf("==================================================================\n");
#endif

#if !defined(BUILD_LINUX)
    tdk_printf("Remap Enalbe = %d\n", rSYSCON_REMAP_ENABLE);
#endif
	tdk_printf("Remap_Base   = 0x%08x\n", SYS_GetRemapBaseAddress());
	tdk_printf("PRODUCT_ID   = 0x%08x\n", rSYSCON_PRODUCT_ID);
	tdk_printf("SYSTEM CLOCK = 0x%08x, %d\n", rSYSCON_SYSTEM_CLOCK, rSYSCON_SYSTEM_CLOCK);
    tdk_printf("==================================================================\n");
	
//    test_led(0, NULL);
	
    tdk_prompt_setprompt("APACHE35");
	tdk_prompt_init(cmds, sizeof(cmds)/sizeof(struct tdk_prompt_cmd));
	tdk_prompt_help();
	if(strlen(g_command)) tdk_prompt_do(g_command);
	tdk_prompt();
#endif

	return 0;
}

#endif
