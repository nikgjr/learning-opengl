/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../system/system.h"

#if IS_BOARD()
extern int app_main(int argc, char *artv[]);
#endif

#if IS_SIMULATOR()
extern int sim_main(int argc, char *artv[]);
#endif

/**
 * main 함수
 */
int main(void)
{
	int ret = 0;

#ifdef TDK_SIMULATION
	ret = sim_main(0, NULL);
//	SYS_Init();
#else
	ret = app_main(0, NULL);
#endif

	if(ret != 0)
	{
		__SIM_END_FAIL(ret);
	}
	else
	{
		__SIM_END_OK();
	}

	{
		int loop=1;
		while(loop);
	}

	return ret;
}

