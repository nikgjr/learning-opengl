/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/
#include "../tdk/tdk_types.h"
#include "../config/CR4_TopRegMap.h"
#include "gic_pl390.h"

/**
 * Distributor Control enable 함수
 * @param	*rDist	 distributor control register
 */
void GICDIST_Enable(tREG_GIC_DIST *rDist)
{
    rDist->ICDDCR |= ICDDCR_ENABLE;
}

/**
 * Distributor Control disable 함수
 * @param	*rDist	 distributor control register
 */
void GICDIST_Disable(tREG_GIC_DIST *rDist)
{
    rDist->ICDDCR &= ~(ICDDCR_ENABLE);
}

/**
 * Interrupt Controller Type register read 함수
 * @param	*rDist	 distributor control register
 * @param	*type	 distributor control register value
 */
void GICDIST_GetGicType(tREG_GIC_DIST *rDist, u32 *type)
{
    *type = rDist->ICDICTR;
}

/**
 * Interrupt Enable Set register setting 함수
 * @param	*rDist	 enable set register
 * @param	*desc	interrupt description(name and number) pointer
 */
void GICDIST_IrqEnable(tREG_GIC_DIST *rDist, int irqNo)
{
    u32 regOffset, irqBit;

    regOffset = irqNo / IRQS_PER_REG;
    irqBit = irqNo % IRQS_PER_REG;

    rDist->ICDISER[regOffset] = 1 << irqBit;
}

/**
 * Interrupt Enable Clear register setting 함수
 * @param	*rDist	 enable clear register
 * @param	*desc	interrupt description(name and number) pointer
 */
void GICDIST_IrqDisable(tREG_GIC_DIST *rDist, int irqNo)
{
    u32 regOffset, irqBit;

    regOffset = irqNo / IRQS_PER_REG;
    irqBit = irqNo % IRQS_PER_REG;

    rDist->ICDICER[regOffset] = 1 << irqBit;
}

/**
 * Interrupt Pending Set register setting 함수
 * @param	*rDist	 pending set register
 * @param	*desc	interrupt description(name and number) pointer
 */
void GICDIST_IrqSetPending(tREG_GIC_DIST *rDist, int irqNo)
{
    u32 regOffset, irqBit;

    regOffset = irqNo / IRQS_PER_REG;
    irqBit = irqNo % IRQS_PER_REG;

    rDist->ICDISPR[regOffset] = 1 << irqBit;
}

/**
 * Interrupt Pending Clear register setting 함수
 * @param	*rDist	 pending clear register
 * @param	*desc	interrupt description(name and number) pointer
 */
void GICDIST_IrqClearPending(tREG_GIC_DIST *rDist, int irqNo)
{
    u32 regOffset, irqBit;

    regOffset = irqNo / IRQS_PER_REG;
    irqBit = irqNo % IRQS_PER_REG;

    rDist->ICDICPR[regOffset] = 1 << irqBit;
}

/**
 * Interrupt Active Status register check 함수
 * @param	*rDist	 active status register
 * @param	*desc	interrupt description(name and number) pointer
 */
u32 GICDIST_IrqIsActive(tREG_GIC_DIST *rDist, int irqNo)
{
    u32 regOffset, irqBit;

    regOffset = irqNo / IRQS_PER_REG;
    irqBit = irqNo % IRQS_PER_REG;

    return(rDist->ICDABR[regOffset] & (1 << irqBit));
}

/**
 * Interrupt Priority Level register setting 함수
 * @param	*rDist	 priority level register
 * @param	*desc	interrupt description(name and number) pointer
 * @param	priority	interrupt priority level value
 */
void GICDIST_IrqSetPriority(tREG_GIC_DIST *rDist, int irqNo, u32 priority)
{
    u32 regOffset;
    u32 prioBitOffset;

    regOffset = irqNo / PRIOS_PER_REG;

    prioBitOffset = irqNo % PRIOS_PER_REG;
    prioBitOffset *= PRIO_FIELD_WIDTH;

    /* input error checking */
    if(priority & ~PRIO_FIELD_MASK)
    {
        /* print error message */
    }
    priority &= PRIO_FIELD_MASK;

    rDist->ICDIPR[regOffset] &= ~(PRIO_FIELD_MASK << prioBitOffset);
    rDist->ICDIPR[regOffset] |= (priority << prioBitOffset);
}

/**
 * Interrupt Priority Level register read 함수
 * @param	*rDist	 priority level register
 * @param	*desc	interrupt description(name and number) pointer
 * @param	*priority	interrupt priority level read value
 */
void GICDIST_IrqGetPriority(tREG_GIC_DIST *rDist, int irqNo, u32 *priority)
{
    u32 regOffset;
    u32 prioBitOffset;

    regOffset = irqNo / PRIOS_PER_REG;

    prioBitOffset = irqNo % PRIOS_PER_REG;
    prioBitOffset *= PRIO_FIELD_WIDTH;

    *priority = rDist->ICDIPR[regOffset] >> prioBitOffset;
    *priority &= PRIO_FIELD_MASK;
}

/**
 * Interrupt Target register setting 함수
 * @param	*rDist	 target register
 * @param	*desc	interrupt description(name and number) pointer
 * @param	target	target setting value
 */
void GICDIST_IrqSetCpuTarget(tREG_GIC_DIST *rDist, int irqNo, u32 target)
{
    u32 regOffset;
    u32 targetBitOffset;

    regOffset = irqNo / TARGETS_PER_REG;

    targetBitOffset = irqNo % TARGETS_PER_REG;
    targetBitOffset *= TARGET_FIELD_WIDTH;

    /* input error checking */
    if(target & ~TARGET_FIELD_MASK)
    {
        /* print error message */
    }
    target &= TARGET_FIELD_MASK;

    rDist->ICDIPTR[regOffset] &= ~(TARGET_FIELD_MASK << targetBitOffset);
    rDist->ICDIPTR[regOffset] |= target << targetBitOffset;
}

/**
 * Interrupt Target register read 함수
 * @param	*rDist	 target register
 * @param	*desc	interrupt description(name and number) pointer
 * @param	target	target read value
 */
void GICDIST_IrqGetCpuTarget(tREG_GIC_DIST *rDist, int irqNo, u32 *target)
{
    u32 regOffset;
    u32 targetBitOffset;

    regOffset = irqNo / TARGETS_PER_REG;

    targetBitOffset = irqNo % TARGETS_PER_REG;
    targetBitOffset *= TARGET_FIELD_WIDTH;

    *target = rDist->ICDIPTR[regOffset] >> targetBitOffset;
    *target &= TARGET_FIELD_MASK;
}

/**
 * Interrupt Configuration register setting 함수
 * @param	*rDist	 configuration register
 * @param	*desc	interrupt description(name and number) pointer
 * @param	type	type setting value
 */
void GICDIST_IrqSetConfig(tREG_GIC_DIST *rDist, int irqNo, u32 type)
{
    u32 regOffset;
    u32 configBitOffset;

    regOffset = irqNo / CONFIGS_PER_REG;

    configBitOffset = irqNo % CONFIGS_PER_REG;
    configBitOffset *= CONFIG_FIELD_WIDTH;

    /* input error checking */
    if(type & ~CONFIG_FIELD_MASK)
    {
        /* print error message */
    }
    type &= CONFIG_FIELD_MASK;

    rDist->ICDICR[regOffset] &= ~(CONFIG_FIELD_MASK << configBitOffset);
    rDist->ICDICR[regOffset] |= type << configBitOffset;
}

/**
 * Interrupt Configuration register read 함수
 * @param	*rDist	 configuration register
 * @param	*desc	interrupt description(name and number) pointer
 * @param	type	type read value
 */
void GICDIST_IrqGetConfig(tREG_GIC_DIST *rDist, int irqNo, u32 *config)
{
    u32 regOffset;
    u32 configBitOffset;

    regOffset = irqNo / CONFIGS_PER_REG;

    configBitOffset = irqNo % CONFIGS_PER_REG;
    configBitOffset *= CONFIG_FIELD_WIDTH;

    *config = rDist->ICDICR[regOffset] >> configBitOffset;
    *config &= CONFIG_FIELD_MASK;
}

/**
 * CPU Interface Control register enable 함수
 * @param	*rCpu	 CPU interface control register
 */
void GICCPU_InterfaceEnable(tREG_GIC_CPU *rCpu)
{
    rCpu->ICCICR |= ICCICR_ENABLE;
}

/**
 * CPU Interface Control register disable 함수
 * @param	*rCpu	 CPU interface control register
 */
void GICCPU_InterfaceDisable(tREG_GIC_CPU *rCpu)
{
    rCpu->ICCICR &= ~(ICCICR_ENABLE);
}

/**
 * Interrupt Priority Mask register setting 함수
 * @param	*rCpu	 priority mask register
 * @param	mask	 interrupt make bit
 */
void GICCPU_SetPriorityMask(tREG_GIC_CPU *rCpu, u32 mask)
{
    /* input error checking */
    if(mask & ~PRIO_FIELD_MASK)
    {
        /* print error message */
    }
    mask &= PRIO_FIELD_MASK;

    rCpu->ICCPMR |= mask;
}

/**
 * Interrupt Priority Mask register read 함수
 * @param	*rCpu	 priority mask register
 * @param	*mask	 priority mask value
 */
void GICCPU_GetPriorityMask(tREG_GIC_CPU *rCpu, u32 *mask)
{
    *mask = rCpu->ICCPMR;
    *mask &= PRIO_FIELD_MASK;
}

/**
 * Interrupt Acknowledge register read 함수
 * @param	*rCpu	 acknowledge register
 * @param	*readAck	 acknowledge value
 */
void GICCPU_ReadIrqAck(tREG_GIC_CPU *rCpu, u32 *readAck)
{
    *readAck = rCpu->ICCIAR;
}

/**
 * Interrupt End of Interrupt register setting 함수
 * @param	*rCpu	 end of interrupt register
 * @param	*desc	interrupt description(name and number) pointer
 */
void GICCPU_SetEndOfIrq(tREG_GIC_CPU *rCpu, int irqNo)
{
    /* input error checking */
    if(irqNo > 0x3FF)
    {
        /* print error message */
    }

    rCpu->ICCEOIR = irqNo;
}

/**
 * Interrupt Running Priority register read 함수
 * @param	*rCpu	 running priority register
 * @param	*priority	priority value
 */
void GICCPU_GetRunningIrqPriority(tREG_GIC_CPU *rCpu, u32 *priority)
{
    *priority = rCpu->ICCRPR;
}

/**
 * Interrupt Highest Pending Interrupt register read 함수
 * @param	*rCpu	 highest pending interrupt register
 * @param	*priority	highest pending interrupt value
 */
void GICCPU_GetHighestPending(tREG_GIC_CPU *rCpu, u32 *irq)
{
    *irq = rCpu->ICCHPIR;
}

