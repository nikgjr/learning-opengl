/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/
#include <stdio.h>
#include <string.h>

#include "../tdk/tdk_types.h"
#include "../config/CR4_TopRegMap.h"

#include "../system/system.h"
#include "../tdk/tdk.h"
#include "gicdrv.h"

/**
 * IRQ description을 저장할 변수
 */
/*
tGIC_IRQ_DESC gIrqDesc[] =
{
	{	"GIC_EXT_INT0		",	GIC_EXT_INT0			},
	{	"GIC_EXT_INT1		",	GIC_EXT_INT1			},
	{	"GIC_EXT_INT2		",  GIC_EXT_INT2			},
	{	"GIC_EXT_INT3		",	GIC_EXT_INT3			},
	{	"GIC_RESERVED		",	GIC_RESERVED			},
	{	"GIC_HUART			",	GIC_HUART				},
	{	"GIC_UART0_TX		",	GIC_UART0_TX			},
	{	"GIC_UART0_RX		",	GIC_UART0_RX			},
	{	"GIC_UART1_TX		", 	GIC_UART1_TX			},
	{	"GIC_UART1_RX		", 	GIC_UART1_RX			},
	{	"GIC_I2C0			", 	GIC_I2C0				},
	{	"GIC_I2C1			", 	GIC_I2C1				},
	{	"GIC_I2C2			", 	GIC_I2C2				},
	{	"GIC_GAU_INT		", 	GIC_GAU_INT				},
	{	"GIC_DCU_INT		", 	GIC_DCU_INT				},
	{	"GIC_SPI0			", 	GIC_SPI0				},
	{	"GIC_SPI1			",  GIC_SPI1				},
	{	"GIC_I2S			",  GIC_I2S					},
	{	"GIC_NAND			",	GIC_NAND				},
	{	"GIC_DMA_ABORT		",	GIC_DMA_ABORT			},
	{	"GIC_DMA_CHANNEL0	",	GIC_DMA_CHANNEL0		},
	{	"GIC_DMA_CHANNEL1	",	GIC_DMA_CHANNEL1		},
	{	"GIC_DMA_CHANNEL2	",	GIC_DMA_CHANNEL2		},
	{	"GIC_DMA_CHANNEL3	",	GIC_DMA_CHANNEL3		},
	{	"GIC_WDT			",	GIC_WDT					},
	{	"GIC_PWM_0			",	GIC_PWM_0				},
	{	"GIC_PWM_1			",	GIC_PWM_1				},
	{	"GIC_PWM_2			",	GIC_PWM_2				},
	{	"GIC_TIMER0_0		",	GIC_TIMER0_0			},
	{	"GIC_TIMER0_1		",	GIC_TIMER0_1			},
	{	"GIC_TIMER1_0		",	GIC_TIMER1_0			},
	{	"GIC_TIMER1_1		",	GIC_TIMER1_1			},
};
*/

/**
 * Global IRQ 변수
 */
//tGIC_IRQ gIrq;

/**
 * Raised 된 Interrupt 저장할 변수
 */
tGIC_RAISED_IRQ gRaisedIrq[RAISED_IRQS_TOTAL];


struct irq_info
{
	int irq;
	GIC_CALL_BACK call_back;
	void *param;
};

/**
 * Interrupt handler function pointer
 */
struct irq_info irq_table[IRQS_TOTAL];


/**
 * 모든 raised irq를 프린터 하는 함수
 */
void GIC_PrintAllRaisedIrq(void)
{
	int i;

	for(i=0; i<RAISED_IRQS_TOTAL; i++)
	{
		tdk_printf("[%3d], irqNo=%d, level=%d\n", i, gRaisedIrq[i].irqNo, gRaisedIrq[i].level);
	}
}

/**
 * Global gRaisedIrq 변수를 clear 및 초기화하는 함수
 */
void GIC_ClearAllRaisedIrq(void)
{
	u32 i;

	memset(gRaisedIrq, 0, RAISED_IRQS_TOTAL * sizeof(tGIC_RAISED_IRQ));
	for(i=0; i<RAISED_IRQS_TOTAL; i++)
		gRaisedIrq[i].irqNo = INVALID_IRQ_NO;
}

/**
 * Global gRaisedIrq 변수에 발생 된 interrupt number를 할당하는 함수
 * @param	*desc	발생 된 interrupt source 의 pointer
 */
void GIC_RegisterRaisedIrq(int irq)
{
	UINT8 i;

	for(i=0; i<RAISED_IRQS_TOTAL; i++)
	{
		if(gRaisedIrq[i].irqNo == INVALID_IRQ_NO)
		{
			gRaisedIrq[i].irqNo = irq;
			return;
		}
	}

	/* Print error message for buffer full */
}

/**
 * Interrupt generation을 check 하기 위한 함수
 * @param	*desc	generation을 기대하는  interrupt source의 pointer
 */
BOOL GIC_CheckRaisedIrq(int irq)
{
	u32 i;

	for(i=0; i<RAISED_IRQS_TOTAL; i++)
	{
		if(irq == gRaisedIrq[i].irqNo)
		{
			gRaisedIrq[i].irqNo = INVALID_IRQ_NO;
			return TRUE;
		}
	}
	return FALSE;
}

int  GIC_WaitIrq(int irq, unsigned int timeout)
{
	while(timeout)
	{
		if(GIC_CheckRaisedIrq(irq)) break;
		timeout--;
	}

	if(timeout==0) return -1;
	return 0;
}

/**
 * Interrupt pointer function 초기화 함수
 */
void GIC_InitIntHandler(void)
{
	u32 i;

	for(i=0; i<IRQS_TOTAL; i++)
	{
		irq_table[i].irq = 0;
		irq_table[i].call_back = NULL;
		irq_table[i].param = NULL;
	}
}

/**
 * Interrupt pointer function에 source interrupt를 할당하는 함수
 * @param	*desc	interrupt source pointer
 * @param	*pFunc	interrupt 발생 시 수행해야 할 함수
 */
void GIC_RegisterHandler(int irq, GIC_CALL_BACK pFunc, void *param)
{
#if !SRAM_STATIC_VECTOR_TABLE
	struct irq_info *info = &irq_table[irq];
	info->irq = irq;
	info->call_back = pFunc;
	info->param = param;
#else
	u32 *vecTable;

	vecTable = (u32 *)VECTOR_TABLE;

	*(vecTable+desc->irqNo) = (u32)pFunc;
#endif
}


/**
 * Interrupt 발생 후 source interrupt callback 함수를 수행하는 함수
 * @param	*desc	interrupt source pointer
 */
void GIC_IsrHandler(int irqNo)
{
#if !SRAM_STATIC_VECTOR_TABLE
	/* Clear interrupt source */
	struct irq_info *info = &irq_table[irqNo];
	if(info->call_back)
	{
		info->call_back(info->param);
	}
#else
	u32 *vecTable;

	vecTable = (u32 *)VECTOR_TABLE;

	((void(*)(void))(*(vecTable + desc->irqNo)))();
#endif
	/* Clear IRQ pending */
	GIC_ClearIrq(irqNo);
#if 0
	GICDIST_IrqClearPending(GICDIST, desc);
	{
		u32 regOffset, irqBit;
		unsigned int addr;
		regOffset = desc->irqNo / IRQS_PER_REG;
		irqBit = desc->irqNo % IRQS_PER_REG;
		GICDIST->ICDICPR[regOffset] = 1 << irqBit;
		*(volatile unsigned int *)(GIC_DIST_BASE+GIC_DIST_PENDING_CLEAR+regOffset*4) = 1<<irqBit;

		addr = GIC_DIST_BASE+GIC_DIST_PENDING_CLEAR;
		addr += regOffset*4;

		__asm volatile
		(
				// irq number = r1
				"MOV	r1,#0xE6000000						\n"
				"MOV	r2,#0x280							\n"
				"LSL	r3,r0,#5							\n"
//				"LSL	r3,r1,#5							\n"
				"STR	r1,[r2,+r3,LSL #02]					\n"
		);
	}
#endif
}

/**
 * IRQ 발생 시 Jump 할 함수
 */
void GIC_IrqHandler(void)
{
	u32 irqNo;

//	tdk_printf("GIC_IrqHandler\n");
	__SIM_DEBUG_REG(SIM_DEBUG_IRQ, irqNo);

	/* Ack the IRQ */
	GICCPU_ReadIrqAck(GICCPU, &irqNo);

	/* We disable the irq otherwise same irq would reassert since
	   the peripheral irq pending register isn't cleared. */
	GICDIST_IrqDisable(GICDIST, irqNo);

#if 1
	/* Register IRQ number on the raised irqs structures */
	GIC_RegisterRaisedIrq(irqNo);
#endif

	/* Service routine */
	GIC_IsrHandler(irqNo);

	/* Set the end-of-interrupt for this irq */
	GICCPU_SetEndOfIrq(GICCPU, irqNo);

	/* We cleared the peripheral irq, so enable the irq */
	GICDIST_IrqEnable(GICDIST,irqNo);

	__SIM_DEBUG_REG(SIM_DEBUG_IRQ, 0x0);
}

void GIC_irq_handler(int irqNo)
{
#if 1
	/* Register IRQ number on the raised irqs structures */
	GIC_RegisterRaisedIrq(irqNo);
#endif
	/* We disable the irq otherwise same irq would reassert since
	   the peripheral irq pending register isn't cleared. */
//	GICDIST_IrqDisable(GICDIST, &irqDesc);

	/* Service routine */
	{
		struct irq_info *info = &irq_table[irqNo];
		if(info->call_back)
		{
			info->call_back(info->param);
		}
	}

	/*
	{
		u32 regOffset, irqBit;

		regOffset = irqNo / IRQS_PER_REG;
		irqBit = irqNo % IRQS_PER_REG;

		GICDIST->ICDICPR[regOffset] = 1 << irqBit;
	}
	*/
	/* We cleared the peripheral irq, so enable the irq */
//	GICDIST_IrqEnable(GICDIST, &irqDesc);
}


void Halt_Handler(void)
{
	tdk_printf("==========================================\n");
	tdk_printf("Halt\n");
	tdk_printf("==========================================\n");
}

/**
 * Interrupt string 및 number를 할당하는 함수
 */
void GIC_InitIrqsDesc(void)
{
/*
	gIrq.if1		= &gIrqDesc[0];
	gIrq.if2	  	= &gIrqDesc[1];
	gIrq.cryto	  	= &gIrqDesc[2];
	gIrq.pkt		= &gIrqDesc[3];
	gIrq.avb		= &gIrqDesc[4];
	gIrq.rsvd1	  	= &gIrqDesc[5];
	gIrq.rsvd2	  	= &gIrqDesc[6];
	gIrq.dmaAbort   = &gIrqDesc[7];
	gIrq.dmaIrq0	= &gIrqDesc[8];
	gIrq.dmaIrq1	= &gIrqDesc[9];
	gIrq.dmaIrq2	= &gIrqDesc[10];
	gIrq.dmaIrq3	= &gIrqDesc[11];
	gIrq.dmaIrq4	= &gIrqDesc[12];
	gIrq.dmaIrq5	= &gIrqDesc[13];
	gIrq.dmaIrq6	= &gIrqDesc[14];
	gIrq.dmaIrq7	= &gIrqDesc[15];
	gIrq.temp0	  	= &gIrqDesc[16];
	gIrq.temp1	  	= &gIrqDesc[17];
	gIrq.rsvd3	  	= &gIrqDesc[18];
	gIrq.rsvd4	  	= &gIrqDesc[19];
	gIrq.rsvd5	  	= &gIrqDesc[20];
	gIrq.rsvd6	  	= &gIrqDesc[21];
	gIrq.rsvd7	  	= &gIrqDesc[22];
	gIrq.rsvd8	  	= &gIrqDesc[23];
	gIrq.rsvd9	  	= &gIrqDesc[24];
	gIrq.rsvd10	 	= &gIrqDesc[25];
	gIrq.uart0Rx	= &gIrqDesc[26];
	gIrq.uart0Tx	= &gIrqDesc[27];
	gIrq.uart1Rx	= &gIrqDesc[28];
	gIrq.uart1Tx	= &gIrqDesc[29];
	gIrq.timer0	 	= &gIrqDesc[30];
	gIrq.timer1	 	= &gIrqDesc[31];
*/
}

/**
 * Interrupt Property setting 함수
 * @param	*pFunc	Property setting pointer function
 * @param	val		Property value
 */
void GIC_ForEachIrqSetVal(void (*pFunc)(tREG_GIC_DIST *, int , u32), u32 val)
{
	u32 i;

	for(i=IRQS_START; i<IRQS_TOTAL; i++)
	{
		pFunc(GICDIST, i, val);
	}
}

/**
 * All IRQs를 enable 하는 함수
 */
void GIC_EnableAllIrqs(void)
{
	u32 i;

	for(i=IRQS_START; i<IRQS_TOTAL; i++)
	{
		GICDIST_IrqEnable(GICDIST, i);
	}
}

/**
 * All IRQs를 disable 하는 함수
 */
void GIC_DisableAllIrqs(void)
{
	u32 i;

	for(i=IRQS_START; i<IRQS_TOTAL; i++)
	{
		GICDIST_IrqDisable(GICDIST, i);
	}
}

/**
 * All pending IRQs를 clear 하는 함수
 */
void GIC_ClearAllIrqs(void)
{
	u32 i;

	for(i=IRQS_START; i<IRQS_TOTAL; i++)
	{
		GICDIST_IrqClearPending(GICDIST, i);
	}
	GIC_ClearAllRaisedIrq();
}

/**
 * Interrupt 초기화 함수
 */
void GIC_InitInterrupts(void)
{
#if IS_BOARD()
	CPU_TARGET target;
	tGIC_INT_TYPE type;
	UINT8 priority;
#else
	tGIC_INT_TYPE type;
#endif
	tGIC_PRIO_MASK prioMask;

	/* Initialize the irq descriptor array */
	GIC_InitIrqsDesc();

	/* Initialize interrupt pointer function */
	GIC_InitIntHandler();

	/* Disable Distributor and CPU Interface */
	GICDIST_Disable(GICDIST);
	GICCPU_InterfaceDisable(GICCPU);

	/* Disable all irqs on all gics */
	GIC_DisableAllIrqs();

#if IS_BOARD()
	/* Configure IRQs */
	// Set CPU target for each interrupt
	target = CPU_TARGET_IF0;
	GIC_ForEachIrqSetVal(GICDIST_IrqSetCpuTarget, (u32)target);

	// Set interrupt type
	type = GIT_N_N_LEVEL;
	GIC_ForEachIrqSetVal(GICDIST_IrqSetConfig, (u32)type);

	// Set priority of interrupt
	priority = 0xA0;
	GIC_ForEachIrqSetVal(GICDIST_IrqSetPriority, (u32)priority);
#else
	type = GIT_1_N_EDGE;
	GICDIST_IrqSetConfig(GICDIST,GIC_ISP0,(u32)type);
	GICDIST_IrqSetConfig(GICDIST,GIC_ISP1,(u32)type);
	GICDIST_IrqSetConfig(GICDIST,GIC_ISP2,(u32)type);
	GICDIST_IrqSetConfig(GICDIST,GIC_ISP3,(u32)type);
	GICDIST_IrqSetConfig(GICDIST,GIC_ISP4,(u32)type);
	GICDIST_IrqSetConfig(GICDIST,GIC_ISP5,(u32)type);
	GICDIST_IrqSetConfig(GICDIST,GIC_ISP6,(u32)type);
	GICDIST_IrqSetConfig(GICDIST,GIC_ISP7,(u32)type);
	GICDIST_IrqSetConfig(GICDIST,GIC_ISP8,(u32)type);
	GICDIST_IrqSetConfig(GICDIST,GIC_EXT_INT1,(u32)type);
	GICDIST_IrqSetConfig(GICDIST,GIC_EXT_INT0,(u32)type);
#endif

	/* Enable Distributor and CPU Interface */
	GICDIST_Enable(GICDIST);
	GICCPU_InterfaceEnable(GICCPU);

	/* Set priority mask */
	prioMask = GPM_LEVEL_256;
	GICCPU_SetPriorityMask(GICCPU, prioMask);

#if IS_BOARD()
	/* Clear all pending IRQs */
	GIC_ClearAllIrqs();
#endif

	/* Enable global interrupt */
#ifdef __ARM__
	__CORE_INT_EN();
#endif
}

/**
 * Source Interrupt enable 함수
 * @param	*rDist	PL390 interrupt controller interrupt enable register pointer
 * @param	*desc	enable 을 기대하는  interrupt source 의 pointer
 */
void GIC_EnableIrq(int irq)
{
	GICDIST_IrqEnable(GICDIST, irq);
}

/**
 * Source Interrupt disable 함수
 * @param	*rDist	PL390 interrupt controller interrupt disable register pointer
 * @param	*desc	disable 을 기대하는  interrupt source 의 pointer
 */
void GIC_DisableIrq(int irq)
{
	GICDIST_IrqDisable(GICDIST, irq);
}

/**
 * Source Interrupt clear 함수
 * @param	*rDist	PL390 interrupt controller interrupt clear register pointer
 * @param	*desc	clear 를 기대하는  interrupt source 의 pointer
 */
void GIC_ClearIrq(int irq)
{
	GICDIST_IrqClearPending(GICDIST, irq);
}

/**
 * All Defined IRQs를 clear 하는 함수
 */
void GIC_ClearAllDefinedIrqs(void)
{
	u32 i;

	for(i=IRQS_START; i<IRQS_TOTAL; i++)
		GIC_ClearIrq(i);
}

/**
 * All Defined IRQs를 enable 하는 함수
 */
void GIC_EnableAllDefinedIrqs(void)
{
	u32 i;

	for(i=IRQS_START; i<IRQS_TOTAL; i++)
		GIC_EnableIrq(i);
}

/**
 * All Defined IRQs를 interrupt 를 disable 하는 함수
 */
void GIC_DisableAllDefinedIrqs(void)
{
	u32 i;

	for(i=IRQS_START; i<IRQS_TOTAL; i++)
		GIC_DisableIrq(i);
}


