
#ifndef __SERIAL_FLASH__
#define __SERIAL_FLASH__

#define MAX_SERIAL_FLASH_SIZE			(4*1024*1024)
#define SERIAL_FLASH_SECTOR_SIZE		(4*1024)
#define MAX_SERIAL_FLASH_SECTOR_COUNT	1024
#define SERIAL_FLASH_BLOCK_SIZE			(64*1024)
#define MAX_SERIAL_FLASH_BLOCK_COUNT	64


void sflash_init(void);
int sflash_wait_for_complete(void);
int sflash_reset(void);
int sflash_chip_erase(void);
int sflash_sector_erase(u32 addr);
int sflash_block_erase(u32 addr);
int sflash_erase(u32 addr, int size);
int sflash_single_write(u32 addr, u32 data);
int sflash_single_read(u32 addr, u32 *data);
int sflash_buffer_write(u32 addr, u32 *buffer, int size);
int sflash_buffer_read(u32 addr, u32 *buffer, int size);


#endif
