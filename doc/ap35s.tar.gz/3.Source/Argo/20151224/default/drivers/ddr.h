#ifndef __DDR_MEMORY__
#define __DDR_MEMORY__

#define DDR_PHY_INIT			(1<<0)
#define DDR_PHY_COMPLETE		(1<<4)
#define DDR_PHY_SUCCESS			(1<<5)

#define DDR_PHY_CONFIG			(DDRC_BASE+0x00)
#define DDR_ADDR_SIZE			(DDRC_BASE+0x04)
#define DDR_TIMING_0			(DDRC_BASE+0x08)
#define DDR_TIMING_1			(DDRC_BASE+0x0c)
#define DDR_TIMING_2			(DDRC_BASE+0x10)
#define DDR_LMR_EXT_STD			(DDRC_BASE+0x14)
#define DDR_LMR_EXT_3_2			(DDRC_BASE+0x18)

enum { DRAM_TYPE_DDR2, DRAM_TYPE_LPDDR };

#define ddr_get_type_string(x)		((x==DRAM_TYPE_DDR2) ? "DDR2" : "LPDDR")

int ddr_config(int type, float freq);
int ddr_init(void);
int ddr_dump(void);

#endif
