#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include "../tdk/tdk_types.h"
#include "../config/CR4_TopRegMap.h"
#include "../system/system.h"

#include "uart_pl011.h"

tREG_PUART *prPUart = (tREG_PUART *)UART0;

void uart_init(tREG_PUART *uart, tPUART_PARAM *param)
{
	u32 temp, ref_clk, divider, remainder, fraction;

	/*
	 ** First, disable everything.
	 */
	uart->UARTCR=0;

	/*
	 ** Set baud rate
	 **
	 ** IBRD = UART_CLK / (16 * BPS)
	 ** FBRD = ROUND((64 * MOD(UART_CLK,(16 * BPS))) / (16 * BPS))
	 */
	temp=16 * (param->baudRate);
	ref_clk=param->uartClk;
	divider=ref_clk / temp;
	remainder=ref_clk % temp;
	temp=(8 * remainder) / param->baudRate;
	fraction=(temp >> 1) + (temp & 1);

	uart->UARTIBRD=divider;
	uart->UARTFBRD=fraction;

	/*
	 ** ----------------------------------------------
	 ** NOTE: MUST BE WRITTEN LAST (AFTER IBRD & FBRD)
	 ** ----------------------------------------------
	 **
	 ** Set the UART to be 8 bits, 1 stop bit, no parity, fifo enabled.
	 */
	uart->UARTLCR_H=(param->sps | param->wlen | param->fen | param->stp2
			| param->eps | param->pen | param->brk);

	/*
	 ** Set the UART FIFO levle to .....
	 */
//	uart->UARTIFLS = FLS_RX_1DIV2|FLS_TX_1DIV2;
	uart->UARTIFLS= FLS_RX_1DIV8 | FLS_TX_1DIV2;

	uart->UARTICR|=0xFFFF;
//	uart->UARTIMSC|=0x03FF;
	uart->UARTIMSC = (IMSC_OEIM|IMSC_BEIM|IMSC_PEIM|IMSC_FEIM|IMSC_RTIM|IMSC_RXIM|IMSC_DSRMIM|IMSC_DCDMIM|IMSC_CTSMIM|IMSC_RIMIM);

	/*
	 ** Finally, enable the UART
	 */
	uart->UARTCR= CR_RX_EN | CR_TX_EN | CR_UART_EN;
}


void uart_putchar(tREG_PUART *uart, u8 ch)
{
    while(uart->UARTFR & FR_TXFF);

    uart->UARTDR = ch;
}

#if 1
/**
 * PL011 UART string send 함수
 * @param	*str	string
 */
void uart_print_string(char *str)
{
/*
    while(*str)
        uart_putchar(prPUart, *str++);
*/
	char prev = 0x0;
	// NULL 문자가 올때 까지 출력한다.
	while(*str)
	{
		// '\n'을 만나면 '\r'도 출력해 준다.
		if(*str=='\n' && prev != '\r') uart_putchar(prPUart, '\r');
		// 한자씩 출력해 준다.
		uart_putchar(prPUart, *str);
		// 버퍼의 위치를 옮긴다.
		prev = *str++;
	}
}
#endif

void uart_puts(char *str)
{
	uart_print_string(str);
	uart_print_string("\n");
}

int uart_getchar(tREG_PUART *uart)
{
    if(!(uart->UARTFR & FR_RXFE))
        return (u8)uart->UARTDR;
    else
        return -1;
}

int uart_writebytes(tREG_PUART *rUart, void *buffer, int length)
{
	int i;
	char *s = (char*)buffer;
	for(i=0; i<length; i++)
	{
		uart_putchar(rUart, s[i]);
	}
	return length;
}


int uart_readbytes(tREG_PUART *rUart, void *buffer, int length)
{
	int i=0;
	int ch;
	char *s = (char*)buffer;
	while(1)
	{
		ch = uart_getchar(rUart);

		if(ch == -1)
		{
			// delay here
			continue;
		}

		// Buffer에 입력 받은 값을 계속해서 저장한다.
    	s[i++]=(char)ch;

    	if(i==length) break;
	}

	return length;
}


void uart_printhex(tREG_PUART *uart, u8 hex)
{
    u8 tmp;

    /* 1st Digit */
    tmp = hex >> 4;
    if(tmp < 0x0A)
        tmp += 0x30;
    else
        tmp += 0x37;
    uart_putchar(uart, tmp);

    /* 2nd Digit */
    tmp = hex & 0x0F;
    if(tmp < 0x0A)
        tmp += 0x30;
    else
        tmp += 0x37;
    uart_putchar(uart, tmp);
}

/**
 * PL011 UART decimal value printer 함수
 * @param	*rUart	UART base register pointer
 * @param	num	number
 * @param	type	decimal tupe 8/16/32
 */
void uart_printdec(tREG_PUART *uart, u32 num, u8 type)
{
    u8 quot;
    u32 tmp;

    if(!num)
    {
        uart_putchar(uart, '0');
        return;
    }

    if(type == DEC_8)
        tmp = 100;
    else if(type == DEC_16)
        tmp = 10000;
    else if(type == DEC_32)
        tmp = 1000000000;
    else
    	tmp = 1000000000;

    while(!(num/tmp))
        tmp /= 10;

    while(1)
    {
        quot = num/tmp;
        uart_putchar(uart, (quot+0x30));
        num -= quot * tmp;
        tmp /= 10;
        if(!tmp)
            break;
    }
}

#if 1

/**
 * PL011 UART printer 함수
 */
void uart_printf(const char *fmt, ...)
{
	 /** %x : print u8 hex value */
	 /** %4x: print UINT16 hex value */
	 /** %8x: print u32 hex value */
	 /** %d : print u8 decimal value */
	 /** %4d: print UINT16 decimal value */
	 /** %8d: print u32 decimal value */
	 /** %s : print string */
#if 0
    va_list args;
    u8 pos = 0;
    u8 i;
    UINT16 u_short;
    u32 u_long;
    u8 *str;
    BOOL f_uint16 = FALSE, f_u32 = FALSE;

    va_start (args, fmt);

    while (fmt[pos]) 
    {
        if (fmt[pos] == '%') 
        {
            if(f_uint16 || f_u32)
                pos +=2;
            else
                pos++;
            switch (fmt[pos])
            {
                case 'x' :
                    if(f_uint16)
                    {
                        u_short = va_arg(args, u32); //UINT16
                        for(i=2; i>0; i--)
                            uart_printhex(prPUart, (u8)(u_short>>(8*(i-1))));
                        f_uint16 = FALSE;
                    }
                    else if(f_u32)
                    {
                        u_long = va_arg (args, u32); //u32
                        for(i=4; i>0; i--)
                            uart_printhex(prPUart, (u8)(u_long>>(8*(i-1))));
                        f_u32 = FALSE;
                    }
                    else
                        uart_printhex(prPUart, (va_arg(args, u32))); //u8
                    break;
                    
                case 'd' :
                    if(f_uint16)
                    {
                        u_short = va_arg(args, u32); //UINT16
                        uart_printdec(prPUart, (u32)u_short, DEC_16);
                        f_uint16 = FALSE;
                    }
                    else if(f_u32)
                    {
                        u_long = va_arg(args, u32); //u32
                        uart_printdec(prPUart, (u32)u_long, DEC_32);
                        f_u32 = FALSE;
                    }
                    else
                        uart_printdec(prPUart, (u32)(va_arg(args, u32)), DEC_8); //u8
                    break;
                    
                case '4' :
                    f_uint16 = TRUE;
                    pos -=2;
                    break;
                    
                case '8' :
                    f_u32 = TRUE;
                    pos -=2;
                    break;
                    
                case 's' :
                    u_long = va_arg(args, u32);
                    str = (u8 *)u_long;
                    while(1)
                    {
                        uart_putchar(prPUart, (u8)(*str++));
                        if(*str == NULL)
                            break;
                    }
                    break;
                    
                case 'c' :
                    u_long = va_arg(args, u32);
                    uart_putchar(prPUart, (u8)u_long);
                    break;
                    
                default:
                    break;
            }
        }
        else if(fmt[pos] == '\n')
        {
            uart_putchar(prPUart, '\n');
            uart_putchar(prPUart, '\r');
        }
        else
        {
            uart_putchar(prPUart, fmt[pos]);
        }
        pos++;
    }
    va_end (args);
#else
	va_list args;
//	u32 i, len;
	char buffer[1024];

	va_start(args, fmt);
	vsnprintf(buffer, sizeof(buffer), fmt, args);
	va_end(args);

	uart_print_string(buffer);
#endif
}

#endif

#if 1
char *uart_gets(char *s)
{
    int c = 0;
	int i=0;

	while(1)
	{
		// UART로 부터 한자를 입력 받는다.
		c = uart_getchar(prPUart);
		if(c < 0)
			continue;

//		PUART_Printf("%d,%d\n", c, '\b');

		if(c == '\r' || c == '\n')
		{
			// CR 또는 LF 문자가 입력되면 "\r\n"을 출력하고 Loop를 빠져 나간다.
			uart_putchar(prPUart, '\r');
			uart_putchar(prPUart, '\n');
			break;
		}

		if(c == '\b' || c==127)
		{
			// Backspace가 입력되면 출력되었던 내용을 지우고 Buffer의 위치도 옮겨준다.
			if(i>0)
			{
				i--;
				uart_putchar(prPUart, c);
				uart_putchar(prPUart, ' ');
				uart_putchar(prPUart, c);
			}
		}
		else
		{
			// Buffer에 입력 받은 값을 계속해서 저장한다.
        	s[i++]=(char)c;
        	uart_putchar(prPUart, c);
		}
	}
	// 마지막에 널 문자를 넣어준다.
    s[i]='\0';
	return s;
}
#endif


int uart_test(void)
{
	return !(prPUart->UARTFR & FR_RXFE);
}
