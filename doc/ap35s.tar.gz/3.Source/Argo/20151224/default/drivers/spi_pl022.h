/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/
#ifndef __SPI_H__
#define __SPI_H__

#include "../tdk/tdk_types.h"

typedef		u32 SPI_OBJECT;

#define		SSP_CR0			0x00
#define		SSP_CR1			0x04
#define		SSP_DR			0x08
#define		SSP_SR			0x0C
#define		SSP_CPSR		0x10
#define		SSP_IMSC		0x14
#define		SSP_RIS			0x18
#define		SSP_MIS			0x1C
#define		SSP_ICR			0x20
#define		SSP_DMACR		0x24

#define		SSP_PERI_ID0	0xFE0
#define		SSP_PERI_ID1	0xFE4
#define		SSP_PERI_ID2	0xFE8
#define		SSP_PERI_ID3	0xFEC

#define		SSP_PCELL_ID0	0xFF0
#define		SSP_PCELL_ID1	0xFF4
#define		SSP_PCELL_ID2	0xFF8
#define		SSP_PCELL_ID3	0xFFC

#define 	SSP_CONTROL_SPH_0		(0<<7)
#define 	SSP_CONTROL_SPH_1		(1<<1)
#define		SSP_CONTROL_SPO_0		(0<<6)
#define		SSP_CONTROL_SPO_1		(1<<6)
#define		SSP_CONTROL_FRAME_MOTOROLA	(0<<4)
#define		SSP_CONTROL_FRAME_TI		(1<<4)
#define		SSP_CONTROL_FRAME_NATIONAL	(2<<4)
#define		SSP_CONTROL_DATA_4			(3)
#define		SSP_CONTROL_DATA_5			(4)
#define		SSP_CONTROL_DATA_6			(5)
#define		SSP_CONTROL_DATA_7			(6)
#define		SSP_CONTROL_DATA_8			(7)
#define		SSP_CONTROL_DATA_9			(8)
#define		SSP_CONTROL_DATA_10			(9)
#define		SSP_CONTROL_DATA_11			(10)
#define		SSP_CONTROL_DATA_12			(11)
#define		SSP_CONTROL_DATA_13			(12)
#define		SSP_CONTROL_DATA_14			(13)
#define		SSP_CONTROL_DATA_15			(14)
#define		SSP_CONTROL_DATA_16			(15)

#define		SSP_CONTROL_MASTER_MODE			(0<<2)
#define		SSP_CONTROL_SLAVE_MODE			(1<<2)
#define		SSP_CONTROL_SYNC_SERAL_ENABLE	(1<<1)
#define		SSP_CONTROL_LOOPBACK_MODE		(1<<0)

#define		SSP_STATUS_BUSY				0x10
#define		SSP_STATUS_RX_FIFO_FULL		0x08
#define		SSP_STATUS_RX_FIFO_READY	0x04
#define		SSP_STATUS_TX_FIFO_READY	0x02
#define		SSP_STATUS_TX_FIFO_EMPTY	0x01

#define		SSP_ENABLE_TX_FIFO_HALF_INT		0x8
#define		SSP_ENABLE_RX_FIFO_HALF_INT		0x4
#define		SSP_ENABLE_RX_TIMEOUT_INT		0x2
#define		SSP_ENABLE_RX_OVERRUN_INT		0x1

#define		SSP_TX_INTR		0x8
#define		SSP_RX_INTR		0x4
#define		SSP_RT_INTR		0x2
#define		SSP_ROR_INTR	0x1

#define		SSP_ENABLE_TX_INTR_STATUS	0x8
#define 	SSP_ENABLE_RX_INTR_STATUS	0x4
#define		SSP_ENABLE_RT_INTR_STATUS	0x2
#define		SSP_ENABLE_ROR_INTR_STATUS	0x1

#define		SPI_IS_TX_FIFO_READY(status)	((status)&SSP_STATUS_TX_FIFO_READY)
#define		SPI_IS_BUSY(status)				((status)&SSP_STATUS_BUSY)

#define 	SPI_TIMEOUT		100

#define __SPI_FUNCCALL__		0
#define __SPI_DEBUG__			0
#define __SPI_DIGEST_DEBUG__	0

#if __SPI_FUNCCALL__
u32 spi_reg_read(SPI_OBJECT spi, u32 offset);
void spi_reg_write(SPI_OBJECT spi, u32 offset, u32 data);

#else
#define spi_reg_read(spi, offset)				*((volatile u32 *)(((u32)(spi))+(offset)))
#define spi_reg_write(spi, offset, data)		*((volatile u32 *)(((u32)(spi))+(offset)))=(data)
#define spi_reg_verify(spi, offset, data)		spi_reg_read((offset))!=(data)
#endif

void spi_init(SPI_OBJECT spi);

u32 spi_wait_status(SPI_OBJECT spi, u32 offset, u32 flag, int timeout);
int spi_write(SPI_OBJECT spi, int data);
int spi_write2(SPI_OBJECT spi, int data);
int spi_read(SPI_OBJECT spi);
int spi_write_bytes(SPI_OBJECT spi, void *buffer, int length);
int spi_read_bytes(SPI_OBJECT spi, void *buffer, int length);

#endif
