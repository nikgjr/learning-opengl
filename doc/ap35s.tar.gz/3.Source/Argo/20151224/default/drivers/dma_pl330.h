#ifndef __DMA_PL330_H__
#define __DMA_PL330_H__

#include "../tdk/tdk_types.h"

#define STRONG_ORDERED		1


#define DMA_DEBUG		0

#if DMA_DEBUG
#define			dma_printf		tdk_printf
#else
#define		dma_printf(...)
#endif

/****************************************************************************
*       Register Map
*****************************************************************************/
typedef volatile struct
{
    u32 SAR;             // [0x400][RO] Source address for DMA channel 0
    u32 DAR;             // [0x404][RO] Destination address for DMA channel 0
    u32 CCR;             // [0x408][RO] Channel control for DMA channel 0
    u32 LC0;             // [0x40C][RO] Loop counter 0 for DMA channel 0
    u32 LC1;             // [0x410][RO] Loop counter 1 for DMA channel 0
    u32 reserved_414_41c[3];
}tAXI_STS_LC_REG;

typedef volatile struct
{
    u32 CSR;             // [0x100][RO] Channel Status for DMA channel 0
    u32 CPC;             // [0x104][RO] Channel PC for DMA channel 0
}tCH_THRD_STS_REG;

typedef volatile struct
{
    u32 DSR;             // [0x000][RO] DMA Manager Status Register
    u32 DPC;             // [0x004][RO] DMA Program Counter Register
    u32 reserved_008_01c[6];
    u32 INTEN;           // [0x020][RW] Interrupt Enable Register
    u32 INT_EVENT_RIS;   // [0x024][RO] Event-Interrupt Raw Status Register
    u32 INTMIS;          // [0x028][RO] Interrupt Status Register
    u32 INTCLR;          // [0x02C][WO] Interrupt Clear Register
    u32 FSRD;            // [0x030][RO] Fault Status DMA Manager Register
    u32 FSRC;            // [0x034][RO] Fault Status DMA Channel Register
    u32 FTRD;            // [0x038][RO] Fault Type DMA Manager Register
    u32 reserved_03c;
    u32 FTR[8];          // [0x040][RO] Fault type for DMA channel[0:7]
    u32 reserved_060_0fc[40];
    tCH_THRD_STS_REG CTSR[8];// [0x100:0x13C][RO] DMA Channel Thread Status Registers
    u32 reserved_140_3fc[176];
    tAXI_STS_LC_REG ASLR[8]; // [0x400:0x4FC][RO] AXI Status and Loop Counter Registers
    u32 reserved_500_cfc[512];
    u32 DBGSTATUS;       // [0xD00][RO] Debug Status Register
    u32 DBGCMD;          // [0xD04][WO] Debug Command Register, WO
    u32 DBGINST0;        // [0xD08][WO] Debug Instruction-0 Register, WO
    u32 DBGINST1;        // [0xD0C][WO] Debug Instruction-1 Register, WO
    u32 reserved_d10_dfc[60];
    u32 CR0;             // [0xE00][RO] Configuration Register 0
    u32 CR1;             // [0xE04][RO] Configuration Register 1
    u32 CR2;             // [0xE08][RO] Configuration Register 2
    u32 CR3;             // [0xE0C][RO] Configuration Register 3
    u32 CR4;             // [0xE10][RO] Configuration Register 4
    u32 CRD;             // [0xE14][RO] DMA Configuration Register
    u32 reserved_e18_e7c[26];
    u32 WD;              // [0xE80][RW] Watchdog Register, RW
    u32 reserved_e84_fdc[87];
    u32 PERIPH_ID_N[4];  // [0xFE0][RO] Peripheral Identification Registers
    u32 PCELL_ID_N[4];   // [0xFF0][RO] Component Identification Registers
}tREG_DMA;

/* DSR */
#define DSR_NON_SECURE      (1<<9)
#define DSR_WAKE_EVENT_SFT  (4)
#define DSR_WAKE_EVENT_MSK  (0x1F<<4)
#define DSR_DS_MASK         (0xF<<0)
#define DSR_DS_FAULTING     (0xF<<0)
#define DSR_DS_WFE          (0x4<<0)
#define DSR_DS_UPDATE_PC    (0x3<<0)
#define DSR_DS_CACHE_MISS   (0x2<<0)
#define DSR_DS_EXECUTING    (0x1<<0)
#define DSR_DS_STOPPED      (0x0<<0)

/* CSR */
#define CSR_NON_SECURE      (1<<21)
#define CSR_WFP_PERIPH      (1<<15)
#define CSR_WFP_BURST       (1<<14)
#define CSR_WAKE_NUM_SFT    (4)
#define CSR_WAKE_NUM_MSK    (0x1F<<4)
#define CSR_CS_MASK         (0xF<<0)
#define CSR_CS_FAULTING     (0xF<<0)
#define CSR_CS_FAULT_COMP   (0xE<<0)
#define CSR_CS_COMPLETING   (0x9<<0)
#define CSR_CS_KILLING      (0x8<<0)
#define CSR_CS_WFP          (0x7<<0)
#define CSR_CS_AT_BARRIER   (0x5<<0)
#define CSR_CS_WFE          (0x4<<0)
#define CSR_CS_UPDATE_PC    (0x3<<0)
#define CSR_CS_CACHE_MISS   (0x2<<0)
#define CSR_CS_EXECUTING    (0x1<<0)
#define CSR_CS_STOPPED      (0x0<<0)

/* DBGSTATUS */
#define DBGSTS_BUSY         (1<<0)

/****************************************************************************
*       Definitions
*****************************************************************************/
#define DMA_PERIPH_ID       0x00241330
#define DMA_PCELL_ID        0xB105F00D

#define CMD_DMAADDH	        0x54
#define CMD_DMAADNH         0x5C
#define CMD_DMAEND	        0x00
#define CMD_DMAFLUSHP	    0x35
#define CMD_DMAGO	        0xA0
#define CMD_DMALD	        0x04
#define CMD_DMALDP	        0x25
#define CMD_DMALP	        0x20
#define CMD_DMALPEND	    0x28
#define CMD_DMAKILL	        0x01
#define CMD_DMAMOV	        0xBC
#define CMD_DMANOP	        0x18
#define CMD_DMARMB	        0x12
#define CMD_DMASEV	        0x34
#define CMD_DMAST	        0x08
#define CMD_DMASTP	        0x29
#define CMD_DMASTZ	        0x0C
#define CMD_DMAWFE	        0x36
#define CMD_DMAWFP	        0x30
#define CMD_DMAWMB	        0x13

#define SIZE_DMAADDH	    3
#define SIZE_DMAADNH        3
#define SIZE_DMAEND	        1
#define SIZE_DMAFLUSHP	    2
#define SIZE_DMALD	        1
#define SIZE_DMALDP	        2
#define SIZE_DMALP	        2
#define SIZE_DMALPEND	    2
#define SIZE_DMAKILL	    1
#define SIZE_DMAMOV	        6
#define SIZE_DMANOP	        1
#define SIZE_DMARMB	        1
#define SIZE_DMASEV	        2
#define SIZE_DMAST	        1
#define SIZE_DMASTP	        2
#define SIZE_DMASTZ	        1
#define SIZE_DMAWFE	        2
#define SIZE_DMAWFP	        2
#define SIZE_DMAWMB	        1
#define SIZE_DMAGO	        6

/* DMA Manager & Channel Status */
#define DMC_STS_STOPPED     0x0
#define DMC_STS_EXECUTING   0x1
#define DMC_STS_CACHE_MISS  0x2
#define DMC_STS_UPDATE_PC   0x3
#define DMC_STS_WFE         0x4
#define DMC_STS_AT_BARRIER  0x5
#define DMC_STS_WFP         0x7
#define DMC_STS_KILLING     0x8
#define DMC_STS_COMPLETING  0x9
#define DMC_STS_FAULT_COMP  0xE
#define DMC_STS_FAULTING    0xF

/* Operating states for the DMA manager thread and DMA channel threads */
#define DMA_STATE_STOPPED		(1 << 0)
#define DMA_STATE_EXECUTING		(1 << 1)
#define DMA_STATE_WFE			(1 << 2)
#define DMA_STATE_FAULTING		(1 << 3)
#define DMA_STATE_COMPLETING	(1 << 4)
#define DMA_STATE_WFP			(1 << 5)
#define DMA_STATE_KILLING		(1 << 6)
#define DMA_STATE_FAULT_COMP	(1 << 7)
#define DMA_STATE_CACHE_MISS	(1 << 8)
#define DMA_STATE_UPDATE_PC		(1 << 9)
#define DMA_STATE_AT_BARRIER	(1 << 10)
#define DMA_STATE_INVALID		(1 << 15)

/* Error code */
#define ERR_INVAL           1
#define ERR_CCR             2

#define THRD_ID_MANAGER     4
#define MAX_DMA_CH          4

/****************************************************************************
*       Macros
*****************************************************************************/
#define __CMD_DEBUG_MSG 1
#if __CMD_DEBUG_MSG
#define DBGCMD(_oft_, _x_...)   dma_printf("0x%08x: ", gCmdOft);\
								dma_printf(_x_);\
                                gCmdOft += _oft_;
#define DBGCMD_START(_addr_)    (gCmdOft = _addr_)
#else
#define DBGCMD(_oft_, _x_...)
#define DBGCMD_START(_addr_)
#endif

#define M_DMA_CLR_INT(_irq_)        (DMA->INTCLR |= (1 << _irq_))

/****************************************************************************
*       Enumeration Definitions
*****************************************************************************/
/*
 * Cache encoding in AXI Protocol
 * WA RA C  B :
 * 0  0  0  0  Noncacheable and nonbufferable
 * 0  0  0  1  Bufferable only
 * 0  0  1  0  Cacheable, but do not allocate
 * 0  0  1  1  Cacheable and bufferable, but do not allocate
 * 0  1  0  0  Reserved
 * 0  1  0  1  Reserved
 * 0  1  1  0  Cacheable write-through, allocate on reads only
 * 0  1  1  1  Cacheable write-back, allocate on reads only
 * 1  0  0  0  Reserved
 * 1  0  0  1  Reserved
 * 1  0  1  0  Cacheable write-through, allocate on writes only
 * 1  0  1  1  Cacheable write-back, allocate on writes only
 * 1  1  0  0  Reserved
 * 1  1  0  1  Reserved
 * 1  1  1  0  Cacheable write-through, allocate on both reads and writes
 * 1  1  1  1  Cacheable write-back, allocate on both reads and writes
 */

typedef enum            /* WA is tied LOW */
{                       /* WA RA C  B : Cache encoding in AXI Protocol */
	SCC_NCAH_NBUF,      /* 0  0  0  0  Noncacheable and nonbufferable */
	SCC_BUF,            /* 0  0  0  1  Bufferable only */
	SCC_CAH_NALC,       /* 0  0  1  0  Cacheable, but do not allocate */
	SCC_CAH_BUF_NALC,   /* 0  0  1  1  Cacheable and bufferable, but do not allocate */
	SCC_INVALID1,       /* 0  1  0  0  Reserved */
	SCC_INVALID2,       /* 0  1  0  1  Reserved */
	SCC_CAH_WTHR_ALC,   /* 0  1  1  0  Cacheable write-through, allocate on reads only */
	SCC_CAH_WBAK_ALC,   /* 0  1  1  1  Cacheable write-back, allocate on reads only */
	
}tSRC_CACHE_CTRL;

typedef enum            /* RA is tied LOW */
{                       /* WA RA C  B : Cache encoding in AXI Protocol */
	DCC_NCAH_NBUF,      /* 0  0  0  0  Noncacheable and nonbufferable */
	DCC_BUF,            /* 0  0  0  1  Bufferable only */
	DCC_CAH_NALC,       /* 0  0  1  0  Cacheable, but do not allocate */
	DCC_CAH_BUF_NALC,   /* 0  0  1  1  Cacheable and bufferable, but do not allocate */
	DCC_INVALID1,       /* 1  0  0  0  Reserved */
	DCC_INVALID2,       /* 1  0  0  1  Reserved */
	DCC_CAH_WTHR_ALC,   /* 1  0  1  0  Cacheable write-through, allocate on writes only */
	DCC_CAH_WBAK_ALC,   /* 1  0  1  1  Cacheable write-back, allocate on writes only */
}tDST_CACHE_CTRL;

typedef enum
{
	ESS_NO,
	ESS_2,
	ESS_4,
	ESS_8,
	ESS_16,
}tENDIAN_SWAP_SIZE;

typedef enum
{
    BS_1B,
    BS_2B,
    BS_4B,
    BS_8B,
//    BS_16B, // do not use b.c of 64bit bus
}tBURST_SIZE;

typedef enum
{
    BL_1XFER = 1,
    BL_2XFER,
    BL_3XFER,
    BL_4XFER,
    BL_5XFER,
    BL_6XFER,
    BL_7XFER,
    BL_8XFER,
    BL_9XFER,
    BL_10XFER,
    BL_11XFER,
    BL_12XFER,
    BL_13XFER,
    BL_14XFER,
    BL_15XFER,
    BL_16XFER,
}tBURST_LEN;

typedef enum
{
    IT_PERIPH,
    IT_PCELL,
}tID_TYPE;

typedef enum
{
    ERA_SAR, // Source Address Register
    ERA_DAR, // Destination Address Register
}tENC_RA;   // DMAADDH, DMAADNH

typedef enum
{
    EO_SINGLE,
    EO_BURST,
    EO_ALWAYS,
}tENC_OPE;  // S or B operand

typedef enum
{
    EOP_SINGLE,
    EOP_BURST,
    EOP_PERI,
}tENC_OPE_P;  // S or B operand and Periph

typedef enum
{
    ERD_SAR, // Source Address Register
    ERD_CCR, // Channel Control Register
    ERD_DAR, // Destination Address Register
}tENC_RD;   //DMAMOV

typedef enum
{
    RT_MEM_TO_MEM,
    RT_MEM_TO_DEV,
    RT_DEV_TO_MEM,
}tREQ_TYPE;

typedef enum
{
	/* The all xfers in the request were success. */
    OERR_NONE,
	/* If req aborted due to global error. */
    OERR_ABORT,
	/* If req failed due to problem with Channel. */
    OERR_FAIL,
}tOPE_ERR;

typedef enum
{
    DC_CH0,
    DC_CH1,
    DC_CH2,
    DC_CH3,
}tDMA_CH;

typedef enum
{
    DPN_UART0_SPI0_TX,
    DPN_UART0_SPI0_RX,
    DPN_UART1_SPI1_TX,
    DPN_UART1_SPI1_RX,
}tDMA_PERI_NUM;

typedef enum
{
    DO_START,
    DO_ABORT,
}tDMA_OPE;

/****************************************************************************
*       Structure Definitions
*****************************************************************************/
typedef union
{
    u32 d;
    struct {
        u32 srcInc:1;        // [0]
        u32 srcBurstSize:3;  // [3:1]
        u32 srcBurstLen:4;   // [7:4]
        u32 srcProtCtrl:3;   // [10:8]
        u32 srcCacheCtrl:3;  // [13:11]
        u32 dstInc:1;        // [14]
        u32 dstBurstSize:3;  // [17:15]
        u32 dstBurstLen:4;   // [21:18]
        u32 dstProtCtrl:3;   // [24:22]
        u32 dstCacheCtrl:3;  // [27:25]
        u32 endianSwapSize:3;// [30:28]
        u32 reserved:1;      // [31]
    }b;
}tCCR;
/*
typedef union
{
    u32 d;
    struct
    {
        u32 chStatus:4;
        u32 wakeNum:5;
        u32 rvd9:5;
        u32 wfp_b_ns:1;
        u32 wfp_periph:1;
        u32 rvd16:5;
        u32 chNonSecure:1;
        u32 rvd22:10;
    }b;
}tCSR;
*/
typedef struct
{
    BOOL srcInc;
    BOOL dstInc;

    /* Protection encoding
     * ARPROT[2:0]
     * [0] 1: privileged access,  0: normal access
     * [1] 1: nonsecure access,  0: secure access
     * [2] 1: instruction access,  0: data access
     */
    BOOL privileged;
    BOOL nonSecure;
    BOOL instruction;

    tBURST_LEN burstLen; // the number of data transfer beat. 1~16
    tBURST_SIZE burstSize; // the number of bytes per beat
    
    tSRC_CACHE_CTRL srcCacheCtrl;
    tDST_CACHE_CTRL dstCacheCtrl;
    tENDIAN_SWAP_SIZE swapSize;
    
}tDMA_REQ_CONF;

typedef struct
{
    BOOL nonSecure_ns; // Non-secure
    u8 chNum_cn;    // DMA channel number. 0~7
    u32 addr;       // which provides the value of the program counter for the DMA channel thread.
}tENC_ARG_GO;

typedef struct
{
    tENC_OPE operand_bs;
    BOOL nLoopCounter_lc; // determine Loop Counter Resiters 0 or 1 [0: Counter0,  1: Counter1]
    BOOL forever_nf;      // Forever flag [0: if DMALPFE started,  1: if DMALP started]
    u8 backJump;
}tENC_ARG_LPEND;

typedef struct
{
    u32 srcAddr;
    u32 dstAddr;
    u32 bytes;
}tDMA_XFER;

typedef struct 
{
    tREQ_TYPE reqType;
    u8 nPeri:5;
    tDMA_REQ_CONF reqConf;
	tDMA_XFER xfer;
}tDMA_REQ;

typedef struct
{
    u32 microCodeBufAddr;
    u32 microCodePhyAddr;
    volatile u8 *microCodeBuf;
    tCCR ccr;
    tDMA_REQ req;
}tDMA_REQ_INFO;

typedef struct
{
    u8 id; // DMA channel number
    u8 event; // DAM interrupt number
    tDMA_REQ_INFO reqInfo;
}tDMA_THREAD;

typedef struct
{
    tBURST_LEN burstLen;
    tBURST_SIZE burstSize;
    tDMA_CH dmaCh;
    tREQ_TYPE reqType;
    tDMA_PERI_NUM periNum;
    u32 srcAddr;
    u32 dstAddr;
    u32 xferBytes;
    u32 microCodeBase;
    u32 microCodePhysical;
}tDMA_INFO;

/****************************************************************************
*       Global Variable Definitions
*****************************************************************************/

/****************************************************************************
*       Global Function Definitions
*****************************************************************************/
void DMA_Init(void);
INT32 DMA_Req(tDMA_INFO *info);
void DMA_Ctrl(tDMA_OPE operation, tDMA_CH dmaCh);
void DMA_IsrAbort(void *param);
void DMA_Isr0(void *param);
void DMA_Isr1(void *param);
void DMA_Isr2(void *param);
void DMA_Isr3(void *param);
void DMA_dump(void);

#endif /* __DMA_PL330_H__ */

