

#include "../config/CR4_Config.h"
#include "../config/CR4_TopRegMap.h"
#include "../system/system.h"

#include "gicdrv.h"
#include "dma_pl330.h"

#include "../tdk/tdk.h"

/**
 * Debug command offset 변수
 */
u32 gCmdOft;
/**
 * Global DMA Thread 변수
 */
tDMA_THREAD gThrd[MAX_DMA_CH];

/**
 * Get Peripheral identification or PCELL identification
 * @param	*rDma	PL330 register pointer
 * @param	type	Peripheral or PCELL
 */
u32 DMA_GetId(tREG_DMA *rDma, tID_TYPE type)
{
	u32 id = 0;

	if(type==IT_PERIPH)
	{
		id |= rDma->PERIPH_ID_N[0];
		id |= rDma->PERIPH_ID_N[1]<<8;
		id |= rDma->PERIPH_ID_N[2]<<16;
		id |= rDma->PERIPH_ID_N[3]<<24;
	}
	else
	{
		id |= rDma->PCELL_ID_N[0];
		id |= rDma->PCELL_ID_N[1]<<8;
		id |= rDma->PCELL_ID_N[2]<<16;
		id |= rDma->PCELL_ID_N[3]<<24;
	}

	return id;
}

/**
 * Add Halfword adds an immediate 16-bit value to the SARn Register or DARn Register
 * @param	*buf	buffer for DMAADDH instruction encoding
 * @param	ra		SARn register(sets ra to 0)/DARn register(sets ra to 1)
 * @param	val		16-bit immediate value
 * @return	DMAADDH size
 */
u32 DMA_InstADDH(u8 *buf, tENC_RA ra, u16 val)
{
	buf[0] = CMD_DMAADDH;
	buf[0] |= ra<<1;
#if STRONG_ORDERED
	buf[1] = ((u8*)(&val))[0];
	buf[2] = ((u8*)(&val))[1];
#else
	*((u16 *)&buf[1]) = val;
#endif

	DBGCMD(SIZE_DMAADDH, "DMAADDH: %s 0x%4x\n", ra == 1 ? "DST" : "SRC", val);

	return SIZE_DMAADDH;
}

/**
 * Add Negative Halfword adds an immediate negative 16-bit value to the SARn Register or DARn Register
 * @param	*buf	buffer for DMAADNH instruction encoding
 * @param	ra		SARn register(sets ra to 0)/DARn register(sets ra to 1)
 * @param	val		16-bit immediate value
 * @return	DMAADNH size
 */
u32 DMA_InstADNH(u8 *buf, tENC_RA ra, u16 val)
{
	buf[0] = CMD_DMAADNH;
	buf[0] |= ra<<1;

#if STRONG_ORDERED
	buf[1] = ((u8*)(&val))[0];
	buf[2] = ((u8*)(&val))[1];
#else
	*((u16 *)&buf[1]) = val;
#endif

	DBGCMD(SIZE_DMAADNH, "DMAADNH: %s 0x%4x\n", ra == 1 ? "DST" : "SRC", val);

	return SIZE_DMAADNH;
}

/**
 * End signals to the DMAC that the DMA sequence is complete
 * @param	*buf	buffer for DMAEND instruction encoding
 * @return	DMAEND size
 */
u32 DMA_InstEND(u8 *buf)
{
	buf[0] = CMD_DMAEND;

	DBGCMD(SIZE_DMAEND, "DMAEND\n\n");

	return SIZE_DMAEND;
}

/**
 * Flush Peripheral clears the sate in the DMAC that describes the contents
 of the peripheral and sends a message to the peripheral to re-send its level status.
 * @param	*buf	buffer for DMAFLUSHP instruction encoding
 * @return	DMAFLUSHP size
 */
u32 DMA_InstFLUSHP(u8 *buf, u8 peri)
{
	buf[0] = CMD_DMAFLUSHP;

	peri = (peri&0x1F)<<3;
	buf[1] = peri;

	DBGCMD(SIZE_DMAFLUSHP, "DMAFLUSHP: peri %d\n", (peri >> 3));

	return SIZE_DMAFLUSHP;
}

/**
 * When the DMA manager executes GO for a DMA channel that is in the Stopped state
 * @param	*buf	buffer for DMAGO instruction encoding
 * @param	*arg	channel number and secure state
 * @return	DMAGO size
 */
u32 DMA_InstGO(u8 *buf, tENC_ARG_GO *arg)
{
	buf[0] = CMD_DMAGO;
	buf[0] |= arg->nonSecure_ns<<1;

	buf[1] = arg->chNum_cn&0x07;

#if STRONG_ORDERED
	buf[2] = ((u8*)(&arg->addr))[0];
	buf[3] = ((u8*)(&arg->addr))[1];
	buf[4] = ((u8*)(&arg->addr))[2];
	buf[5] = ((u8*)(&arg->addr))[3];
#else
	*((u32 *)&buf[2]) = arg->addr;
#endif

	dma_printf("DMAGO: channel %d, addr 0x%8x\n", arg->chNum_cn, arg->addr);

	return SIZE_DMAGO;
}

/**
 * Kill instructs the DMAC to immediately terminate execution of a thread
 * @param	*buf	buffer for DMAKILL instruction encoding
 * @return	DMAKILL size
 */
u32 DMA_InstKILL(u8 *buf)
{
	buf[0] = CMD_DMAKILL;

	dma_printf("DMAKILL\n");

	return SIZE_DMAKILL;
}

/**
 * Load instructs the DMAC to perform a DMA load, using AXI transactions
 that the SAR and CCR registers specify
 * @param	*buf	buffer for DMALD instruction encoding
 * @param	operand_bs	single or burst
 * @return	DMALD size
 */
u32 DMA_InstLD(u8 *buf, tENC_OPE operand_bs)
{
	buf[0] = CMD_DMALD;

	if(operand_bs==EO_SINGLE)
		buf[0] |= (0<<1)|(1<<0);
	else if(operand_bs==EO_BURST)
		buf[0] |= (1<<1)|(1<<0);
	else
		buf[0] |= (0<<1)|(0<<0); // the DMAC always executes a DMA load

	DBGCMD(SIZE_DMALD, "DMALD%c\n", operand_bs == EO_SINGLE ? 'S' : (operand_bs == EO_BURST ? 'B' : 'A'));

	return SIZE_DMALD;
}

/**
 * Load and notify Peripheral instructs the DMAC to perform a DMA load,
 using AXI transactions the SAR and CCR registers specify
 * @param	*buf	buffer for DMALDP instruction encoding
 * @param	operand_bs	single or burst
 * @param	peri	peripheral number(5-bit immediate, value 0-31)
 * @return	DMALDP size
 */
u32 DMA_InstLDP(u8 *buf, tENC_OPE operand_bs, u8 peri)
{
	buf[0] = CMD_DMALDP;

	if(operand_bs==EO_BURST)
		buf[0] |= (1<<1);

	peri = (peri&0x1F)<<3;
	buf[1] = peri;

	DBGCMD(SIZE_DMALDP, "DMALDP%c: peri %d\n", operand_bs == EO_SINGLE ? 'S' : 'B', (peri >> 3));

	return SIZE_DMALDP;
}

/**
 * Loop instructs the DMAC to load an 8-bit value into the Loop Counter Register
 * @param	*buf	buffer for DMALP instruction encoding
 * @param	nLoopCounter	LC0 register(set nLoopCounter to 0)/LC1 register(set nLoopCounter to 1)
 * @param	loopIteration	the number of loops to perform, range 1-256
 * @return	DMALP size
 */
u32 DMA_InstLP(u8 *buf, BOOL nLoopCounter, u16 loopIteration)
{
	buf[0] = CMD_DMALP;

	if(nLoopCounter) // determine Loop Counter Register
		buf[0] |= (1<<1);

	loopIteration--; // DMAC increments by 1
	buf[1] = (u8)loopIteration;

	DBGCMD(SIZE_DMALP, "DMALP_lc%c loop %d\n", nLoopCounter ? '1' : '0', (u8)loopIteration);

	return SIZE_DMALP;
}

/**
 * Loop End indicates the last instruction in the program loop
 * @param	*buf	buffer for DMALPEND instruction encoding
 * @param	*arg	bs - burst or single
 lc - loop counter 0/1register
 nf - DMALPFE started(set nf to 0)/DMALP started(set nf to 1)
 backwards_jump[7:0] - Sets the relative location of the first instruction in the program loop
 * @return	DMALPEND size
 */
u32 DMA_InstLPEND(u8 *buf, tENC_ARG_LPEND *arg)
{
	buf[0] = CMD_DMALPEND;

	if(arg->operand_bs==EO_SINGLE)
		buf[0] |= (0<<1)|(1<<0);
	else if(arg->operand_bs==EO_BURST)
		buf[0] |= (1<<1)|(1<<0);
	else
		buf[0] |= (0<<1)|(0<<0); // the DMAC always executes a DMA load

	if(arg->nLoopCounter_lc)
		buf[0] |= (1<<2);

	if(!arg->forever_nf)
		buf[0] |= (1<<4);

	buf[1] = arg->backJump;

    DBGCMD(SIZE_DMALPEND, "DMALP%s%c_lc%c: back jump to 0x%x\n", 
                            (arg->forever_nf ? "FE" : "END"),
                            (arg->operand_bs == EO_SINGLE ? 'S' : (arg->operand_bs == EO_BURST ? 'B' : 'A')),
                            (arg->nLoopCounter_lc ? '1' : '0'),
			arg->backJump);

	return SIZE_DMALPEND;
}

/**
 * Move instructs the DMAC to move a 32-bit immediate value(SAR, DAR, CCR)
 * @param	*buf	buffer for DMAMOVE instruction encoding
 * @param	rd		SAR(set rd to 0), CCR(set rd to 1), DAR(set rd to 2)
 * @param	val		32-bit immediate value
 * @return	DMAMOVE size
 */
u32 DMA_InstMOV(u8 *buf, tENC_RD rd, u32 val)
{
//	__SIM_DEBUG_REG(SIM_DEBUG_ADDR, buf);
	buf[0] = CMD_DMAMOV;
	buf[1] = rd;

//	__SIM_DEBUG(0x10a);

#if STRONG_ORDERED
	buf[2] = ((u8*)(&val))[0];
	buf[3] = ((u8*)(&val))[1];
	buf[4] = ((u8*)(&val))[2];
	buf[5] = ((u8*)(&val))[3];
#else
	*((u32 *)&buf[2]) = val;
#endif
//	__SIM_DEBUG(0x10b);

//	DBGCMD(SIZE_DMAMOV, "DMAMOV %s 0x%8x\n", rd == ERD_SAR ? "SAR" : (rd == ERD_DAR ? "DAR" : "CCR"), val);

	return SIZE_DMAMOV;
}

/**
 * No operation does nothing
 * @param	*buf	buffer for DMANOP instruction encoding
 * @return	DMANOP size
 */
u32 DMA_InstNOP(u8 *buf)
{
	buf[0] = CMD_DMANOP;

	DBGCMD(SIZE_DMANOP, "DMANOP\n");

	return SIZE_DMANOP;
}

/**
 * Read Memory Barrier function
 * @param	*buf	buffer for DMARMB instruction encoding
 * @return	DMARMB size
 */
u32 DMA_InstRMB(u8 *buf)
{
	buf[0] = CMD_DMARMB;

	DBGCMD(SIZE_DMARMB, "DMARMB\n");

	return SIZE_DMARMB;
}

/**
 * Send Event instructs the DMAC to modify an event-interrupt resource
 * @param	*buf	buffer for DMASEV instruction encoding
 * @param	event	event number(5-bit immediate, value 0-31)
 * @return	DMARMB size
 */
u32 DMA_InstSEV(u8 *buf, u8 event)
{
	buf[0] = CMD_DMASEV;

	event = (event&0x1F)<<3;
	buf[1] = event;

	DBGCMD(SIZE_DMASEV, "DMASEV %d\n", event>>3);

	return SIZE_DMASEV;
}

/**
 * Store instructs the DMAC to transfer data from the FIFO to the location DAR,
 using AXI transactions that the DAR and CCR registers specify
 * @param	*buf	buffer for DMAST instruction encoding
 * @param	operand_bs	single or burst
 * @return	DMAST size
 */
u32 DMA_InstST(u8 *buf, tENC_OPE operand_bs)
{
	buf[0] = CMD_DMAST;

	if(operand_bs==EO_SINGLE)
		buf[0] |= (0<<1)|(1<<0);
	else if(operand_bs==EO_BURST)
		buf[0] |= (1<<1)|(1<<0);
	else
		buf[0] |= (0<<1)|(0<<0); // the DMAC always executes a DMA load

	DBGCMD(SIZE_DMAST, "DMAST%c\n", operand_bs == EO_SINGLE ? 'S' : (operand_bs == EO_BURST ? 'B' : 'A'));

	return SIZE_DMAST;
}

/**
 * Store and notify Peripheral instructs the DMAC to transfer data from
 the FIFO to the location that the DAR specifies, using AXI transactions the SAR and CCR registers specify
 * @param	*buf	buffer for DMASTP instruction encoding
 * @param	operand_bs	single or burst
 * @param	peri	peripheral number(5-bit immediate, value 0-31)
 * @return	DMASTP size
 */
u32 DMA_InstSTP(u8 *buf, tENC_OPE operand_bs, u8 peri)
{
	buf[0] = CMD_DMASTP;

	if(operand_bs==EO_BURST)
		buf[0] |= 1<<1;

	peri = (peri&0x1F)<<3;
	buf[1] = peri;

	DBGCMD(SIZE_DMASTP, "DMASTP%c peri %d\n", operand_bs == EO_SINGLE ? 'S' : 'B', peri >> 3);

	return SIZE_DMASTP;
}

/**
 * Store Zero instructs the DMAC to store zeros, using AXI transactions that the DAR and CCR registers specify
 * @param	*buf	buffer for DMASTZ instruction encoding
 * @return	DMASTZ size
 */
u32 DMA_InstSTZ(u8 *buf)
{
	buf[0] = CMD_DMASTZ;

	DBGCMD(SIZE_DMASTZ, "DMASTZ\n");

	return SIZE_DMASTZ;
}

/**
 * Wait For Event instructs the DMAC to halt execution of the thread until the event, that event_num specifies, occurs
 * @param	*buf	buffer for DMAWFE instruction encoding
 * @param	invalid	invalid is present(set invalid to 1)
 * @param	event	event number(5-bit immediate, value 0-31)
 * @return	DMAWFE size
 */
u32 DMA_InstWFE(u8 *buf, BOOL invalid, u8 event)
{
	buf[0] = CMD_DMAWFE;

	event = (event&0x1F)<<3;
	buf[1] = event;

	if(invalid)
		buf[1] |= 1<<1;

	DBGCMD(SIZE_DMAWFE, "DMAWFE %d, %c\n", event >> 3, invalid ? 'I' : ' ');

	return SIZE_DMAWFE;
}

/**
 * Wait For Peripheral instructs the DMAC to halt execution of the thread until the specified peripheral signals a DMA request for that DMA channel
 * @param	*buf	buffer for DMAWFP instruction encoding
 * @param	operand_bsp	single(set bs to 0 and p to 0), burst(set bs to q and p to 0), periph(set bs to 0 and p to 1)
 * @param	peri	peripheral number(5-bit immediate, value 0-31)
 * @return	DMAWFP size
 */
u32 DMA_InstWFP(u8 *buf, tENC_OPE_P operand_bsp, u8 peri)
{
	buf[0] = CMD_DMAWFP;

	if(operand_bsp==EOP_SINGLE)
		buf[0] |= (0<<1)|(0<<0);
	else if(operand_bsp==EOP_BURST)
		buf[0] |= (1<<1)|(0<<0);
	else
		buf[0] |= (0<<1)|(1<<0);

	peri = (peri&0x1F)<<3;
	buf[1] = peri;

    DBGCMD(SIZE_DMAWFP, "DMAWFP%c peri %d\n", 
        operand_bsp == EOP_SINGLE ? 'S' : (operand_bsp == EOP_BURST ? 'B' : 'P'), peri >> 3);

	return SIZE_DMAWFP;
}

/**
 * Write Memory Barrier function
 * @param	*buf	buffer for DMAWMB instruction encoding
 * @return	DMAWMB size
 */
u32 DMA_InstWMB(u8 *buf)
{
	buf[0] = CMD_DMAWMB;

	DBGCMD(SIZE_DMAWMB, "DMAWMB\n");

	return SIZE_DMAWMB;
}

/**
 * CCR argument description prepare function
 * @param	*reqConf	CCR argument structure pointer
 * @return	CCR argument structure
 */
tCCR DMA_PrepareCCR(tDMA_REQ_CONF *reqConf)
{
	tCCR ccr = { 0 };

	ccr.d = 0;
	/* set the burst address type */
	if(reqConf->srcInc)
		ccr.b.srcInc = 1;
	if(reqConf->dstInc)
		ccr.b.dstInc = 1;

	/* configure burst transfer */
	ccr.b.srcBurstSize = reqConf->burstSize;
	ccr.b.dstBurstSize = reqConf->burstSize;

	ccr.b.srcBurstLen = reqConf->burstLen-1;
	ccr.b.dstBurstLen = reqConf->burstLen-1;

	/* set protection levels for source and destination */
	if(reqConf->privileged)
	{
		ccr.b.srcProtCtrl |= 1;
		ccr.b.dstProtCtrl |= 1;
	}
	if(reqConf->nonSecure)
	{
		ccr.b.srcProtCtrl |= 1<<1;
		ccr.b.dstProtCtrl |= 1<<1;
	}
	if(reqConf->instruction)
	{
		ccr.b.srcProtCtrl |= 1<<2;
		ccr.b.dstProtCtrl |= 1<<2;
	}

	/* set cache control */
	ccr.b.srcCacheCtrl = reqConf->srcCacheCtrl;
	ccr.b.dstCacheCtrl = reqConf->dstCacheCtrl;

	return ccr;
}

/**
 * CCR valid check function
 * @param	ccr	CCR argument structure
 * @return	valid check state
 */
BOOL DMA_IsValidCCR(tCCR ccr)
{
	if((ccr.b.srcCacheCtrl == SCC_INVALID1) || (ccr.b.srcCacheCtrl == SCC_INVALID2) ||
	   (ccr.b.dstCacheCtrl == DCC_INVALID1) || (ccr.b.dstCacheCtrl == DCC_INVALID2))
		return FALSE;
	else
		return TRUE;
}

/**
 * DMA burst code size setting function
 * @param	*req	DMA request structure
 * @return	code size
 */
u32 DMA_GetBurstCodeSize(tDMA_REQ *req)
{
	u32 oft = 0;

	switch(req->reqType)
	{
		case RT_MEM_TO_MEM: // oft = 4
			oft += SIZE_DMALD;
			oft += SIZE_DMARMB;
			oft += SIZE_DMAST;
			oft += SIZE_DMAWMB;
			break;

		case RT_MEM_TO_DEV: // oft = 7
			oft += SIZE_DMAWFP;
			oft += SIZE_DMALD;
			oft += SIZE_DMASTP;
			oft += SIZE_DMAFLUSHP;
			break;

		case RT_DEV_TO_MEM: // oft = 7
			oft += SIZE_DMAWFP;
			oft += SIZE_DMALDP;
			oft += SIZE_DMAST;
			oft += SIZE_DMAFLUSHP;
			break;

		default: // not support
			oft += 0x40000000; /* Scare off the Client */
			break;
	}

	return oft;
}

/**
 * Memory to memory data transfer function
 * @param	*buf	buffer for each instruction encoding
 * @param	*req	DMA request structure pointer
 * @param	cyc	M2M cycle number
 * @return	offset
 */
u32 DMA_LoadStoreMemToMem(u8 *buf, tDMA_REQ *req, u32 cyc)
{
	u32 oft = 0;

	while(cyc--)
	{
		oft += DMA_InstLD(&buf[oft], EO_ALWAYS);
		oft += DMA_InstRMB(&buf[oft]);
		oft += DMA_InstST(&buf[oft], EO_ALWAYS);
		oft += DMA_InstWMB(&buf[oft]);
	}

	return oft;
}

/**
 * Memory to device data transfer function
 * @param	*buf	buffer for each instruction encoding
 * @param	*req	DMA request structure pointer
 * @param	cyc	M2D cycle number
 * @return	offset
 */
u32 DMA_LoadStoreMemToDev(u8 *buf, tDMA_REQ *req, u32 cyc)
{
	u32 oft = 0;

	while(cyc--)
	{
		oft += DMA_InstWFP(&buf[oft], EOP_SINGLE, req->nPeri);
		oft += DMA_InstLD(&buf[oft], EO_ALWAYS);
		oft += DMA_InstSTP(&buf[oft], EO_SINGLE, req->nPeri);
		oft += DMA_InstFLUSHP(&buf[oft], req->nPeri);
	}

	return oft;
}

/**
 * Device to memory data transfer function
 * @param	*buf	buffer for each instruction encoding
 * @param	*req	DMA request structure pointer
 * @param	cyc	D2M cycle number
 * @return	offset
 */
u32 DMA_LoadStoreDevToMem(u8 *buf, tDMA_REQ *req, u32 cyc)
{
	u32 oft = 0;

	while(cyc--)
	{
		oft += DMA_InstWFP(&buf[oft], EOP_SINGLE, req->nPeri);
		oft += DMA_InstLDP(&buf[oft], EO_SINGLE, req->nPeri);
		oft += DMA_InstST(&buf[oft], EO_ALWAYS);
		oft += DMA_InstFLUSHP(&buf[oft], req->nPeri);
	}

	return oft;
}

/**
 * DMA burst transaction function
 * @param	*buf	buffer for each instruction encoding
 * @param	*req	DMA request structure pointer
 * @param	cyc	M2M cycle number
 * @return	offset
 */
u32 DMA_Bursts(u8 *buf, tDMA_REQ *req, u32 cyc)
{
	u32 oft = 0;

	switch(req->reqType)
	{
		case RT_MEM_TO_MEM:
			oft += DMA_LoadStoreMemToMem(&buf[oft], req, cyc);
			break;

		case RT_MEM_TO_DEV:
			oft += DMA_LoadStoreMemToDev(&buf[oft], req, cyc);
			break;

		case RT_DEV_TO_MEM:
			oft += DMA_LoadStoreDevToMem(&buf[oft], req, cyc);
			break;

		default: // not support
			oft += 0x40000000; /* Scare off the Client */
			break;
	}

	return oft;
}

/**
 * DMA loop operation function
 * @param	*buf	buffer for each instruction encoding
 * @param	*bursts	burst size
 * @param	*req	DMA request structure pointer
 * @return	offset
 */
u32 DMA_Loop(u8 *buf, u32 *bursts, tDMA_REQ *req)
{
	u32 cyc, cycmax, sizeLp, sizeLpend, sizeBurst, oft;
	u32 loopCnt0, loopCnt1;
	u32 loopJump0 = 0, loopJump1;
	tENC_ARG_LPEND lpend;

	/* Max iterations possible in DMALP is 256 */
	if(*bursts>=256*256)
	{
		loopCnt1 = 256;
		loopCnt0 = 256;
		cyc = *bursts/loopCnt1/loopCnt0;
	}
	else if(*bursts>256)
	{
		loopCnt1 = 256;
		loopCnt0 = *bursts/loopCnt1;
		cyc = 1;
	}
	else
	{
		loopCnt1 = *bursts;
		loopCnt0 = 0;
		cyc = 1;
	}

	sizeLp = SIZE_DMALP;
	sizeBurst = DMA_GetBurstCodeSize(req);
	sizeLpend = SIZE_DMALPEND;

	if(loopCnt0)
	{
		sizeLp *= 2;
		sizeLpend *= 2;
	}

	/*
	 * Max bursts that we can unroll due to limit on the
	 * size of backward jump that can be encoded in DMALPEND
	 * which is 8-bits and hence 255
	 */
	cycmax = (255-(sizeLp+sizeLpend))/sizeBurst;
	cyc = (cycmax<cyc) ? cycmax : cyc;
	oft = 0;

	if(loopCnt0)
	{
		oft += DMA_InstLP(&buf[oft], 0, loopCnt0);
		loopJump0 = oft;
	}

	oft += DMA_InstLP(&buf[oft], 1, loopCnt1);
	loopJump1 = oft;

	oft += DMA_Bursts(&buf[oft], req, cyc);

	lpend.operand_bs = EO_ALWAYS;
	lpend.forever_nf = FALSE;
	lpend.nLoopCounter_lc = 1;
	lpend.backJump = oft-loopJump1;
	oft += DMA_InstLPEND(&buf[oft], &lpend);

	if(loopCnt0)
	{
		lpend.operand_bs = EO_ALWAYS;
		lpend.forever_nf = FALSE;
		lpend.nLoopCounter_lc = 0;
		lpend.backJump = oft-loopJump0;
		oft += DMA_InstLPEND(&buf[oft], &lpend);
	}

	*bursts = loopCnt1*cyc;
	if(loopCnt0)
		*bursts *= loopCnt0;

	return oft;
}

/**
 * DMA loop setting function
 * @param	*buf	buffer for each instruction encoding
 * @param	*reqInfo	DMA request information structure pointer
 * @return	offset
 */
u32 DMA_SetupLoops(u8 *buf, tDMA_REQ_INFO *reqInfo)
{
	tDMA_REQ_CONF *rc = &reqInfo->req.reqConf;
	tDMA_XFER *xfer = &reqInfo->req.xfer;
	u32 oft = 0;
	u32 bursts, cnt;

	bursts = xfer->bytes/(1<<rc->burstSize)/rc->burstLen;
	while(bursts)
	{
		cnt = bursts;
		oft += DMA_Loop(&buf[oft], &cnt, &reqInfo->req);
		bursts -= cnt;
	}

	return oft;
}

/**
 * DMA transaction setting function
 * @param	*buf	buffer for each instruction encoding
 * @param	*reqInfo	DMA request information structure pointer
  * @return	offset
 */
u32 DMA_SetupXfer(u8 *buf, tDMA_REQ_INFO *reqInfo)
{
	tDMA_XFER *xfer = &reqInfo->req.xfer;
	u32 oft = 0;

	oft += DMA_InstMOV(&buf[oft], ERD_SAR, xfer->srcAddr);
	oft += DMA_InstMOV(&buf[oft], ERD_DAR, xfer->dstAddr);

	if(reqInfo->req.reqType==RT_DEV_TO_MEM||reqInfo->req.reqType==RT_MEM_TO_DEV)
		oft += DMA_InstFLUSHP(&buf[oft], reqInfo->req.nPeri);
	oft += DMA_SetupLoops(&buf[oft], reqInfo);

	return oft;
}

/**
 * DMA request setting function
 * @param	*buf	buffer for each instruction encoding
 * @param	*reqInfo	DMA request information structure pointer
 * @return	offset
 */
INT32 DMA_SetupReq(tDMA_THREAD *thrd)
{
	u8 *buf = (u8 *)thrd->reqInfo.microCodeBuf;
	tDMA_REQ_INFO *ri = &thrd->reqInfo;
	tDMA_REQ_CONF *rc = &thrd->reqInfo.req.reqConf;
	tDMA_XFER *xfer = &thrd->reqInfo.req.xfer;
	u32 oft = 0;

	DBGCMD_START(ri->microCodeBufAddr);

	/* DMAMOV CCR */
	oft += DMA_InstMOV(&buf[oft], ERD_CCR, ri->ccr.d);

	do
	{
		if(xfer->bytes%((1<<rc->burstSize)*rc->burstLen))
		{
			tdk_printf("rc->burstSize=%d, rc->burstLen=%d\n", rc->burstSize, rc->burstLen);
			return -ERR_INVAL;
		}

		oft += DMA_SetupXfer(&buf[oft], ri);
	} while(0);

	/* DMASEV peripheral/event */
	oft += DMA_InstSEV(&buf[oft], thrd->event);

	/* DMAEND */
	oft += DMA_InstEND(&buf[oft]);

	return oft;
}

/**
 * CCR register and DMA request setup function
 * @param	*buf	buffer for each instruction encoding
 * @param	*reqInfo	DMA request information structure pointer
 * @return	offset
 */
INT32 DMA_SubmitReq(tDMA_THREAD *thrd)
{
	tDMA_REQ_CONF *rc = &thrd->reqInfo.req.reqConf;
	INT32 ret;

	/* Prepare CCR */
	thrd->reqInfo.ccr = DMA_PrepareCCR(rc);
	if(!DMA_IsValidCCR(thrd->reqInfo.ccr))
	{
		dma_printf("Invalid CCR\n");
		return -ERR_CCR;
	}

	/* Setup Request */
	ret = DMA_SetupReq(thrd);

	return ret;

}

/**
 * DMA access type check function
 * @param	*thrd	DMA thread id pointer
 * @return	access type state
 */
BOOL DMA_IsManager(tDMA_THREAD *thrd)
{
	if(thrd->id==THRD_ID_MANAGER)
		return TRUE;
	else
		return FALSE;
}

/**
 * The operating states for the DMA manager thread and DMA channel threads check function
 * @param	*rDma	PL330 register pointer
 * @param	*thrd	DMA thread ID pointer
 * @return	DMA state
 */
u32 DMA_GetState(tREG_DMA *rDma, tDMA_THREAD *thrd)
{
	u32 status;

	if(DMA_IsManager(thrd))
		status = rDma->DSR&DSR_DS_MASK;
	else
		status = rDma->CTSR[thrd->id].CSR&CSR_CS_MASK;

	dma_printf("status=0x%08x\n", status);

	switch(status)
	{
		case DMC_STS_STOPPED:
			return DMA_STATE_STOPPED;
		case DMC_STS_EXECUTING:
			return DMA_STATE_EXECUTING;
		case DMC_STS_CACHE_MISS:
			return DMA_STATE_CACHE_MISS;
		case DMC_STS_UPDATE_PC:
			return DMA_STATE_UPDATE_PC;
		case DMC_STS_WFE:
			return DMA_STATE_WFE;
		case DMC_STS_FAULTING:
			return DMA_STATE_FAULTING;
		case DMC_STS_AT_BARRIER:
			if(DMA_IsManager(thrd))
				return DMA_STATE_INVALID;
			else
				return DMA_STATE_AT_BARRIER;
		case DMC_STS_WFP:
			if(DMA_IsManager(thrd))
				return DMA_STATE_INVALID;
			else
				return DMA_STATE_WFP;
		case DMC_STS_KILLING:
			if(DMA_IsManager(thrd))
				return DMA_STATE_INVALID;
			else
				return DMA_STATE_KILLING;
		case DMC_STS_COMPLETING:
			if(DMA_IsManager(thrd))
				return DMA_STATE_INVALID;
			else
				return DMA_STATE_COMPLETING;
		case DMC_STS_FAULT_COMP:
			if(DMA_IsManager(thrd))
				return DMA_STATE_INVALID;
			else
				return DMA_STATE_FAULT_COMP;
		default:
			return DMA_STATE_INVALID;
	}
}

/**
 * Debug idle state waiting function
 * @param	*rDma	PL330 register pointer
 * @return	debug idle state
 */
BOOL DMA_WaitDbgIdle(tREG_DMA *rDma)
{
	u32 cnt = 50;

	do
	{
		if(!(rDma->DBGSTATUS&DBGSTS_BUSY))
			return TRUE;

		SYS_Delay(10);
	} while(--cnt);

	return FALSE;
}

/**
 * Desired DMA state waiting function
 * @param	*rDma	PL330 register pointer
 * @param	*thrd	DMA thread pointer
 * @param	state	DMA state
 */
void DMA_WaitDmaState(tREG_DMA *rDma, tDMA_THREAD *thrd, u32 state)
{
	while(!(DMA_GetState(rDma, thrd)&state));
}

/**
 * Debug instruction executing function
 * @param	*rDma	PL330 register pointer
 * @param	*thrd	DMA thread pointer
 * @param	state	DMA state
 */
void DMA_ExecuteDBGINS(tREG_DMA *rDma, tDMA_THREAD *thrd, u8 *buf, BOOL asManager)
{
	u32 val;

	val = (buf[1]<<24)|(buf[0]<<16);
	if(!asManager)
	{
		val |= 1<<0;
		val |= thrd->id<<8;
	}
	rDma->DBGINST0 = val;

#if STRONG_ORDERED
	((u8*)(&val))[0] = buf[2];
	((u8*)(&val))[1] = buf[3];
	((u8*)(&val))[2] = buf[4];
	((u8*)(&val))[3] = buf[5];
	__SIM_DEBUG(val);
#else
	val = *((u32 *)&buf[2]);
#endif
	rDma->DBGINST1 = val;

	if(!DMA_WaitDbgIdle(rDma))
	{
		dma_printf("DBG Busy!\n");
		return;
	}

	/* Get going */
	rDma->DBGCMD = 0;
}

/**
 * DMA trigger function
 * @param	*rDma	PL330 register pointer
 * @param	*thrd	DMA thread pointer
 * @return	DMA state
 */
BOOL DMA_Trigger(tREG_DMA *rDma, tDMA_THREAD *thrd)
{
	tDMA_REQ_CONF *rc = &thrd->reqInfo.req.reqConf;
	tENC_ARG_GO go;
	u8 buf[6] = { 0 };

	/* Return if already ACTIVE */
	if(DMA_GetState(rDma, thrd)!=DMA_STATE_STOPPED)
		return TRUE;

	go.chNum_cn = thrd->id;
	go.addr = thrd->reqInfo.microCodePhyAddr;

//	tdk_printf("go.addr=0x%08x\n", thrd->reqInfo.microCodeBufAddr);
//	tdk_printf("go.addr=0x%08x\n", thrd->reqInfo.microCodePhyAddr);

	go.nonSecure_ns = rc->nonSecure;
	DMA_InstGO(buf, &go);

	/* Set to generate interrupts for SEV */
	dma_printf("rDma->INTEN=0x%08x\n", rDma->INTEN);
	rDma->INTEN |= 1<<thrd->event;

	/* Only manager can execute GO */
	DMA_ExecuteDBGINS(rDma, thrd, buf, TRUE);

	return TRUE;
}

/**
 * DMA stop function
 * @param	*rDma	PL330 register pointer
 * @param	*thrd	DMA thread pointer
 */
void DMA_Stop(tREG_DMA *rDma, tDMA_THREAD *thrd)
{
	u8 buf[6] = { 0 };

	if(DMA_GetState(rDma, thrd)==DMA_STATE_FAULT_COMP)
		DMA_WaitDmaState(rDma, thrd, (DMA_STATE_FAULTING|DMA_STATE_KILLING));

	/* Return if nothing needs to be done */
    if(DMA_GetState(rDma, thrd) == DMA_STATE_COMPLETING ||
        DMA_GetState(rDma, thrd) == DMA_STATE_KILLING ||
        DMA_GetState(rDma, thrd) == DMA_STATE_STOPPED)
		return;

	DMA_InstKILL(buf);

	rDma->INTEN &= ~(1<<thrd->event);
	DMA_ExecuteDBGINS(rDma, thrd, buf, TRUE);
}

/**
 * DMA start function
 * @param	*rDma	PL330 register pointer
 * @param	*thrd	DMA thread pointer
 * @return	DMA state
 */
BOOL DMA_Start(tREG_DMA *rDma, tDMA_THREAD *thrd)
{
	int state = DMA_GetState(rDma, thrd);

	switch(state)
	{
		case DMA_STATE_FAULT_COMP:
			dma_printf("state = DMA_STATE_FAULT_COMP\n");
			DMA_WaitDmaState(rDma, thrd, (DMA_STATE_FAULTING|DMA_STATE_KILLING));

			if(DMA_GetState(rDma, thrd)==DMA_STATE_KILLING)
				DMA_WaitDmaState(rDma, thrd, DMA_STATE_STOPPED);
			break;

		case DMA_STATE_FAULTING:
			dma_printf("state = DMA_STATE_FAULTING\n");
			DMA_Stop(rDma, thrd);
			break;

		case DMA_STATE_KILLING:
			dma_printf("state = DMA_STATE_KILLING\n");
			DMA_WaitDmaState(rDma, thrd, DMA_STATE_STOPPED);
			break;
		case DMA_STATE_COMPLETING:
			dma_printf("state = DMA_STATE_COMPLETING\n");
			DMA_WaitDmaState(rDma, thrd, DMA_STATE_STOPPED);
			break;

		case DMA_STATE_STOPPED:
			dma_printf("state = DMA_STATE_STOPPED\n");
			return DMA_Trigger(rDma, thrd);

		case DMA_STATE_AT_BARRIER:
		case DMA_STATE_WFP:
		case DMA_STATE_UPDATE_PC:
		case DMA_STATE_CACHE_MISS:
		case DMA_STATE_EXECUTING:
			return TRUE;

		case DMA_STATE_WFE: /* For RESUME, nothing yet */
		default:
			return FALSE;
	}

	return TRUE;
}

/**
 * DMA initialize function
 */
void DMA_Init(void)
{
	u32 i;
	tDMA_REQ_CONF *rc;

	for(i = 0; i<MAX_DMA_CH; i++)
	{
		rc = &gThrd[i].reqInfo.req.reqConf;

		rc->srcInc = 1;
		rc->dstInc = 1;

		/* set Protection unit control */
		rc->privileged = 0;
		rc->nonSecure = 0;
		rc->instruction = 0;

		rc->burstSize = BS_1B;
		rc->burstLen = BL_1XFER;
		rc->srcCacheCtrl = SCC_NCAH_NBUF;
		rc->dstCacheCtrl = DCC_NCAH_NBUF;
		rc->swapSize = ESS_NO;
	}
}

/**
 * DMA request type setting function
 * @param	*rDma	PL330 register pointer
 * @param	*thrd	DMA thread pointer
 * @return	DMA state
 */
INT32 DMA_Req(tDMA_INFO *info)
{
	tDMA_THREAD *thrd = &gThrd[info->dmaCh];
	tDMA_REQ_INFO *ri = &thrd->reqInfo;
	tDMA_REQ_CONF *rc = &ri->req.reqConf;
	tDMA_XFER *xfer = &ri->req.xfer;
	INT32 ret;

	ri->microCodeBufAddr = info->microCodeBase;
	ri->microCodePhyAddr = info->microCodePhysical;

	ri->microCodeBuf = (volatile u8 *)ri->microCodeBufAddr;
	if(info->reqType==RT_MEM_TO_MEM)
	{
		rc->srcInc = 1;
		rc->dstInc = 1;
	}
	else if(info->reqType==RT_MEM_TO_DEV)
	{
		rc->srcInc = 1;
		rc->dstInc = 0;
		ri->req.nPeri = info->periNum;
	}
	else if(info->reqType==RT_DEV_TO_MEM)
	{
		rc->srcInc = 0;
		rc->dstInc = 1;
		ri->req.nPeri = info->periNum;
	}

	thrd->id = info->dmaCh;
	thrd->event = thrd->id;
	rc->burstLen = info->burstLen;
	rc->burstSize = info->burstSize;
	ri->req.reqType = info->reqType;

	xfer->srcAddr = info->srcAddr;
	xfer->dstAddr = info->dstAddr;
	xfer->bytes = info->xferBytes;

	ret = DMA_SubmitReq(thrd);
	if(ret<=0)
		dma_printf("DMA Requst Error!\n");

	return ret;
}

/**
 * DMA operation start or abort control function
 * @param	operation	DMA operation state
 * @param	dmaCh	DMA channel number
 * @return	DMA state
 */
void DMA_Ctrl(tDMA_OPE operation, tDMA_CH dmaCh)
{
	tDMA_THREAD *thrd = &gThrd[dmaCh];

	switch(operation)
	{
		case DO_START:
			DMA_Start(DMA, thrd);
			break;

		case DO_ABORT:
			break;
	}
}


/**
 * DMA ABORT ISR handler function
 */
void DMA_IsrAbort(void *param)
{
	dma_printf("Abort!\n");
}

/**
 * DMA channel 0 ISR handler function
 */
void DMA_Isr0(void *param)
{
	M_DMA_CLR_INT(0);
	dma_printf("DMA CH0 Interrupt\n");
}

/**
 * DMA channel 1 ISR handler function
 */
void DMA_Isr1(void *param)
{
	M_DMA_CLR_INT(1);
	dma_printf("DMA CH1 Interrupt\n");
}

/**
 * DMA channel 2 ISR handler function
 */
void DMA_Isr2(void *param)
{
	M_DMA_CLR_INT(2);
	dma_printf("DMA CH2 Interrupt\n");
}

/**
 * DMA channel 3 ISR handler function
 */
void DMA_Isr3(void *param)
{
	M_DMA_CLR_INT(3);
	dma_printf("DMA CH3 Interrupt\n");
}

/*
 *
    u32 DSR;             // [0x000][RO] DMA Manager Status Register
    u32 DPC;             // [0x004][RO] DMA Program Counter Register
    u32 reserved_008_01c[6];
    u32 INTEN;           // [0x020][RW] Interrupt Enable Register
    u32 INT_EVENT_RIS;   // [0x024][RO] Event-Interrupt Raw Status Register
    u32 INTMIS;          // [0x028][RO] Interrupt Status Register
    u32 INTCLR;          // [0x02C][WO] Interrupt Clear Register
    u32 FSRD;            // [0x030][RO] Fault Status DMA Manager Register
    u32 FSRC;            // [0x034][RO] Fault Status DMA Channel Register
    u32 FTRD;            // [0x038][RO] Fault Type DMA Manager Register
    u32 reserved_03c;
    u32 FTR[8];          // [0x040][RO] Fault type for DMA channel[0:7]
    u32 reserved_060_0fc[40];
    tCH_THRD_STS_REG CTSR[8];// [0x100:0x13C][RO] DMA Channel Thread Status Registers
    u32 reserved_140_3fc[176];
    tAXI_STS_LC_REG ASLR[8]; // [0x400:0x4FC][RO] AXI Status and Loop Counter Registers
    u32 reserved_500_cfc[512];
    u32 DBGSTATUS;       // [0xD00][RO] Debug Status Register
    u32 DBGCMD;          // [0xD04][WO] Debug Command Register, WO
    u32 DBGINST0;        // [0xD08][WO] Debug Instruction-0 Register, WO
    u32 DBGINST1;        // [0xD0C][WO] Debug Instruction-1 Register, WO
    u32 reserved_d10_dfc[60];
    u32 CR0;             // [0xE00][RO] Configuration Register 0
    u32 CR1;             // [0xE04][RO] Configuration Register 1
    u32 CR2;             // [0xE08][RO] Configuration Register 2
    u32 CR3;             // [0xE0C][RO] Configuration Register 3
    u32 CR4;             // [0xE10][RO] Configuration Register 4
    u32 CRD;             // [0xE14][RO] DMA Configuration Register
    u32 reserved_e18_e7c[26];
    u32 WD;              // [0xE80][RW] Watchdog Register, RW
    u32 reserved_e84_fdc[87];
    u32 PERIPH_ID_N[4];  // [0xFE0][RO] Peripheral Identification Registers
    u32 PCELL_ID_N[4];   // [0xFF0][RO] Component Identification Registers
}tREG_DMA;
 */

void DMA_dump(void)
{
#if IS_BOARD()
   tREG_DMA *rDma = DMA;

	tdk_printf("rDma->DSR                        = 0x%08x\n",   rDma->DSR                        ); // [0x000][RO] DMA Manager Status Register
    tdk_printf("rDma->DPC                        = 0x%08x\n",   rDma->DPC                        ); // [0x004][RO] DMA Program Counter Register
    tdk_printf("rDma->INTEN                      = 0x%08x\n",   rDma->INTEN                      ); // [0x020][RW] Interrupt Enable Register
    tdk_printf("rDma->INT_EVENT_R                = 0x%08x\n",   rDma->INT_EVENT_RIS              ); // [0x024][RO] Event-Interrupt Raw Status Register
    tdk_printf("rDma->INTMIS                     = 0x%08x\n",   rDma->INTMIS                     ); // [0x028][RO] Interrupt Status Register
    tdk_printf("rDma->INTCLR                     = 0x%08x\n",   rDma->INTCLR                     ); // [0x02C][WO] Interrupt Clear Register
    tdk_printf("rDma->FSRD                       = 0x%08x\n",   rDma->FSRD                       ); // [0x030][RO] Fault Status DMA Manager Register
    tdk_printf("rDma->FSRC                       = 0x%08x\n",   rDma->FSRC                       ); // [0x034][RO] Fault Status DMA Channel Register
    tdk_printf("rDma->FTRD                       = 0x%08x\n",   rDma->FTRD                       ); // [0x038][RO] Fault Type DMA Manager Register
//    tdk_printf("rDma->FTR[8]                     = 0x%08x\n",   rDma->FTR[8]                     ); // [0x040][RO] Fault type for DMA channel[0:7]
//    tdk_printf("tCH_THRD_STS_REG CTSR[8]       = 0x%08x\n",   tCH_THRD_STS_REG CTSR[8]         ); // [0x100:0x13C][RO] DMA Channel Thread Status Registers
//    tdk_printf("tAXI_STS_LC_REG ASLR[8]        = 0x%08x\n",   tAXI_STS_LC_REG ASLR[8]          ); // [0x400:0x4FC][RO] AXI Status and Loop Counter Registers
    tdk_printf("rDma->DBGSTATUS                  = 0x%08x\n",   rDma->DBGSTATUS                  ); // [0xD00][RO] Debug Status Register
    tdk_printf("rDma->DBGCMD                     = 0x%08x\n",   rDma->DBGCMD                     ); // [0xD04][WO] Debug Command Register, WO
    tdk_printf("rDma->DBGINST0                   = 0x%08x\n",   rDma->DBGINST0                   ); // [0xD08][WO] Debug Instruction-0 Register, WO
    tdk_printf("rDma->DBGINST1                   = 0x%08x\n",   rDma->DBGINST1                   ); // [0xD0C][WO] Debug Instruction-1 Register, WO
    tdk_printf("rDma->CR0                        = 0x%08x\n",   rDma->CR0                        ); // [0xE00][RO] Configuration Register 0
    tdk_printf("rDma->CR1                        = 0x%08x\n",   rDma->CR1                        ); // [0xE04][RO] Configuration Register 1
    tdk_printf("rDma->CR2                        = 0x%08x\n",   rDma->CR2                        ); // [0xE08][RO] Configuration Register 2
    tdk_printf("rDma->CR3                        = 0x%08x\n",   rDma->CR3                        ); // [0xE0C][RO] Configuration Register 3
    tdk_printf("rDma->CR4                        = 0x%08x\n",   rDma->CR4                        ); // [0xE10][RO] Configuration Register 4
    tdk_printf("rDma->CRD                        = 0x%08x\n",   rDma->CRD                        ); // [0xE14][RO] DMA Configuration Register
    tdk_printf("rDma->WD                         = 0x%08x\n",   rDma->WD                         ); // [0xE80][RW] Watchdog Register, RW
//    tdk_printf("rDma->PERIPH_ID_N[4]             = 0x%08x\n",   rDma->PERIPH_ID_N[4]             ); // [0xFE0][RO] Peripheral Identification Registers
//    tdk_printf("rDma->PCELL_ID_N[4]              = 0x%08x\n",   rDma->PCELL_ID_N[4]              ); // [0xFF0][RO] Component Identification Registers
#endif
}


