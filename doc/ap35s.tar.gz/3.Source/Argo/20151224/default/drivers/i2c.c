/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#include "../tdk/tdk.h"

#include "../config/CR4_Config.h"
#include "../config/CR4_TopRegMap.h"
#include "../system/system.h"

#include "i2c.h"

#define i2c_printf(...)

/****************************************************************************
*       Global Variable
*****************************************************************************/
volatile tI2C_CTRL gI2cCtrl[MAX_I2C_NUM];

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C0_Isr(void)
{
    I2C_IsrHandler(I2C0);
//	INTC_ClearPending(IS_I2C0);
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C1_Isr(void)
{
    I2C_IsrHandler(I2C1);
//	INTC_ClearPending(IS_I2C1);
}

int irq_index=0;

struct irq_info
{
	int index;
	int ch;
	u32 status;
};

struct irq_info info[100];

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C_IsrHandler(tREG_I2C *rI2c)
{
	UINT8 ch, status;

	ch = (UINT8) (((UINT32) rI2c - I2C_BASE) / I2C_CH_OFFSET);

	status = (UINT8) rI2c->ISR;
	info[irq_index].index = irq_index;
	info[irq_index].status = status;
	info[irq_index].ch = ch;
	irq_index++;

	if (status & ISR_MACK) // Master TX Ack
	{
		rI2c->ISR &= ~ISR_MACK;

		if (rI2c->LSR & LSR_NACK)
			gI2cCtrl[ch].masterStatus = IMS_NACK;
		else
			gI2cCtrl[ch].masterStatus = IMS_ACK;
	}
	else if (status & ISR_MACKP) // Master RX Prepare Ack
	{
		rI2c->ISR &= ~ISR_MACKP;
		gI2cCtrl[ch].masterStatus = IMS_ACK;
	}
	else if (status & ISR_SAM) //slave address match, when first byte(device address) is received
	{
		rI2c->ISR &= ~ISR_SAM;
		M_I2C_SET_ACK(rI2c);
//		i2c_printf("ISR_SAM:rI2c->SRXR=0x%08x\n", rI2c->SRXR);

		if (rI2c->SRXR & I2C_READ)
		{
			gI2cCtrl[ch].slaveStatus = ISS_HOST_READ;
			rI2c->STXR = gI2cCtrl[ch].txBuf[gI2cCtrl[ch].txIdx++];
			I2C_SetOpMode(rI2c, IM_STX);
///			i2c_printf("Host Read\n");
		}
		else
		{
			gI2cCtrl[ch].slaveStatus = ISS_HOST_WRITE;
			I2C_SetOpMode(rI2c, IM_SRX);
///			i2c_printf("Host Write\n");
		}
		info[irq_index].index = irq_index*-1;
		info[irq_index].status = rI2c->SRXR;
		info[irq_index].ch = ch;
		irq_index++;
		M_I2C_RESUME(rI2c); //it makes 9th bit clock for ack or nack
	}
	else if (status & ISR_SACKP) // Slave RX Prepare Ack (host WRITE to slave), occurs when each byte is received
	{
		u32 data;
//		i2c_printf("ISR_SACKP\n");
		rI2c->ISR &= ~ISR_SACKP;
		gI2cCtrl[ch].slaveStatus = ISS_RXACK;

		data = rI2c->SRXR;
///		i2c_printf("ch=%d, index=%d, data=0x%08xd\n", ch, gI2cCtrl[ch].rxIdx, data);
		info[irq_index].index = irq_index*-1;
		info[irq_index].status = data;
		info[irq_index].ch = ch;
		irq_index++;

		gI2cCtrl[ch].rxBuf[gI2cCtrl[ch].rxIdx++] = data;
		M_I2C_SET_ACK(rI2c);
		M_I2C_RESUME(rI2c);
	}
	else if (status & ISR_SACK) // Slave TX Ack (host READ from slave), occurs when after host read 1byte
	{
//		i2c_printf("ISR_SACK\n");
		rI2c->ISR &= ~ISR_SACK;
		gI2cCtrl[ch].slaveStatus = ISS_TXACK;
		rI2c->STXR = gI2cCtrl[ch].txBuf[gI2cCtrl[ch].txIdx++];
		M_I2C_RESUME(rI2c);

	}
}

void I2C_Debug_Init(void)
{
	irq_index=0;
}

void I2C_Debug(void)
{
	int i;
	for(i=0; i<irq_index; i++)
	{
		i2c_printf("ch=%d, index=%d, status=0x%08x\n", info[i].ch, info[i].index, info[i].status);
	}

	i2c_printf("I2C 0 : %d,%d\n", gI2cCtrl[0].masterStatus, gI2cCtrl[0].slaveStatus);
	i2c_printf("I2C 1 : %d,%d\n", gI2cCtrl[1].masterStatus, gI2cCtrl[1].slaveStatus);
}

/**
 * I2C master mode 초기화 함수
 * @param	*rI2c	I2C base register pointer
 * @param	*param	I2C master mode initialize value
 */
void I2C_MasterInit(tREG_I2C *rI2c, tI2C_CTRL *ic)
{
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);

    /* Clear all interrupt */
    rI2c->ISR = 0;

    /* Enable interrupt */
    rI2c->IER = IER_MACKP | IER_MACK;

    /* Enable module and address type setting */
    if(ic->addrType == IDAT_ADDR_7BIT)
        rI2c->OPR = OPR_S7ADDR | OPR_CORE_EN;
    else
        rI2c->OPR = OPR_S10ADDR | OPR_CORE_EN;

    /* SCL setting */
    rI2c->DIV = ic->clkDiv & DIV_MASK;

    I2C_SetOpMode(rI2c, IM_MTX);

    gI2cCtrl[ch].masterStatus = IMS_IDLE;
    gI2cCtrl[ch].devAddr = ic->devAddr;
    gI2cCtrl[ch].addrType = ic->addrType;
    gI2cCtrl[ch].addrLen = ic->addrLen;
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C_SlaveInit(tREG_I2C *rI2c, tI2C_CTRL *ic)
{
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);

    /* Clear all interrupt */
    rI2c->ISR = 0;

    /* Enable interrupt */
    rI2c->IER = IER_SAM | IER_SACKP | IER_SACK;

    /* Enable module and address type setting */
    if(ic->addrType == IDAT_ADDR_7BIT)
        rI2c->OPR = OPR_S7ADDR | OPR_CORE_EN;
    else
        rI2c->OPR = OPR_S10ADDR | OPR_CORE_EN;

    /* Slave address setting */
    ic->devAddr >>= 1;
    rI2c->SADDRL = (UINT8)ic->devAddr;
    rI2c->SADDRH = (UINT8)(ic->devAddr >> 8);

    I2C_SetOpMode(rI2c, IM_SRX);

    gI2cCtrl[ch].slaveStatus = ISS_IDLE;
    gI2cCtrl[ch].addrType = ic->addrType;
    gI2cCtrl[ch].addrLen = ic->addrLen;
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C_SetOpMode(tREG_I2C *rI2c, tI2C_MODE mode)
{
#if 0
    UINT32 reg;
    
    reg = rI2c->CONR;
    reg &= ~(CONR_MMASK | CONR_SMASK);
    reg |= mode;
    rI2c->CONR = reg;
#else
    rI2c->CONR &= ~(CONR_MMASK | CONR_SMASK);
    rI2c->CONR |= mode;
#endif
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C_StopCondition(tREG_I2C *rI2c)
{
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);

    I2C_SetOpMode(rI2c, IM_MOFF);
    rI2c->LCMR = LCMR_RESUME | LCMR_STOP;
    gI2cCtrl[ch].masterStatus = IMS_IDLE;
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
tI2C_RESP I2C_WaitTransfer(tREG_I2C *rI2c, UINT8 timeOut_ms)
{
    UINT8 ch;
    UINT32 cnt;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);

	cnt = timeOut_ms * 1000 / I2C_WAITING_DELAY / SYS_DELAY_UNIT;
	cnt=10000;

    while(--cnt)
    {
        if(gI2cCtrl[ch].masterStatus == IMS_ACK)
        {
            gI2cCtrl[ch].masterStatus = IMS_IDLE;
            return RESP_OK;
        }

        if(gI2cCtrl[ch].masterStatus == IMS_NACK)
        {
            I2C_StopCondition(rI2c); 
            return RESP_NAK;
        }
        SYS_Delay(I2C_WAITING_DELAY); // 50us
        i2c_printf(".");
    }

    I2C_StopCondition(rI2c); 

    return RESP_XFER_TIMEOUT;
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
tI2C_RESP I2C_SendDevAddr(tREG_I2C *rI2c)
{
	tI2C_RESP resp;
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);

    I2C_SetOpMode(rI2c, IM_MTX);
    
    if(gI2cCtrl[ch].addrType == IDAT_ADDR_7BIT)
    {
        rI2c->MTXR = (UINT8)gI2cCtrl[ch].devAddr;
        rI2c->LCMR = LCMR_RESUME | LCMR_START;
    }
    else
    {
    }

    resp = I2C_WaitTransfer(rI2c, I2C_TIMEOUT);
	if(resp==RESP_XFER_TIMEOUT)
		return RESP_DEV_ADDR_TIMEOUT;
	else if(resp==RESP_NAK)
		return RESP_DEV_ADDR_NAK;

	return resp;
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
BOOL I2C_CheckMasterStatus(tREG_I2C *rI2c, tI2C_MASTER_STATUS status)
{
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);
    
//	__CORE_INT_DIS();
	if(gI2cCtrl[ch].masterStatus == status)
	{
//		__CORE_INT_EN();
		return TRUE;
	}
//	__CORE_INT_EN();

	return FALSE;
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
BOOL I2C_CheckSlaveStatus(tREG_I2C *rI2c, tI2C_SLAVE_STATUS status)
{
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);
    
//	__CORE_INT_DIS();
	if(gI2cCtrl[ch].slaveStatus == status)
	{
//		__CORE_INT_EN();
		return TRUE;
	}
//	__CORE_INT_EN();

	return FALSE;
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C_WaitMasterStatus(tREG_I2C *rI2c, tI2C_MASTER_STATUS status)
{
    while(!(I2C_CheckMasterStatus(rI2c, status)))
    {
        SYS_Delay(I2C_WAITING_DELAY);
    }
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C_WaitSlaveStatus(tREG_I2C *rI2c, tI2C_SLAVE_STATUS status)
{
    while(!(I2C_CheckSlaveStatus(rI2c, status)))
    {
        SYS_Delay(I2C_WAITING_DELAY);
    }
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C_MasterSendByte(tREG_I2C *rI2c, UINT8 dat)
{
    rI2c->MTXR = dat;
    M_I2C_RESUME(rI2c);
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C_StartReceiveByte(tREG_I2C *rI2c)
{
    I2C_SetOpMode(rI2c, IM_MRX);
    M_I2C_RESUME(rI2c);
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
tI2C_RESP I2C_SendDataAddr(tREG_I2C *rI2c, UINT16 addr)
{
    tI2C_RESP resp;
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);

    if(gI2cCtrl[ch].addrLen == IDAL_ADDR_16BIT)
    {
        I2C_MasterSendByte(rI2c, (UINT8)(addr >> 8));
        resp = I2C_WaitTransfer(rI2c, I2C_TIMEOUT);
		if(resp==RESP_XFER_TIMEOUT)
			return RESP_DATA_ADDR_TIMEOUT;
		else if(resp==RESP_NAK)
			return RESP_DATA_ADDR_NAK;
    }

    I2C_MasterSendByte(rI2c, (UINT8)(addr & 0xFF));
    resp = I2C_WaitTransfer(rI2c, I2C_TIMEOUT);
	if(resp==RESP_XFER_TIMEOUT)
		return RESP_DATA_ADDR_TIMEOUT;
	else if(resp==RESP_NAK)
		return RESP_DATA_ADDR_NAK;

    return resp;
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
tI2C_RESP I2C_CheckStageDone(tREG_I2C *rI2c, tI2C_STAGE stage)
{
	UINT32 reg;
	UINT16 cnt;
	
	cnt = I2C_TIMEOUT * 1000 / I2C_STAGE_WAITING_DELAY / SYS_DELAY_UNIT;
    
	while(--cnt)
	{
		reg = rI2c->LSR;
		reg = (reg & LSR_STATE_MASK) >> 4;
		if(reg != stage)
			return RESP_OK;
        
		SYS_Delay(I2C_STAGE_WAITING_DELAY); // 10us
	}
	return RESP_STAGE_TIMEOUT;
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
tI2C_RESP I2C_MasterWriteData(tREG_I2C *rI2c, tI2C_XFER_INFO *xi)
{
	UINT16 i;
	tI2C_RESP resp;
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);

	if(!I2C_CheckMasterStatus(rI2c, IMS_IDLE))
		return RESP_STATUS_MISS;

	i2c_printf("Send Dev Addr");
	/* Device Address & Write mode */
	M_I2C_SET_WRITE_MODE(ch);
	for(i=0; i<I2C_NACK_RETRY_CNT; i++)
	{
		resp = I2C_SendDevAddr(rI2c);
		if(!resp)
			break;
	}
	if(resp)
		return resp;
	i2c_printf("OK\n");

	i2c_printf("Send Data Addr");

	/* Send data address to write */
	resp = I2C_SendDataAddr(rI2c, xi->addr);
	if(resp)
		return resp;
	i2c_printf("OK\n");

	/* start write */
	for(i=0; i<xi->len; i++)
	{
		i2c_printf("[%3d] Data Send : 0x%02x", i, xi->txBuf[i]);
        gI2cCtrl[ch].masterStatus = IMS_DATA_SEND;
		I2C_MasterSendByte(rI2c, xi->txBuf[i]);
		if(I2C_WaitTransfer(rI2c, I2C_TIMEOUT))
			break;
		i2c_printf("OK\n");
	}

	I2C_StopCondition(rI2c); 
	if(i != xi->len)
		return RESP_TX_TIMEOUT;
	else
		return RESP_OK;
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
tI2C_RESP I2C_MasterReadData(tREG_I2C *rI2c, tI2C_XFER_INFO *xi)
{
	UINT16 i;
	tI2C_RESP resp;
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);

	if(!I2C_CheckMasterStatus(rI2c, IMS_IDLE))
		return RESP_STATUS_MISS;

	/* Device Address & Write mode */
	i2c_printf("Send Dev Addr");
	M_I2C_SET_WRITE_MODE(ch);
	for(i=0; i<I2C_NACK_RETRY_CNT; i++)
	{
		resp = I2C_SendDevAddr(rI2c);
		if(!resp)
			break;
	}
	if(resp)
		return resp;

	i2c_printf("OK\n");

	i2c_printf("Send Data Addr");
	/* Send data address to read */
	resp = I2C_SendDataAddr(rI2c, xi->addr);
	if(resp)
		return resp;

	/* Device Address & Read mode */
	M_I2C_SET_READ_MODE(ch);
	resp = I2C_SendDevAddr(rI2c);
	if(resp)
		return resp;

	i2c_printf("OK\n");
	i2c_printf("Send Dev Addr");

	/* Random Read */
	for(i=0; i<xi->len; i++)
	{
		gI2cCtrl[ch].masterStatus = IMS_DATA_RECEIVE;
		I2C_StartReceiveByte(rI2c);
		if(I2C_WaitTransfer(rI2c, I2C_TIMEOUT))
			break;

		xi->rxBuf[i] = rI2c->MRXR;
		i2c_printf("[%3d] Data Recv : 0x%02x", i, xi->rxBuf[i]);
		
		I2C_SetOpMode(rI2c, IM_MOFF);
		if(i == xi->len - 1)
			M_I2C_SET_NACK(rI2c);
		else
			M_I2C_SET_ACK(rI2c);
		M_I2C_RESUME(rI2c);
		i2c_printf("OK\n");
	}

	resp = I2C_CheckStageDone(rI2c, STAGE_ACK);
	if(resp)
		return resp;

	I2C_StopCondition(rI2c);
	resp = I2C_CheckStageDone(rI2c, STAGE_STOP);
	if(resp)
		return resp;

	if(i != xi->len)
		return RESP_RX_TIMEOUT;
	else
		return RESP_OK;
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C_SlaveWriteData(tREG_I2C *rI2c, tI2C_XFER_INFO *xi)
{
	UINT16 i;
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);
	
	I2C_WaitSlaveStatus(rI2c, ISS_HOST_READ);
	for(i=0; i<xi->len; i++)
	{
        gI2cCtrl[ch].slaveStatus = ISS_DATA_SEND;
		rI2c->STXR = 0xff;
		rI2c->STXR = xi->txBuf[i];
		M_I2C_RESUME(rI2c);
		I2C_WaitSlaveStatus(rI2c, ISS_TXACK);
	}
	M_I2C_RESUME(rI2c); // it makes possible to stop condition
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C_SlaveReadData(tREG_I2C *rI2c, tI2C_XFER_INFO *xi)
{
	UINT16 i;
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);
	
	I2C_WaitSlaveStatus(rI2c, ISS_HOST_WRITE);
	for(i=0; i<xi->len; i++)
	{
		I2C_WaitSlaveStatus(rI2c, ISS_RXACK);
        gI2cCtrl[ch].slaveStatus = ISS_DATA_RECEIVE;
		xi->rxBuf[i] = rI2c->SRXR;
		M_I2C_SET_ACK(rI2c);
		M_I2C_RESUME(rI2c);
	}
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C_SetSlaveTxBuff(tREG_I2C *rI2c, UINT8 *pBuf, UINT16 len)
{
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);

    gI2cCtrl[ch].txBuf = pBuf;
    gI2cCtrl[ch].maxTxNum = len;
    gI2cCtrl[ch].txIdx = 0;
}

/****************************************************************************
NAME	
INPUT	
RETURNS
DESCRIPTION
*****************************************************************************/
void I2C_SetSlaveRxBuff(tREG_I2C *rI2c, UINT8 *pBuf, UINT16 len)
{
    UINT8 ch;

    ch = (UINT8)(((UINT32)rI2c - I2C_BASE) / I2C_CH_OFFSET);

    gI2cCtrl[ch].rxBuf = pBuf;
    gI2cCtrl[ch].maxRxNum = len;
    gI2cCtrl[ch].rxIdx = 0;
}


