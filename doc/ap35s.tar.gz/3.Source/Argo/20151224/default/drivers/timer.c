
#include "../tdk/tdk_types.h"

#include "timer.h"

void timer_init(tREG_TIMER *timer, u16 mode, u16 prescale, u16 size, u16 oneshot)
{
	u8 control;
	control = mode|TIMER_CONTROL_INT_ENABLE|prescale|size|oneshot;

	timer->CONTROL = control;
}

void timer_start(tREG_TIMER *timer, u32 load)
{
	timer->LOAD = load;
	timer->CONTROL |= TIMER_CONTROL_ENABLE;
}

void timer_disable(tREG_TIMER *timer)
{
	timer->CONTROL &= ~TIMER_CONTROL_ENABLE;
}
