

#ifndef __ARM_TIMER__
#define __ARM_TIMER__

#include "../tdk/tdk_types.h"
#include "../config/CR4_TopRegMap.h"

typedef volatile struct
{
	u32 LOAD;
	u32 VALUE;
	u32 CONTROL;
	u32 INTCLR;
	u32 RIS;
	u32 MIS;
	u32 BGLOAD;
} tREG_TIMER;

#define TIMER_OFFSET	0x20

#define TIMER_REG_LOAD			0x00
#define TIMER_REG_VALUE			0x04
#define TIMER_REG_CONTROL		0x08
#define TIMER_REG_INTCLR		0x0C
#define TIMER_REG_RIS			0x10
#define TIMER_REG_MIS			0x14
#define TIEMR_REG_BGLOAD		0x18

#define TIMER_REG_TIMER_ITCR		0x0F00
#define TIMER_REG_TIMER_ITOP		0x0F04
#define TIMER_REG_TIMER_PERIID0		0x0FE0
#define TIMER_REG_TIMER_PERIID1		0x0FE4
#define TIMER_REG_TIMER_PERIID2		0x0FE8
#define TIMER_REG_TIMER_PERIID3		0x0FEC
#define TIMER_REG_PCELLID0			0x0FF0
#define TIMER_REG_PCELLID1			0x0FF4
#define TIMER_REG_PCELLID2			0x0FF8
#define TIMER_REG_PCELLID3			0x0FFC

#define TIMER_CONTROL_ENABLE			(1<<7)
#define TIMER_CONTROL_MODE_FREERUN		(1<<0)
#define TIMER_CONTROL_MODE_PERIOD		(1<<6)
#define TIMER_CONTROL_INT_ENABLE		(1<<5)
#define TIMER_CONTROL_PRESCALE_1		(0<<2)
#define TIMER_CONTROL_PRESCALE_16		(1<<2)
#define TIMER_CONTROL_PRESCALE_256		(2<<2)
#define TIMER_CONTROL_SIZE_16BIT		(0<<1)
#define TIMER_CONTROL_SIZE_32BIT		(1<<1)
#define TIMER_CONTROL_ONESHOT			(1<<0)

#define TIMER_ITCR_ENABLE				1
#define TIMER_ITOP_TIMER1				(1<<0)
#define TIMER_ITOP_TIMER2				(1<<1)

void timer_init(tREG_TIMER *timer, u16 mode, u16 prescale, u16 size, u16 oneshot);
void timer_start(tREG_TIMER *timer, u32 load);
void timer_disable(tREG_TIMER *timer);

#endif
