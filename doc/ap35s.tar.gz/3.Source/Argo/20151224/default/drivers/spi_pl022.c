/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#include "spi_pl022.h"
#include "../system/system.h"

#if __SPI_FUNCCALL__
unsigned int spi_reg_read(PI_OBJECT spi, unsigned int offset)
{
	unsigned int data;
#ifdef WIN32
	int offset = offset&0xffff;
	data = *(unsigned int*)(sim_buffer + offset);
#else

#if defined(__KERNEL__)
	data = fwengine_reg_read(g_fwengine_data, (u32)offset);
#else
	data = *(volatile unsigned int *)((unsigned int)spi + offset);
#endif
#endif

#if __SPI_DEBUG__
	tdk_printf("\tRX:Addr=0x%08x Data=0x%08x\n", offset, data);
#endif
	return data;
}

void spi_reg_write(PI_OBJECT spi, unsigned int offset, unsigned int data)
{
#if __SPI_DEBUG__
	tdk_printf("\tTX:Addr=0x%08x Data=0x%08x\n", offset, data);
#endif

#ifdef WIN32
	int offset = offset&0xffff;
#endif

#ifdef WIN32
	*(unsigned int*)(sim_buffer + offset) = data;
#elif defined(__KERNEL__)
	fwengine_reg_write(g_fwengine_data, (u32)offset, data);
#else
	*(volatile unsigned int *)((unsigned int)spi + offset) = data;
#endif
}
#endif

void spi_init(SPI_OBJECT spi)
{
	int SPH=1;
	int SPO=1;

	spi_reg_write(spi, SSP_CR0, (3<<8) | (SPH<<7) | (SPO<<6) | SSP_CONTROL_FRAME_MOTOROLA | SSP_CONTROL_DATA_8 );
	spi_reg_write(spi, SSP_CR1, (0<<3) | SSP_CONTROL_MASTER_MODE | SSP_CONTROL_SYNC_SERAL_ENABLE);

	spi_reg_write(spi, SSP_CPSR, 8);

	spi_reg_write(spi, SSP_IMSC, 0xf);
	spi_reg_write(spi, SSP_RIS, 0xf);
	// DMA Request Enable
	spi_reg_write(spi, SSP_DMACR, (1<<1)|(1<<0));
}

u32 spi_wait_status(SPI_OBJECT spi, u32 offset, u32 flag, int timeout)
{
	u32 status;

	while(timeout)
	{
		status = spi_reg_read(spi, offset);
//		__SIM_DEBUG(status|0xff000000);
		if(status & flag) break;
		timeout--;
	}

	if(timeout==0)	return 0xffffffff;

	return status;
}

int spi_write(SPI_OBJECT spi, int data)
{
//	u32 status;
//	status = spi_wait_status(spi, SSP_SR, SSP_STATUS_TX_FIFO_READY, SPI_TIMEOUT);
//	if(status == 0xffffffff) return -1;
	spi_reg_write(spi, SSP_DR, data);
#if 0
	while(1)
	{
		status = spi_reg_read(SPI0, SSP_SR);
		if(!SPI_IS_BUSY(status)) break;
	}
#endif
	return 0;
}

int spi_write2(SPI_OBJECT spi, int data)
{
	u32 status;
//	status = spi_wait_status(spi, SSP_SR, SSP_STATUS_TX_FIFO_READY, SPI_TIMEOUT);
//	if(status == 0xffffffff) return -1;
	spi_reg_write(spi, SSP_DR, data);
	while(1)
	{
		status = spi_reg_read(spi, SSP_SR);
		if(status & SSP_STATUS_RX_FIFO_READY) break;
	}

	return spi_reg_read(spi, SSP_DR);
}

int spi_read(SPI_OBJECT spi)
{
	u32 status;
	status = spi_wait_status(spi, SSP_SR, SSP_STATUS_RX_FIFO_READY, SPI_TIMEOUT);
	if(status == 0xffffffff) return -1;
	return spi_reg_read(spi, SSP_DR);
}


int spi_write_bytes(SPI_OBJECT spi, void *buffer, int length)
{
	int i;
	int ret;
	u8 *buf = (u8*)buffer;

	for(i=0; i<length; i++)
	{
		ret = spi_write(spi, buf[i]);
		if(ret) break;
	}
	return i;
}

int spi_read_bytes(SPI_OBJECT spi, void *buffer, int length)
{
	int i;
	int ch;
	u8 *buf = (u8*)buffer;

	for(i=0; i<length; i++)
	{
		ch = spi_read(spi);
		if(ch<0) break;
		buf[i] = ch;
		__SIM_STEP(i);
	}
	return i;
}

