#ifndef __GPIO__
#define __GPIO__

#include "../config/CR4_TopRegMap.h"


#define		GPIO_REG_DATA	(GPIO_BASE + 0x000)
#define		GPIO_REG_DIR	(GPIO_BASE + 0x400)
#define		GPIO_REG_IS		(GPIO_BASE + 0x404)
#define		GPIO_REG_IBE	(GPIO_BASE + 0x408)
#define		GPIO_REG_IEV	(GPIO_BASE + 0x40C)
#define		GPIO_REG_IE		(GPIO_BASE + 0x410)
#define		GPIO_REG_RIS	(GPIO_BASE + 0x414)
#define		GPIO_REG_MIS	(GPIO_BASE + 0x418)
#define		GPIO_REG_IC		(GPIO_BASE + 0x41C)
#define		GPIO_REG_AFSEL	(GPIO_BASE + 0x420)

#endif
