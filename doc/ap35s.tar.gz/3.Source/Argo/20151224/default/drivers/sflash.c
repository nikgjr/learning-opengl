#include "../config/CR4_TopRegMap.h"
#include "../system/system.h"

#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"

#include "../drivers/spi_pl022.h"
#include "../include/ansi.h"

#include "sflash.h"

SPI_OBJECT		sflash_spi = (SPI_OBJECT)SPI0;

void sflash_init(void)
{
	spi_init(sflash_spi);

	sflash_reset();
}

int sflash_write_enable(void)
{
	u32 data;
	spi_write(sflash_spi, 0x06);
	// read dummy data
	// 0xffffffff fail
	data=spi_read(sflash_spi);	__SIM_RESP(data);
#if IS_BOARD()
	return data==0xffffffff;
#else
	return 0;
#endif
}

int sflash_read_status(void)
{
	u32 data;

	spi_write(sflash_spi, 0x05);	// command
	spi_write(sflash_spi, 0xff);	// dummy write

	// dummy read
	data=spi_read(sflash_spi);	__SIM_RESP(data);
	// status
	data=spi_read(sflash_spi);	__SIM_RESP(data);

	return data;
}

int sflash_wait_for_complete(void)
{
	int status;
	while(1)
	{
		status = sflash_read_status();
//		tdk_printf("sflash_wait_for_complete:status=0x%08x\n", status);
		if(status<0) return -1;
		if((status&0x1)==0) break;
	}
	return 0;
}

int sflash_reset(void)
{
	int data;

	spi_write(sflash_spi, 0x66);	// command
	data=spi_read(sflash_spi);	__SIM_RESP(data);	// dummy
	if(data == -1)
	{
		tdk_printf("fail to spi read\n");
	}

	spi_write(sflash_spi, 0x99);	// command
	data=spi_read(sflash_spi);	__SIM_RESP(data);	// dummy
	if(data == -1)
	{
		tdk_printf("fail to spi read\n");
	}

	sflash_wait_for_complete();

	return 0;
}

int sflash_chip_erase(void)
{
	int ret;
	int data;

	ret = sflash_write_enable();
	if(ret)	return ret;

	spi_write(sflash_spi, 0x60);	// command
	data=spi_read(sflash_spi);	__SIM_RESP(data);	// dummy
	if(data == -1)
	{
		tdk_printf("fail to spi read\n");
	}

	ret = sflash_wait_for_complete();

	return ret;
}

int sflash_sector_erase(u32 addr)
{
	u32 data;
	int ret;
	u8 *buf = (u8*)&addr;

	__SIM_STEP(0x10);

	ret = sflash_write_enable();
	if(ret)	return ret;
	__SIM_STEP(0x20);

	spi_write(sflash_spi, 0x20);	// command
	spi_write(sflash_spi, buf[2]);	// addr A23-A16
	spi_write(sflash_spi, buf[1]);	// addr A15-A8
	spi_write(sflash_spi, buf[0]);	// addr A7 -A0
	__SIM_STEP(0x30);
	data=spi_read(sflash_spi);	__SIM_RESP(data);
	data=spi_read(sflash_spi);	__SIM_RESP(data);
	data=spi_read(sflash_spi);	__SIM_RESP(data);
	data=spi_read(sflash_spi);	__SIM_RESP(data);
	if(data == 0xffffffff)
	{
		tdk_printf("fail to spi read\n");
	}

	ret = sflash_wait_for_complete();

	return ret;
}

int sflash_block_erase(u32 addr)
{
	u32 data;
	int ret;
	u8 *buf = (u8*)&addr;

	ret = sflash_write_enable();
	if(ret)	return ret;

	spi_write(sflash_spi, 0xD8);	// command
	spi_write(sflash_spi, buf[2]);	// addr A23-A16
	spi_write(sflash_spi, buf[1]);	// addr A15-A8
	spi_write(sflash_spi, buf[0]);	// addr A7 -A0
	data=spi_read(sflash_spi);	__SIM_RESP(data);
	data=spi_read(sflash_spi);	__SIM_RESP(data);
	data=spi_read(sflash_spi);	__SIM_RESP(data);
	data=spi_read(sflash_spi);	__SIM_RESP(data);
	if(data == 0xffffffff)
	{
		tdk_printf("fail to spi read\n");
	}

	ret = sflash_wait_for_complete();

	return ret;
}

int sflash_single_write(u32 addr, u32 data)
{
	int ret;
	u8 *buf = (u8*)&addr;
	u8 *dbuf = (u8*)&data;

	ret = sflash_write_enable();
	if(ret)	return ret;

	spi_write(SPI0, 0x02);      // command
	spi_write(SPI0, buf[2]);    // addr A23-A16
	spi_write(SPI0, buf[1]);    // addr A15-A8
	spi_write(SPI0, buf[0]);    // addr A7 -A0

	spi_write(SPI0, dbuf[0]);	// D7  - D0
	spi_write(SPI0, dbuf[1]);	// D15 - D8
	spi_write(SPI0, dbuf[2]);	// D23 - D16
	spi_write(SPI0, dbuf[3]);	// D31 - D24

	// dummy read
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);

	ret = sflash_wait_for_complete();

	return ret;
}

int sflash_erase(u32 addr, int size)
{
	int ret;
	int err = 0;
	int i;
	int block = size/SERIAL_FLASH_BLOCK_SIZE;
	if((size % SERIAL_FLASH_BLOCK_SIZE) != 0) block += 1;

	for(i=0; i<block; i++)
	{
		ret = sflash_block_erase(addr+i*SERIAL_FLASH_BLOCK_SIZE);
		tdk_printf("Erase 0x%08x : %s\n", addr+i*SERIAL_FLASH_BLOCK_SIZE, ansi_get_status_string(ret==0));
		err += ret;
	}

	return err;
}


int sflash_single_read(u32 addr, u32 *data)
{
	u8 *buf = (u8*)&addr;
	u8 *dbuf = (u8*)data;
	u32 temp;

	spi_write(SPI0, 0x03);
	spi_write(SPI0, buf[2]);    // addr A23-A16
	spi_write(SPI0, buf[1]);    // addr A15-A8
	spi_write(SPI0, buf[0]);    // addr A7 -A0

	spi_write(SPI0, 0xff);		// dummy
	spi_write(SPI0, 0xff);		// dummy
	spi_write(SPI0, 0xff);		// dummy
	spi_write(SPI0, 0xff);		// dummy

	// read dummy
	temp=spi_read(SPI0);	__SIM_RESP(temp);
	temp=spi_read(SPI0);	__SIM_RESP(temp);
	temp=spi_read(SPI0);	__SIM_RESP(temp);
	temp=spi_read(SPI0);	__SIM_RESP(temp);

	temp=spi_read(SPI0);	__SIM_RESP(temp);
	dbuf[0] = temp&0xff;
	temp=spi_read(SPI0);	__SIM_RESP(temp);
	dbuf[1] = temp&0xff;
	temp=spi_read(SPI0);	__SIM_RESP(temp);
	dbuf[2] = temp&0xff;
	temp=spi_read(SPI0);	__SIM_RESP(temp);
	dbuf[3] = temp&0xff;
	return 0;
}

int sflash_buffer_write(u32 addr, u32 *buffer, int size)
{
	int i;
	int count=(size+3)>>2;
	s16 ret;
	addr &= 0xffffff;

	for(i=0; i<count; i++)
	{
		ret = sflash_single_write(addr+4*i, buffer[i]);
		if(ret) return ret;
	}
	return 0;
}

int sflash_buffer_read(u32 addr, u32 *buffer, int size)
{
	int i;
	int count=(size+3)>>2;
	s16 ret;
	addr &= 0xffffff;

	for(i=0; i<count; i++)
	{
		ret = sflash_single_read(addr+4*i, buffer+i);
		if(ret) return ret;
	}
	return 0;
}
