#ifndef __WDT__
#define __WDT__

#include "../config/CR4_TopRegMap.h"
#include "../tdk/tdk_types.h"

typedef volatile struct
{
	u32 WDOGLOAD;		// [00]
	u32 WDOGVALUE;		// [04]
	u32 WDOGCONTROL;	// [08]
	u32 WDOGINTCLR;		// [0C]
	u32 WDOGRIS;		// [10]
	u32 WDOGMIS;		// [14]
} tREG_WDT;

#define WDOG_REG_LOAD			0x00
#define WDOG_REG_VALUE			0x04
#define WDOG_REG_CONTROL		0x08
#define WDOG_REG_INTCLR			0x0C
#define WDOG_REG_RIS			0x10
#define WDOG_REG_MIS			0x14

#define WDOG_REG_LOCK			0xC00

#define WDOG_REG_WDOG_ITCR		0x0F00
#define WDOG_REG_WDOG_ITOP		0x0F04
#define WDOG_REG_WDOG_PERIID0	0x0FE0
#define WDOG_REG_WDOG_PERIID1	0x0FE4
#define WDOG_REG_WDOG_PERIID2	0x0FE8
#define WDOG_REG_WDOG_PERIID3	0x0FEC
#define WDOG_REG_PCELLID0		0x0FF0
#define WDOG_REG_PCELLID1		0x0FF4
#define WDOG_REG_PCELLID2		0x0FF8
#define WDOG_REG_PCELLID3		0x0FFC

#define WDOG_CONTROL_INT_ENABLE		1
#define WDOG_CONTROL_RESET_ENABLE	2


#define wdog_lock(wdog)			*(volatile u32 *)((u32)(wodg)+WDOG_REG_LOCK) = 0x1ACCE551
#define wdog_release(wdog)		*(volatile u32 *)((u32)(wodg)+WDOG_REG_LOCK) = 0

#endif
