/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/
#ifndef __GIC_DRV_H__
#define __GIC_DRV_H__

#include "gic_pl390.h"

/**
 * Vector table static enable 변수
 */
#define	SRAM_STATIC_VECTOR_TABLE	0

/**
 * GIC IRQ Numbers
 */
#define	GIC_EXT_INT1		(32+27)
#define	GIC_EXT_INT0		(32+26)

#define GIC_ISP0            (32+17)
#define GIC_ISP1            (32+18)
#define GIC_ISP2            (32+19)
#define GIC_ISP3            (32+20)
#define GIC_ISP4            (32+21)
#define GIC_ISP5            (32+22)
#define GIC_ISP6            (32+23)
#define GIC_ISP7            (32+24)
#define GIC_ISP8            (32+25)


#define GIC_WDT				(32+ 0)
#define GIC_TIMER_0			(32+ 1)
#define	GIC_TIMER_1			(32+ 2)
#define	GIC_DMA_CHANNEL0	(32+ 3)
#define	GIC_DMA_CHANNEL1	(32+ 4)
#define	GIC_DMA_CHANNEL2	(32+ 5)
#define	GIC_DMA_CHANNEL3	(32+ 6)
#define	GIC_DMA_ABORT		(32+ 7)
#define GIC_I2C0			(32+ 8)
#define GIC_I2C1			(32+ 9)
#define	GIC_SPI0			(32+10)
#define	GIC_SPI1			(32+11)
#define GIC_UART0			(32+12)		// combine
#define GIC_UART1			(32+13)		// combine



/**
 * 사용할 수 있는 interrupt source number
 */
#define RAISED_IRQS_TOTAL   16

/**
 * 사용할 수 있는 interrupt source start number
 */
#define IRQS_START          32

/**
 * Total interrupt source number
 */
#define IRQS_TOTAL          64

/**
 * Total interrupt source number
 */
#define INVALID_IRQ_NO      0x3FF

typedef struct
{
    UINT32 irqNo;
    UINT32 level;
}tGIC_RAISED_IRQ;

typedef struct
{
    tGIC_IRQ_DESC *if1;
    tGIC_IRQ_DESC *if2;
    tGIC_IRQ_DESC *cryto;
    tGIC_IRQ_DESC *pkt;
    tGIC_IRQ_DESC *avb;
    tGIC_IRQ_DESC *rsvd1;
    tGIC_IRQ_DESC *rsvd2;
    tGIC_IRQ_DESC *dmaAbort;
    tGIC_IRQ_DESC *dmaIrq0;
    tGIC_IRQ_DESC *dmaIrq1;
    tGIC_IRQ_DESC *dmaIrq2;
    tGIC_IRQ_DESC *dmaIrq3;
    tGIC_IRQ_DESC *dmaIrq4;
    tGIC_IRQ_DESC *dmaIrq5;
    tGIC_IRQ_DESC *dmaIrq6;
    tGIC_IRQ_DESC *dmaIrq7;
    tGIC_IRQ_DESC *temp0;
    tGIC_IRQ_DESC *temp1;
    tGIC_IRQ_DESC *rsvd3;
    tGIC_IRQ_DESC *rsvd4;
    tGIC_IRQ_DESC *rsvd5;
    tGIC_IRQ_DESC *rsvd6;
    tGIC_IRQ_DESC *rsvd7;
    tGIC_IRQ_DESC *rsvd8;
    tGIC_IRQ_DESC *rsvd9;
    tGIC_IRQ_DESC *rsvd10;
    tGIC_IRQ_DESC *uart0Rx;
    tGIC_IRQ_DESC *uart0Tx;
    tGIC_IRQ_DESC *uart1Rx;
    tGIC_IRQ_DESC *uart1Tx;
    tGIC_IRQ_DESC *timer0;
    tGIC_IRQ_DESC *timer1;
}tGIC_IRQ;

#define		GIC_GET_IRQ_DESC(irq)		&gIrqDesc[(irq)-32]

typedef void (*GIC_CALL_BACK)(void *param);

/****************************************************************************
*       Global Variable Definitions
*****************************************************************************/
extern tGIC_IRQ gIrq;

/****************************************************************************
*       Global Function Definitions
*****************************************************************************/
void __CORE_INT_EN(void);
void __CORE_INT_DIS(void);
void GIC_RegisterHandler(int irq, GIC_CALL_BACK pFunc, void *param);
void GIC_InitInterrupts(void);
void GIC_EnableIrq(int irq);
void GIC_DisableIrq(int irq);
void GIC_ClearIrq(int irq);
BOOL GIC_CheckRaisedIrq(int irq);
int  GIC_WaitIrq(int irq, unsigned int timeout);
void GIC_ClearAllDefinedIrqs(void);
void GIC_EnableAllDefinedIrqs(void);
void GIC_DisableAllDefinedIrqs(void);
void GIC_PrintAllRaisedIrq(void);
void GIC_ClearAllRaisedIrq(void);


#endif /* __GIC_DRV_H__ */

