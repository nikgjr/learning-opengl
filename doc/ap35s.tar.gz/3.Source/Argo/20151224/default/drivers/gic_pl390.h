/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/
#ifndef __GIC_H__
#define __GIC_H__

/****************************************************************************
*       Register Map
*****************************************************************************/
typedef volatile struct
{
    u32 ICDDCR;          // [0x000] Distributor Control Register
    u32 ICDICTR;         // [0x004] Interrupt Controller Type Register
    u32 ICDIIDR;         // [0x008] Distributor Implementer Identification Register
    u32 reserved_00c_07c[29];
    u32 ICDISR[32];      // [0x080] Interrupt Security Register for SGI
                            // [0x082] Interrupt Security Register for PPI
                            // [0x084] Interrupt Security Register for SPI
    u32 ICDISER[32];     // [0x100] The Distributor does not provide registers for INTIDs < 16 b.c SGIs are always enabled
                            // [0x102] Enable Set Registers for PPI
                            // [0x104] Enable Set Registers for SPI
    u32 ICDICER[32];     // [0x180] The Distributor does not provide registers for INTIDs < 16 b.c SGIs are always enabled
                            // [0x182] Enable Clear Registers for PPI
                            // [0x184] Enable Clear Registers for SPI
    u32 ICDISPR[32];     // [0x200] Pending Set Registers for SGI
                            // [0x202] Pending Set Registers for PPI
                            // [0x204] Pending Set Registers for SPI
    u32 ICDICPR[32];     // [0x280] Pending Clear Registers for SGI
                            // [0x282] Pending Clear Registers for PPI
                            // [0x284] Pending Clear Registers for SPI
    u32 ICDABR[32];      // [0x300] Active Status Registers for SGI
                            // [0x302] Active Status Registers for PPI
                            // [0x304] Active Status Registers for SPI
    u32 reseved_380_3fc[32];
    u32 ICDIPR[255];     // [0x400] Priority Level Registers for SGI
                            // [0x410] Priority Level Reigsters for PPI
                            // [0x420] Priority Level Registers for SPI
    u32 reserved_7fc;
                            // [0x800] The Distributor does not provide registers for INTIDs < 32 in ICDIPTR.
    u32 ICDIPTR[255];    // [0x820] Target Registers for SPI
    u32 reserved_bfc;
                            // [0xC00] The Distributor does not provide registers for INTIDs < 32 in ICDICR.
    u32 ICDICR[64];      // [0xC08] Interrupt Configuration Registers for SPI
    u32 ICDPPISR;        // [0xD00] PPI Status Register
    u32 ICDSPISR[31];    // [0xD04] SPI Status Register
    u32 reserved_d80_dd0[21];
    u32 ICDLIR;          // [0xDD4] Legacy Interrupt Registers
    u32 reserved_dd8_ddc[2];
    u32 ICDMR;           // [0xDE0] Match Register
    u32 ICDER;           // [0xDE4] Enable Register
    u32 reserved_de8_efc[70];
    u32 ICDSGIR;         // [0xF00] Software Generated Interrupt Register
    u32 reserved_f04_fbc[47];
    u32 ICDPIR;          // [0xFC0] Peripheral Identification Registers
    u32 reserved_fc4_fcc[3];
    u32 ICDPIR74[4];     // [0xFD0] Peripheral Identification Registers[7:4]
    u32 ICDPIR30[4];     // [0xFE0] Peripheral Identification Registers[3:0]
    u32 ICDPCIR30[4];    // [0xFF0] PrimeCell Identification Registers[3:0]
}tREG_GIC_DIST;

/* Register Field */
/* ICDDCR */
#define ICDDCR_ENABLE       1<<0


typedef volatile struct
{
    u32 ICCICR;          // [0x000] CPU Interface Control Register
    u32 ICCPMR;          // [0x004] Priority Mask Register
    u32 ICCBPR;          // [0x008] Binary Point Register
    u32 ICCIAR;          // [0x00C] Interrupt Acknowledge Register
    u32 ICCEOIR;         // [0x010] End of Interrupt Register
    u32 ICCRPR;          // [0x014] Running Priority Register
    u32 ICCHPIR;         // [0x018] Highest Pending Interrupt Register
    u32 ICCABPR;         // [0x01C] Aliased Binary Point Register
    u32 reserved_020_03c[8];
    u32 ICCITER;         // [0x040] Integration Test Enable Register
    u32 ICCIOR;          // [0x044] Interrupt Output Register
    u32 reserved_048_04c[2];
    u32 ICCMR;           // [0x050] Match Register
    u32 ICCER;           // [0x054] Enable Register
    u32 reserved_058_0f8[41];
    u32 ICCIIDR;         // [0x0FC] CPU Interface Implementer Identification Register
    u32 reserved_100_fbc[944];
    u32 ICCPIR;          // [0xFC0] Peripheral Identification Register
    u32 reserved_fc4_fcc[3];
    u32 ICCPIR74[4];     // [0xFD0] Peripheral Identification Registers[7:4]
    u32 ICCPIR30[4];     // [0xFE0] Peripheral Identification Registers[3:0]
    u32 ICCPCIR30[4];    // [0xFF0] PrimeCell Identification Registers[3:0]
}tREG_GIC_CPU;

/* Register Field */
/* ICCICR */
#define ICCICR_ENABLE       1<<0

/****************************************************************************
*       Definitions
*****************************************************************************/
#define IRQS_PER_REG                        32
#define PRIOS_PER_REG                       4
#define TARGETS_PER_REG                     4
#define CONFIGS_PER_REG                     16
#define PRIO_FIELD_MASK                     0xFF
#define PRIO_FIELD_WIDTH                    8
#define TARGET_FIELD_MASK                   0xFF
#define TARGET_FIELD_WIDTH                  8
#define CONFIG_FIELD_MASK                   0x03
#define CONFIG_FIELD_WIDTH                  2

typedef u32 CPU_TARGET;
#define CPU_TARGET_IF0      0x01
#define CPU_TARGET_IF1      0x02
#define CPU_TARGET_IF2      0x04
#define CPU_TARTET_IF3      0x08
#define CPU_TARGET_IF4      0x10
#define CPU_TARGET_IF5      0x20
#define CPU_TARGET_IF6      0x40
#define CPU_TARTET_IF7      0x80

/****************************************************************************
*       Macros
*****************************************************************************/

/****************************************************************************
*       Enumeration Definitions
*****************************************************************************/
typedef enum
{
    GIT_N_N_LEVEL,
    GIT_N_N_EDGE,
    GIT_1_N_LEVEL,
    GIT_1_N_EDGE,
}tGIC_INT_TYPE;

typedef enum
{
    GPM_LEVEL_16 = 0xF0,
    GPM_LEVEL_32 = 0xF8,
    GPM_LEVEL_64 = 0xFC,
    GPM_LEVEL_128 = 0xFE,
    GPM_LEVEL_256 = 0xFF
}tGIC_PRIO_MASK;

/****************************************************************************
*       Structure Definitions
*****************************************************************************/
typedef struct gic_irq_desc {
	char *name;            // Name of Peripheral
    u32 irqNo;	        // Its line on the GIC
} tGIC_IRQ_DESC;

/****************************************************************************
*       Global Variable Definitions
*****************************************************************************/

/****************************************************************************
*       Global Function Definitions
*****************************************************************************/
void GICDIST_Enable(tREG_GIC_DIST *rDist);
void GICDIST_Disable(tREG_GIC_DIST *rDist);
void GICDIST_GetGicType(tREG_GIC_DIST *rDist, u32 *type);
void GICDIST_IrqEnable(tREG_GIC_DIST *rDist, int irqNo);
void GICDIST_IrqDisable(tREG_GIC_DIST *rDist, int irqNo);
void GICDIST_IrqSetPending(tREG_GIC_DIST *rDist, int irqNo);
void GICDIST_IrqClearPending(tREG_GIC_DIST *rDist, int irqNo);
u32 GICDIST_IrqIsActive(tREG_GIC_DIST *rDist, int irqNo);
void GICDIST_IrqSetPriority(tREG_GIC_DIST *rDist, int irqNo, u32 priority);
void GICDIST_IrqGetPriority(tREG_GIC_DIST *rDist, int irqNo, u32 *priority);
void GICDIST_IrqSetCpuTarget(tREG_GIC_DIST *rDist, int irqNo, u32 target);
void GICDIST_IrqGetCpuTarget(tREG_GIC_DIST *rDist, int irqNo, u32 *target);
void GICDIST_IrqSetConfig(tREG_GIC_DIST *rDist, int irqNo, u32 type);
void GICDIST_IrqGetConfig(tREG_GIC_DIST *rDist, int irqNo, u32 *config);
void GICCPU_InterfaceEnable(tREG_GIC_CPU *rCpu);
void GICCPU_InterfaceDisable(tREG_GIC_CPU *rCpu);
void GICCPU_SetPriorityMask(tREG_GIC_CPU *rCpu, u32 mask);
void GICCPU_GetPriorityMask(tREG_GIC_CPU *rCpu, u32 *mask);
void GICCPU_ReadIrqAck(tREG_GIC_CPU *rCpu, u32 *readAck);
void GICCPU_SetEndOfIrq(tREG_GIC_CPU *rCpu, int irqNo);
void GICCPU_GetRunningIrqPriority(tREG_GIC_CPU *rCpu, u32 *priority);
void GICCPU_GetHighestPending(tREG_GIC_CPU *rCpu, u32 *irq);


#endif /* __GIC_H__ */



