#include <stdio.h>
#include <math.h>

#include "../tdk/tdk.h"
#include "../include/ansi.h"
#include "ddr.h"
#include "../tdk/tdk_util.h"

int ddr_config(int type, float freq)
{
	float pClkMHz = freq;

	float pRefrWindowLowPriority      = 0.850;
	float pRefrWindowHighPriority     = 0.950;

	float pTrfc_time;
	float pTrp_time;

	float pTras_time;
	float  pTrc_time;
	float pTrcd_time;
	float pTrrd_time;
	float  pTwr_time;
	float pTwtr_time;

	float pRefr_time;
	float pInit_time;

	u32 ddr_ctras    ;
	u32 ddr_ctrfc    ;
	u32 ddr_ctrc     ;
	u32 ddr_ctrcd    ;
	u32 ddr_ctrp     ;
	u32 ddr_ctrrd    ;
	u32 ddr_ctwr     ;
	u32 ddr_ctmrd    ;
	u32 ddr_ctdqss   ;
	u32 ddr_ctrefr   ;
	u32 ddr_cinittime;

	u32 ddr_ctwtr;

	u32 pInitWBM;
	u32 pInitOM;
	u32 pCL;
	u32 pInitBT;
	u32 pInitBL;

	u32 pInitDS;
	u32 pInitPASR;

	u32 ddr_isddr2;
	u32 ddr_addrmap;
	u32 ddr_bnksize;
	u32 ddr_rowsize;
	u32 ddr_colsize;

	u32 ddr_cslmr;
	u32 ddr_celmr;
	u32 ddr_celmr2;
	u32 ddr_celmr3;

	if(type==DRAM_TYPE_DDR2)
	{
		pTrfc_time =    105.0;   // refr     -> !nop
		pTrp_time =     15.0;   // prech a  -> !nop
	}
	else
	{
		pTrfc_time =     80.0;   // refr     -> !nop
		pTrp_time =     20.0;   // prech a  -> !nop
	}

	pTras_time =     40.0;   // act a    -> prech a
	 pTrc_time =     75.0;   // act a    -> act a  (Tras + Trcd)
	pTrcd_time =     15.0;   // act a    -> write/read a
	pTrrd_time =     10.0;   // act a    -> act b
	 pTwr_time =     15.0;   // write a  -> prech a
	pTwtr_time =      7.5;   // write a  -> prech a

	pRefr_time =  15625.0;   // refr     -> refr
	pInit_time = 200000.0;   // power up -> refr

	ddr_ctras     = ceil((pTras_time * pClkMHz)/1000.0);   // act a    -> prech a;
	ddr_ctrfc     = ceil((pTrfc_time * pClkMHz)/1000.0);   // refr     -> !nop;
	ddr_ctrc      = ceil(( pTrc_time * pClkMHz)/1000.0);   // act a    -> act a;
	ddr_ctrcd     = ceil((pTrcd_time * pClkMHz)/1000.0);   // act a    -> write/read a;
//	ddr_ctrp      = 3;//0.499 + ( pTrp_time * pClkMHz)/1000.0;   // prech a  -> !nop;
	ddr_ctrp      = ceil(( pTrp_time * pClkMHz)/1000.0);   // prech a  -> !nop;
	ddr_ctrrd     = ceil((pTrrd_time * pClkMHz)/1000.0);   // act a    -> act b;
	ddr_ctwr      = ceil(( pTwr_time * pClkMHz)/1000.0);   // write a  -> prech a;
	ddr_ctmrd     = 2;                                       // lmr      -> !nop
	ddr_ctdqss    = 1;
	ddr_ctrefr    = ceil((pRefrWindowHighPriority * pRefr_time * pClkMHz)/1000.0);
	ddr_cinittime = ceil((pInit_time * pClkMHz)/1000.0);

	if(type==DRAM_TYPE_DDR2) // DDR2
	{
		const int BA_BITS = 2;
		const int ROW_BITS = 13;
		const int COL_BITS = 10;
		const int pSdramAddrBits = 14;

		u32 pInitPD;
		u32 pWR;
		u32 pInitDLL;
		u32 pInitTM;
		u32 pEMR_OUT;
		u32 pEMR_RDQS;
		u32 pEMR_DQSn;
		u32 pEMR_OCD;
		u32 pEMR_RTT;
		u32 pAL;
		u32 pEMR_ODS;
		u32 pEMR_DLL;

		u32 pEMR2_SRT;


		 ddr_ctwtr     = ceil((pTwtr_time * pClkMHz)/1000.0);

		 pInitPD   = 0;    // Power-Down Mode
		//parameter [2:0] pWR       = 3'b010;  // Write Recovery
		 pWR       = ddr_ctwr-1;
		 pInitDLL  = 0;    // DLL Reset
		 pInitTM   = 0;    // Test Mode
		 pCL       = 3;  // cas latency      = 3
		 pInitBT   = 0;    // burst type       = sequental
		 pInitBL   = 2;  // burst            = 4

		 pEMR_OUT  = 0;    // Output Enable/Disable
		 pEMR_RDQS = 0;    // RDQS Enable/Disable
		 pEMR_DQSn = 1;    // DQS# Enable/Disable
		 pEMR_OCD  = 0;  // Off-Chip Driver(OCD) Impedance Calibration
		 pEMR_RTT  = 1;   // On-Die Termination(ODT)
		 pAL       = 0;  // Posted CAS Additive Latency
		 pEMR_ODS  = 0;    // Output Drive Strength
		 pEMR_DLL  = 0;    // DLL Enable

		 pEMR2_SRT = 0;    // SRT Enable

		 ddr_isddr2  = 0;
		 ddr_addrmap = 1;

		 ddr_bnksize = BA_BITS - 2; // +  2
		 ddr_rowsize = ROW_BITS-11; // + 11
		 ddr_colsize = COL_BITS- 8; // +  8

		 ddr_cslmr   = (0 << 13)|(pInitPD<<12)|(pWR<<9)|(pInitDLL<<8)|
				(pInitTM<<7)|(pCL<<4)|(pInitBT<<3)|pInitBL;
		 ddr_celmr   = (0 << 13)|(pEMR_OUT<<12)|(pEMR_RDQS<<11)|
				(pEMR_DQSn<<10)|(pEMR_OCD<<7)|
				(((pEMR_RTT&2)>>1)<<6) |
				(pAL<<3) | ((pEMR_RTT&1)<<2)|(pEMR_ODS<<1)|pEMR_DLL;
		 ddr_celmr2  = pEMR2_SRT<<7;
		 ddr_celmr3  = 0x0;
	}
	else // LPDDR
	{
		const int BA_BITS=2;
//		const int ROW_BITS=12;		// ARGO LPDDR Board
//		const int COL_BITS=9;		// ARGO LPDDR Board
		const int ROW_BITS=11;		// N LPDDR Board
		const int COL_BITS=8;		// N LPDDR Board

		ddr_ctwtr   = 2;

		pInitWBM   = 0;    // write burst mode = programed burst
		pInitOM   = 0;    // operation mode   = standart
#if IS_BOARD()
		// for N 32bit DDR Board
		pCL       = 0x2;  // cas latency      = 2
#else
		pCL       = 0x3;  // cas latency      = 3
#endif
		pInitBT   = 0;    // burst type       = sequental
		pInitBL   = 0x2;  // burst            = 4

		pInitDS   = 0x0;  // drive strength 100%
		pInitDS   = 0x2;  // 0=100%, 2=50%, 4=25% Nextchip
		pInitPASR = 0x0;  // partial array self refresh

		ddr_isddr2  = 1;
		ddr_addrmap = 1;	// 0=bank_row_column, 1=row_bank_column

		ddr_bnksize = BA_BITS - 2; // +  2
		ddr_rowsize = ROW_BITS-11; // + 11
		ddr_colsize = COL_BITS- 8; // +  8

	//	ddr_cslmr   = {{pSdramAddrBits-10{1'b0}}, pInitWBM, pInitOM, pCL, pInitBT, pInitBL};
		ddr_cslmr   = (pInitWBM<<9)|(pInitOM<<7)|(pCL<<4)|(pInitBT<<3)|pInitBL;
	//	ddr_celmr   = {{pSdramAddrBits- 8{1'b0}}, pInitDS, 2'b00, pInitPASR};
		ddr_celmr   = (pInitDS<<5)|pInitPASR;
		ddr_celmr2  = 0;
		ddr_celmr3  = 0;
	}

	{
		u32 reg_cfg_size        = (ddr_isddr2<<7)|(ddr_addrmap<<5)|(ddr_bnksize<<4)|(ddr_rowsize<<2)|ddr_colsize;
		u32 reg_ddr_timing0     = (ddr_ctrc<<16)|(ddr_ctrfc<<8)|ddr_ctras;
		u32 reg_ddr_timing1     = (ddr_ctdqss<<22)|(ddr_ctmrd<<20)|(ddr_ctwtr<<16)|(ddr_ctwr<<12)|(ddr_ctrrd<<8)|(ddr_ctrp<<4)|(ddr_ctrcd);
		u32 reg_ddr_timing2     = (ddr_cinittime<<16)|ddr_ctrefr;
		u32 reg_ddr_lmr_ext_std = (ddr_celmr<<16)|ddr_cslmr;
		u32 reg_ddr_lmr_ext_3_2 = (ddr_celmr3 << 16) | ddr_celmr2;

		tdk_printf("Main Freq = %f, DDR Type=%s\n", pClkMHz, type?"LPDDR":"DDR2");
		tdk_printf("reg_cfg_size         = 0x%08x, 0x%08x, 0x%08x\n", reg_read(DDRC_BASE+0x04), reg_cfg_size        ,reg_read(DDRC_BASE+0x04)^reg_cfg_size        );
		tdk_printf("reg_ddr_timing0      = 0x%08x, 0x%08x, 0x%08x\n", reg_read(DDRC_BASE+0x08), reg_ddr_timing0     ,reg_read(DDRC_BASE+0x08)^reg_ddr_timing0     );
		tdk_printf("reg_ddr_timing1      = 0x%08x, 0x%08x, 0x%08x\n", reg_read(DDRC_BASE+0x0c), reg_ddr_timing1     ,reg_read(DDRC_BASE+0x0c)^reg_ddr_timing1     );
		tdk_printf("reg_ddr_timing2      = 0x%08x, 0x%08x, 0x%08x\n", reg_read(DDRC_BASE+0x10), reg_ddr_timing2     ,reg_read(DDRC_BASE+0x10)^reg_ddr_timing2     );
		tdk_printf("reg_ddr_lmr_ext_std  = 0x%08x, 0x%08x, 0x%08x\n", reg_read(DDRC_BASE+0x14), reg_ddr_lmr_ext_std ,reg_read(DDRC_BASE+0x14)^reg_ddr_lmr_ext_std );
		tdk_printf("reg_ddr_lmr_ext_3_2  = 0x%08x, 0x%08x, 0x%08x\n", reg_read(DDRC_BASE+0x18), reg_ddr_lmr_ext_3_2 ,reg_read(DDRC_BASE+0x18)^reg_ddr_lmr_ext_3_2 );

		reg_write(DDRC_BASE+0x04, reg_cfg_size         );
		reg_write(DDRC_BASE+0x08, reg_ddr_timing0      );
		reg_write(DDRC_BASE+0x0c, reg_ddr_timing1      );
		reg_write(DDRC_BASE+0x10, reg_ddr_timing2      );
		reg_write(DDRC_BASE+0x14, reg_ddr_lmr_ext_std  );
		reg_write(DDRC_BASE+0x18, reg_ddr_lmr_ext_3_2  );
	}

	return 0;
}

int ddr_init(void)
{
	int ret=0;
	u32 data;
	int loop=0x10000;

	reg_write(DDR_PHY_CONFIG, DDR_PHY_INIT);

	while(loop--)
	{
		data = reg_read(DDR_PHY_CONFIG);
		if(data & DDR_PHY_COMPLETE) break;
	}
	data = reg_read(DDR_PHY_CONFIG);
	tdk_printf("DDR_PHY_CONFIG = 0x%08x\n", data);

	if(loop<=0)
	{
		tdk_printf("fail to DDR_PHY_COMPLETE\n");
		ret = -1;
	}

	if(!(data&DDR_PHY_SUCCESS))
	{
		tdk_printf("fail to DDR_PHY_SUCCESS\n");
		ret = -1;
	}

//	tdk_printf("DDR Init : %s\n", (loop>0 && (data&DDR_PHY_SUCCESS))? ANSI_PASS:ANSI_FAIL);

	return ret;
}

int ddr_dump(void)
{
	tdk_printf("============================================\n");
	tdk_printf("DDR Configuration\n");
	tdk_printf("============================================\n");
	tdk_printf("DDR_PHY_CONFIG          = 0x%08x\n", reg_read(DDR_PHY_CONFIG		));
	tdk_printf("DDR_ADDR_SIZE           = 0x%08x\n", reg_read(DDR_ADDR_SIZE			));
	tdk_printf("DDR_TIMING_0            = 0x%08x\n", reg_read(DDR_TIMING_0			));
	tdk_printf("DDR_TIMING_1            = 0x%08x\n", reg_read(DDR_TIMING_1			));
	tdk_printf("DDR_TIMING_2            = 0x%08x\n", reg_read(DDR_TIMING_2			));
	tdk_printf("DDR_LMR_EXT_STD         = 0x%08x\n", reg_read(DDR_LMR_EXT_STD		));
	tdk_printf("DDR_LMR_EXT_3_2         = 0x%08x\n", reg_read(DDR_LMR_EXT_3_2		));

	return 0;
}
