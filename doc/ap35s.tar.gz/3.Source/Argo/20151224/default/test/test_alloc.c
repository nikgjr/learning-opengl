/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "test_alloc.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"

#ifdef __GCC__
extern unsigned int _start;
extern unsigned int __base_of_heap__;
extern unsigned int __end_of_heap__;
extern unsigned int  __HEAP_START;
#endif

int test_alloc(int argc, char *argv[])
{
	unsigned int size = 1*KB;
	int count;
	unsigned int sum = 0;
	int i;
	unsigned int *ptr[1024];


#ifdef __GCC__
	tdk_printf("_start = 0x%08x\n", &_start);
	tdk_printf("__base_of_heap__ = 0x%08x\n", &__base_of_heap__);
	tdk_printf("__end_of_heap__  = 0x%08x\n", &__end_of_heap__);
	tdk_printf("__HEAP_START     = 0x%08x\n", &__HEAP_START);
#endif

	for(i=0, count=0; i<1024; i++, count++)
	{
		ptr[i] = malloc(size);
		if(ptr[i] == NULL) break;

		tdk_printf("[%3d] alloc pointer = 0x%08x\n", i, ptr[i]);
		sum += size;
	}

	for(i=0; i<count; i++)
	{
		free(ptr[i]);
		tdk_printf("[%3d] free pointer = 0x%08x\n", i, ptr[i]);
	}

	tdk_printf("Total alloc size = %d KB\n", sum/KB);
	return 0;
}
