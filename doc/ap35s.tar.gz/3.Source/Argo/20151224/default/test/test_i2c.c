/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/ansi.h"

#include "func_register.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"

#include "../drivers/gicdrv.h"
#include "../drivers/i2c.h"

void i2c_irq_handler(void *param)
{
	tREG_I2C *i2c = (tREG_I2C *)param;
	I2C_IsrHandler(i2c);
}

void i2c_irq_handler_2(void *param)
{
	tREG_I2C *i2c = (tREG_I2C *)param;
	tdk_printf("irq handler\n");
	I2C_IsrHandler(i2c);
}

void i2c_irq_init(void)
{
    GIC_ClearAllRaisedIrq();

	GIC_RegisterHandler(GIC_I2C0, i2c_irq_handler, (void*)I2C0);
	GIC_EnableIrq(GIC_I2C0);

	GIC_RegisterHandler(GIC_I2C1, i2c_irq_handler, (void*)I2C1);
	GIC_EnableIrq(GIC_I2C1);
}

int test_i2c_model(int argc, char *argv[])
{
	int init=0x7100;
	int ch;

	tI2C_RESP resp;
	unsigned char tx_buffer1[] = { 0x01, 0x02, 0x03, 0x04 };
	unsigned char rx_buffer1[9] = { 0x00 };
#if I2C_CHANNEL2_TEST
	unsigned char tx_buffer2[] = { 0x10, 0x20, 0x30, 0x40 };
	unsigned char rx_buffer2[9] = { 0x00 };
#endif
	tI2C_CTRL ic;
	tI2C_XFER_INFO xi;

    xi.addr = 0;
    xi.len = 4;
    xi.txBuf = (UINT8 *)tx_buffer1;
    xi.rxBuf = (UINT8 *)rx_buffer1;

	SYS_SimInfo(init+0x00, "I2C IRQ Init");
	i2c_irq_init();

	for(ch=0; ch<2; ch++)
	{
		tREG_I2C *i2c = NULL;

		switch(ch)
		{
		case 0: i2c = I2C0;		break;
		case 1: i2c = I2C1;		break;
		}

		if(i2c == NULL)
		{
			tdk_printf("fail to i2c pointer\n");
			return -1;
		}

		SYS_SimInfo(init+0x10, "I2C Init");
		ic.devAddr = 0x78;
		ic.clkDiv = 0x4;
		ic.addrType = IDAT_ADDR_7BIT;
		ic.addrLen = IDAL_ADDR_8BIT;

		I2C_MasterInit(i2c, &ic);

		SYS_SimInfo(init+0x20, "I2C Write");
		resp = I2C_MasterWriteData(i2c, &xi);
		if(resp) __SIM_END_FAIL(-1);

		SYS_SimInfo(init+0x30, "I2C Read");
		resp = I2C_MasterReadData(i2c, &xi);
		if(resp) __SIM_END_FAIL(-1);

		SYS_SimInfo(init+0x40, "Compare");
		if(memcmp(xi.rxBuf, xi.txBuf, xi.len) != 0)
		{
			int i;
			for(i=0; i<xi.len; i++)
			{
				tdk_printf("TX=0x%02x, RX=0x%02x\n", xi.txBuf[i], xi.rxBuf[i]);
			}
			return -1;
		}
	}

	tdk_printf("I2C Model Test %s\n", ANSI_PASS);
	return 0;
}

BOOL SYS_VerifyDataByte(UINT32 src, UINT32 dst, UINT32 len)
{
    UINT32 i;
    UINT8 *pSrc, *pDst;

    pSrc = (UINT8 *)src;
    pDst = (UINT8 *)dst;

    for(i=0; i<len; i++)
    {
        if(*pSrc++ != *pDst++)
        {
            tdk_printf("Fail addr:0x%08x, src data:0x%08x, dst dat:0x%08x\n", (UINT32)(pDst-1), *(pSrc-1), *(pDst-1));
            break;
        }
    }

    if(i == len)
        return TRUE;
    else
        return FALSE;
}


/****************************************************************************
NAME
INPUT
RETURNS
DESCRIPTION
*****************************************************************************/
#define __SIM_STR4(x)



void I2C_SimInt(tI2C_CTRL *ic, tI2C_XFER_INFO *xi)
{
	tREG_I2C *master, *slave;
	UINT16 i, j;
	UINT8 tmp[2];
	tI2C_RESP resp;

	for (j = 0; j < 2; j++)
	{
		if (j == 0)
		{
			master = I2C0;
			slave = I2C1;
			__SIM_STR4("M0S1");
			tdk_printf("\nMaster Ch:0, Slave Ch:1\n");
		}
		else
		{
			master = I2C1;
			slave = I2C0;
			__SIM_STR4("M1S0");
			tdk_printf("\nMaster Ch:1, Slave Ch:0\n");
		}

		__SIM_STEP(gStep++);
		I2C_MasterInit(master, ic);
		I2C_SlaveInit(slave, ic);

		/* Master write / slave read */
#if 1
		tdk_printf("Master write - Slave read\n");
		for (i = 0; i < xi->len; i++)
		{
			xi->txBuf[i] = i + 1;
			xi->rxBuf[i] = 0;
		}

		__SIM_STEP(gStep++);
		I2C_SetSlaveRxBuff(slave, xi->rxBuf, xi->len + 2);
		resp = I2C_MasterWriteData(master, xi);
		if (resp)
		{
			tdk_printf("I2C_MasterWriteData:resp=%d\n", resp);
			__SIM_END_FAIL(-1);
			gErrCnt++;
			return;
		}

		__SIM_STR4("VRFY");
		tdk_printf("Verify : ");
		if (!SYS_VerifyDataByte((UINT32) xi->txBuf, (UINT32) (xi->rxBuf + 2),
				xi->len))
		{
			tdk_printf("FAIL\n");
			__SIM_END_FAIL(-1);
			tdk_printf("TX ==========\n");
			tdk_dump32((tdk_addr) xi->txBuf, xi->len, NULL);
			tdk_printf("RX ==========\n");
			tdk_dump32((tdk_addr) xi->rxBuf, xi->len, NULL);
			gErrCnt++;
			return;
		}
		tdk_printf("OK\n");
#endif
		/* Master read / slave write */
#if 1
		tdk_printf("Master read - Slave Write\n");
		for(i=0; i<xi->len; i++)
		{
			xi->txBuf[i] = i+2;
			xi->rxBuf[i] = 0;
		}

		__SIM_STEP(gStep++);
		I2C_SetSlaveRxBuff(slave, tmp, 2); // for receive data address 2 byte
		I2C_SetSlaveTxBuff(slave, xi->txBuf, xi->len);
		resp = I2C_MasterReadData(master, xi);
		if(resp)
		{
			__SIM_END_FAIL(-1);
			gErrCnt++;
		}

		__SIM_STR4("VRFY");
		tdk_printf("Verify : ");
		if(!SYS_VerifyDataByte((UINT32)xi->txBuf, (UINT32)(xi->rxBuf), xi->len))
		{
			tdk_printf("FAIL\n");
			tdk_printf("TX ==========\n");
			tdk_dump32((tdk_addr)xi->txBuf, xi->len, NULL);
			tdk_printf("RX ==========\n");
			tdk_dump32((tdk_addr)xi->rxBuf, xi->len, NULL);
			gErrCnt++;
			__SIM_END_FAIL(-1);
			return;
		}
		tdk_printf("OK\n");
#endif
	}
}

extern void I2C_Debug_Init(void);
extern void I2C_Debug(void);

int test_i2c_loopback(int argc, char *argv[])
{
	int init = 0x7500;
	unsigned char tx_buffer1[128] =
	{ 0x01, 0x02, 0x03, 0x04 };
	unsigned char rx_buffer1[128] =
	{ 0x00 };

	tI2C_CTRL ic;
	tI2C_XFER_INFO xi;

	tdk_printf("=========================\n");
	tdk_printf("I2C Loopback Test\n");
	tdk_printf("=========================\n");


	SYS_SimInfo(init + 0x00, "I2C IRQ Init");
	i2c_irq_init();

	SYS_SimInfo(init + 0x10, "I2C");
	ic.devAddr = I2C_SLAVE_DEV_ADDR;
	ic.clkDiv = 0x14;
//	ic.clkDiv = 0x3;
	ic.addrType = IDAT_ADDR_7BIT;
	ic.addrLen = IDAL_ADDR_16BIT;

	tdk_printf("I2C Test Start\n");
	tdk_printf("By Interrupt\n");

	xi.addr = 0;
	xi.len = 8;
	xi.txBuf = (UINT8 *) tx_buffer1;
	xi.rxBuf = (UINT8 *) rx_buffer1;

	I2C_Debug_Init();
	I2C_SimInt(&ic, &xi);
//	I2C_Debug();

	return 0;
}

int test_i2c_debug(int argc, char *argv[])
{
	I2C_Debug();
}

