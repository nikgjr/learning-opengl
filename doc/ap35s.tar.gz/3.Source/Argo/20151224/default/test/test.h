#ifndef __TEST__
#define __TEST__

int test_timer(int argc, char *argv[]);
int test_wdt(int argc, char *argv[]);
int test_uart_loopback(int argc, char *argv[]);
int test_uart_echo(int argc, char *argv[]);

int test_spi_model(int argc, char *argv[]);
int test_spi_FM25M04(int argc, char *argv[]);
int test_spi_FM25M32A(int argc, char *argv[]);
int test_sflash_write(int argc, char *argv[]);
int test_sflash_program(int argc, char *argv[]);
int test_sflash_erase(int argc, char *argv[]);
int test_sflash_dump(int argc, char *argv[]);
int test_sflash_test(int argc, char *argv[]);


#endif
