/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "func_register.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"
#include "../include/ansi.h"

int g_default_size = 0x80;

unsigned int host_reg_read(tdk_addr addr)
{
	unsigned int data;
	data = *(volatile unsigned int *)addr;
	return data;
}

void host_reg_write(tdk_addr addr, unsigned int data)
{
	*(volatile unsigned int *)addr = data;
}

struct tdk_util_ops g_util_param = { NULL, host_reg_read, host_reg_write };

int	func_r08(int argc, char *argv[])
{
	unsigned int addr;

	if(argc < 2)
		return -1;

	addr = tdk_string_to_value(argv[1]);
	tdk_printf("R:addr = 0x%08x => 0x%08x\n", addr, reg_read8((tdk_addr)addr));
	
	return 0;
}

int	func_r16(int argc, char *argv[])
{
	unsigned int addr;

	if(argc < 2)
		return -1;

	addr = tdk_string_to_value(argv[1]);
	tdk_printf("R:addr = 0x%08x => 0x%08x\n", addr, reg_read16((tdk_addr)addr));

	return 0;
}

int	func_r32(int argc, char *argv[])
{
	unsigned int addr;

	if(argc < 2)
		return -1;

	addr = tdk_string_to_value(argv[1]);
	tdk_printf("R:addr = 0x%08x => 0x%08x\n", addr, host_reg_read((tdk_addr)addr));

	return 0;
}

int	func_w08(int argc, char *argv[])
{
	unsigned int addr = 0;
	unsigned int data = 0;

	if(argc < 3)
		return -1;

	addr = tdk_string_to_value(argv[1]);
	data = tdk_string_to_value(argv[2]);

	reg_write8((tdk_addr)addr, data);
	tdk_printf("W:addr = 0x%08x <= 0x%08x\n", addr, data);
	tdk_printf("R:addr = 0x%08x <= 0x%08x\n", addr, reg_read8((tdk_addr)addr));

	return 0;
}

int	func_w16(int argc, char *argv[])
{
	unsigned int addr = 0;
	unsigned int data = 0;

	if(argc < 3)
		return -1;

	addr = tdk_string_to_value(argv[1]);
	data = tdk_string_to_value(argv[2]);

	reg_write16((tdk_addr)addr, data);
	tdk_printf("W:addr = 0x%08x <= 0x%08x\n", addr, data);
	tdk_printf("R:addr = 0x%08x <= 0x%08x\n", addr, reg_read16((tdk_addr)addr));

	return 0;
}


int	func_w32(int argc, char *argv[])
{
	unsigned int addr = 0;
	unsigned int data = 0;

	if(argc < 3)
		return -1;
	
	addr = tdk_string_to_value(argv[1]);
	data = tdk_string_to_value(argv[2]);

	host_reg_write((tdk_addr)addr, data);
	tdk_printf("W:addr = 0x%08x <= 0x%08x\n", addr, data);
	tdk_printf("R:addr = 0x%08x <= 0x%08x\n", addr, host_reg_read((tdk_addr)addr));

	return 0;
}

int	func_d08(int argc, char *argv[])
{
	unsigned int addr;
	unsigned int size;

	if(argc < 2)
		return -1;

	addr = tdk_string_to_value(argv[1]);
	size = tdk_string_to_value(argv[2]);

	if(addr == 0xffffffff)
		return -1;

	if(size == 0xffffffff || size==0)
		size = g_default_size;

	tdk_dump08((tdk_addr)addr, size, &g_util_param);

	return 0;
}


int	func_d16(int argc, char *argv[])
{
	unsigned int addr;
	unsigned int size;

	if(argc < 2)
		return -1;

	addr = tdk_string_to_value(argv[1]);
	size = tdk_string_to_value(argv[2]);

	if(addr == 0xffffffff)
		return -1;

	if(size == 0xffffffff || size==0)
		size = g_default_size;

	tdk_dump16((tdk_addr)addr, size/2, &g_util_param);

	return 0;
}


int	func_d32(int argc, char *argv[])
{
	unsigned int addr;
	unsigned int size;

	if(argc < 2)
		return -1;

	addr = tdk_string_to_value(argv[1]);
	size = tdk_string_to_value(argv[2]);

	if(addr == 0xffffffff)
		return -1;

	if(size == 0xffffffff || size==0)
		size = g_default_size;

	tdk_dump32((tdk_addr)addr, size/4, &g_util_param);

	return 0;
}

int	func_c32(int argc, char *argv[])
{
	unsigned int addr;
	unsigned int size;
	unsigned int value;
	int i;

	if(argc < 2)
		return -1;

	addr = tdk_string_to_value(argv[1]);
	size = tdk_string_to_value(argv[2]);
	value = tdk_string_to_value(argv[3]);

	if(addr == 0xffffffff)
		return -1;

	if(size == 0xffffffff || size==0)
		size = g_default_size;

	for(i=0; i<size; i+=4)
	{
		reg_write(addr+i, value);
	}

	tdk_dump32((tdk_addr)addr, size/4, &g_util_param);

	return 0;
}

int func_compare(int argc, char *argv[])
{
	int addr1;
	int addr2;
	int size;
	int ret;

	if(argc < 4)
	{
		tdk_printf("compare fail\n");
		return -1;
	}

	addr1 = tdk_string_to_value(argv[1]);
	addr2 = tdk_string_to_value(argv[2]);
	size  = tdk_string_to_value(argv[3]);

	ret = tdk_verify32(addr1, addr2, size/4);
	if(ret==0) tdk_printf("%s\n", ANSI_PASS);

	return 0;
}
