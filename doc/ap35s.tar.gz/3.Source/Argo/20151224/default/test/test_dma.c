#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "func_register.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"

#include "../include/ansi.h"

#include "../drivers/gicdrv.h"
#include "../drivers/dma_pl330.h"
#include "../system/system.h"

void dma_irq_handler(void *param)
{
	int irq = (int)param;

    switch(irq)
    {
    case GIC_DMA_ABORT:
    	break;
    case GIC_DMA_CHANNEL0:
        M_DMA_CLR_INT(0);
    	break;
    case GIC_DMA_CHANNEL1:
        M_DMA_CLR_INT(1);
    	break;
    case GIC_DMA_CHANNEL2:
        M_DMA_CLR_INT(2);
    	break;
    case GIC_DMA_CHANNEL3:
        M_DMA_CLR_INT(3);
    	break;
    }

    tdk_printf("dma_irq_handler:irq=%d\n", irq);
}


/**
 * FPGA board에서 DMA block 초기화 함수
 */
void dma_init(void)
{
    GIC_RegisterHandler(GIC_DMA_ABORT, dma_irq_handler, (void*)GIC_DMA_ABORT);
    GIC_EnableIrq(GIC_DMA_ABORT);

    GIC_RegisterHandler(GIC_DMA_CHANNEL0, dma_irq_handler, (void*)GIC_DMA_CHANNEL0);
    GIC_EnableIrq(GIC_DMA_CHANNEL0);

    GIC_RegisterHandler(GIC_DMA_CHANNEL1, dma_irq_handler, (void*)GIC_DMA_CHANNEL1);
    GIC_EnableIrq(GIC_DMA_CHANNEL1);

    GIC_RegisterHandler(GIC_DMA_CHANNEL2, dma_irq_handler, (void*)GIC_DMA_CHANNEL2);
    GIC_EnableIrq(GIC_DMA_CHANNEL2);

    GIC_RegisterHandler(GIC_DMA_CHANNEL3, dma_irq_handler, (void*)GIC_DMA_CHANNEL3);
    GIC_EnableIrq(GIC_DMA_CHANNEL3);

    DMA_Init();
}

/**
 * FPGA board에서 DMA block을 사용하여 data transfer 후 verify 함수
 * @param	srcAddr	source address
 * @param	dstAddr	destination address
 * @param	len	transfer size
 * @param	nCh	DMA channel number
 */
BOOL dma_verify(UINT32 srcAddr, UINT32 dstAddr, UINT32 len, UINT32 nCh)
{
    UINT32 i, j;
    UINT32 *pBuf;
    UINT32 val;
    int err;

    for(j=0; j<nCh; j++)
    {
        pBuf = (UINT32 *)(dstAddr + (len * j));
        err = 0;
        for(i=0; i<len/4; i++)
        {
            val = *pBuf;
            if((i+j) != val)
            {
                tdk_printf("[%d CH] ERR Addr: 0x%08x, correct: 0x%08x, wrong: 0x%08x\n", j, (UINT32)(pBuf), i, val);
                err++;
            }
            pBuf++;
            if(err>5) break;
        }

        if(err==0)
        {
        	tdk_printf("[%d CH] DMA Verify : %s\n", j, ANSI_PASS);
        }
        else
        {
        	tdk_printf("[%d CH] DMA Verify : %s\n", j, ANSI_FAIL);
        }

    }
    return TRUE;
}

BOOL dma_init_memory(UINT32 srcAddr, UINT32 dstAddr, UINT32 len, UINT32 nCh)
{
	UINT32 i, j;
    UINT32 *pBuf;

    /* Set source memory */
    for(j=0; j<nCh; j++)
    {
        pBuf = (UINT32 *)(srcAddr + (len * j));
        for(i=0; i<len/4; i++)
            *pBuf++ = i + j;
    }

    /* Clear target memory */
    for(j=0; j<nCh; j++)
    {
        pBuf = (UINT32 *)(dstAddr + (len * j));
        for(i=0; i<len/4; i++)
            *pBuf++ = 0;
    }

	return TRUE;
}

/**
 * FPGA board에서 DMA block을 사용하여 memory to memory data transfer test 함수
 * @param	srcAddr	source address
 * @param	dstAddr	destination address
 * @param	len	transfer size
 * @param	nCh	DMA channel number
 */
BOOL dma_transfer(UINT32 srcAddr, UINT32 dstAddr, UINT32 len, UINT32 nCh)
{
//	UINT32 i;
    UINT32 j;
    UINT32 microCodeBase;
    tDMA_INFO info;
 //	 UINT32 *pBuf;
    INT32 ret = 0;

    microCodeBase = SYS_GetNoneCacheAddress()+0x0000;

    __SIM_DEBUG_REG(SIM_DEBUG_RESPONSE, microCodeBase);

    tdk_printf("srcAddr=0x%08x(PADDR=0x%08x), dstAddr=0x%08x(PADDR=0x%08x)\n", srcAddr, SYS_Virtual2Physical(srcAddr), dstAddr, SYS_Virtual2Physical(dstAddr));
    tdk_printf("microCodeBase=0x%08x(PADDR=0x%08x)\n", microCodeBase, SYS_Virtual2Physical(microCodeBase));

#if 0
    /* Set source memory */
    tdk_printf("Set Source\n");
    for(j=0; j<nCh; j++)
    {
        pBuf = (UINT32 *)(srcAddr + (len * j));
        for(i=0; i<len/4; i++)
            *pBuf++ = i + j;
    }

    /* Clear target memory */
    tdk_printf("Clear Target\n");
    for(j=0; j<nCh; j++)
    {
        pBuf = (UINT32 *)(dstAddr + (len * j));
        for(i=0; i<len/4; i++)
            *pBuf++ = 0;
    }
#endif

    tdk_printf("DMA Configuration\n", nCh);
    for(j=0; j<nCh; j++)
    {
        __SIM_DEBUG_REG(SIM_DEBUG_RESPONSE, nCh);
        tdk_printf("[%d CH] Configuration\n", j);
        /* set DMA configure */
        info.burstSize = BS_1B;
        info.burstLen = BL_16XFER;
        info.dmaCh = (tDMA_CH)((UINT32)DC_CH0 + j);
        info.reqType = RT_MEM_TO_MEM;
//        info.srcAddr = srcAddr + (len * j);
//        info.dstAddr = dstAddr + (len * j);
        info.srcAddr = SYS_Virtual2Physical(srcAddr + (len * j));
        info.dstAddr = SYS_Virtual2Physical(dstAddr + (len * j));
        info.xferBytes = len;
        info.microCodeBase = microCodeBase + ret;
        info.microCodePhysical = SYS_Virtual2Physical(info.microCodeBase);
        ret += DMA_Req(&info);
        if(ret <= 0)
        {
        	return FALSE;
        }
        ret = ((ret+3)/4) * 4;
    }

    return TRUE;
}

BOOL dma_start(UINT32 nCh)
{
    UINT32 j;
    for(j=0; j<nCh; j++)
    {
    	tdk_printf("[%d CH] DMA Start \n", j);
        DMA_Ctrl(DO_START, (tDMA_CH)((UINT32)DC_CH0 + j));
    }

    return TRUE;
}

BOOL dma_wait_complete(UINT32 srcAddr, UINT32 dstAddr, UINT32 len, UINT32 nCh)
{
    UINT32 j;
    for(j=0; j<nCh; j++)
	{
 //   	tdk_printf("[%d CH] wait for channel %d complete \n", j, j);
		while(1)
		{
			if(GIC_CheckRaisedIrq(GIC_DMA_CHANNEL0+j))
				break;
			
			if(GIC_CheckRaisedIrq(GIC_DMA_ABORT))
				break;
		}
    	tdk_printf("[%d CH] DMA IRQ OK!!! \n", j);
	}

    return TRUE;
}

int test_dma(int argc, char *argv[])
{
	UINT32 srcAddr, dstAddr;
	UINT32 len;
	BOOL ret;
	int nCh = 4;

	GIC_ClearAllRaisedIrq();

	len = 2048;

	if (argv && argv[1])
		nCh = tdk_string_to_value(argv[1]);
	if (argv && argv[2])
		len = tdk_string_to_value(argv[2]);

//	tdk_printf("Set Syscon Remap\n");
//	reg_write(0x30300010, 0x00000000);
//	reg_write(0x30300014, 0x03FFFFFF);
//	reg_write(0x30300018, 0x04000000);

	tdk_printf("DMA test : Channel Count = %d\n", nCh, nCh);
	tdk_puts("DMA INIT");
	dma_init();

	srcAddr = SYS_GetNoneCacheAddress() + 0x4000;
	dstAddr = SYS_GetNoneCacheAddress() + 0x6000;

	tdk_puts("MEM INIT");
	dma_init_memory(srcAddr, dstAddr, len, nCh);

	tdk_puts("DMA GEN CODE");
	ret = dma_transfer(srcAddr, dstAddr, len, nCh);

	tdk_puts("DMA START");
	dma_start(nCh);

	tdk_puts("DMA WAIT");
	ret = dma_wait_complete(srcAddr, dstAddr, len, nCh);
	if (!ret)
		__SIM_FAIL(ret);

	tdk_puts("DMA VERIFY");
	if (dma_verify(0, dstAddr, len, nCh))
	{
		ret = TRUE;
	}
	else
	{
		ret = FALSE;
	}

	if (ret)
		tdk_printf("DMA test OK\n");
	else
	{
		tdk_printf("test Fail!\n");
		__SIM_FAIL(-1);
	}
	tdk_puts("DMA END");
	return 0;
}

int test_dma_info(int argc, char *argv[])
{
	DMA_dump();
	return 0;
}

