
#include "test_basic.h"
#include "../system/system.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"

int test_basic(int argc, char *argv[])
{
	u32 init = __SIM_READ_REG(SIM_DEBUG_TESTID);
	u32 vaddr = SYS_GetNoneCacheAddress();
	u32 paddr = SYS_Virtual2Physical(vaddr);
	int i;
	u32 data;
	u32 *buffer;

	__SIM_DEBUG(init+0x00);
	reg_write(vaddr+0, 0x100);
	reg_write(vaddr+1, 0x100);
	reg_write(vaddr+2, 0x100);
	reg_write(vaddr+3, 0x100);

	__SIM_RESP(vaddr);
	__SIM_RESP(paddr);

	__SIM_DEBUG(init+0x10);
	for(i=0; i<16; i++)
	{
		reg_write(vaddr+i*4, i+1);
	}

	__SIM_DEBUG(init+0x20);
	for(i=0; i<16; i++)
	{
		data = reg_read(vaddr+i*4);
		if(data != i+1) __SIM_END_FAIL(i);
	}

	__SIM_DEBUG(init+0x110);
	buffer=(u32*)vaddr;
	for(i=0; i<16; i++)
	{
		buffer[i] = i+1;
	}

	__SIM_DEBUG(init+0x120);
	for(i=0; i<16; i++)
	{
		data = buffer[i];
		if(data != i+1) __SIM_END_FAIL(i);
	}


	__SIM_DEBUG(init+0x210);
	buffer=(u32*)0x0;
	for(i=0; i<16; i++)
	{
		buffer[i] = i+1;
	}

	__SIM_DEBUG(init+0x220);
	for(i=0; i<16; i++)
	{
		data = buffer[i];
		if(data != i+1) __SIM_END_FAIL(i);
	}
	return 0;
}

int test_reset(int argc, char *argv[])
{
	u32 type = 1;

	tdk_printf("==========================================\n");
	tdk_printf("R4 Reset\n");
	tdk_printf("==========================================\n");

	if(argv && argv[1]) type = tdk_string_to_value(argv[1]);
	tdk_printf("type = %d\n", type);
	tdk_printf("kkk");

	switch(type)
	{
	case 1:
		tdk_printf("Reset R4\n");
		SYS_DelayTick(10000);
		rSYSCON_RESET = SYSCON_RESET_R4;
		break;
	case 2:
		tdk_printf("Reset R4 & BUS\n");
		SYS_DelayTick(10000);
		rSYSCON_RESET = SYSCON_RESET_BUS;
		break;
	case 4:
		tdk_printf("WDT\n");
		SYS_DelayTick(10000);
		rSYSCON_RESET = SYSCON_RESET_SYSCON;
		break;
	}

	while(1);
}

int test_remap(int argc, char *argv[])
{
	u32 start = 0x0;
	u32 end = 16*MB;
	u32 offset = 0x60000000;

	if(argv && argv[1]) start = tdk_string_to_value(argv[1]);
	if(argv && argv[2]) end = tdk_string_to_value(argv[2]);
	if(argv && argv[3]) offset = tdk_string_to_value(argv[3]);


	tdk_printf("==========================================\n");
	tdk_printf("Remap\n");
	tdk_printf("==========================================\n");
	tdk_printf("Start=0x%08x, End=0x%08x, Offset=0x%08x\n", start, end, offset);

	SYS_RemapEnable(start, end, offset);

	return 0;
}
