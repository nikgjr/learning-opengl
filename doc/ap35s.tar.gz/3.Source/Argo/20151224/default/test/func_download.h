#ifndef __FUNC_DOWNLOAD__
#define __FUNC_DOWNLOAD__

int func_go(int argc, char *argv[]);
int func_rz(int argc, char *argv[]);
int func_reset(int argc, char *argv[]);

#endif
