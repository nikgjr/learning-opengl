/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#ifndef __TEST_BUS__
#define __TEST_BUS__

int test_bus_access(int argc, char *argv[]);
int test_bus_test(int argc, char *argv[]);
int test_bus_ram(int argc, char *argv[]);
int test_map(int argc, char *argv[]);
#endif
