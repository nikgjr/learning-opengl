/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/ansi.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"
#include "../system/system.h"

#if defined(TDK_EMULATOR)
u32 memory[6*MB/4];
#endif

struct top_memory_map
{
	const char *name;
	u32 address;
};

#define		DEFINE_MEMORY_MAP(name,addr)	{ #name , addr }

static const struct top_memory_map	apache35_memory_map[] =
{
//	DEFINE_MEMORY_MAP(APACHE_BOOT_ROM			, APACHE_BOOT_ROM			),
	DEFINE_MEMORY_MAP(APACHE_BOOT_RAM			, APACHE_BOOT_RAM			),

	DEFINE_MEMORY_MAP(APACHE_DMA_0_BASE			, APACHE_DMA_0_BASE			),
	DEFINE_MEMORY_MAP(APACHE_DMA_1_BASE			, APACHE_DMA_1_BASE			),
//	DEFINE_MEMORY_MAP(APACHE_SYSCON_BASE		, APACHE_SYSCON_BASE		),
//	DEFINE_MEMORY_MAP(APACHE_WDT_BASE			, APACHE_WDT_BASE			),
	DEFINE_MEMORY_MAP(APACHE_TIMER_BASE			, APACHE_TIMER_BASE			),
	DEFINE_MEMORY_MAP(APACHE_TEMP_BASE			, APACHE_TEMP_BASE			),
//	DEFINE_MEMORY_MAP(APACHE_DDRC_BASE			, APACHE_DDRC_BASE			),
	DEFINE_MEMORY_MAP(APACHE_I2C_0_BASE			, APACHE_I2C_0_BASE			),
	DEFINE_MEMORY_MAP(APACHE_I2C_1_BASE			, APACHE_I2C_1_BASE			),
#if IS_SIMULATOR()
	DEFINE_MEMORY_MAP(APACHE_UART_0_BASE		, APACHE_UART_0_BASE		),
#endif
	DEFINE_MEMORY_MAP(APACHE_UART_1_BASE		, APACHE_UART_1_BASE		),
	DEFINE_MEMORY_MAP(APACHE_GPIO_0_BASE		, APACHE_GPIO_0_BASE		),
	DEFINE_MEMORY_MAP(APACHE_SPI_0_BASE			, APACHE_SPI_0_BASE			),
	DEFINE_MEMORY_MAP(APACHE_SPI_1_BASE			, APACHE_SPI_1_BASE			),
	DEFINE_MEMORY_MAP(APACHE_CUSTOM_0			, APACHE_CUSTOM_0			),
	DEFINE_MEMORY_MAP(APACHE_CUSTOM_1			, APACHE_CUSTOM_1			),
	DEFINE_MEMORY_MAP(APACHE_CUSTOM_2			, APACHE_CUSTOM_2			),
};

void bench_reg_write(u32 addr, u32 data)
{
//	tdk_printf("WR:0x%08x=0x%08x\n", addr, data);
#if defined(TDK_EMULATOR)
	addr &= 0x00FFFFFF;
	addr/=4;
	memory[addr]=data;
#else
	*((volatile unsigned int*)addr) = data;
#endif
}

u32 bench_reg_read(u32 addr)
{
	unsigned data;
#if defined(TDK_EMULATOR)
	u32 index;
	index = addr&0x00FFFFFF;
	index/=4;
	data = memory[index];
#else
	data = *(volatile unsigned int*)addr;
#endif

//	tdk_printf("RD:0x%08x=0x%08x\n", addr, data);
	return data;
}

int bench_reg_verify(u32 addr, u32 data)
{
	u32 read_data;
	bench_reg_write(addr, data);
	read_data = bench_reg_read(addr);
	if(data != read_data)
	{
		__SIM_DEBUG_REG(SIM_DEBUG_WADDR, addr);
		__SIM_DEBUG_REG(SIM_DEBUG_WDATA, data);

		__SIM_DEBUG_REG(SIM_DEBUG_RADDR, addr);
		__SIM_DEBUG_REG(SIM_DEBUG_RDATA, read_data);
		return -1;
	}
#if IS_BOARD()
	tdk_printf("Address 0x%08x : WR=0x%08x, RD=0x%08x, %s\n", addr, data, read_data, ansi_get_status_string(data == read_data));
#endif
	return 0;
}


int bench_reg_verify2(u32 addr, u32 data)
{
	u32 read_data;
	bench_reg_write(addr, data);
	read_data = bench_reg_read(0x0);
	read_data = bench_reg_read(addr);
	if(data != read_data)
	{
		__SIM_DEBUG_REG(SIM_DEBUG_WADDR, addr);
		__SIM_DEBUG_REG(SIM_DEBUG_WDATA, data);
		__SIM_DEBUG_REG(SIM_DEBUG_RADDR, addr);
		__SIM_DEBUG_REG(SIM_DEBUG_RDATA, read_data);
		return -1;
	}
#if IS_BOARD()
	tdk_printf("Address 0x%08x : WR=0x%08x, RD=0x%08x, %s\n", addr, data, read_data, ansi_get_status_string(data == read_data));
#endif
	return 0;
}


int test_bus_access(int argc, char *argv[])
{
	int i;
	int mm;

	u32 data;
	u32 addr;
	int count=16;

	for(mm=0; mm<sizeof(apache35_memory_map)/sizeof(apache35_memory_map[0]); mm++)
	{
		SYS_SimInfo(apache35_memory_map[mm].address, "Access Test");

		addr = apache35_memory_map[mm].address;
		data = 0x1000;
		for(i=0; i<count; i++)
		{
			bench_reg_verify(addr+(i<<2), (data+i+1));
		}
	}

	return 0;
}

int test_bus_test(int argc, char *argv[])
{
	u32 addr;
	u32 data;
	u32 init=0x3000;

	SYS_SimInfo(init+0x00, "Access Test");

	return 0;
}

struct top_memory_map	uud_memory_map[] =
{
	DEFINE_MEMORY_MAP(APACHE_BOOT_RAM			, APACHE_BOOT_RAM+0x000000	),
};


int test_bus_ram(int argc, char *argv[])
{
	int i;
	int mm;

	u32 data;
	u32 addr;
	u32 value;
	int count=16;
	int ret;

	for(mm=0; mm<sizeof(uud_memory_map)/sizeof(uud_memory_map[0]); mm++)
	{
		SYS_SimInfo(uud_memory_map[mm].address, "Access Test");

		addr = uud_memory_map[mm].address;
		data = mm*0x1000;

		SYS_SimInfo(uud_memory_map[mm].address+0x10, "Write");
		for(i=0; i<count; i++)
		{
			__SIM_DEBUG_REG(SIM_DEBUG_WADDR, addr+(i<<2));
			__SIM_DEBUG_REG(SIM_DEBUG_WDATA, 0x1000+i+1);
			bench_reg_write(addr+(i<<2), 0x1000+i+1);
		}

		SYS_SimInfo(uud_memory_map[mm].address+0x20, "Read");
		for(i=0; i<count; i++)
		{
			value = bench_reg_read(addr+(i<<2));
			__SIM_DEBUG_REG(SIM_DEBUG_RADDR, addr+(i<<2));
			__SIM_DEBUG_REG(SIM_DEBUG_RDATA, value);
			if(value != 0x1000+i+1) return -1;
		}

		SYS_SimInfo(uud_memory_map[mm].address+0x30, "Read/Write");
		for(i=0; i<count; i++)
		{
			ret = bench_reg_verify(addr+(i<<2), (data+i+1));
			if(ret) return ret;
		}

		SYS_SimInfo(uud_memory_map[mm].address+0x40, "Read/Write");
		for(i=0; i<count; i++)
		{
			ret = bench_reg_verify2(addr+(i<<2), (data+i+1));
			if(ret) return ret;
		}

		tdk_printf("Address 0x%08x : %s\n", addr, ansi_get_status_string(1));
	}

	return ret;
}

int test_map(int argc, char *argv[])
{

    return 0;
}
