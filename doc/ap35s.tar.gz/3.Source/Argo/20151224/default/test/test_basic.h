
#ifndef __TEST_BASIC__
#define __TEST_BASIC__

int test_basic(int argc, char *argv[]);
int test_fixmath(int argc, char *argv[]);
int test_reset(int argc, char *argv[]);
int test_remap(int argc, char *argv[]);

#endif
