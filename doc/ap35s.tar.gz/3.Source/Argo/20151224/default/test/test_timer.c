#include <stdio.h>

#include "../system/system.h"
#include "../drivers/timer.h"
#include "test.h"

#include "../system/semaphore.h"
#include "../tdk/tdk.h"

#include "../drivers/gicdrv.h"
#include "../include/ansi.h"

volatile SEMAPHORE sem_timer0;
volatile SEMAPHORE sem_timer1;

void timer_irq_hadnler0(void *param)
{
	tREG_TIMER *timer = TIMER0;
	tdk_puts("TIMER0 I");
	timer->INTCLR = 1;
	sem_post((SEMAPHORE*)&sem_timer0);
}

void timer_irq_hadnler1(void *param)
{
	tREG_TIMER *timer = TIMER1;
	tdk_puts("TIMER1 I");
	timer->INTCLR = 1;
	sem_post((SEMAPHORE*)&sem_timer1);
}

int test_timer_freerun(void)
{
	int ret;

	int scaler = TIMER_CONTROL_PRESCALE_1;

	GIC_RegisterHandler(GIC_TIMER_0, timer_irq_hadnler0, NULL);
	GIC_EnableIrq(GIC_TIMER_0);

	GIC_RegisterHandler(GIC_TIMER_1, timer_irq_hadnler1, NULL);
	GIC_EnableIrq(GIC_TIMER_1);


    tdk_puts("TIMER0");

#if IS_BOARD()
    scaler = TIMER_CONTROL_PRESCALE_256;
#endif

    tdk_printf("TIMER0 Test\n");
	timer_init(TIMER0, TIMER_CONTROL_MODE_FREERUN, scaler, TIMER_CONTROL_SIZE_16BIT, 0);

	sem_init((SEMAPHORE*)&sem_timer0);
    tdk_puts("TIMER0 START");
	timer_start(TIMER0, 999);

	tdk_puts("TIMER0 WAIT");
	ret = sem_pend((SEMAPHORE*)&sem_timer0, 0x10000);
	if(ret)
	{
		tdk_printf("Timer Test %s\n", ANSI_FAIL);
		return -1;
	}

#if 1
    tdk_puts("TIMER1");
	timer_init(TIMER1, TIMER_CONTROL_MODE_PERIOD, scaler, TIMER_CONTROL_SIZE_16BIT, 0);

	sem_init((SEMAPHORE*)&sem_timer1);
    tdk_puts("TIMER1 START");
	timer_start(TIMER1, 999);

	tdk_puts("TIMER1 WAIT");
	ret = sem_pend((SEMAPHORE*)&sem_timer1, 0x10000);
	if(ret)
	{
		tdk_printf("Timer Test %s\n", ANSI_FAIL);
		return -1;
	}
	timer_disable(TIMER1);
#endif

	return 0;
}


int test_timer(int argc, char *argv[])
{
	int fail = 0;
	int ret;

    tdk_puts("TIMER");

	ret = test_timer_freerun();
	fail +=  ret ? 1 : 0;

	return fail;
}

