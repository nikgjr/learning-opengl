

#include "../system/system.h"
#include "../system/semaphore.h"

#include "../drivers/gpio.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"
#include "test.h"

void irq_gpio_handler0(void)
{
	tdk_printf("GP0 IRQ\n");
	reg_write(GPIO_REG_IC, 1<<0);
#if IS_SIMULATOR()
//	INTC_DisableInt(IS_GPIO0);
#endif
}

void irq_gpio_handler1(void)
{
	tdk_printf("GP1 IRQ\n");
	reg_write(GPIO_REG_IC, 1<<1);
#if IS_SIMULATOR()
//	INTC_DisableInt(IS_GPIO1);
#endif
}

void irq_gpio_handler2(void)
{
	tdk_printf("GP2 IRQ\n");
	reg_write(GPIO_REG_IC, 1<<2);
#if IS_SIMULATOR()
//	INTC_DisableInt(IS_GPIO2);
#endif
}

void irq_gpio_handler3(void)
{
	tdk_printf("GP3 IRQ\n");
	reg_write(GPIO_REG_IC, 1<<3);
#if IS_SIMULATOR()
//	INTC_DisableInt(IS_GPIO3);
#endif
}

void irq_gpio_handler4(void)
{
	tdk_printf("GP4 IRQ\n");
	reg_write(GPIO_REG_IC, 1<<4);
#if IS_SIMULATOR()
//	INTC_DisableInt(IS_GPIO4);
#endif
}

void irq_gpio_handler5(void)
{
	tdk_printf("GP5 IRQ\n");
	reg_write(GPIO_REG_IC, 1<<5);
#if IS_SIMULATOR()
//	INTC_DisableInt(IS_GPIO5);
#endif
}

void irq_gpio_handler6(void)
{
	tdk_printf("GP6 IRQ\n");
	reg_write(GPIO_REG_IC, 1<<6);
#if IS_SIMULATOR()
//	INTC_DisableInt(IS_GPIO6);
#endif
}

void irq_gpio_handler7(void)
{
	tdk_printf("GP7 IRQ\n");
	reg_write(GPIO_REG_IC, 1<<7);
#if IS_SIMULATOR()
//	INTC_DisableInt(IS_GPIO7);
#endif
}


int test_gpio(int argc, char *argv[])
{
	u32 addr = GPIO_BASE;
	u32 data;
	int i;

	tdk_printf("GPIO SIM\n");

	tdk_printf("GPIO IN\n");
	data = reg_read(addr+(0xff<<2));
	__SIM_RESP(data);
	data = reg_read(addr+(0xff<<2));
	__SIM_RESP(data);

	tdk_printf("GPIO OUT\n");
	reg_write(addr+0x400, 0xff);
	reg_write(addr+0x000+(0xff<<2), 0x0);
	for(i=0; i<8; i++)
	{
		reg_write(addr+0x000+(0xff<<2), 1<<i);
	}

	for(i=0; i<8; i++)
	{
		reg_write(addr+0x000+(0xff<<2), 1<<(7-i));
	}

	reg_write(addr+(0xff<<2), 0x0);

	tdk_printf("GPIO INT\n");
	reg_write(addr+0x400, 0x00);
//	INTC_EnableInt(IS_GPIO0, 0x0);
//	INTC_EnableInt(IS_GPIO1, 0x0);
//	INTC_EnableInt(IS_GPIO2, 0x0);
//	INTC_EnableInt(IS_GPIO3, 0x0);
//	INTC_EnableInt(IS_GPIO4, 0x0);
//	INTC_EnableInt(IS_GPIO5, 0x0);
//	INTC_EnableInt(IS_GPIO6, 0x0);
//	INTC_EnableInt(IS_GPIO7, 0x0);

	tdk_printf("GPIO STA\n");
	data = reg_read(GPIO_REG_IS	);	__SIM_RESP(data);
	data = reg_read(GPIO_REG_IBE	);	__SIM_RESP(data);
	data = reg_read(GPIO_REG_IEV	);	__SIM_RESP(data);
	data = reg_read(GPIO_REG_IE	);	__SIM_RESP(data);
	data = reg_read(GPIO_REG_RIS	);	__SIM_RESP(data);
	data = reg_read(GPIO_REG_MIS	);	__SIM_RESP(data);
	data = reg_read(GPIO_REG_IC	);	__SIM_RESP(data);
	data = reg_read(GPIO_REG_AFSEL	);	__SIM_RESP(data);

	tdk_printf("GPIO IS\n");
	reg_write(GPIO_REG_IS, 0xff);
	data = reg_read(GPIO_REG_IS	);	__SIM_RESP(data);

	tdk_printf("GPIO IEV\n");
	reg_write(GPIO_REG_IEV, 0xff);
	data = reg_read(GPIO_REG_IEV	);	__SIM_RESP(data);

	tdk_printf("GPIO IE\n");
	reg_write(GPIO_REG_IE, 0xff);
	data = reg_read(GPIO_REG_IE	);	__SIM_RESP(data);

	for(i=0; i<100; i++);
	return 0;
}

int test_gpio_int(int argc, char *argv[])
{
	tdk_printf("=============================\n");
	tdk_printf("GPIO Interrupt Test\n");
	tdk_printf("=============================\n");

	reg_write(GPIO_REG_DIR, 0xf0);

//	INTC_EnableInt(IS_GPIO0, 0x0);
//	INTC_EnableInt(IS_GPIO1, 0x0);

	reg_write(GPIO_REG_IS, 0xff);	// Edge=0, Level=1
	reg_write(GPIO_REG_IE, 0xff);	// Enable

	return 0;
}

int test_gpio_in(int argc, char *argv[])
{
	u32 data;

	tdk_printf("=============================\n");
	tdk_printf("GPIO Inupt Test\n");
	tdk_printf("=============================\n");

	reg_write(GPIO_REG_DIR, 0xf0);
	data = reg_read(GPIO_REG_DATA+(0xff<<2));

	tdk_printf("read = 0x%02x\n", data);

	return 0;
}

int test_gpio_out(int argc, char *argv[])
{
	int i;

	tdk_printf("=============================\n");
	tdk_printf("GPIO Out Test\n");
	tdk_printf("=============================\n");

	reg_write(GPIO_REG_DIR, 0xf0);
	reg_write(GPIO_REG_DATA+(0xff<<2), 0x0);
	for(i=0; i<8; i++)
	{
		tdk_printf("GPIO value = 0x%08x\n", 1<<i);
		reg_write(GPIO_REG_DATA+(0xff<<2), 1<<i);
		SYS_Delay(100000);
	}
	reg_write(GPIO_REG_DATA+(0xff<<2), 0x0);
	return 0;
}
