/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#ifndef __TEST_I2C__
#define __TEST_I2C__

int test_i2c_model(int argc, char *argv[]);
int test_i2c_sensor(int argc, char *argv[]);
int test_i2c_loopback(int argc, char *argv[]);
int test_i2c_debug(int argc, char *argv[]);

#endif
