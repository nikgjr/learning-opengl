#include <stdio.h>

#include "../drivers/wdt.h"
#include "../system/semaphore.h"
#include "../system/system.h"

#include "../drivers/gicdrv.h"
#include "../tdk/tdk.h"

#include "test.h"

SEMAPHORE sem_wdt;

void wdog_irq_hadnler(void * param)
{
	WDT->WDOGINTCLR = 1;
	tdk_puts("WDOG IRQ");
	sem_post(&sem_wdt);
}

int test_wdt(int argc, char *argv[])
{
	int ret;
	int i;
	int wdt_value = 999;

#if IS_BOARD()
	wdt_value = 0x80000;
#endif

    tdk_puts("WDOG");
	sem_init(&sem_wdt);

	GIC_RegisterHandler(GIC_WDT, wdog_irq_hadnler, NULL);
	GIC_EnableIrq(GIC_WDT);

	// enable interrupt
    tdk_puts("WDOG INT");
	WDT->WDOGCONTROL = WDOG_CONTROL_INT_ENABLE;
	WDT->WDOGLOAD = wdt_value;

    tdk_puts("WDOG RE");
	for(i=0; i<100; i++);
	WDT->WDOGLOAD = wdt_value;

    tdk_puts("WDOG RE");
	for(i=0; i<100; i++);
	WDT->WDOGLOAD = wdt_value;

	// wait
    tdk_puts("WDOG W");
	ret = sem_pend(&sem_wdt, 0x100000);
	if(ret)
	{
		tdk_puts("TIMEOUT");
		return -1;
	}

	// enable reset
	GIC_DisableIrq(GIC_WDT);
    tdk_puts("WDOG RST");
	WDT->WDOGCONTROL = WDOG_CONTROL_INT_ENABLE|WDOG_CONTROL_RESET_ENABLE;
	WDT->WDOGLOAD = wdt_value;

    tdk_puts("WDOG RE");
	for(i=0; i<100; i++);
	WDT->WDOGLOAD = wdt_value;

    tdk_puts("WDOG RE");
	for(i=0; i<100; i++);
	WDT->WDOGLOAD = wdt_value;

	// wait
    tdk_puts("WDOG W");

    tdk_puts("WAIT RST");
    while(1);
    tdk_puts("can't display this message!!!!");
}
