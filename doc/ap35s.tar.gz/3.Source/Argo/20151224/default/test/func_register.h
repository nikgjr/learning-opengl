/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#ifndef __FUNC_REG__
#define __FUNC_REG__

int func_r08(int argc, char *argv[]);
int	func_r16(int argc, char *argv[]);
int	func_w16(int argc, char *argv[]);

int func_w08(int argc, char *argv[]);
int	func_r32(int argc, char *argv[]);
int	func_w32(int argc, char *argv[]);

int	func_d8(int argc, char *argv[]);
int	func_d16(int argc, char *argv[]);
int	func_d32(int argc, char *argv[]);

int	func_c8(int argc, char *argv[]);
int	func_c16(int argc, char *argv[]);
int	func_c32(int argc, char *argv[]);

int func_compare(int argc, char *argv[]);

#endif
