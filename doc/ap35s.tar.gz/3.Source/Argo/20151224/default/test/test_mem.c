
#include "../tdk/tdk.h"
#include "../tdk/tdk_types.h"
#include "../tdk/tdk_util.h"

#include "../config/CR4_TopRegMap.h"
#include "../include/ansi.h"
#include "../drivers/ddr.h"

#include <math.h>
#include <stdlib.h>

//#define mem_debug	tdk_printf
#define mem_debug(...)

#define WATCHDOG_RESET()

int error_on_stop=0;
int error_count=0;

int ctrlc(void)
{
	return error_on_stop;
}

int mem_test_alt(u32 *buf, u32 start_addr, u32 end_addr,
			  u32 *dummy)
{
	u32 *addr;
	u32 errs = 0;
	u32 val, readback;
	int j;
	u32 offset;
	u32 test_offset;
	u32 pattern;
	u32 temp;
	u32 anti_pattern;
	u32 num_words;

	static const u32 bitpattern[] = {
		0x00000001,	/* single bit */
		0x00000003,	/* two adjacent bits */
		0x00000007,	/* three adjacent bits */
		0x0000000F,	/* four adjacent bits */
		0x00000005,	/* two non-adjacent bits */
		0x00000015,	/* three non-adjacent bits */
		0x00000055,	/* four non-adjacent bits */
		0xaaaaaaaa,	/* alternating 1/0 */
	};

	num_words = (end_addr - start_addr) / sizeof(u32);

	/*
	 * Data line test: write a pattern to the first
	 * location, write the 1's complement to a 'parking'
	 * address (changes the state of the data bus so a
	 * floating bus doesn't give a false OK), and then
	 * read the value back. Note that we read it back
	 * into a variable because the next time we read it,
	 * it might be right (been there, tough to explain to
	 * the quality guys why it prints a failure when the
	 * "is" and "should be" are obviously the same in the
	 * error message).
	 *
	 * Rather than exhaustively testing, we test some
	 * patterns by shifting '1' bits through a field of
	 * '0's and '0' bits through a field of '1's (i.e.
	 * pattern and ~pattern).
	 */

	mem_debug("Data line test\n");

	addr = buf;
	__SIM_STEP(0x1000);
	for (j = 0; j < sizeof(bitpattern) / sizeof(bitpattern[0]); j++) {
		val = bitpattern[j];
		for (; val != 0; val <<= 1) {
			*addr = val;
			*dummy  = ~val; /* clear the test data off the bus */
			readback = *addr;
			if (readback != val) {
				tdk_printf("FAILURE (data line): "
					"expected %08X, actual %08X\n",
						val, readback);
				errs++;
				if (ctrlc())
					return -1;
			}
			*addr  = ~val;
			*dummy  = val;
			readback = *addr;
			if (readback != ~val) {
				tdk_printf("FAILURE (data line): "
					"Is %08X, should be %08X\n",
						readback, ~val);
				errs++;
				if (ctrlc())
					return -1;
			}
		}
	}

	/*
	 * Based on code whose Original Author and Copyright
	 * information follows: Copyright (c) 1998 by Michael
	 * Barr. This software is placed into the public
	 * domain and may be used for any purpose. However,
	 * this notice must not be changed or removed and no
	 * warranty is either expressed or implied by its
	 * publication or distribution.
	 */
	/*
	* Address line test

	 * Description: Test the address bus wiring in a
	 *              memory region by performing a walking
	 *              1's test on the relevant bits of the
	 *              address and checking for aliasing.
	 *              This test will find single-bit
	 *              address failures such as stuck-high,
	 *              stuck-low, and shorted pins. The base
	 *              address and size of the region are
	 *              selected by the caller.

	 * Notes:	For best results, the selected base
	 *              address should have enough LSB 0's to
	 *              guarantee single address bit changes.
	 *              For example, to test a 64-Kbyte
	 *              region, select a base address on a
	 *              64-Kbyte boundary. Also, select the
	 *              region size as a power-of-two if at
	 *              all possible.
	 *
	 * Returns:     0 if the test succeeds, 1 if the test fails.
	 */
	pattern = (u32) 0xaaaaaaaa;
	anti_pattern = (u32) 0x55555555;

	mem_debug("%s:%d: length = 0x%08x\n", __FUNCTION__, __LINE__, num_words);



	/*
	 * Write the default pattern at each of the
	 * power-of-two offsets.
	 */
	mem_debug("Write the default pattern\n");
	__SIM_STEP(0x1100);
	for (offset = 1; offset < num_words; offset <<= 1)
		addr[offset] = pattern;

	/*
	 * Check for address bits stuck high.
	 */
	mem_debug("Check for address bits stuck high\n");
	test_offset = 0;
	__SIM_STEP(0x1200);
	addr[test_offset] = anti_pattern;

	for (offset = 1; offset < num_words; offset <<= 1) {
		temp = addr[offset];
		if (temp != pattern) {
			tdk_printf("FAILURE: Address bit stuck high @ 0x%08x:"
				" expected 0x%08x, actual 0x%08x, xor=0x%08x(%d)\n",
				start_addr+offset*4, pattern, temp, pattern^temp,pattern^temp);
			errs++;
			if (ctrlc())
				return -1;
		}
	}
	__SIM_STEP(0x1300);
	addr[test_offset] = pattern;
	WATCHDOG_RESET();

	mem_debug("Check for addr bits stuck low or shorted\n");
	/*
	 * Check for addr bits stuck low or shorted.
	 */
	__SIM_STEP(0x1400);
	for (test_offset = 1; test_offset < num_words; test_offset <<= 1) {
		addr[test_offset] = anti_pattern;

		for (offset = 1; offset < num_words; offset <<= 1) {
			temp = addr[offset];
			if ((temp != pattern) && (offset != test_offset)) {
				tdk_printf("FAILURE: Address bit stuck low or"
					" shorted @ 0x%08x: expected 0x%08x,"
					" actual 0x%08x, xor=0x%08x(%d)\n",
					start_addr+offset*4, pattern, temp, pattern^temp,pattern^temp);
				errs++;
				if (ctrlc())
					return -1;
			}
		}
		addr[test_offset] = pattern;
	}

	/*
	 * Description: Test the integrity of a physical
	 *		memory device by performing an
	 *		increment/decrement test over the
	 *		entire region. In the process every
	 *		storage bit in the device is tested
	 *		as a zero and a one. The base address
	 *		and the size of the region are
	 *		selected by the caller.
	 *
	 * Returns:     0 if the test succeeds, 1 if the test fails.
	 */
	num_words++;

	mem_debug("Fill memory with a known pattern\n");
	/*
	 * Fill memory with a known pattern.
	 */
	__SIM_STEP(0x1500);
	for (pattern = 1, offset = 0; offset < num_words; pattern++, offset+=1) {
		WATCHDOG_RESET();
		addr[offset] = pattern;
	}

	/*
	 * Check each location and invert it for the second pass.
	 */
	mem_debug("Check each location and invert it for the second pass\n");
	__SIM_STEP(0x1600);
	for (pattern = 1, offset = 0; offset < num_words; pattern++, offset+=1) {
		WATCHDOG_RESET();
		temp = addr[offset];
		if (temp != pattern) {
			tdk_printf("FAILURE (read/write)1: @ 0x%08x:"
				" expected 0x%08x, actual 0x%08x, xor=0x%08x(%d), next=0x%08x\n",
				start_addr+offset*4, pattern, temp, pattern^temp, pattern^temp, ~pattern);
			errs++;
			if (ctrlc())
				return -1;
		}

		anti_pattern = ~pattern;
		addr[offset] = anti_pattern;
	}

#if 1
	/*
	 * Check each location for the inverted pattern and zero it.
	 */
	mem_debug("Check each location for the inverted pattern and zero it\n");
	__SIM_STEP(0x1700);
	for (pattern = 1, offset = 0; offset < num_words; pattern++, offset+=1)
	{
		WATCHDOG_RESET();
		anti_pattern = ~pattern;
		temp = addr[offset];
		if (temp != anti_pattern) {
			tdk_printf("FAILURE (read/write)2: @ 0x%08x:"
				" expected 0x%08x, actual 0x%08x, xor=0x%08x(%d), pre=0x%08x\n",
				start_addr+offset*4, anti_pattern, temp, anti_pattern^temp, anti_pattern^temp, pattern);
			errs++;
			if (ctrlc())
				return -1;
		}
		addr[offset] = 0;
	}
#endif

	return errs;
}

int mem_test_quick(u32 *buf, u32 start_addr, u32 end_addr,
			    u32 pattern, int iteration)
{
	u32 *end;
	u32 *addr;
	u32 errs = 0;
	u32 incr, length;
	u32 val, readback;

	/* Alternate the pattern */
	incr = 1;
	if (iteration & 1) {
		incr = -incr;
		/*
		 * Flip the pattern each time to make lots of zeros and
		 * then, the next time, lots of ones.  We decrement
		 * the "negative" patterns and increment the "positive"
		 * patterns to preserve this feature.
		 */
		if (pattern & 0x80000000)
			pattern = -pattern;	/* complement & increment */
		else
			pattern = ~pattern;
	}
	length = (end_addr - start_addr) / sizeof(u32);
	end = buf + length;
	tdk_printf("\rPattern %08X  Writing..."
		"%12s"
		"\b\b\b\b\b\b\b\b\b\b",
		pattern, "");

	for (addr = buf, val = pattern; addr < end; addr++) {
		WATCHDOG_RESET();
		*addr = val;
		val += incr;
	}

	tdk_printf("Reading...");

	for (addr = buf, val = pattern; addr < end; addr++)
	{
		WATCHDOG_RESET();
		readback = *addr;
		if (readback != val) {
			u32 offset = addr - buf;

			tdk_printf("Mem error @ 0x%08X: "
				"found %08X, expected %08X\n",
				(u32)(u32 *)(start_addr+offset*4),
				readback, val);
			errs++;
			if (ctrlc())
				return -1;
		}
		val += incr;
	}

	return 0;
}

int test_mem_init(int argc, char *argv[])
{
	SYS_MemInit();
	return 0;
}

int test_mem_config(int argc, char *argv[])
{
	int integer = 150;	// 72.5MHz, integer=75, real=5
	int real = 0;
	int ret;

	float freq;

	u32 type = 1; // 0=DDR2, 1=LPDDR

	if(argv && argv[1]) type = tdk_string_to_value(argv[1]);
	if(argv && argv[2]) integer = tdk_string_to_value(argv[2]);
	if(argv && argv[3]) real = tdk_string_to_value(argv[3]);
	freq = integer+real*0.1f;

	tdk_printf("%s Frequency = %f\n", ddr_get_type_string(type), freq);
	ret = ddr_config(type, freq);
	ret = ddr_init();
	tdk_printf("DDR Init : %s\n", ansi_get_status_string(ret==0));
	ddr_dump();

	return 0;
}

int test_mem(int argc, char *argv[])
{
	u32 dummy;
	u32 *buf;
	u32 start_addr;
	u32 end_addr;

	u32 step = 0x100000;
	int ret;
	int i;
//	int j;
	int sum=0x0;
	int loop=1;

	if(argv && argv[1]) error_on_stop = tdk_string_to_value(argv[1]);


	tdk_printf("===========================\n");
	tdk_printf("Memory Test\n");
	tdk_printf("===========================\n");

	SYS_MemInit();

	error_count = 0;

	while(loop)
	{
		for(i=0; i<APACHE_DRAM_SIZE/step; i++)
		{
			start_addr = APACHE_DRAM_BASE+step*i;
			__SIM_STEP(start_addr);
			end_addr = start_addr+step-1;
			buf = (u32*)start_addr;
	//		tdk_printf("BUF=0x%08x,START=0x%08x,END=0x%08x\n", buf, start_addr, end_addr);
	//		mem_test_quick(buf, start_addr, end_addr, 0);
			ret = mem_test_alt(buf, start_addr, end_addr, &dummy);
	//		ret = test_memory_range(start_addr, step);
			sum += ret;
			if(sum && error_on_stop) break;
			if(tdk_getch()>=0)
			{
				loop = 0;
				break;
			}
		}
		tdk_printf("Result=%s(ERR=%d)\n", ansi_get_status_string(sum==0), sum);
		if(error_on_stop) break;
	}

	tdk_printf("Result=%s(ERR=%d)\n", ansi_get_status_string(sum==0), sum);

	return 0;
}

int test_sram(int argc, char *argv[])
{
	u32 dummy;
	u32 *buf;
	u32 start_addr;
	u32 end_addr;
	u32 step = 4096;
	int ret;
	int i;
	int sum=0x0;

	if(argv && argv[1]) error_on_stop = tdk_string_to_value(argv[1]);

	for(i=0; i<512*1024/step; i++)
	{
		start_addr = APACHE_BOOT_RAM+step*i;
		end_addr = start_addr+step-1;
		buf = (u32*)start_addr;
//		tdk_printf("BUF=0x%08x,START=0x%08x,END=0x%08x\n", buf, start_addr, end_addr);
		ret = mem_test_alt(buf, start_addr, end_addr, &dummy);
//		tdk_printf("test result=%s(ERR=%d)\n", ansi_get_status_string(ret==0), ret);
		sum += ret;
		if(sum && error_on_stop) break;
	}

	tdk_printf("Result=%s(ERR=%d)\n", ansi_get_status_string(sum==0), sum);

	return 0;
}

//#define PRINT_SEGMENT    (16*MB/4)
#define PRINT_SEGMENT    (1*MB/4)

int test_mem_fill(int argc, char *argv[])
{
	int i;
	u32 addr = APACHE_DRAM_BASE;
	u32 size = APACHE_DRAM_SIZE;
	u32 pattern = 0xAAAAAAAA;

	if(argv && argv[1]) addr    = tdk_string_to_value(argv[1]);
	if(argv && argv[2]) size    = tdk_string_to_value(argv[2]);
	if(argv && argv[3]) pattern = tdk_string_to_value(argv[3]);

	tdk_printf("==========================================\n");
	tdk_printf("addr    = 0x%08x\n", addr);
	tdk_printf("size    = 0x%08x(%d MB)\n", size, size/MB);
	tdk_printf("pattern = 0x%08x\n", pattern);

	for(i=0; i<size/4; i++)
	{
//		tdk_printf("%d\n", (i+1)%PRINT_SEGMENT);
		if(((i+1)%PRINT_SEGMENT)==0) tdk_printf(".");
		reg_write(addr+i*4, pattern);
	}
	tdk_printf("\n");
	tdk_printf("test word count=%d\n", size/4);
	tdk_printf("finish !!!!\n");

	return 0;
}

int test_mem_check(int argc, char *argv[])
{
	int i;
	u32 addr = APACHE_DRAM_BASE;
	u32 size = APACHE_DRAM_SIZE;
	u32 pattern = 0xAAAAAAAA;
	u32 data;
	u32 err=0;

	if(argv && argv[1]) addr    = tdk_string_to_value(argv[1]);
	if(argv && argv[2]) size    = tdk_string_to_value(argv[2]);
	if(argv && argv[3]) pattern = tdk_string_to_value(argv[3]);

	tdk_printf("==========================================\n");
	tdk_printf("addr    = 0x%08x\n", addr);
	tdk_printf("size    = 0x%08x(%d MB)\n", size, size/MB);
	tdk_printf("pattern = 0x%08x\n", pattern);

	for(i=0; i<size/4; i++)
	{
		if(((i+1)%PRINT_SEGMENT)==0) tdk_printf(".");
		data = reg_read(addr+i*4);
		if(data != pattern)
		{
			err++;
			tdk_printf("\nERROR addr=0x%08x, read=0x%08x, pattern=0x%08x\n", addr+i*4, data, pattern);
		}
	}
	tdk_printf("\n");
	tdk_printf("test word count=%d, err=%d\n", size/4, err);
	tdk_printf("finish !!!!\n");

	return 0;
}

