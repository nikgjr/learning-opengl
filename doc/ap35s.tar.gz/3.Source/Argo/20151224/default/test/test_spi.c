/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "func_register.h"
#include "../tdk/tdk.h"
#include "../tdk/tdk_util.h"
#include "../system/system.h"

#include "../include/ansi.h"

#include "../drivers/sflash.h"
#include "../drivers/spi_pl022.h"
#include "../drivers/gicdrv.h"
#include "../drivers/dma_pl330.h"

#include "test.h"

int test_spi_reg(int argc, char *argv[])
{
	u8 pl022_id[4] = { 0x0d, 0xf0, 0x05, 0x51 };
	u8 id[4];

	id[0] = spi_reg_read(SPI0, SSP_PCELL_ID0);
	id[1] = spi_reg_read(SPI0, SSP_PCELL_ID1);
	id[2] = spi_reg_read(SPI0, SSP_PCELL_ID2);
	id[3] = spi_reg_read(SPI0, SSP_PCELL_ID3);

	if(memcmp(pl022_id, id, 4)) return -1;

	return 0;
}

int spi_model_test(void)
{
	int i;
	int ret = 0;
	int init=0x4000;
	int test_size=16;

	u8 tx_buffer[1024];
	u8 rx_buffer[1024];

	SYS_SimInfo(init+0x00, "SPI");
	for(i=0; i<256; i++)
	{
		tx_buffer[i] = (i+1);
		rx_buffer[i] = 0;
	}

	SYS_SimInfo(init+0x10, "SPI Write");

	ret = memcmp(tx_buffer, rx_buffer, test_size);
	if(ret)
	{
		for(i=0; i<test_size/4; i++)
		{
			__SIM_DEBUG_REG(SIM_DEBUG_WDATA, tx_buffer[i]);
			__SIM_DEBUG_REG(SIM_DEBUG_RDATA,  rx_buffer[i]);
		}
		return -1;
	}

	SYS_SimInfo(init+0xff, "SPI Write");
	return ret;
}

int test_spi_model(int argc, char *argv[])
{
	u32 status;
	u32 data;

	int i;
	int ret;
	u8 tx_buffer[1024];
	u8 rx_buffer[1024];
	int test_size = 4;
	int recv_count = 0;

	int SPH=1;
	int SPO=0;
	int ch;
	u32 spi;

	int init=0x4100;

	SYS_SimInfo(init+0x00, "SPI");

	for(i=0; i<256; i++)
	{
		tx_buffer[i] = (i+1);
		rx_buffer[i] = 0;
	}

	for(ch=0; ch<2; ch++)
	{
		switch(ch)
		{
		case 0: spi = SPI0; break;
		case 1: spi = SPI1; break;
		default: spi = NULL;
		}

		if(spi == NULL)
		{
			tdk_printf("invalide spi pointer\n");
			return -1;
		}

		tdk_printf("==========================================\n");
		tdk_printf("SPI Channel %d\n", ch);
		tdk_printf("==========================================\n");

		SYS_SimInfo(init+0x10, "Setup");
		spi_reg_write(spi, SSP_CR0, (3<<8) | (SPH<<7) | (SPO<<6) | (0<<4) | 0x7 );
		spi_reg_write(spi, SSP_CR1, (0<<3) | (0<<2) | (1<<1) | 0x0);

		spi_reg_write(spi, SSP_CPSR, 2);

		spi_reg_write(spi, SSP_IMSC, 0xf);
		spi_reg_write(spi, SSP_RIS, 0xf);
		// DMA Request Enable
		spi_reg_write(spi, SSP_DMACR, (1<<1)|(1<<0));

		SYS_SimInfo(init+0x20, "Write");
		for(i=0; i<test_size; i++)
		{
			spi_reg_write(SPI0, SSP_DR, tx_buffer[i]);
		}

		// 32 bit loop-back model
		SYS_SimInfo(init+0x30, "Write Dummy");
		spi_reg_write(spi, SSP_DR, 0x0);
		spi_reg_write(spi, SSP_DR, 0x0);
		spi_reg_write(spi, SSP_DR, 0x0);
		spi_reg_write(spi, SSP_DR, 0x0);

		SYS_SimInfo(init+0x40, "Wait");
		while(1)
		{
			status = spi_reg_read(spi, SSP_SR);
			if(!SPI_IS_BUSY(status)) break;
		}

		SYS_SimInfo(init+0x50, "Read");
		while(1)
		{
			status = spi_wait_status(spi, SSP_SR, SSP_STATUS_RX_FIFO_READY, 10);
			if(status == 0xffffffff)
				break;
			data = spi_reg_read(spi, SSP_DR);
			rx_buffer[recv_count] = data;
			recv_count++;
		}

		SYS_SimInfo(init+0x60, "Verify");
		ret = memcmp(tx_buffer, rx_buffer+4, test_size);
		if(ret)
		{
			for(i=0; i<test_size; i++)
			{
				__SIM_DEBUG_REG(SIM_DEBUG_WDATA, tx_buffer[i]);
				__SIM_DEBUG_REG(SIM_DEBUG_RDATA, rx_buffer[i+4]);
			}
			tdk_printf("SPI Verify : %s\n", ANSI_FAIL);
			return -1;
		}
	}

	tdk_printf("SPI Verify : %s\n", ANSI_PASS);
	return 0;
}

int test_spi(int argc, char *argv[])
{
	u32 status;
	u32 data;

	int i;
	int ret;
	u8 tx_buffer[1024];
	u8 rx_buffer[1024];
	int test_size = 4;
	int recv_count = 0;

	int SPH=1;
	int SPO=0;

	int init=0x4200;

	u32 spi = SPI0;

	SYS_SimInfo(init+0x00, "SPI");

	for(i=0; i<256; i++)
	{
		tx_buffer[i] = (i+1);
		rx_buffer[i] = 0;
	}

	SYS_SimInfo(init+0x10, "Setup");
	spi_reg_write(spi, SSP_CR0, (3<<8) | (SPH<<7) | (SPO<<6) | (0<<4) | 0x7 );
	spi_reg_write(spi, SSP_CR1, (0<<3) | (0<<2) | (1<<1) | 0x0);

	spi_reg_write(spi, SSP_CPSR, 2);

	spi_reg_write(spi, SSP_IMSC, 0xf);
	spi_reg_write(spi, SSP_RIS, 0xf);
	// DMA Request Enable
	spi_reg_write(spi, SSP_DMACR, (1<<1)|(1<<0));

	SYS_SimInfo(init+0x20, "Write");
	for(i=0; i<test_size; i++)
	{
		spi_reg_write(spi, SSP_DR, tx_buffer[i]);
	}

	SYS_SimInfo(init+0x40, "Wait");
	while(1)
	{
		status = spi_reg_read(spi, SSP_SR);
		if(!SPI_IS_BUSY(status)) break;
	}

	SYS_SimInfo(init+0x50, "Read");
	while(1)
	{
		status = spi_wait_status(spi, SSP_SR, SSP_STATUS_RX_FIFO_READY, 10);
		if(status == 0xffffffff)
			break;
		data = spi_reg_read(spi, SSP_DR);
		rx_buffer[recv_count] = data;
		recv_count++;
	}

	SYS_SimInfo(init+0x60, "Verify");
	ret = memcmp(tx_buffer, rx_buffer, test_size);
	if(ret)
	{
		for(i=0; i<test_size; i++)
		{
			__SIM_DEBUG_REG(SIM_DEBUG_WDATA, tx_buffer[i]);
			__SIM_DEBUG_REG(SIM_DEBUG_RDATA,  rx_buffer[i]);
		}
		tdk_printf("SPI Verify : %s\n", ANSI_FAIL);
		return -1;
	}


//	if(status == 0xffffffff) __SIM_END_FAIL();
	tdk_printf("SPI Verify : %s\n", ANSI_PASS);

	return 0;
}


struct spi_irq_data
{
	u32 spi_addr;
	u8 *tx_buffer;
	u8 *rx_buffer;
	u32 tx_cnt;
	u32 rx_cnt;
	u32 rt_cnt;
};

u32 spi_irq = 0;

void spi_tx_irq_handler(void)
{
}

void spi_rx_irq_handler(void *param)
{
	u32 status;
	struct spi_irq_data *pdata = param;
	u32 data;

	spi_irq++;
	status = spi_reg_read(pdata->spi_addr, SSP_RIS);
//	__SIM_DEBUG_REG(SIM_DEBUG_IRQ, status);

	if(status&SSP_RX_INTR)
	{
		while(spi_reg_read(pdata->spi_addr, SSP_SR) & SSP_STATUS_RX_FIFO_READY)
		{
			data = spi_reg_read(pdata->spi_addr, SSP_DR);
			pdata->rx_buffer[pdata->rx_cnt] = data;
			pdata->rx_cnt++;
		}
	}
	if(status & SSP_RT_INTR)
	{
		spi_reg_write(pdata->spi_addr, SSP_ICR, SSP_RT_INTR);
		pdata->rt_cnt++;
	}
}

void spi_dma_irq_handler(void *param)
{
#if 1
	int irq = (int) param;

//	tdk_printf("dma_irq_handler:irq=%d\n", irq);

	switch (irq)
	{
	case GIC_DMA_ABORT:
		break;
	case GIC_DMA_CHANNEL0:
		M_DMA_CLR_INT(0);
		break;
	case GIC_DMA_CHANNEL1:
		M_DMA_CLR_INT(1);
		break;
	case GIC_DMA_CHANNEL2:
		M_DMA_CLR_INT(2);
		break;
	case GIC_DMA_CHANNEL3:
		M_DMA_CLR_INT(3);
		break;
	}
#endif
}

void spi_dma_init(void)
{
#if 1
    GIC_RegisterHandler(GIC_DMA_ABORT, spi_dma_irq_handler, (void*)GIC_DMA_ABORT);
    GIC_EnableIrq(GIC_DMA_ABORT);

    GIC_RegisterHandler(GIC_DMA_CHANNEL0, spi_dma_irq_handler, (void*)GIC_DMA_CHANNEL0);
    GIC_EnableIrq(GIC_DMA_CHANNEL0);

    GIC_RegisterHandler(GIC_DMA_CHANNEL1, spi_dma_irq_handler, (void*)GIC_DMA_CHANNEL1);
    GIC_EnableIrq(GIC_DMA_CHANNEL1);

    GIC_RegisterHandler(GIC_DMA_CHANNEL2, spi_dma_irq_handler, (void*)GIC_DMA_CHANNEL2);
    GIC_EnableIrq(GIC_DMA_CHANNEL2);

    GIC_RegisterHandler(GIC_DMA_CHANNEL3, spi_dma_irq_handler, (void*)GIC_DMA_CHANNEL3);
    GIC_EnableIrq(GIC_DMA_CHANNEL3);

    DMA_Init();
#endif
}

int test_spi_dma(int argc, char *argv[])
{
#if 1
	u32 status;
	u32 data;
	u32 spi = SPI0;

	int i;
	int ret;
	struct spi_irq_data spi_data;

    u8 *tx_buffer = (u8 *)(SYS_GetNoneCacheAddress()+0x8000);
    u8 *rx_buffer = (u8 *)(SYS_GetNoneCacheAddress()+0xa000);

	int test_size = 64;

	int SPH=1;
	int SPO=0;

	int init=0x4300;

	u32 tx_dma_enable = 1;
	u32 rx_dma_enable = 1;

	SYS_SimInfo(init+0x00, "SPI");

	// Configuration Peripheral DMA
//	rSYSCON_DMA_CONFIG = 0xf;

	spi_data.spi_addr = spi;
	spi_data.tx_buffer = tx_buffer;
	spi_data.tx_cnt = 0;
	spi_data.rx_buffer = rx_buffer;
	spi_data.rx_cnt = 0;

    GIC_ClearAllRaisedIrq();

    // if RX DMA Enable, disable spi_irq_handler
    if(!rx_dma_enable)
    {
    	GIC_RegisterHandler(GIC_SPI0, spi_rx_irq_handler, (void*)&spi_data);
    	GIC_EnableIrq(GIC_SPI0);
    }

	for(i=0; i<256; i++)
	{
		tx_buffer[i] = (i+1);
		rx_buffer[i] = 0;
	}

	spi_dma_init();

	SYS_SimInfo(init+0x10, "Setup");
	spi_reg_write(spi, SSP_CR0, (3<<8) | (SPH<<7) | (SPO<<6) | (0<<4) | 0x7 );
	spi_reg_write(spi, SSP_CR1, (0<<3) | (0<<2) | (1<<1) | 0x0);

	spi_reg_write(spi, SSP_CPSR, 2);

//	spi_reg_write(spi, SSP_IMSC, 0xf);
	// Mask TX FIFO Interrupt
	spi_reg_write(spi, SSP_IMSC, 0x7);
	spi_reg_write(spi, SSP_RIS, 0xf);
	// DMA Request Enable
	spi_reg_write(spi, SSP_DMACR, (1<<1)|(1<<0));

	SYS_SimInfo(init+0x11, "Setup");
	if(rx_dma_enable)
	{
		u32 mcode_base = SYS_GetNoneCacheAddress() + 0x1000;
		u32 mcode_size = 0;
		tDMA_CH ch = DC_CH1;
		tDMA_INFO info;
		u32 addr_spi_data = (u32) (spi+SSP_DR);

		__SIM_DEBUG_REG(SIM_DEBUG_RESPONSE, mcode_base);

		info.burstSize = BS_1B;
		info.burstLen = BL_1XFER;
		info.dmaCh = (tDMA_CH) ch;
		info.reqType = RT_DEV_TO_MEM;
		info.srcAddr = addr_spi_data;
		info.dstAddr = SYS_Virtual2Physical((u32) rx_buffer);
		info.xferBytes = test_size;
		info.periNum = DPN_UART1_SPI1_RX; // don't care for mem to mem
		info.microCodeBase = mcode_base + mcode_size;
		info.microCodePhysical = SYS_Virtual2Physical(info.microCodeBase);
		mcode_size += DMA_Req(&info);
		mcode_size = ((mcode_size + 3) / 4) * 4;

		DMA_Ctrl(DO_START, (tDMA_CH) ch);
	}

	SYS_SimInfo(init+0x20, "Write");
	if(tx_dma_enable)
	{
		u32 mcode_base = SYS_GetNoneCacheAddress() + 0x0000;
		u32 mcode_size = 0;
		tDMA_CH ch = DC_CH0;
		tDMA_INFO info;
		u32 addr_spi_data = (u32) (spi+SSP_DR);

		__SIM_DEBUG_REG(SIM_DEBUG_RESPONSE, mcode_base);

		info.burstSize = BS_1B;
		info.burstLen = BL_1XFER;
		info.dmaCh = (tDMA_CH) ch;
		info.reqType = RT_MEM_TO_DEV;
		info.srcAddr = SYS_Virtual2Physical((u32)tx_buffer);
		info.dstAddr = addr_spi_data;
		info.xferBytes = test_size;
		info.periNum = DPN_UART1_SPI1_TX; // don't care for mem to mem
		info.microCodeBase = mcode_base + mcode_size;
		info.microCodePhysical = SYS_Virtual2Physical(info.microCodeBase);
		mcode_size += DMA_Req(&info);
		mcode_size = ((mcode_size + 3) / 4) * 4;

		DMA_Ctrl(DO_START, (tDMA_CH) ch);
	}
	else
	{
		for(i=0; i<test_size; i++)
		{
			status = spi_wait_status(spi, SSP_SR, SSP_STATUS_TX_FIFO_READY, 10);
			if(status == 0xffffffff) continue;
			spi_reg_write(spi, SSP_DR, tx_buffer[i]);
		}

		// 32 bit loop-back model
		SYS_SimInfo(init+0x30, "Write");
		spi_reg_write(spi, SSP_DR, 0x0);
		spi_reg_write(spi, SSP_DR, 0x0);
		spi_reg_write(spi, SSP_DR, 0x0);
		spi_reg_write(spi, SSP_DR, 0x0);

		SYS_SimInfo(init+0x40, "Wait");
		while(1)
		{
			status = spi_reg_read(spi, SSP_SR);
			if(!SPI_IS_BUSY(status)) break;
		}
	}

	SYS_SimInfo(init+0x50, "Read");
	if(rx_dma_enable)
	{
		SYS_SimInfo(init+0x51, "Wait RX DMA Complete...");
		while (1)
		{
			if (GIC_CheckRaisedIrq(GIC_DMA_CHANNEL0 + DC_CH1))
				break;

			if (GIC_CheckRaisedIrq(GIC_DMA_ABORT))
				break;
		}
	}
	else
	{
		while(1)
		{
			if(spi_data.rx_cnt >= test_size)
				break;
		}
	}

	if(tx_dma_enable)
	{
		SYS_SimInfo(init+0x41, "Wait TX DMA Complete...");
		while (1)
		{
			if (GIC_CheckRaisedIrq(GIC_DMA_CHANNEL0 + DC_CH0))
				break;

			if (GIC_CheckRaisedIrq(GIC_DMA_ABORT))
				break;
		}
	}


	SYS_SimInfo(init+0x60, "Verify");
	ret = memcmp(tx_buffer, rx_buffer, test_size);
	if(ret)
	{
		for(i=0; i<test_size; i++)
		{
			__SIM_DEBUG_REG(SIM_DEBUG_WDATA, tx_buffer[i]);
			__SIM_DEBUG_REG(SIM_DEBUG_RDATA,  rx_buffer[i]);
			tdk_printf("[%3d], %x, %x\n", tx_buffer[i], rx_buffer[i]);
		}
		tdk_printf("SPI Verify : %s\n", ANSI_FAIL);
		return -1;
	}

	tdk_printf("SPI Verify : %s\n", ANSI_PASS);

//	if(status == 0xffffffff) __SIM_END_FAIL();
#endif

	return 0;
}

int test_spi_FM25M04(int argc, char *argv[])
{
	u32 status;
	u32 data;

	int i;
	int ret;

	int init=0x4000;

	SYS_SimInfo(init+0x00, "SPI");
#if 0
	for(i=0; i<256; i++)
	{
		tx_buffer[i] = (i+1);
		rx_buffer[i] = 0;
	}
#endif

	SYS_SimInfo(init+0x10, "Setup");
	spi_init(SPI0);

	SYS_SimInfo(init+0x11, "ID");
	spi_write(SPI0, 0x90);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);

	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);


	for(i=0; i<6; i++)
	{
		data=spi_read(SPI0);	__SIM_RESP(data);
		tdk_printf("[%d] 0x%02x\n", i, data);
	}

	return 0;

	SYS_SimInfo(init+0x20, "ERASE");

	spi_write(SPI0, 0x06);
	data=spi_read(SPI0);	__SIM_RESP(data);

	spi_write(SPI0, 0x20);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);

	while(1)
	{
		spi_write(SPI0, 0x05);
		spi_write(SPI0, 0xff);
		data=spi_read(SPI0);	__SIM_RESP(data);
		data=spi_read(SPI0);	__SIM_RESP(data);
		if((data&0x1)==0) break;
	}

	SYS_SimInfo(init+0x40, "READ");

	spi_write(SPI0, 0x03);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);

	for(i=0; i<4; i++)
	{
		spi_write(SPI0, 0xff);
	}
	for(i=0; i<4+4; i++)
	{
		data=spi_read(SPI0);	__SIM_RESP(data);
	}


	SYS_SimInfo(init+0x30, "WRITE");
	spi_write(SPI0, 0x06);
	data=spi_read(SPI0);	__SIM_RESP(data);

	spi_write(SPI0, 0x02);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);

	for(i=0; i<4; i++)
	{
		spi_write(SPI0, i+1);
	}
	for(i=0; i<4+4; i++)
	{
		data=spi_read(SPI0);	__SIM_RESP(data);
	}

	while(1)
	{
		spi_write(SPI0, 0x05);
		spi_write(SPI0, 0xff);
		data=spi_read(SPI0);	__SIM_RESP(data);
		data=spi_read(SPI0);	__SIM_RESP(data);
		if((data&0x1)==0) break;
	}

	SYS_SimInfo(init+0x40, "READ");

	spi_write(SPI0, 0x03);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);

	for(i=0; i<4; i++)
	{
		spi_write(SPI0, 0xff);
	}
	for(i=0; i<4+4; i++)
	{
		data=spi_read(SPI0);	__SIM_RESP(data);
	}


	// Drivers
	SYS_SimInfo(init+0x120, "ERASE");
	ret = sflash_sector_erase(0x1000);
	if(ret)	return -1;

	SYS_SimInfo(init+0x140, "READ");
	ret = sflash_single_read(0x1000, &data);
	__SIM_RESP(data);
	if(ret) return -1;

	SYS_SimInfo(init+0x130, "WRITE");
	for(i=0; i<16; i++)
	{
		ret = sflash_single_write(0x1000+i*4, i+1);
		if(ret) return -1;
	}

	if(ret) return -1;
	SYS_SimInfo(init+0x140, "READ");
	for(i=0; i<16; i++)
	{
		ret = sflash_single_read(0x1000+i*4, &data);
		__SIM_RESP(data);
		if(ret) return -1;
		if(data != i+1) return -1;
	}

	return 0;
}

int test_spi_FM25M32A(int argc, char *argv[])
{
	u32 status;
	u32 data;

	int i;
	int ret;

	int init=0x4000;

	SYS_SimInfo(init+0x00, "SPI");
#if 0
	for(i=0; i<256; i++)
	{
		tx_buffer[i] = (i+1);
		rx_buffer[i] = 0;
	}
#endif

	SYS_SimInfo(init+0x10, "Setup");
	spi_init(SPI0);

	sflash_init();
	sflash_reset();

	SYS_SimInfo(init+0x11, "ID");
	spi_write(SPI0, 0x90);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);

	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);


	for(i=0; i<6; i++)
	{
		data=spi_read(SPI0);	__SIM_RESP(data);
		tdk_printf("[%d] 0x%02x\n", i, data);
	}


	SYS_SimInfo(init+0x20, "ERASE");
	spi_write(SPI0, 0x06);
	data=spi_read(SPI0);	__SIM_RESP(data);

	spi_write(SPI0, 0x20);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);
	data=spi_read(SPI0);	__SIM_RESP(data);

	while(1)
	{
		spi_write(SPI0, 0x05);
		spi_write(SPI0, 0xff);
		data=spi_read(SPI0);	__SIM_RESP(data);
		data=spi_read(SPI0);	__SIM_RESP(data);
		if((data&0x1)==0) break;
	}

	SYS_SimInfo(init+0x40, "READ");

	spi_write(SPI0, 0x03);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);

	for(i=0; i<4; i++)
	{
		spi_write(SPI0, 0xff);
	}
	for(i=0; i<4+4; i++)
	{
		data=spi_read(SPI0);	__SIM_RESP(data);
	}


	SYS_SimInfo(init+0x30, "WRITE");
	spi_write(SPI0, 0x06);
	data=spi_read(SPI0);	__SIM_RESP(data);

	spi_write(SPI0, 0x02);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);

	for(i=0; i<4; i++)
	{
		spi_write(SPI0, i+1);
	}
	for(i=0; i<4+4; i++)
	{
		data=spi_read(SPI0);	__SIM_RESP(data);
	}

	while(1)
	{
		spi_write(SPI0, 0x05);
		spi_write(SPI0, 0xff);
		data=spi_read(SPI0);	__SIM_RESP(data);
		data=spi_read(SPI0);	__SIM_RESP(data);
		if((data&0x1)==0) break;
	}

	SYS_SimInfo(init+0x40, "READ");

	spi_write(SPI0, 0x03);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);
	spi_write(SPI0, 0x00);

	for(i=0; i<4; i++)
	{
		spi_write(SPI0, 0xff);
	}
	for(i=0; i<4+4; i++)
	{
		data=spi_read(SPI0);	__SIM_RESP(data);
	}


	// Drivers
	SYS_SimInfo(init+0x120, "ERASE");
	ret = sflash_sector_erase(0x1000);
	if(ret)	return -1;

	SYS_SimInfo(init+0x140, "READ");
	ret = sflash_single_read(0x1000, &data);
	__SIM_RESP(data);
	if(ret) return -1;

	SYS_SimInfo(init+0x130, "WRITE");
	for(i=0; i<16; i++)
	{
		ret = sflash_single_write(0x1000+i*4, i+1);
		if(ret) return -1;
	}

	if(ret) return -1;
	SYS_SimInfo(init+0x140, "READ");
	for(i=0; i<16; i++)
	{
		ret = sflash_single_read(0x1000+i*4, &data);
		__SIM_RESP(data);
		if(ret) return -1;
		if(data != i+1) return -1;
	}

	tdk_printf("Flash Test : %s\n", ANSI_PASS);

	return 0;
}

int test_sflash_write(int argc, char *argv[])
{
	int ret;
	u32 addr = 0x0;
	u32 data = 0x12345678;

	if(argv && argv[1]) addr = tdk_string_to_value(argv[1]);
	if(argv && argv[2]) data = tdk_string_to_value(argv[2]);

	ret = sflash_single_write(addr, data);
	tdk_printf("programming : %s\n", ansi_get_status_string(ret==0));

	return 0;
}


int test_sflash_program(int argc, char *argv[])
{
	int ret;
	u32 saddr;
	u32 addr;
	u32 size;

	if(argc<4)
	{
		tdk_printf("invalide command\n");
		tdk_printf("usage : e.write flash_addr src_addr size\n");
		return -1;
	}

	saddr  = tdk_string_to_value(argv[1]);
	addr   = tdk_string_to_value(argv[2]);
	size   = tdk_string_to_value(argv[3]);

	tdk_printf("programming ...\n");
	ret = sflash_buffer_write(saddr, (u32*)addr, size);
	tdk_printf("programming : %s\n", ansi_get_status_string(ret==0));
	if(ret)	return ret;

	return 0;
}



int test_sflash_erase(int argc, char *argv[])
{
	u32 addr=-1;
	u32 size=64*KB;
	s16 ret;

	if(argv && argv[1]) addr = tdk_string_to_value(argv[1]);
	if(argv && argv[2]) size = tdk_string_to_value(argv[2]);

	tdk_printf("==========================================\n");
	tdk_printf("FLASH Erase : addr=0x%08x, size=0x%08x(%dKB)\n", addr, size, size/KB);
	tdk_printf("==========================================\n");

	sflash_init();

	if(addr == -1)
	{
		ret = sflash_chip_erase();
	}
	else
	{
		int i;
		for(i=0; i<size/(64*KB); i++)
		{
			ret = sflash_block_erase(addr+i*64*KB);
			tdk_printf("Erase 0x%08x : %s\n", addr+i*64*KB, ansi_get_status_string(ret==0));
		}
	}

	tdk_printf("ERASE:%s\n", ansi_get_status_string(ret==0));
	return ret;
}

int test_sflash_dump(int argc, char *argv[])
{
	int size = 64;
	int sector;
	int i;
	int j;
	u32 addr = 0x0;
	u32 block_base;
	u32 data;

	if(argv && argv[1]) addr = tdk_string_to_value(argv[1]);
	if(argv && argv[2]) size = tdk_string_to_value(argv[2]);

	sflash_init();

	tdk_printf("==========================================\n");
	tdk_printf("FLASH Dump\n");
	tdk_printf("==========================================\n");

	if(argc==1)
	{
		size = 1*MB;
		sector = size/(64*KB);

		for(i=0; i<sector; i++)
		{
			block_base = addr+64*KB*i;
			tdk_printf("[%3d] sec_base=0x%08x:", i, block_base);
			for(j=0; j<4; j++)
			{
				sflash_single_read(block_base+j*4, &data);
				tdk_printf("0x%08x ", data);
			}
			tdk_printf("\n");
		}
	}
	else
	{
		tdk_printf("Address = 0x%08x\n", addr);
		for(i=0; i<size/4; i++)
		{
			sflash_single_read(addr+i*4, &data);
			tdk_printf("0x%08x ", data);
			if((i+1)%4==0) tdk_printf("\n");
		}

		if(i%4 != 0) tdk_printf("\n");
	}
	return 0;
}

int test_sflash_test(int argc, char *argv[])
{
	int size = 2*MB;
	int block = size/(64*KB);
	int i;
	int j;
	u32 addr = 0x0;
	u32 block_base;
	u32 data;
	s16 ret;

	tdk_printf("==========================================\n");
	tdk_printf("FLASH TEST\n");
	tdk_printf("==========================================\n");

	sflash_init();

	for(i=0; i<block; i++)
	{
		block_base = addr+64*KB*i;
		ret = sflash_single_write(block_base, block_base|i);
		ret = sflash_single_write(block_base+0x4, block_base|0x10);
		ret = sflash_single_write(block_base+0x8, block_base|0x20);
		ret = sflash_single_write(block_base+0xC, block_base|0x30);
		tdk_printf("[%3d] sec_base=0x%08x:addr=0x%08x, data=%d, ret=%d\n", i, block_base, block_base, i, ret);
	}


	for(i=0; i<block; i++)
	{
		block_base = addr+64*KB*i;
		tdk_printf("[%3d] sec_base=0x%08x:", i, block_base);

		for(j=0; j<4; j++)
		{
			sflash_single_read(block_base+j*4, &data);
			tdk_printf("0x%08x ", data);
		}
		tdk_printf("\n");
	}

	return 0;
}

