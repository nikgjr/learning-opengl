#ifndef __TEST_MEMORY__
#define __TEST_MEMORY__

int test_mem_init(int argc, char *argv[]);
int test_mem_config(int argc, char *argv[]);
int test_mem(int argc, char *argv[]);
int test_sram(int argc, char *argv[]);
int test_mem_fill(int argc, char *argv[]);
int test_mem_check(int argc, char *argv[]);

#endif
