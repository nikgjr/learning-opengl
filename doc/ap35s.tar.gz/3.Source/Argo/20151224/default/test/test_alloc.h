/******************************************************************************
 *                                                                            *
 * Copyright (c) 2009-2012 by ARGO Co., Ltd. All rights reserved.             *
 *                                                                            *
 ******************************************************************************/

#ifndef __TEST_ALLOC__
#define __TEST_ALLOC__

int test_alloc(int argc, char *argv[]);

#endif
