#include <stdio.h>

#include "../tdk/tdk.h"
#include "../tdk/tdk_types.h"
#include "../tdk/tdk_util.h"

#include "../tdk/tdk_zmodem.h"

int func_go(int argc, char *argv[])
{
	u32 addr=(u32)-1;

	if(argv && argv[1])	addr=tdk_string_to_value(argv[1]);

	if(addr == 0xffffffff)
	{
		tdk_printf("invaide address = 0x%08x\n");
	}

	tdk_printf("jump 0x%08x\n", addr);
    ((void(*)(void))(addr))(); // jump to address
	return 0;
}

int func_rz(int argc, char *argv[])
{
	u32 addr=(u32)0x60000000;
	u32 size;

	size = get_Zmodem((u8*)addr);
	if(size)
	{
		tdk_printf("success to download %d bytes\n", size);
	}
	else
	{
		tdk_printf("fail to download\n");
	}

	return 0;
}

int func_reset(int argc, char *argv[])
{
	return 0;
}
