
#ifndef __TEST_DMA__
#define __TEST_DMA__

int test_dma(int argc, char *argv[]);
int test_dma_info(int argc, char *argv[]);

#endif
