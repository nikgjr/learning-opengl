#include <stdio.h>
#include <string.h>

#include "../system/system.h"
#include "../drivers/uart_pl011.h"
#include "../tdk/tdk_util.h"
#include "../tdk/tdk.h"

#include "test.h"

#include "../drivers/gicdrv.h"
#include "../include/ansi.h"

#define TEST_UART		UART1

#define UART_BUFFER_SIZE	16

unsigned int uart_tx_irq;
unsigned int uart_rx_irq;
volatile int uart_exit_flag = 0;

u8 uart_tx_buffer[UART_BUFFER_SIZE];
u8 uart_rx_buffer[UART_BUFFER_SIZE];

/****************************************************************************
NAME
INPUT
RETURNS
DESCRIPTION
*****************************************************************************/
void uart_tx_irq_handler(void)
{
}


void uart_rx_irq_handler(void *param)
{
	tREG_PUART *uart = (tREG_PUART *)param;
	int ch;

	tdk_printf("UART IRQ\n");

	ch = uart_getchar(uart);

	uart_rx_buffer[uart_rx_irq] = ch;
	uart_rx_irq++;
	tdk_printf("[%4d] uart:rx_irq_handler, recv = %c(%02x)\n", uart_rx_irq, ch, ch);

	if(ch == 'q' || ch == 'Q')
	{
		tdk_printf("[%4d] uart:rx_irq_handler:test finished\n", uart_rx_irq);
		uart_exit_flag = 1;
		tdk_printf("uart_exit_flag = %d\n", uart_exit_flag);
	}
}

void uart_irq_handler(void *param)
{
	tREG_PUART *uart = (tREG_PUART *)param;
	int ch;
	u32 flags;

	flags = uart->UARTMIS;

	tdk_printf("UART IRQ=0x%08x\n", flags);

	if(flags & MIS_RTMIS)
	{
		ch = uart_getchar(uart);

		uart_rx_buffer[uart_rx_irq] = ch;
		uart_rx_irq++;
		tdk_printf("[%4d] uart:rx_irq_handler, recv = %c(%02x)\n", uart_rx_irq, ch, ch);

		if(ch == 'q' || ch == 'Q')
		{
			tdk_printf("[%4d] uart:rx_irq_handler:test finished\n", uart_rx_irq);
			uart_exit_flag = 1;
			tdk_printf("uart_exit_flag = %d\n", uart_exit_flag);
		}
	}
	else if(flags & MIS_RXMIS)
	{
		ch = uart_getchar(uart);

		uart_rx_buffer[uart_rx_irq] = ch;
		uart_rx_irq++;
		tdk_printf("[%4d] uart:rx_irq_handler, recv = %c(%02x)\n", uart_rx_irq, ch, ch);

		if(ch == 'q' || ch == 'Q')
		{
			tdk_printf("[%4d] uart:rx_irq_handler:test finished\n", uart_rx_irq);
			uart_exit_flag = 1;
			tdk_printf("uart_exit_flag = %d\n", uart_exit_flag);
		}
	}

}

int test_uart_loopback(int argc, char *argv[])
{
	tPUART_PARAM param;
	u8 i;
	u32 test_size = UART_BUFFER_SIZE;
	u32 init=0x1000;

#if IS_SIMULATOR()
	param.uartClk = SYSTEM_CLK_SIM;
#else
	param.uartClk = SYSTEM_CLK;
#endif
	param.baudRate = 115200;
	param.sps = LCR_SPS_DIS;
	param.wlen = LCR_WLEN_8BIT;
	param.fen = LCR_FIFO_EN;
	param.stp2 = LCR_STP2_DIS;
	param.eps = LCR_EPS_DIS;
	param.pen = LCR_PARITY_DIS;
	param.brk = 0;


	tdk_printf("==================================\n");
	tdk_printf("UART Test");
	tdk_printf("==================================\n");

	for(i=0; i<test_size; i++)
	{
//		uart_tx_buffer[i] = 0x40+i;
		uart_tx_buffer[i] = 0x50;
		uart_rx_buffer[i] = 0x00;
	}

	/* Uart transfer by polling */
	uart_init(TEST_UART, &param);

#if 1
	tdk_printf("TX\n");
	__SIM_STEP(init+0x10);
	uart_writebytes(TEST_UART, uart_tx_buffer, test_size);

	tdk_printf("Check TX FIFO Empty\n");
	__SIM_STEP(init+0x11);
	while(1)
	{
		if(IS_TX_FIFO_EMPTY(TEST_UART)) break;
	}

	tdk_printf("RX\n");
	__SIM_STEP(init+0x20);
	uart_readbytes(TEST_UART, uart_rx_buffer, test_size);

	tdk_printf("Compare TX vs RX data\n");
	__SIM_STEP(init+0x30);
	if(memcmp(uart_tx_buffer, uart_rx_buffer, test_size) != 0)
	{
		tdk_printf("TX BUFFER\n");
		for(i=0; i<test_size; i++)
		{
			__SIM_RESP(uart_tx_buffer[i]);
		}
		tdk_printf("RX BUFFER\n");
		for(i=0; i<test_size; i++)
		{
			__SIM_RESP(uart_rx_buffer[i]);
		}
	}
	tdk_puts(ansi_get_green_text("PASS"));
	__SIM_STEP(init+0xff);
#endif


	/* Uart transfer by interrupt */
#if 1
	tdk_printf("INT ");


	param.baudRate=460800;
	__SIM_STEP(init+0x00);

	uart_tx_irq = 0;
	uart_rx_irq = 0;

	memset(uart_rx_buffer, 0x0, UART_BUFFER_SIZE);
	strcpy((char*)uart_tx_buffer, "Hello Worldq");
	test_size = strlen((char*)uart_tx_buffer);

	GIC_RegisterHandler(GIC_UART1, uart_irq_handler, (void*)TEST_UART);
	GIC_EnableIrq(GIC_UART1);

	__SIM_STEP(init+0x10);
	 uart_writebytes(TEST_UART, uart_tx_buffer, test_size);

	 __SIM_STEP(init+0x20);
	while(1)
	{
		if(uart_exit_flag) break;
	}

	__SIM_STEP(init+0x30);
	if(memcmp(uart_tx_buffer, uart_rx_buffer, test_size) != 0)
	{
		tdk_printf("TX BUFFER");
		for(i=0; i<test_size; i++)
		{
			__SIM_RESP(uart_tx_buffer[i]);
		}
		tdk_printf("RX BUFFER");
		for(i=0; i<test_size; i++)
		{
			__SIM_RESP(uart_rx_buffer[i]);
		}
	}
	tdk_puts(ansi_get_green_text("PASS"));
#endif
#if 0
	/* Uart transfer by DMA */
	tdk_printf("DMA ");
	param.txIntReq = UTIR_TX_REQ_EMPTY; // if TX FIFO is not full, dma tx req is asserted.
	param.rxIntReq = UTIR_RX_REQ_1B; // FIFO_RX_FULL, UTIR_RX_REQ_16B, UTIR_RX_REQ_24B is for interrupt, not available for DMA request
	param.baudRate = 921600; // 921600 460800
	UART_Init(UART0, &param);
//	UART_Init(UART1, &param);

	__SIM_STEP(gStep++);
//	INTC_EnableInt(IS_DMA, 0);
	dma_init();

	xferCnt = 8;

	txBuf = (u8 *)DMA_SRC_BASE;
	rxBuf = (u8 *)DMA_DST_BASE;
	for(i=0; i<xferCnt; i++)
	{
		*txBuf++ = i+0x51;
		*rxBuf++ = 0;
	}
	for(i=0; i<MAX_UART_CH; i++) //MAX_UART_CH
	{
		__SIM_STEP(gStep++);
		if(i == 0)
		{
			tdk_printf("T0R1");
			utx = UART0;
//			urx = UART1;
			dc.srcAddr = DMA_SRC_BASE;
			dc.dstAddr = (u32)&utx->FIFO_DAT;
			dc.lliBase = DMA_LLI_BASE;
			dc.flowCtrl = DFC_MEM_TO_PER;
			dc.srcPeri = (tDMA_REQ_PERI)0;
			dc.dstPeri = DRP_UART0_TX;
			dc.srcPort = DSP_AHB1;
			dc.dstPort = DDP_AHB1;
			dc.xferBytes = xferCnt;
			dc.lliCtrl = LDC_NONE;
			dc.srcBurstSize = DBS_1B;
			dc.dstBurstSize = DBS_4B;
			dc.srcWidth = DDW_32BIT;
			dc.dstWidth = DDW_8BIT;
			dc.chNum = 0;
			dc.intEn = TRUE;
			dma_prepare_channel(&dc);

			dc.srcAddr = (u32)&urx->FIFO_DAT;
			dc.dstAddr = DMA_DST_BASE;
			dc.flowCtrl = DFC_PER_TO_MEM;
			dc.srcPeri = DRP_UART1_RX;
			dc.dstPeri = (tDMA_REQ_PERI)0;
			dc.xferBytes = xferCnt;
			dc.srcBurstSize = DBS_1B;
			dc.dstBurstSize = DBS_1B;
			dc.srcWidth = DDW_8BIT;
			dc.dstWidth = DDW_32BIT;
			dc.chNum = 1;
			dma_prepare_channel(&dc);

		}
		else
		{
			tdk_printf("T1R0");
//			utx = UART1;
			urx = UART0;
			dc.srcAddr = DMA_SRC_BASE;
			dc.dstAddr = (u32)&utx->FIFO_DAT;
			dc.flowCtrl = DFC_MEM_TO_PER;
			dc.srcPeri = (tDMA_REQ_PERI)0;
			dc.dstPeri = DRP_UART1_TX;
			dc.srcWidth = DDW_32BIT;
			dc.dstWidth = DDW_8BIT;
			dc.chNum = 0;
			dma_prepare_channel(&dc);

			dc.srcAddr = (u32)&urx->FIFO_DAT;
			dc.dstAddr = DMA_DST_BASE;
			dc.flowCtrl = DFC_PER_TO_MEM;
			dc.srcPeri = DRP_UART0_RX;
			dc.dstPeri = (tDMA_REQ_PERI)0;
			dc.srcWidth = DDW_8BIT;
			dc.dstWidth = DDW_32BIT;
			dc.chNum = 1;
			dma_prepare_channel(&dc);
		}

		M_DMA_CH_EN(0);
		M_DMA_CH_EN(1);

		__SIM_STEP(gStep++);
		while(!dma_check_int(0));
		M_DMA_INT_CLR(0);

		__SIM_STEP(gStep++);
		while(!dma_check_int(1));
		M_DMA_INT_CLR(1);

		tdk_printf("VRFY");
		dc.srcAddr = DMA_SRC_BASE;
		dc.dstAddr = DMA_DST_BASE;
		if(tdk_verify32(dc.srcAddr, dc.dstAddr, (dc.xferBytes/4)))
			__SIM_END_FAIL();

		rxBuf = (u8 *)DMA_DST_BASE;
		for(j=0; j<xferCnt; j++)
			*rxBuf++ = 0;

	}
#endif
	return 0;
}

void uart_init_int(void)
{
	tPUART_PARAM param;

	param.uartClk = SYSTEM_CLK;
	param.baudRate = 115200;
	param.sps = LCR_SPS_DIS;
	param.wlen = LCR_WLEN_8BIT;
	param.fen = LCR_FIFO_EN;
	param.stp2 = LCR_STP2_DIS;
	param.eps = LCR_EPS_DIS;
	param.pen = LCR_PARITY_DIS;
	param.brk = 0;

	uart_init(TEST_UART, &param);

	GIC_ClearAllRaisedIrq();

//	GIC_RegisterHandler(TEST_UART_IRQ_TX, uart_tx_handler, (void*)TEST_UART);
//	GIC_EnableIrq(TEST_UART_IRQ_TX);

	GIC_RegisterHandler(GIC_UART0, uart_irq_handler, (void*) UART0);
	GIC_EnableIrq(GIC_UART0);

	/*
	 {
	 int i;
		 for(i=0; i<32; i++)
		 {
			 GIC_EnableIrq(GIC_EXT_INT0+i);
		 }
	 }
	 */

}


void uart_terminate(void)
{
	GIC_DisableIrq(GIC_UART0);
	GIC_DisableIrq(GIC_UART0);
}

int test_uart_echo(int argc, char *argv[])
{
	u32 init=0x1000;
//	int test_size;

	tdk_printf("UART Interrupt Test\n");

	uart_exit_flag = 0;

	SYS_SimInfo(init + 0x00, "UART");
	memset(uart_tx_buffer, 0x00, sizeof(uart_tx_buffer));
	memset(uart_rx_buffer, 0x00, sizeof(uart_rx_buffer));

	SYS_SimInfo(init + 0x10, "UART Init");
	uart_init_int();

	while (1)
	{
		if (uart_exit_flag)
			break;
	}

	SYS_SimInfo(init + 0x40, "UART Disable");
	uart_terminate();

	SYS_SimInfo(init + 0xff, "UART Finish");
	return 0;
}

