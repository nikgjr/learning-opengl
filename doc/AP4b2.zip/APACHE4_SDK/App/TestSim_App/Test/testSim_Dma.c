/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : testSim_Dma.c
*
*  @brief   :
*
*  @author  :
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "sim.h"


#if SIM_ENABLE_DMA










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

UINT8* gTestSimDMASrcBuff  = (UINT8*)(APACHE_DRAM_BASE+0x02000000);
UINT8* gTestSimDMADstBuff  = (UINT8*)(APACHE_DRAM_BASE+0x03000000);
UINT8* gTestSimDMAInstBuff = (UINT8*)(APACHE_DRAM_BASE+0x04000000);










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

static void __testsim_dma_display_meminfo(UINT8* Str, UINT8* pSrcBuff, UINT8* pDstBuff, UINT8* pInstBuff)
{
    DEBUGMSG(MSGINFO, "-------------------------------------------------------------\n");        
    DEBUGMSG(MSGINFO, " >> %s \n", Str);
    DEBUGMSG(MSGINFO, "    - Source      Memory (0x%08X)\n", pSrcBuff);
    DEBUGMSG(MSGINFO, "    - Destination Memory (0x%08X)\n", pDstBuff);
    DEBUGMSG(MSGINFO, "    - Instruction Memory (0x%08X)\n", pInstBuff); 
    DEBUGMSG(MSGINFO, "-------------------------------------------------------------\n");  
}


static void __testsim_dma_display_info(eDMA_CH Ch, UINT32 BurstLen, UINT32 Length)
{  
    DEBUGMSG(MSGINFO, "\r >> DMA_CH%d, DMA_BL_%02dXFER, DataSize(0x%06x)\n", Ch, BurstLen, Length);
}


static void __testsim_dma_byte_display_buff(UINT8 *String, UINT8 *pBuff, UINT32 Size)
{    
    UINT32 i;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");	
    DEBUGMSG(MSGINFO, "\n >> %s BuffAddr = 0x%08X, Size = 0x%08X", String, pBuff, Size);	
    for(i=0;i<Size;i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", pBuff+i);	
        DEBUGMSG(MSGINFO, "%02X ", pBuff[i]);	
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");	
}



static void __testsim_dma_compare_buff_display(UINT8 *pSrc, UINT8 *pDes)
{
    __testsim_dma_byte_display_buff("SRC", pSrc, 0x100);
    __testsim_dma_byte_display_buff("DST", pDes, 0x100); 
}


static UINT32 __testsim_dma_compare_buff_sincr_dincr(UINT8 *pSrc, UINT8* pDes, UINT32 size, UINT32 totalsize)
{
    UINT32 i;
    UINT32 nErrCnt = 0;
    UINT8* pSrc_org  = pSrc;
    UINT8* pDest_org = pDes;
    UINT32 Offset;
    

    for(i=0; i<size; i++)
    {
        if(*pSrc++ != *pDes++)
        {
            nErrCnt++;
            break;
        }
    }


    if(nErrCnt)
    {
        pSrc--;
        pDes--;     
        
        DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
        DEBUGMSG(MSGERR, " >> DMA Compare Error Case1 - 0x%08X\n", size);
        DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", pSrc, pDes);
        DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", pSrc_org, pSrc_org+size);
        DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", pDest_org, pDest_org+size); 

        rSIM_RES05  = 1;
        rSIM_RES07  = (UINT32)pSrc;
        rSIM_RES08  = (UINT32)pDes;
        rSIM_RES09  = (UINT8)*pSrc;
        rSIM_RES10 = (UINT8)*pDes;

        Offset = pSrc-pSrc_org;
        pSrc -= ((Offset>=0x100)?0x80:0);
        pDes -= ((Offset>=0x100)?0x80:0);
        
        __testsim_dma_compare_buff_display(pSrc, pDes);
    }
    else
    {

        
        for( ;i<totalsize; i++)
        {
            if(0xFF != *pDes++)
            {
                nErrCnt++;
                break;
            }
        }

        if(nErrCnt)
        {
            pDes--;     

            DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
            DEBUGMSG(MSGERR, " >> DMA Compare Error Case2 - 0x%08X\n", size);
            DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", pSrc, pDes);
            DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", pSrc_org, pSrc_org+size);
            DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", pDest_org, pDest_org+size); 

            rSIM_RES06  = 1;
            rSIM_RES07  = (UINT32)pSrc;
            rSIM_RES08  = (UINT32)pDes;
            rSIM_RES09  = 0xFF;
            rSIM_RES10 = (UINT8)*pDes;

            pDes -= (((pDes-pDest_org)>=0x100)?0x80:size);
            pSrc = pSrc_org + (pDes-pDest_org);
            __testsim_dma_compare_buff_display(pSrc, pDes);
        }
 
    }

    
    return nErrCnt;
}



static void __testsim_dma_dumy_buff(UINT8 *pData, UINT32 size, UINT8 data)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        *pData++ = i+data;
    }
}


static void __testsim_dma_clear_buff(UINT8 *pData, UINT32 size, UINT8 ClsValue)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        *pData++ = ClsValue;
    }
}



static BOOL __testsim_dma_timeout(UINT32 mSec)
{
    BOOL ret = FALSE;       
    static volatile UINT32 s_TimeOutMsec = 0;  

    if(mSec > 0)
    {
        if(s_TimeOutMsec == 0)
        {
            // Set TimeOut : SystemTick(msec) + TargetMsec;
            s_TimeOutMsec = nc_get_msec(1) + mSec;
        }
        else
        {
            // Timeout Check. 
            if( nc_get_msec(0) > s_TimeOutMsec)
            {
                ret = TRUE;
                s_TimeOutMsec = 0;
            }
        }
    }
    else
    {
        s_TimeOutMsec = 0;
    }
    
    return ret;
}


static void __testsim_dma_init_debug(void)
{
    UINT32 i;
    
    for(i=0; i<=0x4C; i+=4)
    {
        REGRW32(SIM_DEBIG_REG, i) = 0x0;
    }
}


void APACHE_TEST_SIM_APP_DMA_MtoM_SIncr_DIncr(eDMA_CH Ch)
{
    INT32 ret = NC_SUCCESS;  

    tDMA_PARAM tDMAParam;
    UINT32 BurstLength;    
    UINT32 TestDataSize;  

    UINT8* pSrcBuff  = (UINT8*)&gTestSimDMASrcBuff[0];
    UINT8* pDstBuff  = (UINT8*)&gTestSimDMADstBuff[0];
    UINT8* pInstBuff = (UINT8*)&gTestSimDMAInstBuff[0];      


    __testsim_dma_display_meminfo("APACHE_TEST_SIM_APP_DMA_MtoM_SIncr_DIncr", pSrcBuff, pDstBuff, pInstBuff);  


    // Step_01. Open DMA 
    rSIM_STEP = 1;
    BurstLength  = 1;
    TestDataSize = 1024;
    ncLib_DMA_Open();



    // Step_02. Init DAM Channel 
    rSIM_STEP = 2;
    tDMAParam.mReqType    = DMA_MEM_TO_MEM;  
    tDMAParam.mInstAddr   = (UINT32)pInstBuff; 
    tDMAParam.mIntEn      = DISABLE;
    tDMAParam.mRxIncrEn   = ENABLE;  
    tDMAParam.mRxBurstLen = BurstLength;  
    tDMAParam.mTxIncrEn   = ENABLE; 
    tDMAParam.mTxBurstLen = BurstLength;  
    tDMAParam.mSwap       = DMA_SWAP_NO;  
    ret = ncLib_DMA_Control(GCMD_DMA_INIT_CH, Ch, &tDMAParam, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel Init Error!\n");
        rSIM_RES00 = 2;
        
        return;
    }


    // Step_03. Debug Src Buffer Write
    rSIM_STEP = 3;
    __testsim_dma_dumy_buff(pSrcBuff, TestDataSize, Ch);
    __testsim_dma_clear_buff(pInstBuff, (TestDataSize/512)*16, 0xFF);
    __testsim_dma_clear_buff(pDstBuff, TestDataSize, 0xFF);
    __testsim_dma_display_info(Ch, BurstLength, TestDataSize);


   
    // Step_04. DMA Start
    rSIM_STEP = 4;
    ncLib_DMA_Control(GCMD_DMA_START, Ch, (UINT32)pSrcBuff, (UINT32)pDstBuff, TestDataSize, CMD_END);


    
    // Step_05. DMA Done Wait
    rSIM_STEP = 5;    
    while((ret = ncLib_DMA_Control(GCMD_DMA_DONE, Ch, CMD_END)) == NC_FAILURE)
    {
        if(__testsim_dma_timeout(1000))
        {
            DEBUGMSG(MSGWARN, " - DMA TimeOut!~\n");
            rSIM_RES00 = 5;
            
            break;
        }
    }
    __testsim_dma_timeout(0);


    // Step_06. DMA Status Check
    rSIM_STEP = 6;     
    if(ret != NC_FAILURE)
    {   
        if(ret != 0x01)
        {
            DEBUGMSG(MSGWARN, "\nDMA Error Status : 0x%04X\n", ret);
            rSIM_RES01 = 6;
        }
    }


    // Step_07. Compare - Src vs Dest Buffer
    rSIM_STEP = 7;     
    __testsim_dma_compare_buff_sincr_dincr(pSrcBuff, pDstBuff, TestDataSize, TestDataSize);
    
    

    // Step_08. DeInit DMA Channel
    rSIM_STEP = 8;
    ret = ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, Ch, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel DeInit Error!\n");
        rSIM_RES02 = 8;    
        
        return;
    }

    
    // Step_09. Close DMA
    rSIM_STEP = 9;
    ret = ncLib_DMA_Close();    
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Close Error!\n");
        rSIM_RES02 = 9;
        
        return;
    }
    
}


void APACHE_TEST_SIM_APP_DMA(void)
{
    __testsim_dma_init_debug();
    
    APACHE_TEST_SIM_APP_DMA_MtoM_SIncr_DIncr(DMA_CH0);
}


#endif /* SIM_ENABLE_DMA */


/* End Of File */

