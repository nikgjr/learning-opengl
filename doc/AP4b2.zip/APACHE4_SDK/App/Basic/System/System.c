/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : System.c
*
*  @brief   :
*
*  @author  :
*
*  @date    : 2017.11.27
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "App.h"










/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void APACHE_SYS_DisplayClock(void)
{
    // Display Clock
    DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
    DEBUGMSG(MSGINFO, "    CPU   : %7d KHz    AXI   : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_CPU, CMD_END)/KHZ,
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_AXI, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "    APB   : %7d KHz    SSPI  : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_APB, CMD_END)/KHZ,
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_SSPI, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "    QSPI  : %7d KHz    UART  : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_QSPI, CMD_END)/KHZ,
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_UART, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "    TIMER : %7d KHz    I2C   : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_TIMER, CMD_END)/KHZ,
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_I2C, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "    DDR   : %7d KHz    PWM   : %7d KHz\n", ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_DDR, CMD_END)/KHZ,
                                                                  ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_PWM, CMD_END)/KHZ);
    DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
}


/* End Of File */

