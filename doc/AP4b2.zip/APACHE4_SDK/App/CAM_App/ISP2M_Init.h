#ifndef __TEST_ISP2M_h__
#define __TEST_ISP2M_h__

//============================================================================
//      Compiler Dependent Definitions
//============================================================================

#define TEST_MODE_ISP2M     TRUE


//============================================================================
//      Type Definitions
//============================================================================

#define ISPRW8(base_addr, offset)       (*(volatile unsigned char *) (base_addr + (offset<<2)))

#define sim_printf(fmt, args...)  \
                                        do { ncLib_DEBUG_Printf(1, fmt, ## args); } while(0)


//============================================================================
//      User Definitions
//============================================================================
#define IN_NTSC             0   // 720x480 NTSC
#define IN_PAL              1   // 720x576 PAL

#define OUT_PROGRESSIVE     0   // 54Mhz Progressive (8bit)
#define OUT_INTERLACE       1   // 27Mhz Interlace   (8bit)

#define DAC_CVBS            0   // CVBS
#define DAC_IRIS            1   // IRIS

#define CVBS_OUT_H720       0   // CVBS Output : 720H
#define CVBS_OUT_H960       1   // CVBS Output : 960H
#define CVBS_OUT_H720_COMET 2   // CVBS Output : 720H_COMMET (54Mhz)

//============================================================================
//      Definitions for SFR Register
//============================================================================
// 0x80 rEINTMOD                // External Interrupt Control Register 0
#define EINT0EN                 0x01    // External Interrupt 0 enable
#define EINT0MOD_RISE_EDGE      0x00    // This field is affected to EINT0, EINT2, EINT4, and EINT6.
#define EINT0MOD_FALL_EDGE      0x02    // This field is affected to EINT0, EINT2, EINT4, and EINT6.
#define EINT0MOD_LEVEL_MODE     0x04    // This field is affected to EINT0, EINT2, EINT4, and EINT6.
#define EINT0MOD_BOTH_EDGE      0x06    // This field is affected to EINT0, EINT2, EINT4, and EINT6.
#define EINT0FILTER_DIS         0x08    // External Interrupt 0/2/4/6 Noise Filter disable at edge mode.
#define EINT0FILTER_EN          0x00    // External Interrupt 0/2/4/6 Noise Filter enable at edge mode.
#define EINT0_HIGH_LEVEL        0x08    // Active High at Level mode  
#define EINT0_LOW_LEVEL         0x00    // Active Low at Level mode   
#define EINT0_WAKEUP_HI         0x08    // High Level wake-up
#define EINT0_WAKEUP_LOW        0x00    // Low Level wake-up

#define EINT1EN                 0x10    // External Interrupt 1 enable
#define EINT1MOD_RISE_EDGE      0x00    // This field is affected to EINT1, EINT3, and EINT5.
#define EINT1MOD_FALL_EDGE      0x20    // This field is affected to EINT1, EINT3, and EINT5.
#define EINT1MOD_LEVEL_MODE     0x40    // This field is affected to EINT1, EINT3, and EINT5.
#define EINT1MOD_BOTH_EDGE      0x60    // This field is affected to EINT1, EINT3, and EINT5.
#define EINT1FILTER_DIS         0x80    // External Interrupt 1/3/5 Noise Filter disable at edge mode.
#define EINT1FILTER_EN          0x00    // External Interrupt 1/3/5 Noise Filter enable at edge mode.
#define EINT1_HIGH_LEVEL        0x08    // Active High at Level mode
#define EINT1_LOW_LEVEL         0x00    // Active Low at Level mode 
#define EINT1_WAKEUP_HI         0x80    // High Level wake-up  
#define EINT1_WAKEUP_LOW        0x00    // Low Level wake-up   

// 0x87 rPCON                   // Power control
#define PCON_RTCXIEN            0x08
#define PCON_USB_RST            0x04
#define PCON_STOP               0x02
#define PCON_IDLE               0x01

// 0x8D rEF_CON                 // e-FLASH control register
#define SelfEF_RWEN             0x80    // 7 : Enable Read/Write into self e-FLASH simultaneously
#define RDYBSYB                 0x10    // 4 : Timer 0
#define WP_B1                   0x02    // 1 : Write Protect 0x0_8000 ~ 0x0_FFFF
#define WP_B0                   0x01    // 0 : Write Protect 0x0_0000 ~ 0x0_7FFF
#define WP_ALL                  0x03    

// 0xA8 rIE0                    // INT Enable 0 Register
#define IE0_SPI1                0x01
#define IE0_ISP_INT0            0x02
#define IE0_SPI2                0x04
#define IE0_ISP_INT1            0x08
#define IE0_ISP_INT2            0x10
#define IE0_SPI0                0x20
#define IE0_T2MAT               0x40
#define IE0_T2OVF               0x80


// 0xA9 rIPENDSET0              // INT Pending Set 0 Register
#define IPSET0_SPI1             0x01
#define IPSET0_ISP_INT0         0x02
#define IPSET0_SPI2             0x04
#define IPSET0_ISP_INT1         0x08
#define IPSET0_ISP_INT2         0x10
#define IPSET0_SPI0             0x20
#define IPSET0_T2MAT            0x40
#define IPSET0_T2OVF            0x80


// 0xAA rIPENDCLR0              // INT Pending Clear 0 Register
#define IPCLR0_SPI1             0x01
#define IPCLR0_ISP_INT0         0x02
#define IPCLR0_SPI2             0x04
#define IPCLR0_ISP_INT1         0x08
#define IPCLR0_ISP_INT2         0x10
#define IPCLR0_SPI0             0x20
#define IPCLR0_T2MAT            0x40
#define IPCLR0_T2OVF            0x80


// 0xAB rIP0                    // INT Priority 0 Register
#define IP0_SPI1                0x01
#define IP0_ISP_INT0            0x02
#define IP0_SPI2                0x04
#define IP0_ISP_INT1            0x08
#define IP0_ISP_INT2            0x10
#define IP0_SPI0                0x20
#define IP0_T2MAT               0x40
#define IP0_T2OVF               0x80


// 0xAC rIE2                    // INT Enable 2 Register
#define IE2_I2C0                0x01
#define IE2_I2C1                0x02
#define IE2_ISP_INT3            0x04
#define IE2_ISP_INT4            0x08
#define IE2_ISP_INT5            0x10
#define IE2_ISP_INT6            0x20
#define IE2_ISP_INT7            0x40
#define IE2_ISP_INT8            0x80


// 0xAD rIPENDSET2              // INT Pending Set 2 Register
#define IPSET2_I2C0             0x01
#define IPSET2_I2C1             0x02
#define IPSET2_ISP_INT3         0x04
#define IPSET2_ISP_INT4         0x08
#define IPSET2_ISP_INT5         0x10
#define IPSET2_ISP_INT6         0x20
#define IPSET2_ISP_INT7         0x40
#define IPSET2_ISP_INT8         0x80


// 0xAE rIPENDCLR2              // INT Pending Clear 2 Register
#define IPCLR2_I2C0             0x01
#define IPCLR2_I2C1             0x02
#define IPCLR2_ISP_INT3         0x04
#define IPCLR2_ISP_INT4         0x08
#define IPCLR2_ISP_INT5         0x10
#define IPCLR2_ISP_INT6         0x20
#define IPCLR2_ISP_INT7         0x40
#define IPCLR2_ISP_INT8         0x80


// 0xAF rIP2                    // INT Pending Priority 2 Register
#define IP2_I2C0                0x01
#define IP2_I2C1                0x02
#define IP2_ISP_INT3            0x04
#define IP2_ISP_INT4            0x08
#define IP2_ISP_INT5            0x10
#define IP2_ISP_INT6            0x20
#define IP2_ISP_INT7            0x40
#define IP2_ISP_INT8            0x80


// 0xB7 rGIE                    // INT Global Interrupt Enable
#define rGIE_GIE(x)             ((x == 1) ? (rGIE |= (1 << 7)) : (x == 0) ? (rGIE &= ~(1 << 7)) : (rGIE & 0x80))
#define EnterCriticalSection    rGIE = 0x00
#define ExitCriticalSection     rGIE = 0x80
#define GlobalIntDisable        rGIE = 0x00
#define GlobalIntEnable         rGIE = 0x80

// 0xB8 rIE1                    // INT Interrupt Enable 1
#define IE1_T0MAT               0x01    // Enable Timer 0 Match interrupt
#define IE1_T0OVF               0x02    // Enable Timer 0 Overflow interrupt
#define IE1_T1MAT               0x04    // Enable Timer 1 Match interrupt
#define IE1_T1OVF               0x08    // Enable Timer 1 Overflow interrupt
#define IE1_U0TX                0x10    // Enable UART 0 Transmit interrupt
#define IE1_U0RX                0x20    // Enable UART 0 Receive interrupt
#define IE1_U1TX                0x40    // Enable UART 1 Transmit interrupt
#define IE1_U1RX                0x80    // Enable UART 1 Receive interrupt

// 0xB9 rIPENDSET1              // INT Interrupt Pending Set 1 register.
#define IPSET1_T0MAT            0x01
#define IPSET1_T0OVF            0x02
#define IPSET1_T1MAT            0x04
#define IPSET1_T1OVF            0x08
#define IPSET1_U0TX             0x10
#define IPSET1_U0RX             0x20
#define IPSET1_U1TX             0x40
#define IPSET1_U1RX             0x80

// 0xBA rIPENDCLR1              // INT Interrupt Pending Clear 1 register.
#define IPCLR1_T0MAT            0x01
#define IPCLR1_T0OVF            0x02
#define IPCLR1_T1MAT            0x04
#define IPCLR1_T1OVF            0x08
#define IPCLR1_U0TX             0x10
#define IPCLR1_U0RX             0x20
#define IPCLR1_U1TX             0x40
#define IPCLR1_U1RX             0x80

// 0xBB rIP1                    // INT Interrupt Priority 1 register.
#define IP1_T0MAT               0x01
#define IP1_T0OVF               0x02
#define IP1_T1MAT               0x04
#define IP1_T1OVF               0x08
#define IP1_U0TX                0x10
#define IP1_U0RX                0x20
#define IP1_U1TX                0x40
#define IP1_U1RX                0x80

// 0xC0 rTCON                   // TIMER 0/1/2 Control Register
#define T0RUN                   0x01
#define T0CLR                   0x02
#define T1RUN                   0x04
#define T1CLR                   0x08
#define T2RUN                   0x10
#define T2CLR                   0x20

#define MATEN                   0x01    // Timer x Match/Capture Interrupt Enable.
#define OVFEN                   0x02    // Timer x Overflow Interrupt Enable.
#define SEL_INTERVAL            0x00    // Interval Mode.
#define SEL_CAPTURE_RISE        0x04    // Capture Mode (rising edge of TxCAP pin input)
#define SEL_CAPTURE_FALL        0x08    // Capture Mode (falling edge of TxCAP pin input)
#define SEL_PWM                 0x0C    // PWM Mode


// 0xD0 rPSW                    // PSW (Program Status Word)
#define PSW_P                   0x01    // Parity Flag
#define PSW_F1                  0x02    // Flag1 available to the user for general purpose.
#define PSW_OV                  0x04    // Overflow Flag
#define PSW_RS0                 0x00    // 00: Register Bank 0 (0x00 ~ 0x07)
#define PSW_RS1                 0x08    // 01: Register Bank 1 (0x08 ~ 0x0F)
#define PSW_RS2                 0x10    // 10: Register Bank 2 (0x10 ~ 0x17)
#define PSW_RS3                 0x18    // 11: Register Bank 3 (0x18 ~ 0x1F)
#define PSW_F0                  0x20    // Flag0 available to the user for general purpose.
#define PSW_AC                  0x40    // Auxiliary Carry Flag
#define PSW_CY                  0x80    // Carry Flag


// 0xE8 rWDTMOD                  // WDT Mode Register
#define WDTCLR                          0x01
#define WDTEN                           0x02
#define WDTSEL_INT_DIS_RESET_DIS        0x00
#define WDTSEL_INT_DIS_RESET_EN         0x04
#define WDTSEL_INT_EN_RESET_DIS         0x08
#define WDTSEL_INT_EN_RESET_EN          0x0C
#define WDT_DISABLE                     (rWDTMOD &= ~WDTEN)
#define WDT_ENABLE                      (rWDTMOD |= WDTEN)

// 0xEB rWDTWAKE                //WDT Wake-Up function enable
#define WAKEEN                  0x01

// 0xEC, 0xE4 rSPIMOD                   // SPI Mode Register
#define SPI_SSMD                0x80
#define SPI_INTEN               0x40
#define SPI_SCKPHA_SECOND       0x20
#define SPI_SCKPHA_FIRST        0x00
#define SPI_SCKPOL_HI           0x10
#define SPI_SCKPOL_LOW          0x00
#define SPI_MATEN               0x00
#define SPI_SLVEN               0x08
#define SPI_DIR_LSB             0x04
#define SPI_DIR_MSB             0x00
#define SPI_MODE_RXTX           0x02
#define SPI_MODE_RX             0x00
#define SPI_EN                  0x01

// 0xED, 0xE5 rSPICK                    // SPI Baud Rate counter clock select Register
#define SPI_BUSY                0x80
#define SPI_IDLE                0x00
#define SPI_1BYTE               0x00
#define SPI_2BYTE               0x40
#define SPI_CKSEL_0000          0x00
#define SPI_CKSEL_0001          0x01
#define SPI_CKSEL_0010          0x02
#define SPI_CKSEL_0011          0x03
#define SPI_CKSEL_0100          0x04
#define SPI_CKSEL_0101          0x05
#define SPI_CKSEL_0110          0x06
#define SPI_CKSEL_0111          0x07
#define SPI_CKSEL_1000          0x08
#define SPI_CKSEL_1001          0x09
#define SPI_CKSEL_1010          0x0A
#define SPI_CKSEL_1011          0x0B
#define SPI_CKSEL_1100          0x0C


// 0xF1 rU0CON0                 // UART 0 Control Register 0
// 0xF9 rU1CON0                 // UART 1 Control Register 0
#define TMODE_EN                0x01
#define RMODE_EN                0x02
#define SBR                     0x04
#define SCSEL                   0x08
#define LOOPB                   0x10
#define PMD_NO_PARITY           0x00
#define PMD_ODD_PARITY          0x80
#define PMD_EVEN_PARITY         0xA0

// 0xF2 rU0CON1                 // UART 0 Control Register 1
// 0xFA rU1CON1                 // UART 1 Control Register 1
#define STB                     0x01
#define WL_5                    0x00
#define WL_6                    0x02
#define WL_7                    0x04
#define WL_8                    0x06
#define IRMODE                  0x08
#define XDRATE_DIV2             0x00
#define XDRATE_DIV4             0x10
#define XDRATE_DIV8             0x20
#define XDRATE_DIV16            0x30
#define ECLKSEL                 0x40
#define ECHO                    0x80

// 0xF3 rU0STAT                 // UART 0 Status Register
// 0xFB rU1STAT                 // UART 1 Status Register
#define RDV                     0x01
#define BKD                     0x02
#define FER                     0x04
#define PER                     0x08
#define OER                     0x10
#define RXIDLE                  0x20
#define TXIDLE                  0x40
#define THE                     0x80

// 0xF5 rU0INT                  // UART 0 Interrupt Enable Register
// 0xFD rU1INT                  // UART 1 Interrupt Enable Register
#define RDVIE                   0x01    // Receive Data Valid interrupt enable
#define BKDIE                   0x02    // Break Signal Detected interrupt enable
#define FERIE                   0x04    // Frame Error interrupt enable
#define PERIE                   0x08    // Parity Error interrupt enable
#define OERIE                   0x10    // Overrun Error interrupt enable
#define TIIE                    0x40    // Transmit IDLE interrupt enable
#define THEIE                   0x80    // Transmit holding register empty interrupt enable
#define UART_INT_ALL            0xDF

//	Definitions for Interrupt vectors
#define RST_vect                0x00
#define SPI1_vect               0x03    // interrupt ch0
#define ISP0_vect               0x0B    // interrupt ch1
#define SPI2_vect               0x13    // interrupt ch2
#define ISP1_vect               0x0B    // interrupt ch3
#define ISP2_vect               0x23    // interrupt ch4
#define SPI0_vect               0x2B    // interrupt ch5
#define T2_MATCH_vect           0x33    // interrupt ch6
#define T2_OVF_vect             0x3B    // interrupt ch7
#define T0_MATCH_vect           0x43    // interrupt ch8
#define T0_OVF_vect             0x4B    // interrupt ch9
#define T1_MATCH_vect           0x53    // interrupt ch10
#define T1_OVF_vect             0x5B    // interrupt ch11
#define UART0_TX_vect           0x63    // interrupt ch12
#define UART0_RX_vect           0x6B    // interrupt ch13
#define UART1_TX_vect           0x73    // interrupt ch14
#define UART1_RX_vect           0x7B    // interrupt ch15
#define I2C0_vect               0x83    // interrupt ch16
#define I2C1_vect               0x8B    // interrupt ch17
#define ISP3_vect               0x93    // interrupt ch18
#define ISP4_vect               0x9B    // interrupt ch19
#define ISP5_vect               0xA3    // interrupt ch20
#define ISP6_vect               0xAB    // interrupt ch21
#define ISP7_vect               0xB3    // interrupt ch22
#define ISP8_vect               0xBB    // interrupt ch23

//  Definitions for Inner Connection
#define DPC_SCAN_END            0
#define MD_END                  1
#define VSI_NEG                 2
#define VSI_POS                 3
#define VSO_NEG                 4
#define VSO_POS                 5
#define AF_INT                  6 
#define CVBS_INT                7 
#define LINE0_INT               9
#define LINE1_INT               10
#define LINE2_INT               11
#define LINE3_INT               12
// refer data-sheet for other connections

#endif /* __TEST_ISP2M_h__ */
