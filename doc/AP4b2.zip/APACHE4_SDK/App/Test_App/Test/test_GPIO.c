/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_GPIO










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    eGPIO_INT_CH    mGPIO_IntTestCh;

    eGPIO_GROUP     mGPIO_InTestGroup;
    eGPIO_PORT      mGPIO_InTestPort;

    eGPIO_GROUP     mGPIO_OutTestGroup;
    eGPIO_PORT      mGPIO_OutTestPort;
    
    BOOL            mGPIO_TrigMode;          // 0: RISING, 1: FALLING
} tGPIOTEST_FLAG, *ptGPIOTEST_FLAG;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tGPIOTEST_FLAG tGPIOTestFlag; 
volatile tGPIOTEST_FLAG tGPIOTestFlag_Def = { 
                                                GPIO_INT_CH0

                                                ,GPIO_GROUP_A
                                                ,GPIO_PORT0
                                           
                                                ,GPIO_GROUP_A
                                                ,GPIO_PORT0
                                                
                                                ,0                                  
                                           };










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

void __gpio_test_select_port(eGPIO_GROUP* group, eGPIO_PORT* port)
{
    INT8 buf = 0; 

    APACHE_TEST_GetArrowKey_Help("Port Up", "Port Down", "Group Up", "Group Down");
    DEBUGMSG(MSGINFO, " > Select GPIO_%d[%02d]", *group, *port);

    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);

            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(*port < GPIO_PORT31)
                   (*port)++;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(*port > GPIO_PORT0)
                   (*port)--;
            }
            // Number Key '6' and Direction Key 'Rigth'
            else if(buf == '6')
            {
                if(*group < GPIO_GROUP_D)
                   (*group)++;
            }
            // Number Key '4' and Direction Key 'Left'
            else if(buf == '4')
            {
                if(*group > GPIO_GROUP_A)
                   (*group)--;
            }

            DEBUGMSG(MSGINFO, "\r > Select GPIO_%d[%02d]", *group, *port);
        }

        nc_mdelay(10);
    }
}


void APACHE_TEST_GPIO_Isr(UINT32 irq)
{
    eGPIO_INT_CH ch = (eGPIO_INT_CH)(irq - IRQ_NUM_GPIO0); 

    DEBUGMSG(MSGINFO, "   ------------------> IRQ_%d, GPIO_INT_%d\n", irq, ch);
}


void APACHE_TEST_GPIO_Isr_Init(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_INT_CH ch)
{
    // Register GPIO Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_REGISTER_INT
                      ,IRQ_NUM_GPIO0 + ch
                      ,(PrHandler)APACHE_TEST_GPIO_Isr
                      ,CMD_END);

    ncLib_GPIO_Control(GCMD_GPIO_SET_INTC, group, port, ch, tGPIOTestFlag.mGPIO_TrigMode, ENABLE, CMD_END);  
}


void APACHE_TEST_GPIO_Isr_DeInit(eGPIO_GROUP group, eGPIO_PORT port, eGPIO_INT_CH ch)
{
    // Unregister GPIO Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT
                      ,IRQ_NUM_GPIO0 + ch
                      ,CMD_END);

    ncLib_GPIO_Control(GCMD_GPIO_SET_INTC, group, port, ch, tGPIOTestFlag.mGPIO_TrigMode, DISABLE, CMD_END);   
}


void APACHE_TEST_GPIO_ChangeChannel(void)
{
    eGPIO_INT_CH ch = (eGPIO_INT_CH)tGPIOTestFlag.mGPIO_IntTestCh;       
    INT8 buf = 0;

    APACHE_TEST_GetArrowKey_Help("Channel Up", "Channel Down", NULL, NULL);
    
    DEBUGMSG(MSGINFO, "  > GPIO INT Select    : %d", ch);
    
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(ch < GPIO_INT_CH2)
                    ++ch;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(ch > GPIO_INT_CH0)
                    --ch;
            }

            DEBUGMSG(MSGINFO, "\r  > GPIO INT Select    : %d", ch, buf, buf);
        }
    }

    tGPIOTestFlag.mGPIO_IntTestCh = ch;
}


void APACHE_TEST_GPIO_ExternalInt_ext(void)
{
    eGPIO_GROUP in_group  = tGPIOTestFlag.mGPIO_InTestGroup;
    eGPIO_PORT  in_port   = tGPIOTestFlag.mGPIO_InTestPort;
    
    eGPIO_GROUP out_group = tGPIOTestFlag.mGPIO_OutTestGroup;
    eGPIO_PORT  out_port  = tGPIOTestFlag.mGPIO_OutTestPort;
    
    eGPIO_DATA  level = GPIO_LOW;
    INT8 buf;



    //////////////////////////////////////////////////////////////////////////  
    DEBUGMSG(MSGINFO, "\n Select GPIO Port - External Interrupt Test\n");

    // Select - Test GPIO Input Port 
    __gpio_test_select_port(&in_group, &in_port);
    tGPIOTestFlag.mGPIO_InTestGroup = in_group;
    tGPIOTestFlag.mGPIO_InTestPort  = in_port;

    
    // Set - GPIO Input Mode (and Enable Interrupt) 
    ncLib_GPIO_Control(GCMD_GPIO_ENA, in_group, in_port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, in_group, in_port, GPIO_DIR_IN, CMD_END);
    APACHE_TEST_GPIO_Isr_Init(in_group, in_port, GPIO_INT_CH0);

    ncLib_GPIO_Control(GCMD_GPIO_ENA, in_group, in_port+1, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, in_group, in_port+1, GPIO_DIR_IN, CMD_END);
    APACHE_TEST_GPIO_Isr_Init(in_group, (eGPIO_PORT)(in_port+1), GPIO_INT_CH1);

    ncLib_GPIO_Control(GCMD_GPIO_ENA, in_group, in_port+2, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, in_group, in_port+2, GPIO_DIR_IN, CMD_END);
    APACHE_TEST_GPIO_Isr_Init(in_group, (eGPIO_PORT)(in_port+2), GPIO_INT_CH2);







    //////////////////////////////////////////////////////////////////////////
    DEBUGMSG(MSGINFO, "\n Select GPIO Port - Output Ctrl Port\n");

    // Select - Test GPIO Output Port 
    __gpio_test_select_port(&out_group, &out_port);
    tGPIOTestFlag.mGPIO_OutTestGroup = out_group;
    tGPIOTestFlag.mGPIO_OutTestPort  = out_port;


    // Set - GPIO Output Mode
    ncLib_GPIO_Control(GCMD_GPIO_ENA, out_group, out_port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, out_group, out_port, GPIO_DIR_OUT, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, out_group, out_port, level, CMD_END);

    ncLib_GPIO_Control(GCMD_GPIO_ENA, out_group, out_port+1, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, out_group, out_port+1, GPIO_DIR_OUT, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, out_group, out_port+1, level, CMD_END);

    ncLib_GPIO_Control(GCMD_GPIO_ENA, out_group, out_port+2, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, out_group, out_port+2, GPIO_DIR_OUT, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, out_group, out_port+2, level, CMD_END);    



    // Display Test Menu
    APACHE_TEST_GetArrowKey_Help("HIgh", "Low", NULL, NULL);
    DEBUGMSG(MSGINFO, " > GPIO_%d[%02d] - %s\n", out_group, out_port, level?"HIGH":"LOW ");

    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);

            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(level == GPIO_LOW)
                   level = GPIO_HIGH;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(level == GPIO_HIGH)
                   level = GPIO_LOW;
            }
            // Number Key '6' and Direction Key 'Rigth'
            else if(buf == '6')
            {
                if(out_port < GPIO_PORT31)
                   out_port++;
            }
            // Number Key '4' and Direction Key 'Left'
            else if(buf == '4')
            {
                if(out_port > GPIO_PORT0)
                   out_port--;
            }

            DEBUGMSG(MSGINFO, " > GPIO_%d[%02d] - %s\n", out_group, out_port, level?"HIGH":"LOW ");
            
            ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, out_group, out_port, level, CMD_END);
        }

        nc_mdelay(1);
    }


    // Disable External Interrupt (only Input Mode)
    APACHE_TEST_GPIO_Isr_DeInit(in_group, in_port, GPIO_INT_CH0);
    APACHE_TEST_GPIO_Isr_DeInit(in_group, (eGPIO_PORT)(in_port+1), GPIO_INT_CH1);
    APACHE_TEST_GPIO_Isr_DeInit(in_group, (eGPIO_PORT)(in_port+2), GPIO_INT_CH2);


    // GPIO Port Disable
    ncLib_GPIO_Control(GCMD_GPIO_DIS, (eGPIO_GROUP)in_group,  (eGPIO_PORT)in_port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_DIS, (eGPIO_GROUP)in_group,  (eGPIO_PORT)in_port+1, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_DIS, (eGPIO_GROUP)in_group,  (eGPIO_PORT)in_port+2, CMD_END);

    out_port = tGPIOTestFlag.mGPIO_OutTestPort;    
    ncLib_GPIO_Control(GCMD_GPIO_DIS, (eGPIO_GROUP)out_group, (eGPIO_PORT)out_port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_DIS, (eGPIO_GROUP)out_group, (eGPIO_PORT)out_port+1, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_DIS, (eGPIO_GROUP)out_group, (eGPIO_PORT)out_port+2, CMD_END);

}


void APACHE_TEST_GPIO_ExternalInt(void)
{
    eGPIO_INT_CH ch = tGPIOTestFlag.mGPIO_IntTestCh; 
    
    eGPIO_GROUP in_group  = tGPIOTestFlag.mGPIO_InTestGroup;
    eGPIO_PORT  in_port   = tGPIOTestFlag.mGPIO_InTestPort;
        
    eGPIO_GROUP out_group = tGPIOTestFlag.mGPIO_OutTestGroup;
    eGPIO_PORT  out_port  = tGPIOTestFlag.mGPIO_OutTestPort;
    
    eGPIO_DATA  level = GPIO_LOW;
    INT8 buf;



    //////////////////////////////////////////////////////////////////////////  
    DEBUGMSG(MSGINFO, "\n Select GPIO Port - External Interrupt Test\n");

    // Select - Test GPIO Input Port 
    __gpio_test_select_port(&in_group, &in_port);
    tGPIOTestFlag.mGPIO_InTestGroup = in_group;
    tGPIOTestFlag.mGPIO_InTestPort  = in_port;

    
    // Set - GPIO Input Mode
    ncLib_GPIO_Control(GCMD_GPIO_ENA, in_group, in_port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, in_group, in_port, GPIO_DIR_IN, CMD_END);


    // Enable External Interrupt (only Input Mode)
    APACHE_TEST_GPIO_Isr_Init(in_group, in_port, ch);





    //////////////////////////////////////////////////////////////////////////
    DEBUGMSG(MSGINFO, "\n Select GPIO Port - Output Ctrl Port\n");

    
    // Select - Test GPIO Output Port 
    __gpio_test_select_port(&out_group, &out_port);
    tGPIOTestFlag.mGPIO_OutTestGroup = out_group;
    tGPIOTestFlag.mGPIO_OutTestPort  = out_port;


    // Set - GPIO Output Mode
    ncLib_GPIO_Control(GCMD_GPIO_ENA, out_group, out_port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, out_group, out_port, GPIO_DIR_OUT, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, out_group, out_port, level, CMD_END);



    // Display Test Menu
    APACHE_TEST_GetArrowKey_Help("HIgh", "Low", NULL, NULL);
    DEBUGMSG(MSGINFO, " > GPIO_%d[%02d] - %s\n", out_group, out_port, level?"HIGH":"LOW ");

    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);

            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(level == GPIO_LOW)
                   level = GPIO_HIGH;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(level == GPIO_HIGH)
                   level = GPIO_LOW;
            }


            DEBUGMSG(MSGINFO, " > GPIO_%d[%02d] - %s\n", out_group, out_port, level?"HIGH":"LOW ");
            
            ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, out_group, out_port, level, CMD_END);
        }

        nc_mdelay(1);
    }


    // Disable External Interrupt (only Input Mode)
    APACHE_TEST_GPIO_Isr_DeInit(in_group, in_port, ch);


    // Disable Test GPIO Port
    ncLib_GPIO_Control(GCMD_GPIO_DIS, (eGPIO_GROUP)in_group,  (eGPIO_PORT)in_port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_DIS, (eGPIO_GROUP)out_group, (eGPIO_PORT)out_port, CMD_END);
}


void APACHE_TEST_GPIO_InputMode(void)
{
    eGPIO_GROUP in_group  = tGPIOTestFlag.mGPIO_InTestGroup;
    eGPIO_PORT  in_port   = tGPIOTestFlag.mGPIO_InTestPort;
    eGPIO_DATA  level;    
    INT8 buf;

  
    DEBUGMSG(MSGINFO, "\n Select GPIO Port - Input Test\n");


    // Select - Test GPIO Port 
    __gpio_test_select_port(&in_group, &in_port);
    tGPIOTestFlag.mGPIO_InTestGroup = in_group;
    tGPIOTestFlag.mGPIO_InTestPort  = in_port;


    // Enable - GPIO Input Mode
    ncLib_GPIO_Control(GCMD_GPIO_ENA, in_group, in_port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, in_group, in_port, GPIO_DIR_IN, CMD_END);


    // GPIO Port Read
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);
        if(buf != NC_FAILURE)
        {
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }
        }

        level = (eGPIO_DATA)ncLib_GPIO_Control(GCMD_GPIO_GET_DATA, in_group, in_port, CMD_END);

        DEBUGMSG(MSGINFO, "   .GPIO_%d[%02d]", in_group, in_port);
        if(level == GPIO_LOW)
        {
            DEBUGMSG(MSGINFO, " - LOW  [Exit: Enter Key] \n");
        }
        else if (level == GPIO_HIGH)
        {
            DEBUGMSG(MSGINFO, " - HIGH [Exit: Enter Key]\n");
        }

        nc_delay(1);
    }


    ncLib_GPIO_Control(GCMD_GPIO_DIS, (eGPIO_GROUP)in_group, (eGPIO_PORT)in_port, CMD_END);
}


void APACHE_TEST_GPIO_OutputMode(void)
{
    eGPIO_GROUP out_group = tGPIOTestFlag.mGPIO_OutTestGroup;
    eGPIO_PORT  out_port  = tGPIOTestFlag.mGPIO_OutTestPort;
    eGPIO_DATA  level = GPIO_LOW;
    INT8 buf;


    DEBUGMSG(MSGINFO, "\n GPIO Port - Output Test\n");


    // Select - Test GPIO Port 
    __gpio_test_select_port(&out_group, &out_port);
    tGPIOTestFlag.mGPIO_OutTestGroup = out_group;
    tGPIOTestFlag.mGPIO_OutTestPort  = out_port;


    // Enable - GPIO Output Mode
    ncLib_GPIO_Control(GCMD_GPIO_ENA, out_group, out_port, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DIR, out_group, out_port, GPIO_DIR_OUT, CMD_END);
    ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, out_group, out_port, level, CMD_END);


    // Display Test Menu
    APACHE_TEST_GetArrowKey_Help("HIgh", "Low", NULL, NULL);
    DEBUGMSG(MSGINFO, " > Select GPIO_%d[%02d] - %s", out_group, out_port, level?"HIGH":"LOW");

    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);

            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(level == GPIO_LOW)
                   level = GPIO_HIGH;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(level == GPIO_HIGH)
                   level = GPIO_LOW;
            }

            ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, out_group, out_port, level, CMD_END);

            DEBUGMSG(MSGINFO, "\r > Select GPIO_%d[%02d] - %s", out_group, out_port, level?"HIGH":"LOW ");
        }

        nc_mdelay(10);
    }


    // Disable - GPIO Output Mode
    ncLib_GPIO_Control(GCMD_GPIO_DIS, (eGPIO_GROUP)out_group, (eGPIO_PORT)out_port, CMD_END);
}


INT32 APACHE_TEST_GPIO_CUTMode(void)
{
    INT32 select;
    char buf[256];


    // Default Init Variable
    tGPIOTestFlag = tGPIOTestFlag_Def;



    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - GPIO                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " GPIO Controller                                            \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> GPIO Output Test                                       \n");
        DEBUGMSG(MSGINFO, " <2> GPIO Input Test                                        \n");
        DEBUGMSG(MSGINFO, " <3> GPIO External Interrupt Test                           \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <C> GPIO INTC Channel Change     : Ch_%d                   \n", tGPIOTestFlag.mGPIO_IntTestCh);
        DEBUGMSG(MSGINFO, " <T> GPIO INTC Trig Mode Change   : TRIG_%s_EDGE            \n", (tGPIOTestFlag.mGPIO_TrigMode)?"FALLING":"RISING");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_GPIO_OutputMode();
            break;

            case 2:
                APACHE_TEST_GPIO_InputMode();
            break;

            case 3:
                APACHE_TEST_GPIO_ExternalInt();
            break;

            case 4:
                APACHE_TEST_GPIO_ExternalInt_ext();
            break;

            case 12: // 'C'
                APACHE_TEST_GPIO_ChangeChannel();
            break;

            case 29: // 'T'
                _REVERSE(tGPIOTestFlag.mGPIO_TrigMode);
            break;
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to sub menu\n");
            goto Gpio_Exit;
        }
    }

Gpio_Exit:

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_GPIO */


/* End Of File */

