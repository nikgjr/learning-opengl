/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __TEST_H__
#define __TEST_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"










/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

//------------------------------------------------------------------------------
// Test Application DB Version
#define TEST_APP_DB_VER                 3246    // 20180418

#define TEST_APP_BUILD_DATE             __DATE__
#define TEST_APP_BUILD_TIME             __TIME__

#define _DIGIT(s, no)                   ((s)[no] - '0')
#define TEST_APP_BUILD_YEAR             (((_DIGIT(__DATE__, 7) * 10 + _DIGIT(__DATE__, 8)) * 10 + _DIGIT(__DATE__, 9)) * 10 + _DIGIT(__DATE__, 10))                                         
#define TEST_APP_BUILD_MONTH            (__DATE__ [2] == 'n' ? 1 \
                                        : __DATE__ [2] == 'b' ? 2 \
                                        : __DATE__ [2] == 'r' ? (__DATE__ [0] == 'M' ? 3 : 4) \
                                        : __DATE__ [2] == 'y' ? 5 \
                                        : __DATE__ [2] == 'n' ? 6 \
                                        : __DATE__ [2] == 'l' ? 7 \
                                        : __DATE__ [2] == 'g' ? 8 \
                                        : __DATE__ [2] == 'p' ? 9 \
                                        : __DATE__ [2] == 't' ? 10 \
                                        : __DATE__ [2] == 'v' ? 11 : 12)                                                
#define TEST_APP_BUILD_DAY              ((__DATE__ [4] == ' ' ? 0 : _DIGIT(__DATE__, 4)) * 10 + _DIGIT(__DATE__, 5))
#define TEST_APP_BUILD_HOURS            (10 * _DIGIT(__TIME__, 0) + _DIGIT(__TIME__, 1))
#define TEST_APP_BUILD_MINUTES          (10 * _DIGIT(__TIME__, 3) + _DIGIT(__TIME__, 4))
#define TEST_APP_BUILD_SECONDS          (10 * _DIGIT(__TIME__, 6) + _DIGIT(__TIME__, 7))










//------------------------------------------------------------------------------
// Test Function Enable
#define ENABLE_IP_DDR                   TRUE
#define ENABLE_IP_DMAC                  TRUE
#define ENABLE_IP_TIMER                 TRUE
#define ENABLE_IP_PWM                   TRUE
#define ENABLE_IP_I2C                   TRUE
#define ENABLE_IP_SPI                   TRUE
#define ENABLE_IP_GPIO                  TRUE
#define ENABLE_IP_UART                  TRUE
#define ENABLE_IP_CAN                   FALSE
#define ENABLE_IP_SF                    TRUE
#define ENABLE_IP_NAND                  TRUE
#define ENABLE_IP_SDC                   TRUE
#define ENABLE_IP_FPU                   FALSE
#define ENABLE_IP_CORE                  TRUE
#define ENABLE_IP_IPC                   TRUE
#define ENABLE_IP_INTC                  TRUE
#define ENABLE_IP_VDUMP                 TRUE

// Add Test Function

#define ENABLE_IP_DUMMY                 FALSE










//------------------------------------------------------------------------------
// Test Application Local Define

// Test Buff Zone Select
// If the following option is Disable, the buffer is in the Physical DDR area.
//#define __TEST_BUFF_BSS_ZONE__
#define __TEST_BUFF_STACK_ZONE__

#define TEST_PHY_DDR_BASE               (APACHE_DRAM_BASE+(1*MB)) // (remap size * 2)










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

typedef enum _TEST_LIST
{
    FPGA_IP_TEST_QUIT = 0,      ///< 0 Quit

    // Unit Test

    FPGA_IP_TEST_DDR,           ///< 1 - DDR Test   
    FPGA_IP_TEST_DMAC,          ///< 2 - DMAC Test
    FPGA_IP_TEST_TIMER,         ///< 3 - Timer Test
    FPGA_IP_TEST_PWM,           ///< 4 - PWM Test
    FPGA_IP_TEST_I2C,           ///< 5 - I2C Test
    FPGA_IP_TEST_SPI,           ///< 6 - SPI Test
    FPGA_IP_TEST_GPIO,          ///< 7 - GPIO Test     
    FPGA_IP_TEST_UART,          ///< 8 - UART Test
    FPGA_IP_TEST_CAN,           ///< 9 - CAN Test
    FPGA_IP_TEST_SF,            ///< a - sFlash Test
    FPGA_IP_TEST_NAND,          ///< b - Nand Test
    FPGA_IP_TEST_SDC,           ///< c - SDC Test
    FPGA_IP_TEST_FPU,           ///< d - FPU Test
    FPGA_IP_TEST_CORE,          ///< e - Core Benchmark Test
    
    FPGA_IP_TEST_IPC,           ///< f - IPC Test
    FPGA_IP_TEST_INTC,          ///< g - INTC Test
    FPGA_IP_TEST_VDUMP,         ///< h - VDUMP Test
    FPGA_IP_TEST_I,             ///< i - Reserved
    FPGA_IP_TEST_J,             ///< j - Reserved
    FPGA_IP_TEST_K,             ///< k - Reserved
    FPGA_IP_TEST_L,             ///< l - Reserved
    FPGA_IP_TEST_M,             ///< m - Reserved
    FPGA_IP_TEST_N,             ///< n - Reserved
    FPGA_IP_TEST_O,             ///< o - Reserved
    FPGA_IP_TEST_P,             ///< p - Reserved
    FPGA_IP_TEST_Q,             ///< q - Reserved
    FPGA_IP_TEST_R,             ///< r - Reserved
    FPGA_IP_TEST_S,             ///< s - Reserved
    FPGA_IP_TEST_T,             ///< t - Reserved
    FPGA_IP_TEST_U,             ///< u - Reserved
    FPGA_IP_TEST_V,             ///< v - Reserved
    FPGA_IP_TEST_W,             ///< w - Reserved
    FPGA_IP_TEST_X,             ///< x - Reserved
    FPGA_IP_TEST_Y,             ///< y - Reserved
    FPGA_IP_TEST_Z,             ///< z - Reserved

    MAX_OF_FPGA_IP_TEST
} eTEST_LIST;


/*
 *----------------------------
 *  Only FPGA Debug GPIO Port 
 *  0x90D01040 [11:8]
 *      -. PORT0[8]
 *      -. PORT1[9]
 *      -. PORT2[10] 
 *      -. PORT3[11]
 *----------------------------
 */
typedef enum
{
    DBG_GPIO_PORT0,
    DBG_GPIO_PORT1,
    DBG_GPIO_PORT2,
    DBG_GPIO_PORT3,

    DBG_MAX_OF_GPIO_PORT,
} eDBG_GPIO_PORT;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

// Test Main 
extern INT32 APACHE_TEST_APP_Main(void);


#if ENABLE_IP_DDR
// 1 - DDR Test Functions
extern INT32 APACHE_TEST_DDR_CUTMode(void);
#endif


#if ENABLE_IP_DMAC
// 2 - DMA Functions 
extern INT32 APACHE_TEST_DMA_CUTMode(void);
#endif


#if ENABLE_IP_TIMER
// 3 - TIMER Test Functions
extern INT32 APACHE_TEST_TIMER_CUTMode(void);
#endif


#if ENABLE_IP_PWM
// 4 - PWM Test Functions 
extern INT32 APACHE_TEST_PWM_CUTMode(void);
#endif


#if ENABLE_IP_I2C
// 5 - I2C Test Functions
extern INT32 APACHE_TEST_I2C_CUTMode(void);
#endif


#if ENABLE_IP_SPI
// 6 - SPI Test Functions
extern INT32 APACHE_TEST_SSP_CUTMode(void);
#endif


#if ENABLE_IP_GPIO
// 7 - GPIO Functions
extern INT32 APACHE_TEST_GPIO_CUTMode(void);
#endif


#if ENABLE_IP_UART
// 8 - UART Functions
extern INT32 APACHE_TEST_UART_CUTMode(void);
#endif


#if ENABLE_IP_CAN
// 9 - CAN Functions
extern INT32 APACHE_TEST_CAN_CUTMode(void);
#endif


#if ENABLE_IP_SF
// A - sFlash Functions
extern INT32 APACHE_TEST_SF_CUTMode(void);
#endif


#if ENABLE_IP_NAND
// B - Nand Functions
extern INT32 APACHE_TEST_NAND_CUTMode(void);
#endif


#if ENABLE_IP_SDC
// C - SDC Functions
extern INT32 APACHE_TEST_SDC_CUTMode(void);
#endif


#if ENABLE_IP_FPU
// D - FPU Test Functions
extern INT32 APACHE_TEST_FPU_CUTMode(void);
#endif


#if ENABLE_IP_CORE
// E - Core
extern INT32 APACHE_TEST_CORE_CUTMode(void);
#endif


#if ENABLE_IP_IPC
// F - IPC Test
extern INT32 APACHE_TEST_IPC_CUTMode(void);
#endif


#if ENABLE_IP_INTC
// G - GIC Test
extern INT32 APACHE_TEST_INTC_CUTMode(void);
#endif


#if ENABLE_IP_VDUMP
// H - VDUMP Test
extern INT32 APACHE_TEST_VDUMP_CUTMode(void);
#endif


/*
 *  I ~ Z
 *  Add Test Function
 */



// test_Func.c
extern INT32  APACHE_TEST_FUNC_CUTMode(void);

// test_Utils.c
extern void   APACHE_TEST_DebugGPIOToggle(UINT32 Port);
extern void   APACHE_TEST_DebugGPIOSet(UINT32 Port, UINT32 Level);
extern UINT32 APACHE_TEST_Display_InputValue(UINT32 MinNum, UINT32 MaxNum, char *Str);

extern INT32  APACHE_TEST_Asc2Int(char ch);
extern INT32  APACHE_TEST_AtoI(char *Str);

extern void   APACHE_TEST_GetArrowKey_Help(char* UpStr, char* DownStr, char* RightStr, char* LeftStr);
extern INT8   APACHE_TEST_GetArrowKey(INT8 buf);
extern INT8   APACHE_TEST_WaitKey(void);
extern BOOL   APACHE_TEST_ExitKey(void);
extern BOOL   APACHE_TEST_mTimeOut(UINT32 mSec);
extern void   APACHE_TEST_StopWatch(BOOL OnOff);

extern void   APACHE_TEST_MemSet(void* pDstBuff, UINT8 Value, UINT32 nLength);


#endif  /* __TEST_H__ */


/* End Of File */

