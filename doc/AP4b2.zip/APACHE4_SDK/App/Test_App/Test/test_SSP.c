/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_SPI










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    eSSP_CH        mSSP_TestCh;
    UINT32         mSSP_TestDiv;
    UINT32         mSSP_TestAddr;
    UINT32         mSSP_TestFlashSize;

    eSSP_SPH       mSSP_TestSPH;
    eSSP_SPO       mSSP_TestSPO;
    eSSP_ORDER     mSSP_TestOrder;
    
    BOOL           mSSP_MasterIsrEn;
    eDBG_GPIO_PORT mSSP_DebugGpioPort;
    BOOL           mSSP_DebugPortOn;
    BOOL           mSSP_DebugMsgOn;
} tSSPTEST_FLAG, *ptSSPTEST_FLAG;










/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/

#define TEST_CMD_sFlash_PAGE_PROGRAM                0x02
#define TEST_CMD_sFlash_RD_DATA                     0x03
#define TEST_CMD_sFlash_WR_DS                       0x04
#define TEST_CMD_sFlash_RD_STS                      0x05
#define TEST_CMD_sFlash_WR_EN                       0x06
#define TEST_CMD_sFlash_SECTOR_ERASE                0x20
#define TEST_CMD_sFlash_BLOCK_ERASE                 0xD8
#define TEST_CMD_sFlash_RD_IDENTIFICATION           0x9F

#define TEST_STS_WIP                                (0x1<<0)
#define TEST_STS_WEL                                (0x1<<1)

#define TEST_sFlash_BLOCK_SIZE                      (64*KB)
#define TEST_sFlash_SECTOR_SIZE                     (4*KB)
#define TEST_sFlash_PAGE_SIZE                       (256)











/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tSSPTEST_FLAG tSSPTestFlag; 
volatile tSSPTEST_FLAG tSSPTestFlag_Def = {
                                            SSP_CH0,
                                            0x02,
                                            0x0,
                                            (2*MB),
                                            
                                            SSP_SPH_HIGH,
                                            SSP_SPO_HIGH,
                                            SSP_MSB_FIRST,

                                            OFF,
                                            DBG_GPIO_PORT0,
                                            ON,
                                            OFF
                                           };


#if defined(__TEST_BUFF_BSS_ZONE__)
UINT8  gTestSSPwBuff[TEST_sFlash_PAGE_SIZE];
UINT8  gTestSSPrBuff[TEST_sFlash_PAGE_SIZE];

#elif defined(__TEST_BUFF_STACK_ZONE__)
// The buffer is inside the function.

#else
UINT8* gTestSSPwBuff = (UINT8*)(TEST_PHY_DDR_BASE);
UINT8* gTestSSPrBuff = (UINT8*)(TEST_PHY_DDR_BASE+TEST_sFlash_PAGE_SIZE);

#endif










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __test_ssp_display_buff(UINT8 *pBuff, UINT32 Size, UINT32 PageAddr)
{
    UINT32 i;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");	
    DEBUGMSG(MSGINFO, "\n>> PageAddr = 0x%08X", PageAddr);	
    for(i=0;i<Size;i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", PageAddr+i);	
        DEBUGMSG(MSGINFO, "%02X ", pBuff[i]);	
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");	
}


static UINT32 __test_ssp_get_memory_size(UINT8 Capacity)
{
    UINT32 nChipSize = 64*KB;
    UINT32 i;

    for(i = 0; i <= 8; i++)
    {
        if(Capacity == i)
        {
            break;
        }
        else
        {
            nChipSize = nChipSize * 2;
        }
    }

    return nChipSize;
}


static void __test_ssp_dummy_buff_marking(UINT8 *pAddr, UINT32 PageAddr)
{
    pAddr[0] = (PageAddr>>24 & 0xFF);
    pAddr[1] = (PageAddr>>16 & 0xFF);
    pAddr[2] = (PageAddr>>8  & 0xFF);
    pAddr[3] = (PageAddr     & 0xFF);

    pAddr[TEST_sFlash_PAGE_SIZE-4] = (PageAddr>>24 & 0xFF);
    pAddr[TEST_sFlash_PAGE_SIZE-3] = (PageAddr>>16 & 0xFF);
    pAddr[TEST_sFlash_PAGE_SIZE-2] = (PageAddr>>8  & 0xFF);
    pAddr[TEST_sFlash_PAGE_SIZE-1] = (PageAddr     & 0xFF);        
}


static void __test_ssp_dummy_buff(UINT8 *pAddr, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        pAddr[i] = i;
    }
}


static void __test_ssp_clear_buff(UINT8 *pAddr, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        pAddr[i] = 0;
    }
}


static UINT32 __test_ssp_compare_buff(UINT8 *pSrc, UINT8* pDes, UINT32 size)
{
    UINT32 i;
    UINT32 nErrCnt = 0;

    for(i=0; i<size; i++)
    {
        if(pSrc[i] != pDes[i])
        {
            nErrCnt++;
        }
    }

    if(nErrCnt)
        DEBUGMSG(MSGERR, " >> Compare Error Count - %d!\n", nErrCnt);	

    return nErrCnt;
}


static UINT8 __test_ssp_conv_order(UINT8 byte)
{
    UINT8 i;
    UINT8 byte_rev   = 0x0;
    const UINT8 BIT8[8]    = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
    const UINT8 BIT8REV[8] = {0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01};

    if(tSSPTestFlag.mSSP_TestOrder == SSP_MSB_FIRST)
    {
        byte_rev = byte;
    }
    else
    {
        for(i=0;i<8;i++)
        {
            if(byte&BIT8[i]) byte_rev |= BIT8REV[i];
        }
    }

    return byte_rev;
}


void APACHE_TEST_SSP_SetDebugPort(BOOL OnOff, eSSP_CH Ch)
{
    UINT32 Reg;

    Reg = REGRW32(APACHE_SYSCON_BASE, 0x1040);
    Reg &= ~(7<<16);

    if(OnOff == ON)
    {
        if(Ch == SSP_CH0)
            Reg |= (4<<16);
        else
            Reg |= (5<<16); 
    }
    
    REGRW32(APACHE_SYSCON_BASE, 0x1040) = Reg;
}


void APACHE_TEST_SSP_SetDebugLoopBack(BOOL OnOff)
{
    UINT32 Reg;

    Reg = REGRW32(APACHE_SYSCON_BASE, 0x1040);
    Reg &= ~(1<<13);

    if(OnOff == ON)
        Reg |= (1<<13); 
    
    REGRW32(APACHE_SYSCON_BASE, 0x1040) = Reg;
}


UINT32 APACHE_TEST_SSP_GetClock(UINT32 Div)
{
    if(Div < 2)
        Div = 2;

    return (ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_SSPI, CMD_END)/Div);    
}


void APACHE_TEST_SSP_SelectClock(void)
{
    INT8 buf;
    UINT32 nHz;    
    UINT32 Div = tSSPTestFlag.mSSP_TestDiv;  

    
    APACHE_TEST_GetArrowKey_Help("Clock Up", "Clock Down", NULL, NULL);
    DEBUGMSG(MSGINFO, "  > Clock Select    : %06d-KHz(%02d)", (APACHE_TEST_SSP_GetClock(Div)/KHZ), Div);
 
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }
            
            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(Div > 0x02)
                    --Div;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(Div < 0xFF)
                    ++Div;
            }
            
            nHz = APACHE_TEST_SSP_GetClock(Div);
            DEBUGMSG(MSGINFO, "\r  > Clock Select    : %06d-KHz(%02d)", (nHz/KHZ), Div);
        }
    }

    tSSPTestFlag.mSSP_TestDiv = Div;
}


void APACHE_TEST_SSP_Isr(UINT32 irq)
{
    INT32 Sts;
    UINT8 Buff;    
    eSSP_CH Ch = (eSSP_CH)(irq - IRQ_NUM_SPI0);


    // ISR Status Check and Clear  
    Sts = ncLib_SSP_Control(GCMD_SSP_GET_INT_STS, Ch, CMD_END);
    if(Sts&(1<<1))
    {
        // Slave Mode
        ncLib_SSP_Read(Ch, &Buff, 1);

        if(Buff != 0x00)
            ncLib_SSP_Write(Ch, &Buff, 1);
        
        if(tSSPTestFlag.mSSP_DebugMsgOn == ON)
        {
            DEBUGMSG(MSGINFO, " > S : 0x%02x\n", Buff);
        }
    }
    else
    {
        // Master Mode
        //DEBUGMSG(MSGINFO, " > M\n");
    }


    // Toggle - Debug Gpio Port
    APACHE_TEST_DebugGPIOToggle(tSSPTestFlag.mSSP_DebugGpioPort+Ch);
}


void APACHE_TEST_SSP_Isr_Init(eSSP_CH Ch)
{
    // Init - Debug Gpio Port
    APACHE_TEST_DebugGPIOSet(tSSPTestFlag.mSSP_DebugGpioPort+Ch, GPIO_LOW);

    
    // Register SPI Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_REGISTER_INT
                      ,IRQ_NUM_SPI0 + Ch
                      ,(PrHandler)APACHE_TEST_SSP_Isr
                      ,CMD_END);
}


void APACHE_TEST_SSP_Isr_DeInit(eSSP_CH Ch)
{
    // Unregister SPI Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT
                      ,IRQ_NUM_SPI0 + Ch
                      ,CMD_END);
}


void APACHE_TEST_SSP_Init(eSSP_CH Ch, ptSSP_PARAM ptSSPParam)
{
    INT32 ret;
    

    // Open Synchronous Serial Port Interface. (Only SPI Interface Support)
    ncLib_SSP_Open();	



    // Set SSP Channel Operation  
    ptSSPParam->mDataWidth = SSP_DS_8BIT;
    ptSSPParam->mBitRate   = APACHE_TEST_SSP_GetClock(tSSPTestFlag.mSSP_TestDiv);
    ptSSPParam->mSPO       = tSSPTestFlag.mSSP_TestSPO;
    ptSSPParam->mSPH       = tSSPTestFlag.mSSP_TestSPH;
    ptSSPParam->mOrder     = tSSPTestFlag.mSSP_TestOrder;
    

    // Enable Interrupt 
    if(ptSSPParam->mIntEn == ENABLE)
        APACHE_TEST_SSP_Isr_Init(Ch);

    
    // Init SSP Channel 
    ret = ncLib_SSP_Control(GCMD_SSP_INIT_CH, Ch, ptSSPParam, CMD_END);	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "SSP Init Error!\n");
    } 
}


void APACHE_TEST_SSP_DeInit(eSSP_CH Ch, ptSSP_PARAM ptSSPParam)
{
    INT32 ret;


    // Disable Interrupt 
    if(ptSSPParam->mIntEn == ENABLE)
        APACHE_TEST_SSP_Isr_DeInit(Ch);


    // Deinit SSP Channel
    ret = ncLib_SSP_Control(GCMD_SSP_DEINIT_CH, Ch, CMD_END);	
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "SSP DeInit Error!\n");
    } 


    // Close Synchronous Serial Port Interface.
    ncLib_SSP_Close();	
}


void APACHE_TEST_SSP_SlaveMode(eSSP_CH Master_Ch)
{
    tSSP_PARAM tSSPParam_Master;      
    tSSP_PARAM tSSPParam_Slave;   
    eSSP_CH    Slave_Ch;
    
    UINT32 i;
    UINT32 nErrCnt;
    UINT32 Div_Org;

#ifdef __TEST_BUFF_STACK_ZONE__   
    UINT8 wBuff[TEST_sFlash_PAGE_SIZE];
    UINT8 rBuff[TEST_sFlash_PAGE_SIZE];
#else
    UINT8* wBuff = (UINT8*)&gTestSSPwBuff[0];
    UINT8* rBuff = (UINT8*)&gTestSSPrBuff[0];
#endif
    
    
    DEBUGMSG(MSGINFO, "[SSP_TEST] Slave Mode\n");



    // Limit Slave Mode Clock  (DIV > 8)
    Div_Org = tSSPTestFlag.mSSP_TestDiv;
    if(tSSPTestFlag.mSSP_TestDiv < 9)
        tSSPTestFlag.mSSP_TestDiv = 9;



    // FPGA Debug SSP LoopBack Mode
    APACHE_TEST_SSP_SetDebugLoopBack(ON);



    // Init SSP Channel (Master Mode)
    tSSPParam_Master.mIntEn = tSSPTestFlag.mSSP_MasterIsrEn;
    tSSPParam_Master.mMode  = SSP_MODE_MASTER;
    APACHE_TEST_SSP_Init(Master_Ch, &tSSPParam_Master);



    // Init SSP Channel (Slave Mode)
    Slave_Ch = (Master_Ch)?SSP_CH0:SSP_CH1;
    tSSPParam_Slave.mIntEn = ENABLE;
    tSSPParam_Slave.mMode  = SSP_MODE_SLAVE;
    APACHE_TEST_SSP_Init(Slave_Ch, &tSSPParam_Slave);




    // Write Dummy Data and Clear Buff
    __test_ssp_dummy_buff(wBuff, TEST_sFlash_PAGE_SIZE);
    __test_ssp_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);

    for(i=1; i<TEST_sFlash_PAGE_SIZE; i++)
    {
        if(tSSPTestFlag.mSSP_DebugMsgOn == ON)
        {
            DEBUGMSG(MSGINFO, " > W : 0x%02X\n", wBuff[i]);
            tSSPTestFlag.mSSP_DebugMsgOn = APACHE_TEST_WaitKey();
        }

        ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Master_Ch, CMD_END);
        ncLib_SSP_Write(Master_Ch, &wBuff[i], 1);	
        ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Master_Ch, CMD_END);	
        
        if(tSSPTestFlag.mSSP_DebugMsgOn == ON)
        {
            tSSPTestFlag.mSSP_DebugMsgOn = APACHE_TEST_WaitKey();
        }

        ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Master_Ch, CMD_END);
        ncLib_SSP_Read(Master_Ch, &rBuff[i], 1);	
        ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Master_Ch, CMD_END);	
        if(tSSPTestFlag.mSSP_DebugMsgOn == ON)
        {
            DEBUGMSG(MSGINFO, " > R : 0x%02X\n", rBuff[i]);
            tSSPTestFlag.mSSP_DebugMsgOn = APACHE_TEST_WaitKey();
        }
        
    }
	

    // Compare
    nErrCnt = __test_ssp_compare_buff(rBuff, wBuff, TEST_sFlash_PAGE_SIZE);
    if(!nErrCnt)
    {
        DEBUGMSG(MSGINFO, " >> Data Compare Success\n");		
    }
    else
    {
        __test_ssp_display_buff(wBuff, TEST_sFlash_PAGE_SIZE, 0x0);	
        __test_ssp_display_buff(rBuff, TEST_sFlash_PAGE_SIZE, 0x0);	
    }


    // DeInit SSP Channel (Slave Mode)
    APACHE_TEST_SSP_DeInit(Slave_Ch, &tSSPParam_Slave);


    // DeInit SSP Channel (Master Mode)
    APACHE_TEST_SSP_DeInit(Master_Ch, &tSSPParam_Master);


    // FPGA Debug SSP LoopBack Mode
    APACHE_TEST_SSP_SetDebugLoopBack(OFF);


    // roll-Back Clock 
    tSSPTestFlag.mSSP_TestDiv = Div_Org;
    
}


void APACHE_TEST_SSP_sFlash_StartAddrChange(void)
{
    tSSPTestFlag.mSSP_TestAddr = APACHE_TEST_Display_InputValue(0x0, (tSSPTestFlag.mSSP_TestFlashSize-TEST_sFlash_BLOCK_SIZE), "Change TestAddr");
}


UINT8 APACHE_TEST_SSP_sFlash_ReadStatusCmd(eSSP_CH Ch)
{
    UINT8 Command;
    UINT8 Status;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command = __test_ssp_conv_order(TEST_CMD_sFlash_RD_STS);
    ncLib_SSP_Write(Ch, &Command, 1);	
    ncLib_SSP_Read(Ch, &Status, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	

    return __test_ssp_conv_order(Status);
}


void APACHE_TEST_SSP_sFlash_WriteDisableCmd(eSSP_CH Ch)
{
    UINT8 Command;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command = __test_ssp_conv_order(TEST_CMD_sFlash_WR_DS);
    ncLib_SSP_Write(Ch, &Command, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	
}


void APACHE_TEST_SSP_sFlash_WriteEnableCmd(eSSP_CH Ch)
{
    UINT8 Command;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	
    
    Command = __test_ssp_conv_order(TEST_CMD_sFlash_WR_EN);
    ncLib_SSP_Write(Ch, &Command, 1);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	

    while( (APACHE_TEST_SSP_sFlash_ReadStatusCmd(Ch) & TEST_STS_WEL) != TEST_STS_WEL ) ;
}


void APACHE_TEST_SSP_sFlash_WaitWIPCmd(eSSP_CH Ch)
{
    while(APACHE_TEST_SSP_sFlash_ReadStatusCmd(Ch) & TEST_STS_WIP) ;
}


void APACHE_TEST_SSP_sFlash_ReadIDCmd(eSSP_CH Ch, UINT8 *pBuff)
{
    UINT8 Command;
    UINT32 i;

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command = __test_ssp_conv_order(TEST_CMD_sFlash_RD_IDENTIFICATION);
    ncLib_SSP_Write(Ch, &Command, 1);	
    ncLib_SSP_Read(Ch, pBuff, 3);		

    for(i=0; i<3; i++)
        pBuff[i] = __test_ssp_conv_order(pBuff[i]);

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);		
}


void APACHE_TEST_SSP_sFlash_SectorEraseCmd(eSSP_CH Ch, UINT32 SectorAddr)
{
    UINT8 Command[4];

    APACHE_TEST_SSP_sFlash_WaitWIPCmd(Ch);
    APACHE_TEST_SSP_sFlash_WriteEnableCmd(Ch);


    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command[0] = __test_ssp_conv_order(TEST_CMD_sFlash_SECTOR_ERASE);
    Command[1] = __test_ssp_conv_order((SectorAddr>>16 & 0xFF));
    Command[2] = __test_ssp_conv_order((SectorAddr>>8  & 0xFF));
    Command[3] = __test_ssp_conv_order((SectorAddr     & 0xFF));
    ncLib_SSP_Write(Ch, Command, 4);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	


    APACHE_TEST_SSP_sFlash_WaitWIPCmd(Ch);
    APACHE_TEST_SSP_sFlash_WriteDisableCmd(Ch);
}


void APACHE_TEST_SSP_sFlash_BlockEraseCmd(eSSP_CH Ch, UINT32 BlockAddr)
{
    UINT8 Command[4];

    APACHE_TEST_SSP_sFlash_WaitWIPCmd(Ch);
    APACHE_TEST_SSP_sFlash_WriteEnableCmd(Ch);


    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command[0] = __test_ssp_conv_order(TEST_CMD_sFlash_BLOCK_ERASE);
    Command[1] = __test_ssp_conv_order((BlockAddr>>16 & 0xFF));
    Command[2] = __test_ssp_conv_order((BlockAddr>>8  & 0xFF));
    Command[3] = __test_ssp_conv_order((BlockAddr     & 0xFF));
    ncLib_SSP_Write(Ch, Command, 4);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	


    APACHE_TEST_SSP_sFlash_WaitWIPCmd(Ch);
    APACHE_TEST_SSP_sFlash_WriteDisableCmd(Ch);
}


void APACHE_TEST_SSP_sFlash_WritePageCmd(eSSP_CH Ch, UINT32 PageAddr, UINT8 *pBuff)
{
    UINT8 Command[4];
    

    APACHE_TEST_SSP_sFlash_WaitWIPCmd(Ch);
    APACHE_TEST_SSP_sFlash_WriteEnableCmd(Ch);


    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command[0] = __test_ssp_conv_order(TEST_CMD_sFlash_PAGE_PROGRAM);
    Command[1] = __test_ssp_conv_order((PageAddr>>16 & 0xFF));
    Command[2] = __test_ssp_conv_order((PageAddr>>8  & 0xFF));
    Command[3] = __test_ssp_conv_order((PageAddr     & 0xFF));
    ncLib_SSP_Write(Ch, Command, 4);	
    ncLib_SSP_Write(Ch, pBuff, TEST_sFlash_PAGE_SIZE);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	


    APACHE_TEST_SSP_sFlash_WaitWIPCmd(Ch);
    APACHE_TEST_SSP_sFlash_WriteDisableCmd(Ch);


}


void APACHE_TEST_SSP_sFlash_ReadPageCmd(eSSP_CH Ch, UINT32 PageAddr, UINT8 *pBuff)
{
    UINT8 Command[4];

    ncLib_SSP_Control(GCMD_SSP_CS_ENABLE_CH, Ch, CMD_END);	

    Command[0] = __test_ssp_conv_order(TEST_CMD_sFlash_RD_DATA);
    Command[1] = __test_ssp_conv_order((PageAddr>>16 & 0xFF));
    Command[2] = __test_ssp_conv_order((PageAddr>>8  & 0xFF));
    Command[3] = __test_ssp_conv_order((PageAddr     & 0xFF));
    ncLib_SSP_Write(Ch, Command, 4);		
    ncLib_SSP_Read(Ch, pBuff, TEST_sFlash_PAGE_SIZE);	

    ncLib_SSP_Control(GCMD_SSP_CS_DISABLE_CH, Ch, CMD_END);	
}



void APACHE_TEST_SSP_sFlash_ReadID(eSSP_CH Ch)
{
    tSSP_PARAM tSSPParam;    
    UINT8 rRDID[3];
    

    DEBUGMSG(MSGINFO, "[SSP_TEST] Read Identification\n");


    // Init SSP Channel
    tSSPParam.mIntEn = tSSPTestFlag.mSSP_MasterIsrEn;
    tSSPParam.mMode  = SSP_MODE_MASTER;
    APACHE_TEST_SSP_Init(Ch, &tSSPParam);


    // Read ID
    APACHE_TEST_SSP_sFlash_ReadIDCmd(Ch, rRDID);
    tSSPTestFlag.mSSP_TestFlashSize = __test_ssp_get_memory_size((rRDID[2]&0xf));



    // Display Spi-Flash ID
    DEBUGMSG(MSGINFO, " Spi-Flash >> \n");
    DEBUGMSG(MSGINFO, "  manufacturer ID : 0x%02X\n", rRDID[0]);
    DEBUGMSG(MSGINFO, "  memory type     : 0x%02X\n", rRDID[1]);
    DEBUGMSG(MSGINFO, "  memory density  : 0x%02X\n", rRDID[2]);
    DEBUGMSG(MSGINFO, "  memory size     : %d KB\n", tSSPTestFlag.mSSP_TestFlashSize/KB);


    // Deinit SSP Channel
    APACHE_TEST_SSP_DeInit(Ch, &tSSPParam);
    
}


void APACHE_TEST_SSP_sFlash_SectorErase(eSSP_CH Ch)
{
    tSSP_PARAM tSSPParam;      
    UINT32 i;
    UINT32 Addr;
    UINT32 nChipSize;
    UINT32 nErrCnt;

#ifdef __TEST_BUFF_STACK_ZONE__   
    UINT8 rBuff[TEST_sFlash_PAGE_SIZE];
#else
    UINT8* rBuff = (UINT8*)&gTestSSPrBuff[0];  
#endif


    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Sector Erase -> Read Page -> Check Data (0xFF)\n");


    // Init SSP Channel
    tSSPParam.mIntEn = tSSPTestFlag.mSSP_MasterIsrEn;
    tSSPParam.mMode  = SSP_MODE_MASTER;
    APACHE_TEST_SSP_Init(Ch, &tSSPParam);



    // Check Test Spi-Flash Size
    nChipSize = tSSPTestFlag.mSSP_TestFlashSize;
    DEBUGMSG(MSGINFO, " sFlash memory size : %d KB\n", nChipSize/KB);



    // Spi-Flash Block Erase
    for(Addr = tSSPTestFlag.mSSP_TestAddr; Addr < nChipSize; Addr += TEST_sFlash_SECTOR_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Sector Erase  : 0x%08x", Addr);
        APACHE_TEST_SSP_sFlash_SectorEraseCmd(Ch, Addr);
    }
    DEBUGMSG(MSGINFO, "\n");



    // Check Erased Spi-Flash 
    for(Addr = tSSPTestFlag.mSSP_TestAddr, nErrCnt = 0; Addr < nChipSize; Addr += TEST_sFlash_PAGE_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Page Read     : 0x%08x", Addr);
        APACHE_TEST_SSP_sFlash_ReadPageCmd(Ch, Addr, rBuff);

        for(i=0; i<TEST_sFlash_PAGE_SIZE; i++)
        {
            if(rBuff[i] != 0xFF)
            {
                nErrCnt++;
            }
        }
    }
    DEBUGMSG(MSGINFO, "\n");



    // Display Test Result
    if(nErrCnt == 0)
        DEBUGMSG(MSGINFO, " Erase Test Success!\n");
    else
        DEBUGMSG(MSGINFO, " Erase Test Fail! (%d)\n", nErrCnt);



    // Deinit SSP Channel
    APACHE_TEST_SSP_DeInit(Ch, &tSSPParam);

}


void APACHE_TEST_SSP_sFlash_BlockErase(eSSP_CH Ch)
{
    tSSP_PARAM tSSPParam;    
    UINT32 i;
    UINT32 Addr;
    UINT32 nChipSize;
    UINT32 nErrCnt;

#ifdef __TEST_BUFF_STACK_ZONE__   
    UINT8 rBuff[TEST_sFlash_PAGE_SIZE];
#else
    UINT8* rBuff = (UINT8*)&gTestSSPrBuff[0];  
#endif

    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Block Erase -> Read Page -> Check Data (0xFF)\n");



    // Init SSP Channel
    tSSPParam.mIntEn = tSSPTestFlag.mSSP_MasterIsrEn;
    tSSPParam.mMode  = SSP_MODE_MASTER;
    APACHE_TEST_SSP_Init(Ch, &tSSPParam);



    // Check Test Spi-Flash Size
    nChipSize = tSSPTestFlag.mSSP_TestFlashSize;
    DEBUGMSG(MSGINFO, " sFlash memory size     : %d KB\n", nChipSize/KB);



    // Spi-Flash Block Erase
    for(Addr = tSSPTestFlag.mSSP_TestAddr; Addr < nChipSize; Addr += TEST_sFlash_BLOCK_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Block Erase : 0x%08x", Addr);
        APACHE_TEST_SSP_sFlash_BlockEraseCmd(Ch, Addr);
    }
    DEBUGMSG(MSGINFO, "\n");



    // Check Erased Chip 
    for(Addr = tSSPTestFlag.mSSP_TestAddr, nErrCnt = 0; Addr < nChipSize; Addr += TEST_sFlash_PAGE_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", Addr);
        APACHE_TEST_SSP_sFlash_ReadPageCmd(Ch, Addr, rBuff);

        for(i=0; i<TEST_sFlash_PAGE_SIZE; i++)
        {
            if(rBuff[i] != 0xFF)
            {
                nErrCnt++;
            }
        }
    }
    DEBUGMSG(MSGINFO, "\n");


    // Display Test Result
    if(nErrCnt == 0)
        DEBUGMSG(MSGINFO, " Erase Test Success!\n");
    else
        DEBUGMSG(MSGINFO, " Erase Test Fail! (%d)\n", nErrCnt);



    // Deinit SSP Channel
    APACHE_TEST_SSP_DeInit(Ch, &tSSPParam);

}


void APACHE_TEST_SSP_sFlash_WritePage(eSSP_CH Ch)
{
    tSSP_PARAM tSSPParam;    
    UINT32 PageAddr = tSSPTestFlag.mSSP_TestAddr;

#ifdef __TEST_BUFF_STACK_ZONE__   
    UINT8  wBuff[TEST_sFlash_PAGE_SIZE];
#else
    UINT8* wBuff = (UINT8*)&gTestSSPwBuff[0];  
#endif


    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Page Write\n");



    // Init SSP Channel
    tSSPParam.mIntEn = tSSPTestFlag.mSSP_MasterIsrEn;
    tSSPParam.mMode  = SSP_MODE_MASTER;
    APACHE_TEST_SSP_Init(Ch, &tSSPParam);



    // Generate Write Data	
    __test_ssp_dummy_buff(wBuff, TEST_sFlash_PAGE_SIZE);
    __test_ssp_dummy_buff_marking(wBuff, PageAddr);



    // Spi-Flash Sector Erase
    APACHE_TEST_SSP_sFlash_SectorEraseCmd(Ch, PageAddr);

    

    // Spi-Flash Page Write
    APACHE_TEST_SSP_sFlash_WritePageCmd(Ch, PageAddr, wBuff);



    // Display Data
    __test_ssp_display_buff(wBuff, TEST_sFlash_PAGE_SIZE, PageAddr);


  
    // Deinit SSP Channel
    APACHE_TEST_SSP_DeInit(Ch, &tSSPParam);
}


void APACHE_TEST_SSP_sFlash_ReadPage(eSSP_CH Ch)
{
    tSSP_PARAM tSSPParam;    
    UINT32 PageAddr = tSSPTestFlag.mSSP_TestAddr;

#ifdef __TEST_BUFF_STACK_ZONE__   
    UINT8 rBuff[TEST_sFlash_PAGE_SIZE];
#else
    UINT8* rBuff = (UINT8*)&gTestSSPrBuff[0];  
#endif


    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Page Read\n");



    // Init SSP Channel
    tSSPParam.mIntEn = tSSPTestFlag.mSSP_MasterIsrEn;
    tSSPParam.mMode  = SSP_MODE_MASTER;
    APACHE_TEST_SSP_Init(Ch, &tSSPParam);



    // Spi-Flash Page Read
    APACHE_TEST_SSP_sFlash_ReadPageCmd(Ch, PageAddr, rBuff);



    // Display Data
    __test_ssp_display_buff(rBuff, TEST_sFlash_PAGE_SIZE, PageAddr);



    // Deinit SSP Channel
    APACHE_TEST_SSP_DeInit(Ch, &tSSPParam);
}


void APACHE_TEST_SSP_sFlash_SectorErase_WritePage_ReadPage_Compare(eSSP_CH Ch)
{
    tSSP_PARAM tSSPParam;   
    UINT32 PageAddr = 0;
    UINT32 Offset;
    UINT32 nChipSize;
    UINT32 nErrCnt = 0;

#ifdef __TEST_BUFF_STACK_ZONE__   
    UINT8 wBuff[TEST_sFlash_PAGE_SIZE];
    UINT8 rBuff[TEST_sFlash_PAGE_SIZE];
#else
    UINT8* wBuff = (UINT8*)&gTestSSPwBuff[0];
    UINT8* rBuff = (UINT8*)&gTestSSPrBuff[0];
#endif


    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Sector Erase -> Program Page -> Read Page -> Compare\n");



    // Init SSP Channel
    tSSPParam.mIntEn = tSSPTestFlag.mSSP_MasterIsrEn;
    tSSPParam.mMode  = SSP_MODE_MASTER;
    APACHE_TEST_SSP_Init(Ch, &tSSPParam);



    // Check Test Spi-Flash Size
    nChipSize = tSSPTestFlag.mSSP_TestFlashSize;
    DEBUGMSG(MSGINFO, " sFlash memory size     : %d KB\n", nChipSize/KB);



    // Generate Write Test Data
    __test_ssp_dummy_buff(wBuff, TEST_sFlash_PAGE_SIZE);
    __test_ssp_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);



    // Sector Erase -> Page Write
    for(PageAddr = tSSPTestFlag.mSSP_TestAddr; PageAddr < nChipSize; PageAddr += TEST_sFlash_SECTOR_SIZE)
    {
        APACHE_TEST_SSP_sFlash_SectorEraseCmd(Ch, PageAddr);

        for(Offset = 0; Offset < TEST_sFlash_SECTOR_SIZE; Offset += TEST_sFlash_PAGE_SIZE)
        {
            DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", PageAddr+Offset);
            __test_ssp_dummy_buff_marking(wBuff,PageAddr+Offset);
            APACHE_TEST_SSP_sFlash_WritePageCmd(Ch, PageAddr+Offset, wBuff);
        }
    }
    DEBUGMSG(MSGINFO, "\n");



    // Page Read -> Compare		
    for(PageAddr = tSSPTestFlag.mSSP_TestAddr; PageAddr < nChipSize; PageAddr += TEST_sFlash_PAGE_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", PageAddr);
        __test_ssp_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);	
        APACHE_TEST_SSP_sFlash_ReadPageCmd(Ch, PageAddr, rBuff);

        __test_ssp_dummy_buff_marking(wBuff, PageAddr);
        nErrCnt+=__test_ssp_compare_buff(rBuff, wBuff, TEST_sFlash_PAGE_SIZE);
    }
    DEBUGMSG(MSGINFO, "\n");



    // Display Data
    __test_ssp_display_buff(rBuff, TEST_sFlash_PAGE_SIZE, (PageAddr-TEST_sFlash_PAGE_SIZE));	
    if(!nErrCnt)
        DEBUGMSG(MSGERR, " >> Data Compare Success\n");		



    // Deinit SSP Channel
    APACHE_TEST_SSP_DeInit(Ch, &tSSPParam);
}


void APACHE_TEST_SSP_sFlash_BlockErase_WritePage_ReadPage_Compare(eSSP_CH Ch)
{
    tSSP_PARAM tSSPParam;    
    UINT32 PageAddr = 0;
    UINT32 Offset;
    UINT32 nChipSize;
    UINT32 nErrCnt = 0;

#ifdef __TEST_BUFF_STACK_ZONE__   
    UINT8 wBuff[TEST_sFlash_PAGE_SIZE];
    UINT8 rBuff[TEST_sFlash_PAGE_SIZE];
#else
    UINT8* wBuff = (UINT8*)&gTestSSPwBuff[0];
    UINT8* rBuff = (UINT8*)&gTestSSPrBuff[0];
#endif


    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Block Erase -> Program Page -> Read Page -> Compare\n");



    // Init SSP Channel
    tSSPParam.mIntEn = tSSPTestFlag.mSSP_MasterIsrEn;
    tSSPParam.mMode  = SSP_MODE_MASTER;
    APACHE_TEST_SSP_Init(Ch, &tSSPParam);



    // Check sflash Size
    nChipSize = tSSPTestFlag.mSSP_TestFlashSize;
    DEBUGMSG(MSGINFO, " sFlash memory size     : %d KB\n", nChipSize/KB);



    // Generate Write Test Data
    __test_ssp_dummy_buff(wBuff, TEST_sFlash_PAGE_SIZE);
    __test_ssp_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);



    // Block Erase -> Page Write	
    for(PageAddr = tSSPTestFlag.mSSP_TestAddr; PageAddr < nChipSize; PageAddr += TEST_sFlash_BLOCK_SIZE)
    {
        APACHE_TEST_SSP_sFlash_BlockEraseCmd(Ch, PageAddr);

        for(Offset = 0; Offset < TEST_sFlash_BLOCK_SIZE; Offset += TEST_sFlash_PAGE_SIZE)
        {
            DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", PageAddr+Offset);
            __test_ssp_dummy_buff_marking(wBuff,PageAddr+Offset);
            APACHE_TEST_SSP_sFlash_WritePageCmd(Ch, PageAddr+Offset, wBuff);
        }
    }
    DEBUGMSG(MSGINFO, "\n");



    // Page Read -> Compare		
    for(PageAddr = tSSPTestFlag.mSSP_TestAddr; PageAddr < nChipSize; PageAddr += TEST_sFlash_PAGE_SIZE)
    {
        DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", PageAddr);
        __test_ssp_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);	
        APACHE_TEST_SSP_sFlash_ReadPageCmd(Ch, PageAddr, rBuff);

        __test_ssp_dummy_buff_marking(wBuff, PageAddr);
        nErrCnt+=__test_ssp_compare_buff(rBuff, wBuff, TEST_sFlash_PAGE_SIZE);
    }
    DEBUGMSG(MSGINFO, "\n");



    // Display Data
    __test_ssp_display_buff(rBuff, TEST_sFlash_PAGE_SIZE, (PageAddr-TEST_sFlash_PAGE_SIZE));	
    if(!nErrCnt)
        DEBUGMSG(MSGERR, " >> Data Compare Success\n");		



    // Deinit SSP Channel
    APACHE_TEST_SSP_DeInit(Ch, &tSSPParam);
}


void APACHE_TEST_SSP_sFlash_BitRateChange(eSSP_CH Ch)
{
    tSSP_PARAM tSSPParam;    
    UINT32 Div;
    UINT32 nHz;

    UINT8 rRDID[3];
    UINT32 PageAddr = 0;
    UINT32 Offset;
    UINT32 nChipSize;
    UINT32 nErrCnt = 0;

#ifdef __TEST_BUFF_STACK_ZONE__   
    UINT8 wBuff[TEST_sFlash_PAGE_SIZE];
    UINT8 rBuff[TEST_sFlash_PAGE_SIZE];
#else
    UINT8* wBuff = (UINT8*)&gTestSSPwBuff[0];
    UINT8* rBuff = (UINT8*)&gTestSSPrBuff[0];
#endif


    DEBUGMSG(MSGINFO, "\n[SSP_TEST] Bitrate Change\n");



    // Init SSP Channel
    tSSPParam.mIntEn = tSSPTestFlag.mSSP_MasterIsrEn;
    tSSPParam.mMode  = SSP_MODE_MASTER;
    APACHE_TEST_SSP_Init(Ch, &tSSPParam);



    // Generate Write Data
    __test_ssp_dummy_buff(wBuff, TEST_sFlash_PAGE_SIZE);
    __test_ssp_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);



    for(Div = tSSPTestFlag.mSSP_TestDiv; Div < 0xFF; Div++)
    {	
        // Set Clock (Hz)
        nHz = APACHE_TEST_SSP_GetClock(Div);
        ncLib_SSP_Control(GCMD_SSP_SET_BITRATE_CH, Ch, nHz, CMD_END);



        // Read Spi-Flash ID
        APACHE_TEST_SSP_sFlash_ReadIDCmd(Ch, rRDID);
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " sFlash ID (%05dKHz, %02x) : 0x%02x 0x%02x 0x%02x\n", (nHz/KHZ), Div, rRDID[0], rRDID[1], rRDID[2]);
        nChipSize = __test_ssp_get_memory_size((rRDID[2]&0xf));
        DEBUGMSG(MSGINFO, " sFlash memory size : %d KB\n", nChipSize/KB);



        // Block Erase -> Page Write
        for(PageAddr = tSSPTestFlag.mSSP_TestAddr; PageAddr < nChipSize; PageAddr += TEST_sFlash_BLOCK_SIZE)
        {
            APACHE_TEST_SSP_sFlash_BlockEraseCmd(Ch, PageAddr);

            for(Offset = 0; Offset < TEST_sFlash_BLOCK_SIZE; Offset += TEST_sFlash_PAGE_SIZE)
            {
                DEBUGMSG(MSGINFO, "\r  Page Write  : 0x%08x", PageAddr+Offset);
                __test_ssp_dummy_buff_marking(wBuff,PageAddr+Offset);
                APACHE_TEST_SSP_sFlash_WritePageCmd(Ch, PageAddr+Offset, wBuff);
            }
        }
        DEBUGMSG(MSGINFO, "\n");



        // Page Read -> Compare
        for(PageAddr = tSSPTestFlag.mSSP_TestAddr; PageAddr < nChipSize; PageAddr += TEST_sFlash_PAGE_SIZE)
        {
            DEBUGMSG(MSGINFO, "\r  Page Read   : 0x%08x", PageAddr);
            __test_ssp_clear_buff(rBuff, TEST_sFlash_PAGE_SIZE);	
            APACHE_TEST_SSP_sFlash_ReadPageCmd(Ch, PageAddr, rBuff);

            __test_ssp_dummy_buff_marking(wBuff, PageAddr);
            nErrCnt+=__test_ssp_compare_buff(rBuff, wBuff, TEST_sFlash_PAGE_SIZE);
        }
        DEBUGMSG(MSGINFO, "\n");

        if(!nErrCnt)
            DEBUGMSG(MSGERR, " >> Data Compare Success\n");		
    }



    // Deinit SSP Channel
    APACHE_TEST_SSP_DeInit(Ch, &tSSPParam);	
}


INT32 APACHE_TEST_SSP_CUTMode(void)
{
    INT32 select;
    char buf[16];
    eSSP_CH Ch;


    // Default Init Variable
    tSSPTestFlag = tSSPTestFlag_Def;

    
    // Debug Port Enable
    APACHE_TEST_SSP_SetDebugPort(ON, tSSPTestFlag.mSSP_TestCh);


    while(1)
    {
        Ch = tSSPTestFlag.mSSP_TestCh;
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - SSP       				   \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " Standard SPI Controller : Read & Write Support             \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> SSP: Read Serial Flash ID						       \n");
        DEBUGMSG(MSGINFO, " <2> SSP: Sector Erase Test                                 \n");
        DEBUGMSG(MSGINFO, " <3> SSP: Block Erase Test                                  \n");
        DEBUGMSG(MSGINFO, " <4> SSP: Page Write Test                                   \n");
        DEBUGMSG(MSGINFO, " <5> SSP: Page Read Test                                    \n");		
        DEBUGMSG(MSGINFO, " <6> SSP: Sector Erase -> Write Page -> Read Page -> Compare\n");
        DEBUGMSG(MSGINFO, " <7> SSP: Block  Erase -> Write Page -> Read Page -> Compare\n");
        DEBUGMSG(MSGINFO, " <8> SSP: Bit-rate change Test                              \n");
        DEBUGMSG(MSGINFO, " <9> SSP: Slave Mode Test                                   \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <A> SPI Channel Change  : CH-%d                            \n", Ch); 
        DEBUGMSG(MSGINFO, " <B> BitRate Change      : %d KHz                           \n", APACHE_TEST_SSP_GetClock(tSSPTestFlag.mSSP_TestDiv)/KHZ);  
        DEBUGMSG(MSGINFO, " <C> Test Area Change    : 0x%06X                           \n", tSSPTestFlag.mSSP_TestAddr);     
        DEBUGMSG(MSGINFO, " <D> SPH Change          : SPH_%s                           \n", tSSPTestFlag.mSSP_TestSPH?"HIGH":"LOW");  
        DEBUGMSG(MSGINFO, " <E> SPO Change          : SPO_%s                           \n", tSSPTestFlag.mSSP_TestSPO?"HIGH":"LOW");  
        DEBUGMSG(MSGINFO, " <F> Order Change        : %s_FIRST                         \n", tSSPTestFlag.mSSP_TestOrder?"LSB":"MSB");  
        DEBUGMSG(MSGINFO, " <G> Interrupt On/Off    : %s                               \n", (tSSPTestFlag.mSSP_MasterIsrEn)?"On":"Off");
        DEBUGMSG(MSGINFO, " <H> Debug Port On/Off   : %s                               \n", (tSSPTestFlag.mSSP_DebugPortOn)?"On":"Off");          
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ..%s                       \n", (tSSPTestFlag.mSSP_DebugMsgOn)?"o":"x");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_SSP_sFlash_ReadID(Ch);
            break;

            case 2:
                APACHE_TEST_SSP_sFlash_SectorErase(Ch);
            break;

            case 3:
                APACHE_TEST_SSP_sFlash_BlockErase(Ch);
            break;

            case 4:
                APACHE_TEST_SSP_sFlash_WritePage(Ch);
            break;

            case 5:
                APACHE_TEST_SSP_sFlash_ReadPage(Ch);
            break;

            case 6:
                APACHE_TEST_SSP_sFlash_SectorErase_WritePage_ReadPage_Compare(Ch);
            break;	

            case 7:
                APACHE_TEST_SSP_sFlash_BlockErase_WritePage_ReadPage_Compare(Ch);
            break;	

            case 8:
                APACHE_TEST_SSP_sFlash_BitRateChange(Ch);
            break;

            case 9:
                APACHE_TEST_SSP_SlaveMode(Ch);
            break;

            //-----------------------------------------------------------
            // Test Flow Ctrl
            case 10: // A
                tSSPTestFlag.mSSP_TestCh = (tSSPTestFlag.mSSP_TestCh?SSP_CH0:SSP_CH1);
                APACHE_TEST_SSP_SetDebugPort(ON, tSSPTestFlag.mSSP_TestCh);
            break;

            case 11: // B
                APACHE_TEST_SSP_SelectClock();
            break;

            case 12: // C
                APACHE_TEST_SSP_sFlash_StartAddrChange();
            break;

            case 13: // D
                tSSPTestFlag.mSSP_TestSPH = (tSSPTestFlag.mSSP_TestSPH?SSP_SPH_LOW:SSP_SPH_HIGH);
            break;
            
            case 14: // E
                tSSPTestFlag.mSSP_TestSPO = (tSSPTestFlag.mSSP_TestSPO?SSP_SPO_LOW:SSP_SPO_HIGH);
            break;          

            case 15: // F
                tSSPTestFlag.mSSP_TestOrder = (tSSPTestFlag.mSSP_TestOrder?SSP_MSB_FIRST:SSP_LSB_FIRST);
            break;   

            case 16: // G
                _REVERSE(tSSPTestFlag.mSSP_MasterIsrEn);
            break;   
            
            case 17: // H
                _REVERSE(tSSPTestFlag.mSSP_DebugPortOn);
                APACHE_TEST_SSP_SetDebugPort(tSSPTestFlag.mSSP_DebugPortOn, tSSPTestFlag.mSSP_TestCh);
            break;   
            
            case 35: // Z
                _REVERSE(tSSPTestFlag.mSSP_DebugMsgOn);
            break;  
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto SSP_Exit;
        }
    }

SSP_Exit:
    
    // Debug Port Disable
    APACHE_TEST_SSP_SetDebugPort(OFF, tSSPTestFlag.mSSP_TestCh);

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_SPI */


/* End Of File */

