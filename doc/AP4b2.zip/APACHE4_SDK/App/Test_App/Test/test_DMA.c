/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_DMAC


/*
 * It is a test code that checks the state of oversizing.
 * It is unnecessary code in normal state.
 */
#define __DMA_TEST_TRANSFER_SIZE_OVER_CHECK__











/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define TEST_DMA_STACK_BUFF_SIZE            (4*KB)
#define TEST_DMA_BSS_BUFF_SIZE              (16*KB)

#define TEST_DMA_CLS_VALUE                  0xFF
#define TEST_DMA_TIME_OUT                   1000    // 1-sec

#define TEST_DMA_BUFF_STACK                 0
#define TEST_DMA_BUFF_BSS                   1
#define TEST_DMA_BUFF_DDR                   2










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    eDMA_CH         mDMA_TestCh;
    
    BOOL            mDMA_IsrEn;

    BOOL            mDMA_TestBurstCtrl;
    UINT32          mDMA_TestBurstLength;    
    UINT32          mDMA_TestMaxSize;
    UINT32          mDMA_TestAlign;
    UINT8           mDMA_TestUsedBuff;
    BOOL            mDMA_TestIsSimple;
    
    eDBG_GPIO_PORT  mDMA_DebupGpioPort;
    UINT32          mDMA_DebugLoopCnt;
    BOOL            mDMA_DebugLoopOn;
    BOOL            mDMA_DebugMsgOn;
} tDMATEST_FLAG, *ptDMATEST_FLAG;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile tDMATEST_FLAG tDMATestFlag; 
volatile tDMATEST_FLAG tDMATestFlag_Def = { 
                                                DMA_CH0
                                                    
                                                ,OFF

                                                ,ON
                                                ,1
                                                ,TEST_DMA_STACK_BUFF_SIZE
                                                ,0
                                                ,2
                                                ,OFF
                                                
                                                ,DBG_GPIO_PORT0
                                                ,0
                                                ,OFF
                                                ,OFF
                                           };


UINT8 gTestDMASrcBuff[TEST_DMA_BSS_BUFF_SIZE] __attribute__ ((aligned (4)));
UINT8 gTestDMADstBuff[TEST_DMA_BSS_BUFF_SIZE] __attribute__ ((aligned (4)));

/*
* To use DMA, 16-byte aligned instuction-buffer is required.
* However, ARM_Compiler_RVDS_v4.0 does not support 16 aligns.
* ARM_Compiler_RVDS_v4.0 - [local  variable] 1,2,4,8(Support)
*                          [global variable] 1,2,4,8,16,32...(Support)
* Therefore, the instuction buffer must be set to the BSS area.
*/
UINT8 gTestDMAInstBuff[TEST_DMA_BSS_BUFF_SIZE] __attribute__ ((aligned (16)));










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static UINT32 __test_dma_swap32(UINT32 a) 
{                        
    UINT32 a_rev;

    a_rev = ((a&0xff)<<24) | ((a&0xff00)<<8) | ((a&0xff0000)>>8) | ((a&0xff000000)>>24);

    return a_rev;
}


static UINT16 __test_dma_swap16(UINT16 a) 
{                        
    UINT16 a_rev;

    a_rev = ((a&0xff)<<8) | ((a&0xff00)>>8);

    return a_rev;
}


static void __test_dma_display_meminfo(UINT8* Str, UINT8* pSrcBuff, UINT8* pDstBuff, UINT8* pInstBuff)
{

    DEBUGMSG(MSGINFO, "-------------------------------------------------------------\n");        
    DEBUGMSG(MSGINFO, " >> %s \n", Str);
    DEBUGMSG(MSGINFO, "    - Source      Memory (0x%08X)\n", pSrcBuff);
    DEBUGMSG(MSGINFO, "    - Destination Memory (0x%08X)\n", pDstBuff);
    DEBUGMSG(MSGINFO, "    - Instruction Memory (0x%08X)\n", pInstBuff); 
    DEBUGMSG(MSGINFO, "-------------------------------------------------------------\n");
}


static void __test_dma_display_info(eDMA_CH Ch, UINT32 BurstLen, UINT32 Length)
{
    DEBUGMSG(MSGINFO, "\r >> %02d:DMA_CH%d, DMA_BL_%02dXFER, DataSize(0x%06x)", tDMATestFlag.mDMA_DebugLoopCnt, Ch, BurstLen, Length);
}


static void __test_dma_dummy_buff_marking(UINT8 *pAddr, UINT32 Value)
{
    UINT32 i;
    
    pAddr[0] = (Value>>24 & 0xFF);
    pAddr[1] = (Value>>16 & 0xFF);
    pAddr[2] = (Value>>8  & 0xFF);
    pAddr[3] = (Value     & 0xFF);

    for(i=0; i<4; i++)
    {
        if(pAddr[i] == 0)
            pAddr[i] = 0xA5;
    }
}


static void __test_dma_dumy_buff(UINT8 *pAddr, UINT32 size, UINT8 data)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        pAddr[i] = i+data;
    }
}


static void __test_dma_clear_buff(UINT8 *pAddr, UINT32 size, UINT8 ClsValue)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        pAddr[i] = ClsValue;
    }

#ifdef __DMA_TEST_TRANSFER_SIZE_OVER_CHECK__
    ASM_DCACHE_FLUSH((UINT32)pAddr, size);
#endif
}


static void __test_dma_byte_display_buff(UINT8 *String, UINT8 *pBuff, UINT32 Size)
{
    UINT32 i;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");	
    DEBUGMSG(MSGINFO, "\n >> %s BuffAddr = 0x%08X, Size = 0x%08X", String, pBuff, Size);	
    for(i=0;i<Size;i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", pBuff+i);	
        DEBUGMSG(MSGINFO, "%02X ", pBuff[i]);	
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");	
}


static void __test_dma_compare_buff_display(UINT8 *pSrc, UINT8 *pDes)
{
    __test_dma_byte_display_buff("SRC", pSrc, 0x100);
    __test_dma_byte_display_buff("DST", pDes, 0x100); 
}


static UINT32 __test_dma_compare_buff_sincr_dfix(UINT8 *pSrc, UINT8* pDes, UINT32 size, UINT32 totalsize, UINT32 BurstLength)
{
    UINT32 i;
    UINT32 nErrCnt = 0;
    UINT8* pSrc_org  = pSrc;
    UINT8* pDest_org = pDes;


    pSrc += (size-BurstLength);

    for(i=0; i<BurstLength; i++)
    {
        if(pSrc[i] != *pDes++)
        {
            nErrCnt++;
            break;
        }
    }
    
    if(nErrCnt)
    {
        DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
        DEBUGMSG(MSGERR, " >> DMA Compare Error Case1 - 0x%08X\n", size);
        DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", pSrc, pDes);
        DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", pSrc_org, pSrc_org+size);
        DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", pDest_org, pDest_org+size); 
        
        pDes = pDest_org;
        __test_dma_compare_buff_display(pSrc, pDes);
        APACHE_TEST_WaitKey();
    }
#ifdef __DMA_TEST_TRANSFER_SIZE_OVER_CHECK__ 
    else
    {
        for( ;i<totalsize; i++)
        {
            if(TEST_DMA_CLS_VALUE != *pDes++)
            {
                nErrCnt++;
                break;
            }
        }

        if(nErrCnt)
        {
            pDes--;      
            DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
            DEBUGMSG(MSGERR, " >> DMA Compare Error Case2 - 0x%08X\n", size);
            DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", pSrc, pDes);
            DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", pSrc_org, pSrc_org+size);
            DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", pDest_org, pDest_org+size); 
            
            pDes -= (((pDes-pDest_org)>=0x100)?0x80:size);
            pSrc = pSrc_org + (pDes-pDest_org);
            __test_dma_compare_buff_display(pSrc, pDes);
            APACHE_TEST_WaitKey();
        }
    }
#endif
    
    if((nErrCnt == 0) && (tDMATestFlag.mDMA_DebugMsgOn == ON))
    {
        __test_dma_compare_buff_display(pSrc_org, pDest_org);
        tDMATestFlag.mDMA_DebugMsgOn = APACHE_TEST_WaitKey();
    }
    
    return nErrCnt;
}


static UINT32 __test_dma_compare_buff_sfix_dincr(UINT8 *pSrc, UINT8* pDes, UINT32 size, UINT32 totalsize, UINT32 BurstLength)
{
    UINT32 i;
    UINT32 j = 0;
    UINT32 nErrCnt = 0;
    UINT8* pSrc_org  = pSrc;
    UINT8* pDest_org = pDes;
    UINT32 Offset;


    for(i=0; i<(size/BurstLength); i++)
    {
        for(j=0; j<BurstLength; j++)
        {
            if(pSrc[j] != *pDes++)
            {
                nErrCnt++;
                break;
            }
        }

        if(nErrCnt!=0)
            break;
    }
    i=(i*BurstLength);


    if(nErrCnt)
    {
        pDes--;      
        
        DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
        DEBUGMSG(MSGERR, " >> DMA Compare Error Case1 - 0x%08X\n", size);
        DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", pSrc, pDes);
        DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", pSrc_org, pSrc_org+size);
        DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", pDest_org, pDest_org+size); 
        
        Offset = pDes-pDest_org;
        pDes -= ((Offset>=0x100)?0x80:j);
        __test_dma_compare_buff_display(pSrc, pDes);
        APACHE_TEST_WaitKey();
    }
#ifdef __DMA_TEST_TRANSFER_SIZE_OVER_CHECK__   
    else
    {
        for( ;i<totalsize; i++)
        {
            if(TEST_DMA_CLS_VALUE != *pDes++)
            {
                nErrCnt++;
                break;
            }
        }

        if(nErrCnt)
        {
            pDes--;      
            DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
            DEBUGMSG(MSGERR, " >> DMA Compare Error Case2 - 0x%08X\n", size);
            DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", pSrc, pDes);
            DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", pSrc_org, pSrc_org+size);
            DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", pDest_org, pDest_org+size); 
            
            pDes -= (((pDes-pDest_org)>=0x100)?0x80:size);
            pSrc = pSrc_org + (pDes-pDest_org);
            __test_dma_compare_buff_display(pSrc, pDes);
            APACHE_TEST_WaitKey();
        }
 
    }
#endif
    
    if((nErrCnt == 0) && (tDMATestFlag.mDMA_DebugMsgOn == ON))
    {
        __test_dma_compare_buff_display(pSrc_org, pDest_org);
        tDMATestFlag.mDMA_DebugMsgOn = APACHE_TEST_WaitKey();
    }
    
    return nErrCnt;
}


static UINT32 __test_dma_compare_buff_sincr_dincr_swap32(UINT32 *pSrc, UINT32* pDes, UINT32 size, UINT32 totalsize)
{
    UINT32 i;
    UINT32 nErrCnt = 0;
    UINT32* pSrc_org  = pSrc;
    UINT32* pDest_org = pDes;
    UINT32 Offset;


    for(i=0; i<(size/4); i++)
    {
        if(*pSrc != __test_dma_swap32(*pDes))
        {
            nErrCnt++;
            break;
        }

        pSrc++;
        pDes++;
    }


    if(nErrCnt)
    {
        DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
        DEBUGMSG(MSGERR, " >> DMA Compare Error Case1 - 0x%08X\n", size);
        DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", pSrc, pDes);
        DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", pSrc_org, pSrc_org+size);
        DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", pDest_org, pDest_org+size); 
        
        Offset = pSrc-pSrc_org;
        pSrc -= ((Offset>=0x100)?0x80:0);
        pDes -= ((Offset>=0x100)?0x80:0);
        __test_dma_compare_buff_display((UINT8*)pSrc, (UINT8*)pDes);
        APACHE_TEST_WaitKey();
    }
#ifdef __DMA_TEST_TRANSFER_SIZE_OVER_CHECK__ 
    else
    {
        for( ;i<(totalsize/4); i++)
        {
            if(0xFFFFFFFF != *pDes++)
            {
                nErrCnt++;
                break;
            }
        }

        if(nErrCnt)
        {
            pDes--;      
            DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
            DEBUGMSG(MSGERR, " >> DMA Compare Error Case2 - 0x%08X\n", size);
            DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", pSrc, pDes);
            DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", pSrc_org, pSrc_org+size);
            DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", pDest_org, pDest_org+size); 
            
            pDes -= (((pDes-pDest_org)>=0x100)?0x80:size);
            pSrc = pSrc_org + (pDes-pDest_org);
            __test_dma_compare_buff_display((UINT8*)pSrc, (UINT8*)pDes);
            APACHE_TEST_WaitKey();
        }
 
    }
#endif
    
    if((nErrCnt == 0) && (tDMATestFlag.mDMA_DebugMsgOn == ON))
    {
        __test_dma_compare_buff_display((UINT8*)pSrc_org, (UINT8*)pDest_org);
        tDMATestFlag.mDMA_DebugMsgOn = APACHE_TEST_WaitKey();
    }
    
    return nErrCnt;
}


static UINT32 __test_dma_compare_buff_sincr_dincr_swap16(UINT16 *pSrc, UINT16* pDes, UINT32 size, UINT32 totalsize)
{
    UINT32 i;
    UINT32 nErrCnt = 0;
    UINT16* pSrc_org  = pSrc;
    UINT16* pDest_org = pDes;
    UINT32 Offset;


    for(i=0; i<(size/2); i++)
    {
        if(*pSrc != __test_dma_swap16(*pDes))
        {
            nErrCnt++;
            break;
        }

        pSrc++;
        pDes++;
    }


    if(nErrCnt)
    {
        DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
        DEBUGMSG(MSGERR, " >> DMA Compare Error Case1 - 0x%08X\n", size);
        DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", pSrc, pDes);
        DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", pSrc_org, pSrc_org+size);
        DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", pDest_org, pDest_org+size); 
        
        Offset = pSrc-pSrc_org;
        pSrc -= ((Offset>=0x100)?0x80:0);
        pDes -= ((Offset>=0x100)?0x80:0);
        __test_dma_compare_buff_display((UINT8*)pSrc, (UINT8*)pDes);
        APACHE_TEST_WaitKey();
    }
#ifdef __DMA_TEST_TRANSFER_SIZE_OVER_CHECK__ 
    else
    {
        for( ;i<(totalsize/2); i++)
        {
            if(0xFFFF != *pDes++)
            {
                nErrCnt++;
                break;
            }
        }

        if(nErrCnt)
        {
            pDes--;      
            DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
            DEBUGMSG(MSGERR, " >> DMA Compare Error Case2 - 0x%08X\n", size);
            DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", pSrc, pDes);
            DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", pSrc_org, pSrc_org+size);
            DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", pDest_org, pDest_org+size); 
            
            pDes -= (((pDes-pDest_org)>=0x100)?0x80:size);
            pSrc = pSrc_org + (pDes-pDest_org);
            __test_dma_compare_buff_display((UINT8*)pSrc, (UINT8*)pDes);
            APACHE_TEST_WaitKey();
        }
 
    }
#endif
    
    if((nErrCnt == 0) && (tDMATestFlag.mDMA_DebugMsgOn == ON))
    {
        __test_dma_compare_buff_display((UINT8*)pSrc_org, (UINT8*)pDest_org);
        tDMATestFlag.mDMA_DebugMsgOn = APACHE_TEST_WaitKey();
    }
    
    return nErrCnt;
}


static UINT32 __test_dma_compare_buff_sincr_dincr(UINT8 *pSrc, UINT8* pDes, UINT32 size, UINT32 totalsize)
{
    UINT32 i;
    UINT32 nErrCnt = 0;
    UINT8* pSrc_org  = pSrc;
    UINT8* pDest_org = pDes;
    UINT32 Offset;


    for(i=0; i<size; i++)
    {
        if(*pSrc++ != *pDes++)
        {
            nErrCnt++;
            break;
        }
    }


    if(nErrCnt)
    {
        pSrc--;
        pDes--;      
        
        DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
        DEBUGMSG(MSGERR, " >> DMA Compare Error Case1 - 0x%08X\n", size);
        DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", pSrc, pDes);
        DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", pSrc_org, pSrc_org+size);
        DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", pDest_org, pDest_org+size); 
        
        Offset = pSrc-pSrc_org;
        pSrc -= ((Offset>=0x100)?0x80:0);
        pDes -= ((Offset>=0x100)?0x80:0);
        __test_dma_compare_buff_display(pSrc, pDes);
        APACHE_TEST_WaitKey();
    }
#ifdef __DMA_TEST_TRANSFER_SIZE_OVER_CHECK__ 
    else
    { 
        for( ;i<totalsize; i++)
        {
            if(TEST_DMA_CLS_VALUE != *pDes++)
            {
                nErrCnt++;
                break;
            }
        }

        if(nErrCnt)
        {
            pDes--;      
            DEBUGMSG(MSGERR, "\n-------------------------------------------------------------\n");        
            DEBUGMSG(MSGERR, " >> DMA Compare Error Case2 - 0x%08X\n", size);
            DEBUGMSG(MSGERR, "    - SrcPos   (0x%08X) DestPos(0x%08X)\n", pSrc, pDes);
            DEBUGMSG(MSGERR, "    - SrcStart (0x%08X) SrcEnd (0x%08X)\n", pSrc_org, pSrc_org+size);
            DEBUGMSG(MSGERR, "    - DestStart(0x%08X) DestEnd(0x%08X)\n", pDest_org, pDest_org+size); 
            
            pDes -= (((pDes-pDest_org)>=0x100)?0x80:size);
            pSrc = pSrc_org + (pDes-pDest_org);
            __test_dma_compare_buff_display(pSrc, pDes);
            APACHE_TEST_WaitKey();
        }
 
    }
#endif
    
    if((nErrCnt == 0) && (tDMATestFlag.mDMA_DebugMsgOn == ON))
    {
        __test_dma_compare_buff_display(pSrc_org, pDest_org);
        tDMATestFlag.mDMA_DebugMsgOn = APACHE_TEST_WaitKey();
    }
    
    return nErrCnt;
}


void APACHE_TEST_DMA_BurstLengthChange(void)
{
    tDMATestFlag.mDMA_TestBurstLength = APACHE_TEST_Display_InputValue(DMA_BURST_LEN_MIN, DMA_BURST_LEN_MAX, "Change Test BurstLength");
}


void APACHE_TEST_DMA_MemSizeChange(void)
{
    tDMATestFlag.mDMA_TestMaxSize = APACHE_TEST_Display_InputValue(0x1, (4*MB), "Change Test MemoryMaxSize");
}


void APACHE_TEST_DMA_MemAlignChange(void)
{
    tDMATestFlag.mDMA_TestAlign = APACHE_TEST_Display_InputValue(0x0, 0xFFFFFF, "Change Test Memory Align");
}


void APACHE_TEST_DMA_ChannelChange(eDMA_CH Ch)
{  
    INT8 buf = 0;

    APACHE_TEST_GetArrowKey_Help("Channel Up", "Channel Down", NULL, NULL);
    
    DEBUGMSG(MSGINFO, "  > DMA Select    : %d", Ch);
    
    while(1)
    {
        buf = ncLib_UART_Control(GCMD_UT_GET_CHAR, SYS_DEBUG_PORT, CMD_END);

        if(buf != NC_FAILURE)
        {
            // Support Direction Key
            buf = APACHE_TEST_GetArrowKey(buf);
            
            // Enter Key
            if(buf == RETURN_KEY)
            {
                DEBUGMSG(MSGINFO, "\n");
                break;
            }

            // Number Key '8' and Direction Key 'Up'
            if(buf == '8')
            {
                if(Ch < DMA_CH3)
                    ++Ch;
            }
            // Number Key '2' and Direction Key 'Down'
            else if(buf == '2')
            {
                if(Ch > DMA_CH0)
                    --Ch;
            }

            DEBUGMSG(MSGINFO, "\r  > DMA Select    : %d", Ch, buf, buf);
        }
    }

    tDMATestFlag.mDMA_TestCh = Ch;
}


void APACHE_TEST_DMA_Isr(UINT32 irq)
{
    INT32 Sts;
    eDMA_CH Ch = (eDMA_CH)(irq - IRQ_NUM_DMA0);


    // ISR Status Check and Clear
    Sts = ncLib_DMA_Control(GCMD_DMA_GET_INT_STS, Ch, CMD_END); 
    if(Sts != NC_FAILURE)
    {
        if(Sts != 0x01)
        {
            DEBUGMSG(MSGWARN, " > ISR DMA_%d Status : 0x%04X\n", Ch, Sts);
        }

        if(Sts&0x01)
        {
            // DMA Done Status...


            // Debug - Check Time
            APACHE_TEST_StopWatch(OFF);


            // Init - Debug Gpio Port
            APACHE_TEST_DebugGPIOSet(tDMATestFlag.mDMA_DebupGpioPort+Ch, GPIO_LOW);
        }
    }
}


void APACHE_TEST_DMA_Isr_Init(eDMA_CH Ch)
{
    // Register DMA Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_REGISTER_INT
                      ,IRQ_NUM_DMA0 + Ch
                      ,(PrHandler)APACHE_TEST_DMA_Isr
                      ,CMD_END);
}


void APACHE_TEST_DMA_Isr_DeInit(eDMA_CH Ch)
{
    // Unregister DMA Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT
                      ,IRQ_NUM_DMA0 + Ch
                      ,CMD_END);
}


void APACHE_TEST_DMA_Init(eDMA_CH Ch, ptDMA_PARAM ptDMAParam)
{
    INT32 ret;


    // Open DMA 
    ncLib_DMA_Open();



    // Init - Debug Gpio Port
    APACHE_TEST_DebugGPIOSet(tDMATestFlag.mDMA_DebupGpioPort, GPIO_LOW);
    tDMATestFlag.mDMA_DebugLoopCnt = 0;


    // DMA Interrupt Register
    if(ptDMAParam->mIntEn == ON)
        APACHE_TEST_DMA_Isr_Init(Ch);

    

    // Init DAM Channel 
    ret = ncLib_DMA_Control(GCMD_DMA_INIT_CH, Ch, ptDMAParam, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel Init Error!\n");
        return;
    }
}


void APACHE_TEST_DMA_DeInit(eDMA_CH Ch, ptDMA_PARAM ptDMAParam)
{
    INT32 ret;


    // DMA Interrupt UnRegister
    if(ptDMAParam->mIntEn == ON)
        APACHE_TEST_DMA_Isr_DeInit(Ch);



    // DeInit DMA Channel
    ret = ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, Ch, CMD_END);
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Channel DeInit Error!\n");
        return;
    }

    
    // Close DMA
    ret = ncLib_DMA_Close();    
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Close Error!\n");
        return;
    }
}


INT32 APACHE_TEST_DMA_MtoM_SIncr_DIncr_UsedDDR_2CH(UINT8 Loop)
{
    #define TEST_DMA_START 0xFFFF0000
    #define TEST_DMA_WAIT  0x00000000
    #define TEST_DMA_DONE  0x00000001
    #define TEST_DMA_ERR   0xFFFFFFFF
    #define TEST_DMA_END   0x0000FFFF
    
    INT32 ret = NC_SUCCESS;  

    eDMA_CH Ch;
    eDMA_CH StartCh;
    eDMA_CH EndCh;
    tDMA_PARAM tDMAParam; 

    UINT32 pSrcBuff[MAX_OF_DMA_CH];
    UINT32 pDstBuff[MAX_OF_DMA_CH];
    UINT32 pInstBuff[MAX_OF_DMA_CH];
    UINT32 BurstLength[MAX_OF_DMA_CH];  
    UINT32 TestDataSize[MAX_OF_DMA_CH]; 
    INT32  ChannelStatus[MAX_OF_DMA_CH];

    UINT32 TestStopFlag = 0;
    UINT32 TestBuff;
    UINT32 TestMaxSize;


    // Check Core
    if(ASM_GET_CORE_ID() == DLS_CORE)
    {
        StartCh  = DMA_CH0;
        EndCh    = DMA_CH1;
        TestBuff = TEST_PHY_DDR_BASE;
    }
    else
    {
        StartCh  = DMA_CH2;
        EndCh    = DMA_CH3;
        TestBuff = TEST_PHY_DDR_BASE + (16*MB);
    }


    // Open DMA 
    ncLib_DMA_Open();
    

    // Init DMA All Channel 
    TestMaxSize = tDMATestFlag.mDMA_TestMaxSize;   
    for(Ch=StartCh; Ch<=EndCh; Ch++)
    {
        // Test Config    
        BurstLength[Ch]  = tDMATestFlag.mDMA_TestBurstLength;   
        
        if(tDMATestFlag.mDMA_TestIsSimple == 1)
            TestDataSize[Ch] = TestMaxSize;
        else
            TestDataSize[Ch] = 1; 

        // Set Test Buffer Address
        pSrcBuff[Ch]   = _ALIGN(TestBuff, 0x04) + tDMATestFlag.mDMA_TestAlign;
        pDstBuff[Ch]   = _ALIGN(pSrcBuff[Ch] + TestMaxSize, 0x04);
        pInstBuff[Ch]  = _ALIGN(pDstBuff[Ch] + TestMaxSize, 0x10);
        TestBuff       = _ALIGN(pInstBuff[Ch] + TestMaxSize, 0x10000);

        // Test Status Set
        ChannelStatus[Ch] = TEST_DMA_START; 

        __test_dma_display_meminfo("APACHE_TEST_DMA_MtoM_SIncr_DIncr_Multi", (UINT8*)pSrcBuff[Ch], (UINT8*)pDstBuff[Ch], (UINT8*)pInstBuff[Ch]);  


        // Debug Src Buffer Write
        __test_dma_dumy_buff((UINT8*)pSrcBuff[Ch], TestMaxSize, Ch);
        __test_dma_clear_buff((UINT8*)pInstBuff[Ch], (TestMaxSize/DMA_TRANSFER_SIZE)*16, TEST_DMA_CLS_VALUE);

        
        // Set DMA Operation Mode 
        tDMAParam.mReqType    = DMA_MEM_TO_MEM;  
        tDMAParam.mInstAddr   = (UINT32)pInstBuff[Ch];
        tDMAParam.mIntEn      = tDMATestFlag.mDMA_IsrEn;
        tDMAParam.mRxIncrEn   = ENABLE;  
        tDMAParam.mRxBurstLen = BurstLength[Ch];  
        tDMAParam.mTxIncrEn   = ENABLE; 
        tDMAParam.mTxBurstLen = BurstLength[Ch];  
        tDMAParam.mSwap       = DMA_SWAP_NO;  


        // DMA Interrupt Register
        if(tDMAParam.mIntEn == ON)
            APACHE_TEST_DMA_Isr_Init(Ch);


        // Init DAM Channel 
        ret = ncLib_DMA_Control(GCMD_DMA_INIT_CH, Ch, &tDMAParam, CMD_END);
        if(ret == NC_FAILURE)
            DEBUGMSG(MSGERR,  "DMA Channel_%d Init Error!\n", Ch);
    }



    // Multi Channel Loop Test
    while(1)
    {
        for(Ch=StartCh; Ch<=EndCh; Ch++)
        {
            // DMA Start
            if(ChannelStatus[Ch] == TEST_DMA_START)
            {  
                // Dest Buffer Clear
                __test_dma_clear_buff((UINT8*)pDstBuff[Ch], TestMaxSize, TEST_DMA_CLS_VALUE);
                __test_dma_dummy_buff_marking((UINT8*)pSrcBuff[Ch], ((TestDataSize[Ch]<<8)|(BurstLength[Ch])));


                // DMA Test Mode Display
                __test_dma_display_info(Ch, BurstLength[Ch], TestDataSize[Ch]);


                // Debug Gpio Port (set High)
                APACHE_TEST_DebugGPIOSet(tDMATestFlag.mDMA_DebupGpioPort+Ch, GPIO_HIGH);

                
                // DMA Start
                ret = ncLib_DMA_Control(GCMD_DMA_START, Ch, pSrcBuff[Ch], pDstBuff[Ch], TestDataSize[Ch], CMD_END);
                if(ret == NC_SUCCESS)
                    ChannelStatus[Ch] = TEST_DMA_WAIT;
                else
                {
                    ChannelStatus[Ch] = TEST_DMA_ERR;
                    DEBUGMSG(MSGERR, "\n DMA Channel_%d Start Error!\n", Ch);
                }
            }


            // DMA End Check - Run Status(0x0)
            if(ChannelStatus[Ch] == TEST_DMA_WAIT)
            {
                ret = ncLib_DMA_Control(GCMD_DMA_DONE, Ch, CMD_END);

                if(ret != NC_FAILURE)
                    ChannelStatus[Ch] = ret;
            }
            // DMA Done - Stop Status(0x1)
            else if(ChannelStatus[Ch] == TEST_DMA_DONE)
            {
                if(tDMAParam.mIntEn == OFF)
                    APACHE_TEST_DebugGPIOSet(tDMATestFlag.mDMA_DebupGpioPort+Ch, GPIO_LOW);
                
                // Compare - Src vs Dest Buffer
                ret = __test_dma_compare_buff_sincr_dincr((UINT8*)pSrcBuff[Ch], (UINT8*)pDstBuff[Ch], TestDataSize[Ch], TestMaxSize);
                if(ret == NC_SUCCESS)
                {
                    // Change Data Size
                    TestDataSize[Ch] += 1;
                    if(TestDataSize[Ch] > TestMaxSize)
                    {
                        if(tDMATestFlag.mDMA_TestIsSimple == 1)
                            TestDataSize[Ch] = TestMaxSize;
                        else
                            TestDataSize[Ch] = 1; 

                        if(tDMATestFlag.mDMA_TestBurstCtrl == ON)
                        {
                            // Change BurstLength 
                            BurstLength[Ch] += 1;
                            if(BurstLength[Ch] > DMA_BURST_LEN_MAX)
                            {
                                BurstLength[Ch] = DMA_BURST_LEN_MIN;

                                tDMATestFlag.mDMA_DebugLoopCnt++;
                                if((Loop == FALSE) && (Ch == StartCh))
                                    TestStopFlag = 1;
                            }
                                
                            // Change BurstLength (Arg[0]:Rx, Arg[1]:Tx)
                            ncLib_DMA_Control(GCMD_DMA_SET_BURST_LEN, Ch, BurstLength[Ch], BurstLength[Ch], CMD_END);  
                        }
                        else
                        {
                            if((Loop == FALSE) && (Ch == StartCh))
                                TestStopFlag = 1;
                        }
                    }

                    // User Stop Flag
                    if(TestStopFlag)
                        ChannelStatus[Ch] = TEST_DMA_END;
                    else
                        ChannelStatus[Ch] = TEST_DMA_START;
                }
                else
                {
                    ChannelStatus[Ch] = TEST_DMA_ERR;
                }
            }
            else if(ChannelStatus[Ch] == TEST_DMA_END)
            {
                
            }
            // DMA Status(0xXXXX) -> DMA Error
            else
            {
                DEBUGMSG(MSGERR, "\n DMA Channel_%d Wait Satus(%04X) Error!\n", Ch, ChannelStatus[Ch]);
                ChannelStatus[Ch] = TEST_DMA_ERR;
            }
        }


        // Error case - Test Stop
        ret = NC_SUCCESS;
        for(Ch=StartCh; Ch<=EndCh; Ch++)
        {
            if(ChannelStatus[Ch] == TEST_DMA_ERR)
                ret = NC_FAILURE;
        }
        if(ret != NC_SUCCESS)
            break;


        // User Stop
        for(Ch=StartCh; Ch<=EndCh; Ch++)
        {
            if(ChannelStatus[Ch] == TEST_DMA_END)
                ret++;
        }
        if(ret > (EndCh-StartCh))
            break;
        

        // Input Key Exit ('Q' or 'q')
        if(APACHE_TEST_ExitKey())
            TestStopFlag = 1;
        
    }
    DEBUGMSG(MSGERR, "\n");


    // DeInit DMA All Channel 
    for(Ch=StartCh; Ch<=EndCh; Ch++)
    {
        if(tDMAParam.mIntEn == ON)
            APACHE_TEST_DMA_Isr_DeInit(Ch);
        ret = ncLib_DMA_Control(GCMD_DMA_DEINIT_CH, Ch, CMD_END);
        if(ret == NC_FAILURE)
            DEBUGMSG(MSGERR, "DMA Channel_%d DeInit Error!\n", Ch);
    }

    
    // Close DMA
    ret = ncLib_DMA_Close();    
    if(ret == NC_FAILURE)
    {
        DEBUGMSG(MSGERR, "DMA Close Error!\n");
    }


    return ret;
}


void APACHE_TEST_DMA_MtoM_SIncr_DIncr_Swap(eDMA_CH Ch, UINT8 Loop)
{
    INT32 ret = NC_SUCCESS;  

    UINT8  SrcBuff[TEST_DMA_STACK_BUFF_SIZE] __attribute__ ((aligned (4)));
    UINT8  DstBuff[TEST_DMA_STACK_BUFF_SIZE] __attribute__ ((aligned (4)));   

    tDMA_PARAM tDMAParam;
    UINT32 BurstLength;  
    
    UINT32 TestDataSize;  
    UINT32 TestMaxSize;    

    UINT32 pSrcBuff;
    UINT32 pDstBuff;
    UINT32 pInstBuff;     

 
    // Test Config 
    BurstLength = tDMATestFlag.mDMA_TestBurstLength;
    TestMaxSize = tDMATestFlag.mDMA_TestMaxSize;


    // Test Buffer Select
    if(tDMATestFlag.mDMA_TestUsedBuff == TEST_DMA_BUFF_STACK)
    {
        // Stack(SRAM) : cacheable
        pSrcBuff  = (UINT32)&SrcBuff[0];
        pDstBuff  = (UINT32)&DstBuff[0];
        pInstBuff = (UINT32)&gTestDMAInstBuff[0];
        
        if(TestMaxSize > TEST_DMA_STACK_BUFF_SIZE)
            TestMaxSize = TEST_DMA_STACK_BUFF_SIZE;
    }
    else if(tDMATestFlag.mDMA_TestUsedBuff == TEST_DMA_BUFF_BSS)
    {
        // BSS(Virtural DDR) : cacheable
        pSrcBuff  = (UINT32)&gTestDMASrcBuff[0];
        pDstBuff  = (UINT32)&gTestDMADstBuff[0];
        pInstBuff = (UINT32)&gTestDMAInstBuff[0];

        if(TestMaxSize > TEST_DMA_BSS_BUFF_SIZE)
            TestMaxSize = TEST_DMA_BSS_BUFF_SIZE;
    }
    else
    {
        // DDR(Physical DDR) : non-cacheable
        if(ASM_GET_CORE_ID() == DLS_CORE)
            pSrcBuff = _ALIGN(TEST_PHY_DDR_BASE, 0x04);
        else
            pSrcBuff = _ALIGN(TEST_PHY_DDR_BASE + (16*MB), 0x04);

        pDstBuff  = _ALIGN(pSrcBuff + TestMaxSize, 0x04);
        pInstBuff = _ALIGN(pDstBuff + TestMaxSize, 0x10);
    }


    __test_dma_display_meminfo("APACHE_TEST_DMA_MtoM_SIncr_DIncr_Swap", (UINT8*)pSrcBuff, (UINT8*)pDstBuff, (UINT8*)pInstBuff);
       

    // Support BurstLength 2 or 4.
    if((BurstLength != 2) && (BurstLength != 4))
        BurstLength = 4;


    // Set Swap Mode
    if(BurstLength == 2)
        tDMAParam.mSwap = DMA_SWAP_16BIT;
    else if(BurstLength == 4)
        tDMAParam.mSwap = DMA_SWAP_32BIT;
    else
        tDMAParam.mSwap = DMA_SWAP_NO;


    // Set DMA Operation Mode 
    tDMAParam.mReqType    = DMA_MEM_TO_MEM; 
    tDMAParam.mInstAddr   = (UINT32)pInstBuff;      

    tDMAParam.mIntEn      = tDMATestFlag.mDMA_IsrEn;
    tDMAParam.mRxIncrEn   = ENABLE;  
    tDMAParam.mRxBurstLen = BurstLength;  
    tDMAParam.mTxIncrEn   = ENABLE;  
    tDMAParam.mTxBurstLen = BurstLength;  


    // Init DMA Channel 
    APACHE_TEST_DMA_Init(Ch, &tDMAParam);


    // Debug Buffer Write and Clear
    __test_dma_dumy_buff((UINT8*)pSrcBuff, TestMaxSize, Ch);
    __test_dma_clear_buff((UINT8*)pInstBuff, (TestMaxSize/DMA_TRANSFER_SIZE)*16, TEST_DMA_CLS_VALUE);


    // Set Test Mode
    if(tDMATestFlag.mDMA_TestIsSimple == 1)
        TestDataSize = TestMaxSize;
    else
        TestDataSize = BurstLength;


    // Test Run.. 
    // Input Key Exit ('Q' or 'q')
    while(!APACHE_TEST_ExitKey())
    {
        // Dest Buffer Clear
        __test_dma_clear_buff((UINT8*)pDstBuff, TestMaxSize, TEST_DMA_CLS_VALUE);
        __test_dma_dummy_buff_marking((UINT8*)pSrcBuff, ((TestDataSize<<8)|(BurstLength)));

        
        // DMA Test Mode Display
        __test_dma_display_info(Ch, BurstLength, TestDataSize);


        // Toggle - Debug Gpio Port
        APACHE_TEST_DebugGPIOSet(tDMATestFlag.mDMA_DebupGpioPort+Ch, GPIO_HIGH);
        APACHE_TEST_StopWatch(ON);
        

        // DMA Start
        ret = ncLib_DMA_Control(GCMD_DMA_START, Ch, pSrcBuff, pDstBuff, TestDataSize, CMD_END);
        if(ret == NC_SUCCESS)
        {
            // DMA Done Wait
            while((ret = ncLib_DMA_Control(GCMD_DMA_DONE, Ch, CMD_END)) == NC_FAILURE)
            {
                if(APACHE_TEST_mTimeOut(TEST_DMA_TIME_OUT))
                {
                    DEBUGMSG(MSGWARN, " - DMA TimeOut!~\n");
                    break;
                }
            }
            APACHE_TEST_mTimeOut(0);
        }
        else
        {
            DEBUGMSG(MSGERR, "DMA Start Error!\n"); 
        }


        // Toggle - Debug Gpio Port
        if(tDMAParam.mIntEn == OFF)
        {
            APACHE_TEST_StopWatch(OFF);
            APACHE_TEST_DebugGPIOSet(tDMATestFlag.mDMA_DebupGpioPort+Ch, GPIO_LOW);
        }


        // DMA Status Check
        if(ret != NC_FAILURE)
        {   
            if(ret != 0x01)
                DEBUGMSG(MSGERR, "\nDMA Error Status : 0x%04X\n", ret);
        }


        // Compare - Src vs Dest Buffer
        if(tDMAParam.mSwap == DMA_SWAP_16BIT)
            ret = __test_dma_compare_buff_sincr_dincr_swap16((UINT16*)pSrcBuff, (UINT16*)pDstBuff, TestDataSize, TestMaxSize);
        else if(tDMAParam.mSwap == DMA_SWAP_32BIT)
            ret = __test_dma_compare_buff_sincr_dincr_swap32((UINT32*)pSrcBuff, (UINT32*)pDstBuff, TestDataSize, TestMaxSize);


        // Compare - Error Stop
        if(ret != NC_SUCCESS)
            break;


        // Change Data Size
        TestDataSize += BurstLength;
        if(TestDataSize > TestMaxSize)
        {
            DEBUGMSG(MSGINFO, "\n");
            
            // Init Test Transfer Size            
            if(tDMATestFlag.mDMA_TestIsSimple == 1)
                TestDataSize = TestMaxSize;
            else
                TestDataSize = BurstLength; 

            tDMATestFlag.mDMA_DebugLoopCnt++;
            // Test Stop
            if(Loop == FALSE)
                break;
        }
    }
    DEBUGMSG(MSGINFO, "\n"); 


    // DeInit DMA Channel 
    APACHE_TEST_DMA_DeInit(Ch, &tDMAParam);
    
}


void APACHE_TEST_DMA_MtoM_SIncr_DFix(eDMA_CH Ch, UINT8 Loop)
{
    INT32 ret = NC_SUCCESS; 

    UINT8  SrcBuff[TEST_DMA_STACK_BUFF_SIZE] __attribute__ ((aligned (4)));
    UINT8  DstBuff[TEST_DMA_STACK_BUFF_SIZE] __attribute__ ((aligned (4)));   
    
    tDMA_PARAM tDMAParam;
    UINT32 BurstLength;  
    
    UINT32 TestDataSize;  
    UINT32 TestMaxSize;    

    UINT32 pSrcBuff;
    UINT32 pDstBuff;
    UINT32 pInstBuff;


    // Test Config 
    BurstLength = 1;
    TestMaxSize = tDMATestFlag.mDMA_TestMaxSize;


    // Test Buffer Select
    if(tDMATestFlag.mDMA_TestUsedBuff == TEST_DMA_BUFF_STACK)
    {
        // Stack(SRAM) : cacheable
        pSrcBuff  = (UINT32)&SrcBuff[0];
        pDstBuff  = (UINT32)&DstBuff[0];
        pInstBuff = (UINT32)&gTestDMAInstBuff[0];
        
        if(TestMaxSize > TEST_DMA_STACK_BUFF_SIZE)
            TestMaxSize = TEST_DMA_STACK_BUFF_SIZE;
    }
    else if(tDMATestFlag.mDMA_TestUsedBuff == TEST_DMA_BUFF_BSS)
    {
        // BSS(Virtural DDR) : cacheable
        pSrcBuff  = (UINT32)&gTestDMASrcBuff[0];
        pDstBuff  = (UINT32)&gTestDMADstBuff[0];
        pInstBuff = (UINT32)&gTestDMAInstBuff[0];

        if(TestMaxSize > TEST_DMA_BSS_BUFF_SIZE)
            TestMaxSize = TEST_DMA_BSS_BUFF_SIZE;
    }
    else
    {
        // DDR(Physical DDR) : non-cacheable
        if(ASM_GET_CORE_ID() == DLS_CORE)
            pSrcBuff = _ALIGN(TEST_PHY_DDR_BASE, 0x04);
        else
            pSrcBuff = _ALIGN(TEST_PHY_DDR_BASE + (16*MB), 0x04);

        pDstBuff  = _ALIGN(pSrcBuff + TestMaxSize, 0x04);
        pInstBuff = _ALIGN(pDstBuff + TestMaxSize, 0x10);
    }

    
    __test_dma_display_meminfo("APACHE_TEST_DMA_MtoM_SIncr_DFix", (UINT8*)pSrcBuff, (UINT8*)pDstBuff, (UINT8*)pInstBuff);  


    // Set DMA Operation Mode 
    tDMAParam.mReqType    = DMA_MEM_TO_MEM; 
    tDMAParam.mInstAddr   = (UINT32)pInstBuff;  
    
    tDMAParam.mIntEn      = tDMATestFlag.mDMA_IsrEn;
    tDMAParam.mRxIncrEn   = ENABLE;  
    tDMAParam.mRxBurstLen = DMA_BURST_LEN_MIN;  
    tDMAParam.mTxIncrEn   = DISABLE;  
    tDMAParam.mTxBurstLen = DMA_BURST_LEN_MIN;  
    tDMAParam.mSwap       = DMA_SWAP_NO; 


    // Init DMA Channel 
    APACHE_TEST_DMA_Init(Ch, &tDMAParam);


    // Debug Buffer Write and Clear
    __test_dma_dumy_buff((UINT8*)pSrcBuff, TestMaxSize, Ch);
    __test_dma_clear_buff((UINT8*)pInstBuff, (TestMaxSize/DMA_TRANSFER_SIZE)*16, TEST_DMA_CLS_VALUE);


    // Set Test Mode
    if(tDMATestFlag.mDMA_TestIsSimple == 1)
        TestDataSize = TestMaxSize;
    else
        TestDataSize = BurstLength;


    // Test Run.. 
    // Input Key Exit ('Q' or 'q')
    while(!APACHE_TEST_ExitKey())
    {        
        // Dest Buffer Clear
        __test_dma_clear_buff((UINT8*)pDstBuff, TestMaxSize, TEST_DMA_CLS_VALUE);
        __test_dma_dummy_buff_marking((UINT8*)pSrcBuff, ((TestDataSize<<8)|(BurstLength)));

        
        // DMA Test Mode Display
        __test_dma_display_info(Ch, BurstLength, TestDataSize);


        // Toggle - Debug Gpio Port
        APACHE_TEST_DebugGPIOSet(tDMATestFlag.mDMA_DebupGpioPort+Ch, GPIO_HIGH);
        APACHE_TEST_StopWatch(ON);
        

        // DMA Start
        ret = ncLib_DMA_Control(GCMD_DMA_START, Ch, pSrcBuff, pDstBuff, TestDataSize, CMD_END);
        if(ret == NC_SUCCESS)
        {
            // DMA Done Wait
            while((ret = ncLib_DMA_Control(GCMD_DMA_DONE, Ch, CMD_END)) == NC_FAILURE)
            {
                if(APACHE_TEST_mTimeOut(TEST_DMA_TIME_OUT))
                {
                    DEBUGMSG(MSGWARN, " - DMA TimeOut!~\n");
                    break;
                }
            }
            APACHE_TEST_mTimeOut(0);
        }
        else
        {
            DEBUGMSG(MSGERR, "DMA Start Error!\n"); 
        }
        

        // Toggle - Debug Gpio Port
        if(tDMAParam.mIntEn == OFF)
        {
            APACHE_TEST_StopWatch(OFF);
            APACHE_TEST_DebugGPIOSet(tDMATestFlag.mDMA_DebupGpioPort+Ch, GPIO_LOW);
        }


        // DMA Status Check
        if(ret != NC_FAILURE)
        {   
            if(ret != 0x01)
                DEBUGMSG(MSGERR, "\nDMA Error Status : 0x%04X\n", ret);
        }


        // Compare - Src vs Dest Buffer
        ret = __test_dma_compare_buff_sincr_dfix((UINT8*)pSrcBuff, (UINT8*)pDstBuff, TestDataSize, TestMaxSize, BurstLength);


        // Compare - Error Stop
        if(ret != NC_SUCCESS)
            break;


        // Change Data Size
        TestDataSize += BurstLength;
        if(TestDataSize > TestMaxSize)
        {
            DEBUGMSG(MSGINFO, "\n");
           
            // Change BurstLength 
            BurstLength = (BurstLength<<1);
            if(BurstLength > 4)
            {
                BurstLength = DMA_BURST_LEN_MIN;

                tDMATestFlag.mDMA_DebugLoopCnt++;
                // Test Stop
                if(Loop == FALSE)
                    break;
            }
                
            // Change BurstLength (Arg[0]:Rx, Arg[1]:Tx)
            ncLib_DMA_Control(GCMD_DMA_SET_BURST_LEN, Ch, BurstLength, BurstLength, CMD_END);  

            // Init Test Transfer Size            
            if(tDMATestFlag.mDMA_TestIsSimple == 1)
                TestDataSize = TestMaxSize;
            else
                TestDataSize = BurstLength; 

        }
    }
    DEBUGMSG(MSGINFO, "\n"); 


    // DeInit DMA Channel 
    APACHE_TEST_DMA_DeInit(Ch, &tDMAParam);
    
}


void APACHE_TEST_DMA_MtoM_SFix_DIncr(eDMA_CH Ch, UINT8 Loop)
{
    INT32 ret = NC_SUCCESS; 

    UINT8  SrcBuff[TEST_DMA_STACK_BUFF_SIZE] __attribute__ ((aligned (4)));
    UINT8  DstBuff[TEST_DMA_STACK_BUFF_SIZE] __attribute__ ((aligned (4)));   
    
    tDMA_PARAM tDMAParam;
    UINT32 BurstLength;  
    
    UINT32 TestDataSize;  
    UINT32 TestMaxSize;    

    UINT32 pSrcBuff;
    UINT32 pDstBuff;
    UINT32 pInstBuff;


    // Test Config 
    BurstLength = 1;
    TestMaxSize = tDMATestFlag.mDMA_TestMaxSize;


    // Test Buffer Select
    if(tDMATestFlag.mDMA_TestUsedBuff == TEST_DMA_BUFF_STACK)
    {
        // Stack(SRAM) : cacheable
        pSrcBuff  = (UINT32)&SrcBuff[0];
        pDstBuff  = (UINT32)&DstBuff[0];
        pInstBuff = (UINT32)&gTestDMAInstBuff[0];
        
        if(TestMaxSize > TEST_DMA_STACK_BUFF_SIZE)
            TestMaxSize = TEST_DMA_STACK_BUFF_SIZE;
    }
    else if(tDMATestFlag.mDMA_TestUsedBuff == TEST_DMA_BUFF_BSS)
    {
        // BSS(Virtural DDR) : cacheable
        pSrcBuff  = (UINT32)&gTestDMASrcBuff[0];
        pDstBuff  = (UINT32)&gTestDMADstBuff[0];
        pInstBuff = (UINT32)&gTestDMAInstBuff[0];

        if(TestMaxSize > TEST_DMA_BSS_BUFF_SIZE)
            TestMaxSize = TEST_DMA_BSS_BUFF_SIZE;
    }
    else
    {
        // DDR(Physical DDR) : non-cacheable
        if(ASM_GET_CORE_ID() == DLS_CORE)
            pSrcBuff = _ALIGN(TEST_PHY_DDR_BASE, 0x04);
        else
            pSrcBuff = _ALIGN(TEST_PHY_DDR_BASE + (16*MB), 0x04);

        pDstBuff  = _ALIGN(pSrcBuff + TestMaxSize, 0x04);
        pInstBuff = _ALIGN(pDstBuff + TestMaxSize, 0x10);
    }

    
    __test_dma_display_meminfo("APACHE_TEST_DMA_MtoM_SFix_DIncr", (UINT8*)pSrcBuff, (UINT8*)pDstBuff, (UINT8*)pInstBuff);  


    // Set DMA Operation Mode 
    tDMAParam.mReqType    = DMA_MEM_TO_MEM; 
    tDMAParam.mInstAddr   = (UINT32)pInstBuff;  
    
    tDMAParam.mIntEn      = tDMATestFlag.mDMA_IsrEn;
    tDMAParam.mRxIncrEn   = DISABLE;  
    tDMAParam.mRxBurstLen = DMA_BURST_LEN_MIN;  
    tDMAParam.mTxIncrEn   = ENABLE;  
    tDMAParam.mTxBurstLen = DMA_BURST_LEN_MIN;  
    tDMAParam.mSwap       = DMA_SWAP_NO; 


    // Init DMA Channel 
    APACHE_TEST_DMA_Init(Ch, &tDMAParam);


    // Debug Buffer Write and Clear
    __test_dma_dumy_buff((UINT8*)pSrcBuff, TestMaxSize, Ch);
    __test_dma_clear_buff((UINT8*)pInstBuff, (TestMaxSize/DMA_TRANSFER_SIZE)*16, TEST_DMA_CLS_VALUE);


    // Set Test Mode
    if(tDMATestFlag.mDMA_TestIsSimple == 1)
        TestDataSize = TestMaxSize;
    else
        TestDataSize = BurstLength;


    // Test Run.. 
    // Input Key Exit ('Q' or 'q')
    while(!APACHE_TEST_ExitKey())
    {        
        // Dest Buffer Clear
        __test_dma_clear_buff((UINT8*)pDstBuff, TestMaxSize, TEST_DMA_CLS_VALUE);
        __test_dma_dummy_buff_marking((UINT8*)pSrcBuff, ((TestDataSize<<8)|(BurstLength)));

        
        // DMA Test Mode Display
        __test_dma_display_info(Ch, BurstLength, TestDataSize);


        // Toggle - Debug Gpio Port
        APACHE_TEST_DebugGPIOSet(tDMATestFlag.mDMA_DebupGpioPort+Ch, GPIO_HIGH);
        APACHE_TEST_StopWatch(ON);
        

        // DMA Start
        ret = ncLib_DMA_Control(GCMD_DMA_START, Ch, pSrcBuff, pDstBuff, TestDataSize, CMD_END);
        if(ret == NC_SUCCESS)
        {
            // DMA Done Wait
            while((ret = ncLib_DMA_Control(GCMD_DMA_DONE, Ch, CMD_END)) == NC_FAILURE)
            {
                if(APACHE_TEST_mTimeOut(TEST_DMA_TIME_OUT))
                {
                    DEBUGMSG(MSGWARN, " - DMA TimeOut!~\n");
                    break;
                }
            }
            APACHE_TEST_mTimeOut(0);
        }
        else
        {
            DEBUGMSG(MSGERR, "DMA Start Error!\n"); 
        }
        

        // Toggle - Debug Gpio Port
        if(tDMAParam.mIntEn == OFF)
        {
            APACHE_TEST_StopWatch(OFF);
            APACHE_TEST_DebugGPIOSet(tDMATestFlag.mDMA_DebupGpioPort+Ch, GPIO_LOW);
        }


        // DMA Status Check
        if(ret != NC_FAILURE)
        {   
            if(ret != 0x01)
                DEBUGMSG(MSGERR, "\nDMA Error Status : 0x%04X\n", ret);
        }


        // Compare - Src vs Dest Buffer
        ret = __test_dma_compare_buff_sfix_dincr((UINT8*)pSrcBuff, (UINT8*)pDstBuff, TestDataSize, TestMaxSize, BurstLength);


        // Compare - Error Stop
        if(ret != NC_SUCCESS)
            break;


        // Change Data Size
        TestDataSize += BurstLength;
        if(TestDataSize > TestMaxSize)
        {
            DEBUGMSG(MSGINFO, "\n");
            
            // Change BurstLength 
            BurstLength = (BurstLength<<1);
            if(BurstLength > 4)
            {
                BurstLength = DMA_BURST_LEN_MIN;

                tDMATestFlag.mDMA_DebugLoopCnt++;
                // Test Stop
                if(Loop == FALSE)
                    break;
            }
                
            // Change BurstLength (Arg[0]:Rx, Arg[1]:Tx)
            ncLib_DMA_Control(GCMD_DMA_SET_BURST_LEN, Ch, BurstLength, BurstLength, CMD_END);  

            // Init Test Transfer Size            
            if(tDMATestFlag.mDMA_TestIsSimple == 1)
                TestDataSize = TestMaxSize;
            else
                TestDataSize = BurstLength; 
            
        }
    }
    DEBUGMSG(MSGINFO, "\n"); 


    // DeInit DMA Channel 
    APACHE_TEST_DMA_DeInit(Ch, &tDMAParam);
    
}


void APACHE_TEST_DMA_MtoM_SIncr_DIncr(eDMA_CH Ch, UINT8 Loop)
{
    INT32 ret = NC_SUCCESS;  

    UINT8  SrcBuff[TEST_DMA_STACK_BUFF_SIZE] __attribute__ ((aligned (4)));
    UINT8  DstBuff[TEST_DMA_STACK_BUFF_SIZE] __attribute__ ((aligned (4)));   

    tDMA_PARAM tDMAParam;
    UINT32 BurstLength;  
    
    UINT32 TestDataSize;  
    UINT32 TestMaxSize;

    UINT32 pSrcBuff;
    UINT32 pDstBuff;
    UINT32 pInstBuff;


    // Test Config    
    BurstLength = tDMATestFlag.mDMA_TestBurstLength;      
    TestMaxSize = tDMATestFlag.mDMA_TestMaxSize;


    // Test Buffer Select
    if(tDMATestFlag.mDMA_TestUsedBuff == TEST_DMA_BUFF_STACK)
    {
        // Stack(SRAM) : cacheable
        pSrcBuff  = (UINT32)&SrcBuff[0];
        pDstBuff  = (UINT32)&DstBuff[0];
        pInstBuff = (UINT32)&gTestDMAInstBuff[0];
        
        if(TestMaxSize > TEST_DMA_STACK_BUFF_SIZE)
            TestMaxSize = TEST_DMA_STACK_BUFF_SIZE;
    }
    else if(tDMATestFlag.mDMA_TestUsedBuff == TEST_DMA_BUFF_BSS)
    {
        // BSS(Virtural DDR) : cacheable
        pSrcBuff  = (UINT32)&gTestDMASrcBuff[0];
        pDstBuff  = (UINT32)&gTestDMADstBuff[0];
        pInstBuff = (UINT32)&gTestDMAInstBuff[0];

        if(TestMaxSize > TEST_DMA_BSS_BUFF_SIZE)
            TestMaxSize = TEST_DMA_BSS_BUFF_SIZE;
    }
    else
    {
        // DDR(Physical DDR) : non-cacheable
        if(ASM_GET_CORE_ID() == DLS_CORE)
            pSrcBuff = _ALIGN(TEST_PHY_DDR_BASE, 0x04);
        else
            pSrcBuff = _ALIGN(TEST_PHY_DDR_BASE + (16*MB), 0x04);

        pDstBuff  = _ALIGN(pSrcBuff + TestMaxSize, 0x04);
        pInstBuff = _ALIGN(pDstBuff + TestMaxSize, 0x10);
    }


    __test_dma_display_meminfo("APACHE_TEST_DMA_MtoM_SIncr_DIncr", (UINT8*)pSrcBuff, (UINT8*)pDstBuff, (UINT8*)pInstBuff);  


    // Set DMA Operation Mode 
    tDMAParam.mReqType    = DMA_MEM_TO_MEM;  
    tDMAParam.mInstAddr   = (UINT32)pInstBuff; 
    
    tDMAParam.mIntEn      = tDMATestFlag.mDMA_IsrEn;
    tDMAParam.mRxIncrEn   = ENABLE;  
    tDMAParam.mRxBurstLen = BurstLength;  
    tDMAParam.mTxIncrEn   = ENABLE; 
    tDMAParam.mTxBurstLen = BurstLength;  
    tDMAParam.mSwap       = DMA_SWAP_NO;  


    // Init DMA Channel 
    APACHE_TEST_DMA_Init(Ch, &tDMAParam);


    // Debug Buffer Write and Clear
    __test_dma_dumy_buff((UINT8*)pSrcBuff, TestMaxSize, Ch);
    __test_dma_clear_buff((UINT8*)pInstBuff, (TestMaxSize/DMA_TRANSFER_SIZE)*16, TEST_DMA_CLS_VALUE);


    // Set Test Mode
    if(tDMATestFlag.mDMA_TestIsSimple == 1)
        TestDataSize = TestMaxSize;
    else
        TestDataSize = 1; 

    
    // Test Run.. 
    // Input Key Exit ('Q' or 'q')
    while(!APACHE_TEST_ExitKey())
    {
        // Dest Buffer Clear
        __test_dma_clear_buff((UINT8*)pDstBuff, TestMaxSize, TEST_DMA_CLS_VALUE);
        __test_dma_dummy_buff_marking((UINT8*)pSrcBuff, ((TestDataSize<<8)|(BurstLength)));

        
        // DMA Test Mode Display
        __test_dma_display_info(Ch, BurstLength, TestDataSize);


        // Toggle - Debug Gpio Port
        APACHE_TEST_DebugGPIOSet(tDMATestFlag.mDMA_DebupGpioPort+Ch, GPIO_HIGH);
        APACHE_TEST_StopWatch(ON);
        

        // DMA Start
        ret = ncLib_DMA_Control(GCMD_DMA_START, Ch, pSrcBuff, pDstBuff, TestDataSize, CMD_END);
        if(ret == NC_SUCCESS)
        {
            // DMA Done Wait
            while((ret = ncLib_DMA_Control(GCMD_DMA_DONE, Ch, CMD_END)) == NC_FAILURE)
            {
                if(APACHE_TEST_mTimeOut(TEST_DMA_TIME_OUT))
                {
                    DEBUGMSG(MSGWARN, " - DMA TimeOut!~\n");
                    break;
                }
            }
            APACHE_TEST_mTimeOut(0);
        }
        else
        {
            DEBUGMSG(MSGERR, "DMA Start Error!\n"); 
        }


        // Toggle - Debug Gpio Port
        if(tDMAParam.mIntEn == OFF)
        {
            APACHE_TEST_StopWatch(OFF);
            APACHE_TEST_DebugGPIOSet(tDMATestFlag.mDMA_DebupGpioPort+Ch, GPIO_LOW);
        }


        // DMA Status Check
        if(ret != NC_FAILURE)
        {   
            if(ret != 0x01)
                DEBUGMSG(MSGERR, "\nDMA Error Status : 0x%04X\n", ret);
        }


        // Compare - Src vs Dest Buffer
        ret = __test_dma_compare_buff_sincr_dincr((UINT8*)pSrcBuff, (UINT8*)pDstBuff, TestDataSize, TestMaxSize);

        
        // Compare - Error Stop
        if(ret != NC_SUCCESS)
            break;


        // Change Data Size
        TestDataSize += 1;
        if(TestDataSize > TestMaxSize)
        {
            DEBUGMSG(MSGINFO, "\n");
            
            // Init Test Transfer Size            
            if(tDMATestFlag.mDMA_TestIsSimple == 1)
                TestDataSize = TestMaxSize;
            else
                TestDataSize = 1; 

            if(tDMATestFlag.mDMA_TestBurstCtrl == ON)
            {
                // Change BurstLength 
                BurstLength += 1;
                if(BurstLength > DMA_BURST_LEN_MAX)
                {                
                    BurstLength = DMA_BURST_LEN_MIN;

                    tDMATestFlag.mDMA_DebugLoopCnt++;
                    // Test Stop
                    if(Loop == FALSE)
                        break;
                }
     
                // Change BurstLength (Arg[0]:Rx, Arg[1]:Tx)
                ncLib_DMA_Control(GCMD_DMA_SET_BURST_LEN, Ch, BurstLength, BurstLength, CMD_END);  
            }
            else
            {
                // Test Stop
                if(Loop == FALSE)
                    break;
            }
        }
    }
    DEBUGMSG(MSGINFO, "\n"); 


    // DeInit DMA Channel 
    APACHE_TEST_DMA_DeInit(Ch, &tDMAParam);

}


INT32 APACHE_TEST_DMA_CUTMode(void)
{
    INT32 select;
    char buf[256];
    eDMA_CH Ch;


    // Default Init Variable
    tDMATestFlag = tDMATestFlag_Def;
    
    // Check Core
    if(ASM_GET_CORE_ID() == DLS_CORE)
        tDMATestFlag.mDMA_TestCh = DMA_CH0;
    else
        tDMATestFlag.mDMA_TestCh = DMA_CH2;   


    while(1)
    {
        Ch = tDMATestFlag.mDMA_TestCh;
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - DMA                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " DMA Controller                                             \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");    
        DEBUGMSG(MSGINFO, " Memory To Memory                                           \n");             
        DEBUGMSG(MSGINFO, " <1> Mode : Rx(Increment) Tx(Increment)                     \n");
        DEBUGMSG(MSGINFO, " <2> Mode : Rx(Fixed)     Tx(Increment)                     \n");
        DEBUGMSG(MSGINFO, " <3> Mode : Rx(Increment) Tx(Fixed)                         \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <A> DMA Test Channel         : %d                          \n", Ch);
        DEBUGMSG(MSGINFO, " <B> DMA Interrupt On/Off     : %s                          \n", (tDMATestFlag.mDMA_IsrEn)?"On":"Off");
        DEBUGMSG(MSGINFO, " <C> DMA BurstLength On/Off   : %s                          \n", (tDMATestFlag.mDMA_TestBurstCtrl)?"On":"Off");
        DEBUGMSG(MSGINFO, " <D> DMA BurstLength Change   : DMA_BL_%02dXFER             \n", tDMATestFlag.mDMA_TestBurstLength);  
        DEBUGMSG(MSGINFO, " <E> DMA Test MemSize Change  : 0x%07X (%dB)                \n", tDMATestFlag.mDMA_TestMaxSize, tDMATestFlag.mDMA_TestMaxSize); 
        DEBUGMSG(MSGINFO, " <F> DMA Test MemAlign Change : 0x%02X                      \n", tDMATestFlag.mDMA_TestAlign); 
        DEBUGMSG(MSGINFO, " <G> DMA Test Used Buff       : %s                          \n", (tDMATestFlag.mDMA_TestUsedBuff == 0)?"Stack":(tDMATestFlag.mDMA_TestUsedBuff == 1)?"BSS":"DDR"); 
        DEBUGMSG(MSGINFO, " <H> DMA Test Mode Change     : %s                          \n", (tDMATestFlag.mDMA_TestIsSimple)?"Simple":"Full");
        DEBUGMSG(MSGINFO, " <I> DMA Test Loop Mode       : %s                          \n", (tDMATestFlag.mDMA_DebugLoopOn)?"On":"Off");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");      
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to main menu ...                        \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_DMA_MtoM_SIncr_DIncr(Ch, tDMATestFlag.mDMA_DebugLoopOn);
            break;

            case 2:
                APACHE_TEST_DMA_MtoM_SFix_DIncr(Ch, tDMATestFlag.mDMA_DebugLoopOn);
            break;

            case 3:
                APACHE_TEST_DMA_MtoM_SIncr_DFix(Ch, tDMATestFlag.mDMA_DebugLoopOn);
            break;

            case 4:
                APACHE_TEST_DMA_MtoM_SIncr_DIncr_Swap(Ch, tDMATestFlag.mDMA_DebugLoopOn);
            break;

            case 5:
            {
                tDMATestFlag.mDMA_TestUsedBuff = TEST_DMA_BUFF_STACK;
                APACHE_TEST_DMA_MtoM_SIncr_DIncr(Ch, FALSE);
                APACHE_TEST_DMA_MtoM_SFix_DIncr(Ch, FALSE);
                APACHE_TEST_DMA_MtoM_SIncr_DFix(Ch, FALSE);
                APACHE_TEST_DMA_MtoM_SIncr_DIncr_Swap(Ch, FALSE);
                
                tDMATestFlag.mDMA_TestUsedBuff = TEST_DMA_BUFF_BSS;
                APACHE_TEST_DMA_MtoM_SIncr_DIncr(Ch, FALSE);
                APACHE_TEST_DMA_MtoM_SFix_DIncr(Ch, FALSE);
                APACHE_TEST_DMA_MtoM_SIncr_DFix(Ch, FALSE);
                APACHE_TEST_DMA_MtoM_SIncr_DIncr_Swap(Ch, FALSE);
                
                tDMATestFlag.mDMA_TestUsedBuff = TEST_DMA_BUFF_DDR;
                APACHE_TEST_DMA_MtoM_SIncr_DIncr(Ch, FALSE);
                APACHE_TEST_DMA_MtoM_SFix_DIncr(Ch, FALSE);
                APACHE_TEST_DMA_MtoM_SIncr_DFix(Ch, FALSE);
                APACHE_TEST_DMA_MtoM_SIncr_DIncr_Swap(Ch, FALSE);
            }
            break;

            case 6:
                APACHE_TEST_DMA_MtoM_SIncr_DIncr_UsedDDR_2CH(tDMATestFlag.mDMA_DebugLoopOn);  
            break;

            //-----------------------------------------------------------
            // Test Flow Ctrl
            case 10:
                APACHE_TEST_DMA_ChannelChange(Ch);
            break;

            case 11:
                _REVERSE(tDMATestFlag.mDMA_IsrEn);
            break;

            case 12:
                _REVERSE(tDMATestFlag.mDMA_TestBurstCtrl);
            break;
            
            case 13:
                APACHE_TEST_DMA_BurstLengthChange();
            break;

            case 14:
                APACHE_TEST_DMA_MemSizeChange();
            break;

            case 15:
                APACHE_TEST_DMA_MemAlignChange();
            break;

            case 16:
                 if(++tDMATestFlag.mDMA_TestUsedBuff > TEST_DMA_BUFF_DDR)
                    tDMATestFlag.mDMA_TestUsedBuff = TEST_DMA_BUFF_STACK;
            break;

            case 17:
                _REVERSE(tDMATestFlag.mDMA_TestIsSimple);
            break;

            case 18:
                _REVERSE(tDMATestFlag.mDMA_DebugLoopOn);
            break;

            case 35:
                _REVERSE(tDMATestFlag.mDMA_DebugMsgOn);
            break;
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to main menu\n");
            goto DMA_Exit;
        }
    }

DMA_Exit:

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_DMA */


/* End Of File */

