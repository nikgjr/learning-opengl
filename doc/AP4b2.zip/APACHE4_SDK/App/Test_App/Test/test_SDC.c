/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "test.h"

#if ENABLE_IP_SDC










/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define rSDC_BASE                           APACHE_SDC_BASE                       

#define rSDC_CFG                            0x00
    #define bSDC_CFG_1BIT                   (0<<0)
    #define bSDC_CFG_4BIT                   (1<<0)
    #define bSDC_CFG_DMA_SINGLE             (0<<1)
    #define bSDC_CFG_DMA_BURST4             (1<<1)
    #define bSDC_CFG_CMD_CRC                (1<<2)      // Command CRC
    #define bSDC_CFG_BLKR_CRC               (1<<3)      // Block Read CRC
    #define bSDC_CFG_CMD_FIN                (1<<4)      // Send Command Finish
    #define bSDC_CFG_RSP_FIN                (1<<5)      // Command Resp Recived
    #define bSDC_CFG_BLKW_STA               (1<<6)      // Block Write start
    #define bSDC_CFG_BLKW_FIN               (1<<7)      // Block Write Finish
    #define bSDC_CFG_BLKW_RSP_STA           (1<<8)      // Block Write Resp Start
    #define bSDC_CFG_BLKW_RSP_FIN           (1<<9)      // Block Write Resp Finish
    #define bSDC_CFG_BLKR_RSP_STA           (1<<10)     // Block Read Resp Start
    #define bSDC_CFG_BLKR_RSP_FIN		    (1<<11)     // Block Read Resp Finish
    #define bSDC_CFG_DAT1_CD_INT            (1<<12)     // DATA1 CD PIN Select
    #define bSDC_CFG_BLKR_OVR               (1<<13)     // Block Read Overrun
    #define bSDC_CFG_BLKW_UND               (1<<14)     // Block Write Underrun
    #define bSDC_CFG_CMD_TIMEOUT            (1<<15)     // Command TimeOut
    #define bSDC_CFG_BLK_TIMEOUT            (1<<16)     // Block TimeOut
    #define bSDC_CFG_MULTBLK_WR_END         (1<<17)     // All Block Write Finish
    #define bSDC_CFG_MULTBLK_RD_END         (1<<18)     // All Block Read Finish
    #define bSDC_CFG_CARD_DETECT            (1<<19)     // Card Detect Posedge (0->1)
    #define bSDC_CFG_ENABLE_SDIO            (1U<<31)


#define rSDC_CLKI_SCALE                     0x04
#define rSDC_CLKO_WAV                       0x08

#define	rSDC_START_OP			(0x0c)
#define rSDC_STS                            0x10
    #define bSDC_STS_CMD_CRC                (1<<2)      // Command CRC Error      
    #define bSDC_STS_BLKR_CRC               (1<<3)      // Block Read CRC Error
    #define bSDC_STS_CMD_FIN                (1<<4)      // Send Command Finish Error
    #define bSDC_STS_RSP_FIN                (1<<5)      // Command Resp Recived  Error
    #define bSDC_STS_BLKW_STA               (1<<6)      // Block Write start Error
    #define bSDC_STS_BLKW_FIN               (1<<7)      // Block Write Finish Error
    #define bSDC_STS_BLKW_RSP_STA           (1<<8)      // Block Write Resp Start Error
    #define bSDC_STS_BLKW_RSP_FIN           (1<<9)      // Block Write Resp Finish Error
    #define bSDC_STS_BLKR_RSP_STA           (1<<10)     // Block Read Resp Start Error
    #define bSDC_STS_BLKR_RSP_FIN		    (1<<11)     // Block Read Resp Finish Error
    #define bSDC_STS_DAT1_CD_INT            (1<<12)     // DATA1 CD PIN occurred
    #define bSDC_STS_BLKR_OVR               (1<<13)     // Block Read Overrun Error
    #define bSDC_STS_BLKW_UND               (1<<14)     // Block Write Underrun Error
    #define bSDC_STS_CMD_TIMEOUT            (1<<15)     // Command TimeOut
    #define bSDC_STS_BLK_TIMEOUT            (1<<16)     // Block TimeOut
    #define bSDC_STS_MULTBLK_WR_END         (1<<17)     // All Block Write Finish Error
    #define bSDC_STS_MULTBLK_RD_END         (1<<18)     // All Block Read Finish Error
    #define bSDC_STS_CARD_DETECT            (1<<19)     // CD Turned On
    #define bSDC_STS_WRITE_PROTECT          (1<<20)     // WP Turned On



    
#define rSDC_CORE_ADR			(0x14)
#define	rSDC_CORE_ADRH			(0x18)
#define	rSDC_RESP_CNT			(0x1c)
#define	rSDC_BLOCK_CNT			(0x20)
#define	rSDC_GDATA_CNT			(0x24)
#define	rSDC_CMDL				(0x28)
#define	rSDC_CMDH				(0x2c)
#define	rSDC_CMD_RESP			(0x30)
#define	rSDC_CMD_RESP1			(0x34)
#define	rSDC_CMD_RESP2			(0x38)
#define	rSDC_CMD_RESP3			(0x3c)
#define rSDC_CMD_RESP_CRC		(0x40)
#define	rSDC_B_CRC_STAT		(0x44)
#define	rSDC_TIMEOUT                    0x48
#define rSDC_ECMDL         	(0x4c)	// end COMMAND[31:00]     <---- ���⼭���� end command ����
#define rSDC_ECMDH         	(0x50)	// end COMMAND[63:32]
#define rSDC_ECMD_RESP     	(0x54)	// ecmd resp 
#define rSDC_ECMD_RESP1    	(0x58)	// ecmd resp
#define rSDC_ECMD_RESP_CRC 	(0x5c)	// ecmd resp crc {16'b0, computed crc, received crc}
#define rSDC_ECMD_GDATA_CNT	(0x60)	// when to start ecmd 
#define rSDC_DMA_CUR_BEAT_CNT	(0x64)	// Current dma beat count.
#define rSDC_BR_CRC_COMP0		(0x68)	// blk read's computed crc, {dat[1], dat[0]}
#define rSDC_BR_CRC_COMP1		(0x6c)	// blk read's computed crc, {dat[1], dat[0]}
#define rSDC_BR_CRC_REC0		(0x70)	// blk read's received crc, {dat[1], dat[0]}
#define rSDC_BR_CRC_REC1		(0x74)	// blk read's received crc, {dat[1], dat[0]}



//---------------------------------------------------------------------------------------------------

//#define SDCLK_25M		// SDCLK = 25.0 MHz
//#define SDCLK_16M		// SDCLK = 16.7 MHz
//#define SDCLK_12M		// SDCLK = 12.5 MHz
#define SDCLK_3M		// SDCLK = 3.125 MHz


// SD Controller Registers
#define	A_SETUP				(0x00)
#define	A_CLKI_SCALE		(0x04)
#define A_CLKO_WAV			(0x08)
#define	A_START_OP			(0x0c)
#define A_STATUS			(0x10)
#define A_CORE_ADR			(0x14)
#define	A_CORE_ADRH			(0x18)
#define	A_RESP_CNT			(0x1c)
#define	A_BLOCK_CNT			(0x20)
#define	A_GDATA_CNT			(0x24)
#define	A_CMDL				(0x28)
#define	A_CMDH				(0x2c)
#define	A_CMD_RESP			(0x30)
#define	A_CMD_RESP1			(0x34)
#define	A_CMD_RESP2			(0x38)
#define	A_CMD_RESP3			(0x3c)
#define A_CMD_RESP_CRC		(0x40)
#define	A_B_CRC_STAT		(0x44)
#define	A_TIMEOUT			(0x48)
#define A_ECMDL         	(0x4c)	// end COMMAND[31:00]     <---- ���⼭���� end command ����
#define A_ECMDH         	(0x50)	// end COMMAND[63:32]
#define A_ECMD_RESP     	(0x54)	// ecmd resp 
#define A_ECMD_RESP1    	(0x58)	// ecmd resp
#define A_ECMD_RESP_CRC 	(0x5c)	// ecmd resp crc {16'b0, computed crc, received crc}
#define A_ECMD_GDATA_CNT	(0x60)	// when to start ecmd 
#define A_DMA_CUR_BEAT_CNT	(0x64)	// Current dma beat count.
#define A_BR_CRC_COMP0		(0x68)	// blk read's computed crc, {dat[1], dat[0]}
#define A_BR_CRC_COMP1		(0x6c)	// blk read's computed crc, {dat[1], dat[0]}
#define A_BR_CRC_REC0		(0x70)	// blk read's received crc, {dat[1], dat[0]}
#define A_BR_CRC_REC1		(0x74)	// blk read's received crc, {dat[1], dat[0]}




// <SETUP>
//
// [00]     :   0:1-bit mode, 1:4-bit mode
// [01]     :   reserved
// [02]     :   enable intr by 'cmd crc error'
// [03]     :   enable intr by 'BR crc error'
// [04]     :   enable intr by 'send cmd finish'
// [05]     :   enable intr by 'resp finish(receive)'
// [06]     :   enable intr by 'blockw start'
// [07]     :   enable intr by 'blockw finish'
// [08]     :   enable intr by 'blockw resp start'
// [09]     :   enable intr by 'blockw resp finish'
// [10]     :   enable intr by 'blockr receive start'
// [11]     :   enable intr by 'blockr receive finish'
// [12]     :   enable intr by 'DAT1'
// [13]     :   enable intr by 'blockr overrun'
// [14]     :   enable intr by 'blockw underrun'
// [15]     :   enable intr by 'cmd timeout'
// [16]     :   enable intr by 'block timeout'
// [17]     :   enable intr by 'multiple/single block write end' <-- single �Ǵ� multiple block �� �Ϸ�Ǹ� interrupt �߻�
// [18]     :   enable intr by 'multiple/single block read end'  <-- �̰��� read�� ���ؼ�����. 
// ... 
// [31]     :   enable sdio
#define SD_1BIT				0x00000000
#define SD_4BIT				0x00000001
#define SD_DMA_SINGLE		0x00000000
#define SD_DMA_BURST4		0x00000002
#define SD_CCRCE			0x00000004
#define SD_DCRCE			0x00000008
#define SD_CMDFIN			0x00000010
#define SD_RSPFIN			0x00000020
#define SD_BLKWSTA			0x00000040
#define SD_BLKWFIN			0x00000080
#define SD_BLKW_RSPSTA		0x00000100
#define SD_BLKW_RSPFIN		0x00000200
#define SD_BLKR_RCVSTA		0x00000400
#define SD_BLKR_RCBFIN		0x00000800
#define SD_DAT1INT			0x00001000
#define SD_BLKW_OVR			0x00002000
#define SD_BLKW_UNR			0x00004000
#define SD_CMD_TIMEOUT		0x00008000
#define SD_BLK_TIMEOUT		0x00010000	// [16]
#define SD_MULTBLK_WR_END	0x00020000	// [17]
#define SD_MULTBLK_RD_END	0x00040000	// [18]
#define SD_ENABLE_SDIO	    0x80000000	// [31]


// <START_OP>
//
// o. The bits are 'triggered', not registered.
//
// [00]		:	start command
// [01]		: 	wait resp or not
// [02]		:	wait resp, but it's long resp, 136-bit resp
// [03]		: 	ignore resp's crc
// [04]		:	start block
// [05]		:	block read/write, 0=read, 1=write
// [06]		: 	ecmd is pending, 0=no ecmd(single), 1=send ecmd at (ecmd_gdata_cnt)
// [07]		: 	wait ecmd's resp
#define START_CMD			(0x01)
#define WAIT_RSP			(0x02)
#define WAIT_RSP_LONG		(0x04)
#define RSP_IGNORE_CRC		(0x08)
#define START_BLK			(0x10)
#define BLK_WRITE			(0x20)
#define SEND_ECMD			(0x40)
#define WAIT_ECMD_RSP		(0x80)

// <STATUS>
// o. Write 0x1 to the corresponding bit clears itself.
//
// [00]     :   reserved
// [01]     :   reserved
// [02]     :   'cmd resp crc error'
// [03]     :   'blockwr crc error'
// [04]     :   'send cmd finish'
// [05]     :   'resp finish(receive)'
// [06]     :   'blockw start'
// [07]     :   'blockw finish'
// [08]     :   'blockw resp start'
// [09]     :   'blockw resp finish'
// [10]     :   'blockr receive start'
// [11]     :   'blockr receive finish'
// [12]     :   'DAT1'
// [13]     :   'blockr overrun'
// [14]     :   'blockw underrun'
// [15]		:	'cmd timeout'
// [16]		:	'block timeout'
// [17]     :   'multiple/single block write end'  <-- single/multiple block transfer�� �Ϸ�� ���� �� �� �ֽ��ϴ�. single�� ��� ��blockw resp finish���� �ߺ��˴ϴ�. 
// [18]     :   'multiple/single block read end'   <-- read�� ���ؼ� �Դϴ�
#define CMD_RESP_CRC_ERROR		0x00000004
#define BLKRW_RESP_CRC_ERROR		0x00000008
#define SND_CMD_FINISH			0x00000010
#define RCV_RSP_FINISH			0x00000020
#define BLOCK_WRITE_START		0x00000040
#define BLOCK_WRITE_FINISH		0x00000080
#define BLKW_RESP_START			0x00000100
#define BLKW_RESP_FINISH		0x00000200
#define BLOCK_READ_START		0x00000400
#define BLOCK_READ_FINISH		0x00000800
#define DAT1_INT			0x00001000
#define BLKR_OVERRUN			0x00002000
#define BLKR_UNDERRUN			0x00004000
#define CMD_TIMEOUT			0x00008000
#define BLKRW_TIMEOUT			0x00010000
#define MULTBLK_WRITE_END		0x00020000
#define MULTBLK_READ_END		0x00040000
#define CARD_DETECT			0x00080000
#define WRITE_PROTECT			0x00100000

// Response R1, Card Status
//
// [1,0]		:	reserved for manufacturer test mode
// [2]			:	reserved for application specific commands
// [3]			:	AKE_SEQ_ERROR
// [4]			:	reserved for SD I/O Card. (!!!!!!!!!!!!!!!!!!!!!!!)
// [5]			:	APP_CMD
// [7,6]		:	N/A
// [8]			:	READY_FOR_DATA
// [12:9]		:	CURRENT_STATE (4bits)
//					0 : idle,	1 : ready,	2 : ident,	3 : stby,
//					4 : tran,	5 : data,	6 : rcv,	7 : prg,
//					8 : dis,	9-14 : reserved,		15 : reserved for I/O mode
// [13]			:	ERASE_STATE
// [14]			:	CARD_ECC_DISABLED
// [15]			:	WP_ERASE_SKIP
// [16]			:	CSD_OVERWRITE
// [17,18]		:	reserved
// [19]			:	ERROR
// [20]			:	CC_ERROR
// [21]			:	CARD_ECC_FAILED
// [22]			:	ILLEGAL_COMMAND
// [23]			:	COM_CRC_ERROR
// [24]			:	LOCK_UNLOCK_FAILED
// [25]			:	CARD_IS_LOCKED
// [26]			:	WP_VIOLATION
// [27]			:	ERASE_PARAM
// [28]			:	ERASE_SEQ_ERROR
// [29]			:	BLOCK_LEN_ERROR
// [30]			:	ADDRESS_ERROR
// [31]			:	OUT_OR_RANGE

#define SD_TIMEOUT_LIMIT	0x9000 //from Dynalith


//Commands
//CMDI - Command Index : Index of the next command
#define CMD0    0x00	// GO_IDLE_STATE
#define CMD2    0x02	// ALL_SEND_CID
#define CMD3    0x03	// SEND_RELATIVE_ADDR
#define CMD7    0x07	// SELECT/DESELECT_CARD
#define CMD8    0x08	// SEND_IF_COND
#define CMD9    0x09	// SEND_CSD
#define CMD10   0x0a	// SEND_CID
#define CMD12	0x0c	// STOP_TRANSMISSION
#define CMD13	0x0d	// SEND_STATUS
#define CMD16   0x10	// SET_BLOCKLEN
#define CMD17   0x11	// READ_SINGLE_BLOCK
#define CMD18   0x12	// READ_MULTIPLE_BLOCK
#define CMD24	0x18	// WRITE_SINGLE_BLOCK
#define CMD25	0x19	// WRITE_MULTIPLE_BLOCK
#define CMD32	0x20	// ERASE_WR_BLK_START
#define CMD33	0x21	// ERASE_WR_BLK_END
#define CMD38	0x26	// ERASE
#define CMD55   0x37	// APP_CMD

#define ACMD6   0x06	// SET_BUS_WIDTH
#define ACMD41  0x29	// SD_SEND_OP_COND
#define ACMD51   51	// READ_SCR


/*
 * Command type :
 *   bc  : broadcast commands
 *   bcr : braodcast commands with response
 *   ac  : addressed (point-to-point) commands
 *   adts: addressed (point-to-point) data transfer commands
 */
/* Commands by abbreviation                CMD#    type  argument       response */
#define SD_GO_IDLE_STATE	0x00		/* CMD0  : bc   [31:0] stuff bits    -   */
#define SD_ALL_SEND_CID		0x02		/* CMD2  : bcr  [31:0] stuff bits    R2  */
#define SD_SEND_RELATIVE_ADDR	0x03	/* CMD3  : bcr  [31:0] stuff bits    R6  */
#define SD_SELECT_DESELECT_CARD	0x07	/* CMD7  : bcr  [31:16] RCA          R1b */
#define SD_SEND_IF_COND		0x08		/* CMD8  : bcr  [31:0] See below     R7  */
#define SD_SEND_CSD		0x09			/* CMD9  : ac   [31:16] RCA          R2  */
#define SD_SEND_CID		0x0a			/* CMD10 : ac   [31:16] RCA          R2  */
#define SD_SET_BLOCKLEN		0x10		/* CMD16 : ac   [31:0] block length  R1  */
#define SD_READ_SINGLE_BLOCK	0x11	/* CMD17 : adtc [31:0] data address  R1  */
#define SD_APP_CMD              0x37	/* CMD55 : ac   [31:16] RCA          R1  */

#define SD_SET_BUS_WIDTH  	0x06		/* ACMD6 : ac   [1:0] bus width      R1  */
#define SD_SD_SEND_OP_COND	0x29		/* ACMD41: bcr  [31:0] See below     R3  */



//------------------------
//CMD ARG
//------------------------
//CMD8
#define VHS  0x100 //2.7-3.6V
#define CHECK_PATTERN 0xAA
#define PATTERN_MASK	0xFF

//ACMD41, When the card is in Idle state, the host shall issue CMD8 before ACMD41
// Response of ACMD41 is OCR Contents.(R3)
//OCR(operation condition reg) contents
#define BUSY 0x80000000		// bit-31 is Card power up status bit (busy)
#define HCS 0x40000000		// bit-30 is Card Capacity Status (CCS)
#define CCS 0x40000000		// bit-30 is Card Capacity Status (CCS)
#define VOLTAGE_MASK 0x00FFFFFF
#define VOLT 0x00FF8000		// Vdd Voltage Window Setting, 2.7V-3.6V

//CMD7
// Resonse of CMD7 is R1b
// Card Status : 
//    bit 8 : READY_FOR_DATA : '1'=ready
//    bit [12:9] : CURRENT_STATE : '3'=stby, '1'=ready
#define READY_FOR_DATA 0x100	// Card is READY_FOR_DATA
#define CARD_STATUS_STB  0x600	// Card's CURRENT_STATE = '3' = stby	

#define RCA_RCA_MASK 0xFFFF0000

#define ALD_SD_DATA_ERROR_FLAGS	(BLKRW_RESP_CRC_ERROR | BLKR_OVERRUN | BLKR_UNDERRUN | BLKRW_TIMEOUT )
#define ALD_SD_CMD_ERROR_FLAGS	(CMD_TIMEOUT | CMD_RESP_CRC_ERROR)
#define ALD_SD_CMD_DONE_FLAGS ( CMD_RESP_CRC_ERROR | RCV_RSP_FINISH | CMD_TIMEOUT | SND_CMD_FINISH)
#define ALD_SD_CMD_DONE_FLAGS2 ( CMD_RESP_CRC_ERROR | RCV_RSP_FINISH | CMD_TIMEOUT )

#define MMC_RSP_PRESENT	(1 << 0)
#define MMC_RSP_136	(1 << 1)		/* 136 bit response */
#define MMC_RSP_CRC	(1 << 2)		/* expect valid crc */
#define MMC_RSP_BUSY	(1 << 3)		/* card may send busy */
#define MMC_RSP_OPCODE	(1 << 4)		/* response contains opcode */
#define MMC_DATA_WRITE	(1 << 8)
#define MMC_DATA_READ	(1 << 9)
#define MMC_DATA_STREAM	(1 << 10)


#define ETIMEDOUT 60
#define EILSEQ 116
#define EIO 5

enum ald_sd_state {
	STATE_IDLE = 0,
	STATE_SENDING_CMD,
	STATE_SENDING_PARTIAL_CMD,
	STATE_SENDING_PARTIAL_DATA,
	STATE_SENDING_PARTIAL_STOP,
	STATE_PARTIAL_DATA_BUSY,
	STATE_SENDING_DATA,
	STATE_DATA_BUSY,
	STATE_SENDING_STOP,
	STATE_DATA_ERROR,
};

enum {
	EVENT_CMD_COMPLETE = 0,
	EVENT_PARTIAL_CMD_COMPLETE,
	EVENT_PARTIAL_XFER_COMPLETE,
	EVENT_XFER_COMPLETE,
	EVENT_PARTIAL_DATA_COMPLETE,
	EVENT_DATA_COMPLETE,
	EVENT_DATA_ERROR,
	EVENT_XFER_ERROR,
};



/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct  {
	UINT32 rca;
	UINT32 Voltage_window;
	UINT8 HCS_s;
	UINT8 Active;
	UINT8 phys_spec_2_0;
}sd_card;

struct scatterlist 
{
	UINT32 length;
	UINT32 dma_address;
};

struct data_t {
    UINT32 flags;
    struct cmd_t *stop;
    INT32 error;
    UINT32 sg_len;
    struct scatterlist *sg;
    UINT32 bytes_xfered;
    UINT32 blocks;
    UINT32 blksz;
};

struct cmd_t {
    UINT32 opcode;
    UINT32 arg;
    UINT32 resp[4];
    UINT32 flags;
    struct data_t *data;
    INT32 error;
};


struct mrq_t {
    //struct cmd_t *sbc;
    struct cmd_t *cmd;
    struct data_t *data;
    struct cmd_t *stop;
};












/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

INT32 run_task = 0;
UINT32 cmd_flags;
UINT32 pending_events = 0;
UINT32 completed_events = 0;
INT32 blk_init_start;

enum ald_sd_state state = STATE_IDLE;

struct scatterlist sg1[3];
struct scatterlist *sg = &sg1[0];

struct data_t *data;
struct cmd_t  *cmd;
struct mrq_t  *mrq;
struct cmd_t  *stop;
struct cmd_t  *cmd_keep;
struct data_t *data_keep;

volatile INT32 complete = 0;

int blocks_done;
int block_init_start;
int HCXC = 0;
UINT32 ctype;
UINT32 data_status, cmd_status;
UINT32 sg_sent=0, sg_length=0;

sd_card sd_card_0;





#if defined(__TEST_BUFF_BSS_ZONE__)
UINT8 gTestSDSrcBuff[512]       __attribute__ ((aligned (16)));
UINT8 gTestSDDstBuff[512]       __attribute__ ((aligned (16)));

#elif defined(__TEST_BUFF_STACK_ZONE__)
// The buffer should be in the function, but set here for testing.
UINT8* gTestSDSrcBuff  = (UINT8*)(APACHE_IRAM_BASE+(32*KB));
UINT8* gTestSDDstBuff  = (UINT8*)(APACHE_IRAM_BASE+(32*KB)+(16*KB));

#else
volatile UINT8* gTestSDSrcBuff  = (UINT8*)(TEST_PHY_DDR_BASE+0x02000000);
volatile UINT8* gTestSDDstBuff  = (UINT8*)(TEST_PHY_DDR_BASE+0x03000000);

#endif













/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __test_sd_display_buff(UINT8 *pBuff, UINT32 Size, UINT32 PageAddr)
{
    UINT32 i;

    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------");	
    DEBUGMSG(MSGINFO, "\n>> PageAddr = 0x%08X", PageAddr);	
    for(i=0;i<Size;i++)
    {
        if(!(i%0x10))
            DEBUGMSG(MSGINFO, "\n 0x%08X : ", PageAddr+i);	
        DEBUGMSG(MSGINFO, "%02X ", pBuff[i]);	
    }
    DEBUGMSG(MSGINFO, "\n-------------------------------------------------------------\n");	
}


static void __test_sd_dummy_buff(UINT8 *pAddr, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        pAddr[i] = i;
    } 

    ASM_DCACHE_FLUSH((UINT32)pAddr, size);
}


static void __test_sd_clear_buff(UINT8 *pAddr, UINT32 size)
{
    UINT32 i;

    for(i=0;i<size;i++)
    {
        pAddr[i] = 0;
    }

    ASM_DCACHE_FLUSH((UINT32)pAddr, size);
}


static UINT32 __test_sd_compare_buff(UINT8 *pSrc, UINT8* pDes, UINT32 size)
{
    UINT32 i;
    UINT32 nErrCnt = 0;

    for(i=0; i<size; i++)
    {
        if(*pSrc++ != *pDes++)
        {
            nErrCnt++;
        }
    }

    if(nErrCnt)
        DEBUGMSG(MSGERR, " >> Compare Error Count - %d!\n", nErrCnt);	

    return nErrCnt;
}


static void __test_sd_dummy_buff_marking(UINT8 *pAddr, UINT32 PageAddr)
{
    pAddr[0] = (PageAddr>>24 & 0xFF);
    pAddr[1] = (PageAddr>>16 & 0xFF);
    pAddr[2] = (PageAddr>>8  & 0xFF);
    pAddr[3] = (PageAddr     & 0xFF);

    ASM_DCACHE_FLUSH((UINT32)pAddr, 0);
}


static void __test_sd_set_bit(unsigned int bit, unsigned int *vec)
{
	*vec |= 1<<bit;
}


static INT32 __test_sd_and_clear_bit(UINT32 bit, UINT32 *vec)
{
    if (*vec & (1<<bit)) 
    {
        *vec &= ~(1<<bit);
        return 1;
    }
    else	
    {
        return 0;
    }
}


static void __test_sd_request_end(struct mrq_t *mrq)
{
	complete = 1;
}


static void __test_sd_start_command( struct cmd_t *cmd)
{
    UINT32 ald_cmd_flag;

    DEBUGMSG(MSGINFO, "start command: OPCODE=0x%08x, ARGR=0x%08x \n", cmd->opcode, cmd->arg);

    REGRW32(rSDC_BASE, A_CMDH) = cmd->opcode;
    REGRW32(rSDC_BASE, A_CMDL) = cmd->arg;
    ald_cmd_flag = START_CMD;
    if (cmd->flags & MMC_RSP_PRESENT) 
    {
        ald_cmd_flag |= WAIT_RSP;
        if (cmd->flags & MMC_RSP_136) 
        {
            ald_cmd_flag |= WAIT_RSP_LONG;
            REGRW32(rSDC_BASE, A_RESP_CNT) = 120;
        }
        else
        {
            REGRW32(rSDC_BASE, A_RESP_CNT) = 38;
        }
    }
    
    if (! (cmd->flags & MMC_RSP_CRC)) // ignore command CRC
        ald_cmd_flag |= RSP_IGNORE_CRC;
    if (cmd->data) 
    {
        if (cmd->opcode == 51 || cmd->opcode == 13 || cmd->opcode == 6 || cmd->opcode == 18 || cmd->opcode == 17 )
            ald_cmd_flag |= START_BLK; // if it's 'read' DMA. if it's write, trigger later in the tasklet.
    }

    cmd_flags = cmd->flags; // keep cmd flags for use in ISR 8.29
    if (cmd->flags & MMC_RSP_PRESENT) 
    {
        //  8.29
        REGRW32(rSDC_BASE, A_SETUP) = REGRW32(rSDC_BASE, A_SETUP) & ~SND_CMD_FINISH;
        REGRW32(rSDC_BASE, A_SETUP) = REGRW32(rSDC_BASE, A_SETUP) | RCV_RSP_FINISH;
    }
    else
    {
        REGRW32(rSDC_BASE, A_SETUP) = REGRW32(rSDC_BASE, A_SETUP) | SND_CMD_FINISH;
    }

    complete = 0;
    DEBUGMSG(MSGINFO, "triggering command with setup=%x\n",ald_cmd_flag);
    REGRW32(rSDC_BASE, A_START_OP) = ald_cmd_flag;
    DEBUGMSG(MSGINFO, "TIME_OUT = %x\n", REGRW32(rSDC_BASE, A_TIMEOUT));
}


static void __test_sd_start_request(struct mrq_t *mrq)
{
    struct data_t *data;
    int bytes_to_go;

    DEBUGMSG(MSGINFO, "__test_sd_start_request called (cmd->opcode=%x)\n", cmd->opcode);
    pending_events = 0;
    completed_events = 0;
    data_status = 0;

    data = mrq->data;
    if (data) 
    {
        DEBUGMSG(MSGINFO, "connecting data to cmd\n");
        mrq->cmd->data = data;
        DEBUGMSG(MSGINFO, "connecting stop to data\n");
        if (mrq->stop) data->stop = mrq->stop; // connect stop here
        else data->stop = 0;
    }
    else 
    {
        mrq->cmd->data = 0;
    }

    if (data) 
    {
        bytes_to_go = data->sg->length;
        if(ctype & 0x1) 
        { 
            // 4-bit mode here
            REGRW32(rSDC_BASE, A_BLOCK_CNT) = data->blksz*8/4;
            REGRW32(rSDC_BASE, A_GDATA_CNT) = bytes_to_go*8/4;
        }
        else 
        { 
            // 1-bit mode
            REGRW32(rSDC_BASE, A_BLOCK_CNT) = data->blksz*8;
            REGRW32(rSDC_BASE, A_GDATA_CNT) = bytes_to_go*8;
        }
        block_init_start = cmd->arg;
        DEBUGMSG(MSGINFO, "bytes_to_go = %d, bc=%d, gc=%d\n", bytes_to_go, REGRW32(rSDC_BASE, A_BLOCK_CNT), REGRW32(rSDC_BASE, A_GDATA_CNT));
    }

    if (data) 
    {
        if (data->sg_len == 1) 
        {
            blocks_done = data->blksz; // initial buffer blocks
        }
        else 
        {
            blocks_done = data->sg->length/data->blksz; // initial buffer blocks
        }
        DEBUGMSG(MSGINFO, "blocks_done = %d, setting sg_sent = 1\n",blocks_done);
        sg_sent = 1;
        sg_length = data->sg_len;
        REGRW32(rSDC_BASE, A_CORE_ADR) = data->sg->dma_address;
        DEBUGMSG(MSGINFO, "CORE_ADR set to %x\n", REGRW32(rSDC_BASE, A_CORE_ADR));
    }
    else 
    {
        sg_sent = 0; // kkk
    }

    state = STATE_SENDING_CMD;
    __test_sd_start_command(cmd);
}


static void __test_sd_send_stop_cmd(struct data_t *data)
{
    DEBUGMSG(MSGINFO, "sending stop!!\n");
    __test_sd_start_command(data->stop);
}


static void __test_sd_stop_dma()
{
    /* Data transfer was stopped by the interrupt handler */
    __test_sd_set_bit(EVENT_XFER_COMPLETE, &pending_events);
}


static UINT8 __test_sd_wait_cmd_rsp2(void)
{
    volatile UINT32 r1;
    UINT8 ret = 4;

    while(1)
    {
        r1 = REGRW32(rSDC_BASE,A_STATUS);
        
        if((r1 & RCV_RSP_FINISH) == RCV_RSP_FINISH)
        {
            DEBUGMSG(MSGINFO, "    SDC:RCV_RSP_FINISH(2). Status Reg.(0x10)=0x%08x\n",r1);
            REGRW32(rSDC_BASE,A_STATUS) = (CMD_RESP_CRC_ERROR |	RCV_RSP_FINISH);  // Clear flag
            // for R3 response type, ignore CRC check result
            DEBUGMSG(MSGINFO, "    SDC:CMD RESPONSE OK(2).\n");
            
            // Command response finished and no CRC error
            ret = 0;
            break;
        }
        else if((r1 & CMD_TIMEOUT) == CMD_TIMEOUT)
        {
            DEBUGMSG(MSGINFO, "    SDC:CMD_TIMEOUT(2). Status Reg.(0x10)=0x%08x\n",r1);
            REGRW32(rSDC_BASE,A_STATUS) = (CMD_RESP_CRC_ERROR |	CMD_TIMEOUT);
            
            ret = 2;
            break;
        }
    }
    
    // Later Exception restart module
    return ret;
}


static UINT8 __test_sd_wait_cmd_rsp(void)
{
    volatile UINT32 r1;
    UINT8 ret = 4;

    while(1)
    {
        r1 = REGRW32(rSDC_BASE,A_STATUS);
        if((r1 & RCV_RSP_FINISH) == RCV_RSP_FINISH)
        {
            DEBUGMSG(MSGINFO, "    SDC:RCV_RSP_FINISH(1). Status Reg.(0x10)=0x%08x\n",r1);
            REGRW32(rSDC_BASE,A_STATUS) = RCV_RSP_FINISH;	// Clear flag
            if((r1 & CMD_RESP_CRC_ERROR) == CMD_RESP_CRC_ERROR)
            {
                DEBUGMSG(MSGINFO, "    SDC:CMD_RESP_CRC_ERROR(1).\n");
                REGRW32(rSDC_BASE,A_STATUS) = CMD_RESP_CRC_ERROR;
                ret = 1;
                break;
            }
            else if((r1 & BLKRW_RESP_CRC_ERROR) == BLKRW_RESP_CRC_ERROR)
            {
                DEBUGMSG(MSGINFO, "    SDC:BLKR_READ_CRC_ERROR(1).\n");
                REGRW32(rSDC_BASE,A_STATUS) = BLKRW_RESP_CRC_ERROR;
                ret = 1;
                break;
            }
            else 
            {
                DEBUGMSG(MSGINFO, "    SDC:CMD RESPONSE OK(1).\n");
                
                // Command response finished and no CRC error
                ret = 0;
                break;
            }
        }
        else if((r1 & CMD_TIMEOUT) == CMD_TIMEOUT)
        {
            DEBUGMSG(MSGINFO, "    SDC:CMD_TIMEOUT(1). Status Reg.(0x10)=0x%08x\n",r1);
            REGRW32(rSDC_BASE,A_STATUS) = CMD_TIMEOUT;
            
            ret = 2;
            break;
        }
    }
    
    // Later Exception restart module
    return ret;
}

static void __test_sd_tasklet_schedule()
{
    run_task++;
}

static void __test_sd_cmd_interrupt(UINT32 status)
{
    if (!cmd_status) 
    {
        cmd_status = status;
    }
    
    __test_sd_set_bit(EVENT_CMD_COMPLETE, &pending_events);
    DEBUGMSG(MSGINFO, "in cmd_interrupt, pending_events = %x\n",pending_events);
    __test_sd_tasklet_schedule();
}


void __test_sd_command_complete(struct cmd_t *cmd)
{
    UINT32 status = cmd_status;

    cmd_status = 0;

    /* Read the response from the card (up to 16 bytes) */
    if (cmd->flags & MMC_RSP_PRESENT) 
    {
        DEBUGMSG(MSGINFO, "copying response from card\n");
        if (cmd->flags & MMC_RSP_136) 
        {
            cmd->resp[3] = REGRW32(rSDC_BASE,A_CMD_RESP) << 8;
            cmd->resp[2] = (REGRW32(rSDC_BASE,A_CMD_RESP1) << 8) | (REGRW32(rSDC_BASE,A_CMD_RESP) >> 24);
            cmd->resp[1] = (REGRW32(rSDC_BASE,A_CMD_RESP2) << 8) | (REGRW32(rSDC_BASE,A_CMD_RESP1) >> 24);
            cmd->resp[0] = (REGRW32(rSDC_BASE,A_CMD_RESP3) << 8) | (REGRW32(rSDC_BASE,A_CMD_RESP2) >> 24);
        } 
        else 
        {
            cmd->resp[3] = 0;
            cmd->resp[2] = 0;
            cmd->resp[1] = 0;
            cmd->resp[0] = REGRW32(rSDC_BASE,A_CMD_RESP);
            if (cmd->opcode == 3) 
            {
                // SEND_RCA
                //rca = cmd->resp[0] & 0xffff0000;
            }
            if (cmd->opcode == 41) 
            {
                // SEND_OCR ACMD41
                HCXC = (cmd->resp[0] >> 30) & 1;
            }
        }
    }
    else 
    {
        DEBUGMSG(MSGINFO, "not copying response from card\n");
    }

    if (status & CMD_TIMEOUT) 
    {
        DEBUGMSG(MSGINFO, "	SNAKE 810: CMD_TIMEOUT ..  %s()-%d,%s \n",__func__,__LINE__,__FILE__);
        cmd->error = -ETIMEDOUT;
    }
    else if ((cmd->flags & MMC_RSP_CRC) && (status & CMD_RESP_CRC_ERROR)) 
    { 
        DEBUGMSG(MSGINFO, "	SNAKE 810: CMD_RESP_CRC_ERROR ..  %s()-%d,%s \n",__func__,__LINE__,__FILE__);
        cmd->error = -EILSEQ;
    }
    else 
    {
        cmd->error = 0;
    }

    if (cmd->error) 
    {
        if (cmd->data) 
        {
            data = NULL;
        }
    }
}

void APACHE_TEST_SDC_Task()
{
	enum ald_sd_state prev_state;
	UINT32 status;
	unsigned int tmp;
	int bytes_to_go;
	int i;
	unsigned int status1, ready1;

	DEBUGMSG(MSGINFO, "\n in tasklet.. \n");

		do {
			prev_state = state;

			DEBUGMSG(MSGINFO, "state = %x\n", state);
			switch (state) {
			case STATE_IDLE:
				break;

			case STATE_SENDING_CMD:
				DEBUGMSG(MSGINFO, "in STATE_SENDING_CMD pe = %x\n",pending_events);
				if (!__test_sd_and_clear_bit(EVENT_CMD_COMPLETE,
							&pending_events))
					break;

				cmd_keep = cmd; // keep it for later use
				data_keep = data; // keep it for later use
//				cmd = NULL;
				__test_sd_set_bit(EVENT_CMD_COMPLETE, &completed_events);
				__test_sd_command_complete(cmd);
//				if (cmd == mrq->sbc && !cmd->error) {
//					prev_state = state = STATE_SENDING_CMD;
//					__test_sd_start_request(cur_slot,
//							       mrq->cmd);
//					goto unlock;
//				}

				DEBUGMSG(MSGINFO, "card status = %x\n",cmd->resp[0]);
//				if ((cmd->resp[0]) >> 5 & 1)
					
				if (!mrq->data || cmd->error) {
					DEBUGMSG(MSGINFO, "No Data or Cmd-error\n");
					__test_sd_request_end(mrq);
					goto unlock;
				}
				DEBUGMSG(MSGINFO, "X2 sg_sent=%d, sg_length=%d\n",sg_sent,sg_length);
				DEBUGMSG(MSGINFO, "data->flags = %x\n",data->flags);


// ###########
				tmp = REGRW32(rSDC_BASE,A_CMD_RESP);
				status1 = (tmp >> 9) & 0xf;
				ready1 = (tmp >> 8) & 1;
				if (((status1 == 4) | (status1 == 5)) & (ready1 == 1)) {// 'tran(in Write)' or 'data(READ)' state
					DEBUGMSG(MSGINFO, "R1\n");
					goto cont1;
				}
				else {
					DEBUGMSG(MSGINFO, "R2\n");
					for (i = 0; i < 100; i++){
						
					}
                    
					//dprintk("polling status arg = %x\n",cmd->arg); // send status cmd 13
					REGRW32(13,rSDC_BASE+A_CMDH) = 13;
					REGRW32(rSDC_BASE, A_CMDL) = sd_card_0.rca;
					REGRW32(rSDC_BASE, A_RESP_CNT) = 38;
					REGRW32(rSDC_BASE, A_START_OP) = (START_CMD | WAIT_RSP);

					break;
				}

cont1:
//###########
				if (sg_sent < sg_length) {

					DEBUGMSG(MSGINFO, "trig blkwr par\n");
					if (data->flags & MMC_DATA_WRITE) {
						REGRW32(rSDC_BASE, A_START_OP) =  START_BLK | BLK_WRITE;
					}

					prev_state = state = STATE_SENDING_PARTIAL_DATA;
					goto pdata;
				}
				else {

					DEBUGMSG(MSGINFO, "trig blkwr fin\n");
					if (data->flags & MMC_DATA_WRITE) {
						REGRW32(rSDC_BASE, A_START_OP) = START_BLK | BLK_WRITE;
					}

					prev_state = state = STATE_SENDING_DATA;
					goto data1;
				}
				//DEBUGMSG(MSGINFO, "X3");
				/* fall through */
                //break;

			case STATE_SENDING_PARTIAL_CMD:
				DEBUGMSG(MSGINFO, "in STATE_SENDING_PARTIAL_CMD:\n");
				if (!__test_sd_and_clear_bit(EVENT_CMD_COMPLETE,
							&pending_events))
					break;

		__test_sd_set_bit(EVENT_CMD_COMPLETE, &completed_events);
				if (!mrq->data || cmd->error) { // partials error processed the same 
					__test_sd_request_end(mrq);
					goto unlock;
				}
				if (sg_sent < sg_length) {
					DEBUGMSG(MSGINFO, "triggering block write\n");
					if (data->flags & MMC_DATA_WRITE) {
						REGRW32(rSDC_BASE, A_START_OP) = START_BLK | BLK_WRITE;
					}

					prev_state = state = STATE_SENDING_PARTIAL_DATA;
					goto pdata;
				}
				else {
					DEBUGMSG(MSGINFO, "triggering block write\n");
					if (data->flags & MMC_DATA_WRITE) {
						REGRW32(rSDC_BASE, A_START_OP) = START_BLK | BLK_WRITE;
					}

					prev_state = state = STATE_SENDING_DATA;
					goto data1;
				}
				/* fall through */





pdata:			case STATE_SENDING_PARTIAL_DATA:
				DEBUGMSG(MSGINFO, "in STATE_SENDING_PARTIAL_DATA :\n");
				if (__test_sd_and_clear_bit(EVENT_DATA_ERROR,
						       &pending_events)) {
				DEBUGMSG(MSGINFO, "EVENT_DATA_ERROR \n");
					__test_sd_stop_dma();
					if (data->stop)
						__test_sd_send_stop_cmd(data);
					state = STATE_DATA_ERROR;
					break;
				}

				if (!__test_sd_and_clear_bit(EVENT_PARTIAL_XFER_COMPLETE,
							&pending_events)) {
				DEBUGMSG(MSGINFO, "NO EVENT_PARTIAL_XFER_COMPLETE \n");
					break;
				}
				DEBUGMSG(MSGINFO, "EVENT_PARTIAL_XFER_COMPLETE \n");

				__test_sd_set_bit(EVENT_PARTIAL_XFER_COMPLETE, &completed_events);
				prev_state = state = STATE_PARTIAL_DATA_BUSY;
				goto pardabusy;
				/* fall through */

data1:			case STATE_SENDING_DATA:
			DEBUGMSG(MSGINFO, "in STATE_SENDING_DATA : \n");
				if (__test_sd_and_clear_bit(EVENT_DATA_ERROR,
						       &pending_events)) {
					DEBUGMSG(MSGINFO, "EVENT_DATA_ERROR\n");
					__test_sd_stop_dma();
					if (data->stop)
						__test_sd_send_stop_cmd(data);
					state = STATE_DATA_ERROR;
					break;
				}

					DEBUGMSG(MSGINFO, "NO EVENT_DATA_ERROR\n");
				if (!__test_sd_and_clear_bit(EVENT_XFER_COMPLETE,
							&pending_events)) {
					break;
				}

					DEBUGMSG(MSGINFO, "EVENT_XFER_COMPLETE\n");
				__test_sd_set_bit(EVENT_XFER_COMPLETE, &completed_events);
				prev_state = state = STATE_DATA_BUSY;
				/* fall through */

			case STATE_DATA_BUSY:
				DEBUGMSG(MSGINFO, "in STATE_DATA_BUSY : \n");
				if (!__test_sd_and_clear_bit(EVENT_DATA_COMPLETE,
							&pending_events))
					break;


				DEBUGMSG(MSGINFO, "EVENT DATA_COMPLET\n");
//				data = NULL;
				__test_sd_set_bit(EVENT_DATA_COMPLETE, &completed_events);
				status = data_status;

//		tmp = ab_asi_io_read(rSDC_BASE+ A_SETUP);

				DEBUGMSG(MSGINFO, "data_status=%x\n",status);
				if (status & ALD_SD_DATA_ERROR_FLAGS) {
					DEBUGMSG(MSGINFO, "data error\n");
					if (status & BLKRW_TIMEOUT) { //SDMMC_INT_DTO) {
						data->error = -ETIMEDOUT;
					} else if (status & BLKRW_RESP_CRC_ERROR) { //SDMMC_INT_DCRC) {
						data->error = -EILSEQ;
					} else {
						DEBUGMSG(MSGINFO,  "data FIFO error (status=%08x)\n", status);
						data->error = -EIO;
					}
				} else {
					DEBUGMSG(MSGINFO, "no data error\n");
					data->bytes_xfered = data->blocks * data->blksz;
					data->error = 0;
				}

				DEBUGMSG(MSGINFO, "data=%x, data->stop=%x !!\n",data,data->stop);
				if (!data->stop) {
					__test_sd_request_end(mrq);
					goto unlock;
				}

//				if (mrq->sbc && !data->error) {
//					data->stop->error = 0;
//					__test_sd_request_end(mrq);
//					goto unlock;
//				}

				prev_state = state = STATE_SENDING_STOP;

				if (!data->error) {
					__test_sd_send_stop_cmd(data);
				}

				goto stop1;

pardabusy:			case STATE_PARTIAL_DATA_BUSY:
				DEBUGMSG(MSGINFO, "in STATE_PARTIAL_DATA_BUSY:\n");
				if (!__test_sd_and_clear_bit(EVENT_PARTIAL_DATA_COMPLETE,
							&pending_events)) {
					DEBUGMSG(MSGINFO, "No EVENT_PARTIAL_DATA_COMPLETE\n");
					break;
				}
					DEBUGMSG(MSGINFO, "EVENT_PARTIAL_DATA_COMPLETE\n");


				__test_sd_set_bit(EVENT_PARTIAL_DATA_COMPLETE, &completed_events);
				status = data_status;

				DEBUGMSG(MSGINFO, "sg_length=%d, sg_sent = %d, sg[sg_sent-1].length=%d\n",sg_length,sg_sent,sg[sg_sent-1].length);
				if (status & ALD_SD_DATA_ERROR_FLAGS) {
					if (status & BLKRW_TIMEOUT) { //SDMMC_INT_DTO) {
						data->error = -ETIMEDOUT;
					} else if (status & BLKRW_RESP_CRC_ERROR) { //SDMMC_INT_DCRC) {
						data->error = -EILSEQ;
					} else {
						DEBUGMSG(MSGINFO,  "data FIFO error (status=%08x)\n", status);
						data->error = -EIO;
					}
				} else {
					data->bytes_xfered += sg[sg_sent-1].length; // correct bytes_xfered
					data->error = 0;
				}

#if 1 // not reached
				if (sg_sent == sg_length) { // can this code be reached?
				if (!data->stop) {
					__test_sd_request_end(mrq);
					goto unlock;
				}

//				if (mrq->sbc && !data->error) {
//					data->stop->error = 0;
//					__test_sd_request_end(mrq);
//					goto unlock;
//				}
				}
#endif

				DEBUGMSG(MSGINFO, "sending STOP command\n");
				if (sg_sent < sg_length) {
					prev_state = state = STATE_SENDING_PARTIAL_STOP;
					REGRW32(rSDC_BASE, A_CMDH) = 12;
					REGRW32(rSDC_BASE, A_CMDL) = 0;
					REGRW32(rSDC_BASE, A_RESP_CNT) = 38;
					REGRW32(rSDC_BASE, A_START_OP) = START_CMD | WAIT_RSP;
                    
					// fall -through
#if  1 // not reached
				}
				else 
				{
					prev_state = state = STATE_SENDING_STOP;
					goto stop1;
				}
#endif
				/* fall through */

			case STATE_SENDING_PARTIAL_STOP:
				DEBUGMSG(MSGINFO, "in STATE_SENDING_PARTIAL_STOP:\n");

				if (!__test_sd_and_clear_bit(EVENT_CMD_COMPLETE,
							&pending_events)) {
					DEBUGMSG(MSGINFO, "No EVENT_CMD_COMPLETE\n");
					break;
				}
					DEBUGMSG(MSGINFO, "EVENT_CMD_COMPLETE\n");
				
				tmp = REGRW32(rSDC_BASE,A_CMD_RESP);
				status1 = (tmp >> 9) & 0xf;
				ready1 = (tmp >> 8) & 1;
				if (((status1 == 4) | (status1 == 5)) & (ready1 == 1)) {// 'tran(in Write)' or 'data(READ)' state
					DEBUGMSG(MSGINFO, "R3\n");
					goto send_new;
				}
					DEBUGMSG(MSGINFO, "R4, sending CMD13..\n");

				for (i = 0; i < 100; i++)
                {
				//__asm__ __volatile__ ("nop;");
					nc_udelay(1);
				}
				REGRW32(rSDC_BASE, A_CMDH) = 13;
				REGRW32(rSDC_BASE, A_CMDL) = sd_card_0.rca;
				REGRW32(rSDC_BASE, A_RESP_CNT) = 38;
				REGRW32(rSDC_BASE, A_START_OP) = START_CMD | WAIT_RSP;

				break;

send_new:			
				DEBUGMSG(MSGINFO, "sending new buffer...\n");
				prev_state = state = STATE_SENDING_PARTIAL_CMD;

				sg_sent++;
				DEBUGMSG(MSGINFO, "sg=%x ",(unsigned int)sg);
				sg++; //= sg_next(sg);
				DEBUGMSG(MSGINFO, "after sg++, sg=%x ",(unsigned int)sg);
				cmd = cmd_keep;
				data = data_keep;
				DEBUGMSG(MSGINFO, "sg->dma_address=%x, sg->length=%d\n",sg->dma_address,sg->length);
				REGRW32(rSDC_BASE, A_CORE_ADR) = sg->dma_address; // dma address
				REGRW32(rSDC_BASE, A_CMDH) = cmd->opcode;
				DEBUGMSG(MSGINFO, "HCXC=%d, block_init_start=%d,blocks_done=%d.data->blksz=%d\n",HCXC,block_init_start,blocks_done,data->blksz);
				if (HCXC) {
					REGRW32(rSDC_BASE, A_CMDL) = block_init_start+blocks_done; // new start block
				}
				else {
					REGRW32(rSDC_BASE, A_CMDL) = block_init_start+blocks_done*data->blksz; // new start byte
				}
				REGRW32(rSDC_BASE, A_RESP_CNT) = 38;
				cmd_flags = START_CMD | WAIT_RSP;

				bytes_to_go = data->sg->length;
				blocks_done += bytes_to_go/data->blksz;

				if(REGRW32(rSDC_BASE,A_SETUP) & 0x1) { // 4-bit mode here
				REGRW32(rSDC_BASE, A_BLOCK_CNT) = data->blksz*8/4;
				REGRW32(rSDC_BASE, A_GDATA_CNT) = bytes_to_go*8/4;
				}
				else { // 1-bit mode
				REGRW32(rSDC_BASE, A_BLOCK_CNT) = data->blksz*8;
				REGRW32(rSDC_BASE, A_GDATA_CNT) = bytes_to_go*8;
				}


			if (cmd->data) {
			if (cmd->opcode == 51 || cmd->opcode == 13 || cmd->opcode == 6 || cmd->opcode == 18 || cmd->opcode == 17 ) {
				cmd_flags |= START_BLK; // block read
	}
			}
			REGRW32(rSDC_BASE, A_START_OP) = cmd_flags;
			break;

stop1:		case STATE_SENDING_STOP: // ##################################
			DEBUGMSG(MSGINFO, "in STATE_SENDING_STOP : \n");
			if (!__test_sd_and_clear_bit(EVENT_CMD_COMPLETE,
						&pending_events))
				break;

			DEBUGMSG(MSGINFO, "EVENT_CMD_COMPLETE\n");
			cmd = NULL;
			__test_sd_command_complete(mrq->stop);
			DEBUGMSG(MSGINFO, "stop resp = %x\n",mrq->stop->resp[0]);
			__test_sd_request_end(mrq);
			goto unlock;

		case STATE_DATA_ERROR:
			if (!__test_sd_and_clear_bit(EVENT_XFER_COMPLETE,
						&pending_events))
				break;

			state = STATE_DATA_BUSY;
			break;
		}
	DEBUGMSG(MSGINFO, "state = %d, prev_state = %d\n",state,prev_state);
	} while (state != prev_state);

unlock: ;

run_task--;
} // end of tasklet


void APACHE_TEST_SDC_Isr(int int_level) // Interrupt service routine 
{
    unsigned int pending, status;
    unsigned int CMD_DONE1 = 0;


    DEBUGMSG(MSGINFO, "\nInterrupt0!\n");

    if(cmd_flags & MMC_RSP_PRESENT) 
    {
        CMD_DONE1 = 0;
    }
    else 
    {
        CMD_DONE1 = SND_CMD_FINISH;
    }

    status = REGRW32(rSDC_BASE, A_STATUS);
    pending = REGRW32(rSDC_BASE, A_STATUS) & REGRW32(rSDC_BASE, A_SETUP);

    DEBUGMSG(MSGINFO, "\nInterrupt! SDC pending = %x, ie=%x\n", pending, REGRW32(rSDC_BASE, A_SETUP)); //read sdc flags
    if (pending & ALD_SD_CMD_ERROR_FLAGS) 
    {
        DEBUGMSG(MSGINFO, "ALD_SD_CMD_ERROR_FLAGS\n");
        REGRW32(rSDC_BASE, A_STATUS) = ALD_SD_CMD_ERROR_FLAGS;
        cmd_status = status;
        __test_sd_set_bit(EVENT_CMD_COMPLETE, &pending_events);
    }

    if (pending & ALD_SD_DATA_ERROR_FLAGS) 
    {
        DEBUGMSG(MSGINFO, "ALD_SD_DATA_ERROR_FLAGS\n");
        REGRW32(rSDC_BASE, A_STATUS) = ALD_SD_DATA_ERROR_FLAGS;
        data_status = status;
        __test_sd_set_bit(EVENT_DATA_ERROR, &pending_events);
        if (!(pending & (CMD_RESP_CRC_ERROR | BLKRW_RESP_CRC_ERROR | BLKR_OVERRUN | BLKR_UNDERRUN | CMD_TIMEOUT | BLKRW_TIMEOUT )))
            __test_sd_tasklet_schedule();
    }

    
    if (pending & (MULTBLK_WRITE_END | MULTBLK_READ_END)) 
    {
        DEBUGMSG(MSGINFO, "MULTBLK_WRITE_END | MULTBLK_READ_END\n");
        REGRW32(rSDC_BASE, A_STATUS) = (MULTBLK_WRITE_END | MULTBLK_READ_END);
        if (!data_status)
            data_status = status;
        DEBUGMSG(MSGINFO, "sent = %d, len = %d\n",sg_sent,sg_length);
        if (sg_sent < sg_length) 
        {
            __test_sd_set_bit(EVENT_PARTIAL_XFER_COMPLETE, &pending_events);
            __test_sd_set_bit(EVENT_PARTIAL_DATA_COMPLETE, &pending_events);
            __test_sd_tasklet_schedule();
        }
        else 
        {
            __test_sd_set_bit(EVENT_XFER_COMPLETE, &pending_events);
            __test_sd_set_bit(EVENT_DATA_COMPLETE, &pending_events);
            __test_sd_tasklet_schedule();
        }
    }

    if ( pending & (ALD_SD_CMD_DONE_FLAGS2 | CMD_DONE1)) 
    {
        DEBUGMSG(MSGINFO, "ALD_SD_CMD_DONE_FLAGS2 | CMD_DONE1\n");
        REGRW32(rSDC_BASE, A_STATUS) = ALD_SD_CMD_DONE_FLAGS;
        DEBUGMSG(MSGINFO, "after clear .. %x\n", REGRW32(rSDC_BASE, A_STATUS));

        DEBUGMSG(MSGINFO, "sg_sent = %x\n",sg_sent);
        if (sg_sent == 1 || sg_sent == 0) 
        {
            __test_sd_cmd_interrupt(pending);
        }
        else 
        {
            __test_sd_set_bit(EVENT_CMD_COMPLETE, &pending_events);
            __test_sd_tasklet_schedule();
        }
    }

    while(run_task)
    {
        APACHE_TEST_SDC_Task();
    }
}


void APACHE_TEST_SDC_Init(void)
{
    // Open SDIO Interface
    ncLib_SDC_Open();


    // Register SDC Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_REGISTER_INT
                      ,IRQ_NUM_SDC
                      ,(PrHandler)APACHE_TEST_SDC_Isr
                      ,CMD_END);
}


void APACHE_TEST_SDC_DeInit(void)
{
    // Unregister SDC Interrupt Handler
    ncLib_INTC_Control(GCMD_INTC_UNREGISTER_INT
                      ,IRQ_NUM_SDC
                      ,CMD_END);
    
    // Close SDIO Interface
    ncLib_SDC_Close();
}



void APACHE_TEST_SDC_SDCard_rMultiBlk(INT32 card_start_blk, UINT8 *mem_buf_addr, INT32 blk_count)
{
    DEBUGMSG(MSGINFO, "\nSDC:>> Read Multiple Blocks CMD18 -----------------------------\n");
    DEBUGMSG(MSGINFO, "SDC: CMD18\n");
    
    cmd->opcode = 18;
    cmd->arg = card_start_blk;
    cmd->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
    mrq->cmd = cmd;
    stop->opcode = 12;
    stop->arg = 0;
    stop->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
    mrq->stop = stop;
    data->flags = MMC_DATA_READ;
    data->error = 0;
    data->sg_len = 1;
    sg->length = 512*blk_count;
    sg->dma_address = (UINT32)mem_buf_addr;
    data->sg = sg;
    data->bytes_xfered = 0;
    data->blocks = 1;
    data->blksz = 512;
    cmd->data = data;
    mrq->data = data;

    __test_sd_start_request(mrq);
    while (complete == 0) { };
    DEBUGMSG(MSGINFO, "\nCMD18 Done!\n");
    DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);
}


void APACHE_TEST_SDC_SDCard_wMulteBlk(UINT8 *mem_buf_addr, INT32 card_start_blk, INT32 blk_count)
{
    //========================================
    // Start Multiple Data Block Transfer
    //========================================

    UINT32 tmp; // ckim
    UINT32 status1, ready1;
    
    DEBUGMSG(MSGINFO, "\nSDC:>> Write Multiple Blocks CMD25 -----------------------------\n");
    DEBUGMSG(MSGINFO, "SDC: CMD25\n");
    
    cmd->opcode = 25;
    cmd->arg = card_start_blk;
    cmd->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
    mrq->cmd = cmd;
    stop->opcode = 12;
    stop->arg = 0;
    stop->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
    mrq->stop = stop;
    data->flags = MMC_DATA_WRITE;
    data->error = 0;
    data->sg_len = 1;
    sg->length = 512*blk_count;
    sg->dma_address = (UINT32)mem_buf_addr;
    data->sg = sg;
    data->bytes_xfered = 0;
    data->blocks = 1;
    data->blksz = 512;
    cmd->data = data;
    mrq->data = data;


    __test_sd_start_request(mrq);
    while (complete == 0) { };
    DEBUGMSG(MSGINFO, "CMD25 Done!\n");
    DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);


    tmp = REGRW32(rSDC_BASE, A_CMD_RESP);
    status1 = (tmp >> 9) & 0xf;
    ready1 = (tmp >> 8) & 1;
    //	ab_printf(tstr,"tmp = %08x, status1 = %x, ready1 = %x\n", tmp, status1, ready1);
    while (!(((status1 == 4) | (status1 == 5)) & (ready1 == 1))) 
    {
        // 'tran(in Write)' or 'data(READ)' state

        nc_mdelay(100);

        DEBUGMSG(MSGINFO, "SDC: CMD13\n");
        cmd->opcode = 13;
        cmd->arg = sd_card_0.rca;
        cmd->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
        mrq->cmd = cmd;
        mrq->data = 0;
        mrq->stop = 0;
        __test_sd_start_request(mrq);
        while (complete == 0) { } // putchar('0');};
        //	ab_printf("\nCMD13 Done!\n");
        DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);
        tmp = REGRW32(rSDC_BASE,A_CMD_RESP);
        status1 = (tmp >> 9) & 0xf;
        ready1 = (tmp >> 8) & 1;
    }
}


void APACHE_TEST_SDC_SDCard_rSingleBlk(INT32 card_start_blk, UINT8 * mem_buf_addr)
{
	//----------------------------------------------------------
	// Read Single Block
	//----------------------------------------------------------
    DEBUGMSG(MSGINFO, "\nSDC:>> Read Single Block CMD17 -----------------------------\n");
    DEBUGMSG(MSGINFO, "SDC: CMD17\n");
    
	cmd->opcode = 17;
	cmd->arg = card_start_blk; //512; // SDSC
	cmd->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
	mrq->cmd = cmd;
	mrq->stop = 0;
	data->flags = MMC_DATA_READ;
	data->error = 0;
	data->sg_len = 1;
	sg->length = 512;
	sg->dma_address = (UINT32)mem_buf_addr; //(unsigned char *)&rec_block;
	data->sg = sg;
	data->bytes_xfered = 0;
	data->blocks = 1;
	data->blksz = 512;
	cmd->data = data;
	mrq->data = data;


	__test_sd_start_request(mrq);
	while (complete == 0) { };
	DEBUGMSG(MSGINFO, "\nCMD17 Done!\n");
	DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);
}


void APACHE_TEST_SDC_SDCard_wSingleBlk(UINT8 *mem_buf_addr, INT32 card_start_blk)
{
	//========================================
	// Start Single Data Block Transfer
	//========================================
	DEBUGMSG(MSGINFO, "\nSDC:>> Write Single Block CMD24 -----------------------------\n");
	DEBUGMSG(MSGINFO, "SDC: CMD24\n");


	REGRW32(rSDC_BASE,A_TIMEOUT) = 0x1ffffff;

	cmd->opcode = 24;
	cmd->arg = card_start_blk; // SDSC
	cmd->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
	mrq->cmd = cmd;
	mrq->stop = 0;
	data->flags = MMC_DATA_WRITE;
	data->error = 0;
	data->sg_len = 1;
	sg->length = 512;
	sg->dma_address = (UINT32)mem_buf_addr;
	data->sg = sg;
	data->bytes_xfered = 0;
	data->blocks = 1;
	data->blksz = 512;
	cmd->data = data;
	mrq->data = data;


	__test_sd_start_request(mrq);
	while (complete == 0) { };
	DEBUGMSG(MSGINFO, "\nCMD24 Done!\n");
	DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);
}


void APACHE_TEST_SDC_SDCard_Multi_RW(void)
{
    UINT32 nErrCnt = 0;

    UINT8* wBuff = (UINT8*)&gTestSDSrcBuff[0];
    UINT8* rBuff = (UINT8*)&gTestSDDstBuff[0];   

    __test_sd_dummy_buff(wBuff, 512*3);
    __test_sd_clear_buff(rBuff, 512*3);

    __test_sd_dummy_buff_marking(&wBuff[0],       0x0);
    __test_sd_dummy_buff_marking(&wBuff[512],     0x1);    
    __test_sd_dummy_buff_marking(&wBuff[512+512], 0x2);

    APACHE_TEST_SDC_SDCard_wMulteBlk(wBuff, 512, 3); 
    APACHE_TEST_SDC_SDCard_rMultiBlk(512, rBuff, 3);

    nErrCnt =__test_sd_compare_buff(wBuff, rBuff, (512*3));
    
    // Display Data
    __test_sd_display_buff(&rBuff[0], 512, 0x00);	
    __test_sd_display_buff(&rBuff[512], 512, 512);	    
    __test_sd_display_buff(&rBuff[512+512], 512, 512+512);	
    if(!nErrCnt)
        DEBUGMSG(MSGERR, " >> Data Compare Success\n");		
    
}


void APACHE_TEST_SDC_SDCard_Single_RW(void)
{
    UINT32 nErrCnt = 0;

    UINT8* wBuff = (UINT8*)&gTestSDSrcBuff[0];
    UINT8* rBuff = (UINT8*)&gTestSDDstBuff[0];   

    __test_sd_dummy_buff(wBuff, 512);
    __test_sd_clear_buff(rBuff, 512);

    __test_sd_dummy_buff_marking(wBuff, 0x0);

    APACHE_TEST_SDC_SDCard_wSingleBlk(wBuff, 512);
    APACHE_TEST_SDC_SDCard_rSingleBlk(512, rBuff);

    nErrCnt =__test_sd_compare_buff(wBuff, rBuff, 512);
    
    // Display Data
    __test_sd_display_buff(rBuff, 512, 0x00);	
    if(!nErrCnt)
        DEBUGMSG(MSGERR, " >> Data Compare Success\n");		
}


void APACHE_TEST_SDC_SDCardInit(void)
{
    int i;
    volatile unsigned long rtn_reg=0;
    volatile unsigned long rtn_reg2=0;
    
    struct data_t data1;
    struct cmd_t cmd1;
    struct mrq_t mrq1;
    struct cmd_t stop1;

    data = &data1;
    cmd = &cmd1;
    mrq = &mrq1;
    stop = &stop1;

    cmd->opcode = 0;
    cmd->arg = 0;
    cmd->flags = 0;
    ctype = 0; // 4 bit or 1 bit?


    sd_card_0.rca = 0x0;
    sd_card_0.HCS_s = 0x0;
    sd_card_0.Active = 0x0;
    sd_card_0.phys_spec_2_0 = 0x0;
    sd_card_0.Voltage_window = 0x0;


	//--------------------------------------------------------
	// SDC Clock setting
	//--------------------------------------------------------
	#ifdef SDCLK_25M
    	REGRW32(rSDC_BASE,A_CLKI_SCALE) = 0x2;
    	REGRW32(rSDC_BASE,A_CLKO_WAV) = 0x0100;
	#endif
    
	#ifdef SDCLK_16M
        REGRW32(rSDC_BASE, A_CLKI_SCALE) = 0x3;
        REGRW32(rSDC_BASE, A_CLKO_WAV) = 0x0102;
	#endif
    
	#ifdef SDCLK_12M
    	REGRW32(rSDC_BASE,A_CLKI_SCALE) = 0x4;
    	REGRW32(rSDC_BASE,A_CLKO_WAV) = 0x0002;
	#endif
    
	#ifdef SDCLK_3M
    	REGRW32(rSDC_BASE,A_CLKI_SCALE) = 0x10;
    	REGRW32(rSDC_BASE,A_CLKO_WAV) = 0x0108;
	#endif


	//--------------------------------------------------------
	// SDC Timeout setting
	//--------------------------------------------------------
	REGRW32(rSDC_BASE, A_TIMEOUT) = 0x01ffffff;


	//--------------------------------------------------------
	// SDC Setup and Start SDC
	//--------------------------------------------------------
	// SDC Start SDC
    REGRW32(rSDC_BASE, A_STATUS) = 0xffffffff;
    REGRW32(rSDC_BASE, A_SETUP) = (
                                    SD_CCRCE | SD_DCRCE | SD_ENABLE_SDIO | BLKR_OVERRUN | BLKR_UNDERRUN | //BLKW_RESP_FINISH |
                                    SD_CMD_TIMEOUT | 
                                    //		SND_CMD_FINISH | RCV_RSP_FINISH | 
                                    MULTBLK_WRITE_END | MULTBLK_READ_END);



    //-----------------------------------
    // Card Reset
    //-----------------------------------
	DEBUGMSG(MSGINFO, "\nSDC:>> Card Reset. CMD0 -----------------------------\n");
    DEBUGMSG(MSGINFO, "SDC: CMD0, Reset all cards to idle states\n");

    // CMD0 (GO_IDLE_STATE): Resets all cards to idle state
	cmd->opcode = 0;
	cmd->arg = 0;
	cmd->flags = 0;
	cmd->data = 0;
	mrq->cmd = cmd;
	mrq->data = 0;
	DEBUGMSG(MSGINFO, "BSC state = %x\n",state);
	__test_sd_start_request(mrq);
	DEBUGMSG(MSGINFO, "ASC state = %x, setup = %x\n",state, REGRW32(rSDC_BASE, A_SETUP));
	while (complete == 0) { };
	DEBUGMSG(MSGINFO, "CMD0 Done!\n");




    //-----------------------------------
    // Operating Condition Validation
    //-----------------------------------
	DEBUGMSG(MSGINFO, "\nSDC:>> Op. Cond. Validation. CMD8 -----------------------------\n");
	DEBUGMSG(MSGINFO, "SDC: CMD8, Send SD Card I/F cond. and ask the card support voltages\n");

	cmd->opcode = 8;
	cmd->arg = (VHS|CHECK_PATTERN);
	cmd->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
	mrq->cmd = cmd;
	mrq->data = 0;
	__test_sd_start_request(mrq);
	while (complete == 0) { };
	DEBUGMSG(MSGINFO, "\nCMD8 Done!\n");
	DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);



	if (cmd->resp[0] == (VHS|CHECK_PATTERN)) 
    {
        DEBUGMSG(MSGINFO, "VHS and CHECK PATTERN Match\n");
        sd_card_0.phys_spec_2_0 = 1;
	}
	else 
    {
        DEBUGMSG(MSGINFO, "VHS and CHECK PATTERN Doesn Not Match, Trying again..\n");
        cmd->opcode = 8;
        cmd->arg = (VHS|CHECK_PATTERN);
        cmd->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
        mrq->cmd = cmd;
        mrq->data = 0;
        __test_sd_start_request(mrq);
        while (complete == 0) { };
        DEBUGMSG(MSGINFO, "\nCMD8 Done!\n");
        DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);


        if (cmd->resp[0] == (VHS|CHECK_PATTERN)) 
        {
            DEBUGMSG(MSGINFO, "VHS and CHECK PATTERN Match\n");
            sd_card_0.phys_spec_2_0 = 1;
        }
        else 
        {
            DEBUGMSG(MSGINFO, "VHS and CHECK PATTERN Doesn Not Match\n");
            while (1) {}
        }
	}


    //----------------------------------------
    // Card Initialization and Idenfification 
    //----------------------------------------
	DEBUGMSG(MSGINFO, "\nSDC:>> Card Initialization.\n");

	//---------------------------------------------------------
	// SD Spec. V2.0 Card
	//---------------------------------------------------------
	if(sd_card_0.phys_spec_2_0) 
    {   
        // SD Spec. V2.0 Card
        DEBUGMSG(MSGINFO, "SD Spec. V2.0 Card.\n");

        rtn_reg = 0;
        i = 0;
        do 
        {

            DEBUGMSG(MSGINFO, "SDC: CMD55 : 3\n");

            cmd->opcode = 55;
            cmd->arg = 0;
            cmd->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
            mrq->cmd = cmd;
            mrq->data = 0;
            __test_sd_start_request(mrq);
            while (complete == 0) { };
            DEBUGMSG(MSGINFO, "\nCMD55 Done!\n");
            DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);
            DEBUGMSG(MSGINFO, "    Resp. of CMD55=0x%08x\n",cmd->resp[0]); //rtn_reg2);


            
            cmd->opcode = 41;
            cmd->arg = (HCS|VOLT);
            cmd->flags = MMC_RSP_PRESENT; // no crc check
            mrq->cmd = cmd;
            mrq->data = 0;
            __test_sd_start_request(mrq);
            while (complete == 0) { };
            DEBUGMSG(MSGINFO, "\nCMD41 Done!\n");
            DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);
            if (cmd->error)
                DEBUGMSG(MSGINFO, "    ACMD41 Send error.\n");

            DEBUGMSG(MSGINFO, "    Resp. of CMD41(OCR Reg.)=0x%08x\n",cmd->resp[0]);//rtn_reg);

            i += 1;
            //if(i >= 10) return;
        } while(((cmd->resp[0] & BUSY) != BUSY) && (i<SD_TIMEOUT_LIMIT));


        sd_card_0.Voltage_window = cmd->resp[0] & VOLTAGE_MASK;
        // CCS-bit OCR[30] check
        if((cmd->resp[0] & CCS) == CCS) 
        {
            DEBUGMSG(MSGINFO, " *********** SD Spec. V2.0 High Capacity SD Card\n");
            sd_card_0.HCS_s = 1;
        } 
        else 
        {
            DEBUGMSG(MSGINFO, " *********** SD Spec. V2.0 Standard Capacity SD Card\n");
            sd_card_0.HCS_s = 0;
        }	


        //---------------------------------------------
        // Get CID
        //---------------------------------------------
        DEBUGMSG(MSGINFO, "\nSDC:>> Get CID. CMD2 -----------------------------\n");
        DEBUGMSG(MSGINFO, "SDC: CMD2\n");
        cmd->opcode = 2;
        cmd->arg = 0;
        cmd->flags = MMC_RSP_PRESENT | MMC_RSP_136 | MMC_RSP_CRC; // no crc check
        mrq->cmd = cmd;
        mrq->data = 0;
        __test_sd_start_request(mrq);
        while (complete == 0) { };
        DEBUGMSG(MSGINFO, "\nCMD2 Done!\n");
        DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);
        DEBUGMSG(MSGINFO, "    CID Reg.=0x%08x\n",cmd->resp[0]); //rtn_reg);
        DEBUGMSG(MSGINFO, "            =0x%08x\n",cmd->resp[1]); //rtn_reg);
        DEBUGMSG(MSGINFO, "            =0x%08x\n",cmd->resp[2]); //rtn_reg);
        DEBUGMSG(MSGINFO, "            =0x%08x\n",cmd->resp[3]); //rtn_reg);



        //---------------------------------------------
        // Get RCA
        //---------------------------------------------
        DEBUGMSG(MSGINFO, "\nSDC:>> Get RCA. CMD3 -----------------------------\n");
        DEBUGMSG(MSGINFO, "SDC: CMD3\n");
        cmd->opcode = 3;
        cmd->arg = 0;
        cmd->flags = MMC_RSP_PRESENT | MMC_RSP_CRC; // no crc check
        mrq->cmd = cmd;
        mrq->data = 0;
        __test_sd_start_request(mrq);
        while (complete == 0) { };
        DEBUGMSG(MSGINFO, "\nCMD3 Done!\n");
        DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);

        sd_card_0.rca = ((cmd->resp[0] & RCA_RCA_MASK));
        sd_card_0.Active = 1;
        DEBUGMSG(MSGINFO, "    RCA Response=0x%08x\n",rtn_reg);
        DEBUGMSG(MSGINFO, "    RCA Nr for data transfer=0x%08x\n",(rtn_reg>>16));

        DEBUGMSG(MSGINFO, "  A_SETUP = %08x \n", REGRW32(rSDC_BASE,A_SETUP));
	}
	//---------------------------------------------------------
	// SD Spec. V1.0 Card
	//---------------------------------------------------------
	else 
    {   
        // SD Spec. V1.0 Card
        DEBUGMSG(MSGINFO, "SD Spec. V1.0 Card.\n");
        rtn_reg = 0;
        i = 0;
        do 
        {
            DEBUGMSG(MSGINFO, "SDC: CMD55 : 4\n");
            cmd_flags = MMC_RSP_PRESENT | MMC_RSP_CRC ;//| MMC_RSP_BUSY | MMC_RSP_OPCODE;
            REGRW32(rSDC_BASE,A_CMDH) = CMD55;			// CMD[37:32] = command index (6bit)
            REGRW32(rSDC_BASE,A_CMDL) = 0x00000000;	// CMD[32:0] = argument (32bit)
            REGRW32(rSDC_BASE,A_RESP_CNT) = 38;
            REGRW32(rSDC_BASE,A_START_OP) = (START_CMD|WAIT_RSP); state = STATE_SENDING_CMD;	// CMD55's Resp.type = R1(48bit)
            if(__test_sd_wait_cmd_rsp()) 
            {
                DEBUGMSG(MSGINFO, "    CMD55 Send error.\n");
                return;
            }

            rtn_reg2 = REGRW32(rSDC_BASE,A_CMD_RESP);
            DEBUGMSG(MSGINFO, "    Resp. of CMD55=0x%08x\n",rtn_reg2);
            // May be needed to check Command CRC Error at the SD Card.

            DEBUGMSG(MSGINFO, "SDC: ACMD41\n");
            cmd_flags = MMC_RSP_PRESENT | MMC_RSP_CRC ;//| MMC_RSP_BUSY | MMC_RSP_OPCODE;
            REGRW32(rSDC_BASE,A_CMDH) = ACMD41;		// CMD[37:32] = command index (6bit)
            REGRW32(rSDC_BASE,A_CMDL) = (HCS|VOLT);	// CMD[32:0] = argument (32bit)
            REGRW32(rSDC_BASE,A_RESP_CNT) = 38;
            REGRW32(rSDC_BASE,A_START_OP) = (START_CMD|WAIT_RSP|RSP_IGNORE_CRC); state = STATE_SENDING_CMD;	// ACMD41's Resp.type = R3(48bit), OCR Reg.
            if(__test_sd_wait_cmd_rsp2()) 
            {
                DEBUGMSG(MSGINFO, "    ACMD41 Send error.\n");
                return;
            }
            
            rtn_reg = REGRW32(rSDC_BASE,A_CMD_RESP);
            DEBUGMSG(MSGINFO, "    Resp. of CMD41(OCR Reg.)=0x%08x\n",rtn_reg);

            i += 1;
        } while( ((rtn_reg & BUSY) != BUSY) && (i<SD_TIMEOUT_LIMIT));

        if(i >= SD_TIMEOUT_LIMIT)	
            return;

        sd_card_0.Voltage_window = rtn_reg & VOLTAGE_MASK;
        if((rtn_reg & CCS) == CCS)  
            sd_card_0.HCS_s = 1;
        else 
            sd_card_0.HCS_s = 0;


        //---------------------------------------------
        // Get CID
        //---------------------------------------------
        DEBUGMSG(MSGINFO, "\nSDC:>> Get CID. CMD2\n");
        DEBUGMSG(MSGINFO, "SDC: CMD2\n");
        cmd_flags = MMC_RSP_PRESENT | MMC_RSP_136 | MMC_RSP_CRC ;//| MMC_RSP_BUSY | MMC_RSP_OPCODE;
        REGRW32(rSDC_BASE,A_CMDH) = CMD2;			// CMD[37:32] = command index (6bit)
        REGRW32(rSDC_BASE,A_CMDL) = 0x00000000;	// CMD[32:0] = argument (32bit)
        REGRW32(rSDC_BASE,A_RESP_CNT) = 120;
        REGRW32(rSDC_BASE,A_START_OP) = (START_CMD|WAIT_RSP|WAIT_RSP_LONG); 
        state = STATE_SENDING_CMD;	// CMD2's Resp.type = R2(136bit)
        if(__test_sd_wait_cmd_rsp()) 
        {
            DEBUGMSG(MSGINFO, "    CMD2 Send error.\n");
        }
        rtn_reg = REGRW32(rSDC_BASE,A_CMD_RESP3);
        DEBUGMSG(MSGINFO, "    CID Reg.=0x%08x\n",rtn_reg);
        rtn_reg = REGRW32(rSDC_BASE,A_CMD_RESP2);
        DEBUGMSG(MSGINFO, "            =0x%08x\n",rtn_reg);
        rtn_reg = REGRW32(rSDC_BASE,A_CMD_RESP1);
        DEBUGMSG(MSGINFO, "            =0x%08x\n",rtn_reg);
        rtn_reg = REGRW32(rSDC_BASE,A_CMD_RESP);
        DEBUGMSG(MSGINFO, "            =0x%08x\n",rtn_reg);
        //DEBUGMSG(MSGINFO, "    CMD2 Resp. CRC = 0x%04x\n",REGRW32(rSDC_BASE,0x40));
        DEBUGMSG(MSGINFO, "    CMD2 Resp. CRC = 0x%04x\n",REGRW32(rSDC_BASE,A_CMD_RESP_CRC));



        //---------------------------------------------
        // Get RCA
        //---------------------------------------------
        DEBUGMSG(MSGINFO, "\nSDC:>> Get RCA.  CMD3\n");
        DEBUGMSG(MSGINFO, "SDC: CMD3\n");
        cmd_flags = MMC_RSP_PRESENT | MMC_RSP_CRC ;//| MMC_RSP_BUSY | MMC_RSP_OPCODE;
        REGRW32(rSDC_BASE,A_CMDH) = CMD3;          // CMD[37:32] = command index (6bit)
        REGRW32(rSDC_BASE,A_CMDL) = 0x00000000;    // CMD[32:0] = argument (32bit)
        REGRW32(rSDC_BASE,A_RESP_CNT) = 38;
        REGRW32(rSDC_BASE,A_START_OP) = (START_CMD|WAIT_RSP);  
        state = STATE_SENDING_CMD; // CMD3's Resp.type = R6(48bit)
        if(__test_sd_wait_cmd_rsp()) 
         {
            DEBUGMSG(MSGINFO, "    CMD3 Send error.\n");
        }
        rtn_reg = REGRW32(rSDC_BASE,A_CMD_RESP);
        sd_card_0.rca = ((rtn_reg & RCA_RCA_MASK));
        sd_card_0.Active = 1;
        DEBUGMSG(MSGINFO, "    RCA Response=0x%08x\n",rtn_reg);
        DEBUGMSG(MSGINFO, "    RCA Nr for data transfer=0x%08x\n",(rtn_reg>>16));
	}



    if(sd_card_0.Active == 1)
    {
        DEBUGMSG(MSGINFO, "\n################## SDIO Init succes ! ###############\n");
        DEBUGMSG(MSGINFO, "  voltage_windows: 0x%x \n", sd_card_0.Voltage_window);
        DEBUGMSG(MSGINFO, "  RCA_Nr: 0x%x \n", sd_card_0.rca);
        DEBUGMSG(MSGINFO, "  phys_spec_2_0 ? : 0x%x\n",sd_card_0.phys_spec_2_0);
    }	
    else 
    {
        DEBUGMSG(MSGINFO, "SDIO Init failed ! \n");
        return;
    }

 
	//---------------------------------------------
	// Get CSD
	//---------------------------------------------
	DEBUGMSG(MSGINFO, "\nSDC:>> Get CSD. CMD9 -----------------------------\n");
	DEBUGMSG(MSGINFO, "SDC: CMD9\n");
	cmd->opcode = 9;
	cmd->arg = sd_card_0.rca;
	cmd->flags = MMC_RSP_PRESENT | MMC_RSP_136 | MMC_RSP_CRC;
	mrq->cmd = cmd;
	mrq->data = 0;
	__test_sd_start_request(mrq);
	while (complete == 0) { };
	DEBUGMSG(MSGINFO, "\nCMD41 Done!\n");
	DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);
	DEBUGMSG(MSGINFO, "    CSD reg.=0x%08x\n",cmd->resp[0]); //rtn_reg);
	DEBUGMSG(MSGINFO, "            =0x%08x\n",cmd->resp[1]); //rtn_reg);
	DEBUGMSG(MSGINFO, "            =0x%08x\n",cmd->resp[2]); //rtn_reg);
	DEBUGMSG(MSGINFO, "            =0x%08x\n",cmd->resp[3]); //rtn_reg);


	//----------------------------------------
	// Put in transfer state
	//----------------------------------------
	DEBUGMSG(MSGINFO, "\nSDC:>> Select SD Card. CMD7 -----------------------------\n");
	DEBUGMSG(MSGINFO, "SDC: CMD7\n");
	cmd->opcode = 7;
	cmd->arg = sd_card_0.rca;
	cmd->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
	mrq->cmd = cmd;
	mrq->data = 0;
	__test_sd_start_request(mrq);
	while (complete == 0) { };
	DEBUGMSG(MSGINFO, "\nCMD7 Done!\n");
	DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);
	if( cmd->resp[0] == (CARD_STATUS_STB|READY_FOR_DATA))	// Card's CURRENT_STATE = stby, READY_FOR_DATA
		DEBUGMSG(MSGINFO, "    Ready for transfer data !\n");



	//----------------------------------------
	// Set bus width
	//----------------------------------------
	DEBUGMSG(MSGINFO, "\nSDC:>> Set bus width. ACMD6 -----------------------------\n");
	DEBUGMSG(MSGINFO, "SDC: CMD55 : 2\n");
	cmd->opcode = 55;
	cmd->arg = sd_card_0.rca;
	cmd->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
	mrq->cmd = cmd;
	mrq->data = 0;
	__test_sd_start_request(mrq);
	while (complete == 0) { };
	DEBUGMSG(MSGINFO, "\nCMD55 Done!\n");
	DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);



	cmd->opcode = 6;
	cmd->arg = 2;
	cmd->flags = MMC_RSP_PRESENT | MMC_RSP_CRC;
	mrq->cmd = cmd;
	mrq->data = 0;
	__test_sd_start_request(mrq);
	while (complete == 0) { };
	DEBUGMSG(MSGINFO, "\nCMD6 Done!\n");
	DEBUGMSG(MSGINFO, "resp = %x\n",cmd->resp[0]);

	ctype = 1;
	REGRW32(rSDC_BASE,A_SETUP) = REGRW32(rSDC_BASE,A_SETUP) | 0x01; // set 4 bit width



    APACHE_TEST_SDC_SDCard_Single_RW();   
    APACHE_TEST_SDC_SDCard_Multi_RW();
}


INT32 APACHE_TEST_SDC_CUTMode(void)
{
    INT32 select;
    char buf[256];

    APACHE_TEST_SDC_Init();

    while(1)
    {
        DEBUGMSG(MSGINFO, "\n\n\n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, " Detail Description about IP - SDC                          \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " SDC Controller                                             \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <1> SDCard Init                                            \n");
        DEBUGMSG(MSGINFO, "------------------------------------------------------------\n");
        DEBUGMSG(MSGINFO, " <0> Quit : Move on to sub menu ...                         \n");
        DEBUGMSG(MSGINFO, "============================================================\n");
        DEBUGMSG(MSGINFO, "\n");
        DEBUGMSG(MSGINFO, "Select : ");
        DBGSCANF(buf);

        select = APACHE_TEST_Asc2Int(buf[0]);
        DEBUGMSG(MSGINFO, "\n");

        switch(select)
        {
            case 1:
                APACHE_TEST_SDC_SDCardInit();
            break;
            
            case 0:
                DEBUGMSG(MSGINFO, "Move on to sub menu\n");
            goto SDC_Exit;
        }
    }

SDC_Exit:

    APACHE_TEST_SDC_DeInit();

    return NC_SUCCESS;
}


#endif /* ENABLE_IP_SDC */


/* End Of File */

