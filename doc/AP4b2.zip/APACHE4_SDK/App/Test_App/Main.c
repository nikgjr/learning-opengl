/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : Main.c
*
*  @brief   :
*
*  @author  :
*
*  @date    : 2017.11.27
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#define __MAIN_C__

/*
********************************************************************************
*               INCLUDES
********************************************************************************
*/

#include "test.h"










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

void APACHE_TEST_APP_InitDebugPort(UINT32 nDbgZone_APP, UINT32 nDbgZone_SDK)
{
    // Get Debug Port
    if(ASM_GET_CORE_ID() == DLS_CORE)
        SYS_DEBUG_PORT = UART_CH0;
    else
        SYS_DEBUG_PORT = UART_CH1;

    // Open Debug Port
    ncLib_DEBUG_Open();

    // Init Debug Port
    ncLib_DEBUG_Control(GCMD_DBG_INIT, SYS_DEBUG_PORT, UT_BAUDRATE_57600, CMD_END);

    // APP Debug Zone - On/Off
    ncLib_DEBUG_Control(GCMD_DBG_APP_LOG_ZONE, nDbgZone_APP, ON, CMD_END);

    // SDK Debug Zone - On/Off
    ncLib_DEBUG_Control(GCMD_DBG_SDK_LOG_ZONE, nDbgZone_SDK, ON, CMD_END);
}


void APACHE_TEST_APP_InitInterface(void)
{
    // Init Default Peripheral 
    ncLib_SCU_Open();
    ncLib_INTC_Open();
    ncLib_GPIO_Open();
    
    // Init Debug Port
    APACHE_TEST_APP_InitDebugPort(MSGFULL, MSGFULL);
}


INT32 main(void)
{
    // Init Default Interface
    APACHE_TEST_APP_InitInterface();

    // Peripheral IP Test
    APACHE_TEST_APP_Main();
    
    return 0;
}


#undef __MAIN_C__


/* End Of File */

