/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SysTime_Svc.c
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "SysTime_Svc.h"










/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

/* Ticks elapsed in one second by a signal of 1 MHz */
#define MHZ_TICKS_PER_SEC       1000000

#define UINT32_MAX              (4294967295U)










/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/

typedef struct timer_ops
{
    unsigned int clk_base;
    unsigned int clk_mult;
    unsigned int clk_div;
} timer_ops_t;










/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/

static timer_ops_t delay_ops;










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

/*
 * Delay for the given number of microseconds and  milliseconds.
 * The driver must be initialized before calling this function.
 */

void ncSvc_SYSTIME_uDelay(UINT32 usec)
{
    unsigned int start, rdtime, delta, total_delta;

    start = REGRW32(0x08000000, 0x3000);

    total_delta = (usec * delay_ops.clk_div) / delay_ops.clk_mult;

    do
    {
        rdtime = REGRW32(0x08000000, 0x3000);   /* Increasing counter */

        if(start > rdtime)
        {
            rdtime += (UINT32_MAX - start);
            delta = rdtime - start;
        }
        else
        {
            delta = rdtime - start;
        }
    }
    while(delta < total_delta);
}


void ncSvc_SYSTIME_mDelay(UINT32 msec)
{
    ncSvc_SYSTIME_uDelay(msec*1000);
}


void ncSvc_SYSTIME_Init(UINT32 baseclock)
{
    unsigned int mult = MHZ_TICKS_PER_SEC;  /* Value in ticks */
    unsigned int div  = baseclock;          /* Value in ticks per second (Hz) */

    /* Reduce multiplier and divider by dividing them repeatedly by 10 */
    while((mult % 10 == 0) && (div % 10 == 0))
    {
        mult /= 10;
        div  /= 10;
    }

    delay_ops.clk_base = baseclock;
    delay_ops.clk_mult = mult;
    delay_ops.clk_div  = div;
}


/* End Of File */

