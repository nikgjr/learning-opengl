/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __SFLASH_SVC_H__
#define __SFLASH_SVC_H__

/*
********************************************************************************
*              INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*              FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32  ncSvc_SF_Init(ptSF_PARAM ptParam);
extern INT32  ncSvc_SF_DeInit(void);

extern void   ncSvc_SF_SetBitRate(UINT32 bitrate);
extern void   ncSvc_SF_WaitWIP(void);
extern void   ncSvc_SF_WriteEnable(void);
extern void   ncSvc_SF_WriteDisable(void);
extern UINT8  ncSvc_SF_ReadStatus(void);
extern UINT8  ncSvc_SF_ReadStatus2(void);
extern void   ncSvc_SF_WriteStatus(UINT8 Status);
extern void   ncSvc_SF_WriteStatus2(UINT8 Status1, UINT8 Status2);

extern INT32  ncSvc_SF_ReadDeviceIdentification(ptSFLASH_ID ptsFlashID);
extern INT32  ncSvc_SF_SectorErase(UINT32 PageAddr);
extern INT32  ncSvc_SF_BlockErase(UINT32 PageAddr);

extern INT32  ncSvc_SF_WriteData(UINT32 Addr, UINT8 *pData, UINT32 size);
extern INT32  ncSvc_SF_ReadData(UINT32 Addr, UINT8 *pData, UINT32 Size);

extern INT32  ncSvc_SF_GetPadCtrl(void);
extern INT32  ncSvc_SF_FreePadCtrl(void);

extern INT32  ncSvc_SF_QSPIReadDirectOSG(BOOL OnOff);
extern INT32  ncSvc_SF_QSPIReadAPBOSG(UINT32 Addr, UINT32 BuffAddr, UINT32 Size);
extern INT32  ncSvc_SF_QSPIReadLUT(UINT32 Addr, UINT8 *pData, UINT32 Size);

extern void   ncSvc_SF_EnableWP(BOOL OnOff);


#endif /* __SFLASH_SVC_H__ */


/* End Of File */

