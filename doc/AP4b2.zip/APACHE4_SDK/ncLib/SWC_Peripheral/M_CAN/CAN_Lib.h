/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __CAN_LIB_H__
#define __CAN_LIB_H__



// Numer of Last Error Codes (LEC)
#define LEC_NO_OF_ERROR_CODES  8

// Print
#define DEBUG_PRINT 0   // 0: don't print, !=0: print Debug Outputs
#define ERROR_PRINT 1   // 0: don't print, !=0: print Error Outputs

// the maximal data bytes allowed per CAN frame
#define CAN_FD_MAX_NO_OF_DATABYTE_PER_FRAME     64
#define CAN_FD_MAX_DLC                          15  // maximal allowed DLC value in CAN FD
#define CAN_CLASSIC_MAX_DLC                     8  // maximal allowed DLC value in CAN FD

// size of the list buffering RX Messages in Software Memory (not M_CAN or Messag RAM) before they are checked for correctness
#define RX_MESSAGE_LIST_ENTRIES                 32
// size of the list buffering TX Event FIFO elements in Software Memory (not M_CAN or Messag RAM) before they are checked for correctness
#define TX_EVENT_FIFO_LIST_ENTRIES              32


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* CAN GENERIC & SPECIFIC COMMANDS
*/

typedef enum _CAN_CMD
{
    /*
    * Generic Commands
    */

    GCMD_CAN_INIT = 0,
    GCMD_CAN_DEINIT,
    GCMD_CAN_STATUS,
    
    GCMD_CAN_MAX,
    
} eCAN_CMD;


typedef enum
{
    CAN_CH0,
    MAX_OF_CAN_CH
} eCAN_CH;


typedef struct
{
    BOOL            mIntEn;     // Interrupt On or Off
    UINT32          mBaudRate;  // CAN baudrate

} tCAN_PARAM, *ptCAN_PARAM;


/* Buffer/FIFO/Queue Data Field Size */
typedef enum {
  BYTE8 = 0,
  BYTE12 = 1,
  BYTE16 = 2,
  BYTE20 = 3,
  BYTE24 = 4,
  BYTE32 = 5,
  BYTE48 = 6,
  BYTE64 = 7
} data_field_size_enum;


// TX Event FIFO Element Type
typedef enum {
    reserved = 0,
    tx_event = 1,
    transmission_in_spite_of_cancellation = 2
}tx_event_fifo_elem_event_type_enum;

/* M_CAN Message RAM Partitioning - i.e. Start Addresses (BYTE) */
typedef struct {
    UINT32 SIDFC_FLSSA;
    UINT32 XIDFC_FLESA;
    UINT32 RXF0C_F0SA ;  // RX FIFO 0 Start Address
    UINT32 RXF1C_F1SA ;  // RX FIFO 1 Start Address
    UINT32 RXBC_RBSA  ;
    UINT32 TXEFC_EFSA ;
    UINT32 TXBC_TBSA  ;
} msg_ram_partitioning_struct;

// element size structure
typedef struct
{
     word  rx_fifo0;                      // element size in words
     word  rx_fifo1;                      // element size in words
     word  rx_buffer;                     // element size in words
     word  tx_buffer;                     // element size in words
} elem_size_word_struct;

/* protocol statistics struct */
typedef struct {
    UINT32 lec[LEC_NO_OF_ERROR_CODES];
    UINT32 dlec[LEC_NO_OF_ERROR_CODES];
    UINT32 boff;
    UINT32 ewarn;
    UINT32 epass;
    UINT32 pxe;
    boolean changed;
    // add further elements as needed
} protocol_stat_struct;

/* Message statistics struct */
typedef struct {
    UINT32 fdf;  // number of messages with fdf bit set
    UINT32 brs;  // number of messages with brs bit set
    UINT32 esi;  // number of messages with esi bit set
    UINT32 msgs_mram;      // number of messages copied from/to the message RAM (should be equal to received or transmitted messages)
    UINT32 msgs_ir_ok;     // number of correct messages receptions or transmissions signaled by interrupts
} message_stat_struct;

/* Message statistics struct for Message Validation (Check) Results */
typedef struct {
    UINT32 msgs_ok;        // number of messages validated by receiving node: message content     OK
    UINT32 msgs_err;       // number of messages validated by receiving node: message content NOT OK
    UINT32 msgs_duplicate; // number of messages validated by receiving node: last message received again
} message_stat_rx_validation_struct;

/* TLD statistics struct */
typedef struct {
    UINT32 min;     // transmitter loop delay (TLD): minimal observed value
    UINT32 max;     // transmitter loop delay (TLD): maximal observed value
    UINT32 sum;     // transmitter loop delay (TLD): the sum of all measured
    UINT32 sum_cnt; // transmitter loop delay (TLD): number of measurements summed up in tld_sum
} tld_stat_struct;

/* TLD statistics struct */
typedef struct {
    UINT32 ara;   // Access to Reserved Address (ARA)  Interrupt set
    UINT32 mraf;  // Message RAM Access Failure (MRAF) Interrupt set
    UINT32 beu;   // Bit Error Uncorrected      (BEU)  Interrupt set
    UINT32 bec;   // Bit Error Corrected        (BEC)  Interrupt set
} hardware_access_stat_struct;

/* DEBUG statistics struct */
typedef struct {
    UINT32 counter[4];
} debug_stat_struct;


/* statistics struct*/
typedef struct {
    protocol_stat_struct protocol;
    message_stat_struct rx;
    message_stat_struct tx;
    tld_stat_struct tld;
    message_stat_rx_validation_struct rx_check;
    hardware_access_stat_struct hw_access;
    debug_stat_struct debug; // for debugging
    UINT32 tx_event_elements; // number of elements read from tx event fifo
    // add further elements as needed, eg. rx/tx counters
} can_statistics_struct;

// Parameters for Bit Timing Configuration
typedef struct {
    word brp;        // baudrate prescaler
    word prop_seg;   // propagation segment
    word phase_seg1; // phase1 segment
    word phase_seg2; // phase2 segment
    word sjw;        // (re) synchronization jumpwidth
    word tdc;        // transceiver delay compensation (1:yes, 0:no)
    word tdc_offset; // transceiver delay compensation offset
    word tdc_filter_window; // transceiver delay compensation filter window length
} bt_config_struct;

// BitTiming Parameters for a CAN FD node
typedef struct {
    bt_config_struct nominal;  // Arbitration Phase Bit Timing configuration
    bt_config_struct data;     // Data        Phase Bit Timing configuration
    boolean fd_ena;            // TRUE == FD Operation enabled
    boolean brs_ena;           // TRUE == Bit Rate Switch enabled (only evaluated in HW, if FD operation enabled)
} bt_config_canfd_struct;

// TX Buffer Configuration Parameters for a CAN FD node
typedef struct {
    boolean FIFO_true_QUEUE_false;        // select: TRUE=FIFO, FALSE=Queue
    UINT32 fifo_queue_size;                // Elements in FIFO/Queue
    UINT32 ded_buffers_number;             // Number of dedicated TX buffers
    data_field_size_enum data_field_size; // TX Buffer Data Field Size (8byte .. 64byte)
} tx_buff_config_struct;

// CAN structure - Properties of an M_CAN node
typedef struct
{
     boolean ena;                          // TRUE = node enabled/aktive, FALSE = node disabled/does not TX or RX frames
     UINT32 base;                           // base address of this CAN module
     UCHAR  id;                             // local  CAN-Node identifier, e.g. 0 or 2
     UCHAR  id_global;                      // global CAN-Node identifier, used to separate Nodes in a multi-board network
     msg_ram_partitioning_struct mram_sa;  // Absolute Byte Start Addresses for Element Types in Message RAM
     elem_size_word_struct elem_size_word; // Size of Elements in Message RAM (RX Elem. in FIFO0, in FIFO1, TX Buffer) given in words
     can_statistics_struct stat;           // Statistics, any kind
     bt_config_canfd_struct bt_config;     // Bit Timing Configuration
     tx_buff_config_struct tx_config;      // TX Buffer Configuration
     boolean is_m_ttcan_node;              // FALSE: M_CAN Node, TRUE: M_TTCAN Node
     UINT32 interrupts_enabled;             // remembers enabled interrupts of M_CAN (IE register), bit.x=0: disabled, =1 enabled
} can_struct;

// CAN Message ID Type
typedef enum
{
    standard_id = 0,
    extended_id = 1,
    std_and_ext_id = 2
} can_id_type_enum;

// CAN Message Direction
typedef enum
{
    tx_dir = 0,  // transmission
    rx_dir = 1   // reception
} can_msg_dir_enum;

// CAN Message received via the following Type of RX Buffers
typedef enum
{
    FIFO_0 = 0,
    FIFO_1 = 1,
    DEDICATED_RX_BUFFER = 2
} rx_buffer_type_enum;

// CAN Message receive Information: via which RX Buffers, etc.
typedef struct
{
    rx_buffer_type_enum rx_via;        // Type of RX Buffer
    unsigned short int  buffer_index;  // if ded. RX Buffer: buffer index, if RX FIFO: GetIndex
} rx_info_struct;

// CAN Message Struct
typedef struct
{
    BOOL              remote;    // TRUE = Remote Frame, FALSE = Data Frame
    can_id_type_enum  idtype;    // ID or IDEXT
    UINT32            id;        // ID (11) or IDext (29)
    BOOL              fdf;       // FD Format (TRUE = FD Foramt)
    BOOL              brs;       // Bit Rate Switch (TRUE = with Bit Rate Switch)
    BOOL              esi;       // Error State Indicator
    word              dlc;       // Data Length Code used in the frame on the bus: current CAN FD IP impl. delivers 8 data bytes to the software, but transmits up to 64 on the CAN bus
                                // to calculate the data length of a frame based on DLC use the function convert_DLC_to_length(*)
                                // this should be removed, when CAN FD IP can deliver DLC-number of bytes to the software
    UCHAR            data[CAN_FD_MAX_NO_OF_DATABYTE_PER_FRAME];   // Data

    can_msg_dir_enum direction; // Message Direction: RX or TX
    rx_info_struct   rx_info;   // Information regarding the reception of the frame
    BOOL             efc;       // Event FIFO Control (TRUE = Store TX Event FIFO element after transmission)
    UCHAR            mm;        // Message marker (will be copied to TX Event FIFO element)

} can_msg_struct;

/* global status struct ========================= */
typedef struct {
    UCHAR board_id; // unique ID of the FPGA-Board in a network scenario
    can_struct can;
    boolean fd_test_next_message_trigger; // triggers the transmission of a new message, is set by a timer, reset flag in your test case
    // add further elements as needed
    UINT32 DEBUG[3]; // for debugging
} can_global_struct;

// TX Event FIFO Element Struct
typedef struct {
    boolean             esi; // Error State Indicator
    can_id_type_enum idtype; // ID (11) or IDEXT (29)
    boolean          remote; // Remote transmission request
    UINT32                id; // ID (11) or IDext (29)
    UCHAR                 mm; // Message marker
    tx_event_fifo_elem_event_type_enum   et; // Event Type
    boolean             fdf; // FD Format
    boolean             brs; // Bit Rate Switch
    word                dlc; // Data Length Code used in the frame on the bus
    word               txts; // Tx Timestamp
}tx_event_element_struct;

/* logging structure for RX Messages */
typedef struct {
    int   next_free_elem;  // write pointer, points to the next free       list entry (message)
    int   last_full_elem;  // read  pointer, points to the last valid/full list entry (message)
    boolean full;          // TRUE==full, FALSE==not full
    can_msg_struct msg[RX_MESSAGE_LIST_ENTRIES]; // List of RX-Messages
} rx_msg_list_struct;

/* logging structure for TX Event FIFO Elements */
typedef struct {
    int   next_free_elem;  // write pointer, points to the next free       list entry (message)
    int   last_full_elem;  // read  pointer, points to the last valid/full list entry (message)
    boolean full;          // TRUE==full, FALSE==not full
    tx_event_element_struct tx_event_elem[TX_EVENT_FIFO_LIST_ENTRIES]; // List of TX Event FIFO Elements
} tx_event_list_struct;


typedef enum
{
    CAN_BPS_10KBPS,     // 6.7km Class A max
    CAN_BPS_20KBPS,     // 3.3km Class B
    CAN_BPS_50KBPS,     // 1.3km Class B
    CAN_BPS_100KBPS,    // 620m  Class B
    CAN_BPS_125KBPS,    // 530m  Class B max
    CAN_BPS_250KBPS,    // 270m  Class C
    CAN_BPS_500KBPS,    // 130m  Class C
    CAN_BPS_800KBPS,    // 80m   Class C
    CAN_BPS_1000KBPS,   // 40m   Class C max
    CAN_BPS_2000KBPS,   // FD
    CAN_BPS_4000KBPS    // FD
} eCAN_KBPS;

typedef enum
{
    CAN_FD_BPS_500KBPS,
    CAN_FD_BPS_1000KBPS,
    CAN_FD_BPS_2000KBPS,
    CAN_FD_BPS_4000KBPS,
    CAN_FD_BPS_5000KBPS,
    CAN_FD_BPS_8000KBPS

} eCANFD_KBPS;

/* Standard ID Filter Element Type */
typedef enum {
  STD_FILTER_TYPE_RANGE     = 0x0,
  STD_FILTER_TYPE_DUAL      = 0x1,
  STD_FILTER_TYPE_CLASSIC   = 0x2,
  STD_FILTER_TYPE_DISABLE   = 0x3
} SFT_Standard_Filter_Type_enum;

/* Filter Element Configuration - Can be used for SFEC(Standard Id filter configuration) and EFEC(Extended Id filter configuration) */
typedef enum {
  FILTER_ELEMENT_DISBALBE       = 0x0,
  FILTER_ELEMENT_STORE_IN_FIFO0 = 0x1,
  FILTER_ELEMENT_STORE_IN_FIFO1 = 0x2,
  FILTER_ELEMENT_REJECT_ID      = 0x3,
  FILTER_ELEMENT_SET_PRIORITY   = 0x4,
  FILTER_ELEMENT_SET_PRIORITY_AND_STORE_IN_FIFO0 = 0x5,
  FILTER_ELEMENT_SET_PRIORITY_AND_STORE_IN_FIFO1 = 0x6,
  FILTER_ELEMENT_STORE_IN_RX_BUFFER_OR_DEBUG_MSG = 0x7
} Filter_Configuration_enum;


/* Extended ID Filter Element Type */
typedef enum {
  EXTD_FILTER_TYPE_RANGE                         = 0x0,
  EXTD_FILTER_TYPE_DUAL                          = 0x1,
  EXTD_FILTER_TYPE_CLASSIC                       = 0x2,
  EXTD_FILTER_TYPE_RANGE_XIDAM_MASK_NOT_APPLIED  = 0x3
} EFT_Extended_Filter_Type_enum;

/* type definition for Standard message ID filter element */
typedef struct {
    unsigned int                    index; // filter element will be stored in the message RAM at an offset calculated with this index
    unsigned int                    SFID1; // Standard Filter ID 1
    unsigned int                    SFID2; // Standard Filter ID 2
    SFT_Standard_Filter_Type_enum   SFT;   // Standard Filter Type
    Filter_Configuration_enum       SFEC;  // Standard Filter Element Configuration
} struct_standard_id_filter;


/* type definition for Extended message ID filter element */
typedef struct {
        unsigned int                    index;  // filter element will be stored in the message RAM at an offset calculated with this index
        UINT32                           EFID1;  // extended filter ID 1
        UINT32                           EFID2;  // extended filter ID 2
        EFT_Extended_Filter_Type_enum   EFT;    // extended filter type
        Filter_Configuration_enum       EFEC;   // extended filter element configuration
} struct_extended_id_filter;


//extern can_global_struct global;

/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_CAN_Open(void);
extern INT32 ncLib_CAN_Close(void);
extern INT32 ncLib_CAN_Read(can_msg_struct *can_ptr);
extern INT32 ncLib_CAN_Write(can_msg_struct *tx_msg_ptr);
extern INT32 ncLib_CAN_Init(void);
extern void ncLib_CAN_handle_interrupts(void);



#endif /* __CAN_LIB_H__ */


/* End Of File */

