/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __CAN_DRV_H__
#define __CAN_DRV_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
               TYPEDEFS
********************************************************************************
*/



/*
********************************************************************************
*               DEFINES
********************************************************************************
*/
#define CAN_IO_WIRING_BASE_FROM_TOP_DESIGN          0x10F00000

// generate value with '1' set at position 'x'
#define BIT(x) (1 << (x))
#define ARRAYSIZE(x) ((int)(sizeof(x)/sizeof(x[0])))
#define BITMASK_FROM_B_DOWNTO_A(b, a) (((unsigned) -1 >> (31 - (b))) & ~((1U << (a)) - 1))

// ADDRESS and RESET_VALUE definitions for M_TTCAN Registers

// MISC -----------------------
#define ADR_M_CAN_CREL    0x00
#define DEF_M_CAN_CREL    0x32150320  // M_CAN   Version 3_2_1, 20.03.2015

#define ADR_M_CAN_ENDN    0x004       // Endian Register (R)
#define DEF_M_CAN_ENDN    0x87654321

// address: 0x008 CUST Customer Register

#define ADR_M_CAN_DBTP    0x00C       // Data Bit Timing & Prescaler Register (RP)
#define DEF_M_CAN_DBTP    0x00000A33

#define ADR_M_CAN_TEST    0x010       // Test Register (RP)
#define DEF_M_CAN_TEST    0x00000080

#define ADR_M_CAN_RWD     0x014       // RAM Watchdog (RP)
#define DEF_M_CAN_RWD     0x00000000

#define ADR_M_CAN_CCCR    0x018       // CC Control Register (RP)
#define DEF_M_CAN_CCCR    0x00000001

#define ADR_M_CAN_NBTP    0x01C       // Nominal Bit Timing & Prescaler Register (RP)
#define DEF_M_CAN_NBTP    0x06000A03

// Timestamp & Timeout ----------

#define ADR_M_CAN_TSCC    0x020       // Timestamp Counter Configuration (RP)
#define DEF_M_CAN_TSCC    0x00000000

#define ADR_M_CAN_TSCV    0x024       // Timestamp Counter Value (RC)
#define DEF_M_CAN_TSCV    0x00000000

#define ADR_M_CAN_TOCC    0x028       // Timeout Counter Configuration (RP)
#define DEF_M_CAN_TOCC    0xFFFF0000

#define ADR_M_CAN_TOCV    0x02C       // Timeout Counter Value (RC)
#define DEF_M_CAN_TOCV    0x0000FFFF

// Interrupt --------------------

// reserved address/range 0x030-03C
#define ADR_M_CAN_ECR     0x040       // Error Counter Register (R)
#define DEF_M_CAN_ECR     0x00000000

#define ADR_M_CAN_PSR     0x044       // Protocol Status Register (RXS)
#define DEF_M_CAN_PSR     0x00000707

#define ADR_M_CAN_TDCR    0x048       // Transmitter Delay Compensation (RP)
#define DEF_M_CAN_TDCR    0x00000000

// reserved address/range 0x048-04C
#define ADR_M_CAN_IR      0x050       // Interrupt Register (RW)
#define DEF_M_CAN_IR      0x00000000

#define ADR_M_CAN_IE      0x054       // Interrupt Enable (RW)
#define DEF_M_CAN_IE      0x00000000

#define ADR_M_CAN_ILS     0x058       // Interrupt Line Select (RW)
#define DEF_M_CAN_ILS     0x00000000

#define ADR_M_CAN_ILE     0x05C       // Interrupt Line Enable (RW)
#define DEF_M_CAN_ILE     0x00000000

// Rx Message Handler -------------

// reserved address/range 0x060-07C
#define ADR_M_CAN_GFC     0x080       // Global Filter Configuration (RP)
#define DEF_M_CAN_GFC     0x00000000

#define ADR_M_CAN_SIDFC   0x084       // Standard ID Filter Configuration (RP)
#define DEF_M_CAN_SIDFC   0x00000000

#define ADR_M_CAN_XIDFC   0x088       // Extended ID Filter Configuration (RP)
#define DEF_M_CAN_XIDFC   0x00000000

// reserved address/range 0x08C
#define ADR_M_CAN_XIDAM   0x090       // Extended ID AND Mask (RP)
#define DEF_M_CAN_XIDAM   0x1FFFFFFF

#define ADR_M_CAN_HPMS    0x094       // High Priority Message Status (R)
#define DEF_M_CAN_HPMS    0x00000000

#define ADR_M_CAN_NDAT1   0x098       // New Data 1 (RW)
#define DEF_M_CAN_NDAT1   0x00000000

#define ADR_M_CAN_NDAT2   0x09C       // New Data 2 (RW)
#define DEF_M_CAN_NDAT2   0x00000000

#define ADR_M_CAN_RXF0C   0x0A0       // Rx FIFO 0 Configuration (RP)
#define DEF_M_CAN_RXF0C   0x00000000

#define ADR_M_CAN_RXF0S   0x0A4       // Rx FIFO 0 Status (R)
#define DEF_M_CAN_RXF0S   0x00000000

#define ADR_M_CAN_RXF0A   0x0A8       // Rx FIFO 0 Acknowledge (RW)
#define DEF_M_CAN_RXF0A   0x00000000

#define ADR_M_CAN_RXBC    0x0AC       // Rx Buffer Configuration (RW)
#define DEF_M_CAN_RXBC    0x00000000

#define ADR_M_CAN_RXF1C   0x0B0       // Rx FIFO 1 Configuration (RP)
#define DEF_M_CAN_RXF1C   0x00000000

#define ADR_M_CAN_RXF1S   0x0B4       // Rx FIFO 1 Status (R)
#define DEF_M_CAN_RXF1S   0x00000000

#define ADR_M_CAN_RXF1A   0x0B8       // Rx FIFO 1 Acknowledge (RW)
#define DEF_M_CAN_RXF1A   0x00000000

#define ADR_M_CAN_RXESC   0x0BC       // Rx Buffer / FIFO Element Size Configuration (RW)
#define DEF_M_CAN_RXESC   0x00000000

// Tx Message Handler -------------

#define ADR_M_CAN_TXBC    0x0C0       // Tx Buffer Configuration (RP)
#define DEF_M_CAN_TXBC    0x00000000

#define ADR_M_CAN_TXFQS   0x0C4       // Tx FIFO/Queue Status (R)
#define DEF_M_CAN_TXFQS   0x00000000

#define ADR_M_CAN_TXESC   0x0C8       // Tx Buffer Element Size Configuration (RW)
#define DEF_M_CAN_TXESC   0x00000000

#define ADR_M_CAN_TXBRP   0x0CC       // Tx Buffer Request Pending (R)
#define DEF_M_CAN_TXBRP   0x00000000

#define ADR_M_CAN_TXBAR   0x0D0       // Tx Buffer Add Request (RW)
#define DEF_M_CAN_TXBAR   0x00000000

#define ADR_M_CAN_TXBCR   0x0D4       // Tx Buffer Cancellation Request (RW)
#define DEF_M_CAN_TXBCR   0x00000000

#define ADR_M_CAN_TXBTO   0x0D8       // Tx Buffer Transmission Occurred (R)
#define DEF_M_CAN_TXBTO   0x00000000

#define ADR_M_CAN_TXBCF   0x0DC       // Tx Buffer Cancellation Finished (R)
#define DEF_M_CAN_TXBCF   0x00000000

#define ADR_M_CAN_TXBTIE  0x0E0       // Tx Buffer Transmission Interrupt Enable (RW)
#define DEF_M_CAN_TXBTIE  0x00000000

#define ADR_M_CAN_TXBCIE  0x0E4       // Tx Buffer Cancellation Finished Interrupt Enable (RW)
#define DEF_M_CAN_TXBCIE  0x00000000

// reserved address/range 0x0E8-0EC
#define ADR_M_CAN_TXEFC   0x0F0       // Tx Event FIFO Configuration (RP)
#define DEF_M_CAN_TXEFC   0x00000000

#define ADR_M_CAN_TXEFS   0x0F4       // Tx Event FIFO Status (R)
#define DEF_M_CAN_TXEFS   0x00000000

#define ADR_M_CAN_TXEFA   0x0F8       // Tx Event FIFO Acknowledge (RW)
#define DEF_M_CAN_TXEFA   0x00000000

// reserved address/range 0x0FC

//  ~~~~~~~~~ M_TT_CAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#define ADR_M_CAN_TTTMC   0x100       // TT Trigger Memory Configuration (RP)
#define DEF_M_CAN_TTTMC   0x00000000

#define ADR_M_CAN_TTRMC   0x104       // TT Reference Message Configuration (RP)
#define DEF_M_CAN_TTRMC   0x00000000

#define ADR_M_CAN_TTOCF   0x108       // TT Operation Configuration (RP)
#define DEF_M_CAN_TTOCF   0x00010000

#define ADR_M_CAN_TTMLM   0x10C       // TT Matrix Limits (RP)
#define DEF_M_CAN_TTMLM   0x00000000

#define ADR_M_CAN_TURCF   0x110       // TUR Configuration (RP)
#define DEF_M_CAN_TURCF   0x10000000

#define ADR_M_CAN_TTOCN   0x114       // TT Operation Control (RW)
#define DEF_M_CAN_TTOCN   0x00000000

#define ADR_M_CAN_TTGTP   0x118       // TT Global Time Preset (RW)
#define DEF_M_CAN_TTGTP   0x00000000

#define ADR_M_CAN_TTTMK   0x11C       // TT Time Mark (RW)
#define DEF_M_CAN_TTTMK   0x00000000

#define ADR_M_CAN_TTIR    0x120       // TT Interrupt Register (RW)
#define DEF_M_CAN_TTIR    0x00000000

#define ADR_M_CAN_TTIE    0x124       // TT Interrupt Enable (RW)
#define DEF_M_CAN_TTIE    0x00000000

#define ADR_M_CAN_TTILS   0x128       // TT Interrupt Line Select (RW)
#define DEF_M_CAN_TTILS   0x00000000

#define ADR_M_CAN_TTOST   0x12C       // TT Operation Status (R)
#define DEF_M_CAN_TTOST   0x00000080

#define ADR_M_CAN_TURNA   0x130       // TUR Numerator Actual (R)
#define DEF_M_CAN_TURNA   0x00010000

#define ADR_M_CAN_TTLGT   0x134       // TT Local & Global Time (R)
#define DEF_M_CAN_TTLGT   0x00000000

#define ADR_M_CAN_TTCTC   0x138       // TT Cycle Time & Count (R)
#define DEF_M_CAN_TTCTC   0x003F0000

#define ADR_M_CAN_TTCPT   0x13C       // TT Capture Time (R)
#define DEF_M_CAN_TTCPT   0x00000000

#define ADR_M_CAN_TTCSM   0x140       // TT Cycle Sync Mark (R)
#define DEF_M_CAN_TTCSM   0x00000000

// reserved address/range 0x144-1FC


// === Type Definition for REGISTERs =========================================

/* BITFIELDS
 * Bit fields vary widely from compiler to compiler, sorry.
 * With GCC, big endian machines lay out the bits big end first and little endian machines lay out the bits little end first.
 */

//  ~~~~~~~~~ M_CAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


/* Type Definition for register CREL */
typedef union {
  volatile unsigned int value ;            //!< Integer representation
  volatile struct {
    volatile unsigned int   DAY     :  8; //!< 07..00: Design Time Stamp, Day
    volatile unsigned int   MON     :  8; //!< 15..08: Design Time Stamp, Month
    volatile unsigned int   YEAR    :  4; //!< 19..16: Design Time Stamp, Year
    volatile unsigned int   SUBSTEP :  4; //!< 23..20: Sub-Step of Core Release
    volatile unsigned int   STEP    :  4; //!< 27..24: Step of Core Release
    volatile unsigned int   REL     :  4; //!< 31..28: Core Release
  } bits;                                 //!< Bit representation
} M_CAN_CREL_union;




/* Type Definition for register ENDN - Endian Register */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   ETV0    :  8; //!< 07..00: Byte0 has Value h#21
    volatile unsigned int   ETV1    :  8; //!< 15..08: Byte1 has Value h#43
    volatile unsigned int   ETV2    :  8; //!< 23..16: Byte2 has Value h#65
    volatile unsigned int   ETV3    :  8; //!< 31..24: Byte3 has Value h#87
  } bits;                                 //!< Bit representation
} M_CAN_ENDN_union;

/* Type Definition for register DBTP - Data Bit Timing and Prescaler Register */
typedef union {
  volatile unsigned int value; //!< Integer representation
  volatile struct {
    volatile unsigned int DSJW   :4; //!< 03..00: Data (Re) Synchronization Jump Width
    volatile unsigned int DTSEG2 :4; //!< 07..04: Data time segment after  sample point
    volatile unsigned int DTSEG1 :5; //!< 12..08: Data time segment before sample point
    volatile unsigned int res0   :3; //!< 15..13: reserved
    volatile unsigned int DBRP   :5; //!< 20..16: Data Bit Rate Rate Prescaler
    volatile unsigned int res1   :2; //!< 22..21: reserved
    volatile unsigned int TDC    :1; //!<     23: Transceiver Delay Compensation
    volatile unsigned int res2   :8; //!< 31..24: reserved
  } bits; //!< Bit representation
} M_CAN_DBTP_union;

/* Type Definition for register TEST - Test Register */
typedef union {
  volatile unsigned int value; //!< Integer representation
  volatile struct {
    volatile unsigned int res0 : 4; //!< 03..00: reserved
    volatile unsigned int LBCK : 1; //!<     04: Loop Back Mode
    volatile unsigned int TX   : 2; //!< 06..05: Control of Transmit Pin
    volatile unsigned int RX   : 1; //!<     07: Receive Pin
    volatile unsigned int res1 :24; //!< 31..08: reserved
  } bits; //!< Bit representation
} M_CAN_TEST_union;



/* Type Definition for register RWD - RAM Watchdog */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   WDC     :  8; //!< 07..00: Watchdog Configuration
    volatile unsigned int   WDV     :  8; //!< 15..08: Watchdog Value
    volatile unsigned int   res0    : 16; //!< 31..16: reserved
  } bits;                                 //!< Bit representation
} M_CAN_RWD_union;

/* Type Definition for register CCCR - CC Control Register */
typedef union {
  volatile unsigned int value; //!< Integer representation
  volatile struct {
    volatile unsigned int INIT : 1; //!<     00: Initialization
    volatile unsigned int CCE  : 1; //!<     01: Configuration Change Enable
    volatile unsigned int ASM  : 1; //!<     02: Restricted Operation Mode
    volatile unsigned int CSA  : 1; //!<     03: Clock Stop Acknowledge
    volatile unsigned int CSR  : 1; //!<     04: Clock Stop Request
    volatile unsigned int MON  : 1; //!<     05: Bus Monitoring Mode
    volatile unsigned int DAR  : 1; //!<     06: Disable Automatic Retransmission
    volatile unsigned int TEST : 1; //!<     07: Test Mode Enable
    volatile unsigned int FDOE : 1; //!<     08: FD Operation Enable
    volatile unsigned int BRSE : 1; //!<     09: Bit Rate Switch Enable
    volatile unsigned int res0 : 2; //!< 11..10: reserved
    volatile unsigned int PXHD : 1; //!<     12: Protocol Exception Handling Disable
    volatile unsigned int EFBI : 1; //!<     13: Edge Filtering During Bus Integration
    volatile unsigned int TXP  : 1; //!<     14: Transmit Pause
    volatile unsigned int NISO : 1; //!<     15: Non ISO Operation (0=ISO, 1=BoschSpecV1.0)
    volatile unsigned int res1 :16; //!< 31..16: reserved
  } bits; //!< Bit representation CCCR
} M_CAN_CCCR_union;

/* Type Definition for register NBTP - Nominal Bit Timing & Prescaler Register */
typedef union {
  volatile unsigned int value; //!< Integer representation
  volatile struct {
    volatile unsigned int NTSEG2 : 7; //!< 06..00: Nominal time segment after the sample point
    volatile unsigned int res0   : 1; //!<     07: reserved
    volatile unsigned int NTSEG1 : 8; //!< 15..08: Nominal time segment before the sample point
    volatile unsigned int NBRP   : 9; //!< 24..16: Nominal Bit Rate Prescaler
    volatile unsigned int NSJW   : 7; //!< 31..25: Nominal (Re) Synchronization Jump Width
  } bits; //!< Bit representation
} M_CAN_NBTP_union;

/* Type Definition for register TSCC - Timestamp Counter Configuration */
typedef union {
  volatile unsigned int value;        //!< Integer representation
  volatile struct {
    volatile unsigned int TSS   :2;  //!< 01..00: Timestamp Select
    volatile unsigned int res0  :14; //!< 15..02: reserved
    volatile unsigned int TCP   :4;  //!< 19..16: Timestamp Counter Prescaler
    volatile unsigned int res1  :12; //!< 31..20: reserved
  } bits;                            //!< Bit representation
} M_CAN_TSCC_union;


/* TSCC: Timestamp Select */
typedef enum {
    TSCC_TSS_TIMESTAMP_COUNTER_VALUE_ALWAYS_0 = 0x0,
    TSCC_TSS_TIMESTAMP_COUNTER_VALUE_ACCORDING_TO_TCP = 0x1,
    TSCC_TSS_TIMESTAMP_COUNTER_VALUE_EXTERNAL_USED = 0x2
} tscc_tss_timestamp_select_enum;

#define TSCC_TCP_MIN_VALUE  1 // Minimum allowed value for TimeStamp Prescaler
#define TSCC_TCP_MAX_VALUE 16 // Maximum allowed value for TimeStamp Prescaler


/* Type Definition for register TSCV - Timestamp Counter Value */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   TSC     : 16; //!< 15..00: Timestamp Counter
    volatile unsigned int   res0    : 16; //!< 31..16: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TSCV_union;

/* Type Definition for register TOCC - Timeout Counter Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   ETOC    :  1; //!<     00: Enable Timeout Counter
    volatile unsigned int   TOS     :  2; //!< 02..01: Timeout Select
    volatile unsigned int   res0    : 13; //!< 15..03: reserved
    volatile unsigned int   TOP     : 16; //!< 31..16: Timeout Period
  } bits;                                 //!< Bit representation
} M_CAN_TOCC_union;


/* TOCC: Timeout Select */
typedef enum {
    TOCC_TOS_CONTINUOUS_OPERATION               = 0x0,
    TOCC_TOS_TIMEOUT_CONTROLLED_BY_TX_EVENT_FIFO = 0x1,
    TOCC_TOS_TIMEOUT_CONTROLLED_BY_RX_FIFO_0    = 0x2,
    TOCC_TOS_TIMEOUT_CONTROLLED_BY_RX_FIFO_1    = 0x3
} tocc_tos_timeout_select_enum;

/* Type Definition for register TOCV - Timeout Counter Value */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   TOC     : 16; //!< 15..00: Timeout Counter
    volatile unsigned int   res0    : 16; //!< 31..16: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TOCV_union;

/* Type Definition for register ECR - Error Counter Register */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   TEC     :  8; //!< 07..00: Transmit Error Counter
    volatile unsigned int   REC     :  7; //!< 14..08: Receive Error Counter
    volatile unsigned int   RP      :  1; //!<     15: Receive Error Passive
    volatile unsigned int   CEL     :  8; //!< 23..16: CAN Error Logging
    volatile unsigned int   res0    :  8; //!< 31..24: reserved
  } bits;                                 //!< Bit representation
} M_CAN_ECR_union;

/* Type Definition for register PSR - Protocol Status Register */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   LEC     :  3; //!< 02..00: Last Error Code
    volatile unsigned int   ACT     :  2; //!< 04..03: Activity
    volatile unsigned int   EP      :  1; //!<     05: Error Passive
    volatile unsigned int   EW      :  1; //!<     06: Warning Status
    volatile unsigned int   BO      :  1; //!<     07: Bus_Off Status
    volatile unsigned int   DLEC    :  3; //!< 10..08: Data Phase Last Error Code
    volatile unsigned int   RESI    :  1; //!<     11: ESI flag of last received CAN FD Message
    volatile unsigned int   RBRS    :  1; //!<     12: BRS flag of last received CAN FD Message
    volatile unsigned int   RFDF    :  1; //!<     13: Received a CAN FD Message
    volatile unsigned int   PXE     :  1; //!<     14: Protocol Exception Event
    volatile unsigned int   res0    :  1; //!<     15: reserved
    volatile unsigned int   TDCV    :  7; //!< 22..16: Transceiver Delay Compensation Value
    volatile unsigned int   res1    :  9; //!< 31..23: reserved
  } bits; //!< Bit representation
} M_CAN_PSR_union;


/* PSR: Activity Encoding */
enum m_can_psr_activity {
  ACT_SYNCHRONIZING = 0,  // node is synchronizing on CAN communication
  ACT_IDLE = 1,           // node is neither Receiver nor Transmitter
  ACT_RECEIVER = 2,       // node is operating as Receiver
  ACT_TRANSMITTER = 3     // node is operating as Transmitter
};


/* Type Definition for register TDCR - Transmitter Delay Compensation Register */
typedef union {
  volatile unsigned int value;          //!< Integer representation
  volatile struct {
    volatile unsigned int   TDCF  :  7; //!< 06..00: Transmitter Delay Compensation Filter Window Length
    volatile unsigned int   res0  :  1; //!<     07: reserved
    volatile unsigned int   TDCO  :  7; //!< 14..08: Transmitter Delay Compensation Offset
    volatile unsigned int   res1  : 17; //!< 31..15: reserved
  } bits;                               //!< Bit representation
} M_CAN_TDCR_union;

/* Type Definition for register IR - Interrupt Register */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   RF0N    :  1; //!<     00: Rx FIFO 0 New Message
    volatile unsigned int   RF0W    :  1; //!<     01: Rx FIFO 0 Watermark Reached
    volatile unsigned int   RF0F    :  1; //!<     02: Rx FIFO 0 Full
    volatile unsigned int   RF0L    :  1; //!<     03: Rx FIFO 0 Message Lost
    volatile unsigned int   RF1N    :  1; //!<     04: Rx FIFO 1 New Message
    volatile unsigned int   RF1W    :  1; //!<     05: Rx FIFO 1 Watermark Reached
    volatile unsigned int   RF1F    :  1; //!<     06: Rx FIFO 1 Full
    volatile unsigned int   RF1L    :  1; //!<     07: Rx FIFO 1 Message Lost
    volatile unsigned int   HPM     :  1; //!<     08: High Priority Message
    volatile unsigned int   TC      :  1; //!<     09: Transmission Completed
    volatile unsigned int   TCF     :  1; //!<     10: Transmission Cancellation Finished
    volatile unsigned int   TFE     :  1; //!<     11: Tx FIFO Empty
    volatile unsigned int   TEFN    :  1; //!<     12: Tx Event FIFO New Entry
    volatile unsigned int   TEFW    :  1; //!<     13: Tx Event FIFO Watermark Reached
    volatile unsigned int   TEFF    :  1; //!<     14: Tx Event FIFO Full
    volatile unsigned int   TEFL    :  1; //!<     15: Tx Event FIFO Element Lost
    volatile unsigned int   TSW     :  1; //!<     16: Timestamp Wraparound
    volatile unsigned int   MRAF    :  1; //!<     17: Message RAM Access Failure
    volatile unsigned int   TOO     :  1; //!<     18: Timeout Occurred
    volatile unsigned int   DRX     :  1; //!<     19: Message stored to Dedicated Rx Buffer
    volatile unsigned int   BEC     :  1; //!<     20: Bit Error Corrected
    volatile unsigned int   BEU     :  1; //!<     21: Bit Error Uncorrected
    volatile unsigned int   ELO     :  1; //!<     22: Error Logging Overflow
    volatile unsigned int   EP      :  1; //!<     23: Error Passive
    volatile unsigned int   EW      :  1; //!<     24: Warning Status
    volatile unsigned int   BO      :  1; //!<     25: Bus_Off Status
    volatile unsigned int   WDI     :  1; //!<     26: Watchdog Interrupt
    volatile unsigned int   PEA     :  1; //!<     27: Protocol Error in Arbitration Phase
    volatile unsigned int   PED     :  1; //!<     28: Protocol Error in Data        Phase
    volatile unsigned int   ARA     :  1; //!<     29: Access to Reserved Address
    volatile unsigned int   res0    :  2; //!< 30..31: reserved
  } bits;                                 //!< Bit representation
} M_CAN_IR_union;


/* Type Definition for register IE - Interrupt Enable */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   RF0NE   :  1; //!<     00: Rx FIFO 0 New Message Interrupt Enable
    volatile unsigned int   RF0WE   :  1; //!<     01: Rx FIFO 0 Watermark Reached Interrupt Enable
    volatile unsigned int   RF0FE   :  1; //!<     02: Rx FIFO 0 Full Interrupt Enable
    volatile unsigned int   RF0LE   :  1; //!<     03: Rx FIFO 0 Message Lost Interrupt Enable
    volatile unsigned int   RF1NE   :  1; //!<     04: Rx FIFO 1 New Message Interrupt Enable
    volatile unsigned int   RF1WE   :  1; //!<     05: Rx FIFO 1 Watermark Reached Interrupt Enable
    volatile unsigned int   RF1FE   :  1; //!<     06: Rx FIFO 1 Full Interrupt Enable
    volatile unsigned int   RF1LE   :  1; //!<     07: Rx FIFO 1 Message Lost Interrupt Enable
    volatile unsigned int   HPME    :  1; //!<     08: High Priority Message Interrupt Enable
    volatile unsigned int   TCE     :  1; //!<     09: Transmission Completed Interrupt Enable
    volatile unsigned int   TCFE    :  1; //!<     10: Transmission Cancellation Finished Interrupt Enable
    volatile unsigned int   TFEE    :  1; //!<     11: Tx FIFO Empty Interrupt Enable
    volatile unsigned int   TEFNE   :  1; //!<     12: Tx Event FIFO New Entry Interrupt Enable
    volatile unsigned int   TEFWE   :  1; //!<     13: Tx Event FIFO Watermark Reached Interrupt Enable
    volatile unsigned int   TEFFE   :  1; //!<     14: Tx Event FIFO Full Interrupt Enable
    volatile unsigned int   TEFLE   :  1; //!<     15: Tx Event FIFO Element Lost Interrupt Enable
    volatile unsigned int   TSWE    :  1; //!<     16: Timestamp Wraparound Interrupt Enable
    volatile unsigned int   MRAFE   :  1; //!<     17: Message RAM Access Failure Interrupt Enable
    volatile unsigned int   TOOE    :  1; //!<     18: Timeout Occurred Interrupt Enable
    volatile unsigned int   DRXE    :  1; //!<     19: Message stored to Dedicated Rx Buffer Interrupt Enable
    volatile unsigned int   BECE    :  1; //!<     20: Bit Error Corrected Interrupt Enable
    volatile unsigned int   BEUE    :  1; //!<     21: Bit Error Uncorrected Interrupt Enable
    volatile unsigned int   ELOE    :  1; //!<     22: Error Logging Overflow Interrupt Enable
    volatile unsigned int   EPE     :  1; //!<     23: Error Passive Interrupt Enable
    volatile unsigned int   EWE     :  1; //!<     24: Warning Status Interrupt Enable
    volatile unsigned int   BOE     :  1; //!<     25: Bus_Off Status Interrupt Enable
    volatile unsigned int   WDIE    :  1; //!<     26: Watchdog Interrupt Interrupt Enable
    volatile unsigned int   PEAE    :  1; //!<     27: Protocol Error in Arbitration Phase Interrupt Enable
    volatile unsigned int   PEDE    :  1; //!<     28: Protocol Error in Data        Phase Interrupt Enable
    volatile unsigned int   ARAE    :  1; //!<     29: Access to Reserved Address Interrupt Enable
    volatile unsigned int   res0    :  2; //!< 30..31: reserved
  } bits;                                 //!< Bit representation
} M_CAN_IE_union;

/* Type Definition for register ILS - Interrupt Line Select */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   RF0NL   :  1; //!<     00: Rx FIFO 0 New Message Interrupt Line
    volatile unsigned int   RF0WL   :  1; //!<     01: Rx FIFO 0 Watermark Reached Interrupt Line
    volatile unsigned int   RF0FL   :  1; //!<     02: Rx FIFO 0 Full Interrupt Line
    volatile unsigned int   RF0LL   :  1; //!<     03: Rx FIFO 0 Message Lost Interrupt Line
    volatile unsigned int   RF1NL   :  1; //!<     04: Rx FIFO 1 New Message Interrupt Line
    volatile unsigned int   RF1WL   :  1; //!<     05: Rx FIFO 1 Watermark Reached Interrupt Line
    volatile unsigned int   RF1FL   :  1; //!<     06: Rx FIFO 1 Full Interrupt Line
    volatile unsigned int   RF1LL   :  1; //!<     07: Rx FIFO 1 Message Lost Interrupt Line
    volatile unsigned int   HPML    :  1; //!<     08: High Priority Message Interrupt Line
    volatile unsigned int   TCL     :  1; //!<     09: Transmission Completed Interrupt Line
    volatile unsigned int   TCFL    :  1; //!<     10: Transmission Cancellation Finished Interrupt Line
    volatile unsigned int   TFEL    :  1; //!<     11: Tx FIFO Empty Interrupt Line
    volatile unsigned int   TEFNL   :  1; //!<     12: Tx Event FIFO New Entry Interrupt Line
    volatile unsigned int   TEFWL   :  1; //!<     13: Tx Event FIFO Watermark Reached Interrupt Line
    volatile unsigned int   TEFFL   :  1; //!<     14: Tx Event FIFO Full Interrupt Line
    volatile unsigned int   TEFLL   :  1; //!<     15: Tx Event FIFO Element Lost Interrupt Line
    volatile unsigned int   TSWL    :  1; //!<     16: Timestamp Wraparound Interrupt Line
    volatile unsigned int   MRAFL   :  1; //!<     17: Message RAM Access Failure Interrupt Line
    volatile unsigned int   TOOL    :  1; //!<     18: Timeout Occurred Interrupt Line
    volatile unsigned int   DRXL    :  1; //!<     19: Message stored to Dedicated Rx Buffer Interrupt Line
    volatile unsigned int   BECL    :  1; //!<     20: Bit Error Corrected Interrupt Line
    volatile unsigned int   BEUL    :  1; //!<     21: Bit Error Uncorrected Interrupt Line
    volatile unsigned int   ELOL    :  1; //!<     22: Error Logging Overflow Interrupt Line
    volatile unsigned int   EPL     :  1; //!<     23: Error Passive Interrupt Line
    volatile unsigned int   EWL     :  1; //!<     24: Warning Status Interrupt Line
    volatile unsigned int   BOL     :  1; //!<     25: Bus_Off Status Interrupt Line
    volatile unsigned int   WDIL    :  1; //!<     26: Watchdog Interrupt Interrupt Line
    volatile unsigned int   PEAL    :  1; //!<     27: Protocol Error in Arbitration Phase Interrupt Line
    volatile unsigned int   PEDL    :  1; //!<     28: Protocol Error in Data        Phase Interrupt Line
    volatile unsigned int   ARAL    :  1; //!<     29: Access to Reserved Address Interrupt Line
    volatile unsigned int   res0    :  2; //!< 30..31: reserved
  } bits;                                 //!< Bit representation
} M_CAN_ILS_union;


// Interrupt Register Bit Positions in registers IR, ILE, ILS
#define IR_Access_to_Reserved_Address               BIT(29)
#define IR_Protocol_Error_in_Data_Phase             BIT(28)
#define IR_Protocol_Error_in_Arbitration_Phase      BIT(27)
#define IR_Watchdog                                 BIT(26)
#define IR_Bus_Off_Status                           BIT(25)
#define IR_Warning_Status                           BIT(24)
#define IR_Error_Passive                            BIT(23)
#define IR_Error_Logging_Overflow                   BIT(22)
#define IR_Bit_Error_Uncorrected                    BIT(21)
#define IR_Bit_Error_Corrected                      BIT(20)
#define IR_Message_Stored_to_Dedicated_Rx_Buffer    BIT(19)
#define IR_Timeout_Occurred                         BIT(18)
#define IR_Message_RAM_Access_Failure               BIT(17)
#define IR_Timestamp_Wraparound                     BIT(16)
#define IR_Tx_Event_FIFO_Event_Lost                 BIT(15)
#define IR_Tx_Event_FIFO_Full                       BIT(14)
#define IR_Tx_Event_FIFO_Watermark_Reached          BIT(13)
#define IR_Tx_Event_FIFO_New_Entry                  BIT(12)
#define IR_Tx_FIFO_Empty                            BIT(11)
#define IR_Transmission_Cancellation_Finished       BIT(10)
#define IR_Transmission_Completed                   BIT(9)
#define IR_High_Priority_Message                    BIT(8)
#define IR_Rx_FIFO1_Message_Lost                    BIT(7)
#define IR_Rx_FIFO1_Full                            BIT(6)
#define IR_Rx_FIFO1_Watermark_Reached               BIT(5)
#define IR_Rx_FIFO1_New_Message                     BIT(4)
#define IR_Rx_FIFO0_Message_Lost                    BIT(3)
#define IR_Rx_FIFO0_Full                            BIT(2)
#define IR_Rx_FIFO0_Watermark_Reached               BIT(1)
#define IR_Rx_FIFO0_New_Message                     BIT(0)

//#define INTERRUPT_ALL_SIGNALS       0x3FFFFFFF
#define INTERRUPT_ALL_SIGNALS       0x1FFFFFFF

/* Type Definition for register ILE - Interrupt Line Enable */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   EINT0   :  1; //!<     00: enable interrupt line 0
    volatile unsigned int   EINT1   :  1; //!<     01: enable interrupt line 1
    volatile unsigned int   res0    : 30; //!< 31..02: reserved
  } bits;                                 //!< Bit representation
} M_CAN_ILE_union;



/* ILE defines */
#define ILE_DISABLE_INTERRUPT_LINES     0x0
#define ILE_ENABLE_INTERRUPT_LINE_0     0x1
#define ILE_ENABLE_INTERRUPT_LINE_1     0x2


/* Type Definition for register GFC - Global Filter Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   RRFE    :  1; //!<     00: reject remote frames extended
    volatile unsigned int   RRFS    :  1; //!<     01: reject remote frames standard
    volatile unsigned int   ANFE    :  2; //!< 03..02: Accept Non-matching frames extended
    volatile unsigned int   ANFS    :  2; //!< 05..04: Accept Non-matching frames standard
    volatile unsigned int   res0    : 26; //!< 31..06: reserved
  } bits;                                 //!< Bit representation
} M_CAN_GFC_union;


/* Accept Non-matching Frames (GFC Register) */
typedef enum {
  ACCEPT_NON_MATCHING_FRAMES_IN_RX_FIFO0 = 0x0,
  ACCEPT_NON_MATCHING_FRAMES_IN_RX_FIFO1 = 0x1,
  REJECT_NON_MATCHING_FRAMES             = 0x3
} GFC_accept_non_matching_frames_enum;


/* Type Definition for register SIDFC - Standard ID Filter Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   res0    :  2; //!< 01..00: reserved
    volatile unsigned int   FLSSA   : 14; //!< 15..02: Filter List Standard Start Address
    volatile unsigned int   LSS     :  8; //!< 23..16: List Size Standard
    volatile unsigned int   res1    :  8; //!< 31..24: reserved
  } bits;                                 //!< Bit representation
} M_CAN_SIDFC_union;

/* Type Definition for register XIDFC - Extended ID Filter Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   res0    :  2; //!< 01..00: reserved
    volatile unsigned int   FLESA   : 14; //!< 15..02: Filter List Extended Start Address
    volatile unsigned int   LSE     :  7; //!< 22..16: List Size Extended
    volatile unsigned int   res1    :  9; //!< 31..23: reserved
  } bits;                                 //!< Bit representation
} M_CAN_XIDFC_union;


/* Type Definition for register XIDAM - Extended ID AND Mask */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   EIDM    : 29; //!< 28..00: Extended ID Mask
    volatile unsigned int   res0    :  3; //!< 31..29: reserved
  } bits;                                 //!< Bit representation
} M_CAN_XIDAM_union;


/* Type Definition for register HPMS - High Priority Message Status */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   BIDX    :  6; //!< 05..00: Buffer Index
    volatile unsigned int   MSI     :  2; //!< 07..06: Message Storage Indicator
    volatile unsigned int   FIDX    :  7; //!< 14..08: Filter Index
    volatile unsigned int   FLST    :  1; //!<     15: Filter List
    volatile unsigned int   res0    : 16; //!< 31..16: reserved
  } bits;                                 //!< Bit representation
} M_CAN_HPMS_union;


/* HPMS Register: Message Storage Indicator (MSI) */
typedef enum {
    HPMS_MSI_NO_FIFO_SELECTED         = 0x0,
    HPMS_MSI_FIFO_MESSAGE_LOST        = 0x1,
    HPMS_MSI_MESSAGE_STORED_IN_FIFO0  = 0x2,
    HPMS_MSI_MESSAGE_STORED_IN_FIFO1  = 0x3
} MSI_Message_Storage_Indicator;

/* Type Definition for register NDAT1 - New Data 1 */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   NDAT    : 32; //!<     0: New Data flag of Rx Buffer 0 to 31
  } bits;                                 //!< Bit representation
} M_CAN_NDAT1_union;

/* Type Definition for register NDAT2 - New Data 2 */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   NDAT    : 32; //!<     0: New Data flag of Rx Buffer 32 to 63
  } bits;                                 //!< Bit representation
} M_CAN_NDAT2_union;


/* Type Definition for register RXF0C - Rx FIFO 0 Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   res0    :  2; //!< 01..00: reserved
    volatile unsigned int   F0SA    : 14; //!< 15..02: Rx FIFO 0 Start Address
    volatile unsigned int   F0S     :  7; //!< 22..16: Rx FIFO 0 Size
    volatile unsigned int   res1    :  1; //!<     23: reserved
    volatile unsigned int   F0WM    :  7; //!< 30..24: Rx FIFO 0 Watermark
    volatile unsigned int   F0OM    :  1; //!<     31: Rx FIFO 0 Operation Mode (blocking/overwrite)
  } bits;                                 //!< Bit representation
} M_CAN_RXF0C_union;


/* Type Definition for register RXF0S - Rx FIFO 0 Status */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   F0FL    :  7; //!< 06..00: Rx FIFO 0 Fill Level
    volatile unsigned int   res0    :  1; //!<     07: reserved
    volatile unsigned int   F0GI    :  6; //!< 13..08: Rx FIFO 0 Get Index
    volatile unsigned int   res1    :  2; //!< 15..14: reserved
    volatile unsigned int   F0PI    :  6; //!< 21..16: Rx FIFO 0 Put Index
    volatile unsigned int   res2    :  2; //!< 23..22: reserved
    volatile unsigned int   F0F     :  1; //!<     24: Rx FIFO 0 Full
    volatile unsigned int   RF0L    :  1; //!<     25: Rx FIFO 0 Message Lost
    volatile unsigned int   res3    :  6; //!< 31..26: reserved
  } bits;                                 //!< Bit representation
} M_CAN_RXF0S_union;


/* Type Definition for register RXF0A - Rx FIFO 0 Acknowledge */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   F0AI    :  6; //!< 05..00: Rx FIFO 0 Acknowledge Index
    volatile unsigned int   res0    : 26; //!< 31..06: reserved
  } bits;                                 //!< Bit representation
} M_CAN_RXF0A_union;


/* Type Definition for register RXBC - Rx Buffer Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   res0    :  2; //!< 01..00: reserved
    volatile unsigned int   RBSA    : 14; //!< 15..02: Rx Buffer Start Address
    volatile unsigned int   res2    : 16; //!< 31..16: reserved
  } bits;                                 //!< Bit representation
} M_CAN_RXBC_union;


/* Type Definition for register RXF1C - Rx FIFO 1 Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   res0    :  2; //!< 01..00: reserved
    volatile unsigned int   F1SA    : 14; //!< 15..02: Rx FIFO 1 Start Address
    volatile unsigned int   F1S     :  7; //!< 22..16: Rx FIFO 1 Size
    volatile unsigned int   res1    :  1; //!<     23: reserved
    volatile unsigned int   F1WM    :  7; //!< 30..24: Rx FIFO 1 Watermark
    volatile unsigned int   F1OM    :  1; //!<     31: Rx FIFO 1 Operation Mode (blocking=0/overwrite)
  } bits;                                 //!< Bit representation
} M_CAN_RXF1C_union;


/* Type Definition for register RXF1S - Rx FIFO 1 Status */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   F1FL    :  7; //!< 06..00: Rx FIFO 1 Fill Level
    volatile unsigned int   res0    :  1; //!<     07: reserved
    volatile unsigned int   F1GI    :  6; //!< 13..08: Rx FIFO 1 Get Index
    volatile unsigned int   res1    :  2; //!< 15..14: reserved
    volatile unsigned int   F1PI    :  6; //!< 21..16: Rx FIFO 1 Put Index
    volatile unsigned int   res2    :  2; //!< 23..22: reserved
    volatile unsigned int   F1F     :  1; //!<     24: Rx FIFO 1 Full
    volatile unsigned int   RF1L    :  1; //!<     25: Rx FIFO 1 Message Lost
    volatile unsigned int   res3    :  4; //!< 29..26: reserved
    volatile unsigned int   DMS     :  2; //!< 31..30: Debug Message Status
  } bits;                                 //!< Bit representation
} M_CAN_RXF1S_union;



/* Type Definition for register RXF1A - Rx FIFO 1 Acknowledge */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   F1AI    :  6; //!< 05..00: Rx FIFO 1 Acknowledge Index
    volatile unsigned int   res0    : 26; //!< 31..06: reserved
  } bits;                                 //!< Bit representation
} M_CAN_RXF1A_union;




/* Type Definition for register RXESC - Rx Buffer / FIFO Element Size Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   F0DS    :  3; //!< 02..00: Rx FIFO 0 Data Filed Size
    volatile unsigned int   res0    :  1; //!<     03: reserved
    volatile unsigned int   F1DS    :  3; //!< 06..04: Rx FIFO 1 Date Field Size
    volatile unsigned int   res1    :  1; //!<     07: reserved
    volatile unsigned int   RBDS    :  3; //!< 10..08: Rx Buffer Data Field Size
    volatile unsigned int   res2    : 21; //!< 31..11: reserved
  } bits;                                 //!< Bit representation
} M_CAN_RXESC_union;

/* Type Definition for register TXBC - Tx Buffer Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
#if 1 //LDG
     volatile unsigned int   res0    :  2; //!< 01..00: reserved
     volatile unsigned int   TBSA    : 14; //!< 15..02: Tx Buffers Start Address

#else
     volatile unsigned int   TBSA    : 16; //!< 15..02: Tx Buffers Start Address
#endif
    volatile unsigned int   NDTB    :  6; //!< 21..16: Number of Dedicated Transmit Buffers
    volatile unsigned int   res1    :  2; //!< 23..22: reserved
    volatile unsigned int   TFQS    :  6; //!< 29..24: Transmit FIFO/Queue Size
    volatile unsigned int   TFQM    :  1; //!<     30: Tx FIFO/Queue Mode
    volatile unsigned int   res2    :  1; //!<     31: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TXBC_union;


/* Type Definition for register TXFQS - Tx FIFO/Queue Status */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   TFFL    :  6; //!< 05..00: Tx FIFO Free Level
    volatile unsigned int   res0    :  2; //!< 07..06: reserved
    volatile unsigned int   TFGI    :  5; //!< 12..08: Tx FIFO Get Index
    volatile unsigned int   res1    :  3; //!< 23..20: reserved
    volatile unsigned int   TFQPI   :  5; //!< 20..16: Tx FIFO/Queue Put Index
    volatile unsigned int   TFQF    :  1; //!<     21: Tx FIFO/Queue Full (0=not full, 1=full)
    volatile unsigned int   res2    : 10; //!< 31..22: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TXFQS_union;


/* Type Definition for register TXESC - Tx Buffer / FIFO Element Size Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   TBDS    :  3; //!< 02..00: Tx Buffer Data Filed Size
    volatile unsigned int   res     : 29; //!< 03..31: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TXESC_union;




/* Type Definition for register TXBRP - Tx Buffer Request Pending */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   TRP     : 32; //!< 31..00: Transmission Request Pending
  } bits;                                 //!< Bit representation
} M_CAN_TXBRP_union;

/* Type Definition for register TXBAR - Tx Buffer Add Request */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   AR      : 32; //!< 31..00: Add Request
  } bits;                                 //!< Bit representation
} M_CAN_TXBAR_union;

/* Type Definition for register TXBCR - Tx Buffer Cancellation Request */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   CR      : 32; //!< 31..00: Cancellation Request
  } bits;                                 //!< Bit representation
} M_CAN_TXBCR_union;

/* Type Definition for register TXBTO - Tx Buffer Transmission Occurred */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   TO      : 32; //!< 31..00: Transmission Occurred
  } bits;                                 //!< Bit representation
} M_CAN_TXBTO_union;

/* Type Definition for register TXBCF - Tx Buffer Cancellation Finished */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   CF     : 32; //!< 31..00: Cancellation Finished
  } bits;                                 //!< Bit representation
} M_CAN_TXBCF_union;

/* Type Definition for register TXBTIE - Tx Buffer Transmission Interrupt Enable */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int  TIE     : 32; //!< 31..00: Transmission Interrupt Enable
  } bits;                                 //!< Bit representation
} M_CAN_TXBTIE_union;

/* Type Definition for register TXBCIE - Tx Buffer Cancellation Finished Interrupt Enable */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int  CIE     : 32; //!< 31..00: Cancellation Finished Interrupt Enable
  } bits;                                 //!< Bit representation
} M_CAN_TXBCIE_union;


/* Type Definition for register TXEFC - Tx Event FIFO Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   res0    :  2; //!< 01..00: reserved
    volatile unsigned int   EFSA    : 14; //!< 15..02: Event FIFO Start Address
    volatile unsigned int   EFS     :  6; //!< 21..16: Event FIFO Size
    volatile unsigned int   res1    :  2; //!< 23..22: reserved
    volatile unsigned int   EFWM    :  6; //!< 29..24: Event FIFO Watermark
    volatile unsigned int   res2    :  2; //!< 31..30: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TXEFC_union;


/* Type Definition for register TXEFS - Tx Event FIFO Status */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   EFFL    :  6; //!< 05..00: Event FIFO Fill Level
    volatile unsigned int   res0    :  2; //!< 07..06: reserved
    volatile unsigned int   EFGI    :  5; //!< 12..08: Event FIFO Get Index
    volatile unsigned int   res1    :  3; //!< 15..13: reserved
    volatile unsigned int   EFPI    :  5; //!< 20..16: Event FIFO Put Index
    volatile unsigned int   res2    :  3; //!< 23..21: reserved
    volatile unsigned int   EFF     :  1; //!<     24: Event FIFO Full
    volatile unsigned int   TEFL    :  1; //!<     25: Tx Event FIFO Element Lost
    volatile unsigned int   res3    :  6; //!< 31..26: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TXEFS_union;


/* Type Definition for register TXEFA - Tx Event FIFO Acknowledge */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   EFAI    :  5; //!< 04..00: Event FIFO Acknowledge Index
    volatile unsigned int   res0    : 27; //!< 31..05: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TXEFA_union;





/* LEC values - Last Error Code */
enum lec_type {
  LEC_NO_ERROR    = 0,
  LEC_STUFF_ERROR = 1,
  LEC_FORM_ERROR  = 2,
  LEC_ACK_ERROR   = 3,
  LEC_BIT1_ERROR  = 4,
  LEC_BIT0_ERROR  = 5,
  LEC_CRC_ERROR   = 6,
  LEC_NO_CHANGE   = 7,
};


//  ~~~~~~~~~ M_TT_CAN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/* Type Definition for register TTTMC - TT Trigger Memory Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   res0    :  2; //!< 01..00: reserved
    volatile unsigned int   TMSA    : 14; //!< 15..02: Trigger Memory Start Address
    volatile unsigned int   TME     :  7; //!< 22..16: Trigger Memory Elements
    volatile unsigned int   res1    :  9; //!< 31..23: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TTTMC_union;


/* Type Definition for register TTRMC - TT Reference Message Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   RID     : 29; //!< 28..00: Reference Identifier
    volatile unsigned int   res0    :  1; //!<     29: reserved
    volatile unsigned int   XTD     :  1; //!<     30: Extended Identifier
    volatile unsigned int   RMPS    :  1; //!<     31: Reference Message Payload Select
  } bits;                                 //!< Bit representation
} M_CAN_TTRMC_union;




/* Type Definition for register TTOCF - TT Operation Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   OM      :  2; //!< 01..00: Operation Mode
    volatile unsigned int   res0    :  1; //!<     02: reserved
    volatile unsigned int   GEN     :  1; //!<     03: Gap Enable
    volatile unsigned int   TM      :  1; //!<     04: Time Master
    volatile unsigned int   LDSDL   :  3; //!< 07..05: LD of Synchronization Deviation Limit
    volatile unsigned int   IRTO    :  7; //!< 14..08: Initial Reference Trigger Offset
    volatile unsigned int   EECS    :  1; //!<     15: Enable External Clock Synchronization
    volatile unsigned int   AWL     :  8; //!< 23..16: Application Watchdog Limit
    volatile unsigned int   EGTF    :  1; //!<     24: Enable Global Time Filtering
    volatile unsigned int   ECC     :  1; //!<     25: Enable Clock Calibration
    volatile unsigned int   EVTP    :  1; //!<     26: Event Trigger Polarity
    volatile unsigned int   res1    :  5; //!< 31..27: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TTOCF_union;


/* Type Definition for register TTMLM - TT Matrix Limits */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   CCM     :  6; //!< 05..00: Cycle Count Max
    volatile unsigned int   CSS     :  2; //!< 07..06: Cycle Start Synchronization
    volatile unsigned int   TXEW    :  4; //!< 11..08: Tx Enable Window
    volatile unsigned int   res0    :  4; //!< 15..12: reserved
    volatile unsigned int   ENTT    : 12; //!< 27..16: Expected Number of Tx Triggers
    volatile unsigned int   res1    :  4; //!< 31..28: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TTMLM_union;


/* Type Definition for register TURCF - TUR Configuration */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   NCL     : 16; //!< 15..00: Numerator Configuration Low
    volatile unsigned int   DC      : 14; //!< 29..16: Denominator Configuration
    volatile unsigned int   res0    :  1; //!<     30: reserved
    volatile unsigned int   ELT     :  1; //!<     31: Enable Local Time
  } bits;                                 //!< Bit representation
} M_CAN_TURCF_union;


/* Type Definition for register TTOCN - TT Operation Control */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   SGT     :  1; //!<     00: Set Global time
    volatile unsigned int   ECS     :  1; //!<     01: External Clock Synchronization
    volatile unsigned int   SWP     :  1; //!<     02: Stop Watch Edge Select
    volatile unsigned int   SWS     :  2; //!< 04..03: Stop Watch Source
    volatile unsigned int   RTIE    :  1; //!<     05: Register Time Mark Interrupt Pulse Enable
    volatile unsigned int   TMC     :  2; //!< 07..06: Register Time Mark Compare
    volatile unsigned int   TTIE    :  1; //!<     08: Trigger Time Mark Interrupt Pulse Enable
    volatile unsigned int   GCS     :  1; //!<     09: Gap Control Select
    volatile unsigned int   FGP     :  1; //!<     10: Gap Finished Indicator
    volatile unsigned int   TMG     :  1; //!<     11: Time Mark Gap
    volatile unsigned int   NIG     :  1; //!<     12: Next is Gap
    volatile unsigned int   ESCN    :  1; //!<     13: External Synchronization Control
    volatile unsigned int   res0    :  1; //!<     14: reserved
    volatile unsigned int   LCKC    :  1; //!<     15: TT Operation Control Register Locked
    volatile unsigned int   res1    : 16; //!< 31..16: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TTOCN_union;


/* Type Definition for register TTGTP - TT Global Time Preset */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   TP      : 16; //!< 15..00: Time Preset
    volatile unsigned int   CTP     : 16; //!< 31..16: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TTGTP_union;


/* Type Definition for register TTTMK - TT Register Time Mark */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   TM      : 16; //!< 15..00: Time Mark
    volatile unsigned int   TICC    :  7; //!< 22..16: Time Mark Cycle Code
    volatile unsigned int   res0    :  8; //!< 30..23: reserved
    volatile unsigned int   LCKM    :  1; //!<     31: TT Time Mark Register Locked
  } bits;                                 //!< Bit representation
} M_CAN_TTTMK_union;


/* Type Definition for register TTIR - TT Interrupt Register */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   SBC     :  1; //!<     00: Start of Basic Cycle
    volatile unsigned int   SMC     :  1; //!<     01: Start of Matrix Cycle
    volatile unsigned int   CSM     :  1; //!<     02: Change of Synchronization Mode
    volatile unsigned int   SOG     :  1; //!<     03: Start of Gap
    volatile unsigned int   RTMI    :  1; //!<     04: Register Time Mark Interrupt
    volatile unsigned int   TTMI    :  1; //!<     05: Trigger Time Mark Interrupt
    volatile unsigned int   SWE     :  1; //!<     06: Stop Watch Event
    volatile unsigned int   GTW     :  1; //!<     07: Global Time Wrap
    volatile unsigned int   GTD     :  1; //!<     08: Global Time Discontinuity
    volatile unsigned int   GTE     :  1; //!<     09: Global Time Error
    volatile unsigned int   TXU     :  1; //!<     10: Tx Count Underflow
    volatile unsigned int   TXO     :  1; //!<     11: Tx Count Overflow
    volatile unsigned int   SE1     :  1; //!<     12: Scheduling Error 1
    volatile unsigned int   SE2     :  1; //!<     13: Scheduling Error 2
    volatile unsigned int   ELC     :  1; //!<     14: Error Level Changed
    volatile unsigned int   IWT     :  1; //!<     15: Initialization Watch Trigger
    volatile unsigned int   WT      :  1; //!<     16: Watch Trigger
    volatile unsigned int   AW      :  1; //!<     17: Application Watchdog
    volatile unsigned int   CER     :  1; //!<     18: Configuration Error
    volatile unsigned int   res0    : 13; //!< 31..19: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TTIR_union;


/* Type Definition for register TTIE - TT Interrupt Enable */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   SBCE    :  1; //!<     00: Start of Basic Cycle Interrupt Enable
    volatile unsigned int   SMCE    :  1; //!<     01: Start of Matrix Cycle Interrupt Enable
    volatile unsigned int   CSME    :  1; //!<     02: Change of Synchronization Mode Interrupt Enable
    volatile unsigned int   SOGE    :  1; //!<     03: Start of Gap Interrupt Enable
    volatile unsigned int   RTMIE   :  1; //!<     04: Register Time Mark Interrupt Interrupt Enable
    volatile unsigned int   TTMIE   :  1; //!<     05: Trigger Time Mark Interrupt Interrupt Enable
    volatile unsigned int   SWEE    :  1; //!<     06: Stop Watch Event Interrupt Enable
    volatile unsigned int   GTWE    :  1; //!<     07: Global Time Wrap Interrupt Enable
    volatile unsigned int   GTDE    :  1; //!<     08: Global Time Discontinuity Interrupt Enable
    volatile unsigned int   GTEE    :  1; //!<     09: Global Time Error Interrupt Enable
    volatile unsigned int   TXUE    :  1; //!<     10: Tx Count Underflow Interrupt Enable
    volatile unsigned int   TXOE    :  1; //!<     11: Tx Count Overflow Interrupt Enable
    volatile unsigned int   SE1E    :  1; //!<     12: Scheduling Error 1 Interrupt Enable
    volatile unsigned int   SE2E    :  1; //!<     13: Scheduling Error 2 Interrupt Enable
    volatile unsigned int   ELCE    :  1; //!<     14: Error Level Changed Interrupt Enable
    volatile unsigned int   IWTE    :  1; //!<     15: Initialization Watch Trigger Interrupt Enable
    volatile unsigned int   WTE     :  1; //!<     16: Watch Trigger Interrupt Enable
    volatile unsigned int   AWE     :  1; //!<     17: Application Watchdog Interrupt Enable
    volatile unsigned int   CERE    :  1; //!<     18: Configuration Error Interrupt Enable
    volatile unsigned int   res0    : 13; //!< 31..19: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TTIE_union;


/* Type Definition for register TTILS - TT Interrupt Line Select */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   SBCL    :  1; //!<     00: Start of Basic Cycle Interrupt Line
    volatile unsigned int   SMCL    :  1; //!<     01: Start of Matrix Cycle Interrupt Line
    volatile unsigned int   CSML    :  1; //!<     02: Change of Synchronization Mode Interrupt Line
    volatile unsigned int   SOGL    :  1; //!<     03: Start of Gap Interrupt Line
    volatile unsigned int   RTMIL   :  1; //!<     04: Register Time Mark Interrupt Interrupt Line
    volatile unsigned int   TTMIL   :  1; //!<     05: Trigger Time Mark Interrupt Interrupt Line
    volatile unsigned int   SWEL    :  1; //!<     06: Stop Watch Event Interrupt Line
    volatile unsigned int   GTWL    :  1; //!<     07: Global Time Wrap Interrupt Line
    volatile unsigned int   GTDL    :  1; //!<     08: Global Time Discontinuity Interrupt Line
    volatile unsigned int   GTEL    :  1; //!<     09: Global Time Error Interrupt Line
    volatile unsigned int   TXUL    :  1; //!<     10: Tx Count Underflow Interrupt Line
    volatile unsigned int   TXOL    :  1; //!<     11: Tx Count Overflow Interrupt Line
    volatile unsigned int   SE1L    :  1; //!<     12: Scheduling Error 1 Interrupt Line
    volatile unsigned int   SE2L    :  1; //!<     13: Scheduling Error 2 Interrupt Line
    volatile unsigned int   ELCL    :  1; //!<     14: Error Level Changed Interrupt Line
    volatile unsigned int   IWTL    :  1; //!<     15: Initialization Watch Trigger Interrupt Line
    volatile unsigned int   WTL     :  1; //!<     16: Watch Trigger Interrupt Line
    volatile unsigned int   AWL     :  1; //!<     17: Application Watchdog Interrupt Line
    volatile unsigned int   CERL    :  1; //!<     18: Configuration Error Interrupt Line
    volatile unsigned int   res0    : 13; //!< 31..19: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TTILS_union;


/* Type Definition for register TTOST - TT Operation Status */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   EL      :  2; //!< 01..00: error level
    volatile unsigned int   MS      :  2; //!< 03..02: master state
    volatile unsigned int   SYS     :  2; //!< 05..04: synchronization state
    volatile unsigned int   QGTP    :  1; //!<     06: quality of global time phase
    volatile unsigned int   QCS     :  1; //!<     07: quality of clock speed
    volatile unsigned int   RTO     :  8; //!< 15..08: reference trigger offset
    volatile unsigned int   res0    :  6; //!< 21..16: reserved
    volatile unsigned int   WGTD    :  1; //!<     22: wait for global time discontinuity
    volatile unsigned int   GFI     :  1; //!<     23: gap finished indicator
    volatile unsigned int   TMP     :  3; //!< 26..24: time master priority
    volatile unsigned int   GSI     :  1; //!<     27: gap started indicator
    volatile unsigned int   WFE     :  1; //!<     28: wait for event
    volatile unsigned int   AWE     :  1; //!<     29: application watchdog event
    volatile unsigned int   WECS    :  1; //!<     30: wait for external clock synchronization
    volatile unsigned int   SPL     :  1; //!<     31: Schedule Phase Lock
  } bits;                                 //!< Bit representation
} M_CAN_TTOST_union;


/* Type Definition for register TURNA - TUR Numerator Actual */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   NAV     : 18; //!< 17..00: Numerator Actual Value
    volatile unsigned int   res0    : 14; //!< 31..18: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TURNA_union;



/* Type Definition for register TTLGT - TT Local & Global Time */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   LT      : 16; //!< 15..00: LT[15:0]: Local Time
    volatile unsigned int   GT      : 16; //!< 31..16: GT[15:0]: Global Time
  } bits;                                 //!< Bit representation
} M_CAN_TTLGT_union;


/* Type Definition for register TTCTC - TT Cycle Time & Count */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   CT      : 16; //!< 15..00: cycle time
    volatile unsigned int   CC      :  6; //!< 21..16: cycle count
    volatile unsigned int   res0    : 10; //!< 31..17: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TTCTC_union;


/* Type Definition for register TTCPT - TT Capture Time */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   CCV     :  6; //!< 05..00: Cycle Count Value
    volatile unsigned int   res0    : 10; //!< 15..06: reserved
    volatile unsigned int   SWV     : 16; //!< 31..16: Stop Watch Value
  } bits;                                 //!< Bit representation
} M_CAN_TTCPT_union;


/* Type Definition for register TTCSM - TT Cycle Sync Mark */
typedef union {
  volatile unsigned int value;            //!< Integer representation
  volatile struct {
    volatile unsigned int   CSM     : 16; //!< 15..00: Cycle Sync Mark
    volatile unsigned int   res0    : 16; //!< 31..16: reserved
  } bits;                                 //!< Bit representation
} M_CAN_TTCSM_union;




// === Type Definition for RAM ELEMENTSs =====================================

/* Type Definition for RAM Element - Standard Message ID Filter */
typedef union {
    volatile unsigned int value;            //!< Integer representation
    volatile struct {
      volatile unsigned int   SFID2   : 11; //!< 10..00: Standard Filter ID 2
      volatile unsigned int   res0    :  5; //!< 15..11: reserved
      volatile unsigned int   SFID1   : 11; //!< 26..16: Standard Filter ID 1
      volatile unsigned int   SFEC    :  3; //!< 29..27: Standard Filter Element Configuration
      volatile unsigned int   SFT     :  2; //!< 31..30: Standard Filter Type
  } bits;                                   //!< Bit representation
} M_CAN_STD_ID_FILT_ELEMENT_union;




/* Type Definition for RAM Element - Extended Message ID Filter Element - Word 1*/
typedef union {
    volatile unsigned int value;              //!< Integer representation
    volatile struct {
        volatile unsigned int   EFID1   : 29; //!< 28..00: Extended Filter ID 1
        volatile unsigned int   EFEC    :  3; //!< 31..29: Extended Filter Element Configuration
    } bits;                                   //!< Bit representation
} M_CAN_EXTENDED_ID_FILT_ELEMENT_WORD_1_union;


/* Type Definition for RAM Element - Extended Message ID Filter Element - Word 2*/
typedef union {
    volatile unsigned int value;              //!< Integer representation
    volatile struct {
        volatile unsigned int   EFID2   : 29; //!< 28..00: Extended Filter ID 2
        volatile unsigned int   res0    :  1; //!< 29    : reserved
        volatile unsigned int   EFT     :  2; //!< 31..30: Extended Filter Type
    } bits;                                   //!< Bit representation
} M_CAN_EXTENDED_ID_FILT_ELEMENT_WORD_2_union;




/* Rx Buffer and FIFO Element Word 1*/
// Word T0
#define RX_BUF_ESI          BIT(31)
#define RX_BUF_XTD          BIT(30)
#define RX_BUF_RTR          BIT(29)
#define RX_BUF_STDID_SHIFT  18
#define RX_BUF_STDID_MASK   (0x7FF << RX_BUF_STDID_SHIFT)
#define RX_BUF_EXTID_MASK   0x1FFFFFFF
// Word T1
#define RX_BUF_ANMF         BIT(31)
#define RX_BUF_FIDX_SHIFT   24
#define RX_BUF_FIDX_MASK    (0x7F << RX_BUF_FIDX_SHIFT)
#define RX_BUF_FDF          BIT(21)
#define RX_BUF_BRS          BIT(20)
#define RX_BUF_DLC_SHIFT    16
#define RX_BUF_DLC_MASK     (0xF << RX_BUF_DLC_SHIFT)
#define RX_BUF_RXTS_MASK    0xFFFF

/* Tx Buffer Element (in Msg. RAM) */
// Word T0
#define TX_BUF_ESI          BIT(31)    // Error State Indicator (is transmitted with this value)
#define TX_BUF_XTD          BIT(30)    // Extended Identifier (0= standard ID, 1= extended ID)
#define TX_BUF_RTR          BIT(29)    // Remote Transmission Request (0= transmit data frame, 1= transmitt remote frame)
#define TX_BUF_STDID_SHIFT  18
#define TX_BUF_STDID_MASK   (0x7FF << TX_BUF_STDID_SHIFT)
#define TX_BUF_EXTID_MASK   0x1FFFFFFF
// Word T1
#define TX_BUF_MM_SHIFT     24           // Message Marker
#define TX_BUF_MM_MASK      (0xFF << TX_BUF_MM_SHIFT)
#define TX_BUF_EFC          BIT(23)        // Event FIFO control (0= store TX events, 1= don't)
#define TX_BUF_FDF          BIT(21)
#define TX_BUF_BRS          BIT(20)
#define TX_BUF_DLC_SHIFT    16
#define TX_BUF_DLC_MASK     (0xF << TX_BUF_DLC_SHIFT)

// TX Event FIFO Element

/* Type Definition for RAM Element - TX Event FIFO Element - Word 1*/
typedef union {
    volatile unsigned int value;              //!< Integer representation
    volatile struct {
        volatile unsigned int   ID      : 29; //!< 28..00: Identifier
        volatile unsigned int   RTR     :  1; //!< 29    : Remote Transmission Request
        volatile unsigned int   XTD     :  1; //!< 30    : Extended Identifier
        volatile unsigned int   ESI     :  1; //!< 31    : Error State Indicator
    } bits;                                   //!< Bit representation
} M_CAN_TX_EVENT_FIFO_ELEMENT_WORD_1_union;


/* Type Definition for RAM Element - TX Event FIFO Element - Word 2*/
typedef union {
    volatile unsigned int value;              //!< Integer representation
    volatile struct {
        volatile unsigned int   TXTS   : 16; //!< 15..00: Tx Timestamp
        volatile unsigned int   DLC    :  4; //!< 19..16: Data Length Code
        volatile unsigned int   BRS    :  1; //!< 20    : Bit Rate Switch
        volatile unsigned int   FDF    :  1; //!< 21    : FD Format
        volatile unsigned int   ET     :  2; //!< 23..22: Event Type
        volatile unsigned int   MM     :  8; //!< 31..24: Message marker
    } bits;                                   //!< Bit representation
} M_CAN_TX_EVENT_FIFO_ELEMENT_WORD_2_union;





/* Tx Event FIFO Element (in Msg. RAM) */
// Word T0
#define TX_EVENT_FIFO_ESI           BIT(31)
#define TX_EVENT_FIFO_XTD           BIT(30)
#define TX_EVENT_FIFO_RTR           BIT(29)
#define TX_EVENT_FIFO_STDID_SHIFT   18
#define TX_EVENT_FIFO_STDID_MASK    (0x7FF << TX_EVENT_FIFO_STDID_SHIFT)
#define TX_EVENT_FIFO_EXTID_MASK    0x1FFFFFFF
// Word T1
#define TX_EVENT_FIFO_MM_SHIFT      24
#define TX_EVENT_FIFO_MM_MASK       (0xFF << TX_EVENT_FIFO_MM_SHIFT)
#define TX_EVENT_FIFO_ET_SHIFT      22
#define TX_EVENT_FIFO_ET_MASK       (0x3 << TX_EVENT_FIFO_ET_SHIFT)
#define TX_EVENT_FIFO_FDF           BIT(21)
#define TX_EVENT_FIFO_BRS           BIT(22)
#define TX_EVENT_FIFO_DLC_SHIFT     16
#define TX_EVENT_FIFO_DLC_MASK      (0xF << TX_EVENT_FIFO_DLC_SHIFT)
#define TX_EVENT_FIFO_TXTS_MASK     0xFF


/*  Base addresses in M_CAN Cluster
    - The VHDL implementation contains an address decoder with following mapping.
    - To derive the base addresses an offset has to be added to the avalon_base_address from SOPC-Builder.
    - The two topmost bits serve as select bits between the components.

    |<----  top address (byte addressing)  ---->|  |
     F   E    D C   B A 9 8   7 6 5 4   3 2 1 0    |
     s   s .. - -   x x x y   y y y y   y y b b    | top Address width byte(word):     14(12)   15(13)   16(14)
   | -   - .. - - | - - - - | - - - - | - - - - |  | -------------------------------   ------   ------   ------
Eg.  0   0    0 0   0 0 1                          | = Offset for M_CAN_1_BASE       = 0x00200  0x00200  0x00200
Eg.  0   1                                         | = Offset for CAN_IO_WIRING_BASE = 0x04000  0x08000  0x10000
Eg.  1   0                                         | = Offset for MESSAGE_RAM_BASE   = 0x08000  0x10000  0x20000
Eg.  1   1                                         | = Offset for CalibUnit_BASE     = 0x0C000  0x18000  0x30000 (Calib. Unit NOT AVAILABLE HERE)

   Description from VHDL address decoder:
    sel sel
   | ? | ? | .. | 9 : 7 | 6 : 0 | <= AVALON _WORD_ ADDRESS  (but NiosII/Microblaze software use byte addressing)
   | 0 | 0 |    |   x   |   y   | m_can "x", offset address "y"
   | 0 | 1 |    |       w       | can IO wiring module, offset address "w"
   | 1 | 0 |            z       | MRAM      at address "z"
   | 1 | 1 |                | c | CalibUnit at address "c" (Calib. Unit NOT AVAILABLE HERE)
*/


    // SET THESE VALUES BY USER - depending on your M_CAN-Component added to you SoPC
    #define M_CAN_CLUSTER_BASE 0x10F00000//BOSCH_AVALON_M_CAN_BASE  // redefine name of M_CAN Cluster: allows to use later non-vendor specific defines

    #define M_CAN_0_BASE        (M_CAN_CLUSTER_BASE)         // address bit_10='0'      => M_CAN_0
//  #define M_CAN_1_BASE        (M_CAN_CLUSTER_BASE + 0x200) // address bit_10='1'      => M_CAN_1

    #define ADDR_OFFSET_BETWEEN_TWO_M_CAN_MODULES (0x200)  // Addr. Offset from one M_CAN Module to the next
    #define CAN_IO_WIRING_OFFSET (0x8000)
    #define MESSAGE_RAM_OFFSET     (0x8000)
    //#define MESSAGE_RAM_SIZE_IN_WORDS (8192)
    #define MESSAGE_RAM_SIZE_IN_WORDS (4352)

    #define CAN_NUMBER_OF_PRESENT_NODES 1

    #define HOST_CLK_FREQ_HERTZ        XPAR_XPS_TIMER_32_0_CLOCK_FREQ_HZ
    #define CAN_CLK_FREQ_HERTZ         40000000  // m_can_cclk frequency, used to operate the M_CAN protocol controller

    //#define TIMER_TRIG_MSG_TX        0       // TO BE DEFINED



#define GLOBAL_NODE_ID_MASK           0xF    // used to add include global node id into msg_id (used by random message generator), has to be right aligned!
#define GLOBAL_NODE_ID_MASK_WIDTH     0x4    // width of the mask 0xF => 4, 0x1F => 5
#define GLOBAL_NODE_MAX_COUNT         (GLOBAL_NODE_ID_MASK + 1)  // max number of global nodes participating on bus



// M_CAN Message RAM - Basic Properties
#define MESSAGE_RAM_BASE                (M_CAN_CLUSTER_BASE + MESSAGE_RAM_OFFSET)
#define M_CAN_RAM_WORD_WIDTH_IN_BYTE  4
#define CONV_BYTE2WORD_ADDR(x)        ((x) >> 2)

// M_CAN Message RAM - Partitioning
// hint: Software requires byte addresses
#define RAM_WORDS_PER_M_CAN  4096
#define RAM_BYTES_PER_M_CAN  (RAM_WORDS_PER_M_CAN * M_CAN_RAM_WORD_WIDTH_IN_BYTE)

#define M_CAN_0_RAM_BASE     (MESSAGE_RAM_BASE + 0*RAM_BYTES_PER_M_CAN)
#define M_CAN_1_RAM_BASE     (MESSAGE_RAM_BASE + 1*RAM_BYTES_PER_M_CAN)
#define M_CAN_2_RAM_BASE     (MESSAGE_RAM_BASE + 2*RAM_BYTES_PER_M_CAN)
#define M_CAN_3_RAM_BASE     (MESSAGE_RAM_BASE + 3*RAM_BYTES_PER_M_CAN)

// Reserved number of elements in Message RAM - used for calculation of start addresses within RAM Configuration
//   some element_numbers set to less than max, to stay alltogether below 4096 words of MessageRAM requirement
#define MAX_11_BIT_FILTER_ELEMS 128   // maximum is 128 11-bit Filter
#define MAX_29_BIT_FILTER_ELEMS  64   // maximum is  64 29-bit Filter

#define MAX_RX_FIFO_0_ELEMS      64   // maximum is  64 Rx FIFO 0 elements
#define MAX_RX_FIFO_1_ELEMS      32   // maximum is  64 Rx FIFO 1 elements

#define MAX_RX_BUFFER_ELEMS      64   // maximum is  64 Rx Buffer
#define MAX_TX_EVENT_FIFO_ELEMS  32   // maximum is  32 Tx Event FIFO elements
#define MAX_TX_BUFFER_ELEMS      32   // maximum is  32 Tx Buffers

// element sizes when stored in message RAM
#define MAX_RX_BUF_ELEM_SIZE_WORD     18  // size of RX Buffer and FIFO Element
#define MAX_TX_BUF_ELEM_SIZE_WORD     18  // size of TX Buffer and FIFO Element
#define TX_EVENT_FIFO_ELEM_SIZE_WORD   2  // size of TX Event FIFO Element
#define STD_ID_FILTER_ELEM_SIZE_WORD   1  // Standard Message ID Filter Element
#define EXT_ID_FILTER_ELEM_SIZE_WORD   2  // Extended Message ID Filter Element

#define TX_BUF_ELEM_HEADER_WORD        2  // size of TX Buffer and FIFO Element, i.e. amount of words occupied before the payload
#define RX_BUF_ELEM_HEADER_WORD        2  // size of RX Buffer and FIFO Element, i.e. amount of words occupied before the payload


// relative Start Addresses (for all M_CAN Nodes valid) (in Byte)
#define REL_SIDFC_FLSSA           0
#define REL_XIDFC_FLESA          (REL_SIDFC_FLSSA + (MAX_11_BIT_FILTER_ELEMS * STD_ID_FILTER_ELEM_SIZE_WORD * M_CAN_RAM_WORD_WIDTH_IN_BYTE))
#define REL_RXF0C_F0SA           (REL_XIDFC_FLESA + (MAX_29_BIT_FILTER_ELEMS * EXT_ID_FILTER_ELEM_SIZE_WORD * M_CAN_RAM_WORD_WIDTH_IN_BYTE))
#define REL_RXF1C_F1SA           (REL_RXF0C_F0SA  + (MAX_RX_FIFO_0_ELEMS     * MAX_RX_BUF_ELEM_SIZE_WORD    * M_CAN_RAM_WORD_WIDTH_IN_BYTE))
#define REL_RXBC_RBSA            (REL_RXF1C_F1SA  + (MAX_RX_FIFO_1_ELEMS     * MAX_RX_BUF_ELEM_SIZE_WORD    * M_CAN_RAM_WORD_WIDTH_IN_BYTE))
#define REL_TXEFC_EFSA           (REL_RXBC_RBSA   + (MAX_RX_BUFFER_ELEMS     * MAX_RX_BUF_ELEM_SIZE_WORD    * M_CAN_RAM_WORD_WIDTH_IN_BYTE))
#define REL_TXBC_TBSA            (REL_TXEFC_EFSA  + (MAX_TX_EVENT_FIFO_ELEMS * TX_EVENT_FIFO_ELEM_SIZE_WORD * M_CAN_RAM_WORD_WIDTH_IN_BYTE))
#define REL_TXBC_END             (REL_TXBC_TBSA   + (MAX_TX_BUFFER_ELEMS     * MAX_TX_BUF_ELEM_SIZE_WORD    * M_CAN_RAM_WORD_WIDTH_IN_BYTE) - 1)




// Asserts
// Macro CAN_PRINT_ERROR displays an error message and terminates the program when an assertion condition is violated
#define CAN_PRINT_ERROR(condition, message) if(!(condition)) {DEBUGMSG_SDK(MSGERR, "[ASSERT] %s\n", message); }


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

/* ---------------------------------------------------
 * Functions
 * --------------------------------------------------- */

extern void ncDrv_CAN_Init(can_struct *can_ptr);

extern INT32 ncDrv_CAN_ConnectUserHandler(void);

extern INT32 ncDrv_CAN_DisConnectUserHandler(void);

extern void ncDrv_CAN_Bit_Timming_Setting(can_struct *can_ptr, eCAN_KBPS can_basic_speed, eCANFD_KBPS can_fd_speed);

//extern INT32 ncDrv_CAN_Send(can_struct *can_ptr, can_msg_struct *txmsg);

/* Print M_CAN version */
extern void ncDrv_CAN_print_version(can_struct *can);

/* Write to can register */
extern __inline void ncDrv_CAN_reg_set(can_struct *can, word reg, UINT32 val);

/* Read from can register */
extern __inline UINT32 ncDrv_CAN_reg_get(can_struct *can, word reg);

/* Add a value to a register (Read -> Add -> Write Back) */
extern void ncDrv_CAN_reg_add(can_struct *can, word reg_addr, word add_val);

/* Write to can register and check write by Readback */
extern boolean ncDrv_CAN_reg_set_and_check(can_struct *can, word reg, UINT32 val);

/* set the init bit in M_CAN instance */
extern void ncDrv_CAN_set_init (can_struct *can_ptr);

/* reset the init bit in M_CAN instance */
extern void ncDrv_CAN_reset_init (can_struct *can_ptr);

extern void ncDrv_CAN_set_loop_test_enable(can_struct *can_ptr);

extern void ncDrv_CAN_reset(void);

/* set configuration change enable for CAN instance */
extern void ncDrv_CAN_set_config_change_enable (can_struct *can_ptr);

/* reset configuration change enable for CAN instance (init not reset!) */
extern void ncDrv_CAN_reset_config_change_enable (can_struct *can_ptr);

/* reset configuration change enable for CAN instance */
extern void ncDrv_CAN_reset_config_change_enable_and_reset_init (can_struct *can_ptr);

/* Set Nominal Bit Timing of CAN instance (Arbitration Phase) */
extern boolean ncDrv_CAN_set_bit_timing_nominal (can_struct *can_ptr);

/* Set Data Bit Timing of CAN instance (Data Phase) */
extern boolean ncDrv_CAN_set_bit_timing_data (can_struct *can_ptr);

/* Set Nominal and Data Bit Timing and CAN mode (FD, Classic) */
extern void ncDrv_CAN_set_bit_timing(can_struct *can_ptr);

/* Initialize Interrupt Registers */
extern void ncDrv_CAN_interrupt_init(can_struct *can_ptr, UINT32 ir_line0_select, UINT32 ir_line1_select, UINT32 tx_buffer_transmission_ir_enable, UINT32 tx_buffer_cancel_finished_ir_enable);

/* Enable the CAN mode: classic, FD, FD with Bit Rate Switch */
extern void ncDrv_CAN_enable_CAN_mode (can_struct *can_ptr);

/* Convert DLC of the can frame into a payload length in byte */
extern int ncDrv_CAN_convert_DLC_to_data_length (word dlc);

/* Convert element_size (of an RX/TX Element in Message RAM) to payload/data_length in byte */
extern word ncDrv_CAN_convert_element_size_to_data_length (data_field_size_enum data_field_size);

/* Copy RX-Message from Message RAM to the Msg Data Structure given as Pointer */
extern void ncDrv_CAN_copy_msg_from_msg_ram(can_struct *can_ptr, UINT32 msg_addr_in_msg_ram, can_msg_struct *msg_ptr, rx_info_struct);

/* Copy TX-Message into Message RAM */
extern void ncDrv_CAN_write_msg_to_msg_ram(can_struct *can_ptr, UINT32 msg_addr_in_msg_ram, can_msg_struct *msg_ptr);

/* Configure the dedicated Rx Buffers */
extern void ncDrv_CAN_rx_dedicated_buffers_init(can_struct * can_ptr, data_field_size_enum dedicated_rx_buffer_data_field_size);

/* Initialize an RX FIFO in the M_CAN */
extern void ncDrv_CAN_rx_fifo_init(can_struct *can_ptr, int rx_fifo_number, int fifo_size_elems, int fifo_watermark, data_field_size_enum fifo_data_field_size);

/* Copy Message from Dedicated Rx buffer to the Software Message List */
extern void ncDrv_CAN_rx_dedicated_buffer_copy_msg_to_msg_list(can_struct *can_ptr, int ded_buffer_index);

/* Copy all Messages from from RX FIFO_i to the Software Message List */
extern unsigned int ncDrv_CAN_rx_fifo_copy_msg_to_msg_list(can_struct *can_ptr, int rx_fifo_number);

/* Configure Transmit-Buffer Section */
extern void ncDrv_CAN_tx_buffer_init(can_struct *can_ptr, boolean FIFO_true_QUEUE_false, unsigned int fifo_queue_size, unsigned int ded_buffers_number, data_field_size_enum data_field_size);

/* Get the number of Free Elements in TX FIFO */
extern word ncDrv_CAN_tx_fifo_get_num_of_free_elems(can_struct *can_ptr);

/* Check if a Transmit buffer has a pending TX Request */
extern boolean ncDrv_CAN_tx_is_tx_buffer_req_pending(can_struct *can_ptr, int tx_buff_index);

/* Copy Transmit Message to TX buffer - NO CHECK is performed if the buffer has already a pending tx request, NO Transmission is requested */
extern void ncDrv_CAN_tx_write_msg_to_tx_buffer(can_struct *can_ptr, can_msg_struct *tx_msg_ptr, int tx_buff_index);

/* Request Transmission of TX Message in TX buffer - NO CHECK is performed if the buffer has already a pending tx request */
extern void ncDrv_CAN_tx_msg_request_tx(can_struct *can_ptr, int tx_buff_index);

/* Copy Transmit Message to TX buffer and request Transmission */
extern void ncDrv_CAN_tx_write_msg_to_tx_buffer_and_request_tx(can_struct *can_ptr, can_msg_struct *tx_msg_ptr, int tx_buff_index);

/* Copy Transmit Message to dedicated TX buffer and request it - it CHECKs if buffer is free */
extern int ncDrv_CAN_tx_dedicated_msg_transmit(can_struct *can_ptr, can_msg_struct *tx_msg_ptr, int tx_buff_index);

/* Copy Transmit Message into FIFO/Queue and request transmission */
extern int ncDrv_CAN_tx_fifo_queue_msg_transmit(can_struct *can_ptr, can_msg_struct *tx_msg_ptr);

/* Cancel a Tx buffer transmission request */
extern void ncDrv_CAN_tx_buffer_request_cancelation(can_struct * can_ptr, int tx_buf_index);

/* Checks if a Tx buffer cancellation request has been finished or not */
extern boolean ncDrv_CAN_tx_buffer_is_cancelation_finshed(can_struct *can_ptr, int tx_buf_index);

/* Checks if a Tx buffer transmission has occurred or not */
extern boolean ncDrv_CAN_tx_buffer_transmission_occured(can_struct *can_ptr, int tx_buf_index);

/* Configures the Global Filter Settings (GFC Register) */
extern void ncDrv_CAN_global_filter_configuration(can_struct *can_ptr, GFC_accept_non_matching_frames_enum anfs, GFC_accept_non_matching_frames_enum anfe, boolean rrfs, boolean rrfe);

/* Configure standard ID filter usage (SIDFC) */
extern void ncDrv_CAN_filter_init_standard_id(can_struct *can_ptr, unsigned int number_of_filters);

/* Configure extended ID filter usage (XIDFC) */
extern void ncDrv_CAN_filter_init_extended_id(can_struct *can_ptr, unsigned int number_of_filters);

/* Write Standard Identifier Filter in Message RAM */
extern void ncDrv_CAN_filter_write_standard_id(can_struct *can_ptr, int filter_index, SFT_Standard_Filter_Type_enum sft, Filter_Configuration_enum sfec, int sfid1, int sfid2);

/* Write Extended Identifier Filter in Message RAM */
extern void ncDrv_CAN_filter_write_extended_id(can_struct *can_ptr, int filter_index, EFT_Extended_Filter_Type_enum eft, Filter_Configuration_enum efec, int efid1, int efid2);

/* Tx Event FIFO Configuration */
extern void ncDrv_CAN_tx_event_fifo_init(can_struct *can_ptr, int fifo_size_elems, int fifo_watermark);

/* Copy all Event Elements from TX Event FIFO to the Software Event List */
extern int ncDrv_CAN_tx_event_fifo_copy_element_to_tx_event_list(can_struct *can_ptr);

/* Copy a Tx Event FIFO Element from Message RAM to the Tx Event Element Data Structure given as Pointer */
extern void ncDrv_CAN_copy_tx_event_element_from_msg_ram(can_struct *can_ptr, UINT32 msg_addr_in_msg_ram, tx_event_element_struct *tx_event_element_ptr);

/* Configure Time Stamp Usage  AND  Time Out Usage */
extern void ncDrv_CAN_timestampcounter_and_timeoutcounter_init(can_struct *can_ptr, int ts_counter_prescaler, tscc_tss_timestamp_select_enum ts_select, tocc_tos_timeout_select_enum to_select, word to_period, boolean to_counter_enable);

/* Read Time Stamp Value */
extern UINT32 ncDrv_CAN_timestamp_read_value(can_struct *can_ptr);

/* Check correctness of Message RAM Partitioning */
extern void ncDrv_CAN_check_msg_ram_partitioning(void);

/* Init struct that contains Message RAM Partitioning for one CAN node */
extern void ncDrv_CAN_init_msg_ram_partitioning(can_struct *can_ptr);



/* ------------------------------------------------
 * Declaration of the test cases
 * ------------------------------------------------ */

// Function decodes (prints) verbosely the occurred M_CAN Interrupt
extern void m_can_ir_print(int m_can_id, int ir_value);

/* Check the M_CAN & M_TTCAN Register properties */
extern void m_can_register_test(can_struct *can_ptr, boolean reset_value_test_only);


/* Find M_CAN nodes with active IR */
extern void ncDrv_CAN_find_m_can_with_active_IR(void);

/* Handle IR of M_CAN Nodes */
extern void ncDrv_CAN_process_IR(can_struct *can_ptr, UINT32 ir_value);

/* Read new Messages from Dedicated RX Buffers */
extern unsigned int ncDrv_CAN_rx_dedicated_buffer_process_new_msg(can_struct *can_ptr);

/* Handle HighPriorityMessage Interrupt */
extern unsigned int ncDrv_CAN_hpm_ir_handling(can_struct *can_ptr);

/* enable/disable M_CAN nodes in global variable */
//extern void ncDrv_CAN_node_set_reset_ena_in_global_struct(const int used_can_nodes[], int used_can_nodes_number);

/* compare messages for equal contents */
extern boolean msg_compare(can_msg_struct *msg1_ptr, can_msg_struct *msg2_ptr);

/* Check, if there is any Pending TX Message in the given M_CAN Node */
extern boolean ncDrv_CAN_is_any_tx_msg_request_pending(can_struct *can_ptr);

/* Check, if there is any Pending TX Message in any M_CAN Node */
extern BOOL ncDrv_CAN_is_any_tx_msg_request_pending_in_any_m_can(void);

/* Check, if there is any RX Message in the RX FIFO_0 of the given M_CAN Node */
extern unsigned int ncDrv_CAN_is_msg_in_rx_fifo0(can_struct *can_ptr);

/* Check, if there is any RX Message in any M_CAN Node's RX FIFO_0 */
extern boolean ncDrv_CAN_is_msg_in_rx_fifo0_of_any_m_can(void);


/* Message List ################################################# */

/* Reset the RX MSG List */
void ncDrv_CAN_rx_msg_list_reset(void);

/* Copy Message from Message RAM to Message List */
void ncDrv_CAN_copy_msg_from_msg_ram_to_msg_list(can_struct *can_ptr, UINT32 msg_addr_in_msg_ram, rx_info_struct);

/* Get Head Message from Message List */
can_msg_struct * ncDrv_CAN_msg_list_get_head_msg(can_struct *can_ptr);

/* Remove Head Message from Message List */
void ncDrv_CAN_msg_list_remove_head_msg(can_struct *can_ptr);

/* Get Next Free Element Pointer of Message List */
can_msg_struct * ncDrv_CAN_msg_list_get_next_free_element(can_struct *can_ptr);

/* Add Message to Tail of Message List */
void ncDrv_CAN_msg_list_add_msg_at_tail(can_struct *can_ptr);

/* Check, if Message List is EMPTY */
boolean ncDrv_CAN_msg_list_is_empty(can_struct *can_ptr);

/* Check, if Message List is FULL */
boolean ncDrv_CAN_msg_list_is_full(can_struct *can_ptr);

/* Check, if there is any RX Message List in any of the Message Lists */
boolean ncDrv_CAN_is_any_msg_in_any_rx_msg_list(void);



/* Tx Event List ################################################# */

/* Reset the Tx Event FIFO list */
extern void ncDrv_CAN_tx_event_list_reset(void);

/* Copy a Tx Event FIFO element from Message RAM to TX Event List */
extern void ncDrv_CAN_copy_event_element_from_msg_ram_to_tx_event_list(can_struct *can_ptr, UINT32 tx_event_element_addr_in_msg_ram);

/* Get Head element from Tx Event List */
extern tx_event_element_struct * ncDrv_CAN_tx_event_list_get_head_element(can_struct *can_ptr);

/* Remove Head element from Tx Event List */
extern void ncDrv_CAN_tx_event_list_remove_head_element(can_struct *can_ptr);

/* Get Next Free Element Pointer of Tx Event List */
extern tx_event_element_struct * ncDrv_CAN_tx_event_list_get_next_free_element(can_struct *can_ptr);

/* Add Element to Tail of Tx Event List */
extern void ncDrv_CAN_tx_event_list_add_element_at_tail(can_struct *can_ptr);

/* Check, if Tx Event List is EMPTY */
extern boolean ncDrv_CAN_tx_event_list_is_empty(can_struct *can_ptr);

/* Check, if Tx Event List is FULL */
extern boolean ncDrv_CAN_tx_event_list_is_full(can_struct *can_ptr);


/* Message Generation ################################### */

/* Generate a TX Message - used for m_can_test_simple() */
extern can_msg_struct * m_can_test_simple_generate_tx_message(void);

/* Statistics ########################################### */

/* Update Message Statistics */
extern  void ncDrv_CAN_update_msg_statistics_at_mram_access(can_struct *can_ptr, can_msg_struct *msg_ptr);

/* Print Statistics */
extern void print_statistics(can_struct *can_ptr);

/* Reset Statistics */
//extern void reset_statistic(void);

/* Check the consistency of the Statistics */
extern void check_statistic_consistency_single_board_test(const int used_can_nodes[], int used_can_nodes_number);

/* Check the statistics for recorded error events */
//extern void check_statistic_for_detected_errors(const int used_can_nodes[], int used_can_nodes_number);

/* Misc ################################################# */

/* Print Message */
extern void print_msg(can_msg_struct *msg_ptr);

/* prints the content of one Tx Event Element */
extern void print_tx_event_fifo_element(tx_event_element_struct *tx_event_element_ptr);

/* Print relative Message RAM Start-Addresses */
//extern void print_mram_startaddresses(void);


#endif  /* __CAN_DRV_H__ */


/* End Of File */

