/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : INTC_Lib.c
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "INTC_Drv.h"
#include "GICv2.h"










/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/

BOOL gbIntcOpen = FALSE;










/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncLib_INTC_Open(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbIntcOpen == FALSE)
    {
        gbIntcOpen = TRUE;

        ncDrv_INTC_InitIntHandler();
        ncDrv_INTC_Initialize();
    }
    else
    {
        //DEBUGMSG_SDK(MSGERR, "Error, GIC %s\n", LOG_ERR_OPEN);

        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_INTC_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbIntcOpen == TRUE)
    {
        ncDrv_INTC_InitIntHandler();
        ncDrv_INTC_Deinitialize();

        gbIntcOpen = FALSE;
    }
    else
    {
        //DEBUGMSG_SDK(MSGERR, "Error, GIC %s\n", LOG_ERR_CLOSE);

        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_INTC_Read(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_INTC_Write(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_INTC_Control(eINTC_CMD Cmd, ...)
{
    UINT32   count;
    UINT32   argData[CMD_MAX];
    eINT_NUM nIntNum;
    va_list  vlist;
    BOOL     bEndCmd = FALSE;
    INT32    ret = NC_SUCCESS;

    if(gbIntcOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vlist, Cmd);

        for(count = 0; count < CMD_MAX; count++)
        {
            argData[count] = va_arg(vlist, UINT32);

            if(argData[count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vlist);

        if(bEndCmd == FALSE)
        {
            ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

            nIntNum = (eINT_NUM)argData[0];

            switch(Cmd)
            {
                case GCMD_INTC_REGISTER_INT:
                    ncDrv_INTC_RegisterHandler(nIntNum, (PrHandler)argData[1]);
                    ncDrv_GIC_EnableIrq(nIntNum);
                break;

                case GCMD_INTC_UNREGISTER_INT:
                    ncDrv_INTC_UnRegisterHandler(nIntNum);
                    ncDrv_GIC_DisableIrq(nIntNum);
                break;
                
                case GCMD_INTC_SGI_TRIGGER:
                    ncDrv_GIC_SetSGITrigger(nIntNum);
                break;
#if 0
                case GCMD_INTC_SET_TRIG_MODE:
                    if(argData[1] == TRIG_LEVEL_HIGH || argData[1] == TRIG_LEVEL_LOW)
                    {
                        ncDrv_GIC_SetIntTrigType(nIntNum, GIT_N_N_LEVEL);
                    }
                    else
                    {
                        ncDrv_GIC_SetIntTrigType(nIntNum, GIT_1_N_EDGE);
                    }
                break;

                case GCMD_INTC_SET_PRIORITY_LEVEL:
                    ncDrv_GIC_SetPriorityLevel(nIntNum, (argData[1] & 0xFF));
                break;
#endif

                case GCMD_INTC_ENABLE_INT:
                    ncDrv_GIC_EnableIrq(nIntNum);
                break;

                case GCMD_INTC_DISABLE_INT:
                    ncDrv_GIC_DisableIrq(nIntNum);
                break;

                case GCMD_INTC_GET_GICID:
                {
                    ncDrv_GIC_GetInformation((tGIC_ID *)argData[0]);
                }
                break;

                default :
                    ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


void ncLib_INTC_IrqHandler(void)
{
    ncDrv_INTC_IrqHandler();
}


void ncLib_INTC_FiqHandler(void)
{
    ncDrv_INTC_FiqHandler();
}


/* End Of File */

