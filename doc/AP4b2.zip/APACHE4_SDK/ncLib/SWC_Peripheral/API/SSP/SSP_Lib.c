/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "SSP_Drv.h"










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    BOOL       mSSP_ChInit;
    eSSP_MODE  mSSP_Mode;
    eSSP_DS    mSSP_DataWidth;
} tSSP_INFO, *ptSSP_INFO;

typedef struct
{
    tPAD_INFO CS0;
    tPAD_INFO CS1;
    tPAD_INFO DQ0;
    tPAD_INFO DQ1;          
    tPAD_INFO SCK;    
} tSPI_PAD, *ptSPI_PAD;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbSSPOpen = FALSE;

tSSP_INFO gtSSP[MAX_OF_SSP_CH];

tSPI_PAD gtSSP_PAD[MAX_OF_PWM_CH] = 
{
    {   // SPI-0
        {PAD_SPI2_CSN0, {PAD_FUNC_4, PAD_FUNC_MAX}},    // CSN - Only GPIO Ctrl
        {PAD_SPI2_CSN1, {PAD_FUNC_4, PAD_FUNC_MAX}},    // CSN - Only GPIO Ctrl
        {PAD_SPI2_DQ0,  {PAD_FUNC_2, PAD_FUNC_MAX}},
        {PAD_SPI2_DQ1,  {PAD_FUNC_2, PAD_FUNC_MAX}},
        {PAD_SPI2_SCK,  {PAD_FUNC_2, PAD_FUNC_MAX}},
    },
    {   // SPI-1
        {PAD_SPI2_CSN0, {PAD_FUNC_4, PAD_FUNC_MAX}},
        {PAD_SPI2_CSN1, {PAD_FUNC_4, PAD_FUNC_MAX}},
        {PAD_SPI2_DQ2,  {PAD_FUNC_3, PAD_FUNC_MAX}},
        {PAD_SPI2_DQ3,  {PAD_FUNC_3, PAD_FUNC_MAX}},
        {PAD_SEN_RST_N, {PAD_FUNC_1, PAD_FUNC_MAX}},
    },
};










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __ssp_get_padctrl(ptPAD_INFO Pad)
{
    if(Pad->mFunc[0] != PAD_NOT_USED)
    {
        if(Pad->mFunc[1] == PAD_FUNC_MAX)
            Pad->mFunc[1] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, Pad->mId, CMD_END);
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, Pad->mId, Pad->mFunc[0], CMD_END);
    }
}


static void __ssp_free_padctrl(ptPAD_INFO Pad)
{
    if(Pad->mFunc[0] != PAD_NOT_USED)
    {
        if(Pad->mFunc[1] != PAD_FUNC_MAX)
        {
            ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, Pad->mId, Pad->mFunc[1], CMD_END);
            Pad->mFunc[1] = PAD_FUNC_MAX;
        }
    }
}


static void ncLib_SSP_PinMuxCtrlGet(eSSP_CH Ch)
{      
    if(Ch < MAX_OF_SSP_CH)
    { 
        __ssp_get_padctrl(&(gtSSP_PAD[Ch].CS0));
        __ssp_get_padctrl(&(gtSSP_PAD[Ch].CS1));
        __ssp_get_padctrl(&(gtSSP_PAD[Ch].DQ0));
        __ssp_get_padctrl(&(gtSSP_PAD[Ch].DQ1));
        __ssp_get_padctrl(&(gtSSP_PAD[Ch].SCK));
        

        //------------------------------------------------------------------------------------------------------
        // Set PinMux
        // CS0              : Only GPIO Ctrl
        ncLib_GPIO_Control(GCMD_GPIO_SET_DIR,  GPIO_GROUP_PAD, gtSSP_PAD[Ch].CS0.mId, GPIO_DIR_OUT, CMD_END);
        ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_PAD, gtSSP_PAD[Ch].CS0.mId, GPIO_HIGH, CMD_END);

        // CS1              : Only GPIO Ctrl
        if(gtSSP_PAD[Ch].CS1.mFunc[0] != PAD_NOT_USED)
        {
            ncLib_GPIO_Control(GCMD_GPIO_SET_DIR,  GPIO_GROUP_PAD, gtSSP_PAD[Ch].CS1.mId, GPIO_DIR_OUT, CMD_END);
            ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_PAD, gtSSP_PAD[Ch].CS1.mId, GPIO_HIGH, CMD_END);
        }
    }
}


void ncLib_SSP_PinMuxCtrlFree(eSSP_CH Ch)
{
    if(Ch < MAX_OF_SSP_CH)
    {
        __ssp_free_padctrl(&(gtSSP_PAD[Ch].CS0));
        __ssp_free_padctrl(&(gtSSP_PAD[Ch].CS1));
        __ssp_free_padctrl(&(gtSSP_PAD[Ch].DQ0));
        __ssp_free_padctrl(&(gtSSP_PAD[Ch].DQ1));
        __ssp_free_padctrl(&(gtSSP_PAD[Ch].SCK));
    }
}


static INT32 ncLib_SSP_InfoInit(eSSP_CH Ch, ptSSP_PARAM ptSSPParam)
{
    INT32 Ret = NC_FAILURE;
    
    if(ptSSPParam != NULL)
    {
        gtSSP[Ch].mSSP_ChInit    = ON;
        gtSSP[Ch].mSSP_Mode      = ptSSPParam->mMode;
        gtSSP[Ch].mSSP_DataWidth = ptSSPParam->mDataWidth;

        // Set PIN MUX
        ncLib_SSP_PinMuxCtrlGet(Ch);
        
        Ret = NC_SUCCESS;
    }

    return Ret;
}


static void ncLib_SSP_InfoDeInit(eSSP_CH Ch)
{
    gtSSP[Ch].mSSP_ChInit  = OFF;

    // Free PIN MUX
    ncLib_SSP_PinMuxCtrlFree(Ch);   
}


static INT32 ncLib_SSP_IsNotAliveCh(void)
{
    INT32 Ret = NC_SUCCESS;
    eSSP_CH Ch;
    
    for(Ch=SSP_CH0; Ch<MAX_OF_SSP_CH; Ch++)
    {
        if(gtSSP[Ch].mSSP_ChInit == ON)
            Ret = NC_FAILURE;
    }

    return Ret;
}


static void ncLib_SSP_CS_High(eSSP_CH Ch)
{
    if( 0 ) // if((ncLib_SCU_Control(GCMD_SCU_GET_STRAP_INFO, CMD_END) >> 2) & 0x01)
    {
        if(gtSSP_PAD[Ch].CS1.mFunc[0] != PAD_NOT_USED)
            ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_PAD, gtSSP_PAD[Ch].CS1.mId, GPIO_HIGH, CMD_END);
    }
    else
    {
        ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_PAD, gtSSP_PAD[Ch].CS0.mId, GPIO_HIGH, CMD_END);
    }
}


static void ncLib_SSP_CS_Low(eSSP_CH Ch)
{
    if( 0 ) // if((ncLib_SCU_Control(GCMD_SCU_GET_STRAP_INFO, CMD_END) >> 2) & 0x01)
    {
        if(gtSSP_PAD[Ch].CS1.mFunc[0] != PAD_NOT_USED)
            ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_PAD, gtSSP_PAD[Ch].CS1.mId, GPIO_LOW, CMD_END);
    }
    else
    {
        ncLib_GPIO_Control(GCMD_GPIO_SET_DATA, GPIO_GROUP_PAD, gtSSP_PAD[Ch].CS0.mId, GPIO_LOW, CMD_END);
    }
}


INT32 ncLib_SSP_Open(void)
{
    INT32 Ret = NC_SUCCESS;
    eSSP_CH Ch;
    
    if(gbSSPOpen == FALSE)
    {
        ncLib_SCU_Control(GCMD_SCU_ENA_CLK, SCU_CLK_ID_SSPI, CMD_END);  

        for(Ch=SSP_CH0; Ch<MAX_OF_SSP_CH; Ch++)
        {
            ncDrv_SSP_DeInit(Ch);
            ncLib_SSP_InfoDeInit(Ch); 
        }
        
        gbSSPOpen = TRUE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_SSP_Close(void)
{
    INT32 Ret;
    eSSP_CH Ch;
    
    Ret = ncLib_SSP_IsNotAliveCh();
    if(Ret == NC_SUCCESS)
    {
        for(Ch=SSP_CH0; Ch<MAX_OF_SSP_CH; Ch++)
        {
            ncDrv_SSP_DeInit(Ch);
            ncLib_SSP_InfoDeInit(Ch);
        }

        ncLib_SCU_Control(GCMD_SCU_DIS_CLK, SCU_CLK_ID_SSPI, CMD_END);  
        gbSSPOpen = FALSE;
    }

    return Ret;
}


INT32 ncLib_SSP_Read(eSSP_CH Ch, UINT8 *pBuf, UINT32 Length)
{
    INT32 Ret = NC_FAILURE;

    if((gbSSPOpen == TRUE) && (Ch < MAX_OF_SSP_CH) && (gtSSP[Ch].mSSP_ChInit == ON))
    {
        if(gtSSP[Ch].mSSP_Mode == SSP_MODE_MASTER)
            Ret = ncDrv_SSP_mRead(Ch, pBuf, Length, gtSSP[Ch].mSSP_DataWidth);
        else
            Ret = ncDrv_SSP_sRead(Ch, pBuf, Length, gtSSP[Ch].mSSP_DataWidth);
    }       

    return Ret;
}


INT32 ncLib_SSP_Write(eSSP_CH Ch, UINT8 *pBuf, UINT32 Length)
{
    INT32 Ret = NC_FAILURE;
    
    if((gbSSPOpen == TRUE) && (Ch < MAX_OF_SSP_CH) && (gtSSP[Ch].mSSP_ChInit == ON))
    {
        if(gtSSP[Ch].mSSP_Mode == SSP_MODE_MASTER)
            Ret = ncDrv_SSP_mWrite(Ch, pBuf, Length, gtSSP[Ch].mSSP_DataWidth);
        else
            Ret = ncDrv_SSP_sWrite(Ch, pBuf, Length, gtSSP[Ch].mSSP_DataWidth);
    }

    return Ret;
}


INT32 ncLib_SSP_Control(eSSP_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    eSSP_CH Ch;


    if(gbSSPOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, SSP no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Defence Code
            */

            Ch = (eSSP_CH)ArgData[0];
            if(Ch >= MAX_OF_SSP_CH)
                Cmd = GCMD_SSP_MAX;
            if(   (Ch >= MAX_OF_SSP_CH) 
               || ((Cmd != GCMD_SSP_INIT_CH) && (gtSSP[Ch].mSSP_ChInit == OFF)) )
            {
                Cmd = GCMD_SSP_MAX;
            }
            
            /*
            * Implement Control Command Function
            */
                
            switch(Cmd)
            {
                case GCMD_SSP_INIT_CH:
                {
                    Ret = ncLib_SSP_InfoInit(Ch, (ptSSP_PARAM)ArgData[1]);
                    if(Ret == NC_SUCCESS)
                    {
                        ncDrv_SSP_Init(Ch, (ptSSP_PARAM)ArgData[1], ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_SSPI, CMD_END));
                        ncLib_SSP_CS_High(Ch);
                    }
                }
                break;


                case GCMD_SSP_DEINIT_CH:
                {
                    ncDrv_SSP_DeInit(Ch);
                    ncLib_SSP_InfoDeInit(Ch);
                }
                break;


                case GCMD_SSP_CS_ENABLE_CH:
                {
                    ncDrv_SSP_WaitBusIsBusy(Ch, "CS_On");
                    ncLib_SSP_CS_Low(Ch);
                }
                break;


                case GCMD_SSP_CS_DISABLE_CH:
                {
                    ncDrv_SSP_WaitBusIsBusy(Ch, "CS_Off");
                    ncLib_SSP_CS_High(Ch);
                }
                break;


                case GCMD_SSP_SET_BITRATE_CH:
                {
                    ncDrv_SSP_SetBitRate(Ch, (UINT32)ArgData[1], ncLib_SCU_Control(GCMD_SCU_GET_CLK, SCU_CLK_ID_SSPI, CMD_END));
                }
                break;


                case GCMD_SSP_SET_DMA_MODE:
                {
                    ncDrv_SSP_SetDMAMode(Ch, (UINT8)ArgData[1]);
                }
                break;

                     
                case GCMD_SSP_GET_INT_STS:
                {
                    Ret = ncDrv_SSP_GetIntSts(Ch, gtSSP[Ch].mSSP_Mode);
                }
                break;  

                
                case SCMD_SSP_PAD_CTRL_GET:
                {
                    ncLib_SSP_PinMuxCtrlGet(Ch);
                }
                break;


                case SCMD_SSP_PAD_CTRL_FREE:
                {
                    ncLib_SSP_PinMuxCtrlFree(Ch);
                }
                break;  

                
                case GCMD_SSP_MAX:
                {
                    Ret = NC_FAILURE;
                }
                break;    

        
                default :
                {
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support SSP command\n");
                    Ret = NC_FAILURE;
                }
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


/* End Of File */

