/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "SDC_Drv.h"










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbSDCOpen = FALSE;










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    tPAD_INFO CLK;
    tPAD_INFO CMD;
    
    tPAD_INFO DQ0;
    tPAD_INFO DQ1;          
    tPAD_INFO DQ2;
    tPAD_INFO DQ3;

    tPAD_INFO WP;
    tPAD_INFO CD;
} tSDC_PAD, *ptSDC_PAD;










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

tSDC_PAD gtSDC_PAD = 
{
    {PAD_SEN_RST_N,     {PAD_FUNC_3, PAD_FUNC_MAX}},    // CLK
    {PAD_UART2_RX,      {PAD_FUNC_3, PAD_FUNC_MAX}},    // CMD
    
    {PAD_SEN_PD12,      {PAD_FUNC_3, PAD_FUNC_MAX}},    // DQ0
    {PAD_SEN_PD13,      {PAD_FUNC_3, PAD_FUNC_MAX}},    // DQ1
    {PAD_SEN_PD14,      {PAD_FUNC_3, PAD_FUNC_MAX}},    // DQ2
    {PAD_SEN_PD15,      {PAD_FUNC_3, PAD_FUNC_MAX}},    // DQ3

    {PAD_CAN_RX,        {PAD_FUNC_3, PAD_FUNC_MAX}},    // WP
    {PAD_CAN_TX,        {PAD_FUNC_3, PAD_FUNC_MAX}},    // CD    
};










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static void __sdc_get_padctrl(ptPAD_INFO Pad)
{
    if(Pad->mFunc[1] == PAD_FUNC_MAX)
        Pad->mFunc[1] = (ePAD_FUNC)ncLib_SCU_Control(GCMD_SCU_GET_PINMUX, Pad->mId, CMD_END);
    ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, Pad->mId, Pad->mFunc[0], CMD_END);
}


static void __sdc_free_padctrl(ptPAD_INFO Pad)
{
    if(Pad->mFunc[1] != PAD_FUNC_MAX)
    {
        ncLib_SCU_Control(GCMD_SCU_SET_PINMUX, Pad->mId, Pad->mFunc[1], CMD_END);
        Pad->mFunc[1] = PAD_FUNC_MAX;
    }
}


static void ncLib_SDC_PinMuxCtrlGet(void)
{
    __sdc_get_padctrl(&gtSDC_PAD.CLK);
    __sdc_get_padctrl(&gtSDC_PAD.CMD);
    __sdc_get_padctrl(&gtSDC_PAD.DQ0);    
    __sdc_get_padctrl(&gtSDC_PAD.DQ1);
    __sdc_get_padctrl(&gtSDC_PAD.DQ2);
    __sdc_get_padctrl(&gtSDC_PAD.DQ3);
    __sdc_get_padctrl(&gtSDC_PAD.WP);
    __sdc_get_padctrl(&gtSDC_PAD.CD);
}


static void ncLib_SDC_PinMuxCtrlFree(void)
{
    __sdc_free_padctrl(&gtSDC_PAD.CLK);
    __sdc_free_padctrl(&gtSDC_PAD.CMD);
    __sdc_free_padctrl(&gtSDC_PAD.DQ0);    
    __sdc_free_padctrl(&gtSDC_PAD.DQ1);
    __sdc_free_padctrl(&gtSDC_PAD.DQ2);
    __sdc_free_padctrl(&gtSDC_PAD.DQ3);
    __sdc_free_padctrl(&gtSDC_PAD.WP);
    __sdc_free_padctrl(&gtSDC_PAD.CD);
}


INT32 ncLib_SDC_Open(void)
{
    INT32 ret = NC_SUCCESS;
    
    if(gbSDCOpen == FALSE)
    {
        ncLib_SCU_Control(GCMD_SCU_ENA_CLK, SCU_CLK_ID_SDC, CMD_END); 
        
        ncLib_SDC_PinMuxCtrlGet();
        gbSDCOpen = TRUE;
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_SDC_Close(void)
{
    INT32 ret = NC_SUCCESS;

    if(gbSDCOpen == TRUE)
    {
        ncLib_SDC_PinMuxCtrlFree();
        gbSDCOpen = FALSE;
    }
    else
    {
        ret = NC_FAILURE;
    }

    return ret;
}


INT32 ncLib_SDC_Read(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_SDC_Write(void)
{
    INT32 ret = NC_SUCCESS;

    return ret;
}


INT32 ncLib_SDC_Control(eSDC_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    

    if(gbSDCOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, SDC no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */
            switch(Cmd)
            {
                case GCMD_SDC_INIT:
                {

                }
                break;

                case GCMD_SDC_DEINIT:
                {

                }
                break;

                default :
                {
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support SDC command\n");
                    Ret = NC_FAILURE;
                }
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


/* End Of File */

