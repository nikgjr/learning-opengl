/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   : 
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "VDUMP_Drv.h"










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbVDPOpen = FALSE;
tVDP_INFO gtVDP;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static INT32 ncLib_VDP_InfoInit(ptVDP_PARAM ptVDPParam)
{
    INT32 Ret = NC_FAILURE;
    eVDP_CH Ch;
    
    if(ptVDPParam != NULL)
    {
        // Lib Init Check Flag
        gtVDP.mInit   = ON;

        // ISR On/Off Flag
        gtVDP.mIntEn  = ptVDPParam->mIntEn;

        // Interrupt Enable and Status Flag
        gtVDP.mIntSts   = 0;
        gtVDP.mDoneFlag = 0;

        // Channel Enable Flag
        gtVDP.mFrameSel = ptVDPParam->mFrameEdge;
        for(Ch = VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++)
            gtVDP.mChEn[Ch] = ptVDPParam->mDumpCh[Ch].mChEnable;
            
        Ret = NC_SUCCESS;
    }

    return Ret;
}


static void ncLib_VDP_InfoDeInit(void)
{
    gtVDP.mInit = OFF;
}


INT32 ncLib_VDP_Open(void)
{
    INT32 Ret = NC_SUCCESS;

    if(gbVDPOpen == FALSE)
    {
        ncLib_SCU_Control(GCMD_SCU_ENA_CLK, SCU_CLK_ID_VDUMP, CMD_END);  
        ncLib_SCU_Control(GCMD_SCU_SET_RST, SCU_CLK_ID_VDUMP, CMD_END); 
        gbVDPOpen = TRUE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_VDP_Close(void)
{
    INT32 Ret = NC_SUCCESS;

    if(gbVDPOpen == TRUE)
    {
        ncLib_SCU_Control(GCMD_SCU_DIS_CLK, SCU_CLK_ID_VDUMP, CMD_END);  
        
        gbVDPOpen = FALSE;
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncLib_VDP_Read(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_VDP_Write(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_VDP_Control(eVDP_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;
    
    if(gbVDPOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Defence Code
            */
            
            if( ((Cmd != GCMD_VDP_INIT) && (gtVDP.mInit == OFF)) )
            {
                Cmd = GCMD_VDP_MAX; 
            }

            
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case GCMD_VDP_INIT:
                {
                    Ret = ncLib_VDP_InfoInit((ptVDP_PARAM)ArgData[0]);
                    if(Ret == NC_SUCCESS)
                    {
                        ncDrv_VDP_Initialize();
                        ncDrv_VDP_SetOperation(&gtVDP, (ptVDP_PARAM)ArgData[0]);
                    }
                }
                break;

                case GCMD_VDP_DEINIT:
                {
                    ncLib_VDP_InfoDeInit();
                    ncDrv_VDP_DeInitialize(); 
                }
                break;

                case GCMD_VDP_UPDATE_OP:
                {
                    Ret = ncLib_VDP_InfoInit((ptVDP_PARAM)ArgData[0]);
                    if(Ret == NC_SUCCESS)
                        ncDrv_VDP_SetOperation(&gtVDP, (ptVDP_PARAM)ArgData[0]);
                }
                break;

                case GCMD_VDP_START:
                {
                     Ret = ncDrv_VDP_Start(&gtVDP);
                }
                break;

                case GCMD_VDP_STOP:
                {
                     ncDrv_VDP_Stop();
                }
                break;

                case GCMD_VDP_DONE:
                {
                    Ret = ncDrv_VDP_CheckComplete(&gtVDP);
                }
                break;
                
                case GCMD_VDP_INT_CLEAR:
                {
                    Ret = ncDrv_VDP_IntStsClr(&gtVDP);
                }
                break;

                case GCMD_VDP_GET_STS:
                {
                    Ret = ncDrv_VDP_GetStatus(&gtVDP);
                }
                break;

                case GCMD_VDP_GET_INPUT_SIZE:
                {
                    *(UINT32*)ArgData[0] = (UINT32)gtVDP.mInHACT;
                    *(UINT32*)ArgData[1] = (UINT32)gtVDP.mInVACT;
                }
                break;
                
                case GCMD_VDP_GET_OUTPUT_SIZE:
                {
                    ncDrv_VDP_GetOutPutSize((UINT32*)ArgData[0], (UINT32*)ArgData[1]);
                }
                break;
                
                case GCMD_VDP_GET_DUMP_SIZE:
                {
                    Ret = ncDrv_VDP_GetOutPutDumpSize((eVDP_CH)ArgData[0]);
                }
                break;

                case GCMD_VDP_GET_CROP_CNT:
                {
                    ncDrv_VDP_GetCropCnt((UINT32*)ArgData[0], (UINT32*)ArgData[1]);
                }
                break;

                case GCMD_VDP_GET_SCAL_CNT:
                {
                    ncDrv_VDP_GetScalCnt((UINT32*)ArgData[0], (UINT32*)ArgData[1]);
                }
                break;

                case GCMD_VDP_GET_FRM_STS:
                {
                    Ret = ncDrv_VDP_GetOneFrameStatus((eVDP_CH)ArgData[0]);
                }
                break;

                case GCMD_VDP_GET_LINE_CNT:
                {
                    Ret = ncDrv_VDP_GetLineCnt((eVDP_CH)ArgData[0]);
                }
                break;

                case GCMD_VDP_GET_PIXEL_CNT:
                {
                    Ret = ncDrv_VDP_GetPixelCnt((eVDP_CH)ArgData[0]);
                }
                break;

                case GCMD_VDP_CHK_ERROR:
                {
                    Ret = ncDrv_VDP_GetOneFrameErrorStatus((eVDP_CH)ArgData[0]);
                }
                break;
                
                default :
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support VDUMP command\n");
                    Ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


/* End Of File */

