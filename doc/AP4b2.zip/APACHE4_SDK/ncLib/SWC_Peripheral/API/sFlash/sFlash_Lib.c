/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "sFlash_Svc.h"










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbSFOpen = FALSE;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

INT32 ncLib_SF_Open(void)
{
    INT32 Ret = NC_SUCCESS;

    gbSFOpen = TRUE;

    return Ret;
}


INT32 ncLib_SF_Close(void)
{
    INT32 Ret = NC_SUCCESS;

    gbSFOpen = FALSE;

    return Ret;
}


INT32 ncLib_SF_Read(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    INT32 Ret = NC_SUCCESS;

    Ret = ncSvc_SF_ReadData(Addr, pData, Size);
    
    return Ret;
}


INT32 ncLib_SF_Write(UINT32 Addr, UINT8 *pData, UINT32 Size)
{
    INT32 Ret = NC_SUCCESS;

    Ret = ncSvc_SF_WriteData(Addr, pData, Size);

    return Ret;
}


INT32 ncLib_SF_Control(eSF_CMD Cmd, ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;


    if(gbSFOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            DEBUGMSG_SDK(MSGERR, "Error, SF no CMD_END!\n");
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */
            switch(Cmd)
            {
                case GCMD_SF_INIT:
                    Ret = ncSvc_SF_Init((ptSF_PARAM)ArgData[0]);
                break;

                case GCMD_SF_DEINIT:
                    Ret = ncSvc_SF_DeInit();
                break;

                case GCMD_SF_SET_BITRATE:
                    ncSvc_SF_SetBitRate((UINT32) ArgData[0]);
                break;

                case GCMD_SF_BLOCK_ERASE:
                    Ret = ncSvc_SF_BlockErase( ArgData[0] );
                break;

                case GCMD_SF_SECTOR_ERASE:
                    Ret = ncSvc_SF_SectorErase( ArgData[0] );
                break;

                case GCMD_SF_READ_ID:
                    Ret = ncSvc_SF_ReadDeviceIdentification( (tSFLASH_ID *) ArgData[0]);
                break;

                case GCMD_SF_READ_STATUS:
                    Ret = ncSvc_SF_ReadStatus();
                break;

                case GCMD_SF_WRTIE_STATUS:
                    ncSvc_SF_WriteStatus(ArgData[0]);
                break;

                case GCMD_SF_READ_STATUS2:
                    Ret = ncSvc_SF_ReadStatus2();
                break;

                case GCMD_SF_WRITE_STATUS2:
                    ncSvc_SF_WriteStatus2(ArgData[0], ArgData[1]);
                break;

                case GCMD_SF_WAIT_WIP:
                    ncSvc_SF_WaitWIP();
                break;

                case GCMD_SF_WRITE_EN:
                    ncSvc_SF_WriteEnable();
                break;

                case GCMD_SF_WRITE_DS:
                    ncSvc_SF_WriteDisable();
                break;

                case GCMD_SF_ENABLE_WP:
                    ncSvc_SF_EnableWP(ArgData[0]);
                break;

                case SCMD_SF_OSG_READ_EN:
                    Ret = ncSvc_SF_QSPIReadDirectOSG(TRUE); 
                break;   

                case SCMD_SF_OSG_READ_DS:
                    Ret = ncSvc_SF_QSPIReadDirectOSG(FALSE); 
                break;

                case SCMD_SF_OSG_READ_DATA:
                    Ret = ncSvc_SF_QSPIReadAPBOSG(ArgData[0], ArgData[1], ArgData[2]);
                break;
                
                case SCMD_SF_LUT_READ_DATA:
                    Ret = ncSvc_SF_QSPIReadLUT(ArgData[0], (UINT8 *)ArgData[1], ArgData[2]);
                break;
                
                case SCMD_SF_GET_PAD_CTRL:
                    ncSvc_SF_GetPadCtrl();
                break;

                case SCMD_SF_FREE_PAD_CTRL:
                    ncSvc_SF_FreePadCtrl();
                break;  
        
                default :
                {
                    DEBUGMSG_SDK(MSGERR, "Error, This is not support SF command\n");
                    Ret = NC_FAILURE;
                }
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


/* End Of File */

