/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"










/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/

#define __DEBUG_ERROR_BOLD__









/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL     gbDebugOpen = FALSE;
volatile UINT32   gDebugZone  = 0;
volatile eUART_CH gDebugPort  = UART_CH0;










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncLib_DEBUG_Open(void)
{
    INT32 Ret = NC_SUCCESS;

    if(gbDebugOpen == FALSE)
    {
        ncLib_UART_Open();
        
        gbDebugOpen = TRUE;
        gDebugZone = 0;
    }

    return Ret;
}


INT32 ncLib_DEBUG_Close(void)
{
    INT32 Ret = NC_SUCCESS;

    gbDebugOpen = FALSE;
    gDebugZone = 0;
        
    return Ret;
}


INT32 ncLib_DEBUG_Read(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_DEBUG_Write(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_DEBUG_Control(eDBG_CMD Cmd,  ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;


    if(gbDebugOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case GCMD_DBG_INIT:
                {
                    tUART_PARAM tUARTParam;
                    
                    gDebugPort = (eUART_CH)ArgData[0];
                    tUARTParam.mIntEn    = DISABLE;
                    tUARTParam.mBaudRate = (UINT32)ArgData[1];
                    tUARTParam.mSPS      = UT_SPS_DIS;
                    tUARTParam.mLEN      = UT_DATA_8BIT;
                    tUARTParam.mSTP      = UT_STOP_1BIT;
                    tUARTParam.mEPS      = UT_EPS_DIS;
                    tUARTParam.mPEN      = UT_PARITY_DIS;
                    tUARTParam.mBRK      = UT_BRK_DIS;

                    ncLib_UART_Control(GCMD_UT_INIT_CH, gDebugPort, &tUARTParam, CMD_END);
                }
                break;

                case GCMD_DBG_DEINIT:
                    ncLib_UART_Control(GCMD_UT_DEINIT_CH, gDebugPort, CMD_END);
                break;

                case GCMD_DBG_APP_LOG_ZONE:
                case GCMD_DBG_SDK_LOG_ZONE:
                {
                    UINT32 Zone   = ArgData[0];
                    UINT32 Enable = ArgData[1];

                    if(Cmd == GCMD_DBG_SDK_LOG_ZONE)
                        Zone <<= MSGPOS;

                    if(Enable == ON)
                        gDebugZone |= Zone;
                    else
                        gDebugZone &= ~Zone;
                }
                break;

                default:
                    Ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


void ncLib_DEBUG_Printf(UINT32 DebugZone, const char *fmt, ...)
{
    va_list vList;
    char Buff[512];

    if(gbDebugOpen == TRUE)
    {
        if(DebugZone & gDebugZone)
        {
            #ifdef __DEBUG_ERROR_BOLD__
                if(DebugZone&MSGERR)
                    ncLib_UART_Control(GCMD_UT_PUT_STR, gDebugPort, STR_COLOR_RED_ON, CMD_END);
            
                if(DebugZone&(MSGERR<<MSGPOS))
                    ncLib_UART_Control(GCMD_UT_PUT_STR, gDebugPort, STR_COLOR_RED_ON, CMD_END);
                
                if(DebugZone&(MSGWARN<<MSGPOS))
                    ncLib_UART_Control(GCMD_UT_PUT_STR, gDebugPort, STR_COLOR_YELLOW_ON, CMD_END);   
            #endif

            
            va_start(vList, fmt);

            vsnprintf(Buff, sizeof(Buff), fmt, vList);

            va_end(vList);

            ncLib_UART_Control(GCMD_UT_PUT_STR, gDebugPort, Buff, CMD_END);



            #ifdef __DEBUG_ERROR_BOLD__
                if( (DebugZone&MSGERR) || (DebugZone&(MSGERR<<MSGPOS)) || (DebugZone&(MSGWARN<<MSGPOS)) )
                    ncLib_UART_Control(GCMD_UT_PUT_STR, gDebugPort, STR_COLOR_OFF, CMD_END);
            #endif
        }
    }
}


UINT32 ncLib_DEBUG_Scanf(char *buf)
{
    char *cp;
    INT8 data;
    UINT32 count = 0;

    if(gbDebugOpen == TRUE)
    {
        cp = buf;

        do
        {
            data = ncLib_UART_Control(GCMD_UT_GET_CHAR, gDebugPort, CMD_END);

            switch(data)
            {
                case ESCAPE_KEY:
                {
                    UINT32 func_key_step = 1;
                    
                    while(1)
                    {
                        data = ncLib_UART_Control(GCMD_UT_GET_CHAR, gDebugPort, CMD_END);

                        if(data != NC_FAILURE)
                        {
                            // Enter Key [0x1B.0x4F.0x4D]
                            if( (func_key_step == 1) && (data == 'O') )
                            {
                                func_key_step = 2;
                            }
                            else if((func_key_step == 2) && (data == 'M'))
                            {
                                *cp = '\0';
                                ncLib_UART_Control(GCMD_UT_PUT_CHAR, gDebugPort, '\n', CMD_END);
                                
                                data = RETURN_KEY;
                                break;
                            }
                            else
                            {
                                break;
                            }
                        }
                    };
                }
                break;
                
                case RETURN_KEY:
                {
                    if(count < 256)
                    {
                        *cp = '\0';
                        ncLib_UART_Control(GCMD_UT_PUT_CHAR, gDebugPort, '\n', CMD_END);
                    }
                }
                break;

                case BACKSP_KEY:
                case DELETE_KEY:
                {
                    if(count)
                    {
                        count--;
                        *(--cp) = '\0';
                        ncLib_UART_Control(GCMD_UT_PUT_STR, gDebugPort, "\b \b", CMD_END);
                    }
                }
                break;

                default:
                {
                    if(data > 0x1F && data < 0x7F && count < 256)
                    {
                        *cp = (char)data;
                        cp++;
                        count++;

                        ncLib_UART_Control(GCMD_UT_PUT_CHAR, gDebugPort, data, CMD_END);
                    }
                }
                break;
            }
        }
        while(data != RETURN_KEY);
    }

    return count;
}


/* End Of File */

