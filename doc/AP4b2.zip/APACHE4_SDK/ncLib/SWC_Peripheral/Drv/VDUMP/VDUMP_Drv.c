/**
********************************************************************************
*
*  Copyright (C) 2016 NEXTCHIP Inc. All rights reserved.
*
*  @file    : VDP_Drv.c
*
*  @brief   : This file is video dump Controller Driver for NEXTCHIP standard library
*
*  @author  : alessio / TS Group / SoC SW Team
*
*  @date    : 2016.03.08
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "VDUMP_Drv.h"










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

static UINT32 __ceil(FP32 F)
{
    FP32   X;
    UINT32 Y;

    X = F;
    Y = (UINT32)F;

    X = X - (FP32)Y;

    if(X != 0.0) X = 1.0;

    X += F;

    return (UINT32)X;
}


static UINT32 __intceiling(UINT32 nNumber, UINT8 nSignification)
{
    UINT32 X;
    UINT32 Y;

    // Unused Value - The value assigned to X is never subsequently used on any execution path
    //X = nNumber/nSignification;
    Y = nNumber%nSignification;

    if(Y)
    {
        X = nSignification - Y;
        nNumber += X;
    }

    return nNumber;
}


static void ncDrv_VDP_SetRGB2RGB(void)
{
    UINT32 i;

    // Setting V-dump Register Range [0x800~0x854]
    for(i=0; i<(22*4); i+=4)
    {
        // Get ISP's default settings. 
        // ISP RGBtoRGB Register Offset [0x0B80]
        REGRW32(rVDP_BASE, rVDP_RGB2RGB_BASE + i) = (REGRW32(APACHE_ISP_BASE, 0x0B80 + i)&0xFF);
    }
}


static void ncDrv_VDP_SetYCbCr2RGB(void)
{
    UINT32 Reg;

    // Get ISP's default settings. 

    //---------------------------------------------------------------------------
    // YCbCr Offset
    Reg  = ((REGRW32(APACHE_ISP_BASE, 0x34CC)&0xFF)<<16);   // y_offset [7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x34D0)&0xFF)<<8 );   // cb_offset[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x34D4)&0xFF)<<0 );   // cr_offset[7:0]
    REGRW32(rVDP_BASE, rVDP_YCBCR_OFFSET) = Reg;


    //---------------------------------------------------------------------------
    // YCbCr R_Sign
    REGRW32(rVDP_BASE, rVDP_YCBCR_R_SIGN) = (REGRW32(APACHE_ISP_BASE, 0x34D8)&0x7);

    // YCbCr R_Y_Gain, R_Cb_Gain
    Reg  = ((REGRW32(APACHE_ISP_BASE, 0x34DC)&0xFF)<<16);   // R_y_gain [7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x34E0)&0xFF)<<24);   // R_y_gain [10:8]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x34E4)&0xFF)<<0 );   // R_cb_gain[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x34E8)&0xFF)<<8 );   // R_cb_gain[10:8]
    REGRW32(rVDP_BASE, rVDP_YCBCR_R_GAIN_00) = Reg;

    // YCbCr R_Cr_Gain, R_Offset
    Reg  = ((REGRW32(APACHE_ISP_BASE, 0x34EC)&0xFF)<<16);   // R_cr_gain[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x34F0)&0xFF)<<24);   // R_cr_gain[10:8]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x34F4)&0xFF)<<0 );   // R_offset [7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x34F8)&0xFF)<<8 );   // R_offet  [9:8]
    REGRW32(rVDP_BASE, rVDP_YCBCR_R_GAIN_01) = Reg;

    // YCbCr R_min, R_max
    Reg  = ((REGRW32(APACHE_ISP_BASE, 0x34FC)&0xFF)<<16);   // R_min[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3500)&0xFF)<<24);   // R_min[9:8]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3504)&0xFF)<<0 );   // R_max[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3508)&0xFF)<<8 );   // R_max[9:8]
    REGRW32(rVDP_BASE, rVDP_YCBCR_R_LIMIT) = Reg;


    //---------------------------------------------------------------------------
    // YCbCr G_Sign
    REGRW32(rVDP_BASE, rVDP_YCBCR_G_SIGN) = (REGRW32(APACHE_ISP_BASE, 0x350C)&0x7);

    // YCbCr G_Y_Gain, G_Cb_Gain
    Reg  = ((REGRW32(APACHE_ISP_BASE, 0x3510)&0xFF)<<16);   // G_y_gain [7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3514)&0xFF)<<24);   // G_y_gain [10:8]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3518)&0xFF)<<0 );   // G_cb_gain[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x351C)&0xFF)<<8 );   // G_cb_gain[10:8]
    REGRW32(rVDP_BASE, rVDP_YCBCR_G_GAIN_00) = Reg;

    // YCbCr G_Cr_Gain, G_Offset
    Reg  = ((REGRW32(APACHE_ISP_BASE, 0x3520)&0xFF)<<16);   // G_cr_gain[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3524)&0xFF)<<24);   // G_cr_gain[10:8]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3528)&0xFF)<<0 );   // G_offset [7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x352C)&0xFF)<<8 );   // G_offet  [9:8]
    REGRW32(rVDP_BASE, rVDP_YCBCR_G_GAIN_01) = Reg;

    // YCbCr G_min, G_max
    Reg  = ((REGRW32(APACHE_ISP_BASE, 0x3530)&0xFF)<<16);   // G_min[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3534)&0xFF)<<24);   // G_min[9:8]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3538)&0xFF)<<0 );   // G_max[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x353C)&0xFF)<<8 );   // G_max[9:8]
    REGRW32(rVDP_BASE, rVDP_YCBCR_G_LIMIT) = Reg;


    //---------------------------------------------------------------------------
    // YCbCr B_Sign
    REGRW32(rVDP_BASE, rVDP_YCBCR_B_SIGN) = (REGRW32(APACHE_ISP_BASE, 0x3540)&0x7);

    // YCbCr B_Y_Gain, B_Cb_Gain
    Reg  = ((REGRW32(APACHE_ISP_BASE, 0x3544)&0xFF)<<16);   // B_y_gain [7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3548)&0xFF)<<24);   // B_y_gain [10:8]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x354C)&0xFF)<<0 );   // B_cb_gain[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3550)&0xFF)<<8 );   // B_cb_gain[10:8]
    REGRW32(rVDP_BASE, rVDP_YCBCR_B_GAIN_00) = Reg;

    // YCbCr B_Cr_Gain, B_Offset
    Reg  = ((REGRW32(APACHE_ISP_BASE, 0x3554)&0xFF)<<16);   // B_cr_gain[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3558)&0xFF)<<24);   // B_cr_gain[10:8]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x355C)&0xFF)<<0 );   // B_offset [7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3560)&0xFF)<<8 );   // B_offet  [9:8]
    REGRW32(rVDP_BASE, rVDP_YCBCR_B_GAIN_01) = Reg;

    // YCbCr B_min, B_max
    Reg  = ((REGRW32(APACHE_ISP_BASE, 0x3564)&0xFF)<<16);   // B_min[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3568)&0xFF)<<24);   // B_min[9:8]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x356C)&0xFF)<<0 );   // B_max[7:0]
    Reg |= ((REGRW32(APACHE_ISP_BASE, 0x3570)&0xFF)<<8 );   // B_max[9:8]
    REGRW32(rVDP_BASE, rVDP_YCBCR_B_LIMIT) = Reg;
}


static void ncDrv_VDP_SetYC444toYC422(UINT8 Chroma, UINT8 Output)
{
    UINT32 Reg;

    Reg = REGRW32(rVDP_BASE, rVDP_YC_MODE);
    
    // Clear
    Reg &= ~((1<<bVDP_YC_CHROMA_MODE)|(1<<bVDP_YC_OUT_MODE));

    // Set Mode
    Reg |= ((Chroma<<bVDP_YC_CHROMA_MODE)|(Output<<bVDP_YC_OUT_MODE));
    
    REGRW32(rVDP_BASE, rVDP_YC_MODE) = Reg;
}


static void ncDrv_VDP_SetYCProcess(void)
{
    UINT32 i;

    // Setting V-dump Register Range [0xC00~0xC70]
    for(i=0; i<(29*4); i+=4)
    {
        // Get ISP's default settings. 
        // ISP YCPorcess Register Offset [0x1C00]
        REGRW32(rVDP_BASE, rVDP_YC_BASE + i) = REGRW32(APACHE_ISP_BASE, 0x1C00 + i);
    }
}


static void ncDrv_VDP_GetInputSize(ptVDP_INFO ptVDP, ptVDP_PARAM ptVDPParam)
{
    UINT32  Cfg;   

    // Set Format(RGB or YC444 or YC422, Input Path, Capture Frame..)
    Cfg = ((ptVDPParam->mFrameType<<bVDP_CFG_CAP_MODE)
        | (ptVDPParam->mInputPath<<bVDP_CFG_IN_SEL)
        | (0<<bVDP_CFG_ALIGN)
        | (ptVDPParam->mYUVSelect<<bVDP_CFG_YC422)
        | (ptVDPParam->mInFormat<<bVDP_CFG_FORMAT_SEL)
        );
    REGRW32(rVDP_BASE, rVDP_CFG) = Cfg;

    
    // Input Path : Get H-Total, H-Active, H-Blank, V-Active
    switch(ptVDPParam->mInputPath)
    {
        case VDP_I_YC_CROP_OUT_PATH:
        case VDP_I_LDC_OUT_PATH:   
        case VDP_I_OPD_OUT_PATH:  
        case VDP_I_OVERLAY_OUT_PATH:
        default:
        {
            #if 1 // FPGA Test Mode - Input Gen, IPT and ICDC(Input Test Pattern)
                ptVDP->mInVTOT  = (REGRW32(APACHE_ISP_BASE, 0x604));
                ptVDP->mInVTOT |= (REGRW32(APACHE_ISP_BASE, 0x608)<<8); 
                
                ptVDP->mInVACT  = (REGRW32(APACHE_ISP_BASE, 0x60C));
                ptVDP->mInVACT |= (REGRW32(APACHE_ISP_BASE, 0x610)<<8);  
                
                ptVDP->mInHTOT  = (REGRW32(APACHE_ISP_BASE, 0x614));
                ptVDP->mInHTOT |= (REGRW32(APACHE_ISP_BASE, 0x618)<<8);

                ptVDP->mInHACT  = (REGRW32(APACHE_ISP_BASE, 0x61C));
                ptVDP->mInHACT |= (REGRW32(APACHE_ISP_BASE, 0x620)<<8);

                ptVDP->mInHBLK = ptVDP->mInHTOT - ptVDP->mInHACT;
            #else
                ptVDP->mInHTOT  = (REGRW32(APACHE_ISP_BASE, 0x684));
                ptVDP->mInHTOT |= (REGRW32(APACHE_ISP_BASE, 0x688)<<8);

                #if 1
                ptVDP->mInHTOT = 4400;
                REGRW32(APACHE_ISP_BASE, 0x684) = (ptVDP->mInHTOT)&0xff;;
                REGRW32(APACHE_ISP_BASE, 0x688) = (ptVDP->mInHTOT>>8)&0xff;
                #endif

                ptVDP->mInVTOT  = (REGRW32(APACHE_ISP_BASE, 0x68C));
                ptVDP->mInVTOT |= (REGRW32(APACHE_ISP_BASE, 0x690)<<8); 

                ptVDP->mInHACT  = (REGRW32(APACHE_ISP_BASE, 0x6A4));
                ptVDP->mInHACT |= (REGRW32(APACHE_ISP_BASE, 0x6A8)<<8);

                ptVDP->mInVACT  = (REGRW32(APACHE_ISP_BASE, 0x6AC));
                ptVDP->mInVACT |= (REGRW32(APACHE_ISP_BASE, 0x6B0)<<8); 
 
                ptVDP->mInHBLK = ptVDP->mInHTOT - ptVDP->mInHACT;

                REGRW32(APACHE_ISP_BASE, 0x604) = (ptVDP->mInVTOT)&0xff;
                REGRW32(APACHE_ISP_BASE, 0x608) = (ptVDP->mInVTOT>>8)&0xff;

                REGRW32(APACHE_ISP_BASE, 0x60C) = (ptVDP->mInVACT)&0xff;
                REGRW32(APACHE_ISP_BASE, 0x610) = (ptVDP->mInVACT>>8)&0xff;

                REGRW32(APACHE_ISP_BASE, 0x614) = (ptVDP->mInHTOT)&0xff;
                REGRW32(APACHE_ISP_BASE, 0x618) = (ptVDP->mInHTOT>>8)&0xff;
                
                REGRW32(APACHE_ISP_BASE, 0x61C) = (ptVDP->mInHACT)&0xff;
                REGRW32(APACHE_ISP_BASE, 0x620) = (ptVDP->mInHACT>>8)&0xff;
            #endif
        }
        break;
    }
}


static void ncDrv_VDP_SetCrop(ptVDP_INFO ptVDP, ptVDP_PARAM ptVDPParam)
{
    // H-Sync
    UINT32 H_STS = 0;
    UINT32 H_END = ptVDP->mInHACT;

    // V-Sync
    UINT32 V_STS = 0;
    UINT32 V_END = ptVDP->mInVACT;

    // H-Blank
    UINT32 H_BLK = ptVDP->mInHBLK;

    
    // Crop Size Check. 
    if(ptVDPParam->mCropEn == ENABLE)
    {
        // H-Sync Range Check 
        if((ptVDPParam->mCropStartH < ptVDPParam->mCropEndH) && (ptVDPParam->mCropEndH <= H_END))
        {
            // H-Start Postion
            H_STS = ptVDPParam->mCropStartH;

            // H-End Postion
            H_END = ptVDPParam->mCropEndH;

            // H-Blank Size
            H_BLK = ptVDP->mInHTOT - (H_STS + H_END);
        }
        else
        {
            DEBUGMSG_SDK(MSGWARN, "[VDUMP_Drv] Crop H-Size Error, S:%d E:%d H:%d\n", 
                                                ptVDPParam->mCropStartH, ptVDPParam->mCropEndH, H_END);

            ptVDPParam->mCropStartH = H_STS;
            ptVDPParam->mCropEndH   = H_END;
        }

        // V-Sync Range Check 
        if((ptVDPParam->mCropStartV < ptVDPParam->mCropEndV) && (ptVDPParam->mCropEndV <= V_END))
        {
            // V-Start Postion
            V_STS = ptVDPParam->mCropStartV; 

            // V-End Postion 
            V_END = ptVDPParam->mCropEndV;
        }
        else
        {
            DEBUGMSG_SDK(MSGWARN, "[VDUMP_Drv] Crop V-Size Error, S:%d E:%d V:%d\n", 
                                                ptVDPParam->mCropStartV, ptVDPParam->mCropEndV, V_END);

            ptVDPParam->mCropStartV = V_STS;
            ptVDPParam->mCropEndV   = V_END;
        }
    }


    // Set V/H Start and End Postion 
    REGRW32(rVDP_BASE, rVDP_CROP_H_ST_B_BLK) = (H_STS<<16) | H_BLK;
    REGRW32(rVDP_BASE, rVDP_CROP_V_ST_H_END) = (V_STS<<16) | H_END;
    REGRW32(rVDP_BASE, rVDP_CROP_V_END)      = V_END; 

    // Enable
    if(((H_END - H_STS) < ptVDP->mInHACT) || ((V_END - V_STS) < ptVDP->mInVACT))
    {
        REGRW32(rVDP_BASE, rVDP_CROP_EN) = (1<<bVDP_CROP_SYNC_EN)|(1<<bVDP_CROP_DATA_EN); 
    }
    else
    {
        REGRW32(rVDP_BASE, rVDP_CROP_EN) = 0;
        ptVDPParam->mCropEn = DISABLE;
    }
}


static void ncDrv_VDP_SetDownScaler(ptVDP_PARAM ptVDPParam)
{
    // Delay
    UINT32 T_DLY;
    
    // DTO
    UINT32 H_DTO;
    UINT32 V_DTO;

    // Input
    UINT32 IN_H_ACT;
    UINT32 IN_V_ACT; 
    UINT32 IN_H_BLK;
    
    // Output
    UINT32 OUT_H_ACT = ptVDPParam->mScalOutputH;
    UINT32 OUT_V_ACT = ptVDPParam->mScalOutputV;


    // Get Crop Setting Value : (Down-Scaler input == Crop output)
    // H-Active = (H_End - H_Start)
    IN_H_ACT = ((REGRW32(rVDP_BASE, rVDP_CROP_V_ST_H_END)&0xFFFF) - ((REGRW32(rVDP_BASE, rVDP_CROP_H_ST_B_BLK)&0xFFFF0000)>>16));

    // V-Active = (V_End - V_Start)
    IN_V_ACT = ((REGRW32(rVDP_BASE, rVDP_CROP_V_END)&0xFFFF) - ((REGRW32(rVDP_BASE, rVDP_CROP_V_ST_H_END)&0xFFFF0000)>>16));

    // H-Blank
    IN_H_BLK = (REGRW32(rVDP_BASE, rVDP_CROP_H_ST_B_BLK)&0xFFFF);
 

    // Check In/Out Size
    if((ptVDPParam->mScalEn == DISABLE) || (OUT_H_ACT == 0) || (OUT_V_ACT == 0))
    {
        OUT_H_ACT = IN_H_ACT;
        OUT_V_ACT = IN_V_ACT;
    }
    
    if(OUT_H_ACT > IN_H_ACT) 
    {
        OUT_H_ACT = IN_H_ACT;
        ptVDPParam->mScalOutputH = OUT_H_ACT;
    }
    
    if(OUT_V_ACT > IN_V_ACT)
    {
        OUT_V_ACT = IN_V_ACT;       
        ptVDPParam->mScalOutputV = OUT_V_ACT;
    }
    

    // Set Scaler Mode
    REGRW32(rVDP_BASE, rVDP_HVDS_MODE) = (1<<1);


    // Register Update Disable
    REGRW32(rVDP_BASE, rVDP_HVDS_REG_CHG) = 0;


    // Set Down-Scaler Input
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_IN_HACT_SIZE_L) = (IN_H_ACT     &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_IN_HACT_SIZE_H) = ((IN_H_ACT>>8)&0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_IN_HBLK_SIZE_L) = (IN_H_BLK     &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_IN_HBLK_SIZE_H) = ((IN_H_BLK>>8)&0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_IN_VACT_SIZE_L) = (IN_V_ACT     &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_IN_VACT_SIZE_H) = ((IN_V_ACT>>8)&0xFF);


    // Set Down-Scaler DTO
    H_DTO = (UINT32)((((float)IN_H_ACT * VDP_DTO_MIN)/OUT_H_ACT));
    V_DTO = (UINT32)((((float)IN_V_ACT * VDP_DTO_MIN)/OUT_V_ACT));
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_H_DTO_L) = (H_DTO     &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_H_DTO_H) = ((H_DTO>>8)&0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_V_DTO_L) = (V_DTO     &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_V_DTO_H) = ((V_DTO>>8)&0xFF);


    // Set Down-Scaler Output    
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_HACT_SIZE_L) = (OUT_H_ACT     &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_HACT_SIZE_H) = ((OUT_H_ACT>>8)&0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_VACT_SIZE_L) = (OUT_V_ACT     &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_VACT_SIZE_H) = ((OUT_V_ACT>>8)&0xFF);


    // Set HUS
    H_DTO = (UINT32)((((float)OUT_H_ACT * 0x4000)/OUT_H_ACT));
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_IN_H_SIZE_L) = (OUT_H_ACT     &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_IN_H_SIZE_H) = ((OUT_H_ACT>>8)&0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_UP_H_DTO_L)  = (H_DTO         &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_UP_H_DTO_H)  = ((H_DTO>>8)    &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_UP_H_DISP_L) = (OUT_H_ACT     &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_UP_H_DISP_H) = ((OUT_H_ACT>>8)&0xFF);


    // Set HUS Timing Generate.
    H_DTO = (UINT32)((((float)IN_H_ACT * VDP_DTO_MIN)/OUT_H_ACT));
    V_DTO = VDP_DTO_MIN;
    T_DLY = (UINT32)((((float)OUT_H_ACT * (H_DTO - V_DTO))/VDP_DTO_MIN) + 5);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_TG_V_RDLY_L) = (T_DLY         &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_TG_V_RDLY_H) = ((T_DLY>>8)    &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_TG_V_FDLY_L) = (T_DLY         &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_TG_V_FDLY_H) = ((T_DLY>>8)    &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_TG_H_ACT_L)  = (OUT_H_ACT     &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_TG_H_ACT_H)  = ((OUT_H_ACT>>8)&0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_TG_H_DLY_L)  = (T_DLY         &0xFF);
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_TG_H_DLY_H)  = ((T_DLY>>8)    &0xFF);


    // Enable or Disable Down Scaler
    if((OUT_H_ACT < IN_H_ACT) || (OUT_V_ACT < IN_V_ACT))
    {
        REGRW32(rVDP_BASE, rVDP_HVDS_DS_MODE)     = (1<<bVDP_HVDS_DS_EN);
        REGRW32(rVDP_BASE, rVDP_HVDS_HUS_UP_MODE) = (1<<bVDP_HVDS_HUS_UP_EN);
        REGRW32(rVDP_BASE, rVDP_HVDS_HUS_TG_EN)   = bVDP_HVD_HUS_TG_ALL;
    }
    else
    {
        REGRW32(rVDP_BASE, rVDP_HVDS_DS_MODE)     = 0;
        REGRW32(rVDP_BASE, rVDP_HVDS_HUS_UP_MODE) = 0;
        REGRW32(rVDP_BASE, rVDP_HVDS_HUS_TG_EN)   = 0;
        ptVDPParam->mScalEn = DISABLE;
    }

    // Register Update Enable
    REGRW32(rVDP_BASE, rVDP_HVDS_REG_CHG) = 1;
}


static void ncDrv_VDP_SetWDMA(ptVDP_PARAM ptVDPParam)
{
    eVDP_CH Ch;
   
    UINT32 OUT_H_ACT;
    UINT32 OUT_V_ACT;
    
    UINT32 Stride; 
    UINT32 HPixel; 
    UINT32 VLine;
    

    // Get Down-Scaler Output 
    OUT_H_ACT  = (REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_HACT_SIZE_L)&0xFF);
    OUT_H_ACT |= (REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_HACT_SIZE_H)&0xFF)<<8;
    OUT_V_ACT  = (REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_VACT_SIZE_L)&0xFF);
    OUT_V_ACT |= (REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_VACT_SIZE_H)&0xFF)<<8;
    

    // Set WDMA Channel
    for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++)
    {
        if(ptVDPParam->mDumpCh[Ch].mChEnable == ENABLE)
        {
            // Set DMA Mode
            REGRW32(rVDP_BASE, rVDP_WDMA_CFG  +  (Ch * 0x100)) = ( (ptVDPParam->mDumpCh[Ch].mEndian<<bVDP_WDMA_ENDIAN)
                                                                 | (ptVDPParam->mDumpCh[Ch].mParsing<<bVDP_WDMA_PARSING)
                                                                 | (ptVDPParam->mDumpCh[Ch].mBit<<bVDP_WDMA_PACKET_BIT));

            // Set DMA Address
            REGRW32(rVDP_BASE, rVDP_WDMA_ADDR  + (Ch * 0x100)) = ptVDPParam->mDumpCh[Ch].mDumpAddr;


            // Set DMA BurstLength
            if(  (ptVDPParam->mDumpCh[Ch].mBurst == VDP_BURST_6_RESERVED)
              || (ptVDPParam->mDumpCh[Ch].mBurst >= MAX_OF_VDP_WRITE_BURST))
            {
                REGRW32(rVDP_BASE, rVDP_WDMA_BURST + (Ch * 0x100)) = (VDP_BURST_16&0xF);
            }
            else
            {
                REGRW32(rVDP_BASE, rVDP_WDMA_BURST + (Ch * 0x100)) = (ptVDPParam->mDumpCh[Ch].mBurst)&0xF;
            }


   
            Stride = __ceil((float)OUT_H_ACT/(4.0/(1<<ptVDPParam->mDumpCh[Ch].mBit)))*4;
            HPixel = Stride/4;
            VLine  = OUT_V_ACT;

            // Set DMA Size
            REGRW32(rVDP_BASE, rVDP_WDMA_STRIDE + (Ch * 0x100)) = Stride;
            REGRW32(rVDP_BASE, rVDP_WDMA_LINE   + (Ch * 0x100)) = ((HPixel << bVDP_WDMA_HPIX) | (VLine<<bVDP_WDMA_VLINE));
        }
    }
}


static BOOL ncDrv_VDP_IsLevelType(void)
{
    BOOL ret = FALSE;

    if(REGRW32(rVDP_BASE, rVDP_INT_TYPE))
        ret = TRUE;

    return ret;
}


static void ncDrv_VDP_IntTriggerMode(void)
{
    UINT32 nTrigType;

    nTrigType = REGRW32(APACHE_SYSCON_BASE, 0x144);

    if(nTrigType&(1U<<(IRQ_NUM_VDUMP-IRQ_NUM_ISP0)))
        REGRW32(rVDP_BASE, rVDP_INT_TYPE) = 0;  // Edge Type
    else
        REGRW32(rVDP_BASE, rVDP_INT_TYPE) = 1;  // Level Type
}


static UINT32 ncDrv_VDP_SetIntDisable(void)
{
    UINT32 Reg;

    // EDGE  : Read Clear Type
    Reg = (REGRW32(rVDP_BASE, rVDP_INT_STS)&0x3FFFFFF);

    // Level : W '1->0' Clear Type
    Reg = (REGRW32(rVDP_BASE, rVDP_INT_LEVEL_STS)&0x111);
    if(Reg)
    {
        REGRW32(rVDP_BASE, rVDP_INT_LEVEL_CLR) = Reg;
        REGRW32(rVDP_BASE, rVDP_INT_LEVEL_CLR) = 0;
    }

    // Disable Intc
    REGRW32(rVDP_BASE, rVDP_INT_EDGE_EN)  = 0;
    REGRW32(rVDP_BASE, rVDP_INT_LEVEL_EN) = 0;
    
    return Reg;
}


static void ncDrv_VDP_SetIntEnable(ptVDP_INFO ptVDP)
{
    eVDP_CH Ch;    
    UINT32  IntChEn  = 0;   
    UINT32  DoneFlag = 0;

    if(ncDrv_VDP_IsLevelType())
    {
        for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++)
        {
            if(ptVDP->mChEn[Ch] == ENABLE)
            {
                // Pos : CH0(0), CH1(4), CH2(8)
                IntChEn  |= (bVDP_INT_END<<(Ch*4));
                DoneFlag |= (bVDP_INT_END<<(Ch*8));
            }
        }

        if(ptVDP->mIntEn == ENABLE)
            REGRW32(rVDP_BASE, rVDP_INT_LEVEL_EN) = IntChEn;
    }
    else
    {
        
        for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++)
        {
            if(ptVDP->mChEn[Ch] == ENABLE)
            {
                // Pos : CH0(0), CH1(8), CH2(16)
                IntChEn  |= ((bVDP_INT_START|bVDP_INT_END)<<(Ch*8));
                //IntChEn  |= (bVDP_INT_END<<(Ch*8));
                DoneFlag |= (bVDP_INT_END<<(Ch*8));
            }
        }

        // Intc Enable 
        if(ptVDP->mIntEn == ENABLE)
        {
            REGRW32(rVDP_BASE, rVDP_INT_EDGE_EN) = ((bVDP_INT_START|bVDP_INT_END)<<24) | (IntChEn|bVDP_INT_ERR);
            //REGRW32(rVDP_BASE, rVDP_INT_EDGE_EN) = (IntChEn|bVDP_INT_ERR);
        }
    }


    // V-Dump End Flag.
    ptVDP->mDoneFlag = DoneFlag;
    
    // Intc status clear
    ptVDP->mIntSts = 0;
}


void ncDrv_VDP_GetCropCnt(UINT32* V_CNT, UINT32* P_CNT)
{
    *V_CNT = REGRW32(rVDP_BASE, rVDP_DBG_CROP_VCNT)&0xFFFF;
    *P_CNT = REGRW32(rVDP_BASE, rVDP_DBG_CROP_PCNT);
}


void ncDrv_VDP_GetScalCnt(UINT32* V_CNT, UINT32* P_CNT)
{
    *V_CNT = REGRW32(rVDP_BASE, rVDP_DBG_SCAL_VCNT)&0xFFFF;
    *P_CNT = REGRW32(rVDP_BASE, rVDP_DBG_SCAL_PCNT);
}


void ncDrv_VDP_GetOutPutSize(UINT32* H_ACT, UINT32* V_ACT)
{
    *H_ACT  = (REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_HACT_SIZE_L)&0xFF);
    *H_ACT |= (REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_HACT_SIZE_H)&0xFF)<<8;

    *V_ACT  = (REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_VACT_SIZE_L)&0xFF);
    *V_ACT |= (REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_VACT_SIZE_H)&0xFF)<<8;    
}


INT32 ncDrv_VDP_GetOutPutDumpSize(eVDP_CH Ch)
{
    UINT32 OUT_V_ACT;
    UINT32 HPixel;

    HPixel = REGRW32(rVDP_BASE, rVDP_WDMA_LINE + (Ch * 0x100))>>bVDP_WDMA_HPIX;

    OUT_V_ACT  = (REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_VACT_SIZE_L)&0xFF);
    OUT_V_ACT |= (REGRW32(rVDP_BASE, rVDP_HVDS_DS_OUT_VACT_SIZE_H)&0xFF)<<8;
    
    return (INT32)((__intceiling(HPixel, 2)) * OUT_V_ACT * 4);
}


INT32 ncDrv_VDP_GetOneFrameStatus(eVDP_CH Ch)
{
    return (INT32)((REGRW32(rVDP_BASE, rVDP_DBG_ERR_STS + (Ch*0x10))>>16)&0x7);
}


INT32 ncDrv_VDP_GetLineCnt(eVDP_CH Ch)
{
    return (INT32)(REGRW32(rVDP_BASE, rVDP_DBG_LINE_CNT + (Ch*0x10))&0xFFFF);
}


INT32 ncDrv_VDP_GetPixelCnt(eVDP_CH Ch)
{
    return (INT32)(REGRW32(rVDP_BASE, rVDP_DBG_PIXEL_CNT + (Ch*0x10)));
}


INT32 ncDrv_VDP_GetOneFrameErrorStatus(eVDP_CH Ch)
{
    return (INT32)((REGRW32(rVDP_BASE, rVDP_DBG_ERR_STS + (Ch*0x10))>>4)&0x3);
}


INT32 ncDrv_VDP_IntStsClr(ptVDP_INFO ptVDP)
{
    UINT32 Reg;
    UINT32 Tmp;

    // Get Status
    Reg = (REGRW32(rVDP_BASE, rVDP_INT_STS)&0x3FFFFFF);

    // Clear
    REGRW32(rVDP_BASE, rVDP_INT_STS) = Reg;

    if(ncDrv_VDP_IsLevelType())
    {
        // Level : W '1->0' Clear Type
        Tmp = (REGRW32(rVDP_BASE, rVDP_INT_LEVEL_STS)&0x111);
        if(Tmp)
        {
            REGRW32(rVDP_BASE, rVDP_INT_LEVEL_CLR) = Tmp;
            REGRW32(rVDP_BASE, rVDP_INT_LEVEL_CLR) = 0;
        }

        // End Flag Update
        Reg &= 0x3FEFEFE;
        if(Tmp&0x001) Reg |= (1<<0);
        if(Tmp&0x010) Reg |= (1<<8);
        if(Tmp&0x100) Reg |= (1<<16);

        // Update Intc Status
        ptVDP->mIntSts |= Reg;

        // Return Status (END)
        Reg &= 0x010101;
    }
    else
    {
        // Update Intc Status
        ptVDP->mIntSts |= Reg;
    }
    

    // return Current status
    return (INT32)Reg;
}


INT32 ncDrv_VDP_GetStatus(ptVDP_INFO ptVDP)
{
    ncDrv_VDP_IntStsClr(ptVDP);

    // return last status
    return (INT32)ptVDP->mIntSts;
}


INT32 ncDrv_VDP_CheckComplete(ptVDP_INFO ptVDP)
{
    INT32 ret = NC_FAILURE;

    // Check Intc Enable Status
    if(ptVDP->mIntEn == DISABLE)
    {
        // update status 
        ncDrv_VDP_GetStatus(ptVDP);
    }

    // Check Done and Error Status
    if( (ptVDP->mIntSts&bVDP_INT_ERR) || (((ptVDP->mIntSts)&bVDP_INT_DONE) == ptVDP->mDoneFlag))
    {
        // End - Status Return
        ret = ptVDP->mIntSts;
    }

    return ret;
}


void ncDrv_VDP_Stop(void)
{
    // Interrupt Disable
    ncDrv_VDP_SetIntDisable();    
    
    // Disable Vdump All Channel
    REGRW32(rVDP_BASE, rVDP_CTRL) = 0;
}


INT32 ncDrv_VDP_Start(ptVDP_INFO ptVDP)
{
    INT32 Ret = NC_SUCCESS;    
    
    eVDP_CH Ch;
    UINT32  RunCh; 

    if(ptVDP != NULL)
    {
        // Check Enable Channel 
        RunCh = 0; 
        for(Ch=VDP_CH0; Ch<MAX_OF_VDP_CH; Ch++)
        {
            if(ptVDP->mChEn[Ch] == ENABLE)
                RunCh |= (1<<(Ch+bVDP_CTRL_CH_EN));
        }

        // Run V-Dump
        if(RunCh)  
        {
            // Set Interrupt
            ncDrv_VDP_SetIntEnable(ptVDP);
            
            // Enable Channel 
            REGRW32(rVDP_BASE, rVDP_CTRL) = (RunCh | ptVDP->mFrameSel);
            
            // Setting Register Update
            REGRW32(rVDP_BASE, rVDP_REG_UP) = ON;

            // Start
            REGRW32(rVDP_BASE, rVDP_START) = (RunCh | (1<<0));
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


void ncDrv_VDP_SetOperation(ptVDP_INFO ptVDP, ptVDP_PARAM ptVDPParam)
{
    // Disable Channel 
    ncDrv_VDP_DeInitialize();
    
    // Get Input Size
    ncDrv_VDP_GetInputSize(ptVDP, ptVDPParam);
    
    // Set Crop
    ncDrv_VDP_SetCrop(ptVDP, ptVDPParam);

    // Set Down Scaler 
    ncDrv_VDP_SetDownScaler(ptVDPParam);
    
    // Set WDMA
    ncDrv_VDP_SetWDMA(ptVDPParam);     
}


void ncDrv_VDP_DeInitialize(void)
{
    // All Channel Disable
    ncDrv_VDP_Stop();

    // Crop Disable
    REGRW32(rVDP_BASE, rVDP_CROP_EN) = 0;
    
    // Down Scaler Disable
    REGRW32(rVDP_BASE, rVDP_HVDS_DS_MODE)     = 0;
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_UP_MODE) = 0;
    REGRW32(rVDP_BASE, rVDP_HVDS_HUS_TG_EN)   = 0;
}


void ncDrv_VDP_Initialize(void)
{
    // All Function Disable
    ncDrv_VDP_DeInitialize();

    // YCBCR default value (tuning vactor)
    ncDrv_VDP_SetYCProcess();
    ncDrv_VDP_SetYC444toYC422(0, 0);

    // RGB default value (tuning vactor)
    ncDrv_VDP_SetYCbCr2RGB();
    ncDrv_VDP_SetRGB2RGB();

    // Set Interrupt trigger mode
    ncDrv_VDP_IntTriggerMode();
}


/* End Of File */

