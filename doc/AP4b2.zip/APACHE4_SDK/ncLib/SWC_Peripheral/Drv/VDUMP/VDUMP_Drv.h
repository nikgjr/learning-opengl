/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __VDP_DRV_H__
#define __VDP_DRV_H__


/*
********************************************************************************
*               INCLUDE                                    
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define rVDP_BASE                           APACHE_VDUMP_BASE


//------------------------------------------------------------------------------
// Scaler Down and UP
#define rVDP_HVDS_MODE                      (0x100<<2)  // 0x400
#define rVDP_HVDS_REG_CHG                   (0x101<<2)  // 0x404
#define rVDP_HVDS_DS_IN_HACT_SIZE_L         (0x102<<2)  // 0x408
#define rVDP_HVDS_DS_IN_HACT_SIZE_H         (0x103<<2)  // 0x40C
#define rVDP_HVDS_DS_IN_HBLK_SIZE_L         (0x104<<2)  // 0x410
#define rVDP_HVDS_DS_IN_HBLK_SIZE_H         (0x105<<2)  // 0x414
#define rVDP_HVDS_DS_IN_VACT_SIZE_L         (0x106<<2)  // 0x418
#define rVDP_HVDS_DS_IN_VACT_SIZE_H         (0x107<<2)  // 0x41C
#define rVDP_HVDS_DS_MODE                   (0x108<<2)  // 0x420
    #define bVDP_HVDS_DS_EN                 (3)
#define rVDP_HVDS_DS_METHOD_YC              (0x109<<2)  // 0x424
#define rVDP_HVDS_DS_H_DTO_L                (0x10A<<2)  // 0x428
#define rVDP_HVDS_DS_H_DTO_H                (0x10B<<2)  // 0x42C
#define rVDP_HVDS_DS_V_DTO_L                (0x10C<<2)  // 0x430
#define rVDP_HVDS_DS_V_DTO_H                (0x10D<<2)  // 0x434
#define rVDP_HVDS_DS_OUT_HACT_SIZE_L        (0x10E<<2)  // 0x438
#define rVDP_HVDS_DS_OUT_HACT_SIZE_H        (0x10F<<2)  // 0x43C
#define rVDP_HVDS_DS_OUT_VACT_SIZE_L        (0x110<<2)  // 0x440
#define rVDP_HVDS_DS_OUT_VACT_SIZE_H        (0x111<<2)  // 0x444
#define rVDP_HVDS_HUS_IN_H_SIZE_L           (0x112<<2)  // 0x448
#define rVDP_HVDS_HUS_IN_H_SIZE_H           (0x113<<2)  // 0x44C
#define rVDP_HVDS_HUS_IN_ERR                (0x114<<2)  // 0x450
#define rVDP_HVDS_HUS_FIFO_ERR              (0x115<<2)  // 0x454
#define rVDP_HVDS_HUS_TG_EN                 (0x116<<2)  // 0x458
    #define bVDP_HVD_HUS_TG_ALL             (0xF)
#define rVDP_HVDS_HUS_TG_V_RDLY_L           (0x117<<2)  // 0x45C
#define rVDP_HVDS_HUS_TG_V_RDLY_H           (0x118<<2)  // 0x460
#define rVDP_HVDS_HUS_TG_V_FDLY_L           (0x119<<2)  // 0x464
#define rVDP_HVDS_HUS_TG_V_FDLY_H           (0x11A<<2)  // 0x468
#define rVDP_HVDS_HUS_TG_H_ACT_L            (0x11B<<2)  // 0x46C
#define rVDP_HVDS_HUS_TG_H_ACT_H            (0x11C<<2)  // 0x470
#define rVDP_HVDS_HUS_TG_H_DLY_L            (0x11D<<2)  // 0x474
#define rVDP_HVDS_HUS_TG_H_DLY_H            (0x11E<<2)  // 0x478
#define rVDP_HVDS_HUS_UP_MODE               (0x11F<<2)  // 0x47C
    #define bVDP_HVDS_HUS_UP_EN             (1)
#define rVDP_HVDS_HUS_UP_H_DTO_L            (0x120<<2)  // 0x480
#define rVDP_HVDS_HUS_UP_H_DTO_H            (0x121<<2)  // 0x484
#define rVDP_HVDS_HUS_UP_H_DISP_L           (0x122<<2)  // 0x488
#define rVDP_HVDS_HUS_UP_H_DISP_H           (0x123<<2)  // 0x48C
#define rVDP_HVDS_HUS_UP_METHOD_YC          (0x124<<2)  // 0x490
#define rVDP_HVDS_HUS_UP_ERR                (0x125<<2)  // 0x494


//------------------------------------------------------------------------------
// RGB to RGB
#define rVDP_RGB2RGB_BASE                   (0x800)
#define rVDP_RGB_R_R_GAIN_L                 (0x200<<2)  // 0x800
#define rVDP_RGB_R_R_GAIN_H                 (0x201<<2)  // 0x804
#define rVDP_RGB_R_G_GAIN_L                 (0x202<<2)  // 0X808
#define rVDP_RGB_R_G_GAIN_H                 (0x203<<2)  // 0x80C
#define rVDP_RGB_R_B_GAIN_L                 (0x204<<2)  // 0x810
#define rVDP_RGB_R_B_GAIN_H                 (0x205<<2)  // 0x814 
#define rVDP_RGB_G_R_GAIN_L                 (0x206<<2)  // 0x818
#define rVDP_RGB_G_R_GAIN_H                 (0x207<<2)  // 0x81C
#define rVDP_RGB_G_G_GAIN_L                 (0x208<<2)  // 0x820
#define rVDP_RGB_G_G_GAIN_H                 (0x209<<2)  // 0x824
#define rVDP_RGB_G_B_GAIN_L                 (0x20A<<2)  // 0x828
#define rVDP_RGB_G_B_GAIN_H                 (0x20B<<2)  // 0x82C
#define rVDP_RGB_B_R_GAIN_L                 (0x20C<<2)  // 0x830
#define rVDP_RGB_B_R_GAIN_H                 (0x20D<<2)  // 0x834
#define rVDP_RGB_B_G_GAIN_L                 (0x20E<<2)  // 0x838
#define rVDP_RGB_B_G_GAIN_H                 (0x20F<<2)  // 0x83C
#define rVDP_RGB_B_B_GAIN_L                 (0x210<<2)  // 0x840
#define rVDP_RGB_B_B_GAIN_H                 (0x211<<2)  // 0x844
#define rVDP_RGB_R_OFFSET                   (0x212<<2)  // 0x848
#define rVDP_RGB_G_OFFSET                   (0x213<<2)  // 0x84C
#define rVDP_RGB_B_OFFSET                   (0x214<<2)  // 0x850
#define rVDP_RGB_AlPHA                      (0x215<<2)  // 0x854


//------------------------------------------------------------------------------
// YC Process
#define rVDP_YC_BASE                        (0xC00)
#define rVDP_YC_OP                          (0x300<<2)  // 0xC00
#define rVDP_YC_Y_OFFSET_01_L               (0x301<<2)  // 0xC04
#define rVDP_YC_Y_OFFSET_01_H               (0x302<<2)  // 0xC08
#define rVDP_YC_Y_OFFSET_02_L               (0x303<<2)  // 0xC0C
#define rVDP_YC_Y_OOFFSET_02_H              (0x304<<2)  // 0xC10
#define rVDP_YC_Y_GAIN_L                    (0x305<<2)  // 0xC14
#define rVDP_YC_Y_GAIN_H                    (0x306<<2)  // 0xC18
#define rVDP_YC_Y_CLIP_TH_L                 (0x307<<2)  // 0xC1C
#define rVDP_YC_Y_CLIP_TH_H                 (0x308<<2)  // 0xC20
#define rVDP_YC_CB_SAT_GAIN_L               (0x309<<2)  // 0xC24
#define rVDP_YC_CB_SAT_GAIN_H               (0x30A<<2)  // 0xC28
#define rVDP_YC_C_HUE_MG                    (0x30B<<2)  // 0xC2C
#define rVDP_YC_C_HUE_R                     (0x30C<<2)  // 0xC30
#define rVDP_YC_C_HUE_YE                    (0x30D<<2)  // 0xC34
#define rVDP_YC_C_HUE_G                     (0x30E<<2)  // 0xC38
#define rVDP_YC_C_HUE_CY                    (0x30F<<2)  // 0xC3C
#define rVDP_YC_C_HUE_B                     (0x310<<2)  // 0xC40
#define rVDP_YC_C_HUE_GAIN_MG               (0x311<<2)  // 0xC44
#define rVDP_YC_C_HUE_GAIN_R                (0x312<<2)  // 0xC48
#define rVDP_YC_C_HUE_GAIN_YE               (0x313<<2)  // 0xC4C
#define rVDP_YC_C_HUE_GAIN_G                (0x314<<2)  // 0xC50
#define rVDP_YC_C_HUE_GAIN_CY               (0x315<<2)  // 0xC54
#define rVDP_YC_C_HUE_GAIN_B                (0x316<<2)  // 0xC58
#define rVDP_YC_C_DIFF_REF_L                (0x317<<2)  // 0xC5C
#define rVDP_YC_C_DIFF_REF_H                (0x318<<2)  // 0xC60
#define rVDP_YC_CB_DIFF_OFFSET_L            (0x319<<2)  // 0xC64
#define rVDP_YC_CB_DIFF_OFFSET_H            (0x31A<<2)  // 0xC68
#define rVDP_YC_CR_DIFF_OFFSET_L            (0x31B<<2)  // 0xC6C
#define rVDP_YC_CR_DIFF_OFFSET_H            (0x31C<<2)  // 0xC70


//------------------------------------------------------------------------------
// VDUMP PipeLine Ctrl
#define rVDP_CTRL                           (0x8000)
    #define bVDP_CTRL_CH_EN                 (1)
    #define bVDP_CTRL_REG_UP                (0)
#define rVDP_CFG                            (0x8004)
    #define bVDP_CFG_CAP_MODE               (24)
    #define bVDP_CFG_IN_SEL                 (16)
    #define bVDP_CFG_ALIGN                  (10)    
    #define bVDP_CFG_YC422                  (4)
    #define bVDP_CFG_FORMAT_SEL             (0)
#define rVDP_REG_UP                         (0x8008)

// Level Type
#define rVDP_INT_LEVEL_EN                   (0x8010)
#define rVDP_INT_LEVEL_STS                  (0x8014)
#define rVDP_INT_LEVEL_CLR                  (0x8018)

#define rVDP_INT_TYPE                       (0x801C)

// EDGE Type
#define rVDP_INT_EDGE_EN                    (0x8020)

#define rVDP_INT_STS                        (0x8024)
    #define bVDP_INT_ERR                    (0x0C0C0C)
    #define bVDP_INT_DONE                   (0x010101)
    #define bVDP_INT_TIME_OVER              (1<<3)
    #define bVDP_INT_BUFF_OVER              (1<<2)  
    #define bVDP_INT_START                  (1<<1)
    #define bVDP_INT_END                    (1<<0)

    


//------------------------------------------------------------------------------
// VDUMP YC Crop
#define rVDP_CROP_EN                        (0x8040)
    #define bVDP_CROP_SYNC_EN               (16)
    #define bVDP_CROP_VSYNC_REGEN_EN        (8)
    #define bVDP_CROP_DATA_EN               (0)
#define rVDP_CROP_H_ST_B_BLK                (0x8044)
#define rVDP_CROP_V_ST_H_END                (0x804C)
#define rVDP_CROP_V_END                     (0x8054)


//------------------------------------------------------------------------------
// YCBCR to RGB
#define rVDP_YCBCR_OFFSET                   (0x8060)
#define rVDP_YCBCR_R_SIGN                   (0x8064)
#define rVDP_YCBCR_R_GAIN_00                (0x8068)
#define rVDP_YCBCR_R_GAIN_01                (0x806C)
#define rVDP_YCBCR_R_LIMIT                  (0x8070)
#define rVDP_YCBCR_G_SIGN                   (0x8074)
#define rVDP_YCBCR_G_GAIN_00                (0x8078)
#define rVDP_YCBCR_G_GAIN_01                (0x807C)
#define rVDP_YCBCR_G_LIMIT                  (0x8080)
#define rVDP_YCBCR_B_SIGN                   (0x8084)
#define rVDP_YCBCR_B_GAIN_00                (0x8088)
#define rVDP_YCBCR_B_GAIN_01                (0x808C)
#define rVDP_YCBCR_B_LIMIT                  (0x8090)


//------------------------------------------------------------------------------
// YC444 to YC422
#define rVDP_YC_MODE                        (0x8098)
    #define bVDP_YC_CHROMA_MODE             (4)
    #define bVDP_YC_OUT_MODE                (0)


//------------------------------------------------------------------------------
// WDMA
#define rVDP_WDMA_CFG                       (0x8100)
    #define bVDP_WDMA_ENDIAN                (16)
    #define bVDP_WDMA_PARSING               (8)
    #define bVDP_WDMA_PACKET_BIT            (0)
#define rVDP_WDMA_STRIDE                    (0x8104)
#define rVDP_WDMA_ADDR                      (0x8108)
#define rVDP_WDMA_BURST                     (0x810C)
#define rVDP_WDMA_LINE                      (0x8110)
    #define bVDP_WDMA_HPIX                  (16)
    #define bVDP_WDMA_VLINE                 (0)


//------------------------------------------------------------------------------
// VDUMP Start Register
#define rVDP_START                          (0x8434)


// VDUMP DEBUG Register
#define rVDP_DBG_FRM_CNT                    (0x8400)
#define rVDP_DBG_LINE_CNT                   (0x8404)
#define rVDP_DBG_PIXEL_CNT                  (0x8408)
#define rVDP_DBG_ERR_STS                    (0x840C)
#define rVDP_DBG_PATTERN_EN                 (0x8430)
#define rVDP_DBG_CROP_VCNT                  (0x8520)
#define rVDP_DBG_CROP_PCNT                  (0x8524)
#define rVDP_DBG_SCAL_VCNT                  (0x8528)
#define rVDP_DBG_SCAL_PCNT                  (0x852C)


#define VDP_DTO_MIN                         0x1000  // 4096










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    BOOL            mInit;
    
    BOOL            mIntEn;
    UINT32          mIntSts;
    UINT32          mDoneFlag;

    UINT32          mInVTOT;
    UINT32          mInHTOT;
    UINT32          mInHBLK;
    UINT32          mInHACT;
    UINT32          mInVACT;

    eVDP_UPDATA_SEL mFrameSel;
    BOOL            mChEn[MAX_OF_VDP_CH];
} tVDP_INFO, *ptVDP_INFO;










/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern void   ncDrv_VDP_GetCropCnt(UINT32* V_CNT, UINT32* P_CNT);
extern void   ncDrv_VDP_GetScalCnt(UINT32* V_CNT, UINT32* P_CNT);
extern void   ncDrv_VDP_GetOutPutSize(UINT32* H_ACT, UINT32* V_ACT);
extern INT32  ncDrv_VDP_GetOutPutDumpSize(eVDP_CH Ch);
extern INT32  ncDrv_VDP_GetOneFrameStatus(eVDP_CH Ch);
extern INT32  ncDrv_VDP_GetLineCnt(eVDP_CH Ch);
extern INT32  ncDrv_VDP_GetPixelCnt(eVDP_CH Ch);
extern INT32  ncDrv_VDP_GetOneFrameErrorStatus(eVDP_CH Ch);

extern INT32  ncDrv_VDP_IntStsClr(ptVDP_INFO ptVDP);
extern INT32  ncDrv_VDP_GetStatus(ptVDP_INFO ptVDP);
extern INT32  ncDrv_VDP_CheckComplete(ptVDP_INFO ptVDP);
extern void   ncDrv_VDP_Stop(void);
extern INT32  ncDrv_VDP_Start(ptVDP_INFO ptVDP);
extern void   ncDrv_VDP_SetOperation(ptVDP_INFO ptVDP, ptVDP_PARAM ptVDPParam);
extern void   ncDrv_VDP_DeInitialize(void);
extern void   ncDrv_VDP_Initialize(void);

#endif  /* __VDP_DRV_H__ */


/* End Of File */

