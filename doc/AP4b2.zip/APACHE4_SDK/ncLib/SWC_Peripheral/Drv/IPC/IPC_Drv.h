/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __IPC_DRV_H__
#define __IPC_DRV_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define rIPC_BASE(Ch)               (APACHE_IPC_BASE + (Ch*0x100000))

#define rIPC_PUSH(Ch,Id)            (*(volatile unsigned int *)(rIPC_BASE(Ch) + 0x30 + (Id*0x100)))
#define rIPC_POP(Ch,Id)             (*(volatile unsigned int *)(rIPC_BASE(Ch) + 0x34 + (Id*0x100)))


#define rIPC_ENQ_LOCK               0x400    
#define rIPC_DEQ_LOCK               0x404   
#define rIPC_FIFO_STS_CLR           0x408
#define rIPC_INTC_MASK              0x430
#define rIPC_INTC_STS_CLR           0x434
#define rIPC_INTC_TERM              0x438
#define rIPC_INTC_WIDTH             0x43C
#define rIPC_INTC_THRE              0x440
#define rIPC_EN                     0x444
#define rIPC_STS                    0x500
#define rIPC_FIFO_CNT               0x504










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern void   ncDrv_IPC_IntClear(eIPC_CH Ch);
extern INT32  ncDrv_IPC_GetStatus(eIPC_CH Ch);
extern INT32  ncDrv_IPC_GetFIFOCnt(eIPC_CH Ch, eFIFO_ID Id);
extern INT32  ncDrv_IPC_GetFIFO(eIPC_CH Ch, eFIFO_ID Id, UINT32* Data);
extern INT32  ncDrv_IPC_SetFIFO(eIPC_CH Ch, eFIFO_ID Id, UINT32 Data);
extern void   ncDrv_IPC_DeInit(eIPC_CH Ch);
extern void   ncDrv_IPC_Init(eIPC_CH Ch, UINT8* Threshold);


#endif  /* __IPC_DRV_H__ */


/* End Of File */

