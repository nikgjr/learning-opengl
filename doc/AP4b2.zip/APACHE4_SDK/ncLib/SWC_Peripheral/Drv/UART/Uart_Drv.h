/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __UART_DRV_H__
#define __UART_DRV_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define rUART_BASE(Ch)          (APACHE_UART_0_BASE + (Ch*0x100000))



//------------------------------------------------------------------------------
// if (rUART_LCR[7] == 1) : bUART_LCR_DLAB
//------------------------------------------------------------------------------
#define rUART_DLL                   0x00        // RxTx : Divisor Latch Low       
#define rUART_DLM                   0x04        // RxTx : Divisor Latch High
                                                //        - SrcClk/(16*DIV)

//------------------------------------------------------------------------------
// if (rUART_LCR[7] == 0) : bUART_LCR_DLAB
//------------------------------------------------------------------------------
#define rUART_RX                    0x00        // Rx   : Receive Buffer Register
#define rUART_TX                    0x00        //   TX : Transmit Buffer Register


#define rUART_IER                   0x04        // RxTx : Interrupt Enable Register
                                                //        - [7:4] : Reserved     
    #define bUART_IER_MSI           (1<<3)      //        -   [3] : Enable Modem status interrupt              
    #define bUART_IER_RLSI          (1<<2)      //        -   [2] : Enable receiver line status interrupt
    #define bUART_IER_TX            (1<<1)      //        -   [1] : Enable Transmitter fifo empty interrupt
    #define bUART_IER_RX            (1<<0)      //        -   [0] : Enable Received data available interrupt


#define rUART_IIR                   0x08        // Rx   : Interrupt ID Register 
                                                //        - [7:4] : Reserved     
    #define bUART_IIR_TOI           (6<<1)      //        - [3:1] : Receive time out interrupt 
    #define bUART_IIR_RLSI          (3<<1)      //        - [3:1] : Receiver line status interrupt    
    #define bUART_IIR_RDI           (2<<1)      //        - [3:1] : Receiver data interrupt  
    #define bUART_IIR_THRI          (1<<1)      //        - [3:1] : Transmitter holding register empty  
    #define bUART_IIR_MSI           (0<<1)      //        - [3:1] : Modem status interrupt     
    #define bUART_IIR_INT           (1<<0)      //        -   [0] : interrupt Pending


#define rUART_FCR                   0x08        //   Tx : FIFO Control Register 
    #define bUART_FCR_TRIGGER_MASK	(3<<6)      //        - [7:6] : Mask for the FIFO trigger range
    #define bUART_FCR_TRIGGER_14    (3<<6)      //        - [7:6] : FIFO trigger set at 14B 
    #define bUART_FCR_TRIGGER_8     (2<<6)      //        - [7:6] : FIFO trigger set at 8B 
    #define bUART_FCR_TRIGGER_4     (1<<6)      //        - [7:6] : FIFO trigger set at 4B
    #define bUART_FCR_TRIGGER_1     (0<<6)      //        - [7:6] : FIFO trigger set at 1B 
                                                //        - [5:3] : Reserved   
    #define bUART_FCR_CLEAR_XMIT    (1<<2)      //        -   [2] : Clear the XMIT FIFO 
    #define bUART_FCR_CLEAR_RCVR    (1<<1)      //        -   [1] : Clear the RCVR FIFO        
                                                //        -   [0] : Reserved                             


#define rUART_LCR                   0x0C        // RxTx : Line Control Register     
    #define bUART_LCR_DLAB          (1<<7)      //        -   [7] : Divisor latch access bit                
    #define bUART_LCR_SBC           (1<<6)      //        -   [6] : Set break control                           
    #define bUART_LCR_SPAR          (1<<5)      //        -   [5] : Stick parity (?)                      
    #define bUART_LCR_EPAR          (1<<4)      //        -   [4] : Even parity select                       
    #define bUART_LCR_PARITY        (1<<3)      //        -   [3] : Parity Enable                           
    #define bUART_LCR_STOP          (1<<2)      //        -   [2] : Stop bits: 0=1 stop bit, 1= 2 stop bits 
    #define bUART_LCR_WLEN8         (3<<0)      //        - [1:0] : Wordlength: 8 bits
    #define bUART_LCR_WLEN7         (2<<0)      //        - [1:0] : Wordlength: 7 bits
    #define bUART_LCR_WLEN6         (1<<0)      //        - [1:0] : Wordlength: 6 bits
    #define bUART_LCR_WLEN5         (0<<0)      //        - [1:0] : Wordlength: 5 bits                       
  

#define rUART_MCR                   0x10        //   Tx : Modem Control Register 
                                                //        - [7:5] : Reserved  
    #define bUART_MCR_LOOP          (1<<4)      //        -   [4] : Enable loopback test mode                 
    #define bUART_MCR_OUT2          (1<<3)      //        -   [3] : Out2 complement                       
    #define bUART_MCR_OUT1          (1<<2)      //        -   [2] : Out1 complement                           
    #define bUART_MCR_RTS           (1<<1)      //        -   [1] : RTS complement                             
    #define bUART_MCR_DTR           (1<<0)      //        -   [0] : DTR complement 


#define rUART_LSR                   0x14        // Rx   : Line Status Register    
                                                //        -   [7] :    
    #define bUART_LSR_TEMT          (1<<6)      //        -   [6] : Transmitter empty                       
    #define bUART_LSR_THRE          (1<<5)      //        -   [5] : Transmit-hold-register empty             
    #define bUART_LSR_BI            (1<<4)      //        -   [4] : Break interrupt indicator                  
    #define bUART_LSR_FE            (1<<3)      //        -   [3] : Frame error indicator                      
    #define bUART_LSR_PE            (1<<2)      //        -   [2] : Parity error indicator                     
    #define bUART_LSR_OE            (1<<1)      //        -   [1] : Overrun error indicator                   
    #define bUART_LSR_DR            (1<<0)      //        -   [0] : Receiver data ready


#define rUART_MSR                   0x18        // Rx   : Modem Status Register          
#define rUART_SCR                   0x1C        // RxTx : Scratch Register                             


#define rUART_EN                    0x20        //   Tx : UART enable
                                                //        - [7:1] : Reserved  
    #define bUART_EN                (1<<0)      //        -   [0] : Uart Enable


#define rUART_TC                    0x24        // Rx   : Transmisster FIFO count
                                                //        - [7:5] : Reserved  
    #define bUART_TC_MASK           (0x1F)      //        - [4:0] : FIFO Count


#define rUART_RC                    0x28        // Rx   : Receiver FIFO count
                                                //        - [7:5] : Reserved  
    #define bUART_RC_MASK           (0x1F)      //        - [4:0] : FIFO Count










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

extern INT32 ncDrv_UART_GetFIFOCnt(eUART_CH Ch);
extern INT32 ncDrv_UART_GetSts(eUART_CH Ch);

extern void ncDrv_UART_PutChar(eUART_CH Ch, UINT8 Data);
extern INT8 ncDrv_UART_GetChar(eUART_CH Ch);

extern void ncDrv_UART_PutStr(eUART_CH Ch, char *str);

extern void ncDrv_UART_SetBaudrate(eUART_CH Ch, UINT32 RefClk, UINT32 BaudRate);
extern void ncDrv_UART_Deinitialize(eUART_CH Ch);
extern void ncDrv_UART_Initialize(eUART_CH Ch, tUART_PARAM *ptUART, UINT32 RefClk);


#endif  /* __UART_DRV_H__ */


/* End Of File */

