/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __TIMER_DRV_H__
#define __TIMER_DRV_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
 * REGISTER STRUCTURE
 */
 
#define rTIMER0_BASE                APACHE_TIMER0_BASE
#define rTIMER1_BASE                APACHE_TIMER1_BASE

#define rTIMER_CSR                  (0x000)
#define rTIMER_LOAD                 (0x004)
#define rTIMER_PRESCALER            (0x008)
#define rTIMER_OVER                 (0x00C)
#define rTIMER_UNDER                (0x010)
#define rTIMER_CVAL                 (0x014)










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncDrv_TIMER_GetIntSts(eTIMER_CH Ch);
extern void  ncDrv_TIMER_ReLoad(eTIMER_CH Ch);
extern void  ncDrv_TIMER_Start(eTIMER_CH Ch);
extern void  ncDrv_TIMER_Stop(eTIMER_CH Ch);
extern INT32 ncDrv_TIMER_Init(eTIMER_CH Ch, ptTIMER_PARAM ptTIMER, UINT32 RefClk);


#endif  /* __TIMER_DRV_H__ */


/* End Of File */

