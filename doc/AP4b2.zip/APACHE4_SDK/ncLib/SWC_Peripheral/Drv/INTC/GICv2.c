/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : GICv2.c
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    : ARM Generic Interrupt Controller
*             Architecture version 2.0 ( GICv2 ), ARM IHI 0048B.b ID072613
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "GICv2.h"
#include "INTC_Drv.h"


/*
********************************************************************************
*               LOCAL DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL TYPEDEF
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               GLOBAL VARIABLE DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               IMPORTED FUNCTION DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               LOCAL FUNCTION PROTOTYPES
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

/******************************************************************************
 * Distributor function control
 *****************************************************************************/

/*
 * Offset  : 0x0000
 * Purpose : Enables the forwarding of pending interrupts from the Distributor to
 *           the CPU interfaces.
 **/

void ncDrv_GIC_DIST_SetControl(UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, GICD_CTLR) = value;
}


UINT32 ncDrv_GIC_DIST_GetControl(void)
{
    return REGRW32(rGIC_DIST_BASE, GICD_CTLR);
}


/*
 * Offset  : 0x0004
 * Purpose : Provides information about the configuration of the GIC. It indicates.
 **/

UINT32 ncDrv_GIC_DIST_GetIntContolType(void)
{
    return REGRW32(rGIC_DIST_BASE, GICD_TYPER);
}


/*
 * Offset  : 0x0008
 * Purpose : Provides information about the implementer and revision of the Distributor.
 **/

UINT32 ncDrv_GIC_DIST_GetImpIdentification(void)
{
    return REGRW32(rGIC_DIST_BASE, GICD_IIDR);
}


/*
 * Offset  : 0x0080 ~ 0x00BC
 * Purpose : The GICD_IGROUPR registers provide a status bit for each interrupt supported
 *           by the GIC. Each bit controls whether the corresponding interrupt is in Group 0
 *           or Group 1.
 **/

void ncDrv_GIC_DIST_SetIntGroup(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_IGROUPRn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetIntGroup(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_IGROUPRn + offset));
}


/*
 * Offset  : 0x0100 ~ 0x013C
 * Purpose : The GICD_ISENABLERs provide a Set-enable bit for each interrupt supported by the GIC.
 *           Writing 1 to a Set-enable bit enables forwarding of the corresponding interrupt from the
 *           Distributor to the CPU interfaces. Reading a bit identifies whether the interrupt is enabled.
 **/

void ncDrv_GIC_DIST_SetIntSetEnable(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_ISENABLERn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetIntSetEnable(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_ISENABLERn + offset));
}


/*
 * Offset  : 0x0180 ~ 0x01BC
 * Purpose : The GICD_ICENABLERs provide a Clear-enable bit for each interrupt supported by the
 *           GIC. Writing 1 to a Clear-enable bit disables forwarding of the corresponding interrupt from
 *           the Distributor to the CPU interfaces. Reading a bit identifies whether the interrupt is
 *           enabled.
 **/

void ncDrv_GIC_DIST_SetIntClearEnable(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_ICENABLERn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetIntClearEnable(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_ICENABLERn + offset));
}


/*
 * Offset  : 0x0200 ~ 0x023C
 * Purpose : The GICD_ISPENDRs provide a Set-pending bit for each interrupt supported by the GIC.
 *           Writing 1 to a Set-pending bit sets the status of the corresponding peripheral interrupt to
 *           pending. Reading a bit identifies whether the interrupt is pending.
 **/

void ncDrv_GIC_DIST_SetIntSetPending(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_ISPENDRn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetIntSetPending(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_ISPENDRn + offset));
}


/*
 * Offset  : 0x0280 ~ 0x02BC
 * Purpose : The GICD_ICPENDRs provide a Clear-pending bit for each interrupt supported by the GIC.
 *           Writing 1 to a Clear-pending bit clears the pending state of the corresponding peripheral
 *           interrupt. Reading a bit identifies whether the interrupt is pending.
 **/

void ncDrv_GIC_DIST_SetIntClearPending(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_ICPENDRn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetIntClearPending(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_ICPENDRn + offset));
}


/*
 * Offset  : 0x0300 ~ 0x033C
 * Purpose : The GICD_ISACTIVERs provide a Set-active bit for each interrupt that the GIC supports.
 *           Writing to a Set-active bit Activates the corresponding interrupt. These registers are used
 *           when preserving and restoring GIC state.
 **/

void ncDrv_GIC_DIST_SetIntSetActive(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_ISACTIVERn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetIntSetActive(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_ISACTIVERn + offset));
}


/*
 * Offset  : 0x0380 ~ 0x03BC
 * Purpose : The GICD_ICACTIVERs provide a Clear-active bit for each interrupt that the GIC
 *           supports. Writing to a Clear-active bit Deactivates the corresponding interrupt. These
 *           registers are used when preserving and restoring GIC state.
 **/

void ncDrv_GIC_DIST_SetIntClearActive(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_ICACTIVERn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetIntClearActive(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_ICACTIVERn + offset));
}


/*
 * Offset  : 0x0400 ~ 0x05FC
 * Purpose : The GICD_IPRIORITYRs provide an 8-bit priority field for each interrupt supported by the
 *           GIC. This field stores the priority of the corresponding interrupt.
 **/

void ncDrv_GIC_DIST_SetIntPriority(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_IPRIORITYRn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetIntPriority(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_IPRIORITYRn + offset));
}


/*
 * Offset  : 0x0800 ~ 0x09FC
 * Purpose : The GICD_ITARGETSRs provide an 8-bit CPU targets field for each interrupt supported
 *           by the GIC. This field stores the list of target processors for the interrupt. That is, it holds
 *           the list of CPU interfaces to which the Distributor forwards the interrupt if it is asserted and
 *           has sufficient priority.
 **/

void ncDrv_GIC_DIST_SetIntProcTarget(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_ITARGETSRn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetIntProcTarget(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_ITARGETSRn + offset));
}


/*
 * Offset  : 0x0C00 ~ 0x0C7C
 * Purpose : The GICD_ICFGRs provide a 2-bit Int_config field for each interrupt supported by the GIC.
 *           This field identifies whether the corresponding interrupt is edge-triggered or level-sensitive,
 **/

void ncDrv_GIC_DIST_SetIntConfig(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_ICFGRn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetIntConfig(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_ICFGRn + offset));
}


/*
 * Offset  : 0x0D00
 * Purpose : Private peripheral interrupt status register.
 **/

UINT32 ncDrv_GIC_DIST_GetPPIStatus(void)
{
    return REGRW32(rGIC_DIST_BASE, GICD_PPISR);
}


/*
 * Offset  : 0x0D04 ~ 0x0D3C
 * Purpose : Shared Peripheral interrupt status register.
 **/

UINT32 ncDrv_GIC_DIST_GetSPIStatus(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_SPISRn + offset));
}


/*
 * Offset  : 0x0E00 ~ 0x0EFC
 * Purpose : The GICD_NSACRs enable Secure software to permit Non-secure software on a particular
 *           processor to create and manage Group 0 interrupts. They provide an access control for each
 *           implemented interrupt.
 **/

void ncDrv_GIC_DIST_SetNonSecureAccessControl(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_NSACRn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetNonSecureAccessControl(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_NSACRn + offset));
}


/*
 * Offset  : 0x0F00
 * Purpose : Controls the generation of SGIs.
 **/

void ncDrv_GIC_DIST_SetSGIControl(UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, GICD_SGIR) = value;
}


/*
 * Offset  : 0x0F10 ~ 0x0F1C
 * Purpose : The GICD_CPENDSGIRs provide a clear-pending bit for each supported SGI and source
 *           processor combination. When a processor writes a 1 to a clear-pending bit, the pending state
 *           of the corresponding SGI for the corresponding source processor is removed, and no longer
 *           targets the processor performing the write. Writing a 0 has no effect. Reading a bit identifies
 *           whether the SGI is pending, from the corresponding source processor, on the reading
 *           processor.
 **/

void ncDrv_GIC_DIST_SetSGIClearPending(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_CPENDSGIRn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetSGIClearPending(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_CPENDSGIRn + offset));
}


/*
 * Offset  : 0x0F20 ~ 0x0F2C
 * Purpose : The GICD_SPENDSGIRn registers provide a set-pending bit for each supported SGI and
 *           source processor combination. When a processor writes a 1 to a set-pending bit, the pending
 *           state is applied to the corresponding SGI for the corresponding source processor. Writing a
 *           0 has no effect. Reading a bit identifies whether the SGI is pending, from the corresponding
 *           source processor, on the reading processor.
 **/

void ncDrv_GIC_DIST_SetSGISetPending(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_DIST_BASE, (GICD_SPENDSGIRn + offset)) = value;
}


UINT32 ncDrv_GIC_DIST_GetSGISetPending(UINT32 offset)
{
    return REGRW32(rGIC_DIST_BASE, (GICD_SPENDSGIRn + offset));
}


/*
 * Offset  : 0x0FD0 ~ 0x0FFC
 * Purpose : This architecture specification defines offsets 0xFD0 - 0xFFC in the Distributor register map
 *           as a read-only identification register space. Table 4-25 shows the architecturally-required
 *           implementation of the identification register space.
 **/

void ncDrv_GIC_DIST_GetPeripheralID(UINT32 *PID0, UINT32 *PID4)
{
    int i;

    // 0x0FE0 ~ 0x0FEC ARM-defined DevID, ArchID, UsesJEPcode, Revision field.
    // 0x0FD0 ~ 0x0FDC ARM-defined ContinuationCode field.

    *PID0 = 0;
    *PID4 = 0;

    for(i = 0; i < 0x10; i+=4)
    {
        *PID0 |= (REGRW32(rGIC_DIST_BASE, GICD_PIDRn+(0x10+i)) & 0xFF) << (i*2);
        *PID4 |= (REGRW32(rGIC_DIST_BASE, GICD_PIDRn+i) & 0xFF) << (i*2);
    }
}


UINT32 ncDrv_GIC_DIST_GetComponentID(void)
{
    UINT32 ComID = 0;

    // ARM-defined fixed values for the preamble for component discovery.

    ComID  = REGRW32(rGIC_DIST_BASE, GICD_CIDRn) & 0xFF;
    ComID |= (REGRW32(rGIC_DIST_BASE, GICD_CIDRn+0x4) & 0xFF) << 8;
    ComID |= (REGRW32(rGIC_DIST_BASE, GICD_CIDRn+0x8) & 0xFF) << 16;
    ComID |= (REGRW32(rGIC_DIST_BASE, GICD_CIDRn+0xC) & 0xFF) << 24;

    return ComID;
}


/******************************************************************************
 * CPU Interface function control
 *****************************************************************************/

/*
 * Offset  : 0x000
 * Purpose : Enables the signaling of interrupts by the CPU interface to the connected processor, and
 *           provides additional top-level control of the CPU interface. In a GICv2 implementation, this
 *           includes control of the end of interrupt (EOI) behavior.
 **/

void ncDrv_GIC_CPUI_SetControl(UINT32 value)
{
    REGRW32(rGIC_CPUI_BASE, GICC_CTLR) = value;
}


UINT32 ncDrv_GIC_CPUI_GetControl(void)
{
    return REGRW32(rGIC_CPUI_BASE, GICC_CTLR);
}


/*
 * Offset  : 0x004
 * Purpose : Provides an interrupt priority filter. Only interrupts with higher priority than the value in this
 *           register are signaled to the processor.
 **/

void ncDrv_GIC_CPUI_SetIntPriorityMask(UINT32 value)
{
    REGRW32(rGIC_CPUI_BASE, GICC_PMR) = value;
}


UINT32 ncDrv_GIC_CPUI_GetIntPriorityMask(void)
{
    return REGRW32(rGIC_CPUI_BASE, GICC_PMR);
}


/*
 * Offset  : 0x008
 * Purpose : The register defines the point at which the priority value fields split into two parts, the group
 *           priority field and the subpriority field. The group priority field is used to determine interrupt
 *           preemption.
 **/

void ncDrv_GIC_CPUI_SetBinaryPoint(UINT32 value)
{
    REGRW32(rGIC_CPUI_BASE, GICC_BPR) = value;
}


UINT32 ncDrv_GIC_CPUI_GetBinaryPoint(void)
{
    return REGRW32(rGIC_CPUI_BASE, GICC_BPR);
}


/*
 * Offset  : 0x00C
 * Purpose : The processor reads this register to obtain the interrupt ID of the signaled interrupt. This
 *           read acts as an acknowledge for the interrupt.
 **/

UINT32 ncDrv_GIC_CPUI_GetIntAcknowledge(void)
{
    return REGRW32(rGIC_CPUI_BASE, GICC_IAR);
}


/*
 * Offset  : 0x0010
 * Purpose : A processor writes to this register to inform the CPU interface either.
 **/

void ncDrv_GIC_CPUI_SetEndOfInterrupt(UINT32 value)
{
    REGRW32(rGIC_CPUI_BASE, GICC_EOIR) = value;
}


/*
 * Offset  : 0x0014
 * Purpose : Indicates the Running priority of the CPU interface.
 **/

UINT32 ncDrv_GIC_CPUI_GetRunningPrioriry(void)
{
    return REGRW32(rGIC_CPUI_BASE, GICC_RPR);
}


/*
 * Offset  : 0x0018
 * Purpose : Indicates the Interrupt ID, and processor ID if appropriate, of the highest priority pending
 *           interrupt on the CPU interface.
 **/

UINT32 ncDrv_GIC_CPUI_GetHighPriorityPendingInterrupt(void)
{
    return REGRW32(rGIC_CPUI_BASE, GICC_HPPIR);
}


/*
 * Offset  : 0x001C
 * Purpose : A Binary Point Register for handling Group 1 interrupts.
 *           The reset value of this register is defined as (minimum GICC_BPR.Binary point + 1),
 *           resulting in a permitted range of 0x1 - 0x4 .
 **/

void ncDrv_GIC_CPUI_SetAliasedBinaryPoint(UINT32 value)
{
    REGRW32(rGIC_CPUI_BASE, GICC_ABPR) = value;
}


UINT32 ncDrv_GIC_CPUI_GetAliasedBinaryPoint(void)
{
    return REGRW32(rGIC_CPUI_BASE, GICC_ABPR);
}


/*
 * Offset  : 0x0020
 * Purpose : An Interrupt Acknowledge register for handling Group 1 interrupts.
 *           The processor reads this register to obtain the interrupt ID of the signaled Group 1 interrupt.
 *           This read acts as an acknowledge for the interrupt.
 **/

UINT32 ncDrv_GIC_CPUI_GetAliasedIntAcknowledge(void)
{
    return REGRW32(rGIC_CPUI_BASE, GICC_AIAR);
}


/*
 * Offset  : 0x0024
 * Purpose : An end of interrupt register for handling Group 1 interrupts.
 *           When GICC_CTLR.AckCtl is set to 0, a write to this register performs priority drop for the
 *           identified Group 1 interrupt, and if the appropriate GICC_CTLR EOImode bit is set to 0,
 *           also deactivates the interrupt.
 **/

void ncDrv_GIC_CPUI_SetAliasedEndOfInterrupt(UINT32 value)
{
    REGRW32(rGIC_CPUI_BASE, GICC_AEOIR) = value;
}


/*
 * Offset  : 0x0028
 * Purpose : Provides a Highest Priority Pending Interrupt register for the handling of Group 1 interrupts.
 *           If the highest priority pending interrupt on the CPU interface is a Group 1 interrupt, returns
 *           the interrupt ID of that interrupt. Otherwise, returns a spurious interrupt ID of 1023.
 **/

UINT32 ncDrv_GIC_CPUI_GetAliasedHighPriorityPendingInterrupt(void)
{
    return REGRW32(rGIC_CPUI_BASE, GICC_AHPPIR);
}


/*
 * Offset  : 0x00D0
 * Purpose : These are IMPLEMENTATION DEFINED registers that provide support for preserving and
 *           restoring the active priority in power-management implementations.
 **/

void ncDrv_GIC_CPUI_SetActivePriorities(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_CPUI_BASE, (GICC_APR0n + offset)) = value;
}


UINT32 ncDrv_GIC_CPUI_GetActivePriorities(UINT32 offset)
{
    return REGRW32(rGIC_CPUI_BASE, (GICC_APR0n + offset));
}


/*
 * Offset  : 0x00E0
 * Purpose : These are IMPLEMENTATION DEFINED registers that provide support for preserving and
 *           restoring the active priority in power-management implementation. These are separate
 *           registers for Group 1 interrupts.
 **/

void ncDrv_GIC_CPUI_SetNonSecureActivePriorities(UINT32 offset, UINT32 value)
{
    REGRW32(rGIC_CPUI_BASE, (GICC_NSAPR0n + offset)) = value;
}


UINT32 ncDrv_GIC_CPUI_GetNonSecureActivePriorities(UINT32 offset)
{
    return REGRW32(rGIC_CPUI_BASE, (GICC_NSAPR0n + offset));
}


/*
 * Offset  : 0x00FC
 * Purpose : Provides information about the implementer and revision of the CPU interface.
 **/

UINT32 ncDrv_GIC_CPUI_GetInterfaceID(void)
{
    return REGRW32(rGIC_CPUI_BASE, GICC_IIDR);
}


/*
 * Offset  : 0x1000
 * Purpose : When interrupt priority drop is separated from interrupt deactivation, as described in
 *           Priority drop and interrupt deactivation on page 3-38, a write to this register deactivates the
 *           specified interrupt.
 **/

void ncDrv_GIC_CPUI_SetDeactiveInterrupt(UINT32 value)
{
    REGRW32(rGIC_CPUI_BASE, GICC_DIR) = value;
}


/******************************************************************************
 * GICv2 Driver function control
 *****************************************************************************/

void ncDrv_GIC_DistIf_Enable(void)
{
    UINT32 value = 0;

    value = (CTLR_ENABLE_G0 | CTLR_ENABLE_G1);

    ncDrv_GIC_DIST_SetControl(value);
}


void ncDrv_GIC_DistIf_Disable(void)
{
    UINT32 value = 0;

    value &= ~(CTLR_ENABLE_G0 | CTLR_ENABLE_G1);

    ncDrv_GIC_DIST_SetControl(value);
}


void ncDrv_GIC_CpuIf_Enable(void)
{
    UINT32 value = 0;

    value = CTLR_ENABLE_G0 | CTLR_ENABLE_G1 | FIQ_EN_BIT;
    //value |= FIQ_BYP_DIS_GRP1 | FIQ_BYP_DIS_GRP0 | IRQ_BYP_DIS_GRP1 | IRQ_BYP_DIS_GRP0;

    ncDrv_GIC_CPUI_SetControl(value);
}


void ncDrv_GIC_CpuIf_Disable(void)
{
    UINT32 value = 0;

    value &= ~(CTLR_ENABLE_G0 | CTLR_ENABLE_G1 | FIQ_EN_BIT);

    ncDrv_GIC_CPUI_SetControl(value);
}


void ncDrv_GIC_EnableIrq(UINT32 irq)
{
    UINT32 regOffset, bitOffset;

    regOffset = (irq / BIT_32_PER_REG) << 2;
    bitOffset = irq % BIT_32_PER_REG;

    ncDrv_GIC_DIST_SetIntSetEnable(regOffset, (1 << bitOffset));
}


void ncDrv_GIC_DisableIrq(UINT32 irq)
{
    UINT32 regOffset, bitOffset;

    regOffset = (irq / BIT_32_PER_REG) << 2;
    bitOffset = irq % BIT_32_PER_REG;

    ncDrv_GIC_DIST_SetIntClearEnable(regOffset, (1 << bitOffset));
}


void ncDrv_GIC_AllDisableIrqs(void)
{
    UINT32 i, regOffset, bitOffset;

    for(i = IRQS_START; i < IRQS_TOTAL; i++)
    {
        regOffset = (i / BIT_32_PER_REG) << 2;
        bitOffset = i % BIT_32_PER_REG;

        ncDrv_GIC_DIST_SetIntClearEnable(regOffset, (1 << bitOffset));
    }
}


void ncDrv_GIC_ClearPendingIrq(UINT32 irq)
{
    UINT32 regOffset, bitOffset;

    regOffset = (irq / BIT_32_PER_REG) << 2;
    bitOffset = irq % BIT_32_PER_REG;

    ncDrv_GIC_DIST_SetIntClearPending(regOffset, (1 << bitOffset));
}


void ncDrv_GIC_AllClearPendingIrqs(void)
{
    UINT32 i, regOffset, bitOffset;

    for(i = IRQS_START; i < IRQS_TOTAL; i++)
    {
        regOffset = (i / BIT_32_PER_REG) << 2;
        bitOffset = i % BIT_32_PER_REG;

        ncDrv_GIC_DIST_SetIntClearPending(regOffset, (1 << bitOffset));
    }
}


void ncDrv_GIC_SetIrqCPUTarget(UINT32 irq, UINT32 value)
{
    UINT32 regOffset, bitOffset, readTarget;

    regOffset = (irq / BIT_4_PER_REG) << 2;

    bitOffset = irq % BIT_4_PER_REG;
    bitOffset *= BIT_8_FIELD_WIDTH;

    value &= BIT_8_FIELD_MASK;

    readTarget = ncDrv_GIC_DIST_GetIntProcTarget(regOffset);

    readTarget &= ~(0xFF << bitOffset);
    readTarget |= (value << bitOffset);

    ncDrv_GIC_DIST_SetIntProcTarget(regOffset, readTarget);
}


void ncDrv_GIC_SetIntTrigType(UINT32 irq, UINT32 value)
{
    UINT32 regOffset, bitOffset, readCfg;

#if 1 // Only Apache4 (test code)
    // Note that the following code must be enabled after FPGQ_DB_r1609.
    UINT32 regValue;
    UINT32 setValue = 0;

    if((value == GIT_1_N_EDGE) || (value == GIT_N_N_EDGE))
        setValue = 1;

    if(irq < IRQ_NUM_ISP0)
    {
        regOffset = 0x140;
        bitOffset = irq - IRQ_NUM_TIMER0;
    }
    else if(irq < IRQ_NUM_IPC0)
    {
        regOffset = 0x144;
        bitOffset = irq - IRQ_NUM_ISP0;
    }
    else
    {
        regOffset = 0x148;
        bitOffset = irq - IRQ_NUM_IPC0;
    }

    regValue = REGRW32(APACHE_SYSCON_BASE, regOffset);
    regValue &= ~(1<<bitOffset);
    if(setValue)
        regValue |= (setValue<<bitOffset);
    REGRW32(APACHE_SYSCON_BASE, regOffset) = regValue;
#endif

    regOffset = (irq / BIT_16_PER_REG) << 2;

    bitOffset = irq % BIT_16_PER_REG;
    bitOffset *= BIT_2_FIELD_WIDTH;

    value &= BIT_2_FIELD_MASK;

    readCfg = ncDrv_GIC_DIST_GetIntConfig(regOffset);

    readCfg &= ~(0x03 << bitOffset);
    readCfg |= (value << bitOffset);

    ncDrv_GIC_DIST_SetIntConfig(regOffset, readCfg);
}


void ncDrv_GIC_SetPriorityLevel(UINT32 irq, UINT32 value)
{
    UINT32 regOffset, bitOffset, readPrio;

    regOffset = (irq / BIT_4_PER_REG) << 2;

    bitOffset = irq % BIT_4_PER_REG;
    bitOffset *= BIT_8_FIELD_WIDTH;

    value &= BIT_8_FIELD_MASK;

    readPrio = ncDrv_GIC_DIST_GetIntPriority(regOffset);

    readPrio &= ~(0xFF << bitOffset);
    readPrio |= (value << bitOffset);

    ncDrv_GIC_DIST_SetIntPriority(regOffset, readPrio);
}


void ncDrv_GIC_SetGrp0EndOfIntID(UINT32 cpuId, UINT32 eoiId)
{
    UINT32 value = 0;

    value = (cpuId & 0x07) << GICC_CPUID_SHIFT;
    value |= (eoiId & 0x3FF) << GICC_INTID_SHIFT;

    ncDrv_GIC_CPUI_SetEndOfInterrupt(value);
}


void ncDrv_GIC_SetGrp1EndOfIntID(UINT32 cpuId, UINT32 eoiId)
{
    UINT32 value = 0;

    value = (cpuId & 0x07) << GICC_CPUID_SHIFT;
    value |= (eoiId & 0x3FF) << GICC_INTID_SHIFT;

    ncDrv_GIC_CPUI_SetAliasedEndOfInterrupt(value);
}


void ncDrv_GIC_SetIntTypeGroup(UINT32 intId, UINT32 group)
{
    UINT32 value;
    UINT32 regOffset;
    UINT32 bitOffset;

    regOffset = (intId / BIT_32_PER_REG) << 2;
    bitOffset = intId % BIT_32_PER_REG;

    value = ncDrv_GIC_DIST_GetIntGroup(regOffset);

    if(group == GICV2_INTR_GROUP0)
    {
        value &= ~(1 << bitOffset);
    }
    else
    {
        value |= (1 << bitOffset);
    }

    ncDrv_GIC_DIST_SetIntGroup(regOffset, value);
}


void ncDrv_GIC_SetSGITrigger(UINT32 irq)
{
    UINT32 SgiIntID = 0;

    SgiIntID = (0x2<<24)|(irq<<0);

    ncDrv_GIC_DIST_SetSGIControl(SgiIntID);
}


void ncDrv_GIC_GetInformation(tGIC_ID *Gic)
{
    UINT32 Dist_PID0, Dist_PID4;

    ncDrv_GIC_DIST_GetPeripheralID(&Dist_PID0, &Dist_PID4);

    Gic->Dist_PeriID0 = Dist_PID0;
    Gic->Dist_PeriID4 = Dist_PID4;

    Gic->Dist_CompID = ncDrv_GIC_DIST_GetComponentID();
    Gic->CPU_IdentID = ncDrv_GIC_CPUI_GetInterfaceID();
}


/* End Of File */
