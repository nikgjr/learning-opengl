/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : INTC_Drv.h
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note    :
*
********************************************************************************
*/

#ifndef __INTC_DRV_H__
#define __INTC_DRV_H__


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

/*
 * Interrupt number value
 */

#define IRQS_TOTAL              (96 + 32)   // Total interrupt source number
#define IRQS_START              32          // Interrupt source start number


/*
 * CPU interrupt type value
 */
#define INTR_FIQ                0       // Group 0
#define INTR_IRQ                1       // Group 1


/*
 * GICv2 can only target up to 8 PEs
 */
#define GICV2_MAX_TARGET_PE     8

#define CPU_TARGET_IF0          0x01    // DCLS Core   - one CPU interface
#define CPU_TARGET_IF1          0x02    // DCLS Core   - two CPU interface
#define CPU_TARGET_IF2          0x04    // Single Core - three CPU interface
#define CPU_TARGET_IF3          0x08    // DSP Core    - four CPU interface
//#define CPU_TARGET_IF4          0x10    // five CPU interface
//#define CPU_TARGET_IF5          0x20    // six CPU interface
//#define CPU_TARGET_IF6          0x40    // seven CPU interface
//#define CPU_TARTET_IF7          0x80    // eight CPU interface
#define CPU_TARGET_IF02         0x05    // one & three CPU interface
#define CPU_TARGET_IF03         0x09    // one & four CPU interface
#define CPU_TARGET_IF23         0x0C    // three & four CPU interface
#define CPU_TARGET_IF023        0x0D    // one & three & four CPU interface







/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
 * Enforce ARM recommendation to manage priority values such that group1 interrupts
 * always have a lower priority than group0 interrupts.
 * Note, lower numerical values are higher priorities so the comparison checks below
 * are reversed from what might be expected.
 */

typedef enum
{
    INTC_PRIO_LOW = 0xFE,
    INTC_PRIO_MIDDLE = 0xF0,
    INTC_PRIO_HIGH = 0x80,

    MAX_OF_INTC_PRIO_LEVEL
} eINTC_PRIO_LEVEL;


/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/


/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern void ncDrv_INTC_RegisterHandler(UINT32 nIntNum, PrHandler pHandler);
extern void ncDrv_INTC_UnRegisterHandler(UINT32 nIntNum);
extern void ncDrv_INTC_InitIntHandler(void);
extern void ncDrv_INTC_UserHandler(UINT32 nIntNum);

extern void ncDrv_INTC_HaltHandler(void);
extern void ncDrv_INTC_IrqHandler(void);
extern void ncDrv_INTC_FiqHandler(void);

extern INT32 ncDrv_INTC_Initialize(void);
extern INT32 ncDrv_INTC_Deinitialize(void);


#endif  /* __INTC_DRV_H__ */


/* End Of File */

