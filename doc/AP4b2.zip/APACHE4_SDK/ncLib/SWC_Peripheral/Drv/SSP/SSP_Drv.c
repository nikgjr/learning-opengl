/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "SSP_Drv.h"










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

static BOOL ncDrv_SSP_TimeOut(UINT32 mSec)
{
    BOOL ret = FALSE;       
    static volatile UINT32 sSSP_TimeOutMsec = 0;  

    if(mSec > 0)
    {
        if(sSSP_TimeOutMsec == 0)
        {
            // Set TimeOut : SystemTick(msec) + TargetMsec;
            sSSP_TimeOutMsec = nc_get_msec(1) + mSec;
        }
        else
        {
            // Timeout Check. 
            if( nc_get_msec(0) > sSSP_TimeOutMsec)
            {
                ret = TRUE;
                sSSP_TimeOutMsec = 0;
            }
        }
    }
    else
    {
        sSSP_TimeOutMsec = 0;
    }
    
    return ret;
}


INT32 ncDrv_SSP_WaitBusIsBusy(eSSP_CH Ch, INT8* Str)
{
    INT32 Ret = NC_SUCCESS;
    UINT32 TimeOut = SSP_WAIT_TIMEOUT;

    while(REGRW32(rSSP_BASE(Ch), rSSP_CR1)&bSSP_CR1_BUSY)
    {
        if(ncDrv_SSP_TimeOut(TimeOut))
        {
            DEBUGMSG_SDK(MSGERR, "[SSP_Drv] Error, SSP_%d Time Out(%dms) - %s\n", Ch, TimeOut, Str);
            Ret = NC_FAILURE;
            break;
        }
    }
    ncDrv_SSP_TimeOut(0);

    return Ret;
}


void ncDrv_SSP_SetDMAMode(eSSP_CH Ch, UINT8 rwMode)
{
    UINT32 Reg;

    Reg = REGRW32(rSSP_BASE(Ch), rSSP_CR0);
    Reg &= ~(1<<8);
    Reg |= (rwMode<<8);
    REGRW32(rSSP_BASE(Ch), rSSP_CR0) = Reg;

}


INT32 ncDrv_SSP_GetIntSts(eSSP_CH Ch, eSSP_MODE Mode)
{
    INT32 Ret;
    
    if(Mode == SSP_MODE_MASTER)
        Ret = (1<<0);
    else
        Ret = (1<<1);

    return Ret;
}


void ncDrv_SSP_SetBitRate(eSSP_CH Ch, UINT32 BitRate, UINT32 InClk)
{
    UINT32 Div = 2;
    UINT32 Sampling;

    while(1)
    {
        Sampling = (InClk/Div);
        if(BitRate >= Sampling)
        {
            break;
        }
        else if(BitRate < Sampling)
        {
            Div++;
        }
    }

    // BaudRate = RefClk/Div, 0x02~0xFF
    REGRW32(rSSP_BASE(Ch), rSSP_CLK_DIV) = Div - 1;
}


INT32 ncDrv_SSP_sRead(eSSP_CH Ch, UINT8 *pBuf, UINT32 Length, eSSP_DS DataWidth)
{
    INT32  Ret = NC_SUCCESS;
    UINT32 i;
    UINT16 *pBuf16 = (UINT16 *) pBuf;
    UINT8  DIV = 1;

    if(DataWidth > SSP_DS_8BIT)
    {
        pBuf16 = (UINT16 *) pBuf;
        DIV = 2;
    }

    for(i = 0; i < (Length/DIV); i++)
    {
        // Read data
        if(DataWidth > SSP_DS_8BIT)
            pBuf16[i] = (UINT16) (REGRW32(rSSP_BASE(Ch), rSSP_RX)&0xFFFF);
        else
            pBuf[i]   = (UINT8)  (REGRW32(rSSP_BASE(Ch), rSSP_RX)&0xFF);
    }

    return Ret;
}


INT32 ncDrv_SSP_sWrite(eSSP_CH Ch, UINT8 *pBuf, UINT32 Length, eSSP_DS DataWidth)
{
    INT32  Ret = NC_SUCCESS;
    UINT32 i;
    UINT16 *pBuf16 = (UINT16 *)pBuf;
    UINT8  DIV = 1;

    // Check Data Width
    if(DataWidth > SSP_DS_8BIT)
    {
        pBuf16 = (UINT16 *)pBuf;
        DIV = 2;
    }

    for(i=0; i<(Length/DIV); i++)
    {
        // Data Write
        if(DataWidth > SSP_DS_8BIT)
            REGRW32(rSSP_BASE(Ch), rSSP_TX) = pBuf16[i];
        else
            REGRW32(rSSP_BASE(Ch), rSSP_TX) = pBuf[i];
    }

    return Ret;
}


INT32 ncDrv_SSP_mRead(eSSP_CH Ch, UINT8 *pBuf, UINT32 Length, eSSP_DS DataWidth)
{
    INT32  Ret = NC_FAILURE;
    UINT32 i;
    UINT16 *pBuf16 = (UINT16 *) pBuf;
    UINT8  DIV = 1;

    if(DataWidth > SSP_DS_8BIT)
    {
        pBuf16 = (UINT16 *) pBuf;
        DIV = 2;
    }

    // Clear Rx Buffer
    REGRW32(rSSP_BASE(Ch), rSSP_RX_CLR) = 1;

    for(i = 0; i < (Length/DIV); i++)
    {  
        // Check Busy
        Ret = ncDrv_SSP_WaitBusIsBusy(Ch, "R-Busy");


        // Write Dummy data
        REGRW32(rSSP_BASE(Ch), rSSP_TX) = 0x00;


        // Wait Transfer Done.
        Ret = ncDrv_SSP_WaitBusIsBusy(Ch, "R-Done");


        // Read data
        if(DataWidth > SSP_DS_8BIT)
            pBuf16[i] = (UINT16)(REGRW32(rSSP_BASE(Ch), rSSP_RX)&0xFFFF);
        else
            pBuf[i]   = (UINT8) (REGRW32(rSSP_BASE(Ch), rSSP_RX)&0xFF);
    }

    return Ret;
}


INT32 ncDrv_SSP_mWrite(eSSP_CH Ch, UINT8 *pBuf, UINT32 Length, eSSP_DS DataWidth)
{
    INT32  Ret = NC_FAILURE;
    //UINT32 Temp;
    UINT32 i;
    UINT16 *pBuf16 = (UINT16 *)pBuf;
    UINT8  DIV = 1;


    // Check Data Width
    if(DataWidth > SSP_DS_8BIT)
    {
        pBuf16 = (UINT16 *)pBuf;
        DIV = 2;
    }

    for(i=0; i<(Length/DIV); i++)
    {
        // Check Busy
        Ret = ncDrv_SSP_WaitBusIsBusy(Ch, "W-Busy");


        // Data Write
        if(DataWidth > SSP_DS_8BIT)
            REGRW32(rSSP_BASE(Ch), rSSP_TX) = pBuf16[i];
        else
            REGRW32(rSSP_BASE(Ch), rSSP_TX) = pBuf[i];


        // Wait Transfer Done.
        Ret = ncDrv_SSP_WaitBusIsBusy(Ch, "W-Done");

        
        // Clear Rx Buffer
        //Temp = REGRW32(rSSP_BASE(Ch), rSSP_RX)&0xFFFF;
        REGRW32(rSSP_BASE(Ch), rSSP_RX_CLR) = 1;
    }

    return Ret;
}


void ncDrv_SSP_DeInit(eSSP_CH Ch)
{
    // CR1 Clear
    REGRW32(rSSP_BASE(Ch), rSSP_CR1) = 0x0;  
    
    // Disable SSP and Clear
    REGRW32(rSSP_BASE(Ch), rSSP_CR0) = 0x0;  
}


void ncDrv_SSP_Init(eSSP_CH Ch, ptSSP_PARAM ptSSPParam, UINT32 InClk)
{
    UINT32 Reg;


    // Disable SSP and Clear
    REGRW32(rSSP_BASE(Ch), rSSP_CR0) = 0x0;  


    // Set BitRate
    ncDrv_SSP_SetBitRate(Ch, ptSSPParam->mBitRate, InClk);


    // Set Data Width
    Reg = REGRW32(rSSP_BASE(Ch), rSSP_CR1);
    Reg &= ~bSSP_CR1_DS_MASK;
    Reg |= (ptSSPParam->mDataWidth<<8);
    REGRW32(rSSP_BASE(Ch), rSSP_CR1) = Reg;

    
    
    // Set Operation and Enable SSP
    Reg = (0<<bSSP_CR0_CSEN) 
        | (ptSSPParam->mIntEn<<bSSP_CR0_IEN) 
        | (ptSSPParam->mSPH<<bSSP_CR0_SPH) 
        | (ptSSPParam->mSPO<<bSSP_CR0_SPO) 
        | (ptSSPParam->mMode<<bSSP_CR0_OP)
        | (ptSSPParam->mOrder<<bSSP_CR0_DIR)
        | (1<<bSSP_CR0_MOD) 
        | (1<<bSSP_CR0_EN);  
    REGRW32(rSSP_BASE(Ch), rSSP_CR0) = Reg;  
}


/* End Of File */

