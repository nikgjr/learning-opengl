/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __NAND_DRV_H__
#define __NAND_DRV_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define rFSM_BASE                       (APACHE_FMC_BASE)


#define rFSM_STS                        0x00
#define rFSM_CFG                        0x04
#define rFSM_INT_CLR                    0x08
#define rFSM_CYCLES                     0x0C
    #define bFSM_CYCLES_PRESCALE        (25)
    #define bFSM_CYCLES_RR              (22)
    #define bFSM_CYCLES_ALR             (19)
    #define bFSM_CYCLES_CEA             (16)
    #define bFSM_CYCLES_WL              (12)
    #define bFSM_CYCLES_WH              (8)
    #define bFSM_CYCLES_RH              (4)
    #define bFSM_CYCLES_RL              (0)

#define rFSM_SET_ECC                    0x10
#define rFSM_CAL_ECC                    0x14
#define rFSM_CAL_RESULTS                0x18
#define rFSM_RUC_ECC                    0x1C










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/


#endif  /* __NAND_DRV_H__ */


/* End Of File */

