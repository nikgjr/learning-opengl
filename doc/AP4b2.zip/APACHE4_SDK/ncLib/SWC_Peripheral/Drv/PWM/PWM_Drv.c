/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "PWM_Drv.h"










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

UINT32 ncDrv_PWM_GetScal(ePWM_CH Ch)
{
    return ((REGRW32(rPWM_ADDR(Ch), rPWM_CFG) & bPWM_CFG_SCAL_MASK) >> bPWM_CFG_SCAL);
}


INT32 ncDrv_PWM_SetFrequency(ePWM_CH Ch, UINT32 Freq, UINT32 Duty, UINT32 Scal, UINT32 RefClk)
{
    INT32 Ret = NC_SUCCESS;
    
    UINT32 Period;
    UINT32 DutyCycle; 

    if( (Ch < MAX_OF_PWM_CH) 
        && (RefClk != 0)
        && (Freq >= PWM_FREQ_MIN)
        && ((Duty >= PMW_DUTY_MIN) && (Duty <= PWM_DUTY_MAX)))
    {
        Period    = ((RefClk/(Scal+1))/Freq);
        DutyCycle = ((Period*Duty)/100);

        // Defence Code
        DutyCycle = (DutyCycle==0)?1:DutyCycle;
        
        // Set mFrequency and Duty Cycle
        REGRW32(rPWM_ADDR(Ch), rPWM_CNTPA) = Period;
        REGRW32(rPWM_ADDR(Ch), rPWM_CNTPO) = DutyCycle;
        //DEBUGMSG_SDK(MSGINFO, "[PWM_Drv] %02d %06d\n", Duty, DutyCycle);        
    }
    else
    {
        DEBUGMSG_SDK(MSGERR, "[PWM_Drv] Error Frequency Set\n");
        Ret = NC_FAILURE;
    }

    return Ret;
}


INT32 ncDrv_PWM_GetStatus(ePWM_CH Ch)
{
    UINT32 Reg;

    Reg = (REGRW32(rPWM_BASE, rPWM_INT_STS)&(1<<Ch));
    REGRW32(rPWM_BASE, rPWM_INT_CLR) = Reg;

    Reg |= (REGRW32(rPWM_ADDR(Ch), rPWM_CFG)&bPWM_CFG_OP);

    return Reg;
}


void ncDrv_PWM_Stop(ePWM_CH Ch)
{
    UINT32 Reg;

    Reg = REGRW32(rPWM_ADDR(Ch), rPWM_CFG);
    Reg &= ~bPWM_CFG_EN;
    REGRW32(rPWM_ADDR(Ch), rPWM_CFG) = Reg;
}


void ncDrv_PWM_Start(ePWM_CH Ch)
{
    UINT32 Reg;
    
    Reg = REGRW32(rPWM_ADDR(Ch), rPWM_CFG);
    Reg |= bPWM_CFG_EN;
    REGRW32(rPWM_ADDR(Ch), rPWM_CFG) = Reg;

    REGRW32(rPWM_BASE, rPWM_START) = (1<<Ch);
}


void ncDrv_PWM_DeInit(ePWM_CH Ch)
{
    REGRW32(rPWM_ADDR(Ch), rPWM_CFG)   = 0;
    REGRW32(rPWM_ADDR(Ch), rPWM_CNTPA) = 0;
    REGRW32(rPWM_ADDR(Ch), rPWM_CNTPO) = 0;

    REGRW32(rPWM_BASE, rPWM_INT_CLR) = (1<<Ch);
}


INT32 ncDrv_PWM_Init(ePWM_CH Ch, ptPWM_PARAM ptPWM, UINT32 RefClk)
{
    INT32 Ret = NC_SUCCESS;

    Ret = ncDrv_PWM_SetFrequency(Ch, ptPWM->mFrequency, ptPWM->mDutyCycle, (ptPWM->mScale>>bPWM_CFG_SCAL), RefClk);
    
    if(Ret == NC_SUCCESS)
    {
        // Set PWM Config
        REGRW32(rPWM_ADDR(Ch), rPWM_CFG) = (ptPWM->mMode|ptPWM->mScale|ptPWM->mLevel|ptPWM->mOutEn|ptPWM->mIsrEn);
    }
    else
    {
        DEBUGMSG_SDK(MSGERR, "[PWM_Drv] Error Channle Init\n");
        Ret = NC_FAILURE;
    }

	return Ret;
}


void ncDrv_PWM_DeInitialize(void)
{
    ePWM_CH Ch;

    for(Ch=PWM_CH0; Ch<MAX_OF_PWM_CH; Ch++)
    {
        ncDrv_PWM_DeInit(Ch);
    }
}


INT32 ncDrv_PWM_Initialize(UINT32 PreScale)
{
    ePWM_CH Ch;

    REGRW32(rPWM_BASE, rPWM_SCALE) = PreScale;
    
    for(Ch=PWM_CH0; Ch<MAX_OF_PWM_CH; Ch++)
    {
        ncDrv_PWM_DeInit(Ch);
    }

    return NC_SUCCESS;
}


/* End Of File */

