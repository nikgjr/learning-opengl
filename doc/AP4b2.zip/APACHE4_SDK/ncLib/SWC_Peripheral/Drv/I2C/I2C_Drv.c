/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/

#include "Apache.h"

#include "I2C_Drv.h"










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

INT32 ncDrv_I2C_GetIntSts(ptI2C_INFO ptI2C)
{
    INT32 Ret;
    eI2C_CH Ch = ptI2C->mI2C_ChNum;

    if(ptI2C->mI2C_Param.mOpMode == I2C_OP_MODE_MASTER)
        Ret = ncDrv_I2C_mGetIntSts(Ch);
    else
        Ret = ncDrv_I2C_sGetIntSts(Ch);
    
    return Ret;
}


void ncDrv_I2C_SetIntClear(ptI2C_INFO ptI2C)
{
    eI2C_CH Ch = ptI2C->mI2C_ChNum;

    if(ptI2C->mI2C_Param.mOpMode == I2C_OP_MODE_MASTER)
        ncDrv_I2C_mIntClear(Ch);
    else
        ncDrv_I2C_sIntClear(Ch);
}


INT32 ncDrv_I2C_SetDevAddr(ptI2C_INFO ptI2C)
{
    INT32 Ret = NC_FAILURE;
    eI2C_CH Ch = ptI2C->mI2C_ChNum;

    if(ptI2C->mI2C_Param.mOpMode == I2C_OP_MODE_MASTER)
        ncDrv_I2C_mSetDevAddr(Ch, ptI2C->mI2C_Param.mDevAddr);
    else
        ncDrv_I2C_sSetDevAddr(Ch, ptI2C->mI2C_Param.mDevAddr);

    return Ret;
}


INT32 ncDrv_I2C_SetClock(ptI2C_INFO ptI2C)
{
    INT32 Ret;
    eI2C_CH Ch = ptI2C->mI2C_ChNum;

    if(ptI2C->mI2C_Param.mOpMode == I2C_OP_MODE_MASTER)
        Ret = ncDrv_I2C_mSetClock(Ch, ptI2C->mI2C_SrcClk, ptI2C->mI2C_Param.mHz);
    else
        Ret = ncDrv_I2C_sSetClock(Ch, ptI2C->mI2C_SrcClk, ptI2C->mI2C_Param.mHz);

    return Ret;
}


INT32 ncDrv_I2C_ReadData(ptI2C_INFO ptI2C, UINT16 RegAddr, UINT8* pBuff, UINT32 UnitCnt)
{
    INT32 Ret;

    if(ptI2C->mI2C_Param.mOpMode == I2C_OP_MODE_MASTER)
        Ret = ncDrv_I2C_mReadData(ptI2C, RegAddr, pBuff, UnitCnt);
    else
        Ret = ncDrv_I2C_sReadData(ptI2C->mI2C_ChNum, RegAddr, pBuff, UnitCnt);

    return Ret;
}


INT32 ncDrv_I2C_WriteData(ptI2C_INFO ptI2C, UINT16 RegAddr, UINT8* pBuff, UINT32 UnitCnt)
{
    INT32 Ret;

    if(ptI2C->mI2C_Param.mOpMode == I2C_OP_MODE_MASTER)
        Ret = ncDrv_I2C_mWriteData(ptI2C, RegAddr, pBuff, UnitCnt);
    else
        Ret = ncDrv_I2C_sWriteData(ptI2C->mI2C_ChNum, RegAddr, pBuff, UnitCnt);

    return Ret;
}


INT32 ncDrv_I2C_DeInitialize(ptI2C_INFO ptI2C)
{
    INT32 Ret;
    eI2C_CH Ch = ptI2C->mI2C_ChNum;

    if(ptI2C->mI2C_Param.mOpMode == I2C_OP_MODE_MASTER)
        Ret = ncDrv_I2C_mDeInitialize(Ch);
    else
        Ret = ncDrv_I2C_sDeInitialize(Ch);
        
    return Ret;
}


INT32 ncDrv_I2C_Initialize(ptI2C_INFO ptI2C)
{
    INT32 Ret;

    if(ptI2C->mI2C_Param.mOpMode == I2C_OP_MODE_MASTER)
    {
        Ret = ncDrv_I2C_mInitialize(ptI2C->mI2C_ChNum, 
                                    ptI2C->mI2C_Param.mIntEn,
                                    ptI2C->mI2C_SrcClk,
                                    ptI2C->mI2C_Param.mHz);
    }
    else
    {
        Ret = ncDrv_I2C_sInitialize(ptI2C->mI2C_ChNum, 
                                    ptI2C->mI2C_Param.mIntEn,
                                    ptI2C->mI2C_Param.mDevAddr);
    }

    return Ret;
}


/* End Of File */

