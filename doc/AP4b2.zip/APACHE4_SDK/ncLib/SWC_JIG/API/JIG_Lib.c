/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/


/*
********************************************************************************
*               INCLUDE
********************************************************************************
*/

#include "Apache.h"

#include "JIG_Svc.h"










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

volatile BOOL gbJIGOpen = 0;
volatile eUART_CH gJigPort  = UART_CH1;










/*
********************************************************************************
*               FUNCTION DEFINITIONS
********************************************************************************
*/

INT32 ncLib_JIG_Open(void)
{
    INT32 Ret = NC_SUCCESS;

    gbJIGOpen = TRUE;

    return Ret;
}


INT32 ncLib_JIG_Close(void)
{
    INT32 Ret = NC_SUCCESS;

    gbJIGOpen = FALSE;
        
    return Ret;
}


INT32 ncLib_JIG_Write(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_JIG_Read(void)
{
    INT32 Ret = NC_SUCCESS;

    return Ret;
}


INT32 ncLib_JIG_Control(eJIG_CMD Cmd,  ...)
{
    INT32   Ret = NC_SUCCESS;

    UINT32  Count;
    UINT32  ArgData[CMD_MAX];
    va_list vList;
    BOOL    bEndCmd = FALSE;

    
    if(gbJIGOpen == TRUE)
    {
        /*
        * Parsing Variable Argument
        */

        va_start(vList, Cmd);

        for(Count = 0; Count < CMD_MAX; Count++)
        {
            ArgData[Count] = va_arg(vList, UINT32);

            if(ArgData[Count] == CMD_END)
            {
                bEndCmd = TRUE;
                break;
            }
        }

        va_end(vList);


        if(bEndCmd == FALSE)
        {
            Ret = NC_FAILURE;
        }
        else
        {
            /*
            * Implement Control Command Function
            */

            switch(Cmd)
            {
                case GCMD_JIG_INIT:
                {
                    tUART_PARAM tUARTParam;

                    gJigPort = (eUART_CH)ArgData[0];

                    tUARTParam.mIntEn    = ENABLE;
                    tUARTParam.mBaudRate = (UINT32)ArgData[1];
                    tUARTParam.mSPS      = UT_SPS_DIS;
                    tUARTParam.mLEN      = UT_DATA_8BIT;
                    tUARTParam.mSTP      = UT_STOP_1BIT;
                    tUARTParam.mEPS      = UT_EPS_DIS;
                    tUARTParam.mPEN      = UT_PARITY_DIS;
                    tUARTParam.mBRK      = UT_BRK_DIS;

                    ncLib_UART_Control(GCMD_UT_INIT_CH, gJigPort, &tUARTParam, CMD_END);

                    // Register UART Interrupt Handler
                    ncLib_INTC_Control(GCMD_INTC_REGISTER_INT, IRQ_NUM_UART0+gJigPort, (PrHandler)ncSvc_JIG_IRQ_Handler, CMD_END);

                    ncSvc_JIG_Init();
                }
                break;

                case GCMD_JIG_DEINIT:
                {
                    ncLib_UART_Control(GCMD_UT_DEINIT_CH, gJigPort, CMD_END);

                    ncSvc_JIG_DeInit();
                }
                break;

                case GCMD_JIG_DO_COMMAND:
                    Ret = ncSvc_JIG_CommandMain();
                break;

                default:
                    Ret = NC_FAILURE;
                break;
            }
        }
    }
    else
    {
        Ret = NC_FAILURE;
    }

    return Ret;
}


void ncLib_JIG_Printf(const char *fmt, ...)
{
    va_list vList;
    char Buff[512];

    va_start(vList, fmt);

    vsnprintf(Buff, sizeof(Buff), fmt, vList);

    va_end(vList);

    ncLib_UART_Control(GCMD_UT_PUT_STR, gJigPort, Buff, CMD_END);
}


/* End Of File */

