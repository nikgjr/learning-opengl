/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __TIMER_LIB_H__
#define __TIMER_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* TIMER GENERIC & SPECIFIC COMMANDS
*/

typedef enum _TIMER_CMD
{
    /*
    * Generic Timer / Count Commands
    */
    GCMD_TC_INIT_CH = 0,
    GCMD_TC_DEINIT_CH,
    GCMD_TC_START,
    GCMD_TC_STOP,
    GCMD_TC_GET_INT_STS,
    
    GCMD_TC_MAX,

    /*
    * Specific Timer / Count Commands
    */
    SCMD_TC_WDT_REFRESH = 100,
    SCMD_TC_MAX
} eTIMER_CMD;


typedef enum
{
    TC_CH0 = 0,
    TC_CH1,
    TC_CH2,
    TC_CH3,
    TC_CH4,
    TC_CH5, 
    TC_CH6,
    TC_CH7, 
    MAX_OF_TIMER_CH
} eTIMER_CH;


typedef enum _TIMER_MODE
{
    TC_MODE_PERIOD = 0,
    TC_MODE_PWM,                        // Not Used	            
    TC_MODE_ONESHOT,
    TC_MODE_CAPTURE,                    // Not Used	
    TC_MODE_WDT,
    TC_MODE_MAX
} TIMER_MODE;










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{
    UINT8  mMode;               // enum _TIMER_MODE
    UINT8  mClockSource;        // Not Used.
    UINT8  mPrescaler;          // 0~0xFFFF
    UINT8  mTrigMode;           // Not Used.
    UINT32 mPeriod1;            // 1'st period (usec)
    UINT32 mPeriod2;            // Not Used.
} tTIMER_PARAM, *ptTIMER_PARAM;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32  ncLib_TIMER_Open(void);
extern INT32  ncLib_TIMER_Close(void);
extern INT32  ncLib_TIMER_Read(void);
extern INT32  ncLib_TIMER_Write(void);
extern INT32  ncLib_TIMER_Control(eTIMER_CMD Cmd, ...);


#endif /* __TIMER_LIB_H__ */


/* End Of File */

