/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __DMA_LIB_H__
#define __DMA_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               DEFINES
********************************************************************************
*/

#define DMA_BURST_LEN_MIN           1
#define DMA_BURST_LEN_MAX           32

#define DMA_TRANSFER_SIZE           0x3E0










/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* DMAC GENERIC & SPECIFIC COMMANDS
*/

typedef enum _DMA_CMD
{
    /*
    * Generic Commands
    */

    GCMD_DMA_INIT_CH = 0,
    GCMD_DMA_DEINIT_CH,
    GCMD_DMA_START,
    GCMD_DMA_DONE,
    GCMD_DMA_SET_BURST_LEN,
    GCMD_DMA_GET_INT_STS,
    
    GCMD_DMA_MAX

} eDMA_CMD;


typedef enum
{
    DMA_CH0,
    DMA_CH1,
    DMA_CH2,
    DMA_CH3,
    MAX_OF_DMA_CH
} eDMA_CH;


typedef enum
{
    DMA_MEM_TO_MEM,
    DMA_MEM_TO_DEV,
    DMA_DEV_TO_MEM,
    MAX_OF_DMA_TYPE
} eDMA_TYPE;


typedef enum
{
    DMA_SPI0 = 1,
    DMA_SPI1,
    MAX_OF_DMA_PERI_NUM
} eDMA_PERI_NUM;


typedef enum
{
    DMA_SWAP_NO = 0,
    DMA_SWAP_16BIT,
    DMA_SWAP_32BIT,   
    MAX_OF_DMA_SWAP
} eDMA_SWAP;










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct
{  
    BOOL            mIntEn;             // Interrupt            : On or Off   
    eDMA_TYPE       mReqType;    
    eDMA_PERI_NUM   mPeriNum;    
    eDMA_SWAP       mSwap;              // Endianness byte swapping
    
    BOOL            mRxIncrEn;          // Rx Address Increment : On or Off          
    UINT32          mRxBurstLen;        // Rx - Burst Length    
    BOOL            mTxIncrEn;          // Tx Address Increment : On or Off      
    UINT32          mTxBurstLen;        // Tx - Burst Length
    
    UINT32          mInstAddr;          // DMA Instruction Buffer Addr  : Buffer Size = (Tranfer_Data_Size/512)*16;  
} tDMA_PARAM, *ptDMA_PARAM;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_DMA_Open(void);
extern INT32 ncLib_DMA_Close(void);
extern INT32 ncLib_DMA_Read(void);
extern INT32 ncLib_DMA_Write(void);
extern INT32 ncLib_DMA_Control(eDMA_CMD Cmd, ...);


#endif /* __DMA_LIB_H__ */


/* End Of File */

