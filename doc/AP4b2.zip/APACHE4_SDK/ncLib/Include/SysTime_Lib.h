/**
********************************************************************************
*
*  Copyright (C) 2018 NEXTCHIP Inc. All rights reserved.
*
*  @file    : SysTime_Lib.h
*
*  @brief   :
*
*  @author  :
*
*  @date    :
*
*  @version : Version 0.0.1
*
********************************************************************************
*  @note
*
********************************************************************************
*/

#ifndef __SYSTIME_LIB_H__
#define __SYSTIME_LIB_H__


/*
********************************************************************************
*               INCLUDE                                    
********************************************************************************
*/



/*
********************************************************************************
*               DEFINES
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* SYSTIME GENERIC & SPECIFIC COMMANDS
*/

typedef enum _SYSTIME_CMD
{
	/*
	 * Generic System Timer Commands
	 */
	GCMD_ST_START_SYSTIME = 0,      // Start system timer
	GCMD_ST_STOP_SYSTIME,           // Stop system timer
	GCMD_ST_SET_SYSTIME,            // Set system time using tTIME_VAL structure
	GCMD_ST_GET_SYSTIME,            // Get system time using tTIME_VAL structure
	GCMD_ST_SET_SYSTIME_DATE,       // Set system time using SYS_TIME structure
	GCMD_ST_GET_SYSTIME_DATE,       // Get system time using SYS_TIME structure
	GCMD_ST_CONNECT_PTE_HANDLER,    // Connect periodic timing event handler
	GCMD_ST_DISCONNECT_PTE_HANDLER, // Disconnect periodic timing event handler
	GCMD_ST_MDELAY,
	GCMD_ST_MAX,

	/*
	 * Specific System Timer Commands
	 */
	SCMD_ST_DUMMY = 100,
	SCMD_ST_MAX,
} eSYSTIME_CMD;


enum __TIME_FORMAT__
{
	US,
	ASIA,
	EURO
};

/*
 * Periodic Timing Event
 */
typedef enum _PTIME_EVENT
{
	ST_PTE_MSEC1 = 0,
	ST_PTE_MSEC2,
	ST_PTE_MSEC3,
	ST_PTE_1SEC
} PTIME_EVENT;










/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

/*
 * For System Timer
 */
typedef struct _TIME_VAL {
    UINT32          tv_sec;     /* seconds */
    UINT32          tv_usec;    /* microseconds */
} tTIME_VAL, *ptTIME_VAL;










/*
********************************************************************************
*               CONSTANT DEFINITIONS
********************************************************************************
*/


/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/


/*
********************************************************************************
*               FUNCTION DECLARATIONS
********************************************************************************
*/

extern INT32  ncLib_SYSTIME_Open(void);
extern INT32  ncLib_SYSTIME_Close(void);
extern INT32  ncLib_SYSTIME_Read(void);
extern INT32  ncLib_SYSTIME_Write(void);
extern INT32  ncLib_SYSTIME_Control(eSYSTIME_CMD Cmd, ...);


#endif /* __SYSTIME_LIB_H__ */


/* End Of File */

