/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __NAND_LIB_H__
#define __NAND_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* NAND GENERIC & SPECIFIC COMMANDS
*/

typedef enum _NAND_CMD
{
    /*
    * Generic Commands
    */

    GCMD_NAND_INIT = 0,
    GCMD_NAND_DEINIT,
    
    GCMD_NAND_MAX,
    
} eNAND_CMD;











/*
********************************************************************************
*               TYPEDEFS
********************************************************************************
*/

typedef struct _tNAND_PARAM
{
    BOOL    mIntEn;   
    BOOL    mEccEn;    
    BOOL    mDmaEn;
} tNAND_PARAM, *ptNAND_PARAM;










/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_NAND_Open(void);
extern INT32 ncLib_NAND_Close(void);
extern INT32 ncLib_NAND_Read(void);
extern INT32 ncLib_NAND_Write(void);
extern INT32 ncLib_NAND_Control(eNAND_CMD Cmd, ...);


#endif /* __NAND_LIB_H__ */


/* End Of File */

