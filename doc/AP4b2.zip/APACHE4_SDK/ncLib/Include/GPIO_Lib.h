/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __GPIO_LIB_H__
#define __GPIO_LIB_H__


/*
********************************************************************************
*               INCLUDE                                 
********************************************************************************
*/


/*
********************************************************************************
*               ENUMERATION
********************************************************************************
*/

/*
* GPIO GENERIC & SPECIFIC COMMANDS
*/

typedef enum _GPIO_CMD
{
    /*
    * Generic Commands
    */

    GCMD_GPIO_ENA = 0,
    GCMD_GPIO_DIS,
    
    GCMD_GPIO_SET_DIR,
    GCMD_GPIO_SET_DATA,
    GCMD_GPIO_GET_DATA,

    GCMD_GPIO_SET_INTC,

    GCMD_GPIO_MAX,
    
} eGPIO_CMD;

typedef enum
{
    GPIO_GROUP_A,           // [31:0]
    GPIO_GROUP_B,           // [31:0]
    GPIO_GROUP_C,           // [14:0]
    GPIO_GROUP_D,           // FPGA Test PIN
    
    GPIO_GROUP_PAD,
    MAX_OF_GPIO_GROUP
} eGPIO_GROUP;

typedef enum
{
    GPIO_PORT0,
    GPIO_PORT1,
    GPIO_PORT2,
    GPIO_PORT3,
    GPIO_PORT4,
    GPIO_PORT5,
    GPIO_PORT6,
    GPIO_PORT7,

    GPIO_PORT8,
    GPIO_PORT9,
    GPIO_PORT10,
    GPIO_PORT11,
    GPIO_PORT12,
    GPIO_PORT13,
    GPIO_PORT14,
    GPIO_PORT15,

    GPIO_PORT16,
    GPIO_PORT17,
    GPIO_PORT18,
    GPIO_PORT19,
    GPIO_PORT20,
    GPIO_PORT21,
    GPIO_PORT22,
    GPIO_PORT23,

    GPIO_PORT24,
    GPIO_PORT25,
    GPIO_PORT26,
    GPIO_PORT27,
    GPIO_PORT28,
    GPIO_PORT29,
    GPIO_PORT30,
    GPIO_PORT31,
    MAX_OF_GPIO_PORT,
    GPIO_PORT_NOT_USED
} eGPIO_PORT;

typedef enum
{
    GPIO_LOW,
    GPIO_HIGH,
    MAX_OF_GPIO_DATA
} eGPIO_DATA;

typedef enum
{
    GPIO_DIR_IN,    
    GPIO_DIR_OUT,
    MAX_OF_GPIO_DIR
} eGPIO_DIR;


typedef enum
{
    GPIO_INT_CH0,
    GPIO_INT_CH1,
    GPIO_INT_CH2,
    MAX_OF_GIIO_INT_CH
} eGPIO_INT_CH;

typedef enum
{
    GPIO_TRIG_RISING,           // ___|~ (Trigger)
    GPIO_TRIG_FALLING,          // ~~~|_ (Trigger)
    MAX_OF_GPIO_TRIG
} eGPIO_TRIG;









/*
********************************************************************************
*               FUNCTION DEFINITIONS                              
********************************************************************************
*/

extern INT32 ncLib_GPIO_Open(void);
extern INT32 ncLib_GPIO_Close(void);
extern INT32 ncLib_GPIO_Read(void);
extern INT32 ncLib_GPIO_Write(void);
extern INT32 ncLib_GPIO_Control(eGPIO_CMD Cmd, ...);


#endif /* __GPIO_LIB_H__ */


/* End Of File */

