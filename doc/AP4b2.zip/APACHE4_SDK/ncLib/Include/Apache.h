/**
********************************************************************************
*
*  Copyright (C) 2017 NEXTCHIP Inc. All rights reserved.
*
*  @file    : 
*
*  @brief   :
*
*  @author  : 
*
*  @date    : 
*
*  @version : 
*
********************************************************************************
*  @note    : 
*
********************************************************************************
*/

#ifndef __APACHE_H__
#define __APACHE_H__


/*
********************************************************************************
*               INCLUDE                                    
********************************************************************************
*/

#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

#include "Type.h"

/* Peripheral Libraries */
#include "Debug_Lib.h"
#include "DMA_Lib.h"
#include "GPIO_Lib.h"
#include "I2C_Lib.h"
#include "INTC_Lib.h"
#include "PWM_Lib.h"
#include "QSPI_Lib.h"
#include "SCU_Lib.h"
#include "SSP_Lib.h"
#include "sFlash_Lib.h"
#include "SysTime_Lib.h"
#include "Timer_Lib.h"
#include "Uart_Lib.h"
#include "NAND_Lib.h"
#include "SDC_Lib.h"
#include "CAN_Lib.h"
#include "IPC_Lib.h"
#include "VDUMP_Lib.h"

/* ISP Libraries */
//#include "ISP_Lib.h"


/* RE Libraries */
//#include "RE_Lib.h"


/* JIG Libraries */
#include "JIG_Lib.h"










/*
********************************************************************************
*               MEMORY MAP FOR APACHE                             
********************************************************************************
*/

/* Storage Memory Map */

#define APACHE_IROM_BASE                0x00000000
#define APACHE_IRAM_BASE                0x04000000
#define APACHE_NAND_BASE                0x70000000
#define APACHE_DRAM_BASE                0x80000000


/* Peripheral Memory Map */

#define APACHE_SYSCON_BASE              0x08000000
#define APACHE_ICU_BASE                 0x08100000
#define APACHE_GPIO_BASE                0x08101000
#define APACHE_ADC_BASE                 0x08200000
#define APACHE_IPC_BASE                 0x0C400000
#define APACHE_INTC_BASE                0x10000000
#define APACHE_DMAC_BASE                0x10100000
#define APACHE_TIMER0_BASE              0x10300000
#define APACHE_TIMER1_BASE              0x10400000
#define APACHE_PWM_BASE                 0x10500000
#define APACHE_I2C_0_BASE               0x10600000
#define APACHE_I2C_1_BASE               0x10700000
#define APACHE_UART_0_BASE              0x10800000
#define APACHE_UART_1_BASE              0x10900000
#define APACHE_UART_2_BASE              0x10A00000
#define APACHE_UART_3_BASE              0x10B00000
#define APACHE_SPI_0_BASE               0x10C00000
#define APACHE_SPI_1_BASE               0x10D00000
#define APACHE_QSPI_BASE                0x10E00000
#define APACHE_CAN_BASE                 0x10F00000
#define APACHE_DDRC_BASE                0x12000000
#define APACHE_FMC_BASE                 0x12300000
#define APACHE_SDC_BASE                 0x12400000
#define APACHE_DSP_BASE                 0x13000000
#define APACHE_RE_BASE                  0x14000000
#define APACHE_ISP_BASE                 0x14800000
#define APACHE_VDUMP_BASE               0x15000000
#define APACHE_GLD_BASE                 0x15800000
#define APACHE_OSG_BASE                 0x16000000
#define APACHE_MIPI_BASE                0x16800000










/*
********************************************************************************
*               DEFINES                                    
********************************************************************************
*/

#define DLS_CORE                        0
#define SINGLE_CORE                     1










/*
*******************************************************************************
*               DEFINITION FOR ARM ASM CODE SECTION                      
*******************************************************************************
*/

extern UINT32 ASM_GET_CORE_ID(void);    // Check Core ID (0: DLS, 1: Single)
extern void   ASM_DCACHE_FLUSH(UINT32 Addr, UINT32 Size);   // Cache Flush 










/*
********************************************************************************
*               VARIABLE DECLARATIONS
********************************************************************************
*/

#ifdef __MAIN_C__
#define GLOBAL
#else
#define GLOBAL extern
#endif

// Init Value : ncLib_SCU_Open() Function Call. (read only variable)
GLOBAL UINT32 SYS_TICK_CLK;

// Init Value : main() Function (user must be set in main function)
GLOBAL UINT32 SYS_DEBUG_PORT;










/*
*******************************************************************************
*               INLINE FUNCTION FOR APACHE
*******************************************************************************
*/

static __inline UINT32 nc_get_tick(UINT32 cls)
{
    UINT32 RegOffset;

    // Check Core Id
    if(ASM_GET_CORE_ID() == DLS_CORE)
        RegOffset = 0x3000;
    else
        RegOffset = 0x3008;
    
    if(cls)
    {
        // Clear : Count == 0
        REGRW32(APACHE_SYSCON_BASE, RegOffset) = 0x0;
    }

    return REGRW32(APACHE_SYSCON_BASE, RegOffset);
}


static __inline void nc_wait_tick(UINT32 ticks)
{
    UINT32 sTicks = nc_get_tick(1);

    while ((nc_get_tick(0) - sTicks) < ticks);
}


static __inline void nc_delay(UINT32 s)
{
    // limit 10-sec
    if(s > 10) s = 10;

    nc_wait_tick(SYS_TICK_CLK * s);
}


static __inline void nc_mdelay(UINT32 ms)
{
    // limit 10-sec
    if(ms > 10000) ms = 10000;

    nc_wait_tick((SYS_TICK_CLK / MSEC) * ms);
}


static __inline void nc_udelay(UINT32 us)
{
    // limit 10-sec
    if(us > 10000000) us = 10000000;

    nc_wait_tick((SYS_TICK_CLK / USEC) * us);
}


static __inline unsigned int nc_get_msec(UINT32 cls)
{
    UINT32 curr_tick = nc_get_tick(cls);

    if(curr_tick)
        curr_tick = curr_tick / (SYS_TICK_CLK / MSEC);

    return curr_tick;
}


static __inline unsigned int nc_get_usec(UINT32 cls)
{
    UINT32 curr_tick = nc_get_tick(cls);

    if(curr_tick)
        curr_tick = curr_tick / (SYS_TICK_CLK / USEC);

    return curr_tick;
}


static __inline UINT32 nc_get_tick_auto_cls(void)
{
    UINT32 RegOffset;

    // Check Core Id
    if(ASM_GET_CORE_ID() == DLS_CORE)
        RegOffset = 0x3004;
    else
        RegOffset = 0x300C;
    
    // It is initialized to '0' when reading the register.
    return REGRW32(APACHE_SYSCON_BASE, RegOffset);
}


static __inline UINT32 nc_get_msec_auto_cls(void)
{
    UINT32 curr_tick = nc_get_tick_auto_cls();

    if(curr_tick)
        curr_tick = curr_tick / (SYS_TICK_CLK / MSEC);

    return curr_tick;
}


static __inline UINT32 nc_get_usec_auto_cls(void)
{
    UINT32 curr_tick = nc_get_tick_auto_cls();

    if(curr_tick)
        curr_tick = curr_tick / (SYS_TICK_CLK / USEC);

    return curr_tick;
}


static __inline UINT32 nc_conv_vir_to_phy(UINT32 Addr)
{
    UINT32 Remap_Start;
    UINT32 Remap_End;

    UINT32 RegOffset;
    
    // Check Core Id
    if(ASM_GET_CORE_ID() == DLS_CORE)
        RegOffset = 0x104;
    else
        RegOffset = 0x110;

    // Check Remap Enable 
    if(REGRW32(APACHE_SYSCON_BASE, 0x100)&0x01) 
    {
        Remap_Start = REGRW32(APACHE_SYSCON_BASE, RegOffset);
        Remap_End   = REGRW32(APACHE_SYSCON_BASE, (RegOffset+0x20));

        if(    (Addr >= Remap_Start) 
            && (Addr < (Remap_Start + (((Remap_End&0xFFFF)+1)*(64*KB)))))
        {
            Addr = Addr&~(Remap_Start);
            Addr |= (Remap_End&0xFFFF0000);
        }
    }

    return Addr;
}


//-----------------------------------------------------------------------------
// Spinlock
//-----------------------------------------------------------------------------

/*
 * lock number list
 * 0 : Interrupt Controller
 * 1 : UART_0 Debugging Message
 * */
 
#define SPINLOCK_INTC       0
#define SPINLOCK_UART       1

#define IPC_LOCK_REG                (APACHE_IPC_BASE+0x2000)
#define rSPINLOCK(num)              (*(volatile unsigned *)(IPC_LOCK_REG+(num*4)))


static __inline void SPIN_LOCK(UINT32 lockNum)
{
    /*
     * Read Only Register
     *  b'0000 - Lock Success
     *  b'1010 - Lock Fail(Wait~)
     * */
    while(rSPINLOCK(lockNum) == 0x0A);
}


static __inline void SPIN_UNLOCK(UINT32 lockNum)
{
    rSPINLOCK(lockNum) = 0x0;
}


#endif	/* __APACHE_H__ */


/* End Of File */

